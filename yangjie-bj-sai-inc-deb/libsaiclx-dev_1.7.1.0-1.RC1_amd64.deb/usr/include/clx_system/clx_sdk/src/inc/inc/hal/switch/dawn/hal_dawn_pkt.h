/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_pkt.h
 * PURPOSE:
 *      It provides hal pkt module API.
 *
 * NOTES:
 *
 */

#ifndef HAL_DAWN_PKT_H
#define HAL_DAWN_PKT_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_netif.h>
#include <clx_pkt.h>
#include <hal/common/hal_pkt_rsrc.h>
#if defined (CLX_EN_NETIF)
#include <clx_netif.h>
#endif

/* NAMING DECLARATIONS
 */
/* PKT definitions */
#define HAL_DAWN_PKT_TX_MAX_LEN              (9216)
#define HAL_DAWN_PKT_RX_MAX_LEN              (9216 + 86) /* EPP tunnel header */
#define HAL_DAWN_PKT_MIN_LEN                 (64)        /* Ethernet definition */
#define HAL_DAWN_PKT_TMH_HDR_SZ              (20)
#define HAL_DAWN_PKT_PPH_HDR_SZ              (20)
#define HAL_DAWN_PKT_CRC_LEN                 (4)

/* CH */
#define HAL_DAWN_PKT_CH_LAST_GPD             (0)
#define HAL_DAWN_PKT_CH_MIDDLE_GPD           (1)

/* PRG */
#define HAL_DAWN_PKT_PRG_PROCESS_GPD         (0) /* Normal   */
#define HAL_DAWN_PKT_PRG_SKIP_GPD            (1) /* Skip     */

/* CRCC */
#define HAL_DAWN_PKT_CRCC_SUM_BY_HW          (0) /* calculated by HW */
#define HAL_DAWN_PKT_CRCC_SUM_BY_SW          (1) /* calculated by SW */

/* IOC */
#define HAL_DAWN_PKT_IOC_NO_INTR             (0) /* trigger interrupt each GPD */
#define HAL_DAWN_PKT_IOC_HAS_INTR            (1) /* trigger interrupt when ch=0, default setting */

/* HWO */
#define HAL_DAWN_PKT_HWO_SW_OWN              (0)
#define HAL_DAWN_PKT_HWO_HW_OWN              (1)

/* ECC */
#define HAL_DAWN_PKT_ECC_ERROR_OCCUR         (1)

/* CPU, CPI queue number */
#define HAL_DAWN_PKT_CPU_QUE_NUM             (48)
#define HAL_DAWN_PKT_CPI_QUE_NUM             (8)

/* PDMA Definitions */
#define HAL_DAWN_PKT_PDMA_MAX_GPD_PER_PKT    (10)   /* <= 256   */
#define HAL_DAWN_PKT_PDMA_TX_INTR_TIMEOUT    (10 * 1000) /* us */
#define HAL_DAWN_PKT_PDMA_TX_POLL_MAX_LOOP   (10 * 1000) /* int */

/* Mode */
#define HAL_DAWN_PKT_TX_WAIT_MODE            (HAL_DAWN_PKT_TX_WAIT_ASYNC)

/* TX Queue */
#define HAL_DAWN_PKT_TX_TASK_MAX_LOOP        (HAL_DFLT_CFG_PKT_TX_QUEUE_LEN)

/* RX Queue */
#define HAL_DAWN_PKT_RX_QUEUE_NUM            (HAL_DAWN_PKT_RX_CHANNEL_LAST)
#define HAL_DAWN_PKT_RX_TASK_MAX_LOOP        (HAL_DFLT_CFG_PKT_TX_QUEUE_LEN)

/* MACRO FUNCTION DECLARATIONS
 */
/*---------------------------------------------------------------------------*/
/* [CL8360] Alignment to 64-bytes */
#if defined(CLX_EN_HOST_64_BIT_BIG_ENDIAN) || defined(CLX_EN_HOST_64_BIT_LITTLE_ENDIAN)
#define HAL_DAWN_PKT_PDMA_ALIGN_ADDR(pdma_addr, align_sz) (((pdma_addr) + (align_sz)) & 0xFFFFFFFFFFFFFFC0)
#else
#define HAL_DAWN_PKT_PDMA_ALIGN_ADDR(pdma_addr, align_sz) (((pdma_addr) + (align_sz)) & 0xFFFFFFC0)
#endif
/*---------------------------------------------------------------------------*/
#if defined(CLX_EN_BIG_ENDIAN)
#define HAL_DAWN_PKT_ENDIAN_SWAP32(val)  (val)
#else
#define HAL_DAWN_PKT_ENDIAN_SWAP32(val)  CMLIB_UTIL_ENDIAN_SWAP32(val)
#endif
/*---------------------------------------------------------------------------*/
#define HAL_DAWN_PKT_GET_BIT(flags, bit)             ((((flags) & (bit)) > 0)? 1 : 0)
/*---------------------------------------------------------------------------*/
#define HAL_DAWN_PKT_SET_BITMAP(bitmap, mask_bitmap) (bitmap = ((bitmap) | (mask_bitmap)))
#define HAL_DAWN_PKT_CLR_BITMAP(bitmap, mask_bitmap) (bitmap = ((bitmap) & (~(mask_bitmap))))
/*---------------------------------------------------------------------------*/
#define HAL_DAWN_PKT_GET_TX_INTR_TYPE(channel)       (HAL_INTR_TX_CH0 + channel)
#define HAL_DAWN_PKT_GET_RX_INTR_TYPE(channel)       (HAL_INTR_RX_CH0 + channel)

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_DAWN_PKT_TX_WAIT_ASYNC     = 0,
    HAL_DAWN_PKT_TX_WAIT_SYNC_INTR = 1,
    HAL_DAWN_PKT_TX_WAIT_SYNC_POLL = 2

} HAL_DAWN_PKT_TX_WAIT_T;

typedef enum
{
    HAL_DAWN_PKT_RX_SCHED_RR       = 0,
    HAL_DAWN_PKT_RX_SCHED_WRR      = 1

} HAL_DAWN_PKT_RX_SCHED_T;

/* GPD and Packet Strucutre Definition */
#if defined(CLX_EN_BIG_ENDIAN)

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  typ                           : 2;
    UI32_T  tc                            : 4;
    UI32_T  color                         : 2;
    UI32_T  srv                           : 3;
    UI32_T  trig                          : 1;
    UI32_T  igr_phy_port                  :12;
    UI32_T  hsh_val_w0                    : 8;
    /* CLX DWORD 1 */
    UI32_T  hsh_val_w1                    : 2;
    UI32_T  dst_idx                       :15;
    UI32_T  src_idx                       :15;
    /* CLX DWORD 2 */
    UI32_T  intf_fdid                     :14;
    UI32_T  nvo3_mgid_is_transit          : 1;
    UI32_T  skip_epp                      : 1;
    UI32_T  steer_applied                 : 1;
    UI32_T  nvo3_ip_tnl_decap_prop_ttl    : 1;
    UI32_T  nvo3_mpls_uhp_prop_ttl        : 1;
    UI32_T  ecn                           : 2;
    UI32_T  store_and_forward             : 1;
    UI32_T  lag_epoch                     : 1;
    UI32_T  src_supp_tag                  : 5;
    UI32_T  one_arm_rte_srv_fdid          : 1;
    UI32_T  fab_one_arm_rte               : 1;
    UI32_T  skip_ipp                      : 1;
    UI32_T  igr_fab_port_grp              : 1;
    /* CLX DWORD 3 */
    UI32_T                                : 2;
    UI32_T  nvo3_mgid                     :15;
    UI32_T  nvo3_intf                     :14;
    UI32_T  nvo3_src_supp_tag_w0          : 1;
    /* CLX DWORD 4 */
    UI32_T  nvo3_src_supp_tag_w1          : 4;
    UI32_T  mir_bmap                      : 8;
    UI32_T  cp_to_cpu_code                : 4;
    UI32_T  cp_to_cpu_bmap                :16;
} HAL_DAWN_PKT_ITMH_ETH_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  typ                           : 2;
    UI32_T  tc                            : 4;
    UI32_T  color                         : 2;
    UI32_T  srv                           : 3;
    UI32_T  trig                          : 1;
    UI32_T  igr_phy_port                  :12;
    UI32_T  hsh_val_w0                    : 8;
    /* CLX DWORD 1 */
    UI32_T  hsh_val_w1                    : 2;
    UI32_T  dst_idx                       :15;
    UI32_T  src_idx                       :15;
    /* CLX DWORD 2 */
    UI32_T  intf_fdid                     :14;
    UI32_T  nvo3_mgid_is_transit          : 1;
    UI32_T  skip_epp                      : 1;
    UI32_T  steer_applied                 : 1;
    UI32_T  nvo3_ip_tnl_decap_prop_ttl    : 1;
    UI32_T  nvo3_mpls_uhp_prop_ttl        : 1;
    UI32_T  ecn                           : 2;
    UI32_T  store_and_forward             : 1;
    UI32_T  lag_epoch                     : 1;
    UI32_T  src_supp_tag                  : 5;
    UI32_T  one_arm_rte_srv_fdid          : 1;
    UI32_T  fab_one_arm_rte               : 1;
    UI32_T                                : 2;
    /* CLX DWORD 3 */
    UI32_T                                :32;
    /* CLX DWORD 4 */
    UI32_T                                :20;
    UI32_T  had_uturn                     : 1;
    UI32_T                                : 2;
    UI32_T  excpt_code                    : 8;
    UI32_T  exp_dscp_mrkd                 : 1;
} HAL_DAWN_PKT_ETMH_FAB_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  typ                           : 2;
    UI32_T  tc                            : 4;
    UI32_T  color                         : 2;
    UI32_T  srv                           : 3;
    UI32_T  trig                          : 1;
    UI32_T  igr_phy_port                  :12;
    UI32_T  hsh_val_w0                    : 8;
    /* CLX DWORD 1 */
    UI32_T  hsh_val_w1                    : 2;
    UI32_T  dst_idx                       :15;
    UI32_T  src_idx                       :15;
    /* CLX DWORD 2 */
    UI32_T  intf_fdid                     :14;
    UI32_T  nvo3_mgid_is_transit          : 1;
    UI32_T  skip_epp                      : 1;
    UI32_T  steer_applied                 : 1;
    UI32_T  nvo3_ip_tnl_decap_prop_ttl    : 1;
    UI32_T  nvo3_mpls_uhp_prop_ttl        : 1;
    UI32_T  ecn                           : 2;
    UI32_T  igr_fab_port_grp              : 1;
    UI32_T  redir                         : 1;
    UI32_T  excpt_code_mir_bmap           : 8;
    UI32_T  cp_to_cpu_bmap_w0             : 1;
    /* CLX DWORD 3 */
    UI32_T  cp_to_cpu_bmap_w1             : 7;
    UI32_T  egr_phy_port                  :12;
    UI32_T  src_supp_pnd                  : 1;
    UI32_T  mc_vid_ctl                    : 3;
    UI32_T  mc_vid_1st_w0                 : 9;
    /* CLX DWORD 4 */
    UI32_T  mc_vid_1st_w1                 : 3;
    UI32_T  mc_vid_2nd                    :12;
    UI32_T  mc_decr_ttl                   : 1;
    UI32_T  mc_is_routed                  : 1;
    UI32_T  mc_mel_vld                    : 1;
    UI32_T  mc_cp_idx                     :13;
    UI32_T  exp_dscp_mrkd                 : 1;
} HAL_DAWN_PKT_ETMH_ETH_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  decap_act                     : 3;
    UI32_T  igr_l2_vid_num                : 2;
    UI32_T  nvo3_encap_idx                :14;
    UI32_T  mpls_pw_cw_vld                : 1;
    UI32_T  hit_idx_w0                    :12;
    /* CLX DWORD 1 */
    UI32_T  hit_idx_w1                    : 7;
    UI32_T  nvo3_adj_idx                  : 8;
    UI32_T  seg_vmid_w0                   :17;
    /* CLX DWORD 2 */
    UI32_T  seg_vmid_w1                   : 7;
    UI32_T                                : 1;
    UI32_T  l2_sa_lrn_en_hw_cvs           : 1;
    UI32_T  l2_sa_lrn_en_hw               : 1;
    UI32_T  vid_ctl                       : 3;
    UI32_T  vid_1st                       :12;
    UI32_T  vid_2nd_w0                    : 7;
    /* CLX DWORD 3 */
    UI32_T  vid_2nd_w1                    : 5;
    UI32_T  flw_lbl                       :10;
    UI32_T  rewr_idx_ctl                  : 2;
    UI32_T  rewr_idx_0                    :13;
    UI32_T  rewr_idx_1_w0                 : 2;
    /* CLX DWORD 4 */
    UI32_T  rewr_idx_1_w1                 :11;
    UI32_T  mrk_pcp_dei_en                : 1;
    UI32_T  mrk_pcp_val                   : 3;
    UI32_T  mrk_dei_val                   : 1;
    UI32_T  ts                            :16;
} HAL_DAWN_PKT_PPH_L2_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  decap_act                     : 3;
    UI32_T  igr_l2_vid_num                : 2;
    UI32_T  nvo3_encap_idx                :14;
    UI32_T  mpls_pw_cw_vld                : 1;
    UI32_T  hit_idx_w0                    :12;
    /* CLX DWORD 1 */
    UI32_T  hit_idx_w1                    : 7;
    UI32_T  nvo3_adj_idx                  : 8;
    UI32_T  seg_vmid_w0                   :17;
    /* CLX DWORD 2 */
    UI32_T  seg_vmid_w1                   : 7;
    UI32_T                                : 1;
    UI32_T  rpf_pnd                       : 1;
    UI32_T  adj_idx                       :18;
    UI32_T  is_mc                         : 1;
    UI32_T  decr_ttl                      : 1;
    UI32_T  decap_prop_ttl                : 1;
    UI32_T  mrk_dscp_en                   : 1;
    UI32_T  mrk_dscp_val_w0               : 1;
    /* CLX DWORD 3 */
    UI32_T  mrk_dscp_val_w1               : 5;
    UI32_T  flw_lbl                       :10;
    UI32_T  rewr_idx_ctl                  : 2;
    UI32_T  rewr_idx_0                    :13;
    UI32_T  rewr_idx_1_w0                 : 2;
    /* CLX DWORD 4 */
    UI32_T  rewr_idx_1_w1                 :11;
    UI32_T  mrk_pcp_dei_en                : 1;
    UI32_T  mrk_pcp_val                   : 3;
    UI32_T  mrk_dei_val                   : 1;
    UI32_T  ts                            :16;
} HAL_DAWN_PKT_PPH_L3UC_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  decap_act                     : 3;
    UI32_T  igr_l2_vid_num                : 2;
    UI32_T  nvo3_encap_idx                :14;
    UI32_T  mpls_pw_cw_vld                : 1;
    UI32_T  hit_idx_w0                    :12;
    /* CLX DWORD 1 */
    UI32_T  hit_idx_w1                    : 7;
    UI32_T  nvo3_adj_idx                  : 8;
    UI32_T  vid_1st                       :12;
    UI32_T  vid_2nd_w0                    : 5;
    /* CLX DWORD 2 */
    UI32_T  vid_2nd_w1                    : 7;
    UI32_T                                :15;
    UI32_T  l2_sa_lrn_en_hw_cvs           : 1;
    UI32_T  l2_sa_lrn_en_hw               : 1;
    UI32_T  vid_ctl                       : 3;
    UI32_T  is_mc                         : 1;
    UI32_T                                : 1;
    UI32_T  decap_prop_ttl                : 1;
    UI32_T  mrk_dscp_en                   : 1;
    UI32_T  mrk_dscp_val_w0               : 1;
    /* CLX DWORD 3 */
    UI32_T  mrk_dscp_val_w1               : 5;
    UI32_T  flw_lbl                       :10;
    UI32_T  rewr_idx_ctl                  : 2;
    UI32_T  rewr_idx_0                    :13;
    UI32_T  rewr_idx_1_w0                 : 2;
    /* CLX DWORD 4 */
    UI32_T  rewr_idx_1_w1                 :11;
    UI32_T  mrk_pcp_dei_en                : 1;
    UI32_T  mrk_pcp_val                   : 3;
    UI32_T  mrk_dei_val                   : 1;
    UI32_T  ts                            :16;
} HAL_DAWN_PKT_PPH_L3MC_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  decap_act                     : 3;
    UI32_T  igr_l2_vid_num                : 2;
    UI32_T  nvo3_encap_idx                :14;
    UI32_T                                : 1;
    UI32_T  hit_idx_w0                    :12;
    /* CLX DWORD 1 */
    UI32_T  hit_idx_w1                    : 7;
    UI32_T  nvo3_adj_idx                  : 8;
    UI32_T  seg_vmid_w0                   :17;
    /* CLX DWORD 2 */
    UI32_T  seg_vmid_w1                   : 7;
    UI32_T                                : 2;
    UI32_T  adj_idx                       :18;
    UI32_T                                : 1;
    UI32_T  decr_ttl                      : 1;
    UI32_T  decap_prop_ttl                : 1;
    UI32_T  mrk_exp_en                    : 1;
    UI32_T                                : 1;
    /* CLX DWORD 3 */
    UI32_T                                : 2;
    UI32_T  mrk_exp_val                   : 3;
    UI32_T  php_pop_keep_inner_qos        : 1;
    UI32_T                                :26;
    /* CLX DWORD 4 */
    UI32_T                                :11;
    UI32_T  mrk_pcp_dei_en                : 1;
    UI32_T  mrk_pcp_val                   : 3;
    UI32_T  mrk_dei_val                   : 1;
    UI32_T  ts                            :16;
} HAL_DAWN_PKT_PPH_L25_T;

#elif defined(CLX_EN_LITTLE_ENDIAN)

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  hsh_val_w0                    : 8;
    UI32_T  igr_phy_port                  :12;
    UI32_T  trig                          : 1;
    UI32_T  srv                           : 3;
    UI32_T  color                         : 2;
    UI32_T  tc                            : 4;
    UI32_T  typ                           : 2;
    /* CLX DWORD 1 */
    UI32_T  src_idx                       :15;
    UI32_T  dst_idx                       :15;
    UI32_T  hsh_val_w1                    : 2;
    /* CLX DWORD 2 */
    UI32_T  igr_fab_port_grp              : 1;
    UI32_T  skip_ipp                      : 1;
    UI32_T  fab_one_arm_rte               : 1;
    UI32_T  one_arm_rte_srv_fdid          : 1;
    UI32_T  src_supp_tag                  : 5;
    UI32_T  lag_epoch                     : 1;
    UI32_T  store_and_forward             : 1;
    UI32_T  ecn                           : 2;
    UI32_T  nvo3_mpls_uhp_prop_ttl        : 1;
    UI32_T  nvo3_ip_tnl_decap_prop_ttl    : 1;
    UI32_T  steer_applied                 : 1;
    UI32_T  skip_epp                      : 1;
    UI32_T  nvo3_mgid_is_transit          : 1;
    UI32_T  intf_fdid                     :14;
    /* CLX DWORD 3 */
    UI32_T  nvo3_src_supp_tag_w0          : 1;
    UI32_T  nvo3_intf                     :14;
    UI32_T  nvo3_mgid                     :15;
    UI32_T                                : 2;
    /* CLX DWORD 4 */
    UI32_T  cp_to_cpu_bmap                :16;
    UI32_T  cp_to_cpu_code                : 4;
    UI32_T  mir_bmap                      : 8;
    UI32_T  nvo3_src_supp_tag_w1          : 4;
} HAL_DAWN_PKT_ITMH_ETH_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  hsh_val_w0                    : 8;
    UI32_T  igr_phy_port                  :12;
    UI32_T  trig                          : 1;
    UI32_T  srv                           : 3;
    UI32_T  color                         : 2;
    UI32_T  tc                            : 4;
    UI32_T  typ                           : 2;
    /* CLX DWORD 1 */
    UI32_T  src_idx                       :15;
    UI32_T  dst_idx                       :15;
    UI32_T  hsh_val_w1                    : 2;
    /* CLX DWORD 2 */
    UI32_T                                : 2;
    UI32_T  fab_one_arm_rte               : 1;
    UI32_T  one_arm_rte_srv_fdid          : 1;
    UI32_T  src_supp_tag                  : 5;
    UI32_T  lag_epoch                     : 1;
    UI32_T  store_and_forward             : 1;
    UI32_T  ecn                           : 2;
    UI32_T  nvo3_mpls_uhp_prop_ttl        : 1;
    UI32_T  nvo3_ip_tnl_decap_prop_ttl    : 1;
    UI32_T  steer_applied                 : 1;
    UI32_T  skip_epp                      : 1;
    UI32_T  nvo3_mgid_is_transit          : 1;
    UI32_T  intf_fdid                     :14;
    /* CLX DWORD 3 */
    UI32_T                                :32;
    /* CLX DWORD 4 */
    UI32_T  exp_dscp_mrkd                 : 1;
    UI32_T  excpt_code                    : 8;
    UI32_T                                : 2;
    UI32_T  had_uturn                     : 1;
    UI32_T                                :20;
} HAL_DAWN_PKT_ETMH_FAB_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  hsh_val_w0                    : 8;
    UI32_T  igr_phy_port                  :12;
    UI32_T  trig                          : 1;
    UI32_T  srv                           : 3;
    UI32_T  color                         : 2;
    UI32_T  tc                            : 4;
    UI32_T  typ                           : 2;
    /* CLX DWORD 1 */
    UI32_T  src_idx                       :15;
    UI32_T  dst_idx                       :15;
    UI32_T  hsh_val_w1                    : 2;
    /* CLX DWORD 2 */
    UI32_T  cp_to_cpu_bmap_w0             : 1;
    UI32_T  excpt_code_mir_bmap           : 8;
    UI32_T  redir                         : 1;
    UI32_T  igr_fab_port_grp              : 1;
    UI32_T  ecn                           : 2;
    UI32_T  nvo3_mpls_uhp_prop_ttl        : 1;
    UI32_T  nvo3_ip_tnl_decap_prop_ttl    : 1;
    UI32_T  steer_applied                 : 1;
    UI32_T  skip_epp                      : 1;
    UI32_T  nvo3_mgid_is_transit          : 1;
    UI32_T  intf_fdid                     :14;
    /* CLX DWORD 3 */
    UI32_T  mc_vid_1st_w0                 : 9;
    UI32_T  mc_vid_ctl                    : 3;
    UI32_T  src_supp_pnd                  : 1;
    UI32_T  egr_phy_port                  :12;
    UI32_T  cp_to_cpu_bmap_w1             : 7;
    /* CLX DWORD 4 */
    UI32_T  exp_dscp_mrkd                 : 1;
    UI32_T  mc_cp_idx                     :13;
    UI32_T  mc_mel_vld                    : 1;
    UI32_T  mc_is_routed                  : 1;
    UI32_T  mc_decr_ttl                   : 1;
    UI32_T  mc_vid_2nd                    :12;
    UI32_T  mc_vid_1st_w1                 : 3;
} HAL_DAWN_PKT_ETMH_ETH_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  hit_idx_w0                    :12;
    UI32_T  mpls_pw_cw_vld                : 1;
    UI32_T  nvo3_encap_idx                :14;
    UI32_T  igr_l2_vid_num                : 2;
    UI32_T  decap_act                     : 3;
    /* CLX DWORD 1 */
    UI32_T  seg_vmid_w0                   :17;
    UI32_T  nvo3_adj_idx                  : 8;
    UI32_T  hit_idx_w1                    : 7;
    /* CLX DWORD 2 */
    UI32_T  vid_2nd_w0                    : 7;
    UI32_T  vid_1st                       :12;
    UI32_T  vid_ctl                       : 3;
    UI32_T  l2_sa_lrn_en_hw               : 1;
    UI32_T  l2_sa_lrn_en_hw_cvs           : 1;
    UI32_T                                : 1;
    UI32_T  seg_vmid_w1                   : 7;
    /* CLX DWORD 3 */
    UI32_T  rewr_idx_1_w0                 : 2;
    UI32_T  rewr_idx_0                    :13;
    UI32_T  rewr_idx_ctl                  : 2;
    UI32_T  flw_lbl                       :10;
    UI32_T  vid_2nd_w1                    : 5;
    /* CLX DWORD 4 */
    UI32_T  ts                            :16;
    UI32_T  mrk_dei_val                   : 1;
    UI32_T  mrk_pcp_val                   : 3;
    UI32_T  mrk_pcp_dei_en                : 1;
    UI32_T  rewr_idx_1_w1                 :11;
} HAL_DAWN_PKT_PPH_L2_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  hit_idx_w0                    :12;
    UI32_T  mpls_pw_cw_vld                : 1;
    UI32_T  nvo3_encap_idx                :14;
    UI32_T  igr_l2_vid_num                : 2;
    UI32_T  decap_act                     : 3;
    /* CLX DWORD 1 */
    UI32_T  seg_vmid_w0                   :17;
    UI32_T  nvo3_adj_idx                  : 8;
    UI32_T  hit_idx_w1                    : 7;
    /* CLX DWORD 2 */
    UI32_T  mrk_dscp_val_w0               : 1;
    UI32_T  mrk_dscp_en                   : 1;
    UI32_T  decap_prop_ttl                : 1;
    UI32_T  decr_ttl                      : 1;
    UI32_T  is_mc                         : 1;
    UI32_T  adj_idx                       :18;
    UI32_T  rpf_pnd                       : 1;
    UI32_T                                : 1;
    UI32_T  seg_vmid_w1                   : 7;
    /* CLX DWORD 3 */
    UI32_T  rewr_idx_1_w0                 : 2;
    UI32_T  rewr_idx_0                    :13;
    UI32_T  rewr_idx_ctl                  : 2;
    UI32_T  flw_lbl                       :10;
    UI32_T  mrk_dscp_val_w1               : 5;
    /* CLX DWORD 4 */
    UI32_T  ts                            :16;
    UI32_T  mrk_dei_val                   : 1;
    UI32_T  mrk_pcp_val                   : 3;
    UI32_T  mrk_pcp_dei_en                : 1;
    UI32_T  rewr_idx_1_w1                 :11;
} HAL_DAWN_PKT_PPH_L3UC_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  hit_idx_w0                    :12;
    UI32_T  mpls_pw_cw_vld                : 1;
    UI32_T  nvo3_encap_idx                :14;
    UI32_T  igr_l2_vid_num                : 2;
    UI32_T  decap_act                     : 3;
    /* CLX DWORD 1 */
    UI32_T  vid_2nd_w0                    : 5;
    UI32_T  vid_1st                       :12;
    UI32_T  nvo3_adj_idx                  : 8;
    UI32_T  hit_idx_w1                    : 7;
    /* CLX DWORD 2 */
    UI32_T  mrk_dscp_val_w0               : 1;
    UI32_T  mrk_dscp_en                   : 1;
    UI32_T  decap_prop_ttl                : 1;
    UI32_T                                : 1;
    UI32_T  is_mc                         : 1;
    UI32_T  vid_ctl                       : 3;
    UI32_T  l2_sa_lrn_en_hw               : 1;
    UI32_T  l2_sa_lrn_en_hw_cvs           : 1;
    UI32_T                                :15;
    UI32_T  vid_2nd_w1                    : 7;
    /* CLX DWORD 3 */
    UI32_T  rewr_idx_1_w0                 : 2;
    UI32_T  rewr_idx_0                    :13;
    UI32_T  rewr_idx_ctl                  : 2;
    UI32_T  flw_lbl                       :10;
    UI32_T  mrk_dscp_val_w1               : 5;
    /* CLX DWORD 4 */
    UI32_T  ts                            :16;
    UI32_T  mrk_dei_val                   : 1;
    UI32_T  mrk_pcp_val                   : 3;
    UI32_T  mrk_pcp_dei_en                : 1;
    UI32_T  rewr_idx_1_w1                 :11;
} HAL_DAWN_PKT_PPH_L3MC_T;

typedef struct
{
    /* CLX DWORD 0 */
    UI32_T  hit_idx_w0                    :12;
    UI32_T                                : 1;
    UI32_T  nvo3_encap_idx                :14;
    UI32_T  igr_l2_vid_num                : 2;
    UI32_T  decap_act                     : 3;
    /* CLX DWORD 1 */
    UI32_T  seg_vmid_w0                   :17;
    UI32_T  nvo3_adj_idx                  : 8;
    UI32_T  hit_idx_w1                    : 7;
    /* CLX DWORD 2 */
    UI32_T                                : 1;
    UI32_T  mrk_exp_en                    : 1;
    UI32_T  decap_prop_ttl                : 1;
    UI32_T  decr_ttl                      : 1;
    UI32_T                                : 1;
    UI32_T  adj_idx                       :18;
    UI32_T                                : 2;
    UI32_T  seg_vmid_w1                   : 7;
    /* CLX DWORD 3 */
    UI32_T                                :26;
    UI32_T  php_pop_keep_inner_qos        : 1;
    UI32_T  mrk_exp_val                   : 3;
    UI32_T                                : 2;
    /* CLX DWORD 4 */
    UI32_T  ts                            :16;
    UI32_T  mrk_dei_val                   : 1;
    UI32_T  mrk_pcp_val                   : 3;
    UI32_T  mrk_pcp_dei_en                : 1;
    UI32_T                                :11;
} HAL_DAWN_PKT_PPH_L25_T;

#else
#error "Host GPD endian is not defined!!\n"
#endif

#if defined(CLX_EN_BIG_ENDIAN)

/* RX GPD STRUCTURE */
typedef struct
{
    UI32_T  data_buf_addr_lo;
    UI32_T  data_buf_addr_hi;
    UI32_T  chksum              : 16;
    UI32_T  ioc                 :  1;
    UI32_T                      :  1;
    UI32_T  avbl_buf_len        : 14;
    UI32_T                      : 32;

    union
    {
        HAL_DAWN_PKT_ITMH_ETH_T  itmh_eth;
        HAL_DAWN_PKT_ETMH_FAB_T  etmh_fab;
        HAL_DAWN_PKT_ETMH_ETH_T  etmh_eth;
    };
    union
    {
        HAL_DAWN_PKT_PPH_L2_T    pph_l2;
        HAL_DAWN_PKT_PPH_L3UC_T  pph_l3uc;
        HAL_DAWN_PKT_PPH_L3MC_T  pph_l3mc;
        HAL_DAWN_PKT_PPH_L25_T   pph_l25;
    };

    UI32_T                      : 32;
    UI32_T  hwo                 :  1;
    UI32_T  ch                  :  1;
    UI32_T  trn                 :  1;
    UI32_T  ecce                :  1;
    UI32_T  errf                :  1;
    UI32_T                      :  5;
    UI32_T  queue               :  6;
    UI32_T                      :  2;
    UI32_T  cnsm_buf_len        : 14;

} HAL_DAWN_PKT_RX_GPD_T;

/* TX GPD STRUCTURE */
typedef struct
{
    UI32_T  data_buf_addr_lo;
    UI32_T  data_buf_addr_hi;
    UI32_T  chksum              : 16;
    UI32_T  ioc                 :  1;
    UI32_T                      :  1;
    UI32_T  data_buf_size       : 14;
    UI32_T                      : 32;

    union
    {
        HAL_DAWN_PKT_ITMH_ETH_T  itmh_eth;
        HAL_DAWN_PKT_ETMH_FAB_T  etmh_fab;
        HAL_DAWN_PKT_ETMH_ETH_T  etmh_eth;
    };
    union
    {
        HAL_DAWN_PKT_PPH_L2_T    pph_l2;
        HAL_DAWN_PKT_PPH_L3UC_T  pph_l3uc;
        HAL_DAWN_PKT_PPH_L3MC_T  pph_l3mc;
        HAL_DAWN_PKT_PPH_L25_T   pph_l25;
    };

    UI32_T                      : 16;
    UI32_T  ptp_hdr             : 16;
    UI32_T  hwo                 :  1;
    UI32_T  ch                  :  1;
    UI32_T                      :  1;
    UI32_T  ecce                :  1;
    UI32_T                      :  4;
    UI32_T  cos                 :  3;
    UI32_T  phc                 :  1;   /* PTP Header Control */
    UI32_T  ipc                 :  2;   /* Ingress Plane Control */
    UI32_T  crcc                :  1;
    UI32_T  prg                 :  1;   /* Purge */
    UI32_T                      :  2;
    UI32_T  pkt_len             : 14;   /* Total packet length */

} HAL_DAWN_PKT_TX_GPD_T;

#elif defined(CLX_EN_LITTLE_ENDIAN)

/* RX GPD STRUCTURE */
typedef struct
{
    UI32_T  data_buf_addr_lo;
    UI32_T  data_buf_addr_hi;
    UI32_T  avbl_buf_len        : 14;
    UI32_T                      :  1;
    UI32_T  ioc                 :  1;
    UI32_T  chksum              : 16;
    UI32_T                      : 32;

    union
    {
        HAL_DAWN_PKT_ITMH_ETH_T  itmh_eth;
        HAL_DAWN_PKT_ETMH_FAB_T  etmh_fab;
        HAL_DAWN_PKT_ETMH_ETH_T  etmh_eth;
    };
    union
    {
        HAL_DAWN_PKT_PPH_L2_T    pph_l2;
        HAL_DAWN_PKT_PPH_L3UC_T  pph_l3uc;
        HAL_DAWN_PKT_PPH_L3MC_T  pph_l3mc;
        HAL_DAWN_PKT_PPH_L25_T   pph_l25;
    };

    UI32_T                      : 32;
    UI32_T  cnsm_buf_len        : 14;
    UI32_T                      :  2;
    UI32_T  queue               :  6;
    UI32_T                      :  5;
    UI32_T  errf                :  1;
    UI32_T  ecce                :  1;
    UI32_T  trn                 :  1;
    UI32_T  ch                  :  1;
    UI32_T  hwo                 :  1;

} HAL_DAWN_PKT_RX_GPD_T;

/* TX GPD STRUCTURE */
typedef struct
{
    UI32_T  data_buf_addr_lo;
    UI32_T  data_buf_addr_hi;
    UI32_T  data_buf_size       : 14;
    UI32_T                      :  1;
    UI32_T  ioc                 :  1;
    UI32_T  chksum              : 16;
    UI32_T                      : 32;

    union
    {
        HAL_DAWN_PKT_ITMH_ETH_T  itmh_eth;
        HAL_DAWN_PKT_ETMH_FAB_T  etmh_fab;
        HAL_DAWN_PKT_ETMH_ETH_T  etmh_eth;
    };
    union
    {
        HAL_DAWN_PKT_PPH_L2_T    pph_l2;
        HAL_DAWN_PKT_PPH_L3UC_T  pph_l3uc;
        HAL_DAWN_PKT_PPH_L3MC_T  pph_l3mc;
        HAL_DAWN_PKT_PPH_L25_T   pph_l25;
    };

    UI32_T  ptp_hdr             : 16;
    UI32_T                      : 16;
    UI32_T  pkt_len             : 14;   /* Total packet length */
    UI32_T                      :  2;
    UI32_T  prg                 :  1;   /* Purge */
    UI32_T  crcc                :  1;
    UI32_T  ipc                 :  2;   /* Ingress Plane Control */
    UI32_T  phc                 :  1;   /* PTP Header Control */
    UI32_T  cos                 :  3;
    UI32_T                      :  4;
    UI32_T  ecce                :  1;
    UI32_T                      :  1;
    UI32_T  ch                  :  1;
    UI32_T  hwo                 :  1;
} HAL_DAWN_PKT_TX_GPD_T;

#else
#error "Host GPD endian is not defined\n"
#endif

/* ----------------------------------------------------------------------------------- PP Type */
typedef enum
{
    HAL_DAWN_PKT_TMH_TYPE_ITMH_ETH = 0,
    HAL_DAWN_PKT_TMH_TYPE_ITMH_FAB,
    HAL_DAWN_PKT_TMH_TYPE_ETMH_FAB,
    HAL_DAWN_PKT_TMH_TYPE_ETMH_ETH,
    HAL_DAWN_PKT_TMH_TYPE_LAST

} HAL_DAWN_PKT_TMH_TYPE_T;

typedef enum
{
    HAL_DAWN_PKT_TMH_SRV_L2 = 0,
    HAL_DAWN_PKT_TMH_SRV_L25_MPLS,
    HAL_DAWN_PKT_TMH_SRV_L3,
    HAL_DAWN_PKT_TMH_SRV_EGR,            /* L3 downgrade L2 */
    HAL_DAWN_PKT_TMH_SRV_L25_NSH,
    HAL_DAWN_PKT_TMH_SRV_L25_TRILL,
    HAL_DAWN_PKT_TMH_SRV_LAST

} HAL_DAWN_PKT_TMH_SRV_T;

typedef enum
{
    HAL_DAWN_PKT_TMH_DECAP_NONE = 0,
    HAL_DAWN_PKT_TMH_DECAP_1_MPLS_LABEL,
    HAL_DAWN_PKT_TMH_DECAP_2_MPLS_LABEL,
    HAL_DAWN_PKT_TMH_DECAP_3_MPLS_LABEL,
    HAL_DAWN_PKT_TMH_DECAP_4_MPLS_LABEL,
    HAL_DAWN_PKT_TMH_DECAP_IP_TRILL_NSH,
    HAL_DAWN_PKT_TMH_DECAP_LAST

} HAL_DAWN_PKT_TMH_DECAP_T;

typedef struct
{
    union
    {
        HAL_DAWN_PKT_ITMH_ETH_T  itmh_eth;
        HAL_DAWN_PKT_ETMH_FAB_T  etmh_fab;
        HAL_DAWN_PKT_ETMH_ETH_T  etmh_eth;
    };
} HAL_DAWN_PKT_TMH_T;

typedef struct
{
    union
    {
        HAL_DAWN_PKT_PPH_L2_T    pph_l2;
        HAL_DAWN_PKT_PPH_L3UC_T  pph_l3uc;
        HAL_DAWN_PKT_PPH_L3MC_T  pph_l3mc;
        HAL_DAWN_PKT_PPH_L25_T   pph_l25;
    };
} HAL_DAWN_PKT_PPH_T;

/* ----------------------------------------------------------------------------------- Reg Type */
typedef enum
{
    HAL_DAWN_PKT_L2_ISR_RCH0            = (0x1UL << 0),
    HAL_DAWN_PKT_L2_ISR_RCH1            = (0x1UL << 1),
    HAL_DAWN_PKT_L2_ISR_RCH2            = (0x1UL << 2),
    HAL_DAWN_PKT_L2_ISR_RCH3            = (0x1UL << 3),
    HAL_DAWN_PKT_L2_ISR_TCH0            = (0x1UL << 4),
    HAL_DAWN_PKT_L2_ISR_TCH1            = (0x1UL << 5),
    HAL_DAWN_PKT_L2_ISR_TCH2            = (0x1UL << 6),
    HAL_DAWN_PKT_L2_ISR_TCH3            = (0x1UL << 7),
    HAL_DAWN_PKT_L2_ISR_RX_QID_MAP_ERR  = (0x1UL << 8),
    HAL_DAWN_PKT_L2_ISR_RX_FRAME_ERR    = (0x1UL << 9)

} HAL_DAWN_PKT_L2_ISR_T;

typedef enum
{
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_GPD_HWO_ERROR         = (0x1UL << 0),   /* Tx GPD.hwo = 0                         */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_GPD_CHKSM_ERROR       = (0x1UL << 1),   /* Tx GPD.chksm is error                  */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_GPD_NO_OVFL_ERROR     = (0x1UL << 2),   /* S/W push too much GPD                  */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_GPD_DMA_READ_ERROR    = (0x1UL << 3),   /* AXI Rd Error when do GPD read          */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_BUF_SIZE_ERROR        = (0x1UL << 4),   /* Tx GPD.data_buf_size = 0               */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_RUNT_ERROR            = (0x1UL << 5),   /* Tx GPD.pkt_len < 64                    */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_OVSZ_ERROR            = (0x1UL << 6),   /* Tx GPD.pkt_len = 9217                  */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_LEN_MISMATCH_ERROR    = (0x1UL << 7),   /* Tx GPD.pkt_len != sum of data_buf_size */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_PKTPL_DMA_READ_ERROR  = (0x1UL << 8),   /* AXI Rd Error when do Payload read      */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_COS_ERROR             = (0x1UL << 9),   /* Tx GPD.cos is not match cos_to_tch_map */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_GPD_GT255_ERROR       = (0x1UL << 10),  /* Multi-GPD packet's GPD# > 255          */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_PFC                   = (0x1UL << 11),  /* */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_CREDIT_UDFL_ERROR     = (0x1UL << 12),  /* Credit Underflow (count down to 0)     */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_DMA_WRITE_ERROR       = (0x1UL << 13),  /* AXI Wr Error (GPD Write-Back)          */
    HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_STOP_CMD_CPLT         = (0x1UL << 14)

} HAL_DAWN_PKT_TX_CHANNEL_L2_ISR_T;

typedef enum
{
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_AVAIL_GPD_LOW         = (0x1UL << 0),   /* Rx GPD.avbl_gpd_num < threshold        */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_AVAIL_GPD_EMPTY       = (0x1UL << 1),   /* Rx GPD.avbl_gpd_num = 0                */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_AVAIL_GPD_ERROR       = (0x1UL << 2),   /* Rx GPD.hwo = 0                         */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_GPD_CHKSM_ERROR       = (0x1UL << 3),   /* Rx GPD.chksm is error                  */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_DMA_READ_ERROR        = (0x1UL << 4),   /* DMAR error occurs in PCIE              */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_DMA_WRITE_ERROR       = (0x1UL << 5),   /* DMAW error occurs in PCIE              */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_STOP_CMD_CPLT         = (0x1UL << 6),   /* Stop Completion Acknowledge            */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_GPD_GT255_ERROR       = (0x1UL << 7),   /* Multi-GPD packet's GPD# > 255          */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_TOD_UNINIT            = (0x1UL << 8),   /* */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_PKT_ERROR_DROP        = (0x1UL << 9),   /* */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_UDSZ_DROP             = (0x1UL << 10),  /* */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_OVSZ_DROP             = (0x1UL << 11),  /* */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_CMDQ_OVF_DROP         = (0x1UL << 12),  /* */
    HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_FIFO_OVF_DROP         = (0x1UL << 13)

} HAL_DAWN_PKT_RX_CHANNEL_L2_ISR_T;

typedef enum
{
    HAL_DAWN_PKT_TX_CHANNEL_CFG_IOC                      = (0x1UL << 0),
    HAL_DAWN_PKT_TX_CHANNEL_CFG_CHKSUM                   = (0x1UL << 1),
    HAL_DAWN_PKT_TX_CHANNEL_CFG_PFC                      = (0x1UL << 2),
    HAL_DAWN_PKT_TX_CHANNEL_CFG_PKT_LEN_CHK              = (0x1UL << 3),
    HAL_DAWN_PKT_TX_CHANNEL_CFG_EARLY_DONE_IRQ           = (0x1UL << 4),
    HAL_DAWN_PKT_TX_CHANNEL_CFG_CHK_COS                  = (0x1UL << 5),
    HAL_DAWN_PKT_TX_CHANNEL_CFG_ADV_GPD_WRBK             = (0x1UL << 6),
    HAL_DAWN_PKT_TX_CHANNEL_CFG_GPD_WRBK_FULL_PKT_LEN    = (0x1UL << 7),
    HAL_DAWN_PKT_TX_CHANNEL_CFG_LAST                     = (0x1UL << 8)

} HAL_DAWN_PKT_TX_CHANNEL_CFG_T;

typedef enum
{
    HAL_DAWN_PKT_RX_CHANNEL_CFG_IOC      = (0x1UL << 0),
    HAL_DAWN_PKT_RX_CHANNEL_CFG_CHKSUM   = (0x1UL << 1),
    HAL_DAWN_PKT_RX_CHANNEL_CFG_LAST     = (0x1UL << 2)

} HAL_DAWN_PKT_RX_CHANNEL_CFG_T;

/* ----------------------------------------------------------------------------------- Tx */
typedef enum
{
    HAL_DAWN_PKT_TX_CHANNEL_0 = 0,
    HAL_DAWN_PKT_TX_CHANNEL_1,
    HAL_DAWN_PKT_TX_CHANNEL_2,
    HAL_DAWN_PKT_TX_CHANNEL_3,
    HAL_DAWN_PKT_TX_CHANNEL_LAST

} HAL_DAWN_PKT_TX_CHANNEL_T;

typedef void
(*HAL_DAWN_PKT_TX_FUNC_T)(
    const UI32_T                        unit,
    const void                          *ptr_sw_gpd,    /* SW-GPD to be processed  */
    void                                *ptr_coockie);  /* Private data of SDK     */

typedef struct HAL_DAWN_PKT_TX_SW_GPD_S
{
    HAL_DAWN_PKT_TX_FUNC_T               callback;       /* (unit, ptr_sw_gpd, ptr_cookie) */
    void                                *ptr_cookie;    /* Pointer of CLX_PKT_TX_PKT_T    */
    HAL_DAWN_PKT_TX_GPD_T                tx_gpd;
    UI32_T                              gpd_num;
    struct HAL_DAWN_PKT_TX_SW_GPD_S      *ptr_next;

#if defined (CLX_EN_NETIF)
    UI32_T                              channel;        /* For counter */
#endif

} HAL_DAWN_PKT_TX_SW_GPD_T;

typedef struct
{
    UI32_T                              send_ok;
    UI32_T                              gpd_empty;
    UI32_T                              poll_timeout;

    /* queue */
    UI32_T                              enque_ok;
    UI32_T                              enque_retry;

    /* event */
    UI32_T                              trig_event;

    /* normal interrupt */
    UI32_T                              tx_done;

    /* abnormal interrupt */
    UI32_T                              gpd_hwo_err;          /* bit-0  */
    UI32_T                              gpd_chksm_err;        /* bit-1  */
    UI32_T                              gpd_no_ovfl_err;      /* bit-2  */
    UI32_T                              gpd_dma_read_err;     /* bit-3  */
    UI32_T                              buf_size_err;         /* bit-4  */
    UI32_T                              runt_err;             /* bit-5  */
    UI32_T                              ovsz_err;             /* bit-6  */
    UI32_T                              len_mismatch_err;     /* bit-7  */
    UI32_T                              pktpl_dma_read_err;   /* bit-8  */
    UI32_T                              cos_err;              /* bit-9  */
    UI32_T                              gpd_gt255_err;        /* bit-10 */
    UI32_T                              pfc;                  /* bit-11 */
    UI32_T                              credit_udfl_err;      /* bit-12 */
    UI32_T                              dma_write_err;        /* bit-13 */
    UI32_T                              sw_issue_stop;        /* bit-14 */

    /* others */
    UI32_T                              err_recover;
    UI32_T                              ecc_err;

} HAL_DAWN_PKT_TX_CHANNEL_CNT_T;

typedef struct
{
    HAL_DAWN_PKT_TX_CHANNEL_CNT_T        channel[HAL_DAWN_PKT_TX_CHANNEL_LAST];
    UI32_T                              invoke_gpd_callback;
    UI32_T                              no_memory;

    /* queue */
    UI32_T                              deque_ok;
    UI32_T                              deque_fail;

    /* event */
    UI32_T                              wait_event;

} HAL_DAWN_PKT_TX_CNT_T;

/* ----------------------------------------------------------------------------------- Rx */
typedef enum
{
    HAL_DAWN_PKT_RX_CHANNEL_0 = 0,
    HAL_DAWN_PKT_RX_CHANNEL_1,
    HAL_DAWN_PKT_RX_CHANNEL_2,
    HAL_DAWN_PKT_RX_CHANNEL_3,
    HAL_DAWN_PKT_RX_CHANNEL_LAST
} HAL_DAWN_PKT_RX_CHANNEL_T;

typedef enum
{
    HAL_DAWN_PKT_C_NEXT   = 0, /* callback continuous */
    HAL_DAWN_PKT_C_STOP   = 1,
    HAL_DAWN_PKT_C_OTHERS = 2
} HAL_DAWN_PKT_CALLBACK_NO_T;

typedef enum
{
    HAL_DAWN_PKT_RX_CALLBACK_ACTION_INSERT = 0,
    HAL_DAWN_PKT_RX_CALLBACK_ACTION_APPEND = 1,
    HAL_DAWN_PKT_RX_CALLBACK_ACTION_DELETE = 2,
    HAL_DAWN_PKT_RX_CALLBACK_ACTION_DELETE_ALL = 3
} HAL_DAWN_PKT_RX_CALLBACK_ACTION_T;

typedef HAL_DAWN_PKT_CALLBACK_NO_T
(*HAL_DAWN_PKT_RX_FUNC_T)(
    const UI32_T                        unit,
    const void                          *ptr_sw_gpd,    /* SW-GPD to be processed  */
    void                                *ptr_cookie);   /* Private data of SDK     */

typedef struct HAL_DAWN_PKT_RX_CALLBACK_S
{
    HAL_DAWN_PKT_RX_FUNC_T               callback;       /* (unit, ptr_sw_gpd, ptr_cookie) */
    void                                *ptr_cookie;
    struct HAL_DAWN_PKT_RX_CALLBACK_S    *ptr_next;
} HAL_DAWN_PKT_RX_CALLBACK_T;

typedef struct HAL_DAWN_PKT_RX_SW_GPD_S
{
    BOOL_T                              rx_complete;    /* FALSE when PDMA error occurs */
    HAL_DAWN_PKT_RX_GPD_T                rx_gpd;
    struct HAL_DAWN_PKT_RX_SW_GPD_S      *ptr_next;

#if defined (CLX_EN_NETIF)
    void                                *ptr_cookie;    /* Pointer of virt-addr */
#endif

} HAL_DAWN_PKT_RX_SW_GPD_T;

typedef struct
{
    /* queue */
    UI32_T                              enque_ok;
    UI32_T                              enque_retry;
    UI32_T                              deque_ok;
    UI32_T                              deque_fail;

    /* event */
    UI32_T                              trig_event;

    /* normal interrupt */
    UI32_T                              rx_done;

    /* abnormal interrupt */
    UI32_T                              avbl_gpd_low;         /* bit-0  */
    UI32_T                              avbl_gpd_empty;       /* bit-1  */
    UI32_T                              avbl_gpd_err;         /* bit-2  */
    UI32_T                              gpd_chksm_err;        /* bit-3  */
    UI32_T                              dma_read_err;         /* bit-4  */
    UI32_T                              dma_write_err;        /* bit-5  */
    UI32_T                              sw_issue_stop;        /* bit-6  */
    UI32_T                              gpd_gt255_err;        /* bit-7  */
    UI32_T                              tod_uninit;           /* bit-8  */
    UI32_T                              pkt_err_drop;         /* bit-9  */
    UI32_T                              udsz_drop;            /* bit-10 */
    UI32_T                              ovsz_drop;            /* bit-11 */
    UI32_T                              cmdq_ovf_drop;        /* bit-12 */
    UI32_T                              fifo_ovf_drop;        /* bit-13 */

    /* others */
    UI32_T                              err_recover;
    UI32_T                              ecc_err;

#if defined (CLX_EN_NETIF)
    /* it means that user doesn't create intf on that port */
    UI32_T                              netdev_miss;
#endif


} HAL_DAWN_PKT_RX_CHANNEL_CNT_T;

typedef struct
{
    HAL_DAWN_PKT_RX_CHANNEL_CNT_T        channel[HAL_DAWN_PKT_RX_CHANNEL_LAST];
    UI32_T                              invoke_gpd_callback;
    UI32_T                              no_memory;

    /* event */
    UI32_T                              wait_event;

} HAL_DAWN_PKT_RX_CNT_T;

/* ----------------------------------------------------------------------------------- Reg */
#if defined(CLX_EN_LITTLE_ENDIAN)

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  tch_axlen_cfg               :  3;
        UI32_T                              :  5;
        UI32_T  tch_axi_free_arvalid        :  1;
        UI32_T                              :  7;
        UI32_T  tch_arvalid_thrhold_cfg     :  2;
        UI32_T                              :  6;
        UI32_T  tch_rready_low_4_hdr        :  1;
        UI32_T  tch_ios_crdt_add_en         :  1;
        UI32_T                              :  6;
    } field;
} HAL_DAWN_PKT_AXI_LEN_CFG_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  pdma_lbk_en                 :  1;
        UI32_T                              :  3;
        UI32_T  pdma_lbk_plane              :  2;
        UI32_T                              :  2;
        UI32_T  pm_lbk_en                   :  1;
        UI32_T                              :  7;
        UI32_T  pm_lbk_rqid                 :  6;
        UI32_T                              :  2;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_LBK_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  pdma_lbk_rqid0              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid1              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid2              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid3              :  6;
        UI32_T                              :  2;
    } field;
} HAL_DAWN_PKT_LBK_RQID0_3_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  pdma_lbk_rqid4              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid5              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid6              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid7              :  6;
        UI32_T                              :  2;
    } field;
} HAL_DAWN_PKT_LBK_RQID4_7_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  cos_pfc_sts0                :  8;
        UI32_T  cos_pfc_sts1                :  8;
        UI32_T  cos_pfc_sts2                :  8;
        UI32_T  cos_pfc_sts3                :  8;
    } field;
} HAL_DAWN_PKT_COS_PFC_STS_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  pdma_ela_en                 :  1;
        UI32_T                              :  7;
        UI32_T  pdma_ela_valid_sel          :  8;
        UI32_T                              :  8;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_ELA_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  pdma_ela_word0_sel          :  8;
        UI32_T  pdma_ela_word1_sel          :  8;
        UI32_T  pdma_ela_word2_sel          :  8;
        UI32_T  pdma_ela_word3_sel          :  8;
    } field;
} HAL_DAWN_PKT_ELA_SEL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  ingr_pln_ios_credit_base_size_lo    :  8;
        UI32_T  ingr_pln_ios_credit_base_size_hi    :  8;
        UI32_T  ingr_pln_ios_credit_set             :  1;
        UI32_T                                      :  7;
        UI32_T                                      :  1;
        UI32_T  ingr_pln_full_pkt_mode              :  1;
        UI32_T                                      :  6;
    } field;
} HAL_DAWN_PKT_IGR_PLN_CREDIT_CFG_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  ingr_pln_cur_ios_credit_lo  :  8;
        UI32_T  ingr_pln_cur_ios_credit_hi  :  8;
        UI32_T  ingr_pln_ios_credit_ovfl    :  1;
        UI32_T  ingr_pln_ios_credit_udfl    :  1;
        UI32_T                              :  6;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_IGR_PLN_CREDIT_STS_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  ingr_pln_ios_credit_rdy_lo_bound    :  8;
        UI32_T  ingr_pln_ios_credit_rdy_hi_bound    :  8;
        UI32_T                                      :  8;
        UI32_T                                      :  8;
    } field;
} HAL_DAWN_PKT_IGR_PLN_CREDIT_THR_REG_T;


typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_stomp_crc_en            :  1;
        UI32_T                              :  7;
        UI32_T  rch_crc_regen_en            :  1;
        UI32_T                              :  7;
        UI32_T  rch_pfc_fun_en              :  1;
        UI32_T                              :  7;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_RCH_STOMP_CRC_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_ioc_en                  :  1;
        UI32_T                              :  7;
        UI32_T  rch_chksm_en                :  1;
        UI32_T                              :  7;
        UI32_T                              :  8;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_RCH_MISC_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_gpd_pfc_lo              :  8;
        UI32_T  rch_gpd_pfc_hi              :  8;
        UI32_T                              :  8;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_RCH_GPD_PFC_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_fifo_pfc_lo_lo          :  8;
        UI32_T  rch_fifo_pfc_lo_hi          :  3;
        UI32_T                              :  5;
        UI32_T  rch_fifo_pfc_hi_lo          :  8;
        UI32_T  rch_fifo_pfc_hi_hi          :  3;
        UI32_T                              :  5;
    } field;
} HAL_DAWN_PKT_RCH_FIFO_PFC_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_cmdq_pfc_lo             :  5;
        UI32_T                              :  3;
        UI32_T  rch_cmdq_pfc_hi             :  5;
        UI32_T                              :  3;
        UI32_T                              :  8;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_RCH_CMDQ_PFC_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_start                   :  1;
        UI32_T  rch_resume                  :  1;
        UI32_T  rch_stop                    :  1;
        UI32_T                              :  5;
        UI32_T                              :  8;
        UI32_T  rch_gpd_add_no_lo           :  8;
        UI32_T  rch_gpd_add_no_hi           :  8;
    } field;
} HAL_DAWN_PKT_RCH_CMD_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_fifo_ovf_drop_cnt_clr   :  1;
        UI32_T  rch_cmdq_ovf_drop_cnt_clr   :  1;
        UI32_T  rch_ovsz_drop_cnt_clr       :  1;
        UI32_T  rch_udsz_drop_cnt_clr       :  1;
        UI32_T  rch_pkterr_drop_cnt_clr     :  1;
        UI32_T  rch_flush_cnt_clr           :  1;
        UI32_T                              :  2;
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_RCH_CNT_CLR_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_active                  :  1;
        UI32_T  rch_avbl_gpd_pfc            :  1;
        UI32_T  rch_fifo_pfc                :  1;
        UI32_T  rch_cmdq_pfc                :  1;
        UI32_T  rch_pfc                     :  1;
        UI32_T                              :  3;
        UI32_T                              :  8;
        UI32_T  rch_avbl_gpd_no_lo          :  8;
        UI32_T  rch_avbl_gpd_no_hi          :  8;
    } field;
} HAL_DAWN_PKT_RCH_STATUS_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  tch_ioc_en                  :  1;
        UI32_T  tch_chksm_en                :  1;
        UI32_T  tch_pfc_en                  :  1;
        UI32_T  tch_pktlen_chk_en           :  1;
        UI32_T  tch_early_done_irq          :  1;
        UI32_T  tch_chk_cos_en              :  1;
        UI32_T  tch_adv_gpd_wrbk            :  1;
        UI32_T  tch_gpd_wrbk_full_pkt_len   :  1;
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_TCH_CFG_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  tch_start                   :  1;
        UI32_T  tch_resume                  :  1;
        UI32_T  tch_stop                    :  1;
        UI32_T                              :  5;
        UI32_T                              :  8;
        UI32_T  tch_gpd_add_no_lo           :  8;
        UI32_T  tch_gpd_add_no_hi           :  8;
    } field;
} HAL_DAWN_PKT_TCH_CMD_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  tch_active                  :  1;
        UI32_T  tch_pfc                     :  1;
        UI32_T  tch_gpd_rd_dma_act          :  1;
        UI32_T                              :  5;
        UI32_T                              :  8;
        UI32_T  tch_avbl_gpd_no             :  1;
        UI32_T                              :  7;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_TCH_STS_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  tch_gpd_dmar_qos            :  4;
        UI32_T                              :  4;
        UI32_T  tch_pkt_dmar_qos            :  4;
        UI32_T                              :  4;
        UI32_T  tch_gpd_dmaw_qos            :  4;
        UI32_T                              :  4;
        UI32_T                              :  8;
    } field;
} HAL_DAWN_PKT_TCH_QOS_CFG_REG_T;

#elif defined(CLX_EN_BIG_ENDIAN)

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  6;
        UI32_T  tch_ios_crdt_add_en         :  1;
        UI32_T  tch_rready_low_4_hdr        :  1;
        UI32_T                              :  6;
        UI32_T  tch_arvalid_thrhold_cfg     :  2;
        UI32_T                              :  7;
        UI32_T  tch_axi_free_arvalid        :  1;
        UI32_T                              :  5;
        UI32_T  tch_axlen_cfg               :  3;
    } field;
} HAL_DAWN_PKT_AXI_LEN_CFG_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  2;
        UI32_T  pm_lbk_rqid                 :  6;
        UI32_T                              :  7;
        UI32_T  pm_lbk_en                   :  1;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_plane              :  2;
        UI32_T                              :  3;
        UI32_T  pdma_lbk_en                 :  1;
    } field;
} HAL_DAWN_PKT_LBK_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid3              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid2              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid1              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid0              :  6;
    } field;
} HAL_DAWN_PKT_LBK_RQID0_3_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid7              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid6              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid5              :  6;
        UI32_T                              :  2;
        UI32_T  pdma_lbk_rqid4              :  6;
    } field;
} HAL_DAWN_PKT_LBK_RQID4_7_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  cos_pfc_sts3                :  8;
        UI32_T  cos_pfc_sts2                :  8;
        UI32_T  cos_pfc_sts1                :  8;
        UI32_T  cos_pfc_sts0                :  8;
    } field;
} HAL_DAWN_PKT_COS_PFC_STS_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T  pdma_ela_valid_sel          :  8;
        UI32_T                              :  7;
        UI32_T  pdma_ela_en                 :  1;
    } field;
} HAL_DAWN_PKT_ELA_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  pdma_ela_word3_sel          :  8;
        UI32_T  pdma_ela_word2_sel          :  8;
        UI32_T  pdma_ela_word1_sel          :  8;
        UI32_T  pdma_ela_word0_sel          :  8;
    } field;
} HAL_DAWN_PKT_ELA_SEL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                                      :  6;
        UI32_T  ingr_pln_full_pkt_mode              :  1;
        UI32_T                                      :  1;
        UI32_T                                      :  7;
        UI32_T  ingr_pln_ios_credit_set             :  1;
        UI32_T  ingr_pln_ios_credit_base_size_hi    :  8;
        UI32_T  ingr_pln_ios_credit_base_size_lo    :  8;
    } field;
} HAL_DAWN_PKT_IGR_PLN_CREDIT_CFG_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  6;
        UI32_T  ingr_pln_ios_credit_udfl    :  1;
        UI32_T  ingr_pln_ios_credit_ovfl    :  1;
        UI32_T  ingr_pln_cur_ios_credit_hi  :  8;
        UI32_T  ingr_pln_cur_ios_credit_lo  :  8;
    } field;
} HAL_DAWN_PKT_IGR_PLN_CREDIT_STS_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                                      :  8;
        UI32_T                                      :  8;
        UI32_T  ingr_pln_ios_credit_rdy_hi_bound    :  8;
        UI32_T  ingr_pln_ios_credit_rdy_lo_bound    :  8;
    } field;
} HAL_DAWN_PKT_IGR_PLN_CREDIT_THR_REG_T;


typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  7;
        UI32_T  rch_pfc_fun_en              :  1;
        UI32_T                              :  7;
        UI32_T  rch_crc_regen_en            :  1;
        UI32_T                              :  7;
        UI32_T  rch_stomp_crc_en            :  1;
    } field;
} HAL_DAWN_PKT_RCH_STOMP_CRC_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T                              :  7;
        UI32_T  rch_chksm_en                :  1;
        UI32_T                              :  7;
        UI32_T  rch_ioc_en                  :  1;
    } field;
} HAL_DAWN_PKT_RCH_MISC_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T  rch_gpd_pfc_hi              :  8;
        UI32_T  rch_gpd_pfc_lo              :  8;
    } field;
} HAL_DAWN_PKT_RCH_GPD_PFC_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  5;
        UI32_T  rch_fifo_pfc_hi_hi          :  3;
        UI32_T  rch_fifo_pfc_hi_lo          :  8;
        UI32_T                              :  5;
        UI32_T  rch_fifo_pfc_lo_hi          :  3;
        UI32_T  rch_fifo_pfc_lo_lo          :  8;
    } field;
} HAL_DAWN_PKT_RCH_FIFO_PFC_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T                              :  3;
        UI32_T  rch_cmdq_pfc_hi             :  5;
        UI32_T                              :  3;
        UI32_T  rch_cmdq_pfc_lo             :  5;
    } field;
} HAL_DAWN_PKT_RCH_CMDQ_PFC_CTRL_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_gpd_add_no_hi           :  8;
        UI32_T  rch_gpd_add_no_lo           :  8;
        UI32_T                              :  8;
        UI32_T                              :  5;
        UI32_T  rch_stop                    :  1;
        UI32_T  rch_resume                  :  1;
        UI32_T  rch_start                   :  1;
    } field;
} HAL_DAWN_PKT_RCH_CMD_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T                              :  2;
        UI32_T  rch_flush_cnt_clr           :  1;
        UI32_T  rch_pkterr_drop_cnt_clr     :  1;
        UI32_T  rch_udsz_drop_cnt_clr       :  1;
        UI32_T  rch_ovsz_drop_cnt_clr       :  1;
        UI32_T  rch_cmdq_ovf_drop_cnt_clr   :  1;
        UI32_T  rch_fifo_ovf_drop_cnt_clr   :  1;
    } field;
} HAL_DAWN_PKT_RCH_CNT_CLR_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  rch_avbl_gpd_no_hi          :  8;
        UI32_T  rch_avbl_gpd_no_lo          :  8;
        UI32_T                              :  8;
        UI32_T                              :  3;
        UI32_T  rch_pfc                     :  1;
        UI32_T  rch_cmdq_pfc                :  1;
        UI32_T  rch_fifo_pfc                :  1;
        UI32_T  rch_avbl_gpd_pfc            :  1;
        UI32_T  rch_active                  :  1;
    } field;
} HAL_DAWN_PKT_RCH_STATUS_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T                              :  8;
        UI32_T  tch_gpd_wrbk_full_pkt_len   :  1;
        UI32_T  tch_adv_gpd_wrbk            :  1;
        UI32_T  tch_chk_cos_en              :  1;
        UI32_T  tch_early_done_irq          :  1;
        UI32_T  tch_pktlen_chk_en           :  1;
        UI32_T  tch_pfc_en                  :  1;
        UI32_T  tch_chksm_en                :  1;
        UI32_T  tch_ioc_en                  :  1;
    } field;
} HAL_DAWN_PKT_TCH_CFG_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T  tch_gpd_add_no_hi           :  8;
        UI32_T  tch_gpd_add_no_lo           :  8;
        UI32_T                              :  8;
        UI32_T                              :  5;
        UI32_T  tch_stop                    :  1;
        UI32_T  tch_resume                  :  1;
        UI32_T  tch_start                   :  1;
    } field;
} HAL_DAWN_PKT_TCH_CMD_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  7;
        UI32_T  tch_avbl_gpd_no             :  1;
        UI32_T                              :  8;
        UI32_T                              :  5;
        UI32_T  tch_gpd_rd_dma_act          :  1;
        UI32_T  tch_pfc                     :  1;
        UI32_T  tch_active                  :  1;
    } field;
} HAL_DAWN_PKT_TCH_STS_REG_T;

typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                              :  8;
        UI32_T                              :  4;
        UI32_T  tch_gpd_dmaw_qos            :  4;
        UI32_T                              :  4;
        UI32_T  tch_pkt_dmar_qos            :  4;
        UI32_T                              :  4;
        UI32_T  tch_gpd_dmar_qos            :  4;
    } field;
} HAL_DAWN_PKT_TCH_QOS_CFG_REG_T;

#else
#error "Host GPD endian is not defined\n"
#endif

/* ----------------------------------------------------------------------------------- CLX_EN_NETIF */
#if defined (CLX_EN_NETIF)
#define HAL_DAWN_PKT_DRIVER_MAJOR_NUM    (10)
#define HAL_DAWN_PKT_DRIVER_MINOR_NUM    (252) /* DO NOT use MISC_DYNAMIC_MINOR */
#define HAL_DAWN_PKT_DRIVER_NAME         "clx_netif"
#define HAL_DAWN_PKT_DRIVER_PATH         "/dev/"HAL_DAWN_PKT_DRIVER_NAME

/* These requirements come from CLX_NETIF APIs.
 * clx_netif -> hal_pkt_drv -> hal_pkt_knl
 */

typedef struct
{
    UI32_T          tx_pkt;
    UI32_T          tx_queue_full;
    UI32_T          tx_error;
    UI32_T          rx_pkt;

} HAL_DAWN_PKT_NETIF_INTF_CNT_T;

typedef struct
{
    /* unique key */
    UI32_T                      id;
    C8_T                        name[CLX_NETIF_NAME_LEN];
    UI32_T                      port;       /* only support unit port and local port */

    /* metadata */
    UI8_T                       mac[6];

#define HAL_DAWN_PKT_NETIF_INTF_FLAGS_MAC        (1UL << 0)
    UI32_T                      flags;


} HAL_DAWN_PKT_NETIF_INTF_T;

#if defined(NETIF_EN_NETLINK)
typedef struct
{
    C8_T                        name[CLX_NETIF_NAME_LEN];
    C8_T                        mc_group_name[CLX_NETIF_NAME_LEN];
} HAL_DAWN_PKT_NETIF_RX_DST_NETLINK_T;
#endif

typedef enum
{
    HAL_DAWN_PKT_NETIF_RX_DST_SDK = 0,
#if defined(NETIF_EN_NETLINK)
    HAL_DAWN_PKT_NETIF_RX_DST_NETLINK,
#endif
    HAL_DAWN_PKT_NETIF_RX_DST_LAST
} HAL_DAWN_PKT_NETIF_RX_DST_TYPE_T;

typedef struct
{
    /* unique key */
    UI32_T                              id;
    C8_T                                name[CLX_NETIF_NAME_LEN];
    UI32_T                              priority;

    /* match fields */
    UI32_T                              port;     /* only support unit port and local port */
    HAL_PKT_RX_REASON_BITMAP_T          reason_bitmap;
    UI8_T                               pattern[CLX_NETIF_PROFILE_PATTERN_NUM][CLX_NETIF_PROFILE_PATTERN_LEN];
    UI8_T                               mask[CLX_NETIF_PROFILE_PATTERN_NUM][CLX_NETIF_PROFILE_PATTERN_LEN];
    UI32_T                              offset[CLX_NETIF_PROFILE_PATTERN_NUM];

    /* for each flag 1:must hit, 0:don't care */
#define HAL_DAWN_PKT_NETIF_PROFILE_FLAGS_PORT      (1UL << 0)
#define HAL_DAWN_PKT_NETIF_PROFILE_FLAGS_REASON    (1UL << 1)
#define HAL_DAWN_PKT_NETIF_PROFILE_FLAGS_PATTERN_0 (1UL << 2)
#define HAL_DAWN_PKT_NETIF_PROFILE_FLAGS_PATTERN_1 (1UL << 3)
#define HAL_DAWN_PKT_NETIF_PROFILE_FLAGS_PATTERN_2 (1UL << 4)
#define HAL_DAWN_PKT_NETIF_PROFILE_FLAGS_PATTERN_3 (1UL << 5)
    UI32_T                              flags;

    HAL_DAWN_PKT_NETIF_RX_DST_TYPE_T     dst_type;
#if defined(NETIF_EN_NETLINK)
    HAL_DAWN_PKT_NETIF_RX_DST_NETLINK_T  netlink;
#endif

} HAL_DAWN_PKT_NETIF_PROFILE_T;


/* These requirements come from CLX_PKT APIs.
 * clx_pkt -> hal_pkt_srv -> hal_pkt_drv -> hal_pkt_knl
 */
typedef enum
{
    /* network interface */
    HAL_DAWN_PKT_IOCTL_TYPE_CREATE_INTF = 0,
    HAL_DAWN_PKT_IOCTL_TYPE_DESTROY_INTF,
    HAL_DAWN_PKT_IOCTL_TYPE_GET_INTF,
    HAL_DAWN_PKT_IOCTL_TYPE_CREATE_PROFILE,
    HAL_DAWN_PKT_IOCTL_TYPE_DESTROY_PROFILE,
    HAL_DAWN_PKT_IOCTL_TYPE_GET_PROFILE,
    HAL_DAWN_PKT_IOCTL_TYPE_GET_INTF_CNT,
    HAL_DAWN_PKT_IOCTL_TYPE_CLEAR_INTF_CNT,
    /* driver */
    HAL_DAWN_PKT_IOCTL_TYPE_WAIT_RX_FREE,
    HAL_DAWN_PKT_IOCTL_TYPE_WAIT_TX_FREE,     /* waitTxFree(ASYNC) */
    HAL_DAWN_PKT_IOCTL_TYPE_SET_RX_CFG,       /* setRxConfig       */
    HAL_DAWN_PKT_IOCTL_TYPE_GET_RX_CFG,       /* getRxConfig       */
    HAL_DAWN_PKT_IOCTL_TYPE_DEINIT_TASK,      /* deinitTask        */
    HAL_DAWN_PKT_IOCTL_TYPE_DEINIT_DRV,       /* deinitDrv         */
    HAL_DAWN_PKT_IOCTL_TYPE_INIT_TASK,        /* initTask          */
    HAL_DAWN_PKT_IOCTL_TYPE_INIT_DRV,         /* initDrv           */
    /* counter */
    HAL_DAWN_PKT_IOCTL_TYPE_GET_TX_CNT,
    HAL_DAWN_PKT_IOCTL_TYPE_GET_RX_CNT,
    HAL_DAWN_PKT_IOCTL_TYPE_CLEAR_TX_CNT,
    HAL_DAWN_PKT_IOCTL_TYPE_CLEAR_RX_CNT,
    /* port attribute */
    HAL_DAWN_PKT_IOCTL_TYPE_SET_PORT_ATTR,
#if defined(NETIF_EN_NETLINK)
    HAL_DAWN_PKT_IOCTL_TYPE_NL_SET_INTF_PROPERTY,
    HAL_DAWN_PKT_IOCTL_TYPE_NL_GET_INTF_PROPERTY,
    HAL_DAWN_PKT_IOCTL_TYPE_NL_CREATE_NETLINK,
    HAL_DAWN_PKT_IOCTL_TYPE_NL_DESTROY_NETLINK,
    HAL_DAWN_PKT_IOCTL_TYPE_NL_GET_NETLINK,
#endif
    HAL_DAWN_PKT_IOCTL_TYPE_LAST

} HAL_DAWN_PKT_IOCTL_TYPE_T;

typedef enum
{
    HAL_DAWN_PKT_IOCTL_RX_TYPE_INIT = 0,
    HAL_DAWN_PKT_IOCTL_RX_TYPE_DEINIT,
    HAL_DAWN_PKT_IOCTL_RX_TYPE_LAST,

} HAL_DAWN_PKT_IOCTL_RX_TYPE_T;

typedef struct
{
    UI32_T                          unit;
    UI32_T                          channel;
    HAL_DAWN_PKT_RX_CNT_T            rx_cnt;
    HAL_DAWN_PKT_TX_CNT_T            tx_cnt;
    CLX_ERROR_NO_T                  rc;

} HAL_DAWN_PKT_IOCTL_CH_CNT_COOKIE_T;

typedef struct
{
    UI32_T                          unit;
    HAL_DAWN_PKT_NETIF_INTF_T        net_intf;       /* addIntf[In,Out], delIntf[In]              */
    HAL_DAWN_PKT_NETIF_PROFILE_T     net_profile;    /* createProfile[In,Out], destroyProfile[In] */
    HAL_DAWN_PKT_NETIF_INTF_CNT_T    cnt;
    CLX_ERROR_NO_T                  rc;

} HAL_DAWN_PKT_IOCTL_NETIF_COOKIE_T;

typedef struct
{
    CLX_ADDR_T                      callback;       /* (unit, ptr_sw_gpd, ptr_cookie) */
    CLX_ADDR_T                      cookie;         /* Pointer of CLX_PKT_TX_PKT_T    */
    UI32_T                          channel;
    UI32_T                          gpd_num;
    CLX_ADDR_T                      hw_gpd_addr;
    CLX_ADDR_T                      sw_gpd_addr;

} HAL_DAWN_PKT_IOCTL_TX_GPD_T;

typedef struct
{
    UI32_T                          unit;
    UI32_T                          channel;            /* sendGpd[In]      */
    CLX_ADDR_T                      ioctl_gpd_addr;     /* sendGpd[In]      */
    CLX_ADDR_T                      done_sw_gpd_addr;   /* waitTxFree[Out]  */

} HAL_DAWN_PKT_IOCTL_TX_COOKIE_T;

typedef struct
{
    BOOL_T                          rx_complete;        /* FALSE when PDMA error occurs                 */
    CLX_ADDR_T                      hw_gpd_addr;        /* Pointer to HW GPD in user's SW GPD struct    */
    CLX_ADDR_T                      dma_buf_addr;       /* Pointer to DMA buffer allocated by the user (virtual) */

} HAL_DAWN_PKT_IOCTL_RX_GPD_T;

typedef struct
{
    UI32_T                          unit;
    UI32_T                          channel;            /* getRxCnt[In], clearRxInt[In]     */
    CLX_ADDR_T                      ioctl_gpd_addr;     /* waitRxFree[Out]                  */
    UI32_T                          buf_len;            /* setRxCfg[In]                     */
    HAL_DAWN_PKT_IOCTL_RX_TYPE_T     rx_type;            /* setRxCfg[In]                     */

} HAL_DAWN_PKT_IOCTL_RX_COOKIE_T;

typedef struct
{
    UI32_T                          port;
    UI32_T                          status;
    CLX_PORT_SPEED_T                speed;

} HAL_DAWN_PKT_IOCTL_PORT_COOKIE_T;

#if defined(NETIF_EN_NETLINK)

typedef struct
{
    /* intf property */
    UI32_T                          intf_id;
    CLX_NETIF_INTF_PROPERTY_T       property;
    UI32_T                          param0;
    UI32_T                          param1;

    /* netlink */
    CLX_NETIF_NETLINK_T             netlink;

    CLX_ERROR_NO_T                  rc;

} HAL_DAWN_PKT_NL_IOCTL_COOKIE_T;


#endif  /* End of NETIF_EN_NETLINK */

typedef union
{
    UI32_T                          value;
    struct
    {
        UI32_T                      unit :  6;      /* Maximum unit number is 64.       */
        HAL_DAWN_PKT_IOCTL_TYPE_T    type : 10;      /* Maximum 1024 IOCTL types         */
        UI32_T                      rsvd : 16;
    } field;

} HAL_DAWN_PKT_IOCTL_CMD_T;

#endif /* End of CLX_EN_NETIF */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* ----------------------------------------------------------------------------------- Debug APIs */
/* FUNCTION NAME: hal_dawn_pkt_showTxPdmaGpd
 * PURPOSE:
 *      To dump the values of fields for the specified TX GPD.
 * INPUT:
 *      unit        --  The unit ID
 *      ptr_tx_gpd  --  Pointer for the TX GPD
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    --  Successfully dump the GPD content.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showTxPdmaGpd(
    const UI32_T                            unit,
    const volatile HAL_DAWN_PKT_TX_GPD_T     *ptr_tx_gpd);

/* FUNCTION NAME: hal_dawn_pkt_showRxPdmaGpd
 * PURPOSE:
 *      To dump the values of fields for the specified RX GPD.
 * INPUT:
 *      unit        --  The unit ID
 *      ptr_rx_gpd  --  Pointer for the RX GPD
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    --  Successfully show the RX GPD content.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showRxPdmaGpd(
    const UI32_T                            unit,
    const volatile HAL_DAWN_PKT_RX_GPD_T     *ptr_rx_gpd);

/* FUNCTION NAME: hal_dawn_pkt_showTxPdmaCtrlBlock
 * PURPOSE:
 *      To display the PDMA TX control block of the target channel.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 *      gpd_start       -- The GPD start index
 *      gpd_end         -- The GPD end index
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully display the control block.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showTxPdmaCtrlBlock(
    const UI32_T            unit,
    const UI32_T            channel,
    const UI32_T            gpd_start,
    const UI32_T            gpd_end);

/* FUNCTION NAME: hal_dawn_pkt_showRxPdmaCtrlBlock
 * PURPOSE:
 *      To display the PDMA RX control block of the target channel.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 *      gpd_start       -- The GPD start index
 *      gpd_end         -- The GPD end index
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully display the control block.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showRxPdmaCtrlBlock(
    const UI32_T            unit,
    const UI32_T            channel,
    const UI32_T            gpd_start,
    const UI32_T            gpd_end);

/* FUNCTION NAME: hal_dawn_pkt_showTxReg
 * PURPOSE:
 *      To display the PDMA generic registers.
 * INPUT:
 *      unit            -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully display the control block.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showReg(
    const UI32_T            unit);

/* FUNCTION NAME: hal_dawn_pkt_showTxReg
 * PURPOSE:
 *      To display the PDMA TX registers.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully display the control block.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showTxReg(
    const UI32_T            unit,
    const UI32_T            channel);

/* FUNCTION NAME: hal_dawn_pkt_showRxReg
 * PURPOSE:
 *      To display the PDMA RX registers.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully display the control block.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showRxReg(
    const UI32_T            unit,
    const UI32_T            channel);

/* FUNCTION NAME: hal_dawn_pkt_setQueueToRxChannel
 * PURPOSE:
 *      To set a queue id to the specified RX channel.
 * INPUT:
 *      unit            --  The unit ID
 *      queue           --  The target queue ID
 *      channel         --  The expected channel to which the queue mapped
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully configure the mapping.
 *      CLX_E_OTHERS    --  Configure the mapping failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_setQueueToRxChannel(
    const UI32_T            unit,
    const UI32_T            queue,
    const UI32_T            channel);

/* FUNCTION NAME: hal_dawn_pkt_getQueueToRxChannel
 * PURPOSE:
 *      To set a queue id to the specified RX channel.
 * INPUT:
 *      unit            --  The unit ID
 *      queue           --  The target queue ID
 * OUTPUT:
 *      ptr_channel     --  Pointer for the channel to which the queue mapped
 * RETURN:
 *      CLX_E_OK        --  Successfully obtain the mapping.
 *      CLX_E_OTHERS    --  Obtain the mapping failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_getQueueToRxChannel(
    const UI32_T            unit,
    const UI32_T            queue,
          UI32_T            *ptr_channel);

/* FUNCTION NAME: hal_dawn_pkt_setRxQueueTruncateSize
 * PURPOSE:
 *      To set packet truncated size to the target RX queue.
 * INPUT:
 *      unit            --  The unit ID
 *      queue           --  The target queue ID
 *      truncate_size   --  The expected packet truncated size
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully configure the size.
 *      CLX_E_OTHERS    --  Configure the size failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_setRxQueueTruncateSize(
    const UI32_T            unit,
    const UI32_T            queue,
    const UI32_T            truncate_size);

/* FUNCTION NAME: hal_dawn_pkt_getRxQueueTruncateSize
 * PURPOSE:
 *      To obatin the packet truncated size of the target RX queue.
 * INPUT:
 *      unit                --  The unit ID
 *      queue               --  The target queue ID
 * OUTPUT:
 *      ptr_truncate_size   -- Pointer for the packet truncated size
 * RETURN:
 *      CLX_E_OK        --  Successfully configure the size.
 *      CLX_E_OTHERS    --  Configure the size failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_getRxQueueTruncateSize(
    const UI32_T            unit,
    const UI32_T            queue,
          UI32_T            *ptr_truncate_size);

/* FUNCTION NAME: hal_dawn_pkt_setTxChannelCosBitmap
 * PURPOSE:
 *      To map the specified CoS values to the target TX channel.
 * INPUT:
 *      unit            --  The unit ID
 *      channel         --  The target TX channel
 *      cos_bitmap      --  bit 0~7 stand for CoS 0~7 respectively.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully configure the mapping.
 *      CLX_E_OTHERS    --  Configure the mapping failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_setTxChannelCosBitmap(
    const UI32_T            unit,
    const UI32_T            channel,
    const UI8_T             cos_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_getTxChannelCosBitmap
 * PURPOSE:
 *      To get the CoS mapped to the specified channel.
 * INPUT:
 *      unit            --  The unit ID
 *      channel         --  The target TX channel
 * OUTPUT:
 *      ptr_cos_bitmap  --  Pointer for the CoS bitmap
 * RETURN:
 *      CLX_E_OK        --  Successfully get the mapping.
 *      CLX_E_OTHERS    --  Get the mapping failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_getTxChannelCosBitmap(
    const UI32_T            unit,
    const UI32_T            channel,
          UI8_T             *ptr_cos_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_showTxDbgCnt
 * PURPOSE:
 *      To display the PDMA TX counters of the target channel.
 * INPUT:
 *      unit        -- The unit ID
 *      channel     -- The target channel
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Successfully display the counters.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showTxDbgCnt(
    const UI32_T            unit,
    const UI32_T            channel);

/* FUNCTION NAME: hal_dawn_pkt_showRxDbgCnt
 * PURPOSE:
 *      To display the PDMA RX counters of the target channel.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully display the counters.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_showRxDbgCnt(
    const UI32_T            unit,
    const UI32_T            channel);

/* ----------------------------------------------------------------------------------- Diag APIs */
/* FUNCTION NAME: hal_dawn_pkt_getTxCnt
 * PURPOSE:
 *      To clear the PDMA RX counters of the target channel.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 *      ptr_cnt         -- Pointer for the counter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Successfully get the counter.
 *      CLX_E_ENTRY_NOT_FOUND   -- The channel is invalid.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_getTxCnt(
    const UI32_T            unit,
    const UI32_T            channel,
    CLX_PKT_TX_CNT_T        *ptr_cnt);

/* FUNCTION NAME: hal_dawn_pkt_getRxCnt
 * PURPOSE:
 *      To get the PDMA RX counters of the target channel.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 *      ptr_cnt         -- Pointer for the counter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Successfully get the counter.
 *      CLX_E_ENTRY_NOT_FOUND   -- The channel is invalid.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_getRxCnt(
    const UI32_T            unit,
    const UI32_T            channel,
    CLX_PKT_RX_CNT_T        *ptr_cnt);

/* FUNCTION NAME: hal_dawn_pkt_clearTxCnt
 * PURPOSE:
 *      To clear the PDMA TX counters of the target channel.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully clear the counters.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_clearTxCnt(
    const UI32_T            unit,
    const UI32_T            channel);

/* FUNCTION NAME: hal_dawn_pkt_clearRxCnt
 * PURPOSE:
 *      To clear the PDMA RX counters of the target channel.
 * INPUT:
 *      unit            -- The unit ID
 *      channel         -- The target channel
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully clear the counters.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_clearRxCnt(
    const UI32_T            unit,
    const UI32_T            channel);

/* FUNCTION NAME: hal_dawn_pkt_setPdmaLoopback
 * PURPOSE:
 *      To enable or disable the PDMA loopback.
 * INPUT:
 *      unit            -- The unit ID
 *      enabled         -- TRUE: Indicate to enable the PDMA loopback.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully set the configration.
 *      CLX_E_OTHERS    -- Set the configration failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_setPdmaLoopback(
    const UI32_T                    unit,
    const BOOL_T                    enabled);

/* ----------------------------------------------------------------------------------- pkt_drv */
#if defined(CLX_LAMP)
/* FUNCTION NAME: hal_dawn_pkt_sendGpdToCmodel
 * PURPOSE:
 *      To send a packet to the C-model.
 * INPUT:
 *      unit        --  The unit ID
 *      channel     --  The target TX channel
 *      ptr_sw_gpd  --  Pointer for the SW Tx GPD link list
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    --  Successfully send the packet to the C-model.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_sendGpdToCmodel(
    const UI32_T                    unit,
    const HAL_DAWN_PKT_TX_CHANNEL_T  channel,
          HAL_DAWN_PKT_TX_SW_GPD_T   *ptr_sw_gpd);

#else
/* FUNCTION NAME: hal_dawn_pkt_sendGpd
 * PURPOSE:
 *      To perform the packet transmission form CPU to the switch.
 * INPUT:
 *      unit        --  The unit ID
 *      channel     --  The target TX channel
 *      ptr_sw_gpd  --  Pointer for the SW Tx GPD link list
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    --  Successfully perform the transferring.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_sendGpd(
    const UI32_T                    unit,
    const HAL_DAWN_PKT_TX_CHANNEL_T  channel,
          HAL_DAWN_PKT_TX_SW_GPD_T   *ptr_sw_gpd);

#endif

/* ----------------------------------------------------------------------------------- pkt_srv */
/* FUNCTION NAME: hal_dawn_pkt_sendPacket
 * PURPOSE:
 *      To transfer the packet form CPU to the switch.
 * INPUT:
 *      unit            --  The unit ID
 *      channel         --  The target TX channel
 *      ptr_tx_pkt      --  Pointer for the TX packet
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully transfer the packet.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_sendPacket(
    const UI32_T                    unit,
    const UI32_T                    channel,
    const CLX_PKT_TX_PKT_T          *ptr_tx_pkt);

/* FUNCTION NAME: hal_dawn_pkt_invokeRxUsrCallback
 * PURPOSE:
 *      To invoke the user callback function for the RX packet.
 * INPUT:
 *      unit            -- The unit ID
 *      ptr_sw_gpd      -- Pointer for the SW Tx GPD link list
 *      ptr_cookie      -- The Rx callback cookie
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully invoke the callback function.
 * NOTES:
 *      The packet will also be store in the packet monitor.
 */
HAL_DAWN_PKT_CALLBACK_NO_T
hal_dawn_pkt_invokeRxUsrCallback(
    const UI32_T                    unit,
          HAL_DAWN_PKT_RX_SW_GPD_T   *ptr_sw_gpd,
          void                      *ptr_cookie);

/* ----------------------------------------------------------------------------------- Rx Init */
/* FUNCTION NAME: hal_dawn_pkt_setRxGpdCallback
 * PURPOSE:
 *      To register a callback function for receiving RX packet.
 * INPUT:
 *      unit            -- The unit ID
 *      callback        -- The callback function
 *      ptr_cookie      -- The pointer for the private data
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully register the callback.
 *      CLX_E_OTHERS    -- Register the callback failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_setRxGpdCallback(
    const UI32_T                            unit,
    const HAL_DAWN_PKT_RX_FUNC_T             func,
          void                              *ptr_cookie,
    const HAL_DAWN_PKT_RX_CALLBACK_ACTION_T  action);

/* FUNCTION NAME: hal_dawn_pkt_setRxDrvConfig
 * PURPOSE:
 *      1. To stop the Rx channel and deinit the Rx subsystem.
 *      2. To init the Rx subsystem and start the Rx channel.
 *      3. To restart the Rx subsystem
 * INPUT:
 *      unit            -- The unit ID
 *      ptr_rx_cfg      -- The user configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully configure the RX parameters.
 *      CLX_E_OTHERS    -- Configure the parameter failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_pkt_setRxDrvConfig(
    const UI32_T                unit,
    const CLX_PKT_RX_CFG_T      *ptr_rx_cfg);

/* FUNCTION NAME: hal_dawn_pkt_getRxDrvConfig
 * PURPOSE:
 *      To get the Rx subsystem configuration.
 * INPUT:
 *      unit            -- The unit ID
 *      ptr_rx_cfg      -- The user configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully configure the RX parameters.
 *      CLX_E_OTHERS    -- Configure the parameter failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_pkt_getRxDrvConfig(
    const UI32_T                unit,
          CLX_PKT_RX_CFG_T      *ptr_rx_cfg);

/* FUNCTION NAME: hal_dawn_pkt_setRxConfig
 * PURPOSE:
 *      To replace the Rx callback
 * INPUT:
 *      unit            -- The unit ID
 *      ptr_rx_cfg      -- The user configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully configure the RX parameters.
 *      CLX_E_OTHERS    -- Configure the parameter failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_pkt_setRxConfig(
    const UI32_T                unit,
    const CLX_PKT_RX_CFG_T      *ptr_rx_cfg);

/* FUNCTION NAME: hal_dawn_pkt_getRxConfig
 * PURPOSE:
 *      To get the Rx subsystem configuration.
 * INPUT:
 *      unit            -- The unit ID
 *      ptr_rx_cfg      -- The user configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Successfully configure the RX parameters.
 *      CLX_E_OTHERS    -- Configure the parameter failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_pkt_getRxConfig(
    const UI32_T                unit,
          CLX_PKT_RX_CFG_T      *ptr_rx_cfg);

/* ----------------------------------------------------------------------------------- Deinit */
/* FUNCTION NAME: hal_dawn_pkt_deinitTask
 * PURPOSE:
 *      To de-initialize the Task for packet module.
 * INPUT:
 *      unit            --  The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully dinitialize the control block.
 *      CLX_E_OTHERS    --  Initialize the control block failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_deinitTask(
    const UI32_T                unit);

/* FUNCTION NAME: hal_dawn_pkt_deinitPktDrv
 * PURPOSE:
 *      To invoke the functions to de-initialize the control block for each
 *      PDMA subsystem.
 * INPUT:
 *      unit            --  The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully de-initialize the control blocks.
 *      CLX_E_OTHERS    --  De-initialize the control blocks failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_deinitPktDrv(
    const UI32_T                unit);

/* FUNCTION NAME: hal_dawn_pkt_deinit
 * PURPOSE:
 *      To de-initialize the packet module.
 * INPUT:
 *      unit            --  The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully de-initialize the packet module.
 *      CLX_E_OTHERS    --  De-initialize the packet module failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_deinit(
    const UI32_T                unit);

/* ----------------------------------------------------------------------------------- Init */
/* FUNCTION NAME: hal_dawn_pkt_initTask
 * PURPOSE:
 *      To initialize the Task for packet module.
 * INPUT:
 *      unit            --  The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully dinitialize the control block.
 *      CLX_E_OTHERS    --  Initialize the control block failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_initTask(
    const UI32_T                unit);

/* FUNCTION NAME: hal_dawn_pkt_initPktDrv
 * PURPOSE:
 *      To invoke the functions to initialize the control block for each
 *      PDMA subsystem.
 * INPUT:
 *      unit            --  The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully initialize the control blocks.
 *      CLX_E_OTHERS    --  Initialize the control blocks failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_initPktDrv(
    const UI32_T                unit);

/* FUNCTION NAME: hal_dawn_pkt_init
 * PURPOSE:
 *      To initialize the packet module.
 * INPUT:
 *      unit            --  The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Successfully initialize the packet module.
 *      CLX_E_OTHERS    --  Initialize the packet module failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_init(
    const UI32_T                unit);

/* ----------------------------------------------------------------------------------- NETIF APIs */
CLX_ERROR_NO_T
hal_dawn_pkt_createIntf(
    const UI32_T                unit,
          CLX_NETIF_INTF_T      *ptr_net_intf,
          UI32_T                *ptr_intf_id);

CLX_ERROR_NO_T
hal_dawn_pkt_destroyIntf(
    const UI32_T                unit,
    const UI32_T                id);

CLX_ERROR_NO_T
hal_dawn_pkt_getIntf(
    const UI32_T                unit,
    const UI32_T                id,
          CLX_NETIF_INTF_T      *ptr_net_intf);

CLX_ERROR_NO_T
hal_dawn_pkt_createProfile(
    const UI32_T                unit,
          CLX_NETIF_PROFILE_T   *ptr_net_profile,
          UI32_T                *ptr_profile_id);

CLX_ERROR_NO_T
hal_dawn_pkt_destroyProfile(
    const UI32_T                unit,
    const UI32_T                id);

CLX_ERROR_NO_T
hal_dawn_pkt_getProfile(
    const UI32_T                unit,
    const UI32_T                id,
          CLX_NETIF_PROFILE_T   *ptr_net_profile);

CLX_ERROR_NO_T
hal_dawn_pkt_getIntfCnt(
    const UI32_T                unit,
    const UI32_T                id,
          CLX_NETIF_INTF_CNT_T  *ptr_intf_cnt);

CLX_ERROR_NO_T
hal_dawn_pkt_clearIntfCnt(
    const UI32_T                unit,
    const UI32_T                id);

#if defined(NETIF_EN_NETLINK)

CLX_ERROR_NO_T
hal_dawn_pkt_setIntfProperty(
    const UI32_T                        unit,
    const UI32_T                        intf_id,
    const CLX_NETIF_INTF_PROPERTY_T     property,
    const UI32_T                        param0,
    const UI32_T                        param1);

CLX_ERROR_NO_T
hal_dawn_pkt_getIntfProperty(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_NETIF_INTF_PROPERTY_T     property,
    UI32_T                              *ptr_param0,
    UI32_T                              *ptr_param1);

CLX_ERROR_NO_T
hal_dawn_pkt_createNetlink(
    const UI32_T                        unit,
    CLX_NETIF_NETLINK_T                 *ptr_netlink,
    UI32_T                              *ptr_netlink_id);

CLX_ERROR_NO_T
hal_dawn_pkt_destroyNetlink(
    const UI32_T                        unit,
    const UI32_T                        netlink_id);

CLX_ERROR_NO_T
hal_dawn_pkt_getNetlink(
    const UI32_T                        unit,
    const UI32_T                        id,
    CLX_NETIF_NETLINK_T                 *ptr_netlink);

#endif  /* end of NETIF_EN_NETLINK */

CLX_ERROR_NO_T
hal_dawn_pkt_dumpDb(
    const UI32_T                unit,
    const UI32_T                flags);

CLX_ERROR_NO_T
hal_dawn_pkt_dumpReg(
    const UI32_T                unit,
    const UI32_T                flags);

void
hal_dawn_pkt_convertVirtToPhy(
    const UI32_T                unit,
    void                        *ptr_virt_addr,
    CLX_ADDR_T                  *ptr_phy_addr);

void
hal_dawn_pkt_convertPhyToVirt(
    const UI32_T                unit,
    CLX_ADDR_T                  phy_addr,
    void                        **pptr_virt_addr);

#endif  /* End of HAL_DAWN_PKT_H */
