/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_swc.h
 * PURPOSE:
 *      API & special number for CL8570. For example: IEV, EMI.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_LIGHTNING_SWC_H
#define HAL_LIGHTNING_SWC_H

#include <clx_cfg.h>
#include <clx_swc.h>

#include <hal/common/hal_swc.h>

#define HAL_LIGHTNING_SWC_EMI_BANK_NUM                (8)
#define HAL_LIGHTNING_SWC_EMI_NSH_BANK_BASE           (HAL_LIGHTNING_SWC_EMI_BANK_NUM - 1)
#define HAL_LIGHTNING_SWC_PAGE_NUM_PER_BANK           (4)
#define HAL_LIGHTNING_SWC_ILE_TCAM_BANK_NUM           (64)
#define HAL_LIGHTNING_SWC_ILE_TCAM_ENTRY_NUM_PER_BANK (256)
#define HAL_LIGHTNING_SWC_MASTER_DIE_ID               (4) /* t die */

#define HAL_LIGHTNING_SWC_EPG_MAC_HDR_LEN (60)    /* bytes */
#define HAL_LIGHTNING_SWC_EPG_MAC_MAX_IPG (1024)  /* register 10 bits */

/* FUNCTION NAME:   hal_lightning_swc_setCpiEncap
 * PURPOSE:
 *      Set CPI port enacp.
 * INPUT:
 *      unit                -- Device unit number.
 *      port                -- CPI port.
 *      ptr_encap_hdr       -- Struture of encap.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_NOT_SUPPORT   --  Not support.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_lightning_swc_setCpiEncap(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SWC_CPI_ENCAP_HDR_T   *ptr_encap_hdr);

/* FUNCTION NAME:   hal_lightning_swc_getCpiEncap
 * PURPOSE:
 *      Set CPI port enacp.
 * INPUT:
 *      unit                -- Device unit number.
 *      port                -- CPI port.
 * OUTPUT:
 *      ptr_encap_hdr       -- Struture of encap.
 * RETURN:
 *      CLX_E_NOT_SUPPORT   --  Not support.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_lightning_swc_getCpiEncap(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SWC_CPI_ENCAP_HDR_T         *ptr_encap_hdr);

/* FUNCTION NAME:   hal_lightning_swc_setEpgMacHw
 * PURPOSE:
 *      Set MAC EPG packet related configuration (header, payload, ipg, ...)
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_pkt             -- Packet information to be sent
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_lightning_swc_setEpgMacHw(
    const UI32_T                unit,
    const HAL_SWC_EPG_PKT_T     *ptr_pkt);

/* FUNCTION NAME:   hal_lightning_swc_sendEpgMacPkt
 * PURPOSE:
 *      Trigger MAC EPG to send packets
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- EPG ingress port
 *      lpbk                -- 0: Traffic is sent to PP; 1: MAC loopback
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_lightning_swc_sendEpgMacPkt(
    const UI32_T unit,
    const UI32_T port,
    const UI32_T lpbk);

/* FUNCTION NAME:   hal_lightning_swc_chkEpgMacDone
 * PURPOSE:
 *      Trigger MAC EPG to send packets
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- EPG ingress port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_lightning_swc_chkEpgMacDone(
    const UI32_T unit,
    const UI32_T port);

/* FUNCTION NAME:   hal_lightning_swc_stopEpgMacPkt
 * PURPOSE:
 *      Stop MAC EPG from sending packets
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- EPG ingress port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_lightning_swc_stopEpgMacPkt(
    const UI32_T unit,
    const UI32_T port);

#endif
