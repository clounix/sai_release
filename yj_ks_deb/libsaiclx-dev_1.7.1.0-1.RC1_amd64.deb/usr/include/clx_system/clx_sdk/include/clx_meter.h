/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_meter.h
 * PURPOSE:
 *      Define the declartion for Meter module in CLX SDK.
 *
 * NOTES:
 *
 *
 */

#ifndef CLX_METER_H
#define CLX_METER_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* Invalid Meter ID */
#define CLX_METER_INVALID_METER_ID      (0xFFFFFFFF)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* Meter Algorithm */
typedef enum
{
    CLX_METER_ALGO_SRTCM = 0,   /* SrTCM                 */
    CLX_METER_ALGO_TRTCM,       /* TrTCM                 */
    CLX_METER_ALGO_MTRTCM,      /* modified TrTCM        */
    CLX_METER_ALGO_1R2CM,       /* single rate two color */
    CLX_METER_ALGO_LAST
} CLX_METER_ALGO_T;

/* Meter Parameter */
typedef struct CLX_METER_PARAMETER_S
{
    UI32_T cir;         /* cir, unit: 1kbps or 1pps        */
    UI32_T cbs;         /* cbs, unit: 1byte or 1pkt        */
    UI32_T pir_eir;     /* pir or eir, unit: 1kbps or 1pps */
    UI32_T pbs_ebs;     /* pbs or ebs, unit: 1byte or 1pkt */
} CLX_METER_PARAMETER_T;

/* Meter Configuration */
typedef struct CLX_METER_CFG_S
{
    CLX_METER_PARAMETER_T   param;      /* Bucket cir/cbs/pir/pbs/eir/ebs */
    CLX_METER_ALGO_T        algo_mode;  /* Meter Algorithm */

#define CLX_METER_CFG_FLAGS_COLOR_AWARE (1U << 0)   /* bit on: color aware; bit off: color blind */
#define CLX_METER_CFG_FLAGS_LAYER1      (1U << 1)   /* bit on: layer 1; bit off: layer 2         */
#define CLX_METER_CFG_FLAGS_PORT_BASED  (1U << 2)   /* bit on: port based; bit off: device based */
#define CLX_METER_CFG_FLAGS_PACKET_RATE (1U << 3)   /* bit on: packet rate; bit off: bit rate */

    UI32_T                  flags;  /* Refer to CLX_METER_CFG_FLAGS_XXX */
} CLX_METER_CFG_T;

/* Meter Color Resolve Type */
typedef enum
{
    CLX_METER_COLOR_RESOLVE_TYPE_INF_PRECEDENCE = 0,  /* interface precedence */
    CLX_METER_COLOR_RESOLVE_TYPE_DOMAIN_PRECEDENCE,   /* domain precedence    */
    CLX_METER_COLOR_RESOLVE_TYPE_WORST_COLOR,         /* worst color          */
    CLX_METER_COLOR_RESOLVE_TYPE_BEST_COLOR,          /* best color           */
    CLX_METER_COLOR_RESOLVE_TYPE_CIR_FAVOR,           /* cir-favor            */
    CLX_METER_COLOR_RESOLVE_TYPE_LAST,
} CLX_METER_COLOR_RESOLVE_TYPE_T;

/* Ingress Port Metering Configuration */
typedef struct CLX_METER_PORT_CFG_S
{
    UI32_T                  rate;                       /* unit: 1kbps or 1pps */
    UI32_T                  burst_size;                 /* unit: 1byte or 1pkt */

#define CLX_METER_PORT_CFG_FLAGS_METER_EN    (1U << 0)  /* bit on: meter enable; bit off: meter disable */
#define CLX_METER_PORT_CFG_FLAGS_LAYER2      (1U << 1)  /* bit on: layer 2; bit off: layer 1            */
#define CLX_METER_PORT_CFG_FLAGS_PACKET_RATE (1U << 2)  /* bit on: packet rate; bit off: bit rate       */

    UI32_T                  flags;  /* Refer to CLX_METER_PORT_CFG_FLAGS_XXX */
} CLX_METER_PORT_CFG_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_meter_createMeter
 * PURPOSE:
 *      Create a meter for interface (Rx(ingress)/ Tx(egress)),
 *      domain (Forwarding Domain or VRF), or flow (ingress ACL or egress ACL).
 * INPUT:
 *     unit             --  Device unit number
 *     ptr_meter_cfg   --  The configuration of the meter created
 * OUTPUT:
 *     ptr_meter_id  --  The logical ID of the created meter
 * RETURN:
 *     CLX_E_OK             --  Operation is successful
 *     CLX_E_BAD_PARAMETER  --  Bad parameter
 *     CLX_E_TABLE_FULL     --  There is no Meter to serve
 *     CLX_E_OTHERS         --  Operation failed
 * NOTES:
 *  The meter configurations except rate and bucket size are not modified.
 *  However, if user needs to modify these configurations, user should delete
 *  the meter and create a new one. <CL>
 *  Meter ID is used to present a meter; it can be used by destroying, getting,
 *  and setting functions to operate the specified meter. <CL>
 *  If user needs to use a meter, the meter should be bound to an object (e.g.
 *  interface, domain, acl rule). When a meter is not used, it should be unbound
 *  from the object (e.g. interface, domain, acl rule). <CL>
 *  For CBS/EBS/PBS setting, the suggestive value is CBS/EBS/PBS = CIR/EIR/PIR *
 *  125 us, the best value maybe less than the suggestive value.
 */
CLX_ERROR_NO_T
clx_meter_createMeter(
    const UI32_T           unit,
    const CLX_METER_CFG_T  *ptr_meter_cfg,
    UI32_T                 *ptr_meter_id);

/* FUNCTION NAME:   clx_meter_destroyMeter
 * PURPOSE:
 *      Destroy the meter of the assigned ID.
 * INPUT:
 *      unit      --  Device unit number
 *      meter_id  --  The ID of the meter to be destroyed
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operation success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- The specified Meter has not been created
 *      CLX_E_OTHERS          -- Operation failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_meter_destroyMeter(
    const UI32_T        unit,
    const UI32_T        meter_id);

/* FUNCTION NAME:   clx_meter_getMeter
 * PURPOSE:
 *      Get a meter configuration.
 * INPUT:
 *      unit       --  Device unit number
 *      meter_id   --  The ID of the meter
 * OUTPUT:
 *      ptr_meter_cfg  -- The configuration information of the meter created
 * RETURN:
 *      CLX_E_OK              --  Operation is successful
 *      CLX_E_BAD_PARAMETER   --  Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND --  The specified Meter has not been created
 *      CLX_E_OTHERS          --  Operation failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_meter_getMeter(
    const UI32_T     unit,
    const UI32_T     meter_id,
    CLX_METER_CFG_T  *ptr_meter_cfg);

/* FUNCTION NAME:   clx_meter_setMeterParam
 * PURPOSE:
 *      Modify a meter rate and burst (bucket) size.
 * INPUT:
 *      unit             -- Device unit number
 *      meter_id         -- It indicates the meter to be set
 *      ptr_meter_param  -- The new configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Set success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- The meter does not exist.
 *      CLX_E_OTHERS          -- Set failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_meter_setMeterParam(
    const UI32_T                unit,
    const UI32_T                meter_id,
    const CLX_METER_PARAMETER_T *ptr_meter_param);

/* FUNCTION NAME:   clx_meter_setIgrPortMeter
 * PURPOSE:
 *      Set ingress port metering for a specific port.
 * INPUT:
 *      unit             -- Device unit number
 *      port             -- Physical port ID
 *      ptr_cfg          -- The configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Set success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_OTHERS          -- Set failed
 * NOTES:
 *      If ingress port metering is enabled and the traffic exceeds meter rate,
 *      ingress packet will be dropped.
 */
CLX_ERROR_NO_T
clx_meter_setIgrPortMeter(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_METER_PORT_CFG_T *ptr_cfg);

/* FUNCTION NAME:   clx_meter_getIgrPortMeter
 * PURPOSE:
 *      Get ingress port metering for a specific port.
 * INPUT:
 *      unit             -- Device unit number
 *      port             -- Physical port ID
 *      ptr_cfg          -- The configuration
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Set success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_OTHERS          -- Get failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_meter_getIgrPortMeter(
    const UI32_T            unit,
    const UI32_T            port,
    CLX_METER_PORT_CFG_T    *ptr_cfg);

#endif
