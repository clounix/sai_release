/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_swc.h
 * PURPOSE:
 *      It provides switch control module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_SWC_H
#define CLX_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum
{
    CLX_SWC_PROPERTY_IPV4_HDR_ERROR,                /* IPv4 header err action, e.g. version err. */
    CLX_SWC_PROPERTY_IPV6_HDR_ERROR,                /* IPv6 header err action, e.g. version err. */
    CLX_SWC_PROPERTY_GLOBAL_ROUTE_MISS_ACTION,      /* Global route search miss action. */
    CLX_SWC_PROPERTY_L2_AGING_TIME,                 /* Set L2 entry aging time. */
    CLX_SWC_PROPERTY_PENDING_LEARN,                 /* Enable pending Learn. param0: 0: HW learn, 1: SW learn */
    CLX_SWC_PROPERTY_ICMP_REDIRECT,                 /* Packet icmp redirect type. */
    CLX_SWC_PROPERTY_L3_SELF_FORWARD,               /* ICMP redirect packet copy to cpu */
    CLX_SWC_PROPERTY_L3_URPF,                       /* URPF fail action. */
    CLX_SWC_PROPERTY_L3_MCAST_ADDR_VALIDATE,        /* Multicast packet destination MAC not match destination IP action. */
    CLX_SWC_PROPERTY_VXLAN_ROUTER_ALERT,            /* Enable VXLAN router alert bit */
    CLX_SWC_PROPERTY_VXLAN_UDP_PORT,                /* Set UDP destination port of VXLAN packet. */
    CLX_SWC_PROPERTY_NVGRE_ROUTER_ALERT,            /* Enable NVGRE router alert bit. */
    CLX_SWC_PROPERTY_NIV_SRC_VIF,                   /* Set network interface virtualization source virtual interface. */
    CLX_SWC_PROPERTY_VM_FCOE_TRANS_MODE,            /* Set VM FCOE translation mode. */
    CLX_SWC_PROPERTY_MIR_ERSPAN_MISS_ACTION,        /* ERSPAN term miss action. */
    CLX_SWC_PROPERTY_MIR_METER_LAYER,               /* Set mirror meter layer mode. */
    CLX_SWC_PROPERTY_STORM_CTRL_METER_LAYER,        /* Enable storm control meter layer 1 IPG and Preamble. */
    CLX_SWC_PROPERTY_STORM_CTRL_CTRL_PKT_CHECK,     /* Storm control control packet check. */
    CLX_SWC_PROPERTY_SOURCE_GUARD_DHCP_PKT_CHECK,   /* IP source guard DHCP packet check. */
    CLX_SWC_PROPERTY_FCOE_CLV_SWITCH_ENABLE,        /* Enable FCOE CLV switch. */
    CLX_SWC_PROPERTY_FCOE_DROP_UNKNOWN_MAC,         /* Enable FCOE drop unknown MAC. */
    CLX_SWC_PROPERTY_STEERING_EN,                   /* Enable steering. */
    /* exceptions, param0 is CLX_FWD_ACTION_T */
    CLX_SWC_PROPERTY_L2_SA_MOVE_ACTION,             /* Set source address move action, param0 is CLX_FWD_ACTION_T */
    CLX_SWC_PROPERTY_L2_SA_MISS_ACTION,             /* Set source address miss action, param0 is CLX_FWD_ACTION_T */
    CLX_SWC_PROPERTY_L3_IPV4_MC_MISS_ACTION,        /* IPv4 multicast search fail action. */
    CLX_SWC_PROPERTY_L3_IPV6_MC_MISS_ACTION,        /* IPv6 multicast search fail action.*/
    CLX_SWC_PROPERTY_L3_IPV4_OPT_HDR_ACTION,        /* IPv4 with option action. */
    CLX_SWC_PROPERTY_L3_IPV6_OPT_HDR_ACTION,        /* IPv6 with next header action. */
    CLX_SWC_PROPERTY_L3_IGR_MTU_FAIL_ACTION,        /* L3 ingress mtu error action. */
    CLX_SWC_PROPERTY_L3_EGR_MTU_FAIL_ACTION,        /* L3 egress mtu err action. */
    CLX_SWC_PROPERTY_L3_TTL0_ACTION,                /* L3 ttl0 action. */
    CLX_SWC_PROPERTY_L3_IGR_TTL1_ACTION,            /* L3 ingress ttl1 action, only for L3 unicast. */
    CLX_SWC_PROPERTY_L3_EGR_TTL1_ACTION,            /* L3 egress ttl1 action. */
    CLX_SWC_PROPERTY_L3T_TTL0_ACTION,               /* IP tunnel ingress ttl0 action. */
    CLX_SWC_PROPERTY_L3T_TTL1_ACTION,               /* IP tunnel ingress ttl1 action.. */
    CLX_SWC_PROPERTY_L3_ECMP_BLOCK_SIZE,            /* Configure the weighted SW mode ECMP block size. */
    CLX_SWC_PROPERTY_KEEP_DEI,                      /* Enable keep DEI */
    /* Configure the latency threshold to sample high latency packets for sflow. */
    /*  param0 is below values: */
    /*  0:disable, 512ns,    1024ns,    2048ns,    4096ns,   8192ns,*/
    /*  16384ns,   32768ns,   65536ns,   131072ns,  262144ns,       */
    /*  524288ns,  1048576ns, 2097152ns, 4194304ns, 8388608ns       */
    CLX_SWC_PROPERTY_SAMPLE_HIGH_LATENCY_THRESHOLD,
    CLX_SWC_PROPERTY_DTEL_IFA_MIR_ID,               /* DTEL IFA mirror ID. */
    CLX_SWC_PROPERTY_DTEL_IFA_STEER_MIR,            /* DTEL IFA steer mirror. */
    CLX_SWC_PROPERTY_DTEL_IOAM_COPY_TO_CPU,         /* DTEL IOAM copy to CPU property for ingress port. */
    CLX_SWC_PROPERTY_DTEL_IOAM_LOOPBACK_TO_CPU,     /* DTEL IOAM loopback to CPU property for egress port,
                                                     * should enable loopback bit in IOAM header.
                                                     */
    CLX_SWC_PROPERTY_DTEL_IOAM_EXCEPTION_TO_CPU,    /* DTEL IOAM exception to CPU property for egress port,
                                                     * e.g. when IOAM node length misalignment.
                                                     */
    /* Configure whether tm traffic type is determined by inner or outer header */
    CLX_SWC_PROPERTY_ECN_REMARK_USE_INNER_TCP,
    CLX_SWC_PROPERTY_L3T_LINK_LOCAL_ACTION,         /* Set action when ip-tnl has Link Local IP. */
    CLX_SWC_PROPERTY_DTEL_IFA_ENABLE,               /* Enable global IFA. */
    CLX_SWC_PROPERTY_DTEL_DPP_ENABLE,               /* Enable global DPP. */
    CLX_SWC_PROPERTY_LAST
}CLX_SWC_PROPERTY_T;

typedef enum
{
    /*nvo3 key*/
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_OUTER_VID,            /* Hash key : outer L2 header outer VLAN ID. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_INNER_VID,            /* Hash key : outer L2 header inner VLAN ID. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_ETHERTYPE,            /* Hash key : outer L2 header EtherType. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_DMAC,                 /* Hash key : outer L2 header destination MAC.*/
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_SMAC,                 /* Hash key : outer L2 header source MAC .*/
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_MAC_NORMALIZE,        /* Hash key : outer L2 header MAC normalize. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_FLOW_LABEL,         /* Hash key : outer IPv6 flow label. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_NEXT_HEADER,        /* Hash key : outer IPv6 next header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_DIP,                /* Hash key : outer IPv6 destination IP. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_SIP,                /* Hash key : outer IPv6 source IP. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_IP_NORMALIZE,       /* Hash key : outer IPv6 IP normalize. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_DPORT,          /* Hash key : outer IPv6 UDP destination port. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_SPORT,          /* Hash key : outer IPv6 UDP source port. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_PORT_NORMALIZE, /* Hash key : outer IPv6 UDP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_PROTOCOL,           /* Hash key : outer IPv4 protocol. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_DIP,                /* Hash key : outer IPv4 destination IP. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_SIP,                /* Hash key : outer IPv4 source IP. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_IP_NORMALIZE,       /* Hash key : outer IPv4 IP normalize. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_DPORT,          /* Hash key : outer IPv4 UDP destination port. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_SPORT,          /* Hash key : outer IPv4 UDP source port. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_PORT_NORMALIZE, /* Hash key : outer IPv4 UDP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_TRILL_FGL,
    CLX_SWC_HASH_KEY_TYPE_TRILL_VL,
    CLX_SWC_HASH_KEY_TYPE_TRILL_EGR_RN,
    CLX_SWC_HASH_KEY_TYPE_TRILL_IGR_RN,
    CLX_SWC_HASH_KEY_TYPE_TRILL_RN_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV6,               /* Hash key : Vni in the IPv6-GENEVE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV4,               /* Hash key : Vni in the IPv4-GENEVE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV4,               /* Hash key : Key field in the IPv4-GRE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV6,               /* Hash key : Key field in the IPv6-GRE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV4,                /* Hash key : Vni in the IPv4-VXLAN-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV6,                /* Hash key : Vni in the IPv6-VXLAN-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV4,               /* Hash key : Vsid in the IPv4-NVGRE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV6,               /* Hash key : Vsid in the IPv6-NVGRE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL0,             /* Hash key : 1st label in the MPLS-over-IP-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL1,             /* Hash key : 2nd label in the MPLS-over-IP-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL2,             /* Hash key : 3rd label in the MPLS-over-IP-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL3,             /* Hash key : 4th label in the MPLS-over-IP-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL4,             /* Hash key : 5th label in the MPLS-over-IP-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_NSH_SRV_IDX,                   /* Hash key : service index in the NSH header */
    CLX_SWC_HASH_KEY_TYPE_NSH_SRV_PATH,                  /* Hash key : service path in the NSH header */
    /*srv key*/
    CLX_SWC_HASH_KEY_TYPE_VNTAG_SVMID,
    CLX_SWC_HASH_KEY_TYPE_VNTAG_DVMID,
    CLX_SWC_HASH_KEY_TYPE_ETAG_SVMID,
    CLX_SWC_HASH_KEY_TYPE_ETAG_DVMID,
    CLX_SWC_HASH_KEY_TYPE_VEPA_SVID,
    CLX_SWC_HASH_KEY_TYPE_L2_OUTER_VID,                  /* Hash key : L2 header outer VLAN ID. */
    CLX_SWC_HASH_KEY_TYPE_L2_INNER_VID,                  /* Hash key : L2 header inner VLAN ID. */
    CLX_SWC_HASH_KEY_TYPE_L2_ETHERTYPE,                  /* Hash key : L2 header EtherType. */
    CLX_SWC_HASH_KEY_TYPE_L2_DMAC,                       /* Hash key : L2 header destination MAC. */
    CLX_SWC_HASH_KEY_TYPE_L2_SMAC,                       /* Hash key : L2 header source MAC. */
    CLX_SWC_HASH_KEY_TYPE_L2_MAC_NORMALIZE,              /* Hash key : L2 header MAC normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_FLOW_LABEL,               /* Hash key : IPv6 flow label. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_NEXT_HEADER,              /* Hash key : IPv6 next header. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_DIP,                      /* Hash key : IPv6 destination IP. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_SIP,                      /* Hash key : IPv6 source IP. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_IP_NORMALIZE,             /* Hash key : IPv6 IP normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_DPORT,                /* Hash key : IPv6 UDP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_SPORT,                /* Hash key : IPv6 UDP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_PORT_NORMALIZE,       /* Hash key : IPv6 UDP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_DPORT,                /* Hash key : IPv6 TCP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_SPORT,                /* Hash key : IPv6 TCP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_PORT_NORMALIZE,       /* Hash key : IPv6 TCP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_DPORT,               /* Hash key : IPv6 SCTP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_SPORT,               /* Hash key : IPv6 SCTP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_PORT_NORMALIZE,      /* Hash key : IPv6 SCTP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_PROTOCOL,                 /* Hash key : IPv4 UDP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_DIP,                      /* Hash key : IPv4 destination IP. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_SIP,                      /* Hash key : IPv4 source IP. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_IP_NORMALIZE,             /* Hash key : IPv4 IP normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_DPORT,                /* Hash key : IPv4 UDP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_SPORT,                /* Hash key : IPv4 UDP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_PORT_NORMALIZE,       /* Hash key : IPv4 UDP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_DPORT,                /* Hash key : IPv4 TCP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_SPORT,                /* Hash key : IPv4 TCP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_PORT_NORMALIZE,       /* Hash key : IPv4 TCP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_DPORT,               /* Hash key : IPv4 SCTP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_SPORT,               /* Hash key : IPv4 SCTP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_PORT_NORMALIZE,      /* Hash key : IPv4 SCTP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_VFID,                     /* Hash key : FCOE VFID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_SEQID,                    /* Hash key : FCOE SEQID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_DID,                      /* Hash key : FCOE DID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_SID,                      /* Hash key : FCOE SID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_ID_NORMALIZE,             /* Hash key : FCOE ID normalize. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_RXID,                     /* Hash key : FCOE RXID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_OXID,                     /* Hash key : FCOE OXID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_XID_NORMALIZE,            /* Hash key : FCOE XID normalize. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL0,                   /* Hash key : 1st label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL1,                   /* Hash key : 2nd label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL2,                   /* Hash key : 3rd label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL3,                   /* Hash key : 4th label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL4,                   /* Hash key : 5th label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_IGR_PORT,                      /* Hash key : Ingress port. */
    CLX_SWC_HASH_KEY_TYPE_EGR_PORT,                      /* Hash key : Egress port. */
    CLX_SWC_HASH_KEY_TYPE_L2,                            /* Hash key : L2, no use. */
    CLX_SWC_HASH_KEY_TYPE_L3,                            /* Hash key : L3, no use. */
    CLX_SWC_HASH_KEY_TYPE_VM_TUNNEL,                     /* Hash key : VM tunel. */
    CLX_SWC_HASH_KEY_TYPE_USE_INNER,                     /* Hash key : Use inner. */
    CLX_SWC_HASH_KEY_TYPE_COMPRESS_IP,                   /* Hash key : Compress IP. */
    CLX_SWC_HASH_KEY_TYPE_NORMALIZE,                     /* Hash key : Normalize. */
    CLX_SWC_HASH_KEY_TYPE_LAST
}CLX_SWC_HASH_KEY_TYPE_T;

typedef enum
{
    CLX_SWC_RSRC_L2_UC_ADDR = 0,                  /* L2 unicast entry resource. */
    CLX_SWC_RSRC_L3_ECMP_GROUP,                   /* L3 ECMP group resource. */
    CLX_SWC_RSRC_L3_ECMP_PATH,                    /* L3 ECMP path resource. */
    CLX_SWC_RSRC_L3_ECMP_HASH,                    /* L3 ECMP hash resource. */
    CLX_SWC_RSRC_L3_INTF,                         /* L3 interface resource. */
    CLX_SWC_RSRC_L3_ADJ,                          /* L3 adjacency resource. */
    CLX_SWC_RSRC_L3_ROUTER_MAC,                   /* L3 router MAC resource. */
    CLX_SWC_RSRC_L3_HOST,                         /* L3 host resource. */
    CLX_SWC_RSRC_L3_ROUTE,                        /* L3 route resource. */
    CLX_SWC_RSRC_L3_MCAST,                        /* L3 mutlcast resource. */
    CLX_SWC_RSRC_L3_RESOURCE,                     /* L3 resource. */
    CLX_SWC_RSRC_ACL_INGRESS_UCP,                 /* ACL ingress UCP resource. */
    CLX_SWC_RSRC_ACL_INGRESS_GROUP_ENTRY,         /* ACL ingress group entry resource. */
    CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE,     /* ACL ingress UDF key profile resource. */
    CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE_LOU, /* ACL UDF key profile LOU resource. */
    CLX_SWC_RSRC_ACL_EGRESS_UCP,                  /* ACL egress UCP resource. */
    CLX_SWC_RSRC_ACL_EGRESS_GROUP_ENTRY,          /* ACL egress group entry resource. */
    CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE,      /* ACL UDF key profile resource. */
    CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE_LOU,  /* ACL UDF key profile LOU resource. */
    CLX_SWC_RSRC_LAG_GROUP,                       /* LAG group resource. */
    CLX_SWC_RSRC_VLAN_BDID,                       /* L2 vlan resource. */
    CLX_SWC_RSRC_LAST
}CLX_SWC_RSRC_T;

typedef struct CLX_SWC_STEERING_ENTRY_S{
    UI32_T              hdr_size;           /* Maximum bytes(0~63); 0 means 64 bytes */
#define CLX_SWC_FLAGS_STEERING_HDR_EN       (0x1<<0)
#define CLX_SWC_FLAGS_STEERING_HDR_UDP_EN   (0x1<<1)
    UI32_T              flags;
    UI32_T              port;
    CLX_TM_HANDLER_T    handler;
    UI32_T              tc;
    UI32_T              color;
    UI32_T              hdr[16];
    UI32_T              vid_num;
    UI32_T              ipv4_tlen_bidx;      /* IPv4 total length byte index. */
    UI16_T              ipv4_checksum;
    UI32_T              ipv6_plen_bidx;      /* IPv6 payload length byte index. */
}CLX_SWC_STEERING_ENTRY_T;

#define CLX_SWC_HASH_KEY_NUM                    (CLX_SWC_HASH_KEY_TYPE_LAST)
#define CLX_SWC_HASH_KEY_WORD_WIDTH             (32)
#define CLX_SWC_HASH_KEY_BITMAP_SIZE            (((CLX_SWC_HASH_KEY_NUM-1)/CLX_SWC_HASH_KEY_WORD_WIDTH )+1)

typedef UI32_T CLX_SWC_HASH_KEY_BITMAP_T[CLX_SWC_HASH_KEY_BITMAP_SIZE];

#define CLX_SWC_SET_HASHKEYBIT(key_bitmap, hash_key)   \
    (((UI32_T *)key_bitmap)[hash_key/CLX_SWC_HASH_KEY_WORD_WIDTH] |= (0x1UL << (hash_key%CLX_SWC_HASH_KEY_WORD_WIDTH)))
#define CLX_SWC_CLEAR_HASHKEYBIT(key_bitmap, hash_key) \
    (((UI32_T *)key_bitmap)[hash_key/CLX_SWC_HASH_KEY_WORD_WIDTH] &= ~(0x1UL << (hash_key%CLX_SWC_HASH_KEY_WORD_WIDTH)))
#define CLX_SWC_CHK_HASHKEYBIT(key_bitmap, hash_key)   \
    (((UI32_T *)key_bitmap)[hash_key/CLX_SWC_HASH_KEY_WORD_WIDTH] &  (0x1UL << (hash_key%CLX_SWC_HASH_KEY_WORD_WIDTH)))

typedef enum
{
    CLX_SWC_HASH_TYPE_ECMP_L3,              /* For egress path is normal L3 flow. */
    CLX_SWC_HASH_TYPE_ECMP_NVO3,            /* For egress path is nvo3 flow. */
    CLX_SWC_HASH_TYPE_LAG,                  /* LAG loading balance. */
    CLX_SWC_HASH_TYPE_LAG_FABRIC,           /* LAG loading balance for fabric port selection. */
    CLX_SWC_HASH_TYPE_VXLAN_UDP_SRC_PORT,   /* UDP header UDP source port generation for VXLAN tunnel initiation. */
    CLX_SWC_HASH_TYPE_NVGRE_FLOW_ID,        /* NVGRE header flow ID generation for NVGRE tunnel initiation. */
    CLX_SWC_HASH_TYPE_L3T_IPV6_FLOW_LABEL,  /* IPv6 header flow label generation for IPv6 tunnel initiation. */
    CLX_SWC_HASH_TYPE_MPLS_ENTROPY_LABEL,   /* MPLS header entrypylable generation for tunnel initiation. */
    CLX_SWC_HASH_TYPE_MPLS_FLOW_LABEL,      /* MPLS header label generation for tunnel initiation. */
    CLX_SWC_HASH_TYPE_LAST
}CLX_SWC_HASH_TYPE_T;

typedef enum
{
    CLX_SWC_ERROR_SRC_ECC = 0, /* SWC error source is ECC. */
    CLX_SWC_ERROR_SRC_LAST,
} CLX_SWC_ERROR_SRC_T;

typedef enum
{
    CLX_SWC_ECC_NON_CORRECTABLE = 0, /* Error non-correctable. */
    CLX_SWC_ECC_CORRECTED,           /* Error corrected. */
} CLX_SWC_ECC_CORRECTION_T;

#define CLX_SWC_ECC_ERROR_INFO_INVALID_HUB         (0xFFFFFFFF) /* Invalid hub. */
#define CLX_SWC_ECC_ERROR_INFO_INVALID_MEMORY      (0xFFFFFFFF) /* Invalid memory0 */
#define CLX_SWC_ECC_ERROR_INFO_INVALID_TABLE_ID    (0xFFFFFFFF) /* Invalid table ID. */

typedef struct
{
    UI32_T                      hub;                            /* Invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_HUB. */
    UI32_T                      memory;                         /* Invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_MEMORY. */
    UI32_T                      single_error_addr;              /* Single error address. */
    UI32_T                      double_error_addr;              /* Double error address. */

    UI32_T                      inst;                           /* Table inst. */
    UI32_T                      sub_inst;                       /* Table sub-inst. */
    UI32_T                      table_id;                       /* Invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_TABLE_ID. */
    UI32_T                      single_error_table_entry_start; /* Single error table entry start. */
    UI32_T                      single_error_table_entry_end;   /* Single error table entry end. */
    UI32_T                      double_error_table_entry_start; /* Double error table entry start. */
    UI32_T                      double_error_table_entry_end;   /* Double error table entry end. */

    UI32_T                      single_error_cnt;               /* Single error count. */
    UI32_T                      double_error_cnt;               /* Double error count. */

    CLX_SWC_ECC_CORRECTION_T    single_error_correction;        /* Single error correction state. */
    CLX_SWC_ECC_CORRECTION_T    double_error_correction;        /* Double error correction state. */
} CLX_SWC_ERROR_INFO_ECC_T;

typedef struct
{
    union
    {
        CLX_SWC_ERROR_INFO_ECC_T    ecc_info; /* ECC error info. */
    };
} CLX_SWC_ERROR_INFO_T;

typedef void
(*CLX_SWC_ERROR_FUNC_T)(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_INFO_T    *ptr_error_info,
    void                          *ptr_cookie);

typedef struct CLX_SWC_DEVICE_INFO_S
{
    UI32_T vendor_id;
    UI32_T device_id;
    UI32_T revision_id;
}CLX_SWC_DEVICE_INFO_T;

typedef struct CLX_SWC_PORT_CONFIG_S
{
    CLX_PORT_BITMAP_T       bitmap_all;        /* Include active, inactive eth, mxlink, cpu, and cpi ports. */
    CLX_PORT_BITMAP_T       bitmap_active;     /* Include active eth, mxlink, cpu, and cpi ports. */
    CLX_PORT_BITMAP_T       bitmap_mxlink;     /* Active mxlink ports. */
    CLX_PORT_BITMAP_T       bitmap_breakout;   /* Active breakout ports. */
    CLX_PORT_BITMAP_T       bitmap_cpu;        /* Active cpu ports. */
    CLX_PORT_BITMAP_T       bitmap_cpi;        /* Active cpi ports. */
    CLX_PORT_BITMAP_T       bitmap_rcp;        /* Active recirculation ports. */
    CLX_PORT_BITMAP_T       bitmap_1g;         /* Active 1g ports. */
    CLX_PORT_BITMAP_T       bitmap_10g;        /* Active 10g ports. */
    CLX_PORT_BITMAP_T       bitmap_25g;        /* Active 25g ports. */
    CLX_PORT_BITMAP_T       bitmap_40g;        /* Active 40g ports. */
    CLX_PORT_BITMAP_T       bitmap_50g;        /* Active 50g ports. */
    CLX_PORT_BITMAP_T       bitmap_100g;       /* Active 100g ports. */
    CLX_PORT_BITMAP_T       bitmap_200g;       /* Active 200g ports. */
    CLX_PORT_BITMAP_T       bitmap_400g;       /* Active 400g ports. */
} CLX_SWC_PORT_CONFIG_T;

typedef enum
{
    CLX_SWC_CSO_MODE_SLAVE = 0, /* CSO mode slave. */
    CLX_SWC_CSO_MODE_MASTER,    /* CSO mode master. */
    CLX_SWC_CSO_MODE_LAST
} CLX_SWC_CSO_MODE_T;

typedef struct CLX_SWC_CPI_ENCAP_HDR_S{
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_EN                  (0x1<<0)
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN           (0x1<<1) /* If set, use udp_source_port. */
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_CPU_QUEUE_EN     (0x1<<2) /* If set, CPI queue will be encoded in UDP source port.
                                                                  * invalid when flag CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN
                                                                  * is set. */
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_PORT_EN          (0x1<<3) /* If set, ingress port or egress port will be encoded in
                                                                  * UDP source port. Invalid when flag
                                                                  * CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN is set. */
    UI32_T              flags;
    UI32_T              encap_size;                              /* 0: no encap. */
    UI8_T               hdr[64];
    UI32_T              ipv4_tlen_bidx;                          /* IPv4 total length byte index. */
    UI16_T              ipv4_checksum;                           /* IPv4 checksum with total length of 0. */
    UI16_T              udp_source_port;                         /* UDP header source port value. */
}CLX_SWC_CPI_ENCAP_HDR_T;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* FUNCTION NAME:   clx_swc_setHashKey
 * PURPOSE:
 *      Set switch control hash keys.
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash type
 *      key_bitmap          -- Hash key bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setHashKey(
    const UI32_T                    unit,
    const CLX_SWC_HASH_TYPE_T       hash_type,
    const CLX_SWC_HASH_KEY_BITMAP_T key_bitmap);

/* FUNCTION NAME:   clx_swc_getHashKey
 * PURPOSE:
 *      Get switch control hash keys.
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash type
 * OUTPUT:
 *      *ptr_key_bitmap     -- Hash key bitmap
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getHashKey(
    const UI32_T                    unit,
    const CLX_SWC_HASH_TYPE_T       hash_type,
    CLX_SWC_HASH_KEY_BITMAP_T       *ptr_key_bitmap);

/* FUNCTION NAME:   clx_swc_setProperty
 * PURPOSE:
 *      Set switch control property.
 * INPUT:
 *      unit                -- Device unit number
 *      property            -- Property type
 *      param0              -- First parameter
 *      param1              -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setProperty(
    const UI32_T                    unit,
    const CLX_SWC_PROPERTY_T        property,
    const UI32_T                    param0,
    const UI32_T                    param1);

/* FUNCTION NAME:   clx_swc_getProperty
 * PURPOSE:
 *      Get switch control property.
 * INPUT:
 *      unit                -- Device unit number
 *      property            -- Property type
 * OUTPUT:
 *      *ptr_param0         -- Ptr of first parameter
 *      *ptr_param1         -- Ptr of second parameter
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */

CLX_ERROR_NO_T
clx_swc_getProperty(
    const UI32_T                    unit,
    const CLX_SWC_PROPERTY_T        property,
    UI32_T                          *ptr_param0,
    UI32_T                          *ptr_param1);

/* FUNCTION NAME:   clx_swc_setTsValue
 * PURPOSE:
 *      Set timestamp value of system.
 * INPUT:
 *      unit                --  Chip id
 *      sec_hi              --  Bit[47:32] seconds for timestamp
 *      sec_low             --  Bit[31:0]  seconds for timestamp
 *      nsec                --  Bit[29:0]  nano seconds for timestamp
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_swc_setTsValue(
    const UI32_T                unit,
    UI16_T                      sec_hi,
    UI32_T                      sec_low,
    UI32_T                      nsec);

/* FUNCTION NAME:   clx_swc_getTsValue
 * PURPOSE:
 *      Get timestamp value of system.
 * INPUT:
 *      unit                --  Chip id
 * OUTPUT:
 *      ptr_sec_hi          --  Bit[47:32] seconds for timestamp
 *      ptr_sec_low         --  Bit[31:0]  seconds for timestamp
 *      ptr_nsec            --  Bit[29:0]  nano seconds for timestamp
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_swc_getTsValue(
    const UI32_T                unit,
    UI16_T                      *ptr_sec_hi,
    UI32_T                      *ptr_sec_low,
    UI32_T                      *ptr_nsec);

/* FUNCTION NAME:   clx_swc_setTsOffset
 * PURPOSE:
 *      Set timestamp offset.
 * INPUT:
 *      unit                --  Chip id
 *      nsec                --  Signed nano seconds for timestamp offset
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_swc_setTsOffset(
    const UI32_T                unit,
    const I32_T                 nsec);

/* FUNCTION NAME:   clx_swc_setSteering
 * PURPOSE:
 *      Set the configuration of egress view of steering.
 * INPUT:
 *      unit                -- Device unit number
 *      *ptr_str_entry      -- Structure of egress steering
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setSteering(
    const UI32_T                    unit,
    const CLX_SWC_STEERING_ENTRY_T  *ptr_str_entry);

/* FUNCTION NAME:   clx_swc_getSteering
 * PURPOSE:
 *      Get the configuration of egress view of steering.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      *ptr_str_entry      -- Setting of egress steering
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getSteering(
    const UI32_T                    unit,
    CLX_SWC_STEERING_ENTRY_T        *ptr_str_entry);

/* FUNCTION NAME:   clx_swc_setHashConstant
 * PURPOSE:
 *      Set hash engine polynomial coefficients
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      count               -- Size (number of elements) of array pointed by ptr_hash_const
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHER         -- Config fail
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
clx_swc_setHashConstant(
    const UI32_T              unit,
    const CLX_SWC_HASH_TYPE_T hash_type,
    const UI32_T              count,
    const UI32_T              *ptr_hash_const);

/* FUNCTION NAME:   clx_swc_getHashConstant
 * PURPOSE:
 *      Get hash engine polynomial coefficients
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      count               -- Size (number of elements) of array pointed by ptr_hash_const
 *
 * OUTPUT:
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
clx_swc_getHashConstant(
    const UI32_T              unit,
    const CLX_SWC_HASH_TYPE_T hash_type,
    const UI32_T              count,
    UI32_T                    *ptr_hash_const);

/* FUNCTION NAME:   clx_swc_setHashConstantByKey
 * PURPOSE:
 *      Set hash engine polynomial coefficients by a specific key field
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      key                 -- Hash key of interest
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHER         -- Config fail
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
clx_swc_setHashConstantByKey(
    const UI32_T                  unit,
    const CLX_SWC_HASH_TYPE_T     hash_type,
    const CLX_SWC_HASH_KEY_TYPE_T key,
    const UI32_T                  *ptr_hash_const);

/* FUNCTION NAME:   clx_swc_getHashConstantByKey
 * PURPOSE:
 *      Get hash engine polynomial coefficients by a specific key field
 * INPUT:
 *      unit                -- Device unit number
 *      hash_type           -- Hash engine to be config
 *      key                 -- Hash key of interest
 *
 * OUTPUT:
 *      ptr_hash_const      -- Pointer to array of constants
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      It's caller's responsibility to pass an array of correct size.
 *
 */
CLX_ERROR_NO_T
clx_swc_getHashConstantByKey(
    const UI32_T                  unit,
    const CLX_SWC_HASH_TYPE_T     hash_type,
    const CLX_SWC_HASH_KEY_TYPE_T key,
    UI32_T                        *ptr_hash_const);

/* FUNCTION NAME:   clx_swc_registerErrorCallback
 * PURPOSE:
 *      Register error callback function.
 * INPUT:
 *      unit                -- Device unit number
 *      error               -- error source type
 *      callback            -- The callback function of type CLX_SWC_ERROR_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_registerErrorCallback(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_FUNC_T    callback,
    void                          *ptr_cookie);

/* FUNCTION NAME:   clx_swc_deregisterErrorCallback
 * PURPOSE:
 *      Deregister error callback function.
 * INPUT:
 *      unit                -- Device unit number
 *      error               -- error source type
 *      callback            -- The callback function of type CLX_SWC_ERROR_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_deregisterErrorCallback(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_FUNC_T    callback,
    void                          *ptr_cookie);

/* FUNCTION NAME:   clx_swc_getDeviceInfo
 * PURPOSE:
 *      Get device information.
 * INPUT:
 *      unit                -- Device unit number
 *
 * OUTPUT:
 *      ptr_device_info     -- The device information
 *
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_swc_getDeviceInfo(
    const UI32_T                unit,
    CLX_SWC_DEVICE_INFO_T       *ptr_device_info);

/* FUNCTION NAME:   clx_swc_getPortConfig
 * PURPOSE:
 *      Get port bitmap of current config.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_port_config     -- Port bitmaps of current config
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_swc_getPortConfig(
    const UI32_T        unit,
    CLX_SWC_PORT_CONFIG_T   *ptr_port_config);

/* FUNCTION NAME:   clx_swc_getCapacity
 * PURPOSE:
 *      Get resource capacity
 * INPUT:
 *      unit            -- Device unit number
 *      type            -- Resource type
 *      param           -- Parameter if necessary
 * OUTPUT:
 *      ptr_size        -- Size of capacity
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getCapacity(
    const UI32_T unit,
    const CLX_SWC_RSRC_T type,
    const UI32_T param,
    UI32_T *ptr_size);

/* FUNCTION NAME:   clx_swc_getUsage
 * PURPOSE:
 *     Get resource usage.
 * INPUT:
 *      unit            -- Device unit number
 *      type            -- Resource type
 *      param           -- Parameter if necessary
 * OUTPUT:
 *      ptr_cnt         -- Count of usage
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getUsage(
    const UI32_T unit,
    const CLX_SWC_RSRC_T type,
    const UI32_T param,
    UI32_T *ptr_cnt);

/* FUNCTION NAME:   clx_swc_setCsoMode
 * PURPOSE:
 *      Set clock servo mode.
 * INPUT:
 *      unit                -- Device unit number
 *      mode                -- Clock servo mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setCsoMode(
    const UI32_T                unit,
    const CLX_SWC_CSO_MODE_T    mode);

/* FUNCTION NAME:   clx_swc_getCsoMode
 * PURPOSE:
 *      Get clock servo mode.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_mode            -- Clock servo mode
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getCsoMode(
    const UI32_T        unit,
    CLX_SWC_CSO_MODE_T  *ptr_mode);

/* FUNCTION NAME:   clx_swc_getChipTemperature
 * PURPOSE:
 *      Get chip temperature.
 * INPUT:
 *      unit                -- Device unit number.
 * OUTPUT:
 *      ptr_temperature     -- Chip temperature
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getChipTemperature(
    const UI32_T   unit,
    I32_T          *ptr_temperature);

/* FUNCTION NAME:   clx_swc_setCpiEncap
 * PURPOSE:
 *      Set CPI port enacp.
 * INPUT:
 *      unit                -- Device unit number.
 *      port                -- CPI port.
 *      ptr_encap_hdr       -- Structure of encap.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_NOT_SUPPORT   -- Not support.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_setCpiEncap(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SWC_CPI_ENCAP_HDR_T   *ptr_encap_hdr);

/* FUNCTION NAME:   clx_swc_getCpiEncap
 * PURPOSE:
 *      Get CPI port enacp.
 * INPUT:
 *      unit                -- Device unit number.
 *      port                -- CPI port.
 * OUTPUT:
 *      ptr_encap_hdr       -- Structure of encap.
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_NOT_SUPPORT   -- Not support.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_swc_getCpiEncap(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SWC_CPI_ENCAP_HDR_T         *ptr_encap_hdr);

#endif
