/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_mir.h
 * PURPOSE:
 *    It provides HAL driver API functions for mirror module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MIR_H
#define HAL_MIR_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_mir.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
  */

#define HAL_MIR_IS_SESSION_BMP_VALID(unit, session_bmp)             \
            (CLX_E_OK == hal_mir_isSessionBmpValid(unit, session_bmp))

#define HAL_MIR_SESSION_BMP_TO_ID(session_bmp, session_id)          \
            hal_mir_transSessionBmp2Id(session_bmp, &(session_id))

#define HAL_MIR_SESSION_ID_TO_BMP(session_id, session_bmp)          \
            ((session_bmp) = 1U << (session_id))

/* DATA TYPE DECLARATIONS
  */

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   hal_mir_init
 * PURPOSE:
 *     Init Mirror module.
 * INPUT:
 *      unit            -- Device unit index.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Operate success.
 *      CLX_E_OTHER     --  Init fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mir_init(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_mir_deinit
 * PURPOSE:
 *     De-init Mirror module.
 * INPUT:
 *      unit            -- Device unit index.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK       --  Operate success.
 *      CLX_E_OTHER    --  De-init fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mir_deinit(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_mir_addSession
 * PURPOSE:
 *      This API is used to create a mirror session.
 *
 * INPUT:
 *      unit        --   Device unit ID.
 *      ptr_session --   The session information.
 *
 * OUTPUT:
 *      None.
 *
 * RETURN:
 *      CLX_E_OK             --  Operation is success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_ENTRY_EXISTS   --  The session has been created.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mir_addSession(
    const UI32_T            unit,
    const CLX_MIR_SESSION_T *ptr_session);

/* FUNCTION NAME:   hal_mir_delSession
 * PURPOSE:
 *      This API is used to delete a mirror session.
 * INPUT:
 *      unit          --  Device unit ID.
 *      session_id    -- Mirror session ID, the range is 0-7.
 *      direction     -- Mirror session direction.
 *
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK               --  Operation is successful.
 *      CLX_E_BAD_PARAMETER    --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND  --  The specified entry has not been created.
 *
 * NOTES:
 *      Before deleting a mirror session, mirror sources bound to the session
 *      should be first removed.
 */
CLX_ERROR_NO_T
hal_mir_delSession(
    const UI32_T                unit,
    const UI8_T                 session_id,
    const CLX_MIR_DIRECTION_T   direction);

/* FUNCTION NAME:   hal_mir_getSession
 * PURPOSE:
 *      This API is used to get mirror session information.
 * INPUT:
 *      unit         --    Device unit id.
 *
 * OUTPUT:
 *      ptr_session     --  The informations of this session to be obtained.
 *
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- The specified entry has not been created.
 *
 * NOTES:
 *      User must specify the session_id, direction, mirror_mode in (ptr_info).
 */
CLX_ERROR_NO_T
hal_mir_getSession(
    const UI32_T        unit,
    CLX_MIR_SESSION_T   *ptr_session);

/* FUNCTION NAME:   hal_mir_setMirSrcPort
 * PURPOSE:
 *      This API is used to add a physical port as mirror session source or remove a
 *      physical port from mirror session source.
 *      User should specify the physical port ID, mirror session bitmap.
 *
 * INPUT:
 *      unit                  --   Device unit number
 *      port                  --   Port ID
 *      dir                   --   Ingress or egress mirror session
 *      mir_session_bitmap    --   Mirror session bitmap
 *
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK               --  Operation is success.
 *      CLX_E_BAD_PARAMETER    --   Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND  --  The specified entry has not been created
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mir_setMirSrcPort(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_DIR_T     dir,
    const UI32_T        mir_session_bitmap);

/* FUNCTION NAME:   hal_mir_getMirSrcPort
 * PURPOSE:
 *     This API is used to get the mirror session bitmap bound to a port.
 *
 * INPUT:
 *      unit                     --   Device unit ID.
 *      port                     --   The physical port ID.
 *      dir                      --   Ingress or egress mirror session
 * OUTPUT:
 *
 *      ptr_mir_session_bitmap   --   The mirror session is bound to the specified
 *                                    physical port on specified direction.
 *                                    If bit 0 is set, it means that the mirror
 *                                    session 0 is bound to the port.
 * RETURN:
 *      CLX_E_OK                 --   Operation is successful.
 *      CLX_E_BAD_PARAMETER      --   Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND    --   The specified entry has not been created
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mir_getMirSrcPort(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_DIR_T     dir,
    UI32_T              *ptr_mir_session_bitmap);

/* FUNCTION NAME:   hal_mir_addErspanTerm
 * PURPOSE:
 *      This API is used to add an erpsan term.
 *
 * INPUT:
 *      unit                      --  Device unit ID.
 *      ptr_erspan_term_info      --  The erspan termination information.
 *
 * OUTPUT:
 *      None.
 *
 * RETURN:
 *      CLX_E_OK                  -- Operation is successful.
 *      CLX_E_BAD_PARAMETER       -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND     -- The specified entry has not been created.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mir_addErspanTerm(
    const UI32_T                unit,
    const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term);

/* FUNCTION NAME:   hal_mir_delErspanTerm
 * PURPOSE:
 *      This API is used to delete an erpsan term.
 *
 * INPUT:
 *      unit                       --  Device unit ID.
 *      ptr_erspan_term_info       --  The erspan termination information.
 *
 * OUTPUT:
 *      None.
 *
 * RETURN:
 *      CLX_E_OK                  -- Operation is successful.
 *      CLX_E_BAD_PARAMETER       -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND     -- The specified entry has not been created.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mir_delErspanTerm(
    const UI32_T                unit,
    const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term);

/* FUNCTION NAME:   hal_mir_getErspanTerm
 * PURPOSE:
 *      This API is used to get an erspan term information.
 *
 * INPUT:
 *      unit                                       --  Device unit ID.
 *      ptr_erspan_term_info       --  The erspan termination information.
 *
 * OUTPUT:
 *      None.
 *
 * RETURN:
 *      CLX_E_OK                  -- Operation is successful.
 *      CLX_E_BAD_PARAMETER       -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND     -- The specified entry has not been created.
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mir_getErspanTerm(
    const UI32_T            unit,
    CLX_MIR_ERSPAN_TERM_T   *ptr_erspan_term);

/* FUNCTION NAME:   hal_mir_setErspanTermMissAction
 * PURPOSE:
 *      This API is used to configure ERSPAN term miss action.
 *
 * INPUT:
 *      unit        --  Device unit ID
 *      miss_action --  ERSPAN term miss action
 *
 * OUTPUT:
 *      None.
 *
 * RETURN:
 *      CLX_E_OK            -- Operation is successful
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mir_setErspanTermMissAction(
    const UI32_T                unit,
    const UI32_T                miss_action);

/* FUNCTION NAME:   hal_mir_getErspanTermMissAction
 * PURPOSE:
 *      This API is used to get ERSPAN term miss action.
 *
 * INPUT:
 *      unit            --  Device unit id
 *
 * OUTPUT:
 *      ptr_miss_action --  ERSPAN term miss action
 *
 * RETURN:
 *      CLX_E_OK            -- Operation is successful
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mir_getErspanTermMissAction(
    const UI32_T                unit,
    UI32_T                      *ptr_miss_action);

/* FUNCTION NAME: hal_mir_setMeterLayer
 * PURPOSE:
 *      Set mirror meter layer mode (global).
 * INPUT:
 *      unit        --  Device unit number.
 *      layer_mode  --  The mirror meter layer mode.
 *                      1 - layer 1; 0 - layer 2
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_mir_setMeterLayer(
    const UI32_T        unit,
    const UI32_T        layer_mode);

/* FUNCTION NAME: hal_mir_getMeterLayer
 * PURPOSE:
 *      Get mirror meter layer mode (global).
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      ptr_layer_mode  --  The mirror meter layer mode.
 *                          1 - layer 1; 0 - layer 2
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_mir_getMeterLayer(
    const UI32_T        unit,
    UI32_T              *ptr_layer_mode);

CLX_ERROR_NO_T
hal_mir_isSessionBmpValid(
    const UI32_T            unit,
    const UI32_T            session_bmp);

CLX_ERROR_NO_T
hal_mir_transSessionBmp2Id(
    const UI32_T            session_bmp,
    UI32_T                  *ptr_session_id);

CLX_ERROR_NO_T
hal_mir_isSessionIdValid(
    const UI32_T            unit,
    const UI32_T            session_id);

void
hal_mir_updateLagPortEvent(
    const UI32_T unit,
    const UI32_T event,
    const CLX_PORT_T lag_port);
#endif /* end of HAL_MIR_H */

