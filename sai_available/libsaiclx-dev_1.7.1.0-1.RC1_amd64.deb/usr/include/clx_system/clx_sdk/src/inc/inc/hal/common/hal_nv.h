/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_nv.h
 * PURPOSE:
 *      It provides the CL8360 NV module HAL function prototypes.
 * NOTES:
 *
 */

#ifndef HAL_NV_H
#define HAL_NV_H


/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */


/* DATA TYPE DECLARATIONS
 */



/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_nv_init
 * PURPOSE:
 *      Initialize the NV module.
 * INPUT:
 *      unit  --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_init(
    const UI32_T unit);

/* FUNCTION NAME: hal_nv_deinit
 * PURPOSE:
 *      Deinitialize the NV module.
 * INPUT:
 *      unit  --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_deinit(
    const UI32_T unit);

/* FUNCTION NAME:   hal_nv_vxlan_setRouterAlertCheck
 * PURPOSE:
 *      Enable/Disable the VXLAN Router Alert feature.
 * INPUT:
 *      unit               --    Device unit number
 *      enable             --    TRUE or FALSE.
 * OUTPUT:
 *
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_vxlan_setRouterAlertCheck(
    const UI32_T                unit,
    const UI32_T                enable);

/* FUNCTION NAME:   hal_nv_vxlan_getRouterAlertCheck
 * PURPOSE:
 *      Get the VXLAN Router Alert Enable/Disable status.
 * INPUT:
 *      unit          --    Device unit number
 * OUTPUT:
 *      ptr_enable    --    TRUE or FALSE.
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_vxlan_getRouterAlertCheck(
    const UI32_T unit,
    UI32_T       *ptr_enable);

/* FUNCTION NAME:     hal_nv_nvgre_setRouterAlertCheck
 * PURPOSE:
 *      Enable/Disable the NVGRE Router Alert feature.
 * INPUT:
 *      unit        --    Device unit number
 *      enable      --    TRUE or FALSE.
 * OUTPUT:
 *
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_nvgre_setRouterAlertCheck(
    const UI32_T    unit,
    const UI32_T    enable);

/* FUNCTION NAME:     hal_nv_nvgre_getRouterAlertCheck
 * PURPOSE:
 *      Get the NVGRE Router Alert Enable/Disable status.
 * INPUT:
 *      unit          --    Device unit number
 * OUTPUT:
 *      ptr_enable    --    TRUE or FALSE.
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_nvgre_getRouterAlertCheck(
    const UI32_T    unit,
    UI32_T          *ptr_enable);

/* FUNCTION NAME:   hal_nv_addSegService
 * PURPOSE:
 *      add or set a tunnel to a specified segment and related service.
 * INPUT:
 *      unit              --   Device unit number
 *      seg               --   Segment value(24 bits)
 *      ptr_key           --   Tunnel key
 *      ptr_seg_service   --   (seg, tunnel) service
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      The ptr_seg_srv->vid_bdid value modification is not allowed.
 */
CLX_ERROR_NO_T
hal_nv_addSegService(
    const UI32_T                unit,
    const UI32_T                seg,
    const CLX_TUNNEL_KEY_T      *ptr_key,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   hal_nv_delSegService
 * PURPOSE:
 *      delete a tunnel from a specified segment
 * INPUT:
 *      unit        --   Device unit number
 *      seg         --   Segment value (24 bits)
 *      ptr_key     --   Tunnel key
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_delSegService(
    const UI32_T            unit,
    const UI32_T            seg,
    const CLX_TUNNEL_KEY_T  *ptr_key);

/* FUNCTION NAME:   hal_nv_getSegService
 * PURPOSE:
 *      get the service of a (segment, tunnel) pair
 * INPUT:
 *      unit              --   Device unit number
 *      seg               --   Segment value(24 bits)
 *      ptr_key           --   Tunnel key
 * OUTPUT:
 *      ptr_seg_srv       --   (seg, tunnel) service
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_getSegService(
    const UI32_T                unit,
    const UI32_T                seg,
    const CLX_TUNNEL_KEY_T      *ptr_key,
          CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   hal_nv_getSegByTnlFdid
 * PURPOSE:
 *      get seg by tunnel and fdid
 * INPUT:
 *      unit              --   Device unit number
 *      fdid              --   Forwarding domain
 *      lcl_intf_grp      --   Local interface group
 * OUTPUT:
 *      ptr_seg           --   Segment value (24 bits)
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_nv_getSegByTnlFdid(
    const UI32_T                unit,
    const UI32_T                fdid,
    const UI32_T                lcl_intf_grp,
    UI32_T                      *ptr_seg);

/* FUNCTION NAME:   hal_nv_getSegByPortBdid
 * PURPOSE:
 *        get seg by clx_port and fdid
 * INPUT:
 *        unit              --   Device unit number
 *        port              --   Port interface
 *        bdid              --   Bridge domain
 * OUTPUT:
 *        ptr_seg0          --   Segment0 of local
 *        ptr_seg1          --   Segment1 of remote
 * RETURN:
 *        CLX_ERROR_NO_T
 * NOTES:
 *        ptr_seg0 usually equals to ptr_seg1, unless there are
 *        different segments between local and remote 
 * 
 */
CLX_ERROR_NO_T
hal_nv_getSegByPortBdid(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        bdid,
    UI32_T              *ptr_seg0,
    UI32_T              *ptr_seg1);

/* FUNCTION NAME:   hal_nv_getBdidByPortSeg
 * PURPOSE:
 *        get bdid by clx_port and seg
 * INPUT:
 *        unit              --   Device unit number
 *        port              --   Port interface
 *        seg               --   Segment
 *        dir               --   Direction
 * OUTPUT:
 *        bdid              --   Bridge Domain
 * RETURN:
 *        CLX_ERROR_NO_T
 * NOTES:
 * 
 */
CLX_ERROR_NO_T
hal_nv_getBdidByPortSeg(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        seg,
    const CLX_DIR_T     dir,
    UI32_T              *bdid);

/* FUNCTION NAME:   hal_nv_updateClxPortDb
 * PURPOSE:
 *      update swdb for seg <-> fdid for service composed of clx_port.
 * INPUT:
 *      unit    -- device unit number
 *      is_add  -- 1 for add, 0 for del
 *      port    -- clx_port
 *      seg0    -- local segment
 *      seg1    -- remote segment (usually equal to seg0)
 *      bdid    -- bridge domain ID (don't care for del)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_nv_updateClxPortDb(
    const UI32_T        unit,
    const UI32_T        add,
    const CLX_PORT_T    port,
    const UI32_T        seg0,
    const UI32_T        seg1,
    const UI32_T        bdid);

/* FUNCTION NAME:   hal_nv_setVxlanUdpPort
 * PURPOSE:
 *      set vxlan udp_port
 * INPUT:
 *      unit  -- device unit number
 *      dport -- vxlan udp_port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_nv_setVxlanUdpPort(
    const UI32_T unit,
    const UI32_T dport);

/* FUNCTION NAME:   hal_nv_getVxlanUdpPort
 * PURPOSE:
 *      get vxlan udp dport
 * INPUT:
 *      unit      -- device unit number
 * OUTPUT:
 *      ptr_dport -- vxlan udp dport
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_nv_getVxlanUdpPort(
    const UI32_T unit,
    UI32_T       *ptr_dport);

#endif /* #ifndef HAL_NV_H */