/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_pkj.h
 * PURPOSE:
 *     It provides packet journal APIs.
 *
 * NOTES:
 *
 */
#ifndef HAL_PKJ_H
#define HAL_PKJ_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <cdb/cdb.h>
#include <hal/common/hal_pkj_buf.h>
#include <hal/common/hal_pkj_tbl.h>
#include <hal/common/hal_pkj_decoder.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PKJ_MAX_TYPE_LENGTH         (32)
#define HAL_PKJ_MAX_ENTRY_SIZE          (MAX_ENTRY_SIZE)
#define HAL_PKJ_MAX_ENTRY_WORDS         (HAL_MAX_ENTRY_WORD_SIZE)

#define HAL_PKJ_PP_FLAGS_IDS            (1U << 0)
#define HAL_PKJ_PP_FLAGS_ILE            (1U << 1)
#define HAL_PKJ_PP_FLAGS_ICIA           (1U << 2)
#define HAL_PKJ_PP_FLAGS_IEV            (1U << 3)
#define HAL_PKJ_PP_FLAGS_ITM            (1U << 4)
#define HAL_PKJ_PP_FLAGS_ETM            (1U << 5)
#define HAL_PKJ_PP_FLAGS_EMI            (1U << 6)
#define HAL_PKJ_PP_FLAGS_ECIA           (1U << 7)
#define HAL_PKJ_PP_FLAGS_EME            (1U << 8)
#define HAL_PKJ_PP_FLAGS_ALL            (0x1FF)

#define HAL_PKJ_SHOW_FLAGS_FILTER0      (1U << 0)
#define HAL_PKJ_SHOW_FLAGS_MORE         (1U << 1)
#define HAL_PKJ_SHOW_FLAGS_RAW_BUF      (1U << 2)

#define HAL_PKJ_DECODE_FLAGS_KEEP_BUF   (1U << 0)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_PKJ_INFO(__unit__)  \
        (_ext_chip_control_block[(__unit__)].ptr_driver_info->ptr_pkj_info)

#define HAL_PKJ_PP_INFO(__unit__, __pipe__) \
        &(HAL_PKJ_INFO((__unit__))->ptr_pp_info[(__pipe__)])

#define HAL_PKJ_TBL_INFO(__unit__, __tbl_id__) \
        HAL_PKJ_INFO((__unit__))->pptr_tbl_info[(__tbl_id__)]

#define HAL_PKJ_BUF_INFO(__unit__, __buf_id__) \
        HAL_PKJ_INFO((__unit__))->pptr_buf_info[(__buf_id__)]

#define HAL_PKJ_IS_NON_ZERO_CLX_MAC(__clx_mac__)                                    \
    (((__clx_mac__)[0]) || ((__clx_mac__)[1]) || ((__clx_mac__)[2]) ||              \
     ((__clx_mac__)[3]) || ((__clx_mac__)[4]) || ((__clx_mac__)[5]))

#define HAL_PKJ_IS_NON_ZERO_CLX_IPV6(__clx_ipv6__)                                  \
    (((__clx_ipv6__)[0])  || ((__clx_ipv6__)[1])  ||                                \
     ((__clx_ipv6__)[2])  || ((__clx_ipv6__)[3])  ||                                \
     ((__clx_ipv6__)[4])  || ((__clx_ipv6__)[5])  ||                                \
     ((__clx_ipv6__)[6])  || ((__clx_ipv6__)[7])  ||                                \
     ((__clx_ipv6__)[8])  || ((__clx_ipv6__)[9])  ||                                \
     ((__clx_ipv6__)[10]) || ((__clx_ipv6__)[11]) ||                                \
     ((__clx_ipv6__)[12]) || ((__clx_ipv6__)[13]) ||                                \
     ((__clx_ipv6__)[14]) || ((__clx_ipv6__)[15]))

#define HAL_PKJ_PLANE_FOREACH(__unit__, __plane__)                                  \
        for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM; (__plane__)++)           \
            if (CMLIB_BITMAP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

#define HAL_PKJ_FIELD_LENGTH(__unit__, __tbl_id__, __field_id__) \
        (CDB_TABLE((__unit__), (__tbl_id__))->ptr_table_entry[(__field_id__)].length)

#define HAL_PKJ_WORD_SIZE(__bit_num__) \
        ((((__bit_num__) - 1) / 32) + 1)

#define HAL_PKJ_LIST_NUM(__list__)  \
        sizeof((__list__)) / sizeof((__list__)[0])

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_PKJ_ACTION_EN_DISABLE = 0,
    HAL_PKJ_ACTION_EN_ENABLE,
    HAL_PKJ_ACTION_EN_RESET,
    HAL_PKJ_ACTION_EN_LAST,
} HAL_PKJ_ACTION_EN_T;

typedef enum {
    HAL_PKJ_PROPERTY_PSR_TRIGGER_EN = 0,
    HAL_PKJ_PROPERTY_PSR_TRIGGER_HIT_OVERWRITE,
    HAL_PKJ_PROPERTY_PSR_TRIGGER_HIT_BOTH_LAYER,
    HAL_PKJ_PROPERTY_PSR_TRIGGER_IGR_STATUS,
    HAL_PKJ_PROPERTY_PSR_TRIGGER_EGR_STATUS,
    HAL_PKJ_PROPERTY_LAST,
} HAL_PKJ_PROPERTY_T;

typedef enum {
    HAL_PKJ_TRIG_MODIFY_KEY_PORT = (1 << 0),
    HAL_PKJ_TRIG_MODIFY_KEY_MAC  = (1 << 1),
    HAL_PKJ_TRIG_MODIFY_KEY_VLAN = (1 << 2),
    HAL_PKJ_TRIG_MODIFY_KEY_ARP  = (1 << 3),
    HAL_PKJ_TRIG_MODIFY_KEY_IPV4 = (1 << 4),
    HAL_PKJ_TRIG_MODIFY_KEY_IPV6 = (1 << 5),
} HAL_PKJ_TRIG_MODIFY_KEY_T;

typedef struct HAL_PKJ_TRIG_KEY_MAC_S
{
    CLX_MAC_T    dmac;
    CLX_MAC_T    dmac_mask;
    CLX_MAC_T    smac;
    CLX_MAC_T    smac_mask;
    UI16_T       ether_type;
    UI16_T       ether_type_mask;
} HAL_PKJ_TRIG_KEY_MAC_T;

typedef struct HAL_PKJ_TRIG_KEY_VLAN_S
{
    CLX_VLAN_T    svid;
    CLX_VLAN_T    svid_mask;
    CLX_VLAN_T    cvid;
    CLX_VLAN_T    cvid_mask;
#define HAL_PKJ_TRIG_KEY_VLAN_TAG_MODE_1Q    (1 << 0)
    UI32_T    flags;
} HAL_PKJ_TRIG_KEY_VLAN_T;

typedef enum
{
    HAL_PKJ_ARP_FRAME_ARP_REQUEST  = 1,
    HAL_PKJ_ARP_FRAME_ARP_RESPONSE = 2,
} HAL_PKJ_ARP_FRAME_T;

typedef struct HAL_PKJ_TRIG_KEY_ARP_S
{
    CLX_MAC_T              sender_mac;
    CLX_MAC_T              sender_mac_mask;
    CLX_IPV4_T             sender_ip;
    CLX_IPV4_T             sender_ip_mask;
    CLX_MAC_T              target_mac;
    CLX_MAC_T              target_mac_mask;
    CLX_IPV4_T             target_ip;
    CLX_IPV4_T             target_ip_mask;
    HAL_PKJ_ARP_FRAME_T    arp_frame_type;
#define HAL_PKJ_TRIG_KEY_ARP_FRAME_TYPE_VALID    (1 << 0)
    UI32_T    flags;
} HAL_PKJ_TRIG_KEY_ARP_T;

typedef struct HAL_PKJ_TRIG_KEY_IPV4_S
{
    CLX_IPV4_T       dip;
    CLX_IPV4_T       dip_mask;
    CLX_IPV4_T       sip;
    CLX_IPV4_T       sip_mask;
    UI8_T            protocol;
    UI8_T            protocol_mask;
    UI16_T           dst_port;
    UI16_T           dst_port_mask;
    UI16_T           src_port;
    UI16_T           src_port_mask;
} HAL_PKJ_TRIG_KEY_IPV4_T;

typedef struct HAL_PKJ_TRIG_KEY_IPV6_S
{
    CLX_IPV6_T       dip;
    CLX_IPV6_T       dip_mask;
    CLX_IPV6_T       sip;
    CLX_IPV6_T       sip_mask;
    UI8_T            protocol;
    UI8_T            protocol_mask;
    UI32_T           flow_label;
    UI32_T           flow_label_mask;
    UI16_T           dst_port;
    UI16_T           dst_port_mask;
    UI16_T           src_port;
    UI16_T           src_port_mask;
} HAL_PKJ_TRIG_KEY_IPV6_T;

typedef struct HAL_PKJ_TRIG_KEY_S {
    UI32_T                     igr_port;
    UI32_T                     egr_port;
    HAL_PKJ_TRIG_KEY_MAC_T     mac_key;
    HAL_PKJ_TRIG_KEY_VLAN_T    vlan_key;
    HAL_PKJ_TRIG_KEY_ARP_T     arp_key;
    HAL_PKJ_TRIG_KEY_IPV4_T    ipv4_key;
    HAL_PKJ_TRIG_KEY_IPV6_T    ipv6_key;
#define HAL_PKJ_TRIG_KEY_FLAGS_EGR_PORT_VALID (1 << 0)
    UI32_T    flags;
} HAL_PKJ_TRIG_KEY_T;

typedef CLX_ERROR_NO_T
(*HAL_PKJ_HANDLER_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_cb_id,
    const UI32_T    is_cb,
    const UI32_T    *ptr_buf,
    void            *ptr_cookie);

typedef struct HAL_PKJ_HANDLER_VEC_S {
    UI32_T                    is_cb_valid; /* 1: call callback when cb.valid is 1 */
    HAL_PKJ_HANDLER_FUNC_T    callback;
} HAL_PKJ_HANDLER_VEC_T;

typedef struct HAL_PKJ_HANDLER_ENTRY_S {
    UI32_T                    tbl_id;
    UI32_T                    handler_num;
    HAL_PKJ_HANDLER_VEC_T     *ptr_handler_list;
} HAL_PKJ_HANDLER_ENTRY_T;

typedef struct HAL_PKJ_HANDLER_INFO_S {
    UI32_T                     num;
    HAL_PKJ_HANDLER_ENTRY_T    *ptr_entry_list;
} HAL_PKJ_HANDLER_INFO_T;

typedef struct HAL_PKJ_BUF_META_S {
    UI32_T    valid;
    UI32_T    hit;
    UI32_T    idx;
} HAL_PKJ_BUF_META_T;

/* drv_vec */
typedef CLX_ERROR_NO_T
(*HAL_PKJ_INIT_FUNC_T) (
    const UI32_T                unit);

typedef CLX_ERROR_NO_T
(*HAL_PKJ_DEINIT_FUNC_T) (
    const UI32_T                unit);

typedef CLX_ERROR_NO_T
(*HAL_PKJ_SETPROPERTY_FUNC_T) (
    const UI32_T                unit,
    const HAL_PKJ_PROPERTY_T    property,
    const UI32_T                param0,
    const UI32_T                param1);

typedef CLX_ERROR_NO_T
(*HAL_PKJ_GETPROPERTY_FUNC_T) (
    const UI32_T                unit,
    const HAL_PKJ_PROPERTY_T    property,
    UI32_T                      *ptr_param0,
    UI32_T                      *ptr_param1);

typedef CLX_ERROR_NO_T
(*HAL_PKJ_SETTRIGGERKEY_FUNC_T) (
    const UI32_T                       unit,
    const HAL_PKJ_TRIG_KEY_T           *ptr_trig_key,
    const HAL_PKJ_TRIG_MODIFY_KEY_T    flags);

typedef CLX_ERROR_NO_T
(*HAL_PKJ_GETTRIGGERKEY_FUNC_T) (
    const UI32_T          unit,
    HAL_PKJ_TRIG_KEY_T    *ptr_trig_key);

typedef CLX_ERROR_NO_T
(*HAL_PKJ_DUMPTABLE_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    pipe_flags,
    const UI32_T    flags);

typedef CLX_ERROR_NO_T
(*HAL_PKJ_ANALYZE_DBG_FUNC_T) (
    const UI32_T          unit);

typedef struct
{
    const C8_T                         *driver_desc;
    HAL_PKJ_PP_INFO_T                  *ptr_pp_info;
    HAL_PKJ_BUF_INFO_T                 **pptr_buf_info;
    HAL_PKJ_TBL_INFO_T                 **pptr_tbl_info;
    HAL_PKJ_HANDLER_INFO_T             *ptr_handler_info;
    HAL_PKJ_INIT_FUNC_T                init_func;
    HAL_PKJ_DEINIT_FUNC_T              deinit_func;
    HAL_PKJ_SETPROPERTY_FUNC_T         set_property_func;
    HAL_PKJ_GETPROPERTY_FUNC_T         get_property_func;
    HAL_PKJ_SETTRIGGERKEY_FUNC_T       set_trigger_key_func;
    HAL_PKJ_GETTRIGGERKEY_FUNC_T       get_trigger_key_func;
    HAL_PKJ_DUMPTABLE_FUNC_T           dump_table_func;
    HAL_PKJ_ANALYZE_DBG_FUNC_T         analyze_dbg_func;
} HAL_PKJ_INFO_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
CLX_ERROR_NO_T
hal_pkj_init(
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_pkj_deinit(
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_pkj_setProperty(
    const UI32_T                unit,
    const HAL_PKJ_PROPERTY_T    property,
    const UI32_T                param0,
    const UI32_T                param1);

CLX_ERROR_NO_T
hal_pkj_getProperty(
    const UI32_T                unit,
    const HAL_PKJ_PROPERTY_T    property,
    UI32_T                      *ptr_param0,
    UI32_T                      *ptr_param1);

CLX_ERROR_NO_T
hal_pkj_setTriggerKey(
    const UI32_T                       unit,
    const HAL_PKJ_TRIG_KEY_T           *ptr_trig_key,
    const HAL_PKJ_TRIG_MODIFY_KEY_T    flags);

CLX_ERROR_NO_T
hal_pkj_getTriggerKey(
    const UI32_T          unit,
    HAL_PKJ_TRIG_KEY_T    *ptr_trig_key);

CLX_ERROR_NO_T
hal_pkj_dumpTable(
    const UI32_T    unit,
    const UI32_T    pipe_flags, /* ref HAL_PKJ_PP_FLAGS_XXX */
    const UI32_T    flags);     /* ref HAL_PKJ_SHOW_FLAGS_XXX */

CLX_ERROR_NO_T
hal_pkj_analyzeDbg(
    const UI32_T    unit);

/* EXPOSED HAL PROGRAMS
 */
CLX_ERROR_NO_T
hal_pkj_util_readCbData(
    const UI32_T    unit,
    const UI32_T    plane,
    const UI32_T    cb_id,
    UI32_T          *ptr_cb_buf,
    UI32_T          *ptr_data_num);

void
hal_pkj_util_unpackCbMeta(
    const UI32_T          unit,
    const UI32_T          cb_id,
    const UI32_T          *ptr_cb_buf,
    HAL_PKJ_BUF_META_T    *ptr_meta);

CLX_ERROR_NO_T
hal_pkj_util_findDecodeTableId(
    const UI32_T                unit,
    const HAL_PKJ_TBL_INFO_T    *ptr_tbl_info,
    UI32_T                      *ptr_buf,
    UI32_T                      flags,
    UI32_T                      *ptr_tbl_cb_id,
    UI32_T                      *ptr_is_cb);

CLX_ERROR_NO_T
hal_pkj_util_printField(
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_cb_id,
    const UI32_T    is_cb,
    const UI32_T    *ptr_buf,
    const UI32_T    flags);

#endif /* End of HAL_PKJ_H */
