/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_mpls.h
 * PURPOSE:
 *  It provides MPLS HAL API.
 *
 * NOTES:
 *
 */

#ifndef HAL_MPLS_H
#define HAL_MPLS_H


/* INCLUDE FILE DECLARATIONS
 */
#include <clx_mpls.h>
#include <clx_vlan.h>
#include <hal/common/hal_l3.h>


/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MPLS_MAX_NAME_SPACE     (3) /* Maximum name space */
#define HAL_MPLS_LBL_VLD_OFFSET     (21)
#define HAL_MPLS_CW_VLD_OFFSET      (23)
#define HAL_MPLS_PWEL_VLD_OFFSET    (22)
#define HAL_MPLS_EL_VLD_OFFSET      (20)
#define HAL_MPLS_L_LSP_VLD_OFFSET   (23)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MPLS_SEG_IS_LABEL_VALID(seg) \
    (((seg) < HAL_INVALID_SEG_VMID) \
    && ((seg) & (1U << HAL_MPLS_LBL_VLD_OFFSET)))

#define HAL_MPLS_SEG_IS_LABEL_SWAP(seg) \
    (HAL_MPLS_SEG_IS_LABEL_VALID(seg))

#define HAL_MPLS_ENCAP_LABEL_TO_SEG(lbl_val, el_vld, pwel_vld, cw_vld) \
    (((cw_vld) << HAL_MPLS_CW_VLD_OFFSET) | \
    ((pwel_vld) << HAL_MPLS_PWEL_VLD_OFFSET) | \
    (1U << HAL_MPLS_LBL_VLD_OFFSET) | \
    ((el_vld) << HAL_MPLS_EL_VLD_OFFSET) | \
    ((lbl_val) & 0xFFFFF))

#define HAL_MPLS_PW_LABEL_TO_SEG(lbl_val, pwel_vld, cw_vld) \
    HAL_MPLS_ENCAP_LABEL_TO_SEG(lbl_val, 0, pwel_vld, cw_vld)

#define HAL_MPLS_SWAP_LABEL_TO_SEG(l_lsp_vld, el_vld, lbl_val) \
    (((l_lsp_vld) << HAL_MPLS_L_LSP_VLD_OFFSET) | \
    (1U << HAL_MPLS_LBL_VLD_OFFSET) | \
    ((el_vld) << HAL_MPLS_EL_VLD_OFFSET) | \
    ((lbl_val) & 0xFFFFF))

#define HAL_MPLS_SEG_TO_LABEL(seg) ((seg) & 0xFFFFF)

#define HAL_MPLS_SEG_TO_CW(seg) \
    (((seg) & (1U << HAL_MPLS_CW_VLD_OFFSET)) ? 1 : 0)

#define HAL_MPLS_SEG_TO_PWEL(seg) \
    (((seg) & (1U << HAL_MPLS_PWEL_VLD_OFFSET)) ? 1 : 0)

/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_MPLS_PATH_S
{
    CLX_PORT_T intf;
    UI32_T di;
    UI32_T seg;
    UI32_T vid_ctl;
    UI32_T vid1;
    UI32_T vid2;
    UI32_T adj_id;
    UI32_T nvo3_adj_id;
    UI32_T encap_idx;
    UI32_T encap_ecmp_idx;
    UI32_T l3_intf_id;
    UI32_T src_supp_tag;

#define HAL_MPLS_PATH_FLAGS_L2VPN               (1U << 0)
#define HAL_MPLS_PATH_FLAGS_SEG_VALID           (1U << 1)
#define HAL_MPLS_PATH_FLAGS_VID_CTL_VALID       (1U << 2)
#define HAL_MPLS_PATH_FLAGS_PORT_VALID          (1U << 3)

    UI32_T flags;
} HAL_MPLS_PATH_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */


/* FUNCTION NAME:   hal_mpls_init
 * PURPOSE:
 *    Initialize MPLS module.
 * INPUT:
 *      unit                 --  Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             --  Initialize success.
 *      CLX_E_OTHERS         --  Initialize failed.
 *      CLX_E_ALREADY_INITED --  Already iniialized.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_init(
    const UI32_T    unit);


/* FUNCTION NAME: hal_mpls_deinit
 * PURPOSE:
 *     Deinitialize the MPLS module.
 * INPUT:
 *     unit  --  Device unit number
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK  --  Deinitialization success
 *     CLX_E_BAD_PARAMETER  --  Bad parameter
 *     CLX_E_OTHERS  --  Deinitialization failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_deinit(
    const UI32_T    unit);


/* FUNCTION NAME: hal_mpls_createPort
 * PURPOSE:
 *      Create a MPLS tunnel port.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of MPLS encapsulation label stack.
 * OUTPUT:
 *      ptr_port        -- Pointer of MPLS tunnel port.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_TABLE_FULL        -- Hardware table is full.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_createPort(
    const UI32_T                unit,
    const CLX_MPLS_ENCAP_KEY_T  *ptr_key,
    CLX_PORT_T                  *ptr_port);


/* FUNCTION NAME: hal_mpls_destroyPort
 * PURPOSE:
 *      Destroy a MPLS tunnel port.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- MPLS tunnel port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_destroyPort(
    const UI32_T                unit,
    const CLX_PORT_T            port);

/* FUNCTION NAME: hal_mpls_getPort
 * PURPOSE:
 *      Get MPLS tunnel port.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of MPLS encapsulation label stack.
 * OUTPUT:
 *      ptr_port        -- Pointer of MPLS tunnel port.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getPort(
    const UI32_T                unit,
    const CLX_MPLS_ENCAP_KEY_T  *ptr_key,
    CLX_PORT_T                  *ptr_port);


/* FUNCTION NAME: hal_mpls_getKey
 * PURPOSE:
 *      Get the encapsulation of a MPLS tunnel port.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- MPLS tunnel port.
 * OUTPUT:
 *      ptr_key         -- Pointer of MPLS encapsulation label stack.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getKey(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_MPLS_ENCAP_KEY_T        *ptr_key);


/* FUNCTION NAME: hal_mpls_addInit
 * PURPOSE:
 *      Add a MPLS LSP tunnel initiation.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- MPLS tunnel port.
 *      ptr_init        -- Pointer of LSP tunnel initiation.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_TABLE_FULL        -- Hardware table is full.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_addInit(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_MPLS_INIT_T       *ptr_init);


/* FUNCTION NAME: hal_mpls_delInit
 * PURPOSE:
 *      Delete a MPLS LSP tunnel initiation.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- MPLS tunnel port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_delInit(
    const UI32_T                unit,
    const CLX_PORT_T            port);


/* FUNCTION NAME: hal_mpls_getInit
 * PURPOSE:
 *      Get a MPLS LSP tunnel initiation.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- MPLS tunnel port.
 * OUTPUT:
 *      ptr_init        -- Pointer of LSP tunnel initiation.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getInit(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_MPLS_INIT_T             *ptr_init);


/* FUNCTION NAME: hal_mpls_addTerm
 * PURPOSE:
 *      Add a MPLS LSP tunnel termination.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of LSP tunnel termination match key.
 *      ptr_term        -- Pointer of LSP tunnel termination.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_TABLE_FULL        -- Hardware table is full.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_addTerm(
    const UI32_T                unit,
    const CLX_MPLS_MATCH_KEY_T  *ptr_key,
    const CLX_MPLS_TERM_T       *ptr_term);


/* FUNCTION NAME: hal_mpls_delTerm
 * PURPOSE:
 *      Delete a MPLS LSP tunnel termination.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of LSP tunnel termination match key.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_delTerm(
    const UI32_T                unit,
    const CLX_MPLS_MATCH_KEY_T  *ptr_key);


/* FUNCTION NAME: hal_mpls_getTerm
 * PURPOSE:
 *      Get a MPLS LSP tunnel termination.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of LSP tunnel termination match key.
 * OUTPUT:
 *      ptr_term        -- Pointer of LSP tunnel termination.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getTerm(
    const UI32_T                unit,
    const CLX_MPLS_MATCH_KEY_T  *ptr_key,
    CLX_MPLS_TERM_T             *ptr_term);


/* FUNCTION NAME: clx_mpls_addTransit
 * PURPOSE:
 *      Add a MPLS transit LSP.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of LSP transit match key.
 *      ptr_nhlfe       -- Pointer of LSP transit next hop information.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_TABLE_FULL        -- Hardware table is full.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_addTransit(
    const UI32_T                unit,
    const CLX_MPLS_MATCH_KEY_T  *ptr_key,
    const CLX_MPLS_NHLFE_T      *ptr_nhlfe);


/* FUNCTION NAME: hal_mpls_delTransit
 * PURPOSE:
 *      Delete a MPLS transit LSP.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of LSP transit match key.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_delTransit(
    const UI32_T                unit,
    const CLX_MPLS_MATCH_KEY_T  *ptr_key);


/* FUNCTION NAME: hal_mpls_getTransit
 * PURPOSE:
 *      Get a MPLS transit LSP.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of LSP transit match key.
 * OUTPUT:
 *      ptr_nhlfe       -- Pointer of LSP transit next hop information.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getTransit(
    const UI32_T                unit,
    const CLX_MPLS_MATCH_KEY_T  *ptr_key,
    CLX_MPLS_NHLFE_T            *ptr_nhlfe);


/* FUNCTION NAME: hal_mpls_createPwPort
 * PURPOSE:
 *      Create a PW Interface Object.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of PW key.
 * OUTPUT:
 *      ptr_port        -- Pointer PW port.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_TABLE_FULL        -- Hardware table is full.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_createPwPort(
    const UI32_T                unit,
    const CLX_MPLS_PW_KEY_T     *ptr_key,
    CLX_PORT_T                  *ptr_port);


/* FUNCTION NAME: hal_mpls_destroyPwPort
 * PURPOSE:
 *      Destroy a PW Interface Object.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- PW port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_destroyPwPort(
    const UI32_T                unit,
    const CLX_PORT_T            port);


/* FUNCTION NAME: hal_mpls_getPwPort
 * PURPOSE:
 *      Get the PW Interface port.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_key         -- Pointer of PW key.
 * OUTPUT:
 *      ptr_port        -- Pointer of PW port.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getPwPort(
    const UI32_T                unit,
    const CLX_MPLS_PW_KEY_T     *ptr_key,
    CLX_PORT_T                  *ptr_port);


/* FUNCTION NAME: hal_mpls_getPwKey
 * PURPOSE:
 *      Get the Key of a PW Interface Object.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- PW port.
 * OUTPUT:
 *      ptr_pw_key      -- Pointer of pw key.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getPwKey(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_MPLS_PW_KEY_T           *ptr_key);


/* FUNCTION NAME: hal_mpls_addPw
 * PURPOSE:
 *      Add a MPLS PW.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- PW port.
 *      ptr_pw          -- Pointer of MPLS PW.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_TABLE_FULL        -- Hardware table is full.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_addPw(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_MPLS_PW_T         *ptr_pw);


/* FUNCTION NAME: hal_mpls_delPw
 * PURPOSE:
 *      Delete a MPLS PW.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- PW port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_delPw(
    const UI32_T                unit,
    const CLX_PORT_T            port);


/* FUNCTION NAME: clx_mpls_getPw
 * PURPOSE:
 *      Get a MPLS PW.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- PW port.
 * OUTPUT:
 *      ptr_pw          -- Pointer of MPLS PW.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getPw(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_MPLS_PW_T               *ptr_pw);


/* FUNCTION NAME: clx_mpls_addVpws
 * PURPOSE:
 *      Add a MPLS VPWS.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- PW port.
 *      ptr_ac          -- Pointer of PW AC information.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_TABLE_FULL        -- Hardware table is full.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_addVpws(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_MPLS_AC_T         *ptr_ac);


/* FUNCTION NAME: clx_mpls_delVpws
 * PURPOSE:
 *      Delete a MPLS VPWS.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- PW port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_delVpws(
    const UI32_T                unit,
    const CLX_PORT_T            port);


/* FUNCTION NAME: clx_mpls_getVpws
 * PURPOSE:
 *      Get a MPLS VPWS.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- Pw port.
 * OUTPUT:
 *      ptr_ac          -- Pointer of PW AC information.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_mpls_getVpws(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_MPLS_AC_T               *ptr_ac);


/* FUNCTION NAME: clx_mpls_setLabelRange
 * PURPOSE:
 *      Set MPLS label value range.
 * INPUT:
 *      unit        -- Device unit number.
 *      type        -- MPLS label type.
 *      min_value   -- Minimum label value. Shall > 15.
 *      max_value   -- Maximum label value.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_setLabelRange(
    const UI32_T                unit,
    const CLX_MPLS_LABEL_TYPE_T type,
    const UI32_T                min_value,
    const UI32_T                max_value);


/* FUNCTION NAME: clx_mpls_getLabelRange
 * PURPOSE:
 *      Get MPLS label value range.
 * INPUT:
 *      unit            -- Device unit number.
 *      type            -- MPLS label type.
 * OUTPUT:
 *      ptr_min_value   -- Pointer of minimum label value.
 *      ptr_max_value   -- Pointer of maximum label value.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_getLabelRange(
    const UI32_T                unit,
    const CLX_MPLS_LABEL_TYPE_T type,
    UI32_T                      *ptr_min_value,
    UI32_T                      *ptr_max_value);


/* FUNCTION NAME: hal_mpls_traverseInit
 * PURPOSE:
 *      Get all MPLS init entries.
 * INPUT:
 *      unit            -- Device unit number.
 *      callback        -- Callback function provided by user, user can do self
 *                         action to every node data in this callback function.
 *      ptr_cookie      -- User cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie      -- User cookie data as input parameter of callback function
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_traverseInit(
    const UI32_T                        unit,
    const CLX_MPLS_INIT_TRAVERSE_FUNC_T callback,
    void                                *ptr_cookie);


/* FUNCTION NAME: hal_mpls_traverseTransit
 * PURPOSE:
 *      Get all MPLS transit entries.
 * INPUT:
 *      unit            -- Device unit number.
 *      callback        -- Callback function provided by user, user can do self
 *                         action to every node data in this callback function.
 *      ptr_cookie      -- User cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie      -- User cookie data as input parameter of callback function
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_traverseTransit(
    const UI32_T                            unit,
    const CLX_MPLS_TRANSIT_TRAVERSE_FUNC_T  callback,
    void                                    *ptr_cookie);


/* FUNCTION NAME: hal_mpls_traverseTerm
 * PURPOSE:
 *      Get all MPLS term entries.
 * INPUT:
 *      unit            -- Device unit number.
 *      callback        -- Callback function provided by user, user can do self
 *                         action to every node data in this callback function.
 *      ptr_cookie      -- User cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie      -- User cookie data as input parameter of callback function
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_traverseTerm(
    const UI32_T                        unit,
    const CLX_MPLS_TERM_TRAVERSE_FUNC_T callback,
    void                                *ptr_cookie);


/* FUNCTION NAME: hal_mpls_traversePw
 * PURPOSE:
 *      Get all MPLS PW entries.
 * INPUT:
 *      unit            -- Device unit number.
 *      callback        -- Callback function provided by user, user can do self
 *                         action to every node data in this callback function.
 *      ptr_cookie      -- User cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie      -- User cookie data as input parameter of callback function
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_traversePw(
    const UI32_T                        unit,
    const CLX_MPLS_PW_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);


/* FUNCTION NAME: hal_mpls_setSkipMpls
 * PURPOSE:
 *      Set the value of skip MPLS label stacking for MPLS payload parsing.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- Port number.
 *      value           -- value range:0~3
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_setSkipMpls(
    const UI32_T                unit,
    const UI32_T                port,
    const UI32_T                value);


/* FUNCTION NAME: hal_mpls_getSkipMpls
 * PURPOSE:
 *      Get the value of skip MPLS label stacking.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- Port number.
 * OUTPUT:
 *      ptr_value       -- Pointer of the value.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_getSkipMpls(
    const UI32_T                unit,
    const UI32_T                port,
    UI32_T                      *ptr_value);


/* FUNCTION NAME: hal_mpls_setDelMpls
 * PURPOSE:
 *      Set the value of deleting MPLS label stacking when decap miss.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- Port number.
 *      value           -- value range:0~1
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_setDelMpls(
    const UI32_T                unit,
    const UI32_T                port,
    const UI32_T                value);


/* FUNCTION NAME: hal_mpls_getDelMpls
 * PURPOSE:
 *      Get the value of deleting MPLS label stacking.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- Port number.
 * OUTPUT:
 *      ptr_value       -- Pointer of the value.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_getDelMpls(
    const UI32_T                unit,
    const UI32_T                port,
    UI32_T                      *ptr_value);


/* FUNCTION NAME: hal_mpls_getPathInfo
 * PURPOSE:
 *      Get MPLS path information.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- MPLS tunnel or PW port.
 *      ptr_vlan_tag    -- L2VPN PW VLAN tag.
 *      action          -- L2VPN PW VLAN tag action.
 * OUTPUT:
 *      ptr_path        -- Pointer of the path info of the port.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_getPathInfo(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VLAN_TAG_ACTION_T *ptr_vlan_tag,
    const CLX_VLAN_ACTION_T     action,
    HAL_MPLS_PATH_T             *ptr_path);


/* FUNCTION NAME: hal_mpls_getPortByPathInfo
 * PURPOSE:
 *      Get MPLS tunnel or PW por by path information.
 * INPUT:
 *      unit            -- Device unit number.
 *      ptr_path        -- Pointer of the path info of the port.
 *                         Shall specify the seg and th di of the path.
 * OUTPUT:
 *      port            -- MPLS tunnel or PW port.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_getPortByPathInfo(
    const UI32_T            unit,
    const HAL_MPLS_PATH_T   *ptr_path,
    CLX_PORT_T              *ptr_port);


/* FUNCTION NAME: hal_mpls_getPwVlanTagAction
 * PURPOSE:
 *      Get PW VLAN tag action
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- PW port.
 *      vid1            -- First VLAN ID.
 *      vid2            -- Second VLAN ID.
 *      vid_ctl         -- VID control.
 * OUTPUT:
 *      ptr_tag_action  -- Pointer of VLAN tag action.
 *      ptr_vlan_action -- Pointer of VLAN action.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_getPwVlanTagAction(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VLAN_T            vid1,
    const CLX_VLAN_T            vid2,
    const UI32_T                vid_ctl,
    CLX_VLAN_TAG_ACTION_T       *ptr_tag_action,
    CLX_VLAN_ACTION_T           *ptr_vlan_action);


/* FUNCTION NAME: hal_mpls_mcast_transEgrIntfToMelInfo
 * PURPOSE:
 *      Translate L3 multicast egress interface to HW MEL info.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- Egress physical port.
 *      ptr_tag_action  -- Pointer of VLAN tag action.
 *      ptr_egr_intf    -- Pointer of egress interface.
 * OUTPUT:
 *      ptr_mel_info    -- Pointer of MEL info.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_mcast_transEgrIntfToMelInfo(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_VLAN_TAG_ACTION_T     *ptr_tag_action,
    const CLX_L3_MCAST_EGR_INTF_T   *ptr_egr_intf,
    HAL_L3_MCAST_MEL_INFO_T         *ptr_mel_info);


/* FUNCTION NAME: hal_mpls_mcast_transMelInfoToEgrIntf
 * PURPOSE:
 *      Translate HW MEL info to L3 multicast egress interface.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- Egress physical port.
 *      ptr_mel_info    -- Pointer of MEL info.
 * OUTPUT:
 *      ptr_egr_intf    -- Pointer of egress interface.
 *      ptr_tag_action  -- Pointer of VLAN tag action.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_mcast_transMelInfoToEgrIntf(
    const UI32_T                    unit,
    const UI32_T                    port,
    const HAL_L3_MCAST_MEL_INFO_T   *ptr_mel_info,
    CLX_L3_MCAST_EGR_INTF_T         *ptr_egr_intf,
    CLX_VLAN_TAG_ACTION_T           *ptr_tag_action);


/* FUNCTION NAME: hhal_mpls_checkMplsPath
 * PURPOSE:
 *      Check a path whether or not a MPLS path
 * INPUT:
 *      unit            -- Device unit number.
 *      di              -- Egress destination ID.
 *      seg             -- Segment ID.
 * OUTPUT:
 *      ptr_egr_intf    -- Pointer of egress interface.
 * RETURN:
 *      TRUE/FALSE
 * NOTES:
 *
 */
BOOL_T
hal_mpls_checkMplsPath(
    const UI32_T                unit,
    const UI32_T                di,
    const UI32_T                seg);


/* FUNCTION NAME: hal_mpls_getL3VpnAdj
 * PURPOSE:
 *      Get MPLS reserved adj for remove l2 header
 * INPUT:
 *      unit            -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      MPLS reserved adj id.
 * NOTES:
 *
 */
UI32_T
hal_mpls_getL3VpnAdj(
    const UI32_T unit);


/* FUNCTION NAME: hal_mpls_updateAdjInfo
 * PURPOSE:
 *      Update adjacency information
 * INPUT:
 *      unit            -- Device unit number.
 *      adj_id          -- Adjacency ID.
 *      ptr_adj         -- Adjacency information.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_updateAdjInfo(
    const UI32_T                unit,
    const UI32_T                adj_id,
    const HAL_L3_ADJ_INFO_T     *ptr_adj);


/* FUNCTION NAME: hal_mpls_updateNvo3AdjInfo
 * PURPOSE:
 *      Update adjacency information
 * INPUT:
 *      unit            -- Device unit number.
 *      adj_id          -- Nvo3 adjacency ID.
 *      port            -- Egress port.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_updateNvo3AdjInfo(
    const UI32_T                unit,
    const UI32_T                adj_id,
    const CLX_PORT_T            port);


/* FUNCTION NAME: hal_mpls_dumpDb
 * PURPOSE:
 *      Dump MPLS software DB
 * INPUT:
 *      unit            -- Device unit number.
 *      flags           -- Dump flags.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_dumpDb(
    const UI32_T                unit,
    const UI32_T                flags);


/* FUNCTION NAME: hal_mpls_addIevInfo
 * PURPOSE:
 *      Add IEV rslt info of output to LSP
 * INPUT:
 *      unit            -- Device unit number.
 *      iev_idx         -- IEV rslt idx.
 *      adj_id          -- Adjacency ID.
 *      port            -- MPLS port.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_addIevInfo(
    const UI32_T                unit,
    const UI32_T                iev_idx,
    const UI32_T                adj_id,
    const CLX_PORT_T            port);


/* FUNCTION NAME: hal_mpls_delIevInfo
 * PURPOSE:
 *      Delete IEV rslt info of output to LSP
 * INPUT:
 *      unit            -- Device unit number.
 *      iev_idx         -- IEV rslt idx.
 *      adj_id          -- Adjacency ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_delIevInfo(
    const UI32_T                unit,
    const UI32_T                iev_idx,
    const UI32_T                adj_id);


/* FUNCTION NAME: hal_mpls_getDi
 * PURPOSE:
 *      Get MPLS path DI.
 * INPUT:
 *      unit            -- Device unit number.
 *      port            -- MPLS tunnel or PW port.
 * OUTPUT:
 *      ptr_di          -- Pointer of the DI of the port.
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- Entry is not found.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mpls_getDi(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    UI32_T                      *ptr_di);

#endif
