/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_DAWN_PKT_RSRC_H
#define HAL_DAWN_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_pkt.h>

#include <hal/common/hal_pkt_rsrc.h>


/* NAMING CONSTANT DECLARATIONS
 */
/* Keep these values applied to different modules. */
#define HAL_DAWN_PKT_IPP_EXCPT_LAST      (256)
#define HAL_DAWN_PKT_EPP_EXCPT_LAST      (64)

#define HAL_DAWN_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L2UC  \
    (192 + IEV_CFG_EXCPT_EN_W1_SDK_REDIRECT_TO_CPU_L2UC_FIELD_ID )
#define HAL_DAWN_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L3UC  \
    (192 + IEV_CFG_EXCPT_EN_W1_SDK_REDIRECT_TO_CPU_L3UC_FIELD_ID )
#define HAL_DAWN_PKT_IPP_EXCPT_IEV_SDK_L3UC_DA_MISS          \
    (192 + IEV_CFG_EXCPT_EN_W1_SDK_L3UC_DA_MISS_FIELD_ID         )
#define HAL_DAWN_PKT_IPP_EXCPT_IEV_SDK_L3MC_PIM_REGISTER     \
    (192 + IEV_CFG_EXCPT_EN_W1_SDK_L3MC_PIM_REGISTER_FIELD_ID    )
#define HAL_DAWN_PKT_IPP_EXCPT_IEV_SDK_FLEX_DECAP_0_REASON_0 \
    (224 + IEV_CFG_EXCPT_EN_W0_SDK_FLEX_DECAP_0_REASON_0_FIELD_ID)

typedef UI32_T HAL_DAWN_PKT_IPP_EXCPT_T;
typedef UI32_T HAL_DAWN_PKT_EPP_EXCPT_T;

typedef enum
{
    HAL_DAWN_PKT_IPP_L3_EXCPT_FCOE_ZONING = 0,
    HAL_DAWN_PKT_IPP_L3_EXCPT_RPF,
    HAL_DAWN_PKT_IPP_L3_EXCPT_ICMP_REDIR,
    HAL_DAWN_PKT_IPP_L3_EXCPT_SW_FWD,
    HAL_DAWN_PKT_IPP_L3_EXCPT_MTU,
    HAL_DAWN_PKT_IPP_L3_EXCPT_TTL,
    HAL_DAWN_PKT_IPP_L3_EXCPT_LAST
} HAL_DAWN_PKT_IPP_L3_EXCPT_T;

typedef enum
{
    HAL_DAWN_PKT_IPP_RSN_RSVD_0 = 0,
    HAL_DAWN_PKT_IPP_RSN_IDS_MPLS_MP_LSP_INNER_IP_LCL,
    HAL_DAWN_PKT_IPP_RSN_IDS_IP_MC_TNL_LCL_INTF_MISS,
    HAL_DAWN_PKT_IPP_RSN_IDS_IP_MC_TNL_GRE_ISIS,
    HAL_DAWN_PKT_IPP_RSN_IDS_IP_MC_TNL_GRE_KA,
    HAL_DAWN_PKT_IPP_RSN_IDS_IP_MC_TNL_INNER_IP_LCL,
    HAL_DAWN_PKT_IPP_RSN_IDS_TRILL_MC_LCL_INTF_MISS,
    HAL_DAWN_PKT_IPP_RSN_IDS_INNER_SRV_1ST_MISS,
    HAL_DAWN_PKT_IPP_RSN_IDS_INNER_SRV_2ND_MISS,
    HAL_DAWN_PKT_IPP_RSN_IEV_IP_MC_TTL0,
    HAL_DAWN_PKT_IPP_RSN_IEV_IP_MC_TTL1,
    HAL_DAWN_PKT_IPP_RSN_RSVD_1,
    HAL_DAWN_PKT_IPP_RSN_RSVD_2,
    HAL_DAWN_PKT_IPP_RSN_IDS_ECN,
    HAL_DAWN_PKT_IPP_RSN_IEV_ICMP_REDIR,
    HAL_DAWN_PKT_IPP_RSN_IEV_ICMP_REDIR_WITH_RSN_IDS_ECN,
    HAL_DAWN_PKT_IPP_RSN_LAST
} HAL_DAWN_PKT_IPP_RSN_T;

typedef enum
{
    /* IEV.cp_to_cpu_bmap |=
     * (1UL << sw_plane.iev_cp_to_cpu_bit_pos_{i})   |
     * (1UL << sw_plane.iev_sflw_cp_to_cpu_bidx_{i}) |
     * (1UL << (IEV_RSLT_CTL2CPU_PROF.code - 1))     |
     * (1UL << (ICIA_RSLT_TCAM_UCP_POLICY.cp_to_cpu_idx - 1));
     */
    HAL_DAWN_PKT_IPP_COPY2CPU_ICIA_0 = 0,
    HAL_DAWN_PKT_IPP_COPY2CPU_ICIA_1,
    HAL_DAWN_PKT_IPP_COPY2CPU_ICIA_2,
    HAL_DAWN_PKT_IPP_COPY2CPU_ICIA_3,
    HAL_DAWN_PKT_IPP_COPY2CPU_ICIA_4,
    HAL_DAWN_PKT_IPP_COPY2CPU_ICIA_5,
    HAL_DAWN_PKT_IPP_COPY2CPU_COPY_TO_CPU_L2UC,
    HAL_DAWN_PKT_IPP_COPY2CPU_COPY_TO_CPU_L3UC,
    HAL_DAWN_PKT_IPP_COPY2CPU_PORT_SFLOW,
    HAL_DAWN_PKT_IPP_COPY2CPU_ICIA_SFLOW,
    HAL_DAWN_PKT_IPP_COPY2CPU_FLOW_SFLOW,
    HAL_DAWN_PKT_IPP_COPY2CPU_L3MC_SPT_READY_UNSET,
    HAL_DAWN_PKT_IPP_COPY2CPU_COPY_TO_CPU_L2MC,
    HAL_DAWN_PKT_IPP_COPY2CPU_COPY_TO_CPU_L3MC,
    HAL_DAWN_PKT_IPP_COPY2CPU_USR_DEFINE_0,
    HAL_DAWN_PKT_IPP_COPY2CPU_USR_DEFINE_1,
    HAL_DAWN_PKT_IPP_COPY2CPU_LAST
} HAL_DAWN_PKT_IPP_COPY2CPU_T;

typedef enum
{
    /* The value of:
     * 1. emi_sflw_cp_to_cpu_idx_bidx_*
     * 2. ECIA.cp_to_cpu_idx (last is invalid)
     */
    HAL_DAWN_PKT_EPP_COPY2CPU_ECIA_0 = 0,
    HAL_DAWN_PKT_EPP_COPY2CPU_ECIA_1,
    HAL_DAWN_PKT_EPP_COPY2CPU_ECIA_2,
    HAL_DAWN_PKT_EPP_COPY2CPU_ECIA_3,
    HAL_DAWN_PKT_EPP_COPY2CPU_PORT_SFLOW,
    HAL_DAWN_PKT_EPP_COPY2CPU_ECIA_SFLOW,
    HAL_DAWN_PKT_EPP_COPY2CPU_RSVD_0,
    HAL_DAWN_PKT_EPP_COPY2CPU_RSVD_1,
    HAL_DAWN_PKT_EPP_COPY2CPU_LAST
} HAL_DAWN_PKT_EPP_COPY2CPU_T;


/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_dawn_pkt_mapIppExcptToUser
 * PURPOSE:
 *      To map the reason from hw ipp exception bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapIppExcptToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapIppExcptCodeToUser
 * PURPOSE:
 *      To map the reason from hw ipp exception value to user reason bitmap.
 * INPUT:
 *      code   -- The hw reason code
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapIppExcptCodeToUser(
    const UI32_T                            unit,
    const UI32_T                            code,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapIppL3ExcptToUser
 * PURPOSE:
 *      To map the reason from hw ipp l3 exception bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapIppL3ExcptToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapIppCopyToCpuToUser
 * PURPOSE:
 *      To map the reason from hw ipp copy2cpu bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapIppCopyToCpuToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapIppRsnToUser
 * PURPOSE:
 *      To map the reason from hw ipp rsn bitmap to user reason bitmap.
 * INPUT:
 *      hw_bitmap       -- The hw reason bitmap
 * OUTPUT:
 *      ptr_user_bitmap -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapIppRsnToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapIppRsnCodeToUser
 * PURPOSE:
 *      To map the reason from hw ipp rsn code to user reason bitmap.
 * INPUT:
 *      code            -- The hw reason code
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapIppRsnCodeToUser(
    const UI32_T                            unit,
    const UI32_T                            code,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapEppExcptToUser
 * PURPOSE:
 *      To map the reason from hw epp exception bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapEppExcptToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapEppExcptCodeToUser
 * PURPOSE:
 *      To map the reason from hw epp exception code to user reason bitmap.
 * INPUT:
 *      code   -- The hw reason code
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapEppExcptCodeToUser(
    const UI32_T                            unit,
    const UI32_T                            code,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapEppCopyToCpuToUser
 * PURPOSE:
 *      To map the reason from hw epp copy2cpu bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapEppCopyToCpuToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapUserToIppExcpt
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw ipp exception bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapUserToIppExcpt(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapUserToIppL3Excpt
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw ipp l3 excpt bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapUserToIppL3Excpt(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapUserToIppCopy2cpu
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw ipp copy2cpu bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapUserToIppCopyToCpu(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapUserToIppRsn
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw ipp rsn bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapUserToIppRsn(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapUserToEppExcpt
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw epp exception bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapUserToEppExcpt(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_mapUserToEppCopy2cpu
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw epp copy2cpu bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_mapUserToEppCopyToCpu(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_dawn_pkt_transUserToHwReason
 * PURPOSE:
 *      To translate the reason from user-view to chip-view.
 * INPUT:
 *      user_reason     -- The user-view reason
 * OUTPUT:
 *      ptr_hw_reason   -- Pointer to the chip-view reason
 * RETURN:
 *      CLX_E_OK        -- Success to translate the reason.
 *      CLX_E_OTHERS    -- Undefined user-view reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_transUserToHwReason(
    const UI32_T                                unit,
    const CLX_PKT_RX_REASON_T                   user_reason,
    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T     hw_action,
          UI32_T                                *ptr_hw_reason);

/* FUNCTION NAME: hal_dawn_pkt_transHwToUserReason
 * PURPOSE:
 *      To translate the reason from chip-view to user-view.
 * INPUT:
 *      hw_reason       -- The chip-view reason
 * OUTPUT:
 *      ptr_user_reason -- Pointer to the user-view reason
 * RETURN:
 *      CLX_E_OK        -- Success to translate the reason.
 *      CLX_E_OTHERS    -- Undefined chip-view reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_pkt_transHwToUserReason(
    const UI32_T                                unit,
    const UI32_T                                hw_reason,
    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T     hw_action,
          CLX_PKT_RX_REASON_T                   *ptr_user_reason);

#endif  /* End of HAL_VLAN_H */
