/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_PORT_H
#define HAL_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <hal/common/hal_mac.h>
#include <cmlib/cmlib_avl.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PORT_DFLT_UL_EXP_VLAN_TPID_1ST_SET  (0)
#define HAL_PORT_DFLT_UL_ALW_VLAN_TAG_SET       (1)
#define HAL_PORT_DFLT_1ST_TPID                  (0x8100)
#define HAL_PORT_DFLT_2ST_TPID                  (0x0)

#define HAL_PORT_DFLT_L3_MTU_CK_SUPP_SET        (0)
#define HAL_PORT_DFLT_L2_MTU_SIZE               (1536)

#define HAL_PORT_HW_ACCEPTABLE_TYPE_NONE        (0)
#define HAL_PORT_HW_ACCEPTABLE_TYPE_TAGGED      (1)
#define HAL_PORT_HW_ACCEPTABLE_TYPE_UNTAGGED    (2)
#define HAL_PORT_HW_ACCEPTABLE_TYPE_ALL         (3)

#define HAL_PORT_SST_INVALID                    (0x1F)

#define HAL_PORT_ABILITY_ADD_1G(__ptr_ability__)                            \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_1000BASE_X;  \
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_GMII;    \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_GMII;    \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_10G(__ptr_ability__)                           \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_10GBASE_KR;  \
        (__ptr_ability__)->eee       |= CLX_PORT_ABILITY_EEE_10GBASE_KR;    \
        (__ptr_ability__)->fec       |= CLX_PORT_ABILITY_FEC_ABILITY |      \
                                        CLX_PORT_ABILITY_FEC_REQUEST;       \
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_XGMII;   \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_40G(__ptr_ability__)                           \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed    |= CLX_PORT_ABILITY_SPEED_40GBASE_KR4 | \
                                       CLX_PORT_ABILITY_SPEED_40GBASE_CR4;  \
        (__ptr_ability__)->eee      |= CLX_PORT_ABILITY_EEE_40GBASE_KR4 |   \
                                       CLX_PORT_ABILITY_EEE_40GBASE_CR4;    \
        (__ptr_ability__)->fec      |= CLX_PORT_ABILITY_FEC_ABILITY |       \
                                       CLX_PORT_ABILITY_FEC_REQUEST;        \
        (__ptr_ability__)->pause    |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |  \
                                       CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;    \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_XLGMII;  \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_25G(__ptr_ability__)                           \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR_S |\
                                        CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR;\
        (__ptr_ability__)->eee       |= CLX_PORT_ABILITY_EEE_25GBASE_R;     \
        (__ptr_ability__)->fec       |= CLX_PORT_ABILITY_FEC_RS_REQUEST |   \
                                        CLX_PORT_ABILITY_FEC_BASE_R_REQUEST;\
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_25GMII;  \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_50G(__ptr_ability__)                           \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_50GBASE_KR2_CR2; \
        (__ptr_ability__)->fec       |= CLX_PORT_ABILITY_FEC_RS_REQUEST |   \
                                        CLX_PORT_ABILITY_FEC_BASE_R_REQUEST;\
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_50GMII;  \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_100G(__ptr_ability__)                          \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_100GBASE_KR4 | \
                                        CLX_PORT_ABILITY_SPEED_100GBASE_CR4;  \
        (__ptr_ability__)->eee       |= CLX_PORT_ABILITY_EEE_100GBASE_KR4 | \
                                        CLX_PORT_ABILITY_EEE_100GBASE_CR4;  \
        (__ptr_ability__)->fec       |= CLX_PORT_ABILITY_FEC_RS_REQUEST;    \
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_CGMII;   \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_50G_R1(__ptr_ability__)                        \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_50GBASE_KR_CR; \
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_50GMII;  \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_100G_R2(__ptr_ability__)                       \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_100GBASE_KR2_CR2; \
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_CGMII;   \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_200G_R4(__ptr_ability__)                       \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_200GBASE_KR4_CR4; \
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_200GMII; \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
        (__ptr_ability__)->flags     |= CLX_PORT_ABILITY_FLAGS_AUTONEG;     \
    } while(0)

#define HAL_PORT_ABILITY_ADD_400G_R8(__ptr_ability__)                       \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed     |= CLX_PORT_ABILITY_SPEED_400GBASE_CONSORTIUM; \
        (__ptr_ability__)->pause     |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE | \
                                        CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_400GMII; \
        (__ptr_ability__)->medium    |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
                                        CLX_PORT_ABILITY_MEDIUM_COPPER;     \
    } while(0)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_PORT_LOCK(unit)     hal_port_lockPortResource(unit)
#define HAL_PORT_UNLOCK(unit)   hal_port_unlockPortResource(unit)

#define HAL_PORT_ABILITY_INIT(__ptr_ability__)                              \
    do                                                                      \
    {                                                                       \
        (__ptr_ability__)->speed = 0;                                       \
        (__ptr_ability__)->eee   = 0;                                       \
        (__ptr_ability__)->fec   = 0;                                       \
        (__ptr_ability__)->pause = 0;                                       \
        (__ptr_ability__)->medium = 0;                                      \
        (__ptr_ability__)->interface = 0;                                   \
        (__ptr_ability__)->flags = 0;                                       \
    } while(0)

/* DATA TYPE DECLARATIONS
 */

typedef enum
{
    HAL_PORT_PROPERTY_TS_MAC_RPL_EGR = 0,
    HAL_PORT_PROPERTY_TS_MAC_RPL_DA,
    HAL_PORT_PROPERTY_TS_MAC_RPL_EN,
    HAL_PORT_PROPERTY_IGR_TS_EOF_INS_EN,
    HAL_PORT_PROPERTY_EGR_TS_EOF_INS_EN,
} HAL_PORT_PP_PROPERTY_T;

/* Port speed and lane count */
typedef enum
{
    HAL_PORT_SPEED_LANE_1G_R1   = 0,
    HAL_PORT_SPEED_LANE_10G_R1,
    HAL_PORT_SPEED_LANE_40G_R4,
    HAL_PORT_SPEED_LANE_25G_R1,
    HAL_PORT_SPEED_LANE_50G_R2,
    HAL_PORT_SPEED_LANE_100G_R4,
    HAL_PORT_SPEED_LANE_50G_R1,
    HAL_PORT_SPEED_LANE_100G_R2,
    HAL_PORT_SPEED_LANE_200G_R4,
    HAL_PORT_SPEED_LANE_400G_R8,
    HAL_PORT_SPEED_LANE_LAST
} HAL_PORT_SPEED_LANT_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS */

CLX_ERROR_NO_T
hal_port_lockPortResource(
    const   UI32_T  unit);

CLX_ERROR_NO_T
hal_port_unlockPortResource(
    const   UI32_T  unit);

/* FUNCTION NAME:   hal_port_getPortL2LclIntf
 * PURPOSE:
 *      To get default L2_lcl_intf index for a specific port.
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  Physical port id.
 *      port_dir        --  Ingress/egress L2_lcl_intf.
 * OUTPUT:
 *      ptr_l2_lcl_intf_idx --  The specified direction default L2_lcl_intf index of the port.
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getPortL2LclIntf(
    const UI32_T unit,
    const UI32_T port,
    const CLX_DIR_T port_dir,
    UI32_T * ptr_l2_lcl_intf_idx);

/* FUNCTION NAME:   hal_port_setEcn
 * PURPOSE:
 *      To set whether to enable ECN to the port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port id.
 *      enable      --  Whether to enable ECN.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setEcn(
    const   UI32_T  unit,
    const   UI32_T  port,
    const   UI32_T  enable);

/* FUNCTION NAME:   hal_port_getEcn
 * PURPOSE:
 *      To set whether to enable ECN to the port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port id.
 * OUTPUT:
 *      enable      --  Whether to enable ECN.
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getEcn(
    const   UI32_T  unit,
    const   UI32_T  port,
    UI32_T  *ptr_enable);

/* FUNCTION NAME:   hal_port_setSpeed
 * PURPOSE:
 *      To set the speed for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 *      speed   --  The speed of the physical port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setSpeed(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_PORT_SPEED_T    speed);

/* FUNCTION NAME:   hal_port_getSpeed
 * PURPOSE:
 *      To get the speed for a specific port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port id.
 * OUTPUT:
 *      ptr_speed   --  The speed of the physical port.
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getSpeed(
    const   UI32_T              unit,
    const   UI32_T              port,
    CLX_PORT_SPEED_T            *ptr_speed);

/* FUNCTION NAME:   hal_port_setFlowCtrl
 * PURPOSE:
 *      To set the flowcontrol configuration for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 *      fc      --  The flowcontrol configuration of the physical port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setFlowCtrl(
    const   UI32_T          unit,
    const   UI32_T          port,
    const   CLX_PORT_FC_T   fc);

/* FUNCTION NAME:   hal_port_getFlowCtrl
 * PURPOSE:
 *      To get the flowcontrol configuration for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 * OUTPUT:
 *      ptr_fc  --  The flowcontrol configuration of the physical port.
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getFlowCtrl(
    const   UI32_T          unit,
    const   UI32_T          port,
    CLX_PORT_FC_T           *ptr_fc);

/* FUNCTION NAME:   hal_port_setPriFlowCtrl
 * PURPOSE:
 *      To set the PFC configuration for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 *      pri     --  The priority number 0~7.
 *      pfc     --  The PFC configuration of the physical port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setPriFlowCtrl(
    const   UI32_T          unit,
    const   UI32_T          port,
    const   UI8_T           pri,
    const   CLX_PORT_FC_T   pfc);

/* FUNCTION NAME:   hal_port_getPriorityFlowControl
 * PURPOSE:
 *      To get the PFC configuration for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 *      pri     --  The priority number 0~7.
 * OUTPUT:
 *      ptr_pfc --  The PFC configuration of the physical port.
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getPriFlowCtrl(
    const   UI32_T          unit,
    const   UI32_T          port,
    const   UI8_T           pri,
    CLX_PORT_FC_T           *ptr_pfc);

/* FUNCTION NAME:   hal_port_setEeeMode
 * PURPOSE:
 *      To set the EEE mode for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 *      mode    --  The EEE mode of the physical port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setEeeMode(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_PORT_EEE_MODE_T mode);

/* FUNCTION NAME:   hal_port_getEeeMode
 * PURPOSE:
 *      To get the EEE mode for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 * OUTPUT:
 *      ptr_mode                --  The EEE mode of the physical port.
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getEeeMode(
    const   UI32_T              unit,
    const   UI32_T              port,
    CLX_PORT_EEE_MODE_T         *ptr_mode);

/* FUNCTION NAME:   hal_port_setFec
 * PURPOSE:
 *      To set the FEC configuration for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 *      enable  --  The FEC configuration of the physical port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setFec(
    const   UI32_T      unit,
    const   UI32_T      port,
    const   UI32_T      enable);

/* FUNCTION NAME:   hal_port_getFec
 * PURPOSE:
 *      To get the FEC configuration for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 * OUTPUT:
 *      ptr_enable              --  The FEC configuration of the physical port.
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getFec(
    const   UI32_T      unit,
    const   UI32_T      port,
    UI32_T              *ptr_enable);

/* FUNCTION NAME:   hal_port_setAdminState
 * PURPOSE:
 *      To set the administrative state for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 *      status  --  To enable/disable the port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setAdminState(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              state);

/* FUNCTION NAME:   hal_port_getAdminState
 * PURPOSE:
 *      To get the administrative state for a specific port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port id.
 * OUTPUT:
 *      ptr_status  --  To enable/disable the port.
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getAdminState(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_state);

/* FUNCTION NAME:   hal_port_setAnLtStatus
 * PURPOSE:
 *      To set the autonegotiation status for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 *      anlt    --  Toggle status of autonegotiation-linktraining per port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setAnLtStatus(
    const   UI32_T      unit,
    const   UI32_T      port,
    const   UI32_T      anlt);

/* FUNCTION NAME:   hal_port_getAnLtStatus
 * PURPOSE:
 *      To get the autonegotiation status for a specific port.
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  Physical port id.
 * OUTPUT:
 *      ptr_anlt        --  Toggle status of autonegotiation-linktraining per port.
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getAnLtStatus(
    const   UI32_T      unit,
    const   UI32_T      port,
    UI32_T              *ptr_anlt);

/* FUNCTION NAME:   hal_port_setLocalAdvAbility
 * PURPOSE:
 *      To set the auto-negotiation advertisement for a specific port.
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  Physical port id.
 *      ptr_ability     --  Autonegotiation ability setting per port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setLocalAdvAbility(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   hal_port_getLocalAdvAbility
 * PURPOSE:
 *      To get the auto-negotiation advertisement for a specific port.
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  Physical port id.
 *      ptr_ability     --  Autonegotiation ability setting per port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getLocalAdvAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   hal_port_getRemoteAdvAbility
 * PURPOSE:
 *      This API is used to get the auto-negotiation remote advertisement for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_ability     --  Autonegotiation ability setting per port
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getRemoteAdvAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   hal_port_setLoopback
 * PURPOSE:
 *      This API is used to set the loopback for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      lbtype          --  Loopback type:
 *                          CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                          CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                          CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setLoopback(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_PORT_LOOPBACK_T lbtype);

/* FUNCTION NAME:   hal_port_getLoopback
 * PURPOSE:
 *      This API is used to get the loopback for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_lbtype      --  Loopback type:
 *                          CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                          CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                          CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getLoopback(
    const   UI32_T              unit,
    const   UI32_T              port,
    CLX_PORT_LOOPBACK_T         *ptr_lbtype);

/* FUNCTION NAME:   hal_port_setLoopbackOutput
 * PURPOSE:
 *      This API is used to set the loopback output for a specific port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port ID
 *      enable      -- 1 for enable loopback and output, and
 *                     0 for disable loopback and output.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- The operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setLoopbackOutput(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

/* FUNCTION NAME:   hal_port_getLoopbackOutput
 * PURPOSE:
 *      This API is used to get the loopback output for a specific port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port ID
 * OUTPUT:
 *      ptr_enable  -- 1 for enable loopback and output, and
 *                     0 for disable loopback and output.
 * RETURN:
 *      CLX_E_OK            -- The operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getLoopbackOutput(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_enable);

/* FUNCTION NAME:   hal_port_probe
 * PURPOSE:
 *      This API is used to probe a specific port
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_probe(
    const   UI32_T              unit,
    const   UI32_T              port);

/* FUNCTION NAME:   hal_port_initPort
 * PURPOSE:
 *      This API is used to initialize a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_initPort(
    const   UI32_T              unit,
    const   UI32_T              port);

/* FUNCTION NAME:   hal_port_deinitPort
 * PURPOSE:
 *      This API is used to deinitialize a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_deinitPort(
    const   UI32_T              unit,
    const   UI32_T              port);

/* FUNCTION NAME:   hal_port_setLaneCnt
 * PURPOSE:
 *      This API is used to set the lane count for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      cnt             --  Lane count
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_setLaneCnt(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              cnt);

/* FUNCTION NAME:   hal_port_getLaneCnt
 * PURPOSE:
 *      This API is used to get the lane count for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_cnt         --  Lane count
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getLaneCnt(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_cnt);

/* FUNCTION NAME:   hal_port_setMacAddr
 * PURPOSE:
 *      This API is used to set the MAC address for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      mac             --  The MAC address.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_setMacAddr(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_MAC_T           mac);

/* FUNCTION NAME:   hal_port_getMacAddr
 * PURPOSE:
 *      This API is used to get the MAC address for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_mac         --  The MAC address.
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getMacAddr(
    const   UI32_T              unit,
    const   UI32_T              port,
    CLX_MAC_T                   *ptr_mac);

/* FUNCTION NAME:   hal_port_getLink
 * PURPOSE:
 *      This API is used to get the physical link status for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_link        --  Link status (Reference to CLX_PORT_LINK_XXX)
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getLink(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_link);

/* FUNCTION NAME:   hal_port_getFault
 * PURPOSE:
 *      This API is used to get the physical fault status for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_fault       --  Fault status (Reference to CLX_PORT_FAULT_XXX)
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getFault(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_fault);

/* FUNCTION NAME:   hal_port_setMediumType
 * PURPOSE:
 *      This API is used to set the medium type for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      medium          --  Medium type
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_setMediumType(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   CLX_PORT_MEDIUM_TYPE_T  medium);

/* FUNCTION NAME:   hal_port_getMediumType
 * PURPOSE:
 *      This API is used to get the medium type for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_medium      --  Medium type
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getMediumType(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    CLX_PORT_MEDIUM_TYPE_T          *ptr_medium);

/* FUNCTION NAME:   hal_port_setPhyProperty
 * PURPOSE:
 *      This API is used to set the PHY configuration for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      location        --  PHY location
 *      property        --  PHY property type
 *      value_cnt       --  PHY property value count
 *      ptr_value       --  PHY property value array
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_setPhyProperty(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   CLX_PORT_PHY_LOCATION_T location,
    const   CLX_PORT_PHY_PROPERTY_T property,
    const   UI32_T                  value_cnt,
    const   UI32_T                  *ptr_value);

/* FUNCTION NAME:   hal_port_getPhyProperty
 * PURPOSE:
 *      This API is used to get the property for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      location        --  PHY location
 *      property        --  PHY property type
 *      value_cnt       --  PHY property value count
 * OUTPUT:
 *      ptr_value       --  PHY property value array
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getPhyProperty(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   CLX_PORT_PHY_LOCATION_T location,
    const   CLX_PORT_PHY_PROPERTY_T property,
    const   UI32_T                  value_cnt,
    UI32_T                          *ptr_value);

/* FUNCTION NAME:   hal_port_setTxCoef
 * PURPOSE:
 *      Set all tx coefficients (CN2, CN1, C0, C1, C2) for a specific lane
 *      Note 1: different switch family supports different coefficient number
 *      Note 2: when summation of coefficient is overflow, C0 got reduction
 *      Note 3: partial coefficients configuration is allowed (flags within struct config is necessary)
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      lane_idx        --  lane offset within th port
 *      location        --  PHY location
 *      ptr_tx_coef     --  The tx coefficients applied to the specific lane
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_setTxCoef(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   UI32_T                  lane_idx,
    const   CLX_PORT_PHY_LOCATION_T location,
    CLX_PORT_TX_COEF_T              *ptr_tx_coef);

/* FUNCTION NAME:   hal_port_getTxCoef
 * PURPOSE:
 *      Set all tx coefficients (CN2, CN1, C0, C1, C2) for a specific lane
 *      Note 1: different switch family supports different coefficient number
 *      Note 2: flags within the struct indicates the coefficients supported in this switch family
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      lane_idx        --  lane offset within th port
 *      location        --  PHY location
 * OUTPUT:
 *      ptr_tx_coef     -- The tx coefficients applied to the specific lane
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getTxCoef(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   UI32_T                  lane_idx,
    const   CLX_PORT_PHY_LOCATION_T location,
    CLX_PORT_TX_COEF_T              *ptr_tx_coef);

/* FUNCTION NAME:   hal_port_setSrcSuppTag
 * PURPOSE:
 *      This API is used to set src_supp_tag in port module for setting service l2 intf property.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- port id
 * OUTPUT:
 *      ptr_value           -- source suppression tag value
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setSrcSuppTag(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        value);

/* FUNCTION NAME:   hal_port_getSrcSuppTag
 * PURPOSE:
 *      This API is used to get src_supp_tag in port module for setting service l2 intf property.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- port id
 * OUTPUT:
 *      ptr_value           -- source suppression tag value
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getSrcSuppTag(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    UI32_T              *ptr_value);

/* FUNCTION NAME:   hal_port_addSegServiceGroup
 * PURPOSE:
 *      This API is used to add a merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      merged_vid_min      -- Minimum value of merged vlan id
 *      merged_vid_max      -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
hal_port_addSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   hal_port_delSegServiceGroup
 * PURPOSE:
 *      This API is used to del a merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      merged_vid_min      -- Minimum value of merged vlan id
 *      merged_vid_max      -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
hal_port_delSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   hal_port_getSegServiceGroup
 * PURPOSE:
 *      This API is used to get a merged vlan group entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      port                  -- Physical port ID
 *      merged_vid_min        -- Minimum value of merged vlan id
 *      merged_vid_max        -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK              -- Entry exist
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
hal_port_getSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   hal_port_traverseSegServiceGroup
 * PURPOSE:
 *      This API is used to traverse merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      callback            -- The callback function of type CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_traverseSegServiceGroup(
    const UI32_T                                    unit,
    const CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T    callback,
    void                                            *ptr_cookie);

/* FUNCTION NAME:   hal_port_addSegService
 * PURPOSE:
 *      This API is used to add port seg service. It is called by clx_port_addSegService()
 * INPUT:
 *      unit                -- Device unit number
 *      intf                -- interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 *      ptr_seg_srv         -- segment service
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_addSegService(
    const UI32_T                 unit,
    const CLX_PORT_T             intf,
    const UI32_T                 seg0,
    const UI32_T                 seg1,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   hal_port_delSegService
 * PURPOSE:
 *      This API is used to del port seg service. It is called by clx_port_delSegService().
 * INPUT:
 *      unit                -- Device unit number
 *      intf                -- interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_delSegService(
    const UI32_T            unit,
    const CLX_PORT_T        intf,
    const UI32_T            seg0,
    const UI32_T            seg1);

/* FUNCTION NAME:   hal_port_getSegService
 * PURPOSE:
 *      This API is used to get port seg service. It is called by clx_port_getSegService().
 * INPUT:
 *      unit                -- Device unit number
 *      intf                -- interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 * OUTPUT:
 *      ptr_seg_srv         -- segment service
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getSegService(
    const UI32_T            unit,
    const CLX_PORT_T        intf,
    const UI32_T            seg0,
    const UI32_T            seg1,
    CLX_PORT_SEG_SRV_T     *ptr_seg_srv);

/* FUNCTION NAME:  hal_port_setPortDefault
 * PURPOSE:
 *      To apply default properties for the new created port
 * INPUT:
 *      unit                    --  Device unit number.
 *      port                    --  Port number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                --  Operate success.
 *      CLX_E_OTHER             --  Set port default fail.
 * NOTES:
  */
CLX_ERROR_NO_T
hal_port_setPortDefault(
    const UI32_T                unit,
    const UI32_T                port);

/* FUNCTION NAME:  hal_port_resetPortDefault
 * PURPOSE:
 *      To clear default properties for the destroyed port
 * INPUT:
 *      unit                    --  Device unit number.
 *      port                    --  Port number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                --  Operate success.
 *      CLX_E_OTHER             --  Reset port default fail.
 * NOTES:
  */
CLX_ERROR_NO_T
hal_port_resetPortDefault(
    const UI32_T                unit,
    const UI32_T                port);

/* FUNCTION NAME:  hal_port_init
 * PURPOSE:
 *      To initialize port module.
 * INPUT:
 *      unit                --  Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_OTHER         --  Init fail.
 * NOTES:
  */
CLX_ERROR_NO_T
hal_port_init(
    const   UI32_T              unit);

/* FUNCTION NAME: hal_port_deinit
 * PURPOSE:
 *     To deinitialize the port module.
 * INPUT:
 *     unit                 --  Device unit number
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK             --  success
 *     CLX_E_BAD_PARAMETER  --  bad parameter
 *     CLX_E_OTHERS         --  Deinitialization failed for other reasons.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_deinit(
    const UI32_T                unit);

/* FUNCTION NAME:   hal_port_setProperty
 * PURPOSE:
 *      Set Port property.
 * INPUT:
 *      unit            -- Device unit number
 *      port            -- Port ID
 *      property        -- Property type
 *      param0          -- First parameter
 *      param1          -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setProperty(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_PORT_PROPERTY_T property,
    const UI32_T            param0,
    const UI32_T            param1);

/* FUNCTION NAME:   hal_port_getProperty
 * PURPOSE:
 *      Get port property.
 * INPUT:
 *      unit            -- Device unit number
 *      port            -- Port ID
 *      property        -- Property type
 * OUTPUT:
 *      *ptr_param0     -- First parameter
 *      *ptr_param1     -- Second parameter
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getProperty(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_PORT_PROPERTY_T property,
    UI32_T                  *ptr_param0,
    UI32_T                  *ptr_param1);

/* FUNCTION NAME:   hal_port_getLaneMap
 * PURPOSE:
 *      This API is used to get the mapping between unit/port and mac/lane
 *      number.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_mac_macro   --  physical MAC macro ID
 *      ptr_lane        --  Physical lane ID
 *      ptr_max_speed   --  The maximum speed of the physical port
 *      ptr_flags       --  Attributes of the physical port
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_port_getLaneMap(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_mac_macro,
    UI32_T                      *ptr_lane,
    CLX_PORT_SPEED_T            *ptr_max_speed,
    UI32_T                      *ptr_flags);

/* FUNCTION NAME:   hal_port_createPort
 * PURPOSE:
 *      This API is used to create a UNIT_PORT interface object
 * INPUT:
 *      unit                -- Device unit number
 *      port_id             -- Port ID
 * OUTPUT:
 *      ptr_intf            -- The pointer of the UNIT_PORT interface object
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_createPort(
    const UI32_T                unit,
    const UI32_T                port,
    CLX_PORT_T                  *ptr_intf);

/* FUNCTION NAME:   hal_port_destroyPort(
 * PURPOSE:
 *      This API is used to destroy a UNIT_PORT interface object
 * INPUT:
 *      unit                -- Device unit number
 *      intf                -- The pointer of the UNIT_PORT interface object
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_destroyPort(
    const UI32_T                unit,
    CLX_PORT_T                  intf);

/* FUNCTION NAME:   hal_port_getPort
 * PURPOSE:
 *      This API is used to get a UNIT_PORT interface object
 * INPUT:
 *      unit                -- Device unit number
 *      port_id             -- Port ID
 * OUTPUT:
 *      ptr_port            -- The pointer of the UNIT_PORT interface object
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getPort(
    const UI32_T    unit,
    const UI32_T    port,
    CLX_PORT_T      *ptr_port);

/* FUNCTION NAME:   hal_port_setNativeIntfProperty
 * PURPOSE:
 *      This API is used to set the properties for a native interface
 * INPUT:
 *      unit                -- Device unit number
 *      plane_id            -- Plane ID
 *      native_intf         -- Native interface
 *      dir                 -- Direction
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setNativeIntfProperty(
    const UI32_T                    unit,
    const UI32_T                    plane_id,
    const UI32_T                    native_intf,
    const CLX_DIR_T                 dir,
    const CLX_PORT_INTF_PROPERTY_T  *ptr_property);

/* FUNCTION NAME:   hal_port_getNativeIntfProperty
 * PURPOSE:
 *      This API is used to set the properties for a native interface
 * INPUT:
 *      unit                -- Device unit number
 *      plane_id            -- Plane ID
 *      native_intf         -- Native interface
 *      dir                 -- Direction
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getNativeIntfProperty(
    const UI32_T                    unit,
    const UI32_T                    plane_id,
    const UI32_T                    native_intf,
    const CLX_DIR_T                 dir,
    CLX_PORT_INTF_PROPERTY_T        *ptr_property);

/* FUNCTION NAME:   hal_port_setLclIntfProperty
 * PURPOSE:
 *      This API is used to set the properties for a local interface
 * INPUT:
 *      unit                -- Device unit number
 *      plane_id            -- Plane ID
 *      lcl_intf            -- Local interface
 *      dir                 -- Direction
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setLclIntfProperty(
    const UI32_T                    unit,
    const UI32_T                    plane_id,
    const UI32_T                    lcl_intf,
    const CLX_DIR_T                 dir,
    const CLX_PORT_INTF_PROPERTY_T  *ptr_property);

/* FUNCTION NAME:   hal_port_getLclIntfProperty
 * PURPOSE:
 *      This API is used to set the properties for a local interface
 * INPUT:
 *      unit                -- Device unit number
 *      plane_id            -- Plane ID
 *      lcl_intf            -- Local interface
 *      dir                 -- Direction
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getLclIntfProperty(
    const UI32_T                    unit,
    const UI32_T                    plane_id,
    const UI32_T                    lcl_intf,
    const CLX_DIR_T                 dir,
    CLX_PORT_INTF_PROPERTY_T        *ptr_property);

/* FUNCTION NAME:   hal_port_setIntfProperty
 * PURPOSE:
 *      This API is used to set the properties for a specific interface object
 * INPUT:
 *      unit                -- Device unit number
 *      intf                -- Interface object
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setIntfProperty(
    const UI32_T                    unit,
    const CLX_PORT_T                intf,
    const CLX_PORT_INTF_PROPERTY_T  *ptr_property);

/* FUNCTION NAME:   hal_port_getIntfProperty
 * PURPOSE:
 *      This API is used to set the properties for a specific interface object
 * INPUT:
 *      unit                -- Device unit number
 *      intf                -- Interface object
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getIntfProperty(
    const UI32_T                    unit,
    const CLX_PORT_T                intf,
    CLX_PORT_INTF_PROPERTY_T        *ptr_property);

/* FUNCTION NAME:   hal_port_setTsState
 * PURPOSE:
 *      Set port timestamp state.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      enable              --  Timestamp state.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setTsState(
    const UI32_T                unit,
    const UI32_T                port,
    const UI32_T                enable);

/* FUNCTION NAME:   hal_port_getTsState
 * PURPOSE:
 *      Get port timestamp state.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      ptr_enable          --  Timestamp state
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getTsState(
    const UI32_T                unit,
    const UI32_T                port,
    UI32_T                      *ptr_enable);

/* FUNCTION NAME:   hal_port_getTsTxEntry
 * PURPOSE:
 *      Get port tx time stamp entry information.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      ptr_ts_entry        --  Time stamp entry information
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getTsTxEntry(
    const UI32_T                unit,
    const UI32_T                port,
    CLX_PORT_TS_ENTRY_T         *ptr_ts_entry);

/* FUNCTION NAME:   hal_port_getTsRxEntry
 * PURPOSE:
 *      Get port rx time stamp entry information.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      ptr_ts_entry        --  Time stamp entry information
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getTsRxEntry(
    const UI32_T                unit,
    const UI32_T                port,
    CLX_PORT_TS_ENTRY_T         *ptr_ts_entry);

/* FUNCTION NAME:   hal_port_setTsLatency
 * PURPOSE:
 *      Set port rx/tx TS latency based on clock, port speed and FEC.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_updateTsLatency(
    const UI32_T                unit,
    const UI32_T                port);

/* FUNCTION NAME:   hal_port_setUnidirectionalLink
 * PURPOSE:
 *      Set unidirectional link feature per physical port.
 * INPUT:
 *      unit        -- Device unit number.
 *      port        -- Physical port id.
 *      enable      -- 1 for enable unidirectional link, and
 *                     0 for disable unidirectional link.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_setUnidirectionalLink(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

/* FUNCTION NAME:   hal_port_getUnidirectionalLink
 * PURPOSE:
 *      Get unidirectional link feature per physical port.
 * INPUT:
 *      unit        -- Device unit number.
 *      port        -- Physical port id.
 * OUTPUT:
 *      ptr_enable  -- 1 for enable unidirectional link, and
 *                     0 for disable unidirectional link.
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getUnidirectionalLink(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_enable);

/* FUNCTION NAME:   hal_port_getPortType
 * PURPOSE:
 *      Get port type.
 *      This API is used to lookup corresponding database to get its key.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 * OUTPUT:
 *      ptr_type            -- type of CLX_PORT_TYPE_T
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getPortType(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    CLX_PORT_TYPE_T     *ptr_type);

/* FUNCTION NAME:   hal_port_setTxState
 * PURPOSE:
 *      Set tx state per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      enable      -- 1: enable tx state
 *                     0: disable tx state
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setTxState(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

/* FUNCTION NAME:   hal_port_getTxState
 * PURPOSE:
 *      Get tx state per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      ptr_enable  -- 1: tx state is enalbed
 *                     0: tx state is disabled
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getTxState(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_enable);

/* FUNCTION NAME:   hal_port_setRxState
 * PURPOSE:
 *      Set rx state per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      enable      -- 1: enable rx state
 *                     0: disable rx state
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setRxState(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

/* FUNCTION NAME:   hal_port_getRxState
 * PURPOSE:
 *      Get rx state per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      ptr_enable  -- 1: rx state is enalbed
 *                     0: rx state is disabled
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getRxState(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_enable);

/* FUNCTION NAME:   hal_port_enableTxState
 * PURPOSE:
 *      To enable the tx state for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_enableTxState(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_port_enableRxState
 * PURPOSE:
 *      To enable the rx state for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_enableRxState(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_port_disableTxState
 * PURPOSE:
 *      To disable the tx state for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_disableTxState(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_port_disableRxState
 * PURPOSE:
 *      To disable the rx state for a specific port.
 * INPUT:
 *      unit    --  Device unit number.
 *      port    --  Physical port id.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_disableRxState(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_port_setLed
 * PURPOSE:
 *      This API is used to set led state for a specific port.
 * INPUT:
 *      unit        -- Device unit number.
 *      port        -- Physical port id.
 *      enable      -- 1 for enable led, and
 *                     0 for disable led.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setLed(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

/* FUNCTION NAME:   hal_port_setMxLink
 * PURPOSE:
 *      Set mx link per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      enable      -- 1: enable mx link
 *                     0: disable mx link
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setMxLink(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

/* FUNCTION NAME:   hal_port_getMxLink
 * PURPOSE:
 *      Get mx link per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      ptr_enable  -- 1: mx link is enalbed
 *                     0: mx link is disabled
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getMxLink(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_enable);

/* FUNCTION NAME:   hal_port_setMibMaxLen
 * PURPOSE:
 *      Set max length of mib counter per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      max_len     -- Max length of mib counter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      When packet length is larger than the max length, it will be counted to
 *      over-size counter. For example, if MIB_MAX_LENGTH = 2000,
 *      for packet with 1518 < length <= 2000, it will be counted to
 *      MIB SRAM register of 1519_2560. And for packet length > 2000,
 *      it will be counted to oversize_good or oversize_bad counter.
 */
CLX_ERROR_NO_T
hal_port_setMibMaxLen(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    max_len);

/* FUNCTION NAME:   hal_port_getMibMaxLen
 * PURPOSE:
 *      Get max length of mib counter per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 * OUTPUT:
 *      ptr_max_len -- Max length of mib counter
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getMibMaxLen(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_max_len);

/* FUNCTION NAME:   hal_port_getStatus
 * PURPOSE:
 *      Get the status per physical port.
 * INPUT:
 *      unit       -- Device unit number
 *      port       -- Physical port id
 * OUTPUT:
 *      ptr_status -- Port status
 *                    speed  - reference to CLX_PORT_SPEED_T
 *                    link   - reference to CLX_PORT_LINK_XXX
 *                    fault  - reference to CLX_PORT_FAULT_XXX
 *                    rx_fc  - reference to CLX_PORT_FC_STATUS_XXX
 *                    rx_pfc - reference to CLX_PORT_FC_STATUS_XXX
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      There is 8 bits for 8 RX priority flow control status in rx_pfc.
 *      RX flow control status for priority x (x = 0~7) =
 *      rx_pfc & (CLX_PORT_FC_STATUS_ON << x)
 */
CLX_ERROR_NO_T
hal_port_getStatus(
    const UI32_T         unit,
    const UI32_T         port,
    CLX_PORT_STATUS_T    *ptr_status);

/* FUNCTION NAME:   hal_port_txRemoteFault
 * PURPOSE:
 *      Force to transmit remote fault out.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_txRemoteFault(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          enable);

/* FUNCTION NAME:   hal_port_dumpDb
 * PURPOSE:
 *      Dump the database per physical port.
 * INPUT:
 *      unit       -- Device unit number
 *      flags      -- Database type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_dumpDb(
    const UI32_T    unit,
    const UI32_T    flags);

/* FUNCTION NAME:   hal_port_enableHubLmIntr
 * PURPOSE:
 *      This API is used to enable hub logic memory interrupt
 * INPUT:
 *      unit                -- Device unit number
 *      port_id             -- Port ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_enableHubLmIntr(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_port_getPhyAnLt
 * PURPOSE:
 *      To get the autonegotiation status for a specific port.
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  Physical port id.
 * OUTPUT:
 *      ptr_anlt        --  Toggle status of autonegotiation-linktraining per port.
 * RETURN:
 *      CLX_E_OK                --  The operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_port_getPhyAnLt(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_anlt);

/* FUNCTION NAME:   hal_port_setMacProperty
 * PURPOSE:
 *      Set Mac property per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      property    -- Mac property type
 *      ptr_value   -- Mac property value
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setMacProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const HAL_MAC_PROPERTY_T    property,
    const UI32_T                value);

/* FUNCTION NAME:   hal_port_getMacProperty
 * PURPOSE:
 *      Get MAC property per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      property    -- Mac property type
 * OUTPUT:
 *      ptr_value   -- Mac property value
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getMacProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const HAL_MAC_PROPERTY_T    property,
    UI32_T                      *ptr_value);

/* FUNCTION NAME:   hal_port_setSynceMode
 * PURPOSE:
 *      Set SyncE state per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      mode        -- SyncE mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setSynceMode(
    const UI32_T                   unit,
    const UI32_T                   port,
    const CLX_PORT_SYNCE_MODE_T    mode);

/* FUNCTION NAME:   hal_port_getSynceMode
 * PURPOSE:
 *      Get SyncE mode per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 * OUTPUT:
 *      ptr_mode    -- SyncE mode
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getSynceMode(
    const UI32_T             unit,
    const UI32_T             port,
    CLX_PORT_SYNCE_MODE_T    *ptr_mode);

/* FUNCTION NAME:   hal_port_setPpProperty
 * PURPOSE:
 *      Set PP property per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      property    -- PP property type
 *      param0      -- First parameter
 *      param1      -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setPpProperty(
    const UI32_T                    unit,
    const UI32_T                    port,
    const HAL_PORT_PP_PROPERTY_T    property,
    const UI32_T                    param0,
    const UI32_T                    param1);

/* FUNCTION NAME:   hal_port_getPpProperty
 * PURPOSE:
 *      Get PP property per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      property    -- PP property type
 * OUTPUT:
 *      *ptr_param0 -- First parameter
 *      *ptr_param1 -- Second parameter
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getPpProperty(
    const UI32_T                    unit,
    const UI32_T                    port,
    const HAL_PORT_PP_PROPERTY_T    property,
    UI32_T                          *ptr_param0,
    UI32_T                          *prt_param1);

/* FUNCTION NAME:   hal_port_setTsMacReplaceType
 * PURPOSE:
 *      Set mac replace type for time stamp.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      type        -- Mac replace type (reference CLX_PORT_TS_REPLACE_MAC_XXX)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setTsMacReplaceType(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    type);

/* FUNCTION NAME:   hal_port_getTsMacReplaceType
 * PURPOSE:
 *      Get mac replace type for time stamp.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 * OUTPUT:
 *      ptr_type    -- Mac replace type (reference CLX_PORT_TS_REPLACE_MAC_XXX)
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_getTsMacReplaceType(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_type);

/* FUNCTION NAME:   hal_port_getLinkDb
 * PURPOSE:
 *      This API is used to get link database for a specific port.
 * INPUT:
 *      unit -- Device unit number
 *      port -- Physical port id
 * OUTPUT:
 *      ptr_tx_state -- Tx state
 *      ptr_rx_state -- Rx state
 *      ptr_lfc_tx   -- Local flow control state
 *      ptr_pfc_tx   -- Priority flow control state
 * RETURN:
 *      CLX_E_OK -- Operate success
 * NOTES:
 *      There are 8 bits for 8 priority flow control state in pfc_tx.
 *      Tx flow control state for priority x (x = 0~7) = pfc_tx & (1 << x)
 */
CLX_ERROR_NO_T
hal_port_getLinkDb(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_tx_state,
    UI32_T          *ptr_rx_state,
    UI32_T          *ptr_lfc_tx,
    UI32_T          *ptr_pfc_tx);

/* FUNCTION NAME:   hal_port_setMxHdr
 * PURPOSE:
 *      Set MxHdr per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      enable      -- 1: enable MxHdr
 *                     0: disable MxHdr
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_NOT_SUPPORT   --  Not support MxLink
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_port_setMxHdr(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

/* FUNCTION NAME:   hal_port_getMxHdr
 * PURPOSE:
 *      Get MxHdr per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      ptr_enable  -- 1: MxHdr is enalbed
 *                     0: MxHdr is disabled
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_NOT_SUPPORT   --  Not support MxLink
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */

CLX_ERROR_NO_T
hal_port_getMxHdr(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_enable);

/* FUNCTION NAME:   hal_port_getAbility
 * PURPOSE:
 *      This API is used to get the ability for a specific port.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_ability     --  Port ability
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_port_getAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

CLX_ERROR_NO_T
hal_port_getAnEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_AUTO_NEG_TYPE_T        *an_en);

CLX_ERROR_NO_T
hal_port_setAnEn(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_PORT_AUTO_NEG_TYPE_T      an_en);

CLX_ERROR_NO_T
hal_port_getLinkTrngEn(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_PORT_LINK_TRAINING_T            *train_en);

CLX_ERROR_NO_T
hal_port_setLinkTrngEn(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        enable);

CLX_ERROR_NO_T
hal_port_getLinkTrngFailStatus(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_PORT_LINK_TRAINING_FAIL_T       *status);

CLX_ERROR_NO_T
hal_port_setAdverIntf(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        intf_type);

#endif  /* #ifndef HAL_PORT_H */
