/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_ecc.h
 * PURPOSE:
 *  Provide HAL ECC manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_ECC_H
#define HAL_ECC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_swc.h>
#include <hal/common/hal_io.h>
#include <hal/common/hal_intr.h>
#include <dcc/dcc_dma.h>
#include <osal/osal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_ECC_LOG_NUM                        (128)
#define HAL_ECC_HUB_LM_NUM_MAX                 (140)
#define HAL_ECC_TABLE_INST_MAX                 (8)
#define HAL_ECC_LOG_FILTER_INTERVAL_MICRO_SEC  (100000) /* default interval = 100ms (100000us) */

#define HAL_ECC_LM_LOG_ENTRY_WORDS_MAX         (124)
#define HAL_ECC_LM_PHY_ENTRY_WORDS_MAX         (128)
#define HAL_ECC_LM_PARITY_WORDS_MAX            (4)
#define HAL_ECC_RDATA_WORDS_MAX                (128)    /* max rdata words for tcam/sram */
#define HAL_ECC_LM_ATTR_NOT_USER_TABLE         (1U << 0)
#define HAL_ECC_LM_ATTR_NOT_CORRECTABLE        (1U << 1)
#define HAL_ECC_LM_ATTR_NOT_TESTABLE           (1U << 2)
#define HAL_ECC_TCAM_SCAN_USEC_MAX             (2500)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_ECC_GET_ECC_INFO_PTR(__unit__)                                 \
    (_ext_chip_control_block[(__unit__)].ptr_driver_info->ptr_ecc_info)

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_ECC_INJECT_SERR_0,
    HAL_ECC_INJECT_DERR_0,
    HAL_ECC_INJECT_SERR_1,
    HAL_ECC_INJECT_DERR_1,
    HAL_ECC_INJECT_INTR_TEST,
    HAL_ECC_INJECT_LAST,
} HAL_ECC_INJECT_T;

typedef enum
{
    HAL_ECC_SERDES_MAC_ETHX_MAC_EGRTS_FIFO,
    HAL_ECC_SERDES_MAC_ETHX_MAC_MIB_FIFO,
    HAL_ECC_SERDES_MAC_ETHL_MAC_EGRTS_FIFO,
    HAL_ECC_SERDES_MAC_ETHL_MAC_MIB_FIFO,
    HAL_ECC_SERDES_MAC_LAST,
} HAL_ECC_SERDES_MAC_MEMORY_T;

typedef struct
{
    UI32_T    derr_cnt;
    UI32_T    serr_cnt;
    UI32_T    test_intr_cnt;
    UI32_T    correct_cnt;
} HAL_ECC_CNT_INFO_T;

typedef struct
{
    UI32_T                hub_id; /* key */
    HAL_ECC_CNT_INFO_T    cnt_info;
    HAL_ECC_CNT_INFO_T    logical_mem_cnt_info_arr[HAL_ECC_HUB_LM_NUM_MAX];
} HAL_ECC_HUB_CNT_INFO_T;

typedef struct
{
    UI32_T                table_id;     /* key : share_table_id */
    UI32_T                log_table_id; /* table_id from hubToTbl map */
    HAL_ECC_CNT_INFO_T    inst_cnt_info[HAL_ECC_TABLE_INST_MAX];
} HAL_ECC_TBL_CNT_INFO_T;

typedef struct
{
    BOOL_T                      valid;
    OSAL_TM_T                   time;
    OSAL_TIMESPEC_T             timespec;
    UI32_T                      hub_id;                 /* invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_HUB */
    UI32_T                      logical_mem;            /* invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_MEMORY */
    UI32_T                      serr_addr;
    UI32_T                      derr_addr;

    UI32_T                      inst;
    UI32_T                      sub_inst;
    UI32_T                      table_id;               /* invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_TABLE_ID */
    UI32_T                      serr_table_entry_start;
    UI32_T                      serr_table_entry_end;
    UI32_T                      derr_table_entry_start;
    UI32_T                      derr_table_entry_end;

    UI32_T                      serr_cnt;
    UI32_T                      derr_cnt;
    UI32_T                      test_intr_cnt;

    CLX_SWC_ECC_CORRECTION_T    serr_correction;
    CLX_SWC_ECC_CORRECTION_T    derr_correction;

    UI32_T                      rdata[HAL_ECC_RDATA_WORDS_MAX];
} HAL_ECC_LOG_INFO_T;

typedef struct
{
    OSAL_TM_T    time;

    UI32_T       sram_hub_id;
    UI32_T       sram_logical_mem;    /* invalid : HAL_INVALID_ID */
    UI32_T       sram_serr_addr;
    UI32_T       sram_derr_addr;

    UI32_T       tcam_inst;
    UI32_T       tcam_sub_inst;
    UI32_T       tcam_table_id;
    UI32_T       tcam_serr_entry;
    UI32_T       tcam_derr_entry;

    UI32_T       serr_cnt;
    UI32_T       derr_cnt;
    UI32_T       test_intr_cnt;

    UI32_T       rdata[HAL_ECC_RDATA_WORDS_MAX];

#define HAL_ECC_UPDATE_DB_INFO_FLAGS_BD_ACCESS    (1U << 0)
#define HAL_ECC_UPDATE_DB_INFO_FLAGS_TCAM         (1U << 1)
    UI32_T flags;
} HAL_ECC_UPDATE_DB_INFO_T;

typedef struct
{
    UI32_T    logical_mem_num;
} HAL_ECC_HUB_INFO_T;

typedef struct
{
    UI32_T    entry_num;
    UI32_T    entry_bits;
    UI32_T    entry_phy_bits;

#define HAL_ECC_LOGICAL_MEM_SUPPORT_ECC  (1U << 0)
    UI32_T    flags;
} HAL_ECC_LOGICAL_MEM_INFO_T;

typedef CLX_ERROR_NO_T
(*HAL_ECC_TRAVERSE_HUB_CNT_FUNC_T)(
    const UI32_T                    unit,
    const HAL_ECC_HUB_CNT_INFO_T    *ptr_info,
    void                            *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_ECC_TRAVERSE_TBL_CNT_FUNC_T)(
    const UI32_T                    unit,
    const HAL_ECC_TBL_CNT_INFO_T    *ptr_info,
    void                            *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_ECC_INIT_SRAM_FUNC_T) (
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

typedef CLX_ERROR_NO_T
(*HAL_ECC_DEINIT_SRAM_FUNC_T) (
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

typedef CLX_ERROR_NO_T
(*HAL_ECC_HANDLEHUBINTR_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id);

typedef CLX_ERROR_NO_T
(*HAL_ECC_HANDLEINTR_FUNC_T) (
    const UI32_T             unit,
    const HAL_INTR_TYPE_T    intr_type);

typedef CLX_ERROR_NO_T
(*HAL_ECC_HANDLEMPSRAMINTR_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    mpsram);

typedef CLX_ERROR_NO_T
(*HAL_ECC_GETHUBINFO_FUNC_T) (
    const UI32_T          unit,
    const UI32_T          hub_id,
    HAL_ECC_HUB_INFO_T    *ptr_info);

typedef CLX_ERROR_NO_T
(*HAL_ECC_GETLOGICALMEMINFO_FUNC_T) (
    const UI32_T                  unit,
    const UI32_T                  hub_id,
    const UI32_T                  logical_mem,
    HAL_ECC_LOGICAL_MEM_INFO_T    *ptr_info);

typedef const C8_T*
(*HAL_ECC_GETHUBNAME_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id);

typedef CLX_ERROR_NO_T
(*HAL_ECC_ENABLESERDESPCSINTR_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    lane_cnt);

typedef CLX_ERROR_NO_T
(*HAL_ECC_ENABLESERDESMACINTR_FUNC_T) (
    const UI32_T                         unit,
    const HAL_ECC_SERDES_MAC_MEMORY_T    type,
    const UI32_T                         inst_idx,
    const UI32_T                         subinst_idx);

typedef CLX_ERROR_NO_T
(*HAL_ECC_INJECTHUBINTR_FUNC_T) (
    const UI32_T              unit,
    const UI32_T              hub_id,
    const UI32_T              logical_mem,
    const HAL_ECC_INJECT_T    type);

typedef CLX_ERROR_NO_T
(*HAL_ECC_BDREAD_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    entry,
    UI32_T          *ptr_entry,
    UI32_T          *ptr_dbl_ecc_error);

typedef CLX_ERROR_NO_T
(*HAL_ECC_BDWRITE_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    entry,
    const UI32_T    inject,
    const UI32_T    *ptr_entry);

typedef CLX_ERROR_NO_T
(*HAL_ECC_BDCORRECT_SINGLE_BIT_ERR_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    entry);

typedef CLX_ERROR_NO_T
(*HAL_ECC_ENABLE_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    lm_id,
    const UI32_T    en);

typedef CLX_ERROR_NO_T
(*HAL_ECC_ENABLELOGECCBYP_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    en);

typedef CLX_ERROR_NO_T
(*HAL_ECC_READPARITY_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    UI32_T          *ptr_parity);

typedef CLX_ERROR_NO_T
(*HAL_ECC_WRITEPARITY_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    *ptr_parity);

typedef CLX_ERROR_NO_T
(*HAL_ECC_TRANSPHYENTRYTOLOG_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    *ptr_phy_entry,
    UI32_T          *ptr_log_entry);

typedef CLX_ERROR_NO_T
(*HAL_ECC_GETHUBINFOBYTBL_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    tbl_entry_idx,
    UI32_T          *ptr_hub_id,
    UI32_T          *ptr_lm_id,
    UI32_T          *ptr_lm_merge,
    UI32_T          *ptr_lm_attr,
    UI32_T          *ptr_lm_entry_idx);

typedef CLX_ERROR_NO_T
(*HAL_ECC_GETTBLBYHUBINFO_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    lm_id,
    const UI32_T    lm_entry_idx,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_lm_merge,
    UI32_T          *ptr_lm_attr,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_tbl_entry_idx);

typedef CLX_ERROR_NO_T
(*HAL_ECC_GETECCBYPBYHUBINFO_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    lm_id,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_field_id_0,
    UI32_T          *ptr_field_id_1);

typedef CLX_ERROR_NO_T
(*HAL_ECC_INITTCAM_FUNC_T) (
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

typedef CLX_ERROR_NO_T
(*HAL_ECC_DEINITTCAM_FUNC_T) (
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

typedef CLX_ERROR_NO_T
(*HAL_ECC_SETTCAMPARITY_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    entry_idx,
    const UI32_T    *ptr_entry);

typedef CLX_ERROR_NO_T
(*HAL_ECC_COPYTCAMPARITY_FUNC_T) (
    const UI32_T               unit,
    const UI32_T               inst,
    const UI32_T               sub_inst,
    const UI32_T               tbl_id,
    const UI32_T               src_entry_idx,
    const UI32_T               dst_entry_idx,
    const DCC_DMA_D2D_DIR_T    dir,
    const UI32_T               entry_num);

typedef CLX_ERROR_NO_T
(*HAL_ECC_HANDLETCAMINTR_FUNC_T) (
    const UI32_T             unit,
    const HAL_INTR_TYPE_T    intr_type);

typedef CLX_ERROR_NO_T
(*HAL_ECC_CHECKTCAM_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    tbl_entry_idx,
    const UI32_T    entry_num,
    UI32_T          *ptr_ecc_found);

typedef CLX_ERROR_NO_T
(*HAL_ECC_ENABLETCAM_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    tip,
    const UI32_T    en);

typedef CLX_ERROR_NO_T
(*HAL_ECC_GETTIPINFOBYTBL_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    tbl_entry_idx,
    UI32_T          *ptr_tip);

typedef CLX_ERROR_NO_T
(*HAL_ECC_GETTBLBYTIPINFO_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    tip,
    const UI32_T    tip_entry,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_tbl_entry_idx);

typedef CLX_ERROR_NO_T
(*HAL_ECC_GETECCBYPBYTIPINFO_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    tip,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_field_id_0,
    UI32_T          *ptr_field_id_1); /* HAL_INVALID_ID : invalid */

typedef struct
{
    /* sram ecc */
    HAL_ECC_INIT_SRAM_FUNC_T                   init_sram_func;
    HAL_ECC_DEINIT_SRAM_FUNC_T                 deinit_sram_func;
    HAL_ECC_HANDLEHUBINTR_FUNC_T               handle_hub_intr_func;
    HAL_ECC_HANDLEINTR_FUNC_T                  handle_intr_func;
    HAL_ECC_HANDLEMPSRAMINTR_FUNC_T            handle_mpsram_intr_func;
    HAL_ECC_GETHUBINFO_FUNC_T                  get_hub_info_func;
    HAL_ECC_GETLOGICALMEMINFO_FUNC_T           get_logical_mem_info_func;
    HAL_ECC_GETHUBNAME_FUNC_T                  get_hub_name_func;
    HAL_ECC_ENABLESERDESPCSINTR_FUNC_T         enable_serdes_pcs_intr_func;
    HAL_ECC_ENABLESERDESMACINTR_FUNC_T         enable_serdes_mac_intr_func;
    HAL_ECC_INJECTHUBINTR_FUNC_T               inject_intr_func;
    HAL_ECC_BDREAD_FUNC_T                      bdread_func;
    HAL_ECC_BDWRITE_FUNC_T                     bdwrite_func;
    HAL_ECC_BDCORRECT_SINGLE_BIT_ERR_FUNC_T    bdcorrect_single_bit_err_func;
    HAL_ECC_ENABLE_FUNC_T                      enable_func;
    HAL_ECC_ENABLELOGECCBYP_FUNC_T             enable_log_eccbyp_func;
    HAL_ECC_READPARITY_FUNC_T                  read_parity_func;
    HAL_ECC_WRITEPARITY_FUNC_T                 write_parity_func;
    HAL_ECC_TRANSPHYENTRYTOLOG_FUNC_T          trans_phy_entry_to_log_func;
    HAL_ECC_GETHUBINFOBYTBL_FUNC_T             get_hub_info_by_tbl_func;
    HAL_ECC_GETTBLBYHUBINFO_FUNC_T             get_tbl_by_hub_info_func;
    HAL_ECC_GETECCBYPBYHUBINFO_FUNC_T          get_eccbyp_by_hub_info_func;
    /* tcam ecc */
    HAL_ECC_INITTCAM_FUNC_T                    init_tcam_func;
    HAL_ECC_DEINITTCAM_FUNC_T                  deinit_tcam_func;
    HAL_ECC_SETTCAMPARITY_FUNC_T               set_tcam_parity_func;
    HAL_ECC_COPYTCAMPARITY_FUNC_T              copy_tcam_parity_func;
    HAL_ECC_HANDLETCAMINTR_FUNC_T              handle_tcam_intr_func;
    HAL_ECC_CHECKTCAM_FUNC_T                   check_tcam_func;
    HAL_ECC_ENABLETCAM_FUNC_T                  enable_tcam_func;
    HAL_ECC_GETTIPINFOBYTBL_FUNC_T             get_tip_info_by_tbl_func;
    HAL_ECC_GETTBLBYTIPINFO_FUNC_T             get_tbl_by_tip_info_func;
    HAL_ECC_GETECCBYPBYTIPINFO_FUNC_T          get_eccbyp_by_tip_info_func;
} HAL_ECC_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/************************************
 * SRAM ECC DISPATCH API
 ************************************/
CLX_ERROR_NO_T
hal_ecc_initSram(
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

CLX_ERROR_NO_T
hal_ecc_deinitSram(
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

CLX_ERROR_NO_T
hal_ecc_handleHubIntr(
    const UI32_T    unit,
    const UI32_T    hub_id);

CLX_ERROR_NO_T
hal_ecc_handleIntr(
    const UI32_T             unit,
    const HAL_INTR_TYPE_T    intr_type);

CLX_ERROR_NO_T
hal_ecc_handleMpsramIntr(
    const UI32_T    unit,
    const UI32_T    mpsram);

CLX_ERROR_NO_T
hal_ecc_getHubInfo(
    const UI32_T          unit,
    const UI32_T          hub_id,
    HAL_ECC_HUB_INFO_T    *ptr_info);

CLX_ERROR_NO_T
hal_ecc_getLogicalMemInfo(
    const UI32_T                  unit,
    const UI32_T                  hub_id,
    const UI32_T                  logical_mem,
    HAL_ECC_LOGICAL_MEM_INFO_T    *ptr_info);

const C8_T*
hal_ecc_getHubName(
    const UI32_T    unit,
    const UI32_T    hub_id);

CLX_ERROR_NO_T
hal_ecc_enableSerdesPCSIntr(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    lane_cnt);

CLX_ERROR_NO_T
hal_ecc_enableSerdesMacIntr(
    const UI32_T                         unit,
    const HAL_ECC_SERDES_MAC_MEMORY_T    type,
    const UI32_T                         inst_idx,
    const UI32_T                         subinst_idx);

CLX_ERROR_NO_T
hal_ecc_injectIntr(
    const UI32_T              unit,
    const UI32_T              hub_id,
    const UI32_T              logical_mem,
    const HAL_ECC_INJECT_T    type);

/* bd read lm entry
 * CL8360 : log_entry (data), non CL8360 : phy_entry(data+parity)
 */
CLX_ERROR_NO_T
hal_ecc_bdRead(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    entry,
    UI32_T          *ptr_entry,
    UI32_T          *ptr_dbl_ecc_error); /* non CL8360 : not support */

/* bd write lm entry
 * CL8360 : log_entry (data), non CL8360 : phy_entry(data+parity)
 */
CLX_ERROR_NO_T
hal_ecc_bdWrite(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    entry,
    const UI32_T    inject,      /* non CL8360 : not support */
    const UI32_T    *ptr_entry);

CLX_ERROR_NO_T
hal_ecc_bdCorrectSingleBitErr(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    entry);

CLX_ERROR_NO_T
hal_ecc_enable(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    lm_id,
    const UI32_T    en);

/* enable/disable eccbyp mode for errlog_rdata (and would clear errlog_rdata)
 */
CLX_ERROR_NO_T
hal_ecc_enableLogEccbyp(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    en);

/* read parity from errlog_rdata
 * (must enable eccbyp, and trigger fd read before calling this api)
 */
CLX_ERROR_NO_T
hal_ecc_readParity(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    UI32_T          *ptr_parity);

/* write parity to hw temp parity mem
 * (must enable eccbyp, and use fd write to trigger real-write parity to hw after calling this api)
 */
CLX_ERROR_NO_T
hal_ecc_writeParity(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    *ptr_parity);

CLX_ERROR_NO_T
hal_ecc_transPhyEntryToLog(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    logical_mem,
    const UI32_T    *ptr_phy_entry,
    UI32_T          *ptr_log_entry);

CLX_ERROR_NO_T
hal_ecc_getHubInfoByTbl(
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    tbl_entry_idx,
    UI32_T          *ptr_hub_id,
    UI32_T          *ptr_lm_id,
    UI32_T          *ptr_lm_merge,
    UI32_T          *ptr_lm_attr, /* HAL_ECC_LM_ATTR_XXX */
    UI32_T          *ptr_lm_entry_idx);

CLX_ERROR_NO_T
hal_ecc_getTblByHubInfo(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    lm_id,
    const UI32_T    lm_entry_idx,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_lm_merge,
    UI32_T          *ptr_lm_attr, /* HAL_ECC_LM_ATTR_XXX */
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_tbl_entry_idx);

CLX_ERROR_NO_T
hal_ecc_getEccbypByHubInfo(
    const UI32_T    unit,
    const UI32_T    hub_id,
    const UI32_T    lm_id,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_field_id_0,
    UI32_T          *ptr_field_id_1); /* HAL_INVALID_ID : invalid */

/************************************
 * TCAM ECC DISPATCH API
 ************************************/
CLX_ERROR_NO_T
hal_ecc_initTcam(
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

CLX_ERROR_NO_T
hal_ecc_deinitTcam(
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

CLX_ERROR_NO_T
hal_ecc_setTcamParity(
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    entry_idx,
    const UI32_T    *ptr_entry);

CLX_ERROR_NO_T
hal_ecc_copyTcamParity(
    const UI32_T               unit,
    const UI32_T               inst,
    const UI32_T               sub_inst,
    const UI32_T               tbl_id,
    const UI32_T               src_entry_idx,
    const UI32_T               dst_entry_idx,
    const DCC_DMA_D2D_DIR_T    dir,
    const UI32_T               entry_num);

CLX_ERROR_NO_T
hal_ecc_handleTcamIntr(
    const UI32_T             unit,
    const HAL_INTR_TYPE_T    intr_type);

CLX_ERROR_NO_T
hal_ecc_checkTcam(
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    tbl_entry_idx,
    const UI32_T    entry_num,
    UI32_T          *ptr_ecc_found);

CLX_ERROR_NO_T
hal_ecc_enableTcam(
    const UI32_T    unit,
    const UI32_T    tip,
    const UI32_T    en);

CLX_ERROR_NO_T
hal_ecc_getTipInfoByTbl(
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    tbl_entry_idx,
    UI32_T          *ptr_tip);

CLX_ERROR_NO_T
hal_ecc_getTblByTipInfo(
    const UI32_T    unit,
    const UI32_T    tip,
    const UI32_T    tip_entry,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_tbl_entry_idx);

CLX_ERROR_NO_T
hal_ecc_getEccbypByTipInfo(
    const UI32_T    unit,
    const UI32_T    tip,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_field_id_0,
    UI32_T          *ptr_field_id_1); /* HAL_INVALID_ID : invalid */

/************************************
 * ECC COMMON API
 ************************************/
CLX_ERROR_NO_T
hal_ecc_init(
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

CLX_ERROR_NO_T
hal_ecc_deinit(
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

CLX_ERROR_NO_T
hal_ecc_getHubCnt(
    const UI32_T               unit,
    const UI32_T               hub_id,
    HAL_ECC_HUB_CNT_INFO_T    *ptr_info);

CLX_ERROR_NO_T
hal_ecc_traverseHubCnt(
    const UI32_T                             unit,
    const HAL_ECC_TRAVERSE_HUB_CNT_FUNC_T    callback,
    void                                     *ptr_cookie);

CLX_ERROR_NO_T
hal_ecc_clearHubCnt(
    const UI32_T    unit,
    const UI32_T    hub_id); /* HAL_INVALID_ID : clear all hub cnt */

CLX_ERROR_NO_T
hal_ecc_getTblCnt(
    const UI32_T              unit,
    const UI32_T              table_id,
    HAL_ECC_TBL_CNT_INFO_T    *ptr_info);

CLX_ERROR_NO_T
hal_ecc_traverseTblCnt(
    const UI32_T                             unit,
    const HAL_ECC_TRAVERSE_TBL_CNT_FUNC_T    callback,
    void                                     *ptr_cookie);

CLX_ERROR_NO_T
hal_ecc_clearTblCnt(
    const UI32_T    unit,
    const UI32_T    table_id); /* HAL_INVALID_ID : clear all table cnt */

CLX_ERROR_NO_T
hal_ecc_getLog(
    const UI32_T          unit,
    const UI32_T          entry_id,
    HAL_ECC_LOG_INFO_T    *ptr_info);

CLX_ERROR_NO_T
hal_ecc_clearLog(
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_ecc_updateDbAndNotify(
    const UI32_T                      unit,
    const HAL_ECC_UPDATE_DB_INFO_T    *ptr_info);

#endif  /* #ifndef HAL_ECC_H */
