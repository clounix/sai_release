/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_dtel.h
 * PURPOSE:
 *      It provides hal Dataplane telemetry module module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_LIGHTNING_DTEL_H
#define HAL_LIGHTNING_DTEL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_dtel.h>
#include <clx_port.h>
#include <clx_swc.h>
#include <hal/common/hal_tbl.h>
#include <hal/common/hal.h>
#include <hal/common/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_LIGHTNING_DTEL_DPP_IDX                        (1)
#define HAL_LIGHTNING_DTEL_IFA_IDX                        (0)
#define HAL_LIGHTNING_DTEL_IFA_MIR_ID_STEER               (0)
#define HAL_LIGHTNING_DTEL_IFA_CPU_ID_STEER               (0)
#define HAL_LIGHTNING_DTEL_IFA_MIR_EN_STEER               (1)
#define HAL_LIGHTNING_DTEL_IFA_CPU_EN_STEER               (1)

#define HAL_LIGHTNING_DTEL_IFA_VID_CTL                    (6)
#define HAL_LIGHTNING_DTEL_IFA_VID_1ST                    (0)
#define HAL_LIGHTNING_DTEL_IFA_VID_2ND                    (0)

#define HAL_LIGHTNING_DTEL_HBH_OPT_TYP_IOAM_TRACE         (0x3b)
#define HAL_LIGHTNING_DTEL_GRE_PROTO_IOAM_TRACE           (0Xffff)
#define HAL_LIGHTNING_DTEL_GPE_CL_IOAM_TRACE              (0x81)
#define HAL_LIGHTNING_DTEL_IOAM_OPT_CLS_IOAM              (0x0103)
#define HAL_LIGHTNING_DTEL_IOAM_TRACE_INCR_TYPE           (0x1)
#define HAL_LIGHTNING_DTEL_IOAM_MAX_NODE_LEN              (0xf)
#define HAL_LIGHTNING_DTEL_IOAM_FLAGS                     (0x0)
#define HAL_LIGHTNING_DTEL_IOAM_MAX_LEN                   (0x7f)
#define HAL_LIGHTNING_DTEL_IOAM_FLAGS_LEN                 (0x1f)
#define HAL_LIGHTNING_DTEL_IOAM_HOP_LIM                   (0xff)

#define HAL_LIGHTNING_DTEL_IOAM_OPQ_LEN_FIELD             (0xc)
#define HAL_LIGHTNING_DTEL_IOAM_OPQ_ID_LEN                (0Xffffff)
#define HAL_LIGHTNING_DTEL_IOAM_OPQ_LEN_OFFSET            (24)


#define HAL_LIGHTNING_DTEL_DPP_UDP_DP_LIM                 (0Xffff)
#define HAL_LIGHTNING_DTEL_DPP_V6_NHDR_LIM                (0Xff)


#define HAL_LIGHTNING_DTEL_IOAM_TRACE_TYPE_OFFSET         (16)
#define HAL_LIGHTNING_DTEL_IOAM_NODE_LEN_OFFSET           (12)
#define HAL_LIGHTNING_DTEL_IOAM_FLAGS_OFFSET              (7)

#define HAL_LIGHTNING_DTEL_IFA_HOP_LIM_OFFSET             (24)
#define HAL_LIGHTNING_DTEL_IFA_HOP_LIM                    (0xff)

#define HAL_LIGHTNING_DTEL_IFA_MAX_LEN_OFFSET             (16)
#define HAL_LIGHTNING_DTEL_IFA_CUR_LEN_OFFSET             (16)
#define HAL_LIGHTNING_DTEL_IFA_MAX_LEN_LIM                (0xffff)
#define HAL_LIGHTNING_DTEL_IFA_CUR_LEN_LIM                (0xffff)

#define HAL_LIGHTNING_DTEL_IFA_SEND_ID_OFFSET             (16)
#define HAL_LIGHTNING_DTEL_IFA_SEQ_ID_OFFSET              (16)
#define HAL_LIGHTNING_DTEL_IFA_SEND_ID_LIM                (0xffff)
#define HAL_LIGHTNING_DTEL_IFA_SEQ_NUM_LIM                (0xffff)

#define HAL_LIGHTNING_DTEL_IFA_SEND_SEQ_ENTRY             (6)
#define HAL_LIGHTNING_DTEL_IFA_MAX_CUR_ENTRY              (5)
#define HAL_LIGHTNING_DTEL_IFA_HOP_LIM_ENTRY              (4)

#define HAL_LIGHTNING_DTEL_IFA_HOP_ID_START               (1)
#define HAL_LIGHTNING_DTEL_IFA_HOP_ID_OFFSET              (16)


#define HAL_LIGHTNING_DTEL_IFA_OPQ_LEN_FIELD              (0x1F000000)
#define HAL_LIGHTNING_DTEL_IFA_OPQ_ID_LEN                 (0Xffff)

#define HAL_LIGHTNING_DTEL_DPP_PROFILE_NUM                (2)
#define HAL_LIGHTNING_DTEL_PORT_TRANS_PROFILE_ID          (0)

#define HAL_LIGHTNING_DTEL_DPP_LPBK_EXP_ENTRY             (2)
#define HAL_LIGHTNING_DTEL_DPP_LPBK_EXP_BIT               (6)


#define HAL_LIGHTNING_DTEL_IFA_MRK_PCP_DEI_EN             (0)
#define HAL_LIGHTNING_DTEL_IFA_MRK_PCP_VAL                (0)
#define HAL_LIGHTNING_DTEL_IFA_MRK_DEI_VAL                (0)

#define HAL_LIGHTNING_DTEL_DEFAULT_PROFILE_NUM            (0)

#define HAL_LIGHTNING_DTEL_IFA_TID_OFFSET                 (28)
#define HAL_LIGHTNING_DTEL_IFA_UD_0_OFFSET                (16)
#define HAL_LIGHTNING_DTEL_IFA_TID_LIM                    (0xf)
#define HAL_LIGHTNING_DTEL_IFA_UD_0_LIM                   (0xfff)
#define HAL_LIGHTNING_DTEL_IFA_UD_1_LIM                   (0xff)

#define HAL_LIGHTNING_DTEL_DPP_THRESHOLD                  (18)


typedef struct HAL_LIGHTNING_DTEL_CB_S
{
    CLX_SEMAPHORE_ID_T  dtel_sema;
} HAL_LIGHTNING_DTEL_CB_T;


/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_DTEL_LOCK(unit)                        (hal_lightning_dtel_lockResource(unit))
#define HAL_DTEL_UNLOCK(unit)                      (hal_lightning_dtel_unLockResource(unit))

/* DATA TYPE DECLARATIONS
 */

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_lightning_dtel_init(
    const   UI32_T          unit);

CLX_ERROR_NO_T
hal_lightning_dtel_deinit(
    const UI32_T                    unit);

CLX_ERROR_NO_T
hal_lightning_dtel_getPortProperty(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_PROPERTY_T       property,
    UI32_T                          *ptr_param0,
    UI32_T                          *ptr_param1);

CLX_ERROR_NO_T
hal_lightning_dtel_setPortProperty(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_PROPERTY_T       property,
    const UI32_T                    param0,
    const UI32_T                    param1);

CLX_ERROR_NO_T
hal_lightning_dtel_getProperty(
    const UI32_T                    unit,
    const CLX_SWC_PROPERTY_T        property,
    UI32_T                          *ptr_param0,
    UI32_T                          *ptr_param1);

CLX_ERROR_NO_T
hal_lightning_dtel_setProperty(
    const UI32_T                    unit,
    const CLX_SWC_PROPERTY_T        property,
    const UI32_T                    param0,
    const UI32_T                    param1);

CLX_ERROR_NO_T
hal_lightning_dtel_setDppLoopback(
    const UI32_T                unit,
    const CLX_DTEL_DPP_T        *ptr_dpp);

CLX_ERROR_NO_T
hal_lightning_dtel_getDppLoopback(
    const UI32_T                unit,
    CLX_DTEL_DPP_T              *ptr_dpp);

CLX_ERROR_NO_T
hal_lightning_dtel_getProfile(
    const UI32_T                unit,
    const UI32_T                profile_id,
    CLX_DTEL_CFG_T              *ptr_cfg);

CLX_ERROR_NO_T
hal_lightning_dtel_setProfile(
    const UI32_T                unit,
    const UI32_T                profile_id,
    const CLX_DTEL_CFG_T        *ptr_cfg);





#endif /*end of HAL_LIGHTNING_DTEL_H*/
