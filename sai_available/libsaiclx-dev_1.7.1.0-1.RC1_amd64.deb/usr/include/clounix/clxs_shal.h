#if !defined (__CLXS_SHAL_H_)
#define __CLXS_SHAL_H_

#define _SHAL_IS_DEVICE_LIGHTNING_FAMILY(unit)    HAL_IS_DEVICE_LIGHTNING_FAMILY(unit)  
#define _SHAL_IS_DEVICE_DAWN_FAMILY(unit)    HAL_IS_DEVICE_DAWN_FAMILY(unit)
#define _SHAL_GET_DI_FROM_LAG_ID(lag_id)    HAL_GET_DI_FROM_LAG_ID(lag_id) 
#define _SHAL_IP_TNL_FLEX_3    HAL_IP_TNL_FLEX_3
#define _SHAL_MAX_ENTRY_WORD_SIZE    HAL_MAX_ENTRY_WORD_SIZE
#define _SHAL_PORT_MAP_T    HAL_PORT_MAP_T
#define _SHAL_PTR_EXT_CHIP_INFO(unit)    PTR_HAL_EXT_CHIP_INFO(unit)
#define _SHAL_IS_UNIT_VALID(__unit__)    HAL_IS_UNIT_VALID(__unit__)
#define _SHAL_HW_CHIP_ID(unit)  HAL_HW_CHIP_ID(unit)
#define _SHAL_CL_PORT_TO_DI(__unit__, __chip__, __port__)    HAL_CL_PORT_TO_DI(__unit__, __chip__, __port__)
#define _SHAL_OBJ_CHK(__intf__)    HAL_OBJ_CHK(__intf__)
#define _SHAL_CPI_PORT(unit, cpi_idx)    HAL_CPI_PORT(unit, cpi_idx)
#define _SHAL_CPI_PORT_0    HAL_CPI_PORT_0
#define _SHAL_CPI_PORT_1    HAL_CPI_PORT_1
#define _SHAL_OBJ_DI_SET(__intf__, __id__)    HAL_OBJ_DI_SET(__intf__, __id__)
#define _SHAL_OBJ_TYPE_SET(__intf__, __id__)   HAL_OBJ_TYPE_SET(__intf__, __id__)
#define _SHAL_IS_CPI_PORT_ETH_MODE(unit, cpi_port)    HAL_IS_CPI_PORT_ETH_MODE(unit, cpi_port)
#define _SHAL_L3_PARAM_V4_V6    HAL_L3_PARAM_V4_V6
#define _SHAL_L3_PARAM_V4    HAL_L3_PARAM_V4
#define _SHAL_L3_PARAM_V6    HAL_L3_PARAM_V6

#define _SHAL_IO_SUB_HDR_T    HAL_IO_SUB_HDR_T
#define _SHAL_IO_OBJ_META_T    HAL_IO_OBJ_META_T
#define _SHAL_IO_WB_DB_T    HAL_IO_WB_DB_T

CLX_ERROR_NO_T
_shal_io_openNonvolatile(
    const UI32_T unit,
    const UI32_T write_mode);

CLX_ERROR_NO_T
_shal_io_closeNonvolatile(
    const UI32_T unit);

CLX_ERROR_NO_T
_shal_io_getNonvolatile(
    const UI32_T unit,
    const CLX_MODULE_T module,
    C8_T **pptr_buf,
    UI32_T *ptr_num_bytes);

CLX_ERROR_NO_T
_shal_io_saveAvlTree(
    const UI32_T           length,
    const CMLIB_AVL_HEAD_T *ptr_avl,
    _SHAL_IO_OBJ_META_T      *ptr_obj_meta);

CLX_ERROR_NO_T
_shal_io_restoreAvlTree(
    const UI32_T            length,
    const CMLIB_AVL_HEAD_T  *ptr_avl,
    const _SHAL_IO_OBJ_META_T *ptr_obj_meta);

CLX_ERROR_NO_T
_shal_io_saveList(
    const UI32_T       length,
    const CMLIB_LIST_T *ptr_list,
    _SHAL_IO_OBJ_META_T  *ptr_obj_meta);

CLX_ERROR_NO_T
_shal_io_restoreList(
    const UI32_T             length,
    const CMLIB_LIST_T       *ptr_list,
    const _SHAL_IO_OBJ_META_T  *ptr_obj_meta);

CLX_ERROR_NO_T
_shal_io_saveArray(
    const UI32_T       length,
    const UI32_T       count,
    const void         *ptr_array,
    _SHAL_IO_OBJ_META_T  *ptr_obj_meta);

CLX_ERROR_NO_T
_shal_io_restoreArray(
    void                    *ptr_array,
    const _SHAL_IO_OBJ_META_T *ptr_obj_meta);

CLX_ERROR_NO_T
_shal_io_createWbDb(
    UI32_T          obj_count,
    _SHAL_IO_WB_DB_T  **pptr_db);

CLX_ERROR_NO_T
_shal_io_addWbObj(
    _SHAL_IO_WB_DB_T      *ptr_db,
    UI32_T              obj_count,
    _SHAL_IO_OBJ_META_T   *ptr_objs);

CLX_ERROR_NO_T
_shal_io_writeWbDb(
    UI32_T          unit,
    CLX_MODULE_T    module,
    _SHAL_IO_WB_DB_T  *ptr_db);

void
_shal_io_destroyWbDb(
    _SHAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
_shal_io_readWbDb(
    UI32_T          unit,
    CLX_MODULE_T    module,
    _SHAL_IO_WB_DB_T  **pptr_db);

CLX_ERROR_NO_T
_shal_io_getWbObj(
    const HAL_IO_WB_DB_T *ptr_db,
    UI32_T               obj_id,
    _SHAL_IO_OBJ_META_T    *ptr_obj);

UI32_T
_shal_io_getDbVer(
    UI32_T unit);


CLX_ERROR_NO_T
_shal_dawn_tm_sch_setPortShaping(
    const UI32_T unit,
    const UI32_T port,
    const UI32_T max_bandwidth_rate,
    const UI32_T max_burst_size);

CLX_ERROR_NO_T
_shal_dawn_tm_setEnbState(
    const UI32_T unit,
    const UI32_T port,
    const CLX_DIR_T dir,
    const UI32_T all_queue,
    const CLX_TM_HANDLER_T handler,
    const UI32_T enable);



CLX_ERROR_NO_T
_shal_lightning_tm_sch_setPortShaping(
    const UI32_T unit,
    const UI32_T port,
    const UI32_T max_bandwidth_rate,
    const UI32_T max_burst_size);


sai_status_t 
_shal_set_udp_tunnel(
    uint32_t unit,
    uint32_t entry_id,
    uint32_t udp_port);

CLX_ERROR_NO_T 
_shal_vrf_ttl_1_excpt_init(
    const UI32_T    unit);

sai_status_t
_shal_vlan_setBdIpmcKey(
    _In_ const uint32_t                            unit,
    _In_ const uint32_t                            fdid,
    _In_ const bool                                is_ipv4,
    _In_ const sai_vlan_mcast_lookup_key_type_t    sai_key);

sai_status_t
_shal_vlan_getBdIpmcKey(
    _In_ const uint32_t                       unit,
    _In_ const uint32_t                       fdid,
    _In_ const bool                           is_ipv4,
    _Out_ sai_vlan_mcast_lookup_key_type_t    *ptr_sai_key);

sai_status_t 
_shal_get_port_stats_for_pfc_rx_pkts(
    uint32_t unit,
    uint32_t port,
	sai_stat_id_t counter_id,
	uint32_t index,
    _Out_ uint64_t *counters);

sai_status_t
_shal_bridge_setSysMissExcptAct(
    _In_ const uint32_t    unit,
    _In_ const bool        miss_excpt_drop);

sai_status_t 
_shal_set_erspan_ver(
    uint32_t unit,
    uint32_t entry_id,
    uint32_t ver_value);

sai_status_t 
_shal_set_mir_seg_vmid(
    uint32_t unit,
    uint32_t entry_id,
    uint32_t seg_vmid);

sai_status_t 
_shal_set_encap_tnl_type(
    uint32_t unit,
    uint32_t entry_id,
    uint32_t type);

#if SAI_VERSION_CODE >= SAI_VER(1,7,0)
sai_status_t 
_shal_set_sflow_udp_tunnel(
    uint32_t unit,
    uint32_t entry_id,
    uint32_t udp_port);
#endif

#endif /*__CLXS_SHAL_H_*/
