#if !defined (__CLNX_SAI_PORT_LINK_DELAY_H_)
#define __CLNX_SAI_PORT_LINK_DELAY_H_

#ifdef CLX_PORT_LINK_DELAY

#define CLNX_PORT_LINK_DELAY_THREAD_PRI           (50)
#define CLNX_PORT_LINK_DELAY_THREAD_NAME          "PORT_LINK_DELAY_THREAD"
#define CLNX_PORT_LINK_DELAY_THREAD_INTERVAL      (10)
#define CLNX_PORT_LINK_DELAY_THREAD_STACK_SIZE    (32 * 1024)

typedef struct  CLNX_PORT_LINK_DELAY_S
{
    uint32_t                upDelay; 
    uint32_t                downDelay;
    uint64_t                upTime;
    uint64_t                downTime;
    sai_port_oper_status_t  linkStatus;
#ifdef CLX_PORT_LINK_DELAY_CLXEXT
    uint32_t                upCnt; 
    uint32_t                downCnt;
#endif
} CLNX_PORT_LINK_DELAY_T;

typedef struct  CLNX_LINK_DELAY_S
{
    CLX_PORT_BITMAP_T       port_bmp;
    CLNX_PORT_LINK_DELAY_T  *port_link_delay_ptr;
    uint32_t                interval_us;
    CLX_THREAD_ID_T         thread_id;
    CLX_SEMAPHORE_ID_T      sema;
} CLNX_LINK_DELAY_T;

#define CLNX_PORT_LINK_DELAY_LOCK(unit) \
    clnx_sai_mutex_lock(_clnx_link_delay[unit].sema);

#define CLNX_PORT_LINK_DELAY_UNLOCK(unit) \
    clnx_sai_mutex_unlock(_clnx_link_delay[unit].sema);

#define CLNX_PORT_LINK_DELAY_PTR(__unit__, __port__)        ((CLNX_PORT_LINK_DELAY_T *)(_clnx_link_delay[__unit__].port_link_delay_ptr + __port__ ))

sai_status_t clnx_port_linkdelay_state_update(
        _In_ const uint32_t unit,
        _In_ const uint32_t port,
        _In_ const uint32_t link,
        _Out_   bool *ptr_linkdelay_en);

sai_status_t _clnx_port_setLinkUpDelayTime(
    _In_ const sai_object_key_t      *ptr_key,
    _In_ const sai_attribute_value_t *ptr_value,
    void                             *ptr_arg);

sai_status_t _clnx_port_setLinkDownDelayTime(
    _In_ const sai_object_key_t      *ptr_key,
    _In_ const sai_attribute_value_t *ptr_value,
    void                             *ptr_arg);

uint32_t clnx_port_linkdelay_get_upDelayTime(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

uint32_t clnx_port_linkdelay_get_downDelayTime(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

#ifdef CLX_PORT_LINK_DELAY_CLXEXT
uint32_t clnx_port_linkdelay_get_downCnt(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

uint32_t clnx_port_linkdelay_get_upCnt(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);
#endif

sai_status_t clnx_port_link_delay_initRsrc(
    _In_ const uint32_t unit);

sai_status_t clnx_port_link_delay_deinitRsrc(
    _In_ const uint32_t unit);

sai_status_t clnx_port_link_delay_initThread(
    _In_ const uint32_t     unit);

sai_status_t clnx_port_link_delay_destroyThread(
    _In_ const uint32_t     unit);

CLX_ERROR_NO_T _clnx_port_link_delay_diag_dump_cmd(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T _clnx_port_link_delay_diag_get_cmd(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T _clnx_port_link_delay_diag_set_cmd(
    _In_ const C8_T                *tokens[]);
#endif


#endif /* __CLNX_SAI_PORT_LINK_DELAY_H_ */