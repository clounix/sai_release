#define CLNX_SAI_COMMIT_ID "f732cc4ea8324ae4aa1d1d65311e0ce9130801df"
#define CLNX_SAI_GIT_BRANCH "v1.7_ks-dirty"
#define CLNX_SAI_BUILD_TIME "Thu Jun 16 10:01:21 UTC 2022"
#define CLNX_SDK_COMMIT_ID "b90376a236754027d0fddd2e50ed7a21b029e8da(clx_system_1.1.2_RC3)"
#define CLNX_SAI_BUILD_BY "yangjie-bj@7947fc785df6"
#define SAI_VERSION_CODE 67329
#define CLNX_SAI_HEAD_VERSION "1.7.1"
#define SAI_VER(a,b,c) (((a)<<16)+((b)<<8)+(c))
