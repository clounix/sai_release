#define CLNX_SAI_COMMIT_ID "07253fd814ef63fec1a0cae2c240ec0bc7635cc0"
#define CLNX_SAI_SRC_COMMIT_ID "e5b3b37f3393f08f2b71ec6534f23757364e85bf(v1.7.1.0-1.RC1-310-ge5b3b37)"
#define CLNX_SAI_GIT_BRANCH "master-dirty"
#define CLNX_SAI_BUILD_TIME "Sun Oct  9 04:39:35 UTC 2022"
#define CLNX_SDK_COMMIT_ID "cb8625649228a309de28ad0969b6ba3ed2b933ba(clx_system_1.2.1)"
#define CLNX_SAI_BUILD_BY "fanlp@aa99d2162319"
#define SAI_VERSION_CODE 67331
#define CLNX_SAI_HEAD_VERSION "1.7.3"
#define SAI_VER(a,b,c) (((a)<<16)+((b)<<8)+(c))
