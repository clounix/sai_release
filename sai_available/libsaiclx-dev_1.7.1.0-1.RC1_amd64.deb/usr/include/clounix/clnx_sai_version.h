#define CLNX_SAI_COMMIT_ID "78bff2167c60f1688b27e28be3220377fc57dfeb"
#define CLNX_SAI_GIT_BRANCH "v1.7_ks-dirty"
#define CLNX_SAI_BUILD_TIME "Wed Jun 15 04:01:25 UTC 2022"
#define CLNX_SDK_COMMIT_ID "b90376a236754027d0fddd2e50ed7a21b029e8da(clx_system_1.1.2_RC3)"
#define CLNX_SAI_BUILD_BY "yangjie-bj@13890ea7420d"
#define SAI_VERSION_CODE 67329
#define CLNX_SAI_HEAD_VERSION "1.7.1"
#define SAI_VER(a,b,c) (((a)<<16)+((b)<<8)+(c))
