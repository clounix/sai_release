#if !defined (__CLNX_SAI_SWITCH_FEATURE_H_)
#define __CLNX_SAI_SWITCH_FEATURE_H_

typedef enum
{
    CLNX_FEATURE_ACL_LEGACY_BIND,
    CLNX_FEATURE_ADJ_DROP_BY_DELETING_FDB,
    CLNX_FEATURE_BRIDGEPORT_ING_FILTER,
    CLNX_FEATURE_BUM_SONIC_IMPL,
    CLNX_FEATURE_ECC_ERR_LOG,
    CLNX_FEATURE_MAC_MOVE_NOTIFY,
    CLNX_FEATURE_PORT_IP_COUNT_USING_ACL,
    CLNX_FEATURE_PORT_LINK_DELAY,
    CLNX_FEATURE_SHOW_ECMP_PATH,
    CLNX_FEATURE_SWITCH_MONITOR,
    CLNX_FEATURE_LAST
}CLNX_FEATURE_TYPE_T;

uint32_t clnx_switch_get_feature(
    _In_ const uint32_t unit,
    _In_ CLNX_FEATURE_TYPE_T feature_type);

CLX_ERROR_NO_T
clnx_switch_getFeatureType(
    _In_ const char *ptr_feature_name,
    _Out_ UI32_T    *ptr_feature_type);

CLX_ERROR_NO_T clnx_sai_feature_dump_cmd(
    _In_ const C8_T                *tokens[]);


#endif /* __CLNX_SAI_SWITCH_FEATURE_H_ */