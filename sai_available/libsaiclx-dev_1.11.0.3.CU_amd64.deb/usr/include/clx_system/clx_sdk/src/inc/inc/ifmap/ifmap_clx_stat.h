/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   ifmap_clx_stat.h
 * PURPOSE:
 *      It provides user port to CLX port translation API.
 * NOTES:
 */

#ifndef IFMAP_CLX_STAT_H
#define IFMAP_CLX_STAT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
ifmap_clx_stat_getPortCnt(const UI32_T unit,
                          const UI32_T port,
                          const CLX_STAT_PORT_CNT_TYPE_T type,
                          UI64_T *ptr_cnt);

CLX_ERROR_NO_T
ifmap_clx_stat_clearPortCnt(const UI32_T unit,
                            const UI32_T port,
                            const CLX_STAT_PORT_CNT_TYPE_T type);

CLX_ERROR_NO_T
ifmap_clx_stat_setTmQueueCntForPort(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
ifmap_clx_stat_getTmQueueCntForPort(const UI32_T unit, UI32_T *ptr_port);

CLX_ERROR_NO_T
ifmap_clx_stat_getTmCnt(const UI32_T unit,
                        const UI32_T port,
                        const CLX_TM_HANDLER_T handler,
                        const CLX_STAT_TM_CNT_TYPE_T type,
                        CLX_STAT_TM_CNT_T *ptr_cnt);

CLX_ERROR_NO_T
ifmap_clx_stat_clearTmCnt(const UI32_T unit,
                          const UI32_T port,
                          const CLX_TM_HANDLER_T handler,
                          const CLX_STAT_TM_CNT_TYPE_T type);

CLX_ERROR_NO_T
ifmap_clx_stat_getPortRate(const UI32_T unit,
                           const UI32_T port,
                           const CLX_STAT_RATE_TYPE_T type,
                           UI64_T *ptr_rate);

CLX_ERROR_NO_T
ifmap_clx_stat_showDbgCnt(const UI32_T unit,
                          const UI32_T port,
                          const UI32_T stage_bmp,
                          const UI32_T flags);

#endif /* End of #ifndef IFMAP_CLX_STAT_H */
