/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_acl.h
 * PURPOSE:
 *    Provide HAL driver API functions of ACL module.
 *
 * NOTES:
 *
 */

#ifndef HAL_ACL_H
#define HAL_ACL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_acl.h>
#include <hal/hal_l3.h>
#include <hal/hal_cmn.h>
#include <hal/hal_sflow.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_ACL_UCP_ENTRY_NUM_MAX      (1024)
#define HAL_ACL_FLW_GROUP_NUM_MAX      (24)
#define HAL_ACL_IGR_GROUP_NUM_MAX      (12)
#define HAL_ACL_EGR_GROUP_NUM_MAX      (4)
#define HAL_ACL_IGR_POST_GROUP_NUM_MAX (12)
#define HAL_ACL_EGR_POST_GROUP_NUM_MAX (4)
#define HAL_ACL_IGR_UCP_NUM_MAX        (12)
#define HAL_ACL_EGR_UCP_NUM_MAX        (4)
#define HAL_ACL_IGR_POST_UCP_NUM_MAX   (12)
#define HAL_ACL_EGR_POST_UCP_NUM_MAX   (4)
#define HAL_ACL_IGR_ENTRY_NUM_MAX      (HAL_ACL_UCP_ENTRY_NUM_MAX * HAL_ACL_IGR_UCP_NUM_MAX)
#define HAL_ACL_EGR_ENTRY_NUM_MAX      (HAL_ACL_UCP_ENTRY_NUM_MAX * HAL_ACL_EGR_UCP_NUM_MAX)
#define HAL_ACL_IGR_POST_ENTRY_NUM_MAX (HAL_ACL_UCP_ENTRY_NUM_MAX * HAL_ACL_IGR_POST_UCP_NUM_MAX)
#define HAL_ACL_EGR_POST_ENTRY_NUM_MAX (HAL_ACL_UCP_ENTRY_NUM_MAX * HAL_ACL_EGR_POST_UCP_NUM_MAX)
#define HAL_ACL_ENTRY_INVALID_INT_ID   (0xFFFFFFFF)

#define HAL_ACL_UCP_ENTRY_NUM_WORDS_MAX      (HAL_ACL_UCP_ENTRY_NUM_MAX / 32)
#define HAL_ACL_IGR_ENTRY_NUM_WORDS_MAX      (HAL_ACL_IGR_ENTRY_NUM_MAX / 32)
#define HAL_ACL_EGR_ENTRY_NUM_WORDS_MAX      (HAL_ACL_EGR_ENTRY_NUM_MAX / 32)
#define HAL_ACL_IGR_POST_ENTRY_NUM_WORDS_MAX (HAL_ACL_IGR_POST_ENTRY_NUM_MAX / 32)
#define HAL_ACL_EGR_POST_ENTRY_NUM_WORDS_MAX (HAL_ACL_EGR_POST_ENTRY_NUM_MAX / 32)

#define HAL_ACL_KEY_WIDTH_MAX                         (4)
#define HAL_ACL_UDF_PROFILE_NUM                       (64)
#define HAL_ACL_TCP_FLG_ENC_IDX_NUM                   (128)
#define HAL_ACL_PER_UCP_CFG_NUM                       (320)
#define HAL_ACL_UCP_CFG_FRM_TYP_NUM                   (5)
#define HAL_ACL_FCM_REWR_PAGE_NUM                     (144)
#define HAL_ACL_UDF_PKG_DATA_BITS                     (8)
#define HAL_ACL_UDF_INT_LOU_BITS                      (16)
#define HAL_ACL_UDF_INT_SRV_LBL_BITS                  (12)
#define HAL_ACL_UDF_INT_VRF_BITS                      (13)
#define HAL_ACL_UDF_INT_BDID_BITS                     (14)
#define HAL_ACL_UDF_INT_L3_INTF_ID_BITS               (14)
#define HAL_ACL_UDF_INT_IS_ROUTER_MAC_BITS            (1)
#define HAL_ACL_LOU_OR_BITMAP_NUM                     (8)
#define HAL_ACL_REWR_TLV_BIDX_MAX                     (127)
#define HAL_ACL_REWR_TLV_BIDX_NUM                     (128)
#define HAL_ACL_REWR_TLV_BITS                         (16)
#define HAL_ACL_TBL_PKG_LOU_PROF_IDX_ENTRY_SHIFT_BITS (3) /* udf_key_prof_idx */
#define HAL_ACL_TBL_LOU_PROF_ENTRY_SHIFT_BITS         (4)
#define HAL_ACL_REG_IPV6_EXT_HDR_VLD_BIT_OFF          (8)
#define HAL_ACL_PGK_TLV_BYTE_OFF_MAX                  (0x7f)
#define HAL_ACL_UDF_KEY_FLD_WORDS                     (7)
#define HAL_ACL_INVALID_ACL_REWR_IDX                  (0x1FFF)
#define HAL_ACL_INVALID_FLW_CIA_REWR_IDX              (0x3FFFF)
#define HAL_ACL_INVALID_PBR_RSLT_IDX                  (0x3FFFF)
#define HAL_ACL_SUPP_DECR_TTL_PBR_RSLT_IDX            (0x3FFFD)
#define HAL_ACL_REWR_ADD_TLV_MAX                      (8)
#define HAL_ACL_REWR_DEL_TLV_MAX                      (8)
#define HAL_ACL_REWR_ADD_BYTES_MAX                    (16)
#define HAL_ACL_REWR_DEL_BYTES_MAX                    (16)
#define HAL_ACL_REWR_SET_BYTES_MAX                    (16)
#define HAL_ACL_REWR_SET_BYTES_WITH_MASK_MAX          (8)
#define HAL_ACL_REWR_SET_INCR_BYTES_MAX               (4)
#define HAL_ACL_REWR_TOTAL_ADD_BYTES_MAX              (32)
#define HAL_ACL_REWR_TOTAL_SET_BYTES_MAX              (64)
#define HAL_ACL_PKG_LOU_L2_SKIP_0_PRESENT             (0x1)
#define HAL_ACL_PKG_LOU_L2_SKIP_1_PRESENT             (0x2)
#define HAL_ACL_PER_UCP_FRM_TYPE_CFG_NUM              (HAL_ACL_PER_UCP_CFG_NUM / HAL_ACL_UCP_CFG_FRM_TYP_NUM)
#define HAL_ACL_ITM_PER_PLANE_BMP_WORDS               (HAL_ITM_PBM_WORDS / HAL_PLANE_NUM_MAX)
#define HAL_ACL_IS_DUAL_RESOURCE(__unit__)            (HAL_IS_DEVICE_NAMCHABARWA_12_8T_FAMILY(__unit__))

/* check flags of CLX_ACL_GROUP_FORMAT_T */
#define HAL_ACL_MAC_PKT_GROUP_FORMAT                                          \
    (CLX_ACL_GROUP_FORMAT_TC_COLOR | CLX_ACL_GROUP_FORMAT_UDF_KEY_SINGLE |    \
     CLX_ACL_GROUP_FORMAT_UDF_KEY_DOUBLE | CLX_ACL_GROUP_FORMAT_BASE_KEY_L2 | \
     CLX_ACL_GROUP_FORMAT_L2_BIDIR)
#define HAL_ACL_ARP_PKT_GROUP_FORMAT \
    (CLX_ACL_GROUP_FORMAT_BASE_KEY_L3 | (HAL_ACL_MAC_PKT_GROUP_FORMAT))

#define HAL_ACL_FCOE_PKT_GROUP_FORMAT                                   \
    (CLX_ACL_GROUP_FORMAT_BASE_KEY_L3 | CLX_ACL_GROUP_FORMAT_L3_BIDIR | \
     CLX_ACL_GROUP_FORMAT_L4_BIDIR | (HAL_ACL_MAC_PKT_GROUP_FORMAT))

/* check flags of CLX_ACL_GROUP_CLASSIFY_T */
#define HAL_ACL_BASE_KEY_NONE_FLAGS                                    \
    (CLX_ACL_CLASSIFY_FLAGS_PKG_KEY | CLX_ACL_CLASSIFY_FLAGS_LOU_KEY | \
     CLX_ACL_CLASSIFY_FLAGS_UDF_VALID | CLX_ACL_CLASSIFY_FLAGS_PORT_BITMAP_VALID)
#define HAL_ACL_BASE_KEY_COMMON_FLAGS                                      \
    (CLX_ACL_CLASSIFY_FLAGS_QOS_KEY | CLX_ACL_CLASSIFY_FLAGS_PP_INFO_KEY | \
     CLX_ACL_CLASSIFY_FLAGS_PKG_KEY | CLX_ACL_CLASSIFY_FLAGS_LOU_KEY |     \
     CLX_ACL_CLASSIFY_FLAGS_UDF_VALID | CLX_ACL_CLASSIFY_FLAGS_PORT_BITMAP_VALID)
#define HAL_ACL_BASE_KEY_L2_FLAGS (CLX_ACL_CLASSIFY_FLAGS_MAC_KEY | HAL_ACL_BASE_KEY_COMMON_FLAGS)
#define HAL_ACL_BASE_KEY_L3_ARP_FLAGS \
    (CLX_ACL_CLASSIFY_FLAGS_ARP_KEY | HAL_ACL_BASE_KEY_COMMON_FLAGS)
#define HAL_ACL_BASE_KEY_L3_IPV4_FLAGS \
    (CLX_ACL_CLASSIFY_FLAGS_IPV4_KEY | HAL_ACL_BASE_KEY_COMMON_FLAGS)
#define HAL_ACL_BASE_KEY_L3_IPV6_FLAGS \
    (CLX_ACL_CLASSIFY_FLAGS_IPV6_KEY | HAL_ACL_BASE_KEY_COMMON_FLAGS)
#define HAL_ACL_BASE_KEY_L3_FCOE_FLAGS \
    (CLX_ACL_CLASSIFY_FLAGS_FCOE_KEY | HAL_ACL_BASE_KEY_COMMON_FLAGS)
#define HAL_ACL_BASE_KEY_L3_MPLS_FLAGS \
    (CLX_ACL_CLASSIFY_FLAGS_MPLS_KEY | HAL_ACL_BASE_KEY_COMMON_FLAGS)

/* check flags of CLX_ACL_IPV4_KEY_T */
#define HAL_ACL_IPV4_KEY_FLAGS                                                       \
    (CLX_ACL_IPV4_KEY_FLAGS_FRG_TYPE_VALID | CLX_ACL_IPV4_KEY_FLAGS_TTL_TYPE_VALID | \
     CLX_ACL_IPV4_KEY_FLAGS_AUTH_HDR_EXIST | CLX_ACL_IPV4_KEY_FLAGS_OPT_HDR_EXIST)
#define HAL_ACL_IPV4_KEY_FLAGS_MASK \
    (CLX_ACL_IPV4_KEY_FLAGS_AUTH_HDR_EXIST | CLX_ACL_IPV4_KEY_FLAGS_OPT_HDR_EXIST)
/* check flags of CLX_ACL_IPV6_KEY_T */
#define HAL_ACL_IPV6_KEY_FLAGS                                                       \
    (CLX_ACL_IPV6_KEY_FLAGS_FRG_TYPE_VALID | CLX_ACL_IPV6_KEY_FLAGS_TTL_TYPE_VALID | \
     CLX_ACL_IPV6_KEY_FLAGS_AUTH_HDR_EXIST)
#define HAL_ACL_IPV6_KEY_FLAGS_MASK (CLX_ACL_IPV6_KEY_FLAGS_AUTH_HDR_EXIST)

/* check flags of CLX_ACL_QOS_KEY_T */
#define HAL_ACL_NON_IP_QOS_KEY_FLAGS                                           \
    (CLX_ACL_QOS_KEY_FLAGS_STAG_PCP_DEI | CLX_ACL_QOS_KEY_FLAGS_CTAG_PCP_DEI | \
     CLX_ACL_QOS_KEY_FLAGS_TC_COLOR | CLX_ACL_QOS_KEY_FLAGS_COLOR_VALID |      \
     CLX_ACL_QOS_KEY_FLAGS_EXP | CLX_ACL_QOS_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_ACL_IP_QOS_KEY_FLAGS                                       \
    (CLX_ACL_QOS_KEY_FLAGS_DSCP_ECN | CLX_ACL_QOS_KEY_FLAGS_TC_COLOR | \
     CLX_ACL_QOS_KEY_FLAGS_COLOR_VALID)
#define HAL_ACL_IP_W_L2_QOS_KEY_FLAGS                                          \
    (CLX_ACL_QOS_KEY_FLAGS_STAG_PCP_DEI | CLX_ACL_QOS_KEY_FLAGS_CTAG_PCP_DEI | \
     CLX_ACL_QOS_KEY_FLAGS_VLAN_TAG_MODE_1Q | HAL_ACL_IP_QOS_KEY_FLAGS)

/* check flags of CLX_ACL_PP_INFO_KEY_T */
#define HAL_ACL_IGR_L2_PP_KEY_FLAGS                                                       \
    (CLX_ACL_PP_INFO_KEY_FLAGS_L2_FRAME_TYPE_VALID | CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE | \
     CLX_ACL_PP_INFO_KEY_FLAGS_STAG_VALID | CLX_ACL_PP_INFO_KEY_FLAGS_CTAG_VALID |        \
     CLX_ACL_PP_INFO_KEY_FLAGS_TNL_TERM | CLX_ACL_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_ACL_IGR_L3_NON_ARP_PP_KEY_FLAGS                                    \
    (CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE | CLX_ACL_PP_INFO_KEY_FLAGS_TNL_TERM | \
     CLX_ACL_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_ACL_IGR_L3_NON_ARP_W_L2_PP_KEY_FLAGS                                 \
    (CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE | CLX_ACL_PP_INFO_KEY_FLAGS_STAG_VALID | \
     CLX_ACL_PP_INFO_KEY_FLAGS_CTAG_VALID | CLX_ACL_PP_INFO_KEY_FLAGS_TNL_TERM | \
     CLX_ACL_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_ACL_IGR_L3_ARP_PP_KEY_FLAGS (CLX_ACL_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_ACL_IGR_L3_ARP_W_L2_PP_KEY_FLAGS                                       \
    (CLX_ACL_PP_INFO_KEY_FLAGS_STAG_VALID | CLX_ACL_PP_INFO_KEY_FLAGS_CTAG_VALID | \
     CLX_ACL_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_ACL_EGR_PP_KEY_FLAGS (CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE)
#define HAL_ACL_PP_KEY_FLAGS_MASKABLE                                            \
    (CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE | CLX_ACL_PP_INFO_KEY_FLAGS_STAG_VALID | \
     CLX_ACL_PP_INFO_KEY_FLAGS_CTAG_VALID | CLX_ACL_PP_INFO_KEY_FLAGS_TNL_TERM)
/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_ACL_LOCK(_unit_) \
    HAL_COMMON_LOCK_RESOURCE(&_hal_acl_cb[(_unit_)].mutex_sema_id, CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_ACL_UNLOCK(_unit_) HAL_COMMON_FREE_RESOURCE(&_hal_acl_cb[(_unit_)].mutex_sema_id)

#define HAL_ACL_UCP_NUM_GET(__unit__, __type__, __ucp_num__)                   \
    do {                                                                       \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                               \
            __ucp_num__ = PTR_HAL_CONST_INFO(__unit__, acl)->igr_ucp_num;      \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                         \
            __ucp_num__ = PTR_HAL_CONST_INFO(__unit__, acl)->egr_ucp_num;      \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                   \
            __ucp_num__ = PTR_HAL_CONST_INFO(__unit__, acl)->igr_post_ucp_num; \
        } else {                                                               \
            __ucp_num__ = PTR_HAL_CONST_INFO(__unit__, acl)->egr_post_ucp_num; \
        }                                                                      \
    } while (0)

#define HAL_ACL_AVL_HEAD_GET(__unit__, __type__, __ptr_avl_head__)                   \
    do {                                                                             \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                                     \
            __ptr_avl_head__ = _hal_acl_cb[__unit__].entry_cb.ptr_igr_avl_head;      \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                               \
            __ptr_avl_head__ = _hal_acl_cb[__unit__].entry_cb.ptr_egr_avl_head;      \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                         \
            __ptr_avl_head__ = _hal_acl_cb[__unit__].entry_cb.ptr_igr_post_avl_head; \
        } else if (CLX_ACL_GROUP_EGRESS_POST == __type__) {                          \
            __ptr_avl_head__ = _hal_acl_cb[__unit__].entry_cb.ptr_egr_post_avl_head; \
        }                                                                            \
    } while (0)
#define HAL_ACL_SW_ENTRY_BMP_GET(__unit__, __type__, __ptr_sw_entry_bmp__)               \
    do {                                                                                 \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                                         \
            __ptr_sw_entry_bmp__ = _hal_acl_cb[__unit__].entry_cb.igr_sw_entry_bmp;      \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                                   \
            __ptr_sw_entry_bmp__ = _hal_acl_cb[__unit__].entry_cb.egr_sw_entry_bmp;      \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                             \
            __ptr_sw_entry_bmp__ = _hal_acl_cb[__unit__].entry_cb.igr_post_sw_entry_bmp; \
        } else {                                                                         \
            __ptr_sw_entry_bmp__ = _hal_acl_cb[__unit__].entry_cb.egr_post_sw_entry_bmp; \
        }                                                                                \
    } while (0)
#define HAL_ACL_HW_ENTRY_BMP_GET(__unit__, __type__, __ptr_hw_entry_bmp__)               \
    do {                                                                                 \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                                         \
            __ptr_hw_entry_bmp__ = _hal_acl_cb[__unit__].entry_cb.igr_hw_entry_bmp;      \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                                   \
            __ptr_hw_entry_bmp__ = _hal_acl_cb[__unit__].entry_cb.egr_hw_entry_bmp;      \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                             \
            __ptr_hw_entry_bmp__ = _hal_acl_cb[__unit__].entry_cb.igr_post_hw_entry_bmp; \
        } else {                                                                         \
            __ptr_hw_entry_bmp__ = _hal_acl_cb[__unit__].entry_cb.egr_post_hw_entry_bmp; \
        }                                                                                \
    } while (0)

#define HAL_ACL_SW_ENTRY_INFO_ARR_GET(__unit__, __type__, __ptr_sw_entry_info_arr__)               \
    do {                                                                                           \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                                                   \
            __ptr_sw_entry_info_arr__ = _hal_acl_cb[__unit__].entry_cb.igr_sw_entry_info_arr;      \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                                             \
            __ptr_sw_entry_info_arr__ = _hal_acl_cb[__unit__].entry_cb.egr_sw_entry_info_arr;      \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                                       \
            __ptr_sw_entry_info_arr__ = _hal_acl_cb[__unit__].entry_cb.igr_post_sw_entry_info_arr; \
        } else {                                                                                   \
            __ptr_sw_entry_info_arr__ = _hal_acl_cb[__unit__].entry_cb.egr_post_sw_entry_info_arr; \
        }                                                                                          \
    } while (0)
#define HAL_ACL_SW_ENTRY_BMP_WORDS_GET(__unit__, __type__, __sw_entry_bmp_words__) \
    do {                                                                           \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                                   \
            __sw_entry_bmp_words__ = HAL_ACL_IGR_ENTRY_NUM_WORDS_MAX;              \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                             \
            __sw_entry_bmp_words__ = HAL_ACL_EGR_ENTRY_NUM_WORDS_MAX;              \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                       \
            __sw_entry_bmp_words__ = HAL_ACL_IGR_POST_ENTRY_NUM_WORDS_MAX;         \
        } else if (CLX_ACL_GROUP_EGRESS_POST == __type__) {                        \
            __sw_entry_bmp_words__ = HAL_ACL_EGR_POST_ENTRY_NUM_WORDS_MAX;         \
        }                                                                          \
    } while (0)

#define HAL_ACL_GROUP_BMP_GET(__unit__, __type__, __grp_bmp__)               \
    do {                                                                     \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                             \
            __grp_bmp__ = _hal_acl_cb[__unit__].group_cb.igr_group_bmp;      \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                       \
            __grp_bmp__ = _hal_acl_cb[__unit__].group_cb.egr_group_bmp;      \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                 \
            __grp_bmp__ = _hal_acl_cb[__unit__].group_cb.igr_post_group_bmp; \
        } else if (CLX_ACL_GROUP_EGRESS_POST == __type__) {                  \
            __grp_bmp__ = _hal_acl_cb[__unit__].group_cb.egr_post_group_bmp; \
        }                                                                    \
    } while (0)

#define HAL_ACL_INTERNAL_ID_GET(__unit__, __type__, __ptr_internal_id__)                  \
    do {                                                                                  \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                                          \
            __ptr_internal_id__ = &(_hal_acl_cb[__unit__].entry_cb.igr_internal_id);      \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                                    \
            __ptr_internal_id__ = &(_hal_acl_cb[__unit__].entry_cb.egr_internal_id);      \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                              \
            __ptr_internal_id__ = &(_hal_acl_cb[__unit__].entry_cb.igr_post_internal_id); \
        } else if (CLX_ACL_GROUP_EGRESS_POST == __type__) {                               \
            __ptr_internal_id__ = &(_hal_acl_cb[__unit__].entry_cb.egr_post_internal_id); \
        } else {                                                                          \
            __ptr_internal_id__ = NULL;                                                   \
        }                                                                                 \
    } while (0)
#define HAL_ACL_LOU_OR_ENTRY_IDX(__lou_prof_idx__, __bmap_idx__) \
    (((__lou_prof_idx__) << (3)) + (__bmap_idx__))
#define HAL_ACL_FLW_GROUP_ID_START(__unit__) (PTR_HAL_CONST_INFO(__unit__, acl)->igr_group_num)
#define HAL_ACL_FLW_GROUP_ID_END(__unit__)              \
    (PTR_HAL_CONST_INFO(__unit__, acl)->igr_group_num + \
     PTR_HAL_CONST_INFO(__unit__, acl)->flw_group_num - 1)
#define HAL_ACL_VALID_FLW_GROUP_ID(__unit__, __level__, __group_id__) \
    (__group_id__ == _hal_acl_cb[(__unit__)].group_cb.flw_group_id[__level__])
#define HAL_ACL_EGR_ENTRY_ID_OFFSET(__unit__)         \
    (PTR_HAL_CONST_INFO(__unit__, acl)->igr_ucp_num * \
     PTR_HAL_CONST_INFO(__unit__, acl)->ucp_entry_num)
#define HAL_ACL_PACK_SRC_DST_PORT(__src_port__, __dst_port__) \
    (((UI32_T)((__src_port__) & 0xffff) << 16) + ((__dst_port__) & 0xffff))
#define HAL_ACL_PACK_ICMP_TYPE_CODE(__icmp_type__, __icmp_code__) \
    (((UI32_T)((__icmp_type__) & 0xff) << 24) + (((__icmp_code__) & 0xff) << 16))
#define HAL_ACL_PACK_IGMP_TYPE(__igmp_type__)        ((UI32_T)((__igmp_type__) & 0xff) << 24)
#define HAL_ACL_UNPACK_SRC_PORT(__src_dst_port__)    ((__src_dst_port__) >> 16)
#define HAL_ACL_UNPACK_DST_PORT(__src_dst_port__)    ((__src_dst_port__) & 0xFFFF)
#define HAL_ACL_UNPACK_ICMP_TYPE(__icmp_type_code__) ((__icmp_type_code__) >> 24)
#define HAL_ACL_UNPACK_ICMP_CODE(__icmp_type_code__) (((__icmp_type_code__) >> 16) & 0xFF)
#define HAL_ACL_UNPACK_IGMP_TYPE(__igmp_type__)      ((__igmp_type__) >> 24)
#define HAL_ACL_PKG_PROF_ENTRY_IDX(__udf_prof_idx__, __pkg_id__) \
    (((__udf_prof_idx__) << 1) | (__pkg_id__))
#define HAL_ACL_UI32_MSK(__bits__) (0xFFFFFFFF >> (32 - (__bits__)))
#define HAL_ACL_UI32_FLD_MSK(__unit__, __tbl_id__, __fld_id__) \
    (HAL_ACL_UI32_MSK(CDB_TABLE((__unit__), (__tbl_id__))->ptr_table_entry[(__fld_id__)].length))

#define HAL_ACL_UCP_CFG_ENTRY_IDX(__ucp_id__, __frm_typ__) \
    (((__ucp_id__) * HAL_ACL_PER_UCP_CFG_NUM) + ((__frm_typ__) * HAL_ACL_PER_UCP_FRM_TYPE_CFG_NUM))

#define HAL_ACL_LOU_PROF_ENTRY_IDX(__udf_prof_id__, __lou_id__) \
    (((__udf_prof_id__) << HAL_ACL_TBL_LOU_PROF_ENTRY_SHIFT_BITS) | (__lou_id__))

#define HAL_ACL_ADD_HW_ENTRY_BITMAP(__entry_bmp__, __entry_idx__, __entry_width__) \
    do {                                                                           \
        UI32_T __idx__ = (__entry_idx__);                                          \
        for (; __idx__ < (__entry_idx__) + (__entry_width__); __idx__++) {         \
            CMLIB_BITMAP_BIT_ADD((__entry_bmp__), (__idx__));                      \
        }                                                                          \
    } while (0)

#define HAL_ACL_DEL_HW_ENTRY_BITMAP(__entry_bmp__, __entry_idx__, __entry_width__) \
    do {                                                                           \
        UI32_T __idx__ = (__entry_idx__);                                          \
        for (; __idx__ < (__entry_idx__) + (__entry_width__); __idx__++) {         \
            CMLIB_BITMAP_BIT_DEL((__entry_bmp__), (__idx__));                      \
        }                                                                          \
    } while (0)

#define HAL_ACL_GET_FCM_1X_IDX(__fcm_1x_idx__, __fcm_page__, __rewr_1x_idx__)    \
    do {                                                                         \
        (__fcm_1x_idx__) = ((__fcm_page__) << 10) + ((__rewr_1x_idx__) & 0x3ff); \
    } while (0)

#define HAL_ACL_GET_GROUP_NUM(__ptr_acl_const__, __type__, __is_flow__, __group_num__) \
    do {                                                                               \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                                       \
            if (__is_flow__) {                                                         \
                __group_num__ = __ptr_acl_const__->flw_group_num;                      \
            } else {                                                                   \
                __group_num__ = __ptr_acl_const__->igr_group_num;                      \
            }                                                                          \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                                 \
            __group_num__ = __ptr_acl_const__->egr_group_num;                          \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {                           \
            __group_num__ = __ptr_acl_const__->igr_post_group_num;                     \
        } else {                                                                       \
            __group_num__ = __ptr_acl_const__->egr_post_group_num;                     \
        }                                                                              \
    } while (0)

#define HAL_ACL_GET_REWR_PAGE(__rewr_page__, __rewr_1x_idx__) \
    do {                                                      \
        (__rewr_page__) = (__rewr_1x_idx__) >> 10;            \
    } while (0)

#define HAL_ACL_GET_CANDI_UDF_PROF_ID(__candi_prof_id__, __prof_id__, __prof_id_mask__,  \
                                      __udf_prof_id_arr__)                               \
    do {                                                                                 \
        if ((0 == (__prof_id_mask__)) && ((__udf_prof_id_arr__)[(__prof_id__)].vld)) {   \
            (__candi_prof_id__) = (__prof_id__);                                         \
        } else {                                                                         \
            for ((__candi_prof_id__) = 0; (__candi_prof_id__) < HAL_ACL_UDF_PROFILE_NUM; \
                 (__candi_prof_id__)++) {                                                \
                if ((((__candi_prof_id__) & (__prof_id_mask__)) ==                       \
                     ((__prof_id__) & (__prof_id_mask__))) &&                            \
                    ((__udf_prof_id_arr__)[(__candi_prof_id__)].vld)) {                  \
                    break;                                                               \
                }                                                                        \
            }                                                                            \
            if (HAL_ACL_UDF_PROFILE_NUM == (__candi_prof_id__)) {                        \
                (__candi_prof_id__) = HAL_INVALID_ID;                                    \
            }                                                                            \
        }                                                                                \
    } while (0)

#define HAL_ACL_CHECK_UDF_PROFILE_RANGE(__unit__, __udf_prof_id__)                              \
    do {                                                                                        \
        if ((__udf_prof_id__) >= HAL_ACL_UDF_PROFILE_NUM) {                                     \
            DIAG_PRINT(HAL_DBG_ACL, HAL_DBG_WARN, "u=%u, invalid udf-prof-id=%u, range=0-%u\n", \
                       (__unit__), (__udf_prof_id__), HAL_ACL_UDF_PROFILE_NUM - 1);             \
            return CLX_E_BAD_PARAMETER;                                                         \
        }                                                                                       \
    } while (0)

#define HAL_ACL_COPY_TBL(__rc__, __unit__, __bcast_id__, __tbl_id__, __src_entry__, __dst_entry__, \
                         __num__)                                                                  \
    do {                                                                                           \
        (__rc__) = cdb_copyTable((__unit__), (__bcast_id__), 0, (__tbl_id__), (__src_entry__),     \
                                 (__dst_entry__), (__num__));                                      \
        if (CLX_E_OK != (__rc__)) {                                                                \
            break;                                                                                 \
        }                                                                                          \
    } while (0)
#if defined(CLX_ASICSIM)
#define HAL_ACL_COPY_ACTION_TBL(__rc__, __unit__, __tbl_id__, __sub_inst__, __src_entry__,       \
                                __dst_entry__, __num__)                                          \
    do {                                                                                         \
        (__rc__) = cdb_copyTable((__unit__), (CDB_INST_IDX_BCAST), (__sub_inst__), (__tbl_id__), \
                                 (__src_entry__), (__dst_entry__), (__num__));                   \
        if (CLX_E_OK != (__rc__)) {                                                              \
            break;                                                                               \
        }                                                                                        \
    } while (0)
#endif

#define HAL_ACL_GET_FCM_PAGE(__fcm_page__, __fcm_1x_idx__) \
    do {                                                   \
        (__fcm_page__) = (__fcm_1x_idx__) >> 10;           \
    } while (0)

#define HAL_ACL_IS_FLW_GROUP(__unit__, __group_id__)           \
    ((__group_id__ >= HAL_ACL_FLW_GROUP_ID_START(__unit__)) && \
     (__group_id__ <= HAL_ACL_FLW_GROUP_ID_END(__unit__)))

#define HAL_ACL_IS_ACL_GROUP(__unit__, __group_id__, __type__)                   \
    (((__type__ == CLX_ACL_GROUP_INGRESS) &&                                     \
      (__group_id__ < PTR_HAL_CONST_INFO(__unit__, acl)->igr_group_num)) ||      \
     ((__type__ == CLX_ACL_GROUP_EGRESS) &&                                      \
      (__group_id__ < PTR_HAL_CONST_INFO(__unit__, acl)->egr_group_num)) ||      \
     ((__type__ == CLX_ACL_GROUP_INGRESS_POST) &&                                \
      (__group_id__ < PTR_HAL_CONST_INFO(__unit__, acl)->igr_post_group_num)) || \
     ((__type__ == CLX_ACL_GROUP_EGRESS_POST) &&                                 \
      (__group_id__ < PTR_HAL_CONST_INFO(__unit__, acl)->egr_post_group_num)))

#define HAL_ACL_FLOW_SEARCH_VALID(_unit_) (_hal_acl_cb[(_unit_)].flow_cb.entry_num)

#define HAL_ACL_PACK_QOS_TC_COLOR(_tc_, _color_) ((((_tc_) & 0xf) << 2) + ((_color_) & 0x3))
#define HAL_ACL_PACK_PCP_DEI(_pcp_, _dei_)       ((((_pcp_) & 0x7) << 1) + ((_dei_) & 0x1))
#define HAL_ACL_PACK_DSCP_ECN(_dscp_, _ecn_)     ((((_dscp_) & 0x3f) << 2) + ((_ecn_) & 0x3))
#define HAL_ACL_UNPACK_TC(__tc_color__)          (((__tc_color__) >> 2))
#define HAL_ACL_UNPACK_COLOR(__tc_color__)       (((__tc_color__) & 0x3))
#define HAL_ACL_UNPACK_PCP(__pcp_dei__)          (((__pcp_dei__) >> 1))
#define HAL_ACL_UNPACK_DEI(__pcp_dei__)          (((__pcp_dei__) & 0x1))
#define HAL_ACL_UNPACK_DSCP(__dscp_ecn__)        (((__dscp_ecn__) >> 2))
#define HAL_ACL_UNPACK_ECN(__dscp_ecn__)         (((__dscp_ecn__) & 0x3))
#define HAL_ACL_PER_UCP_HW_ENTRY_IDX(__unit__, __entry_1x_idx__) \
    ((__entry_1x_idx__) & HAL_ACL_UI32_MSK(PTR_HAL_CONST_INFO(__unit__, acl)->ucp_entry_bits))
#define HAL_ACL_HW_ENTRY_UCP(__unit__, __entry_1x_idx__) \
    ((__entry_1x_idx__) >> PTR_HAL_CONST_INFO(__unit__, acl)->ucp_entry_bits)
#define HAL_ACL_UCP_FIRST_HW_ENTRY(__unit__, __ucp_idx__) \
    ((__ucp_idx__) << PTR_HAL_CONST_INFO(__unit__, acl)->ucp_entry_bits)
#define HAL_ACL_UCP_LAST_HW_ENTRY(__unit__, __ucp_idx__) \
    ((((__ucp_idx__) + 1) << PTR_HAL_CONST_INFO(__unit__, acl)->ucp_entry_bits) - 1)
#define HAL_ACL_UCP_ENTRY_NUM(__unit__)       (PTR_HAL_CONST_INFO(__unit__, acl)->ucp_entry_num)
#define HAL_ACL_UCP_ENTRY_NUM_WORDS(__unit__) (HAL_ACL_UCP_ENTRY_NUM(__unit__) / 32)

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_ACL_KEY_TCAM_PKG_LOU_FLD_S {
    UI32_T tbl_id;
    UI32_T vld_fld_t;
    UI32_T l2_etyp_fld_t, l2_etyp_fld_c;
    UI32_T l3_proto_fld_t, l3_proto_fld_c;
    UI32_T l4_w0_fld_t, l4_w0_fld_c;

    UI32_T l2_has_non_snap_llc_fld_t, l2_has_non_snap_llc_fld_c;
    UI32_T l2_snap_present_fld_t, l2_snap_present_fld_c;

    UI32_T l2_vlan_1st_vld_fld_t, l2_vlan_1st_vld_fld_c;
    UI32_T l2_vlan_2nd_vld_fld_t, l2_vlan_2nd_vld_fld_c;

    UI32_T lcl_intf_vld_fld_t, lcl_intf_vld_fld_c;
    UI32_T lcl_intf_typ_fld_t, lcl_intf_typ_fld_c;
    UI32_T lcl_intf_is_vntag_fld_t, lcl_intf_is_vntag_fld_c;

    UI32_T lcl_intf_ip_tnl_is_ipv6_fld_t, lcl_intf_ip_tnl_is_ipv6_fld_c;
    UI32_T lcl_intf_ip_tnl_typ_fld_t, lcl_intf_ip_tnl_typ_fld_c;
    UI32_T llc_type_fld_t, llc_type_fld_c;
    UI32_T l2_skip_tag_present_fld_t, l2_skip_tag_present_fld_c;
    UI32_T tnl_is_mpls_fld_t, tnl_is_mpls_fld_c;
    UI32_T lcl_is_tnl_fld_t, lcl_is_tnl_fld_c;
} HAL_ACL_KEY_TCAM_PKG_LOU_FLD_T;

typedef struct HAL_ACL_UCP_PRIO_S {
    UI32_T ucp_prio;
    UI32_T ucp_grp_prio;

#define HAL_ACL_UCP_PRIO_FLAGS_UCP_PRIO     (1U << 0)
#define HAL_ACL_UCP_PRIO_FLAGS_UCP_GRP_PRIO (1U << 1)
    UI32_T flags;
} HAL_ACL_UCP_PRIO_T;

typedef enum {
    HAL_ACL_QOS_RSLT_FLD_PACK_OFF_IGR = 0,
    HAL_ACL_QOS_RSLT_FLD_PACK_OFF_EGR,
    HAL_ACL_QOS_RSLT_FLD_PACK_OFF_LAST
} HAL_ACL_QOS_RSLT_FLD_PACK_OFF_IDX_T;

typedef enum {
    HAL_ACL_KEY_IGR_QOS_FLD_1X = 0,
    HAL_ACL_KEY_IGR_QOS_FLD_2X_WO_L2,
    HAL_ACL_KEY_IGR_QOS_FLD_2X_W_L2,
    HAL_ACL_KEY_IGR_QOS_FLD_3X,
    HAL_ACL_KEY_IGR_QOS_FLD_LAST
} HAL_ACL_KEY_IGR_QOS_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_EGR_QOS_FLD_1X_L2_FCOE = 0,
    HAL_ACL_KEY_EGR_QOS_FLD_1X_ARP,
    HAL_ACL_KEY_EGR_QOS_FLD_1X_IPV4,
    HAL_ACL_KEY_EGR_QOS_FLD_2X_V6,
    HAL_ACL_KEY_EGR_QOS_FLD_2X_FCOE_W_L2,
    HAL_ACL_KEY_EGR_QOS_FLD_2X_ARP_W_L2,
    HAL_ACL_KEY_EGR_QOS_FLD_2X_IPV4_W_L2,
    HAL_ACL_KEY_EGR_QOS_FLD_3X_IPV6_W_L2,
    HAL_ACL_KEY_EGR_QOS_FLD_LAST
} HAL_ACL_KEY_EGR_QOS_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_MAC_FLD_1X_L2_IGR = 0,
    HAL_ACL_KEY_MAC_FLD_2X_W_L2_IGR,
    HAL_ACL_KEY_MAC_FLD_3X_W_L2_IGR,
    HAL_ACL_KEY_MAC_FLD_1X_L2_EGR,
    HAL_ACL_KEY_MAC_FLD_2X_W_L2_EGR,
    HAL_ACL_KEY_MAC_FLD_3X_W_L2_EGR,
    HAL_ACL_KEY_MAC_FLD_LAST
} HAL_ACL_KEY_MAC_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_ARP_FLD_1X_ARP_IGR = 0,
    HAL_ACL_KEY_ARP_FLD_2X_ARP_W_L2_IGR,
    HAL_ACL_KEY_ARP_FLD_1X_ARP_EGR,
    HAL_ACL_KEY_ARP_FLD_2X_ARP_W_L2_EGR,
    HAL_ACL_KEY_ARP_FLD_LAST
} HAL_ACL_KEY_ARP_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_IPV4_FLD_1X_IPV4_IGR = 0,
    HAL_ACL_KEY_IPV4_FLD_2X_IPV4_W_L2_IGR,
    HAL_ACL_KEY_IPV4_FLD_1X_IPV4_EGR,
    HAL_ACL_KEY_IPV4_FLD_2X_IPV4_W_L2_EGR,
    HAL_ACL_KEY_IPV4_FLD_LAST
} HAL_ACL_KEY_IPV4_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_IPV6_FLD_2X_IPV6_IGR = 0,
    HAL_ACL_KEY_IPV6_FLD_3X_IPV6_W_L2_IGR,
    HAL_ACL_KEY_IPV6_FLD_2X_IPV6_EGR,
    HAL_ACL_KEY_IPV6_FLD_3X_IPV6_W_L2_EGR,
    HAL_ACL_KEY_IPV6_FLD_LAST
} HAL_ACL_KEY_IPV6_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_FCOE_FLD_1X_FCOE_IGR = 0,
    HAL_ACL_KEY_FCOE_FLD_2X_FCOE_W_L2_IGR,
    HAL_ACL_KEY_FCOE_FLD_1X_FCOE_EGR,
    HAL_ACL_KEY_FCOE_FLD_2X_FCOE_W_L2_EGR,
    HAL_ACL_KEY_FCOE_FLD_LAST
} HAL_ACL_KEY_FCOE_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_MPLS_FLD_1X_MPLS_IGR = 0,
    HAL_ACL_KEY_MPLS_FLD_1X_MPLS_EGR,
    HAL_ACL_KEY_MPLS_FLD_LAST
} HAL_ACL_KEY_MPLS_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_UDF_FLD_IGR = 0,
    HAL_ACL_KEY_UDF_FLD_EGR,
    HAL_ACL_KEY_UDF_FLD_LAST
} HAL_ACL_KEY_UDF_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_TCAM_PKG_LOU_FLD_IGR = 0,
    HAL_ACL_KEY_TCAM_PKG_LOU_FLD_EGR,
    HAL_ACL_KEY_TCAM_PKG_LOU_FLD_LAST
} HAL_ACL_KEY_TCAM_PKG_LOU_FLD_IDX_T;

typedef struct HAL_ACL_PKG_TLV_FLD_S {
    UI32_T tbl_id;
    UI32_T vld_fld, inc_byte_vld_fld;
    UI32_T typ_fld;
    UI32_T byte_offset_fld, byte_msk_fld;
    UI32_T byte_sel_fld;
} HAL_ACL_PKG_TLV_FLD_T;

typedef struct HAL_ACL_PKG_INT_KEY_VLD_FLD_S {
    UI32_T tbl_id;
    UI32_T lou_fld;
    UI32_T flw_lbl_lcl_intf_fld, flw_lbl_l2_intf_fld;
    UI32_T fdid_fld, l3_intf_id_fld;
    UI32_T vrf_fld;
    UI32_T vlan_1st_vid_fld, vlan_1st_pcp_dei_fld;
    UI32_T vlan_2nd_vid_fld, vlan_2nd_pcp_dei_fld;
    UI32_T is_router_mac_fld;
    UI32_T tcp_flags_fld;
    UI32_T igr_acl_lbl_fld;
    UI32_T pbm_fld;
} HAL_ACL_PKG_INT_KEY_VLD_FLD_T;

typedef enum {
    HAL_ACL_PKG_INT_KEY_VLD_FLD_IGR = 0,
    HAL_ACL_PKG_INT_KEY_VLD_FLD_EGR,
    HAL_ACL_PKG_INT_KEY_VLD_FLD_LAST
} HAL_ACL_PKG_INT_KEY_VLD_FLD_IDX_T;

typedef enum {
    HAL_ACL_LOU_PROF_FLD_REG_IGR = 0,
    HAL_ACL_LOU_PROF_FLD_PRG_IGR,
    HAL_ACL_LOU_PROF_FLD_REG_EGR,
    HAL_ACL_LOU_PROF_FLD_PRG_EGR,
    HAL_ACL_LOU_PROF_FLD_LAST
} HAL_ACL_LOU_PROF_FLD_IDX_T;

typedef struct HAL_ACL_LOU_PROF_FLD_S {
    UI32_T tbl_id;
    UI32_T typ_fld;
    UI32_T sel_fld;
    UI32_T byte_offset_typ_fld, byte_offset_fld;
    UI32_T val_min_fld, val_max_fld;
    UI32_T val_msk_fld, inv_fld;
} HAL_ACL_LOU_PROF_FLD_T;

typedef struct HAL_ACL_PKG_TLV_S {
    HAL_IKG_BYTE_OFFSET_TYP_ENUM_T type;
    UI32_T byte_offset;
    UI32_T byte_msk;
    UI32_T byte_sel;
} HAL_ACL_PKG_TLV_T;

typedef enum {
    HAL_ACL_PKG_TLV_FLD_IGR = 0,
    HAL_ACL_PKG_TLV_FLD_EGR,
    HAL_ACL_PKG_TLV_FLD_FLW,
    HAL_ACL_PKG_TLV_FLD_LAST
} HAL_ACL_PKG_TLV_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_IGR_PP_FLD_1X_L2 = 0,
    HAL_ACL_KEY_IGR_PP_FLD_1X_ARP,
    HAL_ACL_KEY_IGR_PP_FLD_1X_IPV4_FCOE,
    HAL_ACL_KEY_IGR_PP_FLD_2X_IPV6,
    HAL_ACL_KEY_IGR_PP_FLD_2X_ARP_W_L2,
    HAL_ACL_KEY_IGR_PP_FLD_2X_IPV4_FCOE_W_L2,
    HAL_ACL_KEY_IGR_PP_FLD_3X_IPV6_W_L2,
    HAL_ACL_KEY_IGR_PP_FLD_LAST
} HAL_ACL_KEY_IGR_PP_FLD_IDX_T;

typedef enum {
    HAL_ACL_KEY_EGR_PP_FLD_1X_L2 = 0,
    HAL_ACL_KEY_EGR_PP_FLD_1X_ARP,
    HAL_ACL_KEY_EGR_PP_FLD_1X_IPV4_FCOE,
    HAL_ACL_KEY_EGR_PP_FLD_2X_IPV6,
    HAL_ACL_KEY_EGR_PP_FLD_2X_ARP_W_L2,
    HAL_ACL_KEY_EGR_PP_FLD_2X_IPV4_FCOE_W_L2,
    HAL_ACL_KEY_EGR_PP_FLD_3X_IPV6_W_L2,
    HAL_ACL_KEY_EGR_PP_FLD_LAST
} HAL_ACL_KEY_EGR_PP_FLD_IDX_T;

typedef struct HAL_ACL_ADJ_ECMP_PBR_INFO_S {
    UI32_T is_ecmp;     /* avl key */
    UI32_T adj_ecmp_id; /* avl key : "adj id" or "ecmp group id" */
    UI32_T pbr_idx;     /* avl key : iev_rslt_u_flw_uc idx */
} HAL_ACL_ADJ_ECMP_PBR_INFO_T;

typedef struct HAL_ACL_QOS_PROF_IDX_INFO_S {
    UI32_T qos_vld;  /* avl key: qos_vld */
    UI32_T dscp;     /* avl key: dscp */
    UI32_T exp;      /* avl key: exp */
    UI32_T pcp;      /* avl key: pcp */
    UI32_T dei;      /* avl key: dei */
    UI32_T cnt;      /* reference count */
    UI32_T prof_idx; /* profile index */
} HAL_ACL_QOS_PROF_IDX_INFO_T;

typedef struct HAL_ACL_GROUP_INFO_S {
    UI32_T prio;
    UI32_T ucp_member_bmp; /* NB: flow group is fpu bmp */
#define HAL_ACL_GROUP_INFO_FLAGS_ACTIVE          (1U << 0)
#define HAL_ACL_GROUP_INFO_FLAGS_PREEMPT_BY_FLOW (1U << 1)
    UI32_T flags;
} HAL_ACL_GROUP_INFO_T;

typedef struct HAL_ACL_GROUP_CB_S {
    HAL_ACL_GROUP_INFO_T igr_group_info_arr[HAL_ACL_IGR_GROUP_NUM_MAX];
    HAL_ACL_GROUP_INFO_T flw_group_info_arr[HAL_ACL_FLW_GROUP_NUM_MAX];
    HAL_ACL_GROUP_INFO_T egr_group_info_arr[HAL_ACL_EGR_GROUP_NUM_MAX];
    HAL_ACL_GROUP_INFO_T igr_post_group_info_arr[HAL_ACL_IGR_POST_GROUP_NUM_MAX];
    HAL_ACL_GROUP_INFO_T egr_post_group_info_arr[HAL_ACL_EGR_POST_GROUP_NUM_MAX];
    UI32_T flw_group_id[HAL_ACL_FLW_GROUP_NUM_MAX];
    UI32_T igr_group_bmp;
    UI32_T egr_group_bmp;
    UI32_T igr_post_group_bmp;
    UI32_T egr_post_group_bmp;
    UI32_T flw_group_bmp;
} HAL_ACL_GROUP_CB_T;

typedef enum {
    HAL_ACL_WBDB_GROUP_CB_IGR_GROUP_INFO_ARR = 0,
    HAL_ACL_WBDB_GROUP_CB_FLW_GROUP_INFO_ARR,
    HAL_ACL_WBDB_GROUP_CB_EGR_GROUP_INFO_ARR,
    HAL_ACL_WBDB_GROUP_CB_GROUP_BMP,
    HAL_ACL_WBDB_UDF_CB_IGR_UDF_INFO_ARR,
    HAL_ACL_WBDB_UDF_CB_EGR_UDF_INFO_ARR,
    HAL_ACL_WBDB_ENTRY_CB_IGR_ENTRY_INFO_ARR,
    HAL_ACL_WBDB_ENTRY_CB_EGR_ENTRY_INFO_ARR,
    HAL_ACL_WBDB_ENTRY_CB_IGR_ENTRY_BMP,
    HAL_ACL_WBDB_ENTRY_CB_EGR_ENTRY_BMP,
    HAL_ACL_WBDB_ENTRY_CB_ENTRY_INTERNAL_ID,
    HAL_ACL_WBDB_ENTRY_CB_IGR_ENC_TCP_FLG_REF,
    HAL_ACL_WBDB_ENTRY_CB_EGR_ENC_TCP_FLG_REF,
    HAL_ACL_WBDB_FLOW_CB_ENTRY_INFO,
    HAL_ACL_WBDB_REWR_CB_REWR_PAGE,
    HAL_ACL_WBDB_ADJ_ECMP_AVL,
    HAL_ACL_WBDB_EGR_UCP_EN_BMP,
    HAL_ACL_WBDB_GROUP_CB_IGR_POST_GROUP_INFO_ARR,
    HAL_ACL_WBDB_GROUP_CB_EGR_POST_GROUP_INFO_ARR,
    HAL_ACL_WBDB_ENTRY_CB_IGR_POST_ENTRY_BMP,
    HAL_ACL_WBDB_ENTRY_CB_EGR_POST_ENTRY_BMP,
    HAL_ACL_WBDB_ENTRY_CB_IGR_POST_ENTRY_INFO_ARR,
    HAL_ACL_WBDB_ENTRY_CB_EGR_POST_ENTRY_INFO_ARR,
    HAL_ACL_WBDB_RIM_CB_FCM_ENTRY,
    HAL_ACL_WBDB_RIM_CB_REDIR_ENTRY,
    HAL_ACL_WBDB_LAST
} HAL_ACL_WBDB_T;

typedef enum {
    HAL_ACL_BASE_KEY_NONE,
    HAL_ACL_BASE_KEY_1X_L2,
    HAL_ACL_BASE_KEY_1X_ARP,
    HAL_ACL_BASE_KEY_2X_ARP_W_L2,
    HAL_ACL_BASE_KEY_1X_IPV4,
    HAL_ACL_BASE_KEY_2X_IPV4_W_L2,
    HAL_ACL_BASE_KEY_2X_IPV6,
    HAL_ACL_BASE_KEY_3X_IPV6_W_L2,
    HAL_ACL_BASE_KEY_1X_FCOE,
    HAL_ACL_BASE_KEY_2X_FCOE_W_L2,
    HAL_ACL_BASE_KEY_1X_MPLS,
    HAL_ACL_BASE_KEY_2X_MPLS_W_L2
} HAL_ACL_BASE_KEY_T;

typedef enum {
    HAL_ACL_KEY_BASE_CMN_FLD_1X_IGR = 0,
    HAL_ACL_KEY_BASE_CMN_FLD_2X_IGR,
    HAL_ACL_KEY_BASE_CMN_FLD_3X_IGR,
    HAL_ACL_KEY_BASE_CMN_FLD_1X_EGR,
    HAL_ACL_KEY_BASE_CMN_FLD_2X_EGR,
    HAL_ACL_KEY_BASE_CMN_FLD_3X_EGR,
    HAL_ACL_KEY_BASE_CMN_FLD_LAST
} HAL_ACL_KEY_BASE_CMN_FLD_IDX_T;

typedef enum {
    HAL_ACL_PBM_KEY_PACK_OFF_BASE_1X_IGR = 0,
    HAL_ACL_PBM_KEY_PACK_OFF_BASE_2X_WO_L2_IGR,
    HAL_ACL_PBM_KEY_PACK_OFF_BASE_2X_W_L2_IGR,
    HAL_ACL_PBM_KEY_PACK_OFF_BASE_3X_IGR,
    HAL_ACL_PBM_KEY_PACK_OFF_BASE_1X_EGR,
    HAL_ACL_PBM_KEY_PACK_OFF_BASE_2X_WO_L2_EGR,
    HAL_ACL_PBM_KEY_PACK_OFF_BASE_2X_W_L2_EGR,
    HAL_ACL_PBM_KEY_PACK_OFF_BASE_3X_EGR,
    HAL_ACL_PBM_KEY_PACK_OFF_UDF,
    HAL_ACL_PBM_KEY_PACK_OFF_LAST
} HAL_ACL_PBM_KEY_PACK_OFF_IDX_T;

typedef enum {
    HAL_ACL_IP_KEY_L4_W0_TCP_UDP,
    HAL_ACL_IP_KEY_L4_W0_ICMP,
    HAL_ACL_IP_KEY_L4_W0_IGMP,
} HAL_ACL_IP_KEY_L4_W0_T;

typedef struct HAL_ACL_LOU_INFO_S {
    UI32_T vld;

#define HAL_ACL_LOU_INFO_FLAGS_1Q (1U << 0)
    UI32_T flags;
} HAL_ACL_LOU_INFO_T;

typedef struct HAL_ACL_UDF_INFO_S {
    UI32_T vld;
    UI32_T pkg_0_cnt;
    UI32_T pkg_0_consecutive_bmp;
    UI32_T pkg_1_cnt;
    UI32_T pkg_1_consecutive_bmp;

    UI32_T flw_pkg_cnt;
    UI32_T flw_prof_id;
    UI32_T flw_pkg_consecutive_bmp;

    UI32_T flw_1_pkg_cnt;
    UI32_T flw_1_prof_id;

    HAL_ACL_LOU_INFO_T lou_info_arr[CLX_ACL_LOU_NUM];

#define HAL_ACL_UDF_INFO_FLAGS_PKT_FORMAT_1Q     (1U << 0)
#define HAL_ACL_UDF_INFO_FLAGS_PKG_INT_1Q        (1U << 1)
#define HAL_ACL_UDF_INFO_FLAGS_FLW_PKG_INT_1Q    (1U << 2)
#define HAL_ACL_UDF_INFO_FLAGS_FLW_1_PKG_INT_1Q  (1U << 3)
#define HAL_ACL_UDF_INFO_FLAGS_FLW_PROF_ID_VLD   (1U << 4)
#define HAL_ACL_UDF_INFO_FLAGS_FLW_1_PROF_ID_VLD (1U << 5)
#define HAL_ACL_UDF_INFO_FLAGS_L2_SA_LABEL       (1U << 6) // for NB control block
#define HAL_ACL_UDF_INFO_FLAGS_L2_DA_LABEL       (1U << 7) // for NB control block
#define HAL_ACL_UDF_INFO_FLAGS_L3_SA_LABEL       (1U << 8) // for NB control block
#define HAL_ACL_UDF_INFO_FLAGS_L3_DA_LABEL       (1U << 9) // for NB control block

    UI32_T flags;
} HAL_ACL_UDF_INFO_T;

typedef struct HAL_ACL_UDF_CB_S {
    HAL_ACL_UDF_INFO_T igr_udf_info_arr[HAL_ACL_UDF_PROFILE_NUM];
    HAL_ACL_UDF_INFO_T egr_udf_info_arr[HAL_ACL_UDF_PROFILE_NUM];
} HAL_ACL_UDF_CB_T;

typedef struct HAL_ACL_REWR_TLV_BIDX_INFO_S {
#define HAL_ACL_REWR_TLV_NORM_BIDX_BMP_WORDS ((HAL_ACL_REWR_TLV_BIDX_NUM * 3 - 1) / 32 + 1)

    UI32_T del_norm_bidx_bmp[HAL_ACL_REWR_TLV_NORM_BIDX_BMP_WORDS];
    UI32_T add_norm_bidx_bmp[HAL_ACL_REWR_TLV_NORM_BIDX_BMP_WORDS];
    UI32_T set_norm_bidx_bmp[HAL_ACL_REWR_TLV_NORM_BIDX_BMP_WORDS];
    UI32_T del_norm_bidx_max, add_norm_bidx_max, set_norm_bidx_max; /* 0-127   : l2 layer bidx
                                                                     * 128-255 : l3 layer bidx
                                                                     * 256-383 : l4 layer bidx
                                                                     */
    UI32_T first_add_l2_off_0_tlv_idx, first_add_l3_off_0_tlv_idx, first_add_l4_off_0_tlv_idx;
    /* the first rewr tlv idx that
       perform add action at offset 0 */
} HAL_ACL_REWR_TLV_BIDX_INFO_T;

typedef struct HAL_ACL_ENTRY_PACK_BASE_KEY_S {
    HAL_ACL_BASE_KEY_T type;
    UI32_T width;

    HAL_ACL_IP_KEY_L4_W0_T ip_key_l4_w0_type;          /* derived from classify.ipv4/ipv6_key */

#define HAL_ACL_ENTRY_PACK_BASE_QOS_KEY_1Q   (1U << 0) /* derived from classify.qos_key */
#define HAL_ACL_ENTRY_PACK_BASE_QOS_KEY_STAG (1U << 1) /* derived from classify.qos_key */
    UI32_T qos_key_info;

#define HAL_ACL_ENTRY_PACK_BASE_PP_KEY_1Q      (1U << 0) /* derived from classify.pp_info_key */
#define HAL_ACL_ENTRY_PACK_BASE_PP_KEY_VID_VLD (1U << 1) /* derived from classify.pp_info_key */
#define HAL_ACL_ENTRY_PACK_BASE_PP_KEY_L2_LBL  (1U << 2) /* derived from classify.pp_info_key */
#define HAL_ACL_ENTRY_PACK_BASE_PP_KEY_L3_LBL  (1U << 3) /* derived from classify.pp_info_key */
    UI32_T pp_key_info;

#define HAL_ACL_ENTRY_PACK_BASE_MAC_KEY_1Q (1U << 0) /* derived from classify.mac_key */
    UI32_T mac_key_info;

#define HAL_ACL_ENTRY_PACK_REPLACE_SA (1U << 0)
#define HAL_ACL_ENTRY_PACK_REPLACE_DA (1U << 1)
    UI32_T ip_key_info;
} HAL_ACL_ENTRY_PACK_BASE_KEY_T;

typedef struct HAL_ACL_UDF_INT_KEY_CFG_S {
#define HAL_ACL_PKG_PROF_FLW_LBL_VLD_L2_SA_OFFSET (0)
#define HAL_ACL_PKG_PROF_FLW_LBL_VLD_L2_DA_OFFSET (1)
#define HAL_ACL_PKG_PROF_FLW_LBL_VLD_L3_SA_OFFSET (2)
#define HAL_ACL_PKG_PROF_FLW_LBL_VLD_L3_DA_OFFSET (3)

    UI32_T flw_lbl_vld; /* IDS/EMI_RSLT_ACL/FLW_PKG_PROF.flw_lbl_vld */
    UI32_T int_key_vld; /* LT: IDS/EMI_RSLT_PKG_INT_KEY_VLD, MT: DIS/RWI_RSLT_PKG_INT_KEY_VLD*/
    UI32_T phy_port_vld;
} HAL_ACL_UDF_INT_KEY_CFG_T;

typedef struct HAL_ACL_ENTRY_PACK_UDF_KEY_S {
    CLX_ACL_UDF_KEY_T type;
    UI32_T width;
    HAL_ACL_UDF_INT_KEY_CFG_T int_key_cfg;                /* derived from udf prof */
    UI32_T pkg_0_cnt;                                     /* derived from udf prof */
    UI32_T pkg_1_cnt;                                     /* derived from udf prof */
    UI32_T pbm_msb;                                       /* derived from udf prof */

#define HAL_ACL_ENTRY_PACK_UDF_KEY_FLAGS_UDF_1Q (1U << 0) /* derived from udf prof */
    UI32_T flags;
} HAL_ACL_ENTRY_PACK_UDF_KEY_T;

typedef struct HAL_ACL_ENTRY_PACK_ACTION_S {
    CLX_ACL_TELM_TYPE_T telm_type;
    CLX_ACL_REDIRECT_T redirect_type;
    CLX_ACL_REWRITE_ACTION_T rewr_type[CLX_ACL_REWRITE_NUM];

#define HAL_ACL_ENTRY_PACK_ACTION_BYPASS_PRUNE     (1U << 0)
#define HAL_ACL_ENTRY_PACK_ACTION_MISC             (1U << 1)
#define HAL_ACL_ENTRY_PACK_ACTION_LOG              (1U << 2)
#define HAL_ACL_ENTRY_PACK_ACTION_RSN              (1U << 3)
#define HAL_ACL_ENTRY_PACK_ACTION_MIR              (1U << 4)
#define HAL_ACL_ENTRY_PACK_ACTION_SFLW             (1U << 5)
#define HAL_ACL_ENTRY_PACK_ACTION_DST_CNT          (1U << 6)
#define HAL_ACL_ENTRY_PACK_ACTION_SRV_CNT          (1U << 7)
#define HAL_ACL_ENTRY_PACK_ACTION_SRV_CNT2         (1U << 8)
#define HAL_ACL_ENTRY_PACK_ACTION_MARK             (1U << 9)
#define HAL_ACL_ENTRY_PACK_ACTION_POLICER          (1U << 10)
#define HAL_ACL_ENTRY_PACK_ACTION_QOS              (1U << 11)
#define HAL_ACL_ENTRY_PACK_ACTION_PBR              (1U << 12)
#define HAL_ACL_ENTRY_PACK_ACTION_QOS2             (1U << 13)
#define HAL_ACL_ENTRY_PACK_ACTION_TELM             (1U << 14)
#define HAL_ACL_ENTRY_PACK_ACTION_LABEL            (1U << 15)
#define HAL_ACL_ENTRY_PACK_ACTION_REDIR_INDEX_MODE (1U << 16)
    UI32_T flags;
} HAL_ACL_ENTRY_PACK_ACTION_T;

typedef struct HAL_ACL_ENTRY_PACK_INFO_S {
    UI32_T classify_flags;
    UI32_T ucp_pbm_en;
    CLX_PORT_BITMAP_T port_bitmap;
    HAL_ACL_ENTRY_PACK_BASE_KEY_T base_key;
    HAL_ACL_ENTRY_PACK_UDF_KEY_T udf_key;
    HAL_ACL_ENTRY_PACK_ACTION_T action;
} HAL_ACL_ENTRY_PACK_INFO_T;

typedef struct HAL_ACL_ENTRY_ALLOC_INFO_S {
    UI32_T tcp_flg;
    UI32_T enc_tcp_flg_idx;
    UI32_T pbr_tbl_id;
    UI32_T pbr_rslt_idx;
    UI32_T pbr_to_ecmp;
    UI32_T pbr_adj_ecmp_id; /* adj id or ecmp group id*/
    UI32_T pbr_sw_adj_idx;
    HAL_SFLOW_SRC_TYPE_T sflw_src_type;
    UI32_T sflw_prof_idx;
    UI32_T fcm_tbl_id;
    UI32_T fcm_idx; /* 1x/2x/4x view idx */
    UI32_T meter_hw_idx;
    UI32_T policer_meter_hw_idx;
    UI32_T srv_cnt_hw_idx;
    UI32_T dst_cnt_hw_idx;
    HAL_ACL_QOS_PROF_IDX_INFO_T qos_prof;
#define HAL_ACL_ENTRY_ALLOC_FLAGS_ENC_TCP_FLG_IDX_VLD      (1U << 0)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_PBR_RSLT_IDX_VLD         (1U << 1)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_PBR_ADJ_ECMP_ID_VLD      (1U << 2)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_SFLW_PROF_IDX_VLD        (1U << 3)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_FCM_IDX_VLD              (1U << 4)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_FCM_IDX_IS_FLOW          (1U << 5)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_QOS_PROF_VLD             (1U << 6)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_METER_HW_IDX_VLD         (1U << 7)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_POLICER_METER_HW_IDX_VLD (1U << 8)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_SRV_CNT_HW_IDX_VLD       (1U << 9)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_DST_CNT_HW_IDX_VLD       (1U << 10)
#define HAL_ACL_ENTRY_ALLOC_FLAGS_FCM_INDEX_MODE           (1U << 11)
    UI32_T flags;
} HAL_ACL_ENTRY_ALLOC_INFO_T;

typedef struct HAL_ACL_ENTRY_INFO_S {
    UI32_T group;          /* avl key */
    UI32_T prio;           /* avl key */
    UI32_T internal_id;    /* avl key */
    UI32_T sw_entry_id;    /* all one means the entry is not allocated yet */

    UI32_T hw_entry_id;    /* all one means the entry is not added yet */
    UI32_T alloc_entry_id; /* allocate id by hal_acl_allocEntryId*/
    UI32_T norm_width;
    CLX_ACL_GROUP_T type;
    HAL_ACL_ENTRY_PACK_INFO_T pack_info;
    HAL_ACL_ENTRY_ALLOC_INFO_T alloc_info;
} HAL_ACL_ENTRY_INFO_T;

typedef struct HAL_ACL_ENTRY_CB_S {
    HAL_ACL_ENTRY_INFO_T
    igr_sw_entry_info_arr[HAL_ACL_IGR_ENTRY_NUM_MAX]; /* index by logic_entry_id */
    HAL_ACL_ENTRY_INFO_T
    egr_sw_entry_info_arr[HAL_ACL_EGR_ENTRY_NUM_MAX]; /* index by logic_entry_id - egr_entry_id
                                                         offset, lt: 8k, mt: 12k */

    HAL_ACL_ENTRY_INFO_T
    igr_post_sw_entry_info_arr[HAL_ACL_IGR_POST_ENTRY_NUM_MAX]; /* index by logic_entry_id */
    HAL_ACL_ENTRY_INFO_T
    egr_post_sw_entry_info_arr[HAL_ACL_EGR_POST_ENTRY_NUM_MAX]; /* index by logic_entry_id -
                                                         egr_entry_id offset, lt: 8k, mt:  12k*/

    CMLIB_AVL_HEAD_T *ptr_igr_avl_head;                         /* node : HAL_ACL_ENTRY_INFO_T */
    CMLIB_AVL_HEAD_T *ptr_egr_avl_head;                         /* node : HAL_ACL_ENTRY_INFO_T */
    CMLIB_AVL_HEAD_T *ptr_igr_post_avl_head;                    /* node : HAL_ACL_ENTRY_INFO_T */
    CMLIB_AVL_HEAD_T *ptr_egr_post_avl_head;                    /* node : HAL_ACL_ENTRY_INFO_T */

    UI32_T igr_sw_entry_bmp[HAL_ACL_IGR_ENTRY_NUM_WORDS_MAX];
    UI32_T egr_sw_entry_bmp[HAL_ACL_EGR_ENTRY_NUM_WORDS_MAX];
    UI32_T igr_post_sw_entry_bmp[HAL_ACL_IGR_POST_ENTRY_NUM_WORDS_MAX];
    UI32_T egr_post_sw_entry_bmp[HAL_ACL_EGR_POST_ENTRY_NUM_WORDS_MAX];

    UI32_T igr_hw_entry_bmp[HAL_ACL_IGR_ENTRY_NUM_WORDS_MAX];
    UI32_T egr_hw_entry_bmp[HAL_ACL_EGR_ENTRY_NUM_WORDS_MAX];
    UI32_T igr_post_hw_entry_bmp[HAL_ACL_IGR_POST_ENTRY_NUM_WORDS_MAX];
    UI32_T egr_post_hw_entry_bmp[HAL_ACL_EGR_POST_ENTRY_NUM_WORDS_MAX];

    UI32_T igr_internal_id;
    UI32_T egr_internal_id;
    UI32_T igr_post_internal_id;
    UI32_T egr_post_internal_id;

    UI32_T igr_enc_tcp_flg_ref_arr[HAL_ACL_TCP_FLG_ENC_IDX_NUM]; /* ref. cnt of tcp_flg_enc_idx */
    UI32_T egr_enc_tcp_flg_ref_arr[HAL_ACL_TCP_FLG_ENC_IDX_NUM];
    UI32_T tcp_flg_encode;
    BOOL_T insert_order_descending;
} HAL_ACL_ENTRY_CB_T;

typedef struct HAL_ACL_FLOW_ENTRY_PACK_UDF_KEY_S {
    CLX_ACL_UDF_KEY_T type;
    UI32_T udf_prof_id;
    UI32_T flw_prof_id;                                        /* derived from udf prof */
    HAL_ACL_UDF_INT_KEY_CFG_T int_key_cfg;                     /* derived from udf prof */
    UI32_T pkg_cnt;                                            /* derived from udf prof */

#define HAL_ACL_FLOW_ENTRY_PACK_UDF_KEY_FLAGS_UDF_1Q (1U << 0) /* derived from udf prof */
    UI32_T flags;
} HAL_ACL_FLOW_ENTRY_PACK_UDF_KEY_T;

typedef struct HAL_ACL_FLOW_ENTRY_PACK_INFO_S {
    UI32_T classify_flags;
    HAL_ACL_FLOW_ENTRY_PACK_UDF_KEY_T udf_key;
    HAL_ACL_ENTRY_PACK_ACTION_T action;
} HAL_ACL_FLOW_ENTRY_PACK_INFO_T;

typedef struct HAL_ACL_FLOW_ENTRY_INFO_S {
    UI32_T key_tbl;  /* 0 : invalid */
    UI32_T key_idx;  /* 1x/2x/4x view key idx */
    UI32_T rslt_tbl;
    UI32_T rslt_idx; /* 1x/3x view rslt idx */

    HAL_ACL_FLOW_ENTRY_PACK_INFO_T pack_info;
    HAL_ACL_ENTRY_ALLOC_INFO_T alloc_info;
} HAL_ACL_FLOW_ENTRY_INFO_T;

typedef struct HAL_ACL_FLOW_CB_S {
    UI32_T entry_num;
    UI32_T entry_1x_offset;
    HAL_ACL_FLOW_ENTRY_INFO_T *ptr_entry_info;
} HAL_ACL_FLOW_CB_T;

typedef struct HAL_ACL_REWR_CB_S {
    UI32_T fcm_to_rewr_page_arr[HAL_ACL_FCM_REWR_PAGE_NUM];
    UI32_T rewr_page_ref_cnt_arr[HAL_ACL_FCM_REWR_PAGE_NUM]; /* number of fcm entries reference to
                                                                the rewr page */
} HAL_ACL_REWR_CB_T;

typedef struct HAL_ACL_AVL_FCM_INFO_S {
    UI32_T fcm_tbl_id; /* avl key */
    UI32_T fcm_idx;    /* avl key */
    UI32_T rewr_1x_idx;
    CLX_ACL_REWRITE_ACTION_T rewr_type[CLX_ACL_REWRITE_NUM];
#define HAL_ACL_AVL_FCM_INFO_FLAGS_FCM_IDX_IS_FLOW (1U << 0)
    UI32_T flags;
} HAL_ACL_AVL_FCM_INFO_T;

typedef struct HAL_ACL_AVL_REDIR_INFO_S {
    CLX_ACL_RIM_ALLOC_T pbr_type; /* avl key */
    UI32_T pbr_rslt_idx;          /* avl key */
    UI32_T pbr_adj_ecmp_id;       /* adj_id or ecmp_id */
} HAL_ACL_AVL_REDIR_INFO_T;

typedef struct HAL_ACL_RIM_CB_S {
    CMLIB_AVL_HEAD_T *ptr_fcm_avl_head;
    CMLIB_AVL_HEAD_T *ptr_redir_avl_head;
} HAL_ACL_RIM_CB_T;

typedef struct HAL_ACL_KEY_FLD_INFO_S {
    HAL_ACL_KEY_BASE_CMN_FLD_IDX_T key_base_cmn_fld_idx;
    HAL_ACL_KEY_MAC_FLD_IDX_T key_mac_fld_idx;
    HAL_ACL_KEY_ARP_FLD_IDX_T key_arp_fld_idx;
    HAL_ACL_KEY_IPV4_FLD_IDX_T key_ipv4_fld_idx;
    HAL_ACL_KEY_IPV6_FLD_IDX_T key_ipv6_fld_idx;
    HAL_ACL_KEY_FCOE_FLD_IDX_T key_fcoe_fld_idx;
    HAL_ACL_KEY_MPLS_FLD_IDX_T key_mpls_fld_idx;
    HAL_ACL_KEY_IGR_QOS_FLD_IDX_T key_igr_qos_fld_idx;
    HAL_ACL_KEY_EGR_QOS_FLD_IDX_T key_egr_qos_fld_idx;
    HAL_ACL_KEY_IGR_PP_FLD_IDX_T key_igr_pp_fld_idx;
    HAL_ACL_KEY_EGR_PP_FLD_IDX_T key_egr_pp_fld_idx;
    HAL_ACL_KEY_UDF_FLD_IDX_T key_udf_fld_idx;
} HAL_ACL_KEY_FLD_INFO_T;

typedef struct HAL_ACL_CB_S {
    HAL_ACL_GROUP_CB_T group_cb;
    HAL_ACL_UDF_CB_T udf_cb;
    HAL_ACL_ENTRY_CB_T entry_cb;
    HAL_ACL_FLOW_CB_T flow_cb;
    HAL_ACL_REWR_CB_T rewr_cb;
    HAL_ACL_RIM_CB_T rim_cb;
    CMLIB_AVL_HEAD_T *ptr_adj_ecmp_pbr_avl_head; /* node : HAL_ACL_ADJ_ECMP_PBR_INFO_T */
    CMLIB_AVL_HEAD_T *ptr_qos_prof_idx_avl_head; /* node: HAL_ACL_QOS_PROF_IDX_INFO_T */
    CLX_SEMAPHORE_ID_T mutex_sema_id;
    UI32_T switch_mode;
} HAL_ACL_CB_T;

extern HAL_ACL_CB_T _hal_acl_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init ACL module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - init success.
 * @return         CLX_E_NO_MEMORY        - allocate control block failed.
 * @return         CLX_E_OTHERS           - Init fail.
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_acl_init(const UI32_T unit);

/**
 * @brief Deinit ACL module.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK               - deinit success.
 * @return         CLX_E_OTHERS           - deInit fail.
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_acl_deinit(const UI32_T unit);

/**
 * @brief The API is used to add a UCP group.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     type                 - UCP group type: Ingress/Egress
 * @param [in]     priority             - UCP group priority
 * @param [in]     ptr_group_profile    - UCP group profile
 * @param [out]    ptr_group_id         - UCP group id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_addGroup(const UI32_T unit,
                 const CLX_ACL_GROUP_T type,
                 const UI32_T priority,
                 const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile,
                 UI32_T *ptr_group_id);

/**
 * @brief The API is used to delete a UCP group.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - UCP group type: Ingress/Egress
 * @param [in]     group_id    - The UCP group id to be deleted
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_delGroup(const UI32_T unit, const CLX_ACL_GROUP_T type, const UI32_T group_id);

/**
 * @brief The API is used to get the configuration information of UCP group.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     type                 - UCP group type: Ingress/Egress
 * @param [in]     group_id             - The UCP group id to be deleted
 * @param [out]    ptr_priority         - UCP group priority to be returned
 * @param [out]    ptr_group_profile    - UCP group profile to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_getGroup(const UI32_T unit,
                 const CLX_ACL_GROUP_T type,
                 const UI32_T group_id,
                 UI32_T *ptr_priority,
                 CLX_ACL_GROUP_PROFILE_T *ptr_group_profile);

/**
 * @brief The API is used to add a udf key profile.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     type                  - UCP group type: Ingress/Egress
 * @param [in]     udf_key_profile_id    - The udf key profile id to be added
 * @param [in]     ptr_pkt_format        - The packet format
 * @param [in]     ptr_profile           - The programming key format
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_addUdfKeyProfile(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_key_profile_id,
                         const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format,
                         const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

/**
 * @brief The API is used to delete a udf key profile.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     type                  - UCP group type: Ingress/Egress
 * @param [in]     udf_key_profile_id    - udf key profile id to be deleted
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_delUdfKeyProfile(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_key_profile_id);

/**
 * @brief The API is used to get the configuration information of udf key profile.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     type                  - UCP group type: Ingress/Egress
 * @param [in]     udf_key_profile_id    - The udf key profile id to be get
 * @param [out]    ptr_pkt_format        - The packet format information to be returned
 * @param [out]    ptr_profile           - The programming key format information to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_getUdfKeyProfile(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_key_profile_id,
                         CLX_ACL_PKT_FORMAT_T *ptr_pkt_format,
                         CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

/**
 * @brief The API is used to add/set the LOU configuration information.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - UCP group type: Ingress/Egress
 * @param [in]     id         - Udf key profile id.
 * @param [in]     lou_id     - The LOU id to be added/set
 * @param [in]     ptr_lou    - The LOU configuration information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_addLou(const UI32_T unit,
               const CLX_ACL_GROUP_T type,
               const UI32_T id,
               const UI32_T lou_id,
               const CLX_ACL_LOU_CFG_T *ptr_lou);

/**
 * @brief The API is used to delete the LOU configuration information.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     type      - UCP group type: Ingress/Egress
 * @param [in]     id        - Udf key profile id.
 * @param [in]     lou_id    - The LOU id to be deleted
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_delLou(const UI32_T unit, const CLX_ACL_GROUP_T type, const UI32_T id, const UI32_T lou_id);

/**
 * @brief The API is used to get the LOU configuration information.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - UCP group type: Ingress/Egress
 * @param [in]     id         - Udf key profile id.
 * @param [in]     lou_id     - The LOU id to be get
 * @param [out]    ptr_lou    - The LOU configuration information to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_getLou(const UI32_T unit,
               const CLX_ACL_GROUP_T type,
               const UI32_T id,
               const UI32_T lou_id,
               CLX_ACL_LOU_CFG_T *ptr_lou);

/**
 * @brief The API is used to allocate a logic id for UCP entry.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     type              - UCP group type: Ingress/Egress
 * @param [in]     group_id          - Allocate a entry id from UCP group
 * @param [in]     entry_priority    - entry priority
 * @param [out]    ptr_entry_id      - The entry id to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_allocEntryId(const UI32_T unit,
                     const CLX_ACL_GROUP_T type,
                     const UI32_T group_id,
                     const UI32_T entry_priority,
                     UI32_T *ptr_entry_id);

/**
 * @brief The API is used to free the logic id for UCP entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     entry_id    - entry id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_freeEntryId(const UI32_T unit, const UI32_T entry_id);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     entry_id              - Entry id
 * @param [out]    ptr_type              - the UCP group type of the entry id to be returned
 * @param [out]    ptr_group_id          - the group id of the entry id to be returned
 * @param [out]    ptr_entry_priority    - the entry priority of the entry id to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_getEntryIdInfo(const UI32_T unit,
                       const UI32_T entry_id,
                       CLX_ACL_GROUP_T *ptr_type,
                       UI32_T *ptr_group_id,
                       UI32_T *ptr_entry_priority);

/**
 * @brief The API is used to delete an UCP entry from HW.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     entry_id    - entry id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
hal_acl_delEntry(const UI32_T unit, const UI32_T entry_id);

/**
 * @brief The API is used to get an UCP entry from HW.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     entry_id        - entry id
 * @param [out]    ptr_entry_valid     - The status of the entry to be returned
 * @param [out]    ptr_classify    - The classified information of the entry to be returned
 * @param [out]    ptr_action      - The action to be taken of the entry to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_acl_getEntry(const UI32_T unit,
                 const UI32_T entry_id,
                 BOOL_T *ptr_entry_valid,
                 CLX_ACL_CLASSIFY_T *ptr_classify,
                 CLX_ACL_ACTION_T *ptr_action);

/**
 * @brief The API is used to delete an exact match entry from HW.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - UCP group type: Ingress/Egress
 * @param [in]     group_id    - Group id
 * @param [in]     entry_id    - Entry id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_acl_delFlowEntry(const UI32_T unit,
                     const CLX_ACL_GROUP_T type,
                     const UI32_T group_id,
                     const UI32_T entry_id);

/**
 * @brief The API is used to get an exact match entry from HW.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - UCP group type: Ingress/Egress
 * @param [in]     group_id        - Group id
 * @param [in]     entry_id        - Entry id
 * @param [out]    ptr_classify    - The classified information of the entry
 * @param [out]    ptr_action      - The action to be taken of the entry
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_acl_getFlowEntry(const UI32_T unit,
                     const CLX_ACL_GROUP_T type,
                     const UI32_T group_id,
                     const UI32_T entry_id,
                     CLX_ACL_CLASSIFY_T *ptr_classify,
                     CLX_ACL_ACTION_T *ptr_action);

/**
 * @brief The API is used to traverse UCP groups.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - UCP group type: Ingress/Egress
 * @param [in]     callback      - The callback function of type CLX_ACL_GROUP_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_acl_traverseGroup(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const CLX_ACL_GROUP_TRAVERSE_FUNC_T callback,
                      void *ptr_cookie);

/**
 * @brief The API is used to traverse UCP entries.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - UCP group type: Ingress/Egress
 * @param [in]     group_id      - Group id
 * @param [in]     callback      - The callback function of type CLX_ACL_ENTRY_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_acl_traverseEntry(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T group_id,
                      const CLX_ACL_ENTRY_TRAVERSE_FUNC_T callback,
                      void *ptr_cookie);

/**
 * @brief The API is used to traverse udf key profile.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - UCP group type: Ingress/Egress
 * @param [in]     callback      - The callback function of type
 * CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_acl_traverseUdfKeyProfile(const UI32_T unit,
                              const CLX_ACL_GROUP_T type,
                              const CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T callback,
                              void *ptr_cookie);

/**
 * @brief The API is used to traverse lou.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - UCP group type: Ingress/Egress
 * @param [in]     id            - Udf key profile id.
 * @param [in]     callback      - The callback function of type CLX_ACL_LOU_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_acl_traverseLou(const UI32_T unit,
                    const CLX_ACL_GROUP_T type,
                    const UI32_T id,
                    const CLX_ACL_LOU_TRAVERSE_FUNC_T callback,
                    void *ptr_cookie);

CLX_ERROR_NO_T
hal_acl_updateAdjInfo(const UI32_T unit,
                      const UI32_T adj_id,
                      const HAL_L3_ADJ_INFO_T *ptr_adj_info);

CLX_ERROR_NO_T
hal_acl_updateEcmpInfo(const UI32_T unit,
                       const UI32_T ecmp_group_id,
                       const HAL_L3_ECMP_INFO_T *ptr_ecmp_info);

CLX_ERROR_NO_T
hal_acl_getCapacity(const UI32_T unit,
                    const CLX_SWC_RSRC_T type,
                    const UI32_T param,
                    UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_acl_getUsage(const UI32_T unit, const CLX_SWC_RSRC_T type, const UI32_T param, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_acl_setPortProperty(const UI32_T unit,
                        const UI32_T port,
                        const CLX_PORT_PROPERTY_T property,
                        const UI32_T param0,
                        const UI32_T param1);

CLX_ERROR_NO_T
hal_acl_getPortProperty(const UI32_T unit,
                        const UI32_T port,
                        const CLX_PORT_PROPERTY_T property,
                        UI32_T *ptr_param0,
                        UI32_T *ptr_param1);

CLX_ERROR_NO_T
hal_acl_setActiveGroup(const UI32_T unit, const CLX_ACL_GROUP_T type, const UI32_T group_bmp);

CLX_ERROR_NO_T
hal_acl_getActiveGroup(const UI32_T unit, const CLX_ACL_GROUP_T type, UI32_T *ptr_group_bmp);

CLX_ERROR_NO_T
hal_acl_getEntryPbrIdx(const UI32_T unit,
                       const UI32_T is_flow,
                       const UI32_T entry_id,
                       UI32_T *ptr_tbl_id,
                       UI32_T *ptr_pbr_idx);

CLX_ERROR_NO_T
hal_acl_addUdfKeyProfileWValid(const UI32_T unit,
                               const CLX_ACL_GROUP_T type,
                               const UI32_T udf_key_profile_id,
                               const BOOL_T valid,
                               const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format,
                               const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

CLX_ERROR_NO_T
hal_acl_allocHwEntryId(const UI32_T unit,
                       const CLX_ACL_GROUP_T type,
                       const HAL_ACL_ENTRY_INFO_T *ptr_entry,
                       const UI32_T norm_width,
                       UI32_T *ptr_alloc_hw_entry_id);

CLX_ERROR_NO_T
hal_acl_getFlowEntryIdInfo(const UI32_T unit,
                           const UI32_T entry_id,
                           CLX_ACL_GROUP_T *ptr_type,
                           UI32_T *ptr_group_id);

CLX_ERROR_NO_T
hal_acl_rim_alloc(const UI32_T unit, const CLX_ACL_RIM_ALLOC_T type, UI32_T *index);

CLX_ERROR_NO_T
hal_acl_rim_free(const UI32_T unit, const CLX_ACL_RIM_ALLOC_T type, const UI32_T index);

CLX_ERROR_NO_T
hal_acl_rim_setAction(const UI32_T unit,
                      const CLX_ACL_RIM_ALLOC_T type,
                      const UI32_T index,
                      const void *action);

CLX_ERROR_NO_T
hal_acl_rim_getAction(const UI32_T unit,
                      const CLX_ACL_RIM_ALLOC_T type,
                      const UI32_T index,
                      void *action);

CLX_ERROR_NO_T
hal_acl_rim_traverseAction(const UI32_T unit,
                           const CLX_ACL_RIM_ALLOC_T type,
                           const CLX_ACL_RIM_TRAVERSE_FUNC_T callback,
                           void *ptr_cookie);
CLX_ERROR_NO_T
hal_acl_getGroupCb(const UI32_T unit,
                   const CLX_ACL_GROUP_T type,
                   const UI32_T is_flow,
                   HAL_ACL_GROUP_INFO_T **ptr_group_info_arr,
                   UI32_T **ptr_group_bmp,
                   UI32_T **prt_flow_group_id);
#endif /* End of HAL_ACL_H */
