/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_tm_pfc.h
 * PURPOSE:
 *      It provides TM module PFC API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NAMCHABARWA_TM_PFC_H
#define HAL_MT_NAMCHABARWA_TM_PFC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>
#include <osal/osal.h>
#include <hal/hal_tbl.h>
#include <hal/hal.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NAMCHABARWA_TM_PFC_TC_TO_QUEUE_PROFILE_NUM (4) /* NB tc2q map profile total num */
/* NB lossless pfc priority bitmap max num */
#define HAL_MT_NAMCHABARWA_TM_PFC_LOSSLESS_BITMAP_MAX_NUM (2)
#define HAL_MT_NAMCHABARWA_TM_PFC_PRI_MAX_NUM             (8) /* NB pfc pri max num */
#define HAL_MT_NAMCHABARWA_TM_MAX_PFC_SC_NUM              (2)
#define HAL_MT_NAMCHABARWA_TM_PFCWD_GROUP_NUM             (4)
#define HAL_MT_NAMCHABARWA_TM_PFCWD_PER_GROUP_PORT_NUM    (8)
#define HAL_MT_NAMCHABARWA_TM_PFC_TC_BITMAP_MAX           (0xFF) /* NB pfc tc max bitmap */
#define HAL_MT_NAMCHABARWA_TM_INVALID_VALUE               (0xFF)

/* TC classification */
typedef enum {
    HAL_MT_NAMCHABARWA_TM_IPL_TC_LOSSY0 = 0,
    HAL_MT_NAMCHABARWA_TM_IPL_TC_LOSSY1 = 1,
    HAL_MT_NAMCHABARWA_TM_IPL_TC_LOSSLESS0 = 2,
    HAL_MT_NAMCHABARWA_TM_IPL_TC_LOSSLESS1 = 3,
    HAL_MT_NAMCHABARWA_TM_IPL_TC_LAST
} HAL_MT_NAMCHABARWA_TM_IPL_TC_CLASSIFICATION_T;

typedef enum {
    HAL_MT_NAMCHABARWA_TM_EPL_TC_LOSSLESS0 = 0,
    HAL_MT_NAMCHABARWA_TM_EPL_TC_LOSSLESS1 = 1,
    HAL_MT_NAMCHABARWA_TM_EPL_TC_LOSSY0 = 2,
    HAL_MT_NAMCHABARWA_TM_EPL_TC_LOSSY1 = 3,
    HAL_MT_NAMCHABARWA_TM_EPL_TC_LAST
} HAL_MT_NAMCHABARWA_TM_EPL_TC_CLASSIFICATION_T;

/* IPL FIFO classification */
typedef enum {
    HAL_MT_NAMCHABARWA_TM_IPL_PLQ0 = 0, /* plq0 => lossy0 */
    HAL_MT_NAMCHABARWA_TM_IPL_PLQ1,     /* plq1 => lossy1 */
    HAL_MT_NAMCHABARWA_TM_IPL_PLQ2,     /* plq2 => lossless0 */
    HAL_MT_NAMCHABARWA_TM_IPL_PLQ3,     /* plq3 => lossless1 */
    HAL_MT_NAMCHABARWA_TM_IPL_PL_LAST
} HAL_MT_NAMCHABARWA_TM_IPL_PLQ_T;

/* EPL FIFO classification */
typedef enum {
    HAL_MT_NAMCHABARWA_TM_EPL_FIFO0 = 0, /* plq0 => lossless0 */
    HAL_MT_NAMCHABARWA_TM_EPL_FIFO1,     /* plq1 => lossless1 */
    HAL_MT_NAMCHABARWA_TM_EPL_FIFO2,     /* plq2 => lossy0~1 */
    HAL_MT_NAMCHABARWA_TM_EPL_FIFO_LAST
} HAL_MT_NAMCHABARWA_TM_EPL_FIFO_T;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_MT_NAMCHABARWA_TM_PFC_CB_S {
    CLX_LOCK_ID_T pfc_lock;
} HAL_MT_NAMCHABARWA_TM_PFC_CB_T;
/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The function is used to set TM BAC global lossless
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     tc_bitmap      - The bit map of BAC global lossless.
 * @param [in]     mode           - PFC mode.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_setBacGlobalLossless(const UI32_T unit,
                                           const UI32_T tc_bitmap,
                                           HAL_TM_FC_T mode);

/**
 * @brief The function is used to get TM BAC global lossless bit map.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_bit_map    - The bit map of BAC global lossless.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_getBacGlobalLossless(const UI32_T unit, UI32_T *ptr_bit_map);

/**
 * @brief The function is used to set the mapping of the PCP and the queue group.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     handler    - Ingress or egress queue handler.
 * @param [in]     ptr_pfc    - PFC interface structl.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 *                                          CLX_E_TABLE_FULL,       -- Table is full
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_setPfcMapping(const UI32_T unit,
                                        const UI32_T port,
                                        const CLX_TM_HANDLER_T handler,
                                        const CLX_TM_PFC_MAPPING_ENTRY_T *ptr_pfc);

/**
 * @brief The function is used to get the mapping of the PCP and the queue group.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     handler    - Ingress or egress queue handler.
 * @param [out]    ptr_pfc    - PFC interface struct.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_getPfcMapping(const UI32_T unit,
                                        const UI32_T port,
                                        const CLX_TM_HANDLER_T handler,
                                        CLX_TM_PFC_MAPPING_ENTRY_T *ptr_pfc);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_initWarm(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_deinitWarm(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_initWarmPfcWd(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_deinitWarmPfcWd(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

/**
 * @brief The function is used to init TM PFC HW & SW DB
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_initRsrc(const UI32_T unit);

/**
 * @brief The function is used to deinit TM PFC HW & SW DB
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_deinitRsrc(const UI32_T unit);

/**
 * @brief The function is used to init pfc information
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_initCfg(const UI32_T unit);

/**
 * @brief The function is used to set flow control mode.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     mode    - flow control mode(lossy, FC, PFC)
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_setFlowCtrlMode(const UI32_T unit,
                                          const UI32_T port,
                                          const HAL_TM_FC_T mode);

BOOL_T
hal_mt_namchabarwa_tm_pfc_isSQLossless(const UI32_T unit, const UI32_T port, const UI32_T queue);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_pfc_getPriToQueFifo(const UI32_T unit,
                                          const UI32_T port,
                                          const UI32_T queue_id,
                                          UI32_T *fifo);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_PfcWdDetectedPbmHandler(const UI32_T unit,
                                              const CLX_PORT_BITMAP_T timer0_pbm,
                                              const CLX_PORT_BITMAP_T timer1_pbm);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sendPfcWdAsynEvent(const UI32_T unit,
                                         const CLX_PORT_T port,
                                         const UI32_T queue,
                                         const HAL_TM_PFCWD_EVENT_T event,
                                         const UI32_T arg);

/**
 * @brief This API is used to configure PFCWD on queue.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - physical port ID
 * @param [in]     handler      - Egress queue handler
 * @param [in]     ptr_entry    - PFCWD Configuration.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_setPfcWd(const UI32_T unit,
                               const CLX_PORT_T port,
                               const CLX_TM_HANDLER_T handler,
                               CLX_TM_PFCWD_ENTRY_T *ptr_entry);

/**
 * @brief This API is used to get current configuration of PFCWD.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - physical port ID
 * @param [in]     handler      - Egress queue handler.
 * @param [out]    ptr_entry    - PFCWD Configuration
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_getPfcWd(const UI32_T unit,
                               const CLX_PORT_T port,
                               const CLX_TM_HANDLER_T handler,
                               CLX_TM_PFCWD_ENTRY_T *ptr_entry);

/**
 * @brief This API is used to get current state of PFCWD.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - physical port ID
 * @param [in]     handler      - queue handler.
 * @param [out]    ptr_state    - PFCWD Current State
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_getPfcWdState(const UI32_T unit,
                                    const CLX_PORT_T port,
                                    const CLX_TM_HANDLER_T handler,
                                    CLX_TM_PFCWD_STATE_T *ptr_state);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_PfcWdStateDisableEventHandler(const UI32_T unit,
                                                    const CLX_PORT_T port,
                                                    const UI8_T queue_id,
                                                    const HAL_TM_PFCWD_EVENT_T event,
                                                    HAL_TM_PFCWD_QUEUE_ENTRY_T *ptr_runing_entry);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_PfcWdStateOperationalEventHandler(
    const UI32_T unit,
    const CLX_PORT_T port,
    const UI8_T queue_id,
    const HAL_TM_PFCWD_EVENT_T event,
    HAL_TM_PFCWD_QUEUE_ENTRY_T *ptr_runing_entry);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_PfcWdStateStormedEventHandler(const UI32_T unit,
                                                    const CLX_PORT_T port,
                                                    const UI8_T queue_id,
                                                    const HAL_TM_PFCWD_EVENT_T event,
                                                    HAL_TM_PFCWD_QUEUE_ENTRY_T *ptr_runing_entry);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_PfcWdStateCfgNotRdyEventHandler(const UI32_T unit,
                                                      const CLX_PORT_T port,
                                                      const UI8_T queue_id,
                                                      const HAL_TM_PFCWD_EVENT_T event,
                                                      HAL_TM_PFCWD_QUEUE_ENTRY_T *ptr_runing_entry);

#endif /*end of HAL_MT_NAMCHABARWA_TM_PFC_H*/
