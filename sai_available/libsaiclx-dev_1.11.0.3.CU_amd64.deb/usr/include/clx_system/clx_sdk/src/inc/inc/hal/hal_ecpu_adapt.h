/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecpu_adapt.h
 * PURPOSE:
 *  1. Provide common used macros, data structures and elink API.
 */

#ifndef HAL_ECPU_ADAPT_H
#define HAL_ECPU_ADAPT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <stdbool.h>

/* NAMING CONSTANT DECLARATIONS
 */
#ifdef CONFIG_ECPU_SIDE
#ifdef CONFIG_MP_NUM_CPUS
#define CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM CONFIG_MP_NUM_CPUS
#else
#define CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM 1
#endif
#define CLX_SEMAPHORE_BINARY           (1)
#define CLX_SEMAPHORE_SYNC             (0)
#define CLX_SEMAPHORE_WAIT_FOREVER     K_FOREVER
#define osal_createSemaphore(n, c, id) k_sem_init(id, c, 1)
#define osal_destroySemaphore          k_sem_reset
#define osal_takeSemaphore             k_sem_take
#define osal_giveSemaphore             k_sem_give
#define HAL_IS_UNIT_VALID(__unit__)    ((__unit__) < CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM)
#define osal_alloc                     malloc
#define osal_free                      free
#define osal_memcpy                    memcpy
#define osal_memset                    memset
#define RING_BUFFER_SIZE(pelk_cb)      ((pelk_cb)->txbuf.pring->size)
#define RING_SIZE(pring)               ((pring)->pring->ring_size)
#define RING_INFO(pring)               ((pring)->pring)

#define GET_RING_WRINDEX(unit, pring, write_idx, read_idx) \
    do {                                                   \
        write_idx = pring->pring->write_idx;               \
        read_idx = pring->pring->read_idx;                 \
    } while (false)

#define GET_RING_RINDEX(unit, pinfo, pindex) \
    do {                                     \
        *pindex = pinfo->read_idx;           \
    } while (false)

#define GET_RING_WINDEX(unit, pinfo, pindex) \
    do {                                     \
        *pindex = pinfo->write_idx;          \
    } while (false)

#else
#define LOG_INF(...)              DIAG_PRINT(HAL_DBG_ECPU_ELINK, HAL_DBG_INFO, __VA_ARGS__)
#define LOG_WRN(...)              DIAG_PRINT(HAL_DBG_ECPU_ELINK, HAL_DBG_WARN, __VA_ARGS__)
#define LOG_ERR(...)              DIAG_PRINT(HAL_DBG_ECPU_ELINK, HAL_DBG_ERR, __VA_ARGS__)
#define RING_BUFFER_SIZE(pelk_cb) ((pelk_cb)->txbuf.ring.size)
#define RING_SIZE(pring)          ((pring)->ring.ring_size)
#define RING_INFO(pring)          (&(pring)->ring)

#define GET_RING_WRINDEX(unit, pring, write_idx, read_idx)                    \
    do {                                                                      \
        CLX_ERROR_NO_T ret = CLX_E_OK;                                        \
        UI32_T index[2] = {0};                                                \
        ret = aml_readReg(unit, pring->ring.write_idx, index, sizeof(index)); \
        if (ret != CLX_E_OK) {                                                \
            return CLX_E_OTHERS;                                              \
        }                                                                     \
        write_idx = index[0];                                                 \
        read_idx = index[1];                                                  \
    } while (false)

#define GET_RING_RINDEX(unit, pinfo, pindex)                                                   \
    do {                                                                                       \
        if (aml_readReg(unit, pinfo->read_idx, pindex, sizeof(pinfo->read_idx)) != CLX_E_OK) { \
            return CLX_E_OTHERS;                                                               \
        }                                                                                      \
    } while (false)

#define GET_RING_WINDEX(unit, pinfo, pindex)                                                     \
    do {                                                                                         \
        if (aml_readReg(unit, pinfo->write_idx, pindex, sizeof(pinfo->write_idx)) != CLX_E_OK) { \
            return CLX_E_OTHERS;                                                                 \
        }                                                                                        \
    } while (false)

#endif

#endif
