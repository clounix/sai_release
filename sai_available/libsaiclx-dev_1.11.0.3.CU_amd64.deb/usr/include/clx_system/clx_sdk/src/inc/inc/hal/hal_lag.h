/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  HAL_LAG.h
 * PURPOSE:
 *  Define the declartion for LAG module.
 *
 * NOTES:
 *
 */

#ifndef HAL_LAG_H
#define HAL_LAG_H

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_LAG_PORT_MAX_NUM               (512) /* Maximum for all chips */
#define HAL_LAG_GROUP_MAX_MEMBER_NUM       (512) /* Maximum for all chips */
#define HAL_LAG_PORT_LIST_ENTRY_NUM        (8192)
#define HAL_LAG_PORT_LIST_ENTRY_ID_MIN     (0)
#define HAL_LAG_PORT_LIST_ENTRY_ID_MAX     (HAL_LAG_PORT_LIST_ENTRY_NUM - 1)
#define HAL_LAG_PORT_LIST_RSVD_INVALID_IDX (0)
#define HAL_LAG_MEMBER_PBM_WORD_NUM        ((HAL_PHY_PORT_NUM + 31) / 32)
#define HAL_LAG_MEMBER_FLAG_NEW            (1UL << 0)
#define HAL_LAG_MEMBER_FLAG_ORIG           (1UL << 1)
#define HAL_LAG_HSH_SEL_HSH_NUM            (1024)

#define HAL_LAG_LIST_IS_ORI (0)
#define HAL_LAG_LIST_IS_ACT (1)

#define HAL_LAG_PHY_PORT_ENTRY_SIZE (MT_CDB_TDS_RSLT_POC_WORDS)

#define HAL_LAG_TAPPING_DISABLE      (0)
#define HAL_LAG_MGLAG_MAX_MEMBER_NUM (256)
/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_LAG_LOCK(unit) \
    HAL_COMMON_LOCK_RESOURCE(&_ext_hal_lag_cb[(unit)].mutex_sema_id, CLX_SEMAPHORE_WAIT_FOREVER)

#define HAL_LAG_UNLOCK(unit) HAL_COMMON_FREE_RESOURCE(&_ext_hal_lag_cb[(unit)].mutex_sema_id)

/* DATA TYPE DECLARATIONS
 */
typedef enum HAL_LAG_UPDATE_MODE_E {
    HAL_LAG_UPDATE_STATUS = 0, /* ori -> active,   update status active->new
                                  act -> ori/both, update status new->active */
    HAL_LAG_UPDATE_BASE,       /* both -> ori, sync ori and act base and update status active->new
                               both -> act, sync ori and act base and update status new->active */
    HAL_LAG_UPDATE_LAST
} HAL_LAG_UPDATE_MODE_T;

typedef struct HAL_LAG_FDL_GRP_HSH_INFO_S {
    UI32_T grp_id;
    UI32_T hsh_base;
    UI32_T hsh_use_num;
} HAL_LAG_FDL_GRP_HSH_INFO_T;

typedef struct HAL_LAG_CB_S {
    UI32_T port_list_ori_cont_entry_num_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    UI32_T port_list_ori_alloc_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    UI32_T port_list_act_cont_entry_num_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    UI32_T port_list_act_alloc_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    CLX_SEMAPHORE_ID_T mutex_sema_id;
    UI32_T *ptr_lag_sel_dma_buf_not_align;
    UI32_T *ptr_lag_sel_dma_buf;
    CLX_LAG_ATTRIB_T lag_attr[HAL_LAG_PORT_MAX_NUM];
    UI32_T lag_flag[HAL_LAG_PORT_MAX_NUM];
    UI32_T fdl_grp[HAL_FDL_GROUP_NUM]; /* store lag id */
    /* use for add/del member when link up/down in di view */
    UI32_T sw_lag_member_pbm[HAL_LAG_PORT_MAX_NUM][HAL_LAG_MEMBER_PBM_WORD_NUM];
    UI32_T lag_member_auto_update;
    UI32_T lag_mc_resilient;
    UI32_T lag_member_skip_port_check;
    UI32_T lag_tapping;
    /* RESILIENT */
    UI32_T resilient_en;
    /* algorithm_mode */
    CLX_LAG_ALGORITHM_MODE_T algorithm_mode;
} HAL_LAG_CB_T;

typedef enum {
    HAL_LAG_PORT_EVENT_CREATE = 0,
    HAL_LAG_PORT_EVENT_DESTROY,
    HAL_LAG_PORT_EVENT_SET_MEMBER,
    HAL_LAG_PORT_EVENT_LAST
} HAL_LAG_PORT_EVENT_T;

typedef struct HAL_LAG_PORT_LIST_ORIG_ENTRY_S {
    UI32_T di;
    UI32_T is_act;
} HAL_LAG_PORT_LIST_ORIG_ENTRY_T;

typedef struct HAL_LAG_PORT_LIST_ACT_ENTRY_S {
    UI32_T di;
    UI32_T is_new;
} HAL_LAG_PORT_LIST_ACT_ENTRY_T;

typedef struct HAL_LAG_INFO_S {
    UI32_T ori_base_idx;
    UI32_T ori_tot;
    HAL_LAG_PORT_LIST_ORIG_ENTRY_T ori_list[HAL_LAG_GROUP_MAX_MEMBER_NUM];
    UI32_T act_base_idx;
    UI32_T act_tot;
    HAL_LAG_PORT_LIST_ACT_ENTRY_T act_list[HAL_LAG_GROUP_MAX_MEMBER_NUM];
} HAL_LAG_INFO_T;

/* lag member info */
typedef struct HAL_LAG_MEMBER_INFO_S {
    UI32_T member_di;     /* Lag member di. */
    UI32_T member_weight; /* The weight of lag member. */
} HAL_LAG_MEMBER_INFO_T;

/* lag weight info */
typedef struct HAL_LAG_WEIGHT_INFO_S {
    UI32_T actual_num;
    UI32_T greatest_common_divisor;
} HAL_LAG_WEIGHT_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init LAG module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No memory.
 */
CLX_ERROR_NO_T
hal_lag_init(const UI32_T unit);

/**
 * @brief De-init LAG module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lag_deinit(const UI32_T unit);

/**
 * @brief This API is used to create LAG port.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lag_id          - IEEE802.1AX link aggregation ID
 * @param [out]    ptr_lag_port    - The pointer of the LAG port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
hal_lag_createPort(const UI32_T unit, const UI32_T lag_id, CLX_PORT_T *ptr_lag_port);

/**
 * @brief This API is used to destroy LAG port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lag_port    - LAG port
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
CLX_ERROR_NO_T
hal_lag_destroyPort(const UI32_T unit, const CLX_PORT_T lag_port);

/**
 * @brief This API is used to set LAG member.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     lag_port      - LAG port
 * @param [in]     member_cnt    - Member port count
 * @param [in]     ptr_member    - Member port list
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lag_setMember(const UI32_T unit,
                  const CLX_PORT_T lag_port,
                  const UI32_T member_cnt,
                  const CLX_PORT_T *ptr_member);

/**
 * @brief This API is used to get LAG member.
 *
 * @param [in]     unit                     - Device unit number
 * @param [in]     lag_port                 - LAG port
 * @param [in]     member_cnt               - Get member port count
 * @param [out]    ptr_member               - Member port list
 * @param [out]    ptr_actual_member_cnt    - Actual member port count
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lag_getMember(const UI32_T unit,
                  const CLX_PORT_T lag_port,
                  const UI32_T member_cnt,
                  CLX_PORT_T *ptr_member,
                  UI32_T *ptr_actual_member_cnt);

/**
 * @brief The API is used to traverse LAG.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_LAG_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_lag_traversePort(const UI32_T unit, const CLX_LAG_TRAVERSE_FUNC_T callback, void *ptr_cookie);

/**
 * @brief This API is used to get LAG range.
 *
 * @param [in]     unit         - Device unit number
 * @param [out]    ptr_range    - LAG range information
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lag_getRange(const UI32_T unit, CLX_RANGE_INFO_T *ptr_range);

/**
 * @brief This API is used to get LAG port from LAG ID.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lag_id          - IEEE802.1AX link aggregation ID
 * @param [out]    ptr_lag_port    - The pointer of the LAG port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lag_getPort(const UI32_T unit, const UI32_T lag_id, CLX_PORT_T *ptr_lag_port);

/**
 * @brief This API is used to get LAG ID from LAG port.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     lag_port      - LAG port
 * @param [out]    ptr_lag_id    - The pointer of the LAG Id
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lag_getKey(const UI32_T unit, const CLX_PORT_T lag_port, UI32_T *ptr_lag_id);

CLX_ERROR_NO_T
hal_lag_getSrcSuppTag(const UI32_T unit, const CLX_PORT_T lag_port, UI32_T *ptr_value);

CLX_ERROR_NO_T
hal_lag_getCapacity(const UI32_T unit,
                    const CLX_SWC_RSRC_T type,
                    const UI32_T param,
                    UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_lag_getUsage(const UI32_T unit, const CLX_SWC_RSRC_T type, const UI32_T param, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_lag_addFdlGroup(const UI32_T unit,
                    const CLX_PORT_T lag_port,
                    const CLX_FDL_INFO_T *ptr_fdl_info);

CLX_ERROR_NO_T
hal_lag_getFdlGroup(const UI32_T unit, const CLX_PORT_T lag_port, CLX_FDL_INFO_T *ptr_fdl_info);

CLX_ERROR_NO_T
hal_lag_delFdlGroup(const UI32_T unit, const CLX_PORT_T lag_port);

void
hal_lag_linkCallback(const UI32_T unit, const UI32_T port, const UI32_T link, void *ptr_cookie);

void
hal_lag_updateMember(const UI32_T unit, const UI32_T port, const UI32_T link, void *ptr_cookie);

CLX_ERROR_NO_T
hal_lag_getLag(const UI32_T unit, const CLX_PORT_T member_port, CLX_PORT_T *ptr_lag_port);

CLX_ERROR_NO_T
hal_lag_checkLag(const UI32_T unit, const CLX_PORT_TYPE_T lag_port, UI32_T *ptr_lag_di);

CLX_ERROR_NO_T
hal_lag_createMglag(const UI32_T unit, const UI32_T flags, UI32_T *ptr_mglag_id);

CLX_ERROR_NO_T
hal_lag_destroyMglag(const UI32_T unit, const UI32_T mglag_id);

CLX_ERROR_NO_T
hal_lag_setMglagMbr(const UI32_T unit,
                    const UI32_T mglag_id,
                    const UI32_T member_cnt,
                    const UI32_T *ptr_member);

CLX_ERROR_NO_T
hal_lag_getMglagMbr(const UI32_T unit,
                    const UI32_T mglag_id,
                    const UI32_T member_cnt,
                    UI32_T *ptr_member,
                    UI32_T *ptr_actual_member_cnt);

CLX_ERROR_NO_T
hal_lag_getMglagMbrCnt(const UI32_T unit, const UI32_T mglag_id, UI32_T *ptr_member_cnt);

CLX_ERROR_NO_T
hal_lag_getHashPathByHash(const UI32_T unit,
                          const CLX_SWC_HASH_TYPE_T hash_type,
                          const CLX_SWC_FLOW_HASH_KEY_T *ptr_hash_key,
                          const UI32_T lag_id,
                          CLX_LAG_HASHPATH_RSLT_INFO_T *ptr_rslt);

CLX_ERROR_NO_T
hal_lag_setWeightMember(const UI32_T unit,
                        const CLX_PORT_T lag_port,
                        const UI32_T member_cnt,
                        const CLX_LAG_MEMBER_INFO_T *ptr_member_info);

CLX_ERROR_NO_T
hal_lag_getWeightMember(const UI32_T unit,
                        const CLX_PORT_T lag_port,
                        const UI32_T member_cnt,
                        CLX_LAG_MEMBER_INFO_T *ptr_member_info,
                        UI32_T *ptr_actual_member_cnt);

CLX_ERROR_NO_T
hal_lag_setResilient(const UI32_T unit, const UI32_T is_enable);

CLX_ERROR_NO_T
hal_lag_getResilient(const UI32_T unit, UI32_T *is_enable);

CLX_ERROR_NO_T
hal_lag_setAlgoMode(const UI32_T unit, const CLX_LAG_ALGORITHM_MODE_T mode);

CLX_ERROR_NO_T
hal_lag_getAlgoMode(const UI32_T unit, CLX_LAG_ALGORITHM_MODE_T *mode);

CLX_ERROR_NO_T
hal_lag_getMemberByHash(const UI32_T unit,
                        const UI32_T lag_id,
                        UI32_T hash_value,
                        CLX_PORT_T *ptr_member,
                        UI32_T *di);
CLX_ERROR_NO_T
hal_lag_getLagMember(const UI32_T unit,
                     const CLX_PORT_T lag_port,
                     const UI32_T member_cnt,
                     CLX_PORT_T *ptr_member,
                     UI32_T *ptr_actual_member_cnt);

extern HAL_LAG_CB_T _ext_hal_lag_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

#endif /* End of HAL_LAG_H */
