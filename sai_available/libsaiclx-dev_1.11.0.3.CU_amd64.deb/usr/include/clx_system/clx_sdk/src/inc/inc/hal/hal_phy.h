/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_phy.h
 * PURPOSE:
 *      It provide HAL PHY module API.
 * NOTES:
 *
 */

#ifndef HAL_PHY_H
#define HAL_PHY_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PHY_BITS_PER_BYTE  (8)
#define HAL_PHY_BYTES_PER_WORD (2)
#define HAL_PHY_BITS_PER_WORD  (HAL_PHY_BITS_PER_BYTE * HAL_PHY_BYTES_PER_WORD)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_PHY_FOREACH_ABILITY(__field_value__, __field_start__, __field_end__, __ability__)     \
    for ((__ability__) = (__field_start__); (__ability__) < (__field_end__); (__ability__) <<= 1) \
        if (((__ability__) & (__field_value__)) > 0)

/* DATA TYPE DECLARACTIONS
 */
typedef enum {
    HAL_PHY_MDIO_DEVICE_TYPE_PMA_PMD = 1,
    HAL_PHY_MDIO_DEVICE_TYPE_WIS = 2,
    HAL_PHY_MDIO_DEVICE_TYPE_PCS = 3,
    HAL_PHY_MDIO_DEVICE_TYPE_PHY_XS = 4,
    HAL_PHY_MDIO_DEVICE_TYPE_DTE_XS = 5,
    HAL_PHY_MDIO_DEVICE_TYPE_TC = 6,
    HAL_PHY_MDIO_DEVICE_TYPE_AN = 7,
    HAL_PHY_MDIO_DEVICE_TYPE_VENDOR_1 = 30,
    HAL_PHY_MDIO_DEVICE_TYPE_VENDOR_2 = 31,
    HAL_PHY_MDIO_DEVICE_TYPE_LAST = (0x1UL << 5) /* 5-bit vlaue for device type */
} HAL_PHY_MDIO_DEVICE_TYPE_T;

typedef enum {
    HAL_PHY_ADMIN_STATE_TYPE_DISABLE = 0x0,
    HAL_PHY_ADMIN_STATE_TYPE_ENABLE,
    HAL_PHY_ADMIN_STATE_TYPE_LAST
} HAL_PHY_ADMIN_STATE_TYPE_T;

typedef enum {
    HAL_PHY_LINK_STATE_TYPE_DOWN = 0x0,
    HAL_PHY_LINK_STATE_TYPE_UP,
    HAL_PHY_LINK_STATE_TYPE_LAST
} HAL_PHY_LINK_STATE_TYPE_T;

typedef enum {
    HAL_PHY_SPEED_TYPE_1000M = 0x0,
    HAL_PHY_SPEED_TYPE_2500M,
    HAL_PHY_SPEED_TYPE_5G,
    HAL_PHY_SPEED_TYPE_10G,
    HAL_PHY_SPEED_TYPE_25G,
    HAL_PHY_SPEED_TYPE_26G,
    HAL_PHY_SPEED_TYPE_40G,
    HAL_PHY_SPEED_TYPE_50G,
    HAL_PHY_SPEED_TYPE_100G,
    HAL_PHY_SPEED_TYPE_200G,
    HAL_PHY_SPEED_TYPE_400G,
    HAL_PHY_SPEED_TYPE_800G,
    HAL_PHY_SPEED_TYPE_LAST
} HAL_PHY_SPEED_TYPE_T;

typedef enum {
    HAL_PHY_POWERUP_MODULE_TX,
    HAL_PHY_POWERUP_MODULE_RX,
    HAL_PHY_POWERUP_MODULE_LAST
} HAL_PHY_POWERUP_MODULE_TYPE_T;

typedef enum {
    HAL_PHY_LANE_SPEED_TYPE_10P3125 = 0x0,
    HAL_PHY_LANE_SPEED_TYPE_25P78125,
    HAL_PHY_LANE_SPEED_TYPE_26P5625,
    HAL_PHY_LANE_SPEED_TYPE_53P125_NRZ,
    HAL_PHY_LANE_SPEED_TYPE_53P125_PAM4,
    HAL_PHY_LANE_SPEED_TYPE_56P25_PAM4,
    HAL_PHY_LANE_SPEED_TYPE_106P25,
    HAL_PHY_LANE_SPEED_TYPE_112P5,
    HAL_PHY_LANE_SPEED_TYPE_LAST
} HAL_PHY_LANE_SPEED_TYPE_T;

typedef enum {
    HAL_PHY_ACC_HI_Z = 0,
    HAL_PHY_ACC_TERM_VSS_AC = 1, /**< termination to vss, onchip AC coupling */
    HAL_PHY_ACC_TERM_FL_AC = 2,  /**< floating termination, onchip AC coupling */
    // RES1 = 3, // Reserved
    // RES2 = 4, // Reserved
    HAL_PHY_ACC_TERM_VSS_DC = 5, /**< termination to vss, DC coupled */
    HAL_PHY_ACC_TERM_FL_DC = 6,  /**< floating termination to vss, DC coupled */
    // RES3 = 7, // Reserved
} HAL_PHY_ACC_TERM_MODE_T;

typedef enum {
    HAL_PHY_POWER_MODE_P0 = 0x0, /* power up, normal mode, eee disable */
    HAL_PHY_POWER_MODE_P0S,      /* wake : fast        up:P1,RX              down:TX */
    HAL_PHY_POWER_MODE_P1,       /* wake : medium      up:P2,synthersizer    down:RX/TX */
    HAL_PHY_POWER_MODE_P2, /* deep sleep,        up:receiver detection down:RX/TX,synthersizer */
    HAL_PHY_POWER_MODE_PD, /* power down */
    HAL_PHY_POWER_MODE_LAST
} HAL_PHY_POWER_MODE_T;

typedef enum {
    HAL_PHY_ATEST_MODE_ADC = 0x0,
    HAL_PHY_ATEST_MODE_PMON,
    HAL_PHY_ATEST_MODE_LAST
} HAL_PHY_ATEST_MODE_T;

typedef enum {
    HAL_PHY_EEE_TYPE_DISABLE = 0x0,
    HAL_PHY_EEE_TYPE_ENABLE,
    HAL_PHY_EEE_TYPE_LAST
} HAL_PHY_EEE_TYPE_T;

typedef enum {
    HAL_PHY_EEE_MODE_TYPE_DEEP_SLEEP = 0x0,
    HAL_PHY_EEE_MODE_TYPE_FAST_WAKE,
    HAL_PHY_EEE_MODE_TYPE_LAST
} HAL_PHY_EEE_MODE_TYPE_T;

typedef enum {
    HAL_PHY_FEC_TYPE_DISABLE = 0x0,
    HAL_PHY_FEC_TYPE_ENABLE,
    /* 3 RSFECs: RS528/RS544/RS272 */
    HAL_PHY_FEC_TYPE_RS528,
    HAL_PHY_FEC_TYPE_RS544,
    HAL_PHY_FEC_TYPE_RS272,
    HAL_PHY_FEC_TYPE_LAST
} HAL_PHY_FEC_TYPE_T;

typedef enum {
    HAL_PHY_FEC_CNT_TYPE_CERR = 0x0,
    HAL_PHY_FEC_CNT_TYPE_UCERR,
    HAL_PHY_FEC_CNT_TYPE_LANE_SERR,
    HAL_PHY_FEC_CNT_TYPE_LAST
} HAL_PHY_FEC_CNT_TYPE_T;

typedef struct HAL_PHY_FEC_CNT_S {
    BOOL_T cnt_valid;
    UI32_T cnt_value;
} HAL_PHY_FEC_CNT_T;

typedef enum {
    HAL_PHY_LOOPBACK_TYPE_DISABLE = 0x0,
    HAL_PHY_LOOPBACK_TYPE_LOCAL,
    HAL_PHY_LOOPBACK_TYPE_NEAR_END_PARALLEL, /* parallel loopback, pcs tx -> nep -> pcs rx */
    HAL_PHY_LOOPBACK_TYPE_FAR_END_SERIAL,    /* remote serial loopback, low-speed only support, link
                                                partner -> rx -> fes -> tx -> link partner*/
    HAL_PHY_LOOPBACK_TYPE_FAR_END_PARALLEL,  /* remote parallel loopback, link partner -> rx -> fep
                                                -> tx -> link partner*/
    HAL_PHY_LOOPBACK_TYPE_LAST
} HAL_PHY_LOOPBACK_TYPE_T;

typedef enum {
    HAL_PHY_INTF_LOCATION_TYPE_INTERNAL = 0x0,
    HAL_PHY_INTF_LOCATION_TYPE_EXTERNAL_SYSTEM_SIDE,
    HAL_PHY_INTF_LOCATION_TYPE_EXTERNAL_LINE_SIDE,
    HAL_PHY_INTF_LOCATION_TYPE_LAST
} HAL_PHY_INTF_LOCATION_TYPE_T;

typedef enum {
    HAL_PHY_PMA_INTF_TYPE_NONE = 0x0,
    HAL_PHY_PMA_INTF_TYPE_SGMII,
    HAL_PHY_PMA_INTF_TYPE_XFI,
    HAL_PHY_PMA_INTF_TYPE_SFI,
    HAL_PHY_PMA_INTF_TYPE_KR,
    HAL_PHY_PMA_INTF_TYPE_KR4,
    HAL_PHY_PMA_INTF_TYPE_CR4,
    HAL_PHY_PMA_INTF_TYPE_XLAUI,
    HAL_PHY_PMA_INTF_TYPE_XLPPI,
    HAL_PHY_PMA_INTF_TYPE_CAUI,
    HAL_PHY_PMA_INTF_TYPE_CPPI,
    HAL_PHY_PMA_INTF_TYPE_LAST
} HAL_PHY_PMA_INTF_TYPE_T;

typedef enum {
    HAL_PHY_PMD_INTF_TYPE_SGMII = 0x0,
    HAL_PHY_PMD_INTF_TYPE_1000BASE_X,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_ER,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_LR,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_SR,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_KR,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_CR,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_CR2,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_KR2,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_SR2,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_KR4,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_CR4,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_SR4,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_LR4,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_ER4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_CR10,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_SR10,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_KR4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_CR4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_SR4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_LR4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_ER4,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_KR4,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_CR4,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_SR4,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_DR4,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_LR8,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_CR8,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_SR16,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_KR,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_CR,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_SR,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_LR,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_ER,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_KR,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_CR,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_SR,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_CR2,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_SR2,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_KR2,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_CR2,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_SR2,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_MXLINK,  /* PHY internal use */
    HAL_PHY_PMD_INTF_TYPE_100GBASE_MXLINK, /* PHY internal use */
    HAL_PHY_PMD_INTF_TYPE_200GBASE_MXLINK, /* PHY internal use */
    HAL_PHY_PMD_INTF_TYPE_400GBASE_MXLINK, /* PHY internal use */
    HAL_PHY_PMD_INTF_TYPE_100GBASE_KR,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_CR,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_SR,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_KR2,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_CR2,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_SR2,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_SR4,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_CR4,
    HAL_PHY_PMD_INTF_TYPE_800GBASE_SR8,
    HAL_PHY_PMD_INTF_TYPE_800GBASE_CR8,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_SR8,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_CR8,
    HAL_PHY_PMD_INTF_TYPE_LAST
} HAL_PHY_PMD_INTF_TYPE_T;

typedef enum {
    HAL_PHY_AN_TARGET_TYPE_SELF = 0x0,
    HAL_PHY_AN_TARGET_TYPE_PEER,
    HAL_PHY_AN_TARGET_TYPE_LAST
} HAL_PHY_AN_TARGET_TYPE_T;

typedef enum {
    HAL_PHY_ANLT_TYPE_DISABLE = 0x0,
    HAL_PHY_ANLT_TYPE_ENABLE,
    HAL_PHY_ANLT_TYPE_ENABLE_LT, /* Link-training only without Auto negotiation */
    HAL_PHY_ANLT_TYPE_LAST
} HAL_PHY_ANLT_TYPE_T;

typedef enum {
    HAL_PHY_AN_RE_AN_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_RE_AN_TYPE_RESTART,
    HAL_PHY_AN_RE_AN_TYPE_LAST
} HAL_PHY_AN_RE_AN_TYPE_T;

typedef enum {
    HAL_PHY_AN_SPEED_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_SPEED_TYPE_1000BASE_KX = (0x1UL << 0),
    HAL_PHY_AN_SPEED_TYPE_10GBASE_KX4 = (0x1UL << 1),
    HAL_PHY_AN_SPEED_TYPE_10GBASE_KR = (0x1UL << 2),
    HAL_PHY_AN_SPEED_TYPE_40GBASE_KR4 = (0x1UL << 3),
    HAL_PHY_AN_SPEED_TYPE_40GBASE_CR4 = (0x1UL << 4),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_CR10 = (0x1UL << 5),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KP4 = (0x1UL << 6),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KR4 = (0x1UL << 7),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_CR4 = (0x1UL << 8),
    HAL_PHY_AN_SPEED_TYPE_25GBASE_KR_CR_S = (0x1UL << 9),
    HAL_PHY_AN_SPEED_TYPE_25GBASE_KR_CR = (0x1UL << 10),
    HAL_PHY_AN_SPEED_TYPE_2G5BASE_KX = (0x1UL << 11),
    HAL_PHY_AN_SPEED_TYPE_5GBASE_KR = (0x1UL << 12),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_KR_CR = (0x1UL << 13),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KR2_CR2 = (0x1UL << 14),
    HAL_PHY_AN_SPEED_TYPE_200GBASE_KR4_CR4 = (0x1UL << 15),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KR_CR = (0x1UL << 16),
    HAL_PHY_AN_SPEED_TYPE_200GBASE_KR2_CR2 = (0x1UL << 17),
    HAL_PHY_AN_SPEED_TYPE_400GBASE_KR4_CR4 = (0x1UL << 18),
    HAL_PHY_AN_SPEED_TYPE_800GBASE_KR8_CR8 = (0x1UL << 19),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_KR2_CR2 = (0x1UL << 20),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_KR2_CONSORTIUM = (0x1UL << 21),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_CR2_CONSORTIUM = (0x1UL << 22),
    HAL_PHY_AN_SPEED_TYPE_400GBASE_CONSORTIUM = (0x1UL << 23),
    HAL_PHY_AN_SPEED_TYPE_LAST = (0x1UL << 24)
} HAL_PHY_AN_SPEED_TYPE_T;

typedef enum {
    HAL_PHY_AN_EEE_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_EEE_TYPE_1000BASE_KX = (0x1UL << 0),
    HAL_PHY_AN_EEE_TYPE_10GBASE_KX4 = (0x1UL << 1),
    HAL_PHY_AN_EEE_TYPE_10GBASE_KR = (0x1UL << 2),
    HAL_PHY_AN_EEE_TYPE_40GBASE_KR4 = (0x1UL << 3),
    HAL_PHY_AN_EEE_TYPE_40GBASE_CR4 = (0x1UL << 4),
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR10 = (0x1UL << 5),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KP4 = (0x1UL << 6),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KR4 = (0x1UL << 7),
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR4 = (0x1UL << 8),
    HAL_PHY_AN_EEE_TYPE_25GBASE_R = (0x1UL << 9), /* NOTE: defined in EEE capability p8023_d3p2 */
    /*defined in section 78 of 8023cd_d3p4*/ /* not confirmed: waiting for SerDes confirmation */
    HAL_PHY_AN_EEE_TYPE_40GBASE_ER4 = (0x1UL << 10),
    HAL_PHY_AN_EEE_TYPE_50GBASE_KR = (0x1UL << 11),
    HAL_PHY_AN_EEE_TYPE_50GBASE_CR = (0x1UL << 12),
    HAL_PHY_AN_EEE_TYPE_50GBASE_SR = (0x1UL << 13),
    HAL_PHY_AN_EEE_TYPE_50GBASE_FR = (0x1UL << 14),
    HAL_PHY_AN_EEE_TYPE_50GBASE_LR = (0x1UL << 15),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KR2 = (0x1UL << 16),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_CR10   = (0x1UL << 17),*/
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR2 = (0x1UL << 17),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_SR10   = (0x1UL << 18),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_100GBASE_SR4 = (0x1UL << 18),
    HAL_PHY_AN_EEE_TYPE_100GBASE_SR2 = (0x1UL << 19),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_DR     = (0x1UL << 21),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_100GBASE_LR4 = (0x1UL << 20),
    HAL_PHY_AN_EEE_TYPE_100GBASE_ER4 = (0x1UL << 21),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_KR4    = (0x1UL << 25),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_CR4    = (0x1UL << 26),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_SR4    = (0x1UL << 27),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_DR4    = (0x1UL << 24),*/ /* Not support */
    /*defined in section 78 of 802d3bs_d3p5*/ /* not comfirmed: wiaitng for SerDes confirmation */
    /*HAL_PHY_AN_EEE_TYPE_200GBASE_DR4    = (0x1UL << 25),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_200GBASE_FR4 = (0x1UL << 22),
    HAL_PHY_AN_EEE_TYPE_200GBASE_LR4 = (0x1UL << 23),
    /*HAL_PHY_AN_EEE_TYPE_400GBASE_LR16   = (0x1UL << 28),*/ /*Not support*/
    /*HAL_PHY_AN_EEE_TYPE_400GBASE_DR4    = (0x1UL << 29),*/ /*Not support*/
    HAL_PHY_AN_EEE_TYPE_400GBASE_FR8 = (0x1UL << 24),
    HAL_PHY_AN_EEE_TYPE_400GBASE_LR8 = (0x1UL << 25),
    HAL_PHY_AN_EEE_TYPE_LAST
} HAL_PHY_AN_EEE_TYPE_T;

typedef enum {
    HAL_PHY_AN_FEC_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_FEC_TYPE_ABILITY = (0x1UL << 0),
    HAL_PHY_AN_FEC_TYPE_REQUEST = (0x1UL << 1),
    HAL_PHY_AN_FEC_TYPE_25G_RS_REQUEST = (0x1UL << 2),
    HAL_PHY_AN_FEC_TYPE_25G_BASER_REQUEST = (0x1UL << 3),
    HAL_PHY_AN_FEC_TYPE_LAST
} HAL_PHY_AN_FEC_TYPE_T;

typedef enum {
    HAL_PHY_AN_FC_TYPE_CL37_NO_PAUSE = 0x0,
    HAL_PHY_AN_FC_TYPE_CL73_NO_PAUSE = 0x0,
    HAL_PHY_AN_FC_TYPE_CL37_PAUSE = (0x1UL << 0),
    HAL_PHY_AN_FC_TYPE_CL37_ASM_DIR = (0x1UL << 1),
    HAL_PHY_AN_FC_TYPE_CL73_ASYM_PAUSE = (0x1UL << 2),
    HAL_PHY_AN_FC_TYPE_CL73_SYM_PAUSE = (0x1UL << 3),
    HAL_PHY_AN_FC_TYPE_LAST = (0x1UL << 4)
} HAL_PHY_AN_FC_TYPE_T;

typedef enum {
    HAL_PHY_AN_DUPLEX_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_DUPLEX_TYPE_FULL = (0x1UL << 0),
    HAL_PHY_AN_DUPLEX_TYPE_HALF = (0x1UL << 1),
    HAL_PHY_AN_DUPLEX_TYPE_LAST = (0x1UL << 2)
} HAL_PHY_AN_DUPLEX_TYPE_T;

typedef enum {
    HAL_PHY_AN_RF_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_RF_TYPE_1 = (0x1UL << 0),
    HAL_PHY_AN_RF_TYPE_2 = (0x1UL << 1),
    HAL_PHY_AN_RF_TYPE_LAST = (0x1UL << 2)
} HAL_PHY_AN_RF_TYPE_T;

typedef enum {
    HAL_PHY_EYE_SCAN_TYPE_DIAGRAM = 0x0,
    HAL_PHY_EYE_SCAN_TYPE_BER,
    HAL_PHY_EYE_SCAN_TYPE_LAST
} HAL_PHY_EYE_SCAN_TYPE_T;

typedef enum {
    HAL_PHY_PRBS_PATTERN_TYPE_DISABLE = 0x0,
    HAL_PHY_PRBS_PATTERN_TYPE_7,
    HAL_PHY_PRBS_PATTERN_TYPE_9,
    HAL_PHY_PRBS_PATTERN_TYPE_11,
    HAL_PHY_PRBS_PATTERN_TYPE_13,
    HAL_PHY_PRBS_PATTERN_TYPE_15,
    HAL_PHY_PRBS_PATTERN_TYPE_23,
    HAL_PHY_PRBS_PATTERN_TYPE_31,
    HAL_PHY_PRBS_PATTERN_TYPE_13Q,
    HAL_PHY_PRBS_PATTERN_TYPE_JP03A,
    HAL_PHY_PRBS_PATTERN_TYPE_JP03B,
    HAL_PHY_PRBS_PATTERN_TYPE_LINEARITY_PATTERN,
    HAL_PHY_PRBS_PATTERN_TYPE_FULL_RATE_CLOCK,
    HAL_PHY_PRBS_PATTERN_TYPE_HALF_RATE_CLOCK,
    HAL_PHY_PRBS_PATTERN_TYPE_QUARTER_RATE_CLOCK,
    HAL_PHY_PRBS_PATTERN_TYPE_PATT_32_1S_32_0S,
    HAL_PHY_PRBS_PATTERN_TYPE_SQUARE,
    HAL_PHY_PRBS_PATTERN_TYPE_LAST
} HAL_PHY_PRBS_PATTERN_TYPE_T;

typedef enum {
    HAL_PHY_PRBS_CHECKER_TYPE_DISABLE = 0x0,
    HAL_PHY_PRBS_CHECKER_TYPE_ENABLE,
    HAL_PHY_PRBS_CHECKER_TYPE_LAST
} HAL_PHY_PRBS_CHECKER_TYPE_T;

typedef enum {
    /** PRBS Disable */
    HAL_PHY_PRBS_CONFIG_DISABLE = 0,
    /** Enable both PRBS Transmitter and Receiver */
    HAL_PHY_PRBS_CONFIG_ENABLE_TX_RX,
    /** Enable PRBS Receiver */
    HAL_PHY_PRBS_CONFIG_ENABLE_RX,
    /** Enable PRBS Transmitter */
    HAL_PHY_PRBS_CONFIG_ENABLE_TX,
    HAL_PHY_PRBS_LAST
} HAL_PHY_PRBS_CONFIG_T;

typedef enum {
    HAL_PHY_AN_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_TYPE_ENABLE,
    HAL_PHY_AN_TYPE_LAST
} HAL_PHY_AN_TYPE_T;

typedef enum {
    HAL_PHY_LINK_TRAINING_TYPE_DISABLE = 0x0,
    HAL_PHY_LINK_TRAINING_TYPE_ENABLE,
    HAL_PHY_LINK_TRAINING_TYPE_LAST
} HAL_PHY_LINK_TRAINING_TYPE_T;

typedef enum {
    HAL_PHY_PRBS_BER_TYPE_DISABLE = 0x0,
    HAL_PHY_PRBS_BER_TYPE_BER4,
    HAL_PHY_PRBS_BER_TYPE_BER5,
    HAL_PHY_PRBS_BER_TYPE_BER6,
    HAL_PHY_PRBS_BER_TYPE_LAST
} HAL_PHY_PRBS_BER_TYPE_T;

typedef struct HAL_PHY_PRBS_CHECKER_S {
    HAL_PHY_PRBS_CHECKER_TYPE_T checker_mode;
    HAL_PHY_PRBS_BER_TYPE_T ber_mode;
} HAL_PHY_PRBS_CHECKER_T;

typedef enum {
    HAL_PHY_PRBS_CHKSTS_TYPE_UNLOCK = 0x0,
    HAL_PHY_PRBS_CHKSTS_TYPE_PASS = 0x1,
    HAL_PHY_PRBS_CHKSTS_TYPE_FAIL = 0x3,
    HAL_PHY_PRBS_CHKSTS_TYPE_LAST
} HAL_PHY_PRBS_CHKSTS_TYPE_T;

typedef struct HAL_PHY_PRBS_ERRCNT_S {
    HAL_PHY_PRBS_CHKSTS_TYPE_T cmpsts;
    UI32_T errcnt;
} HAL_PHY_PRBS_ERRCNT_T;

typedef enum {
    HAL_PHY_SERDES_DUMP_TYPE_MEM = 0x0,
    HAL_PHY_SERDES_DUMP_TYPE_REG,
    HAL_PHY_SERDES_DUMP_TYPE_COEF,
    HAL_PHY_SERDES_DUMP_TYPE_MSGQ,
    HAL_PHY_SERDES_DUMP_TYPE_LAST
} HAL_PHY_SERDES_DUMP_TYPE_T;

typedef enum {
    HAL_PHY_LED_MODE_TYPE_NORMAL = 0x0,
    HAL_PHY_LED_MODE_TYPE_FORCE,
    HAL_PHY_LED_MODE_TYPE_BIT_ON,
    HAL_PHY_LED_MODE_TYPE_BIT_OFF,
    HAL_PHY_LED_MODE_TYPE_LAST
} HAL_PHY_LED_MODE_TYPE_T;

typedef enum {
    HAL_PHY_LED_STS_TYPE_NORMAL_ON = 0x0,
    HAL_PHY_LED_STS_TYPE_NORMAL_OFF,
    HAL_PHY_LED_STS_TYPE_FORCE_ON,
    HAL_PHY_LED_STS_TYPE_FORCE_OFF,
    HAL_PHY_LED_STS_TYPE_LAST
} HAL_PHY_LED_STS_TYPE_T;

typedef enum {
    HAL_PHY_PROPERTY_TYPE_LANE_SWAP_TX = 0x0,
    HAL_PHY_PROPERTY_TYPE_LANE_SWAP_RX,
    HAL_PHY_PROPERTY_TYPE_POLARITY_REV_TX,
    HAL_PHY_PROPERTY_TYPE_POLARITY_REV_RX,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C0,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C1,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C2,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_CN1,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_CN2,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_CN3,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C3,
    HAL_PHY_PROPERTY_TYPE_REFCLK_ROUTE,
    HAL_PHY_PROPERTY_TYPE_LAST
} HAL_PHY_PROPERTY_TYPE_T;

typedef struct {
#define HAL_PHY_RX_EQ_FLAGS_MLSD           (1UL << 0)
#define HAL_PHY_RX_EQ_FLAGS_CTLERATE       (1UL << 1)
#define HAL_PHY_RX_EQ_FLAGS_CTLEADAPT      (1UL << 2)
#define HAL_PHY_RX_EQ_FLAGS_VGAADAPT       (1UL << 3)
#define HAL_PHY_RX_EQ_FLAGS_ACCBOOST       (1UL << 4)
#define HAL_PHY_RX_EQ_FLAGS_DFE            (1UL << 5)
#define HAL_PHY_RX_EQ_FLAGS_DFERATIO       (1UL << 6)
#define HAL_PHY_RX_EQ_FLAGS_FFETAP         (1UL << 7)
#define HAL_PHY_RX_EQ_FLAGS_CTLECAPADAPT   (1UL << 8)
#define HAL_PHY_RX_EQ_FLAGS_BACKGROUNDADAP (1UL << 9)
    UI32_T flags;
    UI32_T rx_acc_boost;
    UI32_T ctle_adapt_enable;
    UI32_T ctle_boost_a;
    UI32_T ctle_takeover;
    UI32_T ctle_takeover_ratio;
    UI32_T ctle_rate;
    UI32_T vga_adapt_enable;
    UI32_T vga_cap;
    UI32_T vga_takeover;
    UI32_T vga_takeover_ratio;
    UI32_T tap_count;
    UI32_T dfe_adapt_enable;
    UI32_T mlsd_enable;
    UI32_T dfe_ratio;
    UI32_T ctle_cap_adapt;
    UI32_T backgound_adapt_enable;
} HAL_PHY_RX_EQPARAMS_T;

/**
 * mountain:
 * 'CM3': c(-3) value (pre-cursor 3), up to 7 max, 3b unsigned
 * 'CM2': c(-2) value  (pre-cursor 2), up to 7 max, 3b unsigned
 * 'CM1': c(-1) value  (pre-cursor 1), up to 24 max, 6b unsigned
 * 'C0': c(0) value  (main cursor), up to 60 max, 6b unsigned
 * 'C1': c(1) value  (post-cursor 1), up to 24 max, 6b unsigned
 * 'MAIN_OR_MAX': 0 - c0 is main cursor, 1 - c0 is max elements
 */
typedef struct HAL_PHY_TX_COEF_S {
#define HAL_PHY_TX_COEF_FLAGS_C0  (1UL << 0) /* C0 must the last set coefficient */
#define HAL_PHY_TX_COEF_FLAGS_C1  (1UL << 1)
#define HAL_PHY_TX_COEF_FLAGS_CN1 (1UL << 2)
#define HAL_PHY_TX_COEF_FLAGS_C2  (1UL << 3)
#define HAL_PHY_TX_COEF_FLAGS_CN2 (1UL << 4)
#define HAL_PHY_TX_COEF_FLAGS_CN3 (1UL << 5)
#define HAL_PHY_TX_COEF_FLAGS_C3  (1UL << 6)
    UI32_T flags;
    UI32_T cn3;
    UI32_T cn2;
    UI32_T cn1;
    UI32_T c0;
    UI32_T c1;
    UI32_T c2;
    UI32_T main_or_max;
    UI32_T c3;
} HAL_PHY_TX_COEF_T;

#if defined(CLX_EN_BIG_ENDIAN)
typedef union {
    UI32_T value;
    struct {
        UI32_T psel : 1;
        UI32_T rsv : 15;
        UI32_T addr : 16;
    } field;
} HAL_PHY_PHY_ADDR_T;
#else
typedef union {
    UI32_T value;
    struct {
        UI32_T addr : 16;
        UI32_T rsv : 15;
        UI32_T psel : 1;
    } field;
} HAL_PHY_PHY_ADDR_T;
#endif

typedef struct {
    CLX_ERROR_NO_T (*init)(const UI32_T unit, const UI32_T port_id);
    CLX_ERROR_NO_T (*deinit)(const UI32_T unit, const UI32_T port_id);

    CLX_ERROR_NO_T(*setAdminState)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_ADMIN_STATE_TYPE_T admin_state);
    CLX_ERROR_NO_T(*getAdminState)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_ADMIN_STATE_TYPE_T *ptr_admin_state);

    CLX_ERROR_NO_T(*getLinkState)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_LINK_STATE_TYPE_T *ptr_link_state);

    CLX_ERROR_NO_T(*setSpeed)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_SPEED_TYPE_T speed);
    CLX_ERROR_NO_T(*getSpeed)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_SPEED_TYPE_T *ptr_speed);

    CLX_ERROR_NO_T (*setEee)(const UI32_T unit, const UI32_T port_id, const HAL_PHY_EEE_TYPE_T eee);
    CLX_ERROR_NO_T (*getEee)(const UI32_T unit, const UI32_T port_id, HAL_PHY_EEE_TYPE_T *ptr_eee);

    CLX_ERROR_NO_T(*setEeeMode)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_EEE_MODE_TYPE_T eee_mode);
    CLX_ERROR_NO_T(*getEeeMode)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_EEE_MODE_TYPE_T *ptr_eee_mode);

    CLX_ERROR_NO_T (*setFec)(const UI32_T unit, const UI32_T port_id, const HAL_PHY_FEC_TYPE_T fec);
    CLX_ERROR_NO_T (*getFec)(const UI32_T unit, const UI32_T port_id, HAL_PHY_FEC_TYPE_T *ptr_fec);

    CLX_ERROR_NO_T(*setLoopback)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
     const HAL_PHY_LOOPBACK_TYPE_T loopback);
    CLX_ERROR_NO_T(*getLoopback)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
     HAL_PHY_LOOPBACK_TYPE_T *ptr_loopback);

    CLX_ERROR_NO_T(*setPmaIntf)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
     const HAL_PHY_PMA_INTF_TYPE_T pma_intf);
    CLX_ERROR_NO_T(*getPmaIntf)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
     HAL_PHY_PMA_INTF_TYPE_T *ptr_pma_intf);

    CLX_ERROR_NO_T(*setPmdIntf)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_PMD_INTF_TYPE_T pmd_intf);
    CLX_ERROR_NO_T(*getPmdIntf)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_PMD_INTF_TYPE_T *ptr_pmd_intf);

    CLX_ERROR_NO_T (*setAn)(const UI32_T unit, const UI32_T port_id, const HAL_PHY_ANLT_TYPE_T an);
    CLX_ERROR_NO_T (*getAn)(const UI32_T unit, const UI32_T port_id, HAL_PHY_ANLT_TYPE_T *ptr_an);

    CLX_ERROR_NO_T(*setAnReAn)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_RE_AN_TYPE_T an_re_an);
    CLX_ERROR_NO_T(*getAnReAn)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_AN_RE_AN_TYPE_T *ptr_an_re_an);

    CLX_ERROR_NO_T(*setAnSpeed)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_SPEED_TYPE_T an_speed);
    CLX_ERROR_NO_T(*getAnSpeed)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_AN_TARGET_TYPE_T an_target,
     HAL_PHY_AN_SPEED_TYPE_T *ptr_an_speed);

    CLX_ERROR_NO_T(*setAnEee)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_EEE_TYPE_T an_eee);
    CLX_ERROR_NO_T(*getAnEee)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_AN_TARGET_TYPE_T an_target,
     HAL_PHY_AN_EEE_TYPE_T *ptr_an_eee);

    CLX_ERROR_NO_T(*setAnFec)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_FEC_TYPE_T an_fec);
    CLX_ERROR_NO_T(*getAnFec)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_AN_TARGET_TYPE_T an_target,
     HAL_PHY_AN_FEC_TYPE_T *ptr_an_fec);

    CLX_ERROR_NO_T(*setAnFc)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_FC_TYPE_T an_fc);
    CLX_ERROR_NO_T(*getAnFc)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_AN_TARGET_TYPE_T an_target,
     HAL_PHY_AN_FC_TYPE_T *ptr_an_fc);

    CLX_ERROR_NO_T(*setAnDuplex)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_DUPLEX_TYPE_T an_duplex);
    CLX_ERROR_NO_T(*getAnDuplex)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_AN_TARGET_TYPE_T an_target,
     HAL_PHY_AN_DUPLEX_TYPE_T *ptr_an_duplex);

    CLX_ERROR_NO_T(*setAnRf)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_RF_TYPE_T an_rf);
    CLX_ERROR_NO_T(*getAnRf)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_AN_TARGET_TYPE_T an_target,
     HAL_PHY_AN_RF_TYPE_T *ptr_an_rf);

    CLX_ERROR_NO_T(*setPhyCfg)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_cnt,
     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
     const HAL_PHY_PROPERTY_TYPE_T property_type,
     const UI32_T *ptr_property);
    CLX_ERROR_NO_T(*getPhyCfg)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_cnt,
     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
     const HAL_PHY_PROPERTY_TYPE_T property_type,
     UI32_T *ptr_property);
    CLX_ERROR_NO_T(*setC45Cfg)
    (const UI32_T unit,
     const UI32_T eth_macro,
     const UI32_T lane,
     const UI32_T dev_type,
     const UI32_T reg_addr,
     const UI32_T reg);
    CLX_ERROR_NO_T(*getC45Cfg)
    (const UI32_T unit,
     const UI32_T eth_macro,
     const UI32_T lane,
     const UI32_T dev_type,
     const UI32_T reg_addr,
     UI32_T *ptr_reg);
    CLX_ERROR_NO_T (*getTemperature)(const UI32_T unit, const UI32_T port_id, I32_T *ptr_temp);

    CLX_ERROR_NO_T(*dumpEyeScan)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_cnt,
     const HAL_PHY_EYE_SCAN_TYPE_T property,
     const UI32_T sample_deep);

    CLX_ERROR_NO_T(*setPrbsPattern)
    (const UI32_T unit, const UI32_T port_id, const HAL_PHY_PRBS_PATTERN_TYPE_T prbs_pattern);

    CLX_ERROR_NO_T(*getPrbsPattern)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_PRBS_PATTERN_TYPE_T *ptr_prbs_pattern);

    CLX_ERROR_NO_T(*setPrbsChecker)
    (const UI32_T unit,
     const UI32_T port_id,
     const HAL_PHY_PRBS_CHECKER_TYPE_T prbs_checker,
     const UI32_T ber_mode);

    CLX_ERROR_NO_T(*getPrbsChecker)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_PRBS_CHECKER_TYPE_T *ptr_prbs_checker);

    CLX_ERROR_NO_T(*setPrbsGenerator)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_PRBS_CONFIG_T prbs_gen);

    CLX_ERROR_NO_T(*getPrbsGenerator)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_PRBS_CONFIG_T *prbs_gen);

    CLX_ERROR_NO_T(*getPrbsErrorCnt)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_bmp,
     HAL_PHY_PRBS_BER_TYPE_T *ptr_ber_mode,
     HAL_PHY_PRBS_ERRCNT_T *ptr_error_cnt);

    CLX_ERROR_NO_T(*setLedBit)
    (const UI32_T unit, const UI32_T led_id, const UI32_T bit_id, const UI32_T *ptr_led_mode);

    CLX_ERROR_NO_T(*getLedBit)
    (const UI32_T unit, const UI32_T led_id, const UI32_T bit_id, UI32_T *ptr_led_mode);

    CLX_ERROR_NO_T (*setMdioRate)(const UI32_T unit, const UI32_T chn_id, const UI32_T rate_khz);

    void (*setPhyAddr)(void);
    CLX_ERROR_NO_T(*getPhyAddr)
    (const UI32_T unit, const UI32_T port_id, UI32_T *ptr_up_id, HAL_PHY_PHY_ADDR_T *ptr_phy_addr);

    CLX_ERROR_NO_T(*dumpSerDesInfo)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_bmp,
     const HAL_PHY_SERDES_DUMP_TYPE_T dump_type,
     const UI32_T more);

    CLX_ERROR_NO_T(*setTxCoef)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_id,
     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
     HAL_PHY_TX_COEF_T *ptr_tx_coef);

    CLX_ERROR_NO_T(*getTxCoef)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_id,
     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
     HAL_PHY_TX_COEF_T *ptr_tx_coef);

    CLX_ERROR_NO_T (*setMxLink)(const UI32_T unit, const UI32_T port_id, const UI32_T enable);

    CLX_ERROR_NO_T (*getMxLink)(const UI32_T unit, const UI32_T port_id, UI32_T *ptr_enable);

    CLX_ERROR_NO_T(*getFecCnt)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T land_id,
     const HAL_PHY_FEC_CNT_TYPE_T cnt_type,
     HAL_PHY_FEC_CNT_T *ptr_cnt);

    CLX_ERROR_NO_T(*setPrbsErrInject)
    (const UI32_T unit, const UI32_T port_id, const UI32_T num_err);

    CLX_ERROR_NO_T(*setPrbsErrCntClear)
    (const UI32_T unit, const UI32_T port_id, const UI32_T lane_bmp);

    CLX_ERROR_NO_T (*getFwVersion)(const UI32_T unit, UI32_T *version_eth, UI32_T *version_cpi);

    CLX_ERROR_NO_T(*setRxEqTunning)
    (const UI32_T unit, const UI32_T port_id, const UI32_T lane_bmp, const UI32_T phase);

    CLX_ERROR_NO_T (*getPhyRate)(const UI32_T unit, const UI32_T port_id, UI32_T *phy_rate);

    CLX_ERROR_NO_T(*setIsolaMode)
    (const UI32_T unit, const UI32_T port_id, const UI32_T lane_bmp, const UI32_T enable);

    CLX_ERROR_NO_T(*setTxRxPowerup)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_bmp,
     const HAL_PHY_POWERUP_MODULE_TYPE_T module,
     const HAL_PHY_LANE_SPEED_TYPE_T pma_speed);

    CLX_ERROR_NO_T (*setTxElecidle)(const UI32_T unit, const UI32_T port_id, const UI32_T enable);

    CLX_ERROR_NO_T (*getTxElecidle)(const UI32_T unit, const UI32_T port_id, UI32_T *ptr_enable);

    CLX_ERROR_NO_T(*setRxTermination)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_bmp,
     const HAL_PHY_ACC_TERM_MODE_T mode);

    CLX_ERROR_NO_T(*getRxTermination)
    (const UI32_T unit, const UI32_T port_id, HAL_PHY_ACC_TERM_MODE_T *ptr_mode);

    CLX_ERROR_NO_T(*setRxEqConfig)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_id,
     HAL_PHY_RX_EQPARAMS_T *ptr_rxeq_config);

    CLX_ERROR_NO_T(*getRxEqConfig)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_id,
     HAL_PHY_RX_EQPARAMS_T *ptr_rxeq_config);

    CLX_ERROR_NO_T(*updateRxEqConfig)
    (const UI32_T unit, const UI32_T port_id);

    CLX_ERROR_NO_T (*reloadFw)(const UI32_T unit, const UI32_T port_id);

    CLX_ERROR_NO_T(*readPhyReg)
    (const UI32_T unit, const UI32_T port_id, const UI32_T lane_id, UI32_T reg_addr);

    CLX_ERROR_NO_T(*writePhyReg)
    (const UI32_T unit,
     const UI32_T port_id,
     const UI32_T lane_id,
     UI32_T reg_addr,
     const UI32_T value);

    CLX_ERROR_NO_T(*getPhyAtestPmon)
    (const UI32_T unit, const UI32_T port_id, const UI32_T lane_id, const UI32_T test_mode);

    CLX_ERROR_NO_T(*getRxSnr)
    (const UI32_T unit, const UI32_T port_id, const UI32_T iir_alpha);

} HAL_PHY_DRIVER_T;

#if defined(CLX_EN_BIG_ENDIAN)
typedef union {
    UI32_T value;
    struct {
        UI32_T oui : 22;
        UI32_T model : 6;
        UI32_T revision : 4;
    } field;
} HAL_PHY_DEVICE_ID_T;
#else
typedef union {
    UI32_T value;
    struct {
        UI32_T revision : 4;
        UI32_T model : 6;
        UI32_T oui : 22;
    } field;
} HAL_PHY_DEVICE_ID_T;
#endif

typedef struct {
    C8_T *ptr_name;
    HAL_PHY_DRIVER_T *ptr_driver;
    HAL_PHY_DEVICE_ID_T device_id;
    UI32_T device_id_mask;
    UI32_T up_num;
} HAL_PHY_DEVICE_CB_T;

typedef enum {
    HAL_PHY_PHY_TYPE_INTERNAL = 0x0,
    HAL_PHY_PHY_TYPE_EXTERNAL,
    HAL_PHY_PHY_TYPE_LAST
} HAL_PHY_PHY_TYPE_T;

typedef struct {
    C8_T *device_name[HAL_PHY_PHY_TYPE_LAST];
    HAL_PHY_DRIVER_T *driver[HAL_PHY_PHY_TYPE_LAST];
    BOOL_T known_device[HAL_PHY_PHY_TYPE_LAST];
} HAL_PHY_DRIVER_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Init the PHY drive per unit
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_init(const UI32_T unit);

/**
 * @brief Deinit PHY driver per unit
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_deinit(const UI32_T unit);

/**
 * @brief Probe the port and init itself
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_probePort(const UI32_T unit, const UI32_T port_id);

/**
 * @brief Remove the port and deinit itself
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_removePort(const UI32_T unit, const UI32_T port_id);

/**
 * @brief Set admin state to enable or disable
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port_id        - Device port number
 * @param [in]     admin_state    - Port admin state
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAdminState(const UI32_T unit,
                      const UI32_T port_id,
                      const HAL_PHY_ADMIN_STATE_TYPE_T admin_state);

/**
 * @brief Get admin state
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     port_id            - Device port number
 * @param [out]    ptr_admin_state    - Port admin state
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAdminState(const UI32_T unit,
                      const UI32_T port_id,
                      HAL_PHY_ADMIN_STATE_TYPE_T *ptr_admin_state);

/**
 * @brief Get link state
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     port_id           - Device port number
 * @param [out]    ptr_link_state    - Port link state
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getLinkState(const UI32_T unit,
                     const UI32_T port_id,
                     HAL_PHY_LINK_STATE_TYPE_T *ptr_link_state);

/**
 * @brief Set speed
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     speed      - Port speed
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setSpeed(const UI32_T unit, const UI32_T port_id, const HAL_PHY_SPEED_TYPE_T speed);

/**
 * @brief Get speed
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port_id      - Device port number
 * @param [out]    ptr_speed    - Port speed
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getSpeed(const UI32_T unit, const UI32_T port_id, HAL_PHY_SPEED_TYPE_T *ptr_speed);

/**
 * @brief Set EEE(Energy-Efficient Ethernet) ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     eee        - EEE ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setEee(const UI32_T unit, const UI32_T port_id, const HAL_PHY_EEE_TYPE_T eee);

/**
 * @brief Get EEE(Energy-Efficient Ethernet) ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [out]    ptr_eee    - EEE ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getEee(const UI32_T unit, const UI32_T port_id, HAL_PHY_EEE_TYPE_T *ptr_eee);

/**
 * @brief Set EEE(Energy-Efficient Ethernet) mode as deep-sleep or fast-wakeup
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     eee_mode    - EEE mode
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setEeeMode(const UI32_T unit, const UI32_T port_id, const HAL_PHY_EEE_MODE_TYPE_T eee_mode);

/**
 * @brief Get EEE(Energy-Efficient Ethernet) mode
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port_id         - Device port number
 * @param [out]    ptr_eee_mode    - EEE mode
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getEeeMode(const UI32_T unit, const UI32_T port_id, HAL_PHY_EEE_MODE_TYPE_T *ptr_eee_mode);

/**
 * @brief Set FEC(Forward Error Correction) ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     fec        - FEC ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setFec(const UI32_T unit, const UI32_T port_id, const HAL_PHY_FEC_TYPE_T fec);

/**
 * @brief Get FEC(Forward Error Correction) ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [out]    ptr_fec    - FEC ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getFec(const UI32_T unit, const UI32_T port_id, HAL_PHY_FEC_TYPE_T *ptr_fec);

/**
 * @brief Set local loopback ability to enable or disable it
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     intf_location    - Where the loopback interface locates
 * @param [in]     loopback         - Loopback ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setLoopback(const UI32_T unit,
                    const UI32_T port_id,
                    const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                    const HAL_PHY_LOOPBACK_TYPE_T loopback);

/**
 * @brief Get local loopback ability
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     intf_location    - Where the loopback interface locates
 * @param [out]    ptr_loopback     - Loopback ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getLoopback(const UI32_T unit,
                    const UI32_T port_id,
                    const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                    HAL_PHY_LOOPBACK_TYPE_T *ptr_loopback);

/**
 * @brief Set the type of PMA interface
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     intf_location    - Where the interface locates
 * @param [in]     pma_intf         - Type of PMA interface
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setPmaIntf(const UI32_T unit,
                   const UI32_T port_id,
                   const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                   const HAL_PHY_PMA_INTF_TYPE_T pma_intf);

/**
 * @brief Get the type of PMA interface
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     intf_location    - Where the interface locates
 * @param [out]    ptr_pma_intf     - Type of PMA interface
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getPmaIntf(const UI32_T unit,
                   const UI32_T port_id,
                   const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                   HAL_PHY_PMA_INTF_TYPE_T *ptr_pma_intf);

/**
 * @brief Set the type of PMD interface
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     pmd_intf    - Type of PMD interface
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setPmdIntf(const UI32_T unit, const UI32_T port_id, const HAL_PHY_PMD_INTF_TYPE_T pmd_intf);

/**
 * @brief Get the type of PMD interface
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port_id         - Device port number
 * @param [out]    ptr_pmd_intf    - Type of PMD interface
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getPmdIntf(const UI32_T unit, const UI32_T port_id, HAL_PHY_PMD_INTF_TYPE_T *ptr_pmd_intf);

/**
 * @brief Set AN(Auto-Negotiation) ability to enable or disable
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     anlt       - ANLT/LT/DISABLE
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAnLt(const UI32_T unit, const UI32_T port_id, const HAL_PHY_ANLT_TYPE_T anlt);

/**
 * @brief Get AN(Auto-Negotiation) ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [out]    ptr_anlt   - ANLT/LT/DISABLE
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAnLt(const UI32_T unit, const UI32_T port_id, HAL_PHY_ANLT_TYPE_T *ptr_anlt);

/**
 * @brief Set Re-AN(Auto-Negotiation) ability to restart or disable
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     an_re_an    - Re-AN ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAnReAn(const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_RE_AN_TYPE_T an_re_an);

/**
 * @brief Get Re-AN(Auto-Negotiation) ability
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port_id         - Device port number
 * @param [out]    ptr_an_re_an    - Re-AN ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAnReAn(const UI32_T unit, const UI32_T port_id, HAL_PHY_AN_RE_AN_TYPE_T *ptr_an_re_an);

/**
 * @brief Set AN speed ability
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     an_speed    - AN speed ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAnSpeed(const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_SPEED_TYPE_T an_speed);

/**
 * @brief Get AN speed ability
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port_id         - Device port number
 * @param [in]     an_target       - The target of AN ability such as local or remote peer
 * @param [out]    ptr_an_speed    - AN speed ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAnSpeed(const UI32_T unit,
                   const UI32_T port_id,
                   const HAL_PHY_AN_TARGET_TYPE_T an_target,
                   HAL_PHY_AN_SPEED_TYPE_T *ptr_an_speed);

/**
 * @brief Set AN EEE ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     an_eee     - AN EEE ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAnEee(const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_EEE_TYPE_T an_eee);

/**
 * @brief Get AN EEE ability
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port_id       - Device port number
 * @param [in]     an_target     - The target of AN ability such as local or remote peer
 * @param [out]    ptr_an_eee    - AN EEE ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAnEee(const UI32_T unit,
                 const UI32_T port_id,
                 const HAL_PHY_AN_TARGET_TYPE_T an_target,
                 HAL_PHY_AN_EEE_TYPE_T *ptr_an_eee);

/**
 * @brief Set AN FEC ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     an_fec     - AN FEC ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAnFec(const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_FEC_TYPE_T an_fec);

/**
 * @brief Get AN FEC ability
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port_id       - Device port number
 * @param [in]     an_target     - The target of AN ability such as local or remote peer
 * @param [out]    ptr_an_fec    - AN FEC ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAnFec(const UI32_T unit,
                 const UI32_T port_id,
                 const HAL_PHY_AN_TARGET_TYPE_T an_target,
                 HAL_PHY_AN_FEC_TYPE_T *ptr_an_fec);

/**
 * @brief Set AN flow control ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     an_fc      - AN flow control ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAnFc(const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_FC_TYPE_T an_fc);

/**
 * @brief Get AN flow control ability
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port_id      - Device port number
 * @param [in]     an_target    - The target of AN ability such as local or remote peer
 * @param [out]    ptr_an_fc    - AN flow control ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAnFc(const UI32_T unit,
                const UI32_T port_id,
                const HAL_PHY_AN_TARGET_TYPE_T an_target,
                HAL_PHY_AN_FC_TYPE_T *ptr_an_fc);

/**
 * @brief Set AN Duplex ability
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port_id      - Device port number
 * @param [in]     an_duplex    - AN duplex ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAnDuplex(const UI32_T unit,
                    const UI32_T port_id,
                    const HAL_PHY_AN_DUPLEX_TYPE_T an_duplex);

/**
 * @brief Get AN duplex ability
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     an_target        - The target of AN ability such as local or remote peer
 * @param [out]    ptr_an_duplex    - AN duplex ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAnDuplex(const UI32_T unit,
                    const UI32_T port_id,
                    const HAL_PHY_AN_TARGET_TYPE_T an_target,
                    HAL_PHY_AN_DUPLEX_TYPE_T *ptr_an_duplex);

/**
 * @brief Set AN remote-fault ability
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     an_rf      - AN remote fault ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setAnRf(const UI32_T unit, const UI32_T port_id, const HAL_PHY_AN_RF_TYPE_T an_rf);

/**
 * @brief Get AN remote-fault ability
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port_id      - Device port number
 * @param [in]     an_target    - The target of AN ability such as local or remote peer
 * @param [out]    ptr_an_rf    - AN remote-fault ability
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getAnRf(const UI32_T unit,
                const UI32_T port_id,
                const HAL_PHY_AN_TARGET_TYPE_T an_target,
                HAL_PHY_AN_RF_TYPE_T *ptr_an_rf);

/**
 * @brief Set phy config such as lane-swap, polarity-reversion and tx-coefficient
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     lane_cnt         - Count of lanes inside the port
 * @param [in]     intf_location    - Where the interface locates
 * @param [in]     property_type    - Type of config
 * @param [in]     ptr_property     - The config array with lane_cnt elements
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setPhyCfg(const UI32_T unit,
                  const UI32_T port_id,
                  const UI32_T lane_cnt,
                  const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                  const HAL_PHY_PROPERTY_TYPE_T property_type,
                  const UI32_T *ptr_property);

/**
 * @brief Get phy config such as lane-swap, polarity-reversion and tx-coefficient
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     lane_cnt         - Count of lanes inside the port
 * @param [in]     intf_location    - Where the interface locates
 * @param [in]     property_type    - Type of config
 * @param [out]    ptr_property     - The config array with lane_cnt elements
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getPhyCfg(const UI32_T unit,
                  const UI32_T port_id,
                  const UI32_T lane_cnt,
                  const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                  const HAL_PHY_PROPERTY_TYPE_T property_type,
                  UI32_T *ptr_property);

/**
 * @brief Set all tx coefficients (CN2, CN1, C0, C1, C2) for a specific lane
 *        Note 1: different switch family supports different coefficient number
 *        Note 2: when summation of coefficient is overflow, C0 got reduction
 *        Note 3: partial coefficients configuration is allowed (flags within struct config is
 * necessary)
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     lane_id          - Lane offset inside the port
 * @param [in]     intf_location    - Where the interface locates
 * @param [in]     ptr_tx_coef      - The tx coefficients applied to the specific lane
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setTxCoef(const UI32_T unit,
                  const UI32_T port_id,
                  const UI32_T lane_id,
                  const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                  HAL_PHY_TX_COEF_T *ptr_tx_coef);

/**
 * @brief Get all tx coefficients (CN2, CN1, C0, C1, C2) for a spceific lane
 *        Note 1: different switch family supports different coefficient number
 *        Note 2: flags within the struct indicates the coefficients supported in this switch family
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     lane_id          - Lane offset inside the port
 * @param [in]     intf_location    - Where the interface locates
 * @param [out]    ptr_tx_coef      - The tx coefficients applied to the specific lane
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getTxCoef(const UI32_T unit,
                  const UI32_T port_id,
                  const UI32_T lane_id,
                  const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                  HAL_PHY_TX_COEF_T *ptr_tx_coef);

/**
 * @brief Allow users to set C45 config with only eth-macro/lane information.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     eth_macro   - Eth macro id
 * @param [in]     lane        - lane of the eth-macro
 * @param [in]     dev_type    - Type of PHY device
 * @param [in]     reg_addr    - Register address
 * @param [in]     reg         - The data for set into the register specified
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setC45Cfg(const UI32_T unit,
                  const UI32_T eth_macro,
                  const UI32_T lane,
                  const UI32_T dev_type,
                  const UI32_T reg_addr,
                  const UI32_T reg);

/**
 * @brief Allow users to set C45 config with only eth-macro/lane information.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     eth_macro   - Eth macro id
 * @param [in]     lane        - lane of the eth-macro.
 * @param [in]     dev_type    - Type of PHY device
 * @param [in]     reg_addr    - Register address
 * @param [out]    ptr_reg     - Pointer to buffer the data read from register specified
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getC45Cfg(const UI32_T unit,
                  const UI32_T eth_macro,
                  const UI32_T lane,
                  const UI32_T dev_type,
                  const UI32_T reg_addr,
                  UI32_T *ptr_reg);

/**
 * @brief Get temperature of external PHY
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [out]    ptr_temp    - Temperature of enternal PHY
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getTemperature(const UI32_T unit, const UI32_T port_id, I32_T *ptr_temp);

/**
 * @brief Dump eye scan result
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     lane_id     - Lane id in the port
 * @param [in]     property    - Optional perperty setting
 * @param [in]     sample_deep - Sample deep
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_dumpEyeScan(const UI32_T unit,
                    const UI32_T port_id,
                    const UI32_T lane_id,
                    const HAL_PHY_EYE_SCAN_TYPE_T property,
                    const UI32_T sample_deep);

/**
 * @brief Set the PRBS test pattern
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port_id         - Device port number
 * @param [in]     prbs_pattern    - Test pattern on PRBS
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setPrbsPattern(const UI32_T unit,
                       const UI32_T port_id,
                       const HAL_PHY_PRBS_PATTERN_TYPE_T prbs_pattern);

/**
 * @brief Get the PRBS test pattern
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     port_id             - Device port number
 * @param [out]    ptr_prbs_pattern    - Test pattern on PRBS
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getPrbsPattern(const UI32_T unit,
                       const UI32_T port_id,
                       HAL_PHY_PRBS_PATTERN_TYPE_T *ptr_prbs_pattern);

/**
 * @brief Enable/disable the PRBS test checker
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port_id         - Device port number
 * @param [in]     prbs_checker    - Enable/Disable checke
 * @param [in]     ber_mode        - Enable/Disable ber mode
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setPrbsChecker(const UI32_T unit,
                       const UI32_T port_id,
                       const HAL_PHY_PRBS_CHECKER_TYPE_T prbs_checker,
                       const UI32_T ber_mode);

/**
 * @brief Get the PRBS test checker status (enable/disable)
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     port_id             - Device port number
 * @param [out]    ptr_prbs_checker    - Test checker status (enable/disable)
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getPrbsChecker(const UI32_T unit,
                       const UI32_T port_id,
                       HAL_PHY_PRBS_CHECKER_TYPE_T *ptr_prbs_checker);

/**
 * @brief Get the PRBS checker error count
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port_id          - Device port number
 * @param [in]     lane_bmp         - specify the lanes to report prbs error cnt
 * @param [out]    ptr_ber_mode     - for PAM4/NRZ PRBS, ber_mode is enable/disable
 * @param [out]    ptr_error_cnt    - Error bit counter (including lock sts + error counter)
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getPrbsErrorCnt(const UI32_T unit,
                        const UI32_T port_id,
                        const UI32_T lane_bmp,
                        HAL_PHY_PRBS_BER_TYPE_T *ptr_ber_mode,
                        HAL_PHY_PRBS_ERRCNT_T *ptr_error_cnt);

/**
 * @brief Dump serdes internal information
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port_id      - Device port number
 * @param [in]     lane_bmp     - Focus the lane list within the port (started from 0)
 * @param [in]     dump_type    - HAL_PHY_SERDES_DUMP_TYPE_MEM/
 *                                  HAL_PHY_SERDES_DUMP_TYPE_REG/
 *                                  HAL_PHY_SERDES_DUMP_TYPE_COEF
 * @param [in]     more         - more flag to dump more detail
 *                                serdes sdk module osal_printf directly.
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_dumpSerDesInfo(const UI32_T unit,
                       const UI32_T port_id,
                       const UI32_T lane_bmp,
                       const HAL_PHY_SERDES_DUMP_TYPE_T dump_type,
                       const UI32_T more);

/**
 * @brief Set the bit within the shift register for LED
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     led_id       - LED module ID
 * @param [in]     ptr_led_mode - LED mode to set
 * @param [in]     bit_id       - The bit to set
 * @return         CLX_E_OK     - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setLedBit(const UI32_T unit,
                  const UI32_T led_id,
                  const UI32_T bit_id,
                  const UI32_T *ptr_led_mode);

/**
 * @brief get the bit within the shift register for LED
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     led_id       - LED module ID
 * @param [in]     bit_id       - The bit to set
 * @param [out]    ptr_led_mode - LED status [on/off (normal/force)]
 * @return         CLX_E_OK     - Operate success
 */
CLX_ERROR_NO_T
hal_phy_getLedBit(const UI32_T unit, const UI32_T led_id, const UI32_T bit_id, UI32_T *ptr_led_mode);

/**
 * @brief Set MDIO(Management Data Input/Output) register of PHY
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     phy_type    - Type of PHY such as internal or external
 * @param [in]     dev_type    - Type of PHY device
 * @param [in]     reg_addr    - Register address
 * @param [in]     reg         - Register data
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_phy_setMdioReg(const UI32_T unit,
                   const UI32_T port_id,
                   const HAL_PHY_PHY_TYPE_T phy_type,
                   const HAL_PHY_MDIO_DEVICE_TYPE_T dev_type,
                   const UI32_T reg_addr,
                   const UI32_T reg);

/**
 * @brief Get MDIO(Management Data Input/Output) register of PHY
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     phy_type    - Type of PHY such as internal or external
 * @param [in]     dev_type    - Type of PHY device
 * @param [in]     reg_addr    - Register address
 * @param [out]    ptr_reg     - Register data
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_phy_getMdioReg(const UI32_T unit,
                   const UI32_T port_id,
                   const HAL_PHY_PHY_TYPE_T phy_type,
                   const HAL_PHY_MDIO_DEVICE_TYPE_T dev_type,
                   const UI32_T reg_addr,
                   UI32_T *ptr_reg);

/**
 * @brief Set MDIO(Management Data Input/Output) clock rate in KHZ on specified channel
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     chn_id      - MDIO channel ID
 * @param [in]     rate_khz    - MDIO clock rate
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_phy_setMdioRate(const UI32_T unit, const UI32_T chn_id, const UI32_T rate_khz);

/**
 * @brief set port to support MxLink feature
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     enable     - 1: enable mxlink 0: disable mxlink
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 * @return         CLX_E_NOT_SUPPORT      - Hardware does not support.
 */
CLX_ERROR_NO_T
hal_phy_setMxLink(const UI32_T unit, const UI32_T port_id, const UI32_T enable);

/**
 * @brief get MxLink enable/disable
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port_id       - Device port number
 * @param [out]    ptr_enable    - show mxlink enable/disable
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 * @return         CLX_E_NOT_SUPPORT      - Hardware does not support.
 */
CLX_ERROR_NO_T
hal_phy_getMxLink(const UI32_T unit, const UI32_T port_id, UI32_T *ptr_enable);

/**
 * @brief get fec counter value based on counter type
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     lane_id     - Device lane number
 * @param [in]     cnt_type    - CERR/UCERR/lane SERR
 * @param [out]    ptr_cnt     - fec counter value
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 * @return         CLX_E_NOT_SUPPORT      - Hardware does not support.
 */
CLX_ERROR_NO_T
hal_phy_getFecCnt(const UI32_T unit,
                  const UI32_T port_id,
                  const UI32_T lane_id,
                  const HAL_PHY_FEC_CNT_TYPE_T cnt_type,
                  HAL_PHY_FEC_CNT_T *ptr_cnt);

CLX_ERROR_NO_T
hal_phy_setPrbsGenerator(const UI32_T unit, const UI32_T port_id, HAL_PHY_PRBS_CONFIG_T prbs_gen);

CLX_ERROR_NO_T
hal_phy_getPrbsGenerator(const UI32_T unit, const UI32_T port_id, HAL_PHY_PRBS_CONFIG_T *prbs_gen);

/**
 * @brief set phy prbs error inject.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @param [in]     num_err    - Inject error numbers
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_setPrbsErrInject(const UI32_T unit, const UI32_T port_id, const UI32_T num_err);

/**
 * @brief set phy prbs error inject.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     lane_bmp    - Lane bitmamp
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_setPrbsErrCntClear(const UI32_T unit, const UI32_T port_id, const UI32_T lane_bmp);

/**
 * @brief get phy firmware version
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     port_id            - Device port number
 * @param [out]    ptr_version_eth    - Eth phy firmware version
 * @param [out]    ptr_version_cpi    - Cpi phy firmware version
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_getFwVersion(const UI32_T unit,
                     const UI32_T port_id,
                     UI32_T *ptr_version_eth,
                     UI32_T *ptr_version_cpi);

/**
 * @brief set phy rx equalize tuning once.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     lane_bmp    - lane bitmap
 * @param [in]     phase       - tuning phase
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_setRxEqTunning(const UI32_T unit,
                       const UI32_T port_id,
                       const UI32_T lane_bmp,
                       const UI32_T phase);

/**
 * @brief set phy rx equalize tunning once.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [out]    pma_rate    - Phy rate code:
 *                               0: 10P3125
 *                               1: 25P78125
 *                               2: 26P5625
 *                               3: 53P125_NRZ
 *                               4: 53P125_PAM4
 *                               5: 56P25_PAM4
 *                               6: 106P25
 *                               7: 112P5
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_getPhyRate(const UI32_T unit, const UI32_T port_id, UI32_T *pma_rate);

/**
 * @brief set phy isolation mode enable/disable.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     lane_bmp    - lane bitmap
 * @param [in]     enable      - enable/disable isolation mode
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_setIsolaMode(const UI32_T unit,
                     const UI32_T port_id,
                     const UI32_T lane_bmp,
                     const UI32_T enable);

/**
 * @brief set phy tx or rx powerup.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port_id       - Device port number
 * @param [in]     lane_bmp      - lane bitmap
 * @param [in]     module        - tx or rx
 * @param [in]     lane_speed    - serdes lane speed
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_setTxRxPowerup(const UI32_T unit,
                       const UI32_T port_id,
                       const UI32_T lane_bmp,
                       const HAL_PHY_POWERUP_MODULE_TYPE_T module,
                       const HAL_PHY_LANE_SPEED_TYPE_T lane_speed);

/**
 * @brief set phy tx elecidle.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     enable      - enable or disable
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_setTxElecidle(const UI32_T unit, const UI32_T port_id, const UI32_T enable);

/**
 * @brief get phy tx elecidle.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port_id       - Device port number
 * @param [out]    ptr_enable    - phy tx elecidle
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_getTxElecidle(const UI32_T unit, const UI32_T port_id, UI32_T *ptr_enable);

/**
 * @brief set phy rx termination mode.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     lane_bmp    - lane bitmap
 * @param [in]     mode        - termination mode
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_setRxTermination(const UI32_T unit,
                         const UI32_T port_id,
                         const UI32_T lane_bmp,
                         const HAL_PHY_ACC_TERM_MODE_T mode);

/**
 * @brief get phy rx termination mode.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [out]    ptr_mode    - phy rx termination mode
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_getRxTermination(const UI32_T unit, const UI32_T port_id, UI32_T *ptr_mode);

/**
 * @brief get phy Atest or Pmon data.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Physical port ID
 * @param [in]     lane_bmp    - lane bitmap
 * @param [in]     mode        - atest mode
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_phy_getPhyAtestPmon(const UI32_T unit,
                        const UI32_T port_id,
                        const UI32_T lane_bmp,
                        const UI32_T mode);
/**
 * @brief set phy rx eq config.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     port_id            - Device port number
 * @param [in]     lane_id            - Device lane number
 * @param [in]     ptr_rxeq_config    - rx eq config
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_setRxEqConfig(const UI32_T unit,
                      const UI32_T port_id,
                      const UI32_T lane_id,
                      HAL_PHY_RX_EQPARAMS_T *ptr_rxeq_config);

/**
 * @brief get phy rx eq config.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     port_id            - Device port number
 * @param [in]     lane_id            - Device lane number
 * @param [out]    ptr_rxeq_config    - phy rx eq config
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_getRxEqConfig(const UI32_T unit,
                      const UI32_T port_id,
                      const UI32_T lane_id,
                      HAL_PHY_RX_EQPARAMS_T *ptr_rxeq_config);

/**
 * @brief update phy rx eq config.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     port_id            - Device port number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_updateRxEqConfig(const UI32_T unit, const UI32_T port_id);

/**
 * @brief reload phy macro firmware.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port_id    - Device port number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_reloadFw(const UI32_T unit, const UI32_T port_id);

/**
 * @brief read phy reg.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     lane_id     - Lane_id within the port
 * @param [in]     reg_addr    - lane0 reg addr
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_readPhyReg(const UI32_T unit, const UI32_T port_id, const UI32_T lane_id, UI32_T reg_addr);

/**
 * @brief write phy reg.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Device port number
 * @param [in]     lane_id     - Lane_id within the port
 * @param [in]     reg_addr    - lane0 reg addr
 * @param [in]     value       - The value to be set in the reg
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
CLX_ERROR_NO_T
hal_phy_writePhyReg(const UI32_T unit,
                    const UI32_T port_id,
                    const UI32_T lane_id,
                    UI32_T reg_addr,
                    const UI32_T value);

/**
 * @brief get phy rx snr.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port_id     - Physical port ID
 * @param [in]     iir_alpha   - IIR fiter alpha value - 0p10 format
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_phy_getRxSnr(const UI32_T unit, const UI32_T port_id, const UI32_T iir_alpha);
#endif /* End of HAL_PHY_H */
