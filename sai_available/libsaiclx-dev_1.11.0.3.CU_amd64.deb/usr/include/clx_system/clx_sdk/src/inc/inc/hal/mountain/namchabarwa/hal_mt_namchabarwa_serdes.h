/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_serdes.h
 * PURPOSE:
 *      It provide HAL_MT_NAMCHABARWA_SERDES module API.
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_SERDES_H
#define HAL_MT_NAMCHABARWA_SERDES_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_cfg.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_pma.h>
#include <hal/hal_phy.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define ANGROUP_MAXSIZE (4)

#define HAL_MT_NAMCHABARWA_SERDES_MAX_MACRO           (33)
#define HAL_MT_NAMCHABARWA_SERDES_MAX_LANES_PER_MACRO (8)

#define HAL_MT_NAMCHABARWA_SERDES_MACRO_0_BASE_ADDR   (0x2ED4400)
#define HAL_MT_NAMCHABARWA_SERDES_MACRO_OFFSET        (0x114400)
#define HAL_MT_NAMCHABARWA_SERDES_SLICE_ODD_ENEN_GAP  (0x1180000)
#define HAL_MT_NAMCHABARWA_SERDES_SLICE_GAP           (0x451000)
#define HAL_MT_NAMCHABARWA_MACRO_MAX_NUM_PER_SLICE    (4)
#define HAL_MT_NAMCHABARWA_SERDES_CPI_MACRO_BASE_ADDR (0x5E8F800)

#define HAL_MT_NAMCHABARWA_GET_SLICE_SERDES_ADDR(slice)           \
    (HAL_MT_NAMCHABARWA_SERDES_MACRO_0_BASE_ADDR +                \
     (slice % 2) * HAL_MT_NAMCHABARWA_SERDES_SLICE_ODD_ENEN_GAP + \
     (slice / 2) * HAL_MT_NAMCHABARWA_SERDES_SLICE_GAP)
#define HAL_MT_NAMCHABARWA_GET_MACRO_SERDES_ADDR(macro_id)      \
    (((macro_id % HAL_MT_NAMCHABARWA_MACRO_MAX_NUM_PER_SLICE) * \
      HAL_MT_NAMCHABARWA_SERDES_MACRO_OFFSET) +                 \
     HAL_MT_NAMCHABARWA_GET_SLICE_SERDES_ADDR(macro_id /        \
                                              HAL_MT_NAMCHABARWA_MACRO_MAX_NUM_PER_SLICE))
#define HAL_MT_NAMCHABARWA_GET_SLICE_MACRO_SERDES_ADDR(slc, slc_macro) \
    ((slc_macro * HAL_MT_NAMCHABARWA_SERDES_MACRO_OFFSET) +            \
     HAL_MT_NAMCHABARWA_GET_SLICE_SERDES_ADDR(slc))

#define HAL_MT_NAMCHABARWA_SERDES_LANE_OFFSET(__lane__) ((__lane__) * ETH_LANE_OFFSET)

#define HAL_CHECK_SERDES_ERROR(__pass__)                                        \
    do {                                                                        \
        CLX_ERROR_NO_T __rc = CLX_E_OTHERS;                                     \
        if (__pass__ != HAL_MT_NAMCHABARWA_PMA_ERR_CODE_NONE) {                 \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, #__pass__ "=%d\n", __pass__); \
            return __rc;                                                        \
        }                                                                       \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
extern mss_access_t _hal_mt_phy_mss[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][CLX_PORT_NUM]; /*serdes access
                                                                                        struct*/

extern UI32_T _hal_mt_phy_tx_lane_swap[HAL_MT_NAMCHABARWA_SERDES_MAX_MACRO]
                                      [HAL_MT_NAMCHABARWA_SERDES_MAX_LANES_PER_MACRO];

extern UI32_T _hal_mt_phy_rx_lane_swap[HAL_MT_NAMCHABARWA_SERDES_MAX_MACRO]
                                      [HAL_MT_NAMCHABARWA_SERDES_MAX_LANES_PER_MACRO];

typedef struct {
    UI32_T flags;
    UI32_T group[ANGROUP_MAXSIZE];
} HAL_MT_NAMCHABARWA_AN_GROUP;

typedef enum { INIT_QUEUE, EN_QUEUE, DE_QUEUE, OP_QUEUE_LAST } OP_QUEUE_T;

/*serdes speed*/
typedef enum {
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_56P25_PAM4 = 0x0,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_10P3125,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_25P78125,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_26P5625,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_53P125_NRZ,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_53P125_PAM4,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_106P25,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_112P5,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_LAST
} HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_T;

/*serdes tx block width*/
typedef enum {
    HAL_MT_NAMCHABARWA_PMA_PHY_WIDTH_TYPE_16 = 0x2,
    HAL_MT_NAMCHABARWA_PMA_PHY_WIDTH_TYPE_20,
    HAL_MT_NAMCHABARWA_PMA_PHY_WIDTH_TYPE_32,
    HAL_MT_NAMCHABARWA_PMA_PHY_WIDTH_TYPE_40,
    HAL_MT_NAMCHABARWA_PMA_PHY_WIDTH_TYPE_64,
    HAL_MT_NAMCHABARWA_PMA_PHY_WIDTH_TYPE_128,
    HAL_MT_NAMCHABARWA_PMA_PHY_WIDTH_TYPE_LAST
} HAL_MT_NAMCHABARWA_PMA_PHY_WIDTH_TYPE_T;

typedef struct {
    /**
     * Lane number, set lane number between 0 and 3
     **/
    UI8_T lane_num;

    /**
     * Set to 1 to enable rxeq_prbs mode. Set to 0 to use LT mode
     **/
    UI32_T prbs_en;

    /**
     * Set to 1 to enable anlt. Set to 0 to disable anlt
     **/
    UI32_T anlt_en;

    /**
     * Set to 1 for testing between lanes on the same PHY
     **/
    UI32_T an_no_nonce_check;

    /**
     * Set this to 1 for x1 configuration
     * Set this to 0 for running in multi-lane configurations
     **/
    UI32_T an_no_attached;

    /**
     * Disables link training status check
     * In silicon set this to 0
     **/
    UI32_T status_check_disable;

    /**
     * Enables next page support for consortium technologies
     * Not supported in this example sequence
     **/
    UI32_T next_page_en;

    /**
     * Width corresponding to line rate
     **/
    UI32_T ltcs_width;

    /**
     * ANLT clause as per IEEE-802 specification
     * ANLT cluase mapping is as follows
     * 106G  - 4
     * 53PAM - 3
     * 53NRZ - 2
     * 10G   - 1
     **/
    UI32_T ltcs_clause;

    /**
     * Preset check enable
     * Set to 0 in sim
     * To be set by FW in silicon
     **/
    UI32_T ltcs_preset_check;

    /**
     * Set to 1 if enabling precoding, applicable only for PAM
     * Set to 0 for this example
     **/
    UI32_T ltcs_mod;

    /**
     * Mode EQ run in
     * HAL_MT_NAMCHABARWA_PMA_ANLT_MODE, HAL_MT_NAMCHABARWA_PMA_LT_MODE,
     *HAL_MT_NAMCHABARWA_PMA_MANUAL mode
     **/
    UI32_T eq_select;

    /**
     * Set to either HAL_MT_NAMCHABARWA_PMA_ANLT_MODE, HAL_MT_NAMCHABARWA_PMA_LT_MODE,
     *HAL_MT_NAMCHABARWA_PMA_MANUAL_EQ HAL_MT_NAMCHABARWA_PMA_ANLT_MODE - brings up lane in ANLT
     *configuration HAL_MT_NAMCHABARWA_PMA_LT_MODE - brings up lane with link training, no AN
     * HAL_MT_NAMCHABARWA_PMA_MANUAL_EQ - brings up lane with manual EQ
     **/
    hal_mt_namchabarwa_pma_eq_type_t s_eq_type;
} HAL_MT_NAMCHABARWA_PMA_ANLT_CONFIG_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEthxMem(const UI32_T unit,
                                      const UI32_T port_id,
                                      const UI32_T lane_bmp,
                                      const UI32_T more);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEthlMem(const UI32_T unit,
                                      const UI32_T port_id,
                                      const UI32_T lane_bmp,
                                      const UI32_T more);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEthxReg(const UI32_T unit,
                                      const UI32_T port_id,
                                      const UI32_T lane_bmp,
                                      const UI32_T more);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEthlReg(const UI32_T unit,
                                      const UI32_T port_id,
                                      const UI32_T lane_bmp,
                                      const UI32_T more);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEthxCoef(const UI32_T unit,
                                       const UI32_T port_id,
                                       const UI32_T lane_bmp,
                                       const UI32_T more);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEthlCoef(const UI32_T unit,
                                       const UI32_T port_id,
                                       const UI32_T lane_bmp,
                                       const UI32_T more);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEthxMsgq(const UI32_T unit,
                                       const UI32_T port_id,
                                       const UI32_T lane_bmp,
                                       const UI32_T more);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEthlMsgq(const UI32_T unit,
                                       const UI32_T port_id,
                                       const UI32_T lane_bmp,
                                       const UI32_T more);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_dumpEyeBER(const UI32_T unit,
                                     const UI32_T port_id,
                                     const UI32_T lane_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_drawEyeScan(const UI32_T unit,
                                      const UI32_T port_id,
                                      const UI32_T lane_id,
                                      const UI32_T sample_deep);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getEyeScanRowdata(const UI32_T unit,
                                            const UI32_T port_id,
                                            const UI32_T lane_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_downloadFw(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_reloadFw(const UI32_T unit, const UI32_T port_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_refclock_check(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_refclock_route(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_setLcpllLockRange(const UI32_T unit,
                                            const UI32_T port_id,
                                            const UI32_T max_val,
                                            const UI32_T min_val,
                                            const UI32_T lock_cycle);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getLcpllLock(const UI32_T unit,
                                       const UI32_T port_id,
                                       const UI32_T check_en,
                                       const UI32_T expected_val,
                                       UI32_T *pll_lock);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_setTxPowerState(const UI32_T unit,
                                          const UI32_T port_id,
                                          const UI32_T tx_pstate);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getTxPowerState(const UI32_T unit,
                                          const UI32_T port_id,
                                          UI32_T *tx_pstate);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_setRxPowerState(const UI32_T unit,
                                          const UI32_T port_id,
                                          const UI32_T rx_pstate);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getRxPowerState(const UI32_T unit,
                                          const UI32_T port_id,
                                          UI32_T *rx_pstate);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getRxCDRLock(const UI32_T unit,
                                       const UI32_T port_id,
                                       const UI32_T timeout_us);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getLaneSpeed(
    const UI32_T unit,
    const UI32_T port_id,
    HAL_MT_NAMCHABARWA_PMA_PHY_SPEED_TYPE_T *hal_mt_namchabarwa_pma_speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_opAnLtGroup(const UI32_T unit,
                                      const UI32_T port_id,
                                      const OP_QUEUE_T operation,
                                      UI32_T *anlt_group);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_anltEnableIntr(UI32_T unit, UI32_T port, UI32_T enable);
CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getAnIntrSta(UI32_T unit, UI32_T port, UI32_T *status);
CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getAnltStatusComplete(const UI32_T unit,
                                                const UI32_T port_id,
                                                UI32_T *an_status);

CLX_ERROR_NO_T
hal_mt_namchabarwa_serdes_getLtstate(const UI32_T unit, const UI32_T port_id, UI32_T *lt_done);

CLX_ERROR_NO_T
hal_mt_namchabarwa_phy_setAnSpeedConsortium(const UI32_T unit, const UI32_T port_id);
CLX_ERROR_NO_T
hal_mt_namchabarwa_phy_getPortAnltResult(const UI32_T unit,
                                         const UI32_T port,
                                         HAL_PHY_AN_SPEED_TYPE_T *ptr_result,
                                         UI32_T *ptr_fec);
CLX_ERROR_NO_T
hal_mt_namchabarwa_phy_enableEqbkHoldReq(const UI32_T unit, const UI32_T port, UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_phy_configAnLinkStat(const UI32_T unit, const UI32_T port, UI32_T stat);
#endif /* End of HAL_MT_NAMCHABARWA_SERDES_H */
