/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_efuse.h
 * PURPOSE:
 *  Provide HAL efuse APIs for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_EFUSE_H
#define HAL_EFUSE_H

/* INCLUDE FILE DECLARATIONS
 */

#include <hal/hal_const_cmn.h>
#include <clx_error.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_EFUSE_MACRO_WORDS        (128)
#define HAL_EFUSE_TDIE_GROUP_1_WORDS (HAL_EFUSE_MACRO_WORDS * 1)
#define HAL_EFUSE_TDIE_GROUP_2_WORDS (HAL_EFUSE_MACRO_WORDS * 3)
#define HAL_EFUSE_PDIE_GROUP_1_WORDS (HAL_EFUSE_MACRO_WORDS * 1)
#define HAL_EFUSE_PDIE_GROUP_2_WORDS (HAL_EFUSE_MACRO_WORDS * 2)

#define HAL_EFUSE_GET_MACRO(__addr__)          ((__addr__) / HAL_EFUSE_MACRO_WORDS)
#define HAL_EFUSE_GET_PER_MACRO_ADDR(__addr__) ((__addr__) % HAL_EFUSE_MACRO_WORDS)

CLX_ERROR_NO_T
hal_efuse_read(const UI32_T unit,
               const HAL_CHIP_DIE_T die,
               const HAL_EFUSE_GROUP_T group,
               const UI32_T addr,
               UI32_T *ptr_val);

CLX_ERROR_NO_T
hal_efuse_dmaRead(const UI32_T unit,
                  const HAL_CHIP_DIE_T die,
                  const HAL_EFUSE_GROUP_T group,
                  const UI32_T addr,
                  const UI32_T words,
                  UI32_T *ptr_buf); /* if ptr_buf is NULL, put data to EFS_MIR only */

CLX_ERROR_NO_T
hal_efuse_readMir(const UI32_T unit,
                  const HAL_CHIP_DIE_T die,
                  const HAL_EFUSE_GROUP_T group,
                  const UI32_T mir_idx,
                  UI32_T *ptr_val);

CLX_ERROR_NO_T
hal_efuse_write(const UI32_T unit,
                const HAL_CHIP_DIE_T die,
                const HAL_EFUSE_GROUP_T group,
                const UI32_T addr,
                const UI32_T bit_offset,
                const UI32_T bit_len,
                const UI32_T value);

#endif /* End of HAL_EFUSE_H */