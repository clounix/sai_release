/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_cmn_drv.h
 * PURPOSE:
 *  Provide HAL common driver structure and API for HAL exported API.
 *
 * NOTES:
 */

#ifndef HAL_CMN_DRV_H
#define HAL_CMN_DRV_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_stat.h>
#include <clx_dtel.h>
#include <clx_telm.h>
#include <hal/hal_acl.h>
#include <hal/hal_ifmon.h>
#include <hal/hal_tm.h>
#include <hal/hal_tm_pol.h>
#include <hal/hal_tm_buf.h>
#include <hal/hal_tm_sch.h>
#include <hal/hal_l2.h>
#include <hal/hal_l3.h>
#include <hal/hal_l3t.h>
#include <hal/hal_mpls.h>
#include <hal/hal_pkt_rsrc.h>
#include <hal/hal_meter.h>
#include <hal/hal_sflow.h>
#include <hal/hal_mir.h>
#include <hal/hal_lag.h>
#include <hal/hal_qos.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef CLX_ERROR_NO_T (*HAL_CMN_INIT_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_DEINIT_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_ADDNVO3ROUTE_FUNC_T)(const UI32_T unit,
                                                      const UI32_T nvo3_encap_idx,
                                                      const CLX_L3_OUTPUT_TYPE_T output_type,
                                                      const UI32_T output_id,
                                                      const UI32_T *ptr_path_buf,
                                                      HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                                                      CMLIB_AVL_HEAD_T *ptr_path_avl);

typedef CLX_ERROR_NO_T (*HAL_CMN_DELNVO3ROUTE_FUNC_T)(const UI32_T unit,
                                                      const UI32_T nvo3_encap_idx,
                                                      HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                                                      CMLIB_AVL_HEAD_T *ptr_path_avl);

typedef CLX_ERROR_NO_T (*HAL_CMN_ADDIEVL3RTENODE_FUNC_T)(const UI32_T unit,
                                                         const UI32_T iev_idx,
                                                         const CLX_L3_OUTPUT_TYPE_T output_type,
                                                         const UI32_T output_id,
                                                         CMLIB_AVL_HEAD_T *ptr_adj_avl,
                                                         CMLIB_AVL_HEAD_T *ptr_iev_avl);
typedef CLX_ERROR_NO_T (*HAL_CMN_DELIEVL3RTENODE_FUNC_T)(const UI32_T unit,
                                                         const UI32_T iev_idx,
                                                         CMLIB_AVL_HEAD_T *ptr_adj_avl,
                                                         CMLIB_AVL_HEAD_T *ptr_iev_avl);

typedef CLX_ERROR_NO_T (*HAL_CMN_GETIEVL3RTENODE_FUNC_T)(const UI32_T unit,
                                                         const UI32_T id,
                                                         CMLIB_AVL_HEAD_T *ptr_adj_avl,
                                                         CMLIB_AVL_HEAD_T *ptr_iev_avl,
                                                         HAL_CMN_RTE_NODE_T **pptr_node);

typedef CLX_ERROR_NO_T (*HAL_CMN_SAVEIEVL3RTENODES_FUNC_T)(CMLIB_AVL_HEAD_T *ptr_adj_avl,
                                                           CMLIB_AVL_HEAD_T *ptr_iev_avl,
                                                           HAL_IO_OBJ_META_T *ptr_obj_meta);

typedef CLX_ERROR_NO_T (*HAL_CMN_RESTOREIEVL3RTENODES_FUNC_T)(const UI32_T unit,
                                                              CMLIB_AVL_HEAD_T *ptr_adj_avl,
                                                              CMLIB_AVL_HEAD_T *ptr_iev_avl,
                                                              const HAL_IO_OBJ_META_T *ptr_obj_meta);

typedef CLX_ERROR_NO_T (*HAL_CMN_GETENCAPIDXFROMPORT_FUNC_T)(const UI32_T unit,
                                                             const CLX_PORT_T port,
                                                             const CLX_TUNNEL_KEY_T *ptr_key,
                                                             UI32_T *ptr_nvo3_encap_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_GETPORTFROMENCAPIDX_FUNC_T)(const UI32_T unit,
                                                             const UI32_T nvo3_encap_idx,
                                                             CLX_PORT_T *ptr_port,
                                                             CLX_TUNNEL_KEY_T *ptr_key,
                                                             BOOL_T *ptr_use_port);

/* vlan multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_VLAN_SETKEEPDEI_FUNC_T)(const UI32_T unit, const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_VLAN_GETKEEPDEI_FUNC_T)(const UI32_T unit, UI32_T *ptr_enable);

/* l2 multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_REPLACEADDRDI_FUNC_T)(const UI32_T unit,
                                                          const UI32_T match_ueid_mgid,
                                                          const UI32_T replace_ueid_mgid);

typedef CLX_ERROR_NO_T (*HAL_CMN_L2_GETPHYMCID_FUNC_T)(const UI32_T unit,
                                                       const UI32_T phy_mc_id,
                                                       UI32_T *ptr_flags,
                                                       CLX_PORT_BITMAP_T port_bitmap);
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_GETUNCOMPRESSPHYMCID_FUNC_T)(const UI32_T unit,
                                                                 const UI32_T logical_mc_id,
                                                                 UI32_T *ptr_phy_mc_id);
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_TRANSBUMLOGICALMCIDTOPHYID_FUNC_T)(const UI32_T unit,
                                                                       const UI32_T logical_mc_id,
                                                                       UI32_T *ptr_phy_mc_id,
                                                                       BOOL_T *ptr_no_compress);
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_GETBUMUNCOMPRESSPHYMCID_FUNC_T)(
    const UI32_T unit,
    const HAL_L2_BUM_MC_ID_T logical_mc_id,
    HAL_L2_BUM_MC_ID_T *ptr_phy_mc_id);
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_SETBUMENTRYLOGICALMCID_FUNC_T)(const UI32_T unit,
                                                                   const UI32_T bum_entry_idx,
                                                                   const UI32_T logical_mc_id);
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_GETBUMENTRYLOGICALMCID_FUNC_T)(const UI32_T unit,
                                                                   const UI32_T bum_entry_idx,
                                                                   UI32_T *ptr_logical_mc_id);
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_ADDBUMENTRYIDXTOAVL_FUNC_T)(const UI32_T unit,
                                                                const UI32_T logical_mc_id,
                                                                const UI32_T bum_entry_idx);
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_DELBUMENTRYIDXTOAVL_FUNC_T)(const UI32_T unit,
                                                                const UI32_T logical_mc_id,
                                                                const UI32_T bum_entry_idx);
typedef CLX_ERROR_NO_T (*HAL_CMN_L2_TRANSUNCOMPRESSPHYMCIDTOLOGICALID_FUNC_T)(
    const UI32_T unit,
    const UI32_T phy_mc_id,
    const BOOL_T lock,
    UI32_T *ptr_logical_mc_id);
/* ifmon multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_LOCKDATA_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_UNLOCKDATA_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_LOCKFLOW_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_UNLOCKFLOW_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_GETLINK_FUNC_T)(const UI32_T unit,
                                                       const UI32_T port,
                                                       UI32_T *ptr_link);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_GETFAULT_FUNC_T)(const UI32_T unit,
                                                        const UI32_T port,
                                                        UI32_T *ptr_fault);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_GETSPEED_FUNC_T)(const UI32_T unit,
                                                        const UI32_T port,
                                                        CLX_PORT_SPEED_T *ptr_speed);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_ADDMOCLORT_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_DELMOCLORT_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_ADDANLTBITMAP_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_DELANLTBITMAP_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_RECORDTIME_FUNC_T)(const UI32_T unit,
                                                          const HAL_IFMON_TIME_T time_type);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_UPDATESWSTATE_FUNC_T)(const UI32_T unit,
                                                             const UI32_T port,
                                                             UI32_T *ptr_updated);

typedef CLX_ERROR_NO_T (*HAL_CMN_IFMON_DUMPLINKSTATE_FUNC_T)(const UI32_T unit);

/* tm multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETPMSTATE_FUNC_T)(const UI32_T unit,
                                                       const UI32_T port,
                                                       const CLX_DIR_T dir,
                                                       const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETPMSPEED_FUNC_T)(const UI32_T unit,
                                                       const UI32_T port,
                                                       const CLX_PORT_SPEED_T speed);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_POL_SETPROPERTY_FUNC_T)(const UI32_T unit,
                                                            const UI32_T port,
                                                            const HAL_TM_EPM_PROPERTY_T property,
                                                            const UI32_T data);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_POL_GETEPMBUFFEREMPTY_FUNC_T)(const UI32_T unit,
                                                                  const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETTSRXENTRY_FUNC_T)(const UI32_T unit,
                                                         const UI32_T port,
                                                         CLX_PORT_TS_ENTRY_T *ptr_ts_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETTSRXSTATE_FUNC_T)(const UI32_T unit,
                                                         const UI32_T port,
                                                         const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_UPDATETSRXLATENCY_FUNC_T)(const UI32_T unit,
                                                              const UI32_T port,
                                                              const UI32_T latency);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_RESETEPMBUFFER_FUNC_T)(const UI32_T unit,
                                                           const UI32_T port,
                                                           const UI32_T lane_num);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETLANENUM_FUNC_T)(const UI32_T unit,
                                                       const UI32_T port,
                                                       UI32_T *ptr_lane_num);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETSTATE_FUNC_T)(const UI32_T unit,
                                                     const UI32_T port,
                                                     const CLX_DIR_T dir,
                                                     const UI32_T all_queue,
                                                     const CLX_TM_HANDLER_T handler,
                                                     const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETSPEED_FUNC_T)(const UI32_T unit,
                                                     const UI32_T port,
                                                     const CLX_PORT_SPEED_T speed);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETSTEERING_ENABLE_FUNC_T)(const UI32_T unit,
                                                               const UI32_T port,
                                                               const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETSTEERING_ENABLE_FUNC_T)(const UI32_T unit,
                                                               const UI32_T port,
                                                               UI32_T *ptr_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETSTEERING_FUNC_T)(
    const UI32_T unit,
    const CLX_SWC_STEERING_ENTRY_T *ptr_str_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETSTEERING_FUNC_T)(const UI32_T unit,
                                                        CLX_SWC_STEERING_ENTRY_T *ptr_str_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_CONFIGTDM_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_UPDATEPORTTDM_FUNC_T)(const UI32_T unit,
                                                          const UI32_T port,
                                                          const UI32_T lane_cnt);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETSTACKINGPORT_FUNC_T)(const UI32_T unit,
                                                            const UI32_T port,
                                                            const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_UPDATEPORTSTATUS_FUNC_T)(const UI32_T unit,
                                                             const UI32_T port,
                                                             const HAL_TM_SC_T status);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETFLOWCTRLMODE_FUNC_T)(const UI32_T unit,
                                                            const UI32_T port,
                                                            const HAL_TM_FC_T mode);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETAOPEMPTY_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SCH_SETPORTEEE_FUNC_T)(const UI32_T unit,
                                                           const UI32_T port,
                                                           const HAL_TM_EEE_MODE_T mode);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SCH_GETPORTEEE_FUNC_T)(const UI32_T unit,
                                                           const UI32_T port,
                                                           HAL_TM_EEE_MODE_T *ptr_mode);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETCUTTHROUGH_FUNC_T)(const UI32_T unit,
                                                          const UI32_T port,
                                                          const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETCUTTHROUGH_FUNC_T)(const UI32_T unit,
                                                          const UI32_T port,
                                                          UI32_T *ptr_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETPORTLANECNT_FUNC_T)(const UI32_T unit,
                                                           const UI32_T port,
                                                           const UI32_T cnt);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_POL_GETLBSEMPTY_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_DEINITPORTFLOW_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SCH_FLUSHQUEUE_FUNC_T)(const UI32_T unit,
                                                           const UI32_T port,
                                                           const UI32_T flush_all,
                                                           const CLX_TM_HANDLER_T handler,
                                                           const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_POL_SETIOSFLUSH_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_CHECKHEALTHMON_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_POL_SETDROPERROR_FUNC_T)(const UI32_T unit,
                                                             const UI32_T port,
                                                             const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_DUMPREGPORTSTATE_FUNC_T)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETTRUNCATIONPROFILE_FUNC_T)(
    const UI32_T unit,
    const HAL_TM_TRUNCATION_RPOFILE_T *profile);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETTRUNCATIONPROFILE_FUNC_T)(
    const UI32_T unit,
    HAL_TM_TRUNCATION_RPOFILE_T *profile);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETTRUNCATION_FUNC_T)(const UI32_T unit,
                                                          const HAL_TM_TRUNCATION_CONFIG_T *config);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETTRUNCATION_FUNC_T)(const UI32_T unit,
                                                          HAL_TM_TRUNCATION_CONFIG_T *config);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETPFCWDINTERVAL_FUNC_T)(const UI32_T unit,
                                                             const UI32_T interval);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETPFCWDINTERVAL_FUNC_T)(const UI32_T unit,
                                                             UI32_T *ptr_interval);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_SETCPA_FUNC_T)(const UI32_T unit,
                                                   const CLX_SWC_PROPERTY_CPA_TYPE_T type,
                                                   const UI32_T value);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_GETCPA_FUNC_T)(const UI32_T unit,
                                                   const CLX_SWC_PROPERTY_CPA_TYPE_T type,
                                                   UI32_T *ptr_value);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_TCB_SETCAPTUREKEY)(const UI32_T unit,
                                                       const HAL_TM_TCB_CAPTURE_KEY_T *ptr_capture);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_TCB_GETCAPTUREKEY)(const UI32_T unit,
                                                       HAL_TM_TCB_CAPTURE_KEY_T *ptr_capture);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_TCB_GETCAPTUREDATA)(
    const UI32_T unit,
    const UI32_T count,
    UI32_T *ptr_real_count,
    HAL_TM_TCB_CAPTURE_DATA_T *ptr_capture_data_list);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_TCB_START)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_TCB_CLEAR)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_ELAM_SETTRIGGERKEY)(
    const UI32_T unit,
    const HAL_TM_ELAM_TRIGGER_KEY_T *ptr_trigger_key);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_ELAM_GETTRIGGERKEY)(const UI32_T unit,
                                                        HAL_TM_ELAM_TRIGGER_KEY_T *ptr_trigger_key);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_ELAM_SETTRIGGERCONFIG)(
    const UI32_T unit,
    const HAL_TM_ELAM_TRIGGER_CONFIG_T *ptr_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_ELAM_GETTRIGGERCONFIG)(const UI32_T unit,
                                                           HAL_TM_ELAM_TRIGGER_CONFIG_T *ptr_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_ELAM_GETCAPTUREDATA)(
    const UI32_T unit,
    const UI32_T count,
    UI32_T *ptr_real_count,
    HAL_TM_ELAM_CAPTURE_DATA_T *ptr_trigger_data_list);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_ELAM_START)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_ELAM_CLEAR)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_BUF_SETDEFAULT)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_PFCWD_STATEDISABLEEVENTHANDLER_FUNC_T)(
    const UI32_T unit,
    const CLX_PORT_T port,
    const UI8_T queue_id,
    const HAL_TM_PFCWD_EVENT_T event,
    HAL_TM_PFCWD_QUEUE_ENTRY_T *ptr_runing_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_PFCWD_STATECFGNOTRDYEVENTHANDLER_FUNC_T)(
    const UI32_T unit,
    const CLX_PORT_T port,
    const UI8_T queue_id,
    const HAL_TM_PFCWD_EVENT_T event,
    HAL_TM_PFCWD_QUEUE_ENTRY_T *ptr_runing_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_PFCWD_PFCWDSTATEOPERATIONALEVENTHANDLER_FUNC_T)(
    const UI32_T unit,
    const CLX_PORT_T port,
    const UI8_T queue_id,
    const HAL_TM_PFCWD_EVENT_T event,
    HAL_TM_PFCWD_QUEUE_ENTRY_T *ptr_runing_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_TM_PFCWD_PFCWDSTATESTORMEDEVENTHANDLER_FUNC_T)(
    const UI32_T unit,
    const CLX_PORT_T port,
    const UI8_T queue_id,
    const HAL_TM_PFCWD_EVENT_T event,
    HAL_TM_PFCWD_QUEUE_ENTRY_T *ptr_runing_entry);

/* MPLS multiplexing functions */
typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_SETSKIPMPLS_FUNC_T)(const UI32_T unit,
                                                          const UI32_T port,
                                                          const UI32_T value);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_GETSKIPMPLS_FUNC_T)(const UI32_T unit,
                                                          const UI32_T port,
                                                          UI32_T *ptr_value);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_SETDELMPLS_FUNC_T)(const UI32_T unit,
                                                         const UI32_T port,
                                                         const UI32_T value);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_GETDELMPLS_FUNC_T)(const UI32_T unit,
                                                         const UI32_T port,
                                                         UI32_T *ptr_value);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_INITCFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_INITWARM_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_DEINITWARM_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_DEINITCFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_GETPATHINFO_FUNC_T)(const UI32_T unit,
                                                          const CLX_PORT_T port,
                                                          const CLX_VLAN_TAG_ACTION_T *ptr_vlan_tag,
                                                          const CLX_VLAN_ACTION_T action,
                                                          HAL_MPLS_PATH_T *ptr_path);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_GETPORTBYPATHINFO_FUNC_T)(const UI32_T unit,
                                                                const HAL_MPLS_PATH_T *ptr_path,
                                                                CLX_PORT_T *ptr_port);

typedef CLX_ERROR_NO_T (*HAL_CMN_MPLS_UPDATEVPWSLAGMEMBER_FUNC_T)(const UI32_T unit,
                                                                  const UI32_T lag_id,
                                                                  const UI32_T add_member_cnt,
                                                                  const UI32_T *ptr_add_member_di,
                                                                  const UI32_T del_member_cnt,
                                                                  const UI32_T *ptr_del_member_di);

/* stat multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_GETTMCNT_FUNC_T)(const UI32_T unit,
                                                       const UI32_T port,
                                                       const CLX_TM_HANDLER_T handler,
                                                       const CLX_STAT_TM_CNT_TYPE_T type,
                                                       CLX_STAT_TM_CNT_T *ptr_cnt);

typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_CLEARTMCNT_FUNC_T)(const UI32_T unit,
                                                         const UI32_T port,
                                                         const CLX_TM_HANDLER_T handler,
                                                         const CLX_STAT_TM_CNT_TYPE_T type);

typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_GETTMQUEUECNTIDX_FUNC_T)(const UI32_T unit,
                                                               const CLX_TM_HANDLER_T handler,
                                                               UI32_T *ptr_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_GETRSERRDISTCNT)(const UI32_T unit,
                                                       const UI32_T port,
                                                       HAL_STAT_RSERRDIST_CNT_ENTRY_T *ptr_cnt);

typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_CLEARRSERRDISTCNT)(const UI32_T unit, const UI32_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_SETRSERRDISTCNTINTERVAL)(const UI32_T unit,
                                                               const UI32_T interval);

typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_GETPORTRATETYPE_FUNC_T)(const UI32_T unit,
                                                              const CLX_STAT_PORT_CNT_TYPE_T type,
                                                              CLX_STAT_RATE_TYPE_T *rate_type);

typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_WRITESRVCNTHWTBL_FUCT_T)(const UI32_T unit,
                                                               const UI32_T is_ingress,
                                                               const UI32_T bank_id,
                                                               const UI32_T sw_bmap_idx_of_bank,
                                                               const CLX_STAT_CNT_CFG_T cnt_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_STAT_SETCNTCFGSOURCE_FUCT_T)(const UI32_T unit,
                                                              const UI32_T is_ingress,
                                                              const UI32_T bank_id,
                                                              const HAL_STAT_HW_TYPE_T cnt_type);

/* l3 multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_FDID2INTF_FUNC_T)(const UI32_T unit,
                                                      const CLX_BRIDGE_DOMAIN_T bdid,
                                                      UI32_T *ptr_intf_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_INTF2FDID_FUNC_T)(const UI32_T unit,
                                                      const UI32_T intf_id,
                                                      CLX_BRIDGE_DOMAIN_T *ptr_bdid);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETGLOBALROUTEMISSACTION_FUNC_T)(const UI32_T unit,
                                                                     const UI32_T action);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETGLOBALROUTEMISSACTION_FUNC_T)(const UI32_T unit,
                                                                     UI32_T *ptr_action);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETADJINFO_FUNC_T)(const UI32_T unit,
                                                       const UI32_T adj_id,
                                                       HAL_L3_ADJ_INFO_T *ptr_adj_info);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETHOSTIDX_FUNC_T)(const UI32_T unit,
                                                       const CLX_L3_HOST_INFO_T *ptr_host_info,
                                                       UI32_T *is_tcam,
                                                       UI32_T *ptr_host_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETECMPINFO_FUNC_T)(const UI32_T unit,
                                                        const UI32_T ecmp_grp_id,
                                                        HAL_L3_ECMP_INFO_T *ptr_ecmp_info);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_UPDATEADJUSENUM_FUNC_T)(const UI32_T unit,
                                                            const UI32_T adj_id,
                                                            const BOOL_T inc);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_UPDATEECMPGRPUSENUM_FUNC_T)(const UI32_T unit,
                                                                const UI32_T ecmp_grp_id,
                                                                const BOOL_T inc);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETPATHIDXBYGRPADJID_FUNC_T)(
    const UI32_T unit,
    const UI32_T ecmp_grp_id,
    const CLX_L3_OUTPUT_TYPE_T output_type,
    const UI32_T adj_id,
    UI32_T *ptr_act_idx,
    UI32_T *ptr_act_cnt,
    UI32_T *ptr_orig_idx,
    UI32_T *ptr_orig_cnt);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETECMPBLOCKSIZE_FUNC_T)(const UI32_T unit, const UI32_T size);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETECMPRESILIENT_FUNC_T)(const UI32_T unit,
                                                             const UI32_T is_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETECMPRESILIENT_FUNC_T)(const UI32_T unit, UI32_T *is_enable);

typedef CLX_ERROR_NO_T (
    *HAL_CMN_L3_SETECMPALGOMODE_FUNC_T)(const UI32_T unit, const CLX_L3_ECMP_ALGORITHM_MODE_T mode);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETECMPALGOMODE_FUNC_T)(const UI32_T unit,
                                                            CLX_L3_ECMP_ALGORITHM_MODE_T *mode);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETECMPGRPMAXMBRNUM_FUNC_T)(const UI32_T unit,
                                                                const UI32_T num);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETECMPGRPMAXMBRNUM_FUNC_T)(const UI32_T unit, UI32_T *num);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_ACLBINDECMPGRP_FUNC_T)(const UI32_T unit,
                                                           const UI32_T old_ecmp_grp_id,
                                                           UI32_T *new_ecmp_grp_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_ACLUNBINDECMPGRP_FUNC_T)(const UI32_T unit,
                                                             const UI32_T old_ecmp_grp_id,
                                                             const UI32_T new_ecmp_grp_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETECMPBLOCKSIZE_FUNC_T)(const UI32_T unit, UI32_T *ptr_size);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_ADDFCOETCAMENTRY_FUNC_T)(
    const UI32_T unit,
    const UI32_T is_vrf,
    const UI32_T intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T *ptr_fcid_addr,
    const UI32_T group_label,
    const UI32_T iev_rslt_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_DELFCOETCAMENTRY_FUNC_T)(
    const UI32_T unit,
    const UI32_T is_vrf,
    const UI32_T intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T *ptr_fcid_addr);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETFCOETCAMENTRY_FUNC_T)(
    const UI32_T unit,
    const UI32_T is_vrf,
    const UI32_T intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T *ptr_fcid_addr,
    UI32_T *ptr_group_label,
    UI32_T *ptr_iev_rslt_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_DELMEMBERALL_FUNC_T)(const UI32_T unit, const UI32_T mcast_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_ADDMELSUBENTRYBYPORT_FUNC_T)(
    const UI32_T unit,
    const UI32_T mcast_id,
    const UI32_T port_id,
    const UI32_T entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T *ptr_sub_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_DELMELSUBENTRYBYPORT_FUNC_T)(
    const UI32_T unit,
    const UI32_T mcast_id,
    const UI32_T port_id,
    const UI32_T entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T *ptr_sub_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETMELSUBENTRYBYPORT_FUNC_T)(
    const UI32_T unit,
    const UI32_T mcast_id,
    const UI32_T port_id,
    const UI32_T entry_num,
    HAL_L3_MCAST_MEL_SUB_ENTRY_T *ptr_sub_entry,
    UI32_T *ptr_actual_num);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETMELSUBENTRYNUMBYPORT_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T mcast_id,
                                                                    const UI32_T port_id,
                                                                    UI32_T *ptr_entry_num);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETCAPACITY_FUNC_T)(const UI32_T unit,
                                                        const CLX_SWC_RSRC_T type,
                                                        const UI32_T param,
                                                        UI32_T *ptr_size);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETUSAGE_FUNC_T)(const UI32_T unit,
                                                     const CLX_SWC_RSRC_T type,
                                                     const UI32_T param,
                                                     UI32_T *ptr_cnt);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETICMPREDIRECT_FUNC_T)(const UI32_T unit,
                                                            UI32_T *ptr_is_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETICMPREDIRECT_FUNC_T)(const UI32_T unit,
                                                            const UI32_T is_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETSELFFORWARD_FUNC_T)(const UI32_T unit,
                                                           UI32_T *ptr_is_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETSELFFORWARD_FUNC_T)(const UI32_T unit,
                                                           const UI32_T is_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETURPFCHECK_FUNC_T)(const UI32_T unit, UI32_T *ptr_is_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETURPFCHECK_FUNC_T)(const UI32_T unit, const UI32_T is_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETVALIDATEIP_FUNC_T)(const UI32_T unit,
                                                          UI32_T *ptr_enable,
                                                          UI32_T *ptr_fail_act);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETVALIDATEIP_FUNC_T)(const UI32_T unit,
                                                          const UI32_T enable,
                                                          const UI32_T fail_act);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETL3EXCPTACT_FUNC_T)(const UI32_T unit,
                                                          const CLX_SWC_PROPERTY_T property,
                                                          CLX_FWD_ACTION_T *ptr_action);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETL3EXCPTACT_FUNC_T)(const UI32_T unit,
                                                          const CLX_SWC_PROPERTY_T property,
                                                          const CLX_FWD_ACTION_T action);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETL3HDRERRACT_FUNC_T)(const UI32_T unit,
                                                           const CLX_SWC_PROPERTY_T property,
                                                           CLX_FWD_ACTION_T *ptr_action);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETL3HDRERRACT_FUNC_T)(const UI32_T unit,
                                                           const CLX_SWC_PROPERTY_T property,
                                                           const CLX_FWD_ACTION_T action);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_ALLOCFPU_FUNC_T)(const UI32_T unit,
                                                     const CLX_L3_OUTPUT_TYPE_T output_type,
                                                     const UI32_T output_id,
                                                     const UI32_T subnet_bc_id,
                                                     UI32_T *ptr_fwd_ptr);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETFPU_FUNC_T)(const UI32_T unit,
                                                   const UI32_T hw_addr,
                                                   CLX_L3_OUTPUT_TYPE_T *ptr_output_type,
                                                   UI32_T *ptr_output_id,
                                                   UI32_T *ptr_subnet_bc_id);

/* Ecmp Internal for L2 */
/* Create Group */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_CREATEL2GRP_FUNC_T)(const UI32_T unit,
                                                        const CLX_L2_ECMP_GROUP_T *ptr_ecmp_info,
                                                        UI32_T *ptr_ecmp_grp_id);

/* Set Group */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETL2GRP_FUNC_T)(const UI32_T unit,
                                                     const CLX_L2_ECMP_GROUP_T *ptr_ecmp_info,
                                                     UI32_T ptr_ecmp_grp_id);

/* Del Group */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_DELL2GRP_FUNC_T)(const UI32_T unit, const UI32_T ecmp_grp_id);

/* Get Group */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETL2GRP_FUNC_T)(const UI32_T unit,
                                                     const UI32_T ecmp_grp_id,
                                                     CLX_L2_ECMP_GROUP_T *ptr_ecmp_info);

/* Add path */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_ADDL2GRPPATH_FUNC_T)(const UI32_T unit,
                                                         const UI32_T ecmp_grp_id,
                                                         const CLX_L2_ECMP_PATH_T *ptr_path_info);

/* Del path */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_DELL2GRPPATH_FUNC_T)(const UI32_T unit,
                                                         const UI32_T ecmp_grp_id,
                                                         const CLX_L2_ECMP_PATH_T *ptr_path_info);

/* Get path by idx */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETL2GRPPATHBYIDX_FUNC_T)(const UI32_T unit,
                                                              const UI32_T ecmp_grp_id,
                                                              const UI32_T path_idx,
                                                              CLX_L2_ECMP_PATH_T *ptr_path_info);

/* Set grp hsh */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETL2GRPPATHHSH_FUNC_T)(const UI32_T unit,
                                                            const UI32_T ecmp_grp_id,
                                                            const UI32_T *ptr_hash_val_list,
                                                            const UI32_T hash_val_cnt,
                                                            const CLX_L2_ECMP_PATH_T *ptr_path_info);

/* Get grp hsh */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_GETL2GRPPATHHSH_FUNC_T)(
    const UI32_T unit,
    const UI32_T ecmp_grp_id,
    const UI32_T hash_val_cnt,
    const CLX_L2_ECMP_PATH_T *ptr_ecmp_path_info,
    UI32_T *ptr_hash_val_list,
    UI32_T *ptr_actual_hash_val_cnt);

/* Dump Group Path List */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_DUMPL2PATHLIST_FUNC_T)(const UI32_T unit,
                                                           const UI32_T ecmp_grp_id);

/* Set cpu di */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3_SETL2CPUDI_FUNC_T)(const UI32_T unit,
                                                       const UI32_T cpu_id,
                                                       const UI32_T cpu_queue);

/* l3t multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_CFGFLEXTNLGTP_FUNC_T)(const UI32_T unit,
                                                           const UI32_T index,
                                                           const UI32_T flags);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_CFGFLEXTNLPIM_FUNC_T)(const UI32_T unit,
                                                           const UI32_T index,
                                                           const UI32_T flags);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_CFGFLEXTNLGENEVE_FUNC_T)(const UI32_T unit,
                                                              const UI32_T index,
                                                              const UI32_T flags);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_CFGFLEXTNLUSERDEFINED_FUNC_T)(const UI32_T unit,
                                                                   const UI32_T index,
                                                                   const UI32_T flags);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_INITCFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_SETEXCPTACT_FUNC_T)(const UI32_T unit,
                                                         const CLX_SWC_PROPERTY_T property,
                                                         CLX_FWD_ACTION_T action);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_GETEXCPTACT_FUNC_T)(const UI32_T unit,
                                                         const CLX_SWC_PROPERTY_T property,
                                                         CLX_FWD_ACTION_T *ptr_action);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_TRAVTNL2LIST)(const UI32_T unit,
                                                   const HAL_L3T_TRAV_TYPE_T type,
                                                   CMLIB_LIST_T *ptr_list);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_CFGECMPPATHBYNVO3ADJINFO)(const UI32_T unit,
                                                               const UI32_T ecmp_path_idx,
                                                               const CLX_PORT_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_TRANSNVO3ADJTOECMPPATH)(const UI32_T unit,
                                                             const UI32_T nvo3_adj_id,
                                                             CDB_FVP_T *ptr_path_info,
                                                             UI32_T *ptr_buf);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_ALLOCIPSAIDX)(const UI32_T unit,
                                                   const BOOL_T is_ipv4,
                                                   const CLX_IP_ADDR_T *ptr_src_ip,
                                                   UI32_T *ptr_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_FREEIPSAIDX)(const UI32_T unit,
                                                  const BOOL_T is_ipv4,
                                                  const UI32_T idx);
typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_ALLOCIPDAIDX)(const UI32_T unit,
                                                   const BOOL_T is_ipv4,
                                                   const CLX_IP_ADDR_T *ptr_dst_ip,
                                                   const BOOL_T is_seglist,
                                                   const CLX_SRV6_SIDLIST_T *ptr_segment_list,
                                                   UI32_T *ptr_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_FREEIPDAIDX)(const UI32_T unit,
                                                  const BOOL_T is_ipv4,
                                                  const BOOL_T is_seglist,
                                                  const UI32_T segments_left,
                                                  const UI32_T idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_ALLOCDSTTEPIDX)(const UI32_T unit,
                                                     const BOOL_T is_ipv4,
                                                     UI32_T *ptr_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_FREEDSTTEPIDX)(const UI32_T unit,
                                                    const BOOL_T is_ipv4,
                                                    const UI32_T idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_SETTNLPSREN)(const UI32_T unit,
                                                  const CLX_L3T_TNL_PSR_TYPE_T type,
                                                  const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_L3T_GETTNLPSREN)(const UI32_T unit,
                                                  const CLX_L3T_TNL_PSR_TYPE_T type,
                                                  UI32_T *ptr_en);

/* nv multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_NV_INITCFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_NV_SETVXLANRACHECK_FUNC_T)(const UI32_T unit, const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_NV_GETVXLANRACHECK_FUNC_T)(const UI32_T unit, UI32_T *ptr_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_NV_SETNVGRERACHECK_FUNC_T)(const UI32_T unit, const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_NV_GETNVGRERACHECK_FUNC_T)(const UI32_T unit, UI32_T *ptr_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_NV_SETVXLANUDPPORT_FUNC_T)(const UI32_T unit, const UI32_T dport);

typedef CLX_ERROR_NO_T (*HAL_CMN_NV_GETVXLANUDPPORT_FUNC_T)(const UI32_T unit, UI32_T *ptr_dport);

/* srv6 multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_SRV6_INITCFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_SRV6_INITWARM_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_SRV6_DEINITWARM_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_SRV6_CFGEGRLCLINTF_FUNC_T)(const UI32_T unit,
                                                            const HAL_CMN_ACTION_T hwdb_action,
                                                            const CLX_SRV6_ENCAPS_T *ptr_srv6_encaps,
                                                            const UI32_T rwi_rslt_lcl_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_SRV6_CFGIGRLCLINTF_FUNC_T)(const UI32_T unit,
                                                            const HAL_CMN_ACTION_T hwdb_action,
                                                            const CLX_SRV6_LOCAL_T *ptr_srv6_local,
                                                            const UI32_T dis_rslt_lcl_idx);

/* pkt multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPIPPEXCPTCODETOUSER_FUNC_T)(
    const UI32_T unit,
    UI32_T code,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPIPPRSNCODETOUSER_FUNC_T)(
    const UI32_T unit,
    UI32_T code,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPEPPEXCPTCODETOUSER_FUNC_T)(
    const UI32_T unit,
    UI32_T code,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPIPPEXCPTTOUSER_FUNC_T)(
    const UI32_T unit,
    const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPIPPL3EXCPTTOUSER_FUNC_T)(
    const UI32_T unit,
    const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPIPPCOPYTOCPUTOUSER_FUNC_T)(
    const UI32_T unit,
    const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPIPPRSNTOUSER_FUNC_T)(
    const UI32_T unit,
    const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPEPPEXCPTTOUSER_FUNC_T)(
    const UI32_T unit,
    const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPEPPCOPYTOCPUTOUSER_FUNC_T)(
    const UI32_T unit,
    const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPUSERTOIPPEXCPT_FUNC_T)(
    const UI32_T unit,
    const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPUSERTOIPPL3EXCPT_FUNC_T)(
    const UI32_T unit,
    const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPUSERTOIPPCOPYTOCPU_FUNC_T)(
    const UI32_T unit,
    const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPUSERTOIPPRSN_FUNC_T)(
    const UI32_T unit,
    const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPUSERTOEPPEXCPT_FUNC_T)(
    const UI32_T unit,
    const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_MAPUSERTOEPPCOPYTOCPU_FUNC_T)(
    const UI32_T unit,
    const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_TRANSUSERTOHWREASON_FUNC_T)(
    const UI32_T unit,
    const CLX_PKT_RX_REASON_T user_reason,
    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T hw_action,
    UI32_T *ptr_hw_reason);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_TRANSHWTOUSERREASON_FUNC_T)(
    const UI32_T unit,
    const UI32_T hw_reason,
    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T hw_action,
    CLX_PKT_RX_REASON_T *ptr_user_reason);

typedef CLX_ERROR_NO_T (*HAL_CMN_PKT_INITREASONMAP_FUNC_T)(const UI32_T unit);

/* dtel multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_DTEL_GETPORTPROPERTY_FUNC_T)(const UI32_T unit,
                                                              const UI32_T port,
                                                              const CLX_PORT_PROPERTY_T property,
                                                              UI32_T *ptr_param0,
                                                              UI32_T *ptr_param1);

typedef CLX_ERROR_NO_T (*HAL_CMN_DTEL_SETPORTPROPERTY_FUNC_T)(const UI32_T unit,
                                                              const UI32_T port,
                                                              const CLX_PORT_PROPERTY_T property,
                                                              const UI32_T param0,
                                                              const UI32_T param1);

typedef CLX_ERROR_NO_T (*HAL_CMN_DTEL_GETPROPERTY_FUNC_T)(const UI32_T unit,
                                                          const CLX_SWC_PROPERTY_T property,
                                                          UI32_T *ptr_param0,
                                                          UI32_T *ptr_param1);

typedef CLX_ERROR_NO_T (*HAL_CMN_DTEL_SETPROPERTY_FUNC_T)(const UI32_T unit,
                                                          const CLX_SWC_PROPERTY_T property,
                                                          const UI32_T param0,
                                                          const UI32_T param1);

/* telm multiplexing functions start */
typedef CLX_ERROR_NO_T (*HAL_CMN_TELM_GETPORTPROPERTY_FUNC_T)(const UI32_T unit,
                                                              const UI32_T port,
                                                              const CLX_PORT_PROPERTY_T property,
                                                              UI32_T *ptr_param0,
                                                              UI32_T *ptr_param1);

typedef CLX_ERROR_NO_T (*HAL_CMN_TELM_SETPORTPROPERTY_FUNC_T)(const UI32_T unit,
                                                              const UI32_T port,
                                                              const CLX_PORT_PROPERTY_T property,
                                                              const UI32_T param0,
                                                              const UI32_T param1);

typedef CLX_ERROR_NO_T (*HAL_CMN_TELM_GETPROPERTY_FUNC_T)(const UI32_T unit,
                                                          const CLX_SWC_PROPERTY_T property,
                                                          UI32_T *ptr_param0,
                                                          UI32_T *ptr_param1);

typedef CLX_ERROR_NO_T (*HAL_CMN_TELM_SETPROPERTY_FUNC_T)(const UI32_T unit,
                                                          const CLX_SWC_PROPERTY_T property,
                                                          const UI32_T param0,
                                                          const UI32_T param1);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_INITEGRUCPRSRC_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_INITEGRUCPWARMRSRC_FUNC_T)(const UI32_T unit,
                                                                const HAL_IO_WB_DB_T *ptr_wbdb);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_DEINITEGRUCPRSRC_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_DEINITEGRUCPWARMRSRC_FUNC_T)(const UI32_T unit,
                                                                  HAL_IO_OBJ_META_T *ptr_wbdb_obj);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETACTIVEUCP_FUNC_T)(const UI32_T unit,
                                                          const CLX_ACL_GROUP_T type,
                                                          const UI32_T ucp_bmp);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_FLIPEGRUCP_FUNC_T)(const UI32_T unit,
                                                        const UI32_T enable_ucp,
                                                        const UI32_T disable_ucp);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETUCPCFG_FUNC_T)(const UI32_T unit,
                                                       const CLX_ACL_GROUP_T type,
                                                       const UI32_T tbl_id,
                                                       const UI32_T ucp_id,
                                                       const HAL_UCP_FRM_TYP_ENUM_T frame_type,
                                                       const UI32_T *ptr_buf);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETUCPPBMEN_FUNC_T)(const UI32_T unit,
                                                         const UI32_T tbl_id,
                                                         const UI32_T ucp_id,
                                                         const UI32_T *ptr_buf);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_ADDHWENTRY_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T entry_1x_id,
    const UI32_T norm_width,
    const HAL_ACL_PLANE_BCAST_INFO_T *ptr_bcast_info,
    UI32_T (*ptr_entry_2d_buf)[HAL_ACL_ENTRY_WORDS]);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETHWENTRYVLD_FUNC_T)(const UI32_T unit,
                                                           const CLX_ACL_GROUP_T type,
                                                           const UI32_T hw_entry_id,
                                                           const UI32_T norm_width,
                                                           const BOOL_T entry_valid);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_READHWENTRY_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T entry_1x_id,
    const UI32_T norm_width,
    UI32_T (*ptr_entry_2d_buf)[HAL_ACL_ENTRY_WORDS]);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_DELHWENTRY_FUNC_T)(const UI32_T unit,
                                                        const CLX_ACL_GROUP_T type,
                                                        const UI32_T entry_1x_id,
                                                        const UI32_T norm_width);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_CLEARCONTHWENTRY_FUNC_T)(const UI32_T unit,
                                                              const CLX_ACL_GROUP_T type,
                                                              const UI32_T start_1x_entry,
                                                              const UI32_T last_1x_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_MOVEHWENTRY_FUNC_T)(const UI32_T unit,
                                                         const CLX_ACL_GROUP_T type,
                                                         const I32_T src_1x_entry_id,
                                                         const I32_T dst_1x_entry_id,
                                                         const UI32_T tot_1x_move_entry_num,
                                                         const DCC_DMA_D2D_DIR_T d2d_dir,
                                                         const UI32_T shift_cnt,
                                                         const UI32_T cont_move);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_CHECKGROUP_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T prio,
    const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_ADDGROUP_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T prio,
    const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile,
    UI32_T *ptr_group_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETGROUP_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T prio,
    const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile,
    UI32_T group_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_FREEENTRYALLOCRSRC_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const HAL_ACL_ENTRY_ALLOC_INFO_T *ptr_alloc_info);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RESETUCP_FUNC_T)(const UI32_T unit,
                                                      const CLX_ACL_GROUP_T type,
                                                      UI32_T ucp_bmp);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETGROUPPROFILE_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T group_id,
    const UI32_T ucp_member_bmp,
    CLX_ACL_GROUP_PROFILE_T *ptr_group_profile);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETUCPPBMEN_FUNC_T)(const UI32_T unit,
                                                         const CLX_ACL_GROUP_T type,
                                                         const UI32_T group,
                                                         UI32_T *ptr_ucp_pbm_en);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETACLPKGPROF_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T udf_prof_id,
    const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile,
    UI32_T *ptr_acl_pkg_vld,
    UI32_T *ptr_pkg_0_cnt,
    UI32_T *ptr_pkg_1_cnt,
    UI32_T *ptr_pkg_0_consecutive_bmp,
    UI32_T *ptr_pkg_1_consecutive_bmp);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETFLWPKGPROF_FUNC_T)(
    const UI32_T unit,
    const UI32_T udf_prof_id,
    const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile,
    UI32_T *ptr_flw_pkg_vld,
    UI32_T *ptr_flw_1_pkg_vld,
    UI32_T *ptr_consecutive_bmp);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETPKGLOUPROFIDX_FUNC_T)(const UI32_T unit,
                                                              const CLX_ACL_GROUP_T type,
                                                              const UI32_T udf_prof_id,
                                                              const UI32_T flw_pkg_vld,
                                                              const UI32_T pkg_vld,
                                                              const UI32_T lou_vld);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETTCAMPKGLOU_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T udf_key_profile_id,
    const BOOL_T valid,
    const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETPKTFORMAT_FUNC_T)(const UI32_T unit,
                                                          const CLX_ACL_GROUP_T type,
                                                          const UI32_T udf_prof_id,
                                                          const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                                                          CLX_ACL_PKT_FORMAT_T *ptr_pkt_format);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETACLPKGPROF_FUNC_T)(const UI32_T unit,
                                                           const CLX_ACL_GROUP_T type,
                                                           const UI32_T acl_pkg_prof_idx,
                                                           const UI32_T acl_pkg_prof_vld,
                                                           const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                                                           CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETFLWPKGPROF_FUNC_T)(const UI32_T unit,
                                                           const UI32_T flw_pkg_prof_idx,
                                                           const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                                                           CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETPKGLOUPROFIDX_FUNC_T)(const UI32_T unit,
                                                              const CLX_ACL_GROUP_T type,
                                                              const UI32_T udf_prof_id,
                                                              UI32_T *ptr_flw_pkg_prof_vld,
                                                              UI32_T *ptr_flw_pkg_prof_idx,
                                                              UI32_T *ptr_acl_pkg_prof_vld,
                                                              UI32_T *ptr_acl_pkg_prof_idx,
                                                              UI32_T *ptr_lou_prof_vld,
                                                              UI32_T *ptr_lou_prof_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETLOUPROF_FUNC_T)(const UI32_T unit,
                                                        const CLX_ACL_GROUP_T type,
                                                        const UI32_T udf_prof_id,
                                                        const UI32_T lou_id,
                                                        const HAL_ACL_LOU_INFO_T *ptr_lou_info,
                                                        CLX_ACL_LOU_CFG_T *ptr_lou);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETLOUPROF_FUNC_T)(const UI32_T unit,
                                                        const CLX_ACL_GROUP_T type,
                                                        const UI32_T udf_prof_id,
                                                        const UI32_T lou_id,
                                                        const CLX_ACL_LOU_CFG_T *ptr_lou);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETACLPKGPROFLOUINFO_FUNC_T)(const UI32_T unit,
                                                                  const CLX_ACL_GROUP_T type,
                                                                  const UI32_T acl_pkg_prof_idx,
                                                                  UI32_T *ptr_acl_int_lou_vld,
                                                                  UI32_T *ptr_acl_lou_en);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETFLWPKGPROFLOUINFO_FUNC_T)(const UI32_T unit,
                                                                  const UI32_T flw_pkg_prof_idx,
                                                                  UI32_T *ptr_flw_int_lou_vld,
                                                                  UI32_T *ptr_flw_lou_en,
                                                                  UI32_T *ptr_flw_1_int_lou_vld,
                                                                  UI32_T *ptr_flw_1_lou_en);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETFLWPKGPROFLOUEN_FUNC_T)(const UI32_T unit,
                                                                const UI32_T flw_pkg_prof_idx,
                                                                const UI32_T lou_id,
                                                                const UI32_T flw_int_lou_vld,
                                                                const UI32_T flw_lou_en,
                                                                const UI32_T flw_1_int_lou_vld,
                                                                const UI32_T flw_1_lou_en);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETACLPKGPROFLOUEN_FUNC_T)(const UI32_T unit,
                                                                const CLX_ACL_GROUP_T type,
                                                                const UI32_T acl_pkg_prof_idx,
                                                                const UI32_T acl_lou_en);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETFLWUDFKEYINFO_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_CLASSIFY_T *ptr_classify,
    HAL_ACL_FLOW_ENTRY_PACK_UDF_KEY_T *ptr_flw_udf_key,
    UI32_T *ptr_udf_prof_flw_key_typ);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETUDFKEYINFO_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_GROUP_T type,
    const UI32_T group,
    const CLX_ACL_CLASSIFY_T *ptr_classify,
    HAL_ACL_ENTRY_PACK_UDF_KEY_T *ptr_udf_key);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETFREEUCPPBM_FUNC_T)(const UI32_T unit,
                                                           const CLX_ACL_GROUP_T type,
                                                           UI32_T *ucp_num,
                                                           UI32_T *free_ucp_bmp);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_ADDUCPTOGROUP_FUNC_T)(const UI32_T unit,
                                                           const CLX_ACL_GROUP_T type,
                                                           const UI32_T group,
                                                           const UI32_T new_ucp);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_ENABLEGROUP_FUNC_T)(const UI32_T unit,
                                                         const CLX_ACL_GROUP_T type,
                                                         const UI32_T group,
                                                         const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETFLOWENTRY_FUNC_T)(
    const UI32_T unit,
    const HAL_ACL_FLOW_ENTRY_INFO_T *ptr_entry_info,
    CLX_ACL_CLASSIFY_T *ptr_classify,
    CLX_ACL_ACTION_T *ptr_action);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_UNPACKENTRY_FUNC_T)(const UI32_T unit,
                                                         const CLX_ACL_GROUP_T type,
                                                         const HAL_ACL_ENTRY_INFO_T *ptr_entry_info,
                                                         BOOL_T *ptr_entry_valid,
                                                         CLX_ACL_CLASSIFY_T *ptr_classify,
                                                         CLX_ACL_ACTION_T *ptr_action);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_UPDATEECMPINFO_FUNC_T)(const UI32_T unit,
                                                            const UI32_T ecmp_group_id,
                                                            const HAL_L3_ECMP_INFO_T *ptr_ecmp_info);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_UPDATEADJINFO_FUNC_T)(const UI32_T unit,
                                                           const UI32_T adj_id,
                                                           const HAL_L3_ADJ_INFO_T *ptr_adj_info);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETUCPPRIO_FUNC_T)(const UI32_T unit,
                                                        const CLX_ACL_GROUP_T type,
                                                        const UI32_T group_id,
                                                        const HAL_ACL_UCP_PRIO_T *ucp_prio);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_INITCFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETFLOWENTRYIDINFO_FUNC_T)(const UI32_T unit,
                                                                const UI32_T hw_entry_id,
                                                                CLX_ACL_GROUP_T *ptr_type,
                                                                UI32_T *ptr_group_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_CHECKFLOWPREEMPTENTRY_FUNC_T)(const UI32_T unit,
                                                                   const UI32_T group_id,
                                                                   const UI32_T ucp_member_bmp,
                                                                   UI32_T *ptr_flow_entry);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_FREEFLOWPREEMPTENTRY_FUNC_T)(const UI32_T unit,
                                                                  const UI32_T ucp_member_bmp);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_DELFLOWENTRY_FUNC_T)(const UI32_T unit,
                                                          const UI32_T group_id,
                                                          HAL_ACL_FLOW_ENTRY_INFO_T *ptr_entry_info);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETFLOWGROUPENTRYCAPUSAGE_FUNC_T)(const UI32_T unit,
                                                                       const CLX_ACL_GROUP_T type,
                                                                       const UI32_T group_id,
                                                                       const UI32_T get_capacity,
                                                                       UI32_T *ptr_cnt);
typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_SETTAPPINGTPID_FUNC_T)(const UI32_T unit,
                                                            const CLX_SWC_PROPERTY_T property,
                                                            const UI32_T tpid);
typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETTAPPINGTPID_FUNC_T)(const UI32_T unit,
                                                            const CLX_SWC_PROPERTY_T property,
                                                            UI32_T *tpid);
typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_ALLOC_FCM_IDX_FUNC_T)(const UI32_T unit,
                                                               const UI32_T is_flw,
                                                               UI32_T *ptr_index);
typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_FREE_FCM_IDX_FUNC_T)(const UI32_T unit,
                                                              const UI32_T is_flw,
                                                              const UI32_T index);
typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_SETFCMACTION_FUNC_T)(const UI32_T unit,
                                                              const UI32_T is_flw,
                                                              const UI32_T index,
                                                              const void *ptr_action);
typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_GETFCMACTION_FUNC_T)(const UI32_T unit,
                                                              const UI32_T is_flw,
                                                              const UI32_T index,
                                                              const void *ptr_action);
typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_TRAVFCMACTION_FUNC_T)(
    const UI32_T unit,
    const UI32_T is_flw,
    const CLX_ACL_RIM_TRAVERSE_FUNC_T callback,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_ALLOCENTRYID_FUNC_T)(const UI32_T unit,
                                                          const CLX_ACL_GROUP_T type,
                                                          const UI32_T group_id,
                                                          const UI32_T entry_priority,
                                                          UI32_T *ptr_enrty_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_GETSWENTRYINFO_FUNC_T)(const UI32_T unit,
                                                            const UI32_T entry_id,
                                                            CLX_ACL_GROUP_T *type,
                                                            UI32_T *sw_entry_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_INIT_CFG_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_ALLOC_REDIR_IDX_FUNC_T)(const UI32_T unit,
                                                                 const CLX_ACL_RIM_ALLOC_T type,
                                                                 UI32_T *ptr_index);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_FREE_REDIR_IDX_FUNC_T)(const UI32_T unit,
                                                                const CLX_ACL_RIM_ALLOC_T type,
                                                                const UI32_T index);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_SET_REDIR_IDX_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_RIM_ALLOC_T type,
    const UI32_T index,
    const CLX_ACL_REDIRECT_ACTION_T *ptr_redir_act);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_GET_REDIR_IDX_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_RIM_ALLOC_T type,
    const UI32_T index,
    CLX_ACL_REDIRECT_ACTION_T *ptr_redir_act);

typedef CLX_ERROR_NO_T (*HAL_CMN_ACL_RIM_TRAV_REDIR_IDX_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_RIM_ALLOC_T type,
    const CLX_ACL_RIM_TRAVERSE_FUNC_T callback,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_SET_METER_CFG_REG_T)(const UI32_T unit,
                                                            const HAL_METER_TYPE_T type,
                                                            const UI32_T bank_idx,
                                                            const BOOL_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_TRANS_METER_HWIDX_T)(const UI32_T unit,
                                                            const HAL_METER_INDEX_T *ptr_hw_index,
                                                            UI32_T *ptr_hw_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_TRANS_METER_INDEX_T)(const UI32_T unit,
                                                            const UI32_T hw_idx,
                                                            HAL_METER_INDEX_T *ptr_hw_index);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_SET_METER_POOL_T)(const UI32_T unit,
                                                         const HAL_METER_SW_METER_T *ptr_sw_meter);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_SET_IGR_PORT_METER_T)(const UI32_T unit,
                                                             const UI32_T port,
                                                             const CLX_METER_PORT_CFG_T *ptr_cfg,
                                                             const HAL_METER_CFG_T *ptr_hal_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_GET_IGR_PORT_METER_T)(const UI32_T unit,
                                                             const UI32_T port,
                                                             CLX_METER_PORT_CFG_T *ptr_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_ALLOC_CNT_MTR_PROF_T)(const UI32_T unit,
                                                             const BOOL_T ingress,
                                                             UI32_T *ptr_cnt_mtr_prof_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_FREE_CNT_MTR_PROF_T)(const UI32_T unit,
                                                            const BOOL_T ingress,
                                                            const UI32_T cnt_mtr_prof_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_SET_CNT_MTR_PROF_T)(
    const UI32_T unit,
    const BOOL_T ingress,
    const UI32_T cnt_mtr_prof_idx,
    const HAL_METER_CNT_MTR_FIELD_T cnt_mtr_field,
    const UI32_T cnt_mtr_hw_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_GET_CNT_MTR_PROF_T)(
    const UI32_T unit,
    const BOOL_T ingress,
    const UI32_T cnt_mtr_prof_idx,
    const HAL_METER_CNT_MTR_FIELD_T cnt_mtr_field,
    UI32_T *ptr_cnt_mtr_hw_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_METER_CHECK_CNT_MTR_PROF_T)(const UI32_T unit,
                                                             const BOOL_T ingress,
                                                             const UI32_T cnt_mtr_prof_idx,
                                                             BOOL_T *ptr_cnt_mtr_exist);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_SET_IGR_CFG_SFLW_MIR_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T profile_id,
                                                                    const UI32_T sflw_mir_en,
                                                                    const UI32_T sflw_mir_bidx);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_GET_IGR_CFG_SFLW_MIR_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T profile_id,
                                                                    UI32_T *ptr_sflw_mir_en,
                                                                    UI32_T *ptr_sflw_mir_bidx);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_SET_EGR_CFG_SFLW_MIR_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T profile_id,
                                                                    const UI32_T sflw_mir_en,
                                                                    const UI32_T sflw_mir_bidx);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_GET_EGR_CFG_SFLW_MIR_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T profile_id,
                                                                    UI32_T *ptr_sflw_mir_en,
                                                                    UI32_T *ptr_sflw_mir_bidx);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_SET_IGR_CFG_SFLW_FUNC_T)(const UI32_T unit,
                                                                const UI32_T profile_id,
                                                                const UI32_T sflw_cp_to_cpu_bidx,
                                                                const UI32_T sflw_splr_threshold,
                                                                const UI32_T sflw_ioam_en,
                                                                const UI32_T sflw_ioam_flw_lbl_val);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_GET_IGR_CFG_SFLW_FUNC_T)(const UI32_T unit,
                                                                const UI32_T profile_id,
                                                                UI32_T *ptr_sflw_cp_to_cpu_bidx,
                                                                UI32_T *ptr_sflw_ioam_en,
                                                                UI32_T *ptr_sflw_ioam_flw_lbl_val);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_SET_EGR_CFG_SFLW_FUNC_T)(const UI32_T unit,
                                                                const UI32_T profile_id,
                                                                const UI32_T sflw_cp_to_cpu_bidx,
                                                                const UI32_T sflw_splr_threshold);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_GET_EGR_CFG_SFLW_FUNC_T)(const UI32_T unit,
                                                                const UI32_T profile_id,
                                                                UI32_T *ptr_sflw_cp_to_cpu_bidx);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_SET_HIGH_LATENCY_CFG_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T threshold,
                                                                    const UI32_T sflw_lat_en);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_SET_CFG_IOAM_FLW_LBL_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T profile_id,
                                                                    const UI32_T ioam_flw_lbl_val,
                                                                    const UI32_T ioam_flw_lbl_msk);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_INIT_CFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_LAG_INIT_CFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_SWC_INIT_CFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_SWC_GET_ILE_BANK_TYPE_FUNC_T)(const UI32_T unit,
                                                               const UI32_T bank_num,
                                                               const UI32_T is_ile_hash,
                                                               CLX_CFG_TYPE_T *ptr_cfg_type);

typedef CLX_ERROR_NO_T (*HAL_CMN_SWC_GET_ILE_BANK_BITMAP_FUNC_T)(const UI32_T unit,
                                                                 const CLX_CFG_TYPE_T cfg_type,
                                                                 UI32_T *ptr_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_SWC_GET_HASH_TILE_BITMAP_FUNC_T)(
    const UI32_T unit,
    const CLX_SWC_HASH_TILE_TYPE_T hash_tile_type,
    HAL_SWC_HASH_TILE_BITMAP_T ptr_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_SWC_GET_TCAM_BITMAP_FUNC_T)(const UI32_T unit,
                                                             const CLX_SWC_TCAM_TYPE_T tcam_type,
                                                             HAL_SWC_TCAM_BITMAP_T ptr_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_SWC_SET_REASON_BLOOM_FILTER_FUNC_T)(
    const UI32_T unit,
    const CLX_SWC_REASON_BLOOM_FILTER_TYPE_T bloom_filter_type,
    const UI32_T bloom_filter_value);

typedef CLX_ERROR_NO_T (*HAL_CMN_SWC_GET_REASON_BLOOM_FILTER_FUNC_T)(
    const UI32_T unit,
    const CLX_SWC_REASON_BLOOM_FILTER_TYPE_T bloom_filter_type,
    UI32_T *bloom_filter_value);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_INIT_WARMBOOT_FUNC_T)(const UI32_T unit,
                                                           HAL_IO_WB_DB_T *ptr_db);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_DEINIT_WARMBOOT_FUNC_T)(const UI32_T unit,
                                                             HAL_IO_OBJ_META_T *ptr_wbdb_obj,
                                                             UI32_T *ptr_obj_count);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_INIT_CFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_INIT_RESOURCE_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_ALLOCATE_MAPPING_PROFILE_ENTRY_FUNC_T)(
    const UI32_T unit,
    const UI32_T profile_id,
    const CLX_QOS_MAPPING_TYPE_T mapping_type,
    const CLX_QOS_MAPPING_ENTRY_T *ptr_entry_array);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_FREE_MAPPING_PROFILE_ENTRY_FUNC_T)(
    const UI32_T unit,
    const UI32_T profile_id,
    const CLX_QOS_MAPPING_TYPE_T mapping_type,
    const CLX_QOS_MAPPING_ENTRY_T *ptr_entry_array);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_SET_MAPPING_PROFILE_ENTRY_FUNC_T)(
    const UI32_T unit,
    const UI32_T profile_id,
    const CLX_QOS_MAPPING_TYPE_T mapping_type,
    const CLX_QOS_MAPPING_ENTRY_T *ptr_entry_array);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_APPLYPROFILE_FUNC_T)(const UI32_T unit,
                                                          const HAL_QOS_INTF_TYPE_T intf_type,
                                                          const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                                          const UI32_T profile_id,
                                                          UI32_T *ptr_phb_prof_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_GETUSERPROFILEIDX_FUNC_T)(
    const UI32_T unit,
    const CLX_QOS_MAPPING_TYPE_T mapping_type,
    const UI32_T qos_prof_id,
    UI32_T *ptr_profile_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_ALLOCACLQOSPROFILE_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_QOS_ACTION_T acl_qos_action,
    UI32_T *ptr_profile_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_FREEACLQOSPROFILE_FUNC_T)(const UI32_T unit,
                                                               const UI32_T profileId);

typedef CLX_ERROR_NO_T (*HAL_CMN_QOS_GETACLQOSPROFILE_FUNC_T)(const UI32_T unit,
                                                              const UI32_T profile_id,
                                                              CLX_ACL_QOS_ACTION_T *ptr_qos_action);

typedef CLX_ERROR_NO_T (*HAL_CMN_EFUSE_READ_FUNC_T)(const UI32_T unit,
                                                    const HAL_CHIP_DIE_T die,
                                                    const HAL_EFUSE_GROUP_T group,
                                                    const UI32_T addr,
                                                    UI32_T *ptr_val);

typedef CLX_ERROR_NO_T (*HAL_CMN_EFUSE_DMAREAD_FUNC_T)(const UI32_T unit,
                                                       const HAL_CHIP_DIE_T die,
                                                       const HAL_EFUSE_GROUP_T group,
                                                       const UI32_T addr,
                                                       const UI32_T words,
                                                       UI32_T *ptr_buf); /* if ptr_buf is NULL, put
                                                                            data to EFS_MIR only */

typedef CLX_ERROR_NO_T (*HAL_CMN_EFUSE_READMIR_FUNC_T)(const UI32_T unit,
                                                       const HAL_CHIP_DIE_T die,
                                                       const HAL_EFUSE_GROUP_T group,
                                                       const UI32_T mir_idx,
                                                       UI32_T *ptr_val);

typedef CLX_ERROR_NO_T (*HAL_CMN_EFUSE_WRITE_FUNC_T)(const UI32_T unit,
                                                     const HAL_CHIP_DIE_T die,
                                                     const HAL_EFUSE_GROUP_T group,
                                                     const UI32_T addr,
                                                     const UI32_T bit_offset,
                                                     const UI32_T bit_len,
                                                     const UI32_T value);

typedef CLX_ERROR_NO_T (*HAL_CMN_EFUSE_DUMP_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_SFLOW_ALLOC_PROFILE_FUNC_T)(const UI32_T unit,
                                                             const HAL_SFLOW_SRC_TYPE_T src_type,
                                                             const HAL_SFLOW_DST_TYPE_T dst_type,
                                                             const UI32_T mir_session_id,
                                                             const UI32_T profile_id,
                                                             const UI32_T sampling_rate,
                                                             const BOOL_T sample_high_latency);

typedef CLX_ERROR_NO_T (*HAL_CMN_LAG_SRH_FDL_FUNC_T)(const UI32_T unit,
                                                     const UI32_T lag_id,
                                                     UI32_T *ptr_fdl_grp_idx);

typedef CLX_ERROR_NO_T (*HAL_CMN_LAG_ALLOC_FDL_FUNC_T)(const UI32_T unit,
                                                       const UI32_T lag_id,
                                                       UI32_T *ptr_fdl_grp_idx);

typedef CLX_ERROR_NO_T (*HAL_LAG_ENABEL_FDLGRP_BY_DI_FUNC_T)(const UI32_T unit,
                                                             const UI32_T member_di,
                                                             const UI32_T fdl_grp_idx,
                                                             const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_LAG_CLEAR_FDL_STATIC_FUNC_T)(const UI32_T unit,
                                                          const UI32_T ori_member_cnt,
                                                          const UI32_T *ptr_ori_member_di);

typedef CLX_ERROR_NO_T (*HAL_LAG_ENABLE_FDLGRP_FUNC_T)(const UI32_T unit,
                                                       const UI32_T lag_id,
                                                       const UI32_T fdl_grp_idx,
                                                       const UI32_T enable,
                                                       const CLX_FDL_INFO_T *ptr_fdl_info);

typedef CLX_ERROR_NO_T (*HAL_LAG_SYNC_MEMBER_FOR_FDL_FUNC_T)(const UI32_T unit,
                                                             const UI32_T lag_id,
                                                             const UI32_T fdl_grp_idx,
                                                             const UI32_T add_member_cnt,
                                                             const UI32_T *ptr_add_member_di,
                                                             const UI32_T del_member_cnt,
                                                             const UI32_T *ptr_del_member_di);

typedef CLX_ERROR_NO_T (*HAL_LAG_FREE_ORIACT_LIST_T)(const UI32_T unit,
                                                     const UI32_T lag_id,
                                                     HAL_LAG_INFO_T *ptr_lag_info);

typedef CLX_ERROR_NO_T (*HAL_LAG_ALLOC_ORIACT_LIST_T)(const UI32_T unit,
                                                      const UI32_T lagid,
                                                      HAL_LAG_INFO_T *ptr_lag_info);

typedef CLX_ERROR_NO_T (*HAL_LAG_SET_BACKEPOCMCPATH_T)(const UI32_T unit,
                                                       const UI32_T master_epoch,
                                                       const UI32_T backup_epoch,
                                                       const UI32_T orig_member_cnt,
                                                       const UI32_T *ptr_orig_member_di,
                                                       const UI32_T new_member_cnt_mod,
                                                       const UI32_T *ptr_new_member_di_mod,
                                                       const HAL_LAG_INFO_T *ptr_new_lag_info,
                                                       const UI32_T new_member_cnt,
                                                       const UI32_T *ptr_new_member_di,
                                                       const UI32_T del_member_cnt,
                                                       const UI32_T *ptr_del_member_di);

typedef CLX_ERROR_NO_T (*HAL_LAG_SET_UPDATEMASTEREPOCHMCPATH_T)(const UI32_T unit,
                                                                const UI32_T master_epoch,
                                                                const UI32_T backup_epoch);

typedef CLX_ERROR_NO_T (*HAL_LAG_SET_MEMBERPORTSI_T)(const UI32_T unit,
                                                     const UI32_T lag_di,
                                                     const UI32_T add_member_cnt,
                                                     const UI32_T *ptr_add_member_di,
                                                     const UI32_T del_member_cnt,
                                                     const UI32_T *ptr_del_member_di);

typedef CLX_ERROR_NO_T (*HAL_LAG_GET_INFO_T)(const UI32_T unit,
                                             const UI32_T lag_id,
                                             UI32_T *ptr_member_cnt,
                                             UI32_T *ptr_member_di,
                                             HAL_LAG_INFO_T *ptr_lag_info);

typedef CLX_ERROR_NO_T (*HAL_LAG_SET_INFO_T)(const UI32_T unit,
                                             const UI32_T lag_id,
                                             const HAL_LAG_INFO_T *ptr_lag_info);

typedef CLX_ERROR_NO_T (*HAL_LAG_GET_HASHPATH_T)(const UI32_T unit,
                                                 const CLX_SWC_HASH_TYPE_T hash_type,
                                                 const UI32_T lag_id,
                                                 CLX_LAG_HASHPATH_RSLT_INFO_T *ptr_rslt);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_ADD_LOCAL_SPAN_SESSION_FUNC_T)(
    const UI32_T unit,
    const UI32_T entry_id,
    const CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_ADD_RSPAN_SRC_SESSION_FUNC_T)(
    const UI32_T unit,
    const UI32_T entry_id,
    const CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_ADD_RSPAN_DST_SESSION_FUNC_T)(
    const UI32_T unit,
    const UI32_T entry_id,
    const CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_ADD_ERSPAN_SRC_SESSION_FUNC_T)(
    const UI32_T unit,
    const UI32_T entry_id,
    const CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_ADD_ERSPAN_DST_SESSION_FUNC_T)(
    const UI32_T unit,
    const UI32_T entry_id,
    const CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_DEL_LOCAL_SPAN_SESSION_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T entry_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_DEL_RSPAN_SRC_SESSION_FUNC_T)(const UI32_T unit,
                                                                   const UI32_T entry_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_DEL_RSPAN_DST_SESSION_FUNC_T)(const UI32_T unit,
                                                                   const UI32_T entry_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_DEL_ERSPAN_SRC_SESSION_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T entry_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_DEL_ERSPAN_DST_SESSION_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T entry_id);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_SET_RSPAN_DST_SESSION_FUNC_T)(
    const UI32_T unit,
    const UI32_T entry_id,
    const CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_SET_ERSPAN_SRC_SESSION_FUNC_T)(
    const UI32_T unit,
    const UI32_T entry_id,
    const CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_GET_LOCAL_SPAN_SESSION_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T entry_id,
                                                                    CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_GET_RSPAN_SRC_SESSION_FUNC_T)(const UI32_T unit,
                                                                   const UI32_T entry_id,
                                                                   CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_GET_RSPAN_DST_SESSION_FUNC_T)(const UI32_T unit,
                                                                   const UI32_T entry_id,
                                                                   CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_GET_ERSPAN_SRC_SESSION_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T entry_id,
                                                                    CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_GET_ERSPAN_DST_SESSION_FUNC_T)(const UI32_T unit,
                                                                    const UI32_T entry_id,
                                                                    CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_ADD_ERSPAN_TERM_FUNC_T)(
    const UI32_T unit,
    const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_DEL_ERSPAN_TERM_FUNC_T)(
    const UI32_T unit,
    const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_FIND_ERSPAN_TERM_FUNC_T)(
    const UI32_T unit,
    const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_search,
    HAL_MIR_ERSPAN_TERM_T **ptr_erspan_term);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_UPDATE_HW_LAG_MEMBER_FUNC_T)(const UI32_T unit,
                                                                  const UI32_T port,
                                                                  const UI32_T link,
                                                                  void *ptr_cookie);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_INIT_CFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_SET_HW_MIR_SRC_PORT_FUNC_T)(const UI32_T unit,
                                                                 const UI32_T port,
                                                                 const CLX_DIR_T dir,
                                                                 const UI32_T mir_session_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_GET_HW_MIR_SRC_PORT_FUNC_T)(const UI32_T unit,
                                                                 const UI32_T port,
                                                                 const CLX_DIR_T dir,
                                                                 UI32_T *ptr_mir_session_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_SET_HW_ERSPAN_TERM_MISS_ACTION_FUNC_T)(
    const UI32_T unit,
    const UI32_T miss_action);

typedef CLX_ERROR_NO_T (
    *HAL_CMN_MIR_GET_HW_ERSPAN_TERM_MISS_ACTION_FUNC_T)(const UI32_T unit, UI32_T *ptr_miss_action);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_UPDATE_HW_LAG_PORT_EVENT_FUNC_T)(const UI32_T unit,
                                                                      const UI32_T event,
                                                                      const CLX_PORT_T lag_port);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_SET_DESTINATION_FUNC_T)(const UI32_T unit,
                                                             const UI32_T entry_id,
                                                             const CLX_PORT_T port);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_CHECK_PARAMETER_FUNC_T)(const UI32_T unit,
                                                             const CLX_MIR_SESSION_T *ptr_session);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_SETSELECTIVEFLOWMIR_FUNC_T)(
    const UI32_T unit,
    const CLX_SWC_SELECTIVE_FLOW_CFG_T *ptr_select_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_MIR_GETSELECTIVEFLOWMIR_FUNC_T)(
    const UI32_T unit,
    CLX_SWC_SELECTIVE_FLOW_CFG_T *ptr_select_cfg);

typedef CLX_ERROR_NO_T (*HAL_CMN_SEC_INIT_CFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_SEC_GET_DOS_PORT_PROFILE_INFO_FUNC_T)(const UI32_T unit,
                                                                       const UI32_T port,
                                                                       UI32_T *ptr_profile_id,
                                                                       UI32_T *ptr_ref_cnt);

typedef CLX_ERROR_NO_T (*HAL_CMN_SEC_SET_STORM_CTRL_CTRLPKT_EN_FUNC_T)(const UI32_T unit,
                                                                       const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_SEC_GET_STORM_CTRL_CTRLPKT_EN_FUNC_T)(const UI32_T unit,
                                                                       UI32_T *ptr_enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_SEC_SET_STORM_CTRL_METER_LAYER_FUNC_T)(const UI32_T unit,
                                                                        const UI32_T layer_mode);

typedef CLX_ERROR_NO_T (*HAL_CMN_SEC_GET_STORM_CTRL_METER_LAYER_FUNC_T)(const UI32_T unit,
                                                                        UI32_T *ptr_layer_mode);

typedef CLX_ERROR_NO_T (*HAL_CMN_SEC_GET_PORT_ISOLATION_FUNC_T)(const UI32_T unit,
                                                                const UI32_T group,
                                                                CLX_PORT_BITMAP_T igr_port_bitmap,
                                                                CLX_PORT_BITMAP_T egr_port_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_STK_INITRSRC_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_STK_GETFABPORTBMP_FUNC_T)(const UI32_T unit,
                                                           UI32_T *ptr_pp_pbmp,
                                                           CLX_PORT_BITMAP_T cl_pbmp);

typedef CLX_ERROR_NO_T (*HAL_CMN_STK_CHECKFABPORT_FUNC_T)(const UI32_T unit,
                                                          const UI32_T port,
                                                          BOOL_T *ptr_is_fab);
typedef CLX_ERROR_NO_T (*HAL_CMN_STK_SETCPUDIPROPERTY_FUNC_T)(
    const UI32_T unit,
    const CLX_SWC_CPU_DI_PROPERTY_T property,
    const UI32_T value);
typedef CLX_ERROR_NO_T (*HAL_CMN_STK_GETCPUDIPROPERTY_FUNC_T)(
    const UI32_T unit,
    const CLX_SWC_CPU_DI_PROPERTY_T property,
    UI32_T *ptr_value);

typedef CLX_ERROR_NO_T (*HAL_CMN_STK_INITCFG_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_PORT_SETMXLINK_FUNC_T)(const UI32_T unit,
                                                        const UI32_T port,
                                                        const UI32_T enable);

typedef CLX_ERROR_NO_T (*HAL_CMN_PORT_GETMXLINK_FUNC_T)(const UI32_T unit,
                                                        const UI32_T port,
                                                        UI32_T *ptr_enable);
typedef CLX_ERROR_NO_T (*HAL_CMN_PORT_GETINITPORTBITMAP_FUNC_T)(const UI32_T unit,
                                                                CLX_PORT_BITMAP_T *ptr_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PORT_UPDATEPORTBITMAP_FUNC_T)(const UI32_T unit,
                                                               CLX_PORT_BITMAP_T port_bitmap);

typedef CLX_ERROR_NO_T (*HAL_CMN_PORT_UPDATEINTFTAGMODE_FUNC_T)(const UI32_T unit,
                                                                const UI32_T plane_id,
                                                                const UI32_T lcl_intf,
                                                                const UI32_T tag_mode);

typedef CLX_ERROR_NO_T (*HAL_CMN_PORT_GETCAPACITY_FUNC_T)(const UI32_T unit,
                                                          const CLX_SWC_RSRC_T type,
                                                          const UI32_T param,
                                                          UI32_T *ptr_size);

typedef CLX_ERROR_NO_T (*HAL_CMN_PORT_GETUSAGE_FUNC_T)(const UI32_T unit,
                                                       const CLX_SWC_RSRC_T type,
                                                       const UI32_T param,
                                                       UI32_T *ptr_cnt);

typedef CLX_ERROR_NO_T (*HAL_CMN_CPU2JTAG_INIT_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_CPU2JTAG_TOGGLE_TRST_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_CMN_CPU2JTAG_CHECK_IR_FUNC_T)(const UI32_T unit,
                                                           const C8_T *ir_val,
                                                           const UI32_T ir_len);

typedef CLX_ERROR_NO_T (*HAL_CMN_CPU2JTAG_CHECK_DR_FUNC_T)(const UI32_T unit,
                                                           const C8_T *dr_val,
                                                           const UI32_T dr_len,
                                                           const C8_T *exp_dr_val,
                                                           const UI32_T exp_dr_len);

typedef struct {
    HAL_CMN_VLAN_SETKEEPDEI_FUNC_T hal_vlan_setKeepDei;
    HAL_CMN_VLAN_GETKEEPDEI_FUNC_T hal_vlan_getKeepDei;
} HAL_CMN_VLAN_FUNC_VEC_T;

typedef struct {
    HAL_CMN_L2_REPLACEADDRDI_FUNC_T hal_l2_replaceAddrDi;
    HAL_CMN_L2_GETPHYMCID_FUNC_T hal_l2_getPhyMcId;
    HAL_CMN_L2_GETUNCOMPRESSPHYMCID_FUNC_T hal_l2_getUncompressPhyMcId;
    HAL_CMN_L2_TRANSBUMLOGICALMCIDTOPHYID_FUNC_T hal_l2_transBumLogicalMcIdToPhyId;
    HAL_CMN_L2_GETBUMUNCOMPRESSPHYMCID_FUNC_T hal_l2_getBumUncompressPhyMcId;
    HAL_CMN_L2_SETBUMENTRYLOGICALMCID_FUNC_T hal_l2_setBumEntryLogicalMcId;
    HAL_CMN_L2_GETBUMENTRYLOGICALMCID_FUNC_T hal_l2_getBumEntryLogicalMcId;
    HAL_CMN_L2_ADDBUMENTRYIDXTOAVL_FUNC_T hal_l2_addBumEntryIdxToAvl;
    HAL_CMN_L2_DELBUMENTRYIDXTOAVL_FUNC_T hal_l2_delBumEntryIdxFromAvl;
    HAL_CMN_L2_TRANSUNCOMPRESSPHYMCIDTOLOGICALID_FUNC_T hal_l2_transUncompressPhyMcIdToLogicalId;
} HAL_CMN_L2_FUNC_VEC_T;

typedef struct {
    HAL_CMN_IFMON_LOCKDATA_FUNC_T hal_ifmon_lockData;
    HAL_CMN_IFMON_UNLOCKDATA_FUNC_T hal_ifmon_unlockData;
    HAL_CMN_IFMON_LOCKFLOW_FUNC_T hal_ifmon_lockFlow;
    HAL_CMN_IFMON_UNLOCKFLOW_FUNC_T hal_ifmon_unlockFlow;
    HAL_CMN_IFMON_GETLINK_FUNC_T hal_ifmon_getLink;
    HAL_CMN_IFMON_GETFAULT_FUNC_T hal_ifmon_getFault;
    HAL_CMN_IFMON_GETSPEED_FUNC_T hal_ifmon_getSpeed;
    HAL_CMN_IFMON_ADDMOCLORT_FUNC_T hal_ifmon_addMonPort;
    HAL_CMN_IFMON_DELMOCLORT_FUNC_T hal_ifmon_delMonPort;
    HAL_CMN_IFMON_ADDMOCLORT_FUNC_T hal_ifmon_addMonAnlt;
    HAL_CMN_IFMON_DELMOCLORT_FUNC_T hal_ifmon_delMonAnlt;
    HAL_CMN_IFMON_RECORDTIME_FUNC_T hal_ifmon_recordTime;
    HAL_CMN_IFMON_UPDATESWSTATE_FUNC_T hal_ifmon_updateSwState;
    HAL_CMN_IFMON_DUMPLINKSTATE_FUNC_T hal_ifmon_dumpLinkState;
} HAL_CMN_IFMON_FUNC_VEC_T;

typedef struct {
    HAL_CMN_TM_SETPMSTATE_FUNC_T hal_tm_pol_setPmState;
    HAL_CMN_TM_SETPMSPEED_FUNC_T hal_tm_setPmSpeed;
    HAL_CMN_TM_POL_SETPROPERTY_FUNC_T hal_tm_pol_setProperty;
    HAL_CMN_TM_POL_GETEPMBUFFEREMPTY_FUNC_T hal_tm_pol_getEpmBufferEmpty;
    HAL_CMN_TM_GETTSRXENTRY_FUNC_T hal_tm_getTsRxEntry;
    HAL_CMN_TM_SETTSRXSTATE_FUNC_T hal_tm_setTsRxState;
    HAL_CMN_TM_UPDATETSRXLATENCY_FUNC_T hal_tm_updateTsRxLatency;
    HAL_CMN_TM_RESETEPMBUFFER_FUNC_T hal_tm_resetEpmBuffer;
    HAL_CMN_TM_GETLANENUM_FUNC_T hal_tm_pol_getLaneNum;
    HAL_CMN_TM_SETSTATE_FUNC_T hal_tm_setState;
    HAL_CMN_TM_SETSPEED_FUNC_T hal_tm_setSpeed;
    HAL_CMN_TM_SETSTEERING_ENABLE_FUNC_T hal_tm_setSteeringEnable;
    HAL_CMN_TM_GETSTEERING_ENABLE_FUNC_T hal_tm_getSteeringEnable;
    HAL_CMN_TM_SETSTEERING_FUNC_T hal_tm_setSteering;
    HAL_CMN_TM_GETSTEERING_FUNC_T hal_tm_getSteering;
    HAL_CMN_TM_CONFIGTDM_FUNC_T hal_tm_configTdm;
    HAL_CMN_TM_UPDATEPORTTDM_FUNC_T hal_tm_updatePortTdm;
    HAL_CMN_TM_SETSTACKINGPORT_FUNC_T hal_tm_setStackingPort;
    HAL_CMN_TM_UPDATEPORTSTATUS_FUNC_T hal_tm_updatePortStatus;
    HAL_CMN_TM_SETFLOWCTRLMODE_FUNC_T hal_tm_setFlowCtrlMode;
    HAL_CMN_TM_GETAOPEMPTY_FUNC_T hal_tm_getAopEmpty;
    HAL_CMN_TM_SCH_SETPORTEEE_FUNC_T hal_tm_sch_setPortEee;
    HAL_CMN_TM_SCH_GETPORTEEE_FUNC_T hal_tm_sch_getPortEee;
    HAL_CMN_TM_SETCUTTHROUGH_FUNC_T hal_tm_setCutThrough;
    HAL_CMN_TM_SETPORTLANECNT_FUNC_T hal_tm_setPortLaneCnt;
    HAL_CMN_TM_POL_GETLBSEMPTY_FUNC_T hal_tm_pol_getLbsEmpty;
    HAL_CMN_TM_DEINITPORTFLOW_FUNC_T hal_tm_deinitPortFlow;
    HAL_CMN_TM_SCH_FLUSHQUEUE_FUNC_T hal_tm_sch_flushQueue;
    HAL_CMN_TM_POL_SETIOSFLUSH_FUNC_T hal_tm_pol_setIosFlush;
    HAL_CMN_TM_CHECKHEALTHMON_FUNC_T hal_tm_checkHealthMon;
    HAL_CMN_TM_POL_SETDROPERROR_FUNC_T hal_tm_pol_setDropError;
    HAL_CMN_TM_DUMPREGPORTSTATE_FUNC_T hal_tm_dumpRegPortState;
    HAL_CMN_TM_SETTRUNCATIONPROFILE_FUNC_T hal_tm_setTruncationProfile;
    HAL_CMN_TM_GETTRUNCATIONPROFILE_FUNC_T hal_tm_getTruncationProfile;
    HAL_CMN_TM_SETTRUNCATION_FUNC_T hal_tm_setTruncation;
    HAL_CMN_TM_GETTRUNCATION_FUNC_T hal_tm_getTruncation;
    HAL_CMN_TM_SETCPA_FUNC_T hal_tm_setCpa;
    HAL_CMN_TM_GETCPA_FUNC_T hal_tm_getCpa;
    HAL_CMN_TM_TCB_SETCAPTUREKEY hal_tm_tcb_setCaptureKey;
    HAL_CMN_TM_TCB_GETCAPTUREKEY hal_tm_tcb_getCaptureKey;
    HAL_CMN_TM_TCB_GETCAPTUREDATA hal_tm_tcb_getCaptureData;
    HAL_CMN_TM_TCB_START hal_tm_tcb_start;
    HAL_CMN_TM_TCB_CLEAR hal_tm_tcb_clear;
    HAL_CMN_TM_ELAM_SETTRIGGERKEY hal_tm_elam_setTriggerKey;
    HAL_CMN_TM_ELAM_GETTRIGGERKEY hal_tm_elam_getTriggerKey;
    HAL_CMN_TM_ELAM_SETTRIGGERCONFIG hal_tm_elam_setTriggerConfig;
    HAL_CMN_TM_ELAM_GETTRIGGERCONFIG hal_tm_elam_getTriggerConfig;
    HAL_CMN_TM_ELAM_GETCAPTUREDATA hal_tm_elam_getCaptureData;
    HAL_CMN_TM_ELAM_START hal_tm_elam_start;
    HAL_CMN_TM_ELAM_CLEAR hal_tm_elam_clear;
    HAL_CMN_TM_BUF_SETDEFAULT hal_tm_buf_setDefault;
    HAL_CMN_TM_PFCWD_STATEDISABLEEVENTHANDLER_FUNC_T hal_tm_PfcWdStateDisableEventHandler;
    HAL_CMN_TM_PFCWD_STATECFGNOTRDYEVENTHANDLER_FUNC_T hal_tm_PfcWdStateCfgNotRdyEventHandler;
    HAL_CMN_TM_PFCWD_PFCWDSTATEOPERATIONALEVENTHANDLER_FUNC_T
    hal_tm_PfcWdStateOperationalEventHandler;
    HAL_CMN_TM_PFCWD_PFCWDSTATESTORMEDEVENTHANDLER_FUNC_T hal_tm_PfcWdStateStormedEventHandler;
} HAL_CMN_TM_FUNC_VEC_T;

typedef struct {
    /* start from dtel.c file */
    HAL_CMN_DTEL_GETPORTPROPERTY_FUNC_T hal_dtel_getPortProperty;
    HAL_CMN_DTEL_SETPORTPROPERTY_FUNC_T hal_dtel_setPortProperty;
    HAL_CMN_DTEL_GETPROPERTY_FUNC_T hal_dtel_getProperty;
    HAL_CMN_DTEL_SETPROPERTY_FUNC_T hal_dtel_setProperty;
} HAL_CMN_DTEL_FUNC_VEC_T;

typedef struct {
    /* start from dtel.c file */
    HAL_CMN_TELM_GETPORTPROPERTY_FUNC_T hal_telm_getPortProperty;
    HAL_CMN_TELM_SETPORTPROPERTY_FUNC_T hal_telm_setPortProperty;
    HAL_CMN_TELM_GETPROPERTY_FUNC_T hal_telm_getProperty;
    HAL_CMN_TELM_SETPROPERTY_FUNC_T hal_telm_setProperty;
} HAL_CMN_TELM_FUNC_VEC_T;

typedef struct {
    HAL_CMN_MPLS_SETSKIPMPLS_FUNC_T hal_mpls_setSkipMpls;
    HAL_CMN_MPLS_GETSKIPMPLS_FUNC_T hal_mpls_getSkipMpls;
    HAL_CMN_MPLS_SETDELMPLS_FUNC_T hal_mpls_setDelMpls;
    HAL_CMN_MPLS_GETDELMPLS_FUNC_T hal_mpls_getDelMpls;
    HAL_CMN_MPLS_INITCFG_FUNC_T hal_mpls_initCfg;
    HAL_CMN_MPLS_DEINITCFG_FUNC_T hal_mpls_deinitCfg;
    HAL_CMN_MPLS_INITWARM_FUNC_T hal_mpls_initWarm;
    HAL_CMN_MPLS_DEINITWARM_FUNC_T hal_mpls_deinitWarm;
    HAL_CMN_MPLS_GETPATHINFO_FUNC_T hal_mpls_getPathInfo;
    HAL_CMN_MPLS_GETPORTBYPATHINFO_FUNC_T hal_mpls_getPortByPathInfo;
    HAL_CMN_MPLS_UPDATEVPWSLAGMEMBER_FUNC_T hal_mpls_updateVpwsLagMember;
} HAL_CMN_MPLS_FUNC_VEC_T;

typedef struct {
    HAL_CMN_STAT_GETTMCNT_FUNC_T hal_stat_getTmCnt;
    HAL_CMN_STAT_CLEARTMCNT_FUNC_T hal_stat_clearTmCnt;
    HAL_CMN_STAT_GETTMQUEUECNTIDX_FUNC_T hal_stat_getTmQueueCntIdx;
    HAL_CMN_STAT_GETRSERRDISTCNT hal_stat_getRsErrDistCnt;
    HAL_CMN_STAT_CLEARRSERRDISTCNT hal_stat_clearRsErrDistCnt;
    HAL_CMN_STAT_SETRSERRDISTCNTINTERVAL hal_stat_setRsErrDistCntInterval;
    HAL_CMN_STAT_GETPORTRATETYPE_FUNC_T hal_stat_getPortRateType;
} HAL_CMN_STAT_FUNC_VEC_T;

typedef struct {
    /* HAL INTF dispatcher */
    HAL_CMN_L3_FDID2INTF_FUNC_T hal_l3_fdid2intf;
    HAL_CMN_L3_INTF2FDID_FUNC_T hal_l3_intf2fdid;
    /* HAL VRF dispatcher */
    HAL_CMN_L3_SETGLOBALROUTEMISSACTION_FUNC_T hal_l3_setGlobalRouteMissAction;
    HAL_CMN_L3_GETGLOBALROUTEMISSACTION_FUNC_T hal_l3_getGlobalRouteMissAction;
    /* HAL HOST dispatcher */
    HAL_CMN_L3_GETHOSTIDX_FUNC_T hal_l3_getHostIdx;
    /* HAL ADJ and ECMP dispatcher */
    HAL_CMN_L3_GETADJINFO_FUNC_T hal_l3_getAdjInfo;
    HAL_CMN_L3_GETECMPINFO_FUNC_T hal_l3_getEcmpInfo;
    HAL_CMN_L3_UPDATEADJUSENUM_FUNC_T hal_l3_updateAdjUseNum;
    HAL_CMN_L3_UPDATEECMPGRPUSENUM_FUNC_T hal_l3_updateEcmpGrpUseNum;
    HAL_CMN_L3_GETPATHIDXBYGRPADJID_FUNC_T hal_l3_getPathIdxByGrpAdjId;
    HAL_CMN_L3_SETECMPBLOCKSIZE_FUNC_T hal_l3_setEcmpBlockSize;
    HAL_CMN_L3_GETECMPBLOCKSIZE_FUNC_T hal_l3_getEcmpBlockSize;
    HAL_CMN_L3_SETECMPRESILIENT_FUNC_T hal_l3_setEcmpResilient;
    HAL_CMN_L3_GETECMPRESILIENT_FUNC_T hal_l3_getEcmpResilient;
    HAL_CMN_L3_SETECMPALGOMODE_FUNC_T hal_l3_setEcmpAlgoMode;
    HAL_CMN_L3_GETECMPALGOMODE_FUNC_T hal_l3_getEcmpAlgoMode;
    HAL_CMN_L3_SETECMPGRPMAXMBRNUM_FUNC_T hal_l3_setEcmpGrpMaxMbrNum;
    HAL_CMN_L3_GETECMPGRPMAXMBRNUM_FUNC_T hal_l3_getEcmpGrpMaxMbrNum;
    HAL_CMN_L3_ACLBINDECMPGRP_FUNC_T hal_l3_aclBindEcmpGrp;
    HAL_CMN_L3_ACLUNBINDECMPGRP_FUNC_T hal_l3_aclUnbindEcmpGrp;
    /* HAL ROUTE dispatcher */
    HAL_CMN_L3_ADDFCOETCAMENTRY_FUNC_T hal_l3_addFcoeTcamEntry;
    HAL_CMN_L3_DELFCOETCAMENTRY_FUNC_T hal_l3_delFcoeTcamEntry;
    HAL_CMN_L3_GETFCOETCAMENTRY_FUNC_T hal_l3_getFcoeTcamEntry;
    /* HAL MCAST dispatcher */
    HAL_CMN_L3_DELMEMBERALL_FUNC_T hal_l3_delMemberAll;
    HAL_CMN_L3_ADDMELSUBENTRYBYPORT_FUNC_T hal_l3_addMelSubEntryByPort;
    HAL_CMN_L3_DELMELSUBENTRYBYPORT_FUNC_T hal_l3_delMelSubEntryByPort;
    HAL_CMN_L3_GETMELSUBENTRYBYPORT_FUNC_T hal_l3_getMelSubEntryByPort;
    HAL_CMN_L3_GETMELSUBENTRYNUMBYPORT_FUNC_T hal_l3_getMelSubEntryNumByPort;
    /* HAL CAPACITY and USAGE dispatcher */
    HAL_CMN_L3_GETCAPACITY_FUNC_T hal_l3_getCapacity;
    HAL_CMN_L3_GETUSAGE_FUNC_T hal_l3_getUsage;
    HAL_CMN_L3_GETICMPREDIRECT_FUNC_T hal_l3_getIcmpRedirect;
    HAL_CMN_L3_SETICMPREDIRECT_FUNC_T hal_l3_setIcmpRedirect;
    HAL_CMN_L3_GETSELFFORWARD_FUNC_T hal_l3_getSelfForward;
    HAL_CMN_L3_SETSELFFORWARD_FUNC_T hal_l3_setSelfForward;
    HAL_CMN_L3_GETURPFCHECK_FUNC_T hal_l3_getUrpfCheck;
    HAL_CMN_L3_SETURPFCHECK_FUNC_T hal_l3_setUrpfCheck;
    HAL_CMN_L3_GETVALIDATEIP_FUNC_T hal_l3_getValidateIp;
    HAL_CMN_L3_SETVALIDATEIP_FUNC_T hal_l3_setValidateIp;
    HAL_CMN_L3_GETL3EXCPTACT_FUNC_T hal_l3_getL3ExcptAct;
    HAL_CMN_L3_SETL3EXCPTACT_FUNC_T hal_l3_setL3ExcptAct;
    HAL_CMN_L3_GETL3HDRERRACT_FUNC_T hal_l3_getL3HdrErrAct;
    HAL_CMN_L3_SETL3HDRERRACT_FUNC_T hal_l3_setL3HdrErrAct;
    HAL_CMN_L3_ALLOCFPU_FUNC_T hal_l3_allocFpu;
    HAL_CMN_L3_GETFPU_FUNC_T hal_l3_getFpu;
    /* L2 ECMP dispatcher */
    HAL_CMN_L3_CREATEL2GRP_FUNC_T hal_l3_createL2Grp;
    HAL_CMN_L3_SETL2GRP_FUNC_T hal_l3_setL2Grp;
    HAL_CMN_L3_DELL2GRP_FUNC_T hal_l3_delL2Grp;
    HAL_CMN_L3_GETL2GRP_FUNC_T hal_l3_getL2Grp;
    HAL_CMN_L3_ADDL2GRPPATH_FUNC_T hal_l3_addL2GrpPath;
    HAL_CMN_L3_DELL2GRPPATH_FUNC_T hal_l3_delL2GrpPath;
    HAL_CMN_L3_GETL2GRPPATHBYIDX_FUNC_T hal_l3_getL2GrpPathByidx;
    HAL_CMN_L3_SETL2GRPPATHHSH_FUNC_T hal_l3_setL2GrpPathHsh;
    HAL_CMN_L3_GETL2GRPPATHHSH_FUNC_T hal_l3_getL2GrpPathHsh;
    HAL_CMN_L3_DUMPL2PATHLIST_FUNC_T hal_l3_dumpL2PathList;
    HAL_CMN_L3_SETL2CPUDI_FUNC_T hal_l3_setL3CpuDi;
} HAL_CMN_L3_FUNC_VEC_T;

typedef struct {
    HAL_CMN_L3T_CFGFLEXTNLGTP_FUNC_T hal_l3t_cfgFlexTnlGtp;
    HAL_CMN_L3T_CFGFLEXTNLPIM_FUNC_T hal_l3t_cfgFlexTnlPim;
    HAL_CMN_L3T_CFGFLEXTNLGENEVE_FUNC_T hal_l3t_cfgFlexTnlGeneve;
    HAL_CMN_L3T_CFGFLEXTNLUSERDEFINED_FUNC_T hal_l3t_cfgFlexTnlUserDefined;
    HAL_CMN_L3T_INITCFG_FUNC_T hal_l3t_initCfg;
    HAL_CMN_L3T_SETEXCPTACT_FUNC_T hal_l3t_setExcptAct;
    HAL_CMN_L3T_GETEXCPTACT_FUNC_T hal_l3t_getExcptAct;
    HAL_CMN_L3T_TRAVTNL2LIST hal_l3t_travTnl2List;
    HAL_CMN_L3T_CFGECMPPATHBYNVO3ADJINFO hal_l3t_cfgEcmpPathByNvo3AdjInfo;
    HAL_CMN_L3T_TRANSNVO3ADJTOECMPPATH hal_l3t_transNvo3AdjToEcmpPath;
    HAL_CMN_L3T_ALLOCIPSAIDX hal_l3t_allocIpSaIdx;
    HAL_CMN_L3T_FREEIPSAIDX hal_l3t_freeIpSaIdx;
    HAL_CMN_L3T_ALLOCIPDAIDX hal_l3t_allocIpDaIdx;
    HAL_CMN_L3T_FREEIPDAIDX hal_l3t_freeIpDaIdx;
    HAL_CMN_L3T_ALLOCDSTTEPIDX hal_l3t_allocDstTepIdx;
    HAL_CMN_L3T_FREEDSTTEPIDX hal_l3t_freeDstTepIdx;
    HAL_CMN_L3T_SETTNLPSREN hal_l3t_setTnlPsrEn;
    HAL_CMN_L3T_GETTNLPSREN hal_l3t_getTnlPsrEn;
} HAL_CMN_L3T_FUNC_VEC_T;

typedef struct {
    HAL_CMN_NV_INITCFG_FUNC_T hal_nv_initCfg;
    HAL_CMN_NV_SETVXLANRACHECK_FUNC_T hal_nv_setVxlanRouterAlertCheck;
    HAL_CMN_NV_GETVXLANRACHECK_FUNC_T hal_nv_getVxlanRouterAlertCheck;
    HAL_CMN_NV_SETNVGRERACHECK_FUNC_T hal_nv_setNvgreRouterAlertCheck;
    HAL_CMN_NV_GETNVGRERACHECK_FUNC_T hal_nv_getNvgreRouterAlertCheck;
    HAL_CMN_NV_SETVXLANUDPPORT_FUNC_T hal_nv_setVxlanUdpPort;
    HAL_CMN_NV_GETVXLANUDPPORT_FUNC_T hal_nv_getVxlanUdpPort;
} HAL_CMN_NV_FUNC_VEC_T;

typedef struct {
    HAL_CMN_SRV6_INITCFG_FUNC_T hal_srv6_initCfg;
    HAL_CMN_SRV6_INITWARM_FUNC_T hal_srv6_initWarm;
    HAL_CMN_SRV6_DEINITWARM_FUNC_T hal_srv6_deinitWarm;
    HAL_CMN_SRV6_CFGEGRLCLINTF_FUNC_T hal_srv6_cfgEgrLclIntf;
    HAL_CMN_SRV6_CFGIGRLCLINTF_FUNC_T hal_srv6_cfgIgrLclIntf;
} HAL_CMN_SRV6_FUNC_VEC_T;

typedef struct {
    HAL_CMN_PKT_MAPIPPEXCPTCODETOUSER_FUNC_T hal_pkt_mapIppExcptCodeToUser;
    HAL_CMN_PKT_MAPIPPRSNCODETOUSER_FUNC_T hal_pkt_mapIppRsnCodeToUser;
    HAL_CMN_PKT_MAPEPPEXCPTCODETOUSER_FUNC_T hal_pkt_mapEppExcptCodeToUser;
    HAL_CMN_PKT_MAPIPPEXCPTTOUSER_FUNC_T hal_pkt_mapIppExcptToUser;
    HAL_CMN_PKT_MAPIPPL3EXCPTTOUSER_FUNC_T hal_pkt_mapIppL3ExcptToUser;
    HAL_CMN_PKT_MAPIPPCOPYTOCPUTOUSER_FUNC_T hal_pkt_mapIppCopyToCpuToUser;
    HAL_CMN_PKT_MAPIPPRSNTOUSER_FUNC_T hal_pkt_mapIppRsnToUser;
    HAL_CMN_PKT_MAPEPPEXCPTTOUSER_FUNC_T hal_pkt_mapEppExcptToUser;
    HAL_CMN_PKT_MAPEPPCOPYTOCPUTOUSER_FUNC_T hal_pkt_mapEppCopyToCpuToUser;
    HAL_CMN_PKT_MAPUSERTOIPPEXCPT_FUNC_T hal_pkt_mapUserToIppExcpt;
    HAL_CMN_PKT_MAPUSERTOIPPL3EXCPT_FUNC_T hal_pkt_mapUserToIppL3Excpt;
    HAL_CMN_PKT_MAPUSERTOIPPCOPYTOCPU_FUNC_T hal_pkt_mapUserToIppCopyToCpu;
    HAL_CMN_PKT_MAPUSERTOIPPRSN_FUNC_T hal_pkt_mapUserToIppRsn;
    HAL_CMN_PKT_MAPUSERTOEPPEXCPT_FUNC_T hal_pkt_mapUserToEppExcpt;
    HAL_CMN_PKT_MAPUSERTOEPPCOPYTOCPU_FUNC_T hal_pkt_mapUserToEppCopyToCpu;
    HAL_CMN_PKT_TRANSUSERTOHWREASON_FUNC_T hal_pkt_transUserToHwReason;
    HAL_CMN_PKT_TRANSHWTOUSERREASON_FUNC_T hal_pkt_transHwToUserReason;
    HAL_CMN_PKT_INITREASONMAP_FUNC_T hal_pkt_initReasonMap;
} HAL_CMN_PKT_FUNC_VEC_T;

typedef struct {
    HAL_CMN_ACL_INITEGRUCPRSRC_FUNC_T hal_acl_initEgrUcpRsrc;
    HAL_CMN_ACL_INITEGRUCPWARMRSRC_FUNC_T hal_acl_initEgrUcpWarmRsrc;
    HAL_CMN_ACL_DEINITEGRUCPRSRC_FUNC_T hal_acl_deinitEgrUcpRsrc;
    HAL_CMN_ACL_DEINITEGRUCPWARMRSRC_FUNC_T hal_acl_deinitEgrUcpWarmRsrc;
    HAL_CMN_ACL_SETACTIVEUCP_FUNC_T hal_acl_setActiveUcp;
    HAL_CMN_ACL_FLIPEGRUCP_FUNC_T hal_acl_flipEgrUcp;
    HAL_CMN_ACL_SETUCPCFG_FUNC_T hal_acl_setUcpCfg;
    HAL_CMN_ACL_SETUCPPBMEN_FUNC_T hal_acl_setUcpPbmEn;
    HAL_CMN_ACL_ADDHWENTRY_FUNC_T hal_acl_addHwEntry;
    HAL_CMN_ACL_SETHWENTRYVLD_FUNC_T hal_acl_setHwEntryVld;
    HAL_CMN_ACL_READHWENTRY_FUNC_T hal_acl_readHwEntry;
    HAL_CMN_ACL_DELHWENTRY_FUNC_T hal_acl_delHwEntry;
    HAL_CMN_ACL_CLEARCONTHWENTRY_FUNC_T hal_acl_clearContHwEntry;
    HAL_CMN_ACL_MOVEHWENTRY_FUNC_T hal_acl_moveHwEntry;
    HAL_CMN_ACL_CHECKGROUP_FUNC_T hal_acl_checkGroup;
    HAL_CMN_ACL_ADDGROUP_FUNC_T hal_acl_addGroup;
    HAL_CMN_ACL_SETGROUP_FUNC_T hal_acl_setGroup;
    HAL_CMN_ACL_FREEENTRYALLOCRSRC_FUNC_T hal_acl_freeEntryAllocRsrc;
    HAL_CMN_ACL_RESETUCP_FUNC_T hal_acl_resetUcp;
    HAL_CMN_ACL_GETGROUPPROFILE_FUNC_T hal_acl_getGroupProfile;
    HAL_CMN_ACL_GETUCPPBMEN_FUNC_T hal_acl_getUcpPbmEn;
    HAL_CMN_ACL_SETACLPKGPROF_FUNC_T hal_acl_setAclPkgProf;
    HAL_CMN_ACL_SETFLWPKGPROF_FUNC_T hal_acl_setFlwPkgProf;
    HAL_CMN_ACL_SETPKGLOUPROFIDX_FUNC_T hal_acl_setPkgLouProfIdx;
    HAL_CMN_ACL_SETTCAMPKGLOU_FUNC_T hal_acl_setTcamPkgLou;
    HAL_CMN_ACL_GETACLPKGPROF_FUNC_T hal_acl_getAclPkgProf;
    HAL_CMN_ACL_GETFLWPKGPROF_FUNC_T hal_acl_getFlwPkgProf;
    HAL_CMN_ACL_GETPKGLOUPROFIDX_FUNC_T hal_acl_getPkgLouProfIdx;
    HAL_CMN_ACL_GETPKTFORMAT_FUNC_T hal_acl_getPktFormat;
    HAL_CMN_ACL_GETLOUPROF_FUNC_T hal_acl_getLouProf;
    HAL_CMN_ACL_SETLOUPROF_FUNC_T hal_acl_setLouProf;
    HAL_CMN_ACL_GETACLPKGPROFLOUINFO_FUNC_T hal_acl_getAclPkgProfLouInfo;
    HAL_CMN_ACL_GETFLWPKGPROFLOUINFO_FUNC_T hal_acl_getFlwPkgProfLouInfo;
    HAL_CMN_ACL_SETACLPKGPROFLOUEN_FUNC_T hal_acl_setAclPkgProfLouEn;
    HAL_CMN_ACL_SETFLWPKGPROFLOUEN_FUNC_T hal_acl_setFlwPkgProfLouEn;
    HAL_CMN_ACL_GETFLWUDFKEYINFO_FUNC_T hal_acl_getFlwUdfKeyInfo;
    HAL_CMN_ACL_GETUDFKEYINFO_FUNC_T hal_acl_getUdfKeyInfo;
    HAL_CMN_ACL_GETFREEUCPPBM_FUNC_T hal_acl_getFreeUcpPbm;
    HAL_CMN_ACL_ADDUCPTOGROUP_FUNC_T hal_acl_addUcpToGroup;
    HAL_CMN_ACL_ENABLEGROUP_FUNC_T hal_acl_enableGroup;
    HAL_CMN_ACL_GETFLOWENTRY_FUNC_T hal_acl_getFlowEntry;
    HAL_CMN_ACL_UNPACKENTRY_FUNC_T hal_acl_unpackEntry;
    HAL_CMN_ACL_UPDATEECMPINFO_FUNC_T hal_acl_updateEcmpInfo;
    HAL_CMN_ACL_UPDATEADJINFO_FUNC_T hal_acl_updateAdjInfo;
    HAL_CMN_ACL_SETUCPPRIO_FUNC_T hal_acl_setUcpPrio;
    HAL_CMN_ACL_INITCFG_FUNC_T hal_acl_initCfg;
    HAL_CMN_ACL_GETFLOWENTRYIDINFO_FUNC_T hal_acl_getFlowEntryIdInfo;
    HAL_CMN_ACL_CHECKFLOWPREEMPTENTRY_FUNC_T hal_acl_checkFlowPreemptEntry;
    HAL_CMN_ACL_FREEFLOWPREEMPTENTRY_FUNC_T hal_acl_freeFlowPreemptEntry;
    HAL_CMN_ACL_DELFLOWENTRY_FUNC_T hal_acl_delFlowEntry;
    HAL_CMN_ACL_GETFLOWGROUPENTRYCAPUSAGE_FUNC_T hal_acl_getFlowGroupEntryCapUsage;
    HAL_CMN_ACL_SETTAPPINGTPID_FUNC_T hal_acl_setTappingTpid;
    HAL_CMN_ACL_GETTAPPINGTPID_FUNC_T hal_acl_getTappingTpid;
    HAL_CMN_ACL_RIM_ALLOC_FCM_IDX_FUNC_T hal_acl_rim_alloc_fcm_idx;
    HAL_CMN_ACL_RIM_FREE_FCM_IDX_FUNC_T hal_acl_rim_free_fcm_idx;
    HAL_CMN_ACL_RIM_SETFCMACTION_FUNC_T hal_acl_rim_setFcmAction;
    HAL_CMN_ACL_RIM_GETFCMACTION_FUNC_T hal_acl_rim_getFcmAction;
    HAL_CMN_ACL_RIM_TRAVFCMACTION_FUNC_T hal_acl_rim_travFcmAction;
    HAL_CMN_ACL_RIM_ALLOC_REDIR_IDX_FUNC_T hal_acl_rim_alloc_redir_idx;
    HAL_CMN_ACL_RIM_FREE_REDIR_IDX_FUNC_T hal_acl_rim_free_redir_idx;
    HAL_CMN_ACL_RIM_SET_REDIR_IDX_FUNC_T hal_acl_rim_set_redir_idx;
    HAL_CMN_ACL_RIM_GET_REDIR_IDX_FUNC_T hal_acl_rim_get_redir_idx;
    HAL_CMN_ACL_RIM_TRAV_REDIR_IDX_FUNC_T hal_acl_rim_trav_redir_idx;
    HAL_CMN_ACL_ALLOCENTRYID_FUNC_T hal_acl_allocEntryId;
    HAL_CMN_ACL_GETSWENTRYINFO_FUNC_T hal_acl_getSwEntryInfo;
} HAL_CMN_ACL_FUNC_VEC_T;

typedef struct {
    HAL_CMN_METER_INIT_CFG_T hal_meter_initCfg;
    HAL_CMN_METER_SET_METER_CFG_REG_T hal_meter_setMeterCfgReg;
    HAL_CMN_METER_TRANS_METER_HWIDX_T hal_meter_transMeterHwIdx;
    HAL_CMN_METER_TRANS_METER_INDEX_T hal_meter_transMeterIndex;
    HAL_CMN_METER_SET_METER_POOL_T hal_meter_setMeterPool;
    HAL_CMN_METER_SET_IGR_PORT_METER_T hal_meter_setIgrPortMeter;
    HAL_CMN_METER_GET_IGR_PORT_METER_T hal_meter_getIgrPortMeter;
    HAL_CMN_METER_ALLOC_CNT_MTR_PROF_T hal_meter_allocCntMtrProf;
    HAL_CMN_METER_FREE_CNT_MTR_PROF_T hal_meter_freeCntMtrProf;
    HAL_CMN_METER_SET_CNT_MTR_PROF_T hal_meter_setCntMtrProf;
    HAL_CMN_METER_GET_CNT_MTR_PROF_T hal_meter_getCntMtrProf;
    HAL_CMN_METER_CHECK_CNT_MTR_PROF_T hal_meter_checkCntMtrProf;
} HAL_CMN_METER_FUNC_VEC_T;

typedef struct {
    HAL_CMN_SFLOW_SET_IGR_CFG_SFLW_MIR_FUNC_T hal_sflow_setIgrCfgSflwMir;
    HAL_CMN_SFLOW_GET_IGR_CFG_SFLW_MIR_FUNC_T hal_sflow_getIgrCfgSflwMir;
    HAL_CMN_SFLOW_SET_EGR_CFG_SFLW_MIR_FUNC_T hal_sflow_setEgrCfgSflwMir;
    HAL_CMN_SFLOW_GET_EGR_CFG_SFLW_MIR_FUNC_T hal_sflow_getEgrCfgSflwMir;
    HAL_CMN_SFLOW_SET_IGR_CFG_SFLW_FUNC_T hal_sflow_setIgrCfgSflw;
    HAL_CMN_SFLOW_GET_IGR_CFG_SFLW_FUNC_T hal_sflow_getIgrCfgSflw;
    HAL_CMN_SFLOW_SET_EGR_CFG_SFLW_FUNC_T hal_sflow_setEgrCfgSflw;
    HAL_CMN_SFLOW_GET_EGR_CFG_SFLW_FUNC_T hal_sflow_getEgrCfgSflw;
    HAL_CMN_SFLOW_SET_HIGH_LATENCY_CFG_FUNC_T hal_sflow_setHighLatencyCfg;
    HAL_CMN_SFLOW_SET_CFG_IOAM_FLW_LBL_FUNC_T hal_sflow_setCfgIoamFlwLbl;
    HAL_CMN_SFLOW_INIT_CFG_FUNC_T hal_sflow_initCfg;
    HAL_CMN_SFLOW_ALLOC_PROFILE_FUNC_T hal_sflow_allocProfile;
} HAL_CMN_SFLOW_FUNC_VEC_T;

typedef struct {
    HAL_CMN_MIR_ADD_LOCAL_SPAN_SESSION_FUNC_T hal_mir_addLocalSpanSession;
    HAL_CMN_MIR_ADD_RSPAN_SRC_SESSION_FUNC_T hal_mir_addRspanSrcSession;
    HAL_CMN_MIR_ADD_RSPAN_DST_SESSION_FUNC_T hal_mir_addRspanDstSession;
    HAL_CMN_MIR_ADD_ERSPAN_SRC_SESSION_FUNC_T hal_mir_addErspanSrcSession;
    HAL_CMN_MIR_ADD_ERSPAN_DST_SESSION_FUNC_T hal_mir_addErspanDstSession;
    HAL_CMN_MIR_DEL_LOCAL_SPAN_SESSION_FUNC_T hal_mir_delLocalSpanSession;
    HAL_CMN_MIR_DEL_RSPAN_SRC_SESSION_FUNC_T hal_mir_delRspanSrcSession;
    HAL_CMN_MIR_DEL_RSPAN_DST_SESSION_FUNC_T hal_mir_delRspanDstSession;
    HAL_CMN_MIR_DEL_ERSPAN_SRC_SESSION_FUNC_T hal_mir_delErspanSrcSession;
    HAL_CMN_MIR_DEL_ERSPAN_DST_SESSION_FUNC_T hal_mir_delErspanDstSession;
    HAL_CMN_MIR_SET_RSPAN_DST_SESSION_FUNC_T hal_mir_setRspanDstSession;
    HAL_CMN_MIR_SET_ERSPAN_SRC_SESSION_FUNC_T hal_mir_setErspanSrcSession;
    HAL_CMN_MIR_GET_LOCAL_SPAN_SESSION_FUNC_T hal_mir_getLocalSpanSession;
    HAL_CMN_MIR_GET_RSPAN_SRC_SESSION_FUNC_T hal_mir_getRspanSrcSession;
    HAL_CMN_MIR_GET_RSPAN_DST_SESSION_FUNC_T hal_mir_getRspanDstSession;
    HAL_CMN_MIR_GET_ERSPAN_SRC_SESSION_FUNC_T hal_mir_getErspanSrcSession;
    HAL_CMN_MIR_GET_ERSPAN_DST_SESSION_FUNC_T hal_mir_getErspanDstSession;
    HAL_CMN_MIR_ADD_ERSPAN_TERM_FUNC_T hal_mir_addErspanTerm;
    HAL_CMN_MIR_DEL_ERSPAN_TERM_FUNC_T hal_mir_delErspanTerm;
    HAL_CMN_MIR_FIND_ERSPAN_TERM_FUNC_T hal_mir_findErspanTerm;
    HAL_CMN_MIR_UPDATE_HW_LAG_MEMBER_FUNC_T hal_mir_updateHwLagMember;
    HAL_CMN_MIR_INIT_CFG_FUNC_T hal_mir_initCfg;
    HAL_CMN_MIR_SET_HW_MIR_SRC_PORT_FUNC_T hal_mir_setHwMirSrcPort;
    HAL_CMN_MIR_GET_HW_MIR_SRC_PORT_FUNC_T hal_mir_getHwMirSrcPort;
    HAL_CMN_MIR_SET_HW_ERSPAN_TERM_MISS_ACTION_FUNC_T hal_mir_setHwErspanTermMissAction;
    HAL_CMN_MIR_GET_HW_ERSPAN_TERM_MISS_ACTION_FUNC_T hal_mir_getHwErspanTermMissAction;
    HAL_CMN_MIR_UPDATE_HW_LAG_PORT_EVENT_FUNC_T hal_mir_updateHwLagPortEvent;
    HAL_CMN_MIR_SET_DESTINATION_FUNC_T hal_mir_setDestination;
    HAL_CMN_MIR_CHECK_PARAMETER_FUNC_T hal_mir_checkParameter;
    HAL_CMN_MIR_SETSELECTIVEFLOWMIR_FUNC_T hal_mir_setSelectiveFlowMir;
    HAL_CMN_MIR_GETSELECTIVEFLOWMIR_FUNC_T hal_mir_getSelectiveFlowMir;
} HAL_CMN_MIR_FUNC_VEC_T;

typedef struct {
    HAL_CMN_LAG_INIT_CFG_FUNC_T hal_lag_initCfg;
    HAL_CMN_LAG_SRH_FDL_FUNC_T hal_lag_searchFdl;
    HAL_CMN_LAG_ALLOC_FDL_FUNC_T hal_lag_allocateFdl;
    HAL_LAG_ENABEL_FDLGRP_BY_DI_FUNC_T hal_lag_enableFdlGroupByDi;
    HAL_LAG_CLEAR_FDL_STATIC_FUNC_T hal_lag_clearFdlStatic;
    HAL_LAG_ENABLE_FDLGRP_FUNC_T hal_lag_enableFdlGroup;
    HAL_LAG_SYNC_MEMBER_FOR_FDL_FUNC_T hal_lag_syncMemberForFdl;
    HAL_LAG_FREE_ORIACT_LIST_T hal_lag_freeOriActList;
    HAL_LAG_ALLOC_ORIACT_LIST_T hal_lag_allocOriActList;
    HAL_LAG_SET_BACKEPOCMCPATH_T hal_lag_setBackupEpochMcPath;
    HAL_LAG_SET_UPDATEMASTEREPOCHMCPATH_T hal_lag_updateMasterEpochMcPath;
    HAL_LAG_SET_MEMBERPORTSI_T hal_lag_setMemberPortSi;
    HAL_LAG_GET_INFO_T hal_lag_getInfo;
    HAL_LAG_SET_INFO_T hal_lag_setInfo;
    HAL_LAG_GET_HASHPATH_T hal_lag_getHashPath;
} HAL_CMN_LAG_FUNC_VEC_T;

typedef struct {
    HAL_CMN_SWC_INIT_CFG_FUNC_T hal_swc_initCfg;
    HAL_CMN_SWC_GET_ILE_BANK_TYPE_FUNC_T hal_swc_getIleBankType;
    HAL_CMN_SWC_GET_ILE_BANK_BITMAP_FUNC_T hal_swc_getIleBankBitmap;
    HAL_CMN_SWC_GET_HASH_TILE_BITMAP_FUNC_T hal_swc_getHashTileBitmap;
    HAL_CMN_SWC_GET_TCAM_BITMAP_FUNC_T hal_swc_getTcamBitmap;
    HAL_CMN_SWC_SET_REASON_BLOOM_FILTER_FUNC_T hal_swc_setReasonBloomFilter;
    HAL_CMN_SWC_GET_REASON_BLOOM_FILTER_FUNC_T hal_swc_getReasonBloomFilter;
} HAL_CMN_SWC_FUNC_VEC_T;

typedef struct {
    HAL_CMN_SEC_INIT_CFG_FUNC_T hal_sec_initCfg;
    HAL_CMN_SEC_GET_DOS_PORT_PROFILE_INFO_FUNC_T hal_sec_getDosPortProfileInfo;
    HAL_CMN_SEC_SET_STORM_CTRL_CTRLPKT_EN_FUNC_T hal_sec_setStormCtrlCtrlPktEn;
    HAL_CMN_SEC_GET_STORM_CTRL_CTRLPKT_EN_FUNC_T hal_sec_getStormCtrlCtrlPktEn;
    HAL_CMN_SEC_SET_STORM_CTRL_METER_LAYER_FUNC_T hal_sec_setStormCtrlMeterLayer;
    HAL_CMN_SEC_GET_STORM_CTRL_METER_LAYER_FUNC_T hal_sec_getStormCtrlMeterLayer;
    HAL_CMN_SEC_GET_PORT_ISOLATION_FUNC_T hal_sec_getPortIsolation;
} HAL_CMN_SEC_FUNC_VEC_T;

typedef struct {
    HAL_CMN_QOS_INIT_WARMBOOT_FUNC_T hal_qos_initWarmboot;
    HAL_CMN_QOS_DEINIT_WARMBOOT_FUNC_T hal_qos_deinitWarmboot;
    HAL_CMN_QOS_INIT_CFG_FUNC_T hal_qos_initCfg;
    HAL_CMN_QOS_INIT_RESOURCE_FUNC_T hal_qos_initResource;
    HAL_CMN_QOS_ALLOCATE_MAPPING_PROFILE_ENTRY_FUNC_T hal_qos_allocateMappingProfileEntry;
    HAL_CMN_QOS_FREE_MAPPING_PROFILE_ENTRY_FUNC_T hal_qos_freeMappingProfileEntry;
    HAL_CMN_QOS_SET_MAPPING_PROFILE_ENTRY_FUNC_T hal_qos_setMappingProfileEntry;
    HAL_CMN_QOS_APPLYPROFILE_FUNC_T hal_qos_applyProfile;
    HAL_CMN_QOS_GETUSERPROFILEIDX_FUNC_T hal_qos_getUserProfileIdx;
    HAL_CMN_QOS_ALLOCACLQOSPROFILE_FUNC_T hal_qos_allocAclQosProfile;
    HAL_CMN_QOS_FREEACLQOSPROFILE_FUNC_T hal_qos_freeAclQosProfile;
    HAL_CMN_QOS_GETACLQOSPROFILE_FUNC_T hal_qos_getAclQosProfile;
} HAL_CMN_QOS_FUNC_VEC_T;

typedef struct {
    HAL_CMN_EFUSE_READ_FUNC_T hal_efuse_read;
    HAL_CMN_EFUSE_DMAREAD_FUNC_T hal_efuse_dmaRead;
    HAL_CMN_EFUSE_READMIR_FUNC_T hal_efuse_readMir;
    HAL_CMN_EFUSE_WRITE_FUNC_T hal_efuse_write;
    HAL_CMN_EFUSE_DUMP_FUNC_T hal_efuse_dump;
} HAL_CMN_EFUSE_FUNC_VEC_T;

typedef struct {
    HAL_CMN_STK_INITRSRC_FUNC_T hal_stk_initRsrc;
    HAL_CMN_STK_INITCFG_FUNC_T hal_stk_initCfg;
    HAL_CMN_STK_GETFABPORTBMP_FUNC_T hal_stk_getFabPortBmp;
    HAL_CMN_STK_CHECKFABPORT_FUNC_T hal_stk_checkFabPort;
    HAL_CMN_STK_SETCPUDIPROPERTY_FUNC_T hal_stk_setCpuDiProperty;
    HAL_CMN_STK_GETCPUDIPROPERTY_FUNC_T hal_stk_getCpuDiProperty;
} HAL_CMN_STK_FUNC_VEC_T;

typedef struct {
    HAL_CMN_PORT_SETMXLINK_FUNC_T hal_port_setMxLink;
    HAL_CMN_PORT_GETMXLINK_FUNC_T hal_port_getMxLink;
    HAL_CMN_PORT_GETINITPORTBITMAP_FUNC_T hal_port_getInitPortBitmap;
    HAL_CMN_PORT_UPDATEPORTBITMAP_FUNC_T hal_port_updatePortBitmap;
    HAL_CMN_PORT_UPDATEINTFTAGMODE_FUNC_T hal_port_updateIntfTagMode;
    HAL_CMN_PORT_GETCAPACITY_FUNC_T hal_port_getCapacity;
    HAL_CMN_PORT_GETUSAGE_FUNC_T hal_port_getUsage;
} HAL_CMN_PORT_FUNC_VEC_T;
typedef struct {
    HAL_CMN_INIT_FUNC_T hal_cmn_init;
    HAL_CMN_DEINIT_FUNC_T hal_cmn_deinit;

    HAL_CMN_ADDNVO3ROUTE_FUNC_T hal_cmn_addNvo3Route;
    HAL_CMN_DELNVO3ROUTE_FUNC_T hal_cmn_delNvo3Route;

    HAL_CMN_ADDIEVL3RTENODE_FUNC_T hal_cmn_addIevL3RteNode;
    HAL_CMN_DELIEVL3RTENODE_FUNC_T hal_cmn_delIevL3RteNode;
    HAL_CMN_GETIEVL3RTENODE_FUNC_T hal_cmn_getIevL3RteNode;

    HAL_CMN_SAVEIEVL3RTENODES_FUNC_T hal_cmn_saveIevL3RteNodes;
    HAL_CMN_RESTOREIEVL3RTENODES_FUNC_T hal_cmn_restoreIevL3RteNodes;

    HAL_CMN_GETENCAPIDXFROMPORT_FUNC_T hal_cmn_getEncapIdxFromPort;
    HAL_CMN_GETPORTFROMENCAPIDX_FUNC_T hal_cmn_getPortFromEncapIdx;
} HAL_CMN_CMN_FUNC_VEC_T;

typedef struct {
    HAL_CMN_CPU2JTAG_INIT_FUNC_T hal_cpu2jtag_init;
    HAL_CMN_CPU2JTAG_TOGGLE_TRST_FUNC_T hal_cpu2jtag_toggleTrst;
    HAL_CMN_CPU2JTAG_CHECK_IR_FUNC_T hal_cpu2jtag_checkIr;
    HAL_CMN_CPU2JTAG_CHECK_DR_FUNC_T hal_cpu2jtag_checkDr;
} HAL_CMN_CPU2JTAG_FUNC_VEC_T;

typedef struct {
    /* vlan multiplexing functions */
    HAL_CMN_VLAN_FUNC_VEC_T *const vlan_cmn_func_vec;
    /* l2 multiplexing functions */
    HAL_CMN_L2_FUNC_VEC_T *const l2_cmn_func_vec;
    /* ifmon multiplexing functions */
    HAL_CMN_IFMON_FUNC_VEC_T *const ifmon_cmn_func_vec;
    /* tm multiplexing functions */
    HAL_CMN_TM_FUNC_VEC_T *const tm_cmn_func_vec;
    /* MPLS multiplexing functions */
    HAL_CMN_MPLS_FUNC_VEC_T *const mpls_cmn_func_vec;
    /* stat multiplexing functions */
    HAL_CMN_STAT_FUNC_VEC_T *const stat_cmn_func_vec;
    /* l3 multiplexing functions */
    HAL_CMN_L3_FUNC_VEC_T *const l3_cmn_func_vec;
    /* l3t multiplexing functions */
    HAL_CMN_L3T_FUNC_VEC_T *const l3t_cmn_func_vec;
    /* nv multiplexing functions */
    HAL_CMN_NV_FUNC_VEC_T *const nv_cmn_func_vec;
    /* srv6 multiplexing functions */
    HAL_CMN_SRV6_FUNC_VEC_T *const srv6_cmn_func_vec;
    /* pkt multiplexing functions */
    HAL_CMN_PKT_FUNC_VEC_T *const pkt_cmn_func_vec;
    /* dtel multiplexing functions */
    HAL_CMN_DTEL_FUNC_VEC_T *const dtel_cmn_func_vec;
    /* telm multiplexing functions */
    HAL_CMN_TELM_FUNC_VEC_T *const telm_cmn_func_vec;
    /* acl multiplexing functions */
    HAL_CMN_ACL_FUNC_VEC_T *const acl_cmn_func_vec;
    /* meter multiplexing functions */
    HAL_CMN_METER_FUNC_VEC_T *const meter_cmn_func_vec;
    /* sflow multiplexing functions */
    HAL_CMN_SFLOW_FUNC_VEC_T *const sflow_cmn_func_vec;
    /* mir multiplexing functions */
    HAL_CMN_MIR_FUNC_VEC_T *const mir_cmn_func_vec;
    /* lag multiplexing functions */
    HAL_CMN_LAG_FUNC_VEC_T *const lag_cmn_func_vec;
    /* swc multiplexing functions */
    HAL_CMN_SWC_FUNC_VEC_T *const swc_cmn_func_vec;
    /* sec multiplexing functions */
    HAL_CMN_SEC_FUNC_VEC_T *const sec_cmn_func_vec;
    /* qos multiplexing functions*/
    HAL_CMN_QOS_FUNC_VEC_T *const qos_cmn_func_vec;
    /* stk multiplexing functions*/
    HAL_CMN_STK_FUNC_VEC_T *const stk_cmn_func_vec;
    /* efuse multiplexing functions */
    HAL_CMN_EFUSE_FUNC_VEC_T *const efuse_cmn_func_vec;
    /* port multiplexing functions*/
    HAL_CMN_PORT_FUNC_VEC_T *const port_cmn_func_vec;
    /* common functions */
    HAL_CMN_CMN_FUNC_VEC_T *const cmn_cmn_func_vec;
    /* cpu2jtag multiplexing functions */
    HAL_CMN_CPU2JTAG_FUNC_VEC_T *const cpu2jtag_cmn_func_vec;

} HAL_CMN_FUNC_VEC_T;
#endif /* #ifndef HAL_CMN_DRV_H */
