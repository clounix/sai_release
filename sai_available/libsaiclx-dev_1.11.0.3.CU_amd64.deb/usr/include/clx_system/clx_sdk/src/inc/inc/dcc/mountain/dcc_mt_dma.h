/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  dcc_mt_dma.h
 * PURPOSE:
 *  1. Provide the access interfaces of DMA and CLD DMA to chip Device Control Command(DCC_MT).
 *  2. Define DCC_MT DMA and CLD DMA related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_MT_DMA_H
#define DCC_MT_DMA_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <dcc/dcc_dma.h>
#include <dcc/mountain/dcc_mt.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define DCC_MT_DMA_WORD_LENGTH            (4)                      /* words, means 4 bytes */
#define DCC_MT_DMA_DFLT_RING_SIZE         (2)                      /* default ring size */
#define DCC_MT_DMA_DFLT_CLD_DMA_RING_SIZE (512)                    /* default CLD DMA ring size */
#define DCC_MT_DMA_DFLT_OP_MODE           (DCC_MT_CH_OP_MODE_POLL) /* defalut operation mode */
#ifdef NB_EMU_DEV
#define DCC_MT_DMA_DFLT_MAX_TIMEOUT_CNT (3000000000)
#else
#define DCC_MT_DMA_DFLT_MAX_TIMEOUT_CNT (1000000)
#endif
#define DCC_MT_DMA_MAX_RETRY_NUM (100)

#define DCC_MT_DMA_DFLT_CLD_THREAD_STACK (32 * 1024)
#define DCC_MT_DMA_DFLT_CLD_THREAD_PRI   (80)
#define DCC_MT_DMA_DFLT_CLD_SLEEP_PERIOD (3000000)

/* Alignment to 16-bytes */
#if defined(CLX_EN_HOST_64_BIT_BIG_ENDIAN) || defined(CLX_EN_HOST_64_BIT_LITTLE_ENDIAN)
#define DCC_DMA_ALIGN_ADDR(dma_addr, align_sz) (((dma_addr) + (align_sz)) & 0xFFFFFFFFFFFFFFF0)
#else
#define DCC_DMA_ALIGN_ADDR(dma_addr, align_sz) (((dma_addr) + (align_sz)) & 0xFFFFFFF0)
#endif

#define DCC_DMA_GET_BIT(flags, bit) (((flags) & (bit)) > 0 ? 1 : 0) /* bit get */
#define DCC_DMA_SET_BIT(flags, bit) ((flags) |= (bit))              /* bit set */
#define DCC_DMA_CLR_BIT(flags, bit) ((flags) &= ~(bit))             /* bit clear */

/********************DMA register************************************/
// TODO:use auto gen reg instead of hard coding
#define DCC_MT_DMA_BASE_ADDR            (0x51C1400)
#define DCC_MT_DMA_GET_MMIO(__offset__) (DCC_MT_DMA_BASE_ADDR + (__offset__))

#define DCC_MT_DMA_CFG_CH_ENABLE     (0x4)
#define DCC_MT_DMA_CFG_DESC_LOCATION (0x8)
#define DCC_MT_DMA_CFG_DESC_ENDIAN   (0xC)
#define DCC_MT_DMA_CFG_DATA_ENDIAN   (0x10)
#define DCC_MT_DMA_CFG_CRC_EN        (0x48)
// #define DCC_MT_DMA_CFG_RESET                               (0xA0)
#define DCC_MT_DMA_CTL_NORMAL_INTR_MASK           (0xA4)
#define DCC_MT_DMA_CFW_NORMAL_INTR_CLR            (0xA8)
#define DCC_MT_DMA_STA_NORMAL_INTR                (0xB4)
#define DCC_MT_DMA_CFG_CH0_RING_BASE              (0xB8)
#define DCC_MT_DMA_CFG_CH0_RING_SIZE              (0x158)
#define DCC_MT_DMA_CFG_CH0_DESC_WORK_IDX          (0x1A8)
#define DCC_MT_DMA_STA_CH0_DESC_POP_IDX           (0x1F8)
#define DCC_MT_DMA_CFG_CH0_MODE                   (0x248)
#define DCC_MT_DMA_CFW_GLOBAL_RESET               (0x348)
#define DCC_MT_DMA_CFW_CHANNEL_RESET              (0x34C)
#define DCC_MT_DMA_CFW_CHANNEL_RESTART            (0x350)
#define DCC_MT_CFG_PDMA2PCIE_INTR_MASK_ALL        (0xD20)
#define DCC_MT_DMA_CFG_PDMA2PCIE_INTR_CH0_MASK    (0xD24)
#define DCC_MT_DMA_IRQ_PDMA_ABNORMAL_CH0_INTR     (0xD6C)
#define DCC_MT_DMA_IRQ_PDMA_ABNORMAL_CH0_INTR_MSK (0xD70)
#define DCC_MT_DMA_IRQ_PDMA_ABNORMAL_CH0_INTR_TST (0xD74)

#define DCC_MT_GET_DMA_CH_RING_BASE_REG(__channel__) \
    (DCC_MT_DMA_CFG_CH0_RING_BASE + (0x8 * (__channel__)))
#define DCC_MT_GET_DMA_CH_RING_SIZE_REG(__channel__) \
    (DCC_MT_DMA_CFG_CH0_RING_SIZE + (0x4 * (__channel__)))
#define DCC_MT_GET_DMA_CH_DESC_WORK_IDX_REG(__channel__) \
    (DCC_MT_DMA_CFG_CH0_DESC_WORK_IDX + (0x4 * (__channel__)))
#define DCC_MT_GET_DMA_CH_DESC_POP_IDX_REG(__channel__) \
    (DCC_MT_DMA_STA_CH0_DESC_POP_IDX + (0x4 * (__channel__)))
#define DCC_MT_GET_DMA_CH_MODE(__channel__) (DCC_MT_DMA_CFG_CH0_MODE + (0x4 * (__channel__)))
/********************DMA register end************************************/

/*
 * descriptor
    63---------------47-----------------------------------------------0
    |       size     |                  s_addr                        |
    |      [63:48]   |                  [47:0]                        |
0x8  ----------------|------------------------------------------------|
    |      status    |                  d_addr                        |
    |      [63:48]   |                  [47:0]                        |
0x10 ----------------|------------------------------------------------|

*/
#if defined(CLX_EN_LITTLE_ENDIAN)
typedef struct {
    UI32_T s_addr_lo : 32;
    UI32_T s_addr_hi : 16;
    UI32_T size : 16;
    UI32_T d_addr_lo : 32;
    UI32_T d_addr_hi : 16;

    /*status[127:112]*/
    UI32_T interrupt : 1;
    UI32_T err : 1;
    UI32_T eop : 1;
    UI32_T sop : 1;
    UI32_T sinc : 1;
    UI32_T dinc : 1;
    UI32_T xfer_size : 5;
    UI32_T reserve : 5;

} DCC_MT_DMA_DESC_T;
#elif defined(CLX_EN_BIG_ENDIAN)
typedef struct {
    /*status[127:112]*/
    UI32_T reserve : 5;
    UI32_T xfer_size : 5;
    UI32_T dinc : 1;
    UI32_T sinc : 1;
    UI32_T sop : 1;
    UI32_T eop : 1;
    UI32_T err : 1;
    UI32_T interrupt : 1;

    UI32_T d_addr_lo : 32;
    UI32_T d_addr_hi : 16;
    UI32_T size : 16;
    UI32_T s_addr_lo : 32;
    UI32_T s_addr_hi : 16;

} DCC_MT_DMA_DESC_T;
#else
#error "Host DMA endian is not defined\n"
#endif

typedef enum {
    MT_DMA_HOSTMEM_TO_HOSTMEM = 0,
    MT_DMA_DEVICE_TO_HOSTMEM = 1,
    MT_DMA_HOSTMEM_TO_DEVICE = 2,
    MT_DMA_DEVICE_TO_DEVICE = 3,
} DCC_MT_DMA_CH_MODE;

typedef enum {
    DCC_MT_DMA_CH_RX0 = 0,
    DCC_MT_DMA_CH_RX1 = 1,
    DCC_MT_DMA_CH_RX2 = 2,
    DCC_MT_DMA_CH_RX3 = 3,
    DCC_MT_DMA_CH_TX0 = 4,
    DCC_MT_DMA_CH_TX1 = 5,
    DCC_MT_DMA_CH_TX2 = 6,
    DCC_MT_DMA_CH_TX3 = 7,
    DCC_MT_DMA_CH_RSRV0 = 8,
    DCC_MT_DMA_CH_DTOH = 9,
    DCC_MT_DMA_CH_HTOD = 10,
    DCC_MT_DMA_CH_DTOD = 11,
    DCC_MT_DMA_CH_RSRV1 = 12,
    DCC_MT_DMA_CH_RSRV2 = 13,
    DCC_MT_DMA_CH_CLD = 14,
    DCC_MT_DMA_CH_RSRV3 = 15,
    DCC_MT_DMA_CH_ECPU_RX = 16,
    DCC_MT_DMA_CH_ECPU_TX = 17,
    DCC_MT_DMA_CH_L2_FIFO = 18,
    DCC_MT_DMA_CH_IOAM_FIFO = 19,

    DCC_MT_DMA_CH_LAST
} DCC_MT_DMA_CHANNEL_T;

typedef struct {
    CLX_SEMAPHORE_ID_T sema;      /* mutually exclusive access the same table */
    CLX_SEMAPHORE_ID_T sync_sema; /* intr sync */
    CLX_THREAD_ID_T task_id;
    UI32_T task_sleep_intvl;
    DCC_MT_CH_OP_MODE_T op_mode;
    UI32_T timeout_cnt;

    UI32_T work_idx;
    UI32_T pop_idx;
    UI32_T ring_size;
    DCC_MT_DMA_CH_MODE ch_mode;

    volatile DCC_MT_DMA_DESC_T *ring_base;
    volatile DCC_MT_DMA_DESC_T *ring_base_align;
    BOOL_T err_flag;
} DCC_MT_DMA_CH_CB_T;

CLX_ERROR_NO_T
dcc_dma_ch_set_work_idx(const UI32_T unit,
                        const DCC_MT_DMA_CHANNEL_T channel,
                        const UI32_T work_idx);
UI32_T
dcc_dma_ch_get_work_idx(const UI32_T unit, const DCC_MT_DMA_CHANNEL_T channel);
UI32_T
dcc_dma_ch_get_pop_idx(const UI32_T unit, const DCC_MT_DMA_CHANNEL_T channel);
BOOL_T
dcc_dma_ch_get_enable_status(const UI32_T unit, const DCC_MT_DMA_CHANNEL_T channel);
CLX_ERROR_NO_T
dcc_dma_ch_enable(const UI32_T unit, const DCC_MT_DMA_CHANNEL_T channel);
CLX_ERROR_NO_T
dcc_dma_ch_disable(const UI32_T unit, const DCC_MT_DMA_CHANNEL_T channel);
CLX_ERROR_NO_T
dcc_dma_ch_set_ring_base(const UI32_T unit,
                         const DCC_MT_DMA_CHANNEL_T channel,
                         const CLX_ADDR_T ring_base_phy);
CLX_ERROR_NO_T
dcc_dma_ch_get_ring_base(const UI32_T unit,
                         const DCC_MT_DMA_CHANNEL_T channel,
                         const CLX_ADDR_T *ring_base_phy);
CLX_ERROR_NO_T
dcc_dma_ch_reset(const UI32_T unit, const DCC_MT_DMA_CHANNEL_T channel);
BOOL_T
dcc_dma_ch_get_channel_reset_status(const UI32_T unit, const DCC_MT_DMA_CHANNEL_T channel);
CLX_ERROR_NO_T
dcc_dma_ch_set_ring_size(const UI32_T unit,
                         const DCC_MT_DMA_CHANNEL_T channel,
                         const UI32_T ring_size);
CLX_ERROR_NO_T
dcc_dma_ch_set_mode(const UI32_T unit, const DCC_MT_DMA_CHANNEL_T channel, const UI32_T mode);

CLX_ERROR_NO_T
dcc_mt_dma_initDmaRsrc(const UI32_T unit);

CLX_ERROR_NO_T
dcc_mt_dma_initDmaIntr(const UI32_T unit);

CLX_ERROR_NO_T
dcc_mt_dma_deinitDmaRsrc(const UI32_T unit);

CLX_ERROR_NO_T
dcc_mt_dma_initDmaThread(const UI32_T unit);

#define DCC_MT_INIT_CLD_TASK(task, inst_idx_in, subinst_idx_in, table_id_in, entry_idx_in, \
                             addr_in, ptr_buf_in, entry_len_in, entry_num_in, d_to_h_in,   \
                             callback_in, op_mode_in)                                      \
    do {                                                                                   \
        (task).inst_idx = (inst_idx_in);                                                   \
        (task).subinst_idx = (subinst_idx_in);                                             \
        (task).table_id = (table_id_in);                                                   \
        (task).entry_idx = (entry_idx_in);                                                 \
        (task).addr = (addr_in);                                                           \
        (task).ptr_buf = (ptr_buf_in);                                                     \
        (task).entry_len = (entry_len_in);                                                 \
        (task).entry_num = (entry_num_in);                                                 \
        (task).d_to_h = (d_to_h_in);                                                       \
        (task).callback = (callback_in);                                                   \
        (task).op_mode = (op_mode_in);                                                     \
    } while (0)

/**
 * @brief dcc_mt_dma_deinitDmaThread() is responsible for thread of DCC_MT DMA deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_MT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_mt_dma_deinitDmaThread(const UI32_T unit);

/**
 * @brief dcc_mt_dma_showDmaChannelInfo() is a function to display DCC_MT DMA channel information.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     channel    - The logic channel.
 */
void
dcc_mt_dma_showDmaChannelInfo(const UI32_T unit, const UI32_T channel);

/**
 * @brief dcc_mt_dma_writeIndEntry() is a function to move table entry which is indirect access from
 * host to device.
 *
 * To use this function to access indirect table, we need set indirect command first.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_src_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred
 * @param [in]     entry_num      - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully write data from host to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to write data from host to device
 */
CLX_ERROR_NO_T
dcc_mt_dma_writeIndEntry(const UI32_T unit,
                         void *ptr_src_buf,
                         const UI32_T addr,
                         const UI32_T entry_len,
                         const UI32_T entry_num);

/**
 * @brief dcc_mt_dma_readTbl() is a function to move table entry which is indirect access  from
 * device to host.
 *
 * To use this function to access indirect table, we need set indirect command first.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_dst_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred
 * @param [in]     entry_num      - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully read data from device to host
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to host
 */
CLX_ERROR_NO_T
dcc_mt_dma_readIndEntry(const UI32_T unit,
                        void *ptr_dst_buf,
                        const UI32_T addr,
                        const UI32_T entry_len,
                        const UI32_T entry_num);

/**
 * @brief dcc_mt_dma_copyIndEntry() is a function to move table entry from device to device.
 *
 * @param [in]     unit         - The specified unit number.
 * @param [in]     src_addr     - The start address of source device table address for DMA transfer.
 * This address should be a valid address inside chip.
 * @param [in]     dst_addr     - The start address of destination device table address for DMA
 * transfer.
 * @param [in]     entry_len    - The length of an entry is going to be transferred
 * @param [in]     entry_num    - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully write data from host to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to write data from host to device
 */
CLX_ERROR_NO_T
dcc_mt_dma_copyIndEntry(const UI32_T unit,
                        const UI32_T src_addr,
                        const UI32_T dst_addr,
                        const UI32_T entry_len,
                        const UI32_T entry_num);

/**
 * @brief dcc_mt_dma_writeEntry() is a function to move table entry from host to device.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_src_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred
 * @param [in]     entry_num      - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully write data from host to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to write data from host to device
 */
CLX_ERROR_NO_T
dcc_mt_dma_writeEntry(const UI32_T unit,
                      void *ptr_src_buf,
                      const UI32_T addr,
                      const UI32_T entry_len,
                      const UI32_T entry_num);

/**
 * @brief dcc_mt_dma_readEntry() is a function to move table data from device to host.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_dst_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred
 * @param [in]     entry_num      - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully read data from device to host
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to host
 */
CLX_ERROR_NO_T
dcc_mt_dma_readEntry(const UI32_T unit,
                     void *ptr_dst_buf,
                     const UI32_T addr,
                     const UI32_T entry_len,
                     const UI32_T entry_num);

/**
 * @brief dcc_mt_dma_writeEntry() is a function to move table entry from device to device.
 *
 * @param [in]     unit         - The specified unit number.
 * @param [in]     src_addr     - The start address of source device table address for DMA transfer.
 * This address should be a valid address inside chip.
 * @param [in]     dst_addr     - The start address of destination device table address for DMA
 * transfer.
 * @param [in]     entry_len    - The length of an entry is going to be transferred
 * @param [in]     entry_num    - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully write data from host to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to write data from host to device
 */
CLX_ERROR_NO_T
dcc_mt_dma_copyEntry(const UI32_T unit,
                     const UI32_T src_addr,
                     const UI32_T dst_addr,
                     const UI32_T entry_len,
                     const UI32_T entry_num);

/**
 * @brief dcc_mt_dma_setDmaHToDOperationMode() is a function to change DCC_MT host to device DMA
 * channel operation mode to be poll or interrupt.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     op_mode    - The DMA channel operation mode, valid are:
 *                              1. DCC_MT_CH_OP_MODE_POLL
 *                              2. DCC_MT_CH_OP_MODE_INTR
 * @return         CLX_E_OK        - Set DMA channel operation mode successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation mode.
 */
CLX_ERROR_NO_T
dcc_mt_dma_setDmaHToDOperationMode(const UI32_T unit, const DCC_MT_CH_OP_MODE_T op_mode);

/**
 * @brief dcc_mt_dma_setDmaDToHOperationMode() is a function to change DCC_MT device to host DMA
 * channel operation mode to be poll or interrupt.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     op_mode    - The DMA channel operation mode, valid are:
 *                              1. DCC_MT_CH_OP_MODE_POLL
 *                              2. DCC_MT_CH_OP_MODE_INTR
 * @return         CLX_E_OK        - Set DMA channel operation mode successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation mode.
 */
CLX_ERROR_NO_T
dcc_mt_dma_setDmaDToHOperationMode(const UI32_T unit, const DCC_MT_CH_OP_MODE_T op_mode);

/**
 * @brief dcc_mt_dma_setDmaDToDOperationMode() is a function to change DCC_MT device to device DMA
 * channel operation mode to be poll or interrupt.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     op_mode    - The DMA channel operation mode, valid are:
 *                              1. DCC_MT_CH_OP_MODE_POLL
 *                              2. DCC_MT_CH_OP_MODE_INTR
 * @return         CLX_E_OK        - Set DMA channel operation mode successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation mode.
 */
CLX_ERROR_NO_T
dcc_mt_dma_setDmaDToDOperationMode(const UI32_T unit, const DCC_MT_CH_OP_MODE_T op_mode);

/**
 * @brief dcc_mt_dma_setDmaHToDOperationTimeoutCnt() is a function to change DCC_MT host to device
 * DMA channel operation time-out count.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     timeout_cnt    - The DMA channel operation time-out count for polling mode.
 * @return         CLX_E_OK        - Set DMA channel operation time-out count successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation time-out count.
 */
CLX_ERROR_NO_T
dcc_mt_dma_setDmaHToDOperationTimeoutCnt(const UI32_T unit, const UI32_T timeout_cnt);

/**
 * @brief dcc_mt_dma_setDmaDToHOperationTimeoutCnt() is a function to change DCC_MT device to host
 * DMA channel operation time-out count.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     timeout_cnt    - The DMA channel operation time-out count for polling mode.
 * @return         CLX_E_OK        - Set DMA channel operation time-out count successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation time-out count.
 */
CLX_ERROR_NO_T
dcc_mt_dma_setDmaDToHOperationTimeoutCnt(const UI32_T unit, const UI32_T timeout_cnt);

/**
 * @brief dcc_mt_dma_setDmaDToDOperationTimeoutCnt() is a function to change DCC_MT device to device
 * DMA channel operation time-out count.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     timeout_cnt    - The DMA channel operation time-out count for polling mode.
 * @return         CLX_E_OK        - Set DMA channel operation time-out count successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation time-out count.
 */
CLX_ERROR_NO_T
dcc_mt_dma_setDmaDToDOperationTimeoutCnt(const UI32_T unit, const UI32_T timeout_cnt);

/**
 * @brief dcc_mt_dma_showCldChannelInfo() is a function to display DCC_MT CLD DMA channel
 * information.
 *
 * @param [in]     unit    - The specified unit number.
 */

void
dcc_mt_dma_showCldChannelInfo(const UI32_T unit);

/**
 * @brief dcc_mt_dma_setCldMode() is a function to set DCC_MT CLD DMA uP operation mode
 *
 * @param [in]     unit        - The specified unit number.
 * @param [in]     period      - Significant part of each task interval (1 ~ 65535)
 * @param [in]     exponent    - Exponent part of each task interval (2^exponent, 0 ~ 15)
 *                               -- The exact time interval is period
 * @param [in]     enable      - Enable CLD DMA
 * @param [in]     repeat      - Enable automatic repeat after all tasks complete
 * @return         CLX_E_OK               - Set uP operation mode successfully
 * @return         CLX_E_BAD_PARAMETER    - Invalid exponent parameter
 * @return         CLX_E_OTHERS           - Fail to set uP operation mode
 */

CLX_ERROR_NO_T
dcc_mt_dma_setCldMode(const UI32_T unit,
                      const UI32_T period,
                      const UI32_T exponent,
                      const BOOL_T enable,
                      const BOOL_T repeat);

/*
 * PURPOSE:
 *      dcc_mt_dma_addCldTask() is a function to add a calendar DMA task
 *
 * INPUT:
 *      unit                  -- The specified unit number
 *      ptr_task              -- Pointer to detailed task info
 * OUTPUT:
 *      ptr_task_id           -- task_id assigned to the new task
 * RETURN:
 *      CLX_E_OK              -- Task is successfully added into system
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_TABLE_FULL      -- Task table full, cannot add a new task
 *      CLX_E_OTHERS          -- Fail to add task into system due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_mt_dma_addCldTask(const UI32_T unit, const DCC_CLD_TASK_T *ptr_task, UI32_T *ptr_task_id);

/*
 * PURPOSE:
 *      dcc_mt_dma_delCldTask() is a function to delete a calendar DMA task
 *
 * INPUT:
 *      unit                  -- The specified unit number
 *      task_id               -- The task to be deleted
 * OUTPUT:
 *       None
 * RETURN:
 *      CLX_E_OK              -- Task is successfully deleted from system
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_ENTRY_NOT_FOUND -- Task associated with the task_id does not exist
 *      CLX_E_OTHERS          -- Fail to delete task from system due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_mt_dma_delCldTask(const UI32_T unit, const UI32_T task_id);

/**
 * @brief dcc_mt_dma_setCldTaskStatus() is a function to set a task status to the idle/pause state
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     task_id    - The task to be set status
 * @param [in]     state      - The new state of the task, valid settings are
 *                              1. DCC_CLD_STAT_IDLE
 *                              2. DCC_CLD_STAT_PAUSE
 * @return         CLX_E_OK                 - Task status is successfully set
 * @return         CLX_E_BAD_PARAMETER      - Input parameter has error configuration or value
 * @return         CLX_E_ENTRY_NOT_FOUND    - Task associated with the task_id doesn't exist
 * @return         CLX_E_OTHERS             - Fail to set task state due to internal error
 */

CLX_ERROR_NO_T
dcc_mt_dma_setCldTaskStatus(const UI32_T unit, const UI32_T task_id, const BOOL_T state);

/**
 * @brief dcc_mt_dma_getCldTaskStatus() is a function to get a task's current status
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     task_id       - The task to be queried
 * @param [out]    ptr_status    - Status of the task under study
 * @return         CLX_E_OK                 - Task status is successfully obtained
 * @return         CLX_E_BAD_PARAMETER      - Input parameter has error configuration or value
 * @return         CLX_E_ENTRY_NOT_FOUND    - Task associated with the task_id doesn't exist
 * @return         CLX_E_OTHERS             - Fail to read task status due to internal error
 */

CLX_ERROR_NO_T
dcc_mt_dma_getCldTaskStatus(const UI32_T unit, const UI32_T task_id, DCC_CLD_STAT_T *ptr_status);

/**
 * @brief dcc_mt_dma_showCldTaskInfo() is a function to show DCC_MT CLD DMA task information.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     task_id    - task_id of the task under study
 */

CLX_ERROR_NO_T
dcc_mt_dma_showCldTaskInfo(const UI32_T unit, const UI32_T task_id);

/**
 * @brief dcc_mt_dma_dmaUpError() is a function to handle dma up error irq.
 *
 * @param [in]     unit    - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK        - handle tdma uP error successfully
 * @return         CLX_E_OTHERS    - fail to handle tdma uP error
 */
CLX_ERROR_NO_T
dcc_mt_dma_dmaUpError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_cldStaUpdError() is a function to handle CLD DMA status update error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle cld dma status update error successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_cldStaUpdError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_tdmaStaUpdError() is a function to handle tdma status update error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle tdma status update error successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_tdmaStaUpdError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_cldDmaHtoDError() is a function to handle cld dma device to host error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle cld dma device to host error successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_cldDmaDtoHError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_cldDmaHtoDError() is a function to handle cld dma host to device error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle cld dma host to device error successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_cldDmaHtoDError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_dmaTableHtoDError() is a function to handle host to device tdma error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle tdma host to device error successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_dmaTableHtoDError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_dmaTableDtoHError() is a function to handle device to host tdma error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle tdma device to host error successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_dmaTableDtoHError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_dmaTableDtoDError() is a function to handle device to device tdma error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle tdma device to host error successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_dmaTableDtoDError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_recoverDmaChannel() is a function to recover DMA channel while DMA uP is
 * damaged.
 *
 * @param [in]     unit        - The specified unit number.
 * @param [in]     dma_type    - The specified dma type, include cld DMA, table DMA write, and table
 * DMA read.
 * @return         CLX_E_OK        - recover Dma channel error successfully
 * @return         CLX_E_OTHERS    - recover Dma channel error failed
 */

CLX_ERROR_NO_T
dcc_mt_dma_recoverDmaChannel(const UI32_T unit, DCC_DMA_TYPE_T dma_type);

/**
 * @brief dcc_mt_dma_recoverDmaDoubleEccError() is a function to handle program memory double bit
 * ECC error for Dma uP.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle cld dma device to host error successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_recoverDmaDoubleEccError(const UI32_T unit, const UI32_T isr_cookie);

/* DMA channel ISR */
CLX_ERROR_NO_T
dcc_mt_dma_cldChIsr(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_mt_dma_txCmd() is a function to send custom command to DCE uP
 *
 * @param [in]     unit        - The specified unit number
 * @param [in]     cmd         - Custom command ID
 * @param [in]     ptr_data    - Pointer for the user data sent to DCE uP
 * @param [in]     data_len    - Valid word count in ptr_data
 * @return         CLX_E_OK    - Handle the command successfully
 */
CLX_ERROR_NO_T
dcc_mt_dma_txCmd(const UI32_T unit,
                 const DCC_DMA_CMD_T cmd,
                 UI32_T *ptr_data,
                 const UI32_T data_len); /* in word */

/**
 * @brief calculate 4bytes aligned entry_len
 *
 * @param [in]     unit               - The specified unit number.
 * @param [in]     entry_len          - entry_len
 * @param [out]    entry_len_align    - 4 bytes aligned entry_len
 */
void
_dcc_mt_dma_calculate_4bytes_align(const UI32_T unit, UI32_T entry_len, UI32_T *entry_len_align);
#endif /* END of DCC_MT_H*/
