/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_mir.h
 * PURPOSE:
 *    Provide mir hal layer api.
 *
 * NOTES:
 *
 */

#ifndef HAL_LT_MIR_H
#define HAL_LT_MIR_H

typedef struct HAL_LT_MIR_EMI_RSLT_MIR_SES_S {
    UI32_T pcp_dei_vld;
    UI32_T pcp;
    UI32_T dei;
    UI32_T nvo3_encap_idx;
    UI32_T nvo3_adj_idx;
    UI32_T seg_vmid;
    UI32_T keep_crc_as_is;
    UI32_T keep_igr_vlan_tags;
    UI32_T vid_ctl;
    UI32_T vid_1st;
    UI32_T vid_2nd;
} HAL_LT_MIR_EMI_RSLT_MIR_SES_T;

CLX_ERROR_NO_T
hal_lt_mir_addLocalSpanSession(const UI32_T unit,
                               const UI32_T entry_id,
                               const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_addRspanSrcSession(const UI32_T unit,
                              const UI32_T entry_id,
                              const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_addRspanDstSession(const UI32_T unit,
                              const UI32_T entry_id,
                              const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_addErspanSrcSession(const UI32_T unit,
                               const UI32_T entry_id,
                               const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_addErspanDstSession(const UI32_T unit,
                               const UI32_T entry_id,
                               const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_delLocalSpanSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_lt_mir_delRspanSrcSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_lt_mir_delRspanDstSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_lt_mir_delErspanSrcSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_lt_mir_delErspanDstSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_lt_mir_setRspanDstSession(const UI32_T unit,
                              const UI32_T entry_id,
                              const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_setErspanSrcSession(const UI32_T unit,
                               const UI32_T entry_id,
                               const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_getLocalSpanSession(const UI32_T unit,
                               const UI32_T entry_id,
                               CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_getRspanSrcSession(const UI32_T unit,
                              const UI32_T entry_id,
                              CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_getRspanDstSession(const UI32_T unit,
                              const UI32_T entry_id,
                              CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_getErspanSrcSession(const UI32_T unit,
                               const UI32_T entry_id,
                               CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_getErspanDstSession(const UI32_T unit,
                               const UI32_T entry_id,
                               CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_lt_mir_addErspanTerm(const UI32_T unit, const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

CLX_ERROR_NO_T
hal_lt_mir_delErspanTerm(const UI32_T unit, const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

CLX_ERROR_NO_T
hal_lt_mir_findErspanTerm(const UI32_T unit,
                          const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_search,
                          HAL_MIR_ERSPAN_TERM_T **ptr_erspan_term);

CLX_ERROR_NO_T
hal_lt_mir_updateHwLagMember(const UI32_T unit,
                             const UI32_T port,
                             const UI32_T link,
                             void *ptr_cookie);

CLX_ERROR_NO_T
hal_lt_mir_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_mir_setHwMirSrcPort(const UI32_T unit,
                           const UI32_T port,
                           const CLX_DIR_T dir,
                           const UI32_T mir_session_bitmap);

CLX_ERROR_NO_T
hal_lt_mir_getHwMirSrcPort(const UI32_T unit,
                           const UI32_T port,
                           const CLX_DIR_T dir,
                           UI32_T *ptr_mir_session_bitmap);

CLX_ERROR_NO_T
hal_lt_mir_setHwErspanTermMissAction(const UI32_T unit, const UI32_T miss_action);

CLX_ERROR_NO_T
hal_lt_mir_getHwErspanTermMissAction(const UI32_T unit, UI32_T *ptr_miss_action);

CLX_ERROR_NO_T
hal_lt_mir_updateHwLagPortEvent(const UI32_T unit, const UI32_T event, const CLX_PORT_T lag_port);

CLX_ERROR_NO_T
hal_lt_mir_setDestination(const UI32_T unit, const UI32_T entry_id, const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_lt_mir_checkParameter(const UI32_T unit, const CLX_MIR_SESSION_T *ptr_session);

#endif /* End of HAL_LT_MIR_H */
