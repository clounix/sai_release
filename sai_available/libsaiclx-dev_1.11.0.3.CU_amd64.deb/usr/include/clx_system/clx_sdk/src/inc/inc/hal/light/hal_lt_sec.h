/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_sec.h
 * PURPOSE:
 *      Define the declaration for Security module.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_LT_SEC_H
#define HAL_LT_SEC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_cfg.h>
#include <clx_types.h>
#include <clx_error.h>
#include <clx_sec.h>
#include <clx_port.h>
#include <osal/osal.h>
#include <dcc/dcc.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_LT_SEC_PP_PBM_WORDS (24) /* PP PBM words */

/* Dos check size maximum */
#define HAL_LT_SEC_DOS_MAX_ICMPV4_SIZE    (0xFFFF)
#define HAL_LT_SEC_DOS_MAX_ICMPV6_SIZE    (0xFFFF)
#define HAL_LT_SEC_DOS_MAX_L4_PROT        (0xFF)
#define HAL_LT_SEC_DOS_MIN_UDP_SIZE       (0xF)
#define HAL_LT_SEC_DOS_MIN_UDP_FRG_OFF    (0xF)
#define HAL_LT_SEC_DOS_MIN_TCP_SIZE       (0x1F)
#define HAL_LT_SEC_DOS_MIN_TCP_FRG_OFF    (0x1F)
#define HAL_LT_SEC_DOS_MIN_SCTP_SIZE      (0xF)
#define HAL_LT_SEC_DOS_MIN_SCTP_FRG_OFF   (0xF)
#define HAL_LT_SEC_DOS_MIN_IPV6_FRAG_SIZE (0x1F)

/* storm meter rate max */
#define HAL_LT_SEC_SCMETER_RATE_MAX (1600000000UL) /* 1.6G Kbps = 1.6Tbps */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_lt_sec_initCfg(const UI32_T unit);

/**
 * @brief set port DoS configuration. (add profile or record reference counter)
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - physical port ID.
 * @param [in]     ptr_entry    - DoS per port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_setDosPortConfig(const UI32_T unit,
                            const UI32_T port,
                            const CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry);

/**
 * @brief get port DoS configuration. (get the port DoS profile id, and get dos profile entry)
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - physical port ID.
 * @param [out]    ptr_entry    - DoS per port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getDosPortConfig(const UI32_T unit,
                            const UI32_T port,
                            CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry);

/**
 * @brief Get port DoS profile information
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     port              - Port id
 * @param [in]     ptr_profile_id    - Profile id
 * @param [in]     ptr_ref_cnt       - Reference count
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_sec_getDosPortProfileInfo(const UI32_T unit,
                                 const UI32_T port,
                                 UI32_T *ptr_profile_id,
                                 UI32_T *ptr_ref_cnt);

/**
 * @brief set global DoS configuration. (update all profile)
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - DoS global configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_setDosConfig(const UI32_T unit, const CLX_SEC_DOS_CONFIG_T *ptr_entry);

/**
 * @brief get global DoS configuration. (get profile 0)
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_entry    - DoS global configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getDosConfig(const UI32_T unit, CLX_SEC_DOS_CONFIG_T *ptr_entry);

/**
 * @brief Set storm control properties on a physical port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [in]     ptr_entry    - The storm control properties for the physical port.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_setStormCtrlProperty(const UI32_T unit,
                                const UI32_T port,
                                const CLX_SEC_STORM_CTRL_T *ptr_entry);

/**
 * @brief Get storm control properties on a physical port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [out]    ptr_entry    - The storm control properties for the physical port.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getStormCtrlProperty(const UI32_T unit,
                                const UI32_T port,
                                CLX_SEC_STORM_CTRL_T *ptr_entry);

/**
 * @brief Get storm control counter on a physical port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [in]     type       - The storm control counter type.
 * @param [out]    ptr_cnt    - The storm control counter.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getStormCtrlCnt(const UI32_T unit,
                           const UI32_T port,
                           const CLX_SEC_STORM_CTRL_TYPE_T type,
                           CLX_SEC_STORM_CTRL_CNT_T *ptr_cnt);

/**
 * @brief Set storm control enable for control packets.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     enable    - Enable/Disable storm control for control packets.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_setStormCtrlCtrlPktEn(const UI32_T unit, const UI32_T enable);

/**
 * @brief Set storm control enable for control packets.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - Enable/Disable storm control for control packets.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getStormCtrlCtrlPktEn(const UI32_T unit, UI32_T *ptr_enable);

/**
 * @brief Set storm control meter layer mode(L1/L2).
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     layer_mode    - storm control meter layer mode.
 *                                 1 - layer 1; 0 - layer 2
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_setStormCtrlMeterLayer(const UI32_T unit, const UI32_T layer_mode);

/**
 * @brief Set storm control meter layer mode(global).
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_layer_mode    - storm control meter layer mode
 *                                     1 - layer 1; 0 - layer 2
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getStormCtrlMeterLayer(const UI32_T unit, UI32_T *ptr_layer_mode);

/**
 * @brief Set source guard properties on a physical port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [in]     ptr_entry    - The source guard properties for the physical port.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_setSourceGuardProperty(const UI32_T unit,
                                  const CLX_PORT_T port,
                                  const CLX_SEC_SG_PROPERTY_T *ptr_entry);

/**
 * @brief Get source guard properties on a physical port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [out]    ptr_entry    - The source guard properties for the physical port.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getSourceGuardProperty(const UI32_T unit,
                                  const CLX_PORT_T port,
                                  CLX_SEC_SG_PROPERTY_T *ptr_entry);

/**
 * @brief Add a source guard entry.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - Source guard entry.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_addSourceGuardEntry(const UI32_T unit, const CLX_SEC_SG_ENTRY_T *ptr_entry);

/**
 * @brief Delete a source guard entry.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - Source guard entry.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_delSourceGuardEntry(const UI32_T unit, const CLX_SEC_SG_ENTRY_T *ptr_entry);

/**
 * @brief Get a source guard entry.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_entry    - Source guard entry.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getSourceGuardEntry(const UI32_T unit, CLX_SEC_SG_ENTRY_T *ptr_entry);

/**
 * @brief Set the egress portlist for an ingress port.
 *
 * For a given ingress port, the packet is allowed to the egress port
 * only if corresponding bit of the port is set in the port bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Ingress port ID.
 * @param [in]     port_bitmap    - Egress port bitmap.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_setEgressPort(const UI32_T unit, const UI32_T port, const CLX_PORT_BITMAP_T port_bitmap);

/**
 * @brief Get the egress portlist for an ingress port.
 *
 * For a given ingress port, the packet is allowed to the egress port
 * only if corresponding bit of the port is set in the port bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Ingress port ID.
 * @param [out]    port_bitmap    - Egress port bitmap.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_lt_sec_getEgressPort(const UI32_T unit, const UI32_T port, CLX_PORT_BITMAP_T port_bitmap);

/**
 * @brief Reset source port suppression.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Ingress port ID.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Port beyond range.
 */

CLX_ERROR_NO_T
hal_lt_sec_resetPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief Set port default configure
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port id
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */

CLX_ERROR_NO_T
hal_lt_sec_setPortDefault(const UI32_T unit, const UI32_T port);

#endif /* End of HAL_LT_SEC_H */
