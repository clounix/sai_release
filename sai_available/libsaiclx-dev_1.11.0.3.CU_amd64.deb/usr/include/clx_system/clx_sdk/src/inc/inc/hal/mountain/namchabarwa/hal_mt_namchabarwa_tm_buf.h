/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_tm_buf_buf.h
 * PURPOSE:
 *      It provides hal traffic management module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NAMCHABARWA_TM_BUF_H
#define HAL_MT_NAMCHABARWA_TM_BUF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>
#include <osal/osal.h>
#include <hal/hal_tbl.h>
#include <hal/hal.h>
#include <hal/hal_const_cmn.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NAMCHABARWA_TM_CELL_SIZE (256)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_MT_NAMCHABARWA_TM_BUF_QUEUE_STATUS_S {
    UI32_T is_lossless; /* The buffer of the queue is lossy or lossless */
    UI32_T egr_type;    /* The ECN mark status:
                           0:CLX_TM_BUF_EGR_PROFILE_TYPE_TAIL_DROP,
                           1:CLX_TM_BUF_EGR_PROFILE_TYPE_WRED_DROP,
                           2:CLX_TM_BUF_EGR_PROFILE_TYPE_WRED_ECN */
} HAL_MT_NAMCHABARWA_TM_BUF_QUEUE_STATUS_T;

/* HAL layer API structure */

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The function is used to init TM buffer management HW & SW DB
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_initRsrc(const UI32_T unit);

/**
 * @brief The function is used to deinit TM buffer management HW & SW DB
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_deinitRsrc(const UI32_T unit);

/**
 * @brief The function is used to init TM buffer management configuration
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_initCfg(const UI32_T unit);

/**
 * @brief The function is used to update the port status with action.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [in]     status    - action (HAL_TM_PS_ACTIVED, HAL_TM_PS_NO_ACTIVED)
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_updatePortStatus(const UI32_T unit,
                                           const UI32_T port,
                                           const HAL_TM_SC_T status);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_getBufOccupancy(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_TM_HANDLER_T handler,
                                          const CLX_TM_BUF_TYPE_T type,
                                          CLX_TM_BUF_OCCUPANCY_T *ptr_entry);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_deinitWarm(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_initWarm(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_getBufWatermark(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_TM_HANDLER_T handler,
                                          const CLX_TM_BUF_TYPE_T type,
                                          CLX_TM_BUF_WATERMARK_T *ptr_entry);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_clearBufWatermark(const UI32_T unit,
                                            const UI32_T port,
                                            const CLX_TM_HANDLER_T handler,
                                            const CLX_TM_BUF_TYPE_T type);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_getBufWatermarkList(const UI32_T unit,
                                              const UI32_T port,
                                              const CLX_TM_HANDLER_T *ptr_handler_list,
                                              const CLX_TM_BUF_TYPE_T type,
                                              const UI32_T list_cnt,
                                              CLX_TM_BUF_WATERMARK_T *ptr_entry_list);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_clearBufWatermarkList(const UI32_T unit,
                                                const UI32_T port,
                                                const CLX_TM_HANDLER_T *ptr_handler_list,
                                                const CLX_TM_BUF_TYPE_T type,
                                                const UI32_T list_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_initTask(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_deinitTask(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_setPortDefault(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_resetPortDefault(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_createBufProfile(const UI32_T unit,
                                           const CLX_TM_BUF_TYPE_T type,
                                           const UI32_T profile_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_deleteBufProfile(const UI32_T unit,
                                           const CLX_TM_BUF_TYPE_T type,
                                           const UI32_T profile_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_setBufProfile(const UI32_T unit,
                                        const UI32_T profile_id,
                                        const CLX_TM_BUF_PROFILE_T *profile);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_getBufProfile(const UI32_T unit,
                                        const UI32_T profile_id,
                                        CLX_TM_BUF_PROFILE_T *profile);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_setBufConfig(const UI32_T unit, const CLX_TM_BUF_CONFIG_T *config);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_getBufConfig(const UI32_T unit, CLX_TM_BUF_CONFIG_T *config);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_setEgrQueueHistogramConfig(const UI32_T unit,
                                                     const CLX_TM_HISTOGRAM_CONFIG_T *ptr_config);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_getEgrQueueHistogramConfig(const UI32_T unit,
                                                     CLX_TM_HISTOGRAM_CONFIG_T *ptr_config);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_registerHistogramCallback(const UI32_T unit,
                                                    const UI32_T port,
                                                    const CLX_TM_HISTOGRAM_FUNC_T func,
                                                    void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_deRegisterHistogramCallback(const UI32_T unit,
                                                      const UI32_T port,
                                                      const CLX_TM_HISTOGRAM_FUNC_T func,
                                                      void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_setDynamicThreshold(const UI32_T unit,
                                              const CLX_TM_BUF_TYPE_T type,
                                              const UI32_T enable,
                                              const UI32_T factor);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_getDynamicThreshold(const UI32_T unit,
                                              const CLX_TM_BUF_TYPE_T type,
                                              UI32_T *enable,
                                              UI32_T *factor);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_setSharePoolSize(const UI32_T unit,
                                       const UI32_T lossy_pool_size,
                                       const UI32_T lossless_pool_size,
                                       const BOOL_T is_egr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_getSharePoolSize(const UI32_T unit,
                                       UI32_T *ptr_lossy_pool_size,
                                       UI32_T *ptr_lossless_pool_size,
                                       const BOOL_T is_egr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_setRedBaseYellowEn(const UI32_T unit, const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_getRedBaseYellowEn(const UI32_T unit, UI32_T *ptr_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_setDefault(const UI32_T unit);

UI32_T
_hal_mt_namchabarwa_tm_buf_getValueFromCfg(const UI32_T unit,
                                           const UI32_T cfg,
                                           const UI32_T param0,
                                           const UI32_T param1,
                                           UI32_T value);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_checkPortSqDepthIsZero(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_setSqProfilePolicy(const UI32_T unit,
                                             const UI32_T port,
                                             const UI32_T queue);

CLX_ERROR_NO_T
hal_mt_namchabrawa_tm_buf_setSwTable(const UI32_T unit,
                                     const UI32_T port,
                                     const UI32_T handler,
                                     const UI32_T lossless,
                                     const UI32_T type);

CLX_ERROR_NO_T
hal_mt_namchabrawa_tm_buf_getSwTable(const UI32_T unit,
                                     const UI32_T oq_index,
                                     HAL_MT_NAMCHABARWA_TM_BUF_QUEUE_STATUS_T *ptr_status);

BOOL_T
hal_mt_namchabarwa_tm_buf_checkIsFlushChipTraffic(const UI32_T unit, const CLX_TM_BUF_TYPE_T type);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_buf_clearEgrQueueHistogramCount(const UI32_T unit,
                                                      const UI32_T port,
                                                      const CLX_TM_HANDLER_T handler);

#endif /*end of HAL_MT_NAMCHABARWA_TM_BUF_H*/
