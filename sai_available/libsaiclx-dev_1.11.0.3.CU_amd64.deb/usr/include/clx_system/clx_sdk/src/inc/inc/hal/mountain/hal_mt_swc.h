/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_swc.h
 * PURPOSE:
 *    It provides HAL driver API functions for swc module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_SWC_H
#define HAL_MT_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <math.h>
#include <clx_pkt.h>
#include <hal/mountain/hal_mt_pkt_rsrc.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_SWC_REASON_PRIORITY_MIN       (0)
#define HAL_MT_SWC_REASON_PRIORITY_MAX       (15)
#define HAL_MT_SWC_REASON_CLOCK_TO_NS        (0.741)
#define HAL_MT_SWC_REASON_PRIORITY_SPT       (12)
#define HAL_MT_SWC_REASON_PRIORITY_SPT_HIGHT (HAL_MT_SWC_REASON_PRIORITY_SPT + 1)

#define HAL_MT_SWC_HASH_ID_ECMP_L3    (0)
#define HAL_MT_SWC_HASH_ID_ECMP_NVO3  (1)
#define HAL_MT_SWC_HASH_ID_MPLS       (1)
#define HAL_MT_SWC_HASH_ID_LAG        (2)
#define HAL_MT_SWC_HASH_ID_FABRIC_LAG (2)
#define HAL_MT_SWC_HASH_ID_ECMP_L2    (3)
#define HAL_MT_SWC_HASH_ENGINE_NUM    (4)
#define HAL_MT_SWC_HASH_KEY_ALL       (0x3ffffff)

#define HAL_MT_SWC_CB(unit) (&_hal_mt_swc_cb[unit])
#define HAL_MT_SWC_LOCK(unit) \
    HAL_COMMON_LOCK_RESOURCE(&(_hal_mt_swc_cb[unit].sema_id), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_SWC_UNLOCK(unit)                        HAL_COMMON_FREE_RESOURCE(&(_hal_mt_swc_cb[unit].sema_id))
#define HAL_MT_NAMCHABARWA_CHIP_INIT_PP_SRAM_NUM       (96)
#define HAL_MT_NAMCHABARWA_CHIP_INIT_PP_TCAM_CHECK_NUM (14)
#define HAL_MT_NAMCHABARWA_CHIP_INIT_PP_HASH_CHECK_NUM (12)
/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_MT_SWC_EPP_REASON_ACTION_DISABLE = 0,
    HAL_MT_SWC_EPP_REASON_ACTION_COPY,
    HAL_MT_SWC_EPP_REASON_ACTION_REDIR,
    HAL_MT_SWC_EPP_REASON_ACTION_DROP,
    HAL_MT_SWC_EPP_REASON_ACTION_LAST
} HAL_MT_SWC_EPP_REASON_ACTION_T;

typedef enum {
    HAL_MT_SWC_WBDB_CFG_ID = 0,
    HAL_MT_SWC_WBDB_CB_ID,
    HAL_MT_SWC_WBDB_OBJ_LAST
} HAL_MT_SWC_WBDB_OBJ_TYPE_T;

typedef struct HAL_MT_SWC_CB_S {
    CLX_SEMAPHORE_ID_T sema_id;
    BOOL_T excpt_ctrl;
    UI32_T excpt_actions[CLX_PKT_RX_REASON_LAST];
    CLX_SWC_RX_REASON_ACTION_T rx_reason_action[CLX_PKT_RX_REASON_LAST];
    UI32_T reason_prio[HAL_MT_PKT_PP_REASON_LAST];
} HAL_MT_SWC_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_mt_swc_getHashTileBitmap(const UI32_T unit,
                             const CLX_SWC_HASH_TILE_TYPE_T hash_tile_type,
                             HAL_SWC_HASH_TILE_BITMAP_T ptr_bitmap);

CLX_ERROR_NO_T
hal_mt_swc_getTcamBitmap(const UI32_T unit,
                         const CLX_SWC_TCAM_TYPE_T tcam_type,
                         HAL_SWC_TCAM_BITMAP_T ptr_bitmap);

/**
 * @brief Set hash engine configuration.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     hash_type      - Hash engine
 * @param [in]     hash_engine    - Hash engine attributes
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
hal_mt_swc_setHashEngine(const UI32_T unit,
                         const CLX_SWC_HASH_TYPE_T hash_type,
                         const CLX_SWC_HASH_ENGINE_T *hash_engine);

/**
 * @brief Get hash engine configuration.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     hash_type      - Hash engine
 * @param [out]    hash_engine    - Pointer to hash engine attributes
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
hal_mt_swc_getHashEngine(const UI32_T unit,
                         const CLX_SWC_HASH_TYPE_T hash_type,
                         CLX_SWC_HASH_ENGINE_T *hash_engine);

/**
 * @brief Get switch control bitmap of all hash keys.
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    key_bitmap    - Hash key bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getAllHashKeyBitmap(const UI32_T unit, CLX_SWC_HASH_KEY_BITMAP_T *key_bitmap);

/**
 * @brief Set switch control hash keys.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     hash_type     - Hash type
 * @param [in]     key_bitmap    - Hash key bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_setHashKey(const UI32_T unit,
                      const CLX_SWC_HASH_TYPE_T hash_type,
                      const CLX_SWC_HASH_KEY_BITMAP_T key_bitmap);

/**
 * @brief Get switch control hash keys.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     hash_type    - Hash type
 * @param [out]    key_bitmap   - Hash key bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getHashKey(const UI32_T unit,
                      const CLX_SWC_HASH_TYPE_T hash_type,
                      CLX_SWC_HASH_KEY_BITMAP_T *key_bitmap);

/**
 * @brief Set hash engine polynominal coefficients
 *
 * Only ptr_hash_const[0] will be apply.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     count             - Size (number of elements) of array pointed by ptr_hash_const,
 * don't care on CL8600
 * @param [in]     ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
hal_mt_swc_setHashConstant(const UI32_T unit,
                           const CLX_SWC_HASH_TYPE_T hash_type,
                           const UI32_T count,
                           const UI32_T *ptr_hash_const);

/**
 * @brief Get hash engine polynominal coefficients
 *
 * Only get ptr_hash_const[0].
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     count             - Size (number of elements) of array pointed by ptr_hash_const,
 * don't care on CL8600
 * @param [out]    ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getHashConstant(const UI32_T unit,
                           const CLX_SWC_HASH_TYPE_T hash_type,
                           const UI32_T count,
                           UI32_T *ptr_hash_const);

/**
 * @brief To set table reason_code_act_x and field actx in each stage.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     epp_reason_code    - epp reason code
 * @param [in]     cpu_vld            - cpu cpoy or not
 * @param [in]     fwd_vld            - fwd copy or not
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_setEppReasonActTbl(const UI32_T unit,
                              const HAL_MT_PKT_PP_REASON_T epp_reason_code,
                              const UI32_T cpu_vld,
                              const UI32_T fwd_vld);

/**
 * @brief To set PP reason priority.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     pp_reason_code    - pp reason code
 * @param [in]     priority          - reason priority
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_setPpReasonPriority(const UI32_T unit,
                               const UI32_T pp_reason_code,
                               const UI32_T priority);

/**
 * @brief To get PP reason priority.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     pp_reason_code    - pp reason code
 * @param [out]    priority          - reason priority
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getPpReasonPriority(const UI32_T unit, const UI32_T pp_reason_code, UI32_T *priority);

/**
 * @brief Set RX reason action.
 *        Asign drop reason code if fowarding action is dropping.
 *        Asign CPU qeueu if fowarding action is copy to CPU or redirect to CPU.
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     rx_reason_code      - rx reason code
 * @param [in]     rx_reason_action    - rx reason aciton
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_setRxReasonAction(const UI32_T unit,
                             const CLX_PKT_RX_REASON_T rx_reason_code,
                             const CLX_SWC_RX_REASON_ACTION_T *rx_reason_action);

/**
 * @brief Get RX reason action. Get drop reason code or cpu queue.
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     rx_reason_code      - rx reason code
 * @param [in]     rx_reason_action    - rx reason aciton
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getRxReasonAction(const UI32_T unit,
                             const CLX_PKT_RX_REASON_T rx_reason_code,
                             CLX_SWC_RX_REASON_ACTION_T *rx_reason_action);

/**
 * @brief This function is to set reason priority.
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @param [in]     priority          - reason priority
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_setRxReasonPriority(const UI32_T unit,
                               const CLX_PKT_RX_REASON_T rx_reason_code,
                               const UI32_T priority);

/**
 * @brief This function is to get reason priority.
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @param [out]    priority          - reason priority
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getRxReasonPriority(const UI32_T unit,
                               const CLX_PKT_RX_REASON_T rx_reason_code,
                               UI32_T *priority);

#if defined(CLX_HSH_LIB)
/**
 * @brief This function is to get flow hash value.
 *
 * @param [in]     unit            - device unit number
 * @param [in]     hash_type       - hash type
 * @param [in]     ptr_hash_key    - hash key
 * @param [out]    p_hash_value    - hash value
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getFlowHashValue(const UI32_T unit,
                            const CLX_SWC_HASH_TYPE_T hash_type,
                            const CLX_SWC_FLOW_HASH_KEY_T *ptr_hash_key,
                            UI32_T *p_hash_value);
#endif

/**
 * @brief This function is to set reason bloom filter configuration.
 *
 * @param [in]     unit                  - device unit number
 * @param [in]     bloom_filter_type     - bloom filter type
 * @param [in]     bloom_filter_value    - bloom filter value
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_setReasonBloomFilter(const UI32_T unit,
                                const CLX_SWC_REASON_BLOOM_FILTER_TYPE_T bloom_filter_type,
                                const UI32_T bloom_filter_value);

/**
 * @brief This function is to get reason bloom filter configuration.
 *
 * @param [in]     unit                  - device unit number
 * @param [in]     bloom_filter_type     - bloom filter type
 * @param [in]     bloom_filter_value    - bloom filter value
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getReasonBloomFilter(const UI32_T unit,
                                const CLX_SWC_REASON_BLOOM_FILTER_TYPE_T bloom_filter_type,
                                UI32_T *bloom_filter_value);

/**
 * @brief Set exceptions to drop, to CPU or foward.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     enable    - Enable or restore exceptions
 * @param [in]     action    - Drop, forward or send to the CPU
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_setException(const UI32_T unit, const UI32_T enable, const CLX_FWD_ACTION_T action);

/**
 * @brief Trap all packets to CPU.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     enable    - Enable or disable
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_setTrapAll(const UI32_T unit, const UI32_T enable);

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [out]    ptr_temperature_list    - Chip temperature list
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_swc_getChipTemperatureList(const UI32_T unit, CLX_SWC_THERMAL_LIST_T *ptr_temperature_list);

/**
 * @brief This function is to get max timestamp sec.
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    max_ts_sec    - Max Timestamp sec
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getMaxTsSec(const UI32_T unit, UI32_T *max_ts_sec);

/**
 * @brief This function is to get tod info.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_swc_getTodInfo(const UI32_T unit);

/**
 * @brief To get packet hash path.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     hash_type       - Hash type
 * @param [in]     ptr_hash_key    - Pointer of hash key
 * @param [in]     id              - Lag id / ECMP group id
 * @param [out]    ptr_rslt        - Pointer of result
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHER     - Init fail
 */
CLX_ERROR_NO_T
hal_mt_swc_getPktHashPath(const UI32_T unit,
                          const CLX_SWC_HASH_TYPE_T hash_type,
                          const CLX_SWC_FLOW_HASH_KEY_T *ptr_hash_key,
                          const UI32_T id,
                          CLX_SWC_HASH_PATH_RSLT_INFO_T *ptr_rslt);

/**
 * @brief To get hash path key
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     hash_type       - Hash type
 * @param [in]     pkt_info        - Packet info
 * @param [out]    ptr_key_bitmap  - Pointer of key bitmap
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHER     - Init fail
 */
CLX_ERROR_NO_T
hal_mt_swc_getHashPathKey(const UI32_T unit,
                          const CLX_SWC_HASH_TYPE_T hash_type,
                          const CLX_SWC_HASH_PATH_PKT_INFO_T pkt_info,
                          CLX_SWC_HASH_KEY_BITMAP_T *ptr_key_bitmap);

/**
 * @brief To initialize switch control module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK       - Operate success
 * @return         CLX_E_OTHER    - Init fail
 */
CLX_ERROR_NO_T
hal_mt_swc_init(const UI32_T unit);

/**
 * @brief To deinitialize switch control module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK       - Operate success
 * @return         CLX_E_OTHER    - Init fail
 */
CLX_ERROR_NO_T
hal_mt_swc_deinit(const UI32_T unit);

#endif /* End of HAL_MT_SWC_H */
