/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  dcc_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DCC).
 *  2. Define DCC IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_IO_H
#define DCC_IO_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <dcc/dcc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DCC constant definition */
/* unit of time: us, all times need for further check */
#define DCC_IO_CMD_SUSPEND_TIME  (1)
#define DCC_IO_CMD_BUSY_POLL_CNT (10)

/* For IO channel, we do not need to define BASE_DCE_MMIO_BUF registers.
We will copy response from this BASE_DCE_MMIO_BUF into the *ptr_rsp of DCC_CMD_T directly. */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* DCC IO channel status */
enum {
    IO_RSP_STAT_IDLE = 0, /* 0x0 */
    IO_RSP_STAT_BSY,      /* 0x1 */
    IO_RSP_STAT_RDY,      /* 0x2 */
    IO_RSP_STAT_ABT,      /* 0x3 */
    IO_RSP_STAT_NAK,      /* 0x4 */
    IO_RSP_STAT_ERR,      /* 0x5 */
    IO_RSP_STAT_LAST
};

/* DCC IO channel error code */
enum {
    IO_RSP_CODE_NORMAL = 0x0,
    IO_RSP_CODE_BUS_SLV_ERR = 0x1,
    IO_RSP_CODE_BUS_DEC_ERR = 0x2,
    IO_RSP_CODE_BUF_ECC_ERR = 0x3,
    IO_RSP_CODE_HASH_TIME_OUT_ERR = 0x4,
    IO_RSP_CODE_CMD_ADDR_INVALID_ERR = 0x8,
    IO_RSP_CODE_CMD_LEN_ERR = 0x9,
    IO_RSP_CODE_CMD_OP_ERR = 0xA,
    IO_RSP_CODE_CMD_OPT_SIZE_ERR = 0xB,
    IO_RSP_CODE_CMD_READ_NOT_WORD_ALIGN_MODE_ERR = 0xC,
    IO_RSP_CODE_CMD_ADDR_WORD_ALIGN_ERR = 0xD,
    IO_RSP_CODE_CMD_ADDR_HALF_WORD_ALIGN_ERR = 0xE,
    IO_RSP_CODE_CMD_LEN_NOT_WORD_ALIGN_MODE_ERR = 0xF,
    IO_RSP_CODE_LAST
};

/* Hash result state */
typedef enum {
    DCC_IO_HASH_STAT_SET_SUCCESS = 0x0,
    DCC_IO_HASH_STAT_ADD_SUCCESS = 0x1,
    DCC_IO_HASH_STAT_INSERT_FAIL = 0x2,
    DCC_IO_HASH_STAT_SET_FAIL = 0x3,
    DCC_IO_HASH_STAT_GET_SUCCESS = 0x4,
    DCC_IO_HASH_STAT_GET_FAIL = 0x5,
    DCC_IO_HASH_STAT_UCERR = 0x6,
    DCC_IO_HASH_STAT_MULTIPLE_INSTANCE = 0x7,
    DCC_IO_HASH_STAT_DEL_SUCCESS = 0x8,
    DCC_IO_HASH_STAT_DEL_FAIL = 0x9,
    DCC_IO_HASH_STAT_LAST
} DCC_IO_HASH_STAT_T;

/**
 * @brief dcc_io_initIoRsrc() is responsible for resource of DCC IO initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_io_initIoRsrc(const UI32_T unit);

/**
 * @brief dcc_io_initIoThread() is responsible for thread of DCC IO initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_io_initIoThread(const UI32_T unit);

/**
 * @brief dcc_io_deinitIoRsrc() is responsible for resource of DCC IO deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_io_deinitIoRsrc(const UI32_T unit);

/**
 * @brief dcc_io_deinitIoThread() is responsible for thread of DCC IO deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_io_deinitIoThread(const UI32_T unit);

/**
 * @brief dcc_io_txCmd() is the function that will send a command to DCE IO channel.
 *
 * @param [in]     unit        - The unit number that would like to be accessed.
 * @param [in]     action      - Read or write action.
 * @param [in]     addr        - Chip register or table address.
 * @param [in]     ptr_data    - The command data or data buffer.
 * @param [in]     data_len    - The command data length.
 * @return         CLX_E_OK        - Successfully send a DCC command.
 * @return         CLX_E_OTHERS    - Fail to send a DCC command.
 */
CLX_ERROR_NO_T
dcc_io_txCmd(const UI32_T unit,
             const DCC_CMD_ACT_T action,
             const UI32_T addr,
             UI32_T *ptr_data,
             const UI32_T data_len);

/**
 * @brief dcc_io_txHashCmd() is a function that will send a hash command through DCE IO channel.
 *
 * @param [in]     unit             - The unit number that would like to be accessed.
 * @param [in]     action           - Hash add, lookup, or delete action.
 * @param [in]     addr             - Chip register or table address.
 * @param [in]     ptr_hash_info    - Hash table meta info, indirect addr, trig addr, view.
 * @param [in]     bnk_bitmap       - The bank bitmap to apply hash action.
 * @param [in]     ptr_data         - The hash command data and data buffer.
 * @param [in]     data_len         - The hash command data length.
 * @param [out]    ptr_entry_idx    - The hash value of the hash key.
 * @return         CLX_E_OK        - Successfully send a DCC command.
 * @return         CLX_E_OTHERS    - Fail to send a DCC command.
 */
CLX_ERROR_NO_T
dcc_io_txHashCmd(const UI32_T unit,
                 const DCC_CMD_HASH_ACT_T action,
                 const UI32_T addr,
                 HASH_TBL_META_T *ptr_hash_info,
                 const UI32_T bnk_bitmap,
                 UI32_T *ptr_data,
                 const UI32_T data_len,
                 UI32_T *ptr_entry_idx);

/**
 * @brief dcc_io_showIoChannelInfo() is a function to display DCC IO channel information.
 *
 * @param [in]     unit    - The specified unit number.
 */
void
dcc_io_showIoChannelInfo(const UI32_T unit);

#endif /* END of DCC_IO_H*/
