/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mir.h
 * PURPOSE:
 *    It provides HAL driver API functions for mirror module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MIR_H
#define HAL_MIR_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_mir.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MIR_SESSION_ID_NUM           (8)
#define HAL_MIR_SESSION_ENTRY_NUM        (HAL_MIR_SESSION_ID_NUM * 2)
#define HAL_MIR_EGRESS_SESSION_ENTRY_MIN (HAL_MIR_SESSION_ID_NUM)
#define HAL_MIR_EGRESS_SESSION_ENTRY_MAX (HAL_MIR_SESSION_ID_NUM * 2 - 1)

#define HAL_MIR_ERSPAN_TERM_NUM (16)

#define HAL_MIR_IS_SESSION_BMP_VALID(unit, session_bmp) \
    (CLX_E_OK == hal_mir_isSessionBmpValid(unit, session_bmp))

#define HAL_MIR_SESSION_BMP_TO_ID(session_bmp, session_id) \
    hal_mir_transSessionBmp2Id(session_bmp, &(session_id))

#define HAL_MIR_SESSION_ID_TO_BMP(session_id, session_bmp) ((session_bmp) = 1U << (session_id))

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_MIR_METER_ENTRY_S {
    UI32_T trunc_size;
    UI32_T bs_level;
    UI32_T refresh_token;
    UI32_T layer1_meter_add_token;
    UI32_T packet;
    UI32_T valid;
    UI32_T bs_level_enable;
} HAL_MIR_METER_ENTRY_T;

typedef struct HAL_MIR_DEST_SEG_SRV_S {
    UI32_T seg;
    UI32_T is_single_tag;
    CLX_PORT_BITMAP_T local_ports;
} HAL_MIR_DEST_SEG_SRV_T;

typedef struct HAL_MIR_WARM_DEST_SEG_SRV_S {
    UI32_T seg;
    UI32_T is_single_tag;
    UI32_T local_ports[CLX_BITMAP_SIZE(160)];
} HAL_MIR_WARM_DEST_SEG_SRV_T;

typedef struct HAL_MIR_SESSION_S {
    UI32_T valid;                      /* is allocated */
    CLX_MIR_TYPE_T mir_type;           /* mirror type  */
    CLX_PORT_T port;                   /* Destination port/lag */
    HAL_MIR_METER_ENTRY_T meter_entry; /* for CL8360 E1 */
    UI32_T init_seq_num;               /* register write only */
} HAL_MIR_SESSION_T;

typedef struct HAL_MIR_ERSPAN_TERM_S {
    CLX_IP_ADDR_T src_ip;
    CLX_IP_ADDR_T dst_ip;
    UI32_T erspan_id;
    UI32_T session_vld;
    UI32_T session_id;
    UI32_T srv_intf_id; /* HAL_INVALID_ID means entry invalid */
    UI16_T vrfo;        /* Vrf id of the underlay network. CL8600 only */
} HAL_MIR_ERSPAN_TERM_T;

typedef struct HAL_MIR_SEL_FLW_S {
    UI32_T enable;
    CLX_SWC_HASH_TYPE_T hash_type; /* only support CLX_SWC_HASH_TYPE_LAG */
    UI32_T hash_value;
    UI32_T hash_mask;
    UI32_T src_port;
    UI32_T mir_id;
    UI32_T flags; /* CLX_SWC_SELECTIVE_FLOW_FLAGS_XXX */
} HAL_MIR_SEL_FLW_T;

typedef struct HAL_MIR_CB_S {
    CLX_SEMAPHORE_ID_T sema;
    HAL_MIR_SESSION_T session[HAL_MIR_SESSION_ENTRY_NUM];
    HAL_MIR_ERSPAN_TERM_T erspan_term[HAL_MIR_ERSPAN_TERM_NUM];
    UI32_T dest_srv_intf_id; /* mirror destination */
    UI32_T miss_srv_intf_id; /* erspan miss action */
                             /* for rspan/erspan term */
    UI32_T term_srv_intf_id[HAL_MIR_SESSION_ID_NUM + 1];
    UI32_T meter_add_token;
    /* for destination seg srv intf */
    HAL_MIR_DEST_SEG_SRV_T dest_seg_srv[HAL_MIR_SESSION_ENTRY_NUM];
    UI32_T lag_member_auto_update;
    HAL_MIR_SEL_FLW_T select_flow;
} HAL_MIR_CB_T;

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init Mirror module.
 *
 * @param [in]     unit    - Device unit index.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Init fail.
 */
CLX_ERROR_NO_T
hal_mir_init(const UI32_T unit);

/**
 * @brief De-init Mirror module.
 *
 * @param [in]     unit    - Device unit index.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - De-init fail.
 */
CLX_ERROR_NO_T
hal_mir_deinit(const UI32_T unit);

/**
 * @brief This API is used to create a mirror session.
 *
 * @param [in]     unit           - Device unit ID.
 * @param [in]     ptr_session    - The session information.
 * @return         CLX_E_OK               - Operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - The session has been created.
 */
CLX_ERROR_NO_T
hal_mir_addSession(const UI32_T unit, const CLX_MIR_SESSION_T *ptr_session);

/**
 * @brief This API is used to delete a mirror session.
 *
 * Before deleting a mirror session, mirror sources bound to the session
 * should be first removed.
 *
 * @param [in]     unit          - Device unit ID.
 * @param [in]     session_id    - Mirror session ID, the range is 0-7.
 * @param [in]     direction     - Mirror session direction.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
CLX_ERROR_NO_T
hal_mir_delSession(const UI32_T unit, const UI8_T session_id, const CLX_MIR_DIRECTION_T direction);

/**
 * @brief This API is used to get mirror session information.
 *
 * User must specify the session_id, direction, mirror_mode in (ptr_session).
 *
 * @param [in]     unit           - Device unit id.
 * @param [out]    ptr_session    - The informations of this session to be obtained.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
CLX_ERROR_NO_T
hal_mir_getSession(const UI32_T unit, CLX_MIR_SESSION_T *ptr_session);

/**
 * @brief This API is used to add a physical port as mirror session source or remove a
 *        physical port from mirror session source.
 *        User should specify the physical port ID, mirror session bitmap.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     port                  - Port ID
 * @param [in]     dir                   - Ingress or egress mirror session
 * @param [in]     mir_session_bitmap    - Mirror session bitmap
 * @return         CLX_E_OK                 - Operation is success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created
 */
CLX_ERROR_NO_T
hal_mir_setMirSrcPort(const UI32_T unit,
                      const UI32_T port,
                      const CLX_DIR_T dir,
                      const UI32_T mir_session_bitmap);

/**
 * @brief This API is used to get the mirror session bitmap bound to a port.
 *
 * @param [in]     unit                      - Device unit ID.
 * @param [in]     port                      - The physical port ID.
 * @param [in]     dir                       - Ingress or egress mirror session
 * @param [out]    ptr_mir_session_bitmap    - The mirror session is bound to the specified
 *                                             physical port on specified direction.
 *                                             If bit 0 is set, it means that the mirror
 *                                             session 0 is bound to the port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created
 */
CLX_ERROR_NO_T
hal_mir_getMirSrcPort(const UI32_T unit,
                      const UI32_T port,
                      const CLX_DIR_T dir,
                      UI32_T *ptr_mir_session_bitmap);

/**
 * @brief This API is used to add an erpsan term.
 *
 * @param [in]     unit                    - Device unit ID.
 * @param [in]     ptr_erspan_term_cfg    - The erspan termination information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
CLX_ERROR_NO_T
hal_mir_addErspanTerm(const UI32_T unit, const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

/**
 * @brief This API is used to delete an erpsan term.
 *
 * @param [in]     unit                    - Device unit ID.
 * @param [in]     ptr_erspan_term_cfg    - The erspan termination information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
CLX_ERROR_NO_T
hal_mir_delErspanTerm(const UI32_T unit, const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

/**
 * @brief This API is used to get an erspan term information.
 *
 * @param [in]     unit                    - Device unit ID.
 * @param [in]     ptr_erspan_term_cfg    - The erspan termination information.
 * @param [out]     ptr_erspan_term_cfg    - The erspan termination information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
CLX_ERROR_NO_T
hal_mir_getErspanTerm(const UI32_T unit, CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

/**
 * @brief This API is used to traverse erspan term information.
 *
 * @param [in]     unit                    - Device unit ID.
 * @param [in]     callback                - The callback function of type
 * CLX_MIR_ERSPAN_TERM_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie              - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie              - The cookie data as output parameter of callback
 * function
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
CLX_ERROR_NO_T
hal_mir_traverseErspanTerm(const UI32_T unit,
                           const CLX_MIR_ERSPAN_TERM_TRAVERSE_FUNC_T callback,
                           void *ptr_cookie);

/**
 * @brief This API is used to configure ERSPAN term miss action.
 *
 * @param [in]     unit           - Device unit ID
 * @param [in]     miss_action    - ERSPAN term miss action
 * @return         CLX_E_OK               - Operation is successful
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mir_setErspanTermMissAction(const UI32_T unit, const UI32_T miss_action);

/**
 * @brief This API is used to get ERSPAN term miss action.
 *
 * @param [in]     unit               - Device unit id
 * @param [out]    ptr_miss_action    - ERSPAN term miss action
 * @return         CLX_E_OK               - Operation is successful
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mir_getErspanTermMissAction(const UI32_T unit, UI32_T *ptr_miss_action);

/**
 * @brief Set mirror meter layer mode (global).
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     layer_mode    - The mirror meter layer mode.
 *                                 1 - layer 1; 0 - layer 2
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mir_setMeterLayer(const UI32_T unit, const UI32_T layer_mode);

/**
 * @brief Get mirror meter layer mode (global).
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_layer_mode    - The mirror meter layer mode.
 *                                     1 - layer 1; 0 - layer 2
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mir_getMeterLayer(const UI32_T unit, UI32_T *ptr_layer_mode);

/**
 * @brief This API is used to check mirror bmp.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     session_bmp    - mirror session bmp
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mir_isSessionBmpValid(const UI32_T unit, const UI32_T session_bmp);

/**
 * @brief This API is used to trans mirror bmp to id.
 *
 * @param [in]     session_bmp    - mirror session bmp
 * @param [out]    ptr_session_id - mirror session id
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mir_transSessionBmp2Id(const UI32_T session_bmp, UI32_T *ptr_session_id);

/**
 * @brief This API is used to trans mirror bmp to id.
 *
 * @param [in]     unit - Device unit number
 * @param [in]     session_id - mirror session id
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mir_isSessionIdValid(const UI32_T unit, const UI32_T session_id);

/**
 * @brief This API is used to update monitor lag port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     event       - Lag port change event
 * @param [in]     lag_port    - Change lag port
 */
void
hal_mir_updateLagPortEvent(const UI32_T unit, const UI32_T event, const CLX_PORT_T lag_port);

/**
 * @brief This API is used to get mirror control block.
 *
 * @param [in]     unit    - Device unit number
 * @return    mirror control block
 */
HAL_MIR_CB_T *
hal_mir_getCb(const UI32_T unit);

/**
 * @brief To set selective flow config
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_select_cfg      - Selective flow config
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         CLX_E_BAD_PARAMETER     - Bad parameter
 */
CLX_ERROR_NO_T
hal_mir_setSelectiveFlowMir(const UI32_T unit, const CLX_SWC_SELECTIVE_FLOW_CFG_T *ptr_select_cfg);

/**
 * @brief To get selective flow config
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [out]    ptr_select_cfg      - Selective flow config
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         CLX_E_BAD_PARAMETER     - Bad parameter
 */
CLX_ERROR_NO_T
hal_mir_getSelectiveFlowMir(const UI32_T unit, CLX_SWC_SELECTIVE_FLOW_CFG_T *ptr_select_cfg);

#endif /* end of HAL_MIR_H */
