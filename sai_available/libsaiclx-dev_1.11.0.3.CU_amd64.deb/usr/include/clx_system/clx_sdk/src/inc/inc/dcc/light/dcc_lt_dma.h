/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  dcc_lt_dma.h
 * PURPOSE:
 *  1. Provide the access interfaces of DMA and CLD DMA to chip Device Control Command(DCC_LT).
 *  2. Define DCC_LT DMA and CLD DMA related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_LT_DMA_H
#define DCC_LT_DMA_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <dcc/dcc_dma.h>
#include <dcc/light/dcc_lt.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DCC_LT constant definition */
#define DCC_LT_DMA_BYTES_PER_WORD    (4)
#define DCC_LT_MAX_DMA_MOVE_DATA_LEN (8 * 1024)      /* 8KB */
#define DCC_LT_CLD_MAX_TASK          (512)           /* CLD DMA has 512 tasks */
#define DCC_LT_CLD_INT_REG_WIDTH     (32)            /* Each register is a word, 32 bits */
#define DCC_LT_CLD_INT_REG_CNT \
    (DCC_LT_CLD_MAX_TASK / DCC_LT_CLD_INT_REG_WIDTH) /* 32 task status per reg */
#define DCC_LT_DMA_HTOD_TRIGGER_OFFSET      (0)
#define DCC_LT_DMA_DTOH_TRIGGER_OFFSET      (2)
#define DCC_LT_DMA_DTOD_TRIGGER_OFFSET      (5)
#define DCC_LT_CLD_CMD_TRIGGER_OFFSET       (4)
#define DCC_LT_CMD_TRIGGER_OFFSET           (10)
#define DCC_LT_DMA_DTOD_TCAM_TRIGGER_OFFSET (11)
#define DCC_LT_CLD_TMR_PRD_VALUE            (1024)
#define DCC_LT_CLD_TMR_PRD_WIDTH            (16)
#define DCC_LT_CLD_TMR_PRD_OFFSET           (0)
#define DCC_LT_CLD_CTL_ENABLE_OFFSET        (0)
#define DCC_LT_CLD_CTL_REPEAT_OFFSET        (8)
#define DCC_LT_CLD_CTL_EXP_VALUE            (1)
#define DCC_LT_CLD_CTL_EXP_WIDTH            (4)
#define DCC_LT_CLD_CTL_EXP_OFFSET           (16)
#define DCC_LT_DMA_ENTRY_LEN_WIDTH          (8)
#define DCC_LT_DMA_ENTRY_NUM_WIDTH          (16)
#define DCC_LT_CLD_ENTRY_LEN_WIDTH          (8)
#define DCC_LT_CLD_ENTRY_NUM_WIDTH          (16)
/* unit of time: us, all times need for further check */
#define DCC_LT_DMA_HTOD_SUSPEND_TIME (2)
#define DCC_LT_DMA_DTOH_SUSPEND_TIME (2)
#define DCC_LT_DMA_DTOD_SUSPEND_TIME (2)
#define DCC_LT_CLD_CMD_SUSPEND_TIME  (2)
#define DCC_LT_DMA_BUSY_POLL_CNT     (10)

/* MACRO FUNCTION DECLARATIONS
 */

#define DCC_LT_INIT_CLD_TASK(task, inst_idx_in, subinst_idx_in, table_id_in, entry_idx_in, \
                             addr_in, ptr_buf_in, entry_len_in, entry_num_in, d_to_h_in,   \
                             callback_in, op_mode_in)                                      \
    do {                                                                                   \
        (task).inst_idx = (inst_idx_in);                                                   \
        (task).subinst_idx = (subinst_idx_in);                                             \
        (task).table_id = (table_id_in);                                                   \
        (task).entry_idx = (entry_idx_in);                                                 \
        (task).addr = (addr_in);                                                           \
        (task).ptr_buf = (ptr_buf_in);                                                     \
        (task).entry_len = (entry_len_in);                                                 \
        (task).entry_num = (entry_num_in);                                                 \
        (task).d_to_h = (d_to_h_in);                                                       \
        (task).callback = (callback_in);                                                   \
        (task).op_mode = (op_mode_in);                                                     \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
#define DCC_LT_DMA_CH_IRQ  (1 << 4)
#define DCC_LT_DMA_CH_UPD  (1 << 5)
#define DCC_LT_DMA_CH_DIR  (1 << 6)
#define DCC_LT_DMA_CH_HTOD (0 << 7)

#ifdef CLX_EN_BIG_ENDIAN
/* DMA command OPD */
typedef union {
    UI32_T reg;
    struct {
        UI32_T opd : 8;
        UI32_T dbeat : 8;
        UI32_T : 4;
        UI32_T doffs : 12;
    } field;
} DCC_LT_DMA_H2D_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T status : 8;
        UI32_T err_code : 8;
        UI32_T num : 16;
    } field;
} DCC_LT_DMA_H2D_CMD_OPD2_REG_T;

/* DMA command OPD */
typedef union {
    UI32_T reg;
    struct {
        UI32_T opd : 8;
        UI32_T dbeat : 8;
        UI32_T : 4;
        UI32_T doffs : 12;
    } field;
} DCC_LT_DMA_D2H_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T status : 8;
        UI32_T err_code : 8;
        UI32_T num : 16;
    } field;
} DCC_LT_DMA_D2H_CMD_OPD2_REG_T;

/* DMA command OPD */
typedef union {
    UI32_T reg;
    struct {
        UI32_T opd : 8;
        UI32_T dbeat : 8;
        UI32_T : 4;
        UI32_T doffs : 12;
    } field;
} DCC_LT_DMA_D2D_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T status : 8;
        UI32_T err_code : 8;
        UI32_T num : 16;
    } field;
} DCC_LT_DMA_D2D_CMD_OPD2_REG_T;
#else
/* DMA command OPD */
typedef union {
    UI32_T reg;
    struct {
        UI32_T doffs : 12;
        UI32_T : 4;
        UI32_T dbeat : 8;
        UI32_T opd : 8;
    } field;
} DCC_LT_DMA_H2D_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T num : 16;
        UI32_T err_code : 8;
        UI32_T status : 8;
    } field;
} DCC_LT_DMA_H2D_CMD_OPD2_REG_T;

/* DMA command OPD */
typedef union {
    UI32_T reg;
    struct {
        UI32_T doffs : 12;
        UI32_T : 4;
        UI32_T dbeat : 8;
        UI32_T opd : 8;
    } field;
} DCC_LT_DMA_D2H_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T num : 16;
        UI32_T err_code : 8;
        UI32_T status : 8;
    } field;
} DCC_LT_DMA_D2H_CMD_OPD2_REG_T;

/* DMA command OPD */
typedef union {
    UI32_T reg;
    struct {
        UI32_T doffs : 12;
        UI32_T : 4;
        UI32_T dbeat : 8;
        UI32_T opd : 8;
    } field;
} DCC_LT_DMA_D2D_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T num : 16;
        UI32_T err_code : 8;
        UI32_T status : 8;
    } field;
} DCC_LT_DMA_D2D_CMD_OPD2_REG_T;
#endif

typedef struct {
    /* Host to device */
    UI32_T htod_haddr_mmio_addr;
    UI32_T htod_haddrh_mmio_addr;
    UI32_T htod_daddr_mmio_addr;
    UI32_T htod_cmd_opd_mmio_addr;
    UI32_T htod_cmd_opd2_mmio_addr;
    UI32_T htod_hsta_adr_mmio_addr;
    UI32_T htod_hsta_adrh_mmio_addr;
    /* Device to host */
    UI32_T dtoh_haddr_mmio_addr;
    UI32_T dtoh_haddrh_mmio_addr;
    UI32_T dtoh_daddr_mmio_addr;
    UI32_T dtoh_cmd_opd_mmio_addr;
    UI32_T dtoh_cmd_opd2_mmio_addr;
    UI32_T dtoh_hsta_adr_mmio_addr;
    UI32_T dtoh_hsta_adrh_mmio_addr;
    /* Device to device */
    UI32_T dtod_src_daddr_mmio_addr;
    UI32_T dtod_dst_daddr_mmio_addr;
    UI32_T dtod_cmd_opd_mmio_addr;
    UI32_T dtod_cmd_opd2_mmio_addr;
    UI32_T dtod_hsta_adr_mmio_addr;
    UI32_T dtod_hsta_adrh_mmio_addr;
    /* uP control */
    UI32_T upctl_dev_int_set_mmio_addr;
    UI32_T upctl_up_hsterr_int_en_mmio_addr;
    UI32_T upctl_up_hsterr_int_mask_mmio_addr;
    UI32_T upctl_up_hsterr_int_clr_mmio_addr;
    UI32_T upctl_up_hsterr_int_stat_mmio_addr;
    UI32_T upctl_upctl_info1_mmio_addr;
} DCC_LT_DMA_MMIO_ADDR_CB_T;

typedef struct {
    UI32_T max_entry_len;
    UI32_T max_entry_num;
    UI32_T max_dma_len;
} DCC_LT_DMA_DMA_ATTRIB_T;

/* DCC_LT CLD DMA command operand structure */

#define DCC_LT_CLD_CH_IRQ  (1 << 4)
#define DCC_LT_CLD_CH_FUPD (1 << 5)
#define DCC_LT_CLD_CH_HTOD (1 << 7)

typedef CLX_ERROR_NO_T (*DCC_LT_CLD_FUNC_T)(const UI32_T unit, const UI32_T task_id);

#ifdef CLX_EN_BIG_ENDIAN
/* Task command2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T cmd : 8;
        UI32_T : 8;
        UI32_T opd2 : 16;
    } field;
} DCC_LT_CLD_TASK_CMD2_REG_T;

/* Task command1 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T : 16;
        UI32_T opd1 : 16;
    } field;
} DCC_LT_CLD_TASK_CMD1_REG_T;

/* DMA command OPD */
typedef union {
    UI32_T reg;
    struct {
        UI32_T opd : 8;
        UI32_T dbeat : 8;
        UI32_T : 4;
        UI32_T doffs : 12;
    } field;
} DCC_LT_CLD_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T status : 8;
        UI32_T err_code : 8;
        UI32_T num : 16;
    } field;
} DCC_LT_CLD_CMD_OPD2_REG_T;

/* TASK_STA_FAIL_IDX */
typedef union {
    UI32_T reg;
    struct {
        UI32_T : 16;
        UI32_T task_sta_fail_idx : 16;
    } field;
} DCC_LT_CLD_TASK_STA_FAIL_IDX_REG_T;
#else
/* Task command2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T opd2 : 16;
        UI32_T : 8;
        UI32_T cmd : 8;
    } field;
} DCC_LT_CLD_TASK_CMD2_REG_T;

/* Task command1 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T opd1 : 16;
        UI32_T : 16;
    } field;
} DCC_LT_CLD_TASK_CMD1_REG_T;

/* DMA command OPD */
typedef union {
    UI32_T reg;
    struct {
        UI32_T doffs : 12;
        UI32_T : 4;
        UI32_T dbeat : 8;
        UI32_T opd : 8;
    } field;
} DCC_LT_CLD_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union {
    UI32_T reg;
    struct {
        UI32_T num : 16;
        UI32_T err_code : 8;
        UI32_T status : 8;
    } field;
} DCC_LT_CLD_CMD_OPD2_REG_T;

/* TASK_STA_FAIL_IDX */
typedef union {
    UI32_T reg;
    struct {
        UI32_T task_sta_fail_idx : 16;
        UI32_T : 16;
    } field;
} DCC_LT_CLD_TASK_STA_FAIL_IDX_REG_T;
#endif

typedef struct {
    UI32_T task_cmd2_mmio_addr;
    UI32_T task_cmd1_mmio_addr;
    UI32_T haddr_mmio_addr;
    UI32_T haddrh_mmio_addr;
    UI32_T daddr_mmio_addr;
    UI32_T cmd_opd_mmio_addr;
    UI32_T cmd_opd2_mmio_addr;
    UI32_T task_sta_fail_idx_mmio_addr;
    /* uP control */
    UI32_T upctl_uptst_rw_1_mmio_addr;
    UI32_T upctl_tmr0_ctl0_mmio_addr;
    UI32_T upctl_tmr0_ctl1_mmio_addr;
    UI32_T upctl_dev_int_set_mmio_addr;
    UI32_T upctl_up_comm_clr_mmio_addr[DCC_LT_CLD_INT_REG_CNT];
    UI32_T upctl_up_comm_sta_mmio_addr[DCC_LT_CLD_INT_REG_CNT];
} DCC_LT_CLD_MMIO_ADDR_CB_T;

typedef struct {
    UI32_T ctrl_mmio_addr;
    UI32_T rsp_mmio_addr;
    UI32_T data_mmio_addr;
} DCC_LT_CMD_MMIO_ADDR_CB_T;

typedef struct {
    UI32_T max_entry_len;
    UI32_T max_entry_num;
    UI32_T max_dma_len;
} DCC_LT_CLD_DMA_ATTRIB_T;

/* DCC_LT CLD DMA command structure */
typedef struct DCC_LT_CLD_CMD_S {
    DCC_LT_CLD_TASK_CMD2_REG_T cmd2; /* 1st word:     command type and opd2     */
    DCC_LT_CLD_TASK_CMD1_REG_T cmd1; /* 2nd word:     command opd1              */
    DCC_LT_HOST_ADDR_T haddr;        /* 3rd/4th word: host address              */
    UI32_T daddr;                    /* 5th word:     device addres             */
    DCC_LT_CLD_CMD_OPD_REG_T opd;    /* 6th word:     flags, dbeat, and doffs   */
    DCC_LT_CLD_CMD_OPD2_REG_T opd2;  /* 7th word:     status, err code, and num */
} DCC_LT_CLD_CMD_T;

/* DCC_LT DMA channel control block structure */
typedef struct {
    /* channel OS resource */
    CLX_SEMAPHORE_ID_T htod_protect_sema; /* channel protection semaphore */
    CLX_SEMAPHORE_ID_T dtoh_protect_sema; /* channel protection semaphore */
    CLX_SEMAPHORE_ID_T dtod_protect_sema; /* channel protection semaphore */

    volatile void *ptr_htod_status_buf;   /* point to dma mem to save htod execution status */
    volatile void *ptr_dtoh_status_buf;   /* point to dma mem to save dtoh execution status */
    volatile void *ptr_dtod_status_buf;   /* point to dma mem to save dtoh execution status */

    /* channel operation mode */
    DCC_LT_CH_OP_MODE_T htod_op_mode; /* operation is polling or interrupt */
    UI32_T htod_op_timeout_cnt;       /* time-out count while channel access operation */

    DCC_LT_CH_OP_MODE_T dtoh_op_mode; /* operation is polling or interrupt */
    UI32_T dtoh_op_timeout_cnt;       /* time-out count while channel access operation */

    DCC_LT_CH_OP_MODE_T dtod_op_mode; /* operation is polling or interrupt */
    UI32_T dtod_op_timeout_cnt;       /* time-out count while channel access operation */

    /* debug counters */
    UI32_T htod_abt_cnt; /* abort count */
    UI32_T htod_err_cnt; /* error count */

    UI32_T dtoh_abt_cnt; /* abort count */
    UI32_T dtoh_err_cnt; /* error count */

    UI32_T dtod_abt_cnt; /* abort count */
    UI32_T dtod_err_cnt; /* error count */

    BOOL_T htod_start;   /* indicate DMA htod channel is executing */
    BOOL_T dtoh_start;   /* indicate DMA dtoh channel is executing */
    BOOL_T dtod_start;   /* indicate DMA dtoh channel is executing */

    /* performance timestamp */
    CLX_TIME_T htod_cmd_start;    /* dma host to device start execution time */
    CLX_TIME_T htod_cmd_stop;     /* dma host to device end execution time */
    CLX_TIME_T htod_cmd_max_time; /* dma host to device command Max execution time */
    CLX_TIME_T htod_cmd_min_time; /* dma host to device command min execution time */

    CLX_TIME_T dtoh_cmd_start;    /* dma device to host start execution time */
    CLX_TIME_T dtoh_cmd_stop;     /* dma device to host end execution time */
    CLX_TIME_T dtoh_cmd_max_time; /* dma device to host command Max execution time */
    CLX_TIME_T dtoh_cmd_min_time; /* dma device to host command min execution time */

    CLX_TIME_T dtod_cmd_start;    /* dma device to device start execution time */
    CLX_TIME_T dtod_cmd_stop;     /* dma device to device end execution time */
    CLX_TIME_T dtod_cmd_max_time; /* dma device to device command Max execution time */
    CLX_TIME_T dtod_cmd_min_time; /* dma device to device command min execution time */

    /* mmio addr control block */
    DCC_LT_DMA_MMIO_ADDR_CB_T mmio_addr_cb;

    /* dma channel attribute */
    DCC_LT_DMA_DMA_ATTRIB_T dma_attrib;
} DCC_LT_DMA_CH_CB_T;

/* DCC_LT CLD DMA channel control block structure */
typedef struct DCC_LT_CLD_CH_CB_S {
    /* uP interrupt control register */
    UI32_T up_comm_reg_stat[DCC_LT_CLD_INT_REG_CNT];  /* uP interrupt status register */
    UI32_T up_comm_reg_clear[DCC_LT_CLD_INT_REG_CNT]; /* uP interrupt clear register */
    /* channel OS resource */
    CLX_SEMAPHORE_ID_T protect_sema;           /* channel protection semaphore */
    UI16_T cld_idx[DCC_LT_CLD_MAX_TASK];       /* calendar array */
    DCC_CLD_TASK_T tasks[DCC_LT_CLD_MAX_TASK]; /* task array */
    volatile CLX_HUGE_T *ptr_task_status;      /* task status array, pointer to DMA memory */
    UI16_T next_avail_task_id;                 /* next available task ID to assign */
    BOOL_T up_redownload;                      /* indecate uP of CLD DMA need to be redownload
                                                * TRUE: CLD DMA needs to redownload uP
                                                * FALSE: CLD DMA does not need to redownload uP
                                                */
    /* debug counters */
    UI32_T rst_cnt_htod; /* reset count */
    UI32_T rst_cnt_dtoh; /* reset count */
    UI32_T err_cnt_htod; /* error count */
    UI32_T err_cnt_dtoh; /* error count */
    UI32_T err_cnt_cmd;  /* error count */

    /* performance timestamp */
    CLX_TIME_T cmd_start;
    CLX_TIME_T cmd_stop;

    /* mmio addr control block */
    DCC_LT_CLD_MMIO_ADDR_CB_T mmio_addr_cb;

    /* cld channel attribute */
    DCC_LT_CLD_DMA_ATTRIB_T dma_attrib;
} DCC_LT_CLD_CH_CB_T;

typedef struct DCC_LT_CMD_CH_CB_S {
    CLX_SEMAPHORE_ID_T protect_sema;
    BOOL_T cmd_start;

    UI32_T seq_num;

    /* performance timestamp */
    CLX_TIME_T cmd_start_time;
    CLX_TIME_T cmd_stop_time;

    /* mmio addr control block */
    DCC_LT_CMD_MMIO_ADDR_CB_T mmio_addr_cb;

} DCC_LT_CMD_CH_CB_T;

/**
 * @brief dcc_lt_dma_initDmaRsrc() is responsible for resource of DCC_LT DMA initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_dma_initDmaRsrc(const UI32_T unit);

/**
 * @brief dcc_lt_dma_initCldRsrc() is responsible for resource of DCC_LT CLD initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_dma_initCldRsrc(const UI32_T unit);

/**
 * @brief dcc_lt_dma_initDmaThread() is responsible for thread of DCC_LT DMA initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_dma_initDmaThread(const UI32_T unit);

/**
 * @brief dcc_lt_dma_initCldThread() is responsible for thread of DCC_LT CLD initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_dma_initCldThread(const UI32_T unit);

/**
 * @brief dcc_lt_dma_deinitDmaRsrc() is responsible for resource of DCC_LT DMA deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
/* dcc_lt channel deinit */
CLX_ERROR_NO_T
dcc_lt_dma_deinitDmaRsrc(const UI32_T unit);

/**
 * @brief dcc_lt_dma_deinitCldRsrc() is responsible for resource of DCC_LT DMA deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_dma_deinitCldRsrc(const UI32_T unit);

/**
 * @brief dcc_lt_dma_deinitDmaThread() is responsible for thread of DCC_LT DMA deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_dma_deinitDmaThread(const UI32_T unit);

/**
 * @brief dcc_lt_dma_deinitCldThread() is responsible for thread of DCC_LT CLD deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_dma_deinitCldThread(const UI32_T unit);

/**
 * @brief dcc_lt_dma_showDmaChannelInfo() is a function to display DCC_LT DMA channel information.
 *
 * @param [in]     unit    - The specified unit number.
 */
void
dcc_lt_dma_showDmaChannelInfo(const UI32_T unit);

/**
 * @brief dcc_lt_dma_writeTbl() is a function to move table data from host to device.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_src_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred
 * @param [in]     entry_num      - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully write data from host to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to write data from host to device
 */
CLX_ERROR_NO_T
dcc_lt_dma_writeTbl(const UI32_T unit,
                    void *ptr_src_buf,
                    const UI32_T addr,
                    const UI32_T entry_len,
                    const UI32_T entry_num);

/**
 * @brief dcc_lt_dma_readTbl() is a function to move table data from device to host.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_dst_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred
 * @param [in]     entry_num      - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully read data from device to host
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to host
 */
CLX_ERROR_NO_T
dcc_lt_dma_readTbl(const UI32_T unit,
                   void *ptr_dst_buf,
                   const UI32_T addr,
                   const UI32_T entry_len,
                   const UI32_T entry_num);

/**
 * @brief dcc_lt_dma_copyTbl() is a function to copy table data from device to device.
 *
 * @param [in]     unit         - The specified unit number.
 * @param [in]     src_addr     - The start address of source device table address for DMA transfer.
 * This address should be a valid address inside chip.
 * @param [in]     dst_addr     - The start address of destination device table address for DMA
 * transfer.
 * @param [in]     dir          - The direction order for copy data.
 * @param [in]     entry_len    - The length of an entry is going to be transferred.
 * @param [in]     entry_num    - Number of entries are going to be transferred.
 * @return         CLX_E_OK               - Successfully copy data from device to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to device
 */
CLX_ERROR_NO_T
dcc_lt_dma_copyTbl(const UI32_T unit,
                   const UI32_T src_addr,
                   const UI32_T dst_addr,
                   const DCC_DMA_D2D_DIR_T dir,
                   const UI32_T entry_len,
                   const UI32_T entry_num);

/**
 * @brief dcc_lt_dma_copyTcam() is a function to copy tcam table data from device to device.
 *
 * @param [in]     unit         - The specified unit number.
 * @param [in]     src_addr     - The start address of source device table address for DMA transfer.
 * This address should be a valid address inside chip.
 * @param [in]     dst_addr     - The start address of destination device table address for DMA
 * transfer.
 * @param [in]     dir          - The direction order for copy data.
 * @param [in]     entry_len    - The length of an entry is going to be transferred.
 * @param [in]     entry_num    - Number of entries are going to be transferred.
 * @return         CLX_E_OK               - Successfully copy data from device to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to device
 */
CLX_ERROR_NO_T
dcc_lt_dma_copyTcam(const UI32_T unit,
                    const UI32_T src_addr,
                    const UI32_T dst_addr,
                    const DCC_DMA_D2D_DIR_T dir,
                    const UI32_T entry_len,
                    const UI32_T entry_num);

/**
 * @brief dcc_lt_dma_setDmaHToDOperationMode() is a function to change DCC_LT host to device DMA
 * channel operation mode to be poll or interrupt.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     op_mode    - The DMA channel operation mode, valid are:
 *                              1. DCC_LT_CH_OP_MODE_POLL
 *                              2. DCC_LT_CH_OP_MODE_INTR
 * @return         CLX_E_OK        - Set DMA channel operation mode successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation mode.
 */
CLX_ERROR_NO_T
dcc_lt_dma_setDmaHToDOperationMode(const UI32_T unit, const DCC_LT_CH_OP_MODE_T op_mode);

/**
 * @brief dcc_lt_dma_setDmaDToHOperationMode() is a function to change DCC_LT device to host DMA
 * channel operation mode to be poll or interrupt.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     op_mode    - The DMA channel operation mode, valid are:
 *                              1. DCC_LT_CH_OP_MODE_POLL
 *                              2. DCC_LT_CH_OP_MODE_INTR
 * @return         CLX_E_OK        - Set DMA channel operation mode successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation mode.
 */
CLX_ERROR_NO_T
dcc_lt_dma_setDmaDToHOperationMode(const UI32_T unit, const DCC_LT_CH_OP_MODE_T op_mode);

/**
 * @brief dcc_lt_dma_setDmaDToDOperationMode() is a function to change DCC_LT device to device DMA
 * channel operation mode to be poll or interrupt.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     op_mode    - The DMA channel operation mode, valid are:
 *                              1. DCC_LT_CH_OP_MODE_POLL
 *                              2. DCC_LT_CH_OP_MODE_INTR
 * @return         CLX_E_OK        - Set DMA channel operation mode successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation mode.
 */
CLX_ERROR_NO_T
dcc_lt_dma_setDmaDToDOperationMode(const UI32_T unit, const DCC_LT_CH_OP_MODE_T op_mode);

/**
 * @brief dcc_lt_dma_setDmaHToDOperationTimeoutCnt() is a function to change DCC_LT host to device
 * DMA channel operation time-out count.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     timeout_cnt    - The DMA channel operation time-out count for polling mode.
 * @return         CLX_E_OK        - Set DMA channel operation time-out count successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation time-out count.
 */
CLX_ERROR_NO_T
dcc_lt_dma_setDmaHToDOperationTimeoutCnt(const UI32_T unit, const UI32_T timeout_cnt);

/**
 * @brief dcc_lt_dma_setDmaDToHOperationTimeoutCnt() is a function to change DCC_LT device to host
 * DMA channel operation time-out count.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     timeout_cnt    - The DMA channel operation time-out count for polling mode.
 * @return         CLX_E_OK        - Set DMA channel operation time-out count successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation time-out count.
 */
CLX_ERROR_NO_T
dcc_lt_dma_setDmaDToHOperationTimeoutCnt(const UI32_T unit, const UI32_T timeout_cnt);

/**
 * @brief dcc_lt_dma_setDmaDToDOperationTimeoutCnt() is a function to change DCC_LT device to device
 * DMA channel operation time-out count.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     timeout_cnt    - The DMA channel operation time-out count for polling mode.
 * @return         CLX_E_OK        - Set DMA channel operation time-out count successfully.
 * @return         CLX_E_OTHERS    - Fail to set DMA channel operation time-out count.
 */
CLX_ERROR_NO_T
dcc_lt_dma_setDmaDToDOperationTimeoutCnt(const UI32_T unit, const UI32_T timeout_cnt);

/**
 * @brief dcc_lt_dma_showCldChannelInfo() is a function to display DCC_LT CLD DMA channel
 * information.
 *
 * @param [in]     unit    - The specified unit number.
 */

void
dcc_lt_dma_showCldChannelInfo(const UI32_T unit);

/**
 * @brief dcc_lt_dma_setCldMode() is a function to set DCC_LT CLD DMA uP operation mode
 *
 * @param [in]     unit        - The specified unit number.
 * @param [in]     period      - Significant part of each task interval (1 ~ 65535)
 * @param [in]     exponent    - Exponent part of each task interval (2^exponent, 0 ~ 15)
 *                               -- The exact time interval is period
 * @param [in]     enable      - Enable CLD DMA
 * @param [in]     repeat      - Enable automatic repeat after all tasks complete
 * @return         CLX_E_OK               - Set uP operation mode successfully
 * @return         CLX_E_BAD_PARAMETER    - Invalid exponent parameter
 * @return         CLX_E_OTHERS           - Fail to set uP operation mode
 */

CLX_ERROR_NO_T
dcc_lt_dma_setCldMode(const UI32_T unit,
                      const UI32_T period,
                      const UI32_T exponent,
                      const BOOL_T enable,
                      const BOOL_T repeat);

/*
 * PURPOSE:
 *      dcc_lt_dma_addCldTask() is a function to add a calendar DMA task
 *
 * INPUT:
 *      unit                  -- The specified unit number
 *      ptr_task              -- Pointer to detailed task info
 * OUTPUT:
 *      ptr_task_id           -- task_id assigned to the new task
 * RETURN:
 *      CLX_E_OK              -- Task is successfully added into system
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_TABLE_FULL      -- Task table full, cannot add a new task
 *      CLX_E_OTHERS          -- Fail to add task into system due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_lt_dma_addCldTask(const UI32_T unit, const DCC_CLD_TASK_T *ptr_task, UI32_T *ptr_task_id);

/*
 * PURPOSE:
 *      dcc_lt_dma_delCldTask() is a function to delete a calendar DMA task
 *
 * INPUT:
 *      unit                  -- The specified unit number
 *      task_id               -- The task to be deleted
 * OUTPUT:
 *       None
 * RETURN:
 *      CLX_E_OK              -- Task is successfully deleted from system
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_ENTRY_NOT_FOUND -- Task associated with the task_id does not exist
 *      CLX_E_OTHERS          -- Fail to delete task from system due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_lt_dma_delCldTask(const UI32_T unit, const UI32_T task_id);

/**
 * @brief dcc_lt_dma_setCldTaskStatus() is a function to set a task status to the idle/pause state
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     task_id    - The task to be set status
 * @param [in]     state      - The new state of the task, valid settings are
 *                              1. DCC_CLD_STAT_IDLE
 *                              2. DCC_CLD_STAT_PAUSE
 * @return         CLX_E_OK                 - Task status is successfully set
 * @return         CLX_E_BAD_PARAMETER      - Input parameter has error configuration or value
 * @return         CLX_E_ENTRY_NOT_FOUND    - Task associated with the task_id doesn't exist
 * @return         CLX_E_OTHERS             - Fail to set task state due to internal error
 */

CLX_ERROR_NO_T
dcc_lt_dma_setCldTaskStatus(const UI32_T unit, const UI32_T task_id, const DCC_CLD_STAT_T state);

/**
 * @brief dcc_lt_dma_getCldTaskStatus() is a function to get a task's current status
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     task_id       - The task to be queried
 * @param [out]    ptr_status    - Status of the task under study
 * @return         CLX_E_OK                 - Task status is successfully obtained
 * @return         CLX_E_BAD_PARAMETER      - Input parameter has error configuration or value
 * @return         CLX_E_ENTRY_NOT_FOUND    - Task associated with the task_id doesn't exist
 * @return         CLX_E_OTHERS             - Fail to read task status due to internal error
 */

CLX_ERROR_NO_T
dcc_lt_dma_getCldTaskStatus(const UI32_T unit, const UI32_T task_id, DCC_CLD_STAT_T *ptr_status);

/**
 * @brief dcc_lt_dma_showCldTaskInfo() is a function to show DCC_LT CLD DMA task information.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     task_id    - task_id of the task under study
 */

CLX_ERROR_NO_T
dcc_lt_dma_showCldTaskInfo(const UI32_T unit, const UI32_T task_id);

/**
 * @brief dcc_lt_dma_dmaUpError() is a function to handle dma up error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK        - handle tdma uP error successfully
 * @return         CLX_E_OTHERS    - fail to handle tdma uP error
 */
CLX_ERROR_NO_T
dcc_lt_dma_dmaUpError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_cldStaUpdError() is a function to handle CLD DMA status update error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle cld dma status update error successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_cldStaUpdError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_tdmaStaUpdError() is a function to handle tdma status update error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle tdma status update error successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_tdmaStaUpdError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_cldDmaHtoDError() is a function to handle cld dma device to host error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle cld dma device to host error successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_cldDmaDtoHError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_cldDmaHtoDError() is a function to handle cld dma host to device error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle cld dma host to device error successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_cldDmaHtoDError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_dmaTableHtoDError() is a function to handle host to device tdma error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle tdma host to device error successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_dmaTableHtoDError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_dmaTableDtoHError() is a function to handle device to host tdma error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle tdma device to host error successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_dmaTableDtoHError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_dmaTableDtoDError() is a function to handle device to device tdma error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle tdma device to device error successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_dmaTableDtoDError(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_recoverDmaChannel() is a function to recover DMA channel while DMA uP is
 * damaged.
 *
 * @param [in]     unit        - The specified unit number.
 * @param [in]     dma_type    - The specified dma type, include cld DMA, table DMA write, and table
 * DMA read.
 * @return         CLX_E_OK        - recover Dma channel error successfully
 * @return         CLX_E_OTHERS    - recover Dma channel error failed
 */

CLX_ERROR_NO_T
dcc_lt_dma_recoverDmaChannel(const UI32_T unit, DCC_DMA_TYPE_T dma_type);

/**
 * @brief dcc_lt_dma_recoverDmaDoubleEccError() is a function to handle program memory double bit
 * ECC error for Dma uP.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle cld dma device to host error successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_recoverDmaDoubleEccError(const UI32_T unit, const UI32_T isr_cookie);

/* DMA channel ISR */
CLX_ERROR_NO_T
dcc_lt_dma_cldChIsr(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief dcc_lt_dma_txCmd() is a function to send custom command to DCE uP
 *
 * @param [in]     unit        - The specified unit number
 * @param [in]     cmd         - Custom command ID
 * @param [in]     ptr_data    - Pointer for the user data sent to DCE uP
 * @param [in]     data_len    - Valid word count in ptr_data
 * @return         CLX_E_OK    - Handle the command successfully
 */
CLX_ERROR_NO_T
dcc_lt_dma_txCmd(const UI32_T unit,
                 const DCC_DMA_CMD_T cmd,
                 UI32_T *ptr_data,
                 const UI32_T data_len); /* in word */
#endif                                   /* END of DCC_LT_H*/
