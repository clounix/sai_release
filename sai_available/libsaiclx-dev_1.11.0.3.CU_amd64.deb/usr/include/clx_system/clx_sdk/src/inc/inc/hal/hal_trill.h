/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_trill.h
 * PURPOSE:
 *  Define TRILL module HAL function.
 *
 * NOTES:
 *
 */

#ifndef HAL_TRILL_H
#define HAL_TRILL_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_trill.h>
#include <cmlib/cmlib_avl.h>
#include <hal/hal.h>
#include <hal/hal_vlan.h>
#include <hal/hal_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_TRILL_VL_MIN           (1)
#define HAL_TRILL_VL_MAX           (4094)
#define HAL_TRILL_FGL_MIN          (0)
#define HAL_TRILL_FGL_MAX          (4095)
#define HAL_TRILL_SEG_OFFSET       (12)     /* trill vl & fgl_hi */
#define HAL_TRILL_UNKNOWN_NICKNAME (0x0000) /* RFC defined 0x0000 */
#define HAL_TRILL_RSV_NICKNAME     (0xFFC0) /* RFC defined 0xFFC0-0xFFFF */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TRILL_NOT_SUPPORT_FAMILY(__unit__)    \
    (HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) && \
        (HAL_REVISION_ID_E1 == HAL_DEVICE_REV_ID(__unit__))

#define HAL_TRILL_ENABLE(__unit__) \
    ((HAL_TRILL_NOT_SUPPORT_FAMILY(__unit__)) ? 0 : _ext_hal_trill_cfg_en[(__unit__)])

#define HAL_TRILL_CHECK_ENABLE(__unit__)                                               \
    do {                                                                               \
        if (0 == HAL_TRILL_ENABLE(__unit__)) {                                         \
            DIAG_PRINT(HAL_DBG_TRILL, HAL_DBG_WARN, "u=%u, check trill enable failed", \
                       (__unit__));                                                    \
            return CLX_E_OP_INVALID;                                                   \
        }                                                                              \
    } while (0)

#define HAL_TRILL_CHECK_NOT_ENABLE(__unit__)                                                  \
    do {                                                                                      \
        if (0 != HAL_TRILL_ENABLE(__unit__)) {                                                \
            DIAG_PRINT(HAL_DBG_TRILL, HAL_DBG_WARN, "u=%u, not support when trill is enable", \
                       (__unit__));                                                           \
            return CLX_E_OP_INVALID;                                                          \
        }                                                                                     \
    } while (0)

#define HAL_TRILL_IS_TREE_MGID(__mgid__)                        \
    (((__mgid__) >= HAL_MGID_LAG_BASE_ID + HAL_MGID_LAG_MIN) && \
     ((__mgid__) <= HAL_MGID_LAG_BASE_ID + HAL_MGID_LAG_MAX))

#define HAL_TRILL_VL_FGL_TO_SEG(__vl_fgl_hi__, __fgl_low__, __seg__)                      \
    do {                                                                                  \
        HAL_CHECK_MIN_MAX_RANGE((__vl_fgl_hi__), HAL_TRILL_FGL_MIN, HAL_TRILL_FGL_MAX);   \
        (__seg__) = (__vl_fgl_hi__) << HAL_TRILL_SEG_OFFSET;                              \
        if (HAL_INVALID_ID != (__fgl_low__)) {                                            \
            HAL_CHECK_MIN_MAX_RANGE((__fgl_low__), HAL_TRILL_FGL_MIN, HAL_TRILL_FGL_MAX); \
            (__seg__) |= (__fgl_low__);                                                   \
        }                                                                                 \
    } while (0)

#define HAL_TRILL_VL_FGL_TO_IS_SINGLE(__vl_fgl_hi__, __fgl_low__, __is_single__) \
    (__is_single__) = (HAL_INVALID_ID == (__fgl_low__)) ? 1 : 0

#define HAL_TRILL_VL_FGL_TO_VID_NUM(__vl_fgl_hi__, __fgl_low__, __num__)      \
    (__num__) = (HAL_INVALID_ID == (__fgl_low__)) ? HAL_TRILL_HW_VL_VID_NUM : \
                                                    HAL_TRILL_HW_FGL_VID_NUM

/* DATA TYPE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */
extern UI32_T _ext_hal_trill_cfg_en[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Initialize TRILL module.
 *
 * @param [in]     unit            - Device unit number.
 * @return         CLX_E_OK                - Initialize success.
 * @return         CLX_E_OTHERS            - Initialize failed.
 * @return         CLX_E_ALREADY_INITED    - Already iniialized.
 */
CLX_ERROR_NO_T
hal_trill_init(const UI32_T unit);

/**
 * @brief Deinitialize TRILL module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK            - Deinitialize success.
 * @return         CLX_E_OTHERS        - Deinitialize failed.
 * @return         CLX_E_NOT_INITED    - Not initilized.
 */
CLX_ERROR_NO_T
hal_trill_deinit(const UI32_T unit);

/**
 * @brief Assign the nickname for the device
 *
 * 1. User should assign the device nickname before calling other trill APIs.
 * 2. If user doesn't assign the nickname, the default nickname is 0x0000 (unknown).
 * 3. The given nickname should not in the reserved ranged as RFC6325 defined.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     nickname    - Nickname of the device
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
CLX_ERROR_NO_T
hal_trill_setMyNickname(const UI32_T unit, const CLX_TRILL_NICKNAME_T nickname);

/**
 * @brief Get the nickname of the device
 *
 * If user doesn't assign the nickname, the default nickname is 0x0000 (unknown).
 *
 * @param [in]     unit            - Device unit number
 * @param [out]    ptr_nickname    - Nickname of the device
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - User doesn't set the nickname.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
CLX_ERROR_NO_T
hal_trill_getMyNickname(const UI32_T unit, CLX_TRILL_NICKNAME_T *ptr_nickname);

/**
 * @brief Set the forward action for TRILL-related exception.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_action    - Forward action for the exception
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
CLX_ERROR_NO_T
hal_trill_setPktHandling(const UI32_T unit, const CLX_TRILL_PKT_HANDLING_T *ptr_action);

/**
 * @brief Get the forward action for TRILL-related exception.
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    ptr_action    - Forward action for the exception
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
CLX_ERROR_NO_T
hal_trill_getPktHandling(const UI32_T unit, CLX_TRILL_PKT_HANDLING_T *ptr_action);

/**
 * @brief Create a Trill-type tunnel port for unicast Trill tunnel.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     egr_nickname    - Nickname of the remote RB
 * @param [in]     flags           - Option
 * @param [out]    ptr_tnl_port    - Trill-type tunnel port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Tunnel port has already been created.
 */
CLX_ERROR_NO_T
hal_trill_createPort(const UI32_T unit,
                     const CLX_TRILL_NICKNAME_T egr_nickname,
                     const UI32_T flags,
                     CLX_PORT_T *ptr_tnl_port);

/**
 * @brief Destroy a Trill-type tunnel port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     tnl_port    - Trill-type tunnel port
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Tunnel port is not created.
 */
CLX_ERROR_NO_T
hal_trill_destroyPort(const UI32_T unit, const CLX_PORT_T tnl_port);

/**
 * @brief Add a trill-type tunnel initiation as well as initiation properties.
 *        If the tunnel initiation existed, the tunnel initiation properties will be updated.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Keys and properties for tunnel initiation
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Tunnel-port is not created.
 * @return         CLX_E_TABLE_FULL         - Hardware table is full.
 * @return         CLX_E_NO_MEMORY          - No available memory.
 */
CLX_ERROR_NO_T
hal_trill_addInit(const UI32_T unit, const CLX_TRILL_INIT_INFO_T *ptr_info);

/**
 * @brief Delete a trill-type tunnel initiation entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Keys for tunnel initiation
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Tunnel init entry is not added.
 */
CLX_ERROR_NO_T
hal_trill_delInit(const UI32_T unit, const CLX_TRILL_INIT_INFO_T *ptr_info);

/**
 * @brief Get a tunnel initiation entry for trill-type tunnel.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Keys for tunnel initiation
 * @param [out]    ptr_info    - Properties for tunnel initiation
 * @return         CLX_E_OK                 - Operation success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - Tunnel init entry is not added.
 */
CLX_ERROR_NO_T
hal_trill_getInit(const UI32_T unit, CLX_TRILL_INIT_INFO_T *ptr_info);

/**
 * @brief Add a trill-type tunnel termination entry and also set the termination properties.
 *        If the tunnel termination existed, the tunnel termination properties will be updated.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Keys and properties for tunnel termination
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 */
CLX_ERROR_NO_T
hal_trill_addTerm(const UI32_T unit, const CLX_TRILL_TERM_INFO_T *ptr_info);

/**
 * @brief Delete a trill-type tunnel termination entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Keys for tunnel termination
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Tunnel term entry is not added.
 */
CLX_ERROR_NO_T
hal_trill_delTerm(const UI32_T unit, const CLX_TRILL_TERM_INFO_T *ptr_info);

/**
 * @brief Get a tunnel termination properties for trill-type tunnel.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Keys for tunnel termination
 * @param [out]    ptr_info    - Properties for tunnel termination
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Tunnel term entry is not added.
 */
CLX_ERROR_NO_T
hal_trill_getTerm(const UI32_T unit, CLX_TRILL_TERM_INFO_T *ptr_info);

/**
 * @brief Add a service based on multicast trill-type tunnel and segment, either vl or fgl.
 *        If the service existed, the properties will be updated.
 *
 * If igr_nickname is my_nickname, means add the tunnel-init based service property.
 * Otherwise, add the tunnel-term based service property.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     igr_nickname    - Ingress RB nickname
 * @param [in]     egr_nickname    - Tree root nickname
 * @param [in]     vl_fgl_high     - Vl or fgl high-part value
 * @param [in]     fgl_low         - Fgl low-part value (for vl, must fill all one)
 * @param [in]     ptr_srv         - Service Properies
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
hal_trill_addSegService(const UI32_T unit,
                        const CLX_TRILL_NICKNAME_T igr_nickname,
                        const CLX_TRILL_NICKNAME_T egr_nickname,
                        const UI32_T vl_fgl_high,
                        const UI32_T fgl_low,
                        const CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Delete a service based on multicast trill-type tunnel and segment, either vl or fgl.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     igr_nickname    - Ingress RB nickname
 * @param [in]     egr_nickname    - Tree root nickname
 * @param [in]     vl_fgl_high     - Vl or fgl high-part value
 * @param [in]     fgl_low         - Fgl low-part value (for vl, must fill all one)
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Service entry is not added.
 */
CLX_ERROR_NO_T
hal_trill_delSegService(const UI32_T unit,
                        const CLX_TRILL_NICKNAME_T igr_nickname,
                        const CLX_TRILL_NICKNAME_T egr_nickname,
                        const UI32_T vl_fgl_high,
                        const UI32_T fgl_low);

/**
 * @brief Get a service based on multicast trill-type tunnel and segment, either vl or fgl.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     igr_nickname    - Ingress RB nickname
 * @param [in]     egr_nickname    - Tree root nickname
 * @param [in]     vl_fgl_high     - Vl or fgl high-part value
 * @param [in]     fgl_low         - Fgl low-part value (for vl, must fill all one)
 * @param [out]    ptr_srv         - Service Properies
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Service entry is not added.
 */
CLX_ERROR_NO_T
hal_trill_getSegService(const UI32_T unit,
                        const CLX_TRILL_NICKNAME_T igr_nickname,
                        const CLX_TRILL_NICKNAME_T egr_nickname,
                        const UI32_T vl_fgl_high,
                        const UI32_T fgl_low,
                        CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Add a unicast routing information for Trill tunnel init or transit.
 *        If the routing information is existed, the related attributes will be updated.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Address and properties of Trill init/transit route
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
hal_trill_addRoute(const UI32_T unit, const CLX_TRILL_ROUTE_INFO_T *ptr_info);

/**
 * @brief Delete a unicast routing entry with the specific egress nickname and forward type.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Address of Trill init/transit route
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The routing entry has not been added.
 */
CLX_ERROR_NO_T
hal_trill_delRoute(const UI32_T unit, const CLX_TRILL_ROUTE_INFO_T *ptr_info);

/**
 * @brief Get a routing information with the specific egress nickname and forward type.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - Address of Trill init/transit route
 * @param [out]    ptr_info    - Properties of Trill init/transit route
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The routing entry has not been added.
 */
CLX_ERROR_NO_T
hal_trill_getRoute(const UI32_T unit, CLX_TRILL_ROUTE_INFO_T *ptr_info);

/**
 * @brief Add the mcast forwarding information according to the specified condition.
 *        If the forwarding information existed, the attributes will be updated.
 *
 * 1. Should add normal tree before add prune tree.
 * 2. a. init: normal/vlan_tree use the same resource
 * mac/ip_tree use the same resource
 * b. transit : need add bud tree if term exists
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - The mcast forwarding information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - No available entry.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
hal_trill_addTree(const UI32_T unit, const CLX_TRILL_TREE_INFO_T *ptr_info);

/**
 * @brief Delete the mcast forwarding information according to the specified condition and
 * egr_nickname.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - The mcast forwarding information
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The forwarding entry has not been added.
 */
CLX_ERROR_NO_T
hal_trill_delTree(const UI32_T unit, const CLX_TRILL_TREE_INFO_T *ptr_info);

/**
 * @brief Get the mcast forwarding information according to the specified condition and
 * egr_nickname.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_info    - The mcast forwarding information
 * @param [out]    ptr_info    - The mcast forwarding information
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - no available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The forwarding entry has not been added.
 */
CLX_ERROR_NO_T
hal_trill_getTree(const UI32_T unit, CLX_TRILL_TREE_INFO_T *ptr_info);

/**
 * @brief Add a Trill adjacency check entry.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Adjacency check information
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 */
CLX_ERROR_NO_T
hal_trill_addAdjCheckEntry(const UI32_T unit, const CLX_TRILL_ADJ_CHECK_T *ptr_entry);

/**
 * @brief Delete a Trill adjacency check entry
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Adjacency check information
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The entry has not been added.
 */
CLX_ERROR_NO_T
hal_trill_delAdjCheckEntry(const UI32_T unit, const CLX_TRILL_ADJ_CHECK_T *ptr_entry);

/**
 * @brief Check the Trill adjacency check entry exist or not.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Adjacency check information
 * @return         CLX_E_OK                 - The entry exists.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The entry doesn't exist.
 */
CLX_ERROR_NO_T
hal_trill_getAdjCheckEntry(const UI32_T unit, const CLX_TRILL_ADJ_CHECK_T *ptr_entry);

/**
 * @brief Add a Trill RPF check entry.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Rpf check information
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 */
CLX_ERROR_NO_T
hal_trill_addRpfCheckEntry(const UI32_T unit, const CLX_TRILL_RPF_CHECK_T *ptr_entry);

/**
 * @brief Delete a Trill RPF check entry.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Rpf check information
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The entry has not been added.
 */
CLX_ERROR_NO_T
hal_trill_delRpfCheckEntry(const UI32_T unit, const CLX_TRILL_RPF_CHECK_T *ptr_entry);

/**
 * @brief Check the TRILL RPF check entry exist or not.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Rpf check information
 * @return         CLX_E_OK                 - The entry exists.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The entry doesn't exist.
 */
CLX_ERROR_NO_T
hal_trill_getRpfCheckEntry(const UI32_T unit, const CLX_TRILL_RPF_CHECK_T *ptr_entry);

/**
 * @brief Add virtual rb with virtual nickname.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     nickname      - Virtual nickname
 * @param [in]     flags         - Optional flags
 *                                 Please reference CLX_TRILL_VIRTUAL_RB_
 * @param [out]    ptr_rbv_id    - Virtual rb id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_TABLE_FULL       - No available entry
 */
CLX_ERROR_NO_T
hal_trill_addVirtualRb(const UI32_T unit,
                       const CLX_TRILL_NICKNAME_T nickname,
                       const UI32_T flags,
                       UI32_T *ptr_rbv_id);

/**
 * @brief Delete a virtual rb.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     rbv_id    - Virtual rb id
 * @return         CLX_E_OK                 - Entry exists
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry does not exist
 */
CLX_ERROR_NO_T
hal_trill_delVirtualRb(const UI32_T unit, const UI32_T rbv_id);

/**
 * @brief Get virtual nickname with virtual rb id.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     rbv_id      - Virtual rb id
 * @param [out]    ptr_nickname    - Virtual nickname
 * @return         CLX_E_OK                 - Entry exists
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry does not exist
 */
CLX_ERROR_NO_T
hal_trill_getVirtualRb(const UI32_T unit, const UI32_T rbv_id, CLX_TRILL_NICKNAME_T *ptr_nickname);

/**
 * @brief Set TRILL related port properties.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - Port
 * @param [in]     ptr_property    - Port properties
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Operation fail
 */
CLX_ERROR_NO_T
hal_trill_setPortProperty(const UI32_T unit,
                          const CLX_PORT_T port,
                          const CLX_TRILL_PORT_PROPERTY_T *ptr_property);

/**
 * @brief Get TRILL related port properties.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - Port
 * @param [out]    ptr_property    - Port properties
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Operation fail
 */
CLX_ERROR_NO_T
hal_trill_getPortProperty(const UI32_T unit,
                          const CLX_PORT_T port,
                          CLX_TRILL_PORT_PROPERTY_T *ptr_property);

/**************************************************************************************/
/* Exposed HAL Function                                                               */
/**************************************************************************************/
/**
 * @brief Get src_supp_tag for Trill-type interface.
 *
 * @param [in]     unit       - Device unit number
 * @param [out]    ptr_sst    - HW source suppression tag value
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry doesn't exist
 */
CLX_ERROR_NO_T
hal_trill_getSrcSuppTag(const UI32_T unit, UI32_T *ptr_sst);

/**
 * @brief Get HW tunnel init info of Trill tunnel.
 *
 * 1. Trill module uses intf_obj type to distinct UC or MC:
 * For UC: use tnl_port to get get info, don't care tree_nickname.
 * For MC: use tree_nickname to get info, tnl_port can be any except Trill-type obj.
 * 2. Both unicast/multicast should be added by addInit before calling this API.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     bdid             - Bridge domain id
 * @param [in]     tnl_port         - Interface object (for unicast)
 * @param [in]     tree_nickname    - Egress nickname (For multicast)
 * @param [out]    ptr_seg          - HW segment
 * @param [out]    ptr_encap_idx    - HW encap idx
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Tunnel doesn't exist
 */
CLX_ERROR_NO_T
hal_trill_getHwInitInfo(const UI32_T unit,
                        const CLX_BRIDGE_DOMAIN_T bdid,
                        const CLX_PORT_T tnl_port,
                        const CLX_TRILL_NICKNAME_T tree_nickname,
                        UI32_T *ptr_seg,
                        UI32_T *ptr_encap_idx);

/**
 * @brief Get SW tunnel init info of Trill tunnel.
 *
 * 1. Use encap_idx to distinct UC or MC:
 * For Unicast: tnl_port will be Trill-type obj, and tree_nickname is ignored.
 * For Multicast: tnl_port is ignored, and tree_nickname will be used.
 * 2. Both unicast/multicast should be added by addInit before calling this API.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     encap_idx            - HW encap_idx
 * @param [out]    ptr_tnl_port         - Interface object
 * @param [out]    ptr_tree_nickname    - Trill tree nickname
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Tunnel doesn't exist
 * @return         CLX_E_BAD_PARAMETER      - Inputs are illegal
 */
CLX_ERROR_NO_T
hal_trill_getSwInitInfo(const UI32_T unit,
                        const UI32_T encap_idx,
                        CLX_PORT_T *ptr_tnl_port,
                        CLX_TRILL_NICKNAME_T *ptr_tree_nickname);

/**
 * @brief Get HW vid_ctl/1st/2nd info of Trill tunnel.
 *
 * 1. For Trill tunnel, inner DO NOT allow any vlan (VL/FGL is treated as segment).
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_tag_action    - VLAN tag action
 * @param [in]     vlan_action       - VLAN action
 * @param [out]    ptr_info          - HW vlan info
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry doesn't exist
 * @return         CLX_E_BAD_PARAMETER      - Some of inputs are illegal
 */
CLX_ERROR_NO_T
hal_trill_getHwVidInfo(const UI32_T unit,
                       const CLX_VLAN_TAG_ACTION_T *ptr_tag_action,
                       const CLX_VLAN_ACTION_T vlan_action,
                       HAL_VLAN_VID_CTL_T *ptr_info);

/**
 * @brief Get SW vid action of TRILL tunnel.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     ptr_vid_ctl        - HW vlan info
 * @param [out]    ptr_tag_action     - VLAN tag action
 * @param [out]    ptr_vlan_action    - VLAN action
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Inputs are illegal
 */
CLX_ERROR_NO_T
hal_trill_getSwVidInfo(const UI32_T unit,
                       const HAL_VLAN_VID_CTL_T *ptr_vid_ctl,
                       CLX_VLAN_TAG_ACTION_T *ptr_tag_action,
                       CLX_VLAN_ACTION_T *ptr_vlan_action);

/**
 * @brief Get mgid_lag_id for TRILL_NORMAL_TREE.
 *
 * @param [in]     unit               - Device unit number
 * @param [out]    ptr_mgid_lag_id    - mgid_lag_id
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_trill_getTreeMgid(const UI32_T unit, UI32_T *ptr_mgid_lag_id);

/**
 * @brief Add TRILL VL_FGL to fdid mapping for trill_tnl_port
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lcl_intf_idx    - local interface idx
 * @param [in]     seg             - segment id
 * @param [in]     bdid            - mapped bridge domain id
 * @param [in]     is_add          - is new add
 * @return         CLX_E_OK           - Operate success
 * @return         CLX_E_NO_MEMORY    - No available memory
 */
CLX_ERROR_NO_T
hal_trill_addSegDb(const UI32_T unit,
                   const UI32_T lcl_intf_idx,
                   const UI32_T seg,
                   const UI32_T bdid,
                   const UI32_T is_add);

/**
 * @brief Delete TRILL VL_FGL to fdid mapping for trill_tnl_port
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lcl_intf_idx    - local interface idx
 * @param [in]     seg             - segment id
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_trill_delSegDb(const UI32_T unit, const UI32_T lcl_intf_idx, const UI32_T seg);

/**
 * @brief Enable/Disable designated forwarder.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Port object
 * @param [in]     enable    - DF enable
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_trill_setDfEnable(UI32_T unit, CLX_PORT_T port, UI32_T enable);

/**
 * @brief Get designated forwarder enable/disable control value.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Port object
 * @param [in]     ptr_enable    - DF enable
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_trill_getDfEnable(const UI32_T unit, const CLX_PORT_T port, UI32_T *ptr_enable);

/**
 * @brief Callback function when l3 adjacency info is updated.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     adj_id          - Sw view adjacency ID
 * @param [in]     ptr_adj_info    - Updated adjacency info
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_trill_updateAdjInfo(const UI32_T unit,
                        const UI32_T adj_id,
                        const HAL_L3_ADJ_INFO_T *ptr_adj_info);

/**
 * @brief Callback function when nvo3 adjacency info is updated.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     nvo3_adj_id    - Sw view nov3 adjacency id
 * @param [in]     clx_port       - Updated nvo3 adjacency info
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_trill_updateNvo3AdjInfo(const UI32_T unit, const UI32_T nvo3_adj_id, const CLX_PORT_T clx_port);

#endif
