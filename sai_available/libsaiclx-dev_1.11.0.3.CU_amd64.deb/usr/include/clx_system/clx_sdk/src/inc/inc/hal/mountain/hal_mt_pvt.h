/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_pvt.h
 * PURPOSE:
 *    It provides HAL driver API functions for PVT module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_PVT_H
#define HAL_MT_PVT_H

#ifdef __cplusplus
extern "C" {
#endif
/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <osal/osal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_PVT_REASON_PRIORITY_MIN (0)

/*
 * Multiplies an integer by a fraction, while avoiding unnecessary
 * overflow or loss of precision.
 */
#define HAL_MT_PVT_MULT_FRAC(x, numer, denom)           \
    ({                                                  \
        typeof(x) quot = (x) / (denom);                 \
        typeof(x) rem = (x) % (denom);                  \
        (quot * (numer)) + ((rem * (numer)) / (denom)); \
    })

#define HAL_MT_PVT_RESULT_CHECK(rc, sema, mem) \
    if ((rc) != CLX_E_OK) {                    \
        if (sema) {                            \
            osal_giveSemaphore(sema);          \
        }                                      \
        if (mem) {                             \
            osal_free(mem);                    \
        }                                      \
        return (rc);                           \
    }

/* DATA TYPE DECLARATIONS
 */
/*
 * struct HAL_MT_PVT_POLY_TERM_T - a term descriptor of the PVT data translation
 *              polynomial
 * @deg: degree of the term.
 * @coef: multiplication factor of the term.
 * @divider: distributed divider per each degree.
 * @divider_leftover: divider leftover, which couldn't be redistributed.
 */
typedef struct {
    UI32_T deg;
    I32_T coef;
    I32_T divider;
    I32_T divider_leftover;
} HAL_MT_PVT_POLY_TERM_T;

/*
 * struct HAL_MT_PVT_POLY_T - PVT data translation polynomial descriptor
 * @total_divider: total data divider.
 * @terms: polynomial terms up to a free one.
 */
typedef struct {
    I32_T total_divider;
    HAL_MT_PVT_POLY_TERM_T terms[];
} HAL_MT_PVT_POLY_T;

typedef enum {
    HAL_MT_PVT_TEMP,
    HAL_MT_PVT_VOLT,
    HAL_MT_PVT_LVT,
    HAL_MT_PVT_ULVT,
    HAL_MT_PVT_SVT,
    HAL_MT_PVT_SENSORS_MAX
} HAL_MT_PVT_SENSOR_TYPE_T;

typedef enum {
    HAL_MT_PVT_TRIMO,
    HAL_MT_PVT_TRIMG,
    HAL_MT_PVT_VTRIM,
    HAL_MT_PVT_TRIM_TYPE_MAX
} HAL_MT_PVT_TRIM_TYPE_T;

typedef struct {
    UI32_T bit_offset;
    UI32_T bit_num;
    UI32_T bit_msk;
    UI32_T value;
} HAL_MT_PVT_TRIM_T;

typedef struct {
    UI32_T bit_offset;
    UI32_T bit_num;
    UI32_T bit_msk;
    UI32_T value;
} HAL_MT_PVT_CTRL_REG_FILED_T;

/*
it it mapping to PVT field, it is derived from
HAL_MT_REG_TOP_CFG_PVT10_CONTROL_FIELD_T
*/
typedef enum {
    HAL_MT_CONTROL_PVT_VSAMPLE_FIELD_ID,
    HAL_MT_CONTROL_PVT_PSAMPLE_FIELD_ID,
    HAL_MT_CONTROL_PVT_TRIMO_FIELD_ID,
    HAL_MT_CONTROL_PVT_TRIMG_FIELD_ID,
    HAL_MT_CONTROL_PVT_VTRIM_FIELD_ID,
    HAL_MT_CONTROL_PADDING1_FIELD_ID,
    HAL_MT_CONTROL_LAST_FIELD_ID
} HAL_MT_PVT_CONTROL_FIELD_T;

typedef struct {
    UI32_T id;
    CLX_SEMAPHORE_ID_T sema;
    UI32_T ctrl_reg;
    UI32_T data_reg;
    UI32_T ena_reg;
    UI32_T ready_reg;
    HAL_MT_PVT_TRIM_T trim[HAL_MT_PVT_TRIM_TYPE_MAX];
} HAL_MT_PVT_DEV_T;

typedef enum {
    HAL_MT_PVT_ID_0,
    HAL_MT_PVT_ID_1,
    HAL_MT_PVT_ID_2,
    HAL_MT_PVT_ID_3,
    HAL_MT_PVT_ID_4,
    HAL_MT_PVT_ID_5,
    HAL_MT_PVT_ID_6,
    HAL_MT_PVT_ID_7,
    HAL_MT_PVT_ID_8,
    HAL_MT_PVT_ID_9,
    HAL_MT_PVT_ID_10,
    HAL_MT_PVT_ID_11,
    HAL_MT_PVT_ID_12,
    HAL_MT_PVT_ID_13,
    HAL_MT_PVT_ID_14,
    HAL_MT_PVT_ID_MAX
} HAL_MT_PVT_ID_T;

#define HAL_MT_PVT_TIME_OUT 1000

#define HAL_MT_PVT_ENA_ENABLE    1
#define HAL_MT_PVT_ENA_DISENABLE 0

typedef struct {
    UI32_T vsample;
    UI32_T psample;
} HAL_MT_PVT_EVA_T;

/* EFUSE BIT mapping for PVT TRIMG/TRIMO/VTRIM */
#define HAL_MT_EFUSE_PAGE_SIZE      256
#define HAL_MT_PVT_REG_BIT_NUM      32
#define HAL_MT_PVT_TRIMO_BIT_OFFSET 384 /* Bit 384 ~ 504 */
#define HAL_MT_PVT_TRIMO_BIT_NUM    8
#define HAL_MT_PVT_TRIMO_MASK       0xFF

#define HAL_MT_PVT_TRIMG_BIT_OFFSET 512 /* BIt 512 ~ 587 */
#define HAL_MT_PVT_TRIMG_BIT_NUM    5
#define HAL_MT_PVT_TRIMG_MASK       0x1F

#define HAL_MT_PVT_VTRIM_BIT_OFFSET 592 /* BIt 592 ~ 667 */
#define HAL_MT_PVT_VTRIM_BIT_NUM    5
#define HAL_MT_PVT_VTRIM_MASK       0x1F

#define HAL_MT_PVT_ID_CHK(unit, id) OSAL_ASSERT((id) < HAL_MT_PVT_ID_MAX);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_pvt_getChipTemperature(const UI32_T unit, I32_T *ptr_temperature);

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature list
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_pvt_getChipTemperatureList(const UI32_T unit, CLX_SWC_THERMAL_LIST_T *ptr_temperature);

CLX_ERROR_NO_T
hal_mt_pvt_init(const UI32_T unit);

void
hal_mt_pvt_deinit(const UI32_T unit);

I32_T
hal_mt_pvt_calc_poly(const HAL_MT_PVT_POLY_T *poly, I32_T data);

CLX_ERROR_NO_T
hal_mt_pvt_getChipTemperature(const UI32_T unit, I32_T *ptr_temperature);

CLX_ERROR_NO_T
_hal_mt_pvt_trim_set(const UI32_T unit, HAL_MT_PVT_ID_T pvt_id, HAL_MT_PVT_SENSOR_TYPE_T pvt_type);

CLX_ERROR_NO_T
_hal_mt_pvt_config(const UI32_T unit, HAL_MT_PVT_ID_T pvt_id, HAL_MT_PVT_SENSOR_TYPE_T pvt_type);

CLX_ERROR_NO_T
_hal_mt_pvt_ena(const UI32_T unit, HAL_MT_PVT_ID_T pvt_id, BOOL_T enable);

CLX_ERROR_NO_T
_hal_mt_pvt_read_data(const UI32_T unit,
                      HAL_MT_PVT_ID_T pvt_id,
                      HAL_MT_PVT_SENSOR_TYPE_T type,
                      I32_T *val);

CLX_ERROR_NO_T
_hal_mt_pvt_trim_cfg_get(const UI32_T unit,
                         HAL_MT_PVT_DEV_T *dev,
                         HAL_MT_PVT_TRIM_TYPE_T type,
                         UI32_T *data);

#ifdef __cplusplus
}
#endif
#endif /* End of HAL_MT_PVT_H */
