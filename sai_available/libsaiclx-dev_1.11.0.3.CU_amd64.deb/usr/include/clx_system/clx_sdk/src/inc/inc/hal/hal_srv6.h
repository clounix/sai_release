/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_srv6.h
 * PURPOSE:
 *      It provide srv6 tunnel hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_SRV6_H
#define HAL_SRV6_H
#include <clx_srv6.h>
#include <clx_cfg.h>
#include <clx_types.h>
#include <api/diag.h>
#include <hal/hal_cmn.h>
#include <hal/hal.h>

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum {
    HAL_SRV6_SID_SLV_MODE_DISABLE = 0,
    HAL_SRV6_SID_SLV_MODE_SRV6 = 1,
    HAL_SRV6_SID_SLV_MODE_USID = 2,
    HAL_SRV6_SID_SLV_MODE_GSRV6 = 3,
    HAL_SRV6_SID_SLV_MODE_LAST
} HAL_SRV6_SID_SLV_MODE_E;

#define HAL_SRV6_SID_SLV_LOCATOR_LEN_DEFAULT     (8)
#define HAL_SRV6_SID_SLV_FUNC_LEN_DEFAULT        (4)
#define HAL_SRV6_SID_SLV_ARG_LEN_DEFAULT         (2)
#define HAL_SRV6_SID_SLV_USID_BLOCK_LEN_DEFAULT  (7)
#define HAL_SRV6_SID_SLV_USID_NODE_LEN_DEFAULT   (1)
#define HAL_SRV6_SID_SLV_GSRV6_PREFIX_DEFAULT    (4)
#define HAL_SRV6_SID_SLV_GSRV6_SI_OFFSET_DEFAULT (4)

#define HAL_SRV6_SID_LOCATOR_LEN_MAX      (16) /* Max number of locator size */
#define HAL_SRV6_SID_FUNC_LEN_MAX         (4)  /* Max number of function size */
#define HAL_SRV6_SID_ARG_LEN_MAX          (2)  /* Max number of argument size */
#define HAL_SRV6_SID_USID_BLOCK_LEN_MAX   (7)  /* Max number of uSID block size */
#define HAL_SRV6_SID_USID_NODE_LEN_MAX    (16) /* Max number of uSID node id size */
#define HAL_SRV6_SID_GSRV6_PREFIX_LEN_MAX (12) /* Max number of G-SRv6 prefix size */
#define HAL_SRV6_SID_GSRV6_SI_OFFSET_MAX  (16) /* Max number of G-SRv6 SID index offset */
#define HAL_SRV6_VRFI_MIN                 (0)
#define HAL_SRV6_VRFI_MAX                 (8190)

typedef enum {
    HAL_SRV6_TRAV_TYPE_PORT,
    HAL_SRV6_TRAV_TYPE_LOCAL,
    HAL_SRV6_TRAV_TYPE_ENCAPS,
    HAL_SRV6_TRAV_TYPE_NVO3ROUTE,
    HAL_SRV6_TRAV_TYPE_ENDPOINT_POLICY,
    HAL_SRV6_TRAV_TYPE_LAST
} HAL_SRV6_TRAV_TYPE_T;

#define HAL_SRV6_NVO3_ENCAPS_NUM           (8192)
#define HAL_SRV6_ENCAP_IDX_BITMAP_SIZE     (CLX_BITMAP_SIZE(HAL_TUNNEL_NUM))
#define HAL_SRV6_LOCATOR_LABEL_NUM         (512)
#define HAL_SRV6_VPN_LABEL_NUM             (0xFFFFF)
#define HAL_SRV6_LOCATOR_LABEL_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_SRV6_LOCATOR_LABEL_NUM))
#define HAL_SRV6_INVALID_ECMP_MBR_IDX      (0) /* Invalid FWR_RSLT_TNL_ECMP_MBR idx */

#define HAL_SRV6_TDS_SLV_HAH_BDO_SEL_NUM      (2)
#define HAL_SRV6_TDS_SLV_HAH_SRC_TEP_SEL_NUM  (4)
#define HAL_SRV6_TDS_SLV_HAH_MSGO_SEL_NUM     (2)
#define HAL_SRV6_TDS_SLV_HAH_MGO_SEL_NUM      (4)
#define HAL_SRV6_TDS_SLV_HAH_MPLS_LSP_SEL_NUM (2)

#define HAL_SRV6_HASH_SRV6_ENTRIES_PER_TILE (16 * 1024)
#define HAL_SRV6_TRAVERSE_DMA_ENTRY_NUM     (512)
#define HAL_SRV6_TRAVERSE_SLEEP_USEC        (5 * 1000)
#define HAL_SRV6_TRAVERSE_SLEEP_TH_DMA_NUM  (16)
#define HAL_SRV6_DMA_ENTRY_BYTES            (MT_CDB_FPU_HSH_SRV6_ENCAP_WORDS * HAL_BYTES_OF_WORD)
/* NB FPU HSH DMA is 24 bytes alignment. TODO: maybe cdb will have this macro */
#define HAL_SRV6_DMA_HSH_ENTRY_BYTES (24)
#define HAL_SRV6_DMA_HSH_ENTRY_WORDS (HAL_SRV6_DMA_HSH_ENTRY_BYTES / HAL_BYTES_OF_WORD)
/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SRV6_IS_ENCAP_BEHAVIOR(__beh__) \
    (((HAL_SRV6_BEHAVIOR_ENCAP & __beh__) > 0) ? TRUE : FALSE)
#define HAL_SRV6_IS_END_BEHAVIOR(__beh__)    (((HAL_SRV6_BEHAVIOR_END & __beh__) > 0) ? TRUE : FALSE)
#define HAL_SRV6_SET_ENCAP_BEHAVIOR(__beh__) (__beh__ = (__beh__ | HAL_SRV6_BEHAVIOR_ENCAP))
#define HAL_SRV6_SET_END_BEHAVIOR(__beh__)   (__beh__ = (__beh__ | HAL_SRV6_BEHAVIOR_END))
#define HAL_SRV6_CLR_ENCAP_BEHAVIOR(__beh__) (__beh__ = (__beh__ ^ HAL_SRV6_BEHAVIOR_ENCAP))
#define HAL_SRV6_CLR_END_BEHAVIOR(__beh__)   (__beh__ = (__beh__ ^ HAL_SRV6_BEHAVIOR_END))

#define HAL_SRV6_SUPPORT(__unit__)                                                             \
    do {                                                                                       \
        if (HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__) || HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) { \
            DIAG_PRINT(HAL_DBG_SRV6, HAL_DBG_WARN, "u=%u, Device is not support SRV6 rc=%d\n", \
                       __unit__, CLX_E_BAD_PARAMETER);                                         \
            return CLX_E_NOT_SUPPORT;                                                          \
        }                                                                                      \
    } while (0)

#define HAL_SRV6_IPV6_IS_ZERO(ptr_ip) \
    ((0x0 == ptr_ip[0] && 0 == osal_memcmp(ptr_ip, ptr_ip + 1, 15)))

#define HAL_SRV6_CHECK_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)             \
    do {                                                                                          \
        if (!HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)) {        \
            DIAG_PRINT(HAL_DBG_SRV6, HAL_DBG_WARN, "u=%u, invalid " #__value__ "=%d\n", __unit__, \
                       __value__);                                                                \
            return CLX_E_BAD_PARAMETER;                                                           \
        }                                                                                         \
    } while (0)

#define HAL_SRV6_FPU_SIZE(__bitmap__, __bitmap_size__, __fpu_size__, __size__) \
    do {                                                                       \
        UI32_T bit;                                                            \
        __size__ = 0;                                                          \
        CMLIB_BITMAP_BIT_FOREACH(__bitmap__, bit, __bitmap_size__)             \
        {                                                                      \
            __size__ = __size__ + __fpu_size__;                                \
        }                                                                      \
    } while (0)
// static inline void ipv6_to_srctep_hw_ipv6(const CLX_IPV6_T ip_addr6, UI32_T *hw_ipv6, UI32_T
// arr_size)
// {
//     // l3_sa_4x_58
//     (hw_ipv6)[3] = (UI32_T)((ip_addr6)[3]) << 26 |
//                         (ip_addr6)[4] << 18 |
//                         (ip_addr6)[5] << 10 |
//                         (ip_addr6)[6] << 2  |
//                         (ip_addr6)[7] >> 6;
//     (hw_ipv6)[4] = (UI32_T)((ip_addr6)[0]) << 18 |
//                         (ip_addr6)[1] <<  10 |
//                         (ip_addr6)[2] <<  2  |
//                         (ip_addr6)[3] >>  6;
//     // l3_sa_4x_70
//     (hw_ipv6)[0] = (UI32_T)((ip_addr6)[12]) << 24|
//                         (ip_addr6)[13] << 16 |
//                         (ip_addr6)[14] << 8  |
//                         (ip_addr6)[15];
//     (hw_ipv6)[1] = (ip_addr6)[ 8] << 24 |
//                         (ip_addr6)[ 9] << 16 |
//                         (ip_addr6)[10] << 8  |
//                         (ip_addr6)[11];
//     (hw_ipv6)[2] = (UI32_T)(ip_addr6)[7] & 0x3f;
// }

// static inline void ipv6_to_dsttep_hw_ipv6(const CLX_IPV6_T ip_addr6, UI32_T *hw_ipv6, UI32_T
// arr_size)
// {
//     // l3_da_0
//     hw_ipv6[0] = ip_addr6[12] << 24 |
//                  ip_addr6[13] << 16 |
//                  ip_addr6[14] << 8  |
//                  ip_addr6[15];
//     // l3_da_59_32
//     hw_ipv6[1] = (ip_addr6[8] & 0xF) << 24 |
//                   ip_addr6[9] << 16 |
//                   ip_addr6[10] << 8 |
//                   ip_addr6[11];
//     // l3_da_63_60
//     hw_ipv6[2] = (ip_addr6[8] & 0xF0) >> 4;

//     // l3_da_2
//     hw_ipv6[3] = ip_addr6[4] << 24 |
//                  ip_addr6[5] << 16 |
//                  ip_addr6[6] << 8 |
//                  ip_addr6[7];
//     // l3_da_3
//     hw_ipv6[4] = ip_addr6[0] << 24 |
//                  ip_addr6[1] << 16 |
//                  ip_addr6[2] << 8 |
//                  ip_addr6[3];
// }

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_SRV6_BEHAVIOR_NONE,
    HAL_SRV6_BEHAVIOR_ENCAP,
    HAL_SRV6_BEHAVIOR_END,
    HAL_SRV6_BEHAVIOR_LAST
} HAL_SRV6_BEHAVIOR_T;
typedef enum {
    HAL_SRV6_WBDB_LOCATOR,
    HAL_SRV6_WBDB_FUNCTION,
    HAL_SRV6_WBDB_ENCAP,
    HAL_SRV6_WBDB_SIDLIST,
    HAL_SRV6_WBDB_LAST
} HAL_SRV6_WBDB_T;

typedef enum {
    HAL_SRV6_DB_DUMP_FLAGS_PORT = 0,
    HAL_SRV6_DB_DUMP_FLAGS_LOCATOR,
    HAL_SRV6_DB_DUMP_FLAGS_FUNCTION,
    HAL_SRV6_DB_DUMP_FLAGS_LOCATOR_LABEL_ELEMENT,
    HAL_SRV6_DB_DUMP_FLAGS_NVO3_ENCAP_ELEMENT,
    HAL_SRV6_DB_DUMP_FLAGS_NVO3_ROUTE,
    HAL_SRV6_DB_DUMP_FLAGS_LAST,
} HAL_SRV6_DB_DUMP_FLAGS_T;

typedef struct HAL_SRV6_PORT_AVL_NODE_S {
    UI32_T srv6_beh; /* HAL_SRV6_BEHAVIOR_T */
    UI16_T nvo3_encap_idx;
    UI32_T tnl_lcl_idx;

    /* Source Node Result */
    UI32_T ip_sa_idx;
    UI32_T ip_da_idx;
    CLX_SRV6_ENCAPS_BEH_E encap_beh_code;

    /* Endpoint Node Result */
    UI32_T hsh_src_tep_idx;
    /* rmt_src_ip empty means don't care source node ip address,
     * in that case we need enable tapping-skip-src-ip-check */
    CLX_IPV6_T rmt_src_ip;
    UI32_T vrfo;
} HAL_SRV6_PORT_AVL_NODE_T;

typedef struct HAL_SRV6_NVO3_ENCAP_NODE_S {
    BOOL_T port_using;
    HAL_SRV6_PORT_AVL_NODE_T srv6_port_node;
} HAL_SRV6_NVO3_ENCAP_ELEMENT_T;

typedef struct HAL_SRV6_LOCATOR_KEY_S {
    UI16_T vrfo;
    UI32_T locator_len;
    CLX_IP_ADDR_T locator_ip;
} HAL_SRV6_LOCATOR_KEY_T;

typedef struct HAL_SRV6_LOCATOR_AVL_NODE_S {
    HAL_SRV6_LOCATOR_KEY_T key; /* AVL tree key,  SRV6 locator */
    /* Data content */
    UI32_T entry_idx;
    UI32_T locator_lbl;
    BOOL_T dst_tep_2x;
} HAL_SRV6_LOCATOR_AVL_NODE_T;

typedef struct HAL_SRV6_FUNC_KEY_S {
    UI32_T srv6_func;
    UI32_T locator_lbl;
    UI32_T function_len;
} HAL_SRV6_FUNC_KEY_T;

typedef struct HAL_SRV6_FUNC_AVL_NODE_S {
    HAL_SRV6_FUNC_KEY_T key; /* AVL tree key,  SRV6 Function */
    /* Data content */

} HAL_SRV6_FUNC_AVL_NODE_T;

typedef struct HAL_SRV6_LOCATOR_LABEL_ELEMENT_S {
    HAL_SRV6_LOCATOR_AVL_NODE_T *ptr_locator_node;
    CMLIB_LIST_T *ptr_function_list;
} HAL_SRV6_LOCATOR_LABEL_ELEMENT_T;

typedef struct HAL_SRV6_SIDLIST_AVL_NODE_S {
    CLX_SRV6_SIDLIST_T sidlist;
    UI16_T prof_idx;
    UI16_T ref_cnt;
} HAL_SRV6_SIDLIST_AVL_NODE_T;

typedef struct HAL_SRV6_CB_S {
    CMLIB_AVL_HEAD_T *ptr_locator_avl;          /* HAL_SRV6_LOCATOR_AVL_NODE_T */
    CMLIB_AVL_HEAD_T *ptr_function_avl;         /* HAL_SRV6_FUNC_AVL_NODE_T */
    CMLIB_AVL_HEAD_T *ptr_iev_ecmp_path_avl;    /* HAL_CMN_RTE_NODE_T   */
    HAL_CMN_RTE_NODE_T **pptr_iev_nvo3_adj_arr; /* maintain nvo3_adj_id->ecmp_path_idx relation */

    HAL_SRV6_LOCATOR_LABEL_ELEMENT_T *ptr_locator_lbl_arr; /* HAL_SRV6_LOCATOR_LABEL_ELEMENT_T    */
    HAL_SRV6_NVO3_ENCAP_ELEMENT_T *ptr_nvo3_encap_idx_arr; /* HAL_SRV6_NVO3_ENCAP_ELEMENT_T       */
    UI32_T nvo3_encap_idx_bitmap[HAL_SRV6_ENCAP_IDX_BITMAP_SIZE];
    UI32_T locator_lbl_bitmap[HAL_SRV6_LOCATOR_LABEL_BITMAP_SIZE];
    UI32_T locator_len; /* Locator size */
    UI32_T func_len;    /* Function size */
    UI32_T arg_len;     /* Argument size */
    CLX_SEMAPHORE_ID_T srv6_sema;

    UI32_T hash_endpoint_policy_size[HAL_SWC_FPU_NUM];
    void *ptr_traverse_dma_entry_not_align;
    void *ptr_traverse_dma_entry;
    CMLIB_AVL_HEAD_T *ptr_sidlist_avl; /* HAL_SRV6_SIDLIST_AVL_NODE_T */
} HAL_SRV6_CB_T;

typedef HAL_SRV6_CB_T HAL_SRV6_CB_P[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
typedef UI32_T HAL_HSH_ENCAP_ENTRY_T[MT_CDB_FPU_HSH_SRV6_ENCAP_WORDS];
typedef UI32_T HAL_SRV6_DMA_HSH_ENTRY_T[HAL_SRV6_DMA_HSH_ENTRY_WORDS];
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_srv6_init(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_deinit(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_createPort(const UI32_T unit, const UI32_T flag, CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_srv6_destroyPort(const UI32_T unit, const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_srv6_traversePort(const UI32_T unit,
                      const CLX_SRV6_PORT_TRAVERSE_FUNC_T callback,
                      void *ptr_cookie);

CLX_ERROR_NO_T
hal_srv6_addSrv6Local(const UI32_T unit, const CLX_SRV6_LOCAL_T *ptr_srv6_local);

CLX_ERROR_NO_T
hal_srv6_delSrv6Local(const UI32_T unit, const CLX_SRV6_LOCAL_T *ptr_srv6_local);

CLX_ERROR_NO_T
hal_srv6_traverseSrv6Local(const UI32_T unit,
                           const CLX_SRV6_LOCAL_TRAVERSE_FUNC_T callback,
                           void *ptr_cookie);

CLX_ERROR_NO_T
hal_srv6_setSrv6Local(const UI32_T unit, const CLX_SRV6_LOCAL_T *ptr_srv6_local);

CLX_ERROR_NO_T
hal_srv6_getSrv6Local(const UI32_T unit, CLX_SRV6_LOCAL_T *ptr_srv6_local);

CLX_ERROR_NO_T
hal_srv6_addMySidEntry(const UI32_T unit, const CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

CLX_ERROR_NO_T
hal_srv6_delMySidEntry(const UI32_T unit, const CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

CLX_ERROR_NO_T
hal_srv6_setMySidEntry(const UI32_T unit, const CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

CLX_ERROR_NO_T
hal_srv6_getMySidEntry(const UI32_T unit, CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

CLX_ERROR_NO_T
hal_srv6_setSrv6SidGlobalProfile(const UI32_T unit,
                                 const CLX_SRV6_SID_GLOBAL_PROFILE_T *ptr_sid_prof);

CLX_ERROR_NO_T
hal_srv6_getSrv6SidGlobalProfile(const UI32_T unit, CLX_SRV6_SID_GLOBAL_PROFILE_T *ptr_sid_prof);

CLX_ERROR_NO_T
hal_srv6_addEncaps(const UI32_T unit, const CLX_SRV6_ENCAPS_T *ptr_srv6_encaps);

CLX_ERROR_NO_T
hal_srv6_delEncaps(const UI32_T unit, const CLX_SRV6_ENCAPS_T *ptr_srv6_encaps);

CLX_ERROR_NO_T
hal_srv6_setEncaps(const UI32_T unit, const CLX_SRV6_ENCAPS_T *ptr_srv6_encaps);

CLX_ERROR_NO_T
hal_srv6_getEncaps(const UI32_T unit, CLX_SRV6_ENCAPS_T *ptr_srv6_encaps);

CLX_ERROR_NO_T
hal_srv6_addNvo3Route(const UI32_T unit, const CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

CLX_ERROR_NO_T
hal_srv6_setNvo3Route(const UI32_T unit, const CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

CLX_ERROR_NO_T
hal_srv6_delNvo3Route(const UI32_T unit, const CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

CLX_ERROR_NO_T
hal_srv6_getNvo3Route(const UI32_T unit, CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

CLX_ERROR_NO_T
hal_srv6_addEndPointPolicy(const UI32_T unit,
                           const CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy);

CLX_ERROR_NO_T
hal_srv6_delEndPointPolicy(const UI32_T unit,
                           const CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy);

CLX_ERROR_NO_T
hal_srv6_setEndPointPolicy(const UI32_T unit,
                           const CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy);

CLX_ERROR_NO_T
hal_srv6_getEndPointPolicy(const UI32_T unit, CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy);

CLX_ERROR_NO_T
hal_srv6_addSegService(const UI32_T unit,
                       const CLX_PORT_T srv6_port,
                       const UI32_T vpn_lbl,
                       const CLX_PORT_SEG_SRV_T *ptr_srv);

CLX_ERROR_NO_T
hal_srv6_delSegService(const UI32_T unit, const CLX_PORT_T srv6_port, const UI32_T vpn_lbl);

CLX_ERROR_NO_T
hal_srv6_setSegService(const UI32_T unit,
                       const CLX_PORT_T srv6_port,
                       const UI32_T vpn_lbl,
                       const CLX_PORT_SEG_SRV_T *ptr_srv);

CLX_ERROR_NO_T
hal_srv6_getSegService(const UI32_T unit,
                       const CLX_PORT_T srv6_port,
                       const UI32_T vpn_lbl,
                       CLX_PORT_SEG_SRV_T *ptr_srv);

CLX_ERROR_NO_T
hal_srv6_traverseMySidEntry(const UI32_T unit,
                            const CLX_SRV6_MYSIDENTRY_TRAVERSE_FUNC_T callback,
                            void *ptr_cookie);

CLX_ERROR_NO_T
hal_srv6_traverseEndPointPolicy(const UI32_T unit,
                                const CLX_SRV6_ENDPOINTPOLICY_TRAVERSE_FUNC_T callback,
                                void *ptr_cookie);

CLX_ERROR_NO_T
hal_srv6_traverseEncaps(const UI32_T unit,
                        const CLX_SRV6_ENCAPS_TRAVERSE_FUNC_T callback,
                        void *ptr_cookie);

CLX_ERROR_NO_T
hal_srv6_traverseNvo3Route(const UI32_T unit,
                           const CLX_SRV6_NVO3_ROUTE_TRAVERSE_FUNC_T callback,
                           void *ptr_cookie);

/* Below is internal Libary Function */
HAL_SRV6_CB_P *
hal_srv6_getCtrlBlock(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_dumpDb(const UI32_T unit, const UI32_T flags);

CLX_ERROR_NO_T
hal_srv6_getSwInitInfo(const UI32_T unit, const UI32_T nvo3_encap_idx, CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_srv6_getHwInitInfo(const UI32_T unit, const CLX_PORT_T srv6_port, UI32_T *ptr_nvo3_encap_idx);

CLX_ERROR_NO_T
hal_srv6_composeClxPort(const UI32_T unit, const UI32_T nvo3_encap_idx, CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_srv6_srv6PortDumpDb(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_srv6LocatorLabelDumpDb(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_srv6LocatorDumpDb(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_srv6FunctionDumpDb(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_srv6LocatorLabelElementDumpDb(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_srv6Nvo3EncapElementDumpDb(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_srv6Nvo3RouteDumpDb(const UI32_T unit);

CLX_ERROR_NO_T
hal_srv6_retrieveLocatorKeyFromMysid(const UI32_T unit,
                                     const CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry,
                                     HAL_SRV6_LOCATOR_KEY_T *key);

CLX_ERROR_NO_T
hal_srv6_retrieveFunctionKeyFromMysid(const UI32_T unit,
                                      const CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry,
                                      HAL_SRV6_FUNC_KEY_T *key);

CLX_ERROR_NO_T
hal_srv6_retrieveLocalObject(const UI32_T unit,
                             const void *ptr_srv6_node,
                             CLX_SRV6_LOCAL_T *ptr_srv6_local);

CLX_ERROR_NO_T
hal_srv6_retrieveMySidEntryObject(const UI32_T unit,
                                  const void *ptr_locator_node,
                                  const void *ptr_function_node,
                                  CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

CLX_ERROR_NO_T
hal_srv6_retrieveNvo3RouteObject(const UI32_T unit,
                                 const UI32_T nvo3_encap_idx,
                                 CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

CLX_ERROR_NO_T
hal_srv6_retrieveEncapsObject(const UI32_T unit,
                              const UI32_T nvo3_encaps_idx,
                              const UI32_T ip_sa_idx,
                              const UI32_T ip_da_idx,
                              CLX_SRV6_ENCAPS_T *ptr_srv6_encaps_hw);

BOOL_T
hal_srv6_isSrv6VpnBehavior(CLX_SRV6_MYSID_ENTRY_BEHAVIOR_T beh_code);

CLX_ERROR_NO_T
hal_srv6_validateSrv6Port(const UI32_T unit, const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_srv6_updateNvo3AdjInfo(const UI32_T unit, const UI32_T nvo3_adj_id, const CLX_PORT_T clx_port);

CLX_ERROR_NO_T
hal_srv6_setHashAction(const UI32_T unit,
                       const CLX_SRV6_HASH_TYPE_T hash_type,
                       const CLX_SRV6_HASH_ACTION_T *srv6_hash_action);

CLX_ERROR_NO_T
hal_srv6_getHashAction(const UI32_T unit,
                       const CLX_SRV6_HASH_TYPE_T hash_type,
                       CLX_SRV6_HASH_ACTION_T *srv6_hash_action);

#endif /* End of HAL_SRV6_H */
