/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_STAT_H
#define HAL_STAT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stat.h>
#include <clx_tm.h>
#include <dcc/dcc_dma.h>
#include <hal/hal_sec.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_STAT_ENABLE_PP_CNT
#define HAL_STAT_ENABLE_ETHX_CNT
#define HAL_STAT_POLLING_INTERVAL         (10000)
#define HAL_STAT_MAX_POLLING_CNT          ((4 * 1000000) / HAL_STAT_POLLING_INTERVAL)
#define HAL_STAT_THREAD_STACK_SIZE        (64 * 1024)
#define HAL_STAT_THREAD_PRIORITY          (30)
#define HAL_STAT_MAX_CPI_LANE             (4)
#define HAL_STAT_MAX_SRV_CNT_NUM_PER_BANK (1024 * 6)
#define HAL_STAT_MAX_SRV_CNT_BANK_NUM     (16)
#define HAL_STAT_MAX_SRV_CNT_EXT_BANK_NUM (4)
#define HAL_STAT_MAX_DST_CNT_NUM_PER_BANK (256)
#define HAL_STAT_MAX_DST_CNT_BANK_NUM     (4)
#define HAL_STAT_MAX_SRV_CNT_NUM          (HAL_STAT_MAX_SRV_CNT_NUM_PER_BANK * HAL_STAT_MAX_SRV_CNT_BANK_NUM)
#define HAL_STAT_MAX_DST_CNT_NUM          (HAL_STAT_MAX_DST_CNT_NUM_PER_BANK * HAL_STAT_MAX_DST_CNT_BANK_NUM)
#define HAL_STAT_MAX_PP_CNT_NUM           (HAL_STAT_MAX_SRV_CNT_NUM + HAL_STAT_MAX_DST_CNT_NUM)
#define HAL_STAT_MAX_FP_LANE              (256)
#define HAL_STAT_MAX_SERDES_LANE          (HAL_STAT_MAX_FP_LANE + HAL_STAT_MAX_CPI_LANE)
#define HAL_STAT_MAX_SW_TOTAL_PORT_NUM    (256 + 2 + 1)
#define HAL_STAT_MAX_SRV_CNT_BMP_SIZE     ((HAL_STAT_MAX_SRV_CNT_NUM - 1) / 32 + 1)
#define HAL_STAT_MAX_DST_CNT_BMP_SIZE     ((HAL_STAT_MAX_DST_CNT_NUM - 1) / 32 + 1)
#define HAL_STAT_INVALID_HW_CNT_IDX       (0xFFFFFF)
#define HAL_STAT_INVALID_SRV_CNT_ID       (0x3FFFF)
#define HAL_STAT_INVALID_DST_CNT_ID       (0x3FF)
#define HAL_STAT_INVALID_TM_QUEUE_IDX     (0xFFFFFFFF)
#define HAL_STAT_DST_CNT_FIELD_NUM        (12)
#define HAL_STAT_IPORT_OPORT_FIELD_NUM    (2)
#define HAL_STAT_INTER_FRAME_GAP_SIZE     (12)
#define HAL_STAT_PREAMBLE_SZIE            (8)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_STAT_UPDATE_CNT_SRC32(dest64, src32_now, src32_last, src_max) \
    do {                                                                  \
        UI64_ADD_UI32(dest64, (src32_now - src32_last) & src_max);        \
    } while (0)

#define HAL_STAT_UPDATE_CNT_SRC64(dest64, src64_now, src64_last, src_high_max)       \
    do {                                                                             \
        UI64_T _sub;                                                                 \
        UI64_T _max;                                                                 \
        UI64_ASSIGN(_sub, UI64_HI(src64_now), UI64_LOW(src64_now));                  \
        UI64_ASSIGN(_max, src_high_max, 0xFFFFFFFFUL);                               \
        UI64_SUB_UI64(_sub, src64_last);                                             \
        UI64_AND(_sub, _max);                                                        \
        UI64_ADD_UI64(dest64, _sub);                                                 \
        if (UI64_CMP(src64_now, src64_last) < 0) {                                   \
            DIAG_PRINT(HAL_DBG_STAT_DMA, HAL_DBG_INFO, "now %x %x, last %x %x\n",    \
                       UI64_HI(src64_now), UI64_LOW(src64_now), UI64_HI(src64_last), \
                       UI64_LOW(src64_last));                                        \
        }                                                                            \
    } while (0)

#define HAL_STAT_LOCK(__unit__) \
    osal_takeSemaphore(&(_ptr_hal_stat_cb[__unit__]->sema_rsrc), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_UNLOCK(__unit__) osal_giveSemaphore(&(_ptr_hal_stat_cb[__unit__]->sema_rsrc))
#define HAL_STAT_WAIT(__unit__) \
    osal_takeSemaphore(&(_ptr_hal_stat_cb[__unit__]->sema_task), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_SIGNAL(__unit__) osal_giveSemaphore(&(_ptr_hal_stat_cb[__unit__]->sema_task))
#define HAL_STAT_DMA_LOCK(__unit__) \
    osal_takeSemaphore(&(_ptr_hal_stat_cb[__unit__]->sema_dma), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_DMA_UNLOCK(__unit__) osal_giveSemaphore(&(_ptr_hal_stat_cb[__unit__]->sema_dma))
#define HAL_STAT_CNT_LOCK(__unit__, __type__)                                  \
    osal_takeSemaphore(&(_ptr_hal_stat_cb[__unit__]->stat_buf[__type__].sema), \
                       CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_CNT_UNLOCK(__unit__, __type__) \
    osal_giveSemaphore(&(_ptr_hal_stat_cb[__unit__]->stat_buf[__type__].sema))
#define HAL_STAT_API_CNT_LOCK(__unit__) \
    osal_takeSemaphore(&(_ptr_hal_stat_cb[__unit__]->api_cnt.sema), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_API_CNT_UNLOCK(__unit__) \
    osal_giveSemaphore(&(_ptr_hal_stat_cb[__unit__]->api_cnt.sema))
#define HAL_STAT_SW_CNT_INFO(__unit__) (_ptr_hal_stat_cb[__unit__]->sw_cnt_info)
#define HAL_STAT_SW_CNT_BMAP(__unit__) (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.usage_bmap)
#define HAL_STAT_SW_CNT_HW_ID(__unit__, __sw_id__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.hw_cnt_id[__sw_id__])
#define HAL_STAT_SW_CNT_CFG(__unit__, __sw_id__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.cfg[__sw_id__])
#define HAL_STAT_SW_REF_CNT(__unit__, __sw_id__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.ref_cnt[__sw_id__])
#define HAL_STAT_SRV_CNT_INFO(__unit__, __bank__) (_ptr_hal_stat_cb[__unit__]->srv_banks[__bank__])
#define HAL_STAT_DST_CNT_INFO(__unit__, __bank__) (_ptr_hal_stat_cb[__unit__]->dst_banks[__bank__])
#define HAL_STAT_MIB_SW_CNT(__unit__, __lane__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.mib_sw[__lane__][__type__])
#define HAL_STAT_API_RFC_CNT(__unit__, __port__, __type__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.rfc_cnt[__port__][__type__][__idx__])
#define HAL_STAT_RFC_BMAP(__unit__, __port__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.update_bmap[__port__])
#define HAL_STAT_CLX_MIB_SW_CNT(__unit__, __sw_port__, __type__) \
    (_ptr_hal_stat_cb[__unit__]                                  \
         ->api_cnt.clx_mib_sw[__sw_port__][__type__ - HAL_STAT_MIB_SW_CLX_MIB_START])
#define HAL_STAT_CLX_EXCPT_SW_CNT(__unit__, __sw_port__, __type__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.excpt_sw[__sw_port__][__type__][__idx__])
#define HAL_STAT_API_CLX_MIB_CNT(__unit__, __sw_port__, __type__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.rfc_cnt[__sw_port__][__type__][__idx__])
#define HAL_STAT_CLX_MIB_SW_BMAP(__unit__, __sw_port__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.update_bmap[__sw_port__])
#define HAL_STAT_PORT_RATE(__unit__, __port__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->stat_rate.port[__port__][__type__])
#define HAL_STAT_LAST_PORT_RATE(__unit__, __port__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->stat_rate.last_port_rate[__port__][__type__])
#define HAL_STAT_PORT_RATE_LAST_CNT(__unit__, __port__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->stat_rate.last_value[__port__][__type__])
#define HAL_STAT_SRV_BMAP(__unit__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.srv_reset_bmap[__idx__])
#define HAL_STAT_DST_BMAP(__unit__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.dst_reset_bmap[__idx__])
#define HAL_STAT_CONST_PP(__unit__, __idx__)  (PTR_HAL_CONST_INFO(__unit__, stat)->pp[__idx__])
#define HAL_STAT_CONST_MAC(__unit__, __idx__) (PTR_HAL_CONST_INFO(__unit__, stat)->mac[__idx__])
#define HAL_STAT_CONST_TM(__unit__, __idx__)  (PTR_HAL_CONST_INFO(__unit__, stat)->tm[__idx__])

#define HAL_STAT_GET_HW_CNT_TYPE(__virt_hw_cnt_id__) ((__virt_hw_cnt_id__ >> 24) & 0xFF)
#define HAL_STAT_GET_HW_CNT_IDX(__virt_hw_cnt_id__)  (__virt_hw_cnt_id__ & 0xFFFFFF)
#define HAL_STAT_SET_HW_CNT_ID(__virt_hw_cnt_id__, __hw_cnt_type__, __phy_hw_cnt_idx__) \
    (__virt_hw_cnt_id__ = (((__hw_cnt_type__ & 0xFF) << 24) | (__phy_hw_cnt_idx__ & 0xFFFFFF)))
#define HAL_STAT_SET_HW_CNT_TYPE(__virt_hw_cnt_id__, __hw_cnt_type__) \
    (__virt_hw_cnt_id__ = (((__hw_cnt_type__ & 0xFF) << 24) | (__virt_hw_cnt_id__ & 0xFFFFFF)))

#define HAL_STAT_LANE_IDX(__unit__, __port__)                                  \
    (HAL_IS_DEVICE_NAMCHABARWA_FAMILY(__unit__)) ?                             \
        ((HAL_CL_PORT_TO_ETH_MACRO(__unit__, __port__) *                       \
              HAL_STAT_CONST_MAC(__unit__, HAL_STAT_CAP_LANE_NUM_PER_MAC_ID) + \
          HAL_CL_PORT_TO_MACRO_PORT(__unit__, __port__))) :                    \
        (((HAL_CL_PORT_TO_DIE(__unit__, __port__) *                            \
           HAL_STAT_CONST_MAC(__unit__, HAL_STAT_CAP_MAC_NUM_PER_DIE_ID)) +    \
          HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__)) *                      \
             HAL_STAT_CONST_MAC(__unit__, HAL_STAT_CAP_LANE_NUM_PER_MAC_ID) +  \
         HAL_CL_PORT_TO_MACRO_PORT(__unit__, __port__))

#define HAL_STAT_CHECK_FILTER0(flags)   (flags & (1U << 0))
#define HAL_STAT_CHECK_HIDDEN_ON(flags) (flags & (1U << 1))

#define HAL_STAT_DBG_SHOW_INDENT(__space_num__) \
    do {                                        \
        UI32_T(__temp__) = (__space_num__);     \
        while (0 != (__temp__)) {               \
            osal_printf(" ");                   \
            (__temp__) -= 1;                    \
        }                                       \
    } while (0)
/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_STAT_WBDB_SW_CNT_ID = 0,
    HAL_STAT_WBDB_SRV_BANK_ID,
    HAL_STAT_WBDB_DST_BANK_ID,
    HAL_STAT_WBDB_TM_CFG_ID,
    HAL_STAT_WBDB_OBJ_LAST
} HAL_STAT_WBDB_OBJ_TYPE_T;

typedef enum {
    HAL_STAT_HW_TYPE_SRV_CNT = 0,
    HAL_STAT_HW_TYPE_SRV_CNT_EXT0,
    HAL_STAT_HW_TYPE_SRV_CNT_EXT1,
    HAL_STAT_HW_TYPE_SRV_CNT_EXT2,
    HAL_STAT_HW_TYPE_DST_CNT,
    HAL_STAT_HW_TYPE_STM_CNT,
    HAL_STAT_HW_TYPE_EXCPT_IEV_CNT,
    HAL_STAT_HW_TYPE_EXCPT_EME_CNT,
    HAL_STAT_HW_TYPE_ETHC_MIB_SRAM,
    HAL_STAT_HW_TYPE_ETHC_MIB_REG,
    HAL_STAT_HW_TYPE_ETHX_MIB_SRAM,
    HAL_STAT_HW_TYPE_ETHX_MIB_REG,
    HAL_STAT_HW_TYPE_TM,
    HAL_STAT_HW_TYPE_TM_ENB,
    HAL_STAT_HW_TYPE_TM_SPC_CNT,
    HAL_STAT_HW_TYPE_TM_XBN_EVENT,
    HAL_STAT_HW_TYPE_TM_XBN_CELL_ERR,
    HAL_STAT_HW_TYPE_TM_XBN_PATH_ERR,
    HAL_STAT_HW_TYPE_TM_ENB_STC,
    HAL_STAT_HW_TYPE_TM_ENB_STC_PKT,
    HAL_STAT_HW_TYPE_TM_ADM,
    HAL_STAT_HW_TYPE_TM_EA_P,
    HAL_STAT_HW_TYPE_TM_EA_G,
    HAL_STAT_HW_TYPE_TM_EA_G_STR,
    HAL_STAT_HW_TYPE_TM_IOS,
    HAL_STAT_HW_TYPE_TM_EPM,
    HAL_STAT_HW_TYPE_TM_EPM_LBK,
    HAL_STAT_HW_TYPE_TM_LBM,
    HAL_STAT_HW_TYPE_TM_ETM_DROP,
    HAL_STAT_HW_TYPE_TM_ETM_REMOTE_CPU_DROP,
    HAL_STAT_HW_TYPE_TM_EPM_DROP,
    HAL_STAT_HW_TYPE_TM_LBM_EMIR_DROP,
    HAL_STAT_HW_TYPE_TM_LBM_CP2CPU_DROP,
    HAL_STAT_HW_TYPE_TM_LBM_EXP2CPU_DROP,
    HAL_STAT_HW_TYPE_L2_MTU_ECNT,
    HAL_STAT_HW_TYPE_TM_ENB_BUF_FULL_TRUC,
    HAL_STAT_HW_TYPE_TM_EA_P_UC_AOQ_STA,
    HAL_STAT_HW_TYPE_TM_EA_P_MC_AOQ_STA,
    HAL_STAT_HW_TYPE_TM_EA_P_UCMC_AOQ_STA,
    HAL_STAT_HW_TYPE_TM_EA_PCIEQ_STA,
    HAL_STAT_HW_TYPE_TM_EA_EP0CPUQ_STA_STA,
    HAL_STAT_HW_TYPE_TM_EA_EP1CPUQ_STA_STA,
    HAL_STAT_HW_TYPE_TM_IA_AIQ_CNT,
    HAL_STAT_HW_TYPE_TM_IA_AIQ_HRM_CNT,
    /* CL8570 */
    HAL_STAT_HW_TYPE_FLEX_IGR_CNT,
    HAL_STAT_HW_TYPE_TM_ADM_TMIIN,
    HAL_STAT_HW_TYPE_TM_ADM_PASS,
    HAL_STAT_HW_TYPE_TM_ADM_DROP,
    HAL_STAT_HW_TYPE_TM_ADM_FULL,
    HAL_STAT_HW_TYPE_TM_EA_DROP,
    HAL_STAT_HW_TYPE_TM_EA_PASS,
    HAL_STAT_HW_TYPE_TM_EA_REQ,
    HAL_STAT_HW_TYPE_TM_IA_DROP,
    HAL_STAT_HW_TYPE_TM_IA_PASS,
    HAL_STAT_HW_TYPE_TM_IA_REQ,
    HAL_STAT_HW_TYPE_TM_DEB,
    HAL_STAT_HW_TYPE_TM_ENB_TYPE,
    HAL_STAT_HW_TYPE_TM_IPM,
    HAL_STAT_HW_TYPE_TM_TMI,
    HAL_STAT_HW_TYPE_TM_TMI_TYPE,
    HAL_STAT_HW_TYPE_TM_TMI_STC,
    HAL_STAT_HW_TYPE_TM_UQM,
    HAL_STAT_HW_TYPE_TM_XBNR,
    HAL_STAT_HW_TYPE_TM_XBNS,
    HAL_STAT_HW_TYPE_TM_ADM_CMS,
    HAL_STAT_HW_TYPE_TM_DEB_FLUSH,
    HAL_STAT_HW_TYPE_TM_EPM_ERR,
    HAL_STAT_HW_TYPE_TM_IOS_LBS,
    HAL_STAT_HW_TYPE_TM_IOS_SCNT,
    HAL_STAT_HW_TYPE_TM_IOS_DEQ,
    HAL_STAT_HW_TYPE_TM_IOS_LBS_DEQ,
    /* CL8600 */
    HAL_STAT_HW_TYPE_IN_PORT,
    HAL_STAT_HW_TYPE_OUT_PORT,
    HAL_STAT_HW_TYPE_EPP_RSN_CNT,
    HAL_STAT_HW_TYPE_IPP_RSN_CNT,
    HAL_STAT_HW_TYPE_CNT_RSN_GRP0,

    HAL_STAT_HW_TYPE_TM_SQ_DROP_PKT_CNT_MEM0,
    HAL_STAT_HW_TYPE_TM_SQ_DROP_PKT_CNT_MEM1,
    HAL_STAT_HW_TYPE_TM_SQ_DROP_MISC_CNT_MEM0,
    HAL_STAT_HW_TYPE_TM_SQ_DROP_MISC_CNT_MEM1,

    HAL_STAT_HW_TYPE_TM_OQ_WRED_DROP_ECN_PKT_CNT_MEM0,
    HAL_STAT_HW_TYPE_TM_OQ_WRED_DROP_ECN_PKT_CNT_MEM1,
    HAL_STAT_HW_TYPE_TM_OQ_WRED_DROP_ECN_MISC_CNT_MEM0,
    HAL_STAT_HW_TYPE_TM_OQ_WRED_DROP_ECN_MISC_CNT_MEM1,

    HAL_STAT_HW_TYPE_TM_OQ_WRED_ECN_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_OQ_WRED_ECN_MISC_CNT,

    HAL_STAT_HW_TYPE_TM_OQ_TX_CNT,
    HAL_STAT_HW_TYPE_TM_CPU_PORT_OQ_TX_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_CPU_PORT_OQ_TX_OCTETS_CNT,

    HAL_STAT_HW_TYPE_TM_DBG_START,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_PDBWR2ASM_FD_I_CNT = HAL_STAT_HW_TYPE_TM_DBG_START,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_PDBWR2ASM_FD_I_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_PDBWR2ASM_PD_I_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_PDBWR2ASM_PD_I_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_ASM2REP_PD_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_ASM2REP_PD_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_ASM2PPL_DUAL_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_ASM2PPL_DUAL_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_ASM2FRG_DROP_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_ASM2FRG_DROP_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_ASM_SILENT_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_ASM_SILENT_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_CP_ASM2REP_2COM_PD_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_DQC_STA_RETRANSMIT_DURATION_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_DELETE_PORT_PD_IN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_OQC_PORT_PD_IN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_SUB0_PPL_KEY_OUT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_SUB1_PPL_KEY_OUT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_SUB0_PPL_RESULT_IN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_SUB1_PPL_RESULT_IN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT0,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT1,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT2,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT3,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT4,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT5,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT6,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT7,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT0,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT1,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT2,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT3,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT4,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT5,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT6,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT7,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_ALL_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_EOP_ERR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_ECC_ERR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_DT_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_INVLD_PTR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_ALL_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_EOP_ERR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_ECC_ERR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_DT_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_INVLD_PTR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_DRP_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_UC_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_MC_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_CPU_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_MIR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_INT_C_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_INT_R_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_DRP_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_UC_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_MC_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_PORT2QP_CREDIT_CNT_0,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_PORT2QP_CREDIT_CNT_1,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_PORT2QP_CREDIT_CNT_2,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_PORT2QP_CREDIT_CNT_3,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_QP2UCMC_CREDIT_CNT_0,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_QP2UCMC_CREDIT_CNT_1,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_QP2UCMC_CREDIT_CNT_2,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_QP2UCMC_CREDIT_CNT_3,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_OQ2SLICE_CREDIT_CNT_0,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_OQ2SLICE_CREDIT_CNT_1,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_SLICE_CREDIT_CNT_0,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_SLICE_CREDIT_CNT_1,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP2PORT_CREDIT_RETURN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_CIR_TIME_CREDIT_ASSIGN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_CIR_TIME_TOKEN_EVENT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_CIR_TIME_MAX_TOKEN_EVENT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_PIR_TIME_CREDIT_ASSIGN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_PIR_TIME_TOKEN_EVENT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_PIR_TIME_MAX_TOKEN_EVENT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_FC_PORT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_FC_QP_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_FC_DQC2SCH_CREDIT_GRANT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_END,
    HAL_STAT_HW_TYPE_LAST
} HAL_STAT_HW_TYPE_T;

typedef enum {
    HAL_STAT_HW_DUP_TYPE_PLANE = 0,
    HAL_STAT_HW_DUP_TYPE_DIE,
    HAL_STAT_HW_DUP_TYPE_SERDES_MACRO,
    HAL_STAT_HW_DUP_TYPE_BIN,
    HAL_STAT_HW_DUP_TYPE_LAST
} HAL_STAT_HW_DUP_TYPE_T;

typedef enum {
    HAL_STAT_PP_BANK_TYPE_NOT_ASSIGNED = 0,
    HAL_STAT_PP_BANK_TYPE_IFP_SRV1,
    HAL_STAT_PP_BANK_TYPE_IFP_SRV2,
    HAL_STAT_PP_BANK_TYPE_IFP_SRV3, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_IFP_SRV4, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_IFP_SRV5, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_IFP_SRV6, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP0,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP1,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP2,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP3,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP4,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP5,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP6,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP7,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP8,       /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP9,       /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP10,      /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP11,      /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP0,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP1,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP2,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP3,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP4,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP5,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP6,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP7,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP8,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP9,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP10, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP11, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_FLOW,
    HAL_STAT_PP_BANK_TYPE_EFP_SRV1,
    HAL_STAT_PP_BANK_TYPE_EFP_SRV2,
    HAL_STAT_PP_BANK_TYPE_EFP_SRV3,
    HAL_STAT_PP_BANK_TYPE_EFP_SRV4, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ECIA_GROUP0,
    HAL_STAT_PP_BANK_TYPE_ECIA_GROUP1,
    HAL_STAT_PP_BANK_TYPE_ECIA_GROUP2,
    HAL_STAT_PP_BANK_TYPE_ECIA_GROUP3,
    HAL_STAT_PP_BANK_TYPE_ECIA_POST_GROUP0, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ECIA_POST_GROUP1, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ECIA_POST_GROUP2, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ECIA_POST_GROUP3, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_LAST
} HAL_STAT_PP_BANK_TYPE_T;

typedef enum {
    HAL_STAT_PP_OBJ_IN_SRV_L2_INTF = 0,    /*  Vlan-based service l2 */
    HAL_STAT_PP_OBJ_IN_SRV_L3_INTF,        /*  L3 interface */
    HAL_STAT_PP_OBJ_IN_SRV_FDID,           /*  Set properties of the bridge domain */
    HAL_STAT_PP_OBJ_IN_L2_LCL_INTF,        /*  L2 lcl interface */
    HAL_STAT_PP_OBJ_IN_PORT_INTF,          /*  Port interface, CL8600 only */
    HAL_STAT_PP_OBJ_VRF,                   /*  Set VRF */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP0,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP1,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP2,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP3,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP4,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP5,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP6,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP7,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP8,       /*  CIA UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP9,       /*  CIA UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP10,      /*  CIA UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP11,      /*  CIA UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP0,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP1,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP2,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP3,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP4,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP5,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP6,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP7,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP8,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP9,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP10, /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_UCP_GROUP11, /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_FLOW,                  /*  Flow group */
    HAL_STAT_PP_OBJ_OUT_L3_INTF,           /*  Egress L3 interface */
    HAL_STAT_PP_OBJ_OUT_L2_LCL_INTF,       /*  Egerss L2 LCL interface */
    HAL_STAT_PP_OBJ_OUT_SRV_L2_INTF,       /*  MPLS */
    HAL_STAT_PP_OBJ_OUT_PORT_INTF,         /*  Port interface, CL8600 only */
    HAL_STAT_PP_OBJ_ECIA_UCP_GROUP0,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ECIA_UCP_GROUP1,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ECIA_UCP_GROUP2,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ECIA_UCP_GROUP3,       /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ECIA_POST_UCP_GROUP0,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ECIA_POST_UCP_GROUP1,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ECIA_POST_UCP_GROUP2,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ECIA_POST_UCP_GROUP3,  /*  CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_TYPE_LAST
} HAL_STAT_PP_OBJ_TYPE_T;

typedef enum {
    HAL_STAT_CAP_SRV_IDX_OFFSET_ID,
    HAL_STAT_CAP_SRV_NUM_PER_BANK_ID,
    HAL_STAT_CAP_SRV_BANK_NUM_ID,
    HAL_STAT_CAP_SRV_NUM_ID,
    HAL_STAT_CAP_SRV_BMP_SIZE_ID,
    HAL_STAT_CAP_DST_NUM_PER_BANK_ID,
    HAL_STAT_CAP_DST_BANK_NUM_ID,
    HAL_STAT_CAP_DST_NUM_ID,
    HAL_STAT_CAP_DST_BMP_SIZE_ID,
    HAL_STAT_CAP_PP_CNT_NUM_ID,
    HAL_STAT_CAP_PP_LAST
} HAL_STAT_CAP_PP_TYPE_T;

typedef enum {
    HAL_STAT_CAP_MAC_NUM_PER_DIE_ID,
    HAL_STAT_CAP_LANE_NUM_PER_MAC_ID,
    HAL_STAT_CAP_FP_LANE_NUM_ID,
    HAL_STAT_CAP_CPI_LANE_NUM_ID,
    HAL_STAT_CAP_MAC_LAST
} HAL_STAT_CAP_MAC_TYPE_T;

typedef enum {
    HAL_STAT_CAP_TM_QUEUECNT_PLANE_OFFSET_ID,
    HAL_STAT_CAP_TM_QUEUECNT_CPU_OFFSET_ID,
    HAL_STAT_CAP_TM_QUEUECNT_CPI_OFFSET_ID,
    HAL_STAT_CAP_TM_LAST
} HAL_STAT_CAP_TM_TYPE_T;

typedef enum {
    /* mib, per lane basis */
    HAL_STAT_MIB_SW_IN_OCTETS = 0,
    HAL_STAT_MIB_SW_IN_PKTS_ALL,
    HAL_STAT_MIB_SW_IN_PKTS_GOOD,
    HAL_STAT_MIB_SW_IN_PKTS_UC,
    HAL_STAT_MIB_SW_IN_PKTS_NUC,
    HAL_STAT_MIB_SW_IN_PKTS_PAUSE,
    HAL_STAT_MIB_SW_IN_PKTS_PAUSE_PFC,
    HAL_STAT_MIB_SW_IN_PKTS_ERR,
    HAL_STAT_MIB_SW_IN_PKTS_ERR_FCS,
    HAL_STAT_MIB_SW_IN_PKTS_ERR_LONG,
    HAL_STAT_MIB_SW_IN_PKTS_64B,
    HAL_STAT_MIB_SW_IN_PKTS_4096B_9216B,
    HAL_STAT_MIB_SW_IN_PKTS_9217B_MAX,
    HAL_STAT_MIB_SW_OUT_OCTETS,
    HAL_STAT_MIB_SW_OUT_PKTS_ALL,
    HAL_STAT_MIB_SW_OUT_PKTS_GOOD,
    HAL_STAT_MIB_SW_OUT_PKTS_UC,
    HAL_STAT_MIB_SW_OUT_PKTS_NUC,
    HAL_STAT_MIB_SW_OUT_PKTS_PAUSE_PFC,
    HAL_STAT_MIB_SW_OUT_PKTS_ERR,
    HAL_STAT_MIB_SW_OUT_PKTS_64B,
    HAL_STAT_MIB_SW_OUT_PKTS_4096B_9216B,
    HAL_STAT_MIB_SW_OUT_PKTS_9217B_MAX,
    HAL_STAT_MIB_SW_OUT_PKTS_OVERSIZE,
    /* non-mib start, per port basis */
    HAL_STAT_MIB_SW_CLX_MIB_START,
    HAL_STAT_MIB_SW_L3_DISCARDS = HAL_STAT_MIB_SW_CLX_MIB_START,
    HAL_STAT_MIB_SW_INGRESS_L3_DISCARDS,
    HAL_STAT_MIB_SW_EGRESS_L3_DISCARDS,
    HAL_STAT_MIB_SW_L3_BLACKHOLE_DISCARDS,
    HAL_STAT_MIB_SW_INGRESS_PARITY_DISCARDS,
    HAL_STAT_MIB_SW_EGRESS_NON_QUEUE_DISCARDS,
    HAL_STAT_MIB_SW_EGRESS_INVALID_VLAN_DISCARDS,
    HAL_STAT_MIB_SW_INGRESS_L2_MTU_DISCARDS,
    HAL_STAT_MIB_SW_BUFFER_DISCARDS,
    HAL_STAT_MIB_SW_INGRESS_NON_QUEUE_DISCARDS,
    HAL_STAT_MIB_SW_IN_PKTS_DROP,
    HAL_STAT_MIB_SW_OUT_PKTS_DROP,
    HAL_STAT_MIB_SW_PKTS_DROP,
    HAL_STAT_MIB_SW_IN_MAC_ERR,
    /* in/out port */
    HAL_STAT_MIB_SW_IN_START,
    HAL_STAT_MIB_SW_IN_DROP_NON_IP_PKTS = HAL_STAT_MIB_SW_IN_START,
    HAL_STAT_MIB_SW_IN_DROP_NON_IP_OCTETS,
    HAL_STAT_MIB_SW_IN_DROP_IPV4_PKTS,
    HAL_STAT_MIB_SW_IN_DROP_IPV4_OCTETS,
    HAL_STAT_MIB_SW_IN_DROP_IPV6_PKTS,
    HAL_STAT_MIB_SW_IN_DROP_IPV6_OCTETS,
    HAL_STAT_MIB_SW_IN_GOOD_PKTS,
    HAL_STAT_MIB_SW_IN_GOOD_OCTETS,
    HAL_STAT_MIB_SW_IN_GOOD_IPV4_PKTS,
    HAL_STAT_MIB_SW_IN_GOOD_IPV4_OCTETS,
    HAL_STAT_MIB_SW_IN_GOOD_IPV6_PKTS,
    HAL_STAT_MIB_SW_IN_GOOD_IPV6_OCTETS,
    HAL_STAT_MIB_SW_OUT_START,
    HAL_STAT_MIB_SW_OUT_DROP_NON_IP_PKTS = HAL_STAT_MIB_SW_OUT_START,
    HAL_STAT_MIB_SW_OUT_DROP_NON_IP_OCTETS,
    HAL_STAT_MIB_SW_OUT_DROP_IPV4_PKTS,
    HAL_STAT_MIB_SW_OUT_DROP_IPV4_OCTETS,
    HAL_STAT_MIB_SW_OUT_DROP_IPV6_PKTS,
    HAL_STAT_MIB_SW_OUT_DROP_IPV6_OCTETS,
    HAL_STAT_MIB_SW_OUT_GOOD_PKTS,
    HAL_STAT_MIB_SW_OUT_GOOD_OCTETS,
    HAL_STAT_MIB_SW_OUT_GOOD_IPV4_PKTS,
    HAL_STAT_MIB_SW_OUT_GOOD_IPV4_OCTETS,
    HAL_STAT_MIB_SW_OUT_GOOD_IPV6_PKTS,
    HAL_STAT_MIB_SW_OUT_GOOD_IPV6_OCTETS,
    HAL_STAT_MIB_SW_TYPE_LAST
} HAL_STAT_MIB_SW_TYPE_T;

typedef enum {
    HAL_STAT_RFC_CNT_SRC_SRAM = 0,
    HAL_STAT_RFC_CNT_SRC_REG,
    HAL_STAT_RFC_CNT_SRC_SW_L, /* lane based */
    HAL_STAT_RFC_CNT_SRC_SW_P, /* port based */
    HAL_STAT_RFC_CNT_SRC_TYPE_LAST,
} HAL_STAT_RFC_CNT_SRC_TYPE_T;

typedef enum {
    HAL_STAT_RFC_CNT_BUF_OLD = 0,
    HAL_STAT_RFC_CNT_BUF_NEW,
    HAL_STAT_RFC_CNT_BUF_SHOW,
    HAL_STAT_RFC_CNT_BUF_TYPE_LAST
} HAL_STAT_RFC_CNT_BUF_TYPE_T;

typedef enum {
    HAL_STAT_RFC_CNT_SEL_BOTH = 0,
    HAL_STAT_RFC_CNT_SEL_LSB,
    HAL_STAT_RFC_CNT_SEL_MSB
} HAL_STAT_RFC_CNT_SEL_TYPE_T;

typedef enum {
    HAL_STAT_RS_ERR_DIST_CNT0 = 0,
    HAL_STAT_RS_ERR_DIST_CNT1,
    HAL_STAT_RS_ERR_DIST_CNT2,
    HAL_STAT_RS_ERR_DIST_CNT3,
    HAL_STAT_RS_ERR_DIST_CNT4,
    HAL_STAT_RS_ERR_DIST_CNT5,
    HAL_STAT_RS_ERR_DIST_CNT6,
    HAL_STAT_RS_ERR_DIST_CNT7,
    HAL_STAT_RS_ERR_DIST_CNT_LAST
} HAL_STAT_RS_ERR_DIST_CNT_TYPE_T;

typedef CLX_ERROR_NO_T (*HAL_STAT_UPDATE_FUNC_T)(const UI32_T unit,
                                                 const UI32_T idx,
                                                 const BOOL_T clear);

typedef struct HAL_STAT_HW_CB_S {
    HAL_STAT_HW_TYPE_T hw_cnt_type;
    UI32_T table_id;
    UI32_T replica_cnt1;
    UI32_T replica_cnt2;
    UI32_T entry_size;
    UI32_T entry_cnt;
    UI32_T sw_aggr_factor;
    UI32_T sw_hc_size;
    UI32_T sub_task_cnt;
    HAL_STAT_UPDATE_FUNC_T update_func;
    HAL_STAT_HW_DUP_TYPE_T dup_type;
} HAL_STAT_HW_CB_T;

typedef struct HAL_STAT_RFC_CNT_CALC_S {
    HAL_STAT_RFC_CNT_SRC_TYPE_T src;
    UI32_T type;
    HAL_STAT_RFC_CNT_SEL_TYPE_T sel;
    UI32_T mask;
} HAL_STAT_RFC_CNT_CALC_T;

typedef struct HAL_STAT_BUF_S {
    void *ptr_dma_not_align;
    void *ptr_dma_buf; /* aligned 16 based address of ptr_dma_not_align */
    void *ptr_old_buf;
    UI64_T *ptr_results;
    UI32_T task_cnt;
    UI32_T *ptr_tasks_id;
    DCC_CLD_TASK_T *ptr_tasks;
#define HAL_STAT_FLAGS_OLD_BUF_VALID     (1U << 0)
#define HAL_STAT_FLAGS_ADD_DMA_TASK_DONE (1U << 1)
    UI32_T flags;
    CLX_SEMAPHORE_ID_T sema;
} HAL_STAT_BUF_T;

typedef struct HAL_STAT_SRV_CNT_S {
    UI32_T usage_bmap[(HAL_STAT_MAX_SRV_CNT_NUM_PER_BANK - 1) / 32 + 1];
    UI32_T sw_cnt_id[HAL_STAT_MAX_SRV_CNT_NUM_PER_BANK];
    HAL_STAT_PP_BANK_TYPE_T bank_type;
} HAL_STAT_SRV_CNT_T;

typedef struct HAL_STAT_DST_CNT_S {
    UI32_T usage_bmap[(HAL_STAT_MAX_DST_CNT_NUM_PER_BANK - 1) / 32 + 1];
    UI32_T sw_cnt_id[HAL_STAT_MAX_DST_CNT_NUM_PER_BANK];
    HAL_STAT_PP_BANK_TYPE_T bank_type;
} HAL_STAT_DST_CNT_T;

typedef struct HAL_STAT_SW_CNT_S {
    UI32_T usage_bmap[(HAL_STAT_MAX_PP_CNT_NUM - 1) / 32 + 1];
    UI32_T hw_cnt_id[HAL_STAT_MAX_PP_CNT_NUM];
    CLX_STAT_CNT_CFG_T cfg[HAL_STAT_MAX_PP_CNT_NUM];
    UI32_T ref_cnt[HAL_STAT_MAX_PP_CNT_NUM];
    UI32_T srv_reset_bmap[2][HAL_STAT_MAX_SRV_CNT_BMP_SIZE];
    UI32_T dst_reset_bmap[2][HAL_STAT_MAX_DST_CNT_BMP_SIZE];
    UI32_T srv_cnt_left;
    UI32_T dst_cnt_left;
} HAL_STAT_SW_CNT_T;

#define HAL_STAT_SW_CNT_MIB_NUM (HAL_STAT_MIB_SW_CLX_MIB_START)
#define HAL_STAT_SW_CNT_CLX_NUM (HAL_STAT_MIB_SW_TYPE_LAST - HAL_STAT_MIB_SW_CLX_MIB_START)
#define HAL_STAT_SW_CNT_EXCPT_NUM \
    (CLX_STAT_PORT_CNT_TYPE_EGRESS_INVALID_VLAN_DISCARDS - CLX_STAT_PORT_CNT_TYPE_L3_DISCARDS + 1)
#define HAL_STAT_SW_CNT_IN_PORT_NUM  (HAL_STAT_MIB_SW_OUT_START - HAL_STAT_MIB_SW_IN_START)
#define HAL_STAT_SW_CNT_OUT_PORT_NUM (HAL_STAT_MIB_SW_TYPE_LAST - HAL_STAT_MIB_SW_OUT_START)

typedef struct HAL_STAT_API_CNT_CB_S {
    UI64_T mib_sw[HAL_STAT_MAX_SERDES_LANE][HAL_STAT_SW_CNT_MIB_NUM];
    UI64_T clx_mib_sw[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][HAL_STAT_SW_CNT_CLX_NUM];
    UI64_T excpt_sw[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][HAL_STAT_SW_CNT_EXCPT_NUM]
                   [HAL_STAT_RFC_CNT_BUF_TYPE_LAST];
    UI64_T rfc_cnt[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][CLX_STAT_PORT_CNT_TYPE_LAST]
                  [HAL_STAT_RFC_CNT_BUF_TYPE_LAST];
    UI32_T update_bmap[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][(CLX_STAT_PORT_CNT_TYPE_LAST - 1) / 32 + 1];
    CLX_SEMAPHORE_ID_T sema;
} HAL_STAT_API_CNT_CB_T;

typedef struct HAL_STAT_TM_CNT_CFG_S {
    UI32_T port;
    UI32_T cpu_queue;
} HAL_STAT_TM_CNT_CFG_T;

typedef struct HAL_STAT_RATE_CB_S {
    UI64_T last_value[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][CLX_STAT_RATE_TYPE_LAST];
    UI64_T port[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][CLX_STAT_RATE_TYPE_LAST];
    UI64_T last_port_rate[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][CLX_STAT_RATE_TYPE_LAST];
    CLX_TIME_T last_update;
} HAL_STAT_RATE_CB_T;

typedef enum {
    HAL_STAT_REFRESH_FREE = 0,
    HAL_STAT_REFRESH_WAITING,
    HAL_STAT_REFRESH_DOING,
} HAL_STAT_REFRESH_TYPE_T;

typedef struct HAL_STAT_CB_S {
    CLX_SEMAPHORE_ID_T sema_rsrc;
    CLX_SEMAPHORE_ID_T sema_task;
    CLX_THREAD_ID_T update_thread_id;
    HAL_STAT_BUF_T stat_buf[HAL_STAT_HW_TYPE_LAST];
    HAL_STAT_SW_CNT_T sw_cnt_info;
    HAL_STAT_SRV_CNT_T srv_banks[HAL_STAT_MAX_SRV_CNT_BANK_NUM];
    HAL_STAT_DST_CNT_T dst_banks[HAL_STAT_MAX_DST_CNT_BANK_NUM];
    HAL_STAT_API_CNT_CB_T api_cnt;
    HAL_STAT_TM_CNT_CFG_T tm_cfg;
    HAL_STAT_RATE_CB_T stat_rate;
    UI64_T update_cnt;
    CLX_SEMAPHORE_ID_T sema_dma;
    UI32_T per_task_intvl;
#define HAL_STAT_FLAGS_POLLING (1U << 0)
    UI32_T flags;
} HAL_STAT_CB_T;

typedef struct HAL_STAT_EXP_CNT_MERGE_S {
    UI32_T merge_num;
    UI32_T exp_array[];
} HAL_STAT_EXCPT_CNT_MERGE_T;

typedef struct HAL_STAT_RSERRDIST_CNT_ENTRY_S {
    UI64_T cnt[HAL_STAT_RS_ERR_DIST_CNT_LAST];
} HAL_STAT_RSERRDIST_CNT_ENTRY_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Get Stat Control block of corresponding unit.
 *
 * @param [in]     unit           - device unit number
 * @param [in]     ptr_hw_cb      - pointer to HW control block info
 * @param [in]     hw_cb_num      - number of entries in HW control block
 * @param [in]     ptr_formula    - pointer to RFC API counter calculation formula
 * @param [out]    pptr_cb        - pointer to SW control block
 * @return         CLX_E_OK        - Init success.
 * @return         CLX_E_OTHERS    - Init fail
 */
CLX_ERROR_NO_T
hal_stat_initCb(const UI32_T unit,
                HAL_STAT_HW_CB_T *ptr_hw_cb,
                UI32_T hw_cb_num,
                HAL_STAT_RFC_CNT_CALC_T *ptr_formula,
                HAL_STAT_CB_T **pptr_cb);

/**
 * @brief This API is used to clear all port based counters and port TM type counters
 *        when a port is initially created.
 *
 * This API clear counters.
 * (1) port based counters
 * (2) port tm type counters
 * This API not clear counters, user should manually clear them if need.
 * (1) SRV/DST PP counters
 * (2) debug counters
 * (3) exception counters
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port number
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Operate fail.
 */
CLX_ERROR_NO_T
hal_stat_setPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to clear all port based counters and port TM type counters
 *        when a port is reset.
 *
 * This API clear counters.
 * (1) port based counters
 * (2) port tm type counters
 * This API not clear counters, user should manually clear them if need.
 * (1) SRV/DST PP counters
 * (2) debug counters
 * (3) exception counters
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port number
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Operate fail.
 */
CLX_ERROR_NO_T
hal_stat_resetPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to get port counter by physical port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port
 * @param [in]     type       - The type of counter
 * @param [out]    ptr_cnt    - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getPortCnt(const UI32_T unit,
                    const UI32_T port,
                    const CLX_STAT_PORT_CNT_TYPE_T type,
                    UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port counter by physical port.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port
 * @param [in]     type    - The type of counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_clearPortCnt(const UI32_T unit, const UI32_T port, const CLX_STAT_PORT_CNT_TYPE_T type);

/**
 * @brief This API is used to get TM queue counter index by TM handler.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     handler    - The handler of TM queue
 * @param [out]    ptr_idx    - Queue counter index
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getTmQueueCntIdx(const UI32_T unit, const CLX_TM_HANDLER_T handler, UI32_T *ptr_idx);

/**
 * @brief This API is used to set port ID and TM queue counter used for port.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - TM port ID
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - Allocate memory failed
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_stat_setTmQueueCntForPort(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to get port ID and TM queue counter used for port
 *
 * @param [in]     unit        - Device unit number
 * @param [out]    ptr_port    - TM port ID
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getTmQueueCntForPort(const UI32_T unit, UI32_T *ptr_port);

/**
 * @brief This API is used to set CPU queue ID and TM queue counter used for CPU.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     handler        - The handler of TM queue
 * @param [in]     cpu_handler    - The handler of CPU queue
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - Allocate memory failed
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_stat_setTmQueueCntForCpu(const UI32_T unit,
                             const CLX_TM_HANDLER_T handler,
                             const CLX_TM_HANDLER_T cpu_handler);

/**
 * @brief This API is used to get CPU queue ID and TM queue counter used for CPU.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     handler            - The handler of TM queue
 * @param [out]    ptr_cpu_handler    - The handler of CPU queue
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getTmQueueCntForCpu(const UI32_T unit,
                             const CLX_TM_HANDLER_T handler,
                             CLX_TM_HANDLER_T *ptr_cpu_handler);

/**
 * @brief This API is used to get TM counter by TM queue.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     handler    - The handler of TM queue
 * @param [out]    ptr_cnt    - Queue counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getTmQueueCnt(const UI32_T unit,
                       const CLX_TM_HANDLER_T handler,
                       CLX_STAT_TM_QUEUE_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear TM counter by TM queue.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     handler    - The handler of TM queue
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - Allocate memory failed
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_stat_clearTmQueueCnt(const UI32_T unit, const CLX_TM_HANDLER_T handler);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @param [out]    ptr_cnt    - Counter value
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_stat_getTmCnt(const UI32_T unit,
                  const UI32_T port,
                  const CLX_TM_HANDLER_T handler,
                  const CLX_STAT_TM_CNT_TYPE_T type,
                  CLX_STAT_TM_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_stat_clearTmCnt(const UI32_T unit,
                    const UI32_T port,
                    const CLX_TM_HANDLER_T handler,
                    const CLX_STAT_TM_CNT_TYPE_T type);

/**
 * @brief This API is used to create a distribution counter for
 *        ingress interface (L2, L3, tunnel), egress interface (L2, L3, tunnel),
 *        domain (VLAN, FD, VRF) and flow (ingress ACL and egress ACL).
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    ptr_cnt_id    - Counter logic ID.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - There is no counter to serve.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
CLX_ERROR_NO_T
hal_stat_createDistCnt(const UI32_T unit, UI32_T *ptr_cnt_id);

/**
 * @brief This API is used to destroy a distribution counter.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter logic ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
CLX_ERROR_NO_T
hal_stat_destroyDistCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get a distribution counter.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - Counter
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
CLX_ERROR_NO_T
hal_stat_getDistCnt(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_DIST_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear a distribution counter.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed
 */
CLX_ERROR_NO_T
hal_stat_clearDistCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to create a counter for interface (ingress, egress) or
 *        domain (forward domain, VRF)
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_cfg       - The type of counter
 * @param [out]    ptr_cnt_id    - Counter ID.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - There is no counter available.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
CLX_ERROR_NO_T
hal_stat_createCnt(const UI32_T unit, const CLX_STAT_CNT_CFG_T *ptr_cfg, UI32_T *ptr_cnt_id);

/**
 * @brief This API is used to destroy a counter create via hal_stat_createCnt
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
hal_stat_destroyCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to the config of the counter under study
 *
 * The number of counters value return is determined by the type of counter under study.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cfg    - The type of counter
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
hal_stat_getCntCfg(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_CNT_CFG_T *ptr_cfg);

/**
 * @brief This API is used to get port traffic rate by physical port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     type        - The type of traffic rate
 * @param [out]    ptr_rate    - Pointer to rate
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getPortRate(const UI32_T unit,
                     const UI32_T port,
                     const CLX_STAT_RATE_TYPE_T type,
                     UI64_T *ptr_rate);

/* FUNCTION NAME:   hal_stat_getPortRateType
 * PURPOSE:
 *      This API is used to get port rate type from port cnt type.
 * INPUT:
 *    unit                  --  Device unit number
 *    type                  --  The type of port cnt
 *
 * OUTPUT:
 *    *rate_type            --  The type of traffic rate
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_stat_getPortRateType(const UI32_T unit,
                         const CLX_STAT_PORT_CNT_TYPE_T type,
                         CLX_STAT_RATE_TYPE_T *rate_type);

/**
 * @brief This API is used to get PP counter HW index using SW index
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     sw_cnt_id         - SW counter id
 * @param [in]     cnt_type          - counter type
 * @param [in]     pp_obj_type       - PP binding object type
 * @param [in]     old_hw_cnt_idx    - old hw cnt index, old_hw_cnt_idx is not free when it's
 *                                     HAL_STAT_INVALID_HW_CNT_IDX
 * @param [out]    ptr_hw_cnt_idx    - HW counter idx
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_TABLE_FULL         - No available HW resource
 * @return         CLX_E_ENTRY_NOT_FOUND    - The SW counter has not been created.
 */
CLX_ERROR_NO_T
hal_stat_getCntHWIdx(const UI32_T unit,
                     const UI32_T sw_cnt_id,
                     const HAL_STAT_HW_TYPE_T cnt_type,
                     const HAL_STAT_PP_OBJ_TYPE_T pp_obj_type,
                     const UI32_T old_hw_cnt_idx,
                     UI32_T *ptr_hw_cnt_idx);

/**
 * @brief This API is used to get PP counter SW ID using HW index
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     hw_cnt_idx       - HW counter idx in HW table
 * @param [in]     cnt_type         - counter type
 * @param [out]    ptr_sw_cnt_id    - HW counter id
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getCntSWId(const UI32_T unit,
                    const UI32_T hw_cnt_idx,
                    const HAL_STAT_HW_TYPE_T cnt_type,
                    UI32_T *ptr_sw_cnt_id);

/**
 * @brief This API is used to get how many times the counter has been updated
 *
 * @param [in]     unit       - Device unit number
 * @param [out]    ptr_cnt    - Update count
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getUpdateCnt(const UI32_T unit, UI64_T *ptr_cnt);

/**
 * @brief This API is used to get PP storm control counter by index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     plane      - Plane number
 * @param [in]     cnt_idx    - The strom control counter index
 * @param [out]    ptr_cnt    - Pointer to corresponding counter entry (3 values)
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getStormCnt(const UI32_T unit,
                     const UI32_T plane,
                     const UI32_T cnt_idx,
                     HAL_SEC_SCCOUNTER_ENTRY_T *ptr_cnt);

/**
 * @brief This API is used to clear PP storm control counter by index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     plane      - Plane number
 * @param [in]     cnt_idx    - The strom control counter index
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_clearStormCnt(const UI32_T unit, const UI32_T plane, const UI32_T cnt_idx);

/**
 * @brief This API is used to find the actual entry of _ptr_hal_stat_hw_types from type.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - The type user wants to get
 * @param [out]    pptr_hw_type    - The actual HAL_STAT_HW_CB which type is equal to type
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_lookupHwType(const UI32_T unit,
                      const HAL_STAT_HW_TYPE_T type,
                      HAL_STAT_HW_CB_T **pptr_hw_type);

/**
 * @brief To get a free index from a bitmap array
 *
 * @param [in]     ptr_bitmap    - Pointer to the UI32 bitmap array
 * @param [in]     size          - Size of the bitmap array
 * @param [in]     count         - Number of (countinuous, aligned) index to allocate
 * @param [out]    ptr_idx       - The index allocated
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_TABLE_FULL       - No available index
 */
CLX_ERROR_NO_T
hal_stat_getFreeIdx(const UI32_T *ptr_bitmap,
                    const UI32_T size,
                    const UI32_T count,
                    UI32_T *ptr_idx);

/**
 * @brief To free index from a bitmap array
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     cnt_type               - counter type
 * @param [in]     hw_cnt_idx             - HW counter idx in HW table
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 */
CLX_ERROR_NO_T
hal_stat_freeCntHwIdx(const UI32_T unit,
                      const HAL_STAT_HW_TYPE_T cnt_type,
                      const UI32_T hw_cnt_idx);

/**
 * @brief To get a PP HW counter bank Id and corresponding index Id
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     hw_cnt_id                  - HW counter Id
 * @param [in]     mode                       - Counter mode
 * @param [out]    ptr_bank_id                - The HW bank Id of the corresponding counter
 * @param [out]    ptr_sw_bmap_idx_of_bank    - The index the corresponding counter in the bank
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 */
CLX_ERROR_NO_T
hal_stat_getPpBankId(const UI32_T unit,
                     const UI32_T hw_cnt_id,
                     const CLX_STAT_CNT_MODE_T mode,
                     UI32_T *ptr_bank_id,
                     UI32_T *ptr_sw_bmap_idx_of_bank);

/**
 * @brief This API is used to get RS-FEC error distribution counter value.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port
 * @param [out]    ptr_cnt    - Pointer to counters
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_getRsErrDistCnt(const UI32_T unit,
                         const UI32_T port,
                         HAL_STAT_RSERRDIST_CNT_ENTRY_T *ptr_cnt);

/**
 * @brief This API is used to clear RS-FEC error distribution counter value.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_clearRsErrDistCnt(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to set RS-FEC error distribution counter polling interval.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     interval    - polling interval (unit: microsecond)
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_stat_setRsErrDistCntInterval(const UI32_T unit, const UI32_T interval);

/**
 * @brief This API is used to get the regular counter base index.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     mode    - Mode number
 * @return    The index
 */
UI32_T
hal_stat_getSrvCntBase(const UI32_T unit, const UI32_T mode);

/**
 * @brief This API is used to get the width of entry in regular counter.
 *
 * @param [in]     mode    - Mode number
 * @return    Width number
 */
UI32_T
hal_stat_getSrvCntMode(const UI32_T mode);
#endif /* End of HAL_STAT_H */
