/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_meter.h
 * PURPOSE:
 *    It provides HAL driver API functions for meter module.
 *
 * NOTES:
 *    None
 */
#ifndef HAL_METER_H
#define HAL_METER_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_types.h>
#include <clx_error.h>
#include <clx_meter.h>
#include <clx_init.h>
#include <clx_cfg.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_METER_SERVICE_TYPE_NUM (8)  /* interface, phy port, and domain, etc */
#define HAL_METER_CIA_TYPE_NUM     (16) /* total of icia ucp grps and ecia ucp grps */

/* bucket count in one meter */
#define HAL_METER_BUCKET_CNT (2)

/* fixed packet length for packet mode */
#define HAL_METER_PKT_LEN (128)

/* meter register words number */
#define HAL_METER_REG_WORDS (1)

/* meter token variate words number */
#define HAL_METER_TOKEN_VAR_WORDS (2)

/* meter set hw count */
#define HAL_METER_SET_CNT (200)

/* MACRO FUNCTION DECLARATIONS
 */

/* Meter pool mgmt control block */
#define HAL_METER_POOL_MGMT_CB(unit) (_hal_meter_pool_mgmt_cb[unit])

/* global meter bank capacity, unit: double bucket */
#define HAL_METER_GLOBAL_BANK_CAPACITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->g_bank_capacity)

/* max global meter rate, unit: kbps */
#define HAL_METER_GLOBAL_RATE_MAX(unit) (PTR_HAL_CONST_INFO(unit, meter)->g_rate_max)

/* plane meter bank capacity, unit: double bucket */
#define HAL_METER_PLANE_BANK_CAPACITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->p_bank_capacity)

/* reserved meter bank capacity, unit: double bucket */
#define HAL_METER_RSV_BANK_CAPACITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->rsv_bank_capacity)

/* meter rate granularity, unit: kbps */
#define HAL_METER_RATE_GRANULARITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->rate_gra)

/* max plane meter rate, unit: kbps */
#define HAL_METER_PLANE_RATE_MAX(unit) (PTR_HAL_CONST_INFO(unit, meter)->p_rate_max)

/* meter bucket granularity, unit: byte */
#define HAL_METER_BUCKET_GRANULARITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->bucket_gra)

/* max meter bucket size, unit: byte */
#define HAL_METER_BUCKET_MAX(unit, global)                               \
    ((1 == (global)) ? (PTR_HAL_CONST_INFO(unit, meter)->g_bucket_max) : \
                       (PTR_HAL_CONST_INFO(unit, meter)->p_bucket_max))

/* ucp group number for ingress cia */
#define HAL_METER_INGRESS_UCP_GRP_NUM(unit) (PTR_HAL_CONST_INFO(unit, meter)->igr_grp_num)

/* ucp group number for egress cia */
#define HAL_METER_EGRESS_UCP_GRP_NUM(unit) (PTR_HAL_CONST_INFO(unit, meter)->egr_grp_num)

/* plane meter pool entry number */
#define HAL_METER_POOL_PLANE_ENTRY_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->p_entry_num)

/* global meter pool entry number */
#define HAL_METER_POOL_GLOBAL_ENTRY_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->g_entry_num)

/* reserved meter pool entry number */
#define HAL_METER_POOL_RSV_ENTRY_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->rsv_entry_num)

/* total meter pool entry number */
#define HAL_METER_POOL_ENTRY_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->total_entry_num)

/* plane meter bank number */
#define HAL_METER_BANK_PLANE_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->p_bank_num)

/* global meter bank number */
#define HAL_METER_BANK_GLOBAL_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->g_bank_num)

/* reserved meter bank number */
#define HAL_METER_BANK_RSV_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->rsv_bank_num)

/* total meter bank number */
#define HAL_METER_BANK_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->total_bank_num)

/* meter translate packet to rate
 * rate = (((packet) * HAL_METER_PKT_LEN * 8) / 1000)
 */
#define HAL_METER_PKT_TO_RATE(packet, rate)                \
    do {                                                   \
        UI64_T __pkt1__;                                   \
        UI64_T __rate1__;                                  \
        osal_memset(&__pkt1__, 0, sizeof(UI64_T));         \
        osal_memset(&__rate1__, 0, sizeof(UI64_T));        \
        UI64_ADD_UI32(__pkt1__, packet);                   \
        UI64_MULT_UI32(__pkt1__, (HAL_METER_PKT_LEN * 8)); \
        cmlib_bit64_divUi32(__pkt1__, 1000, &__rate1__);   \
        rate = UI64_LOW(__rate1__);                        \
    } while (0)

/* meter translate rate to packet
 * packet =  (((rate) * 1000) / (HAL_METER_PKT_LEN * 8))
 */
#define HAL_METER_RATE_TO_PKT(rate, packet)                                 \
    do {                                                                    \
        UI64_T __pkt2__;                                                    \
        UI64_T __rate2__;                                                   \
        osal_memset(&__pkt2__, 0, sizeof(UI64_T));                          \
        osal_memset(&__rate2__, 0, sizeof(UI64_T));                         \
        UI64_ADD_UI32(__rate2__, rate);                                     \
        UI64_MULT_UI32(__rate2__, (1000));                                  \
        cmlib_bit64_divUi32(__rate2__, (HAL_METER_PKT_LEN * 8), &__pkt2__); \
        packet = UI64_LOW(__pkt2__);                                        \
    } while (0)

/* meter translate round rate to packet */
#define HAL_METER_ROUND_RATE_TO_PKT(rate, packet)          \
    do {                                                   \
        UI32_T __pkt__ = 0;                                \
        UI32_T __rate__ = 0;                               \
        HAL_METER_RATE_TO_PKT(rate, __pkt__);              \
        HAL_METER_PKT_TO_RATE(__pkt__, __rate__);          \
        packet = __rate__ != rate ? __pkt__ + 1 : __pkt__; \
    } while (0)

/* meter round rate */
#define HAL_METER_ROUND_RATE(unit, rate)                             \
    ((((rate) < HAL_METER_RATE_GRANULARITY(unit)) && ((rate) > 0)) ? \
         (1) :                                                       \
         ((rate) / HAL_METER_RATE_GRANULARITY(unit)))

/* meter round bucket size */
#define HAL_METER_ROUND_BUCKET_SIZE(unit, size)                        \
    ((((size) < HAL_METER_BUCKET_GRANULARITY(unit)) && ((size) > 0)) ? \
         (1) :                                                         \
         ((size) / HAL_METER_BUCKET_GRANULARITY(unit)))

/* translate packet to bucket */
#define HAL_METER_PKT_TO_BUCKET(packet) ((packet) * HAL_METER_PKT_LEN)

/* translate bucket to packet */
#define HAL_METER_BUCKET_TO_PKT(bucket) ((bucket) / HAL_METER_PKT_LEN)

/* DATA TYPE DECLARATIONS
 */

/* meter type in HAL */
typedef enum {
    HAL_METER_TYPE_INGRESS_INTF = 0, /* ingress interface */
    HAL_METER_TYPE_EGRESS_INTF,      /* egress interface */
    HAL_METER_TYPE_INGRESS_PORT,     /* ingress physical port [CL8600 only] */
    HAL_METER_TYPE_EGRESS_PORT,      /* egress physical port  [CL8600 only] */
    HAL_METER_TYPE_DOMAIN,           /* ingress domain */
    HAL_METER_TYPE_EGRESS_DOMAIN,    /* egress domain [CL8600 only] */
    HAL_METER_TYPE_IGR_MIR_POLICER,  /* ingress mirror or copp meter [CL8600] */
    HAL_METER_TYPE_EGR_MIR_POLICER,  /* egress mirror or copp meter [CL8600] */
    HAL_METER_TYPE_ICIA,             /* ingress cia */
    HAL_METER_TYPE_ECIA,             /* egress cia */
    HAL_METER_TYPE_FLOW,             /* flow-based */
    HAL_METER_TYPE_LAST,
} HAL_METER_TYPE_T;

/* meter resource type in HAL */
typedef enum {
    HAL_METER_RSRC_TYPE_PLANE = 0, /* plane Meter */
    HAL_METER_RSRC_TYPE_GLOBAL,    /* global Meter */
    HAL_METER_RSRC_TYPE_RSV,       /* reserved Meter */
    HAL_METER_RSRC_TYPE_LAST,
} HAL_METER_RSRC_TYPE_T;

/* cnt_mtr_prof entry field */
typedef enum {
    HAL_METER_CNT_MTR_FIELD_DIST_CNT = 0, /* field distributed counter */
    HAL_METER_CNT_MTR_FIELD_CNT,          /* field counter */
    HAL_METER_CNT_MTR_FIELD_METER,        /* field meter */
    HAL_METER_CNT_MTR_FIELD_LAST
} HAL_METER_CNT_MTR_FIELD_T;

/* double bucket hw meter */
typedef struct HAL_METER_HW_METER_S {
    UI32_T even_sw_id;                     /* even allocated by which sw meter */
    UI32_T odd_sw_id;                      /* odd allocated by which sw meter  */
    UI32_T bank_idx;                       /* hw meter owned by which bank (0 ~ 19) */
    struct HAL_METER_HW_METER_S *ptr_next; /* next hw meter                    */
    struct HAL_METER_HW_METER_S *ptr_prev; /* prev hw meter                    */
} HAL_METER_HW_METER_T;

typedef struct HAL_METER_INDEX_S {
    UI32_T hw_id;   /* hw meter pool entry id   */
    UI16_T even_en; /* even bucket enable       */
    UI16_T odd_en;  /* odd bucket enable        */
} HAL_METER_INDEX_T;

/* Meter TCM Mode */
typedef enum {
    HAL_METER_ALGO_SRTCM = 0, /* SrTCM                 */
    HAL_METER_ALGO_TRTCM,     /* TrTCM                 */
    HAL_METER_ALGO_MTRTCM,    /* modified TrTCM        */
    HAL_METER_ALGO_1R2CM,     /* single rate two color */
    HAL_METER_ALGO_LAST
} HAL_METER_ALGO_T;

/* Meter Parameter */
typedef struct HAL_METER_PARAMETER_S {
    UI32_T cir;     /* cir */
    UI32_T cbs;     /* cbs */
    UI32_T pir_eir; /* pir or eir */
    UI32_T pbs_ebs; /* pbs or ebs */
} HAL_METER_PARAMETER_T;

/* Meter Configuration*/
typedef struct HAL_METER_CFG_S {
    HAL_METER_PARAMETER_T param;     /* Bucket cir/cbs/pir/pbs/eir/ebs */
    HAL_METER_ALGO_T algo_mode;      /* Meter TCM mode */
    HAL_METER_RSRC_TYPE_T rsrc_type; /* resource type */
    UI16_T color_aware;              /* 0: color blind; 1: color ware */
    UI16_T layer1;                   /* 0: layer2; 1: layer1 */
    UI16_T global;                   /* 0: plane; 1: global */
    UI16_T packet;                   /* 0: byte; 1: packet */
} HAL_METER_CFG_T;

typedef struct HAL_METER_SW_METER_S {
    UI32_T sw_id;               /* meter id */
    HAL_METER_CFG_T cfg;        /* tcm mode/color mode/layer mode/port mode */
    HAL_METER_INDEX_T hw_index; /* hw meter info when meter allocated       */
    HAL_METER_TYPE_T type;      /* sw meter type                            */
    UI32_T valid;               /* 0: sw meter not created; 1: created      */
    UI32_T ref_cnt;             /* reference count */
} HAL_METER_SW_METER_T;

typedef struct HAL_METER_BANK_S {
    struct HAL_METER_BANK_S *ptr_next;     /* next bank */
    struct HAL_METER_BANK_S *ptr_prev;     /* prev bank */
    HAL_METER_RSRC_TYPE_T rsrc_type;       /* resource type */
    UI16_T global;                         /* 0: plane meter; 1: global meter */
    UI16_T valid;                          /* 0: not allocated; 1: allocated */
    UI16_T ucp_grp_id;                     /* the ucp group id if the bank is used for cia */
    UI16_T used_single_num;                /* the number of the used single bucket in bank */
    UI16_T used_double_num;                /* the number of the used double bucket in bank */
    HAL_METER_TYPE_T type;                 /* the bank type */
    HAL_METER_HW_METER_T free_single_list; /* the double list of the free single bucket nodes */
    HAL_METER_HW_METER_T free_double_list; /* the double list of the free double bucket nodes */
    HAL_METER_HW_METER_T *ptr_hw;          /* hw meters managed by this bank */
} HAL_METER_BANK_T;

/* Meter pool mgmt control block */
typedef struct HAL_METER_POOL_MGMT_CB_S {
    HAL_METER_BANK_T *ptr_bank_list; /* the array of meter bank */

    /* allocated bank management */
    HAL_METER_BANK_T
    used_p_srv[HAL_METER_SERVICE_TYPE_NUM]; /* manage allocated plane bank for service  */
    HAL_METER_BANK_T used_p_cia[HAL_METER_CIA_TYPE_NUM]; /* manage allocated plane bank for cia */
    HAL_METER_BANK_T used_p_flow;           /* manage allocated plane bank for flow     */
    HAL_METER_BANK_T
    used_g_srv[HAL_METER_SERVICE_TYPE_NUM]; /* manage allocated global bank for service */
    HAL_METER_BANK_T used_g_cia[HAL_METER_CIA_TYPE_NUM]; /* manage allocated global bank for cia */
    HAL_METER_BANK_T used_g_flow;   /* manage allocated global bank for flow    */
    HAL_METER_BANK_T used_igr_port; /* manage allocated ingress port bank for port rate limit */

    HAL_METER_BANK_T free_p_list;   /* manage free plane bank list              */
    HAL_METER_BANK_T free_g_list;   /* manage free global bank list             */
    HAL_METER_BANK_T free_rsv_list; /* manage free reserved bank list */
    HAL_METER_SW_METER_T *ptr_sw;   /* the array of sw meter                    */
    HAL_METER_HW_METER_T *ptr_hw;   /* the array of hw meter                    */
    UI32_T sw_id_num_words;         /* it is used to manage sw meter ids        */
    UI32_T *ptr_sw_id_bmap;         /* it is used to manage sw meter ids        */
    UI32_T sw_p_free_cnt;           /* free sw plane meter count                */
    UI32_T sw_g_free_cnt;           /* free sw global meter count               */
    UI32_T sw_rsv_free_cnt;         /* free reserved meter count */

    UI32_T p_bank_num;              /* plane meter bank number */
    UI32_T g_bank_num;              /* global meter bank number */
    UI32_T rsv_bank_num;            /* reserved meter bank number */
    UI32_T total_bank_num;          /* total meter bank number */

    UI32_T p_entry_num;             /* plane meter entry number, unit: double bucket */
    UI32_T g_entry_num;             /* global meter entry number, unit: double bucket */
    UI32_T rsv_entry_num;           /* reserved meter entry number, unit: double bucket */
    UI32_T total_entry_num;         /* total meter entry number */

/* ingress port meter use reserved resource */
#define HAL_METER_CAPACITY_FLAGS_ING_PORT_METER_RSV (1U << 0)
    UI32_T flags; /* meter capacity flags */
} HAL_METER_POOL_MGMT_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* meter pool mgmt control block */
extern HAL_METER_POOL_MGMT_CB_T *_hal_meter_pool_mgmt_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/**
 * @brief init meter module control blocks.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK               - init success.
 * @return         CLX_E_NO_MEMORY        - allocate control block failed.
 * @return         CLX_E_OTHERS           - Init fail.
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_meter_init(const UI32_T unit);

/**
 * @brief deinit meter module control blocks and free resource.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK               - deinit success.
 * @return         CLX_E_OTHERS           - deInit fail.
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_meter_deinit(const UI32_T unit);

/**
 * @brief convert the data format: A
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     value       - CL8360 plane meter, data(15 bits), format: A(11 bits)+B(4 bits)
 *                               CL8360 global meter, data(16 bits), format: A(12 bits)+B(4 bits)
 *                               CL8570, data(16 bits), format: A(11 bits)+B(5 bits)
 *                               CL8600, data(15 bits), format: A(11 bits)+B(4 bits)
 * @param [out]    ptr_rate    - meter rate
 */
void
hal_meter_transDataToRate(const UI32_T unit, const UI32_T value, UI32_T *ptr_rate);

/**
 * @brief convert the data format: A
 *
 * @param [in]     unit               - device unit number
 * @param [in]     value              - data(15 bits), format: A(11 bits)+B(4 bits)
 * @param [out]    ptr_bucket_size    - meter bucket size
 */
void
hal_meter_transDataToBucket(const UI32_T unit, const UI32_T value, UI32_T *ptr_bucket_size);

/**
 * @brief meter show resource
 *
 * @param [in]     unit      - The device number
 * @param [in]     detail    - detail information
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_meter_showResource(const UI32_T unit, const BOOL_T detail);

/**
 * @brief Alloc hw meter resource
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     meter_id      - Meter id
 * @param [in]     meter_type    - Meter type
 * @param [in]     ucp_grp_id    - Ucp group id
 * @param [out]    ptr_hw_idx    - Hw index
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_meter_allocHwMeterRsrc(const UI32_T unit,
                           const UI32_T meter_id,
                           const HAL_METER_TYPE_T meter_type,
                           const UI32_T ucp_grp_id,
                           UI32_T *ptr_hw_idx);

/**
 * @brief Create sw meter
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     ptr_cfg            - Meter config
 * @param [out]    ptr_sw_meter_id    - Sw meter id
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_meter_createSwMeter(const UI32_T unit, const HAL_METER_CFG_T *ptr_cfg, UI32_T *ptr_sw_meter_id);

/**
 * @brief Set sw meter config
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     sw_meter_id      - Sw meter id
 * @param [in]     ptr_meter_cfg    - Meter config
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_meter_setSwMeterCfg(const UI32_T unit,
                        const UI32_T sw_meter_id,
                        const HAL_METER_CFG_T *ptr_meter_cfg);

/**
 * @brief meter get property
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     property      - property
 * @param [in]     ptr_param0    - param0
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_meter_getProperty(const UI32_T unit, const CLX_SWC_PROPERTY_T property, UI32_T *ptr_param0);

/**
 * @brief create a meter
 *
 * the rate & burst size should be multiple of 64. if usr provide a number
 * which is not multiple of 64, this function will reset it.
 * eg: rate = 1 kbps, the final rate will be 64 kbps
 * size = 1 byte, the final size will be 64 bytes.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_meter_cfg    - meter configuration
 * @param [out]    ptr_meter_id     - meter id, it presents a logical meter
 * @return         CLX_E_OK               - create success.
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid or null pointer.
 * @return         CLX_E_OTHERS           - not inited or others.
 * @return         CLX_E_TABLE_FULL       - no more meter can be created.
 */
CLX_ERROR_NO_T
hal_meter_createMeter(const UI32_T unit,
                      const CLX_METER_CFG_T *ptr_meter_cfg,
                      UI32_T *ptr_meter_id);

/**
 * @brief delete a meter.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     meter_id    - service meter logic id
 * @return         CLX_E_OK                 - success
 * @return         CLX_E_BAD_PARAMETER      - bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - the meter does not exist.
 * @return         CLX_E_ENTRY_IN_USE       - the meter is in use
 */
CLX_ERROR_NO_T
hal_meter_destroyMeter(const UI32_T unit, const UI32_T meter_id);

/**
 * @brief get a meter configuration.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     meter_id         - meter id, it presents a logical meter
 * @param [in]     enable           - enable semaphore lock
 * @param [out]    ptr_meter_cfg    - the meter configuration.
 * @return         CLX_E_OK                 - get success.
 * @return         CLX_E_BAD_PARAMETER      - parameter invalid or null pointer.
 * @return         CLX_E_ENTRY_NOT_FOUND    - the meter does not exist.
 * @return         CLX_E_OTHERS             - unit is invalid.
 */
CLX_ERROR_NO_T
hal_meter_getMeterWithLock(const UI32_T unit,
                           const UI32_T meter_id,
                           const BOOL_T enable,
                           CLX_METER_CFG_T *ptr_meter_cfg);

/**
 * @brief get a meter configuration.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     meter_id         - meter id, it presents a logical meter
 * @param [out]    ptr_meter_cfg    - the meter configuration.
 * @return         CLX_E_OK                 - get success.
 * @return         CLX_E_BAD_PARAMETER      - parameter invalid or null pointer.
 * @return         CLX_E_ENTRY_NOT_FOUND    - the meter does not exist.
 * @return         CLX_E_OTHERS             - unit is invalid.
 */
CLX_ERROR_NO_T
hal_meter_getMeter(const UI32_T unit, const UI32_T meter_id, CLX_METER_CFG_T *ptr_meter_cfg);

/**
 * @brief modify meter rate & bucket size.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     meter_id           - meter id, it presents a logical meter
 * @param [out]    ptr_meter_param    - the meter rate & bucket size.
 * @return         CLX_E_OK                 - set success.
 * @return         CLX_E_BAD_PARAMETER      - parameter invalid or null pointer.
 * @return         CLX_E_ENTRY_NOT_FOUND    - the meter does not exist.
 * @return         CLX_E_OTHERS             - unit is invalid.
 */
CLX_ERROR_NO_T
hal_meter_setMeterParam(const UI32_T unit,
                        const UI32_T meter_id,
                        const CLX_METER_PARAMETER_T *ptr_meter_param);

/**
 * @brief Set ingress port metering for a specific port.
 *
 * If ingress port metering is enabled and the traffic exceeds meter rate,
 * ingress packet will be dropped.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port ID
 * @param [in]     ptr_cfg    - The configuration
 * @return         CLX_E_OK               - Set success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Set failed
 */
CLX_ERROR_NO_T
hal_meter_setIgrPortMeter(const UI32_T unit,
                          const UI32_T port,
                          const CLX_METER_PORT_CFG_T *ptr_cfg);

/**
 * @brief Get ingress port metering for a specific port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port ID
 * @param [in]     ptr_cfg    - The configuration
 * @return         CLX_E_OK               - Set success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Get failed
 */
CLX_ERROR_NO_T
hal_meter_getIgrPortMeter(const UI32_T unit, const UI32_T port, CLX_METER_PORT_CFG_T *ptr_cfg);

/**
 * @brief free meter hw index without lock
 *
 * @param [in]     unit      - The device number
 * @param [in]     hw_idx    - hw index
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_meter_freeMeterHwIdxWithoutLock(const UI32_T unit, const UI32_T hw_idx);

/**
 * @brief get a hw meter index for meter
 *
 * @param [in]     unit          - device unit number.
 * @param [in]     meter_id      - sw meter id
 * @param [in]     meter_type    - meter type
 * @param [in]     ucp_grp_id    - ucp group id for ingress or egress cia
 * @param [in]     old_hw_idx    - old hw meter index, old_hw_idx is not free when it's
 *                                 HAL_INVALID_MTR_HW_IDX
 * @param [out]    ptr_hw_idx    - hw meter index
 * @return         CLX_E_OK                 - alloc success.
 * @return         CLX_E_BAD_PARAMETER      - parameter invalid or null pointer.
 * @return         CLX_E_OTHERS             - not inited or others.
 * @return         CLX_E_ENTRY_NOT_FOUND    - no more hw meter.
 */
CLX_ERROR_NO_T
hal_meter_allocMeterHwIdx(const UI32_T unit,
                          const UI32_T meter_id,
                          const HAL_METER_TYPE_T meter_type,
                          const UI32_T ucp_grp_id,
                          const UI32_T old_hw_idx,
                          UI32_T *ptr_hw_idx);

/**
 * @brief free a hw meter index for meter
 *
 * @param [in]     unit      - device unit number.
 * @param [in]     hw_idx    - hw meter idx
 * @return         CLX_E_OK                 - alloc success.
 * @return         CLX_E_BAD_PARAMETER      - parameter invalid or null pointer.
 * @return         CLX_E_OTHERS             - not inited or others.
 * @return         CLX_E_ENTRY_NOT_FOUND    - no more hw meter.
 */
CLX_ERROR_NO_T
hal_meter_freeMeterHwIdx(const UI32_T unit, const UI32_T hw_idx);

/**
 * @brief get a meter id by hw meter index.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     hw_idx          - meter hw index.
 * @param [in]     enable          - enable semaphore lock
 * @param [out]    ptr_meter_id    - meter id
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_meter_getMeterIdWithLock(const UI32_T unit,
                             const UI32_T hw_idx,
                             const BOOL_T enable,
                             UI32_T *ptr_meter_id);

/**
 * @brief get a meter id by hw meter index.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     hw_idx          - meter hw index.
 * @param [out]    ptr_meter_id    - meter id
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_meter_getMeterId(const UI32_T unit, const UI32_T hw_idx, UI32_T *ptr_meter_id);

/**
 * @brief allocate icia or ecia cnt_mtr_prof entry. meter and counter is disabled
 *        by default.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [in]     ingress                 - Ingress or egress.
 * @param [out]    ptr_cnt_mtr_prof_idx    - cnt_mtr_prof entry index.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_meter_allocCntMtrProf(const UI32_T unit, const BOOL_T ingress, UI32_T *ptr_cnt_mtr_prof_idx);

/**
 * @brief free icia or ecia cnt_mtr_prof entry.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     ingress             - Ingress or egress.
 * @param [in]     cnt_mtr_prof_idx    - cnt_mtr_prof entry index.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_meter_freeCntMtrProf(const UI32_T unit, const BOOL_T ingress, const UI32_T cnt_mtr_prof_idx);

/**
 * @brief set hw meter or counter index into into icia or ecia cnt_mtr_prof entry.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     ingress             - Ingress or egress.
 * @param [in]     cnt_mtr_prof_idx    - cnt_mtr_prof entry index.
 * @param [in]     cnt_mtr_field       - Select meter or counter.
 * @param [in]     cnt_mtr_hw_idx      - Hw meter or counter index.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_meter_setCntMtrProf(const UI32_T unit,
                        const BOOL_T ingress,
                        const UI32_T cnt_mtr_prof_idx,
                        const HAL_METER_CNT_MTR_FIELD_T cnt_mtr_field,
                        const UI32_T cnt_mtr_hw_idx);

/**
 * @brief get hw meter or counter index from icia or ecia cnt_mtr_prof entry.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     ingress               - Ingress or egress.
 * @param [in]     cnt_mtr_prof_idx      - cnt_mtr_prof entry index.
 * @param [in]     cnt_mtr_field         - Select meter or counter.
 * @param [out]    ptr_cnt_mtr_hw_idx    - Hw meter or counter index.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_meter_getCntMtrProf(const UI32_T unit,
                        const BOOL_T ingress,
                        const UI32_T cnt_mtr_prof_idx,
                        const HAL_METER_CNT_MTR_FIELD_T cnt_mtr_field,
                        UI32_T *ptr_cnt_mtr_hw_idx);

/**
 * @brief check if any meter or counter exists in icia or ecia cnt_mtr_prof entry.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     ingress              - Ingress or egress.
 * @param [in]     cnt_mtr_prof_idx     - cnt_mtr_prof entry index.
 * @param [out]    ptr_cnt_mtr_exist    - any meter or counter exists or not.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_meter_checkCntMtrProf(const UI32_T unit,
                          const BOOL_T ingress,
                          const UI32_T cnt_mtr_prof_idx,
                          BOOL_T *ptr_cnt_mtr_exist);

#endif /* End of HAL_METER_H */
