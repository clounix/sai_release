/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_MT_NAMCHABARWA_PORT_H
#define HAL_MT_NAMCHABARWA_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <hal/mountain/hal_mt_mac.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_serdes.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NAMCHABARWA_ETH_SLICE_MAX_NUM                  (8)
#define HAL_MT_NAMCHABARWA_ETH_MACRO_MAX_NUM_PER_SLICE        (4)
#define HAL_MT_NAMCHABARWA_L256_ETH_MACRO_MAX_NUM_PER_SLICE   (8)
#define HAL_MT_NAMCHABARWA_PORT_DROP_PKT_DISABLE              (0)
#define HAL_MT_NAMCHABARWA_PORT_DROP_PKT_UNTAGGED             (1)
#define HAL_MT_NAMCHABARWA_PORT_DROP_PKT_TAGGED               (2)
#define HAL_MT_NAMCHABARWA_PORT_DROP_PKT_TAGGED_EXPT_DFLT_VID (3)
#define HAL_MT_NAMCHABARWA_PORT_MACRO_INVALID                 (0xFFFFFFFF)

#define HAL_MT_NAMCHABARWA_PORT_DERICTION_INGRESS (0)
#define HAL_MT_NAMCHABARWA_PORT_DERICTION_EGRESS  (1)

#define HAL_MT_NAMCHABARWA_PORT_MBURST_CNT_TX_BYTE       (0)
#define HAL_MT_NAMCHABARWA_PORT_MBURST_CNT_TX_PKT        (1)
#define HAL_MT_NAMCHABARWA_PORT_MBURST_CNT_TX_MATCH_BYTE (2)
#define HAL_MT_NAMCHABARWA_PORT_MBURST_CNT_TX_MATCH_PKT  (3)

typedef enum {
    HAL_MT_NAMCHABARWA_PORT_FC_DISABLE,
    HAL_MT_NAMCHABARWA_PORT_FC_PAUSE,
    HAL_MT_NAMCHABARWA_PORT_FC_PFC,
    HAL_MT_NAMCHABARWA_PORT_FC_LAST
} HAL_MT_NAMCHABARWA_PORT_FC_T;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS */
/**
 * @brief This API is used to set the mapping between unit/port and mac/lane
 *        number.
 *
 * This API is suggested to be used during SDK initialization.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [in]     eth_macro    - eth ball MAC macro ID (shown in schematic)
 * @param [in]     lane         - eth lane ID
 * @param [in]     max_speed    - The maximum speed of the physical port
 * @param [in]     flags        - Attributes of the physical port
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setLaneMap(const UI32_T unit,
                                   const UI32_T port,
                                   const UI32_T eth_macro,
                                   const UI32_T lane,
                                   const CLX_PORT_SPEED_T max_speed,
                                   const UI32_T flags);

/**
 * @brief This API is used to get the mapping between unit/port and mac/lane
 *        number.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port             - Physical port ID
 * @param [out]    ptr_eth_macro    - eth MAC macro ID
 * @param [out]    ptr_lane         - eth lane ID
 * @param [out]    ptr_max_speed    - The maximum speed of the physical port
 * @param [out]    ptr_flags        - Attributes of the physical port
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getLaneMap(const UI32_T unit,
                                   const UI32_T port,
                                   UI32_T *ptr_eth_macro,
                                   UI32_T *ptr_lane,
                                   CLX_PORT_SPEED_T *ptr_max_speed,
                                   UI32_T *ptr_flags);

/**
 * @brief This API is used to set port egress vlan tag control.
 *        number.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     intf            - Logical port ID
 * @param [in]     bdid            - Bridge Doamin ID
 * @param [in]     ptr_port_tag    - Egress vlan tag control
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setVlanTagCtrl(const UI32_T unit,
                                       const CLX_PORT_T intf,
                                       const CLX_BRIDGE_DOMAIN_T bdid,
                                       const CLX_PORT_VLAN_TAG_CTRL_T *ptr_port_tag);

/**
 * @brief This API is used to get port egress vlan tag control.
 *        number.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     intf            - Logical port ID
 * @param [in]     bdid            - Bridge Doamin ID
 * @param [out]    ptr_port_tag    - egress vlan tag control
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getVlanTagCtrl(const UI32_T unit,
                                       const CLX_PORT_T intf,
                                       const CLX_BRIDGE_DOMAIN_T bdid,
                                       CLX_PORT_VLAN_TAG_CTRL_T *ptr_port_tag);

/**
 * @brief To get register and filed of mac status for a specific port
 *
 * @param [in]     unit         - Chip id
 * @param [in]     port         - Physical Port id
 * @param [in]     status       - Status type
 * @param [out]    ptr_param0   - Value
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getMacStatus(const UI32_T unit,
                                     const UI32_T port,
                                     const UI32_T status,
                                     UI32_T *ptr_param0);

/**
 * @brief To set umac channel mode
 *
 * @param [in]     unit        - Chip id
 * @param [in]     port        - Port id
 * @param [in]     lane_cnt    - Lane cnt
 * @param [in]     fec         - fec mode
 * @param [in]     speed       - set speed
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setChMode(const UI32_T unit,
                                  const UI32_T port,
                                  const UI32_T lane_cnt,
                                  const UI32_T fec,
                                  const UI32_T speed);

/**
 * @brief To get fec from umac channel mode
 *
 * @param [in]     unit    - Chip id
 * @param [in]     port    - Port id
 * @param [in]     fec     - fec mode
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getFec(const UI32_T unit, const UI32_T port, UI32_T *fec);

/**
 * @brief To set umac and pl speed for a specific port
 *
 * @param [in]     unit        - Chip id
 * @param [in]     port        - Port id
 * @param [in]     lane_cnt    - Lane cnt
 * @param [in]     fec         - fec mode
 * @param [in]     speed       - set speed
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setSpeed(const UI32_T unit,
                                 const UI32_T port,
                                 const UI32_T lane_cnt,
                                 const UI32_T fec,
                                 const UI32_T speed);

/**
 * @brief To set mac control property
 *
 * @param [in]     unit        - Chip id
 * @param [in]     port        - Port id
 * @param [in]     property    - Property type
 * @param [in]     param0      - First parameter
 * @param [in]     param1      - Second parameter
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setMacProperty(const UI32_T unit,
                                       const UI32_T port,
                                       const HAL_MAC_PROPERTY_T property,
                                       const UI32_T param0,
                                       const UI32_T param1);

/**
 * @brief To get mac control property
 *
 * @param [in]     unit        - Chip id
 * @param [in]     port        - Port id
 * @param [in]     property    - Property type
 * @param [out]    ptr_param0  - Property value
 * @param [out]    ptr_param1  - Reserved
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getMacProperty(const UI32_T unit,
                                       const UI32_T port,
                                       const HAL_MAC_PROPERTY_T property,
                                       UI32_T *ptr_param0,
                                       UI32_T *ptr_param1);

/**
 * @brief To set eth port dead lock
 *
 * @param [in]     unit    - Chip id
 * @param [in]     port    - Port id
 * @param [in]     queue   - Queue id
 * @param [in]     mode    - Dead lock state
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setDeadLock(const UI32_T unit,
                                    const UI32_T port,
                                    const UI32_T queue,
                                    const UI32_T mode);

/**
 * @brief To set eth port dead lock
 *
 * set  based on 0.74ns unit. For example 100ms 1.35*10^8 (80B EFCO);
 *
 * @param [in]     unit         - Chip id
 * @param [in]     port         - Port id
 * @param [in]     threshold    - Dead lock threshold
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setDeadLockTh(const UI32_T unit, const UI32_T port, const UI32_T threshold);

/**
 * @brief To set tx flush state
 *
 * Tx flush is write only feature.
 *
 * @param [in]     unit      - Chip id
 * @param [in]     port      - Port id
 * @param [in]     enable    - Flush state
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setTxFlush(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief To set tx queue flush state
 *
 * Tx que flush is write only feature.
 *
 * @param [in]     unit     - Chip id
 * @param [in]     port     - Port id
 * @param [in]     queue    - Flush queue
 * @param [in]     enable   - Mac tx flush enable/disable
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setTxQueFlush(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T queue,
                                      const UI32_T enable);

/**
 * @brief To set per queue Flow Control ignore
 *
 * @param [in]     unit      - Chip id
 * @param [in]     port      - Port id
 * @param [in]     queue     - Queue id
 * @param [in]     enable    - Fc ignore state
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setFlowCtrlIgnore(const UI32_T unit,
                                          const UI32_T port,
                                          const UI32_T queue,
                                          const UI32_T enable);

/**
 * @brief Set epl xoff mask.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - 1: enable epl xoff mask
 *                             0: disable epl xoff mask
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setTxXoffMask(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief check buffer empty.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_checkBufEmpty(const UI32_T unit, const UI32_T port);

/**
 * @brief Set rx port status.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - 1: enable
 *                             0: disable
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setRxAdminState(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief Set tx port status.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - 1: enable
 *                             0: disable
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setTxAdminState(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief config cpx port pl.
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     port     - cpx port id(256,257,259)
 * @param [in]     speed    - cpi speed,max 100g
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_cfgCpxPl(const UI32_T unit, const UI32_T port, CLX_PORT_SPEED_T speed);

/**
 * @brief This API is used to set the cut through state for a specific port.
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     port     - Physical port ID
 * @param [in]     speed    - Physical port speed
 * @param [in]     ct_en    - Cut throught state
 *                            1 for cut through state
 *                            0 for store and forward state
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setCutThrough(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T speed,
                                      const UI32_T ct_en);

/**
 * @brief To set the flow control configuration for a specific port.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port             - Physical port id
 * @param [in]     channel_num      - Port buffer num
 * @param [in]     speed            - Physical port speed
 * @param [in]     fc_mode          - HAL_MT_NAMCHABARWA_PORT_FC_T
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setFlowControl(const UI32_T unit,
                                       const UI32_T port,
                                       const UI32_T channel_num,
                                       const UI32_T speed,
                                       const UI32_T fc_mode);

/**
 * @brief To set pkt drop for tm module.
 * @param [in]     unit     - Device unit number
 * @param [in]     port     - Physical port id
 * @param [in]     channel_num - Port buffer num
 * @param [in]     speed    - Physical port speed
 * @param [in]     drop_flg - drop flag
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setPktDrop(const UI32_T unit,
                                   const UI32_T port,
                                   const UI32_T channel_num,
                                   const UI32_T speed,
                                   const UI32_T drop_flg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setFabric(const UI32_T unit, const UI32_T port, const UI32_T fabric_en);

CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getFabric(const UI32_T unit, const UI32_T port, UI32_T *fabric_en);

/**
 * @brief config mburst property.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [in]     ptr_property - Property type
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setMburstProperty(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_PORT_MBURST_PROPERTY_T *ptr_property);

/**
 * @brief get mburst property.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [in]     ptr_property - Property type
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getMburstProperty(const UI32_T unit,
                                          const UI32_T port,
                                          CLX_PORT_MBURST_PROPERTY_T *ptr_property);

/**
 * @brief get mburst histogram statistic
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Port
 * @param [in]     dir       - IPL or EPL
 * @param [in]     p_stat    - statistic
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getMburstStat(const UI32_T unit,
                                      const UI32_T port,
                                      const CLX_DIR_T dir,
                                      CLX_PORT_MBURST_STAT_T *p_stat);

/**
 * @brief get mburst histogram count
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical Port ID
 * @param [in]     dir          - IPL or EPL
 * @param [in]     thrd_num     - Threshold num
 * @param [out]    ptr_count    - Mburst Histogram count
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_getMburstHistCnt(const UI32_T unit,
                                         const UI32_T port,
                                         const CLX_DIR_T dir,
                                         const UI32_T thrd_num,
                                         UI32_T *ptr_count);

/**
 * @brief clear mburst count
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port
 * @param [in]     dir     - IPL or EPL
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_port_setMburstClear(const UI32_T unit, const UI32_T port, const CLX_DIR_T dir);

#endif /* #ifndef HAL_MT_NAMCHABARWA_PORT_H */
