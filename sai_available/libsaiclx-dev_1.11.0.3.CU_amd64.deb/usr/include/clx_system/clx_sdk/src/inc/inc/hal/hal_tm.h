/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_tm.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_TM_H
#define HAL_TM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>
#include <clx_swc.h>
#include <clx_tm.h>
#include <osal/osal_timer.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* front port num + pcie + 2 cpi + 2 rc */
#define HAL_TM_HW_PORT_NUM (HAL_PORT_NUM_MAX + 1 + 2 + 2)

/*#define HAL_TM_DEBUG_PRINTF_EABLED*/
/*high 4 bit(bit[31:28]) means object type*/
#define HAL_TM_HANDLER_TYPE_SHIFT (28)

/*bit[31:28] object type encoding*/
#define HAL_TM_HANDLER_LEGACY_QUEUE_TYPE    (0)
#define HAL_TM_HANDLER_UNICAST_QUEUE_TYPE   (1)
#define HAL_TM_HANDLER_MULTICAST_QUEUE_TYPE (2)
#define HAL_TM_HANDLER_SCHEDULE_NODE_TYPE   (3)

/* queue num*/
#define HAL_TM_CPU_QUEUE_NUM       (48)
#define HAL_TM_UNICAST_QUEUE_NUM   (8)
#define HAL_TM_MULTICAST_QUEUE_NUM (8)
#define HAL_TM_LEGACY_QUEUE_NUM    (8)
#define HAL_TM_CPI_QUEUE_NUM       (8)

/*DEQ ranker queue status query time(unit is us)*/
#define HAL_TM_DEQ_RANKER_QUERY_TIME (50)

/*DEQ ranker queue status query loops is limited to be 160*/
#define HAL_TM_DEQ_RANKER_QUERY_MAX_LOOP (160)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TM_MISC_LOCK(unit)       (hal_tm_misc_lockResource(unit))
#define HAL_TM_MISC_UNLOCK(unit)     (hal_tm_misc_unlockResource(unit))
#define HAL_TM_SNAPSHOT_LOCK(unit)   (hal_tm_snapshot_lockResource(unit))
#define HAL_TM_SNAPSHOT_UNLOCK(unit) (hal_tm_snapshot_unlockResource(unit))

#define HAL_TM_HANDLER_SET(handler, type, id) \
    ((handler) = ((type) << HAL_TM_HANDLER_TYPE_SHIFT) + (id))

#define HAL_TM_HANDLER_GET(handler, type, id)                         \
    do {                                                              \
        (type) = ((handler) >> HAL_TM_HANDLER_TYPE_SHIFT);            \
        (id) = ((handler) & ((1U << HAL_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while (0)

#define HAL_TM_HANDLER_ID_GET(handler, id)                            \
    do {                                                              \
        (id) = ((handler) & ((1U << HAL_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while (0)

/* handler id valid check*/
#define HAL_TM_UNICAST_QUEUE_HANDLER_ID_VALID(id) (((id) >= 0) && ((id) < HAL_TM_UNICAST_QUEUE_NUM))

#define HAL_TM_MULTICAST_QUEUE_HANDLER_ID_VALID(id) \
    (((id) >= 0) && ((id) < HAL_TM_MULTICAST_QUEUE_NUM))

#define HAL_TM_CPU_QUEUE_HANDLER_ID_VALID(id) ((id) < HAL_TM_CPU_QUEUE_NUM)

#define HAL_TM_LEGACY_QUEUE_HANDLER_ID_VALID(id) \
    ((((I32_T)id) >= 0) && ((id) < HAL_TM_LEGACY_QUEUE_NUM))

/*schedule node handler id valid check, root node is exculde*/
#define HAL_TM_SCHEDULE_NODE_HANDLER_ID_VALID(id) (((id) >= 0) && ((id) < HAL_TM_SCH_NODE_NUM - 1))

/*check macro*/
#define HAL_TM_CHECK_MIN_MAX_RANGE(__value__, __min__, __max__) \
    (((__value__) > (__max__)) || ((__value__) < (__min__)))

#define HAL_TM_SNAPSHOT_TASK_NAME ("SNAPSHOT_TASK")
#define HAL_TM_SNAPSHOT_SEM_NAME  ("TM_SNAPSHOT")
#define HAL_TM_SNAPSHOT_LIST_NAME ("TM_SNAPSHOT_LIST")

/* unit 10ms */
#define HAL_TM_SNAPSHOT_INTERVAL_UNIT (10 * 1000)
#define HAL_TM_SNAPSHOT_STACK_SIZE    (64 * 1024)
#define HAL_TM_SNAPSHOT_THREAD_PRI    (10)
#define HAL_TM_SNAPSHOT_CALLBACK_NUM  (3)

/* PFCWD Task */
#define HAL_TM_PFCWD_DEFAULT_INTERVAL_MS (10) // Defaule 10ms
#define HAL_TM_PFCWD_STACK_SIZE          (64 * 1024)
#define HAL_TM_PFCWD_SEM_NAME            ("TM_PFCWD")
#define HAL_TM_PFCWD_TASK_NAME           ("PFCWD_TASK")
#define HAL_TM_PFCWD_THREAD_PRI          (10)
#define HAL_TM_PFCWD_CALLBACK_NUM        (3)
#define HAL_TM_PFCWD_PFC_PRI_NUM         (8)

/* customer init type default value*/
#define HAL_TM_CFG_TYPE_STEERING_TRUNCATE_ENABLE_DFLT (0)   /* do not truncate */
#define HAL_TM_CFG_TYPE_BUF_SNAPSHOT_INTERVAL_DFLT    (100) /* 100 units (100 * 10ms = 1s) */

#define HAL_TM_CFG_TYPE_BUF_FAIR_BUF_CTRL     (1)
#define HAL_TM_CFG_TYPE_BUF_USER_BUF_CTRL     (0)
#define HAL_TM_CFG_TYPE_FLOWCTRL_RESERVE_MODE (0)

#define HAL_TM_ERROR_RETURN(module, rc, fmt, args...)                                          \
    {                                                                                          \
        if (CLX_E_OK != rc) {                                                                  \
            DIAG_PRINT(module, HAL_DBG_ERR, "[error:%s-%d]:" fmt, clx_error_getString(rc), rc, \
                       ##args);                                                                \
            return rc;                                                                         \
        }                                                                                      \
    }

#define HAL_TM_ERROR_NO_RETURN(module, rc, fmt, args...)                                       \
    {                                                                                          \
        if (CLX_E_OK != rc) {                                                                  \
            DIAG_PRINT(module, HAL_DBG_ERR, "[error:%s-%d]:" fmt, clx_error_getString(rc), rc, \
                       ##args);                                                                \
        }                                                                                      \
    }

#define HAL_TM_ERROR_GOTO_LABEL(module, rc, label, fmt, args...)                               \
    {                                                                                          \
        if (CLX_E_OK != rc) {                                                                  \
            DIAG_PRINT(module, HAL_DBG_ERR, "[error:%s-%d]:" fmt, clx_error_getString(rc), rc, \
                       ##args);                                                                \
            goto label;                                                                        \
        }                                                                                      \
    }

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_TDM_MACRO_PORT_ONE = 0,
    HAL_TDM_MACRO_PORT_TWO,
    HAL_TDM_MACRO_PORT_FOUR,
    HAL_TDM_MACRO_PARTIAL_PORT_ONE,
    HAL_TDM_MACRO_PARTIAL_PORT_TWO,
    HAL_TDM_MACRO_PARTIAL_PORT_THREE,
    HAL_TDM_MACRO_LAST
} HAL_TDM_RESULT_T;

/* TDM related structure */
typedef struct HAL_TM_PLANE_TDM_S {
#define HAL_TM_TDM_OS_ONLY       (1U << 0)
#define HAL_TM_TDM_40G_ONLY      (1U << 1)
#define HAL_TM_TDM_CLOCK_900MHZ  (1U << 2)
#define HAL_TM_TDM_CLOCK_975MHZ  (1U << 3)
#define HAL_TM_TDM_CLOCK_1075MHZ (1U << 4)
#define HAL_TM_TDM_WITH_PCI_PORT (1U << 5)
#define HAL_TM_TDM_WITH_CPI_PORT (1U << 6)
#define HAL_TM_TDM_CLOCK_924MHZ  (1U << 7)
#define HAL_TM_TDM_WITH_RC_PORT  (1U << 8)

    UI32_T flags;
    UI32_T slot_period;
    I16_T slot_array[256];
} HAL_TM_PLANE_TDM_T;

typedef struct HAL_TM_TDM_CB_S {
    HAL_TM_PLANE_TDM_T *ptr_plane_tdm_info[32]; /*avoid coverity*/
} HAL_TM_TDM_CB_T;

/* Port Speed */
/* Please check HW define for all speed setting when add other speed*/
typedef enum {
    HAL_TM_PORT_SPEED_1G = 0,
    HAL_TM_PORT_SPEED_10G,
    HAL_TM_PORT_SPEED_25G,
    HAL_TM_PORT_SPEED_40G,
    HAL_TM_PORT_SPEED_50G,
    HAL_TM_PORT_SPEED_100G,
    HAL_TM_PORT_SPEED_200G,
    HAL_TM_PORT_SPEED_400G,
    HAL_TM_PORT_SPEED_800G,
    HAL_TM_PORT_SPEED_LAST
} HAL_TM_PORT_SPEED_T;

/*structure of TM MAC MACRO*/
typedef struct HAL_TM_MAC_MACRO_S {
    UI8_T ppid_lane0; /*PPID for lane 0, 63 for default*/
    UI8_T ppid_lane1; /*PPID for lane 1, 63 for default*/
    UI8_T ppid_lane2; /*PPID for lane 2, 63 for default*/
    UI8_T ppid_lane3; /*PPID for lane 3, 63 for default*/
    UI32_T gp;        /*1:gaurantee port; 0: non-gautantee port*/
} HAL_TM_MAC_MACRO_T;

/*structure of TM PPID*/
typedef struct HAL_TM_PPID_S {
    UI16_T mac_macro; /*TM MAC MACRO ID*/
    UI16_T lane;      /*0~3*/
} HAL_TM_PPID_T;

/*Type of CLX port translate*/
typedef enum {
    HAL_TM_PORT_TRANS_TYPE_MP = 0,
    HAL_TM_PORT_TRANS_TYPE_PP,
    HAL_TM_PORT_TRANS_TYPE_LAST
} HAL_TM_PORT_TRANS_TYPE_T;

typedef enum {
    HAL_TM_PFCWD_EVENT_ENABLE, /* Feature turn to enable */
    HAL_TM_PFCWD_EVENT_DISABLE,
    HAL_TM_PFCWD_EVENT_DETECTED,
    HAL_TM_PFCWD_EVENT_RECOVER_TIMEOUT,
    HAL_TM_PFCWD_EVENT_CONFIG_CHANGE, /* Already Enabled but configure change */
    HAL_TM_PFCWD_EVENT_PFC_MAP_CHANGED,
    HAL_TM_PFCWD_EVENT_WARM_DEINIT,   /* Warmboot deinit, restore to oper state */
    HAL_TM_PFCWD_EVENT_LAST
} HAL_TM_PFCWD_EVENT_T;

/*control block for misc module*/
typedef struct HAL_TM_MISC_CB_S {
    CLX_SEMAPHORE_ID_T misc_sema; /*semaphore for misc module*/
} HAL_TM_MISC_CB_T;

typedef struct HAL_TM_SNAPSHOT_CALLBACK_S {
    CLX_TM_SNAPSHOT_FUNC_T callback;
    void *ptr_cookie;
} HAL_TM_SNAPSHOT_CALLBACK_T;

typedef struct HAL_TM_TASK_SNAPSHOT_CB_S {
    CLX_SEMAPHORE_ID_T sem_snapshot;
    CLX_THREAD_ID_T snapshot_task_id;
    CLX_TM_POOL_BUF_SNAPSHOT_T snapshot[HAL_BIN_NUM_MAX];
    UI32_T interval;
    UI32_T egr_global_hys_thd;
    HAL_TM_SNAPSHOT_CALLBACK_T callback_list[HAL_TM_SNAPSHOT_CALLBACK_NUM];
    BOOL_T valid;
} HAL_TM_TASK_SNAPSHOT_CB_T;

typedef struct HAL_TM_PFCWD_TIMER_ENTRY_S {
    UI32_T unit;
    UI32_T port;
    UI8_T queue_id;
} HAL_TM_PFCWD_TIMER_ENTRY_T;

typedef struct HAL_TM_PFCWD_ASYN_EVENT_S {
    UI32_T unit;
    UI32_T port;
    UI8_T queue_id;
    HAL_TM_PFCWD_EVENT_T event;
    UI32_T arg;
} HAL_TM_PFCWD_ASYN_EVENT_T;

typedef struct HAL_TM_PFCWD_QUEUE_ENTRY_S {
    BOOL_T enable;
    UI8_T queue;
    UI8_T reg_member_idx;
    CLX_TM_PFCWD_STATE_T state;
    UI32_T detection_time; // Detection Time in ms
    UI32_T recovery_time;  // Recovery  Time in ms
    CLX_TM_PFCWD_ACTION_T action;
    UI32_T rx_pfc_pri_mapping;
    CLX_PORT_FC_T old_mac_pfc_config[HAL_TM_PFCWD_PFC_PRI_NUM];
    OSAL_TIMER_ID_T timerid;
    HAL_TM_PFCWD_TIMER_ENTRY_T
    *restore_timer_entry; /* arg for timeout, need free when timeout or timer stop*/
} HAL_TM_PFCWD_QUEUE_ENTRY_T;

typedef struct HAL_TM_PFCWD_PORT_ENTRY_S {
    CLX_SEMAPHORE_ID_T sem;
    UI8_T supported_pfc_num;
    HAL_TM_PFCWD_QUEUE_ENTRY_T *queue_entry;
} HAL_TM_PFCWD_PORT_ENTRY_T;

typedef struct HAL_TM_PFCWD_CALLBACK_S {
    CLX_TM_PFCWD_HANDLE_FUNC_T callback;
    void *ptr_cookie;
} HAL_TM_PFCWD_CALLBACK_T;

typedef struct HAL_TM_TASK_PFCWD_CB_S {
    CLX_SEMAPHORE_ID_T sem_pfcwd; // Protect callback_list, port entry also has it own lock.
    CLX_THREAD_ID_T task_id;
    UI32_T interval;
    HAL_TM_PFCWD_PORT_ENTRY_T entry_array[HAL_PORT_NUM_MAX];
    HAL_TM_PFCWD_CALLBACK_T callback_list[HAL_TM_PFCWD_CALLBACK_NUM];
} HAL_TM_TASK_PFCWD_CB_T;

typedef struct HAL_TM_TASK_CB_S {
    HAL_TM_TASK_SNAPSHOT_CB_T snapshot_cb;
} HAL_TM_TASK_CB_T;

typedef enum {
    HAL_TM_TRUNC_TYPE_MIRROR = 0,      /* mirror type */
    HAL_TM_TRUNC_TYPE_TOCPU,           /* to cpu type */
    HAL_TM_TRUNC_TYPE_MOD,             /* mod type */
    HAL_TM_TRUNC_TYPE_ENCAP_SHIM,      /* encap shim type */
    HAL_TM_TRUNC_TYPE_ENCAP_SHIM_META, /* encap shim meta type */
    HAL_TM_TRUNC_TYPE_NO_DECAP,        /* no decap type */
    HAL_TM_TRUNC_TYPE_CPA_MARK,        /* cpa(cut payload) mark type */
    HAL_TM_TRUNC_TYPE_ACL,             /* mirror type */
    HAL_TM_TRUNC_TYPE_LAST
} HAL_TM_TRUNC_TYPE_T;

typedef enum {
    HAL_TM_TRUNC_SIZE_64 = 0, /* 64 bytes*/
    HAL_TM_TRUNC_SIZE_128,    /* 128 bytes */
    HAL_TM_TRUNC_SIZE_192,    /* 192 bytes */
    HAL_TM_TRUNC_SIZE_256,    /* 256 bytes */
    HAL_TM_TRUNC_SIZE_512,    /* 512 bytes */
    HAL_TM_TRUNC_SIZE_984,    /* 984 bytes */
    HAL_TM_TRUNC_SIZE_1024,   /* 1024 bytes */
    HAL_TM_TRUNC_SIZE_LAST
} HAL_TM_TRUNC_SIZE_T;

typedef struct HAL_TM_TRUNCATION_PROFILE_S {
    HAL_TM_TRUNC_TYPE_T trunc_type; /* truncation packet type */
    UI32_T profile_id;              /* truncation profile index*/
    HAL_TM_TRUNC_SIZE_T trunc_size; /* packet truncation size*/
                                    /* only support 64/128/192/256/512/1024 byte*/
    BOOL_T enable; /* the profile_id profile enable or disable truncation function*/
} HAL_TM_TRUNCATION_RPOFILE_T;

typedef struct HAL_TM_TRUNCATION_CONFIG_S {
    HAL_TM_TRUNC_TYPE_T trunc_type; /* truncation packet type */
    CLX_MIR_DIRECTION_T dir;        /* type is mirror to use, mirror direction*/
    UI32_T session_id;              /* type is mirror to use, mirror session*/
    UI32_T cpu_queue_id;            /* type is toCpu to use, cpu queueu id*/
    UI32_T profile_id;              /* truncation profile index*/
} HAL_TM_TRUNCATION_CONFIG_T;

typedef struct HAL_TM_TCB_TRIGGER_IGR_DATA_S {
    UI32_T valid;                 /* valid, 1 bit */
    UI32_T di;                    /* di, 16 bits */
    UI32_T int_role;              /* INT role, 2 bits */
    UI32_T int_mode;              /* IMT mode, 2 bit */
    UI32_T int_clone;             /* IMT clone, 1 bit */
    UI32_T tc;                    /* tc, 2 bits */
    UI32_T cpu_valid;             /* cpu valid, 1 bit */
    UI32_T cpu_redir;             /* cpu redirect, 1 bit */
    UI32_T cpu_dest;              /* cpu dest, 2 bit */
    UI32_T cpu_queue;             /* cpu queue id, 6 bit */
    UI32_T ct_mode;               /* cut through mode, 1 bit */
    UI32_T pkt_size;              /* packet size, 14 bits */
    UI32_T mirror_session;        /* mirror session id, 8 bits */
    UI32_T mod_en;                /* Mod enable, 1 bit */
    UI32_T acl_redirect_trunc_en; /* Acl redirect truncation enable, 1 bit */
    UI32_T cpa_en;                /* CPU enable, 1 bit */
    UI32_T flow_hash;             /* flow hash, 10 bit */
    UI32_T meter_color;           /* meter color, 2 bit */
    UI32_T pkj;                   /* pkj, 1 bit */
    UI32_T sop;                   /* sop, 1 bit */
    UI32_T eop;                   /* eop, 1 bit */
    UI32_T frag_size;             /* frag size, 8 bit */
    UI32_T rec_vld;               /* recive valid, 1 bit */
    UI32_T sport;                 /* source port, cl port */
    UI32_T drop_reason_code;      /* drop reason code, 6 bit*/
} HAL_TM_TCB_TRIGGER_IGR_DATA_T;

typedef struct HAL_TM_TCB_TRIGGER_EGR_DATA_S {
    UI32_T valid;       /* valid, 1 bit */
    UI32_T pkt_size;    /* packet size, 14 bits*/
    UI32_T oq;          /* out queue, 12 bits */
    UI32_T cud_type;    /* cud type, 5 bits */
    UI32_T cud_value;   /* cud value, 16 bits */
    UI32_T ecn_mark;    /* ecn mark, 1 bit */
    UI32_T cpa_mark;    /* cpa mark, 1 bit */
    UI32_T trunc;       /* truncation, 1 bit */
    UI32_T sop;         /* sop, 1 bit */
    UI32_T eop;         /* eop, 1 bit */
    UI32_T frag_size;   /* frag size, 8 bit */
    UI32_T error;       /* error flag, 1 bit */
    UI32_T dport;       /* dest port, cl port */
    UI32_T pd_fifo_num; /* pd fifo num, 2 bit */
} HAL_TM_TCB_TRIGGER_EGR_DATA_T;
typedef struct HAL_TM_TCB_CAPTURE_S {
#define HAL_TM_TCB_MATCH_TYPE_INGRESS (0)    /* TCB match ingress type */
#define HAL_TM_TCB_MATCH_TYPE_EGRESS  (1)    /* TCB match egress type */
    UI32_T match_type;                       /* TCB match type */
    HAL_TM_TCB_TRIGGER_IGR_DATA_T igr_match; /* ingress match key */
    HAL_TM_TCB_TRIGGER_IGR_DATA_T igr_mask;  /* ingress match mask */
    HAL_TM_TCB_TRIGGER_EGR_DATA_T egr_match; /* egress match key */
    HAL_TM_TCB_TRIGGER_EGR_DATA_T egr_mask;  /* egress match mask */
} HAL_TM_TCB_CAPTURE_KEY_T;

typedef struct HAL_TM_TCB_TRIGGER_DATA_S {
#define HAL_TM_TCB_TRIG_DATA_TYPE_INGRESS (0) /* TCB match ingress type */
#define HAL_TM_TCB_TRIG_DATA_TYPE_EGRESS  (1) /* TCB match egress type */
    UI32_T trig_data_type;                    /* TCB match type */
    HAL_TM_TCB_TRIGGER_IGR_DATA_T igr_data;   /* TCB ingress trigger data */
    HAL_TM_TCB_TRIGGER_EGR_DATA_T egr_data;   /* TCB egress trigger data */
} HAL_TM_TCB_TRIGGER_DATA_T;

typedef struct HAL_TM_TCB_CAPTURE_DATA_S {
#define HAL_TM_TCB_CAPTURE_PKT_LEN (10240)      /* max capture packet size */
    UI64_T timestamp;                           /* capture packet timestamp */
    HAL_TM_TCB_TRIGGER_DATA_T trigger_data;     /* TCB trigger data */
    UI8_T pkt_data[HAL_TM_TCB_CAPTURE_PKT_LEN]; /* capture packet data */
} HAL_TM_TCB_CAPTURE_DATA_T;

typedef enum HAL_TM_ELAM_MODULE_S {
    HAL_TM_ELAM_MODULE_ASM,        /* NB TM submodule ASM */
    HAL_TM_ELAM_MODULE_REP,        /* NB TM submodule REP */
    HAL_TM_ELAM_MODULE_BAC,        /* NB TM submodule BAC */
    HAL_TM_ELAM_MODULE_BAC_TOP,    /* NB TM submodule BAC_TOP */
    HAL_TM_ELAM_MODULE_OQC,        /* NB TM submodule OQC */
    HAL_TM_ELAM_MODULE_DQC,        /* NB TM submodule DQC */
    HAL_TM_ELAM_MODULE_DQC_TOP,    /* NB TM submodule DQC_TOP */
    HAL_TM_ELAM_MODULE_FRG,        /* NB TM submodule FRG */
    HAL_TM_ELAM_MODULE_PDB_CENTER, /* NB TM submodule PDB_CENTER */
    HAL_TM_ELAM_MODULE_LAST
} HAL_TM_ELAM_MODULE_T;

typedef struct HAL_TM_ELAM_TRIGGER_CONFIG_S {
    HAL_TM_ELAM_MODULE_T module; /* NB TM submodule */
    UI32_T slice;                /* slice id or plane id */
    UI32_T bus_sel;              /* bus select */
    UI32_T count;                /* trigger count */
    BOOL_T enable;               /* enable or disable trigger */
} HAL_TM_ELAM_TRIGGER_CONFIG_T;

typedef struct HAL_TM_ELAM_TRIGGER_DATA_S {
#define HAL_TM_ELAM_TRIGGER_DATA_SIZE (16)             /* ELAM trigger data length */
    UI8_T trigger_data[HAL_TM_ELAM_TRIGGER_DATA_SIZE]; /* ELAM trigger data */
} HAL_TM_ELAM_TRIGGER_DATA_T;

typedef struct HAL_TM_ELAM_CAPTURE_DATA_S {
    HAL_TM_ELAM_TRIGGER_DATA_T trigger_data; /* ELAM capture trigger data */
    UI64_T timestamp;                        /* ELAM capture timestamp */
} HAL_TM_ELAM_CAPTURE_DATA_T;

typedef struct HAL_TM_ELAM_TRIGGER_KEY_S {
    HAL_TM_ELAM_TRIGGER_DATA_T match; /* ELAM trigger math key */
    HAL_TM_ELAM_TRIGGER_DATA_T mask;  /* ELAM trigger math mask */
} HAL_TM_ELAM_TRIGGER_KEY_T;

CLX_ERROR_NO_T
hal_tm_misc_lockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_misc_unlockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_misc_initRsrc(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_misc_deinitRsrc(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_misc_deinitCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_initRsrc(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_deinitRsrc(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_deinitCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_setProperty(const UI32_T unit,
                   const UI32_T port,
                   const CLX_TM_HANDLER_T handler,
                   const CLX_TM_PROPERTY_T property,
                   const UI32_T param0,
                   const UI32_T param1);

CLX_ERROR_NO_T
hal_tm_getProperty(const UI32_T unit,
                   const UI32_T port,
                   const CLX_TM_HANDLER_T handler,
                   const CLX_TM_PROPERTY_T property,
                   UI32_T *ptr_param0,
                   UI32_T *ptr_param1);

void
hal_tm_getPlaneNum(const UI32_T unit, UI32_T *ptr_plane_num);

void
hal_tm_getBinNum(const UI32_T unit, UI32_T *ptr_bin_num);

CLX_ERROR_NO_T
hal_tm_dumpDb(const UI32_T unit, const UI32_T flags);

CLX_ERROR_NO_T
hal_tm_dumpReg(const UI32_T unit, const UI32_T flags);

CLX_ERROR_NO_T
hal_tm_getTdmCtrlBlock(const UI32_T unit, HAL_TM_TDM_CB_T **pptr_cb);

CLX_ERROR_NO_T
hal_tm_getTdmPlaneCtrlBlock(const UI32_T unit,
                            const UI32_T plane_idx,
                            HAL_TM_PLANE_TDM_T **pptr_pl_cb);

CLX_ERROR_NO_T
hal_tm_initTaskRsrc(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_deinitTaskRsrc(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_getSnapshotTaskCtrlBlock(const UI32_T unit, HAL_TM_TASK_SNAPSHOT_CB_T **pptr_cb);

CLX_ERROR_NO_T
hal_tm_snapshot_lockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_snapshot_unlockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_pfcwd_lockPortResource(const UI32_T unit, const CLX_PORT_T port);
CLX_ERROR_NO_T
hal_tm_pfcwd_unlockPortResource(const UI32_T unit, const CLX_PORT_T port);
CLX_ERROR_NO_T
hal_tm_pfcwd_lockResource(const UI32_T unit);
CLX_ERROR_NO_T
hal_tm_pfcwd_unlockResource(const UI32_T unit);
CLX_ERROR_NO_T
hal_tm_initPfcWdTaskRsrc(const UI32_T unit);
CLX_ERROR_NO_T
hal_tm_deinitPfcWdTaskRsrc(const UI32_T unit);
C8_T *
hal_tm_getPfcWdEventString(const HAL_TM_PFCWD_EVENT_T event);
C8_T *
hal_tm_getPfcWdStateString(const CLX_TM_PFCWD_STATE_T state);

CLX_ERROR_NO_T
hal_tm_getPfcWdTaskCtrlBlock(const UI32_T unit, HAL_TM_TASK_PFCWD_CB_T **pptr_cb);

CLX_ERROR_NO_T
hal_tm_getPfcWdQueueEntry(const UI32_T unit,
                          const CLX_PORT_T port,
                          const UI32_T queue,
                          HAL_TM_PFCWD_QUEUE_ENTRY_T **pptr_entry);

CLX_ERROR_NO_T
hal_tm_registerPfcWdCallback(const UI32_T unit,
                             const CLX_TM_PFCWD_HANDLE_FUNC_T notify_function,
                             void *ptr_cookie);

CLX_ERROR_NO_T
hal_tm_deregisterPfcWdCallback(const UI32_T unit,
                               const CLX_TM_PFCWD_HANDLE_FUNC_T notify_function,
                               void *ptr_cookie);

CLX_ERROR_NO_T
hal_tm_PfcWdStateEventHandler(const UI32_T unit,
                              const CLX_PORT_T port,
                              const UI8_T queue_id,
                              const HAL_TM_PFCWD_EVENT_T event,
                              CLX_TM_PFCWD_ENTRY_T *new_pfcwd_config);

/**
 * @brief This API is used to configure PFCWD on queue.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - physical port ID
 * @param [in]     handler      - Egress queue handler
 * @param [in]     ptr_entry    - PFCWD Configuration.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_tm_setPfcWd(const UI32_T unit,
                const CLX_PORT_T port,
                const CLX_TM_HANDLER_T handler,
                CLX_TM_PFCWD_ENTRY_T *ptr_entry);

/**
 * @brief This API is used to get current configuration of PFCWD.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - physical port ID
 * @param [in]     handler      - Egress queue handler.
 * @param [out]    ptr_entry    - PFCWD Configuration
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_tm_getPfcWd(const UI32_T unit,
                const CLX_PORT_T port,
                const CLX_TM_HANDLER_T handler,
                CLX_TM_PFCWD_ENTRY_T *ptr_entry);

/**
 * @brief This API is used to get current state of PFCWD.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - physical port ID
 * @param [in]     handler      - queue handler.
 * @param [out]    ptr_state    - PFCWD Current State
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_tm_getPfcWdState(const UI32_T unit,
                     const CLX_PORT_T port,
                     const CLX_TM_HANDLER_T handler,
                     CLX_TM_PFCWD_STATE_T *ptr_state);

void
hal_tm_processPfcWdCallbackFunc(const UI32_T unit,
                                const CLX_PORT_T port,
                                const UI8_T queue,
                                const CLX_TM_PFCWD_EVENT_T pfcwd_event);

void
hal_tm_PfcWdRestoreTimerHandler(void *arg);
#endif /* #ifndef HAL_TM_H */
