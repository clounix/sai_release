/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_l3t.h
 * PURPOSE:
 *      It provide l3 tunnel hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_L3T_H
#define HAL_L3T_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_l3t.h>
#include <hal/hal_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define TERM_ECN_MAP_MODE (0) /* fix term ecn_map_mode to rfc6040 */

#define ALLOC_ZERO_FIELDS (0) /* alloc index in hal-cim only, no hw read-write */
#define ALLOC_ONE_ENTRY   (1)

/* Seg's MSB may be used as control bit, e.g. MPLSoTNL, thus 0 is safer */
#define HAL_L3T_INVALID_SEG (0x0)

#define HAL_L3T_MAX_NUM_OF_FLEX_TUNNEL (0x4)

#define FLEX_TUNNEL_TYPE_IP  (1)                /* IDS_KEY_DECAP_FLEX.typ */
#define FLEX_TUNNEL_TYPE_UDP (2)                /* IDS_KEY_DECAP_FLEX.typ */

#define HAL_L3T_DEFAULT_VRFO_ID       (0x0)     /* Default vrf id of underlay network */
#define HAL_L3T_MAX_NUM_OF_VRFO       (512)     /* Max number of vrfo */
#define HAL_L3T_MAX_VLAN_VAL          (0xFFF)
#define HAL_L3T_MAX_NUM_OF_ES_GROUP   (128)     /* Max number of ethernet segment group */
#define HAL_L3T_ENCAP_IDX_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_TUNNEL_NUM))
#define HAL_L3T_MAX_NUM_OF_MY_TNL_MAC (512)     /* entry number of IDS_KEY_TCAM_MY_TNL_MAC */
#define HAL_L3T_MAX_NUM_OF_DST_TEP    (512)     /* entry number of TDS_TCAM_DST_TEP */
#if defined(CLX_EN_DAWN)
#define HAL_L3T_MAX_NUM_OF_MY_TNL_MAC_PORT (34) /* entry number of reg:ids.my_tnl_mac_port */
#else
#define HAL_L3T_MAX_NUM_OF_MY_TNL_MAC_PORT (66)
#endif
#define HAL_L3T_FLAGS_1Q        (0x1U << 0)
#define HAL_L3T_FLAGS_SID_VALID (0x1U << 1)
#define HAL_L3T_FLAGS_CID_VALID (0x1U << 2)

/* {cp2cpu, drop, ecn[1:0]} */
#define HAL_L3T_ECN_GET_ACT(__val__) (__val__ = __val__ & 0xC)
#define HAL_L3T_ECN_ACT_CP2CPU       (0x8)   /* 0b10xx = cp2cpu        */
#define HAL_L3T_ECN_ACT_DROP         (0x4)   /* 0b01xx =          drop */
#define HAL_L3T_ECN_ACT_FWD          (0x0)   /* 0b00xx = n/a           */

#define HAL_L3T_PORT_MERGE_DEFAULT   (0xdff) /* Merge port index of vlan interface port */
#define HAL_L3T_INVALID_ECMP_MBR_IDX (0)     /* Invalid FWR_RSLT_TNL_ECMP_MBR idx */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_L3T_IS_TERM_MODE(__mode__)  (((HAL_L3T_TNL_MODE_TERM & __mode__) > 0) ? TRUE : FALSE)
#define HAL_L3T_IS_INIT_MODE(__mode__)  (((HAL_L3T_TNL_MODE_INIT & __mode__) > 0) ? TRUE : FALSE)
#define HAL_L3T_SET_TERM_MODE(__mode__) (__mode__ = (__mode__ | HAL_L3T_TNL_MODE_TERM))
#define HAL_L3T_SET_INIT_MODE(__mode__) (__mode__ = (__mode__ | HAL_L3T_TNL_MODE_INIT))
#define HAL_L3T_CLR_TERM_MODE(__mode__) (__mode__ = (__mode__ ^ HAL_L3T_TNL_MODE_TERM))
#define HAL_L3T_CLR_INIT_MODE(__mode__) (__mode__ = (__mode__ ^ HAL_L3T_TNL_MODE_INIT))

#define HAL_L3T_HAS_SEG_ID(__unit__, __tnl_type__) (hal_l3t_chkSegId(__unit__, __tnl_type__))
#define HAL_L3T_USE_CLX_PORT(__key__, __rev__)     (hal_l3t_chkIfUseClxPort(__key__, __rev__))

#define HAL_L3T_NVO3_ADJ_CPU_REASON (HAL_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L3UC)

/* Hw parser tunnel type value */
#define HAL_L3T_ULP_GRE_VALUE         (0x2F)
#define HAL_L3T_ULP_IP_TNL_IPV4_VALUE (0x4)
#define HAL_L3T_ULP_IP_TNL_IPV6_VALUE (0x29)
#define HAL_L3T_VXLAN_GPE_VALUE       (0x12B6)
#define HAL_L3T_VXLAN_BAS_VALUE       (0x12B5)
#define HAL_L3T_UDP_DP_GTP0_VALUE     (0x868)
#define HAL_L3T_UDP_DP_GTP1_VALUE     (0x869)
#define HAL_L3T_INVALID_PROTO_VALUE   (0)

#define HAL_L3T_REVERSE_TNLKEY(__key_out__, __key_in__)                                  \
    do {                                                                                 \
        osal_memcpy(&(__key_out__.src_ip), &(__key_in__.dst_ip), sizeof(CLX_IP_ADDR_T)); \
        osal_memcpy(&(__key_out__.dst_ip), &(__key_in__.src_ip), sizeof(CLX_IP_ADDR_T)); \
        __key_out__.tunnel_type = __key_in__.tunnel_type;                                \
        __key_out__.vrfo = __key_in__.vrfo;                                              \
    } while (0)
#define HAL_L3T_ENCAP_SIP_NUM (2048) /* cl8600: IPV4 srcip max encap number */
#define HAL_L3T_ENCAP_DIP_NUM (8192) /* cl8600: IPV4 dstip max encap number */
/* cl8600: srcip usage bitmap */
#define HAL_L3T_ENCAP_SIP_USAGE_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_L3T_ENCAP_SIP_NUM))
/* cl8600: dstip usage bitmap */
#define HAL_L3T_ENCAP_DIP_USAGE_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_L3T_ENCAP_DIP_NUM))
/* cl8600: dst_tep usage bitmap */
#define HAL_L3T_TERM_DST_TEP_USAGE_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_L3T_MAX_NUM_OF_DST_TEP))
/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_L3T_TNL_MODE_NONE,
    HAL_L3T_TNL_MODE_TERM,
    HAL_L3T_TNL_MODE_INIT,
    HAL_L3T_TNL_MODE_LAST
} HAL_L3T_TNL_MODE_T;

typedef enum {
    HAL_L3T_TRAV_TYPE_INIT,
    HAL_L3T_TRAV_TYPE_TERM,
    HAL_L3T_TRAV_TYPE_NVO3_ROUTE,
    HAL_L3T_TRAV_TYPE_PORT,
    HAL_L3T_TRAV_TYPE_LAST
} HAL_L3T_TRAV_TYPE_T;

typedef enum {
    HAL_L3T_DB_DUMP_FLAGS_PORT = 0,
    HAL_L3T_DB_DUMP_FLAGS_INIT,
    HAL_L3T_DB_DUMP_FLAGS_TERM,
    HAL_L3T_DB_DUMP_FLAGS_TNLMAC,
    HAL_L3T_DB_DUMP_FLAGS_NVO3ROUTE,
    HAL_L3T_DB_DUMP_FLAGS_NVO3ADJ,
    HAL_L3T_DB_DUMP_FLAGS_NV,
    HAL_L3T_DB_DUMP_FLAGS_ESGRP,
    HAL_L3T_DB_DUMP_FLAGS_MGO,
    HAL_L3T_DB_DUMP_FLAGS_LAST,
} HAL_L3T_DB_DUMP_FLAGS_T;

typedef enum {
    HAL_L3T_RM_TNL_ECMP_MODE_ADJ,
    HAL_L3T_RM_TNL_ECMP_MODE_ECMP,
    HAL_L3T_RM_TNL_ECMP_MODE_LAST
} HAL_L3T_RM_TNL_ECMP_MODE_T;

typedef struct HAL_L3T_ERSPAN_TERM_AVL_NODE_S {
    CLX_TUNNEL_KEY_T tnl_key; /* AVL tree key: term view */
    UI16_T lcl_intf_idx;
    UI32_T term_flags;
    UI32_T src_tep_idx;
} HAL_L3T_ERSPAN_TERM_AVL_NODE_T;

typedef struct HAL_L3T_KEY_AVL_NODE_S {
    CLX_TUNNEL_KEY_T tnl_key; /* AVL tree key: init view */
    UI32_T tnl_mode;          /* HAL_L3T_TNL_MODE_T */
    UI16_T lcl_intf_idx;
    UI16_T nvo3_encap_idx;
    UI16_T mc_mode;
    UI32_T init_flags; /* HAL_L3T_FLAGS_XXX, not used in cl8600 */
    UI32_T term_flags; /* HAL_L3T_FLAGS_XXX */
} HAL_L3T_KEY_AVL_NODE_T;

typedef struct HAL_L3T_PORT_AVL_NODE_S {
    CLX_TUNNEL_KEY_T tnl_key; /* AVL tree key: init view */
    UI32_T tnl_mode;          /* HAL_L3T_TNL_MODE_T */
    UI16_T nvo3_encap_idx;    /* relates CLX_TUNNEL_KEY_T and clx_port */
    UI32_T init_flags;        /* HAL_L3T_FLAGS_XXX, not used in cl8600 */
    UI32_T term_flags;        /* HAL_L3T_FLAGS_XXX */
    UI32_T tep_bind_idx;      /* relate to TDS_HSH_TEP_BIND */
} HAL_L3T_PORT_AVL_NODE_T;

typedef struct HAL_L3T_NVO3_ADJ_AVL_NODE_S {
    UI32_T nvo3_adj_id;          /* nvo3_adj hardware index */
    CLX_PORT_T port;             /* destination of nvo3_adj, only port/lag are allowed */
    UI32_T vid_flags;            /* HAL_L3T_FLAGS_XXX, not used in cl8600 */
    UI32_T tpid_flags;           /* HAL_L3T_FLAGS_XXX, not used in cl8600 */
    CMLIB_LIST_T *ptr_ecmp_list; /* UI32_T, ecmp path index list */
} HAL_L3T_NVO3_ADJ_AVL_NODE_T;

typedef struct HAL_L3T_NVO3_ENCAP_NODE_S {
    BOOL_T use_port;
    union {
        HAL_L3T_PORT_AVL_NODE_T *ptr_port_node;
        HAL_L3T_KEY_AVL_NODE_T *ptr_key_node;
    };
} HAL_L3T_NVO3_ENCAP_NODE_T;

typedef struct HAL_L3T_TNL_MAC_KEY_S {
    UI32_T tnl_port_idx;
    UI32_T vlan_id;
} HAL_L3T_TNL_MAC_KEY_T;

typedef struct HAL_L3T_TRAV_COOKIE_S {
    UI32_T unit;
    CMLIB_LIST_T *ptr_list;
} HAL_L3T_TRAV_COOKIE_T;

typedef struct HAL_L3T_NVO3_ADJ_TRAV_NODE_S {
    UI32_T adj_id;
    CLX_L3_ADJ_INFO_T adj_info;
} HAL_L3T_NVO3_ADJ_TRAV_NODE_T;

typedef struct HAL_L3T_TERM_DST_TEP_KEY_S {
    UI16_T vrfo;
    CLX_IP_ADDR_T dst_ip;
} HAL_L3T_TERM_DST_TEP_KEY_T;

typedef struct HAL_L3T_TERM_DIP_AVL_NODE_S {
    HAL_L3T_TERM_DST_TEP_KEY_T dst_tep; /* AVL tree key, tunnel_term.dst_ip and tunnel_term.vrfo */
    UI16_T entry_idx;                   /* tnl_decap's entry_idx */
    UI16_T ref_cnt;                     /* reference count */
} HAL_L3T_TERM_DIP_AVL_NODE_T;

typedef struct HAL_L3T_TERM_MGO_AVL_NODE_S {
    HAL_L3T_TERM_DST_TEP_KEY_T dst_tep; /* AVL tree key, tunnel_term.dst_ip and tunnel_term.vrfo */
    UI16_T entry_idx;                   /* tnl_decap's entry_idx */
    UI16_T ref_cnt;                     /* reference count */
} HAL_L3T_TERM_MGO_AVL_NODE_T;

typedef struct HAL_L3T_INIT_SIP_AVL_NODE_S {
    CLX_IP_ADDR_T src_ip;
    UI16_T prof_idx;
    UI16_T ref_cnt;
} HAL_L3T_INIT_SIP_AVL_NODE_T;

typedef struct HAL_L3T_CB_S {
    CMLIB_AVL_HEAD_T *ptr_key_avl;                     /* HAL_L3T_KEY_AVL_NODE_T       */
    CMLIB_AVL_HEAD_T *ptr_port_avl;                    /* HAL_L3T_PORT_AVL_NODE_T  */
    CMLIB_AVL_HEAD_T *ptr_term_dip_avl;                /* HAL_L3T_TERM_DIP_AVL_NODE_T  */
    CMLIB_AVL_HEAD_T *ptr_nvo3_adj_avl;                /* HAL_L3T_NVO3_ADJ_AVL_NODE_T      */
    CMLIB_AVL_HEAD_T *ptr_erspan_term_avl;             /* HAL_L3T_ERSPAN_TERM_AVL_NODE_T   */
    HAL_L3T_NVO3_ENCAP_NODE_T *ptr_nvo3_encap_idx_arr; /* HAL_L3T_NVO3_ENCAP_NODE_T        */

    CMLIB_AVL_HEAD_T *ptr_iev_ecmp_path_avl;           /* HAL_CMN_RTE_NODE_T   */
    HAL_CMN_RTE_NODE_T **pptr_iev_nvo3_adj_arr; /* maintain nvo3_adj_id->ecmp_path_idx relation */

    UI32_T tnl_mac_port_arr[HAL_L3T_MAX_NUM_OF_MY_TNL_MAC_PORT];
    /* index: tnl_mac_port, value: plane_port, for getTunnelMac. not used in cl8600 */
    UI32_T tnl_mac_vlan[HAL_L3T_MAX_NUM_OF_MY_TNL_MAC]; /* HAL_L3T_FLAGS_xxx */

    HAL_L3T_TNL_MAC_KEY_T
    tnl_mac_key_arr[HAL_L3T_MAX_NUM_OF_MY_TNL_MAC]; /* tunnel mac hash key, for cl8600 */
    UI32_T sip_usage_bitmap[HAL_L3T_ENCAP_SIP_USAGE_BITMAP_SIZE]; /* for cl8600 */
    CMLIB_AVL_HEAD_T *ptr_init_sip_avl;                           /* HAL_L3T_INIT_SIP_AVL_NODE_T */
    UI32_T dip_usage_bitmap[HAL_L3T_ENCAP_DIP_USAGE_BITMAP_SIZE]; /* for cl8600 */
    UI32_T dst_tep_usage_bitmap[HAL_L3T_TERM_DST_TEP_USAGE_BITMAP_SIZE]; /* for cl8600 */
    UI32_T esgrp_ref_arr[HAL_L3T_MAX_NUM_OF_ES_GROUP]; /* Bound tunnel port, for cl8600 */
    CMLIB_AVL_HEAD_T *ptr_term_mgo_avl;                /* HAL_L3T_TERM_MGO_AVL_NODE_T  */

    CLX_L3T_FLEX_TUNNEL_TYPE_T flex_tnl_arr[HAL_L3T_MAX_NUM_OF_FLEX_TUNNEL];
    CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T flex_tnl_udf_profile_arr[HAL_L3T_MAX_NUM_OF_FLEX_TUNNEL];

    UI32_T nvo3_encap_idx_bitmap[HAL_L3T_ENCAP_IDX_BITMAP_SIZE];
    CLX_SEMAPHORE_ID_T l3t_sema;
    CLX_SEMAPHORE_ID_T nvo3_sema;
} HAL_L3T_CB_T;

typedef HAL_L3T_CB_T HAL_L3T_CB_P[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_l3t_init(const UI32_T unit);

CLX_ERROR_NO_T
hal_l3t_deinit(const UI32_T unit);

CLX_ERROR_NO_T
hal_l3t_createPort(const UI32_T unit,
                   const CLX_TUNNEL_KEY_T *ptr_key,
                   const UI32_T flag,
                   CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_l3t_destroyPort(const UI32_T unit, const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_l3t_getPort(const UI32_T unit, const CLX_TUNNEL_KEY_T *ptr_key, CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_l3t_getKey(const UI32_T unit, const CLX_PORT_T port, CLX_TUNNEL_KEY_T *ptr_key);

CLX_ERROR_NO_T
hal_l3t_traversePort(const UI32_T unit,
                     const CLX_L3T_PORT_TRAVERSE_FUNC_T callback,
                     void *ptr_cookie);

CLX_ERROR_NO_T
hal_l3t_trav(const UI32_T unit,
             const HAL_L3T_TRAV_TYPE_T type,
             const void *ptr_callback,
             void *ptr_cookie);

CLX_ERROR_NO_T
hal_l3t_setFlexTunnelUdfProfile(const UI32_T unit,
                                const UI32_T index,
                                CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

CLX_ERROR_NO_T
hal_l3t_getFlexTunnelUdfProfile(const UI32_T unit,
                                const UI32_T index,
                                CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

/* EXPORTED HAL SUBPROGRAM BODIES
 */
BOOL_T
hal_l3t_chkNshPayload(const CLX_TUNNEL_TYPE_T tunnel_type);

BOOL_T
hal_l3t_chkSegId(const UI32_T unit, const CLX_TUNNEL_TYPE_T tunnel_type);

BOOL_T
hal_l3t_chkIfUseClxPort(const CLX_TUNNEL_KEY_T tnl_key, const UI32_T term);

BOOL_T
hal_l3t_chkL2Payload(const CLX_TUNNEL_TYPE_T tunnel_type);

CLX_ERROR_NO_T
hal_l3t_chkIoam(const UI32_T unit, const CLX_TUNNEL_KEY_T tnl_key, UI32_T *ptr_ioam_type);

CLX_ERROR_NO_T
hal_l3t_validateTnlPort(const UI32_T unit, const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_l3t_getSrcSuppTag(const UI32_T unit, UI32_T *ptr_src_supp_tag);

CLX_ERROR_NO_T
hal_l3t_getHwVidInfo(const UI32_T unit,
                     const CLX_PORT_T port,
                     const CLX_TUNNEL_KEY_T *ptr_key,
                     const CLX_VLAN_TAG_ACTION_T *ptr_vlan_tag_action,
                     const CLX_VLAN_ACTION_T vlan_action,
                     HAL_VLAN_VID_CTL_T *ptr_vid_info);

CLX_ERROR_NO_T
hal_l3t_getSwVidInfo(const UI32_T unit,
                     const CLX_PORT_T port,
                     const CLX_TUNNEL_KEY_T *ptr_key,
                     const HAL_VLAN_VID_CTL_T *ptr_vid_info,
                     CLX_VLAN_TAG_ACTION_T *ptr_vlan_tag_action,
                     CLX_VLAN_ACTION_T *ptr_vlan_action);

CLX_ERROR_NO_T
hal_l3t_getHwInitInfo(const UI32_T unit,
                      const UI32_T fdid,
                      const CLX_PORT_T port,
                      const CLX_TUNNEL_KEY_T *ptr_key,
                      UI32_T *ptr_seg0,
                      UI32_T *ptr_seg1,
                      UI32_T *ptr_nvo3_encap_idx);

CLX_ERROR_NO_T
hal_l3t_getSwInitInfo(const UI32_T unit,
                      const UI32_T nvo3_encap_idx,
                      CLX_PORT_T *ptr_port,
                      CLX_TUNNEL_KEY_T *ptr_key);

CLX_ERROR_NO_T
hal_l3t_getTnlSwdbNode(const UI32_T unit,
                       const CLX_TUNNEL_KEY_T *ptr_key,
                       const BOOL_T use_port,
                       const BOOL_T erspan,
                       void **pptr_found_node);

CLX_ERROR_NO_T
hal_l3t_cfgTnlKeySwdb(const UI32_T unit,
                      const HAL_CMN_ACTION_T swdb_action,
                      HAL_L3T_KEY_AVL_NODE_T *ptr_in_node,
                      HAL_L3T_KEY_AVL_NODE_T **pptr_out_node);

CLX_ERROR_NO_T
hal_l3t_cfgErspanTermSwdb(const UI32_T unit,
                          const HAL_CMN_ACTION_T swdb_action,
                          HAL_L3T_ERSPAN_TERM_AVL_NODE_T *ptr_in_node,
                          HAL_L3T_ERSPAN_TERM_AVL_NODE_T **pptr_out_node);

CLX_ERROR_NO_T
hal_l3t_cfgInitSipSwdb(const UI32_T unit,
                       const HAL_CMN_ACTION_T swdb_action,
                       HAL_L3T_INIT_SIP_AVL_NODE_T *ptr_in_node,
                       HAL_L3T_INIT_SIP_AVL_NODE_T **pptr_out_node);

CLX_ERROR_NO_T
hal_l3t_allocNvo3EncapIdx(const UI32_T unit, UI32_T *ptr_nvo3_encap_idx);

CLX_ERROR_NO_T
hal_l3t_getLclIntf(const UI32_T unit,
                   const CLX_TUNNEL_KEY_T *ptr_key,
                   UI32_T *ptr_lcl_intf,
                   CLX_DIR_T *ptr_dir);

CLX_ERROR_NO_T
hal_l3t_chkPortSrvInfo(const UI32_T unit,
                       const CLX_PORT_T port,
                       const CLX_PORT_SEG_SRV_T *ptr_seg_srv);

CLX_ERROR_NO_T
hal_l3t_getErspanTermLclIntf(const UI32_T unit,
                             const CLX_IP_ADDR_T *ptr_src_ip,
                             const CLX_IP_ADDR_T *ptr_dst_ip,
                             const UI32_T vrfo,
                             UI32_T *ptr_lcl_intf,
                             UI32_T *ptr_src_tep);

CLX_ERROR_NO_T
hal_l3t_composeClxPort(const UI32_T unit, const UI32_T nvo3_encap_idx, CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_l3t_cfgAdjEcmpList(const UI32_T unit,
                       const HAL_CMN_ACTION_T action,
                       const UI32_T adj_id,
                       const UI32_T grp_id);

CLX_ERROR_NO_T
hal_l3t_cfgEcmpPathByNvo3AdjInfo(const UI32_T unit,
                                 const UI32_T ecmp_path_idx,
                                 const CLX_PORT_T port);

UI32_T
hal_l3t_getFlexTnlId(const CLX_TUNNEL_TYPE_T tunnel_type);

CLX_ERROR_NO_T
hal_l3t_cfgFlexTnlGtp(const UI32_T unit, const UI32_T index, const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_cfgFlexTnlPim(const UI32_T unit, const UI32_T index, const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_cfgFlexTnlUserDefined(const UI32_T unit, const UI32_T index, const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_cfgFlexTnlGeneve(const UI32_T unit, const UI32_T index, const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_getDbFlexTnlArr(const UI32_T unit, CLX_L3T_FLEX_TUNNEL_TYPE_T *ptr_flex_tnl_arr);

HAL_L3T_CB_P *
hal_l3t_getCtrlBlock(const UI32_T unit);

CLX_ERROR_NO_T
hal_l3t_dumpDb(const UI32_T unit, const UI32_T flags);

CLX_ERROR_NO_T
hal_l3t_validateTnlType(const UI32_T unit, const CLX_TUNNEL_TYPE_T tunnel_type);

CLX_ERROR_NO_T
hal_l3t_cfgNvo3AdjSwdb(const UI32_T unit,
                       const HAL_CMN_ACTION_T swdb_action,
                       HAL_L3T_NVO3_ADJ_AVL_NODE_T *ptr_in_node,
                       HAL_L3T_NVO3_ADJ_AVL_NODE_T **pptr_out_node);

CLX_ERROR_NO_T
hal_l3t_getCntMtrSwId(const UI32_T unit,
                      const UI32_T table_id,
                      const UI32_T cnt_mtr_prof_idx,
                      UI32_T *ptr_cnt_sw_id,
                      UI32_T *ptr_dist_cnt_sw_id,
                      UI32_T *ptr_meter_sw_id);

CLX_ERROR_NO_T
hal_l3t_cfgCntMtr(const UI32_T unit,
                  const UI32_T table_id,
                  const UI32_T cnt_id,
                  const UI32_T dist_cnt_id,
                  const UI32_T meter_id,
                  const UI32_T old_cnt_mtr_prof_idx,
                  UI32_T *ptr_cnt_mtr_prof_idx);

CLX_ERROR_NO_T
hal_l3t_getNvo3EncapIdx(const UI32_T unit,
                        const CLX_TUNNEL_KEY_T tnl_key,
                        UI32_T *ptr_nvo3_encap_idx);

CLX_ERROR_NO_T
hal_l3t_getInitIpTnlType(const UI32_T unit,
                         const CLX_TUNNEL_TYPE_T tnl_type,
                         UI32_T *ptr_init_ip_tnl_type);

void
hal_l3t_composeClxTermKey(const CLX_TUNNEL_KEY_T *ptr_key_swdb, CLX_TUNNEL_KEY_T *ptr_key_clx);

void
hal_l3t_composeSwdbTermKey(const CLX_TUNNEL_KEY_T *ptr_key_clx, CLX_TUNNEL_KEY_T *ptr_key_swdb);

CLX_ERROR_NO_T
hal_l3t_cfgTnlTermDipSwdb(const UI32_T unit,
                          const HAL_CMN_ACTION_T swdb_action,
                          HAL_L3T_TERM_DIP_AVL_NODE_T *ptr_in_node,
                          HAL_L3T_TERM_DIP_AVL_NODE_T **pptr_out_node);

void
hal_l3t_destroyAdjListData(void *ptr_node_data);
#endif
