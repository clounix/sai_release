/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_lightning_acl.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_LAG_H
#define HAL_MT_NAMCHABARWA_LAG_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_lag.h>
#include <hal/hal_lag.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NAMCHABARWA_LAG_PORT_NUM             (128)
#define HAL_MT_NAMCHABARWA_LAG_GROUP_MAX_MEMBER_NUM (512)
#define HAL_MT_NAMCHABARWA_LAG_PORT_MIN             (HAL_LAG_BASE_ID)
#define HAL_MT_NAMCHABARWA_LAG_PORT_MAX             (HAL_LAG_BASE_ID + HAL_MT_NAMCHABARWA_LAG_PORT_NUM - 1)
#define HAL_MT_NAMCHABARWA_LAG_GRP_ID_MIN           (0)
#define HAL_MT_NAMCHABARWA_LAG_GRP_ID_MAX           (HAL_MT_NAMCHABARWA_LAG_PORT_NUM - 1)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_freeOriActList(const UI32_T unit,
                                      const UI32_T lag_id,
                                      HAL_LAG_INFO_T *ptr_lag_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_allocOriActList(const UI32_T unit,
                                       const UI32_T lag_id,
                                       HAL_LAG_INFO_T *ptr_lag_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_setBackupEpochMcPathAutoUpdate(const UI32_T unit,
                                                      const UI32_T master_epoch,
                                                      const UI32_T backup_epoch,
                                                      const UI32_T orig_member_cnt,
                                                      const UI32_T *ptr_orig_member_di,
                                                      const UI32_T new_member_cnt_mod,
                                                      const UI32_T *ptr_new_member_di_mod,
                                                      const HAL_LAG_INFO_T *ptr_new_lag_info,
                                                      const UI32_T new_member_cnt,
                                                      const UI32_T *ptr_new_member_di,
                                                      const UI32_T del_member_cnt,
                                                      const UI32_T *ptr_del_member_di);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_updateMasterEpochMcPath(const UI32_T unit,
                                               const UI32_T master_epoch,
                                               const UI32_T backup_epoch);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_setMemberPortSi(const UI32_T unit,
                                       const UI32_T lag_di,
                                       const UI32_T add_member_cnt,
                                       const UI32_T *ptr_add_member_di,
                                       const UI32_T del_member_cnt,
                                       const UI32_T *ptr_del_member_di);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_getMemberCnt(const UI32_T unit,
                                    const CLX_PORT_T lag_port,
                                    UI32_T *ptr_member_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_getInfo(const UI32_T unit,
                               const UI32_T lag_id,
                               UI32_T *ptr_member_cnt,
                               UI32_T *ptr_member_di,
                               HAL_LAG_INFO_T *ptr_lag_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_setInfo(const UI32_T unit,
                               const UI32_T lag_id,
                               const HAL_LAG_INFO_T *ptr_lag_info);

#if defined(CLX_HSH_LIB)
CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_getHashPath(const UI32_T unit,
                                   const CLX_SWC_HASH_TYPE_T hash_type,
                                   const UI32_T lag_id,
                                   CLX_LAG_HASHPATH_RSLT_INFO_T *ptr_rslt);
#endif

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_setAttr(const UI32_T unit,
                               const CLX_PORT_T lag_port,
                               const CLX_LAG_ATTRIB_T *ptr_attr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lag_getAttr(const UI32_T unit,
                               const CLX_PORT_T lag_port,
                               CLX_LAG_ATTRIB_T *ptr_attr);
#endif /* End of HAL_MT_NAMCHABARWA_LAG_H */
