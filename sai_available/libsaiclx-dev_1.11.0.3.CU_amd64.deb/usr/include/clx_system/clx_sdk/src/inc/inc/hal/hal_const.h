/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_const.h
 * PURPOSE:
 *  It provides constant definition for use.
 *
 * NOTES:
 */

#ifndef HAL_CONST_H
#define HAL_CONST_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <cdb/cdb.h>
#include <hal/hal_swc.h>
#include <hal/hal_stat.h>
/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_VLAN_ENTRY_NUM     (4096)
#define HAL_TRILL_NICKNAME_MIN (0x0001)   /* 0x0000 is unknown */
#define HAL_TRILL_NICKNAME_MAX (0xFFBF)   /* 0xFFC0~0xFFFF is reserved */
#define HAL_VM_P2P_ECID_MIN    (0x1)      /* min ecid for point-to-point e-channel      */
#define HAL_VM_P2P_ECID_MAX    (0xFFFFF)  /* max ecid for point-to-point e-channel      */
#define HAL_VM_P2MP_ECID_MIN   (0x100000) /* min ecid for point-to-multipoint e-channel */
#define HAL_VM_P2MP_ECID_MAX   (0x3FFFFE) /* max ecid for point-to-multipoint e-channel */
#define HAL_VM_VIF_MIN         (0x0)      /* min svif */
#define HAL_VM_VIF_MAX         (0xFFF)    /* max svif */
#define HAL_VM_VIF_LIST_MIN    (0x4000)   /* min dvif */
#define HAL_VM_VIF_LIST_MAX    (0x7FFF)   /* max dvif */
#define HAL_VM_SCID_MIN        (0x1)      /* min scid */
#define HAL_VM_SCID_MAX        (0xFFF)    /* max scid */
#define HAL_QOS_PCP_NUM        (8)        /* 3 bit PCP in VLAN tag */
#define HAL_QOS_DEI_NUM        (2)        /* 1 bit DEI in VLAN tag */
#define HAL_QOS_DSCP_NUM       (64)       /* 6 bit DSCP in IP header */
#define HAL_QOS_EXP_NUM        (8)        /* 3 bit EXP in MPLS Lable */
#define HAL_QOS_COLOR_NUM      (3)        /* 3 bit colors(Green/Yellow/Red) */

/* MACRO FUNCTION DECLARATIONS
 */
#define PTR_HAL_CONST_INFO(__unit__, __module__) \
    (_ext_chip_control_block[(__unit__)].ptr_driver_info->ptr_const_info->ptr_##__module__##_const)

/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_CONST_VLAN_INFO_S {
    UI32_T vid_ctl_add;
} HAL_CONST_VLAN_INFO_T;

typedef struct HAL_CONST_PKT_INFO_S {
    UI32_T ipp_excpt_num;
    UI32_T ipp_l3_excpt_num;
    UI32_T ipp_copy2cpu_num;
    UI32_T ipp_rsn_num;
    UI32_T epp_excpt_num;
    UI32_T epp_copy2cpu_num;
    UI32_T pcie_que_num;
    UI32_T cpi_que_num;
} HAL_CONST_PKT_INFO_T;

typedef struct HAL_CONST_SWC_INFO_S {
    UI32_T emi[HAL_SWC_CAP_EMI_LAST];
    UI32_T tcam_bank_num;
    UI32_T tcam_bank_entry;
    UI32_T master_die_id;
    UI32_T fpu_tile_num;
    UI32_T fpu_tcam_num;
} HAL_CONST_SWC_INFO_T;

typedef struct HAL_CONST_STAT_INFO_S {
    UI32_T pp[HAL_STAT_CAP_PP_LAST];
    UI32_T mac[HAL_STAT_CAP_MAC_LAST];
    UI32_T tm[HAL_STAT_CAP_TM_LAST];
} HAL_CONST_STAT_INFO_T;

typedef struct HAL_CONST_ACL_INFO_S {
    UI32_T udf_int_key_vld_bmp_flw;
    UI32_T udf_int_key_vld_bmp_igr;
    UI32_T udf_int_key_vld_bmp_egr;
    UI32_T udf_0_pkg_tlv_base_id;
    UI32_T action_flags_igr;
    UI32_T action_flags_egr;
    UI32_T igr_acl_group_label_full_lsb_vld_bits;
    UI32_T igr_acl_group_label_share_lsb_vld_bits;
    UI32_T rewr_page_num;
    UI32_T igr_ucp_num;
    UI32_T egr_ucp_num;
    UI32_T flw_ucp_num;
    UI32_T igr_group_num;
    UI32_T egr_group_num;
    UI32_T flw_group_num;
    UI32_T ucp_entry_num;
    UI32_T igr_entry_num;
    UI32_T egr_entry_num;
    UI32_T ucp_entry_bits;
    UI32_T fpu_1_level_start;
    UI32_T fpu_1_group_offset;
    UI32_T igr_post_group_num;
    UI32_T egr_post_group_num;
    UI32_T igr_post_entry_num;
    UI32_T egr_post_entry_num;
    UI32_T igr_post_ucp_num;
    UI32_T egr_post_ucp_num;
} HAL_CONST_ACL_INFO_T;

typedef struct HAL_CONST_LAG_INFO_S {
    UI32_T lag_hw_grp_tbl;
    UI32_T lag_hw_grp_ori_base_field;
    UI32_T lag_hw_grp_ori_size_field;
    UI32_T lag_hw_grp_act_base_field;
    UI32_T lag_hw_grp_act_size_field;
    UI32_T lag_igr_phy_port_tbl;
    UI32_T lag_igr_phy_port_src_idx_field;
    UI32_T lag_hw_ori_port_di_tbl;
    UI32_T lag_hw_ori_port_di_field;
    UI32_T lag_hw_ori_port_state_tbl;
    UI32_T lag_hw_ori_port_state_field;
    UI32_T lag_hw_act_port_di_tbl;
    UI32_T lag_hw_act_port_di_field;
    UI32_T lag_hw_act_port_state_tbl;
    UI32_T lag_hw_act_port_state_field;
    UI32_T lag_port_num;
    UI32_T lag_port_max_per_grp;
    UI32_T lag_port_min;
    UI32_T lag_port_max;
    UI32_T lag_grp_id_min;
    UI32_T lag_grp_id_max;
} HAL_CONST_LAG_INFO_T;

typedef struct HAL_CONST_SFLOW_INFO_S {
    UI32_T profile_entry_num;
    UI32_T dtel_profile_num;
} HAL_CONST_SFLOW_INFO_T;

typedef struct HAL_CONST_TM_INFO_S {
    UI32_T cpu_queue_num;
    UI32_T port_pfc_max_num; // Max num of pfc priority support on port
    UI32_T cell_size;
    UI32_T legacy_queue_max_num;
    UI32_T unicast_queue_max_num;
    UI32_T multicast_queue_max_num;
    UI32_T burst_size_max_num;
} HAL_CONST_TM_INFO_T;
typedef struct HAL_CONST_QOS_INFO_S {
    UI32_T tc_max_num;
    UI32_T phb_profile_max_num;
} HAL_CONST_QOS_INFO_T;
typedef struct HAL_CONST_L3T_INFO_S {
    UI32_T ip_tnl_gre_no_key;
    UI32_T ip_tnl_gre_w_key;
    UI32_T ip_tnl_raw;
    UI32_T ip_tnl_isatap;
    UI32_T ip_tnl_6to4;
    UI32_T ip_tnl_vxlan_bas;
    UI32_T ip_tnl_vxlan_gpe;
    UI32_T ip_tnl_geneve;
    UI32_T ip_tnl_int_rep;
    UI32_T ip_tnl_srv6_encap;
    UI32_T ip_tnl_srv6_insert;
    UI32_T ip_tnl_flex0;
    UI32_T ip_tnl_flex1;
    UI32_T ip_tnl_flex2;
    UI32_T ip_tnl_flex3;
    UI32_T tunnel_di_base;
    UI32_T nvo3adj_num;
    UI32_T invalid_nvo3_encap_idx;
    UI32_T invalid_nvo3_adj_idx;
} HAL_CONST_L3T_INFO_T;

typedef struct HAL_CONST_PORT_INFO_S {
    UI32_T drop_di_base;
    UI32_T drop_di_num;
    UI32_T cpu_di_base;
    UI32_T l2_mtu_min;
    UI32_T l2_mtu_max;
    UI32_T hal_port_num;
    UI32_T hal_plane_num;
    UI32_T hal_plane_bits;
    UI32_T hal_plane_mask;
    UI32_T hal_plane_eth_port_max;
    UI32_T hal_plane_eth_dp_port_max;
    UI32_T hal_rc_port_num;
} HAL_CONST_PORT_INFO_T;

typedef struct HAL_CONST_METER_INFO_S {
    UI32_T p_bank_capacity;   /* plane meter bank capacity, unit: double bucket */
    UI32_T p_rate_max;        /* max plane global meter rate, unit: kbps */
    UI32_T p_bucket_max;      /* max global meter bucket size, unit: bytes */

    UI32_T g_bank_capacity;   /* global meter bank capacity, unit: double bucket */
    UI32_T g_rate_max;        /* max global meter rate, unit: kbps */
    UI32_T g_bucket_max;      /* max global meter bucket size, unit: bytes */

    UI32_T rsv_bank_capacity; /* reserved meter bank capacity, unit: double bucket */

    UI32_T rate_gra;          /* meter rate granularity, unit: kbps */
    UI32_T bucket_gra;        /* meter bucket granularity, unit: byte */
    UI32_T igr_grp_num;       /* ucp group number for ingress cia */
    UI32_T egr_grp_num;       /* ucp group number for egress cia */
} HAL_CONST_METER_INFO_T;

typedef struct HAL_CONST_SEC_INFO_S {
    UI32_T max_icmpv4_size;    /* maximum icmpv4 size */
    UI32_T max_icmpv6_size;    /* maximum icmpv6 size */
    UI32_T max_l4_prot;        /* maximum l4 protocol */
    UI32_T min_udp_size;       /* minimum udp size */
    UI32_T min_udp_frg_off;    /* minimum udp fragment offset */
    UI32_T min_tcp_size;       /* minimum tcp size */
    UI32_T min_tcp_frg_off;    /* minimum tcp fragment offset */
    UI32_T min_sctp_size;      /* minimum sctp size */
    UI32_T min_sctp_frg_off;   /* minimum sctp fragment offset */
    UI32_T min_ipv6_frag_size; /* minimum ipv6 fragment size */
    UI32_T max_sc_meter_rate;  /* maximum storm control meter rate, unit: kbps */
} HAL_CONST_SEC_INFO_T;

typedef struct HAL_CONST_L2_INFO_S {
    UI32_T mgid_base_id;
    UI32_T mgid_drop_offset;
    UI32_T mgid_stk_cpu_bcast_offset;
    UI32_T mgid_stk_cpu_neighbor_offset;
    UI32_T mgid_dflt_vlan_offset;
    UI32_T mgid_dflt_vlan_rsv1_offset;
    UI32_T mgid_dflt_vlan_rsv2_offset;
} HAL_CONST_L2_INFO_T;

typedef struct HAL_CONST_INFO_S {
    /* vlan */
    HAL_CONST_VLAN_INFO_T *const ptr_vlan_const;
    /* pkt */
    HAL_CONST_PKT_INFO_T *const ptr_pkt_const;
    /* swc */
    HAL_CONST_SWC_INFO_T *const ptr_swc_const;
    /* stat */
    HAL_CONST_STAT_INFO_T *const ptr_stat_const;
    /* acl */
    HAL_CONST_ACL_INFO_T *const ptr_acl_const;
    /* lag */
    HAL_CONST_LAG_INFO_T *const ptr_lag_const;
    /* sflow */
    HAL_CONST_SFLOW_INFO_T *const ptr_sflow_const;
    /* l3t */
    HAL_CONST_L3T_INFO_T *const ptr_l3t_const;
    /* port */
    HAL_CONST_PORT_INFO_T *const ptr_port_const;
    /* meter */
    HAL_CONST_METER_INFO_T *const ptr_meter_const;
    /* security */
    HAL_CONST_SEC_INFO_T *const ptr_sec_const;
    /* l2 */
    HAL_CONST_L2_INFO_T *const ptr_l2_const;
    /* tm */
    HAL_CONST_TM_INFO_T *const ptr_tm_const;
    /* qos */
    HAL_CONST_QOS_INFO_T *const ptr_qos_const;
} HAL_CONST_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif /* #ifndef HAL_CONST_H */
