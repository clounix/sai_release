/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_l2.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_LT_L2_H
#define HAL_LT_L2_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_l2.h>
#include <hal/hal_l2.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_LT_L2_FDB_ENTRY_BYTES            (LT_CDB_ICM_COM_1X_U_L2_FDB_WORDS * HAL_BYTES_OF_WORD)
#define HAL_LT_L2_FDB_ENTRY_RSLT_WORD_OFFSET (3)

#define HAL_LT_L2_ICM_CHECK_RING_INTERVAL_USEC        (50 * 1000)
#define HAL_LT_L2_ICM_MARKER_ENTRY_FDID               (16383)
#define HAL_LT_L2_ICM_RING_RESET_DONE_MAX_POLL_NUM    (1000)
#define HAL_LT_L2_ICM_RING_WAIT_RESET_DONE_SLEEP_USEC (2000)
#define HAL_LT_L2_ICM_RING_RESET_DONE_SLEEP_USEC      (20)
#define HAL_LT_L2_ICM_RING_MAX_RESET_NUM              (10)
#define HAL_LT_L2_ICM_FAST_CMD_AGE_ENTRY_NUM          (512)
#define HAL_LT_L2_ICM_CLONE_ENTRY_NUM                 (512)
#define HAL_LT_L2_ICM_FADING_DMA_ENTRY_NUM            (16)

#define HAL_LT_L2_FAST_CMD_DONE_POLLING_NUM_MAX (240)

#define HAL_LT_L2_MC_LAG_MBR_AVL_NAME ("MC_LAG_MBR_AVL")

#define HAL_LT_L2_SKIP_SIZE_FIELD_LENGTH (0x7)

#define HAL_LT_L2_CHECK_MCAST_INTF_FLAGS_MEL (1U << 0)
#define HAL_LT_L2_CHECK_MCAST_INTF_FLAGS_DEL (1U << 1)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_LT_L2_CHECK_UC_EXM(_unit_)                                                            \
    do {                                                                                          \
        if (0 == HAL_HASH_TYPE_L2_BMP(_unit_)) {                                                  \
            DIAG_PRINT(HAL_DBG_L2, HAL_DBG_WARN, "u=%u, invalid fdb entry region=0\n", (_unit_)); \
            return CLX_E_BAD_PARAMETER;                                                           \
        }                                                                                         \
    } while (0)

#define HAL_LT_L2_CHECK_MC_EXM(_unit_)                                                            \
    do {                                                                                          \
        if (0 == HAL_HASH_TYPE_L2_GROUP_BMP(_unit_)) {                                            \
            DIAG_PRINT(HAL_DBG_L2, HAL_DBG_WARN, "u=%u, invalid fdb entry region=0\n", (_unit_)); \
            return CLX_E_BAD_PARAMETER;                                                           \
        }                                                                                         \
    } while (0)

#define HAL_LT_L2_UNPACK_FIFO_FIELD(__unit__, __fifo_field__, __loc_field__, __ptr_entry__, \
                                    __ptr_field__)                                          \
    do {                                                                                    \
        CDB_FIELD_T *ptr_field_db = (HAL_LT_L2_FIFO_LOC_FILED_ID == (__fifo_field__)) ?     \
            (_hal_lt_l2_loc_field_offset + (__loc_field__)) :                               \
            (_hal_lt_l2_fifo_field_offset + (__fifo_field__));                              \
        hal_unpackField((__unit__), HAL_LT_LAST_TBL_ID, 0, ptr_field_db->offset,            \
                        ptr_field_db->length, (__ptr_entry__), (__ptr_field__));            \
    } while (0)

#define HAL_LT_L2_PACK_LOC_FIELD(__unit__, __loc_field__, __ptr_entry__, __ptr_field__) \
    do {                                                                                \
        CDB_FIELD_T *ptr_field_db = _hal_lt_l2_loc_field_offset + (__loc_field__);      \
        hal_packField((__unit__), HAL_LT_LAST_TBL_ID, 0, ptr_field_db->offset,          \
                      ptr_field_db->length, (__ptr_entry__), (__ptr_field__));          \
    } while (0)

#if !defined(CLX_LAMP)
#define HAL_LT_L2_ICM_TASK(_unit_)                           \
    ((HAL_DEVICE_CHIP_ID(_unit_) == HAL_DEVICE_ID_CL8368) || \
     (HAL_DEVICE_CHIP_ID(_unit_) == HAL_DEVICE_ID_CL8369))
#else
#define HAL_LT_L2_ICM_TASK(_unit_) (0)
#endif

#define HAL_LT_L2_ICM_PACK_MARKER_ENTRY(__unit__, __fdb_entry__, __di__)                           \
    do {                                                                                           \
        UI32_T __hw_mac__[2];                                                                      \
                                                                                                   \
        osal_memset((__fdb_entry__), 0, sizeof(HAL_L2_FDB_ENTRY_T));                               \
                                                                                                   \
        (__hw_mac__)[0] = 0xffffffff;                                                              \
        (__hw_mac__)[1] = 0xfeff;                                                                  \
        cdb_packUi32Field((__unit__), LT_TBL_ICM_COM_1X_U_L2_FDB_ID,                               \
                          LT_ICM_COM_1X_U_L2_FDB_TYP_FIELD_ID, (__fdb_entry__),                    \
                          HAL_ILE_KEY_1X_U_L2_FDB_IS_STATIC);                                      \
        cdb_packUi32Field((__unit__), LT_TBL_ICM_COM_1X_U_L2_FDB_ID,                               \
                          LT_ICM_COM_1X_U_L2_FDB_FDID_FIELD_ID, (__fdb_entry__),                   \
                          HAL_LT_L2_ICM_MARKER_ENTRY_FDID);                                        \
        cdb_packField((__unit__), LT_TBL_ICM_COM_1X_U_L2_FDB_ID,                                   \
                      LT_ICM_COM_1X_U_L2_FDB_MAC_FIELD_ID, (__fdb_entry__), (__hw_mac__));         \
        cdb_packUi32Field((__unit__), LT_TBL_ICM_COM_1X_U_L2_FDB_ID,                               \
                          LT_ICM_COM_1X_U_L2_FDB_UEID_MGID_S_FIELD_ID, (__fdb_entry__), (__di__)); \
    } while (0)

#define HAL_LT_L2_ICM_TRANS_FAST_CMD_ENTRY_TO_FDB(__unit__, __fdb_entry__, __fast_cmd_entry__) \
    do {                                                                                       \
        osal_memset((__fdb_entry__), 0, sizeof(HAL_L2_FDB_ENTRY_T));                           \
        hal_unpackField((__unit__), HAL_LT_LAST_TBL_ID, 0, 0, 85, (__fast_cmd_entry__),        \
                        (__fdb_entry__));                                                      \
        hal_unpackField((__unit__), HAL_LT_LAST_TBL_ID, 0, 89, 80, (__fast_cmd_entry__),       \
                        &((__fdb_entry__)[3]));                                                \
    } while (0)

#define HAL_LT_L2_ICM_PRINT_POLL_ENTRY(__unit__, __entry_idx__, __compare_rslt__,               \
                                       __hw_fdb_entry__, __sw_fdb_entry__)                      \
    do {                                                                                        \
        DIAG_PRINT(HAL_DBG_L2_POLL, HAL_DBG_INFO, "u=%u, poll-entry-idx=%u, compare-rslt=%u\n", \
                   (__unit__), (__entry_idx__), (__compare_rslt__));                            \
        HAL_L2_PRINT_FDB_ENTRY(HAL_DBG_L2_POLL, "poll-hw-", (__hw_fdb_entry__), "\n");          \
        HAL_L2_PRINT_FDB_ENTRY(HAL_DBG_L2_POLL, "poll-sw-", (__sw_fdb_entry__), "\n");          \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_LT_L2_COMPARE_FDB_ENTRY_SAME,
    HAL_LT_L2_COMPARE_FDB_ENTRY_DIFF,
    HAL_LT_L2_COMPARE_FDB_ENTRY_NON_USER_VIEW_FLD_DIFF,
} HAL_LT_L2_COMPARE_FDB_ENTRY_RSLT_T;

typedef enum {
    HAL_LT_L2_FIFO_LOC_FILED_ID,
    HAL_LT_L2_FIFO_TBL_IDX_FIELD_ID,
    HAL_LT_L2_FIFO_REASON_FIELD_ID,
    HAL_LT_L2_FIFO_DUMMY_0_FIELD_ID,
    HAL_LT_L2_FIFO_SEQ_NO_FIELD_ID,
    HAL_LT_L2_FIFO_DUMMY_1_FIELD_ID,
    HAL_LT_L2_FIFO_LAST_FIELD_ID
} HAL_LT_L2_FIFO_FIELD_T;

typedef enum {
    HAL_LT_L2_LOC_KEY_FIELD_ID,
    HAL_LT_L2_LOC_KEY_MAC_FIELD_ID,
    HAL_LT_L2_LOC_KEY_MAC_W1_FIELD_ID,
    HAL_LT_L2_LOC_KEY_MAC_W0_FIELD_ID,
    HAL_LT_L2_LOC_KEY_FDID_FIELD_ID,
    HAL_LT_L2_LOC_KEY_TYP_FIELD_ID,
    HAL_LT_L2_LOC_FLW_LBL_FIELD_ID,
    HAL_LT_L2_LOC_PND_FIELD_ID,
    HAL_LT_L2_LOC_WIDTH_FIELD_ID,
    HAL_LT_L2_LOC_HIT_BITS_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_UEID_MGID_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_SEG_VMID_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_VID_2ND_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_VID_1ST_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_VID_CTL_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_IS_SECURE_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_SRC_SUPP_TAG_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_MIR_KEEP_IGR_VLAN_TAGS_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_RESERVED_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_CP_TO_CPU_IDX_FIELD_ID,
    HAL_LT_L2_LOC_RSLT_TYP_FIELD_ID,
    HAL_LT_L2_LOC_LAST_FIELD_ID
} HAL_LT_L2_LOC_FIELD_T;
typedef enum {
    HAL_LT_L2_FIFO_REASON_SA_LEARN = 1,
    HAL_LT_L2_FIFO_REASON_SA_MOVE = 2,
    HAL_LT_L2_FIFO_REASON_INSERT_ADD = 3,
    HAL_LT_L2_FIFO_REASON_INSERT_DEL = 4,
    HAL_LT_L2_FIFO_REASON_INSERT_MODIFY = 5,
#if defined(CLX_EN_DAWN)
    HAL_LT_L2_FIFO_REASON_INSERT = 4,
#endif
    HAL_LT_L2_FIFO_REASON_DIRECT_WR = 6,
    HAL_LT_L2_FIFO_REASON_HW_AGE = 7,

    HAL_LT_L2_FIFO_REASON_FAST_CMD_DEL = 8,
    HAL_LT_L2_FIFO_REASON_FAST_CMD_MODIFY = 9,
#if defined(CLX_EN_DAWN)
    HAL_LT_L2_FIFO_REASON_FAST_CMD = 9,
#endif
} HAL_LT_L2_FIFO_REASON_T;
typedef enum {
    HAL_LT_L2_MC_SC_FDID = 0,
    HAL_LT_L2_MC_SC_INTF = 1,
} HAL_LT_L2_MC_SC_ENUM_T;

typedef enum {
    HAL_LT_L2_MGID2VMID_FDID = 0,
    HAL_LT_L2_MGID2VMID_INTF = 1,
} HAL_LT_L2_MGID2VMID_ENUM_T;

typedef enum {
    HAL_LT_L2_WBDB_MCAST_CB_GROUP_FDID_ARR = 0,
    HAL_LT_L2_WBDB_MCAST_CB_MC_SC_REF_CNT_2D_ARR,
    HAL_LT_L2_WBDB_MCAST_LAG_MBR_AVL_START,
    HAL_LT_L2_WBDB_MCAST_LAG_MBR_AVL_END =
        HAL_LT_L2_WBDB_MCAST_LAG_MBR_AVL_START + (HAL_LAG_PORT_MAX_NUM - 1),
    HAL_LT_L2_WBDB_LAST
} HAL_LT_L2_WBDB_T;

typedef struct HAL_LT_L2_MCAST_LAG_MBR_DB_S {
    CMLIB_AVL_HEAD_T *ptr_mc_group_avl;
} HAL_LT_L2_MCAST_LAG_MBR_DB_T;

typedef struct HAL_LT_L2_MCAST_LAG_MBR_INFO_S {
    UI32_T mcast_id; /* avl key */
    CLX_L2_MCAST_EGR_INTF_TYPE_T type;
    CLX_BRIDGE_DOMAIN_T bdid;
    CLX_VLAN_ACTION_T action;
    CLX_VLAN_T svid;
    CLX_VLAN_T cvid;
#define CLX_L2_MCAST_EGR_INTF_FLAGS_SVID_VALID (1U << 0)
#define CLX_L2_MCAST_EGR_INTF_FLAGS_CVID_VALID (1U << 1)
    UI32_T flags;
} HAL_LT_L2_MCAST_LAG_MBR_INFO_T;
typedef struct HAL_LT_L2_TRAV_ENTRY_TO_LIST_COOKIE_S {
    UI32_T unit;
    UI32_T port;
} HAL_LT_L2_TRAV_ENTRY_TO_LIST_COOKIE_T;

/**
 * @brief This API is used to initialize L2 module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_init(const UI32_T unit);

/**
 * @brief This API is used to deinitialize L2 module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_deinit(const UI32_T unit);

/**
 * @brief This API is used to add/set a L2 unicast MAC address entry.
 *        If the address entry does not exist, it will add the entry;
 *        if the address entry already exists, it will set the entry with user input value.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 address entry to be added/set
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_addAddr(const UI32_T unit, const CLX_L2_ADDR_T *ptr_addr);

/**
 * @brief This API is used to delete a L2 unicast MAC address entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 address entry to be deleted.
 *                               User should only fill the key fields "bdid" and "mac". The other
 * fields will be ignored.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_delAddr(const UI32_T unit, const CLX_L2_ADDR_T *ptr_addr);

/**
 * @brief This API is used to get a L2 unicast MAC address entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 address entry to be obtained.
 *                               User should only fill the key fields "bdid" and "mac". The other
 * fields will be ignored.
 * @param [out]    ptr_addr    - The fully filled L2 address entry obtained.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_getAddr(const UI32_T unit, CLX_L2_ADDR_T *ptr_addr);

/**
 * @brief This API is used to replace L2 unicast MAC address entries which match the specified
 * criteria with the newly specified values.
 *
 * When user specifies the "replace_field" with CLX_L2_ADDR_REPLACE_FIELD_DEL set,
 * other values which are included by "replace_field" parameter will be ignored,
 * and the parameter "ptr_replace_addr" can be NULL.
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     match_field         - Indicate which fields of L2 uncast MAC address entry are
 * used to match the given "ptr_match_addr". User can choose one or more fields to do matching.
 *                                       Refer to CLX_L2_ADDR_MATCH_FIELD_XXX.
 * @param [in]     ptr_match_addr      - Specify the values of matched fields used to perform
 * matching. User need to input values of these fields which are chosen by "match_field" parameter.
 * @param [in]     replace_field       - Indicate which fields' values will be replaced with new
 * values. Refer to CLX_L2_ADDR_REPLACE_FIELD_XXX.
 * @param [in]     ptr_replace_addr    - Specify the new values used to replace the old values for
 * the matched MAC address entries. User need to input values of these fields which are chosen by
 * "replace_field" parameter.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_replaceAddr(const UI32_T unit,
                      const UI32_T match_field,
                      const CLX_L2_ADDR_T *ptr_match_addr,
                      const UI32_T replace_field,
                      const CLX_L2_ADDR_T *ptr_replace_addr);

/**
 * @brief This API is used to traverse all the L2 unicast MAC address entries, and handle it by
 * user's callback.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     mode          - The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 * @param [in]     callback      - The callback function to be called when each L2 address entry is
 * traversed
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_traverseAddr(const UI32_T unit,
                       const CLX_L2_ADDR_TRAVERSE_MODE_T mode,
                       const CLX_L2_ADDR_TRAVERSE_FUNC_T callback,
                       void *ptr_cookie);

/**
 * @brief This API is used to register a callback function that will be called
 *        whenever the L2 unicast MAC address table is updated.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_L2_ADDR_NOTIFY_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_registerAddrNotifyCallback(const UI32_T unit,
                                     const CLX_L2_ADDR_NOTIFY_FUNC_T callback,
                                     void *ptr_cookie);

/**
 * @brief This API is used to degister a callback function that will be called
 *        whenever the L2 unicast MAC address table is updated.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_L2_ADDR_NOTIFY_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_deregisterAddrNotifyCallback(const UI32_T unit,
                                       const CLX_L2_ADDR_NOTIFY_FUNC_T callback,
                                       void *ptr_cookie);

/**
 * @brief This API is used to register a callback function that will be called
 *        whenever the L2 unicast entry needs to be learned by sofware.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_L2_ADDR_SW_LEARN_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_registerAddrSwLearnCallback(const UI32_T unit,
                                      const CLX_L2_ADDR_SW_LEARN_FUNC_T callback,
                                      void *ptr_cookie);

/**
 * @brief This API is used to degister a callback function that will be called
 *        whenever the L2 unicast entry needs to be learned by sofware.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_L2_ADDR_SW_LEARN_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_deregisterAddrSwLearnCallback(const UI32_T unit,
                                        const CLX_L2_ADDR_SW_LEARN_FUNC_T callback,
                                        void *ptr_cookie);

/**
 * @brief This API is used to add a L2 multicast ID.
 *        After the L2 multicast ID is added, L2 multicast egress interfaces can be added to it.
 *        If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set, this API will add L2 multicast ID with the ID
 * pointed by ptr_mcast_id; if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a
 * L2 multicast ID.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     flags           - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [in]     ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                                   this field specifies the L2 multicast ID to be added.
 * @param [out]    ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                                   this field specifies the allocated L2 multicast ID.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_addMcastId(const UI32_T unit, const UI32_T flags, UI32_T *ptr_mcast_id);

/**
 * @brief This API is used to delete a L2 multicast ID.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     mcast_id    - The L2 multicast ID to be deleted
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_delMcastId(const UI32_T unit, const UI32_T mcast_id);

/**
 * @brief This API is used to get a L2 multicast ID.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     mcast_id       - The L2 multicast ID to be obtained
 * @param [out]    ptr_flags      - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [out]    port_bitmap    - The egress port bitmap
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_getMcastId(const UI32_T unit,
                     const UI32_T mcast_id,
                     UI32_T *ptr_flags,
                     CLX_PORT_BITMAP_T port_bitmap);

/**
 * @brief This API is used to add egress interface for a L2 multicast ID.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     mcast_id        - The L2 multicast ID
 * @param [in]     egr_intf_cnt    - The number of egress interfaces to be added
 * @param [in]     ptr_egr_intf    - The egress interface list to be added
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_addMcastEgrIntf(const UI32_T unit,
                          const UI32_T mcast_id,
                          const UI32_T egr_intf_cnt,
                          CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf);

/**
 * @brief This API is used to delete egress interface for a L2 multicast ID.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     mcast_id        - The L2 multicast ID
 * @param [in]     egr_intf_cnt    - The number of egress interfaces to be deleted
 * @param [in]     ptr_egr_intf    - The egress interface list to be deleted.
 *                                   If CLX_L2_MCAST_FLAGS_REPLICATION of the L2 multicast ID is not
 * set, user should only fill the "type", "bdid" and "port" fields, and the other fields will be
 * ignored.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_delMcastEgrIntf(const UI32_T unit,
                          const UI32_T mcast_id,
                          const UI32_T egr_intf_cnt,
                          CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf);

/**
 * @brief This API is used to get egress interface count for a L2 multicast ID.
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     mcast_id            - The L2 multicast ID
 * @param [out]    ptr_egr_intf_cnt    - The egress interface count
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_getMcastEgrIntfCnt(const UI32_T unit, const UI32_T mcast_id, UI32_T *ptr_egr_intf_cnt);

/**
 * @brief This API is used to get egress interface for a L2 multicast ID.
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     mcast_id                   - The L2 multicast ID
 * @param [in]     egr_intf_cnt               - The number of egress interfaces to be get
 * @param [out]    ptr_egr_intf               - The egress interface list obtained
 * @param [out]    ptr_actual_egr_intf_cnt    - The actual number of egress interface obtained
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_getMcastEgrIntf(const UI32_T unit,
                          const UI32_T mcast_id,
                          const UI32_T egr_intf_cnt,
                          CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf,
                          UI32_T *ptr_actual_egr_intf_cnt);

/**
 * @brief This API is used to add/set a L2 multicast MAC address entry.
 *        If the multicast address entry does not exist, it will add the entry;
 *        if the multicast address entry already exists, it will set the entry with user input
 * value.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 multicast address entry to be added/set
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_addMcastAddr(const UI32_T unit, const CLX_L2_MCAST_ADDR_T *ptr_addr);

/**
 * @brief This API is used to delete a L2 multicast address entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 multicast entry to be deleted.
 *                               User should only fill the key fields "bdid" and "mac". The other
 * fields will be ignored.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_delMcastAddr(const UI32_T unit, const CLX_L2_MCAST_ADDR_T *ptr_addr);

/**
 * @brief This API is used to get a L2 multicast address entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 multicast address entry to be obtained.
 *                               User should only fill the key fields "bdid" and "mac". The other
 * fields will be ignored.
 * @param [out]    ptr_addr    - The full filled L2 multicast address entry obtained
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_getMcastAddr(const UI32_T unit, CLX_L2_MCAST_ADDR_T *ptr_addr);

/**
 * @brief This API is used to traverse all the L2 multicast MAC address entries, and handle it by
 * user's callback.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     mode          - The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 * @param [in]     callback      - The callback function to be called when each L2 multicast address
 * entry is traversed
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_traverseMcastAddr(const UI32_T unit,
                            const CLX_L2_ADDR_TRAVERSE_MODE_T mode,
                            const CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T callback,
                            void *ptr_cookie);

/**
 * @brief This API is used to add/set a L2 IP multicast group entry.
 *        If the IP multicast entry does not exist, it will add the entry;
 *        if the IP multicast entry already exists, it will set the entry with user input value.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_group    - The IP multicast entry to be added/set
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_addIpMcastGroup(const UI32_T unit, const CLX_L2_IP_MCAST_GROUP_T *ptr_group);

/**
 * @brief This API is used to delete a L2 IP multicast group entry.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_group    - The L2 IP multicast entry to be deleted.
 *                                User should only fill the key fields "bdid", "grp_ip" and
 * "src_ip". Other fields will be ignored.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_delIpMcastGroup(const UI32_T unit, const CLX_L2_IP_MCAST_GROUP_T *ptr_group);

/**
 * @brief This API is used to get a L2 IP multicast group entry.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_group    - The L2 IP multicast entry to be obtained.
 *                                User should only fill the key fields "bdid", "grp_ip" and
 * "src_ip". Other fields will be ignored.
 * @param [out]    ptr_group    - The full filled L2 IP multicast entry obtained
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_getIpMcastGroup(const UI32_T unit, CLX_L2_IP_MCAST_GROUP_T *ptr_group);

/**
 * @brief This API is used to add a L2 multicast ID.
 *        After the L2 multicast ID is added, L2 multicast egress interfaces can be added to it.
 *        If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set, this API will add L2 multicast ID with the ID
 * pointed by ptr_mcast_id; if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a
 * set of L2 multicast ID.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     flags           - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [in]     mcast_id_cnt    - The number of L2 multicast ID need to be added.
 * @param [in]     ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                                   this field specifies the L2 multicast ID to be added.
 * @param [out]    ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                                   this field specifies the first allocated L2 multicast ID.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_l2_addMultiMcastId(const UI32_T unit,
                          const UI32_T flags,
                          const UI32_T mcast_id_cnt,
                          UI32_T *ptr_mcast_id);

CLX_ERROR_NO_T
hal_lt_l2_getCapacity(const UI32_T unit,
                      const CLX_SWC_RSRC_T type,
                      const UI32_T param,
                      UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_lt_l2_getUsage(const UI32_T unit,
                   const CLX_SWC_RSRC_T type,
                   const UI32_T param,
                   UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_lt_l2_setAgingTime(const UI32_T unit, const UI32_T aging_time);

CLX_ERROR_NO_T
hal_lt_l2_getAgingTime(const UI32_T unit, UI32_T *ptr_aging_time);

CLX_ERROR_NO_T
hal_lt_l2_setSaMoveAction(const UI32_T unit, const CLX_FWD_ACTION_T action);

CLX_ERROR_NO_T
hal_lt_l2_getSaMoveAction(const UI32_T unit, UI32_T *ptr_action);

CLX_ERROR_NO_T
hal_lt_l2_setSaMissAction(const UI32_T unit,
                          const CLX_SWC_PROPERTY_T reason,
                          const CLX_FWD_ACTION_T action);

CLX_ERROR_NO_T
hal_lt_l2_getSaMissAction(const UI32_T unit, const CLX_SWC_PROPERTY_T reason, UI32_T *ptr_action);

CLX_ERROR_NO_T
hal_lt_l2_setPendingLearn(const UI32_T unit, const UI32_T pending_learn);

CLX_ERROR_NO_T
hal_lt_l2_getPendingLearn(const UI32_T unit, UI32_T *ptr_pending_learn);

CLX_ERROR_NO_T
hal_lt_l2_dumpDb(const UI32_T unit, const UI32_T flags);

CLX_ERROR_NO_T
hal_lt_l2_printMcastId(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_l2_getChipCfgInfo(const UI32_T unit,
                         const CLX_SWC_CHIP_CFG_INFO_TYPE_T type,
                         const UI32_T para0,
                         const UI32_T para1,
                         UI32_T *ptr_value);

/*not use */
void
hal_lt_l2_resetIcmRingCnt(const UI32_T unit);
/*not use */
void
hal_lt_l2_getIcmRingCnt(const UI32_T unit,
                        UI32_T *ptr_bubble_cnt,
                        UI32_T *ptr_ring_cnt,
                        UI32_T *ptr_ring_reset_cnt,
                        UI32_T *ptr_dma_cnt,
                        UI32_T *ptr_entry_cnt);

void
hal_lt_l2_enablePollUpdate(const UI32_T unit, const UI32_T en);

CLX_ERROR_NO_T
hal_lt_l2_updateMcastLagMember(const UI32_T unit,
                               const UI32_T lag_id,
                               const UI32_T add_member_cnt,
                               const UI32_T *ptr_add_member_di,
                               const UI32_T del_member_cnt,
                               const UI32_T *ptr_del_member_di);

CLX_ERROR_NO_T
hal_lt_l2_delMcastLag(const UI32_T unit, const UI32_T lag_id);

#endif /* End of HAL_LT_L2_H */
