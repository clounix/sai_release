/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_intr.h
 * PURPOSE:
 *      1. hal_mt_intr.h provides HAL ISR manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_INTR_H
#define HAL_MT_INTR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <aml/aml.h>

#include <hal/hal.h>
#include <cmlib/cmlib_queue.h>

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_INTR_GET_INTR_FUNC_PTR(unit) (hal_mt_intr_func[unit])

#define HAL_MT_NAMCHABAWAR_INTR_VEC_CHAIN24    (24)
#define HAL_MT_NAMCHABAWAR_INTR_VEC_CHAIN25    (25)
#define HAL_MT_NAMCHABAWAR_INTR_VEC_CHAIN29    (29)
#define HAL_MT_NAMCHABAWAR_INTR_MASK_UMAC0     (0)
#define HAL_MT_NAMCHABAWAR_INTR_MASK_UMAC1     (1)
#define HAL_MT_NAMCHABAWAR_INTR_MAX_CAHIN_SIZE (32)
#define HAL_MT_NAMCHABAWAR_INTR_MAX_SLAVE_SIZE (32)
#define HAL_MT_NAMCHABARWA_CHAIN29_CMAC_SLV    (16)

typedef enum {
    /* PL per slice chains */
    HAL_MT_NAMCHABARWA_IPL_SLV,
    HAL_MT_NAMCHABARWA_IPL_DP_SLV,
    HAL_MT_NAMCHABARWA_IPL_APP_SLV,
    HAL_MT_NAMCHABARWA_LBM_SLV,
    HAL_MT_NAMCHABARWA_EPL_APP_SLV,
    HAL_MT_NAMCHABARWA_EPL_DP_SLV,
    HAL_MT_NAMCHABARWA_EPL_SLV,

    /* PP per slice chains */
    HAL_MT_NAMCHABARWA_TDS_SLV,
    HAL_MT_NAMCHABARWA_DIS_SLV,
    HAL_MT_NAMCHABARWA_CNT_SLV,
    HAL_MT_NAMCHABARWA_MTR_SLV,
    HAL_MT_NAMCHABARWA_RWO_SLV,
    HAL_MT_NAMCHABARWA_RWI_SLV,
    HAL_MT_NAMCHABARWA_FWR_SLV,

    /* PP FPU share */
    HAL_MT_NAMCHABARWA_FPUHSH_SLV,
    HAL_MT_NAMCHABARWA_FPUTCAM_SLV,
    HAL_MT_NAMCHABARWA_FPUMISC_SLV,
    HAL_MT_NAMCHABARWA_FPUMEM_SLV,

    /* PP CIA share */
    HAL_MT_NAMCHABARWA_ICIA_SLV,
    HAL_MT_NAMCHABARWA_ECIA_SLV,
    HAL_MT_NAMCHABARWA_CIAT_SLV,

    /* TM per slice chains */
    HAL_MT_NAMCHABARWA_ASM_SLV,
    HAL_MT_NAMCHABARWA_REP_SLV,
    HAL_MT_NAMCHABARWA_BAC_SLV,
    HAL_MT_NAMCHABARWA_DQC_SLV,
    HAL_MT_NAMCHABARWA_OQC_SLV,
    HAL_MT_NAMCHABARWA_FRG_SLV,
    HAL_MT_NAMCHABARWA_SCH_SLV,

    /* TM module share */
    HAL_MT_NAMCHABARWA_PDB_QUAD_SLV,
    HAL_MT_NAMCHABARWA_PDB_CENTER_SLV,
    HAL_MT_NAMCHABARWA_PPL_SLV,
    HAL_MT_NAMCHABARWA_MCDB_SLV,
    HAL_MT_NAMCHABARWA_BAC_TOP_SLV,
    HAL_MT_NAMCHABARWA_OQC_TOP_SLV,
    HAL_MT_NAMCHABARWA_DQC_TOP_SLV,
    HAL_MT_NAMCHABARWA_PDM_SLV,
    HAL_MT_NAMCHABARWA_PDM_EME_SLV,

    /* UMAC */
    HAL_MT_NAMCHABARWA_UMAC_SLV, /* UMAC_WRAP && UMAC_AXI*/
    HAL_MT_NAMCHABARWA_PHY_WRAP_SLV,

    /* PCX */
    HAL_MT_NAMCHABARWA_TOP_SLV,
    HAL_MT_NAMCHABARWA_PDMA_SLV,
    HAL_MT_NAMCHABARWA_TOD_SLV,
    HAL_MT_NAMCHABARWA_ECPU_SLV,
    HAL_MT_NAMCHABARWA_PLDA_SLV,
    HAL_MT_NAMCHABARWA_PHY_SLV,

    HAL_MT_NAMCHABARWA_CMAC_SLV, /* CMAC_WRAP && CMAC_AXI*/
    HAL_MT_NAMCHABARWA_CMAC_PHY_SLV,

    HAL_MT_NAMCHABARWA_SLV_LAST,

    HAL_MT_INTR_TYPE_START = HAL_MT_NAMCHABARWA_SLV_LAST,
    HAL_MT_INTR_PDMA_NORMAL = HAL_MT_INTR_TYPE_START,
    HAL_MT_INTR_PDMA_RX_FIFO0,
    HAL_MT_INTR_PDMA_RX_FIFO1,
    HAL_MT_INTR_PDMA_RX_FIFO2,
    HAL_MT_INTR_PDMA_RX_FIFO3,
    HAL_MT_INTR_PDMA_TX_FIFO0,
    HAL_MT_INTR_PDMA_TX_FIFO1,
    HAL_MT_INTR_PDMA_TX_FIFO2,
    HAL_MT_INTR_PDMA_TX_FIFO3,
    HAL_MT_INTR_PDMA_GENERAL,
    HAL_MT_INTR_PDMA_L2_FIFO,
    HAL_MT_INTR_PDMA_IOAM_FIFO,
    HAL_MT_INTR_PDMA_ECPU_TX_FIFO,
    HAL_MT_INTR_PDMA_ECPU_RX_FIFO,
    HAL_MT_INTR_PDMA_ERR,
    HAL_MT_INTR_DCC_IO_ERR,
    HAL_MT_INTR_PORT_ANLT_LINK_GOOD,
    HAL_MT_INTR_PORT_ANLT_AN_DONE,
    HAL_MT_INTR_PORT_ANLT_AN_NEWPAGE,
    HAL_MT_NAMCHABARWA_TDS_SLV_ECC,
    HAL_MT_NAMCHABARWA_DIS_SLV_ECC,
    HAL_MT_NAMCHABARWA_FPUHSH_SLV_ECC,
    HAL_MT_NAMCHABARWA_FWR_SLV_ECC,
    HAL_MT_NAMCHABARWA_RWI_SLV_ECC,
    HAL_MT_NAMCHABARWA_RWO_SLV_ECC,
    HAL_MT_NAMCHABARWA_MTR_SLV_ECC,
    HAL_MT_NAMCHABARWA_CNT_SLV_ECC,
    HAL_MT_NAMCHABARWA_ICIA_SLV_ECC,
    HAL_MT_NAMCHABARWA_ECIA_SLV_ECC,
    HAL_MT_NAMCHABARWA_CIAT_SLV_ECC,
    HAL_MT_NAMCHABARWA_RWI_SLV_TELM_HDR,
    HAL_MT_INTR_IFMON,
    HAL_MT_INTR_COMMON_THREAD_TYPE,
    HAL_MT_INTR_TM_PFCWD,

    HAL_MT_INTR_TYPE_LAST

} HAL_MT_INTR_TYPE_T;

typedef struct {
    HAL_MT_INTR_TYPE_T intr_type;

    UI32_T inst_idx;
    UI32_T subinst_idx;

    UI32_T stat_reg; /* intr reg id, such as MT_REG_TDS_SLV_TDS_TIMEOUT_IRQ_ID */
    UI32_T mask_reg;
    UI32_T clr_reg;
    UI32_T test_reg;
} HAL_MT_INTR_REG_NODE_T;

typedef CLX_ERROR_NO_T (*HAL_MT_ISR_HANDLE_FUNC_T)(const UI32_T unit, void *ptr_cookie);

typedef struct HAL_MT_INTR_NODE_S {
    HAL_MT_INTR_REG_NODE_T reg_info;
    HAL_MT_ISR_HANDLE_FUNC_T intr_handle_func;
    const struct HAL_MT_INTR_NODE_S *next;
} HAL_MT_INTR_NODE_T;

/* Callback Functions for IRQ related registers R/W */
typedef CLX_ERROR_NO_T (*HAL_MT_INTR_READ_FUNC_T)(const UI32_T unit,
                                                  UI32_T *ptr_reg_val,
                                                  UI32_T *word_size,
                                                  const HAL_MT_INTR_REG_NODE_T intr_node);

typedef CLX_ERROR_NO_T (*HAL_MT_INTR_READ_MASK_FUNC_T)(const UI32_T unit,
                                                       UI32_T *ptr_reg_val,
                                                       const HAL_MT_INTR_REG_NODE_T intr_node);

typedef CLX_ERROR_NO_T (*HAL_MT_INTR_WRITE_FUNC_T)(const UI32_T unit,
                                                   UI32_T *reg_val,
                                                   HAL_MT_INTR_REG_NODE_T intr_node);

typedef CLX_ERROR_NO_T (*HAL_MT_INTR_TYPE_WRITE_FUNC_T)(const UI32_T unit,
                                                        const HAL_MT_INTR_TYPE_T intr_type);

typedef CLX_ERROR_NO_T (*HAL_MT_INTR_CHAIN_UNMASK_FUNC_T)(const UI32_T unit, const UI32_T reg_val);

typedef CLX_ERROR_NO_T (*HAL_MT_INTR_TYPE_UNMASK_FUNC_T)(const UI32_T unit,
                                                         const UI32_T chain,
                                                         const UI32_T slave,
                                                         const HAL_MT_INTR_TYPE_T intr_type);

typedef CLX_ERROR_NO_T (*HAL_MT_INTR_DUMP_FUNC_T)(const UI32_T unit);

typedef struct {
    UI32_T slave;
    UI32_T inst_idx;
    UI32_T subinst_idx;
    const HAL_MT_INTR_NODE_T *slave_head;
} HAL_MT_INTR_VEC_T;

typedef struct {
    HAL_MT_INTR_READ_FUNC_T intr_read_stat;
    HAL_MT_INTR_WRITE_FUNC_T intr_test;
    HAL_MT_INTR_WRITE_FUNC_T intr_clear;
    HAL_MT_INTR_READ_MASK_FUNC_T intr_read_mask;
    HAL_MT_INTR_WRITE_FUNC_T intr_mask;
    HAL_MT_INTR_WRITE_FUNC_T intr_unmask;
    HAL_MT_INTR_TYPE_WRITE_FUNC_T intr_type_unmask;
    HAL_MT_INTR_TYPE_WRITE_FUNC_T intr_type_mask;
    HAL_MT_INTR_CHAIN_UNMASK_FUNC_T intr_umac_unmask;
    HAL_MT_INTR_DUMP_FUNC_T intr_dump;
} HAL_MT_INTR_FUNC_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* -------------------------------------- Init and deinit */
CLX_ERROR_NO_T
hal_mt_intr_init(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_intr_deinit(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_intr_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_intr_deinitCfg(const UI32_T unit);

/* -------------------------------------- Reg operation */
CLX_ERROR_NO_T
hal_mt_intr_readIntr(const UI32_T unit,
                     UI32_T *reg_val,
                     UI32_T *word_size,
                     const HAL_MT_INTR_REG_NODE_T intr_node);

CLX_ERROR_NO_T
hal_mt_intr_maskIntr(const UI32_T unit, UI32_T *reg_val, const HAL_MT_INTR_REG_NODE_T intr_node);

CLX_ERROR_NO_T
hal_mt_intr_clearIntr(const UI32_T unit, UI32_T *reg_val, const HAL_MT_INTR_REG_NODE_T intr_node);

CLX_ERROR_NO_T
hal_mt_intr_unmaskIntr(const UI32_T unit, UI32_T *reg_val, const HAL_MT_INTR_REG_NODE_T intr_node);

CLX_ERROR_NO_T
hal_mt_intr_unmask_intr_type(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

CLX_ERROR_NO_T
hal_mt_intr_unmaskUmac(const UI32_T unit, const UI32_T reg_val);

CLX_ERROR_NO_T
hal_mt_intr_mask_intr_type(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

CLX_ERROR_NO_T
hal_mt_intr_dump_intr(const UI32_T unit);

/* -------------------------------------- API and callbacks */
CLX_ERROR_NO_T
hal_mt_namchabarwa_request_irq(const UI32_T unit,
                               HAL_MT_INTR_TYPE_T intr_type,
                               HAL_MT_ISR_HANDLE_FUNC_T handler);

CLX_ERROR_NO_T
hal_mt_intr_triggerEvent(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

CLX_ERROR_NO_T
hal_mt_intr_triggerEventReg(const UI32_T unit, void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_intr_triggerCommonEvent(const UI32_T unit, void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_intr_waitEvent(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type, const UI32_T timeout);

CLX_ERROR_NO_T
hal_mt_intr_take_spinlock(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

CLX_ERROR_NO_T
hal_mt_intr_give_spinlock(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

CLX_ERROR_NO_T
hal_mt_intr_waitIfmonEvent(const UI32_T unit, const UI32_T timeout);

CLX_ERROR_NO_T
hal_mt_telm_triggerTelmHdrEvent(const UI32_T unit, void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_intr_triggerL2FifoEvent(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

CLX_ERROR_NO_T
hal_mt_intr_getEventCnt(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_intr_incrEventCnt(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

CLX_ERROR_NO_T
hal_mt_intr_clearEventCnt(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

const C8_T *
hal_mt_intr_getEventString(const UI32_T unit, const HAL_MT_INTR_TYPE_T intr_type);

#endif /* #ifndef HAL_MT_INTR_H */
