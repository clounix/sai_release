/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  diag.h
 * PURPOSE:
 *      1. It provides DIAG (Diagnosis) module internal API
 *      2. It provides debug console and buffer functionalities
 *
 * NOTES:
 *
 */

#ifndef DIAG_H
#define DIAG_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_module.h>
#include <hal/hal_tbl.h>
#include <hal/hal_dbg.h>
#include <cdb/cdb.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_SUBMODULE_LAST (16)

extern UI32_T _ext_module_dbg_flag[OSAL_TASK_ID_LAST][CLX_MODULE_LAST][HAL_SUBMODULE_LAST];

#ifdef CLX_EN_DEBUG

#ifdef CLX_EN_COMPILER_SUPPORT_FUNCTION
#define DIAG_SET_MODULE_INFO(__module_id__, __file_name__) \
    static CLX_MODULE_T __CLX_MODULE__ = (__module_id__)

#define DIAG_PRINT(submodule, __flag__, ...)                                              \
    do {                                                                                  \
        if (CLX_E_OK == diag_checkLogLevel(__CLX_MODULE__, submodule, __flag__)) {        \
            if (0 != ((HAL_DBG_ERR) & (__flag__))) {                                      \
                diag_printToInternalLog(__CLX_MODULE__, __flag__, __func__, __LINE__,     \
                                        ##__VA_ARGS__);                                   \
            }                                                                             \
            if (0 != (__flag__)) {                                                        \
                diag_print(__CLX_MODULE__, __func__, __LINE__, ##__VA_ARGS__);            \
                if (0 == ((HAL_DBG_ERR) & (__flag__))) {                                  \
                    diag_printToInternalLog(__CLX_MODULE__, __flag__, __func__, __LINE__, \
                                            ##__VA_ARGS__);                               \
                }                                                                         \
            }                                                                             \
        }                                                                                 \
    } while (0)

#else /* !CLX_EN_COMPILER_SUPPORT_FUNCTION */
#define DIAG_SET_MODULE_INFO(__module_id__, __file_name__) \
    static CLX_MODULE_T __CLX_MODULE__ = (__module_id__);  \
    static C8_T *__CLX_FILE__ = (__file_name__)

#define DIAG_PRINT(submodule, __flag__, ...)                                                  \
    do {                                                                                      \
        if (CLX_E_OK == diag_checkLogLevel(__CLX_MODULE__, submodule, __flag__)) {            \
            if (0 != ((HAL_DBG_ERR) & (__flag__))) {                                          \
                diag_printToInternalLog(__CLX_MODULE__, __flag__, __CLX_FILE__, __LINE__,     \
                                        ##__VA_ARGS__);                                       \
            }                                                                                 \
            if (0 != (__flag__)) {                                                            \
                diag_print(__CLX_MODULE__, __CLX_FILE__, __LINE__, ##__VA_ARGS__);            \
                if (0 == ((HAL_DBG_ERR) & (__flag__))) {                                      \
                    diag_printToInternalLog(__CLX_MODULE__, __flag__, __CLX_FILE__, __LINE__, \
                                            ##__VA_ARGS__);                                   \
                }                                                                             \
            }                                                                                 \
        }                                                                                     \
    } while (0)

#endif /* #ifdef CLX_EN_COMPILER_SUPPORT_FUNCTION */

#define DIAG_PRINT_RAW(submodule, __flag__, ...)                                   \
    do {                                                                           \
        if (CLX_E_OK == diag_checkLogLevel(__CLX_MODULE__, submodule, __flag__)) { \
            if (0 != (__flag__)) {                                                 \
                diag_print_raw(__CLX_MODULE__, ##__VA_ARGS__);                     \
            }                                                                      \
        }                                                                          \
    } while (0)

#define DIAG_PRINT_HEX_BUF(submodule, __flag__, __ptr_buf__, __buf_size__)         \
    do {                                                                           \
        if (CLX_E_OK == diag_checkLogLevel(__CLX_MODULE__, submodule, __flag__)) { \
            if (0 != (__flag__)) {                                                 \
                diag_printHexBuf(__CLX_MODULE__, __ptr_buf__, __buf_size__);       \
            }                                                                      \
        }                                                                          \
    } while (0)

#define DIAG_PRINT_HEX_TBL(submodule, __flag__, __ptr_buf__, __buf_word_size__)      \
    do {                                                                             \
        if (CLX_E_OK == diag_checkLogLevel(__CLX_MODULE__, submodule, __flag__)) {   \
            if (0 != (__flag__)) {                                                   \
                diag_printWideField(__CLX_MODULE__, __buf_word_size__, __ptr_buf__); \
            }                                                                        \
        }                                                                            \
    } while (0)

#define DIAG_EN_TBL_TRACK
#ifdef DIAG_EN_TBL_TRACK

#define DIAG_PRINT_MULTI_FEILDS_INFO(submodule, __flag__, __unit__, __tbl_id__, __inst__,          \
                                     __subinst__, __entry__, __list__, __count__, __buf__)         \
    do {                                                                                           \
        if (CLX_E_OK == diag_checkLogLevel(__CLX_MODULE__, submodule, __flag__)) {                 \
            if (0 != (__flag__)) {                                                                 \
                diag_print(__CLX_MODULE__, __func__, __LINE__,                                     \
                           "[C] %s inst=%u sub-inst=%u entry=%u:\n",                               \
                           CDB_TABLE(__unit__, __tbl_id__)->ptr_table_name, __inst__, __subinst__, \
                           __entry__);                                                             \
                diag_printMultiFields(__CLX_MODULE__, __unit__, __tbl_id__, __list__, __count__);  \
                diag_printTblInfo(__CLX_MODULE__, __unit__, __tbl_id__, __buf__);                  \
            }                                                                                      \
        }                                                                                          \
    } while (0)

#define DIAG_PRINT_SINGLE_FEILD_INFO(submodule, __flag__, __unit__, __tbl_id__, __inst__,          \
                                     __subinst__, __entry__, __value__, __fid__, __buf__)          \
    do {                                                                                           \
        if (CLX_E_OK == diag_checkLogLevel(__CLX_MODULE__, submodule, __flag__)) {                 \
            if (0 != (__flag__)) {                                                                 \
                diag_print(__CLX_MODULE__, __func__, __LINE__,                                     \
                           "[C] %s inst=%u sub-inst=%u entry=%u:\n",                               \
                           CDB_TABLE(__unit__, __tbl_id__)->ptr_table_name, __inst__, __subinst__, \
                           __entry__);                                                             \
                diag_printSingleField(__CLX_MODULE__, __unit__, __tbl_id__, __value__, __fid__);   \
                diag_printTblInfo(__CLX_MODULE__, __unit__, __tbl_id__, __buf__);                  \
            }                                                                                      \
        }                                                                                          \
    } while (0)

#define DIAG_PRINT_TBL_INFO(submodule, __flag__, __unit__, __tbl_id__, __inst__, __subinst__,      \
                            __entry__, __buf__)                                                    \
    do {                                                                                           \
        if (CLX_E_OK == diag_checkLogLevel(__CLX_MODULE__, submodule, __flag__)) {                 \
            if (0 != (__flag__)) {                                                                 \
                diag_print(__CLX_MODULE__, __func__, __LINE__,                                     \
                           "[C] %s inst=%u sub-inst=%u entry=%u:\n",                               \
                           CDB_TABLE(__unit__, __tbl_id__)->ptr_table_name, __inst__, __subinst__, \
                           __entry__);                                                             \
                diag_printTblInfo(__CLX_MODULE__, __unit__, __tbl_id__, __buf__);                  \
            }                                                                                      \
        }                                                                                          \
    } while (0)

#else /* !DIAG_EN_TBL_TRACK */
#define DIAG_PRINT_MULTI_FEILDS_INFO(...)
#define DIAG_PRINT_SINGLE_FEILD_INFO(...)
#define DIAG_PRINT_TBL_INFO(...)
#endif

#else /* !CLX_EN_DEBUG */
#define DIAG_SET_MODULE_INFO(__module_id__, __file_name__)
#define DIAG_PRINT(submodule, __flag__, ...)
#define DIAG_PRINT_HEX_BUF(submodule, __flag__, __ptr_buf__, __buf_size__)
#define DIAG_PRINT_HEX_TBL(submodule, __flag__, __ptr_buf__, __buf_word_size__)
#define DIAG_PRINT_RAW(...)
#define DIAG_PRINT_MULTI_FEILDS_INFO(...)
#define DIAG_PRINT_SINGLE_FEILD_INFO(...)
#define DIAG_PRINT_TBL_INFO(...)

#endif /* #ifdef CLX_EN_DEBUG */

#define DIAG_BYTES_OF_WORD     (4)
#define DIAG_MAX_ENTRY_LEN     (MAX_ENTRY_SIZE)
#define DIAG_MAX_FIELD_LEN     (MAX_FIELD_SIZE)
#define DIAG_MAX_FIELD_NUM     (MAX_FIELD_NUM)
#define DIAG_PRINT_BUF_SIZE    (512)
#define DIAG_LOG_ENTRY_MAX_NUM (4 * 1024)

/* DATA TYPE DECLARATIONS
 */
/* DIAG Table CLI Input Type selection */
typedef enum {
    DIAG_INPUT_TYPE_NAME = 0,
    DIAG_INPUT_TYPE_ID,
    DIAG_INPUT_TYPE_RAW,
    DIAG_INPUT_TYPE_LAST
} DIAG_INPUT_TYPE_T;

/* DIAG Show cmd format option */
typedef enum {
    DIAG_SHOW_CMD_FIELD_OPT_NORMAL = 0,
    DIAG_SHOW_CMD_FIELD_OPT_FILTER0,
    DIAG_SHOW_CMD_FIELD_OPT_RAW,
    DIAG_SHOW_CMD_FIELD_OPT_LAST
} DIAG_SHOW_CMD_FIELD_OPT_T;

typedef enum {
    DIAG_SHOW_CMD_ENTRY_OPT_NORMAL = 0,
    DIAG_SHOW_CMD_ENTRY_OPT_FILTER0,
    DIAG_SHOW_CMD_ENTRY_OPT_LAST
} DIAG_SHOW_CMD_ENTRY_OPT_T;

typedef struct DIAG_FIELD_S {
    UI32_T field_id;
    UI32_T data[DIAG_MAX_FIELD_LEN];
    UI32_T mask[DIAG_MAX_FIELD_LEN];
    UI32_T data_size;
    UI32_T mask_size;
    BOOL_T zero;
} DIAG_FIELD_T;

typedef struct DIAG_FIELDS_META_S {
    UI32_T valid_field_num;
    DIAG_FIELD_T field_info[DIAG_MAX_FIELD_NUM];
    UI32_T raw_data[DIAG_MAX_ENTRY_LEN];
    UI32_T raw_mask[DIAG_MAX_ENTRY_LEN];
    BOOL_T valid_entry;
    BOOL_T allZero;
} DIAG_FIELDS_META_T;

typedef enum {
    DIAG_SET_MODE_SET_ONLY = 0,
    DIAG_SET_MODE_VERIFY_ONLY,
    DIAG_SET_MODE_SET_AND_VERIFY,
    DIAG_SET_MODE_LAST
} DIAG_SET_MODE_T;

typedef struct DIAG_LOG_ENTRY_S {
    OSAL_TM_T timestamp;
    CLX_MODULE_T module;
    UI32_T dbg_level;
    C8_T log[DIAG_PRINT_BUF_SIZE];
} DIAG_LOG_ENTRY_T;

typedef struct DIAG_LOG_CB_S {
    UI32_T inited;
    CLX_SEMAPHORE_ID_T sema;
    BOOL_T wrap_mode;
    UI32_T nonwrap_count;
    UI32_T entry_index;
    UI32_T entry_count;
    DIAG_LOG_ENTRY_T *ptr_entry;
} DIAG_LOG_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief This function initialize the DIAG module
 *
 * @return         CLX_E_OK           - operate success
 * @return         CLX_E_NO_MEMORY    - bad parameter
 * @return         CLX_E_OTHERS       - operate failed
 */
CLX_ERROR_NO_T
diag_init(void);

/**
 * @brief This function de-initialize the DIAG module
 *
 * @return         CLX_E_OK        - operate success
 * @return         CLX_E_OTHERS    - operate failed
 */
CLX_ERROR_NO_T
diag_deinit(void);

/**
 * @brief This function is used to enable/disable module's debug message recording
 *
 * @param [in]     task_id      - task id
 * @param [in]     module_id    - selected module item
 * @param [in]     submodule    - submodule id
 * @param [in]     dbg_flag     - debug level
 * @return         CLX_E_OK               - operate success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
diag_setDebugFlag(const OSAL_TASK_ID_T task_id,
                  const CLX_MODULE_T module_id,
                  const UI32_T submodule,
                  const UI32_T dbg_flag);

/**
 * @brief This function is used to get current debug message recording status
 *
 * @param [in]     task_id          - task id
 * @param [in]     module_id        - selected module item
 * @param [in]     submodule        - submodule id
 * @param [out]    ptr_dbg_flag     - pointer to get the debug flag status
 * @return         CLX_E_OK               - operate success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
diag_getDebugFlag(const OSAL_TASK_ID_T task_id,
                  const CLX_MODULE_T module_id,
                  const UI32_T submodule,
                  UI32_T *ptr_dbg_flag);

CLX_ERROR_NO_T
diag_checkDebugFlag(const UI32_T submodule, const CLX_MODULE_T module, const UI32_T dbg_level);

void
diag_print_raw(const CLX_MODULE_T module, const C8_T *ptr_fmt, ...);

void
diag_printWideField(const CLX_MODULE_T module,
                    const UI32_T data_size_in_word,
                    const UI32_T *value_list);

void
diag_printTblInfo(const CLX_MODULE_T module,
                  const UI32_T unit,
                  const UI32_T table_id,
                  const UI32_T *ptr_buf);

void
diag_printSingleField(const CLX_MODULE_T module,
                      const UI32_T unit,
                      const UI32_T table_id,
                      const UI32_T *value_list,
                      const UI32_T field_id);

void
diag_printMultiFields(const CLX_MODULE_T module,
                      const UI32_T unit,
                      const UI32_T table_id,
                      const CDB_FVP_T *value_list,
                      const UI32_T field_count);

/**
 * @brief This function is used to output debug message to console or/and save to DIAG buffer
 *
 * @param [in]     module      - selected module item
 * @param [in]     ptr_func    - function or file name string
 * @param [in]     line        - line number
 * @param [in]     ptr_fmt     - input string pointer
 */
void
diag_print(const CLX_MODULE_T module,
           const C8_T *ptr_func,
           const UI32_T line,
           const C8_T *ptr_fmt,
           ...);

/**
 * @brief This function is used to output debug message into internal log
 *
 * @param [in]     module       - selected module item
 * @param [in]     dbg_level    - debug level
 * @param [in]     ptr_func     - function or file name string
 * @param [in]     line         - line number
 * @param [in]     ptr_fmt      - input string pointer
 */
void
diag_printToInternalLog(const CLX_MODULE_T module,
                        const UI32_T dbg_level,
                        const C8_T *ptr_func,
                        const UI32_T line,
                        const C8_T *ptr_fmt,
                        ...);

/**
 * @brief This function is used to get internal log _diag_log_buf
 *
 * @param [out]    ptr_entry_index    - the curent index of internal log
 * @param [out]    ptr_entry_count    - the entry count of internal log
 * @param [out]    ptr_entry          - the snapshot of all internal logs
 */
void
diag_getInternalLog(UI32_T *ptr_entry_index, UI32_T *ptr_entry_count, DIAG_LOG_ENTRY_T *ptr_entry);

/**
 * @brief This function is used to clear all internal log
 *
 */
void
diag_clearInternalLog(void);

/**
 * @brief This function is used to enable internal log mode to wrap mode or not
 *
 * @param [in]     wrap_mode_enable    - enable wrap mode or not
 */
void
diag_setInternalLogWrapMode(const BOOL_T wrap_mode_enable);

/**
 * @brief This function is used to get internal log if wrap mode or not
 *
 * @param [out]    ptr_mode    - pointer of wrap mode
 */
void
diag_getInternalLogWrapMode(BOOL_T *ptr_mode);

/**
 * @brief Show table/reg by field data according to the DIAG_FIELDS_META_T
 *
 * @param [in]     unit                   - unit index
 * @param [in]     inst_idx               - instance index
 * @param [in]     sub_inst_idx           - sub instance index
 * @param [in]     entry_idx              - entry index
 * @param [in]     tbl_id                 - table index
 * @param [in]     ptr_diag_field_meta    - pointer of DIAG_FIELDS_META_T
 *                                          to indicate which field shoud be shown
 * @param [in]     opt                    - show option
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
diag_showMem(UI32_T unit,
             UI32_T inst_idx,
             UI32_T sub_inst_idx,
             UI32_T entry_idx,
             UI32_T tbl_id,
             DIAG_FIELDS_META_T *ptr_diag_field_meta,
             DIAG_SHOW_CMD_FIELD_OPT_T opt);

/**
 * @brief set table/reg by field data and mask according to the DIAG_FIELDS_META_T
 *
 * @param [in]     unit                   - unit index
 * @param [in]     inst_idx               - instance index
 * @param [in]     sub_inst_idx           - sub instance index
 * @param [in]     entry_idx              - entry index
 * @param [in]     tbl_id                 - table index
 * @param [in]     ptr_diag_field_meta    - pointer of DIAG_FIELDS_META_T
 * @param [in]     mode                   - set mode
 * @return         CLX_E_OK        - operate success
 * @return         CLX_E_OTHERS    - operate failed
 */
CLX_ERROR_NO_T
diag_setMem(UI32_T unit,
            UI32_T inst_idx,
            UI32_T sub_inst_idx,
            UI32_T entry_idx,
            UI32_T tbl_id,
            DIAG_FIELDS_META_T *ptr_diag_field_meta,
            DIAG_SET_MODE_T mode);

/**
 * @brief set table/reg by overwrite data
 *
 * @param [in]     unit              - unit index
 * @param [in]     inst_idx          - instance index
 * @param [in]     sub_inst_idx      - sub instance index
 * @param [in]     entry_idx         - entry index
 * @param [in]     tbl_id            - table index
 * @param [in]     ptr_write_data    - pointer of overwrite raw data buffer
 * @param [in]     mode              - set mode
 * @return         CLX_E_OK          - operate success
 * @return         CLX_E_OTHERS      - operate failed
 */
CLX_ERROR_NO_T
diag_setMemOverwrite(UI32_T unit,
                     UI32_T inst_idx,
                     UI32_T sub_inst_idx,
                     UI32_T entry_idx,
                     UI32_T tbl_id,
                     UI32_T *ptr_write_data,
                     DIAG_SET_MODE_T mode);

/**
 * @brief Add hash by field data according to the DIAG_FIELDS_META_T
 *
 * @param [in]     unit                   - unit index
 * @param [in]     inst_idx               - instance index
 * @param [in]     sub_inst_idx           - sub instance index
 * @param [in]     bank_bmp               - bank bitmap
 * @param [in]     tbl_id                 - table index
 * @param [in]     ptr_diag_field_meta    - pointer of DIAG_FIELDS_META_T
 * @param [out]    ptr_entry_idx          - added entry idx
 * @return         CLX_E_OK        - operate success
 * @return         CLX_E_OTHERS    - operate failed
 */
CLX_ERROR_NO_T
diag_addHash(UI32_T unit,
             UI32_T inst_idx,
             UI32_T sub_inst_idx,
             UI32_T bank_bmp,
             UI32_T tbl_id,
             DIAG_FIELDS_META_T *ptr_diag_field_meta,
             UI32_T *ptr_entry_idx);

/**
 * @brief Delete hash by field data according to the DIAG_FIELDS_META_T
 *
 * @param [in]     unit                   - unit index
 * @param [in]     inst_idx               - instance index
 * @param [in]     sub_inst_idx           - sub instance index
 * @param [in]     bank_bmp               - bank bitmap
 * @param [in]     tbl_id                 - table index
 * @param [in]     ptr_diag_field_meta    - pointer of DIAG_FIELDS_META_T
 * @param [out]    ptr_entry_idx          - deleted entry index
 * @return         CLX_E_OK        - operate success
 * @return         CLX_E_OTHERS    - operate failed
 */
CLX_ERROR_NO_T
diag_delHash(UI32_T unit,
             UI32_T inst_idx,
             UI32_T sub_inst_idx,
             UI32_T bank_bmp,
             UI32_T tbl_id,
             DIAG_FIELDS_META_T *ptr_diag_field_meta,
             UI32_T *ptr_entry_idx);

/**
 * @brief Lookup hash by field data according to the DIAG_FIELDS_META_T
 *
 * @param [in]     unit                   - unit index
 * @param [in]     inst_idx               - instance index
 * @param [in]     sub_inst_idx           - sub instance index
 * @param [in]     bank_bmp               - bank bitmap
 * @param [in]     tbl_id                 - table index
 * @param [in]     ptr_diag_field_meta    - pointer of DIAG_FIELDS_META_T
 * @param [out]    ptr_entry_idx          - lookup result
 * @return         CLX_E_OK        - operate success
 * @return         CLX_E_OTHERS    - operate failed
 */
CLX_ERROR_NO_T
diag_lookupHash(UI32_T unit,
                UI32_T inst_idx,
                UI32_T sub_inst_idx,
                UI32_T bank_bmp,
                UI32_T tbl_id,
                DIAG_FIELDS_META_T *ptr_diag_field_meta,
                UI32_T *ptr_entry_idx);

/**
 * @brief Update hash by field data according to the DIAG_FIELDS_META_T
 *
 * @param [in]     unit                   - unit index
 * @param [in]     inst_idx               - instance index
 * @param [in]     sub_inst_idx           - sub instance index
 * @param [in]     bank_bmp               - bank bitmap
 * @param [in]     tbl_id                 - table index
 * @param [in]     ptr_diag_field_meta    - pointer of DIAG_FIELDS_META_T
 * @param [out]    ptr_entry_idx          - added entry idx
 * @return         CLX_E_OK        - operate success
 * @return         CLX_E_OTHERS    - operate failed
 */
CLX_ERROR_NO_T
diag_updateHash(UI32_T unit,
                UI32_T inst_idx,
                UI32_T sub_inst_idx,
                UI32_T bank_bmp,
                UI32_T tbl_id,
                DIAG_FIELDS_META_T *ptr_diag_field_meta,
                UI32_T *ptr_entry_idx);

/**
 * @brief print buf in hex style
 *
 * @param [in]     module      - selected module item
 * @param [in]     ptr_buf     - data buf
 * @param [in]     buf_size    - print size
 * @return         CLX_E_OK        - operate success
 * @return         CLX_E_OTHERS    - operate failed
 */
void
diag_printHexBuf(const CLX_MODULE_T module, const UI8_T *ptr_buf, const UI32_T buf_size);

/**
 * @brief check if log level matches.
 *
 * @param [in]     submodule    - selected submodule item
 * @param [in]     module       - selected module item
 * @param [in]     dbg_level    - current dbg level
 * @return         CLX_E_OK        - operate success
 * @return         CLX_E_OTHERS    - operate failed
 */
CLX_ERROR_NO_T
diag_checkLogLevel(const CLX_MODULE_T module, const UI32_T submodule, const UI32_T dbg_level);

#endif /* End of DIAG_H */
