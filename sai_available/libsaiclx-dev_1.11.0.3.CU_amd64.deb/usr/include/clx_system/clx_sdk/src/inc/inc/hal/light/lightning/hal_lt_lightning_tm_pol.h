/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_lt_lightning_tm_pol.h
 * PURPOSE:
 *      It provide HAL API of PM, IOS and LBM module.
 * NOTES:
 */

#ifndef HAL_LT_LIGHTNING_TM_POL_H
#define HAL_LT_LIGHTNING_TM_POL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setPmState(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_DIR_T dir,
                                   const UI32_T enable);

/**
 * @brief To set cos map to pcp at IOS.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - Port id
 * @param [in]     ori_pcp_bmp     - Bitmap of original PCP (meaningless when action is ADD)
 * @param [in]     new_pcp_bmp     - Bitmap of new PCP (meaningless when action is DELETE)
 * @param [in]     action          - CLEAR ALL, ADD, UPDATE or DELETE
 * @param [out]    ptr_class       - *ptr_class is original class if the action is delete or update.
 * *ptr_class is new class if the action is ADD.
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setIosCosMapPcp(const UI32_T unit,
                                        const UI32_T port,
                                        const UI32_T ori_pcp_bmp,
                                        const UI32_T new_pcp_bmp,
                                        const HAL_TM_IOS_COS_MAP_PCP_ACTION_T action,
                                        UI32_T *ptr_class);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_getIosCosMapPcp(const UI32_T unit,
                                        const UI32_T port,
                                        const UI32_T ios_class,
                                        UI32_T *ptr_pcp_bmp);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_resetIpmCosPortDscp(const UI32_T unit,
                                            const UI32_T port,
                                            const UI32_T target_cos);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_getDscpToCos(const UI32_T unit,
                                     const UI32_T port,
                                     const UI32_T dscp,
                                     UI32_T *ptr_cos);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setIpmCosPortDscp(const UI32_T unit,
                                          const UI32_T port,
                                          const UI32_T dscp_count,
                                          const UI32_T *ptr_dscp_list,
                                          const UI32_T target_cos);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setIosCos(const UI32_T unit,
                                  const UI32_T port,
                                  const UI32_T ios_class,
                                  const UI32_T new_pcp_bmp);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setIosCosToPcp(const UI32_T unit,
                                       const UI32_T port,
                                       const UI32_T ios_class,
                                       const UI32_T new_pcp_bmp);

/**
 * @brief To set cos for related pcp bitmap at IPM.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - Port id
 * @param [in]     pcp_bitmap      - Bitmap of PCP
 * @param [in]     ios_class       - 0:lossy, 1:hi 1, 2:hi 2, 3:control
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setIpmCosPort(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T pcp_bitmap,
                                      const UI32_T ios_class);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_getEpmBufferEmpty(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setProperty(const UI32_T unit,
                                    const UI32_T port,
                                    const HAL_TM_EPM_PROPERTY_T property,
                                    const UI32_T data);

/**
 * @brief To set sc index(0 and 1) map to cos at IOS.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - Port id
 * @param [in]     sc_idx          - Only 0 or 1
 * @param [in]     ios_class       - 0:lossy, 1:hi 1, 2:hi 2, 3:control
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setIosScIdxToCos(const UI32_T unit,
                                         const UI32_T port,
                                         const UI32_T sc_idx,
                                         const UI32_T ios_class);

/**
 * @brief To get cos by sc index(0 and 1) at IOS.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - port id
 * @param [in]     sc_idx          - Only 0 or 1
 * @param [out]    ptr_ios_class   - Ios class
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_getIosScIdxToCos(const UI32_T unit,
                                         const UI32_T port,
                                         const UI32_T sc_idx,
                                         UI32_T *ptr_ios_class);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setIosFlush(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_getLbsEmpty(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_resetLbsSpg(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_setDropError(const UI32_T unit, const UI32_T port, const UI32_T enable);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_getIpmCosPort(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T ios_class,
                                      UI32_T *ptr_pcp_bitmap);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_updateIpmCosPortDscp(const UI32_T unit,
                                             const UI32_T port,
                                             const UI32_T target_cos,
                                             const UI32_T new_cos);

CLX_ERROR_NO_T
hal_lt_lightning_tm_pol_updateIpmCosPortDscpEn(const UI32_T unit,
                                               const UI32_T port,
                                               const UI32_T target_cos);

#endif /* #ifndef HAL_LT_LIGHTNING_TM_POL_H */
