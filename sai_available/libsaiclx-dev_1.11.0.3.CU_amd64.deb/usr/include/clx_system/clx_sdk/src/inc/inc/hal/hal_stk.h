/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_stk.h
 * PURPOSE:
 *      It provides hal stacking module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_STK_H
#define HAL_STK_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stk.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_STK_DFLT_CHIP_MODE       (HAL_STK_CHIP_MODE_PORT_CHIP)
#define HAL_STK_DFLT_CHIP_ID         (0)
#define HAL_STK_INVALID_CHIP_ID      (31)
#define HAL_STK_EXTENDED_CHIP_ID_MIN (32)
#define HAL_STK_EXTENDED_CHIP_ID_MAX (HAL_STK_EXTENDED_CHIP_ID_MIN + HAL_EXTENDED_CHIP_NUM - 1)

#define HAL_STK_UC_INVLID_VQI_GRP  (0x3F)
#define HAL_STK_MIR_INVLID_VQI_GRP (0x1FF)
#define HAL_STK_CPU_INVLID_VQI_GRP (0x3F)

#define HAL_STK_PATH_PORT_NUM    (32) /* maximum supported port for each path */
#define HAL_STK_PATH_GRP_NUM     (2)  /* only clockwise anti-clockwise */
#define HAL_STK_PATH_GRP_MIN     (0)
#define HAL_STK_PATH_GRP_MAX     (HAL_STK_PATH_GRP_MIN + HAL_STK_PATH_GRP_NUM - 1)
#define HAL_STK_PATH_FAB_NUM     (32)
#define HAL_STK_INVALID_PATH_GRP (31) /* sw reserved for unconfiged chip path */
#define HAL_STK_PATH_FAB_MAX     (HAL_STK_PATH_GRP_MIN + HAL_STK_PATH_FAB_NUM - 2)
#define HAL_STK_PATH_CPU_FAB_NUM (4)
#define HAL_STK_PATH_CPU_FAB_MAX (HAL_STK_PATH_GRP_MIN + HAL_STK_PATH_CPU_FAB_NUM - 1)

#define HAL_STK_UC_SEL_HSH_BITS  (5)
#define HAL_STK_UC_SEL_ENTRY_NUM (1U << HAL_STK_UC_SEL_HSH_BITS)

#define HAL_STK_MC_SEL_HSH_BITS  (10)
#define HAL_STK_MC_SEL_ENTRY_NUM (1U << HAL_STK_MC_SEL_HSH_BITS)
#define HAL_STK_MC_SEL_EPOCH_BIT (HAL_STK_MC_SEL_HSH_BITS)

#define HAL_STK_MIR_SEL_HSH_BITS  (5)
#define HAL_STK_MIR_SEL_ENTRY_NUM (1U << HAL_STK_MIR_SEL_HSH_BITS)

#define HAL_STK_CPU_SEL_HSH_BITS  (5)
#define HAL_STK_CPU_SEL_ENTRY_NUM (1U << HAL_STK_CPU_SEL_HSH_BITS)

#define HAL_STK_LCL_CPI0_CPU_ID (30)
#define HAL_STK_LCL_CPI1_CPU_ID (31)

#define HAL_STK_CPU2CPU_PLANE      (1)
#define HAL_STK_CPU2CPU_PLANE_PORT (33)
#define HAL_STK_CPU2CPU_SUPP_IDX   (135)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_STK_LCL_DI_TO_DI(__unit__, __chip__, __lcl_di__) \
    ((__chip__) * HAL_PORT_DI_NUM(__unit__) + (__lcl_di__))

#define HAL_STK_LCL_DI_MIN(__unit__) (HAL_HW_CHIP_ID(__unit__) * HAL_PORT_DI_NUM(__unit__))
#define HAL_STK_LCL_DI_MAX(__unit__) \
    (((HAL_HW_CHIP_ID(__unit__) + 1) * HAL_PORT_DI_NUM(__unit__)) - 1)
#define HAL_STK_IS_LCL_DI(__unit__, __di__) \
    ((HAL_STK_LCL_DI_MIN(__unit__) <= (__di__)) && (HAL_STK_LCL_DI_MAX(__unit__) >= (__di__)))

#define HAL_STK_CHIP_MIN(__unit__) (0)
#define HAL_STK_CHIP_MAX(__unit__) ((HAL_PHY_PORT_NUM / HAL_PORT_DI_NUM(__unit__)) - 1)

#define HAL_STK_PLANE_BMP_FOREACH(__unit__, __plane__)                          \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (CMLIB_BITMAP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

#define HAL_STK_DP_PLANE_PORT_ETH_BMP_FOREACH(__pbmp__, __dp_pn_port__)         \
    for ((__dp_pn_port__) = HAL_PLANE_ETH_DP_PORT_MIN;                          \
         (__dp_pn_port__) <= HAL_PLANE_ETH_DP_PORT_MAX_CMN; (__dp_pn_port__)++) \
        if (CMLIB_BITMAP_BIT_CHK((__pbmp__), (__dp_pn_port__)))

#define HAL_STK_EXTENDED_CHIP_DI_BASE(__unit__, __chip__, __base__)                            \
    ({                                                                                         \
        if ((HAL_STK_EXTENDED_CHIP_ID_MIN <= (__chip__)) &&                                    \
            ((__chip__) <= HAL_STK_EXTENDED_CHIP_ID_MAX)) {                                    \
            __base__ = (HAL_EXTENDED_CHIP_DI_BASE +                                            \
                        HAL_EXTENDED_CHIP_DI_NUM * (__chip__ - HAL_STK_EXTENDED_CHIP_ID_MIN)); \
        } else {                                                                               \
            __base__ = 0;                                                                      \
        }                                                                                      \
    })

/* DATA TYPE DECLARATIONS
 */
typedef UI32_T HAL_STK_DP_PBMP_T[HAL_ITM_PBM_WORDS];
typedef UI32_T HAL_STK_DP_PBMP_OLD_V2_T[8];

typedef enum {
    HAL_STK_CHIP_MODE_PORT_CHIP = 0,
    HAL_STK_CHIP_MODE_CHASSIS_FAB,
    HAL_STK_CHIP_MODE_CHASSIS_LC,
    HAL_STK_CHIP_MODE_CHASSIS_CUSTOMIZE,
    HAL_STK_CHIP_MODE_LAST
} HAL_STK_CHIP_MODE_T;

typedef enum {
    HAL_STK_WBDB_CHIP_MODE,
    HAL_STK_WBDB_PATH_PBMP,
    HAL_STK_WBDB_CPU_PATH_PBMP,
    HAL_STK_WBDB_LAST
} HAL_STK_WBDB_T;

typedef struct HAL_STK_CB_S {
    HAL_STK_CHIP_MODE_T chip_mode;
    HAL_STK_DP_PBMP_T path_pbmp[HAL_STK_PATH_FAB_NUM];
    HAL_STK_DP_PBMP_T cpu_path_pbmp[HAL_STK_PATH_FAB_NUM];
    UI32_T *ptr_lag_sel_dma_buf_not_align;
    UI32_T *ptr_lag_sel_dma_buf;
    CLX_SEMAPHORE_ID_T sema_id;
    UI16_T l2uc_cpu_id;
    UI16_T l2uc_cpu_queue;
    UI16_T l3uc_cpu_id;
    UI16_T l3uc_cpu_queue;
} HAL_STK_CB_T;

typedef HAL_STK_CB_T HAL_STK_CB_P[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
/**
 * @brief Config stacking related register/table.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_init(const UI32_T unit);

/**
 * @brief Config stacking related register/table.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_deinit(const UI32_T unit);

/**
 * @brief Get chip id.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_chip    - Device chip id
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_stk_getMyChipId(const UI32_T unit, UI32_T *ptr_chip);

/**
 * @brief Set the reason bitmap to trap packets to the remote chip
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     chip             - Device chip id
 * @param [in]     reason_bitmap    - The reason bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_setReasonMapping(const UI32_T unit,
                         const UI32_T chip,
                         const CLX_PKT_RX_REASON_BITMAP_T reason_bitmap);

/**
 * @brief Get the reason bitmap which traps packets to the target remote chip
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     chip                 - Device chip id
 * @param [out]    ptr_reason_bitmap    - Pointer to the reason bitmap obtained
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_getReasonMapping(const UI32_T unit,
                         const UI32_T chip,
                         CLX_PKT_RX_REASON_BITMAP_T *ptr_reason_bitmap);

/* EXPORTED HAL PROGRAMS
 */

/**
 * @brief Get fabric port bitmap in hw plane port view.
 *
 * 1. For pp_pbmp size, please reference HAL_ITM_PBM_WORDS.
 *
 * @param [in]     unit           - Device unit number
 * @param [out]    ptr_pp_pbmp    - mgid port bitmap   (optional)
 * @param [out]    cl_pbmp        - CLX_PORT_BITMAP_T  (optional)
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_getFabPortBmp(const UI32_T unit, UI32_T *ptr_pp_pbmp, CLX_PORT_BITMAP_T cl_pbmp);

/**
 * @brief Check given port is used as fabric port or not.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port
 *                           0 : used as front port
 * @param [out]    ptr_is_fab             - status
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_checkFabPort(const UI32_T unit, const UI32_T port, BOOL_T *ptr_is_fab);

/**
 * @brief Set the egress stacking port queue for a specific remote cpu queue
 *        when Tx packet to remote cpu.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     rmt_cpu_queue     - Remote CPU queue
 * @param [in]     stacking_queue    - Egress stacking port queue
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_setStackingPortQueueMapping(const UI32_T unit,
                                    const UI32_T rmt_cpu_queue,
                                    const UI32_T stacking_queue);

/**
 * @brief Get the egress stacking port queuefor a specific remote cpu queue
 *        when Tx packet to remote cpu.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     rmt_cpu_queue         - Remote CPU queue
 * @param [out]    ptr_stacking_queue    - Egress stacking port queue
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_getStackingPortQueueMapping(const UI32_T unit,
                                    const UI32_T rmt_cpu_queue,
                                    UI32_T *ptr_stacking_queue);

/**
 * @brief Get the DIL entry.
 *
 * @param [in]     unit    - Device unit number
 * @return         HAL_STK_CB_P    - Control block pointer
 */
HAL_STK_CB_P *
hal_stk_getCtrlBlock(const UI32_T unit);

/**
 * @brief Get path number.
 *
 * @param [in]     unit    - Device unit number
 * @return         UI32_T    - path number
 */
UI32_T
hal_stk_getPathNum(const UI32_T unit);

/**
 * @brief Initiate the stk configuration.
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_stk_initCfg(const UI32_T unit);

/**
 * @brief Get extended chip di range.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     chip           - Device chip id
 * @param [out]    ptr_di_base    - DI base
 * @param [out]    ptr_di_num     - DI number
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_stk_getExtChipDiInfo(const UI32_T unit,
                         const UI32_T chip,
                         UI32_T *ptr_di_base,
                         UI32_T *ptr_di_num);

/**
 * @brief Get chip mode.
 *
 * @param [in]     unit             - Device unit number
 * @param [out]    ptr_chip_mode    - Chip mode
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_stk_getChipMode(const UI32_T unit, UI32_T *ptr_chip_mode);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
#endif
