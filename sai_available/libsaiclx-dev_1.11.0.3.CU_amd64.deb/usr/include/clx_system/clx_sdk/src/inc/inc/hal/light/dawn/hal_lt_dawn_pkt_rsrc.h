/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_dawn_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_LT_DAWN_PKT_RSRC_H
#define HAL_LT_DAWN_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_pkt.h>

#include <hal/hal_pkt_rsrc.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* Keep these values applied to different modules. */
#define HAL_LT_DAWN_PKT_IPP_EXCPT_LAST (256)
#define HAL_LT_DAWN_PKT_EPP_EXCPT_LAST (64)

#define HAL_LT_DAWN_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L2UC \
    (192 + LT_IEV_CFG_EXCPT_EN_W1_SDK_REDIRECT_TO_CPU_L2UC_FIELD_ID)
#define HAL_LT_DAWN_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L3UC \
    (192 + LT_IEV_CFG_EXCPT_EN_W1_SDK_REDIRECT_TO_CPU_L3UC_FIELD_ID)
#define HAL_LT_DAWN_PKT_IPP_EXCPT_IEV_SDK_L3UC_DA_MISS \
    (192 + LT_IEV_CFG_EXCPT_EN_W1_SDK_L3UC_DA_MISS_FIELD_ID)
#define HAL_LT_DAWN_PKT_IPP_EXCPT_IEV_SDK_L3MC_PIM_REGISTER \
    (192 + LT_IEV_CFG_EXCPT_EN_W1_SDK_L3MC_PIM_REGISTER_FIELD_ID)
#define HAL_LT_DAWN_PKT_IPP_EXCPT_IEV_SDK_FLEX_DECAP_0_REASON_0 \
    (224 + LT_IEV_CFG_EXCPT_EN_W0_SDK_FLEX_DECAP_0_REASON_0_FIELD_ID)

typedef UI32_T HAL_LT_DAWN_PKT_IPP_EXCPT_T;
typedef UI32_T HAL_LT_DAWN_PKT_EPP_EXCPT_T;

typedef enum {
    HAL_LT_DAWN_PKT_IPP_L3_EXCPT_FCOE_ZONING = 0,
    HAL_LT_DAWN_PKT_IPP_L3_EXCPT_RPF,
    HAL_LT_DAWN_PKT_IPP_L3_EXCPT_ICMP_REDIR,
    HAL_LT_DAWN_PKT_IPP_L3_EXCPT_SW_FWD,
    HAL_LT_DAWN_PKT_IPP_L3_EXCPT_MTU,
    HAL_LT_DAWN_PKT_IPP_L3_EXCPT_TTL,
    HAL_LT_DAWN_PKT_IPP_L3_EXCPT_LAST
} HAL_LT_DAWN_PKT_IPP_L3_EXCPT_T;

typedef enum {
    HAL_LT_DAWN_PKT_IPP_RSN_RSVD_0 = 0,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_MPLS_MP_LSP_INNER_IP_LCL,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_IP_MC_TNL_LCL_INTF_MISS,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_IP_MC_TNL_GRE_ISIS,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_IP_MC_TNL_GRE_KA,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_IP_MC_TNL_INNER_IP_LCL,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_TRILL_MC_LCL_INTF_MISS,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_INNER_SRV_1ST_MISS,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_INNER_SRV_2ND_MISS,
    HAL_LT_DAWN_PKT_IPP_RSN_IEV_IP_MC_TTL0,
    HAL_LT_DAWN_PKT_IPP_RSN_IEV_IP_MC_TTL1,
    HAL_LT_DAWN_PKT_IPP_RSN_RSVD_1,
    HAL_LT_DAWN_PKT_IPP_RSN_RSVD_2,
    HAL_LT_DAWN_PKT_IPP_RSN_IDS_ECN,
    HAL_LT_DAWN_PKT_IPP_RSN_IEV_ICMP_REDIR,
    HAL_LT_DAWN_PKT_IPP_RSN_IEV_ICMP_REDIR_WITH_RSN_IDS_ECN,
    HAL_LT_DAWN_PKT_IPP_RSN_LAST
} HAL_LT_DAWN_PKT_IPP_RSN_T;

typedef enum {
    /* IEV.cp_to_cpu_bmap |=
     * (1UL << sw_plane.iev_cp_to_cpu_bit_pos_{i})   |
     * (1UL << sw_plane.iev_sflw_cp_to_cpu_bidx_{i}) |
     * (1UL << (IEV_RSLT_CTL2CPU_PROF.code - 1))     |
     * (1UL << (ICIA_RSLT_TCAM_UCP_POLICY.cp_to_cpu_idx - 1));
     */
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_ICIA_0 = 0,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_ICIA_1,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_ICIA_2,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_ICIA_3,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_ICIA_4,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_ICIA_5,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_COPY_TO_CPU_L2UC,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_COPY_TO_CPU_L3UC,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_PORT_SFLOW,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_ICIA_SFLOW,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_FLOW_SFLOW,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_L3MC_SPT_READY_UNSET,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_COPY_TO_CPU_L2MC,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_COPY_TO_CPU_L3MC,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_USR_DEFINE_0,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_USR_DEFINE_1,
    HAL_LT_DAWN_PKT_IPP_COPY2CPU_LAST
} HAL_LT_DAWN_PKT_IPP_COPY2CPU_T;

typedef enum {
    /* The value of:
     * 1. emi_sflw_cp_to_cpu_idx_bidx_*
     * 2. ECIA.cp_to_cpu_idx (last is invalid)
     */
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_ECIA_0 = 0,
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_ECIA_1,
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_ECIA_2,
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_ECIA_3,
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_PORT_SFLOW,
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_ECIA_SFLOW,
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_RSVD_0,
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_RSVD_1,
    HAL_LT_DAWN_PKT_EPP_COPY2CPU_LAST
} HAL_LT_DAWN_PKT_EPP_COPY2CPU_T;

typedef enum {
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_RSVD_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VNTAG_UPS_DPL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VNTAG_DWS_D,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VNTAG_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_ETAG_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_ECID_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VM_RPF_CK,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_L2_LCL_INTF_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TAG_ERR,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_NVO3_L3_MTU,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_EL_LE_15,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_2ND_ELI,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_ELI_BOS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_TOP_GAL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_TOP_XL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_TOP_RSVD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_LBL_GT4,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_SRV_RSLT_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_NULL_UHP_BOS_L2_HDR_PRESENT,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_UHP_P2P_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_LSP_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_UHP_IP_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_MPLS_NULL_IPV4,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_MPLS_NULL_IPV6,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_HIT_GAL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_HIT_XL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_HIT_RSVD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_HIT_BOS0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_UHP_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_UHP_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_TRANSIT_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_TRANSIT_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_INNER_IP_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_PW_CW,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_PW_ACH,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_PW_UNK,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_DECAP_IP_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_P2P_LSP_INNER_IPV4_LCL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_MPLS_P2P_LSP_INNER_IPV6_LCL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_TYP_NOT_ALW,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV4_FRAG,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV4_IHL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV4_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV4_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV4_AH,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV6_FRAG,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV6_EXT,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV6_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV6_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_IPV6_AH,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_L2_LCL_INTF_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_TNL_INNER_IP_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_ERSPAN_TYP_2_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_ERSPAN_TYP_3_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_ERSPAN_TYP_3_FT,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_AUTO_TNL_DA,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_AUTO_TNL_SA,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_ETH_IP_HDR,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_DECAP_FLEX_UDP_CKSUM_IPV4,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_DECAP_FLEX_UDP_CKSUM_IPV6,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_GPE_UDP_CKSUM_IPV4,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_GPE_UDP_CKSUM_IPV6,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_GPE_IFLG,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_GPE_CTL_FLG_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_GPE_CTL_FLG_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_GPE_CTL_FLG_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_GPE_CTL_FLG_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_BAS_UDP_CKSUM_IPV4,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_BAS_UDP_CKSUM_IPV6,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_BAS_IFLG,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_BAS_CTL_FLG,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_VXLAN_BAS_RSVD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_HDR_RSVD_FLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_CTL_FLG_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_CTL_FLG_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_CTL_FLG_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_CTL_FLG_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_UC_TNL_INNER_IPV4_LCL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IP_UC_TNL_INNER_IPV6_LCL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_ISIS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_GRE_KA,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_ECN,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRILL_MC_MAC,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRILL_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRILL_OP_LEN_MAX,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRILL_TRANSIT_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRILL_TRANSIT_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRILL_DECAP_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRILL_DECAP_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRILL_OPT,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_NSH_LEN_LT_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRANSIT_NSH_SRV_IDX_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRANSIT_NSH_OAM,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRANSIT_NSH_CRI,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_TRANSIT_NSH_RSVD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_DECAP_NSH_OAM,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_DECAP_NSH_CRI,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_DECAP_NSH_RSVD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_DECAP_NSH_CL_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_DECAP_NSH_LEN_GT_6,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IPV4_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_UL_L2_VLAN_1ST_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_UL_L2_VLAN_UNEXP,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_NTO1_INNER_VLAN_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_INNER_SRV_1ST_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_INNER_SRV_2ND_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_RSLT_SRV_U_L2_INTF_IDX_FF,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_RSLT_SRV_U_L2_INTF_IDX_FE,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_L3_MTU,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IPV4_MC_L2_DA_MALFORMED,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IPV6_MC_L2_DA_MALFORMED,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_FCOE_VER_BAD,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_L3_TNL_INNER_IP_RTE_NOT_EN,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IPV4_CKSUM,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IPV4_IHL_LT_5,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IPV4_TLEN_LT_IHL,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IPV6_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_IPV6_HDR_TRUNCATED,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_RSVD_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_RSVD_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_RSVD_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_RSVD_4,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_SDK_DOS_CHK_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_SDK_DOS_CHK_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IDS_SDK_DOS_CHK_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_TRILL_UC_ADJ,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_MTU,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_NVO3_RSLT_ECMP_PATH_U_EP_L3_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_NVO3_ENCAP_IDX_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_NVO3_ENCAP_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_ECMP_PATH_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L2_UEID_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L2_ECMP_PATH_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_UEID_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L2_SA_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L2_SA_MOVE,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_STACKING_LOOP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L2_SRC_SUPP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L25_NSH_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSLT_BNK_TYP_L25_NSH,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSLT_BNK_TYP_L2_INDIR,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSLT_BNK_TYP_L3_INDIR,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSLT_BNK_TYP_FLW,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_FLW_ICIA_3X_INVLD_IDX,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_STM_CTL,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L2_TOPO_BLK,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_ARP_SRC_GUARD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV4_SRC_GUARD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV6_SRC_GUARD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_FCOE_SRC_GUARD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_TRILL_MC_ADJ,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_TRILL_MC_RPF,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSLT_BNK_TYP_L4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSLT_BNK_TYP_L2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSLT_BNK_TYP_L3,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L2_DA_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L2_SA_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L25_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L25_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_SW_FWD_IPV4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_SW_FWD_IPV6,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_FCOE_EXT_UNK,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_FCOE_DID_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_FCOE_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_FCOE_ZONING,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_FCOE_TTL,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_DA_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV4_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV4_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV6_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV6_TTL_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV4_ICMP_REDIR,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV6_ICMP_REDIR,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV4_MRPF,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV6_MRPF,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV4_MC_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV6_MC_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV4_MC_BRIDGED_CP_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV6_MC_BRIDGED_CP_TTL_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_SA_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV4_URPF,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_L3_IPV6_URPF,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_PBR_FLW_TYP,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_NSH_POP_LEN_GT_6,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_NSH_POP_CL_INVLD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_NSH_POP_INVLD_IP_VER,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_PBR_DROP_FCOE_CLS_2F,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_ECC,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_5,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_6,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_7,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_RSVD_8,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_5,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_6,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_7,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_8,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_9,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_10,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_11,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_12,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_USER_DEFINED_13,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_REDIRECT_TO_CPU_L2UC,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_REDIRECT_TO_CPU_L3UC,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_MIRROR_ERSPAN_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_1588_RX,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_VM_BFD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_VM_FDB_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_L3_BFD,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_L3UC_DA_MISS,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_L3MC_PIM_REGISTER,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_ICIA_REDIRECT_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_ICIA_REDIRECT_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_ICIA_REDIRECT_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_ICIA_REDIRECT_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_ICIA_REDIRECT_4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_ICIA_REDIRECT_5,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_ICIA_REDIRECT_6,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_ICIA_REDIRECT_7,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_0_REASON_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_0_REASON_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_0_REASON_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_0_REASON_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_0_REASON_4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_0_REASON_5,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_1_REASON_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_1_REASON_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_1_REASON_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_1_REASON_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_1_REASON_4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_1_REASON_5,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_2_REASON_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_2_REASON_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_2_REASON_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_2_REASON_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_2_REASON_4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_2_REASON_5,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_3_REASON_0,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_3_REASON_1,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_3_REASON_2,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_3_REASON_3,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_3_REASON_4,
    HAL_LT_DAWN_PKT_IPP_REASON_IEV_SDK_FLEX_DECAP_3_REASON_5,
    HAL_LT_DAWN_PKT_IPP_REASON_LAST = 512,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_0 = 512,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_HDR_INCR_LCL,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_DECAP_HDR_MISS,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_DECAP_ACT_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_DECAP_FLEX_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_MPLS_ELI_BOS,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_MPLS_ELI_EL_NON_IP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_MPLS_POP_BEYOND_BOS,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_MPLS_2ND_ELI,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_PHP_POP_EXPOSE_NON_IP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_MPLS_ENTROPY_BOS,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_MPLS_DECAP_EXPOSE_NON_IP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_TRILL_TRANSIT_ADJ_IDX_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_ADJ_RSLT_BNK_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_L3_ADJ_IDX_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_L2_HDR_MISS,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_L3_MTU,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_L3_IPV4_TTL_1,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_L3_IPV6_TTL_1,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_SRC_SUPP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_RSLT_BNK_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_L25_UC_TURN_MC,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_L2_TOPO_BLK,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_ECIA_DROP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_NSH_O_NSH,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_NSH_UNK_ETYP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_NSH_RSLT_BNK_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_NSH_O_TNL_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_NSH_NXT_PTR,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_IP_TNL_TYP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_MPLS_NXT_PTR,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_MPLS_O_UNK_IP_TNL,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_TRILL_ENCAP_FGL,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_TRILL_ENCAP_VL,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_NVO3_L3_MTU,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_PORT_ISO,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_TYP_ORDERS,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_BIDX_ASCEND,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_OOR,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_TOT,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_REWR_IDX_OVERLAP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_TOT_4X,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_CHG_BLST,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_INS_BLST,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_SRV_IDX_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_INS_DEL_OVERLAP,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_INS_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_FCM_TLV_DEL_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_L2_HDR_LCL,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_STEER_MIR_EGR,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_ERSPAN_NVO3_INVLD,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_1,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_2,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_3,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_4,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_5,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_6,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_7,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_8,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_9,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_10,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_11,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_12,
    HAL_LT_DAWN_PKT_EPP_REASON_EME_RSVD_13,
    HAL_LT_DAWN_PKT_EPP_REASON_LAST = 768
} HAL_LT_DAWN_PKT_PP_REASON_T;

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief To map the reason from hw ipp exception bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapIppExcptToUser(const UI32_T unit,
                                  const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                                  CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp exception value to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     code             - The hw reason code
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapIppExcptCodeToUser(const UI32_T unit,
                                      const UI32_T code,
                                      CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp l3 exception bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapIppL3ExcptToUser(const UI32_T unit,
                                    const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                                    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp copy2cpu bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapIppCopyToCpuToUser(const UI32_T unit,
                                      const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                                      CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp rsn bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapIppRsnToUser(const UI32_T unit,
                                const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                                CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp rsn code to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     code             - The hw reason code
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapIppRsnCodeToUser(const UI32_T unit,
                                    const UI32_T code,
                                    CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw epp exception bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapEppExcptToUser(const UI32_T unit,
                                  const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                                  CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw epp exception code to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     code             - The hw reason code
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapEppExcptCodeToUser(const UI32_T unit,
                                      const UI32_T code,
                                      CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw epp copy2cpu bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapEppCopyToCpuToUser(const UI32_T unit,
                                      const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                                      CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw ipp exception bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapUserToIppExcpt(const UI32_T unit,
                                  const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                                  HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw ipp l3 excpt bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapUserToIppL3Excpt(const UI32_T unit,
                                    const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                                    HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw ipp copy2cpu bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapUserToIppCopyToCpu(const UI32_T unit,
                                      const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                                      HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw ipp rsn bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapUserToIppRsn(const UI32_T unit,
                                const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                                HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw epp exception bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapUserToEppExcpt(const UI32_T unit,
                                  const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                                  HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw epp copy2cpu bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_mapUserToEppCopyToCpu(const UI32_T unit,
                                      const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                                      HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To translate the reason from user-view to chip-view.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_reason      - The user-view reason
 * @param [in]     hw_action        - The chip-view action
 * @param [out]    ptr_hw_reason    - Pointer to the chip-view reason
 * @return         CLX_E_OK        - Success to translate the reason.
 * @return         CLX_E_OTHERS    - Undefined user-view reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_transUserToHwReason(const UI32_T unit,
                                    const CLX_PKT_RX_REASON_T user_reason,
                                    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T hw_action,
                                    UI32_T *ptr_hw_reason);

/**
 * @brief To translate the reason from chip-view to user-view.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     hw_reason        - The chip-view reason
 * @param [in]     hw_action        - The chip-view action
 * @param [out]    ptr_user_reason  - Pointer to the user-view reason
 * @return         CLX_E_OK        - Success to translate the reason.
 * @return         CLX_E_OTHERS    - Undefined chip-view reason
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_transHwToUserReason(const UI32_T unit,
                                    const UI32_T hw_reason,
                                    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T hw_action,
                                    CLX_PKT_RX_REASON_T *ptr_user_reason);

/**
 * @brief To translate chip-view PP reasons to string.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     pp_reason        - The PP reason code.
 * @param [in]     str_len          - String length
 * @param [out]    str_pp_reason    - The PP reason code string.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER      - PP reason out of range.
 * @return         CLX_E_ENTRY_NOT_FOUND    - PP reason dose not match.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_getPpReason(const UI32_T unit,
                            const HAL_LT_DAWN_PKT_PP_REASON_T pp_reason,
                            const UI32_T str_len,
                            C8_T *str_pp_reason);

#endif /* End of HAL_VLAN_H */
