/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_dawn_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_LT_DAWN_STAT_H
#define HAL_LT_DAWN_STAT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stat.h>
#include <clx_tm.h>
#include <dcc/dcc_dma.h>
#include <hal/hal_cmn.h>
#include <hal/hal_cmn_drv.h>
#include <hal/hal_stat.h>
#include <hal/hal_sec.h>
#include <hal/light/dawn/hal_lt_dawn_cmn.h>

#define HAL_LT_DAWN_STAT_USE_CLD_DMA

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_LT_DAWN_STAT_SRV_CNT_IDX_OFFSET          (10)
#define HAL_LT_DAWN_STAT_SRV_CNT_NUM_PER_BANK        ((1U << HAL_LT_DAWN_STAT_SRV_CNT_IDX_OFFSET) * 6)
#define HAL_LT_DAWN_STAT_SRV_CNT_BANK_NUM            (16)
#define HAL_LT_DAWN_STAT_DST_CNT_NUM_PER_BANK        (256)
#define HAL_LT_DAWN_STAT_DST_CNT_BANK_NUM            (4)
#define HAL_LT_DAWN_STAT_MAC_NUM_PER_DIE             (32)
#define HAL_LT_DAWN_STAT_LANE_NUM_PER_MAC            (4)
#define HAL_LT_DAWN_STAT_ETHC_LANE_NUM               (256)
#define HAL_LT_DAWN_STAT_ETHX_LANE_NUM               (4)
#define HAL_LT_DAWN_STAT_TM_QUEUECNT_NUM_PER_PLANE   (600)
#define HAL_LT_DAWN_STAT_TM_CPU_QUEUE_NUM            (48)
#define HAL_LT_DAWN_STAT_TM_CPI_QUEUE_NUM            (8)
#define HAL_LT_DAWN_STAT_DEFAULT_POLLING_INTERVAL_MS (10)
#define HAL_LT_DAWN_STAT_MIN_POLLING_INTERVAL_MS     (5)
#define HAL_LT_DAWN_STAT_MAX_POLLING_INTERVAL_MS     (10)
#define HAL_LT_DAWN_STAT_MAX_SW_TOTAL_PORT_NUM       (128 + 2 + 1)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_LT_DAWN_STAT_DBG_SHOW_INDENT(__space_num__) \
    do {                                                \
        UI32_T(__temp__) = (__space_num__);             \
        while (0 != (__temp__)) {                       \
            osal_printf(" ");                           \
            (__temp__) -= 1;                            \
        }                                               \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_LT_DAWN_STAT_MIB_REG_RX_MCAST_PKT = 0,
    HAL_LT_DAWN_STAT_MIB_REG_RX_BCAST_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_NUCAST_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_SYMBOL_ERR_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_RS_ERR_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_STOMP_CRC_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_CRC_ERR_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_UNK_OPC_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_UNDERSIZE_GOOD_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_UNDERSIZE_BAD_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_UNDERSIZE_OCTET,
    HAL_LT_DAWN_STAT_MIB_REG_RX_PFC0_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_PFC1_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_PFC2_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_PFC3_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_PFC4_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_PFC5_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_PFC6_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_PFC7_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_DROP_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_RX_LENG_ERR_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_MCAST_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_BCAST_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_NUCAST_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_ERR_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_UNDERSIZE_GOOD_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_UNDERSIZE_BAD_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_UNDERSIZE_OCTET,
    HAL_LT_DAWN_STAT_MIB_REG_TX_PFC0_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_PFC1_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_PFC2_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_PFC3_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_PFC4_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_PFC5_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_PFC6_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_PFC7_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TX_DROP_PKT,
    HAL_LT_DAWN_STAT_MIB_REG_TYPE_LAST
} HAL_LT_DAWN_STAT_MIB_REG_TYPE_T;

typedef enum {
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_PAUSE_MC_PKT = 0,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_PAUSE_MC_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_PAUSE_UC_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_PAUSE_UC_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_PFC_MC_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_PFC_MC_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_64_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_64_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_65_127_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_65_127_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_128_255_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_128_255_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_256_511_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_256_511_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_512_1023_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_512_1023_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_1024_1518_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_1024_1518_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_1519_2560_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_1519_2560_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_2561_MAX_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_LENG_2561_MAX_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_OS_GOOD_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_OS_GOOD_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_OS_BAD_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_RX_OS_BAD_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_PAUSE_MC_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_PAUSE_MC_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_PFC_MC_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_PFC_MC_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_64_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_64_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_65_127_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_65_127_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_128_255_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_128_255_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_256_511_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_256_511_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_512_1023_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_512_1023_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_1024_1518_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_1024_1518_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_1519_2560_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_1519_2560_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_2561_MAX_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_LENG_2561_MAX_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_OS_GOOD_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_OS_GOOD_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_OS_BAD_PKT,
    HAL_LT_DAWN_STAT_MIB_SRAM_TX_OS_BAD_OCTET,
    HAL_LT_DAWN_STAT_MIB_SRAM_TYPE_LAST
} HAL_LT_DAWN_STAT_MIB_SRAM_TYPE_T;

typedef enum {
    HAL_LT_DAWN_STAT_TM_ENB_BUF_FULL_TRUNC = 0,
    HAL_LT_DAWN_STAT_TM_ENB_BUF_FULL_ENQED,
    HAL_LT_DAWN_STAT_TM_ENB_CT_PKT_CNT,
    HAL_LT_DAWN_STAT_TM_ENB_SF_PKT_CNT,
    HAL_LT_DAWN_STAT_TM_ENB_STR_PKT_CNT,
    HAL_LT_DAWN_STAT_TM_ENB_LEN_INVALID_PKT_CNT,
    HAL_LT_DAWN_STAT_TM_ENB_TOTAL_PKT_CNT,
    HAL_LT_DAWN_STAT_TM_ENB_TYPE_LAST
} HAL_LT_DAWN_STAT_TM_ENB_TYPE_T;

typedef enum {
    HAL_LT_DAWN_STAT_TM_XNB_SOP_EVENT_FROM_ITM = 0,
    HAL_LT_DAWN_STAT_TM_XNB_EOP_EVENT_FROM_ITM,
    HAL_LT_DAWN_STAT_TM_XNB_SOP_EVENT_FROM_INFO,
    HAL_LT_DAWN_STAT_TM_XNB_EOP_EVENT_FROM_INFO,
    HAL_LT_DAWN_STAT_TM_XNB_SOP_EVENT_TO_INFO,
    HAL_LT_DAWN_STAT_TM_XNB_EOP_EVENT_TO_INFO,
    HAL_LT_DAWN_STAT_TM_XNB_SOP_EVENT_TO_ENB_0,
    HAL_LT_DAWN_STAT_TM_XNB_EOP_EVENT_TO_ENB_0,
    HAL_LT_DAWN_STAT_TM_XNB_SOP_EVENT_TO_ENB_1,
    HAL_LT_DAWN_STAT_TM_XNB_EOP_EVENT_TO_ENB_1,
    HAL_LT_DAWN_STAT_TM_XNB_EVENT_TYPE_LAST
} HAL_LT_DAWN_STAT_TM_XBN_EVENT_TYPE_T;

typedef enum {
    HAL_LT_DAWN_STAT_TM_ADM_RX_PKT_OUT = 0,
    HAL_LT_DAWN_STAT_TM_ADM_RX_PKT_IN,
    HAL_LT_DAWN_STAT_TM_ADM_TYPE_LAST
} HAL_LT_DAWN_STAT_TM_ADM_TYPE_T;

typedef enum {
    HAL_LT_DAWN_STAT_TM_EA_P_DROP_CNT_Q0 = 0,
    HAL_LT_DAWN_STAT_TM_EA_P_DROP_CNT_Q1,
    HAL_LT_DAWN_STAT_TM_EA_P_DROP_CNT_Q2,
    HAL_LT_DAWN_STAT_TM_EA_P_DROP_CNT_Q3,
    HAL_LT_DAWN_STAT_TM_EA_P_DROP_CNT_Q4,
    HAL_LT_DAWN_STAT_TM_EA_P_DROP_CNT_Q5,
    HAL_LT_DAWN_STAT_TM_EA_P_DROP_CNT_Q6,
    HAL_LT_DAWN_STAT_TM_EA_P_DROP_CNT_Q7,
    HAL_LT_DAWN_STAT_TM_EA_P_TYPE_LAST
} HAL_LT_DAWN_STAT_TM_EA_P_TYPE_T;

typedef enum {
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_Q0 = 0,
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_Q1,
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_Q2,
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_Q3,
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_Q4,
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_Q5,
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_Q6,
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_Q7,
    HAL_LT_DAWN_STAT_TM_EA_G_DROP_CNT_STR,
    HAL_LT_DAWN_STAT_TM_EA_G_TYPE_LAST
} HAL_LT_DAWN_STAT_TM_EA_G_TYPE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init stat module control blocks.
 *
 * @param [in]     unit    - device unit number
 * @return         CLX_E_OK               - init success.
 * @return         CLX_E_NO_MEMORY        - allocate control block failed
 * @return         CLX_E_OTHERS           - init fail
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_init(const UI32_T unit);

/**
 * @brief Deinit stat module control blocks and free resource.
 *
 * @param [in]     unit    - device unit number
 * @return         CLX_E_OK               - deinit success
 * @return         CLX_E_OTHERS           - deInit fail
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_deinit(const UI32_T unit);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @param [out]    ptr_cnt    - Counter value
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getTmCnt(const UI32_T unit,
                          const UI32_T port,
                          const CLX_TM_HANDLER_T handler,
                          const CLX_STAT_TM_CNT_TYPE_T type,
                          CLX_STAT_TM_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearTmCnt(const UI32_T unit,
                            const UI32_T port,
                            const CLX_TM_HANDLER_T handler,
                            const CLX_STAT_TM_CNT_TYPE_T type);

/**
 * @brief This API is used to get a distribution counter.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - Counter
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getDistCnt(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_DIST_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear a distribution counter.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearDistCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get PP counter SW ID using HW index
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     hw_cnt_idx       - HW counter idx in HW table
 * @param [in]     cnt_type         - counter type
 * @param [out]    ptr_sw_cnt_id    - HW counter id
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getCntSWId(const UI32_T unit,
                            const UI32_T hw_cnt_idx,
                            const HAL_STAT_HW_TYPE_T cnt_type,
                            UI32_T *ptr_sw_cnt_id);

/**
 * @brief This API is used to get port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @param [out]    ptr_cnt     - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getMibSram(const UI32_T unit,
                            const UI32_T port,
                            const HAL_STAT_HW_TYPE_T hw_type,
                            const HAL_LT_DAWN_STAT_MIB_SRAM_TYPE_T cnt_type,
                            UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearMibSram(const UI32_T unit,
                              const UI32_T port,
                              const HAL_STAT_HW_TYPE_T hw_type,
                              const HAL_LT_DAWN_STAT_MIB_SRAM_TYPE_T cnt_type);

/**
 * @brief This API is used to get port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @param [out]    ptr_cnt     - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getMibReg(const UI32_T unit,
                           const UI32_T port,
                           const HAL_STAT_HW_TYPE_T hw_type,
                           const HAL_LT_DAWN_STAT_MIB_REG_TYPE_T cnt_type,
                           UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearMibReg(const UI32_T unit,
                             const UI32_T port,
                             const HAL_STAT_HW_TYPE_T hw_type,
                             const HAL_LT_DAWN_STAT_MIB_REG_TYPE_T cnt_type);

/**
 * @brief This API is used to get port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @param [out]    ptr_cnt     - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getMibRaw(const UI32_T unit,
                           const UI32_T port,
                           const HAL_STAT_HW_TYPE_T hw_type,
                           const HAL_LT_DAWN_STAT_MIB_SRAM_TYPE_T cnt_type,
                           UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearMibRaw(const UI32_T unit,
                             const UI32_T port,
                             const HAL_STAT_HW_TYPE_T hw_type,
                             const HAL_LT_DAWN_STAT_MIB_SRAM_TYPE_T cnt_type);

/**
 * @brief This API is used to get TM raw counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     inst_idx     - Instance index
 * @param [in]     sub_idx      - Sub-instance index
 * @param [in]     type         - TM counter type
 * @param [in]     entry_idx    - Entry index
 * @param [in]     field_id     - Counter index of the corresponding field
 * @param [out]    ptr_cnt      - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getTmRaw(const UI32_T unit,
                          const UI32_T inst_idx,
                          const UI32_T sub_idx,
                          const HAL_STAT_HW_TYPE_T type,
                          const UI32_T entry_idx,
                          const UI32_T field_id,
                          UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     inst_idx     - Instance index
 * @param [in]     sub_idx      - Sub-instance index
 * @param [in]     type         - TM counter type
 * @param [in]     entry_idx    - Entry index
 * @param [in]     field_id     - Counter index of the corresponding field
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearTmRaw(const UI32_T unit,
                            const UI32_T inst_idx,
                            const UI32_T sub_idx,
                            const HAL_STAT_HW_TYPE_T type,
                            const UI32_T entry_idx,
                            const UI32_T field_id);

/**
 * @brief This API is used to get how many times the counter has been updated
 *
 * @param [in]     unit       - Device unit number
 * @param [out]    ptr_cnt    - Update count
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getUpdateCnt(const UI32_T unit, UI64_T *ptr_cnt);

/**
 * @brief This API is used to get PP exception counter by exception code
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     excpt_id    - The exception code
 * @param [out]    ptr_cnt     - Pointer to counter value
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getExcptCnt(const UI32_T unit,
                             const HAL_LT_DAWN_CMN_EXCPT_T excpt_id,
                             UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear PP exception counter by exception code
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     excpt_id    - The exception code
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearExcptCnt(const UI32_T unit, const HAL_LT_DAWN_CMN_EXCPT_T excpt_id);

/**
 * @brief This API is used to get PP storm control counter by index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     plane      - Plane number
 * @param [in]     cnt_idx    - The strom control counter index
 * @param [out]    ptr_cnt    - Pointer to corresponding counter entry (3 values)
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getStormCnt(const UI32_T unit,
                             const UI32_T plane,
                             const UI32_T cnt_idx,
                             HAL_SEC_SCCOUNTER_ENTRY_T *ptr_cnt);

/**
 * @brief This API is used to clear PP storm control counter by index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     plane      - Plane number
 * @param [in]     cnt_idx    - The strom control counter index
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearStormCnt(const UI32_T unit, const UI32_T plane, const UI32_T cnt_idx);

/**
 * @brief This API is used to show debug counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - CLX port number
 * @param [in]     stage_bmp    - The bitmap of stage:
 *                                bit0: mac; bit1: ipm; bit2: ios: bit3: ipp; bit4: xbn; bit5: tm;
 *                                bit6: epp; bit7: epm; bit8: lbm
 * @param [in]     flags        - Show the counter or not if it is zero
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_showDbgCnt(const UI32_T unit,
                            const UI32_T port,
                            const UI32_T stage_bmp,
                            const UI32_T flags);

/**
 * @brief This API is used to clear all debug counter
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearDbgCnt(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_dawn_stat_getAiqWatermark(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_TM_HANDLER_T handler,
                                 CLX_TM_BUF_WATERMARK_T *ptr_cnt);

CLX_ERROR_NO_T
hal_lt_dawn_stat_clearAiqWatermark(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_TM_HANDLER_T handler);

CLX_ERROR_NO_T
hal_lt_dawn_stat_clearAoqWatermark(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_TM_HANDLER_T handler);

CLX_ERROR_NO_T
hal_lt_dawn_stat_getAoqWatermark(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_TM_HANDLER_T handler,
                                 CLX_TM_BUF_WATERMARK_T *ptr_cnt);

/**
 * @brief This API is used to get PP counter HW index using SW index
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     sw_cnt_id         - SW counter id
 * @param [in]     cnt_type          - counter type
 * @param [in]     pp_obj_type       - PP binding object type
 * @param [out]    ptr_hw_cnt_idx    - HW counter idx
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_TABLE_FULL         - No available HW resource
 * @return         CLX_E_ENTRY_NOT_FOUND    - The SW counter has not been created.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getCntHWIdx(const UI32_T unit,
                             const UI32_T sw_cnt_id,
                             const HAL_STAT_HW_TYPE_T cnt_type,
                             const HAL_STAT_PP_OBJ_TYPE_T pp_obj_type,
                             UI32_T *ptr_hw_cnt_idx);

/**
 * @brief To get a PP HW counter bank Id and corresponding index Id
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     hw_cnt_id                  - HW counter Id
 * @param [in]     mode                       - Counter mode
 * @param [out]    ptr_bank_id                - The HW bank Id of the corresponding counter
 * @param [out]    ptr_sw_bmap_idx_of_bank    - The index the corresponding counter in the bank
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getPpBankId(const UI32_T unit,
                             const UI32_T hw_cnt_id,
                             const CLX_STAT_CNT_MODE_T mode,
                             UI32_T *ptr_bank_id,
                             UI32_T *ptr_sw_bmap_idx_of_bank);

/**
 * @brief This API is used to get value of the counter under study
 *
 * The number of counters value return is determined by the type of counter under study.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - The return counter values
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getCnt(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_clearCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get TM queue counter index by TM handler.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     handler    - The handler of TM queue
 * @param [out]    ptr_idx    - Queue counter index
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_stat_getTmQueueCntIdx(const UI32_T unit,
                                  const CLX_TM_HANDLER_T handler,
                                  UI32_T *ptr_idx);
#endif /* End of HAL_LT_DAWN_STAT_H */
