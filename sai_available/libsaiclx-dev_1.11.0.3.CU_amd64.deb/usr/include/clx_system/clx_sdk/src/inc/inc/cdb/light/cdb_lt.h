/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME: cdb_lt.h
 * PURPOSE:
 *     Chip database (CDB) driver
 * NOTES:
 */

#ifndef CDB_LT_H
#define CDB_LT_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* special inst_idx for broadcast */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
_cdb_dawn_writeEntry(const UI32_T unit,
                     const UI32_T inst_idx,
                     const UI32_T subinst_idx,
                     const UI32_T table_id,
                     const UI32_T entry_idx,
                     const UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_dawn_readEntry(const UI32_T unit,
                    const UI32_T inst_idx,
                    const UI32_T subinst_idx,
                    const UI32_T table_id,
                    const UI32_T entry_idx,
                    UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_dawn_modifyField(const UI32_T unit,
                      const UI32_T inst_idx,
                      const UI32_T subinst_idx,
                      const UI32_T table_id,
                      const UI32_T entry_idx,
                      const UI32_T field_id,
                      const UI32_T *ptr_field);

CLX_ERROR_NO_T
_cdb_dawn_modifyUi32Field(const UI32_T unit,
                          const UI32_T inst_idx,
                          const UI32_T subinst_idx,
                          const UI32_T table_id,
                          const UI32_T entry_idx,
                          const UI32_T field_id,
                          const UI32_T field);

CLX_ERROR_NO_T
_cdb_dawn_modifyMultiFields(const UI32_T unit,
                            const UI32_T inst_idx,
                            const UI32_T subinst_idx,
                            const UI32_T table_id,
                            const UI32_T entry_idx,
                            const UI32_T fvp_count,
                            const CDB_FVP_T *ptr_fvp);

CLX_ERROR_NO_T
_cdb_dawn_readUi32Field(const UI32_T unit,
                        const UI32_T inst_idx,
                        const UI32_T subinst_idx,
                        const UI32_T table_id,
                        const UI32_T entry_idx,
                        const UI32_T field_id,
                        UI32_T *ptr_field);

CLX_ERROR_NO_T
_cdb_lightning_writeEntry(const UI32_T unit,
                          const UI32_T inst_idx,
                          const UI32_T subinst_idx,
                          const UI32_T table_id,
                          const UI32_T entry_idx,
                          const UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_lightning_readEntry(const UI32_T unit,
                         const UI32_T inst_idx,
                         const UI32_T subinst_idx,
                         const UI32_T table_id,
                         const UI32_T entry_idx,
                         UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_lightning_modifyField(const UI32_T unit,
                           const UI32_T inst_idx,
                           const UI32_T subinst_idx,
                           const UI32_T table_id,
                           const UI32_T entry_idx,
                           const UI32_T field_id,
                           const UI32_T *ptr_field);

CLX_ERROR_NO_T
_cdb_lightning_modifyUi32Field(const UI32_T unit,
                               const UI32_T inst_idx,
                               const UI32_T subinst_idx,
                               const UI32_T table_id,
                               const UI32_T entry_idx,
                               const UI32_T field_id,
                               const UI32_T field);

CLX_ERROR_NO_T
_cdb_lightning_modifyMultiFields(const UI32_T unit,
                                 const UI32_T inst_idx,
                                 const UI32_T subinst_idx,
                                 const UI32_T table_id,
                                 const UI32_T entry_idx,
                                 const UI32_T fvp_count,
                                 const CDB_FVP_T *ptr_fvp);

CLX_ERROR_NO_T
_cdb_lightning_readUi32Field(const UI32_T unit,
                             const UI32_T inst_idx,
                             const UI32_T subinst_idx,
                             const UI32_T table_id,
                             const UI32_T entry_idx,
                             const UI32_T field_id,
                             UI32_T *ptr_field);

CLX_ERROR_NO_T
_cdb_lt_index_logic2phy(const UI32_T unit,
                        const CDB_MEM_SERVICE_T *mem_service,
                        const UI32_T table_id,
                        const UI32_T entry_idx,
                        UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_lt_index_phy2logic(const UI32_T unit,
                        const CDB_MEM_SERVICE_T *mem_service,
                        const UI32_T table_id,
                        const UI32_T entry_idx,
                        UI32_T *ptr_entry_idx);

BOOL_T
_cdb_lt_index_isValid(const UI32_T unit, const UI32_T tbl_id, const UI32_T entry_idx);

CLX_ERROR_NO_T
_cdb_lt_addHashEntry(const UI32_T unit,
                     const UI32_T inst_idx,
                     const UI32_T subinst_idx,
                     const UI32_T bank_bmp,
                     const UI32_T table_id,
                     const UI32_T flag,
                     const UI32_T *ptr_entry,
                     UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_lt_updateHashEntry(const UI32_T unit,
                        const UI32_T inst_idx,
                        const UI32_T subinst_idx,
                        const UI32_T bank_bmp,
                        const UI32_T table_id,
                        const UI32_T flag,
                        const UI32_T *ptr_entry,
                        UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_lt_lookupHashEntry(const UI32_T unit,
                        const UI32_T inst_idx,
                        const UI32_T subinst_idx,
                        const UI32_T bank_bmp,
                        const UI32_T table_id,
                        UI32_T *ptr_entry,
                        UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_lt_delHashEntry(const UI32_T unit,
                     const UI32_T inst_idx,
                     const UI32_T subinst_idx,
                     const UI32_T bank_bmp,
                     const UI32_T table_id,
                     const UI32_T *ptr_entry,
                     UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_dawn_dma_writeEntry(const UI32_T unit,
                         const UI32_T inst_idx,
                         const UI32_T subinst_idx,
                         const UI32_T bank_bmp,
                         const UI32_T table_id,
                         const UI32_T entry_idx,
                         const UI32_T entry_num,
                         UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_dawn_dma_readEntry(const UI32_T unit,
                        const UI32_T inst_idx,
                        const UI32_T subinst_idx,
                        const UI32_T bank_bmp,
                        const UI32_T table_id,
                        const UI32_T entry_idx,
                        const UI32_T entry_num,
                        UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_dawn_dma_copyTbl(const UI32_T unit,
                      const UI32_T inst_idx,
                      const UI32_T subinst_idx,
                      const UI32_T table_id,
                      const UI32_T src_entry_idx,
                      const UI32_T dst_entry_idx,
                      const UI32_T entry_num);

CLX_ERROR_NO_T
_cdb_lt_dma_writeEntry(const UI32_T unit,
                       const UI32_T inst_idx,
                       const UI32_T subinst_idx,
                       const UI32_T bank_bmp,
                       const UI32_T table_id,
                       const UI32_T entry_idx,
                       const UI32_T entry_num,
                       UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_lt_dma_readEntry(const UI32_T unit,
                      const UI32_T inst_idx,
                      const UI32_T subinst_idx,
                      const UI32_T bank_bmp,
                      const UI32_T table_id,
                      const UI32_T entry_idx,
                      const UI32_T entry_num,
                      UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_lt_dma_copyTbl(const UI32_T unit,
                    const UI32_T inst_idx,
                    const UI32_T subinst_idx,
                    const UI32_T table_id,
                    const UI32_T src_entry_idx,
                    const UI32_T dst_entry_idx,
                    const UI32_T entry_num);

CLX_ERROR_NO_T
_cdb_lt_resetTable(const UI32_T unit,
                   const UI32_T inst_idx,
                   const UI32_T subinst_idx,
                   const UI32_T table_id,
                   const UI32_T *ptr_entry);
/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif /* End of CDB_H */
