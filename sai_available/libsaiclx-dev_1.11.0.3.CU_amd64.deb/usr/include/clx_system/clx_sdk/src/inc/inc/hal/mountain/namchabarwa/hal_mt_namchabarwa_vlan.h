/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_vlan.h
 * PURPOSE:
 *  Define the declartion for VLAN module for CL8600.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_VLAN_H
#define HAL_MT_NAMCHABARWA_VLAN_H

#include <clx_types.h>
#include <clx_error.h>
#include <clx_swc.h>
#include <clx_vlan.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum {
    HAL_MT_NAMCHABARWA_PVLAN_PORT_TYPE_NORMAL,
    HAL_MT_NAMCHABARWA_PVLAN_PORT_TYPE_PROMISCUOUS,
    HAL_MT_NAMCHABARWA_PVLAN_PORT_TYPE_ISOLATED,
    HAL_MT_NAMCHABARWA_PVLAN_PORT_TYPE_COMMUNITY,
    HAL_MT_NAMCHABARWA_PVLAN_PORT_LAST
} HAL_MT_NAMCHABARWA_PVLAN_PORT_TYPE_T;

typedef enum {
    HAL_MT_NAMCHABARWA_HW_VLAN_TAG_MODE_1Q,
    HAL_MT_NAMCHABARWA_HW_VLAN_TAG_MODE_1AD,
    HAL_MT_NAMCHABARWA_HW_VLAN_TAG_MODE_24B,
    HAL_MT_NAMCHABARWA_HW_VLAN_TAG_MODE_SEG,
} HAL_MT_NAMCHABARWA_HW_VLAN_TAG_MODE_T;

/* DATA TYPE DECLARATIONS
 */

/* MACRO API DECLARATIONS
 */

/**
 * @brief Create a bridge domain.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - The Bridge domain id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         others                 - Operate failed
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_createBridgeDomain(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief Destory a forwarding domain entry.
 *
 * Will disable fdid only.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - L2 bridge domain id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         others                 - Operate failed
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_destroyBridgeDomain(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief Set bridge domain property.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     bdid               - Bridge domain ID
 * @param [in]     ptr_bd_property    - Bridge domain property
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         others                 - Operate failed
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_setBdProperty(const UI32_T unit,
                                      const CLX_BRIDGE_DOMAIN_T bdid,
                                      const CLX_BD_PROPERTY_T *ptr_bd_property);

/**
 * @brief Get bridge domain property.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     bdid               - Bridge domain ID.
 * @param [out]    ptr_bd_property    - Bridge domain property
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_getBdProperty(const UI32_T unit,
                                      const CLX_BRIDGE_DOMAIN_T bdid,
                                      CLX_BD_PROPERTY_T *ptr_bd_property);

/**
 * @brief Create vlan entry.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vid     - VLAN ID
 * @return         CLX_E_OK              - Operate success.
 * @return         CLX_E_ENTRY_EXISTS    - Duplicated create.
 * @return         CLX_E_OTHER           - Operate fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_createVlan(const UI32_T unit, const UI32_T vid);

/**
 * @brief Destory vlan entry
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vid     - VLAN ID
 * @return         CLX_E_OK              - Operate success
 * @return         CLX_E_ENTRY_EXISTS    - Duplicated create
 * @return         CLX_E_OTHER           - Operate fail
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_delVlan(const UI32_T unit, const UI32_T vid);

/**
 * @brief Set member and untag port list of a vlan.
 *
 * @param [in]     unit    - Device unit number
 *                           ptr_entry
 *                           1) vlan           --  802.1Q VLAN associated with the entry.
 *                           The 802.1Q VLAN id range is 1-4094.
 *                           2) port_bitmap    --  Port bitmap indicate what port join VLAN member.
 *                           3) ut_port_bitmap --  Untagged port bitmap indicated what port not
 * tagging VLAN.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_setPort(const UI32_T unit, const CLX_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Get member and untag port list of a vlan.
 *
 * @param [in]     unit    - Device unit number
 *                           ptr_entry
 *                           1. vlan           --  802.1Q VLAN associated with the entry.
 *                           The 802.1Q VLAN id range is 1-4094.
 *                           ptr_entry
 *                           2. port_bitmap    --  Port bitmap indicate what port join VLAN member.
 *                           3. ut_port_bitmap --  Untagged port bitmap indicated what port not
 * tagging VLAN.
 * @return         CLX_E_OK                 - Operation is success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry in VLAN table.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_getPort(const UI32_T unit, CLX_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Traverse vlan tagged/untagged member port for active vlan.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function to be called for each traversed vlan entry
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 *                                        NOTES
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_traverseEntry(const UI32_T unit,
                                      const CLX_VLAN_ENTRY_TRAVERSE_FUNC_T callback,
                                      void *ptr_cookie);

/**
 * @brief Set vlan-based service l2.
 *
 * Should create VLAN and bridge domain first.
 * Unset bd property must before unbind bd
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     vid        - VLAN id.
 * @param [in]     ptr_srv    - Service control.
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_setService(const UI32_T unit,
                                   const CLX_VLAN_T vid,
                                   const CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Get vlan-based service l2.
 *
 * Should create VLAN and bridge domain first.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     vid        - VLAN id.
 * @param [in]     ptr_srv    - Service control.
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_getService(const UI32_T unit,
                                   const CLX_VLAN_T vid,
                                   CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Set VLAN filter.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Logic port ID
 * @param [in]     dir       - Filter direction
 * @param [in]     enable    - Enable/Disable filter
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_setVlanFilter(const UI32_T unit,
                                      const UI32_T port,
                                      const CLX_DIR_T dir,
                                      const UI32_T enable);

/**
 * @brief Get VLAN filter.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Logic port ID
 * @param [in]     dir       - Filter direction
 * @param [out]    enable    - Enable/Disable filter
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_getVlanFilter(const UI32_T unit,
                                      const UI32_T port,
                                      const CLX_DIR_T dir,
                                      UI32_T *enable);

/**
 * @brief Apply default vlan related properties for the new created port:
 *        (1) Join default vlan as untagged member port
 *        (2) Join default vlan flooding member
 *
 * (1) CLX/Hw design support modify member port of an un-active VLAN.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port number
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Operate fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_setPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief Reset default vlan related properties for the deleted port:
 *        (1) Remove from default vlan member port
 *        (2) Remove from default vlan flooding member
 *
 * (1) CLX/Hw design support modify member port of an un-active VLAN.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port number
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Operate fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_resetPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief Init vlan module.
 *
 * 1) Create default vlan and add all port as untagged member.
 * 2) Create default bridge domain and bind default vlan to that.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK                - Operate success.
 * @return         CLX_E_ALREADY_INITED    - Unexpected init.
 * @return         CLX_E_OTHER             - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_init(const UI32_T unit);

/**
 * @brief Deinit vlan module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK            - Operate success.
 * @return         CLX_E_NOT_INITED    - Unexpected deinit.
 * @return         CLX_E_OTHER         - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_deinit(const UI32_T unit);

/**
 * @brief Print created bridge domain ID.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_printCreatedBdId(const UI32_T unit);

/**
 * @brief add pvlan entry for a primary vlan.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     primary_vlan       - 802.1Q VLAN associated with the entry
 *                                      The 802.1Q VLAN id range is 1-4094
 * @param [in]     ptr_pvlan_entry    - The pvlan entry will be set
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_TABLE_FULL       - Table full
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_addPvlanEntry(const UI32_T unit,
                                      const UI32_T primary_vlan,
                                      const CLX_VLAN_PVLAN_ENTRY_T *ptr_pvlan_entry);

/**
 * @brief delete pvlan entry for a primary vlan.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     primary_vlan    - 802.1Q VLAN associated with the entry.
 *                                   The 802.1Q VLAN id range is 1-4094.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_delPvlanEntry(const UI32_T unit, const UI32_T primary_vlan);

/**
 * @brief Get pvlan entry for a primary vlan.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     primary_vlan       - 802.1Q VLAN associated with the entry.
 *                                      The 802.1Q VLAN id range is 1-4094.
 * @param [out]    ptr_pvlan_entry    - The pvlan entry will be set.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_getPvlanEntry(const UI32_T unit,
                                      const UI32_T primary_vlan,
                                      CLX_VLAN_PVLAN_ENTRY_T *ptr_pvlan_entry);

/**
 * @brief Get capacity of vlan-related hw resource type
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Vlan-related hw resource type
 * @param [in]     param       - Optional parameter
 * @param [out]    ptr_size    - Capacity size
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_getCapacity(const UI32_T unit,
                                    const CLX_SWC_RSRC_T type,
                                    const UI32_T param,
                                    UI32_T *ptr_size);

/**
 * @brief Get used of vlan-related hw resource type
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - Vlan-related hw resource type
 * @param [in]     param      - Optional parameter
 * @param [out]    ptr_cnt    - Count of usage
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_getUsage(const UI32_T unit,
                                 const CLX_SWC_RSRC_T type,
                                 const UI32_T param,
                                 UI32_T *ptr_cnt);

/**
 * @brief Diag print dis_hsh_bdi entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - lcl intferface
 * @param [in]     s_vlan      - Service vlan
 * @param [in]     c_vlan      - Customer vlan
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_printDisHshBdiEntry(const UI32_T unit,
                                          const UI32_T lcl_intf,
                                          const CLX_VLAN_T s_vlan,
                                          const CLX_VLAN_T c_vlan);

/**
 * @brief Diag print rwi_hsh_vlan entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - lcl intferface
 * @param [in]     bdid        - Bridge domain index
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_printRwiHshVlanEntry(const UI32_T unit,
                                           const UI32_T lcl_intf,
                                           const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief This function is to get VLAN chip configurable information.
 *
 * @param [in]     unit     - Device unit number, get chip configuration is required, but get global
 * configuration is not required
 * @param [in]     type     - Type for get chip configurable information
 * @param [in]     para0    - Parameter0 if necessary
 * @param [in]     para1    - Parameter1 if necessary
 *                            ptr_value
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         other                - Operate fail
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_vlan_getChipCfgInfo(const UI32_T unit,
                                       const CLX_SWC_CHIP_CFG_INFO_TYPE_T type,
                                       const UI32_T para0,
                                       const UI32_T para1,
                                       UI32_T *ptr_value);

#endif
