/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  ifmap_clx_sec.h
 * PURPOSE:
 *      Define the declartion for Security module in CLX SDK.
 *
 * NOTES:
 *
 */

#ifndef IFMAP_CLX_SEC_H
#define IFMAP_CLX_SEC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/**
 * @brief set port DoS configuration. (add profile or record reference counter)
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     user_port    - User port ID.
 * @param [in]     ptr_entry    - DoS per port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_setDosPortConfig(const UI32_T unit,
                               const UI32_T user_port,
                               const CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry);

/**
 * @brief get port DoS configuration. (get the port DoS profile id, and get dos profile entry)
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     user_port    - User port ID.
 * @param [out]    ptr_entry    - DoS per port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getDosPortConfig(const UI32_T unit,
                               const UI32_T user_port,
                               CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry);

/**
 * @brief This API is used to set storm control properties.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - User Port ID
 * @param [in]     ptr_entry    - The storm control properties for the specified port
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_setStormCtrlProperty(const UI32_T unit,
                                   const UI32_T user_port,
                                   const CLX_SEC_STORM_CTRL_T *ptr_entry);

/**
 * @brief This API is used to get storm control properties.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - User Port ID
 * @param [out]    ptr_entry    - The storm control properties for the specified port
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getStormCtrlProperty(const UI32_T unit,
                                   const UI32_T user_port,
                                   CLX_SEC_STORM_CTRL_T *ptr_entry);

/**
 * @brief This API is used to get storm control counter information.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - User Port ID
 * @param [in]     type         - The storm control traffic type
 * @param [out]    ptr_cnt      - The storm control counter information for the specified traffic
 * type which will be provided by the specified port.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getStormCtrlCnt(const UI32_T unit,
                              const UI32_T user_port,
                              const CLX_SEC_STORM_CTRL_TYPE_T type,
                              CLX_SEC_STORM_CTRL_CNT_T *ptr_cnt);

/**
 * @brief This API is used to set source guard properties.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - User Port ID
 * @param [in]     ptr_entry    - The source guard properties for the specified port
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_setSourceGuardProperty(const UI32_T unit,
                                     const CLX_PORT_T user_port,
                                     const CLX_SEC_SG_PROPERTY_T *ptr_entry);

/**
 * @brief This API is used to get source guard properties.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - User Port ID
 * @param [out]    ptr_entry    - The source guard properties for the specified port
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getSourceGuardProperty(const UI32_T unit,
                                     const CLX_PORT_T user_port,
                                     CLX_SEC_SG_PROPERTY_T *ptr_entry);

/**
 * @brief This API is used to add a source guard entry or set an existing source guard entry.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_user_entry    - The source guard entry which will be added or set. It should at
 * least be filled with the keys.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_TABLE_FULL       - Table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_addSourceGuardEntry(const UI32_T unit, const CLX_SEC_SG_ENTRY_T *ptr_user_entry);

/**
 * @brief This API is used to delete a source guard entry.
 *
 * Once the input source guard entry keys matches an existing source guard entry keys,
 * no matter the source guard entry contents are matched or not, the entry will be deleted.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_user_entry    - The source guard entry which will be deleted. It should at least
 * be filled with the keys.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory for this operation.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The entry doesn't exist.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_delSourceGuardEntry(const UI32_T unit, const CLX_SEC_SG_ENTRY_T *ptr_user_entry);

/**
 * @brief This API is used to get a source guard entry.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_user_entry    - The source guard entry which will be provided. It should be filled
 * with the keys, which are used to get the source guard entry.
 * @param [out]    ptr_user_entry    - The source guard entry which will be provided. It includes keys
 * and checked contents.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getSourceGuardEntry(const UI32_T unit, CLX_SEC_SG_ENTRY_T *ptr_user_entry);

/**
 * @brief This API is used to set egress ports of an ingress port.
 *
 * For a given ingress port, the packet is allowed to be sent to the egress port only if the
 * corresponding bit of the port is set in the port bitmap.  If user wants to add an egress port
 * to the given ingress port, set the corresponding bit to 1 in the port_bitmap.  If user wants
 * to delete an egress port from the given ingress port, set the corresponding bit to 0 in the
 * port_bitmap.
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     user_port           - Ingress user port ID
 * @param [in]     user_port_bitmap    - Egress user port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_setEgressPort(const UI32_T unit,
                            const UI32_T user_port,
                            const CLX_PORT_BITMAP_T user_port_bitmap);

/**
 * @brief This API is used to get egress ports of an ingress port.
 *
 * For a given ingress port, the packet is allowed to be sent to the egress port only
 * if the corresponding bit of the port is set to 1 in the port bitmap.
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     user_port           - Ingress user port ID
 * @param [out]    user_port_bitmap    - Egress user port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
ifmap_clx_sec_getEgressPort(const UI32_T unit,
                            const UI32_T user_port,
                            CLX_PORT_BITMAP_T user_port_bitmap);

#endif /* CLX_SEC_H */
