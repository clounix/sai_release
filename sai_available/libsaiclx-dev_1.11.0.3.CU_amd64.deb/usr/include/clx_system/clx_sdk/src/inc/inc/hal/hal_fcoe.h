/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_fcoe.h
 * PURPOSE:
 *      It provide FCoE module api.
 * NOTES:
 *
 *
 */

#ifndef HAL_FCOE_H
#define HAL_FCOE_H

/* INCLUDE FILE DECLARATIONS
 */

#include <hal/hal_tbl.h>

/* MACRO  DECLARATIONS
 */

#define HAL_FCOE_INTF_MAX_INTF_ID(unit)                                     \
    (HAL_TBL_INFO(unit, LT_TBL_IDS_RSLT_SRV_L3_INTF_ID)->entry_max_number - \
     2)               /* 0 based ID, {all 1} is invalid -- HW define */
#define HAL_FCOE_VRF_MAX_VRF_ID(unit) \
    ((1UL << 13) - 2) /* 0 based ID, {all 1} is invalid -- HW define */

#define HAL_FCOE_HASH_ZONING_BANK_BMP(unit) HAL_HASH_TYPE_SECURITY_BMP(unit)
#define HAL_FCOE_HASH_HOST_BANK_BMP(unit)   HAL_HASH_TYPE_L3_NO_PREFIX_BMP(unit)

#define HAL_FCOE_FRR_INVALID_GRP_ID (0xFFFF)
#define HAL_FCOE_RSVD_FDID          (HAL_L2_IDS_RSLT_SRV_FDID_ENTRY_ID_MIN_SDN)

#define HAL_FCOE_ECMP_GRP_ID_TO_DI(ecmp_grp_id) (ecmp_grp_id + HAL_ECMP_BASE_ID)
#define HAL_FCOE_FRR_GRP_ID_TO_DI(frr_grp_id)   (frr_grp_id + HAL_FRR_BASE_ID)

#define HAL_FCOE_CB(unit) (&_hal_fcoe_cb[unit])

#define HAL_FCOE_LOCK(unit)   hal_fcoe_lockFcoeResource(unit)
#define HAL_FCOE_UNLOCK(unit) hal_fcoe_unlockFcoeResource(unit)

/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_FCOE_BDID_TO_INTF_S {
    CLX_BRIDGE_DOMAIN_T bdid; /* key: FCoE dedicated forwarding domain */
    UI32_T intf_idx;          /* FCoE interface index, read from HW */
} HAL_FCOE_BDID_TO_INTF_T;

typedef struct HAL_FCOE_CLV_PORT_INFO_S {
    CLX_FCOE_CLV_PORT_MODE_T port_mode; /* F_Port or CL_Port*/
    CLX_PORT_T cl_port_id;              /* CL_Port physical port id or lag_id.only for F_Port */
    UI32_T restore_lcl_intf_grp;        /* lcl_intf_grp when F_port->CL_Port. only for F_Port */
    UI32_T restore_srv_l2_idx;          /* srv_l2_idx when F_Port->CL_Port.   only for F_Port */
    BOOL_T valid;
} HAL_FCOE_CLV_PORT_INFO_T;

typedef struct HAL_FCOE_CLV_CL_PORT_INFO_S {
    UI32_T srv_l2_intf; /* only for cl_port, allocated srv_l2_intf entry */
    BOOL_T valid;
} HAL_FCOE_CLV_CL_PORT_INFO_T;

/**
 * @brief lock FCOE Resource.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
hal_fcoe_lockFcoeResource(const UI32_T unit);

/**
 * @brief unlock FCOE Resource.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
hal_fcoe_unlockFcoeResource(const UI32_T unit);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init FCOE module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_init(const UI32_T unit);

/**
 * @brief de-init FCOE module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_deinit(const UI32_T unit);

/**
 * @brief This API is used to add an FCoE logic interface.
 *        FCF switch is based on Layer 3 forwarding, and the logic interface is a virtual
 *        entity which represents Layer3 switch interface in forwarding. Each VLAN /
 *        bridge-domain can derive one logic interface.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     bdid             - Bridge domain ID
 * @param [in]     ptr_intf_info    - Logic interface information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_addIntf(const UI32_T unit,
                 const CLX_BRIDGE_DOMAIN_T bdid,
                 const CLX_FCOE_INTF_INFO_T *ptr_intf_info);

/**
 * @brief This API is used to delete a VLAN-based FCoE interface.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - Bridge domain ID
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_delIntf(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief This API is used to get FCoE interface information.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     bdid         - Bridge domain ID
 * @param [out]    ptr_entry    - Logic interface information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_getIntf(const UI32_T unit,
                 const CLX_BRIDGE_DOMAIN_T bdid,
                 CLX_FCOE_INTF_INFO_T *ptr_entry);

/**
 * @brief This API is used to add an l3_host entry for fcoe local route, which is used in FCF switch
 * routing. A host represents an N_Port or VE_Port which is directly connected to a local switch.
 * The key of host is {vrf, FCID}. When an N_Port is connected, the FCID is N_Port_ID. When a
 * VE_Port is connected, the FCID is the domain-controller address of remote switch, which has the
 * following format: "FF-FC-Domain_id!".
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_host_info    - Host information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_addHost(const UI32_T unit, const CLX_FCOE_HOST_INFO_T *ptr_host_info);

/**
 * @brief This API is used to Delete an l3_host entry & adjacency entry for fcoe local route.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_host_info    - l3_host key
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_delHost(const UI32_T unit, const CLX_FCOE_HOST_INFO_T *ptr_host_info);

/**
 * @brief This API is used to get a l3_host entry information for fcoe local route.
 *
 * @param [in]     unit             - Device unit number
 * @param [out]    ptr_host_info    - l3_host enrty information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_getHost(const UI32_T unit, CLX_FCOE_HOST_INFO_T *ptr_host_info);

/**
 * @brief This API is used to add an FCoE remote route entry, which is used in the FCF
 *        switch routing. A remote route represents an N_Port or VE_Port which is not
 *        directly connected to the local switch, and it is reachable via at least one
 *        other FCF switch.
 *        The route entry goes through Layer 3 forwarding via the longest-prefix-match
 *        mechanism, and the route entry should be derived from static configuration or by
 *        PSPF algorithm.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Remote route key & information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_addRoute(const UI32_T unit, const CLX_FCOE_ROUTE_INFO_T *ptr_entry);

/**
 * @brief This API is used to delete an l3_fib entry for FCoE remote rout.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_route_info    - l3_fib key
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_delRoute(const UI32_T unit, const CLX_FCOE_ROUTE_INFO_T *ptr_route_info);

/**
 * @brief This API is used to get an l3_fib entry information for fcoe fib route.
 *
 * @param [in]     unit              - Device unit number
 * @param [out]    ptr_route_info    - l3_fib information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_getRoute(const UI32_T unit, CLX_FCOE_ROUTE_INFO_T *ptr_route_info);

/**
 * @brief This API is used to enable/disable the zoning check of VLAN/bridge-domain. When
 *        the zoning is disabled, packet will bypass the zone check.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     bdid          - Bridge domain ID
 * @param [in]     is_enabled    - Zoning check is enabled or disabled
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_setZoneCheck(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid, const BOOL_T is_enabled);

/**
 * @brief This API is used to get the zoning check configuration.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     bdid          - Bridge domain ID
 * @param [out]    ptr_enable    - Zoning check is enabled or disabled
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_getZoneCheck(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid, BOOL_T *ptr_enable);

/**
 * @brief This API is used to add a zoning entry; if zoning is enabled, packet will use
 *        {VLAN, src_FCID, dst_FCID} as key to look up the zoning table; if lookup is
 *        missed, the packet will be dropped.
 *        Note that the entry is normalized, the direction of src_FCID/dst_FCID takes no
 *        effect, and user only needs to add entry of one direction.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_zone_info    - zone information : include vid/bd-id ,dst_fcid,src_fcid
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_addZone(const UI32_T unit, const CLX_FCOE_ZONE_T *ptr_zone_info);

/**
 * @brief This API is used to delete a zoning entry.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_zone_info    - zone information : include vid/bd-id ,dst_fcid,src_fcid
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_delZone(const UI32_T unit, const CLX_FCOE_ZONE_T *ptr_zone_info);

/**
 * @brief This API is used to get if a zoning entry exists.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_zone_info - zone information : include vid/bd-id ,dst_fcid,src_fcid
 * @param [out]    ptr_is_set    - The rule has been set in chip or not
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_getZone(const UI32_T unit, const CLX_FCOE_ZONE_T *ptr_zone_info, BOOL_T *ptr_is_set);

/**
 * @brief Set specify port's CLV mode configuration information
 *
 * Before CLV config, normal FCoE VLAN config should be completed(including flooding member config).
 * config F_Port:  only guarantee upstream flow work correctly(traffic from F_Port to CL_Port).
 * its a special path only for CLV.
 * config CL_Port: only guarantee downstream flow work correctly(traffic from CL_Port to F_Port).
 * its a normal path same with layer 2.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - cl port or f port which need to cofigure
 * @param [in]     ptr_entry    - including port's CLV mode configuration information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_setPortNpvConfig(const UI32_T unit,
                          const CLX_PORT_T port,
                          const CLX_FCOE_CLV_PORT_INFO_T *ptr_entry);

/**
 * @brief This API is used to get per-port's CLV mode configuration information.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - CL port or F port which need to be cofigured
 * @param [out]    ptr_entry    - It includes port's CLV mode configuration information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_getPortNpvConfig(const UI32_T unit,
                          const CLX_PORT_T port,
                          CLX_FCOE_CLV_PORT_INFO_T *ptr_entry);

/**
 * @brief This API is used to set action for several special kinds of FC frame at ingress
 *        or egress stage, this setting is global. There are five kinds of FC frame
 *        for setting action:
 *        (1) Packet with VFT ext-header, and hop-count = 1
 *        (2) Packet with IFR ext-header
 *        (3) Packet with Unknown ext-header
 *        (4) Class 2 frame
 *        (5) Class F frame
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - The configuration of FC frame
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_setFrameTypeAction(const UI32_T unit, const CLX_FCOE_FC_FRAME_ACTION_T *ptr_entry);

/**
 * @brief This API is used to get action for special FC frame.
 *
 * @param [in]     unit         - Device unit number
 * @param [out]    ptr_entry    - The configuration of FC frame
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_getFrameTypeAction(const UI32_T unit, CLX_FCOE_FC_FRAME_ACTION_T *ptr_entry);

/**
 * @brief This API is used to create a FCoE interface object.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port             - physical port ID.
 * @param [out]    ptr_fcoe_port    - The pointer of the FCoE port
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_createPort(const UI32_T unit, const CLX_PORT_T port, CLX_PORT_T *ptr_fcoe_port);

/**
 * @brief This API is used to destroy a FCoE interface object.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     fcoe_port    - The FCoE port
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_fcoe_destroyPort(const UI32_T unit, const CLX_PORT_T fcoe_port);

/**
 * @brief Reset local interface default index for the deleted fcoe port:
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Port beyond range.
 */

CLX_ERROR_NO_T
hal_fcoe_resetPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief Set local interface default index for the new fcoe port:
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Port beyond range.
 */

CLX_ERROR_NO_T
hal_fcoe_setPortDefault(const UI32_T unit, const UI32_T port);

#endif /* End of HAL_FCOE_H */
