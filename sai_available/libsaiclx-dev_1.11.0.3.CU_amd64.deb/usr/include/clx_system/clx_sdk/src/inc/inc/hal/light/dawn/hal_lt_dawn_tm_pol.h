/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_lt_dawn_tm_pol.h
 * PURPOSE:
 *      It provide HAL API of PM, IOS and LBM module.
 * NOTES:
 */

#ifndef HAL_LT_DAWN_TM_POL_H
#define HAL_LT_DAWN_TM_POL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_LT_DAWN_IOS_BUF_TOTAL_SZ     (8188)
#define HAL_LT_DAWN_IOS_REQ_UN_ALLOC     (109)
#define HAL_LT_DAWN_IOS_OPT_REQ_UN_ALLOC (1)
#define HAL_LT_DAWN_IOS_TOTAL_UN_ALLOC \
    (HAL_LT_DAWN_IOS_REQ_UN_ALLOC + HAL_LT_DAWN_IOS_OPT_REQ_UN_ALLOC)
#define HAL_LT_DAWN_IOS_ALLOC (HAL_LT_DAWN_IOS_BUF_TOTAL_SZ - HAL_LT_DAWN_IOS_TOTAL_UN_ALLOC)

#define HAL_LT_DAWN_IOS_SHARE_TRUNC_HRM  (136)
#define HAL_LT_DAWN_IOS_CREDIT_TRUNC_HRM (34)
#define HAL_LT_DAWN_IOS_RCP_CREDIT_MAX   (32)
#define HAL_LT_DAWN_IOS_LB_CREDIT_MAX    (128)
#define HAL_LT_DAWN_IOS_PCIE_CREDIT_MAX  (32)
#define HAL_LT_DAWN_IOS_CP_HRM_MAX       (1416)
#define HAL_LT_DAWN_IOS_PFC_HRM_MAX      (3072)
#define HAL_LT_DAWN_IOS_FP_MIN_THR       (16)

#define HAL_LT_DAWN_IOS_LOSSY_TRUNC_ON_THR                                                        \
    (HAL_LT_DAWN_IOS_ALLOC - HAL_LT_DAWN_IOS_SHARE_TRUNC_HRM - HAL_LT_DAWN_IOS_CREDIT_TRUNC_HRM - \
     HAL_LT_DAWN_IOS_RCP_CREDIT_MAX - HAL_LT_DAWN_IOS_LB_CREDIT_MAX -                             \
     HAL_LT_DAWN_IOS_PCIE_CREDIT_MAX - HAL_LT_DAWN_IOS_CP_HRM_MAX - HAL_LT_DAWN_IOS_PFC_HRM_MAX - \
     HAL_LT_DAWN_IOS_FP_MIN_THR)

#define HAL_LT_DAWN_IOS_LOSSY_TRUNC_GAP (157)
#define HAL_LT_DAWN_IOS_LOSSY_DROP_ON_THR \
    (HAL_LT_DAWN_IOS_LOSSY_TRUNC_ON_THR - HAL_LT_DAWN_IOS_LOSSY_TRUNC_GAP)
#define HAL_LT_DAWN_IOS_LOSSY_DROP_GAP (317)
#define HAL_LT_DAWN_IOS_LOSSY_DROP_OFF_THR \
    (HAL_LT_DAWN_IOS_LOSSY_DROP_ON_THR - HAL_LT_DAWN_IOS_LOSSY_DROP_GAP)

#define HAL_LT_DAWN_IOS_FCOS_TRUNC_ON_THR (8191)
#define HAL_LT_DAWN_IOS_FCOS_DROP_ON_THR  (8191)
#define HAL_LT_DAWN_IOS_FCOS_DROP_OFF_THR (8191)

#define HAL_LT_DAWN_IOS_FP_DROP_ON_THR (1478)
#define HAL_LT_DAWN_IOS_FP_DROP_GAP    (97)
#define HAL_LT_DAWN_IOS_FP_DROP_OFF_THR \
    (HAL_LT_DAWN_IOS_FP_DROP_ON_THR - HAL_LT_DAWN_IOS_FP_DROP_GAP)

#define HAL_LT_DAWN_IOS_GB_HI_GAP  (337)
#define HAL_LT_DAWN_IOS_FP_HI_GAP  (227)
#define HAL_LT_DAWN_IOS_FP_COS_GAP (127)

#define HAL_LT_DAWN_IOS_GB_HI2_XOFF_THR     (2915)
#define HAL_LT_DAWN_IOS_GB_HI2_XON_THR      (HAL_LT_DAWN_IOS_GB_HI2_XOFF_THR - HAL_LT_DAWN_IOS_GB_HI_GAP)
#define HAL_LT_DAWN_IOS_FP_HI2_XOFF_THR     (1536)
#define HAL_LT_DAWN_IOS_FP_HI2_XON_THR      (HAL_LT_DAWN_IOS_FP_HI2_XOFF_THR - HAL_LT_DAWN_IOS_FP_HI_GAP)
#define HAL_LT_DAWN_IOS_FP_COS_HI2_XOFF_THR (512)
#define HAL_LT_DAWN_IOS_FP_COS_HI2_XON_THR \
    (HAL_LT_DAWN_IOS_FP_COS_HI2_XOFF_THR - HAL_LT_DAWN_IOS_FP_COS_GAP)

#define HAL_LT_DAWN_IOS_GB_HI1_XOFF_THR     (2403)
#define HAL_LT_DAWN_IOS_GB_HI1_XON_THR      (HAL_LT_DAWN_IOS_GB_HI1_XOFF_THR - HAL_LT_DAWN_IOS_GB_HI_GAP)
#define HAL_LT_DAWN_IOS_FP_HI1_XOFF_THR     (1024)
#define HAL_LT_DAWN_IOS_FP_HI1_XON_THR      (HAL_LT_DAWN_IOS_FP_HI1_XOFF_THR - HAL_LT_DAWN_IOS_FP_HI_GAP)
#define HAL_LT_DAWN_IOS_FP_COS_HI1_XOFF_THR (512)
#define HAL_LT_DAWN_IOS_FP_COS_HI1_XON_THR \
    (HAL_LT_DAWN_IOS_FP_COS_HI1_XOFF_THR - HAL_LT_DAWN_IOS_FP_COS_GAP)

#define HAL_LT_DAWN_IOS_FP_EN (0x1ffff)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_LT_DAWN_TM_POL_CTL  (0x3)
#define HAL_LT_DAWN_TM_POL_HI_2 (0x2)
#define HAL_LT_DAWN_TM_POL_HI_1 (0x1)
#define HAL_LT_DAWN_TM_POL_LOW  (0x0)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_LT_DAWN_TM_IOS_COS_MAP_PCP_ACTION_ADD,
    HAL_LT_DAWN_TM_IOS_COS_MAP_PCP_ACTION_UPDATE,
    HAL_LT_DAWN_TM_IOS_COS_MAP_PCP_ACTION_DELETE,
    HAL_LT_DAWN_TM_IOS_COS_MAP_PCP_ACTION_CLEAR_ALL,
    HAL_LT_DAWN_TM_IOS_COS_MAP_PCP_ACTION_LAST
} HAL_LT_DAWN_TM_IOS_COS_MAP_PCP_ACTION_T;

CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_setPmState(const UI32_T unit,
                              const UI32_T port,
                              const CLX_DIR_T dir,
                              const UI32_T enable);

CLX_ERROR_NO_T
hal_lt_dawn_tm_setPmSpeed(const UI32_T unit, const UI32_T port, const CLX_PORT_SPEED_T speed);

CLX_ERROR_NO_T
hal_lt_dawn_tm_getTsRxEntry(const UI32_T unit,
                            const UI32_T port,
                            CLX_PORT_TS_ENTRY_T *ptr_ts_entry);

CLX_ERROR_NO_T
hal_lt_dawn_tm_setTsRxState(const UI32_T unit, const UI32_T port, const UI32_T enable);

CLX_ERROR_NO_T
hal_lt_dawn_tm_updateTsRxLatency(const UI32_T unit, const UI32_T port, const UI32_T latency);

CLX_ERROR_NO_T
hal_lt_dawn_tm_getIosCosFromPcp(const UI32_T unit,
                                const UI32_T port,
                                const UI32_T pcp_bitmap,
                                UI32_T *ptr_class);

/**
 * @brief To set cos map to pcp at IOS.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - Port id
 * @param [in]     ori_pcp_bmp     - Bitmap of original PCP (meaningless when action is ADD)
 * @param [in]     new_pcp_bmp     - Bitmap of new PCP (meaningless when action is DELETE)
 * @param [in]     action          - ADD, UPDATE or DELETE
 * @param [out]    ptr_class       - *ptr_class is original class if the action is delete or update.
 * *ptr_class is new class if the action is ADD.
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_setIosCosMapPcp(const UI32_T unit,
                               const UI32_T port,
                               const UI32_T ori_pcp_bmp,
                               const UI32_T new_pcp_bmp,
                               const HAL_LT_DAWN_TM_IOS_COS_MAP_PCP_ACTION_T action,
                               UI32_T *ptr_class);

/**
 * @brief To set cos for related pcp bitmap at IPM.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - Port id
 * @param [in]     pcp_bitmap      - Bitmap of PCP
 * @param [in]     ios_class       - Regular Hi 1 or Hi 2
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_setIpmCosPort(const UI32_T unit,
                             const UI32_T port,
                             const UI32_T pcp_bitmap,
                             const UI32_T ios_class);

/**
 * @brief To set port mapping at EPM and EPM_M.
 *
 * @param [in]     unit             - Chip id
 * @param [in]     ptr_ppid         - Pointer of ppid structure
 * @param [in]     ptr_mac_macro    - Pointer of TM mac macro structure
 *                                    RETURN
 * @return         CLX_E_OK         - Operate success
 * @return         CLX_E_OTHERS     - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_setEpmPortMapping(const UI32_T unit,
                                     const HAL_LT_DAWN_TM_PPID_T *ptr_ppid,
                                     const HAL_LT_DAWN_TM_MAC_MACRO_T *ptr_mac_macro);

/**
 * @brief To set port mapping at LBM.
 *
 * @param [in]     unit             - Chip id
 * @param [in]     ptr_ppid         - Pointer of ppid structure
 * @param [in]     ptr_mac_macro    - Pointer of TM mac macro structure
 *                                    RETURN
 * @return         CLX_E_OK         - Operate success
 * @return         CLX_E_OTHERS     - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_setLbmPortMapping(const UI32_T unit,
                                     const HAL_LT_DAWN_TM_PPID_T *ptr_ppid,
                                     const HAL_LT_DAWN_TM_MAC_MACRO_T *ptr_mac_macro);

/**
 * @brief To get EPM buffer empty.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - CLX port number
 *                                   RETURN
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_getEpmBufferEmpty(const UI32_T unit, const UI32_T port);

/**
 * @brief To reset EPM buffer if lane number is changed.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - CLX port number
 * @param [in]     lane_num        - Lane number:4/2/1
 *                                   RETURN
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_resetEpmBuffer(const UI32_T unit, const UI32_T port, const UI32_T lane_num);

/**
 * @brief To get lane number from EPM buffer setting of this port.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - CLX port number
 * @param [out]    ptr_lane_num    - Lane number of this port
 *                                   RETURN
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_getLaneNum(const UI32_T unit, const UI32_T port, UI32_T *ptr_lane_num);

CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_setProperty(const UI32_T unit,
                               const UI32_T port,
                               const HAL_TM_EPM_PROPERTY_T property,
                               const UI32_T data);

CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_setCpiQueueTruncateSize(const UI32_T unit,
                                           const UI32_T port,
                                           const UI32_T queue,
                                           const UI32_T size);

CLX_ERROR_NO_T
hal_lt_dawn_tm_pol_getCpiQueueTruncateSize(const UI32_T unit,
                                           const UI32_T port,
                                           const UI32_T queue,
                                           UI32_T *ptr_size);

#endif /* #ifndef HAL_LT_DAWN_TM_POL_H */
