/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  dcc_mt.h
 * PURPOSE:
 *  1. Provide the chip Device Control Command(DCC_MT) interfaces, it will include:
 *     a. Per channel init status.
 *     b. DCC_MT Errror handler.
 *  2. Define DCC_MT related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_MT_H
#define DCC_MT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_cfg.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <hal/hal_tbl.h>
#include <dcc/dcc.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* MT broadcast definition */
#define DCC_MT_BROADCAST_ADDR                (0x8000000)
#define DCC_MT_BROADCAST_ECPU_REP_NUM_ADDR   (0x051C0038)
#define DCC_MT_BROADCAST_ECPU_ADDR_STEP_ADDR (0x051C003C)
#define DCC_MT_BROADCAST_PDMA_REP_NUM_ADDR   (0x051C0040)
#define DCC_MT_BROADCAST_PDMA_ADDR_STEP_ADDR (0x051C0044)
#define DCC_MT_BROADCAST_CMST_REP_NUM_ADDR   (0x051C0048)
#define DCC_MT_BROADCAST_CMST_ADDR_STEP_ADDR (0x051C004C)

/* DCC_MT constant definition */
#define DCC_MT_CMD_LENGTH_UNIT (4)  /* words, means 4 bytes */
#define DCC_MT_HIGH_ADDR_WIDTH (32) /* High address width is 32 bits */
#define DCC_MT_MAX_TIMEOUT_CNT (10000000)
/* unit of time: us, all times need for further check */
#define DCC_MT_UP_DOWNLOAD_SUSPEND_TIME (50)

#define DCC_MT_EN_CMD_PERF_RECORD (1)

/* DCE second level interrupt for DCE channel error */
#define DCC_MT_IOCMD_CORE1_ERR  (1UL << 1)
#define DCC_MT_IOCMD_CORE2_ERR  (1UL << 4)
#define DCC_MT_DMA_TABLEH2D_ERR (1UL << 20)
#define DCC_MT_DMA_TABLED2H_ERR (1UL << 21)
#define DCC_MT_CLD_DMA_H2D_ERR  (1UL << 22)
#define DCC_MT_CLD_DMA_D2H_ERR  (1UL << 23)
#define DCC_MT_IOCMD_CORE3_ERR  (1UL << 25)
#define DCC_MT_DMA_TABLED2D_ERR (1UL << 27)
#define DCC_MT_TDMA_STAUPD_ERR  (1UL << 28)
#define DCC_MT_CLD_STAUPD_ERR   (1UL << 29)
#define DCC_MT_DMA_UPERRIRQ     (1UL << 31)

/* DCE third level interrupt for DCE uP error (DCC_MT_DMA_UPERRIRQ) */
/* uP to host error interrupt status */
#define DCC_MT_WTD_HST_ERR       (1UL << 0)
#define DCC_MT_PMEM_DECC_ERR     (1UL << 1)
#define DCC_MT_DMEM0_DECC_ERR    (1UL << 2)
#define DCC_MT_DMEM1_DECC_ERR    (1UL << 3)
#define DCC_MT_TMEM_DECC_ERR     (1UL << 4)
#define DCC_MT_PMEM_SECC_ERR     (1UL << 5)
#define DCC_MT_DMEM0_SECC_ERR    (1UL << 6)
#define DCC_MT_DMEM1_SECC_ERR    (1UL << 7)
#define DCC_MT_TMEM_SECC_ERR     (1UL << 8)
#define DCC_MT_SHR_ARB_TMO_ERR   (1UL << 9)
#define DCC_MT_DBUS_ARB_TMO_ERR  (1UL << 10)
#define DCC_MT_PMEM_ARB0_TMO_ERR (1UL << 11)
#define DCC_MT_PMEM_ARB1_TMO_ERR (1UL << 12)
#define DCC_MT_DMEM_ARB0_TMO_ERR (1UL << 13)
#define DCC_MT_DMEM_ARB1_TMO_ERR (1UL << 14)

/* DCE second level interrupt for DCE channel error */
/* Default enable setting */
#define DCC_MT_CH_ERR_INTR_MASK                                                   \
    (DCC_MT_IOCMD_CORE1_ERR | DCC_MT_DMA_TABLEH2D_ERR | DCC_MT_DMA_TABLED2H_ERR | \
     DCC_MT_DMA_TABLED2D_ERR | DCC_MT_CLD_DMA_H2D_ERR | DCC_MT_CLD_DMA_D2H_ERR |  \
     DCC_MT_CLD_STAUPD_ERR | DCC_MT_TDMA_STAUPD_ERR | DCC_MT_DMA_UPERRIRQ)

/* DCE third level interrupt for DCE uP error */
/* Default enable setting */
#define DCC_MT_UP_ERR_INTR_MASK \
    (DCC_MT_PMEM_DECC_ERR | DCC_MT_DMEM0_DECC_ERR | DCC_MT_DMEM1_DECC_ERR | DCC_MT_TMEM_DECC_ERR)

/* status update error */
#define DCC_MT_COMPLETION_TIMEOUT_ERR   (1UL << 0)
#define DCC_MT_UNSUPPORT_REQUEST_ERR    (1UL << 1)
#define DCC_MT_COMPLETE_ABORT_ERR       (1UL << 2)
#define DCC_MT_CONFIG_REQUEST_RETRY_ERR (1UL << 3)
#define DCC_MT_PCIE_RESET_ERR           (1UL << 6)
#define DCC_MT_PCIE_ECC_ERR             (1UL << 7)

/* for host 64 bits address access macro */
#define DCC_MT_HOST_ADDR_HI(dst)  (dst.ui32[1])
#define DCC_MT_HOST_ADDR_LOW(dst) (dst.ui32[0])
#define DCC_MT_HOST_ADDR_ASSIGN(dst, high, low) \
    do {                                        \
        DCC_MT_HOST_ADDR_HI(dst) = (high);      \
        DCC_MT_HOST_ADDR_LOW(dst) = (low);      \
    } while (0)
#define DCC_MT_HOST_ADDR_64_BIT_SET(dst, high, low)      \
    do {                                                 \
        dst = (high);                                    \
        dst = ((dst << DCC_MT_HIGH_ADDR_WIDTH) | (low)); \
    } while (0)

/* DCC_MT semaphore macro */
#define DCC_MT_TAKE_SEMA(sema, timeOut) osal_takeSemaphore(sema, timeOut)
#define DCC_MT_GIVE_SEMA(sema)          osal_giveSemaphore(sema)

/* DCC_MT MMIO register access macro */
#if defined(CLX_LAMP)
#define DCC_MT_MMIO_REG_READ(unit, offset, ptr_data) dcc_mt_lamp_readReg(unit, offset, ptr_data, 4)
#define DCC_MT_MMIO_REG_WRITE(unit, offset, ptr_data) \
    dcc_mt_lamp_writeReg(unit, offset, ptr_data, 4)
#else
#define DCC_MT_MMIO_REG_READ(unit, offset, ptr_data)  aml_readReg(unit, offset, ptr_data, 4)
#define DCC_MT_MMIO_REG_WRITE(unit, offset, ptr_data) aml_writeReg(unit, offset, ptr_data, 4)
#endif /* #if defined(CLX_LAMP) */

#if defined(DCC_MT_EN_CMD_PERF_RECORD)
#define DCC_MT_CMD_EXEC_TIME_RECORD(unit, cmd_time, cmd_max_time, cmd_min_time) \
    do {                                                                        \
        cmd_max_time = ((cmd_max_time < cmd_time) ? cmd_time : cmd_max_time);   \
        cmd_min_time = ((cmd_min_time > cmd_time) ? cmd_time : cmd_min_time);   \
    } while (0)
#endif

#define DCC_MT_INIT_IO_CH_DONE(unit)  (dcc_mt_control_block[unit].state.init_io_done)
#define DCC_MT_INIT_DMA_CH_DONE(unit) (dcc_mt_control_block[unit].state.init_dma_done)
#define DCC_MT_INIT_CLD_CH_DONE(unit) (dcc_mt_control_block[unit].state.init_cld_done)
#define DCC_MT_INIT_DCE_DONE(unit)    (dcc_mt_control_block[unit].state.init_dce_done)

#define DCC_MT_INVALID_MMIO_ADDR (0xFFFFFFFF)

/* MACRO FUNCTION DECLARATIONS
 */

#define DCC_MT_INIT_A_CMD(ptr_cmd, cmd_act_in, addr_in, ptr_data_in, data_len_in, ptr_rsp_in) \
    do {                                                                                      \
        (ptr_cmd)->action = (cmd_act_in);                                                     \
        (ptr_cmd)->addr = (addr_in);                                                          \
        (ptr_cmd)->ptr_data = (ptr_data_in);                                                  \
        (ptr_cmd)->data_len = (data_len_in);                                                  \
        (ptr_cmd)->ptr_rsp = (ptr_rsp_in);                                                    \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
/* DCC_MT channel access mode (polling or interrupt) */
typedef enum {
    DCC_MT_CH_OP_MODE_POLL = 0,
    DCC_MT_CH_OP_MODE_INTR,
    DCC_MT_CH_OP_MODE_LAST
} DCC_MT_CH_OP_MODE_T;

typedef struct {
    UI32_T ui32[2];
} DCC_MT_HOST_ADDR_T;

typedef CLX_ERROR_NO_T (*DCC_MT_ISR_HANDLE_FUNC_T)(const UI32_T unit, const UI32_T isr_cookie);

/* DCC_MT control block state */
typedef struct {
    BOOL_T init_io_done;  /* indicate IO channel initializing done */
    BOOL_T init_dma_done; /* indicate DMA channel initializing done */
    BOOL_T init_cld_done; /* indicate Calendar DMA channel initializing done */
    BOOL_T init_dce_done; /* indicate DCE error channel initializing done  */

} DCC_MT_CB_STATE_T;

typedef enum {
    DCC_MT_INTR_IOCMD_CORE1_ERROR = 0,
    DCC_MT_INTR_IOCMD_CORE2_ERROR,
    DCC_MT_INTR_DMA_TABLEH2D_ERROR,
    DCC_MT_INTR_DMA_TABLED2H_ERROR,
    DCC_MT_INTR_CLD_DMA_H2D_ERROR,
    DCC_MT_INTR_CLD_DMA_D2H_ERROR,
    DCC_MT_INTR_IOCMD_CORE3_ERROR,
    DCC_MT_INTR_DMA_TABLED2D_ERROR,
    DCC_MT_INTR_TDMA_STAUPD_ERROR,
    DCC_MT_INTR_CLD_STAUPD_ERROR,
    DCC_MT_INTR_DMA_UP_ERROR,
    DCC_MT_INTR_TYPE_LAST
} DCC_MT_INTR_TYPE_T;

typedef enum {
    /* uP to host error interrupt status */
    DCC_MT_UP_WTD_HST_ERROR = 0,
    DCC_MT_UP_PMEM_DECC_ERROR,
    DCC_MT_UP_DMEM0_DECC_ERROR,
    DCC_MT_UP_DMEM1_DECC_ERROR,
    DCC_MT_UP_TMEM_DECC_ERROR,
    DCC_MT_UP_PMEM_SECC_ERROR,
    DCC_MT_UP_DMEM0_SECC_ERROR,
    DCC_MT_UP_DMEM1_SECC_ERROR,
    DCC_MT_UP_TMEM_SECC_ERROR,
    DCC_MT_UP_SHR_ARB_TMO_ERROR,
    DCC_MT_UP_DBUS_ARB_TMO_ERROR,
    DCC_MT_UP_PMEM_ARB0_TMO_ERROR,
    DCC_MT_UP_PMEM_ARB1_TMO_ERROR,
    DCC_MT_UP_DMEM_ARB0_TMO_ERROR,
    DCC_MT_UP_DMEM_ARB1_TMO_ERROR,
    DCC_MT_UP_ERROR_LAST
} DCC_MT_UP_INTR_TYPE_T;

typedef UI32_T DCC_MT_INTR_MASK_T;

typedef struct {
    const DCC_MT_INTR_TYPE_T intr_type;    /* interrupt type */
    const DCC_MT_INTR_MASK_T intr_mask;    /* interrupt mask */
    DCC_MT_ISR_HANDLE_FUNC_T isr_callback; /* interrupt handler function */
    UI32_T isr_cookie;                     /* the cookie of interrupt handler */
    const C8_T *const ptr_isr_desc;        /* interrupt handler descriptions */
} DCC_MT_INTR_VEC_T;

typedef struct {
    DCC_MT_INTR_VEC_T *const ptr_intr_vector; /* INTR vector table */
    const UI16_T intr_num;                    /* total high-pri INTR number */
    const DCC_MT_INTR_MASK_T intr_all_mask;   /* total high-pri INTR mask bits */
} DCC_MT_ISR_INFO_T;

typedef struct {
    const C8_T *const driver_desc;         /* driver description */
    DCC_MT_ISR_INFO_T *const ptr_isr_info; /* ISR information pointer */
} DCC_MT_DRIVER_T;

typedef struct DCC_MT_DCE_CB_S {
    DCC_MT_DRIVER_T *ptr_driver_info;
} DCC_MT_DCE_CB_T;

typedef struct {
    UI32_T dce_int_en_mmio_addr;
    UI32_T dce_int_mask_mmio_addr;
    UI32_T dce_int_set_mmio_addr;
    UI32_T dce_int_clr_mmio_addr;
    UI32_T dce_int_stat_mmio_addr;
} DCC_MT_DCE_MMIO_ADDR_CB_T;

/* DCC_MT control block structure */
typedef struct {
    DCC_MT_CB_STATE_T state;                    /* DCC_MT control block state */
    DCC_MT_DCE_CB_T dce_cb;                     /* dce control block */
    DCC_MT_DCE_MMIO_ADDR_CB_T dce_mmio_addr_cb; /* dce mmio addr control block */
} DCC_MT_CB_T;

typedef CLX_ERROR_NO_T (*DCC_MT_DRIVER_INIT_FUNC_T)(DCC_MT_DRIVER_T **pptr_dcc_mt_driver);

typedef struct {
    DCC_MT_DRIVER_INIT_FUNC_T dcc_mt_initDriver_callback; /* driver handler function pointer */
} DCC_MT_DEVICE_DRIVER_MAP_T;

/**
 * @brief dcc_mt_init() is responsible for DCC_MT initialization, it will do
 *        the following:
 *        1. Allocate an available DCC_MT control block.
 *        2. Initialize DCC_MT miscellaneous resources(DCC_MT DMA buffers).
 *        3. Initialize DCC_MT IO channel.
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_MT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */

CLX_ERROR_NO_T
dcc_mt_init(const UI32_T unit);

/**
 * @brief dcc_mt_chInit() is responsible for DCC_MT initialization, it will do
 *        the following:
 *        1. Initialize DCC_MT channels. It will include:
 *        a. DMA channel initialization.
 *        b. Calendar DMA channel initialization.
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_MT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */

CLX_ERROR_NO_T
dcc_mt_chInit(const UI32_T unit);

/**
 * @brief dcc_mt_deInit() is responsible for DCC_MT de-initialization, it will
 *        do the following:
 *        1. De-initialize DCC_MT channels.
 *        2. De-initialize DCC_MT miscellaneous resource(DCC_MT DMA buffers).
 *        3. De-initialize DCC_MT control block.
 *
 * @param [in]     unit    - The unit number that would like to de-initialized.
 * @return         CLX_E_OK        - Successfully de-initialize DCC_MT.
 * @return         CLX_E_OTHERS    - Fail to complete de-initialization procedure.
 */
CLX_ERROR_NO_T
dcc_mt_deinit(const UI32_T unit);

/* DMA channel Error ISR */
CLX_ERROR_NO_T
dcc_mt_dceChIsr(const UI32_T unit, const UI32_T isr_cookie);

extern DCC_MT_CB_T dcc_mt_control_block[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern DCC_MT_ISR_INFO_T dcc_mt_up_err_isr_info;

extern DCC_MT_INTR_VEC_T dcc_mt_up_err_vector[];
#endif /* END of DCC_MT_H*/
