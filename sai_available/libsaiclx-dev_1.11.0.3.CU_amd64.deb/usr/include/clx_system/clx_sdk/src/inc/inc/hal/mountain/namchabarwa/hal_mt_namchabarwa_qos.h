/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_qos.h
 * PURPOSE:
 *      It provides hal qos module API.
 * NOTES:
 *      None.
 */

#ifndef HAL_MT_NAMCHABARWA_QOS_H
#define HAL_MT_NAMCHABARWA_QOS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_qos.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NAMCHABARWA_INVALID_PHB_HW_IDX (0x7F) /* NB SRV INTF uses invalid index */
#define HAL_MT_NAMCHABARWA_DEFAULT_PHB_HW_IDX (0x0)  /* NB LCL INTF uses default index */
#define HAL_MT_NAMCHABARWA_DEFAULT_PROF_IDX   (0)    /* NB default profile index */
/* total number of traffice class for qos mapping for namchabarwa */
#define HAL_MT_NAMCHABARWA_QOS_TC_NUM (8)
/* qos phb_prof_idx min value for local interface */
#define HAL_MT_NAMCHABARWA_QOS_PHB_PROFILE_MIN (0)
/* qos phb_prof_idx max value for local interface */
#define HAL_MT_NAMCHABARWA_QOS_PHB_PROFILE_MAX (127)
/* qos phb_prof_idx max value for local interface */
#define HAL_MT_NAMCHABARWA_BDI_QOS_PHB_PROFILE_MAX (126)

extern HAL_QOS_INIT_PHB_TO_DSCP_ENTRY_T _hal_qos_init_phb_to_dscp[HAL_QOS_TC_NUM][HAL_QOS_COLOR_NUM];
extern HAL_QOS_INIT_PHB_TO_PCP_DEI_ENTRY_T _hal_qos_init_phb_to_pcp_dei[HAL_QOS_TC_NUM]
                                                                       [HAL_QOS_COLOR_NUM];
extern HAL_QOS_INIT_PHB_TO_EXP_ENTRY_T _hal_qos_init_phb_to_exp[HAL_QOS_TC_NUM][HAL_QOS_COLOR_NUM];
extern HAL_QOS_CONTROL_T *_ptr_hal_qos_control[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern CLX_SEMAPHORE_ID_T _profile_sema[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
/* MACRO FUNCTION DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */



/**
 * @brief create a priority mapping profile.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_init(const UI32_T unit);

/**
 * @brief Deinitialize Qos module.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK        - Deinitialize success.
 * @return         CLX_E_OTHERS    - Deinitialize failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_deinit(const UI32_T unit);

/**
 * @brief create a priority mapping profile.
 *
 * Use this API to create a new mapping profile.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mapping_type    - The type of the mapping profile.
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                   the mapping of ingress pcp/dei to phb.
 *                                   CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                   the mapping of ingress dscp to phb.
 *                                   CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                   the mapping of ingress exp to phb.
 *                                   CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                   the mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                   the mapping of egress phb to dscp.
 *                                   CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                   the mapping of egress phb to exp.
 * @param [in]     profile_id      - An int value which means the mapping profile id and also the
 * index in hardware table.
 * @param [out]    ptr_profile_idx        - The profile id from the hardware table.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - NO more memory for the entry.
 * @return         CLX_E_EXISTS           - The mapping proile is alreaded created.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_createProfile(const UI32_T unit,
                                     const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                     const UI32_T profile_id,
                                     UI32_T *ptr_profile_idx);

/**
 * @brief delete a priority mapping profile.
 *
 * Use this API to destroy a  mapping profile.  Only when the mapping profile is not used by other
 * objects (such as port/vm/interface/tunnel and so on) can destroy it. if "profile_id" is 0, return
 * CLX_E_NOT_SUPPORT because chip must have the default mapping of ingress pcp/dei to phb.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mapping_type    - The type of the mapping profile.
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                   the mapping of ingress pcp/dei to phb.
 *                                   CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                   the mapping of ingress dscp to phb.
 *                                   CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                   the mapping of ingress exp to phb.
 *                                   CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                   the mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                   the mapping of egress phb to dscp.
 *                                   CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                   the mapping of egress phb to exp.
 * @param [in]     profile_id      - an int value which means the mapping profile id and also the
 * index in hardware table.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping proile is not exist.
 * @return         CLX_E_NOT_SUPPORT        - Not support to delete the mapping profile.
 *                                            (eg. the mapping profile has been applied to a
 * port/vm/interface/tunnel and so on)
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_delProfile(const UI32_T unit,
                                  const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                  const UI32_T profile_id);

/**
 * @brief configure a priority mapping entry.
 *
 * Use this API to configure a mapping entry.
 * User should set all fields needed according to the "mapping_type" parameter in entry.
 * if "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB,
 * fields "pcp","dei", "tc", "color" must be input by user and ignor other fields.
 * if "mapping_type" is CLX_QOS_MAPPING_DSCP_TO_PHB,
 * fields "dscp", "tc", "color" must be input by user and ignor other fields.
 * if "mapping_type" is CLX_QOS_MAPPING_EXP_TO_PHB,
 * fields "exp", "tc", "color" must be input by user and ignor other fields.
 * if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI,
 * fields "pcp", "dei", "tc", "color" must be input by user and ignor other fields.
 * if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_DSCP,
 * fields "dscp", "tc", "color" must be input by user and ignor other fields.
 * if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_EXP,
 * fields "exp", "tc", "color" must be input by user and ignor other fields.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mapping_type    - The type of the mapping profile.
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                   the mapping of ingress pcp/dei to phb.
 *                                   CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                   the mapping of ingress dscp to phb.
 *                                   CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                   the mapping of ingress exp to phb.
 *                                   CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                   the mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                   the mapping of egress phb to dscp.
 *                                   CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                   the mapping of egress phb to exp.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI means
 *                                   the default mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP means
 *                                   the default mapping of egress phb to dscp.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_EXP means
 *                                   the default mapping of egress phb to exp.
 * @param [in]     profile_id      - an int value which means the mapping profile id and also the
 * index in hardware table.
 * @param [in]     ptr_entry           - the entry of the priority mapping.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping proile is not found.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_setProfileEntry(const UI32_T unit,
                                       const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                       const UI32_T profile_id,
                                       const CLX_QOS_MAPPING_ENTRY_T *ptr_entry);

/**
 * @brief get a priority mapping entry.
 *
 * Use this API to get a mapping entry.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mapping_type    - The type of the mapping profile.
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                   the mapping of ingress pcp/dei to phb.
 *                                   CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                   the mapping of ingress dscp to phb.
 *                                   CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                   the mapping of ingress exp to phb.
 *                                   CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                   the mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                   the mapping of egress phb to dscp.
 *                                   CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                   the mapping of egress phb to exp.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI means
 *                                   the default mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP means
 *                                   the default mapping of egress phb to dscp.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_EXP means
 *                                   the default mapping of egress phb to exp.
 * @param [in]     profile_id      - an int value which means the mapping profile id and also the
 * index in hardware table.
 * @param [in]     ptr_entry       - the entry which the user want to get.
 *                                   if "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB,
 *                                   fields "pcp", "dei" are the input.
 *                                   if "mapping_type" is CLX_QOS_MAPPING_DSCP_TO_PHB,
 *                                   fields "dscp" is the input.
 *                                   if "mapping_type" is CLX_QOS_MAPPING_EXP_TO_PHB,
 *                                   fields "exp" is the input.
 *                                   if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI or
 * CLX_QOS_MAPPING_PHB_TO_DSCP or "CLX_QOS_MAPPING_PHB_TO_EXP" fields "tc", "color" are the input.
 * @param [out]    ptr_entry       - the entry which return to the user.
 *                                   if "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB or
 * CLX_QOS_MAPPING_DSCP_TO_PHB or CLX_QOS_MAPPING_EXP_TO_PHB, fields "tc", "color" are output. if
 * "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI, fields "pcp", "dei" are output. if
 * "mapping_type" is CLX_QOS_MAPPING_PHB_TO_DSCP, fields "dscp" is output. if "mapping_type" is
 * CLX_QOS_MAPPING_PHB_TO_EXP, fields "exp" is output.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - the mapping profile_id is not exists.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_getProfileEntry(const UI32_T unit,
                                       const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                       const UI32_T profile_id,
                                       CLX_QOS_MAPPING_ENTRY_T *ptr_entry);

/**
 * @brief apply or unapply a priority mapping profile.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     intf_type           - Interface type: Local interface and L2 service interface.
 * @param [in]     mapping_type        - The type of the mapping profile.
 *                                       CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress
 * pcp/dei to phb CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb
 *                                       CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp
 * to phb CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei
 *                                       CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb
 * to dscp CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp
 * @param [in]     profile_id          - an int value which means the mapping profile id and aslo
 * the index in hardware table. 0 ~ 127: apply profile; CLX_QOS_INVALID_PROFILE_ID: cancel to apply
 * profile.
 * @param [in]     ptr_phb_prof_idx    - Pointer for the old phb_prof_idx in table L2_LCL_INTF or
 * L2_SRV_INTF.
 * @param [out]    ptr_phb_prof_idx    - qos module return a new phb_prof_idx to applier.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - NO more memory for apply.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_applyProfile(const UI32_T unit,
                                    const HAL_QOS_INTF_TYPE_T intf_type,
                                    const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                    const UI32_T profile_id,
                                    UI32_T *ptr_phb_prof_idx);

/**
 * @brief create a priority mapping profile for user.
 *
 * Use this API to create a new mapping profile.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mapping_type    - The type of the mapping profile.
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                   the mapping of ingress pcp/dei to phb.
 *                                   CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                   the mapping of ingress dscp to phb.
 *                                   CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                   the mapping of ingress exp to phb.
 *                                   CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                   the mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                   the mapping of egress phb to dscp.
 *                                   CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                   the mapping of egress phb to exp.
 * @param [in]     profile_id      - an int value which means the mapping profile id and aslo the
 * index in hardware table.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - NO more memory for the entry.
 * @return         CLX_E_EXISTS           - The mapping proile is alreaded created.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_createUserProfile(const UI32_T unit,
                                         const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                         const UI32_T profile_id);

/**
 * @brief delete a priority mapping profile for user.
 *
 * Use this API to destroy a  mapping profile.  Only when the mapping profile is not used by other
 * objects (such as port/vm/interface/tunnel and so on) can destroy it. if "profile_id" is 0, return
 * CLX_E_NOT_SUPPORT because chip must have the default mapping of ingress pcp/dei to phb.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mapping_type    - The type of the mapping profile.
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                   the mapping of ingress pcp/dei to phb.
 *                                   CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                   the mapping of ingress dscp to phb.
 *                                   CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                   the mapping of ingress exp to phb.
 *                                   CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                   the mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                   the mapping of egress phb to dscp.
 *                                   CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                   the mapping of egress phb to exp.
 * @param [in]     profile_id      - an int value which means the mapping profile id and also the
 * index in hardware table.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping proile is not exist.
 * @return         CLX_E_NOT_SUPPORT        - Not support to delete the mapping profile.
 *                                            (eg. the mapping profile has been applied to a
 * port/vm/interface/tunnel and so on)
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_delUserProfile(const UI32_T unit,
                                      const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                      const UI32_T profile_id);

/**
 * @brief configure a priority mapping entry for user.
 *
 * Use this API to configure a mapping entry. User should set all fields needed according to the
 * "mapping_type" parameter in the entry.
 * If "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB, fields "pcp", "dei", "tc", "color",
 * must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_DSCP_TO_PHB, fields "dscp", "tc", "color",
 * must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_EXP_TO_PHB, fields "exp", "tc", "color".
 * If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI or CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 * fields "pcp", "dei", "tc", "color" must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_DSCP or CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP,
 * fields "dscp", "tc", "color" must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_EXP or CLX_QOS_MAPPING_DFLT_PHB_TO_EXP,
 * fields "exp", "tc", "color" must be input by user, and other fields must be ignored.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     mapping_type    - The type of the mapping profile.
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress
 * pcp/dei to phb.  CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb.
 *                                   CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp to
 * phb.  CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb to
 * dscp.                             CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI means the default mapping 
 * of egress phb to pcp/dei when packets untag in.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP means the mapping of egress phb 
 * to dscp when packets untag in.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_EXP means the mapping of egress phb 
 * to exp  when packets untag in.
 * @param [in]     profile_id       - An assigned number that represents the software profile ID and
 * the index of hardware table on this QoS mapping type. 
 * For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and 
 * CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profileId should set to 0.
 * @param [in]     ptr_entry       - The entry of the priority mapping.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping proile is not found.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_setUserProfileEntry(const UI32_T unit,
                                           const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                           const UI32_T profile_id,
                                           const CLX_QOS_MAPPING_ENTRY_T *ptr_entry);

/**
 * @brief get a priority mapping entry for user.
 *
 * Use this API to get a mapping entry.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mapping_type    - The type of the mapping profile.
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress
 * pcp/dei to phb.  CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb.
 *                                   CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp to
 * phb.  CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei.
 *                                   CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb to
 * dscp.  CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI means the default mapping 
 * of egress phb to pcp/dei when packets untag in.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP means the default mapping of 
 * egress phb to dscp when packets untag in.
 *                                   CLX_QOS_MAPPING_DFLT_PHB_TO_EXP means the default mapping of 
 * egress phb to exp  when packets untag in.
 * @param [in]     profile_id       - An assigned number that represents the software profile ID and
 * the index of hardware table on this QoS mapping type.
 * For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and 
 * CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profileId should set to 0.
 * @param [in]     ptr_entry       - The entry which to be obtained by user.
 *                                   If "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB, fields
 * "pcp" and "dei" are the input.  If "mapping_type" is CLX_QOS_MAPPING_DSCP_TO_PHB, fields
 * "dscp" is the input.  If "mapping_type" is CLX_QOS_MAPPING_EXP_TO_PHB, fields "exp" is the
 * input.  If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI, CLX_QOS_MAPPING_PHB_TO_DSCP,
 *                                   CLX_QOS_MAPPING_PHB_TO_EXP, CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 *                                  CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP or CLX_QOS_MAPPING_DFLT_PHB_TO_EXP,
 *                                  fields "tc", "color" are the input.
 * @param [out]    ptr_entry       - The entry which to be obtained by user.
 *                                   If "mapping_type" is
 *                                   CLX_QOS_MAPPING_PCP_DEI_TO_PHB, CLX_QOS_MAPPING_DSCP_TO_PHB
 *                                   or CLX_QOS_MAPPING_EXP_TO_PHB,  fields "tc" and "color" and
 * "sticky" are output.
 * If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI or CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 * fields "pcp" and "dei" are output. If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_DSCP or
 * CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP, fields "dscp" is output. If "mapping_type" is
 * CLX_QOS_MAPPING_PHB_TO_EXP or CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, fields "exp" is output.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping profileId is not exists.
 * @return         CLX_E_NOT_INITED         - SDK module has not been initialized.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_getUserProfileEntry(const UI32_T unit,
                                           const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                           const UI32_T profile_id,
                                           CLX_QOS_MAPPING_ENTRY_T *ptr_entry);

/**
 * @brief apply or unapply a priority mapping profile for user.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     intf_type           - Interface type: Local interface and L2 service interface.
 * @param [in]     mapping_type        - The type of the mapping profile.
 *                                       CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress
 * pcp/dei to phb CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb
 *                                       CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp
 * to phb CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei
 *                                       CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb
 * to dscp CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp
 * @param [in]     profile_id          - an int value which means the mapping profile id and aslo
 * the index in hardware table. 0 ~ 127: apply profile; CLX_QOS_INVALID_PROFILE_ID: cancel to apply
 * profile.
 * @param [in]     ptr_phb_prof_idx    - Pointer for the old phb_prof_idx in table L2_LCL_INTF or
 * L2_SRV_INTF.
 * @param [out]    ptr_phb_prof_idx    - qos module return a new phb_prof_idx to applier.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - NO more memory for apply.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_applyUserProfile(const UI32_T unit,
                                        const HAL_QOS_INTF_TYPE_T intf_type,
                                        const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                        UI32_T profile_id,
                                        UI32_T *ptr_phb_prof_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_allocateMappingProfileEntry(const UI32_T unit,
                                                   const UI32_T profile_id,
                                                   const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                                   const CLX_QOS_MAPPING_ENTRY_T *ptr_entry_array);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_freeMappingProfileEntry(const UI32_T unit,
                                               const UI32_T profile_id,
                                               const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                               const CLX_QOS_MAPPING_ENTRY_T *ptr_entry_array);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_setMappingProfileEntry(const UI32_T unit,
                                              const UI32_T profile_id,
                                              const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                              const CLX_QOS_MAPPING_ENTRY_T *ptr_entry_array);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_getUserProfileIdx(const UI32_T unit,
                                         const CLX_QOS_MAPPING_TYPE_T mapping_type,
                                         const UI32_T qos_prof_id,
                                         UI32_T *ptr_profile_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_allocAclQosProfile(const UI32_T unit,
                                          const CLX_ACL_QOS_ACTION_T acl_qos_action,
                                          UI32_T *ptr_profile_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_freeAclQosProfile(const UI32_T unit, const UI32_T profile_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_getAclQosProfile(const UI32_T unit,
                                        const UI32_T profile_id,
                                        CLX_ACL_QOS_ACTION_T *ptr_qos_action);
CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_deinitWarmboot(const UI32_T unit,
                                      HAL_IO_OBJ_META_T *ptr_wbdb_obj,
                                      UI32_T            *ptr_obj_count);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_initWarmboot(const UI32_T unit,
                                    HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_qos_initResource(const UI32_T unit);
#endif /* End of HAL_MT_NAMCHABARWA_QOS_H */
