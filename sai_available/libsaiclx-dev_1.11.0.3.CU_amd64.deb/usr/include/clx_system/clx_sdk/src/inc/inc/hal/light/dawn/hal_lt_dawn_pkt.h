/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_dawn_pkt.h
 * PURPOSE:
 *      It provides hal pkt module API.
 *
 * NOTES:
 *
 */

#ifndef HAL_LT_DAWN_PKT_H
#define HAL_LT_DAWN_PKT_H

/* INCLUDE FILE DECLARTIONS
 */
#include <light/dawn/hal_lt_dawn_pkt_knl.h>
#include <hal/hal_pkt_rsrc.h>
/*---------------------------------------------------------------------------*/
#if defined(CLX_EN_BIG_ENDIAN)
#define HAL_LT_DAWN_PKT_ENDIAN_SWAP32(val) (val)
#else
#define HAL_LT_DAWN_PKT_ENDIAN_SWAP32(val) CMLIB_UTIL_ENDIAN_SWAP32(val)
#endif
/*---------------------------------------------------------------------------*/
#define HAL_LT_DAWN_PKT_GET_BIT(flags, bit) ((((flags) & (bit)) > 0) ? 1 : 0)
/*---------------------------------------------------------------------------*/
#define HAL_LT_DAWN_PKT_GET_TX_INTR_TYPE(channel) (HAL_LT_INTR_TX_CH0 + channel)
#define HAL_LT_DAWN_PKT_GET_RX_INTR_TYPE(channel) (HAL_LT_INTR_RX_CH0 + channel)

/* ----------------------------------------------------------------------------------- PP Type */
typedef enum {
    HAL_LT_DAWN_PKT_TMH_SRV_L2 = 0,
    HAL_LT_DAWN_PKT_TMH_SRV_L25_MPLS,
    HAL_LT_DAWN_PKT_TMH_SRV_L3,
    HAL_LT_DAWN_PKT_TMH_SRV_EGR, /* L3 downgrade L2 */
    HAL_LT_DAWN_PKT_TMH_SRV_L25_NSH,
    HAL_LT_DAWN_PKT_TMH_SRV_L25_TRILL,
    HAL_LT_DAWN_PKT_TMH_SRV_LAST

} HAL_LT_DAWN_PKT_TMH_SRV_T;

typedef enum {
    HAL_LT_DAWN_PKT_TMH_DECAP_NONE = 0,
    HAL_LT_DAWN_PKT_TMH_DECAP_1_MPLS_LABEL,
    HAL_LT_DAWN_PKT_TMH_DECAP_2_MPLS_LABEL,
    HAL_LT_DAWN_PKT_TMH_DECAP_3_MPLS_LABEL,
    HAL_LT_DAWN_PKT_TMH_DECAP_4_MPLS_LABEL,
    HAL_LT_DAWN_PKT_TMH_DECAP_IP_TRILL_NSH,
    HAL_LT_DAWN_PKT_TMH_DECAP_LAST

} HAL_LT_DAWN_PKT_TMH_DECAP_T;

typedef struct {
    union {
        HAL_LT_DAWN_PKT_PPH_L2_T pph_l2;
        HAL_LT_DAWN_PKT_PPH_L3UC_T pph_l3uc;
        HAL_LT_DAWN_PKT_PPH_L3MC_T pph_l3mc;
        HAL_LT_DAWN_PKT_PPH_L25_T pph_l25;
    };
} HAL_LT_DAWN_PKT_PPH_T;

/* ----------------------------------------------------------------------------------- Reg Type */

typedef enum {
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_IOC = (0x1UL << 0),
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_CHKSUM = (0x1UL << 1),
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_PFC = (0x1UL << 2),
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_PKT_LEN_CHK = (0x1UL << 3),
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_EARLY_DONE_IRQ = (0x1UL << 4),
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_CHK_COS = (0x1UL << 5),
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_ADV_GPD_WRBK = (0x1UL << 6),
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_GPD_WRBK_FULL_PKT_LEN = (0x1UL << 7),
    HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_LAST = (0x1UL << 8)

} HAL_LT_DAWN_PKT_TX_CHANNEL_CFG_T;

typedef enum {
    HAL_LT_DAWN_PKT_RX_CHANNEL_CFG_IOC = (0x1UL << 0),
    HAL_LT_DAWN_PKT_RX_CHANNEL_CFG_CHKSUM = (0x1UL << 1),
    HAL_LT_DAWN_PKT_RX_CHANNEL_CFG_LAST = (0x1UL << 2)

} HAL_LT_DAWN_PKT_RX_CHANNEL_CFG_T;

/* ----------------------------------------------------------------------------------- Rx */
typedef enum {
    HAL_LT_DAWN_PKT_C_NEXT = 0, /* callback continuous */
    HAL_LT_DAWN_PKT_C_STOP = 1,
    HAL_LT_DAWN_PKT_C_OTHERS = 2
} HAL_LT_DAWN_PKT_CALLBACK_NO_T;

typedef HAL_LT_DAWN_PKT_CALLBACK_NO_T (*HAL_LT_DAWN_PKT_RX_FUNC_T)(
    const UI32_T unit,
    const void *ptr_sw_gpd, /* SW-GPD to be processed  */
    void *ptr_cookie);      /* Private data of SDK     */

typedef struct HAL_LT_DAWN_PKT_RX_CALLBACK_S {
    HAL_LT_DAWN_PKT_RX_FUNC_T callback; /* (unit, ptr_sw_gpd, ptr_cookie) */
    void *ptr_cookie;
    struct HAL_LT_DAWN_PKT_RX_CALLBACK_S *ptr_next;
} HAL_LT_DAWN_PKT_RX_CALLBACK_T;

/* ----------------------------------------------------------------------------------- Reg */
#if defined(CLX_EN_LITTLE_ENDIAN)

typedef union {
    UI32_T reg;
    struct {
        UI32_T tch_axlen_cfg : 3;
        UI32_T : 5;
        UI32_T tch_axi_free_arvalid : 1;
        UI32_T : 7;
        UI32_T tch_arvalid_thrhold_cfg : 2;
        UI32_T : 6;
        UI32_T tch_rready_low_4_hdr : 1;
        UI32_T tch_ios_crdt_add_en : 1;
        UI32_T : 6;
    } field;
} HAL_LT_DAWN_PKT_AXI_LEN_CFG_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T pdma_lbk_en : 1;
        UI32_T : 3;
        UI32_T pdma_lbk_plane : 2;
        UI32_T : 2;
        UI32_T pm_lbk_en : 1;
        UI32_T : 7;
        UI32_T pm_lbk_rqid : 6;
        UI32_T : 2;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_LBK_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T pdma_lbk_rqid0 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid1 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid2 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid3 : 6;
        UI32_T : 2;
    } field;
} HAL_LT_DAWN_PKT_LBK_RQID0_3_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T pdma_lbk_rqid4 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid5 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid6 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid7 : 6;
        UI32_T : 2;
    } field;
} HAL_LT_DAWN_PKT_LBK_RQID4_7_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T cos_pfc_sts0 : 8;
        UI32_T cos_pfc_sts1 : 8;
        UI32_T cos_pfc_sts2 : 8;
        UI32_T cos_pfc_sts3 : 8;
    } field;
} HAL_LT_DAWN_PKT_COS_PFC_STS_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T pdma_ela_en : 1;
        UI32_T : 7;
        UI32_T pdma_ela_valid_sel : 8;
        UI32_T : 8;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_ELA_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T pdma_ela_word0_sel : 8;
        UI32_T pdma_ela_word1_sel : 8;
        UI32_T pdma_ela_word2_sel : 8;
        UI32_T pdma_ela_word3_sel : 8;
    } field;
} HAL_LT_DAWN_PKT_ELA_SEL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T ingr_pln_ios_credit_base_size_lo : 8;
        UI32_T ingr_pln_ios_credit_base_size_hi : 8;
        UI32_T ingr_pln_ios_credit_set : 1;
        UI32_T : 7;
        UI32_T : 1;
        UI32_T ingr_pln_full_pkt_mode : 1;
        UI32_T : 6;
    } field;
} HAL_LT_DAWN_PKT_IGR_PLN_CREDIT_CFG_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T ingr_pln_cur_ios_credit_lo : 8;
        UI32_T ingr_pln_cur_ios_credit_hi : 8;
        UI32_T ingr_pln_ios_credit_ovfl : 1;
        UI32_T ingr_pln_ios_credit_udfl : 1;
        UI32_T : 6;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_IGR_PLN_CREDIT_STS_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T ingr_pln_ios_credit_rdy_lo_bound : 8;
        UI32_T ingr_pln_ios_credit_rdy_hi_bound : 8;
        UI32_T : 8;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_IGR_PLN_CREDIT_THR_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T rch_stomp_crc_en : 1;
        UI32_T : 7;
        UI32_T rch_crc_regen_en : 1;
        UI32_T : 7;
        UI32_T rch_pfc_fun_en : 1;
        UI32_T : 7;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_RCH_STOMP_CRC_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T rch_ioc_en : 1;
        UI32_T : 7;
        UI32_T rch_chksm_en : 1;
        UI32_T : 7;
        UI32_T : 8;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_RCH_MISC_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T rch_gpd_pfc_lo : 8;
        UI32_T rch_gpd_pfc_hi : 8;
        UI32_T : 8;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_RCH_GPD_PFC_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T rch_fifo_pfc_lo_lo : 8;
        UI32_T rch_fifo_pfc_lo_hi : 3;
        UI32_T : 5;
        UI32_T rch_fifo_pfc_hi_lo : 8;
        UI32_T rch_fifo_pfc_hi_hi : 3;
        UI32_T : 5;
    } field;
} HAL_LT_DAWN_PKT_RCH_FIFO_PFC_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T rch_cmdq_pfc_lo : 5;
        UI32_T : 3;
        UI32_T rch_cmdq_pfc_hi : 5;
        UI32_T : 3;
        UI32_T : 8;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_RCH_CMDQ_PFC_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T rch_fifo_ovf_drop_cnt_clr : 1;
        UI32_T rch_cmdq_ovf_drop_cnt_clr : 1;
        UI32_T rch_ovsz_drop_cnt_clr : 1;
        UI32_T rch_udsz_drop_cnt_clr : 1;
        UI32_T rch_pkterr_drop_cnt_clr : 1;
        UI32_T rch_flush_cnt_clr : 1;
        UI32_T : 2;
        UI32_T : 8;
        UI32_T : 8;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_RCH_CNT_CLR_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T rch_active : 1;
        UI32_T rch_avbl_gpd_pfc : 1;
        UI32_T rch_fifo_pfc : 1;
        UI32_T rch_cmdq_pfc : 1;
        UI32_T rch_pfc : 1;
        UI32_T : 3;
        UI32_T : 8;
        UI32_T rch_avbl_gpd_no_lo : 8;
        UI32_T rch_avbl_gpd_no_hi : 8;
    } field;
} HAL_LT_DAWN_PKT_RCH_STATUS_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T tch_ioc_en : 1;
        UI32_T tch_chksm_en : 1;
        UI32_T tch_pfc_en : 1;
        UI32_T tch_pktlen_chk_en : 1;
        UI32_T tch_early_done_irq : 1;
        UI32_T tch_chk_cos_en : 1;
        UI32_T tch_adv_gpd_wrbk : 1;
        UI32_T tch_gpd_wrbk_full_pkt_len : 1;
        UI32_T : 8;
        UI32_T : 8;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_TCH_CFG_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T tch_active : 1;
        UI32_T tch_pfc : 1;
        UI32_T tch_gpd_rd_dma_act : 1;
        UI32_T : 5;
        UI32_T : 8;
        UI32_T tch_avbl_gpd_no : 1;
        UI32_T : 7;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_TCH_STS_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T tch_gpd_dmar_qos : 4;
        UI32_T : 4;
        UI32_T tch_pkt_dmar_qos : 4;
        UI32_T : 4;
        UI32_T tch_gpd_dmaw_qos : 4;
        UI32_T : 4;
        UI32_T : 8;
    } field;
} HAL_LT_DAWN_PKT_TCH_QOS_CFG_REG_T;

#elif defined(CLX_EN_BIG_ENDIAN)

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 6;
        UI32_T tch_ios_crdt_add_en : 1;
        UI32_T tch_rready_low_4_hdr : 1;
        UI32_T : 6;
        UI32_T tch_arvalid_thrhold_cfg : 2;
        UI32_T : 7;
        UI32_T tch_axi_free_arvalid : 1;
        UI32_T : 5;
        UI32_T tch_axlen_cfg : 3;
    } field;
} HAL_LT_DAWN_PKT_AXI_LEN_CFG_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 2;
        UI32_T pm_lbk_rqid : 6;
        UI32_T : 7;
        UI32_T pm_lbk_en : 1;
        UI32_T : 2;
        UI32_T pdma_lbk_plane : 2;
        UI32_T : 3;
        UI32_T pdma_lbk_en : 1;
    } field;
} HAL_LT_DAWN_PKT_LBK_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 2;
        UI32_T pdma_lbk_rqid3 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid2 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid1 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid0 : 6;
    } field;
} HAL_LT_DAWN_PKT_LBK_RQID0_3_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 2;
        UI32_T pdma_lbk_rqid7 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid6 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid5 : 6;
        UI32_T : 2;
        UI32_T pdma_lbk_rqid4 : 6;
    } field;
} HAL_LT_DAWN_PKT_LBK_RQID4_7_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T cos_pfc_sts3 : 8;
        UI32_T cos_pfc_sts2 : 8;
        UI32_T cos_pfc_sts1 : 8;
        UI32_T cos_pfc_sts0 : 8;
    } field;
} HAL_LT_DAWN_PKT_COS_PFC_STS_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 8;
        UI32_T pdma_ela_valid_sel : 8;
        UI32_T : 7;
        UI32_T pdma_ela_en : 1;
    } field;
} HAL_LT_DAWN_PKT_ELA_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T pdma_ela_word3_sel : 8;
        UI32_T pdma_ela_word2_sel : 8;
        UI32_T pdma_ela_word1_sel : 8;
        UI32_T pdma_ela_word0_sel : 8;
    } field;
} HAL_LT_DAWN_PKT_ELA_SEL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 6;
        UI32_T ingr_pln_full_pkt_mode : 1;
        UI32_T : 1;
        UI32_T : 7;
        UI32_T ingr_pln_ios_credit_set : 1;
        UI32_T ingr_pln_ios_credit_base_size_hi : 8;
        UI32_T ingr_pln_ios_credit_base_size_lo : 8;
    } field;
} HAL_LT_DAWN_PKT_IGR_PLN_CREDIT_CFG_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 6;
        UI32_T ingr_pln_ios_credit_udfl : 1;
        UI32_T ingr_pln_ios_credit_ovfl : 1;
        UI32_T ingr_pln_cur_ios_credit_hi : 8;
        UI32_T ingr_pln_cur_ios_credit_lo : 8;
    } field;
} HAL_LT_DAWN_PKT_IGR_PLN_CREDIT_STS_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 8;
        UI32_T ingr_pln_ios_credit_rdy_hi_bound : 8;
        UI32_T ingr_pln_ios_credit_rdy_lo_bound : 8;
    } field;
} HAL_LT_DAWN_PKT_IGR_PLN_CREDIT_THR_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 7;
        UI32_T rch_pfc_fun_en : 1;
        UI32_T : 7;
        UI32_T rch_crc_regen_en : 1;
        UI32_T : 7;
        UI32_T rch_stomp_crc_en : 1;
    } field;
} HAL_LT_DAWN_PKT_RCH_STOMP_CRC_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 8;
        UI32_T : 7;
        UI32_T rch_chksm_en : 1;
        UI32_T : 7;
        UI32_T rch_ioc_en : 1;
    } field;
} HAL_LT_DAWN_PKT_RCH_MISC_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 8;
        UI32_T rch_gpd_pfc_hi : 8;
        UI32_T rch_gpd_pfc_lo : 8;
    } field;
} HAL_LT_DAWN_PKT_RCH_GPD_PFC_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 5;
        UI32_T rch_fifo_pfc_hi_hi : 3;
        UI32_T rch_fifo_pfc_hi_lo : 8;
        UI32_T : 5;
        UI32_T rch_fifo_pfc_lo_hi : 3;
        UI32_T rch_fifo_pfc_lo_lo : 8;
    } field;
} HAL_LT_DAWN_PKT_RCH_FIFO_PFC_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 8;
        UI32_T : 3;
        UI32_T rch_cmdq_pfc_hi : 5;
        UI32_T : 3;
        UI32_T rch_cmdq_pfc_lo : 5;
    } field;
} HAL_LT_DAWN_PKT_RCH_CMDQ_PFC_CTRL_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 8;
        UI32_T : 8;
        UI32_T : 2;
        UI32_T rch_flush_cnt_clr : 1;
        UI32_T rch_pkterr_drop_cnt_clr : 1;
        UI32_T rch_udsz_drop_cnt_clr : 1;
        UI32_T rch_ovsz_drop_cnt_clr : 1;
        UI32_T rch_cmdq_ovf_drop_cnt_clr : 1;
        UI32_T rch_fifo_ovf_drop_cnt_clr : 1;
    } field;
} HAL_LT_DAWN_PKT_RCH_CNT_CLR_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T rch_avbl_gpd_no_hi : 8;
        UI32_T rch_avbl_gpd_no_lo : 8;
        UI32_T : 8;
        UI32_T : 3;
        UI32_T rch_pfc : 1;
        UI32_T rch_cmdq_pfc : 1;
        UI32_T rch_fifo_pfc : 1;
        UI32_T rch_avbl_gpd_pfc : 1;
        UI32_T rch_active : 1;
    } field;
} HAL_LT_DAWN_PKT_RCH_STATUS_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 8;
        UI32_T : 8;
        UI32_T tch_gpd_wrbk_full_pkt_len : 1;
        UI32_T tch_adv_gpd_wrbk : 1;
        UI32_T tch_chk_cos_en : 1;
        UI32_T tch_early_done_irq : 1;
        UI32_T tch_pktlen_chk_en : 1;
        UI32_T tch_pfc_en : 1;
        UI32_T tch_chksm_en : 1;
        UI32_T tch_ioc_en : 1;
    } field;
} HAL_LT_DAWN_PKT_TCH_CFG_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 7;
        UI32_T tch_avbl_gpd_no : 1;
        UI32_T : 8;
        UI32_T : 5;
        UI32_T tch_gpd_rd_dma_act : 1;
        UI32_T tch_pfc : 1;
        UI32_T tch_active : 1;
    } field;
} HAL_LT_DAWN_PKT_TCH_STS_REG_T;

typedef union {
    UI32_T reg;
    struct {
        UI32_T : 8;
        UI32_T : 4;
        UI32_T tch_gpd_dmaw_qos : 4;
        UI32_T : 4;
        UI32_T tch_pkt_dmar_qos : 4;
        UI32_T : 4;
        UI32_T tch_gpd_dmar_qos : 4;
    } field;
} HAL_LT_DAWN_PKT_TCH_QOS_CFG_REG_T;

#else
#error "Host GPD endian is not defined\n"
#endif

/* ----------------------------------------------------------------------------------- CLX_EN_NETIF
 */
#if defined(CLX_EN_NETIF)
#define HAL_LT_DAWN_PKT_DRIVER_MAJOR_NUM (10)
#define HAL_LT_DAWN_PKT_DRIVER_MINOR_NUM (252) /* DO NOT use MISC_DYNAMIC_MINOR */
#define HAL_LT_DAWN_PKT_DRIVER_NAME      "clx_netif"
#define HAL_LT_DAWN_PKT_DRIVER_PATH      "/dev/" HAL_LT_DAWN_PKT_DRIVER_NAME
#endif

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* ----------------------------------------------------------------------------------- Debug APIs */
/**
 * @brief To dump the values of fields for the specified TX GPD.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_tx_gpd    - Pointer for the TX GPD
 * @return         CLX_E_OK    - Successfully dump the GPD content.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showTxPdmaGpd(const UI32_T unit,
                              const volatile HAL_LT_DAWN_PKT_TX_GPD_T *ptr_tx_gpd);

/**
 * @brief To display the PDMA TX control block of the target channel.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     channel      - The target channel
 * @param [in]     gpd_start    - The GPD start index
 * @param [in]     gpd_end      - The GPD end index
 * @return         CLX_E_OK    - Successfully display the control block.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showTxPdmaCtrlBlock(const UI32_T unit,
                                    const UI32_T channel,
                                    const UI32_T gpd_start,
                                    const UI32_T gpd_end);

/**
 * @brief To display the PDMA RX control block of the target channel.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     channel      - The target channel
 * @param [in]     gpd_start    - The GPD start index
 * @param [in]     gpd_end      - The GPD end index
 * @return         CLX_E_OK    - Successfully display the control block.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showRxPdmaCtrlBlock(const UI32_T unit,
                                    const UI32_T channel,
                                    const UI32_T gpd_start,
                                    const UI32_T gpd_end);

/**
 * @brief To display the PDMA generic registers.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Successfully display the control block.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showComReg(const UI32_T unit);

/**
 * @brief To display the PDMA TX registers.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     channel    - The target channel
 * @return         CLX_E_OK    - Successfully display the control block.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showTxReg(const UI32_T unit, const UI32_T channel);

/**
 * @brief To display the PDMA RX registers.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     channel    - The target channel
 * @return         CLX_E_OK    - Successfully display the control block.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showRxReg(const UI32_T unit, const UI32_T channel);

/**
 * @brief To display the PDMA registers.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     flags      - reg type flag
 * @param [in]     ptr_cookie - The target channel
 * @return         CLX_E_OK    - Successfully display the control block.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showReg(const UI32_T unit, const UI32_T flags, const void *ptr_cookie);

/**
 * @brief To display the PDMA control block of the target channel.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     flags        - The flags to assign pdma type
 * @param [in]     gpd_start    - The GPD start index
 * @param [in]     gpd_end      - The GPD end index
 * @param [in]     ptr_cookie   - The poniter to channel
 * @return         CLX_E_OK    - Successfully display the control block.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showPdmaCtrlBlock(const UI32_T unit,
                                  const UI32_T flags,
                                  const UI32_T gpd_start,
                                  const UI32_T gpd_end,
                                  const void *ptr_cookie);

/**
 * @brief To set a queue id to the specified RX channel.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     queue      - The target queue ID
 * @param [in]     channel    - The expected channel to which the queue mapped
 * @return         CLX_E_OK        - Successfully configure the mapping.
 * @return         CLX_E_OTHERS    - Configure the mapping failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_setQueueToRxChannel(const UI32_T unit, const UI32_T queue, const UI32_T channel);

/**
 * @brief To set a queue id to the specified RX channel.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     queue          - The target queue ID
 * @param [out]    ptr_channel    - Pointer for the channel to which the queue mapped
 * @return         CLX_E_OK        - Successfully obtain the mapping.
 * @return         CLX_E_OTHERS    - Obtain the mapping failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_getQueueToRxChannel(const UI32_T unit, const UI32_T queue, UI32_T *ptr_channel);

/**
 * @brief To set packet truncated size to the target RX queue.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     queue            - The target queue ID
 * @param [in]     truncate_size    - The expected packet truncated size
 * @return         CLX_E_OK        - Successfully configure the size.
 * @return         CLX_E_OTHERS    - Configure the size failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_setRxQueueTruncateSize(const UI32_T unit,
                                       const UI32_T queue,
                                       const UI32_T truncate_size);

/**
 * @brief To obatin the packet truncated size of the target RX queue.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     queue                - The target queue ID
 * @param [out]    ptr_truncate_size    - Pointer for the packet truncated size
 * @return         CLX_E_OK        - Successfully configure the size.
 * @return         CLX_E_OTHERS    - Configure the size failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_getRxQueueTruncateSize(const UI32_T unit,
                                       const UI32_T queue,
                                       UI32_T *ptr_truncate_size);

/**
 * @brief To map the specified CoS values to the target TX channel.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     channel       - The target TX channel
 * @param [in]     cos_bitmap    - bit 0~7 stand for CoS 0~7 respectively.
 * @return         CLX_E_OK        - Successfully configure the mapping.
 * @return         CLX_E_OTHERS    - Configure the mapping failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_setTxChannelCosBitmap(const UI32_T unit,
                                      const UI32_T channel,
                                      const UI8_T cos_bitmap);

/**
 * @brief To get the CoS mapped to the specified channel.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     channel           - The target TX channel
 * @param [out]    ptr_cos_bitmap    - Pointer for the CoS bitmap
 * @return         CLX_E_OK        - Successfully get the mapping.
 * @return         CLX_E_OTHERS    - Get the mapping failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_getTxChannelCosBitmap(const UI32_T unit,
                                      const UI32_T channel,
                                      UI8_T *ptr_cos_bitmap);

/**
 * @brief To display the PDMA TX counters of the target channel.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     channel    - The target channel
 * @return         CLX_E_OK    - Successfully display the counters.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showTxDbgCnt(const UI32_T unit, const UI32_T channel);

/**
 * @brief To display the PDMA RX counters of the target channel.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     channel    - The target channel
 * @return         CLX_E_OK    - Successfully display the counters.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_showRxDbgCnt(const UI32_T unit, const UI32_T channel);

/* ----------------------------------------------------------------------------------- Diag APIs */
/**
 * @brief To clear the PDMA RX counters of the target channel.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     channel    - The target channel
 * @param [in]     ptr_cnt    - Pointer for the counter
 * @return         CLX_E_OK                 - Successfully get the counter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The channel is invalid.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_getTxCnt(const UI32_T unit, const UI32_T channel, CLX_PKT_TX_CNT_T *ptr_cnt);

/**
 * @brief To get the PDMA RX counters of the target channel.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     channel    - The target channel
 * @param [in]     ptr_cnt    - Pointer for the counter
 * @return         CLX_E_OK                 - Successfully get the counter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The channel is invalid.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_getRxCnt(const UI32_T unit, const UI32_T channel, CLX_PKT_RX_CNT_T *ptr_cnt);

/**
 * @brief To clear the PDMA TX counters of the target channel.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     channel    - The target channel
 * @return         CLX_E_OK    - Successfully clear the counters.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_clearTxCnt(const UI32_T unit, const UI32_T channel);

/**
 * @brief To clear the PDMA RX counters of the target channel.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     channel    - The target channel
 * @return         CLX_E_OK    - Successfully clear the counters.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_clearRxCnt(const UI32_T unit, const UI32_T channel);

/**
 * @brief To enable or disable the PDMA loopback.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     enabled    - TRUE: Indicate to enable the PDMA loopback.
 * @return         CLX_E_OK        - Successfully set the configration.
 * @return         CLX_E_OTHERS    - Set the configration failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_setPdmaLoopback(const UI32_T unit, const BOOL_T enabled);

/* ----------------------------------------------------------------------------------- pkt_drv */
/* ----------------------------------------------------------------------------------- pkt_srv */
/**
 * @brief To transfer the packet form CPU to the switch.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     channel       - The target TX channel
 * @param [in]     ptr_tx_pkt    - Pointer for the TX packet
 * @return         CLX_E_OK    - Successfully transfer the packet.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_sendPacket(const UI32_T unit,
                           const UI32_T channel,
                           const CLX_PKT_TX_PKT_T *ptr_tx_pkt);

/**
 * @brief To invoke the user callback function for the RX packet.
 *
 * The packet will also be store in the packet monitor.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_sw_gpd    - Pointer for the SW Rx GPD link list
 * @param [in]     ptr_cookie    - The Rx callback cookie
 * @return         CLX_E_OK    - Successfully invoke the callback function.
 */
HAL_LT_DAWN_PKT_CALLBACK_NO_T
hal_lt_dawn_pkt_invokeRxUsrCallback(const UI32_T unit,
                                    HAL_LT_DAWN_PKT_RX_SW_GPD_T *ptr_sw_gpd,
                                    void *ptr_cookie);
/**
 * @brief To invoke the cpu forward callback function for the RX packet.
 *
 * The packet will also be store in the packet monitor.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_sw_gpd    - Pointer for the SW Rx GPD link list
 * @param [in]     ptr_cookie    - The Rx callback cookie
 * @return         CLX_E_OK    - Successfully invoke the callback function.
 */
HAL_LT_DAWN_PKT_CALLBACK_NO_T
hal_lt_dawn_pkt_forwardToCpuPkt(const UI32_T unit, const void *ptr_sw_gpd, void *ptr_cookie);

/* ----------------------------------------------------------------------------------- Rx Init */
/**
 * @brief To register a callback function for receiving RX GPD.
 *
 * @param [in]     unit          - The unit IDG
 * @param [in]     func          - The RX callback function
 * @param [in]     ptr_cookie    - The RX callback cookie
 * @param [in]     action        - To insert, append, delete or delete all
 * @return         CLX_E_OK        - Successfully register the callback.
 * @return         CLX_E_OTHERS    - Register the callback failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_setRxGpdCallback(const UI32_T unit,
                                 const HAL_LT_DAWN_PKT_RX_FUNC_T func,
                                 void *ptr_cookie,
                                 const HAL_PKT_RX_CALLBACK_ACTION_T action);

/**
 * @brief 1. To stop the Rx channel and deinit the Rx subsystem.
 *        2. To init the Rx subsystem and start the Rx channel.
 *        3. To restart the Rx subsystem
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_rx_cfg    - The user configuration
 * @return         CLX_E_OK        - Successfully configure the RX parameters.
 * @return         CLX_E_OTHERS    - Configure the parameter failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_setRxDrvConfig(const UI32_T unit, const CLX_PKT_RX_CFG_T *ptr_rx_cfg);

/**
 * @brief To get the Rx subsystem configuration.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_rx_cfg    - The user configuration
 * @return         CLX_E_OK        - Successfully configure the RX parameters.
 * @return         CLX_E_OTHERS    - Configure the parameter failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_getRxDrvConfig(const UI32_T unit, CLX_PKT_RX_CFG_T *ptr_rx_cfg);

/**
 * @brief To replace the Rx callback
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_rx_cfg    - The user configuration
 * @return         CLX_E_OK        - Successfully configure the RX parameters.
 * @return         CLX_E_OTHERS    - Configure the parameter failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_setRxConfig(const UI32_T unit, const CLX_PKT_RX_CFG_T *ptr_rx_cfg);

/**
 * @brief To get the Rx subsystem configuration.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_rx_cfg    - The user configuration
 * @return         CLX_E_OK        - Successfully configure the RX parameters.
 * @return         CLX_E_OTHERS    - Configure the parameter failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_getRxConfig(const UI32_T unit, CLX_PKT_RX_CFG_T *ptr_rx_cfg);

/**
 * @brief To register a callback function for receiving RX packet.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     flags         - The callback flags
 * @param [in]     action        - The callback list action
 * @param [in]     ptr_cookie   - The pointer for the private data
 * @return         CLX_E_OK        - Successfully register the callback.
 * @return         CLX_E_OTHERS    - Register the callback failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_setRxGpdCallbackList(const UI32_T unit,
                                     const UI32_T flags,
                                     HAL_PKT_RX_CALLBACK_ACTION_T action,
                                     void *ptr_cookie);

/* ----------------------------------------------------------------------------------- Deinit */
/**
 * @brief To de-initialize the packet module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Successfully de-initialize the packet module.
 * @return         CLX_E_OTHERS    - De-initialize the packet module failed.
 */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_deinit(const UI32_T unit);

/* ----------------------------------------------------------------------------------- NETIF APIs */
CLX_ERROR_NO_T
hal_lt_dawn_pkt_createIntf(const UI32_T unit, CLX_NETIF_INTF_T *ptr_net_intf, UI32_T *ptr_intf_id);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_destroyIntf(const UI32_T unit, const UI32_T id);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_getIntf(const UI32_T unit, const UI32_T id, CLX_NETIF_INTF_T *ptr_net_intf);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_createProfile(const UI32_T unit,
                              CLX_NETIF_PROFILE_T *ptr_net_profile,
                              UI32_T *ptr_profile_id);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_destroyProfile(const UI32_T unit, const UI32_T id);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_getProfile(const UI32_T unit,
                           const UI32_T id,
                           CLX_NETIF_PROFILE_T *ptr_net_profile);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_getIntfCnt(const UI32_T unit, const UI32_T id, CLX_NETIF_INTF_CNT_T *ptr_intf_cnt);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_clearIntfCnt(const UI32_T unit, const UI32_T id);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_setIntfProperty(const UI32_T unit,
                                const UI32_T intf_id,
                                const CLX_NETIF_INTF_PROPERTY_T property,
                                const UI32_T param0,
                                const UI32_T param1);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_getIntfProperty(const UI32_T unit,
                                const UI32_T port,
                                const CLX_NETIF_INTF_PROPERTY_T property,
                                UI32_T *ptr_param0,
                                UI32_T *ptr_param1);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_createNetlink(const UI32_T unit,
                              CLX_NETIF_NETLINK_T *ptr_netlink,
                              UI32_T *ptr_netlink_id);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_destroyNetlink(const UI32_T unit, const UI32_T netlink_id);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_getNetlink(const UI32_T unit, const UI32_T id, CLX_NETIF_NETLINK_T *ptr_netlink);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_dumpDb(const UI32_T unit, const UI32_T flags);

CLX_ERROR_NO_T
hal_lt_dawn_pkt_dumpReg(const UI32_T unit, const UI32_T flags);

void
hal_lt_dawn_pkt_convertVirtToPhy(const UI32_T unit, void *ptr_virt_addr, CLX_ADDR_T *ptr_phy_addr);

void
hal_lt_dawn_pkt_convertPhyToVirt(const UI32_T unit, CLX_ADDR_T phy_addr, void **pptr_virt_addr);
#endif /* End of HAL_LT_DAWN_PKT_H */
