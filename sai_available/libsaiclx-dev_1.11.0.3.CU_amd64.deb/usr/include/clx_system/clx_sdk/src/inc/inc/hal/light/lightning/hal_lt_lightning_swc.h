/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_lightning_swc.h
 * PURPOSE:
 *      API & special number for CL8570. For example: IEV, EMI.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_LT_LIGHTNING_SWC_H
#define HAL_LT_LIGHTNING_SWC_H

#include <clx_cfg.h>
#include <clx_swc.h>

#include <hal/hal_swc.h>

#define HAL_LT_LIGHTNING_SWC_EMI_BANK_NUM                (8)
#define HAL_LT_LIGHTNING_SWC_EMI_NSH_BANK_BASE           (HAL_LT_LIGHTNING_SWC_EMI_BANK_NUM - 1)
#define HAL_LT_LIGHTNING_SWC_PAGE_NUM_PER_BANK           (4)
#define HAL_LT_LIGHTNING_SWC_ILE_TCAM_BANK_NUM           (64)
#define HAL_LT_LIGHTNING_SWC_ILE_TCAM_ENTRY_NUM_PER_BANK (256)
#define HAL_LT_LIGHTNING_SWC_MASTER_DIE_ID               (4) /* t die */

#define HAL_LT_LIGHTNING_SWC_EPG_MAC_HDR_LEN (60)            /* bytes */
#define HAL_LT_LIGHTNING_SWC_EPG_MAC_MAX_IPG (1024)          /* register 10 bits */

#define HAL_SWC_MII_TDIE_ID          (4)
#define HAL_SWC_MAX_NODE_NUM_PER_DIE (4)

typedef struct {
    UI32_T node_count;
    I32_T thermal[HAL_SWC_MAX_NODE_NUM_PER_DIE];
} HAL_SWC_DIE_THERMAL_LIST_T;

/**
 * @brief Set CPI port enacp.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - CPI port.
 * @param [in]     ptr_encap_hdr    - Struture of encap.
 * @return         CLX_E_NOT_SUPPORT    - Not support.
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_setCpiEncap(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_SWC_CPI_ENCAP_HDR_T *ptr_encap_hdr);

/**
 * @brief Set CPI port enacp.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - CPI port.
 * @param [out]    ptr_encap_hdr    - Struture of encap.
 * @return         CLX_E_NOT_SUPPORT    - Not support.
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_getCpiEncap(const UI32_T unit,
                                 const UI32_T port,
                                 CLX_SWC_CPI_ENCAP_HDR_T *ptr_encap_hdr);

/**
 * @brief Init EPG user packet before feeding user configuration
 *
 * @param [out]    ptr_pkt    - EPG user packet
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_initEpgPkt(HAL_SWC_EPG_PKT_T *ptr_pkt);

/**
 * @brief Build EPG hardware buffer from user packet
 *
 * @param [in]     ptr_pkt    - EPG user packet
 * @param [in]     pad        - 1-byte padding after packet header
 * @param [in]     buf_len    - length of EPG hardware buffer
 * @param [out]    ptr_buf    - EPG hardware buffer
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_buildEpgBuf(const HAL_SWC_EPG_PKT_T *ptr_pkt,
                                 const UI32_T pad,
                                 const UI32_T buf_len,
                                 UI8_T *ptr_buf);

/**
 * @brief Set MAC EPG packet related configuration (header, payload, ipg, ...)
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     ptr_pkt    - Packet information to be sent
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_setEpgMacHw(const UI32_T unit, const HAL_SWC_EPG_PKT_T *ptr_pkt);

/**
 * @brief Trigger MAC EPG to send packets
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - EPG ingress port
 * @param [in]     lpbk    - 0: Traffic is sent to PP; 1: MAC loopback
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_sendEpgMacPkt(const UI32_T unit, const UI32_T port, const UI32_T lpbk);

/**
 * @brief Trigger MAC EPG to send packets
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - EPG ingress port
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_chkEpgMacDone(const UI32_T unit, const UI32_T port);

/**
 * @brief Stop MAC EPG from sending packets
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - EPG ingress port
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_stopEpgMacPkt(const UI32_T unit, const UI32_T port);

/**
 * @brief Get device information.
 *
 * @param [in]     unit               - Device unit number
 * @param [out]    ptr_device_info    - The device information
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_getDeviceInfo(const UI32_T unit, CLX_SWC_DEVICE_INFO_T *ptr_device_info);

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [out]    ptr_temperature_list    - Chip temperature list
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_swc_getChipTemperatureList(const UI32_T unit,
                                            CLX_SWC_THERMAL_LIST_T *ptr_temperature_list);
#endif
