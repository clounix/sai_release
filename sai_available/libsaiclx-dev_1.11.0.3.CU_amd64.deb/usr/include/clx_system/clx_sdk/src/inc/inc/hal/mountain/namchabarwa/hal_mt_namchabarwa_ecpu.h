/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_ecpu.h
 * PURPOSE:
 *  Provide HAL driver API functions of ecpu module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_ECPU_H
#define HAL_MT_NAMCHABARWA_ECPU_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_swc.h>
#include <hal/hal_ecpu.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO  DECLARATIONS
 */

#define HAL_MT_NAMCHABARWA_ECPU_ITCM_LOW_ADDR   (0)
#define HAL_MT_NAMCHABARWA_ECPU_ITCM_HI_ADDR    (0x100000)
#define HAL_MT_NAMCHABARWA_ECPU_DTCM_LOW_ADDR   (0x20000000)
#define HAL_MT_NAMCHABARWA_ECPU_DTCM_HI_ADDR    (0x20100000)
#define HAL_MT_NAMCHABARWA_ECPU_ITCMBASE        (0)
#define HAL_MT_NAMCHABARWA_ECPU_DTCMBASE        (0x20000000)
#define HAL_MT_NAMCHABARWA_ECPU_ITCMBASE_CHAIN  (0x51cbc00) /*The address of ITCM on the chain*/
#define HAL_MT_NAMCHABARWA_ECPU_DTCMBASE_CHAIN  (0x52cbc00) /*The address of DTCM on the chain*/
#define HAL_MT_NAMCHABARWA_EADDR2CHADDR(eaddr)  ((eaddr) - HAL_MT_NAMCHABARWA_ECPU_DTCMBASE + HAL_MT_NAMCHABARWA_ECPU_DTCMBASE_CHAIN)
#define HAL_MT_NAMCHABARWA_CHADDR2EADDR(chaddr) ((chaddr) - HAL_MT_NAMCHABARWA_ECPU_DTCMBASE_CHAIN + HAL_MT_NAMCHABARWA_ECPU_DTCMBASE)

#define HAL_MT_NAMCHABARWA_ECPU_PORT_MIN_BANDWIDTH      0
#define HAL_MT_NAMCHABARWA_ECPU_PORT_MIN_BURST_SIZE     0
#define HAL_MT_NAMCHABARWA_ECPU_PORT_MAX_BANDWIDTH      1000  //pps
#define HAL_MT_NAMCHABARWA_ECPU_PORT_MAX_BURST_SIZE     50

#define HAL_MT_NAMCHABARWA_TM_ECPU_QUEUE_NUM            8

/* DATA TYPE DECLARATIONS
 */

/* FUNCTION MACRO DECLARATIONS
 */
/**
 * @brief This API is used to init ecpu tx/rx hw information.
 *
 *
 * @param [in]    unit      - Device unit number
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_NOT_INITED       - Ecpu not started.
 * @return         CLX_E_OTHERS           - Failed to init hardware.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_hwInit(const UI32_T unit);

/**
 * @brief This API is used to reboot ecpu.
 *
 *
 * @param [in]    unit      - Device unit number
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_NOT_INITED       - Ecpu not started.
 * @return         CLX_E_OTHERS           - Failed to reboot.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_reboot(const UI32_T unit);

/**
 * @brief This API is used to stop ecpu of the specified unit.
 *
 *
 * @param [in]    unit      - Device unit number
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_OTHERS           - Failed to stop ecpu.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_stop(const UI32_T unit);

/**
 * @brief This API is used to read ecpu memory.
 *
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    addr      - Memory address.
 * @param [in]    len       - Memory length.
 * @param [in]    pbuf      - Buffer.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_OTHERS           - Failed to read memory.
 * @return         CLX_E_BAD_PARAMETER    - Parameters is invalid.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_readMem(const UI32_T unit,
                                const UI32_T addr,
                                const UI32_T len,
                                UI32_T *pbuf);

/**
 * @brief This API is used to upload fireware to ecpu sram and start ecpu.
 *
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    path      - Fireware file name.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_OTHERS           - Failed to upload fireware.
 * @return         CLX_E_BAD_PARAMETER    - Failed to open fireware file, maybe it doesn't exist.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_updateSramFw(const UI32_T unit, C8_T *path);

/**
 * @brief This API is used to register ecpu interrupt callback.
 *
 *
 * @param [in]    unit      - Device unit number.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_OTHERS           - Failed to register interrupt callback.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_registerIntr(const UI32_T unit);

/**
 * @brief This API is used to get diag log buffer information.
 *
 *
 * @param [out]    buf_info      - Buffer information pointer.
 * @return         CLX_E_OK               - Successfully.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_diagLogBufInfo(CLX_ECPU_DIAG_BUF_INFO_T *buf_info);

/**
 * @brief This API is used to get dtcm address.
 *
 *
 * @param [out]    addr      - Dtcm address pointer.
 * @return         CLX_E_OK               - Successfully.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_getDtcmAddr(UI64_T *addr);

/**
 * @brief This API is used to get dtcm on chain address.
 *
 *
 * @param [out]    addr      - Dtcm address pointer.
 * @return         CLX_E_OK               - Successfully.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_getDtcmOnChainAddr(UI64_T *addr);

/**
 * @brief This API is used to get itcm address.
 *
 *
 * @param [out]    addr      - Dtcm address pointer.
 * @return         CLX_E_OK               - Successfully.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_getItcmAddr(UI64_T *addr);

/**
 * @brief This API is used to get itcm on chain address.
 *
 *
 * @param [out]    addr      - Dtcm address pointer.
 * @return         CLX_E_OK               - Successfully.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_getItcmOnChainAddr(UI64_T *addr);

/**
 * @brief This API is used to set port limit.
 *
 *
 * @param [in]    unit      - Device unit number
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecpu_portLimit(const UI32_T unit);

#endif /* #ifndef HAL_MT_NAMCHABARWA_ECC_H */
