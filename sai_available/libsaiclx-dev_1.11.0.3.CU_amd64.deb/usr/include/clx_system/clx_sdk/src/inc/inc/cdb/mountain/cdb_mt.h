/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME: cdb_mt.h
 * PURPOSE:
 *     Chip database (CDB) driver
 * NOTES:
 */

#ifndef CDB_MT_H
#define CDB_MT_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
#define CDB_MT_TCAM_INDEX_OFFSET 0
#define CDB_MT_TCAM_INDEX_LEN    20
#define CDB_MT_TCAM_INST_OFFSET  20
#define CDB_MT_TCAM_INST_LEN     4

#define CDB_MT_FPU_INDEX_LEN 20

#define CDB_MT_HASH_INDEX_OFFSET 0
#define CDB_MT_HASH_INDEX_LEN    15
#define CDB_MT_HASH_TILE_OFFSET  15
#define CDB_MT_HASH_TILE_LEN     3
#define CDB_MT_HASH_STAGE_OFFSET 18
#define CDB_MT_HASH_STAGE_LEN    2
#define CDB_MT_HASH_INST_OFFSET  20
#define CDB_MT_HASH_INST_LEN     4

#define CDB_MT_DMA_FALSE 0
#define CDB_MT_DMA_TRUE  1

#define CDB_MT_FPU_SRAM_NUM_PER_SLICE (32 * 1024)

#define CDB_MT_MULTI_TBL_NUM 27

#define CDB_MT_FPU_HASH_CONFLICT_INDEX_OFFSET 24
#define CDB_MT_FPU_HASH_CONFLICT_INDEX_LEN    15

#define CDB_MT_HASH_GET_INSTID(entry_index, inst_id) \
    (inst_id = ((entry_index >> CDB_MT_HASH_INST_OFFSET) & ((1 << CDB_MT_HASH_INST_LEN) - 1)))

#define CDB_MT_HASH_GET_STAGEID(entry_index, stage_id) \
    (stage_id = ((entry_index >> CDB_MT_HASH_STAGE_OFFSET) & ((1 << CDB_MT_HASH_STAGE_LEN) - 1)))

#define CDB_MT_HASH_GET_TILEID(entry_index, tile_id) \
    (tile_id = ((entry_index >> CDB_MT_HASH_TILE_OFFSET) & ((1 << CDB_MT_HASH_TILE_LEN) - 1)))

#define CDB_MT_HASH_GET_INDEX(entry_index, index) \
    (index = ((entry_index >> CDB_MT_HASH_INDEX_OFFSET) & ((1 << CDB_MT_HASH_INDEX_LEN) - 1)))

#define CDB_MT_TCAM_GET_INSTID(entry_index, inst_id) \
    (inst_id = ((entry_index >> CDB_MT_TCAM_INST_OFFSET) & ((1 << CDB_MT_TCAM_INST_LEN) - 1)))

#define CDB_MT_TCAM_GET_INDEX(entry_index, index) \
    (index = ((entry_index >> CDB_MT_TCAM_INDEX_OFFSET) & ((1 << CDB_MT_TCAM_INDEX_LEN) - 1)))

#define CDB_MT_FPU_GET_IDX(entry_index, index) \
    (index = (entry_index & ((1 << CDB_MT_FPU_INDEX_LEN) - 1)))

#define CDB_MT_MULT_TBL_ENTRY_MAX(unit, table_id)         \
    (HAL_TBL_INFO((unit), (table_id))->entry_max_number * \
     HAL_TBL_INFO((unit), (table_id))->subinst_count)

#define CDB_MT_MULT_TBL_SUB_INST(unit, table_id, entry_id) \
    ((entry_id) / HAL_TBL_INFO((unit), (table_id))->entry_max_number)

#define CDB_MT_MULT_TBL_ENTRY_ID(unit, table_id, entry_id) \
    ((entry_id) % HAL_TBL_INFO((unit), (table_id))->entry_max_number)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    CDB_MT_PROC_CMST = 0,
    CDB_MT_PROC_PDMA,
    CDB_MT_PROC_ECPU,
    CDB_MT_PROC_LAST
} CDB_MT_PROC_TYPE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
_cdb_nb_index_logic2phy(const UI32_T unit,
                        const CDB_MEM_SERVICE_T *mem_service,
                        const UI32_T table_id,
                        const UI32_T entry_idx,
                        UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_nb_index_phy2logic(const UI32_T unit,
                        const CDB_MEM_SERVICE_T *mem_service,
                        const UI32_T table_id,
                        const UI32_T entry_idx,
                        UI32_T *ptr_entry_idx);

BOOL_T
_cdb_nb_index_isValid(const UI32_T unit, const UI32_T tbl_id, const UI32_T entry_idx);

CLX_ERROR_NO_T
cdb_nb_writeEntry(const UI32_T unit,
                  const UI32_T inst_idx,
                  const UI32_T subinst_idx,
                  const UI32_T table_id,
                  const UI32_T entry_idx,
                  const UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_nb_writeEntryWithCache(const UI32_T unit,
                            const UI32_T inst_idx,
                            const UI32_T subinst_idx,
                            const UI32_T table_id,
                            const UI32_T entry_idx,
                            const UI32_T *ptr_entry);

CLX_ERROR_NO_T
cdb_nb_readEntry(const UI32_T unit,
                 const UI32_T inst_idx,
                 const UI32_T subinst_idx,
                 const UI32_T table_id,
                 const UI32_T entry_idx,
                 UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_nb_modifyField(const UI32_T unit,
                    const UI32_T inst_idx,
                    const UI32_T subinst_idx,
                    const UI32_T table_id,
                    const UI32_T entry_idx,
                    const UI32_T field_id,
                    const UI32_T *ptr_field);

CLX_ERROR_NO_T
_cdb_nb_modifyUi32Field(const UI32_T unit,
                        const UI32_T inst_idx,
                        const UI32_T subinst_idx,
                        const UI32_T table_id,
                        const UI32_T entry_idx,
                        const UI32_T field_id,
                        const UI32_T field);

CLX_ERROR_NO_T
_cdb_nb_modifyMultiFields(const UI32_T unit,
                          const UI32_T inst_idx,
                          const UI32_T subinst_idx,
                          const UI32_T table_id,
                          const UI32_T entry_idx,
                          const UI32_T fvp_count,
                          const CDB_FVP_T *ptr_fvp);

CLX_ERROR_NO_T
_cdb_nb_readUi32Field(const UI32_T unit,
                      const UI32_T inst_idx,
                      const UI32_T subinst_idx,
                      const UI32_T table_id,
                      const UI32_T entry_idx,
                      const UI32_T field_id,
                      UI32_T *ptr_field);

CLX_ERROR_NO_T
_cdb_nb_addHashEntry(const UI32_T unit,
                     const UI32_T inst_idx,
                     const UI32_T subinst_idx,
                     const UI32_T bank_bmp,
                     const UI32_T table_id,
                     const UI32_T flag,
                     const UI32_T *ptr_entry,
                     UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_nb_updateHashEntry(const UI32_T unit,
                        const UI32_T inst_idx,
                        const UI32_T subinst_idx,
                        const UI32_T bank_bmp,
                        const UI32_T table_id,
                        const UI32_T flag,
                        const UI32_T *ptr_entry,
                        UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_nb_lookupHashEntry(const UI32_T unit,
                        const UI32_T inst_idx,
                        const UI32_T subinst_idx,
                        const UI32_T bank_bmp,
                        const UI32_T table_id,
                        UI32_T *ptr_entry,
                        UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
_cdb_nb_delHashEntry(const UI32_T unit,
                     const UI32_T inst_idx,
                     const UI32_T subinst_idx,
                     const UI32_T bank_bmp,
                     const UI32_T table_id,
                     const UI32_T *ptr_entry,
                     UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
cdb_nb_dma_writeEntry(const UI32_T unit,
                      const UI32_T inst_idx,
                      const UI32_T subinst_idx,
                      const UI32_T bank_bmp,
                      const UI32_T table_id,
                      const UI32_T entry_idx,
                      const UI32_T entry_num,
                      UI32_T *ptr_entry);

CLX_ERROR_NO_T
cdb_nb_dma_readEntry(const UI32_T unit,
                     const UI32_T inst_idx,
                     const UI32_T subinst_idx,
                     const UI32_T bank_bmp,
                     const UI32_T table_id,
                     const UI32_T entry_idx,
                     const UI32_T entry_num,
                     UI32_T *ptr_entry);

CLX_ERROR_NO_T
_cdb_nb_copyTable(const UI32_T unit,
                  const UI32_T inst_idx,
                  const UI32_T subinst_idx,
                  const UI32_T table_id,
                  const UI32_T src_entry_idx,
                  const UI32_T dst_entry_idx,
                  const UI32_T entry_num);

CLX_ERROR_NO_T
cdb_nb_resetTable(const UI32_T unit,
                  const UI32_T inst_idx,
                  const UI32_T subinst_idx,
                  const UI32_T table_id,
                  const UI32_T *ptr_entry);

void
_cdb_nb_calculate_nsquare_align(const UI32_T unit, UI32_T entry_len, UI32_T *entry_len_align);

CLX_ERROR_NO_T
_cdb_nb_set_entryValid(const UI32_T unit,
                       const UI32_T inst_idx,
                       const UI32_T subinst_idx,
                       const UI32_T table_id,
                       const UI32_T entry_idx,
                       const BOOL_T entry_valid);
/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

CLX_ERROR_NO_T
cdb_nb_mem_check(const UI32_T unit,
                 const UI32_T inst_idx,
                 const UI32_T subinst_idx,
                 const UI32_T bank_bmp,
                 const UI32_T table_id,
                 const UI32_T entry_idx,
                 const UI32_T entry_num,
                 const UI32_T *ptr_entry);

CLX_ERROR_NO_T
cdb_nb_mem_dma_check(const UI32_T unit,
                     const UI32_T inst_idx,
                     const UI32_T subinst_idx,
                     const UI32_T bank_bmp,
                     const UI32_T table_id,
                     const UI32_T entry_idx,
                     const UI32_T entry_num,
                     UI32_T *ptr_entry);

#endif /* End of CDB_H */
