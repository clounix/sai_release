/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_lightning_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_LT_LIGHTNING_PORT_H
#define HAL_LT_LIGHTNING_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS */

/**
 * @brief This API is used to set the mapping between unit/port and mac/lane
 *        number.
 *
 * This API is suggested to be used during SDK initialization.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [in]     eth_macro    - eth ball MAC macro ID
 * @param [in]     lane         - eth lane ID
 * @param [in]     max_speed    - The maximum speed of the physical port
 * @param [in]     flags        - Attributes of the physical port
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_lightning_port_setLaneMap(const UI32_T unit,
                                 const UI32_T port,
                                 const UI32_T eth_macro,
                                 const UI32_T lane,
                                 const CLX_PORT_SPEED_T max_speed,
                                 const UI32_T flags);

/**
 * @brief This API is used to get the mapping between unit/port and mac/lane
 *        number.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port             - Physical port ID
 * @param [out]    ptr_eth_macro    - eth ball macro ID
 * @param [out]    ptr_lane         - eth lane ID
 * @param [out]    ptr_max_speed    - The maximum speed of the physical port
 * @param [out]    ptr_flags        - Attributes of the physical port
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_lightning_port_getLaneMap(const UI32_T unit,
                                 const UI32_T port,
                                 UI32_T *ptr_eth_macro,
                                 UI32_T *ptr_lane,
                                 CLX_PORT_SPEED_T *ptr_max_speed,
                                 UI32_T *ptr_flags);

#endif /* #ifndef HAL_LT_LIGHTNING_PORT_H */
