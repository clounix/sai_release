/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_lightning_up.h
 * PURPOSE:
 *      1. It provides uP download API.
 *
 * NOTES:
 *
 */

#ifndef HAL_LT_LIGHTNING_UP_H
#define HAL_LT_LIGHTNING_UP_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum name {
    HAL_LT_LIGHTNING_UP_DCE,
    HAL_LT_LIGHTNING_UP_PSYST,
    HAL_LT_LIGHTNING_UP_PSYSP,
    HAL_LT_LIGHTNING_UP_ETHX,
    HAL_LT_LIGHTNING_UP_ETHL,
    HAL_LT_LIGHTNING_UP_LAST
} HAL_LT_LIGHTNING_UP_TYPE_T;

typedef struct {
    UI32_T M0_CMN_BG_V2VTRIM : 5;
    UI32_T M0_CMN_BG_V2ITRIM : 5;
    UI32_T M0_CMN_BG_PTATTRIM : 5;
    UI32_T resv_15 : 1;
    UI32_T M0_TX_L0_RESCAL : 2;
    UI32_T M0_TX_L1_RESCAL : 2;
    UI32_T M0_TX_L2_RESCAL : 2;
    UI32_T M0_TX_L3_RESCAL : 2;
    UI32_T M0_RX_L0_RTERM_CTRL : 4;
    UI32_T M0_RX_L1_RTERM_CTRL : 4;
    UI32_T M0_RX_L2_RTERM_CTRL : 4;
    UI32_T M0_RX_L3_RTERM_CTRL : 4;
    UI32_T resv_8 : 8;
    UI32_T M1_CMN_BG_V2VTRIM : 5;
    UI32_T M1_CMN_BG_V2ITRIM : 5;
    UI32_T M1_CMN_BG_PTATTRIM : 5;
    UI32_T resv_31 : 1;
    UI32_T M1_TX_L0_RESCAL : 2;
    UI32_T M1_TX_L1_RESCAL : 2;
    UI32_T M1_TX_L2_RESCAL : 2;
    UI32_T M1_TX_L3_RESCAL : 2;
    UI32_T M1_RX_L0_RTERM_CTRL : 4;
    UI32_T M1_RX_L1_RTERM_CTRL : 4;
    UI32_T M1_RX_L2_RTERM_CTRL : 4;
    UI32_T M1_RX_L3_RTERM_CTRL : 4;
    UI32_T resv_24 : 8;
} HAL_LT_LIGHTNING_UP_ETHL_EFUSE_T;

typedef struct {
    UI32_T CMN_BG_V2VTRIM : 5;
    UI32_T CMN_BG_V2ITRIM : 5;
    UI32_T CMN_BG_PTATTRIM : 5;
    UI32_T resv_15 : 1;
    UI32_T TX_L0_RESCAL : 2;
    UI32_T TX_L1_RESCAL : 2;
    UI32_T RX_L0_RTERM_CTRL : 4;
    UI32_T RX_L1_RTERM_CTRL : 4;
    UI32_T resv_28 : 4;
} HAL_LT_LIGHTNING_UP_ETHX_EFUSE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Download Pdie Serdes uP FW.
 *
 * @param [in]     unit    - unit index
 *                           die_idx     -- die_id
 * @return         CLX_E_OK        - download success.
 * @return         CLX_E_OTHERS    - download fail.
 */
CLX_ERROR_NO_T
hal_lt_lightning_up_initEthlSerdesUp(const UI32_T unit, const UI32_T die_idx);

CLX_ERROR_NO_T
hal_lt_lightning_up_setEthlSerdesUpHalt(const UI32_T unit, const UI32_T die_idx);

/**
 * @brief Download Tdie Serdes uP FW.
 *
 * @param [in]     unit    - unit index
 * @return         CLX_E_OK        - download success.
 * @return         CLX_E_OTHERS    - download fail.
 */
CLX_ERROR_NO_T
hal_lt_lightning_up_initEthxSerdesUp(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_lightning_up_setEthxSerdesUpHalt(const UI32_T unit);

/**
 * @brief Download Tdie port uP FW.
 *
 * @param [in]     unit    - unit index
 * @return         CLX_E_OK        - download success.
 * @return         CLX_E_OTHERS    - download fail.
 */
CLX_ERROR_NO_T
hal_lt_lightning_up_initPsystUp(const UI32_T unit);

/**
 * @brief Download Tdie port uP FW.
 *
 * @param [in]     unit    - unit index
 * @return         CLX_E_OK        - download success.
 * @return         CLX_E_OTHERS    - download fail.
 */
CLX_ERROR_NO_T
hal_lt_lightning_up_initPsystUpRov(const UI32_T unit);

/**
 * @brief Download Pdie port uP FW.
 *
 * @param [in]     unit       - unit index
 * @param [in]     die_idx    - die index
 * @return         CLX_E_OK        - download success.
 * @return         CLX_E_OTHERS    - download fail.
 */
CLX_ERROR_NO_T
hal_lt_lightning_up_initPsyspUp(const UI32_T unit, const UI32_T die_idx);

/**
 * @brief Notify psyst that psysp is ready for access (link status/link speed/mac activity)
 *
 * @param [in]     unit       - unit index
 * @param [in]     die_idx    - die index
 * @return         CLX_E_OK        - sync psysp ready pattern success.
 * @return         CLX_E_OTHERS    - sync psysp ready pattern fail.
 */
CLX_ERROR_NO_T
hal_lt_lightning_up_syncPsyspUpReady(const UI32_T unit, const UI32_T die_idx);

/**
 * @brief Download DCE uP FW.
 *
 * @param [in]     unit    - unit index
 * @param [in]     idx     - uP index:
 *                           Index 0 - for DMA uP
 *                           Index 1 - for ZC uP
 * @return         CLX_E_OK        - download success.
 * @return         CLX_E_OTHERS    - download fail.
 */
CLX_ERROR_NO_T
hal_lt_lightning_up_initDceUp(const UI32_T unit, const UI32_T idx);

/**
 * @brief Deinit DCE uP FW.
 *
 * @param [in]     unit    - unit index
 * @return         CLX_E_OK        - Deinit success.
 * @return         CLX_E_OTHERS    - Deinit fail.
 */
CLX_ERROR_NO_T
hal_lt_lightning_up_deinitDceUp(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_lightning_up_resetTdieUp(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_lightning_up_resetPdieUp(const UI32_T unit, const UI32_T die_idx);

#endif /* HAL_LT_LIGHTNING_UP_H */
