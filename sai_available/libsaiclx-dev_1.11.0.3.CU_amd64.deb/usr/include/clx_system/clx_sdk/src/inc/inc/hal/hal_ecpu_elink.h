/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecpu_elink.h
 * PURPOSE:
 *  1. Provide elink module macros and data structures.
 */

#ifndef HAL_ECPU_ELINK_H
#define HAL_ECPU_ELINK_H

/* INCLUDE FILE DECLARATIONS
 */
#ifdef CONFIG_ECPU_SIDE
#include "hal_ecpu_ringbuffer.h"
#else
#include "hal/hal_ecpu_ringbuffer.h"
#endif
/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_ELINK_MSG_DATA_START (1 << 0)
#define HAL_ELINK_MSG_DATA_END   (1 << 1)
#define HAL_ELINK_MSG_DATA_WHOLE (HAL_ELINK_MSG_DATA_START | HAL_ELINK_MSG_DATA_END)
#ifdef CONFIG_ECPU_SIDE
#define HAL_ELINK_KA_TIMEOUT (1)        /*second*/
#else
#define HAL_ELINK_KA_TIMEOUT     (1000) /*ms*/
#define HAL_ELINK_WAIT_UP_PERIOD (2000) /*2ms*/
#define HAL_ELINK_WAIT_UP_MAX    (3000)
#define HAL_ELINK_RSP_TIMEOUT    (1000 * 1000)  /* 1S */

CLX_ERROR_NO_T
hal_elink_rx_irq_handler(UI32_T unit);
#endif
#define HAL_ELINK_KA_MAXCNT       (3)
#define HAL_ELINK_WAITACK_TIMEOUT (5)
#define HAL_ELINK_SENDTYPE_CTRL   (1 << 0)
#define HAL_ELINK_SENDTYPE_KA     (1 << 1)
#define HAL_ELINK_SENDTYPE_DATA   (1 << 2)
#define HAL_ELINK_CFG_QUE_LEN     (128)

#define HAL_ELINK_RX_CNT_INCR(unit)         (_elink_statistics[(unit)].rx_cnt++)
#define HAL_ELINK_RX_KEEP_INCR(unit)        (_elink_statistics[(unit)].rx_keep++)
#define HAL_ELINK_RX_ACK_INCR(unit)         (_elink_statistics[(unit)].rx_ack++)
#define HAL_ELINK_RX_DISCNT_INCR(unit)      (_elink_statistics[(unit)].rx_discnt++)
#define HAL_ELINK_RX_PKT_INCR(unit)         (_elink_statistics[(unit)].rx_pkt++)
#define HAL_ELINK_RX_DROP_CNT_INCR(unit)    (_elink_statistics[(unit)].rx_drop_cnt++)
#define HAL_ELINK_RX_DROP_KEEP_INCR(unit)   (_elink_statistics[(unit)].rx_drop_keep++)
#define HAL_ELINK_RX_DROP_ACK_INCR(unit)    (_elink_statistics[(unit)].rx_drop_ack++)
#define HAL_ELINK_RX_DROP_DISCNT_INCR(unit) (_elink_statistics[(unit)].rx_drop_discnt++)
#define HAL_ELINK_RX_DROP_PKT_INCR(unit)    (_elink_statistics[(unit)].rx_drop_pkt++)

#define HAL_ELINK_TX_CNT_INCR(unit)         (_elink_statistics[(unit)].tx_cnt++)
#define HAL_ELINK_TX_KEEP_INCR(unit)        (_elink_statistics[(unit)].tx_keep++)
#define HAL_ELINK_TX_ACK_INCR(unit)         (_elink_statistics[(unit)].tx_ack++)
#define HAL_ELINK_TX_DISCNT_INCR(unit)      (_elink_statistics[(unit)].tx_discnt++)
#define HAL_ELINK_TX_PKT_INCR(unit)         (_elink_statistics[(unit)].tx_pkt++)
#define HAL_ELINK_TX_DROP_CNT_INCR(unit)    (_elink_statistics[(unit)].tx_drop_cnt++)
#define HAL_ELINK_TX_DROP_KEEP_INCR(unit)   (_elink_statistics[(unit)].tx_drop_keep++)
#define HAL_ELINK_TX_DROP_ACK_INCR(unit)    (_elink_statistics[(unit)].tx_drop_ack++)
#define HAL_ELINK_TX_DROP_DISCNT_INCR(unit) (_elink_statistics[(unit)].tx_drop_discnt++)
#define HAL_ELINK_TX_DROP_PKT_INCR(unit)    (_elink_statistics[(unit)].tx_drop_pkt++)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum elink_machine_id {
    HAL_ELINK_MACHINE_ID_HOSTCPU,
    HAL_ELINK_MACHINE_ID_ECPU1,
    HAL_ELINK_MACHINE_ID_ECPU2,
    HAL_ELINK_MACHINE_ID_LAST
} HAL_ELINK_MACHINE_ID_T;

typedef enum elink_fsm_status {
    HAL_ELINK_FSM_INIT,
    HAL_ELINK_FSM_WAIT_ACK,
    HAL_ELINK_FSM_WAIT_CONNECT,
    HAL_ELINK_FSM_ESTABLISHED,
    HAL_ELINK_FSM_DISCONNECTED,
    HAL_ELINK_FSM_LAST
} HAL_ELINK_FSM_STATUS_T;

typedef enum elink_event {
    HAL_ELINK_EVENT_START,
    HAL_ELINK_EVENT_CNT_SEND,
    HAL_ELINK_EVENT_CNT_RCV,
    HAL_ELINK_EVENT_ACK,
    HAL_ELINK_EVENT_DISCNT,
    HAL_ELINK_EVENT_LAST
} HAL_ELINK_EVENT_T;

typedef struct elink_fsm {
    HAL_ELINK_FSM_STATUS_T fsm;
    UI16_T seq_id; /*sequence*/
} HAL_ELINK_FSM_T;

typedef enum elink_msg_type {
    HAL_ELINK_MSG_TYPE_CONNECT,    /*connect message*/
    HAL_ELINK_MSG_TYPE_DISCONNECT, /*disconnect message*/
    HAL_ELINK_MSG_TYPE_KA,         /*keep alive message*/
    HAL_ELINK_MSG_TYPE_DATA,       /*data message*/
    HAL_ELINK_MSG_TYPE_ACK,
    HAL_ELINK_MSG_TYPE_LAST
} HAL_ELINK_MSG_TYPE_T;

typedef enum elink_media_type {
    HAL_ELINK_MEDIA_TYPE_REGISTER,
    HAL_ELINK_MEDIA_TYPE_DTCM,
    HAL_ELINK_MEDIA_TYPE_ITCM
} HAL_ELINK_MEDIA_TYPE_T;

typedef struct elink_keepalive {
    UI16_T timeout_cnt;
    UI16_T time; /*Wait for ack time*/
#ifdef CONFIG_ECPU_SIDE
    struct k_timer timer;
#else
    OSAL_TIMER_ID_T timer;
#endif
    UI16_T seq_id;
} HAL_ELINK_KA_T;

typedef struct elink_cache {
    CLX_ELINK_MSG_HDR_T *pmsg;
    UI32_T offset;
    UI32_T len;
} HAL_ELINK_CACHE_T;

typedef struct elink_cb {
    UI8_T local_id;
    UI8_T remote_id;
    UI16_T seq_id;
    HAL_ELINK_FSM_T elink_fsm;
#ifdef CONFIG_ECPU_SIDE
    struct k_timer timer; /*for elink connect*/
#endif
    HAL_ELINK_KA_T ka;    /*keep alive*/
    HAL_ELINK_CACHE_T cache;
    HAL_RING_CTL_T rxbuf;
    HAL_RING_CTL_T txbuf;
    UI32_T unit;
    UI8_T sendtype;
    UI8_T init;
} HAL_ELINK_CB_T;

typedef struct elink_app_entry {
    UI8_T app_id;
    UI16_T valid;
    CLX_ELINK_QUEUE_T *pqueue;
    CLX_APP_DEINIT_FUNC_T deinit;
} HAL_ELINK_APP_ENTRY_T;

typedef struct elink_app_control {
    HAL_ELINK_APP_ENTRY_T app_vec[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_ECPU_ELINK_MAX_APP];
#ifdef CONFIG_ECPU_SIDE
    struct k_sem sem;
#else
    CLX_SEMAPHORE_ID_T sem;
#endif
    UI32_T init_done;
    I32_T num[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
    UI32_T map[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_ECPU_ELINK_MAX_APP];
} HAL_ELINK_APP_CB_T;

typedef struct elink_statistics {
    UI64_T rx_cnt;
    UI64_T rx_keep;
    UI64_T rx_ack;
    UI64_T rx_discnt;
    UI64_T rx_pkt; /*data*/
    UI64_T rx_drop_cnt;
    UI64_T rx_drop_keep;
    UI64_T rx_drop_ack;
    UI64_T rx_drop_discnt;
    UI64_T rx_drop_pkt;

    UI64_T tx_cnt;
    UI64_T tx_keep;
    UI64_T tx_ack;
    UI64_T tx_discnt;
    UI64_T tx_pkt; /*data*/
    UI64_T tx_drop_cnt;
    UI64_T tx_drop_keep;
    UI64_T tx_drop_ack;
    UI64_T tx_drop_discnt;
    UI64_T tx_drop_pkt;
} HAL_ELINK_STAT_T;

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */
extern HAL_ELINK_STAT_T _elink_statistics[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to process received message.
 *
 *
 * @param [in]    pelk_cb    - Elink control block
 * @param [in]    pmsg       - Message pointer
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_procRxMsg(HAL_ELINK_CB_T *pelk_cb, CLX_ELINK_MSG_HDR_T *pmsg);

/**
 * @brief This API is used to get elink control block.
 *
 *
 * @param [in]     unit     - Device unit number
 * @return         HAL_ELINK_CB_T *       - Elink control block.
 */
HAL_ELINK_CB_T *
hal_elink_getElinkCb(const UI32_T unit);

/**
 * @brief This API is used to get application control block.
 *
 *
 * @param [in]     void  - void
 * @return         HAL_ELINK_APP_CB_T *       - Alapplication elink control block.
 */
HAL_ELINK_APP_CB_T *
hal_elink_getAppTable(void);

/**
 * @brief This API is used to encape message header and data header.
 *
 *
 * @param [in]    pelk_cb    - Elink control block
 * @param [in]    type       - Elink message type
 * @param [in]    app_id     - Application id
 * @param [in]    len        - Message length
 * @param [out]   pehdr      - Message elink common header pointer
 *
 * @return
 */
void
hal_elink_encapMsgHdr(HAL_ELINK_CB_T *pelk_cb,
                      const CLX_ELINK_DATAMSG_TYPE_T type,
                      const UI8_T app_id,
                      const UI16_T len,
                      CLX_ELINK_HDR_T *pehdr);

/**
 * @brief This API is used to get elink statistics.
 *
 *
 * @param [in]     unit     - Device unit number
 *
 * @return         HAL_ELINK_STAT_T *       - Elink statistics control block.
 */
HAL_ELINK_STAT_T *
hal_elink_getStatistics(const UI32_T unit);

/**
 * @brief This API is used to clear elink statistics.
 *
 *
 * @param [in]     unit     - Device unit number
 *
 * @return
 */
void
hal_elink_clearStatistics(UI32_T unit);

/**
 * @brief This API is used to get receive message channel data pointer index.
 *
 *
 * @param [in]     unit       - Device unit number
 * @param [out]    prindex    - Read point index
 * @param [out]    pwindex    - Write point index
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_getRxRWIdx(const UI32_T unit, UI32_T *prindex, UI32_T *pwindex);

/**
 * @brief This API is used to get send message channel data pointer index.
 *
 *
 * @param [in]     unit       - Device unit number
 * @param [out]    prindex    - Read point index
 * @param [out]    pwindex    - Write point index
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_getTxRWIdx(const UI32_T unit, UI32_T *prindex, UI32_T *pwindex);

/**
 * @brief This API is used to reset elink module.
 *
 *
 * @param [in]     unit       - Device unit number
 *
 * @return
 */
void
hal_elink_reset(const UI32_T unit);

/**
 * @brief This API is used to wait elink up.
 *
 *
 * @param [in]     unit       - Device unit number
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_waitUp(const UI32_T unit);

/**
 * @brief This API is used to init elink module.
 *
 *
 * @param [in]     unit       - Device unit number
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_init(const UI32_T unit);

/**
 * @brief This API is used to deinit elink module.
 *
 *
 * @param [in]     unit       - Device unit number
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_deinit(const UI32_T unit);

/**
 * @brief This API is used to register notify message queue.
 *
 *
 * @param [in]     pqueue       - Queue handler
 *
 * @return
 */
void
hal_elink_registerNotifyQue(CLX_ELINK_QUEUE_T *pqueue);

/**
 * @brief This API is used to unregister notify message queue.
 *
 *
 * @param [in] void   - void
 *
 * @return
 */
void
hal_elink_unregisterNotifyQue(void);

/**
 * @brief This API is used to dequeue the message from elink queue.
 *
 *
 * @param [in]     pqueue       - Queue handler
 * @param [out]    ppmsg        - Message pointer
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_dequeueInfo(CLX_ELINK_QUEUE_T *pqueue, void **ppmsg);

/**
 * @brief This API is used to dequeue the message from elink queue.
 *
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     pqueue       - Queue handler
 * @param [out]    ppmsg        - Message pointer
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_dequeueInfo_with_unit(UI32_T *unit, CLX_ELINK_QUEUE_T *pqueue, void **ppmsg);

/**
 * @brief This API is used to enqueue the message from elink queue.
 *
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     pqueue       - Queue handler
 * @param [in]     pmsg         - Message pointer
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_enqueueInfo(const UI32_T unit, CLX_ELINK_QUEUE_T *pqueue, void *pmsg);

#endif
