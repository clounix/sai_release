/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/**
 * @brief Namchabarwa PL defines.
 *
 * @file hal_mt_namchabarwa.h
 *
 */

#ifndef __HAL_MT_NAMCHABARWA_PL_H__
#define __HAL_MT_NAMCHABARWA_PL_H__

#include <api/diag.h>
#include <math.h>

#define HAL_MT_NAMCHABARWA_DP0_ETH_PORT_MIN   0
#define HAL_MT_NAMCHABARWA_DP0_ETH_PORT_MAX   15
#define HAL_MT_NAMCHABARWA_DP1_ETH_PORT_MIN   16
#define HAL_MT_NAMCHABARWA_DP1_ETH_PORT_MAX   31
#define HAL_MT_NAMCHABARWA_ETH_PORT_PER_SLICE 32
#define HAL_MT_NAMCHABARWA_CPU_PORT           32
#define HAL_MT_NAMCHABARWA_ECPU_PORT          33
#define HAL_MT_NAMCHABARWA_CPI_PORT0          34
#define HAL_MT_NAMCHABARWA_CPI_PORT1          35
#define HAL_MT_NAMCHABARWA_CPX_PORT_LAST      35
#define HAL_MT_NAMCHABARWA_LBM_NORMAL_SCH     40
#define HAL_MT_NAMCHABARWA_LBM_CT_SCH         2

#define HAL_MT_NAMCHABARWA_IPL_PST_DP0_VPORT_MAX 17
#define HAL_MT_NAMCHABARWA_IPL_PST_DP1_VPORT_MAX 16

#define HAL_MT_NAMCHABARWA_PL_PAUSE_MODE      0
#define HAL_MT_NAMCHABARWA_PL_PFC_MODE        1
#define HAL_MT_NAMCHABARWA_PL_FC_DIS_MODE     2
#define HAL_MT_NAMCHABARWA_PL_PAUSE_MODE_LAST 3

#define HAL_MT_NAMCHABARWA_PL_DEAD_LOCK_PAUSE_MODE      0
#define HAL_MT_NAMCHABARWA_PL_DEAD_LOCK_PFC_MODE        1
#define HAL_MT_NAMCHABARWA_PL_DEAD_LOCK_FC_DIS_MODE     2
#define HAL_MT_NAMCHABARWA_PL_DEAD_LOCK_PFC_DIS_MODE    3
#define HAL_MT_NAMCHABARWA_PL_DEAD_LOCK_PAUSE_MODE_LAST 4

#define HAL_MT_NAMCHABARWA_PL_VLAN_PCP_NUM    8
#define HAL_MT_NAMCHABARWA_PL_VLAN_DEI_NUM    2
#define HAL_MT_NAMCHABARWA_PL_IPV4_6_DSCP_NUM 64
#define HAL_MT_NAMCHABARWA_PL_MPLS_EXP_NUM    8

#define HAL_MT_NAMCHABARWA_PL_PST_SCH_MODE_NORMAL      0
#define HAL_MT_NAMCHABARWA_PL_PST_SCH_MODE_CUT_THROUGH 1

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_BANK_SIZE 256

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(SIZE_KB) \
    SIZE_KB * 1024 / HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_BANK_SIZE
// #define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_TOTAL_SIZE_IN_KB(SIZE_KB)  SIZE_KB * 1024 /
// HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_BANK_SIZE #define
// HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_SIZE_IN_KB(SIZE_KB)        SIZE_KB * 1024 /
// HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_BANK_SIZE

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_WIDTH 12

#define HAL_MT_NAMCHABARWA_PL_ETH_PORT_SPD(SPD)             \
    ((SPD == CLX_PORT_SPEED_800G) ?                         \
         7 :                                                \
         ((SPD == CLX_PORT_SPEED_400G) ?                    \
              6 :                                           \
              ((SPD == CLX_PORT_SPEED_200G) ?               \
                   5 :                                      \
                   ((SPD == CLX_PORT_SPEED_100G) ?          \
                        4 :                                 \
                        ((SPD == CLX_PORT_SPEED_50G) ?      \
                             3 :                            \
                             ((SPD == CLX_PORT_SPEED_40G) ? \
                                  2 :                       \
                                  ((SPD == CLX_PORT_SPEED_25G) ? 1 : 0)))))))

#define HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G (100)
#define HAL_MT_NAMCHABARWA_PL_BANDWIDTH_800G (800)

#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_800G_TH (0x1c)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_400G_TH (0xc)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_200G_TH (0x6)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_100G_TH (0x4)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_50G_TH  (0x2)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_40G_TH  (0x2)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_25G_TH  (0x1)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_10G_TH  (0x1)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_800G_CT_TH \
    (0x4) // EXP, make sure 99% traffic, umac not under run drop
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_400G_CT_TH (0x2)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_200G_CT_TH (0x1)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_100G_CT_TH (0x1)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_50G_CT_TH  (0x1)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_40G_CT_TH  (0x1)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_25G_CT_TH  (0x1)
#define HAL_MT_NAMCHABARWA_PL_LSY_SPD_10G_CT_TH  (0x1)
#define HAL_MT_NAMCHABARWA_PL_LLS_SPD_800G_TH    (0x1c)
#define HAL_MT_NAMCHABARWA_PL_LLS_SPD_400G_TH    (0x1c)
#define HAL_MT_NAMCHABARWA_PL_LLS_SPD_200G_TH    (0x1c)
#define HAL_MT_NAMCHABARWA_PL_LLS_SPD_100G_TH    (0x1c)
#define HAL_MT_NAMCHABARWA_PL_LLS_SPD_50G_TH     (0x1c)
#define HAL_MT_NAMCHABARWA_PL_LLS_SPD_40G_TH     (0x1c)
#define HAL_MT_NAMCHABARWA_PL_LLS_SPD_25G_TH     (0x1c)
#define HAL_MT_NAMCHABARWA_PL_LLS_SPD_10G_TH     (0x1c)

#define HAL_MT_NAMCHABARWA_PL_MTU_DFT           (10200)
#define HAL_MT_NAMCHABARWA_PL_PPH_LEANGTH       (40)
#define HAL_MT_NAMCHABARWA_PL_OUTER_MAC_LENGTH  (12)
#define HAL_MT_NAMCHABARWA_PL_OUTER_TYPE_LENGTH (2)
#define HAL_MT_NAMCHABARWA_PL_CPX_MTU_DFT \
    (HAL_MT_NAMCHABARWA_PL_MTU_DFT + HAL_MT_NAMCHABARWA_PL_PPH_LEANGTH)
#define HAL_MT_NAMCHABARWA_PL_CPX_RUNT_DFT                                        \
    (HAL_MT_NAMCHABARWA_PL_PPH_LEANGTH + HAL_MT_NAMCHABARWA_PL_OUTER_MAC_LENGTH + \
     HAL_MT_NAMCHABARWA_PL_OUTER_TYPE_LENGTH)

#define HAL_MT_NAMCHABARWA_PL_GEN_PKT_DURATION     (100)
#define HAL_MT_NAMCHABARWA_PL_GEN_PKT_LEN_MAX      (9600)
#define HAL_MT_NAMCHABARWA_PL_GEN_PKT_LEN_MIN      (64)
#define HAL_MT_NAMCHABARWA_PL_GEN_PKT_DATA_MAX     (9640)
#define HAL_MT_NAMCHABARWA_PL_GEN_PKT_MAC_ADDR_LEN (6)
#define HAL_MT_NAMCHABARWA_PL_CPX_DATA_BUF_REG_NUM (4)
#define HAL_MT_NAMCHABARWA_PL_LINE_DATA_SIZE       (256)
#define HAL_MT_NAMCHABARWA_PL_LINE_MAX_NUM         (128)
#define HAL_MT_NAMCHABARWA_PL_BANK_DATA_SIZE       (16)
#define HAL_MT_NAMCHABARWA_PL_DATA_ADDR_OFST       (5)
#define HAL_MT_NAMCHABARWA_PL_BYTE_NUM_PRE_REG     (4)
#define HAL_MT_NAMCHABARWA_PL_BYTE_BIT_OFST        (8)
#define HAL_MT_NAMCHABARWA_PL_LINE_BANK_NUM        (24)
#define HAL_MT_NAMCHABARWA_PL_LINE_DATABANK_NUM    (16)
#define HAL_MT_NAMCHABARWA_PL_DPORT_OFST           (7)
#define HAL_MT_NAMCHABARWA_PL_EOP_OFST             (13)
#define HAL_MT_NAMCHABARWA_PL_PAYLOAD_OFST         (13)
#define HAL_MT_NAMCHABARWA_PL_FRAG_SIZE_OFST       (14)
#define HAL_MT_NAMCHABARWA_PL_CORE_CLOCK_MHZ       (1350)
#define HAL_MT_NAMCHABARWA_PL_ETH_TYPE             (0x8809)

// fd buffer

// BANDWIDTH MODE
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PFC_Q0_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PFC_Q0_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PAUSE_Q0_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PAUSE_Q0_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PFC_Q1_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PFC_Q1_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PAUSE_Q1_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PAUSE_Q1_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))

// lossless queue num mode and speed mode
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PFC_Q2_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(45))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PFC_Q2_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q2_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(44))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q2_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(48))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_100G_Q2_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(90))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_100G_Q3_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(90))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_100G_Q3_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(100))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_800G_Q3_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(374))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_800G_Q3_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(384))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PFC_Q3_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(45))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PFC_Q3_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q3_DROP_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(64))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q3_TRUNC_THD \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))

// set 100G default xon thd to 12KB, xoff = 16KB

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_100G_PFC_XON \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(26))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_PFC_XON \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(13))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_100G_PFC_XOFF \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(30))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_PFC_XOFF \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_100G_PAUSE_XON \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(26))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_PAUSE_XON \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(18))
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_PAUSE_XOFF \
    (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))

// #define
// HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_FD_BUF_START_ADDR(HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_THD_SIZE_IN_KB(18))
// #define HAL_MT_NAMCHABARWA_IPL_PFC_UMAC_FD_BUF_SIZE
// (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_SIZE_IN_KB(24))  //384
#define HAL_MT_NAMCHABARWA_IPL_PFC_UMAC_FD_BUF_SIZE   (384) // 384
#define HAL_MT_NAMCHABARWA_IPL_PAUSE_UMAC_FD_BUF_SIZE (384)

#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P0 (0)
#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P1 (3072)
#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P2 (6144)
#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P3 (9216)
#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P4 (12288)
#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P5 (15360)
#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P6 (18432)
#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P7 (21504)

#define HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE (16)

#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_SIZE(MODE, BANDWIDTH)                            \
    ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                             \
         (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_PFC_UMAC_FD_BUF_SIZE) :         \
         (((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                                     \
               (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_PAUSE_UMAC_FD_BUF_SIZE) : \
               0)))

#define HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR(PORT)                                      \
    ((PORT % 8 == 0) ?                                                                        \
         (HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P0) :                                    \
         ((PORT % 8 == 1) ?                                                                   \
              (HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P1) :                               \
              ((PORT % 8 == 2) ?                                                              \
                   (HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P2) :                          \
                   ((PORT % 8 == 3) ?                                                         \
                        (HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P3) :                     \
                        ((PORT % 8 == 4) ?                                                    \
                             (HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P4) :                \
                             ((PORT % 8 == 5) ?                                               \
                                  (HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P5) :           \
                                  ((PORT % 8 == 6) ?                                          \
                                       (HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P6) :      \
                                       ((PORT % 8 == 7) ?                                     \
                                            (HAL_MT_NAMCHABARWA_IPL_UMAC_FD_BUF_ST_ADDR_P7) : \
                                            0))))))))

// lossy queue drop thd
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q0_DROP_THD(MODE, BANDWIDTH)                               \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                                          \
         (0) :                                                                                      \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                                \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PFC_Q0_DROP_THD) : \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                                         \
                   (ceil(BANDWIDTH / 100.00) *                                                      \
                    HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PAUSE_Q0_DROP_THD) :                     \
                   0)))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q1_DROP_THD(MODE, BANDWIDTH)            \
    ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                  \
         ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                  \
              (ceil(2 * (BANDWIDTH) / 100.00) *                                  \
               HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PFC_Q1_DROP_THD) :         \
              (ceil(BANDWIDTH / 100.00) *                                        \
               HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PFC_Q1_DROP_THD)) :        \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                           \
              ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?             \
                   (ceil(2 * (BANDWIDTH) / 100.00) *                             \
                    HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PFC_Q1_DROP_THD) :    \
                   (ceil(BANDWIDTH / 100.00) *                                   \
                    HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSY_PAUSE_Q1_DROP_THD)) : \
              0))

// lossy queue trunc thd
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q0_TRUNC_THD(MODE, BANDWIDTH)                    \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                                \
         (0) :                                                                            \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                      \
              (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q0_DROP_THD(MODE, BANDWIDTH) + 40) :      \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                               \
                   (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q0_DROP_THD(MODE, BANDWIDTH) + 40) : \
                   0)))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q1_TRUNC_THD(MODE, BANDWIDTH)             \
    ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                    \
         (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q1_DROP_THD(MODE, BANDWIDTH) + 40) :    \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                             \
              HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q1_DROP_THD(MODE, BANDWIDTH) + 40 : \
              0))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_XON_THD(MODE, BANDWIDTH)                            \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                                   \
         (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_100G_PFC_XON) :                                   \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                         \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_PFC_XON) :        \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                                  \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_PAUSE_XON) : \
                   0)))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_XOFF_THD(MODE, BANDWIDTH)                            \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                                    \
         (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_100G_PFC_XOFF) :                                   \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                          \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_PFC_XOFF) :        \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                                   \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_PAUSE_XOFF) : \
                   0)))

// lossless queue drop thd
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q2_DROP_THD(MODE, BANDWIDTH)       \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                  \
         (0) :                                                              \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                        \
              (ceil(BANDWIDTH / 100.00) *                                   \
               HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PFC_Q2_DROP_THD) : \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ? 0 : 0)))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q3_DROP_THD(MODE, BANDWIDTH)                    \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                               \
         HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_100G_Q3_DROP_THD :                    \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                     \
              (ceil(BANDWIDTH / 100.00) *                                                \
               HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PFC_Q3_DROP_THD) :              \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                              \
                   ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_800G == BANDWIDTH) ?                \
                        HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_800G_Q3_DROP_THD :     \
                        (ceil(BANDWIDTH / 100.00) *                                      \
                         HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q3_DROP_THD)) : \
                   0)))

// lossless queue trunc thd
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q2_TRUNC_THD(MODE, BANDWIDTH)             \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                         \
         (0) :                                                                     \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                               \
              HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q2_DROP_THD(MODE, BANDWIDTH) + 40 : \
              (MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ? 0 :                       \
                                                         0))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q3_TRUNC_THD(MODE, BANDWIDTH)                  \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                              \
         HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_LOSSLESS_100G_Q3_TRUNC_THD :                  \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                    \
              (HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q3_DROP_THD(MODE, BANDWIDTH) + 40) :    \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                             \
                   HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q3_DROP_THD(MODE, BANDWIDTH) + 40 : \
                   0)))

// dedicate size
#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q0_IOS_MIN_SIZE(MODE, BANDWIDTH)                  \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                                 \
         (0) :                                                                             \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                       \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE) :      \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                                \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE) : \
                   0)))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q1_IOS_MIN_SIZE(MODE, BANDWIDTH)                  \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                                 \
         (2 * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE) :                                  \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                       \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE) :      \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                                \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE) : \
                   0)))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q2_IOS_MIN_SIZE(MODE, BANDWIDTH)             \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                            \
         (0) :                                                                        \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                  \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE) : \
              (((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ? 0 : 0))))

#define HAL_MT_NAMCHABARWA_IPL_DATA_BUFF_Q3_IOS_MIN_SIZE(MODE, BANDWIDTH)                      \
    ((HAL_MT_NAMCHABARWA_PL_BANDWIDTH_100G == BANDWIDTH) ?                                     \
         2 * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE :                                        \
         ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                           \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE) :          \
              ((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                                    \
                   (2 * ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_IPL_100G_IOS_MIN_SIZE) : \
                   0)))

#define HAL_MT_NAMCHABARWA_IPL_ETH_PORT_EN_START 0
#define HAL_MT_NAMCHABARWA_IPL_ETH_PORT_EN_END   0
#define HAL_MT_NAMCHABARWA_IPL_ETH_PORT_EN_WIDTH \
    (HAL_MT_NAMCHABARWA_IPL_ETH_PORT_EN_END - HAL_MT_NAMCHABARWA_IPL_ETH_PORT_EN_START + 1)
#define HAL_MT_NAMCHABARWA_IPL_ETH_FABRIC_PORT_EN_START 1
#define HAL_MT_NAMCHABARWA_IPL_ETH_FABRIC_PORT_EN_END   1
#define HAL_MT_NAMCHABARWA_IPL_ETH_FABRIC_PORT_EN_WIDTH \
    (HAL_MT_NAMCHABARWA_IPL_ETH_FABRIC_PORT_EN_END -    \
     HAL_MT_NAMCHABARWA_IPL_ETH_FABRIC_PORT_EN_START + 1)
#define HAL_MT_NAMCHABARWA_IPL_ETH_PFC_MODE_EN_START 2
#define HAL_MT_NAMCHABARWA_IPL_ETH_PFC_MODE_EN_END   2
#define HAL_MT_NAMCHABARWA_IPL_ETH_PFC_MODE_EN_WIDTH \
    (HAL_MT_NAMCHABARWA_IPL_ETH_PFC_MODE_EN_END - HAL_MT_NAMCHABARWA_IPL_ETH_PFC_MODE_EN_START + 1)
#define HAL_MT_NAMCHABARWA_IPL_ETH_IGNORE_TM_PFC_START 3
#define HAL_MT_NAMCHABARWA_IPL_ETH_IGNORE_TM_PFC_END   3
#define HAL_MT_NAMCHABARWA_IPL_ETH_IGNORE_TM_PFC_WIDTH \
    (HAL_MT_NAMCHABARWA_IPL_ETH_IGNORE_TM_PFC_END -    \
     HAL_MT_NAMCHABARWA_IPL_ETH_IGNORE_TM_PFC_START + 1)
#define HAL_MT_NAMCHABARWA_IPL_ETH_READ_LIMIT_START 4
#define HAL_MT_NAMCHABARWA_IPL_ETH_READ_LIMIT_END   7
#define HAL_MT_NAMCHABARWA_IPL_ETH_READ_LIMIT_WIDTH \
    (HAL_MT_NAMCHABARWA_IPL_ETH_READ_LIMIT_END - HAL_MT_NAMCHABARWA_IPL_ETH_READ_LIMIT_START + 1)

#define HAL_MT_NAMCHABARWA_IPL_PLTC_MPLS_DEPTH   64
#define HAL_MT_NAMCHABARWA_IPL_PLTC_VLAN_DEPTH   128
#define HAL_MT_NAMCHABARWA_IPL_PLTC_IPV4_6_DEPTH 512

#define HAL_MT_NAMCHABARWA_IPL_SOFT_RESET_VALID_LEVEL 0
#define HAL_MT_NAMCHABARWA_IPL_APP_VLAN_ETYPE_MAX     8

#define HAL_MT_NAMCHABARWA_EPL_PFC_UMAC_FD_BUF_SIZE   (341) // 384
#define HAL_MT_NAMCHABARWA_EPL_PAUSE_UMAC_FD_BUF_SIZE (341)

#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P0 (0)
#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P1 (1024)
#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P2 (2048)
#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P3 (3072)
#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P4 (4096)
#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P5 (5120)
#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P6 (6144)
#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P7 (7168)

#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_SIZE(MODE, BANDWIDTH)                            \
    ((MODE == HAL_MT_NAMCHABARWA_PL_PFC_MODE) ?                                             \
         (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_EPL_PFC_UMAC_FD_BUF_SIZE) :         \
         (((MODE == HAL_MT_NAMCHABARWA_PL_PAUSE_MODE) ?                                     \
               (ceil(BANDWIDTH / 100.00) * HAL_MT_NAMCHABARWA_EPL_PAUSE_UMAC_FD_BUF_SIZE) : \
               0)))

#define HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR(PORT)                                      \
    ((PORT % 8 == 0) ?                                                                        \
         (HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P0) :                                    \
         ((PORT % 8 == 1) ?                                                                   \
              (HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P1) :                               \
              ((PORT % 8 == 2) ?                                                              \
                   (HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P2) :                          \
                   ((PORT % 8 == 3) ?                                                         \
                        (HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P3) :                     \
                        ((PORT % 8 == 4) ?                                                    \
                             (HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P4) :                \
                             ((PORT % 8 == 5) ?                                               \
                                  (HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P5) :           \
                                  ((PORT % 8 == 6) ?                                          \
                                       (HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P6) :      \
                                       ((PORT % 8 == 7) ?                                     \
                                            (HAL_MT_NAMCHABARWA_EPL_UMAC_FD_BUF_ST_ADDR_P7) : \
                                            0))))))))

typedef enum {
    HAL_MT_NAMCHABARWA_IPL_LIMIT_RATE_800G = 0,
    HAL_MT_NAMCHABARWA_IPL_LIMIT_RATE_400G = 1,
    HAL_MT_NAMCHABARWA_IPL_LIMIT_RATE_200G_100G_50G_40G = 3,
    HAL_MT_NAMCHABARWA_IPL_LIMIT_RATE_25G_10G = 7,
    HAL_MT_NAMCHABARWA_IPL_LIMIT_RATE_LAST
} HAL_MT_NAMCHABARWA_IPL_LIMIT_RATE_T;

typedef struct HAL_MT_NAMCHABARWA_IPL_APP_PARSE_S {
    UI32_T jumbo_etype;
    UI32_T skip2_len;
    UI32_T skip1_len;
    UI32_T skip1_etype;
    UI32_T skip2_etype;
    UI32_T inner_etype[HAL_MT_NAMCHABARWA_IPL_APP_VLAN_ETYPE_MAX];
    UI32_T outer_etype[HAL_MT_NAMCHABARWA_IPL_APP_VLAN_ETYPE_MAX];
} HAL_MT_NAMCHABARWA_IPL_APP_PARSE_T;

typedef struct HAL_MT_NAMCHABARWA_IPL_APP_SPE_MAC_S {
    UI32_T spe_mac_da[2];
    UI32_T spe_mac_mask[2];
} HAL_MT_NAMCHABARWA_IPL_APP_SPE_MAC_T;

typedef struct HAL_MT_NAMCHABARWA_IPL_APP_TC2QUEUE_MIX_S {
    UI32_T cfg_use_l3;
    UI32_T ctrl_pkt_tc;
    UI32_T unknown_tc;
} HAL_MT_NAMCHABARWA_IPL_APP_TC2QUEUE_MIX_T;

typedef struct HAL_MT_NAMCHABARWA_PL_TC_S {
    UI32_T que[4]; // tc_value: range 0~7
} HAL_MT_NAMCHABARWA_PL_TC_T;

typedef struct HAL_MT_NAMCHABARWA_PL_LOSSY_THD_S {
    UI32_T q0_drop;
    UI32_T q0_trunc;
    UI32_T q1_drop;
    UI32_T q1_trunc;
} HAL_MT_NAMCHABARWA_PL_LOSSY_THD_T;

typedef struct HAL_MT_NAMCHABARWA_PL_LOSSLESS_THD_S {
    UI32_T q2_drop;
    UI32_T q2_trunc;
    UI32_T q3_drop;
    UI32_T q3_trunc;
} HAL_MT_NAMCHABARWA_PL_LOSSLESS_THD_T;

typedef struct HAL_MT_NAMCHABARWA_PL_PAUSE_THD_S {
    UI32_T q2_xon;
    UI32_T q3_xon;
    UI32_T q2_xoff;
    UI32_T q3_xoff;
} HAL_MT_NAMCHABARWA_PL_PAUSE_THD_T;

typedef struct HAL_MT_NAMCHABARWA_PL_BUFF_MODE_S {
    UI32_T
    mode; // 0:8x100g three queue pfc, 1:8x100g three queue pause, 2:common pfc, 3:common pause
    UI32_T channel_num; // total enable port num of one umac
    UI32_T bandwidth;
} HAL_MT_NAMCHABARWA_PL_BUFF_MODE_T;

typedef struct HAL_MT_NAMCHABARWA_PL_PST_BUFF_SCH_S {
    UI32_T pst_sch_mode; // 0:normal, 1:cut_through
    UI32_T bandwidth;
    UI32_T limit_rate;
} HAL_MT_NAMCHABARWA_PL_PST_BUFF_SCH_T;

typedef struct HAL_MT_NAMCHABARWA_PL_FD_BUFF_ADDR_S {
    UI32_T q0_addr;
    UI32_T q1_addr;
    UI32_T q2_addr;
    UI32_T q3_addr;
} HAL_MT_NAMCHABARWA_PL_FD_BUFF_ADDR_T;

typedef struct HAL_MT_NAMCHABARWA_PL_BUFF_SIZE_S {
    UI32_T q0_size;
    UI32_T q1_size;
    UI32_T q2_size;
    UI32_T q3_size;
} HAL_MT_NAMCHABARWA_PL_BUFF_SIZE_T;

typedef struct HAL_MT_NAMCHABARWA_PL_FD_BUFF_S {
    HAL_MT_NAMCHABARWA_PL_BUFF_SIZE_T size;
    HAL_MT_NAMCHABARWA_PL_FD_BUFF_ADDR_T addr;
} HAL_MT_NAMCHABARWA_PL_FD_BUFF_T;

typedef struct HAL_MT_NAMCHABARWA_IPL_ETH_CFG_S {
    UI32_T port_en;
    UI32_T mode; // {fast_tm_pfc, pfc_mode, fabric_mode}
    UI32_T leak_en;
    UI32_T leak_size[2];

#define HAL_MT_NAMCHABARWA_IPL_ETH_ENABLE (1 << 0)
#define HAL_MT_NAMCHABARWA_IPL_ETH_MODE   (1 << 1)
    UI32_T flag;
} HAL_MT_NAMCHABARWA_IPL_ETH_CFG_T;

typedef struct HAL_MT_NAMCHABARWA_PL_ETH_LEAK_S {
    UI32_T lossy_leak_en;
    UI32_T lossy_leak_size; // 20bit
    UI32_T lossless_leak_en;
    UI32_T lossless_leak_size;
} HAL_MT_NAMCHABARWA_PL_ETH_LEAK_T;

typedef struct HAL_MT_NAMCHABARWA_IPL_GLOBAL_S {
    UI32_T dp_pst_sch_en;     //{dp1 and dp0} 1+1
    UI32_T dp_pst_bubble_en;  //{dp1 and dp0} 1
    UI32_T dp_pst_bubble_clr; //{dp1 and dp0} 1+1
} HAL_MT_NAMCHABARWA_IPL_GLOBAL_T;

typedef struct HAL_MT_NAMCHABARWA_IPL_CFG_CPX_PORT_S {
    UI32_T en;               // port enable
    UI32_T mode;             // 0-cpu, 1-cpi
    UI32_T have_pph_already; // 0-no have pph,need insert, 1-noneed insert
    UI32_T pfc_mode;         // only for cpi, 0-pause, 1-pfc
    UI32_T id_sel;           // 2'b00-32, 01-33, 10-34, 11-35
    UI32_T fast_tm_pfc;      // 1:ipl_pfc|tm_pfc, 0:ipl_pfc
    UI32_T forced_mode;      // 2'b00/11-nomal, 01-force fc, 10-force rdy
} HAL_MT_NAMCHABARWA_IPL_CFG_CPX_PORT_T;

typedef enum {
    HAL_MT_NAMCHABARWA_IPL_FRM_ERR,
    HAL_MT_NAMCHABARWA_IPL_CRC_ERR,     /* frames received with CRC Error */
    HAL_MT_NAMCHABARWA_IPL_FRM_LEN_VIO, /* Frames greater than programmed MaxFrameSize, violation */
    HAL_MT_NAMCHABARWA_IPL_JABBER_ERR,  /* frames exceed Jabber size and have CRC Error */
    HAL_MT_NAMCHABARWA_IPL_IEEE8023_LEN_ERR, /* frames received with Length Error, payload != length
                                                type */
} HAL_MT_NAMCHABARWA_IPL_DROP_RSN_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_CFG_CPX_PORT_S {
    UI32_T enable;             // port enable
    UI32_T mode;               // 0-cpu/ecpu, 1-cpi
    UI32_T keep_pph;           // 0-remove pph, 1-keep pph. cfg with ipl have_pph_already
    UI32_T pfc_mode;           // only for cpi, 0-pause, 1-pfc
    UI32_T id_sel;             // 2'b00-32, 01-33, 10-34, 11-35
    UI32_T port_leak_en;       // port leak_timer_enable
    UI32_T leak_thres;         // 16B unit, maximum 32KB
    UI32_T cpi_port_spd;       // only valid for cpi port.3'd7~3'd5:unused;
                               // 3'd4:100G;3'd3:50G;3'd2:40G;3'd1:25G;3'd0:10G
    UI32_T pfc_ignore;         // dbg for cpi port queue0~1 pfc mode dead_lock detect enable
    UI32_T dead_lock_en;       // for cpi port queue0~1 pfc mode dead_lock detect enable
    UI32_T que_flush_en;       // queue flush enable
    UI32_T port_flush_en;      // port flush enable
    UI32_T pause_dead_lock_en; // pause mode dead-lock detect enable
} HAL_MT_NAMCHABARWA_EPL_CFG_CPX_PORT_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_CPX_S {
    UI32_T outer_mac;
    UI32_T tc2que_map[8];
    UI32_T mtu;
    UI32_T que_weight[4];
} HAL_MT_NAMCHABARWA_EPL_CPX_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_ETH_PORT_S {
    UI32_T enable;
    UI32_T mode;
    UI32_T port_spd;
} HAL_MT_NAMCHABARWA_EPL_ETH_PORT_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_APP_ETH_PORT_S {
    UI32_T mode;
    UI32_T leak_en;
    UI32_T leak_thres;
    UI32_T port_spd;
} HAL_MT_NAMCHABARWA_EPL_APP_ETH_PORT_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_APP_TC2QUE_MAP_S {
    UI32_T tc[8]; // que_value: range 0~3
    UI32_T tc_bitmap;
} HAL_MT_NAMCHABARWA_EPL_APP_TC2QUE_MAP_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_CFG_ETH_PORT_S {
    HAL_MT_NAMCHABARWA_EPL_ETH_PORT_T epl_eth;
    HAL_MT_NAMCHABARWA_EPL_APP_ETH_PORT_T epl_app_eth;

#define HAL_MT_NAMCHABARWA_EPL_ETH_ENABLE   (1 << 0)
#define HAL_MT_NAMCHABARWA_EPL_ETH_MODE     (1 << 1)
#define HAL_MT_NAMCHABARWA_EPL_ETH_PORT_SPD (1 << 2)
    UI32_T flag;
} HAL_MT_NAMCHABARWA_EPL_CFG_ETH_PORT_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_DP_QUE_SPD_READ_TH_S {
    UI32_T lsy_spd_800g_th;
    UI32_T lsy_spd_400g_th;
    UI32_T lsy_spd_200g_th;
    UI32_T lsy_spd_100g_th;
    UI32_T lsy_spd_50g_th;
    UI32_T lsy_spd_40g_th;
    UI32_T lsy_spd_25g_th;
    UI32_T lsy_spd_10g_th;
    UI32_T lls_spd_800g_th;
    UI32_T lls_spd_400g_th;
    UI32_T lls_spd_200g_th;
    UI32_T lls_spd_100g_th;
    UI32_T lls_spd_50g_th;
    UI32_T lls_spd_40g_th;
    UI32_T lls_spd_25g_th;
    UI32_T lls_spd_10g_th;
} HAL_MT_NAMCHABARWA_EPL_DP_QUE_SPD_READ_TH_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_PKT_HEAD_VLAN_S {
    UI16_T vlan_tpid; // 2bytes,   0x8100, IEEE 802.1Q tag
    UI8_T vlan_pri;   // 3bits,    priority, 0-7
    UI8_T vlan_cfi;   // 1bit,     0-std format mac addr, 1-non std
    UI16_T vlan_id;   // 12bits,   vlan id, 0-4095
} HAL_MT_NAMCHABARWA_EPL_PKT_HEAD_VLAN_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_PKT_HEAD_S {
    CLX_MAC_T dst_mac;  // 6bytes,   destination mac address
    CLX_MAC_T src_mac;  // 6bytes,   source mac address
    UI16_T eth_ii_type; // 2bytes,   ethernet II type or 802.3 payload size
    UI8_T vlan_vld;     // 1bit,     0-ethernet II pkt, 1-vlan pkt and need vlan_cfg
    HAL_MT_NAMCHABARWA_EPL_PKT_HEAD_VLAN_T vlan_cfg; // vlan pkt field cfg
} HAL_MT_NAMCHABARWA_EPL_PKT_HEAD_T;

typedef struct HAL_MT_NAMCHABARWA_EPL_PKT_GEN_CFG_S {
    UI32_T pkt_size;        // total bytes size of the pkt 64-9640
    HAL_MT_NAMCHABARWA_EPL_PKT_HEAD_T pkt_head_cfg;
    UI8_T dport;            // pkt destination port, 0-31
    UI8_T repeat_num;       // 8bits, the pkt sent times during repeat duration in a loop
    UI8_T loop_num;         // 8bits, times of repeat_num sent pkts, 0-continuously
    UI8_T payload_ofst;     // 5bits, addr of payload start5'd13 is no vlan frame; 5'd17 vlan frame
    UI8_T payload_random;   // 1bits, if use the random payload
    UI8_T head_ofst;        // 4bits, addr of payload start5'd13 is no vlan frame; 5'd17 vlan frame
    UI8_T head_random;      // 2bits, 2'b00/11-no change head, 2'b01-random, 2'b10-increase
    UI8_T plen_random_en;   // 1bit
    UI8_T data_duplication; // 1bit , data to multi umac dport
    UI16_T repeat_duration; // 16bits, default 0x100
    UI32_T payload_size;    // 32bits, payload size,
    UI8_T pkt_payload[HAL_MT_NAMCHABARWA_PL_GEN_PKT_LEN_MAX]; // pkt payload
} HAL_MT_NAMCHABARWA_EPL_PKT_GEN_CFG_T;

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_softrst(UI32_T unit, UI32_T plane, UI32_T reset);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_app_cfgParser(UI32_T unit,
                                     UI32_T port,
                                     HAL_MT_NAMCHABARWA_IPL_APP_PARSE_T *parse);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_app_cfgSpeMac(UI32_T unit,
                                     UI32_T plane,
                                     HAL_MT_NAMCHABARWA_IPL_APP_SPE_MAC_T *spe_mac);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgVlanPltcMap(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T pcp,
                                      const UI32_T dei,
                                      const UI32_T loss_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_getVlanPltcMap(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T pcp,
                                      const UI32_T dei,
                                      UI32_T *ptr_loss_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgDscpPltcMap(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T dscp,
                                      const UI32_T loss_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_getDscpPltcMap(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T dscp,
                                      UI32_T *ptr_loss_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgExpPltcMap(const UI32_T unit,
                                     const UI32_T port,
                                     const UI32_T exp,
                                     const UI32_T loss_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_getExpPltcMap(const UI32_T unit,
                                     const UI32_T port,
                                     const UI32_T exp,
                                     UI32_T *ptr_loss_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgQ2tcMap(UI32_T unit, UI32_T port, HAL_MT_NAMCHABARWA_PL_TC_T *que2tc);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_getQ2tcMap(UI32_T unit, UI32_T port, HAL_MT_NAMCHABARWA_PL_TC_T *que2tc);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgRsnMask(const UI32_T unit,
                                  const UI32_T plane,
                                  const UI32_T macro,
                                  const HAL_MT_NAMCHABARWA_IPL_DROP_RSN_T reason,
                                  const BOOL_T mask_en);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgXoffMaskPortPltc(const UI32_T unit,
                                           const UI32_T port,
                                           const UI32_T pltc_bmp,
                                           const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgBufferDropThd(UI32_T unit,
                                        UI32_T port,
                                        HAL_MT_NAMCHABARWA_PL_BUFF_MODE_T *drop_mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgBuffPerPort(UI32_T unit,
                                      UI32_T port,
                                      HAL_MT_NAMCHABARWA_PL_BUFF_MODE_T *buff_mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgBufferDropThd(UI32_T unit,
                                        UI32_T port,
                                        HAL_MT_NAMCHABARWA_PL_BUFF_MODE_T *drop_mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgFdBuffer(UI32_T unit,
                                   UI32_T port,
                                   HAL_MT_NAMCHABARWA_PL_BUFF_MODE_T *buff_mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_checkBufEmpty(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_checkBufEmpty(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgAdminState(const UI32_T unit, const UI32_T port, const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgAdminState(const UI32_T unit, const UI32_T port, const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgPstSch(UI32_T unit, UI32_T port, const UI32_T speed, UI32_T pst_mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgFlushEn(const UI32_T unit, const UI32_T port, const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgQueFlushEn(const UI32_T unit,
                                     const UI32_T port,
                                     const UI32_T queue,
                                     const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgPortSpeed(const UI32_T unit, const UI32_T port, const UI32_T port_spd);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgTdmSlot2PortMap(const UI32_T unit,
                                          const UI32_T port,
                                          const UI32_T lane_cnt,
                                          const CLX_PORT_SPEED_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgSchUmac(UI32_T unit, UI32_T port, UI32_T speed, UI32_T mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_getSchUmac(UI32_T unit, UI32_T port, UI32_T speed, UI32_T *mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_getCpxPort(const UI32_T unit,
                                  const UI32_T plane,
                                  HAL_MT_NAMCHABARWA_IPL_CFG_CPX_PORT_T *cpx_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_setCpxPort(const UI32_T unit,
                                  const UI32_T plane,
                                  HAL_MT_NAMCHABARWA_IPL_CFG_CPX_PORT_T *cpx_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgGlobaPort(UI32_T unit, UI32_T port, UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgGlobaPort(UI32_T unit, UI32_T port, UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgCpxRuntPktSize(UI32_T unit, UI32_T port, UI32_T pkt_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgCpxRuntPktSize(UI32_T unit, UI32_T port, UI32_T pkt_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_setCpxPort(const UI32_T unit,
                                  const UI32_T plane,
                                  HAL_MT_NAMCHABARWA_EPL_CFG_CPX_PORT_T *cpx_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_getCpxPort(const UI32_T unit,
                                  const UI32_T plane,
                                  HAL_MT_NAMCHABARWA_EPL_CFG_CPX_PORT_T *cpx_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgEth(UI32_T unit,
                              UI32_T port,
                              HAL_MT_NAMCHABARWA_EPL_CFG_ETH_PORT_T *cfg_eth);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgTc2QueMap(UI32_T unit,
                                    UI32_T port,
                                    HAL_MT_NAMCHABARWA_EPL_APP_TC2QUE_MAP_T *tc_que);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_getTc2QueMap(UI32_T unit,
                                    UI32_T port,
                                    HAL_MT_NAMCHABARWA_EPL_APP_TC2QUE_MAP_T *tc_que);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_initAllMem(UI32_T unit, UI32_T plane);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lbm_initMem(UI32_T unit, UI32_T plane);

CLX_ERROR_NO_T
hal_mt_namchabarwa_lbm_initTfcTh(UI32_T unit, UI32_T plane);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgSoftreset(const UI32_T unit, const UI32_T plane, const UI32_T reset);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_initAllMem(UI32_T unit, UI32_T plane);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_initAllMemDone(UI32_T unit, UI32_T plane, UI32_T *init_done);
CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgCpx(UI32_T unit, UI32_T plane, HAL_MT_NAMCHABARWA_EPL_CPX_T *cpx_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_setCpxSpeed(const UI32_T unit, const UI32_T port, CLX_PORT_SPEED_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgLsyQueSpdReadTh(UI32_T unit,
                                          UI32_T plane,
                                          HAL_MT_NAMCHABARWA_EPL_DP_QUE_SPD_READ_TH_T *que_spd);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgQueSpdReadTh(UI32_T unit,
                                       UI32_T plane,
                                       HAL_MT_NAMCHABARWA_EPL_DP_QUE_SPD_READ_TH_T *que_spd);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgPortFcMode(UI32_T unit, UI32_T port, UI32_T mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgEthPort(UI32_T unit,
                                  UI32_T port,
                                  HAL_MT_NAMCHABARWA_IPL_ETH_CFG_T *eth_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_cfgPortFastTmPfc(UI32_T unit, UI32_T port, UI32_T mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_ipl_getPortFcMode(UI32_T unit, UI32_T port, UI32_T *ptr_mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgEthFcMode(const UI32_T unit, const UI32_T port, const UI32_T mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgEthDeadLock(const UI32_T unit,
                                      const UI32_T port,
                                      const UI32_T queue,
                                      const UI32_T mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgDeadLockDetectTh(const UI32_T unit,
                                           const UI32_T port,
                                           const UI32_T threshold);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgFlowCtrlIgnore(const UI32_T unit,
                                         const UI32_T port,
                                         const UI32_T queue,
                                         const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setFabric(UI32_T unit, UI32_T port, UI32_T fabric_en);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getFabric(UI32_T unit, UI32_T port, UI32_T *fabric_en);

/**
 * @brief Initialize time stamp fifo
 *
 * @param [in]     unit     - Chip id
 * @param [in]     plane_id - Device plane id in specific chip
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_initTsFifo(const UI32_T unit, const UI32_T plane_id);

/**
 * @brief Get port tx time stamp entry count.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - Port id
 * @param [out]    ptr_count       - Time stamp entry information
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getTsEntryCount(const UI32_T unit, const UI32_T port, UI32_T *ptr_count);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getTsEntry(const UI32_T unit,
                                 const UI32_T port,
                                 const UI32_T count,
                                 CLX_PORT_TS_ENTRY_T *ptr_ts_entry);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_checkTsFifoIrq(UI32_T unit, UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMxHdrEn(const UI32_T unit, const UI32_T port, const BOOL_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMxHdrEn(const UI32_T unit, const UI32_T port, UI32_T *enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_initIPL(const UI32_T unit, const UI32_T port, const UI32_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_initEPL(const UI32_T unit,
                           const UI32_T port,
                           const UI32_T lane_cnt,
                           const CLX_PORT_SPEED_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_deinitIPL(const UI32_T unit, const UI32_T port, const UI32_T lane_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_deinitEPL(const UI32_T unit,
                             const UI32_T port,
                             const UI32_T lane_num,
                             const CLX_PORT_SPEED_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_cfgDeadLockDetectTh(const UI32_T unit,
                                           const UI32_T port,
                                           const UI32_T threshold);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstCalPort(const UI32_T unit, const UI32_T port, const CLX_DIR_T dir);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstCalPort(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_DIR_T dir,
                                       UI32_T *p_port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstPattMatch(const UI32_T unit,
                                         const UI32_T port,
                                         const CLX_DIR_T dir,
                                         UI32_T *p_pattern);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstPattMatch(const UI32_T unit,
                                         const UI32_T port,
                                         const CLX_DIR_T dir,
                                         UI32_T *p_pattern);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstPattMask(const UI32_T unit,
                                        const UI32_T port,
                                        const CLX_DIR_T dir,
                                        UI32_T *p_mask);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstPattMask(const UI32_T unit,
                                        const UI32_T port,
                                        const CLX_DIR_T dir,
                                        UI32_T *p_mask);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstWinCnt(const UI32_T unit,
                                      const UI32_T port,
                                      const CLX_DIR_T dir,
                                      const UI32_T count);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstWinDiv(const UI32_T unit,
                                      const UI32_T port,
                                      const CLX_DIR_T dir,
                                      UI32_T *p_count);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstRateWgt(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_DIR_T dir,
                                       const UI32_T weight);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstRateWgt(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_DIR_T dir,
                                       UI32_T *p_weight);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstCalRateSel(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_DIR_T dir,
                                          const UI32_T mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstCalRateSel(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_DIR_T dir,
                                          UI32_T *p_mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstCalAddCxheader(const UI32_T unit,
                                              const UI32_T port,
                                              const CLX_DIR_T dir,
                                              const UI32_T status);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstCalAddCxheader(const UI32_T unit,
                                              const UI32_T port,
                                              const CLX_DIR_T dir,
                                              UI32_T *p_status);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstRateThrd(const UI32_T unit,
                                        const UI32_T port,
                                        const CLX_DIR_T dir,
                                        const UI32_T thrd_num,
                                        const UI32_T threshold);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstRateThrd(const UI32_T unit,
                                        const UI32_T port,
                                        const CLX_DIR_T dir,
                                        const UI32_T thrd_num,
                                        UI32_T *p_thrd);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstCount(const UI32_T unit,
                                     const UI32_T port,
                                     const CLX_DIR_T dir,
                                     const UI32_T cnt_type,
                                     UI32_T *p_count);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstInstantRate(const UI32_T unit,
                                           const UI32_T port,
                                           const CLX_DIR_T dir,
                                           UI32_T *p_rate);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstMaxRate(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_DIR_T dir,
                                       UI32_T *p_rate);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstMaxRateTs(const UI32_T unit,
                                         const UI32_T port,
                                         const CLX_DIR_T dir,
                                         UI32_T *p_rate_ts);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstAverageRate(const UI32_T unit,
                                           const UI32_T port,
                                           const CLX_DIR_T dir,
                                           UI32_T *p_rate);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstHistIrqMask(const UI32_T unit,
                                           const UI32_T port,
                                           const CLX_DIR_T dir,
                                           const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstHistIrqMask(const UI32_T unit,
                                           const UI32_T port,
                                           const CLX_DIR_T dir,
                                           UI32_T *p_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstHistMaxValue(const UI32_T unit,
                                            const UI32_T port,
                                            const CLX_DIR_T dir,
                                            const UI32_T value);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstHistMaxValue(const UI32_T unit,
                                            const UI32_T port,
                                            const CLX_DIR_T dir,
                                            UI32_T *p_value);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_getMburstHistCnt(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_DIR_T dir,
                                       const UI32_T thrd_num,
                                       UI32_T *p_count);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_setMburstClear(const UI32_T unit,
                                     const UI32_T port,
                                     const CLX_DIR_T dir,
                                     const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_getCpxMemEmpty(const UI32_T unit, const UI32_T plane, UI32_T *empty);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_setTestMode(const UI32_T unit, const UI32_T plane, const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_epl_getTestMode(const UI32_T unit, const UI32_T plane, UI32_T *ptr_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_genPkt(const UI32_T unit,
                             const UI32_T port,
                             CLX_PORT_SPEED_T speed,
                             HAL_MT_NAMCHABARWA_EPL_PKT_GEN_CFG_T *pkt_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_genPkt_stop(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_pl_initPfcMap(UI32_T unit);
#endif
