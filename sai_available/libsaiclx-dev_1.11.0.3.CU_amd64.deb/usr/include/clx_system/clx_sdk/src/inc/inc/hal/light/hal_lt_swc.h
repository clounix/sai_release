/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_swc.h
 * PURPOSE:
 *    Provide swc hal layer api.
 *
 * NOTES:
 *
 */

#ifndef HAL_LT_SWC_H
#define HAL_LT_SWC_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/*IPP hash engine for: ECMP, LAG*/
#define HAL_LT_SWC_HASH_ID_ECMP_L3    (0)
#define HAL_LT_SWC_HASH_ID_ECMP_NVO3  (1)
#define HAL_LT_SWC_HASH_ID_LAG        (2)
#define HAL_LT_SWC_HASH_ID_FABRIC_LAG (3)

/*EPP hash engine for: packet generation during tunnel initialization*/
#define HAL_LT_SWC_HASH_ID_MPLS_FLOW_LABEL        (0)
#define HAL_LT_SWC_HASH_ID_MPLS_FLOW_LABEL_MSB    (1)
#define HAL_LT_SWC_HASH_ID_MPLS_ENTROPY_LABEL     (2)
#define HAL_LT_SWC_HASH_ID_MPLS_ENTROPY_LABEL_MSB (3)

#define HAL_LT_SWC_HASH_ID_L3T_IPV6_FLOW_LABEL     (0)
#define HAL_LT_SWC_HASH_ID_L3T_IPV6_FLOW_LABEL_MSB (1)
#define HAL_LT_SWC_HASH_ID_VXLAN_UDP_SRC_PORT      (2)
#define HAL_LT_SWC_HASH_ID_NVGRE_FLOW_ID           (3)

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_LT_SWC_HASH_KEY_MAPPING_S {
    CLX_SWC_HASH_KEY_TYPE_T key_type;
    UI32_T field_id;
} HAL_LT_SWC_HASH_KEY_MAPPING_T;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM BODIES
 */
CLX_ERROR_NO_T
hal_lt_swc_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_swc_getIleBankType(const UI32_T unit,
                          const UI32_T bank_num,
                          const UI32_T is_ile_hash,
                          CLX_CFG_TYPE_T *ptr_cfg_type);

CLX_ERROR_NO_T
hal_lt_swc_setIleBankType(const UI32_T unit,
                          const UI32_T bank_num,
                          const UI32_T is_ile_hash,
                          CLX_CFG_TYPE_T cfg_type);

CLX_ERROR_NO_T
hal_lt_swc_getIleBankBitmap(const UI32_T unit, const CLX_CFG_TYPE_T cfg_type, UI32_T *ptr_bitmap);

/**
 * @brief Set hash engine polynominal coefficients
 *
 * It's caller's responsibility to pass an array of correct size.
 * For IPP hash engines, SDK need 24 UI32_T constants.
 * For EPP hash engines, SDK need 10 UI32_T constants.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     count             - Size (number of elements) of array pointed by ptr_hash_const
 * @param [in]     ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
hal_lt_swc_setHashConstant(const UI32_T unit,
                           const CLX_SWC_HASH_TYPE_T hash_type,
                           const UI32_T count,
                           const UI32_T *ptr_hash_const);

/**
 * @brief Get hash engine polynominal coefficients
 *
 * It's caller's responsibility to pass an array of correct size.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     count             - Size (number of elements) of array pointed by ptr_hash_const
 * @param [out]    ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_swc_getHashConstant(const UI32_T unit,
                           const CLX_SWC_HASH_TYPE_T hash_type,
                           const UI32_T count,
                           UI32_T *ptr_hash_const);

/**
 * @brief Set hash engine polynominal coefficients by a specific key field
 *
 * It's caller's responsibility to pass an array of correct size.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     key               - Hash key of interest
 * @param [in]     ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
hal_lt_swc_setHashConstantByKey(const UI32_T unit,
                                const CLX_SWC_HASH_TYPE_T hash_type,
                                const CLX_SWC_HASH_KEY_TYPE_T key,
                                const UI32_T *ptr_hash_const);

/**
 * @brief Get hash engine polynominal coefficients by a specific key field
 *
 * It's caller's responsibility to pass an array of correct size.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     key               - Hash key of interest
 * @param [out]    ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_swc_getHashConstantByKey(const UI32_T unit,
                                const CLX_SWC_HASH_TYPE_T hash_type,
                                const CLX_SWC_HASH_KEY_TYPE_T key,
                                UI32_T *ptr_hash_const);

/**
 * @brief set hash engine's hash key.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     hash_type     - Hash type
 * @param [in]     key_bitmap    - Hash key bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_swc_setHashKey(const UI32_T unit,
                      const CLX_SWC_HASH_TYPE_T hash_type,
                      const CLX_SWC_HASH_KEY_BITMAP_T key_bitmap);

/**
 * @brief Get switch control property.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash type
 * @param [in]     ptr_key_bitmap    - Pointer of key bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_swc_getHashKey(const UI32_T unit,
                      const CLX_SWC_HASH_TYPE_T hash_type,
                      CLX_SWC_HASH_KEY_BITMAP_T *ptr_key_bitmap);

/**
 * @brief Set exceptions to drop, to CPU or foward.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     enable    - Enable or restore exceptions
 * @param [in]     action    - Drop, forward or send to the CPU
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_swc_setException(const UI32_T unit, const UI32_T enable, const CLX_FWD_ACTION_T action);

/**
 * @brief Trap all packets to CPU.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     enable    - Enable or disable
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_swc_setTrapAll(const UI32_T unit, const UI32_T enable);

/**
 * @brief To initialize switch control module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK       - Operate success
 * @return         CLX_E_OTHER    - Init fail
 */
CLX_ERROR_NO_T
hal_lt_swc_init(const UI32_T unit);

/**
 * @brief To deinitialize switch control module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK       - Operate success
 * @return         CLX_E_OTHER    - Init fail
 */
CLX_ERROR_NO_T
hal_lt_swc_deinit(const UI32_T unit);

#endif /* End of HAL_LT_SWC_H */