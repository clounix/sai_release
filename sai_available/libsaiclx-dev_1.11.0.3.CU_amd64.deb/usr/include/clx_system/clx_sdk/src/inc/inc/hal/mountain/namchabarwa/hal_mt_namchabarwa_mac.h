/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/**
 * @brief CoMira MAC IP defines.
 *
 * @file hal_mt_namchabarwa_mac.h
 *
 */

#ifndef HAL_MT_NAMCHABARWA_MAC_H
#define HAL_MT_NAMCHABARWA_MAC_H

#include <api/diag.h>
#include <hal/hal_port.h>

#define HAL_MT_NAMCHABARWA_MAC_RXJABBER_DFT     0x3fff
#define HAL_MT_NAMCHABARWA_MAC_TXJABBER_DFT     0x3fff
#define HAL_MT_NAMCHABARWA_MAC_RXMAXFRMSIZE_DFT 1518
#define HAL_MT_NAMCHABARWA_MAC_PPH_LEANGTH      40
#define HAL_MT_NAMCHABARWA_MAC_OUTER_MAC_LENGTH 12
#define HAL_MT_NAMCHABARWA_CMAC_JABBER_DFT                                      \
    (HAL_MT_NAMCHABARWA_MAC_RXJABBER_DFT + HAL_MT_NAMCHABARWA_MAC_PPH_LEANGTH + \
     HAL_MT_NAMCHABARWA_MAC_OUTER_MAC_LENGTH)
#define HAL_MT_NAMCHABARWA_CMAC_RXMAXFRMSIZE_DFT HAL_MT_NAMCHABARWA_CMAC_JABBER_DFT

/* plane_idx of cpi port is used to ipl/epl, cmac defined in pcx and no need plane_idx */
#define HAL_MT_PORT_TO_PLANE_FOR_MAC(__unit__, __port__)             \
    (HAL_IS_CPI_PORT(__unit__, __port__) ?                           \
         0 :                                                         \
         ((HAL_IS_DEVICE_NAMCHABARWA_12_8T_FAMILY(__unit__)) ?       \
              (HAL_CL_PORT_TO_PLANE(__unit__, __port__) +            \
               (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__) / 4)) : \
              HAL_CL_PORT_TO_PLANE(__unit__, __port__)))

#define HAL_MT_PORT_TO_MACRO_FOR_MAC(__unit__, __port__)      \
    ((HAL_IS_DEVICE_NAMCHABARWA_12_8T_FAMILY(__unit__)) ?     \
         (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__) % 4) : \
         (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__)))

typedef enum {
    HAL_MT_NAMCHABARWA_DISABLED = 0,
    HAL_MT_NAMCHABARWA_10G_R1 = 15,
    HAL_MT_NAMCHABARWA_10G_R1_FC = 16,
    HAL_MT_NAMCHABARWA_25G_R1 = 21,
    HAL_MT_NAMCHABARWA_25G_R1_FC = 22,
    HAL_MT_NAMCHABARWA_25G_R1_RS = 23,
    HAL_MT_NAMCHABARWA_25G_R1_CON_RS = 24,
    HAL_MT_NAMCHABARWA_40G_R4 = 26,
    HAL_MT_NAMCHABARWA_40G_R4_FC = 27,
    HAL_MT_NAMCHABARWA_50G_R2 = 37,
    HAL_MT_NAMCHABARWA_50G_R2_RS = 39,
    HAL_MT_NAMCHABARWA_50G_R1_KP = 43,
    HAL_MT_NAMCHABARWA_100G_R2_KP_CK = 44,
    HAL_MT_NAMCHABARWA_100G_R1_KP_CK = 45,
    HAL_MT_NAMCHABARWA_100G_R4 = 46,
    HAL_MT_NAMCHABARWA_100G_R4_RS = 47,
    HAL_MT_NAMCHABARWA_100G_R2_KP = 50,
    HAL_MT_NAMCHABARWA_100G_R1_KP = 51,
    HAL_MT_NAMCHABARWA_200G_R8_KP = 52,
    HAL_MT_NAMCHABARWA_200G_R4_KP = 53,
    HAL_MT_NAMCHABARWA_200G_R2_KP = 54,
    HAL_MT_NAMCHABARWA_400G_R8_KP = 56,
    HAL_MT_NAMCHABARWA_400G_R4_KP = 57,
    HAL_MT_NAMCHABARWA_800G_R8_KP = 59,
    HAL_MT_NAMCHABARWA_800G_R8_CON_KP = 60,
    HAL_MT_NAMCHABARWA_100G_R4_KP_CK = 62,
    HAL_MT_NAMCHABARWA_CHMODE_LAST = 64,
} HAL_MT_NAMCHABARWA_MAC_CHMODE_E;

/* MAC IP type */
typedef enum {
    HAL_MT_NAMCHABARWA_MAC_UMAC = 0x0,
    HAL_MT_NAMCHABARWA_MAC_CMAC,
} HAL_MT_NAMCHABARWA_MAC_TYPE_E;

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setAppCfg0(UI32_T unit,
                                  UI32_T plane,
                                  UI32_T plane_port,
                                  UI32_T subinst_idx,
                                  HAL_MT_NAMCHABARWA_MAC_TYPE_E mac_type,
                                  UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_getAppCfg0(UI32_T unit,
                                  UI32_T plane,
                                  UI32_T plane_port,
                                  UI32_T subinst_idx,
                                  HAL_MT_NAMCHABARWA_MAC_TYPE_E mac_type,
                                  UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_getVersion(UI32_T unit,
                                  UI32_T plane,
                                  UI32_T plane_port,
                                  UI32_T subinst_idx,
                                  HAL_MT_NAMCHABARWA_MAC_TYPE_E mac_type,
                                  UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_getChSts(UI32_T unit,
                                UI32_T plane,
                                UI32_T plane_port,
                                UI32_T subinst_idx,
                                HAL_MT_NAMCHABARWA_MAC_TYPE_E mac_type,
                                UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setMacOverride(UI32_T unit, UI32_T port, UI32_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setChMode(UI32_T unit, UI32_T port, HAL_MT_NAMCHABARWA_MAC_CHMODE_E mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_getChMode(UI32_T unit, UI32_T port, HAL_MT_NAMCHABARWA_MAC_CHMODE_E *mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setLowLatency(UI32_T unit, UI32_T port, UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_getLowLatency(UI32_T unit, UI32_T port, UI32_T *enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setTxWrThrd(UI32_T unit, UI32_T port, UI32_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setTxRdThrd(UI32_T unit, UI32_T port, UI32_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setFcRxFilter(UI32_T unit, UI32_T port, UI32_T enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setJabber(const UI32_T unit,
                                 const UI32_T port,
                                 const UI32_T rxjabber,
                                 const UI32_T txjabber);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setMtu(const UI32_T unit, const UI32_T port, const UI32_T maxfrmsize);

/**
 * @brief This API is used to set the MAC address for a specific port.
 *
 * Example is as below.
 * CLX_MAC_T clx_mac = {0x0, 0x1, 0x2, 0x3, 0x4, 0x5};
 * UI32_T    hw_mac[2];
 * hw_mac[0] = 0x00010203;
 * hw_mac[1] = 0x0405;
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @param [in]     mac     - The MAC address.
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setMacAddr(const UI32_T unit, const UI32_T port, const CLX_MAC_T mac);

/**
 * @brief This API is used to get the MAC address for a specific port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port ID
 * @param [out]    ptr_mac    - The MAC address.
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_getMacAddr(const UI32_T unit, const UI32_T port, CLX_MAC_T *ptr_mac);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_wrap_reset(UI32_T unit, UI32_T plane, UI32_T eth_macro, UI32_T reset);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_wrap_cfgMisc(UI32_T unit, UI32_T plane, UI32_T eth_macro);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setFabric(UI32_T unit, UI32_T port, UI32_T fabric_en);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setTxPrbs(UI32_T unit, UI32_T port, UI32_T pattern);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_setRxPrbs(UI32_T unit, UI32_T port, UI32_T pattern);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mac_wrap_cfgMuxMapping(const UI32_T unit, UI32_T *init_112g);

#endif
