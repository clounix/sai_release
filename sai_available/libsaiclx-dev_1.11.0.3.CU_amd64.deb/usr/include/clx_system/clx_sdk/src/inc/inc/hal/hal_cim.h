/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_cim.h
 * PURPOSE:
 *  1. Provide Centralized Index Management API.
 * NOTES:
 */

#ifndef HAL_CIM_H
#define HAL_CIM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_cfg.h>
#include <cdb/cdb.h>
#include <hal/hal.h>
#include <hal/hal_tbl.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_CIM_SW_ENTRY_INFO_S {
    UI32_T hw_tbl_id;
    UI32_T base_index;
    UI32_T length;
    UI32_T used_cnt;
} HAL_CIM_SW_ENTRY_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Alloc/reuse table profile index，setting hw table and record reference count
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     field_num        - Number of fields to be set.
 * @param [in]     ptr_field        - The structure of CDB_FVP_T.
 * @param [in]     old_entry_idx    - Old profile entry index.
 * @param [out]    ptr_entry_idx    - Alloc profile entry indxe.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_TABLE_FULL         - Resources is full.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_addProfileEntry(const UI32_T unit,
                        const UI32_T boardcast_idx,
                        const UI32_T table_id,
                        const UI32_T field_num,
                        CDB_FVP_T *ptr_field,
                        const UI32_T old_entry_idx,
                        UI32_T *ptr_entry_idx);

/**
 * @brief Free table profile index，clear hw table, decreasing reference count.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     entry_idx        - The profile entry index
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found or not used.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_delProfileEntry(const UI32_T unit,
                        const UI32_T boardcast_idx,
                        const UI32_T table_id,
                        const UI32_T entry_idx);

/**
 * @brief Get profile entry index by table filed info.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     field_num        - Number of fields to be set.
 * @param [in]     ptr_field        - The structure of CDB_FVP_T.
 * @param [out]    ptr_entry_idx    - Profile entry index.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_getProfileEntryIndex(const UI32_T unit,
                             const UI32_T boardcast_idx,
                             const UI32_T table_id,
                             const UI32_T field_num,
                             CDB_FVP_T *ptr_field,
                             UI32_T *ptr_entry_idx);

/**
 * @brief Getting reference count.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     entry_idx        - Profile entry index
 * @param [out]    ptr_refcnt       - reference count
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_getProfileEntryRefCnt(const UI32_T unit,
                              const UI32_T boardcast_idx,
                              const UI32_T table_id,
                              const UI32_T entry_idx,
                              UI32_T *ptr_refcnt);

/**
 * @brief Modify reference count.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     entry_idx        - Profile entry index
 * @param [in]     count            - count to be increase or decrease
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_modifyProfileEntryRefCnt(const UI32_T unit,
                                 const UI32_T boardcast_idx,
                                 const UI32_T table_id,
                                 const UI32_T entry_idx,
                                 const I32_T count);

/**
 * @brief Allocating free index and setting hw table fields same info by sw table index.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     sw_table_id      - The software table id.
 * @param [in]     field_num        - Number of fields to be set.
 * @param [in]     count            - The requested consecutive count.
 * @param [in]     ptr_field        - The structure of CDB_FVP_T.
 * @param [out]    ptr_entry_idx    - The return index
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_TABLE_FULL         - Resources is full.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_allocIndexSwEntry(const UI32_T unit,
                          const UI32_T boardcast_idx,
                          const UI32_T sw_table_id,
                          const UI32_T field_num,
                          const UI32_T count,
                          CDB_FVP_T *ptr_field,
                          UI32_T *ptr_entry_idx);

/**
 * @brief Allocating free index and setting hw table fields same info by table id.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The hardware table id.
 * @param [in]     field_num        - Number of fields to be set.
 * @param [in]     count            - The requested consecutive count.
 * @param [in]     ptr_field        - The structure of CDB_FVP_T.
 * @param [out]    ptr_entry_idx    - The pointer of return index
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_TABLE_FULL         - Resources is full.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_allocIndexEntry(const UI32_T unit,
                        const UI32_T boardcast_idx,
                        const UI32_T table_id,
                        const UI32_T field_num,
                        const UI32_T count,
                        CDB_FVP_T *ptr_field,
                        UI32_T *ptr_entry_idx);

/**
 * @brief Allocating a free index and setting hw table fields different info by table id.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The hardware table id.
 * @param [in]     field_num        - Number of fields to be set.
 * @param [in]     count            - The requested consecutive count.
 * @param [in]     ptr_field        - The structure array of CDB_FVP_T.
 * @param [out]    ptr_entry_idx    - The return index
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_TABLE_FULL         - Resources is full.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_allocBulkIndexEntry(const UI32_T unit,
                            const UI32_T boardcast_idx,
                            const UI32_T table_id,
                            const UI32_T field_num,
                            const UI32_T count,
                            CDB_FVP_T **ptr_field,
                            UI32_T *ptr_entry_idx);

/**
 * @brief Setting an index and hw table.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The hardware table id.
 * @param [in]     entry_idx        - The entry index.
 * @param [in]     field_num        - Number of fields to be set.
 * @param [in]     ptr_field        - The structure of CDB_FVP_T.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 */
CLX_ERROR_NO_T
hal_cim_setIndexEntry(const UI32_T unit,
                      const UI32_T boardcast_idx,
                      const UI32_T table_id,
                      const UI32_T entry_idx,
                      const UI32_T field_num,
                      CDB_FVP_T *ptr_field);

/**
 * @brief Free entry index
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     entry_idx        - The return index
 * @param [in]     count            - The consecutive count.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 */
CLX_ERROR_NO_T
hal_cim_freeIndexEntry(const UI32_T unit,
                       const UI32_T boardcast_idx,
                       const UI32_T table_id,
                       const UI32_T entry_idx,
                       const UI32_T count);

/**
 * @brief Getting free entry index count by table id
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The hardware table id.
 * @param [out]    ptr_cnt          - return free count.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 */
CLX_ERROR_NO_T
hal_cim_getFreeEntryCnt(const UI32_T unit,
                        const UI32_T boardcast_idx,
                        const UI32_T table_id,
                        UI32_T *ptr_cnt);

/**
 * @brief Getting free entry index count by sw table id
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     sw_table_id      - The software table id.
 * @param [out]    ptr_cnt          - return free count.
 * @return         CLX_E_OK        - Successfully init table.
 * @return         CLX_E_OTHERS    - Fail to init table.
 */
CLX_ERROR_NO_T
hal_cim_getFreeSwEntryCnt(const UI32_T unit,
                          const UI32_T boardcast_idx,
                          const UI32_T sw_table_id,
                          UI32_T *ptr_cnt);

/**
 * @brief Getting sw entry info
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     sw_table_id      - The software table id.
 * @param [out]    ptr_info         - software entry info.
 * @return         CLX_E_OK                 - Successfully get sw table info.
 * @return         CLX_E_ENTRY_NOT_FOUND    - not found entry
 */
CLX_ERROR_NO_T
hal_cim_getSwEntryInfo(const UI32_T unit,
                       const UI32_T boardcast_idx,
                       const UI32_T sw_table_id,
                       HAL_CIM_SW_ENTRY_INFO_T *ptr_info);

/**
 * @brief Checking entry index is valid or not.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The hardware table id.
 * @param [in]     entry_idx        - The table index
 * @return         CLX_E_OK                 - entry is found.
 * @return         CLX_E_ENTRY_NOT_FOUND    - entry is not found.
 */
CLX_ERROR_NO_T
hal_cim_checkIndexEntry(const UI32_T unit,
                        const UI32_T boardcast_idx,
                        const UI32_T table_id,
                        const UI32_T entry_idx);

/**
 * @brief Reseting allocated bmp size
 *
 * @param [in]     unit              - The unit number.
 * @param [in]     sw_table_id       - The software table id.
 * @param [in]     ptr_entry_info    - The sw entry info.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - entry is not found.
 */
CLX_ERROR_NO_T
hal_cim_resetBmpSize(const UI32_T unit,
                     const UI32_T sw_table_id,
                     const HAL_CIM_SW_ENTRY_INFO_T *ptr_entry_info);

/**
 * @brief Setting hw table and record reference count by entry field.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     ptr_field        - The structure of CDB_FVP_T.
 * @param [in]     old_entry_idx    - Old entry index.
 * @param [out]    ptr_entry_idx    - The return index
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_TABLE_FULL         - Resources is full.
 * @return         CLX_E_OTHERS             - Operation Failed.
 * @return         CLX_E_NOT_SUPPORT        - Operation not support.
 */
CLX_ERROR_NO_T
hal_cim_addFieldProfileEntry(const UI32_T unit,
                             const UI32_T boardcast_idx,
                             const UI32_T table_id,
                             CDB_FVP_T *ptr_field,
                             const UI32_T old_entry_idx,
                             UI32_T *ptr_entry_idx);

/**
 * @brief Free table field profile index，clear hw table field，decreasing reference count by entry
 * field.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     entry_idx        - The return index.
 * @param [in]     field_id         - The field id.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
CLX_ERROR_NO_T
hal_cim_delFieldProfileEntry(const UI32_T unit,
                             const UI32_T boardcast_idx,
                             const UI32_T table_id,
                             const UI32_T entry_idx,
                             const UI32_T field_id);

/**
 * @brief Getting field profile reference count.
 *
 * @param [in]     unit             - The unit number.
 * @param [in]     boardcast_idx    - The inst or subinst index，bc use CDB_INST_IDX_BCAST.
 * @param [in]     table_id         - The table id.
 * @param [in]     entry_idx        - The return index.
 * @param [in]     field_id         - The field id.
 * @param [out]    ptr_refcnt       - return reference count
 * @return         CLX_E_OK                 - Successfully get
 * @return         CLX_E_OTHERS             - Error index type
 * @return         CLX_E_ENTRY_NOT_FOUND    - Fail to search table id
 */
CLX_ERROR_NO_T
hal_cim_getFieldProfileEntryRefCnt(const UI32_T unit,
                                   const UI32_T boardcast_idx,
                                   const UI32_T table_id,
                                   const UI32_T entry_idx,
                                   const UI32_T field_id,
                                   UI32_T *ptr_refcnt);

/**
 * @brief cim init.
 *
 * @param [in]     unit    - The unit number.
 * @return         CLX_E_OK        - Successfully init
 * @return         CLX_E_OTHERS    - Error index
 */
CLX_ERROR_NO_T
hal_cim_init(const UI32_T unit);

/**
 * @brief cim deinit.
 *
 * @param [in]     unit    - The unit number.
 * @return         CLX_E_OK        - Successfully init
 * @return         CLX_E_OTHERS    - Free cim sem failed
 */
CLX_ERROR_NO_T
hal_cim_deinit(const UI32_T unit);

#endif /* #ifndef HAL_CIM_H */
