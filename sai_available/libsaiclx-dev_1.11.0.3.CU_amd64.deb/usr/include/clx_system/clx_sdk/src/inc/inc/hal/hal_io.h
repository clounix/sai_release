/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_io.h
 * PURPOSE:
 *      1. hal_io.h provides HAL IO manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_IO_H
#define HAL_IO_H

#include <clx_module.h>
#include <cmlib/cmlib_avl.h>
#include <cmlib/cmlib_list.h>
#include <cmlib/cmlib_hash.h>

typedef struct HAL_IO_SUB_HDR_S {
    UI32_T cnt;      /* meta unit count */
    UI32_T unit_len; /* the length of one meta unit */
} HAL_IO_SUB_HDR_T;

typedef struct HAL_IO_SWDB_AVL_COOKIE_S {
    HAL_IO_SUB_HDR_T header;
    C8_T *ptr_data;
} HAL_IO_SWDB_AVL_COOKIE_T;

typedef struct HAL_IO_OBJ_META_S {
    UI32_T obj_id;
    UI32_T obj_ver;
    UI32_T data_size;
    C8_T *ptr_data;
} HAL_IO_OBJ_META_T;

typedef struct HAL_IO_WB_DB_S {
    UI32_T max_cnt;        /* used when closeNonVolatile */
    UI32_T cur_idx;        /* used when addWbObj         */
    UI32_T total_obj_size; /* used when closeNonVolatile */
    HAL_IO_OBJ_META_T *ptr_objs;
} HAL_IO_WB_DB_T;

CLX_ERROR_NO_T
hal_io_openNonvolatile(const UI32_T unit, const UI32_T write_mode);

CLX_ERROR_NO_T
hal_io_closeNonvolatile(const UI32_T unit);

CLX_ERROR_NO_T
hal_io_getNonvolatile(const UI32_T unit,
                      const CLX_MODULE_T module,
                      C8_T **pptr_buf,
                      UI32_T *ptr_num_bytes);

/**
 * @brief The function is used to save AVL tree to buffer. Please note that
 *        avl node should not have pointer field.
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_avl         - Pointer of the avl tree head
 * @param [in]     ptr_obj_meta    - Object Meta for the avl storage
 * @param [out]    ptr_obj_meta    - Object Meta for the avl storage
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_io_saveAvlTree(const UI32_T length,
                   const CMLIB_AVL_HEAD_T *ptr_avl,
                   HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief The function is used to restore AVL tree from buffer
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_avl         - Pointer of the avl tree head
 * @param [in]     ptr_obj_meta    - Object Meta for the avl storage
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_io_restoreAvlTree(const UI32_T length,
                      const CMLIB_AVL_HEAD_T *ptr_avl,
                      const HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief The function is used to save List to buffer. Please note that
 *        list node should not have pointer field.
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_list        - Pointer of the list head
 * @param [in]     ptr_obj_meta    - Object Meta for the list storage
 * @param [out]    ptr_obj_meta    - Object Meta for the list storage
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_io_saveList(const UI32_T length, const CMLIB_LIST_T *ptr_list, HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief The function is used to restore List from buffer
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_list        - Pointer of the List head
 * @param [in]     ptr_obj_meta    - Object Meta for the list storage
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_io_restoreList(const UI32_T length,
                   const CMLIB_LIST_T *ptr_list,
                   const HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief The function is used to save Array to buffer. Please note that
 *        1. array node should not have pointer field.
 *
 * @param [in]     length          - Node size
 * @param [in]     count           - Node count
 * @param [in]     ptr_array       - Pointer of the array head
 * @param [in]     ptr_obj_meta    - Object Meta for the array storage
 * @param [out]    ptr_obj_meta    - Object Meta for the array storage
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_io_saveArray(const UI32_T length,
                 const UI32_T count,
                 const void *ptr_array,
                 HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief The function is used to restore Array from buffer
 *
 * @param [in]     ptr_array       - Pointer of the Array head
 * @param [in]     ptr_obj_meta    - Object Meta for the array storage
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_io_restoreArray(void *ptr_array, const HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief The function is used to save hash table to buffer.
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_hash_tbl    - Pointer of the hash table
 * @param [in]     ptr_obj_meta    - Object Meta for the hash table
 * @param [out]    ptr_obj_meta    - Object Meta for the hash table
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_NO_MEMORY - No memory.
 */
CLX_ERROR_NO_T
hal_io_saveHashTbl(const UI32_T length,
                   CMLIB_HASH_TBL_T *ptr_hash_tbl,
                   HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief The function is used to restore hash table from buffer
 *
 * @param [in]     length          - Node size
 * @param [in]     key_offset      - Key offset in node
 * @param [in]     ptr_obj_meta    - Object Meta for the hash table
 * @param [in]     ptr_hash_tbl    - Pointer of the hash table
 * @param [out]    ptr_hash_tbl    - Pointer of the hash table
 * @return         CLX_E_OK    - Operate success.
 */
CLX_ERROR_NO_T
hal_io_restoreHashTbl(const UI32_T length,
                      const UI32_T key_offset,
                      const HAL_IO_OBJ_META_T *ptr_obj_meta,
                      CMLIB_HASH_TBL_T *ptr_hash_tbl);

/**
 * @brief The function is used to create a warmboot database.
 *
 * @param [in]     obj_count    - Total object count
 * @param [out]    pptr_db      - Pointer to the warmboot database
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_io_createWbDb(UI32_T obj_count, HAL_IO_WB_DB_T **pptr_db);

/**
 * @brief The function is used to add object(s) to warmboot database.
 *
 * @param [in]     ptr_db       - Pointer to the warmboot database
 * @param [out]    obj_count    - Object count to be added
 * @param [out]    ptr_objs     - Objects to be added
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_io_addWbObj(HAL_IO_WB_DB_T *ptr_db, UI32_T obj_count, HAL_IO_OBJ_META_T *ptr_objs);

/**
 * @brief The function is used to dump warmboot database to nonvolatile storage
 *
 * @param [in]     unit      - Device unit
 * @param [in]     module    - Module id
 * @param [in]     ptr_db    - Pointer to the warmboot database
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_io_writeWbDb(UI32_T unit, CLX_MODULE_T module, HAL_IO_WB_DB_T *ptr_db);

/**
 * @brief The function is used to destroy warmboot database
 *        after dumping to nonvolatile storage
 *
 * @param [in]     ptr_db    - Pointer to the warmboot database
 */
void
hal_io_destroyWbDb(HAL_IO_WB_DB_T *ptr_db);

/**
 * @brief The function is used to read warmboot database from nonvolatile storage
 *
 * WbDb format in Nonvolatile Data:
 *              +----------------------------------------------+
 * 0x00         | Object Count                                 |
 *              +----------------------------------------------+
 * 0x04         | Object 1 Offset                              |
 *              +----------------------------------------------+
 * 0x08         | Object 2 Offset                              |
 *              +----------------------------------------------+
 * 0x12         | Object 3 Offset                              |
 *              +----------------------------------------------+
 * 0x16         | Object 4 Offset                              |
 *              +----------------------------------------------+
 * (4 + 4(N-1)) | Object N Offset                              |
 *              +----------------------------------------------+
 * (4 + 4N)     | <Object 1>                                   |
 *              | Obj1_ID | Obj1_VER | Obj1_DATA (with size s1)|
 *              +----------------------------------------------+
 * (4 + 4N      | <Object 2>                                   |
 * + 8 + s1 )   | Obj2_ID | Obj2_VER | Obj2_DATA (with size s2)|
 *              +----------------------------------------------+
 * (4+4N+8+s1   | <Object 3>                                   |
 * + 8 + s2)    | Obj3_ID | Obj3_VER | Obj3_DATA (with size s3)|
 *              +----------------------------------------------+
 * (4+4N+8(N-1) | <Object N>                                   |
 * + sigma      | Objn_ID | Objn_VER | Objn_DATA (with size sn)|
 * (s[1~n-1]))  |                                              |
 *              +----------------------------------------------+
 *
 * @param [in]     unit       - Device unit
 * @param [in]     module     - Module id
 * @param [out]    pptr_db    - Pointer to the warmboot database
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_io_readWbDb(UI32_T unit, CLX_MODULE_T module, HAL_IO_WB_DB_T **pptr_db);

/**
 * @brief The function is used to get object from warmboot database
 *
 * It would try to find the best-matched object by obj_ver from wbdb.
 * If possible, it returns the object with obj_ver = CLX_WB_VER_RELEASE;
 * if not found, it returns the object with the closest version.
 *
 * @param [in]     ptr_db     - Pointer to the warmboot database
 * @param [in]     obj_id     - Object id
 * @param [out]    ptr_obj    - Object
 * @return         CLX_E_OK                 - Object with same obj_id is found
 * @return         CLX_E_ENTRY_NOT_FOUND    - Object is not found
 */
CLX_ERROR_NO_T
hal_io_getWbObj(const HAL_IO_WB_DB_T *ptr_db, UI32_T obj_id, HAL_IO_OBJ_META_T *ptr_obj);

/**
 * @brief The function is used to get currently loaded nonvolitile version
 *
 * @param [in]     unit    - Device unit
 * @return         db_ver    - Currently loaded nonvolitile version
 */
UI32_T
hal_io_getDbVer(UI32_T unit);

#endif /* #ifndef HAL_IO_H */