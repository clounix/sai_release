/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_meter.h
 * PURPOSE:
 *    Provide HAL driver API functions for light family
 *
 * NOTES:
 *    None
 */

#ifndef HAL_LT_METER_H
#define HAL_LT_METER_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_meter.h>
#include <hal/hal_meter.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Meter config initialize
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_meter_initCfg(const UI32_T unit);

/**
 * @brief Set meter bank config register
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Resource type
 * @param [in]     bank_idx    - bank id
 * @param [in]     enable      - enable or disable
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_meter_setMeterCfgReg(const UI32_T unit,
                            const HAL_METER_TYPE_T type,
                            const UI32_T bank_idx,
                            const BOOL_T enable);

/**
 * @brief Translate meter hw index
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_hw_index    - meter hw index
 * @param [out]    ptr_hw_idx      - hw index
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_meter_transMeterHwIdx(const UI32_T unit,
                             const HAL_METER_INDEX_T *ptr_hw_index,
                             UI32_T *ptr_hw_idx);

/**
 * @brief Translate meter index
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     hw_idx          - hw index
 * @param [out]    ptr_hw_index    - meter hw index
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_meter_transMeterIndex(const UI32_T unit,
                             const UI32_T hw_idx,
                             HAL_METER_INDEX_T *ptr_hw_index);

/**
 * @brief Set meter pool
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_sw_meter    - sw meter
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_meter_setMeterPool(const UI32_T unit, const HAL_METER_SW_METER_T *ptr_sw_meter);

/**
 * @brief Set Ingress port meter config
 *
 * @param [in]     unit           - Device port meter
 * @param [in]     port           - Physical port id
 * @param [in]     ptr_cfg        - Port meter config
 * @param [in]     ptr_hal_cfg    - Hal meter config
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_meter_setIgrPortMeter(const UI32_T unit,
                             const UI32_T port,
                             const CLX_METER_PORT_CFG_T *ptr_cfg,
                             const HAL_METER_CFG_T *ptr_hal_cfg);

/**
 * @brief Get ingress port meter config
 *
 * @param [in]     unit       - Device unit
 * @param [in]     port       - Physical port id
 * @param [out]    ptr_cfg    - Port meter config
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_meter_getIgrPortMeter(const UI32_T unit, const UI32_T port, CLX_METER_PORT_CFG_T *ptr_cfg);

/**
 * @brief allocate icia or ecia cnt_mtr_prof entry. meter and counter is disabled
 *        by default.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [in]     ingress                 - Ingress or egress.
 * @param [out]    ptr_cnt_mtr_prof_idx    - cnt_mtr_prof entry index.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_lt_meter_allocCntMtrProf(const UI32_T unit, const BOOL_T ingress, UI32_T *ptr_cnt_mtr_prof_idx);

/**
 * @brief free icia or ecia cnt_mtr_prof entry.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     ingress             - Ingress or egress.
 * @param [in]     cnt_mtr_prof_idx    - cnt_mtr_prof entry index.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_lt_meter_freeCntMtrProf(const UI32_T unit, const BOOL_T ingress, const UI32_T cnt_mtr_prof_idx);

/**
 * @brief set hw meter or counter index into into icia or ecia cnt_mtr_prof entry.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     ingress             - Ingress or egress.
 * @param [in]     cnt_mtr_prof_idx    - cnt_mtr_prof entry index.
 * @param [in]     cnt_mtr_field       - Select meter or counter.
 * @param [in]     cnt_mtr_hw_idx      - Hw meter or counter index.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_lt_meter_setCntMtrProf(const UI32_T unit,
                           const BOOL_T ingress,
                           const UI32_T cnt_mtr_prof_idx,
                           const HAL_METER_CNT_MTR_FIELD_T cnt_mtr_field,
                           const UI32_T cnt_mtr_hw_idx);

/**
 * @brief get hw meter or counter index from icia or ecia cnt_mtr_prof entry.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     ingress               - Ingress or egress.
 * @param [in]     cnt_mtr_prof_idx      - cnt_mtr_prof entry index.
 * @param [in]     cnt_mtr_field         - Select meter or counter.
 * @param [out]    ptr_cnt_mtr_hw_idx    - Hw meter or counter index.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_lt_meter_getCntMtrProf(const UI32_T unit,
                           const BOOL_T ingress,
                           const UI32_T cnt_mtr_prof_idx,
                           const HAL_METER_CNT_MTR_FIELD_T cnt_mtr_field,
                           UI32_T *ptr_cnt_mtr_hw_idx);

/**
 * @brief check if any meter or counter exists in icia or ecia cnt_mtr_prof entry.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     ingress              - Ingress or egress.
 * @param [in]     cnt_mtr_prof_idx     - cnt_mtr_prof entry index.
 * @param [out]    ptr_cnt_mtr_exist    - any meter or counter exists or not.
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - bad parameter
 */
CLX_ERROR_NO_T
hal_lt_meter_checkCntMtrProf(const UI32_T unit,
                             const BOOL_T ingress,
                             const UI32_T cnt_mtr_prof_idx,
                             BOOL_T *ptr_cnt_mtr_exist);

#endif /* End of HAL_LT_METER_H */
