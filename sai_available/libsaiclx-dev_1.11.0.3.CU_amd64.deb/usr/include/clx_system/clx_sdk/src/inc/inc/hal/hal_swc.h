/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_swc.h
 * PURPOSE:
 *      It provides hal switch control module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_SWC_H
#define HAL_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_cfg.h>
#include <clx_swc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/*IPP hash engine for: ECMP, LAG*/
#define HAL_SWC_HASH_ID_ECMP_L3    (0)
#define HAL_SWC_HASH_ID_ECMP_NVO3  (1)
#define HAL_SWC_HASH_ID_LAG        (2)
#define HAL_SWC_HASH_ID_FABRIC_LAG (3)

/*EPP hash engine for: packet generation during tunnel initialization*/
#define HAL_SWC_HASH_ID_MPLS_FLOW_LABEL        (0)
#define HAL_SWC_HASH_ID_MPLS_FLOW_LABEL_MSB    (1)
#define HAL_SWC_HASH_ID_MPLS_ENTROPY_LABEL     (2)
#define HAL_SWC_HASH_ID_MPLS_ENTROPY_LABEL_MSB (3)

#define HAL_SWC_HASH_ID_L3T_IPV6_FLOW_LABEL     (0)
#define HAL_SWC_HASH_ID_L3T_IPV6_FLOW_LABEL_MSB (1)
#define HAL_SWC_HASH_ID_VXLAN_UDP_SRC_PORT      (2)
#define HAL_SWC_HASH_ID_NVGRE_FLOW_ID           (3)

#define HAL_SWC_ILE_HASH_BANK_NUM                  (16)
#define HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK        (16 * 1024)
#define HAL_SWC_FPU_HASH_POLICY_ENTRY_NUM_PER_BANK (10 * 1024) /*need to rename*/

#define HAL_SWC_ILE_TCAM_BANK_NUM  (64)
#define HAL_SWC_ILE_TCAM_ENTRY_NUM (16 * 1024)

#define HAL_SWC_HASH_L2_FDB_REGION_MAX           (14 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L2_FDB_REGION_DEFAULT       (4 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L2_GROUP_REGION_DEFAULT     (1 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_128_REGION_DEFAULT       (1 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_64_REGION_DEFAULT        (1 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_NO_PREFIEX_DEFAULT       (6 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_SECURITY_REGION_DEFAULT     (1 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_FLOW_REGION_DEFAULT         (2 * HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_TCAM_L2_FDB_REGION_DEFAULT       (3 * 512)
#define HAL_SWC_TCAM_L2_FDB_GROUP_REGION_DEFAULT (1 * 512)
#define HAL_SWC_TCAM_L3_128_REGION_DEFAULT       (HAL_SWC_ILE_TCAM_ENTRY_NUM / 2)
#define HAL_SWC_TCAM_L3_64_REGION_DEFAULT        (HAL_SWC_ILE_TCAM_ENTRY_NUM / 2)

/*ILE TCAM bank define*/
#define HAL_SWC_ILE_TCAM_128_BMP(unit) _hal_swc_cb[unit]._ile_tcam_128_bmp
#define HAL_SWC_ILE_TCAM_64_BMP(unit)  _hal_swc_cb[unit]._ile_tcam_64_bmp

#define HAL_SWC_EPG_2B      (2)
#define HAL_SWC_EPG_4B      (4)
#define HAL_SWC_EPG_6B      (6)
#define HAL_SWC_EPG_PLD_LEN (128)

#define HAL_SWC_EXCEPTION_WORD_NUM              (10) /* 4 ids, 4 iev, 2 eme */
#define HAL_SWC_TRAP_ALL_CFG_CTRL2CPU_ENTRY_NUM (4)
#define HAL_SWC_TRAP_ALL_CFG_EXCEPTION_WORD_NUM (HAL_SWC_EXCEPTION_WORD_NUM)
/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SWC_LOCK(unit) \
    HAL_COMMON_LOCK_RESOURCE(&(_hal_swc_cb[unit].sema_id), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_SWC_UNLOCK(unit)                 HAL_COMMON_FREE_RESOURCE(&(_hal_swc_cb[unit].sema_id))
#define HAL_SWC_CONST_EMI(__unit__, __idx__) (PTR_HAL_CONST_INFO(__unit__, swc)->emi[__idx__])

/* 25.6T 1FPU 24TILE and 32K TCAM; 12.8T 2FPU 48TILE and 64k TCAM*/
#define HAL_SWC_FPU_NUM   (2)
#define HAL_SWC_FPU_INST0 (0)
#define HAL_SWC_FPU_INST1 (1)

#define HAL_SWC_HASH_STAGE_NUM          (3)
#define HAL_SWC_HASH_TILE_NUM_PER_STAGE (8)
#define HAL_SWC_HASH_TILE_NUM           (24)
#define HAL_SWC_HASH_TILE_WORD_WIDTH    (32)
#define HAL_SWC_HASH_TILE_BITMAP_SIZE \
    (((HAL_SWC_HASH_TILE_NUM - 1) / HAL_SWC_HASH_TILE_WORD_WIDTH) + 1)

typedef UI32_T HAL_SWC_HASH_TILE_BITMAP_T[HAL_SWC_HASH_TILE_BITMAP_SIZE * 2];

#define HAL_SWC_TCAM_TYPE         (2)
#define HAL_SWC_TCAM_NUM_PER_TYPE (16)
#define HAL_SWC_TCAM_NUM          (HAL_SWC_TCAM_TYPE * HAL_SWC_TCAM_NUM_PER_TYPE)
#define HAL_SWC_TCAM_ENTRY_NUM    (HAL_SWC_TCAM_NUM * 1024)
#define HAL_SWC_TCAM_WORD_WIDTH   (32)
#define HAL_SWC_TCAM_BITMAP_SIZE  (((HAL_SWC_TCAM_NUM - 1) / HAL_SWC_TCAM_WORD_WIDTH) + 1)
#define HAL_SWC_TCAM_CFG_FIELD    (4)

typedef UI32_T HAL_SWC_TCAM_BITMAP_T[HAL_SWC_TCAM_BITMAP_SIZE * 2];

#define HAL_SWC_HASH_TILE_PRI_NUM_PER_FPU (12)
#define HAL_SWC_HASH_TILE_PRI_NUM         (HAL_SWC_HASH_TILE_PRI_NUM_PER_FPU * 2)
/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_SWC_WBDB_CFG_ID = 0,
    HAL_SWC_WBDB_CIM_ID,
    HAL_SWC_WBDB_OBJ_LAST
} HAL_SWC_WBDB_OBJ_TYPE_T;

typedef enum {
    HAL_SWC_CAP_EMI_BANK_NUM = 0,
    HAL_SWC_CAP_EMI_NSH_BANK_BASE,
    HAL_SWC_CAP_EMI_PAGE_PER_BANK,
    HAL_SWC_CAP_EMI_ENTRY_PER_BANK,
    HAL_SWC_CAP_EMI_LAST
} HAL_SWC_CAP_EMI_TYPE_T;

typedef struct {
    CLX_MAC_T dmac;
    CLX_MAC_T smac;

    UI16_T tpid;
    UI32_T pcp;
    UI32_T dei;
    UI32_T vid;

    UI32_T ip; /* user inputs sip&dip */
    CLX_IP_ADDR_T sip;
    CLX_IP_ADDR_T dip;

    UI32_T len;
    UI32_T num;
    CLX_PORT_SPEED_T speed;
    CLX_PORT_BITMAP_T pbm;

    UI8_T pld[HAL_SWC_EPG_PLD_LEN];
    UI32_T pld_len;

    UI8_T fill;

    UI32_T rep_num;
    UI32_T duration;
} HAL_SWC_EPG_PKT_T;

typedef struct HAL_SWC_ERROR_HANDLER_S {
    UI32_T valid;
    CLX_SWC_ERROR_FUNC_T callback;
    void *ptr_cookie;
} HAL_SWC_ERROR_HANDLER_T;

typedef struct {
    CLX_PKT_CTRL_TO_CPU_ENTRY_T ctrl2cpu_entry[HAL_SWC_TRAP_ALL_CFG_CTRL2CPU_ENTRY_NUM];
    UI32_T excpt_word[HAL_SWC_TRAP_ALL_CFG_EXCEPTION_WORD_NUM];

} HAL_SWC_TRAP_ALL_CFG_USR_DATA;

typedef struct {
    BOOL_T enabled;
    HAL_SWC_TRAP_ALL_CFG_USR_DATA usr_data;

} HAL_SWC_TRAP_ALL_CFG_T;

typedef CLX_ERROR_NO_T (*HASH_TILE_CFG)(UI32_T unit, UI32_T entry_num);

typedef struct {
    HAL_SWC_TCAM_BITMAP_T tcam_bmp;
    UI32_T tcam_counter;
    UI32_T l3_route_tcam_start_index;
    UI32_T l3_host_tcam_start_index;
    UI32_T l2_tcam_start_index;
} HAL_SWC_TCAM_USED_T;

typedef struct {
    HAL_SWC_TCAM_BITMAP_T tcam_bmp;
    UI32_T tcam_counter;
    UI32_T tcam_start_index;
    UI32_T tcam_end_index;
} HAL_SWC_TCAM_INFO_T;

typedef struct {
    CLX_SWC_HASH_TILE_TYPE_T hash_tile_type;
    HASH_TILE_CFG hash_tile_cfg;
} HAL_SWC_HAL_TILE_CFG_T;

typedef struct {
    HAL_SWC_HASH_TILE_BITMAP_T hash_tile_bmp;
    UI32_T hash_tile_counter;
    UI32_T hash_tile[HAL_SWC_FPU_NUM * HAL_SWC_HASH_TILE_NUM];
    UI32_T high_pri;
    UI32_T low_pri;
} HAL_SWC_HASH_TILE_INFO_T;

typedef struct {
    UI32_T tile_pri;
    UI32_T tile_used;
} HAL_SWC_HASH_TILE_PRI_T;

typedef struct HAL_SWC_CB_S {
    CLX_SWC_HASH_KEY_BITMAP_T key_bitmap[CLX_SWC_HASH_TYPE_LAST];
    CLX_SEMAPHORE_ID_T sema_id;
    UI32_T _ile_tcam_128_bmp[CLX_BITMAP_SIZE(HAL_SWC_ILE_TCAM_BANK_NUM)];
    UI32_T _ile_tcam_64_bmp[CLX_BITMAP_SIZE(HAL_SWC_ILE_TCAM_BANK_NUM)];
    UI32_T _ile_hash_l2_fdb_base;
    UI32_T _ile_hash_l2_fdb_bank_num;
    CLX_CFG_TYPE_T _ile_hash_bank_type[HAL_SWC_ILE_HASH_BANK_NUM];
    CLX_CFG_TYPE_T _ile_tcam_bank_type[HAL_SWC_ILE_TCAM_BANK_NUM];
    HAL_SWC_ERROR_HANDLER_T error_handler[CLX_SWC_ERROR_SRC_LAST];
    CLX_SWC_CSO_MODE_T cso_mode;
    /* Set excetions to drop or CPU. Not support warmboot */
    UI32_T excpt_ctrl_en;
    UI32_T excpt_en_bmp[HAL_SWC_EXCEPTION_WORD_NUM];
    UI32_T excpt_trap_en_bmp[HAL_SWC_EXCEPTION_WORD_NUM];
    UI32_T excpt_supp_cpu_cp_bmp[HAL_SWC_EXCEPTION_WORD_NUM];

    /* Database for trap-all config */
    HAL_SWC_TRAP_ALL_CFG_T trap_all_cfg;

    /* HASH configuration*/
    HAL_SWC_HASH_TILE_INFO_T hash_tile_info[CLX_SWC_HASH_TILE_TYPE_LAST];
    HAL_SWC_HASH_TILE_PRI_T hash_tile_pri[HAL_SWC_FPU_NUM][HAL_SWC_HASH_STAGE_NUM]
                                         [HAL_SWC_HASH_TILE_NUM_PER_STAGE];
    UI32_T hash_pri_num[HAL_SWC_HASH_TILE_PRI_NUM];
    UI32_T hash_pri_min;

    /* TCAM configuration*/
    HAL_SWC_TCAM_INFO_T tcam_info[CLX_SWC_TCAM_TYPE_LAST];
    HAL_SWC_TCAM_USED_T tcam_used;

    /* Memory check flag*/
    CDB_MEM_CHECK_T mem_check;
} HAL_SWC_CB_T;

typedef struct HAL_SWC_HASH_REG_INFO_S {
    UI32_T plane;  /* plane id */
    UI32_T reg_id; /*register id*/
    UI32_T reg_num;
    UI32_T field_id;
    UI32_T *ptr_field_values;
} HAL_SWC_HASH_REG_INFO_T;
/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
/**
 * @brief Set switch control property.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [in]     param0      - First parameter
 * @param [in]     param1      - Second parameter
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_setProperty(const UI32_T unit,
                    const CLX_SWC_PROPERTY_T property,
                    const UI32_T param0,
                    const UI32_T param1);

/**
 * @brief Get switch control property.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [out]    ptr_param0  - First parameter
 * @param [out]    ptr_param1  - Second parameter
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getProperty(const UI32_T unit,
                    const CLX_SWC_PROPERTY_T property,
                    UI32_T *ptr_param0,
                    UI32_T *ptr_param1);

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_swc_getChipTemperature(const UI32_T unit, I32_T *ptr_temperature);

/**
 * @brief Set timestamp value of system.
 *
 * @param [in]     unit       - Chip id
 * @param [in]     sec_hi     - Bit[47:32] seconds for timestamp
 * @param [in]     sec_low    - Bit[31:0]  seconds for timestamp
 * @param [in]     nsec       - Bit[29:0]  nano seconds for timestamp
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_swc_setTsValue(const UI32_T unit, UI16_T sec_hi, UI32_T sec_low, UI32_T nsec);

/**
 * @brief Get timestamp value of system.
 *
 * @param [in]     unit           - Chip id
 * @param [in]     ptr_sec_hi     - Bit[47:32] seconds for timestamp
 * @param [in]     ptr_sec_low    - Bit[31:0]  seconds for timestamp
 * @param [in]     ptr_nsec       - Bit[29:0]  nano seconds for timestamp
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_swc_getTsValue(const UI32_T unit, UI16_T *ptr_sec_hi, UI32_T *ptr_sec_low, UI32_T *ptr_nsec);

/**
 * @brief Set timestamp offset.
 *
 * @param [in]     unit    - Chip id
 * @param [in]     nsec    - Signed nano seconds for timestamp offset
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_swc_setTsOffset(const UI32_T unit, const I32_T nsec);

/**
 * @brief Set the configuration of egress view of steering.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_str_entry    - Structure of egress steering
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_setSteering(const UI32_T unit, const CLX_SWC_STEERING_ENTRY_T *ptr_str_entry);

/**
 * @brief Get the configuration of egress view of steering.
 *
 * @param [in]     unit    - Device unit number
 * @param [out]    ptr_str_entry    - Structure of egress steering
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getSteering(const UI32_T unit, CLX_SWC_STEERING_ENTRY_T *ptr_str_entry);

/**
 * @brief Register error callback function.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     error         - error source type
 * @param [in]     callback      - The callback function of type CLX_SWC_ERROR_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_registerErrorCallback(const UI32_T unit,
                              const CLX_SWC_ERROR_SRC_T error,
                              const CLX_SWC_ERROR_FUNC_T callback,
                              void *ptr_cookie);

/**
 * @brief Deregister error callback function.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     error         - error source type
 * @param [in]     callback      - The callback function of type CLX_SWC_ERROR_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_deregisterErrorCallback(const UI32_T unit,
                                const CLX_SWC_ERROR_SRC_T error,
                                const CLX_SWC_ERROR_FUNC_T callback,
                                void *ptr_cookie);

void
hal_swc_notifyErrorCallback(const UI32_T unit,
                            const CLX_SWC_ERROR_SRC_T error,
                            const CLX_SWC_ERROR_INFO_T *ptr_error_info);

/**
 * @brief Get device information.
 *
 * @param [in]     unit               - Device unit number
 * @param [out]    ptr_device_info    - The device information
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getDeviceInfo(const UI32_T unit, CLX_SWC_DEVICE_INFO_T *ptr_device_info);

/**
 * @brief Get port bitmap of current config.
 *
 * @param [in]     unit               - Device unit number
 * @param [out]    ptr_port_config    - type of CLX_SWC_PORT_CONFIG_T
 * @return         CLX_E_OK        - Operation success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_swc_getPortConfig(const UI32_T unit, CLX_SWC_PORT_CONFIG_T *ptr_port_config);

/**
 * @brief Get resource capacity
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Resource type
 * @param [in]     param       - Parameter if necessary
 * @param [out]    ptr_size    - Size of capacity
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getCapacity(const UI32_T unit,
                    const CLX_SWC_RSRC_T type,
                    const UI32_T param,
                    UI32_T *ptr_size);

/**
 * @brief Get resource usage.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - Resource type
 * @param [in]     param      - Parameter if necessary
 * @param [out]    ptr_cnt    - Count of usage
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getUsage(const UI32_T unit, const CLX_SWC_RSRC_T type, const UI32_T param, UI32_T *ptr_cnt);

/**
 * @brief Set clock servo mode.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     mode    - Clock servo mode
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_setCsoMode(const UI32_T unit, const CLX_SWC_CSO_MODE_T mode);

/**
 * @brief Get clock servo mode.
 *
 * @param [in]     unit        - Device unit number
 * @param [out]    ptr_mode    - Clock servo mode
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getCsoMode(const UI32_T unit, CLX_SWC_CSO_MODE_T *ptr_mode);

/**
 * @brief This function is to set reason priority.
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @param [in]     priority          - reason priority
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_setRxReasonPriority(const UI32_T unit,
                            const CLX_PKT_RX_REASON_T rx_reason_code,
                            const UI32_T priority);

/**
 * @brief This function is to get reason priority.
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @param [out]    priority          - reason priority
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getRxReasonPriority(const UI32_T unit,
                            const CLX_PKT_RX_REASON_T rx_reason_code,
                            UI32_T *priority);

/**
 * @brief To set PP reason priority.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     pp_reason_code    - pp reason code
 * @param [in]     priority          - reason priority
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_setPpReasonPriority(const UI32_T unit, const UI32_T pp_reason_code, const UI32_T priority);

/**
 * @brief To get PP reason priority.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     pp_reason_code    - pp reason code
 * @param [out]    priority          - reason priority
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getPpReasonPriority(const UI32_T unit, const UI32_T pp_reason_code, UI32_T *priority);

/**
 * @brief This function is to get flow hash value.
 *
 * @param [in]     unit            - device unit number
 * @param [in]     hash_type       - hash type
 * @param [in]     ptr_hash_key    - hash key
 * @param [out]    p_hash_value    - hash value
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getFlowHashValue(const UI32_T unit,
                         const CLX_SWC_HASH_TYPE_T hash_type,
                         const CLX_SWC_FLOW_HASH_KEY_T *ptr_hash_key,
                         UI32_T *p_hash_value);

/**
 * @brief This function is to get max timestamp sec.
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    max_ts_sec    - Max Timestamp sec
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getMaxTsSec(const UI32_T unit, UI32_T *max_ts_sec);

/**
 * @brief This function is to get Tod Info.
 *
 * @param [in]     unit    - device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_swc_getTodInfo(const UI32_T unit);

/**
 * @brief This function is to get chip configurable information
 *
 * @param [in]     unit     - Device unit number, get chip configuration is required, but get global
 * configuration is not required
 * @param [in]     type     - Type for get chip configurable information
 * @param [in]     para0    - Parameter0 if necessary
 * @param [in]     para1    - Parameter1 if necessary
 *                            ptr_value
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         other                - Operate fail
 */
CLX_ERROR_NO_T
hal_swc_getChipCfgInfo(const UI32_T unit,
                       const CLX_SWC_CHIP_CFG_INFO_TYPE_T type,
                       const UI32_T para0,
                       const UI32_T para1,
                       UI32_T *ptr_value);

/**
 * @brief This function is to get table name by table id
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     tbl_id          - Table id
 * @param [in]     tbl_name_len    - Table name length
 * @param [out]    ptr_tbl_name    - Table name
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         other                - Operate fail
 */
CLX_ERROR_NO_T
hal_swc_getTblName(const UI32_T unit,
                   const UI32_T tbl_id,
                   const UI32_T tbl_name_len,
                   C8_T *ptr_tbl_name);

/**
 * @brief This function retrieves the string name based on the index.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     data_type       - Data Type
 * @param [in]     index           - Index
 * @param [in]     str_len         - String length
 * @param [out]    str_name        - String name
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         other                - Operate fail
 */
CLX_ERROR_NO_T
hal_swc_getStringNameById(const UI32_T unit,
                          const CLX_SWC_DATA_TYPE_T data_type,
                          const UI32_T index,
                          const UI32_T str_len,
                          C8_T *str_name);
#endif
