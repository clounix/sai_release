/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_stk.h
 * PURPOSE:
 *      It provides hal stacking module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_LT_STK_H
#define HAL_LT_STK_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stk.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
/**
 * @brief Initiate the stk software resource, such as software database and semaphore.
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_stk_initRsrc(const UI32_T unit);

/**
 * @brief Set the DIL entry.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     di               - Destination index
 * @param [in]     ptr_dil_entry    - DIL entry
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_setDilEntry(const UI32_T unit, const UI32_T di, const CLX_STK_DIL_T *ptr_dil_entry);

/**
 * @brief Reset the DIL entry.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     di      - Destination index
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_resetDilEntry(const UI32_T unit, const UI32_T di);

/**
 * @brief Get the DIL entry.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     di               - Destination index
 * @param [out]    ptr_dil_entry    - DIL entry
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_getDilEntry(const UI32_T unit, const UI32_T di, CLX_STK_DIL_T *ptr_dil_entry);

/**
 * @brief Config stacking related register/table.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_init(const UI32_T unit);

/**
 * @brief Set chip id.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     chip    - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_setMyChipId(const UI32_T unit, const UI32_T chip);

/**
 * @brief Set neighbor chip id. Each device has two neighbors in a ring topology.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Path id
 * @param [in]     chip    - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_setNeighborChipId(const UI32_T unit, const UI32_T path, const UI32_T chip);

/**
 * @brief Get neighbor chip id. Each device has two neighbors in a ring topology.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     path        - Path id
 * @param [out]    ptr_chip    - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_getNeighborChipId(const UI32_T unit, const UI32_T path, UI32_T *ptr_chip);

/**
 * @brief Set cut off chip id. It is used to avoid packet looping in a ring topology.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Path id
 * @param [in]     chip    - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_setCutOffChipId(const UI32_T unit, const UI32_T path, const UI32_T chip);

/**
 * @brief Get cut off chip id. It is used to avoid packet looping in a ring topology.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     path        - Path id
 * @param [out]    ptr_chip    - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_getCutOffChipId(const UI32_T unit, const UI32_T path, UI32_T *ptr_chip);

/**
 * @brief Add stacking port to a stacking group path.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Path id
 * @param [in]     port    - Port id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_addStackingPort(const UI32_T unit, const UI32_T path, const UI32_T port);

/**
 * @brief Delete stacking port from a stacking group path.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     path       - Path id
 * @param [in]     port       - Port id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_delStackingPort(const UI32_T unit, const UI32_T path, const UI32_T port);

/**
 * @brief Get stacking port list from a stacking group path.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     path             - Path id
 * @param [out]    ptr_port_list    - Port list
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */

CLX_ERROR_NO_T
hal_lt_stk_getStackingPort(const UI32_T unit, const UI32_T path, CLX_PORT_BITMAP_T *ptr_port_list);

/**
 * @brief Set a path to the remote chip.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Path id
 * @param [in]     chip    - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_setPathToRemoteChip(const UI32_T unit, const UI32_T path, const UI32_T chip);

/**
 * @brief Add stacking port to a stacking group path for packet to CPU.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     cpu_path    - Path id
 * @param [in]     port        - Port id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_addStackingPortToCpu(const UI32_T unit, const UI32_T cpu_path, const UI32_T port);

/**
 * @brief Delete stacking port from a stacking group path for packet to CPU.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     cpu_path    - Path id
 * @param [in]     port        - Port id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_delStackingPortToCpu(const UI32_T unit, const UI32_T cpu_path, const UI32_T port);

/**
 * @brief Get stacking port list from a stacking group path for packet to CPU.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     cpu_path         - Path id
 * @param [out]    ptr_port_list    - Port list
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */

CLX_ERROR_NO_T
hal_lt_stk_getStackingPortToCpu(const UI32_T unit,
                                const UI32_T cpu_path,
                                CLX_PORT_BITMAP_T *ptr_port_list);

/**
 * @brief Set a cpu path to the remote chip.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     cpu_path    - Path id
 * @param [in]     chip        - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_setCpuPathToRemoteChip(const UI32_T unit, const UI32_T cpu_path, const UI32_T chip);

/**
 * @brief Initiate the stk configuration.
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_stk_initCfg(const UI32_T unit);

/* EXPORTED HAL PROGRAMS
 */
/**
 * @brief Get fabric port bitmap in hw plane port view.
 *
 * 1. For pp_pbmp size, please reference HAL_ITM_PBM_WORDS.
 *
 * @param [in]     unit           - Device unit number
 * @param [out]    ptr_pp_pbmp    - mgid port bitmap   (optional)
 * @param [out]    cl_pbmp        - CLX_PORT_BITMAP_T  (optional)
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_getFabPortBmp(const UI32_T unit, UI32_T *ptr_pp_pbmp, CLX_PORT_BITMAP_T cl_pbmp);

/**
 * @brief Check given port is used as fabric port or not.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port
 *                           0 : used as front port
 * @param [out]    ptr_is_fab             - status
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_stk_checkFabPort(const UI32_T unit, const UI32_T port, BOOL_T *ptr_is_fab);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
#endif
