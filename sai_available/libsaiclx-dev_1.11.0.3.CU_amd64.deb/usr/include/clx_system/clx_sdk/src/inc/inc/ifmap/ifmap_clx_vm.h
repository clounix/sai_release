/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   ifmap_clx_vm.h
 * PURPOSE:
 *      It provides user port to cl port translation for VM API.
 * NOTES:
 */

#ifndef IFMAP_CLX_VM_H
#define IFMAP_CLX_VM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_vm.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to create a VM port with
 *        port, vm id and vm tag type.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     user_port      - Port or LAG port
 * @param [in]     vm_id          - VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 * @param [in]     vm_tag_type    - VM type
 * @param [out]    ptr_vm_port    - VM port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_createPort(const UI32_T unit,
                        const CLX_PORT_T user_port,
                        const CLX_VM_ID_T vm_id,
                        const CLX_VM_TAG_TYPE_T vm_tag_type,
                        CLX_PORT_T *ptr_vm_port);

/**
 * @brief This API is used to get a VM port.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     user_port      - Port or LAG port
 * @param [in]     vm_id          - VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 * @param [in]     vm_tag_type    - VM type
 * @param [out]    ptr_vm_port    - VM port
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - VM port is not created.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getPort(const UI32_T unit,
                     const CLX_PORT_T user_port,
                     const CLX_VM_ID_T vm_id,
                     const CLX_VM_TAG_TYPE_T vm_tag_type,
                     CLX_PORT_T *ptr_vm_port);

/**
 * @brief This API is used to get keys of a VM port.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     vm_port            - VM port
 * @param [out]    ptr_user_port      - Port or LAG port
 * @param [out]    ptr_vm_id          - VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 * @param [out]    ptr_vm_tag_type    - VM type
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - VM port is not created or is destroyed.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getKey(const UI32_T unit,
                    const CLX_PORT_T vm_port,
                    CLX_PORT_T *ptr_user_port,
                    CLX_VM_ID_T *ptr_vm_id,
                    CLX_VM_TAG_TYPE_T *ptr_vm_tag_type);

/**
 * @brief This API is used to set the associated upstream port of a downstream port.
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     user_downstream_port    - Downstream port (port or VM port)
 * @param [in]     user_upstream_port      - Upstream port (port or LAG port)
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_setUpstreamPort(const UI32_T unit,
                             const CLX_PORT_T user_downstream_port,
                             const CLX_PORT_T user_upstream_port);

/**
 * @brief This API is used to reset the associated upstream port of a downstream port.
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     user_downstream_port    - Downstream port (port or VM port)
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_resetUpstreamPort(const UI32_T unit, const CLX_PORT_T user_downstream_port);

/**
 * @brief This API is used to get the associated upstream port of the downstream port.
 *
 * @param [in]     unit                      - Device unit number
 * @param [in]     user_downstream_port      - Downstream port (port or VM port)
 * @param [out]    ptr_user_upstream_port    - Upstream port (port or LAG port)
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getUpstreamPort(const UI32_T unit,
                             const CLX_PORT_T user_downstream_port,
                             CLX_PORT_T *ptr_user_upstream_port);

/**
 * @brief This API is used to set port property to provide VM function for the port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - port
 * @param [in]     ptr_prty     - VM related port property
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_setPortProperty(const UI32_T unit,
                             const CLX_PORT_T user_port,
                             const CLX_VM_PORT_PRTY_T *ptr_prty);

/**
 * @brief This API is used to get port property which providing VM function for the port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - port
 * @param [out]    ptr_prty     - VM related port property
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getPortProperty(const UI32_T unit,
                             const CLX_PORT_T user_port,
                             CLX_VM_PORT_PRTY_T *ptr_prty);

/**
 * @brief This API is used to add a point-to-point e_channel/vif downstream entry
 *        for 802.1BR and NIV in PE/IV switch.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_user_addr    - Unicast entry in PE/IV, including
 *                                    vm_id, vm_tag_type, source and destination port information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_addUcastAddr(const UI32_T unit, const CLX_VM_PE_UCAST_ADDR_T *ptr_user_addr);

/**
 * @brief This API is used to delete a point-to-point e_channel/vif downstream entry
 *        for 802.1BR and NIV in PE/IV switch.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_user_addr    - Unicast entry in PE/IV, including source port, vm_id and
 * vm_tag_type
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_delUcastAddr(const UI32_T unit, const CLX_VM_PE_UCAST_ADDR_T *ptr_user_addr);

/**
 * @brief This API is used to get a point-to-point e_channel/vif downstream entry
 *        for 802.1BR and NIV in PE/IV switch.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_user_addr    - Unicast entry in PE/IV, including source port, vm_id and
 * vm_tag_type
 * @param [out]    ptr_user_addr    - Unicast entry in PE/IV, including destination port information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_getUcastAddr(const UI32_T unit, CLX_VM_PE_UCAST_ADDR_T *ptr_user_addr);

/**
 * @brief This API is used to add a point-to-multi-point e_channel/vif downstream entry
 *        for 802.1BR and NIV in PE/IV switch.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_user_addr    - Multicast entry in PE/IV, including
 *                                    vm_id, vm_tag_type, source port and destination pbm/group
 * information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_addMcastAddr(const UI32_T unit, const CLX_VM_PE_MCAST_ADDR_T *ptr_user_addr);

/**
 * @brief This API is used to delete a point-to-multi-point e_channel/vif downstream entry
 *        for 802.1BR and NIV in PE/IV switch.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_user_addr    - Multicast entry in PE/IV, including source port, vm_id and
 * vm_tag_type
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_delMcastAddr(const UI32_T unit, const CLX_VM_PE_MCAST_ADDR_T *ptr_user_addr);

/**
 * @brief This API is used to get point-to-multi-point e_channel/vif downstream entry
 *        for 802.1BR and NIV in PE/IV switch.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_user_addr    - Multicast entry in PE/IV, including source port, vm_id and
 * vm_tag_type
 * @param [out]    ptr_user_addr    - Multicast entry in PE/IV, including destination pbm/group
 * information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_pe_getMcastAddr(const UI32_T unit, CLX_VM_PE_MCAST_ADDR_T *ptr_user_addr);

/**
 * @brief This API is used to add interface of a port combined with multicast vm id, and
 *        set related interface properties.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     user_port       - port
 * @param [in]     vm_id           - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type         - VM type
 * @param [in]     ptr_property    - Interface property
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_addMcastIntfProperty(const UI32_T unit,
                                  const CLX_PORT_T user_port,
                                  const CLX_VM_ID_T vm_id,
                                  const CLX_VM_TAG_TYPE_T vm_type,
                                  const CLX_PORT_INTF_PROPERTY_T *ptr_property);

/**
 * @brief This API is used to delete interface of a port combined with multicast vm id.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - port
 * @param [in]     vm_id        - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type      - VM type
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not exists.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_delMcastIntfProperty(const UI32_T unit,
                                  const CLX_PORT_T user_port,
                                  const CLX_VM_ID_T vm_id,
                                  const CLX_VM_TAG_TYPE_T vm_type);

/**
 * @brief This API is used to get interface properties of a port combined with multicast vm id.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     user_port       - port
 * @param [in]     vm_id           - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type         - VM type
 * @param [out]    ptr_property    - Interface property
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not exists.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getMcastIntfProperty(const UI32_T unit,
                                  const CLX_PORT_T user_port,
                                  const CLX_VM_ID_T vm_id,
                                  const CLX_VM_TAG_TYPE_T vm_type,
                                  CLX_PORT_INTF_PROPERTY_T *ptr_property);

/**
 * @brief This API is used to add service of a port combined multicast vm-id and vlan.
 *        1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *        2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     user_port      - Port
 * @param [in]     vm_id          - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type        - VM type
 * @param [in]     seg0           - Segment parameter 0
 * @param [in]     seg1           - Segment parameter 1
 * @param [in]     ptr_seg_srv    - Service
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_addMcastSegService(const UI32_T unit,
                                const CLX_PORT_T user_port,
                                const CLX_VM_ID_T vm_id,
                                const CLX_VM_TAG_TYPE_T vm_type,
                                const UI32_T seg0,
                                const UI32_T seg1,
                                const CLX_PORT_SEG_SRV_T *ptr_seg_srv);

/**
 * @brief This API is used to delete service of a port combined multicast vm-id and vlan.
 *        1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *        2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     user_port    - Port
 * @param [in]     vm_id        - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type      - VM type
 * @param [in]     seg0         - Segment parameter 0
 * @param [in]     seg1         - Segment parameter 1
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_delMcastSegService(const UI32_T unit,
                                const CLX_PORT_T user_port,
                                const CLX_VM_ID_T vm_id,
                                const CLX_VM_TAG_TYPE_T vm_type,
                                const UI32_T seg0,
                                const UI32_T seg1);

/**
 * @brief This API is used to get service of a port combined multicast vm-id and vlan.
 *        1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *        2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     user_port      - Port
 * @param [in]     vm_id          - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type        - VM type
 * @param [in]     seg0           - Segment parameter 0
 * @param [in]     seg1           - Segment parameter 1
 * @param [out]    ptr_seg_srv    - Service
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
ifmap_clx_vm_getMcastSegService(const UI32_T unit,
                                const CLX_PORT_T user_port,
                                const CLX_VM_ID_T vm_id,
                                const CLX_VM_TAG_TYPE_T vm_type,
                                const UI32_T seg0,
                                const UI32_T seg1,
                                CLX_PORT_SEG_SRV_T *ptr_seg_srv);

#endif /* End of #ifndef IFMAP_CLX_VM_H */
