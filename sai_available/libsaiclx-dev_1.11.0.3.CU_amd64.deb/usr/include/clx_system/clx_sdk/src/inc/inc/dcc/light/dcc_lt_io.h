/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  dcc_lt_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DCC_LT).
 *  2. Define DCC_LT IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_LT_IO_H
#define DCC_LT_IO_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <dcc/dcc_io.h>
#include <dcc/light/dcc_lt.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DCC_LT constant definition */
#define DCC_LT_MAX_IO_CMD_SIZE               (64 * 4) /* 64 words */
#define DCC_LT_IO_HASH_CMD_CFG_OFFSET        (0x0)
#define DCC_LT_IO_HASH_CMD_BNK_BITMAP_OFFSET (0x4)
#define DCC_LT_IO_HASH_CMD_DATA_OFFSET       (0x8)
#define DCC_LT_IO_HASH_RSLT_STAT_OFFSET      (0x0)
#define DCC_LT_IO_HASH_RSLT_INDEX_OFFSET     (0x4)
#define DCC_LT_IO_HASH_RSLT_DATA_OFFSET      (0xC)
#define DCC_LT_IO_HASH_RSLT_HEADER_LEN \
    (DCC_LT_IO_HASH_RSLT_DATA_OFFSET - DCC_LT_IO_HASH_RSLT_STAT_OFFSET)
/* unit of time: us, all times need for further check */
#define DCC_LT_IO_CMD_SUSPEND_TIME  (1)
#define DCC_LT_IO_CMD_BUSY_POLL_CNT (10)

/* For IO channel, we do not need to define BASE_DCE_MMIO_BUF registers.
We will copy response from this BASE_DCE_MMIO_BUF into the *ptr_rsp of DCC_LT_CMD_T directly. */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* IO frame struct start */
/* below is for w0 and w1 of BASE_DCE_MMIO_REG register. */

#define DCC_LT_IO_CH_OPT_IRQ_MODE  (1)
#define DCC_LT_IO_CH_OPT_SIZE_BYTE (0)
#define DCC_LT_IO_CH_OPT_SIZE_HALF (1)
#define DCC_LT_IO_CH_OPT_SIZE_WORD (2)

#ifdef CLX_EN_BIG_ENDIAN
/* Command Control */
typedef union {
    UI32_T reg;
    struct {
        UI32_T cmd_sn : 8;
        UI32_T cmd_op : 8;
        UI32_T : 4;
        UI32_T cmd_opt_size : 2;
        UI32_T cmd_opt_irq : 1;
        UI32_T : 1;
        UI32_T cmd_len : 8;
    } field;
} DCC_LT_IO_REG_CMDCTL_REG_T;

/* Hash result length */
typedef union {
    UI32_T reg;
    struct {
        UI32_T : 24;
        UI32_T hash_rslt_len : 8;
    } field;
} DCC_LT_IO_REG_HASH_RSLT_LEN_REG_T;

/* Response status */
typedef union {
    UI32_T reg;
    struct {
        UI32_T rsp_sn : 8;
        UI32_T rsp_code : 8;
        UI32_T rsp_status : 8;
        UI32_T rsp_len : 8;
    } field;
} DCC_LT_IO_REG_RSPSTAT_REG_T;

/* Hash configuration */
typedef union {
    UI32_T reg;
    struct {
        UI32_T : 22;
        UI32_T view : 2;
        UI32_T : 6;
        UI32_T cmd : 2;
    } field;
} DCC_LT_IO_BUF_HASH_CFG_REG_T;

/* Hash trigger */
typedef union {
    UI32_T reg;
    struct {
        UI32_T : 31;
        UI32_T load : 1;
    } field;
} DCC_LT_IO_BUF_HASH_TRIG_REG_T;

/* Hash status */
typedef union {
    UI32_T reg;
    struct {
        UI32_T : 23;
        UI32_T res_done : 1;
        UI32_T : 4;
        UI32_T res_state : 4;
    } field;
} DCC_LT_IO_BUF_HASH_STAT_REG_T;
#else
/* Command Control */
typedef union {
    UI32_T reg;
    struct {
        UI32_T cmd_len : 8;
        UI32_T : 1;
        UI32_T cmd_opt_irq : 1;
        UI32_T cmd_opt_size : 2;
        UI32_T : 4;
        UI32_T cmd_op : 8;
        UI32_T cmd_sn : 8;
    } field;
} DCC_LT_IO_REG_CMDCTL_REG_T;

/* Hash result length */
typedef union {
    UI32_T reg;
    struct {
        UI32_T hash_rslt_len : 8;
        UI32_T : 24;
    } field;
} DCC_LT_IO_REG_HASH_RSLT_LEN_REG_T;

/* Response status */
typedef union {
    UI32_T reg;
    struct {
        UI32_T rsp_len : 8;
        UI32_T rsp_status : 8;
        UI32_T rsp_code : 8;
        UI32_T rsp_sn : 8;
    } field;
} DCC_LT_IO_REG_RSPSTAT_REG_T;

/* Hash configuration */
typedef union {
    UI32_T reg;
    struct {
        UI32_T cmd : 2;
        UI32_T : 6;
        UI32_T view : 2;
        UI32_T : 22;
    } field;
} DCC_LT_IO_BUF_HASH_CFG_REG_T;

/* Hash trigger */
typedef union {
    UI32_T reg;
    struct {
        UI32_T load : 1;
        UI32_T : 31;
    } field;
} DCC_LT_IO_BUF_HASH_TRIG_REG_T;

/* Hash status */
typedef union {
    UI32_T reg;
    struct {
        UI32_T res_state : 4;
        UI32_T : 4;
        UI32_T res_done : 1;
        UI32_T : 23;
    } field;
} DCC_LT_IO_BUF_HASH_STAT_REG_T;
#endif

typedef struct {
    UI32_T reg_cmdadr_mmio_addr;
    UI32_T reg_cmdctl_mmio_addr;
    UI32_T reg_hash_rslt_len_mmio_addr;
    UI32_T reg_rspstat_mmio_addr;
    UI32_T reg_rspdata_mmio_addr;
    UI32_T reg_hashstat_mmio_addr;
    UI32_T buf_data_buf_mmio_addr;
} DCC_LT_IO_MMIO_ADDR_CB_T;

/* DCC_LT IO channel control block structure */
typedef struct {
    /* channel OS resource */
    CLX_SEMAPHORE_ID_T protect_sema; /* channel protection semaphore */
    /* channel operation mode */
    DCC_LT_CH_OP_MODE_T op_mode; /* operation is polling or interrupt */
    UI32_T op_timeout_cnt;       /* time-out count while channel access operation */
    /* debug counters */
    UI32_T rst_cnt; /* reset count */
    UI32_T abt_cnt; /* abort count */
    UI32_T nak_cnt; /* non-ack count */
    UI32_T err_cnt; /* error count */
    /* performance timestamp */
    CLX_TIME_T cmd_start;    /* io command start execution time */
    CLX_TIME_T cmd_stop;     /* io command end execution time */
    CLX_TIME_T cmd_max_time; /* io command Max execution time */
    CLX_TIME_T cmd_min_time; /* io command min execution time */
    /* mmio addr control block */
    DCC_LT_IO_MMIO_ADDR_CB_T mmio_addr_cb;
    /* channel cmd serial number */
    UI8_T sn;
} DCC_LT_IO_CH_CB_T;

/**
 * @brief dcc_lt_io_initIoRsrc() is responsible for resource of DCC_LT IO initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_io_initIoRsrc(const UI32_T unit);

/**
 * @brief dcc_lt_io_initIoThread() is responsible for thread of DCC_LT IO initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_io_initIoThread(const UI32_T unit);

/**
 * @brief dcc_lt_io_deinitIoRsrc() is responsible for resource of DCC_LT IO deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_io_deinitIoRsrc(const UI32_T unit);

/**
 * @brief dcc_lt_io_deinitIoThread() is responsible for thread of DCC_LT IO deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_LT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_lt_io_deinitIoThread(const UI32_T unit);

/**
 * @brief dcc_lt_io_txCmd() is the function that will send a command to DCE IO channel.
 *
 * @param [in]     unit        - The unit number that would like to be accessed.
 * @param [in]     action      - Read or write action.
 * @param [in]     addr        - Chip register or table address.
 * @param [in]     ptr_data    - The command data or data buffer.
 * @param [in]     data_len    - The command data length.
 * @return         CLX_E_OK        - Successfully send a DCC_LT command.
 * @return         CLX_E_OTHERS    - Fail to send a DCC_LT command.
 */
CLX_ERROR_NO_T
dcc_lt_io_txCmd(const UI32_T unit,
                const DCC_LT_CMD_ACT_T action,
                const UI32_T addr,
                UI32_T *ptr_data,
                const UI32_T data_len);

/**
 * @brief dcc_lt_io_txHashCmd() is a function that will send a hash command through DCE IO channel.
 *
 * @param [in]     unit             - The unit number that would like to be accessed.
 * @param [in]     action           - Hash add, lookup, or delete action.
 * @param [in]     addr             - Chip register or table address.
 * @param [in]     ptr_hash_info    - Hash table meta info, indirect addr, trig addr, view.
 * @param [in]     bnk_bitmap       - The bank bitmap to apply hash action.
 * @param [in]     ptr_data         - The hash command data and data buffer.
 * @param [in]     data_len         - The hash command data length.
 * @param [out]    ptr_entry_idx    - The hash value of the hash key.
 * @return         CLX_E_OK        - Successfully send a DCC_LT command.
 * @return         CLX_E_OTHERS    - Fail to send a DCC_LT command.
 */
CLX_ERROR_NO_T
dcc_lt_io_txHashCmd(const UI32_T unit,
                    const DCC_LT_CMD_HASH_ACT_T action,
                    const UI32_T addr,
                    HASH_TBL_META_T *ptr_hash_info,
                    const UI32_T bnk_bitmap,
                    UI32_T *ptr_data,
                    const UI32_T data_len,
                    UI32_T *ptr_entry_idx);

/**
 * @brief dcc_lt_io_setIoOperationMode() is a function to change DCC_LT IO channel operation mode to
 * be poll or interrupt.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     op_mode    - The IO channel operation mode, valid are:
 *                              1. DCC_LT_CH_OP_MODE_POLL
 *                              2. DCC_LT_CH_OP_MODE_INTR
 * @return         CLX_E_OK        - Set IO channel operation mode successfully.
 * @return         CLX_E_OTHERS    - Fail to set IO channel operation mode.
 */
CLX_ERROR_NO_T
dcc_lt_io_setIoOperationMode(const UI32_T unit, const DCC_LT_CH_OP_MODE_T op_mode);

/**
 * @brief dcc_lt_io_setIoOperationTimeoutCnt() is a function to change DCC_LT IO channel operation
 * time-out count.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     timeout_cnt    - The IO channel operation time-out count for polling mode.
 * @return         CLX_E_OK        - Set IO channel operation time-out count successfully.
 * @return         CLX_E_OTHERS    - Fail to set IO channel operation time-out count.
 */
CLX_ERROR_NO_T
dcc_lt_io_setIoOperationTimeoutCnt(const UI32_T unit, const UI32_T timeout_cnt);

/**
 * @brief dcc_lt_io_showIoChannelInfo() is a function to display DCC_LT IO channel information.
 *
 * @param [in]     unit    - The specified unit number.
 */
void
dcc_lt_io_showIoChannelInfo(const UI32_T unit);

/**
 * @brief dcc_lt_ioCmdCoreOneError() is a function to handle io core one error irq.
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     isr_cookie    - The specified isr cookie.
 * @return         CLX_E_OK    - handle io command error successfully
 */
CLX_ERROR_NO_T
dcc_lt_ioCmdCoreOneError(const UI32_T unit, const UI32_T isr_cookie);

#endif /* END of DCC_LT_IO_H*/
