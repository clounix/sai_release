/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_dawn_ifmon.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_LT_DAWN_IFMON_H
#define HAL_LT_DAWN_IFMON_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <cmlib/cmlib_list.h>
#include <clx_ifmon.h>

/* NAMING CONSTANT DECLARATIONS
 */

#if defined(CLX_LAMP)
#define HAL_LT_DAWN_IFMON_MODE_DFLT (CLX_IFMON_MODE_POLL)
#else
#define HAL_LT_DAWN_IFMON_MODE_DFLT (CLX_IFMON_MODE_INTR)
#endif

#define HAL_LT_DAWN_IFMON_INTERVAL_DFLT (500000)

#define HAL_LT_DAWN_IFMON_STACK_SIZE (64 * 1024)
#define HAL_LT_DAWN_IFMON_THREAD_PRI (85)

#define HAL_LT_DAWN_IFMON_LANE_SHIFT_PER_MACRO (2) /* 4 lanes per macro */
#define HAL_LT_DAWN_IFMON_LANE_NUM_PER_MACRO   (1U << HAL_LT_DAWN_IFMON_LANE_SHIFT_PER_MACRO)
#define HAL_LT_DAWN_IFMON_LANE_MASK_PER_MACRO  (HAL_LT_DAWN_IFMON_LANE_NUM_PER_MACRO - 1)

#define HAL_LT_DAWN_IFMON_DIE_NUM          (2)
#define HAL_LT_DAWN_IFMON_LANE_NUM_PER_DIE (160)
#define HAL_LT_DAWN_IFMON_LANE_NUM         (HAL_LT_DAWN_IFMON_DIE_NUM * HAL_LT_DAWN_IFMON_LANE_NUM_PER_DIE)
#define HAL_LT_DAWN_IFMON_LANE_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_LT_DAWN_IFMON_LANE_NUM))

#define HAL_LT_DAWN_IFMON_SPEED_BIT (4)
#define HAL_LT_DAWN_IFMON_SPEED_BITMAP_SIZE \
    (HAL_LT_DAWN_IFMON_SPEED_BIT * HAL_LT_DAWN_IFMON_LANE_BITMAP_SIZE)

#define HAL_LT_DAWN_IFMON_NOTIFY_HANDLER_CNT (16)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_LT_DAWN_IFMON_CFG_LOCK(unit)   hal_lt_dawn_ifmon_lockIfmonResource(unit)
#define HAL_LT_DAWN_IFMON_CFG_UNLOCK(unit) hal_lt_dawn_ifmon_unlockIfmonResource(unit)

#define HAL_LT_DAWN_IFMON_FLOW_LOCK(unit)   hal_lt_dawn_ifmon_lockFlow(unit)
#define HAL_LT_DAWN_IFMON_FLOW_UNLOCK(unit) hal_lt_dawn_ifmon_unlockFlow(unit)

/* DATA TYPE DECLARATIONS
 */

typedef UI32_T HAL_LT_DAWN_IFMON_LANE_BITMAP_T[HAL_LT_DAWN_IFMON_LANE_BITMAP_SIZE];
typedef UI32_T HAL_LT_DAWN_IFMON_SPEED_BITMAP_T[HAL_LT_DAWN_IFMON_SPEED_BITMAP_SIZE];

typedef enum {
    HAL_LT_DAWN_IFMON_SPEED_ZERO = 0,
    HAL_LT_DAWN_IFMON_SPEED_10M,
    HAL_LT_DAWN_IFMON_SPEED_100M,
    HAL_LT_DAWN_IFMON_SPEED_1G,
    HAL_LT_DAWN_IFMON_SPEED_10G,
    HAL_LT_DAWN_IFMON_SPEED_40G,
    HAL_LT_DAWN_IFMON_SPEED_100G,
    HAL_LT_DAWN_IFMON_SPEED_25G,
    HAL_LT_DAWN_IFMON_SPEED_50G,
    HAL_LT_DAWN_IFMON_SPEED_LAST
} HAL_LT_DAWN_IFMON_SPEED_T;

typedef enum {
    HAL_LT_DAWN_IFMON_TYPE_DEV = 0,
    HAL_LT_DAWN_IFMON_TYPE_HOST,
    HAL_LT_DAWN_IFMON_TYPE_INTR,
    HAL_LT_DAWN_IFMON_TYPE_CUR,
    HAL_LT_DAWN_IFMON_TYPE_NEW,
    HAL_LT_DAWN_IFMON_TYPE_SW,
    HAL_LT_DAWN_IFMON_TYPE_LAST
} HAL_LT_DAWN_IFMON_TYPE_T;

typedef enum {
    HAL_LT_DAWN_IFMON_FAULT_TYPE_LOCAL = 0,
    HAL_LT_DAWN_IFMON_FAULT_TYPE_REMOTE,
    HAL_LT_DAWN_IFMON_FAULT_TYPE_LAST
} HAL_LT_DAWN_IFMON_FAULT_TYPE_T;

typedef struct HAL_LT_DAWN_IFMON_STATE_S {
    HAL_LT_DAWN_IFMON_LANE_BITMAP_T link_bitmap;
    HAL_LT_DAWN_IFMON_LANE_BITMAP_T fault_bitmap;
    HAL_LT_DAWN_IFMON_SPEED_BITMAP_T speed_bitmap;
} HAL_LT_DAWN_IFMON_STATE_T;

typedef struct HAL_LT_DAWN_IFMON_FAULT_STATE_S {
    HAL_LT_DAWN_IFMON_LANE_BITMAP_T local_fault_bitmap;
    HAL_LT_DAWN_IFMON_LANE_BITMAP_T remote_fault_bitmap;
} HAL_LT_DAWN_IFMON_FAULT_STATE_T;

typedef struct HAL_LT_DAWN_IFMON_NOTIFY_HANDLER_S {
    CLX_IFMON_NOTIFY_FUNC_T notify_func;
    void *ptr_cookie;
} HAL_LT_DAWN_IFMON_NOTIFY_HANDLER_T;

typedef struct HAL_LT_DAWN_IFMON_CB_S {
    CLX_SEMAPHORE_ID_T sem_conf;
    CLX_SEMAPHORE_ID_T sem_flow;
    BOOL_T monitor_state;
    CLX_THREAD_ID_T thread_id;
    CLX_IFMON_MODE_T mode;
    UI32_T interval_us;
    HAL_LT_DAWN_IFMON_STATE_T dev_state;
    HAL_LT_DAWN_IFMON_FAULT_STATE_T dev_fault_type;
    HAL_LT_DAWN_IFMON_STATE_T host_state;
    HAL_LT_DAWN_IFMON_STATE_T intr_state;
    HAL_LT_DAWN_IFMON_STATE_T cur_state;
    HAL_LT_DAWN_IFMON_STATE_T new_state;
    HAL_LT_DAWN_IFMON_STATE_T sw_state;
    HAL_LT_DAWN_IFMON_LANE_BITMAP_T sw_status_bitmap;
    UI32_T callback_cnt;
    HAL_LT_DAWN_IFMON_NOTIFY_HANDLER_T notify_handler[HAL_LT_DAWN_IFMON_NOTIFY_HANDLER_CNT];
    CMLIB_LIST_T *ptr_callback_list;
} HAL_LT_DAWN_IFMON_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize IfMon function.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_init(const UI32_T unit);

/**
 * @brief Deinitialize IfMon function.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_deinit(const UI32_T unit);

/**
 * @brief Lock the resource of IfMon.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_lockIfmonResource(const UI32_T unit);

/**
 * @brief Unlock the resource of IfMon.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_unlockIfmonResource(const UI32_T unit);

/**
 * @brief Lock the flow of IfMon.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_lockFlow(const UI32_T unit);

/**
 * @brief Unlock the flow of IfMon.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_unlockFlow(const UI32_T unit);

/**
 * @brief To get monitor state.
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    ptr_enable    - Pointer for monitor state
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getMonitorState(const UI32_T unit, BOOL_T *ptr_enable);

/**
 * @brief To set monitor state.
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     enable   - Monitor state
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setMonitorState(const UI32_T unit, const BOOL_T enable);

/**
 * @brief To handle interrupt service routine.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     isr_cookie    - ISR cookie
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_handleIsr(const UI32_T unit, const UI32_T isr_cookie);

/**
 * @brief To get speed from speed bitmap.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lane            - Lane id
 * @param [in]     speed_bitmap    - Speed bitmap
 * @param [out]    ptr_speed       - Pointer for port speed
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getSpeedFromBitmap(const UI32_T unit,
                                     const UI32_T lane,
                                     HAL_LT_DAWN_IFMON_SPEED_BITMAP_T speed_bitmap,
                                     CLX_PORT_SPEED_T *ptr_speed);

/**
 * @brief To set speed to speed bitmap.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lane            - Lane id
 * @param [in]     speed           - Port speed
 * @param [out]    speed_bitmap    - Speed bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setSpeedToBitmap(const UI32_T unit,
                                   const UI32_T lane,
                                   CLX_PORT_SPEED_T speed,
                                   HAL_LT_DAWN_IFMON_SPEED_BITMAP_T speed_bitmap);

/**
 * @brief To set speed bitmap.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - Database type
 * @param [out]    speed_bitmap    - Speed bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setSpeedBitmap(const UI32_T unit,
                                 const HAL_LT_DAWN_IFMON_TYPE_T type,
                                 HAL_LT_DAWN_IFMON_SPEED_BITMAP_T speed_bitmap);

/**
 * @brief To get speed bitmap.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - Database type
 * @param [out]    speed_bitmap    - Speed bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getSpeedBitmap(const UI32_T unit,
                                 const HAL_LT_DAWN_IFMON_TYPE_T type,
                                 HAL_LT_DAWN_IFMON_SPEED_BITMAP_T speed_bitmap);

/**
 * @brief To set link port bitmap.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     type           - Database type
 * @param [out]    link_bitmap    - Link port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setLinkBitmap(const UI32_T unit,
                                const HAL_LT_DAWN_IFMON_TYPE_T type,
                                HAL_LT_DAWN_IFMON_LANE_BITMAP_T link_bitmap);

/**
 * @brief To get link port bitmap.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     type           - Database type
 * @param [out]    link_bitmap    - Link port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getLinkBitmap(const UI32_T unit,
                                const HAL_LT_DAWN_IFMON_TYPE_T type,
                                HAL_LT_DAWN_IFMON_LANE_BITMAP_T link_bitmap);

/**
 * @brief To set fault port bitmap.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - Database type
 * @param [out]    fault_bitmap    - Fault port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setFaultBitmap(const UI32_T unit,
                                 const HAL_LT_DAWN_IFMON_TYPE_T type,
                                 HAL_LT_DAWN_IFMON_LANE_BITMAP_T fault_bitmap);

/**
 * @brief To get fault port bitmap.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - Database type
 * @param [out]    fault_bitmap    - Fault port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getFaultBitmap(const UI32_T unit,
                                 const HAL_LT_DAWN_IFMON_TYPE_T type,
                                 HAL_LT_DAWN_IFMON_LANE_BITMAP_T fault_bitmap);

/**
 * @brief To get local/remote fault port bitmap.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - Database type
 * @param [out]    fault_bitmap    - Local/Remote fault port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getFaultTypeBitmap(const UI32_T unit,
                                     const HAL_LT_DAWN_IFMON_FAULT_TYPE_T type,
                                     HAL_LT_DAWN_IFMON_LANE_BITMAP_T fault_bitmap);

/**
 * @brief To get software status port bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [out]    status_bitmap    - Status port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getSwStatusBitmap(const UI32_T unit,
                                    HAL_LT_DAWN_IFMON_LANE_BITMAP_T status_bitmap);

/**
 * @brief To set software status port bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     status_bitmap    - Status port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setSwStatusBitmap(const UI32_T unit,
                                    const HAL_LT_DAWN_IFMON_LANE_BITMAP_T status_bitmap);

/**
 * @brief To record time for time type.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     time_type    - Time type
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_recordTime(const UI32_T unit, const HAL_IFMON_TIME_T time_type);

/**
 * @brief To get port speed.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [out]    ptr_speed    - Pointer for port speed
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getSpeed(const UI32_T unit, const UI32_T port, CLX_PORT_SPEED_T *ptr_speed);

/**
 * @brief To set port speed.
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     port     - Physical port ID
 * @param [in]     speed    - Port speed
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setSpeed(const UI32_T unit, const UI32_T port, const CLX_PORT_SPEED_T speed);

/**
 * @brief To get port link.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [out]    ptr_link    - Pointer for port link
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getLink(const UI32_T unit, const UI32_T port, UI32_T *ptr_link);

/**
 * @brief To get port fault.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [out]    ptr_fault    - Pointer for port fault
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getFault(const UI32_T unit, const UI32_T port, UI32_T *ptr_fault);

/**
 * @brief To register a callback function to handle a port link change.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     notify_func    - Callback function
 * @param [in]     ptr_cookie     - Cookie data of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_register(const UI32_T unit,
                           const CLX_IFMON_NOTIFY_FUNC_T notify_func,
                           void *ptr_cookie);

/**
 * @brief To deregister a callback function from callback functions.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     notify_func    - Callback function
 * @param [in]     ptr_cookie     - Cookie data of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_deregister(const UI32_T unit,
                             const CLX_IFMON_NOTIFY_FUNC_T notify_func,
                             void *ptr_cookie);

/**
 * @brief To get callback function count.
 *
 * @param [in]     unit                - Device unit number
 * @param [out]    ptr_callback_cnt    - Pointer for callback function count
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getCallbackCnt(const UI32_T unit, UI32_T *ptr_callback_cnt);

/**
 * @brief This API is used to get interface monitor mode, interface monitor
 *        port bitmap and interface monitor interval.
 *
 * The polling interval is valid if and only if the interface monitor
 * polling mode is used.
 *
 * @param [in]     unit               - Device unit number
 * @param [out]    ptr_mode           - Pointer for interface monitor mode
 * @param [out]    ptr_port_bitmap    - Pointer for interface monitor port bitmap
 * @param [out]    ptr_interval_us    - Pointer for interface monitor polling interval
 *                                      in microseconds
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getMode(const UI32_T unit,
                          CLX_IFMON_MODE_T *ptr_mode,
                          CLX_PORT_BITMAP_T *ptr_port_bitmap,
                          UI32_T *ptr_interval_us);

/**
 * @brief This API is used to set interface monitor mode, interface monitor
 *        port bitmap and interface monitor interval.
 *
 * The polling interval is valid if and only if the interface monitor
 * polling mode is used.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     mode           - Interface monitor mode
 * @param [in]     port_bitmap    - Interface monitor port bitmap
 * @param [in]     interval_us    - Interface monitor polling interval in
 *                                  microseconds
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setMode(const UI32_T unit,
                          const CLX_IFMON_MODE_T mode,
                          const CLX_PORT_BITMAP_T port_bitmap,
                          const UI32_T interval_us);

/**
 * @brief To get port eee mode.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [out]    ptr_eee_mode    - Pointer for port eee mode
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_getPortEeeMode(const UI32_T unit,
                                 const UI32_T port,
                                 CLX_PORT_EEE_MODE_T *ptr_eee_mode);

/**
 * @brief To set port eee mode.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @param [in]     eee_mode    - Interface monitor mode
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_setPortEeeMode(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_PORT_EEE_MODE_T eee_mode);

/**
 * @brief To update sw state if port is at mac loopback or at uni-directional link.
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     port                   - Physical port ID
 * @param [out]    ptr_updated            - State is updated or not
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_updateSwState(const UI32_T unit, const UI32_T port, UI32_T *ptr_updated);

/**
 * @brief To dump device/host link state.
 *
 * @param [in]     unit                   - Device unit number
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_dumpLinkState(const UI32_T unit);

/**
 * @brief To add monitored port.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_addMonPort(const UI32_T unit, const UI32_T port);

/**
 * @brief To delete monitored port.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_delMonPort(const UI32_T unit, const UI32_T port);

/**
 * @brief Dump the database per physical port.
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     flags    - Database type
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_dawn_ifmon_dumpDb(const UI32_T unit, const UI32_T flags);

#endif /* #ifndef HAL_LT_DAWN_IFMON_H */
