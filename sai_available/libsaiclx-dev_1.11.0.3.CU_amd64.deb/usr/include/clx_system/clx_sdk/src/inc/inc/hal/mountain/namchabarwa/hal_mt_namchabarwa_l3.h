/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_l3.h
 * PURPOSE:
 *      Provide HAL driver API functions for CL8570.
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_NAMCHABARWA_L3_H
#define HAL_MT_NAMCHABARWA_L3_H

/*****************************************************************************
 * INCLUDE FILE DECLARATIONS
 *****************************************************************************
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_swc.h>
#include <clx_fcoe.h>
#include <clx_l3.h>
#include <clx_l2.h>
#include <cmlib/cmlib_util.h>
#include <cmlib/cmlib_avl.h>
#include <cmlib/cmlib_list.h>
#include <cmlib/cmlib_bit.h>
#include <cmlib/cmlib_bitmap.h>
#include <hal/hal_l3.h>
#include <hal/hal_vlan.h>
#include <hal/hal_tbl.h>
#include <hal/hal_io.h>
#include <hal/hal_swc.h>
#include <cdb/mountain/cdb_mt.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
/* HITBIT */
#define HAL_MT_NAMCHABARWA_L3_HITBIT_SLICE (32) /* 32 FPU share one MT_TBL_FPU_RSLT_HSH_HIT_ID */
#define HAL_MT_NAMCHABARWA_L3_HITBIT_BITS  (1)  /* 1 bits for each FPU entry */

#define HAL_MT_NAMCHABARWA_L3_MGI_V4_HASH_ENTRY_NUM_PER_BANK (20 * 1024)
#define HAL_MT_NAMCHABARWA_L3_MGI_V6_HASH_ENTRY_NUM_PER_BANK (10 * 1024)
#define HAL_MT_NAMCHABARWA_L3_MSGI_HASH_ENTRY_NUM_PER_BANK   (20 * 1024)

#define HAL_MT_NAMCHABARWA_L3_TCAM_IND_NORMAL_BUF_WORDS \
    (MT_CDB_FPUTCAM_SLV_SLC0_TILE_TCAM_IND_DATA_WORDS)
#define HAL_MT_NAMCHABARWA_L3_TCAM_IND_LONG_BUF_WORDS \
    (MT_CDB_FPUTCAM_SLV_SLC0_TILE_TCAM_IND_DATA_WORDS * 2)
#define HAL_MT_NAMCHABARWA_L3_HASH_IND_BUF_WORDS (MT_CDB_FPUHSH_SLV_TILE_HSH_IND_DATA_WORDS)

/* INTF */
#define HAL_MT_NAMCHABARWA_L3_INTF_ENTRY_NUM(unit) \
    (HAL_TBL_INFO(unit, MT_TBL_DIS_RSLT_BDI_ID)->entry_max_number)
#define HAL_MT_NAMCHABARWA_L3_INTF_ENTRY_MIN(unit) (1) /* SW-reserved 0 */
#define HAL_MT_NAMCHABARWA_L3_INTF_ENTRY_MAX(unit) (HAL_MT_NAMCHABARWA_L3_INTF_ENTRY_NUM(unit) - 1)

/* MTU */
#define HAL_MT_NAMCHABARWA_L3_MTU_SIZE_MIN  (0)
#define HAL_MT_NAMCHABARWA_L3_MTU_SIZE_MAX  (16383)
#define HAL_MT_NAMCHABARWA_L3_MTU_SIZE_DFLT (0)

/* VRF */
#define HAL_MT_NAMCHABARWA_L3_VRF_ENTRY_NUM  (8192)
#define HAL_MT_NAMCHABARWA_L3_VRF_ENTRY_MIN  (0)
#define HAL_MT_NAMCHABARWA_L3_VRF_ENTRY_MAX  (HAL_MT_NAMCHABARWA_L3_VRF_ENTRY_NUM - 1)
#define HAL_MT_NAMCHABARWA_L3_VRF_ENTRY_MASK (HAL_MT_NAMCHABARWA_L3_VRF_ENTRY_NUM - 1)

/* Router-MAC */
#define HAL_MT_NAMCHABARWA_L3_MY_ROUTEMAC_TCAM_NUM(unit) \
    (HAL_TBL_INFO(unit, MT_TBL_DIS_TCAM_RMACI_ID)->entry_max_number)
#define HAL_MT_NAMCHABARWA_L3_MY_ROUTEMAC_NUM(unit) \
    (HAL_TBL_INFO(unit, MT_TBL_DIS_SRAM_RMACI_ID)->entry_max_number)
#define HAL_MT_NAMCHABARWA_L3_MY_ROUTEMAC_MIN(unit) (0)
#define HAL_MT_NAMCHABARWA_L3_MY_ROUTEMAC_MAX(unit) \
    (HAL_MT_NAMCHABARWA_L3_MY_ROUTEMAC_NUM(unit) - 2) /* reserve 1 for invalid */
#define HAL_MT_NAMCHABARWA_L3_MY_ROUTEMAC_INVALID(unit) \
    (HAL_MT_NAMCHABARWA_L3_MY_ROUTEMAC_NUM(unit) - 1)

/* reserved drop adj */
#define HAL_MT_NAMCHABARWA_L3_RESERVE_ADJ_ID         (0)
#define HAL_MT_NAMCHABARWA_L3_HW_RESERVE_ADJ_BIT_NUM (8)

/* ROUTE */
#define HAL_MT_NAMCHABARWA_L3_ROUTE_AFIB_DFLT_NUM (32768)

/* ECMP */
#define HAL_MT_L3_ECMP_PATH_MAX_TOT (1U << 10) /* act_tot = MAX      */
#define HAL_MT_L3_ECMP_HSH_MAX_TOT  (1U << 15) /* sw_spray_tot = MAX */

/* default act_base or orig_base CLX_L3_OUTPUT_TYPE_ADJ/CLX_L3_OUTPUT_TYPE_L2_ECMP */
#define HAL_MT_L3_ADJ_L2_ECMP_PATH_DFLT_BASE_IDX (65535)
/* default act_base or orig_base CLX_L3_OUTPUT_TYPE_MPLS_TRANS */
#define HAL_MT_L3_MPLS_ECMP_PATH_DFLT_BASE_IDX (16384)
/* default act_base or orig_base CLX_L3_OUTPUT_TYPE_NVO3_ADJ */
#define HAL_MT_L3_NVO3_ECMP_PATH_DFLT_BASE_IDX (4095)
#define HAL_MT_L3_ECMP_PATH_DFLT_TOT           (0) /* default act_tot or orig_tot   */

/* MCAST */
#define HAL_L3_RPF_TCAM_MAX_NUM                       (1024)
#define HAL_L3_MCAST_SG_TCAM_MAX_NUM                  (1024)
#define HAL_MT_NAMCHABARWA_L3_MCAST_L3MC_ID(mcast_id) (mcast_id - HAL_L2_MGID_NUM)

#define HAL_MT_L3_MPLS_LABEL_BITMASK    (0xFFFFF)
#define HAL_MT_L3_VALN_BITMASK          (0xFFF)
#define HAL_MT_L3_VALN_VID_BITLENGTH    (12)
#define HAL_MT_L3_SVALN_LABEL_BITLENGTH (8)

#define HAL_MT_NAMCHABARWA_L3_MCAST_FPU_KRN_OFFSET (20)
#define HAL_MT_NAMCHABARWA_L3_MCAST_FPU_KRN_LEN    (1)

/* ECMP */
#define HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT (4)
#define HAL_MT_L3_ECMP_MBR_TABLE_CNT(tot) \
    ((tot > 0) ? ((tot) - 1) / HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT + 1 : 0)
#define HAL_MT_L3_ECMP_MBR_HW_CNT(tot) \
    ((HAL_MT_L3_ECMP_MBR_TABLE_CNT(tot)) * HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT)
#define HAL_MT_L3_ECMP_MBR_TABLE_IDX(offset)    ((offset) / HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT)
#define HAL_MT_L3_ECMP_MBR_TABLE_OFFSET(offset) ((offset) * HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT)

#define HAL_MT_L3_ECMP_NVO3_PER_TABLE_MBR_CNT (1)
#define HAL_MT_L3_ECMP_NVO3_MBR_TABLE_CNT(tot) \
    ((tot > 0) ? ((tot) - 1) / HAL_MT_L3_ECMP_NVO3_PER_TABLE_MBR_CNT + 1 : 0)

#define HAL_MT_L3_ECMP_MBR_PHY2LOGIC_BASE(base) ((base) & 0xffff)

#define HAL_MT_ADJ_L2_ECMP_GRP_MAX_NUM (16 * 1024)
#define HAL_MT_NVO3_ECMP_GRP_MAX_NUM   (64)
#define HAL_MT_MPLS_ECMP_GRP_MAX_NUM   (1024)
#define HAL_MT_ADJ_L2_ECMP_MBR_MAX_NUM (16 * 1024)
#define HAL_MT_NVO3_ECMP_MBR_MAX_NUM   (4 * 1024)
#define HAL_MT_MPLS_ECMP_MBR_MAX_NUM   (4 * 1024)

#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_SLICE_LEN    (1)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_STAGE_LEN    (2)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_TILE_LEN     (3)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_INDEX_LEN    (16)
#define HAL_MT_L3_ECMP_FPU_GRP_BASE_INDEX_LEN        (15)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_SLICE_OFFSET (21)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_STAGE_OFFSET (19)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_TILE_OFFSET  (16)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_INDEX_OFFSET (0)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_IVALID_FWD_PTR    (0x7FFFF) /* 2b'Stage,3b'tile,14b'index */
#define HAL_MT_L3_ECMP_ICIA_GRP_MBR_IVALID_FWD_PTR   (0x3FFFF)

/* drop base id */
#define HAL_MT_NAMCHABARWA_L3_DROP_ID(unit) (HAL_DROP_BASE_ID(unit))

/*****************************************************************************
 * MACRO FUNCTION DECLARATIONS
 *****************************************************************************
 */
/* hw_addr is 20bit format, 2bit stage + 3bit tile + 15bit entry_idx, entry_width is means how many
 * 1x used per entry */
#define HAL_MT_NAMCHABARWA_L3_GET_HITBIT_HW_ADDR(__hw_addr__, __hit_addr__)                      \
    (__hit_addr__ =                                                                              \
         ((((((__hw_addr__) >> CDB_MT_HASH_STAGE_OFFSET) & ((1 << CDB_MT_HASH_STAGE_LEN) - 1)) * \
            HAL_SWC_HASH_TILE_NUM_PER_STAGE) +                                                   \
           (((__hw_addr__) >> CDB_MT_HASH_TILE_OFFSET) & ((1 << CDB_MT_HASH_TILE_LEN) - 1))) *   \
              (HAL_TBL_INFO((unit), (MT_TBL_FPU_RSLT_HSH_HIT_ID))->entry_max_number) +           \
          (((__hw_addr__) & ((1 << CDB_MT_HASH_INDEX_LEN) - 1)) >> 5)))

#define HAL_MT_NAMCHABARWA_L3_GET_PHY_FPU_ADDR(__slice_idx__, __stage_idx__, __tile_idx__,       \
                                               __entry_idx__, __phy_fpu_idx__)                   \
    (__phy_fpu_idx__ =                                                                           \
         (((__entry_idx__) & ((1 << CDB_MT_HASH_INDEX_LEN) - 1)) |                               \
          (((__tile_idx__) & ((1 << CDB_MT_HASH_TILE_LEN) - 1)) << CDB_MT_HASH_TILE_OFFSET) |    \
          (((__stage_idx__) & ((1 << CDB_MT_HASH_STAGE_LEN) - 1)) << CDB_MT_HASH_STAGE_OFFSET) | \
          (((__slice_idx__) & ((1 << CDB_MT_HASH_INST_LEN) - 1)) << CDB_MT_HASH_INST_OFFSET)))

#define HAL_MT_NAMCHABARWA_L3_GET_12_8T_FPU_ADDR(__slice_idx__, __entry_idx__, __phy_fpu_idx__)     \
    (__phy_fpu_idx__ =                                                                              \
         (((__entry_idx__) &                                                                        \
           (((1 << (CDB_MT_HASH_INDEX_LEN + CDB_MT_HASH_TILE_LEN + CDB_MT_HASH_STAGE_LEN)) - 1))) | \
          (((__slice_idx__) & ((1 << CDB_MT_HASH_INST_LEN) - 1)) << CDB_MT_HASH_INST_OFFSET)))

/* ADJ */
#define HAL_MT_NAMCHABARWA_L3_ADJ_RESERVE_ID (0)
#define HAL_MT_NAMCHABARWA_L3_ADJ_FPU_SIZE(__bitmap__, __bitmap_size__, __fpu_size__, __size__) \
    do {                                                                                        \
        UI32_T bit;                                                                             \
        __size__ = 0;                                                                           \
        CMLIB_BITMAP_BIT_FOREACH(__bitmap__, bit, __bitmap_size__)                              \
        {                                                                                       \
            __size__ = __size__ + __fpu_size__;                                                 \
        }                                                                                       \
    } while (0)

#define HAL_MT_NAMCHABARWA_L3_ADJ_HW_TO_SW_INDEX(hw_index, sw_index)        \
    ((sw_index) = ((hw_index) / HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK *       \
                       (HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK -               \
                        HAL_MT_NAMCHABARWA_L3_HW_RESERVE_ADJ_BIT_NUM) +     \
                   ((hw_index) % HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK >=     \
                            HAL_MT_NAMCHABARWA_L3_HW_RESERVE_ADJ_BIT_NUM ?  \
                        ((hw_index) % HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK - \
                         HAL_MT_NAMCHABARWA_L3_HW_RESERVE_ADJ_BIT_NUM) :    \
                        0)))

#define HAL_MT_NAMCHABARWA_L3_ADJ_SW_TO_HW_INDEX(sw_index, hw_index)    \
    ((hw_index) = ((sw_index) /                                         \
                       (HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK -           \
                        HAL_MT_NAMCHABARWA_L3_HW_RESERVE_ADJ_BIT_NUM) * \
                       HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK +            \
                   (sw_index) %                                         \
                       (HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK -           \
                        HAL_MT_NAMCHABARWA_L3_HW_RESERVE_ADJ_BIT_NUM) + \
                   HAL_MT_NAMCHABARWA_L3_HW_RESERVE_ADJ_BIT_NUM))

/* utility */
#define HAL_MT_NAMCHABARWA_L3_PLANE_BMP_FOREACH(__unit__, __plane__)            \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (CMLIB_BITMAP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

/* hw addr and fpu idx */
#define HAL_MT_NAMCHABARWA_L3_GET_FPU_ADDR(__hw_addr__, __fpu_idx__)                         \
    (__fpu_idx__ = ((__hw_addr__) & (HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK - 1)) |             \
         ((((__hw_addr__) >> CDB_MT_HASH_TILE_OFFSET) & ((1 << CDB_MT_HASH_TILE_LEN) - 1))   \
          << (CDB_MT_HASH_TILE_OFFSET - 1)) |                                                \
         ((((__hw_addr__) >> CDB_MT_HASH_STAGE_OFFSET) & ((1 << CDB_MT_HASH_STAGE_LEN) - 1)) \
          << (CDB_MT_HASH_STAGE_OFFSET - 1)))

#define HAL_MT_NAMCHABARWA_L3_GET_HW_ADDR(__fpu_idx__, __hw_addr__)                                \
    (__hw_addr__ = ((__fpu_idx__) & (HAL_SWC_ILE_HASH_ENTRY_NUM_PER_BANK - 1)) |                   \
         ((((__fpu_idx__) >> (CDB_MT_HASH_TILE_OFFSET - 1)) & ((1 << CDB_MT_HASH_TILE_LEN) - 1))   \
          << CDB_MT_HASH_TILE_OFFSET) |                                                            \
         ((((__fpu_idx__) >> (CDB_MT_HASH_STAGE_OFFSET - 1)) & ((1 << CDB_MT_HASH_STAGE_LEN) - 1)) \
          << CDB_MT_HASH_STAGE_OFFSET))

#define HAL_MT_NAMCHABARWA_L3_GET_HW_ADDR_SLICE(__fpu_idx__, __hw_addr__) \
    (__hw_addr__ = ((__fpu_idx__) | (1 << CDB_MT_HASH_INST_OFFSET)))

/* VLAN and MPLS LABEL */
#define HAL_MT_NAMCHABARWA_L3_GET_VLAN_BY_LABEL(__s_vlan__, __c_vlan__, __mpls_en__, \
                                                __mpls_label__)                      \
    do {                                                                             \
        (__s_vlan__) = (__mpls_label__ & HAL_MT_L3_MPLS_LABEL_BITMASK) >>            \
            HAL_MT_L3_VALN_VID_BITLENGTH;                                            \
        if (__mpls_en__) {                                                           \
            (__s_vlan__) |= (1 << HAL_MT_L3_SVALN_LABEL_BITLENGTH);                  \
        }                                                                            \
        (__c_vlan__) = (__mpls_label__) & HAL_MT_L3_VALN_BITMASK;                    \
    } while (0)

#define HAL_MT_NAMCHABARWA_L3_GET_LABEL_BY_VLAN(__mpls_en__, __mpls_label__, __s_vlan__, \
                                                __c_vlan__)                              \
    do {                                                                                 \
        (__mpls_en__) = (((__s_vlan__) >> HAL_MT_L3_SVALN_LABEL_BITLENGTH) & 0x1);       \
        (__mpls_label__) = ((__s_vlan__ & ((1 << HAL_MT_L3_SVALN_LABEL_BITLENGTH) - 1))  \
                            << HAL_MT_L3_VALN_VID_BITLENGTH) |                           \
            (__c_vlan__ & HAL_MT_L3_VALN_BITMASK);                                       \
    } while (0)

/* Mcast */
#define HAL_MT_NAMCHABARWA_L3_MCAST_HSH_PSR_TAGS(tags, inst_id, idx)              \
    do {                                                                          \
        (inst_id = ((tags >> HAL_MT_NAMCHABARWA_L3_MCAST_FPU_KRN_OFFSET) &        \
                    ((1 << HAL_MT_NAMCHABARWA_L3_MCAST_FPU_KRN_LEN) - 1)));       \
        (idx = (tags & ((1 << HAL_MT_NAMCHABARWA_L3_MCAST_FPU_KRN_OFFSET) - 1))); \
    } while (0)

#define HAL_MT_NAMCHABARWA_L3_MCAST_TRANS_1X_TO_2X(hw_addr_1x, hw_addr_2x)                         \
    do {                                                                                           \
        hw_addr_2x = (hw_addr_1x & ((1 << CDB_MT_HASH_INDEX_LEN) - 1));                            \
        hw_addr_2x = (((hw_addr_1x) & (~((1 << CDB_MT_HASH_INDEX_LEN) - 1))) | (hw_addr_2x >> 1)); \
    } while (0)

/* ECMP */
#define HAL_MT_L3_GRPID_TO_TYPEID(id, type, grpid) \
    do {                                           \
        (type) = (((id) >> 29));                   \
        (grpid) = (((id) & 0x1fffffff));           \
    } while (0)

#define HAL_MT_L3_TYPEID_TO_GRPID(type, grpid, id) \
    do {                                           \
        (id) = ((type) << 29) + (grpid);           \
    } while (0)

#define HAL_MT_L3_GRPID_TO_ID(id, grpid) \
    do {                                 \
        (grpid) = (((id) & 0x1fffffff)); \
    } while (0)

#define HAL_MT_L3_L2GRPID_TO_TYPEID(id, grpid) \
    do {                                       \
        (grpid) = (((id) & 0x1fffffff));       \
    } while (0)

#define HAL_MT_L3_L2TYPEID_TO_GRPID(grpid, id)                 \
    do {                                                       \
        (id) = ((CLX_L3_OUTPUT_TYPE_L2_ECMP) << 29) + (grpid); \
    } while (0)

/* Mcast */
#define HAL_MT_NAMCHABARWA_L3_MAC_IS_BCAST(mac) ((mac[0] == 0xFFFFFFFF) && (mac[1] == 0xFFFF))

/* Cpu id and queue info */
#define HAL_MT_NAMCHABARWA_L3_SET_CPU_ID(__cpu_id__, __cpu_id_queue__) \
    do {                                                               \
        (__cpu_id_queue__) &= 0x3F;                                    \
        (__cpu_id_queue__) |= (((__cpu_id__) & 0x3) << 6);             \
    } while (0)

/* Cpu id and queue info */
#define HAL_MT_NAMCHABARWA_L3_SET_CPU_QUEUE(__cpu_queue__, __cpu_id_queue__) \
    do {                                                                     \
        (__cpu_id_queue__) &= 0xC0;                                          \
        (__cpu_id_queue__) |= ((__cpu_queue__) & 0x3F);                      \
    } while (0)
/*****************************************************************************
 * DATA TYPE DECLARATIONS
 *****************************************************************************
 */
typedef struct HAL_MT_L3_RMAC_INTF_S {
    UI32_T vld;
    UI32_T intf_id;
    UI32_T intf_id_mask;
} HAL_MT_L3_RMAC_INTF_T;

typedef struct HAL_MT_L3_CB_S {
    CLX_SEMAPHORE_ID_T sema;
    HAL_MT_L3_RMAC_INTF_T *ptr_idx2intf; /* Array of rmac index */
    UI32_T *ptr_intf2idx;                /* Array of l3 interface */
    UI32_T cpu_id_queue;                 /* cpu id and queue */
} HAL_MT_L3_CB_T;

/* MCAST */
typedef struct HAL_MT_NAMCHABARWA_L3_RPF_TCAM_S {
    UI32_T entry_idx;
    UI32_T bdid;
    UI32_T grp_mtree_id;
    UI32_T grp_mtree_type;
} HAL_MT_NAMCHABARWA_L3_RPF_TCAM_T;

/* MGI KEY LEN */
typedef enum {
    HAL_L3_MCAST_MGI_V4_KEY_TYPE = 0,   /* 0:v4 key         */
    HAL_L3_MCAST_MGI_MPLS_KEY_TYPE = 1, /* 1:mpls key       */
    HAL_L3_MCAST_MGI_V4_KEY_TYPE_LAST

} HAL_L3_MCAST_MGI_KEY_TYPE_T;

typedef enum {
    HAL_L3_MCAST_RPFC_SINGLE_INTF_MODE = 0, /* single intf mode */
    HAL_L3_MCAST_RPFC_ECMP_MODE = 1,        /* ecmp mode */
    HAL_L3_MCAST_RPFC_PIM_BIDIR_MODE = 2,   /* bidir-pim mode */
    HAL_L3_MCAST_RPFC_MODE_TYPE_LAST
} HAL_L3_MCAST_RPFC_MODE_TYPE_T;

typedef enum {
    HAL_L3_RPFC_RP_TYPE = 0,   /* MTREE-ID */
    HAL_L3_RPFC_ECMP_TYPE = 1, /* ECMP-BASE */
    HAL_L3_RPFC_TYPE_LAST
} HAL_L3_RPFC_TYPE_T;

/* emdb_id and hash_id is calculate by grp_id and sn */
typedef struct HAL_MT_NAMCHABARWA_L3_GROUP_MEMBER_INFO_S {
    UI32_T sn;                              /* ipmc group member sn         */
    UI32_T emdb_idx;                        /* ipmc group member emdb idx  */
    UI32_T mcdb_id;                         /* ipmc group member mcdb id    */
    UI32_T port_id;                         /* ipmc group member port       */
    UI32_T intf_id;                         /* ipmc group member interface  */
    UI32_T tbl;                             /* tbl id                       */
    UI32_T hw_idx;                          /* mel idx                      */
    CLX_L3_MCAST_EGR_INTF_TYPE_T intf_type; /* set when add member and used for get */

} HAL_MT_NAMCHABARWA_L3_GROUP_MEMBER_INFO_T;

typedef struct HAL_MT_NAMCHABARWA_L3_GROUP_NODE_S {
    /* AVL key */
    UI32_T group_idx; /* ipmc group index         */

    /* AVL data */
    UI32_T group_size;             /* ipmc group member count  */
    CLX_PORT_BITMAP_T port_bitmap; /* ipmc group pbm           */
    CMLIB_LIST_T *ptr_member_list; /* ipmc group member list   */

} HAL_MT_NAMCHABARWA_L3_GROUP_NODE_T;

typedef struct HAL_MT_NAMCHABARWA_L3_MCAST_CB_S {
    /* RPF */
    UI32_T rp_id_bmp[CLX_BITMAP_SIZE(HAL_L3_RPF_NUM)];
    CMLIB_AVL_HEAD_T *ptr_rpa_avl;

    /* Usage */
    UI32_T hash_1x_cnt;
    UI32_T hash_2x_cnt;
    UI32_T sg_tcam_cnt;

    /* Count */
    UI32_T ipv4_xg_cnt;
    UI32_T ipv4_sg_cnt;
    UI32_T ipv6_xg_cnt;
    UI32_T ipv6_sg_cnt;

    CLX_SEMAPHORE_ID_T sema;
    CLX_SEMAPHORE_ID_T df_sema;

    /* Swdb */
    CMLIB_AVL_HEAD_T *ptr_group_avl; /* save group and member        */
    CMLIB_AVL_HEAD_T *ptr_sg_avl;    /* save (s,g) entry             */
    CMLIB_AVL_HEAD_T *ptr_s_g_avl;   /* save src or grp reference    */

    /* Tile BMP */
    HAL_SWC_HASH_TILE_BITMAP_T mgi_tile_bmp;
    HAL_SWC_HASH_TILE_BITMAP_T msgi_tile_bmp;
    HAL_SWC_HASH_TILE_BITMAP_T rpfc_tile_bmp;

    HAL_MT_NAMCHABARWA_L3_RPF_TCAM_T rpfc_tcam_info[HAL_L3_RPF_TCAM_MAX_NUM];

} HAL_MT_NAMCHABARWA_L3_MCAST_CB_T;

/* sw mcast ip node */
typedef struct HAL_MT_NAMCHABARWA_L3_MCAST_SG_NODE_S {
    /* AVL key */
    UI32_T ipv4;
    UI32_T vrf_id;

    union {
        UI32_T hw_ipv4;
        UI32_T hw_ipv6[4];
    } grp_addr;

    union {
        UI32_T hw_ipv4;
        UI32_T hw_ipv6[4];
    } src_addr;

    /* AVL data */
    UI32_T insert_tcam; /* sg hw addr info */
    UI32_T hw_idx;

    UI32_T da_tag; /* sg hw search key */
    UI32_T da_tcam_hit;
    UI32_T sa_tag;
    UI32_T sa_tcam_hit;
    UI32_T sa_afib_hit;

} HAL_MT_NAMCHABARWA_L3_MCAST_SG_NODE_T;

/* sw mcast ip node */
typedef struct HAL_MT_NAMCHABARWA_L3_MCAST_S_G_NODE_S {
    /* AVL key */
    UI32_T ipv4;
    UI32_T vrf_id;

    union {
        UI32_T hw_ipv4;
        UI32_T hw_ipv6[4];
    } ip_addr;

    UI32_T tag; /* hw info */
    UI32_T tcam_hit;
    UI32_T afib_hit;

    /* reference info */
    UI32_T src_add_by_mcast; /* used by src */
    UI32_T src_used_num;     /* used by src */
    UI32_T sg_only;          /* used by xg */
    UI32_T xg_used_num;      /* used by xg */

} HAL_MT_NAMCHABARWA_L3_MCAST_S_G_NODE_T;

typedef struct HAL_MT_NAMCHABARWA_L3_MCAST_GRP_RSRC_S {
    UI32_T ipv4;
    UI32_T tbl_id;                       /* table ID           */
    HAL_SWC_HASH_TILE_BITMAP_T bank_bmp; /* bank bitmap        */
    union {
        UI32_T ipv4_xg_buf[MT_CDB_FPU_HSH_MGI_V4_WORDS];
        UI32_T ipv6_xg_buf[MT_CDB_FPU_HSH_MGI_V6_WORDS];
        UI32_T ip_sg_buf[MT_CDB_FPU_HSH_MSGI_WORDS];
    } buf;
    C8_T ip_str[CMLIB_UTIL_IP_ADDR_STR_SIZE];

    /* user data */
    UI32_T grp_hit;
    UI32_T mcast_id;
    UI32_T mcast_en;
    UI32_T mc_drop;
    UI32_T c2c_en;
    UI32_T pim_sm_spt_rdy;
    UI32_T keep_ttl;
    UI32_T bd_mode;
    UI32_T l3_intf_id;
    UI32_T mrpf_fail_act;
    UI32_T sg_only;
    UI32_T sa_dc;

    /* hw info */
    UI32_T valid; /* only for sg */
    UI32_T da_tag;
    UI32_T da_tcam_hit;
    UI32_T sa_tag;
    UI32_T sa_tcam_hit;
    UI32_T sa_afib_hit;

    UI32_T insert_tcam; /* sg hw addr info */
    UI32_T hw_idx;

} HAL_MT_NAMCHABARWA_L3_MCAST_GRP_RSRC_T;

typedef struct HAL_MT_NAMCHABARWA_L3_MCAST_MEL_INFO_S {
    UI32_T bd_id;
    UI32_T decr_ttl;
    UI32_T src_supp_ck_vid;
    UI32_T src_supp_tag;
    UI32_T nvo3_adj_idx;
    UI32_T nvo3_encap_idx;
    UI32_T seg_vmid;
    UI32_T mpls_ctl;
    UI32_T swap_lbl;
    UI32_T da_mod;
    UI32_T sa_mod;
    CLX_MAC_T dmac;
    HAL_VLAN_VID_CTL_T vid_info;

} HAL_MT_NAMCHABARWA_L3_MCAST_MEL_INFO_T;

/* ROUTE */
typedef struct HAL_MT_NAMCHABARWA_L3_FIB_RSRC_S {
    /* HW data */
    UI32_T is_default;
    UI32_T fwd_ptr;
    UI32_T sa_dc;
    UI32_T decr_ttl;
    UI32_T acl_label;

    /* User data */
    CLX_L3_OUTPUT_TYPE_T output_type; /* Host|Route                   */
    UI32_T output_id;                 /* Host|Route                   */
    UI32_T subnet_bc_id;              /* SubnetBcast                  */
    UI32_T subnet_bc_en;              /* SubnetBcast                  */
    // UI32_T                  mcast_id;           /* Mcast                        */
    // UI32_T                  mcast_en;           /* Mcast                        */
    UI32_T mpls_label; /* Host|Route                   */
    UI32_T mpls_en;    /* Host|Route                   */
    UI32_T uc_drop;    /* Host|Route                   */
    // UI32_T                  mc_drop;            /* Mcast                        */
    // UI32_T                  pim_reg;            /* Mcast                        */

    /* Both */
    // UI32_T                  cp_to_cpu_idx;      /* Mcast                        */
    // UI32_T                  pim_sm_spt_rdy;     /* Mcast                        */
    // UI32_T                  mrpf_fail_act;      /* Mcast                        */
    // UI32_T                  l3_intf_id;         /* Mcast                        */
    // UI32_T                  acc_intf_is_sig;    /* Mcast                        */

} HAL_MT_NAMCHABARWA_L3_FIB_RSRC_T;

typedef struct HAL_MT_NAMCHABARWA_L3_ROUTE_RSRC_S {
    UI32_T tbl_id;                             /* ILE table ID             */
    UI32_T bank_bmp;                           /* ILE bank bitmap [HASH]   */
    UI32_T free_exm;                           /* ILE free EXM id [HASH]   */
    UI32_T flw_lbl;                            /* IEV_INDIR result         */
    UI32_T iev_idx;                            /* IEV index (getFcoe)      */
    HAL_MT_NAMCHABARWA_L3_FIB_RSRC_T fib_rsrc; /* FIB result               */
    union {
        UI32_T ipv4_tcam_1x_buf[HAL_MT_NAMCHABARWA_L3_TCAM_IND_NORMAL_BUF_WORDS];
        UI32_T ipv6_tcam_2x_buf[HAL_MT_NAMCHABARWA_L3_TCAM_IND_NORMAL_BUF_WORDS];
        UI32_T ipv6_tcam_4x_buf[HAL_MT_NAMCHABARWA_L3_TCAM_IND_LONG_BUF_WORDS];
    } buf;
    union {
        UI32_T afib_ptr_buf[MT_CDB_FPU_RSLT_AFIB_PTR_WORDS];
        UI32_T mgi_buf[MT_CDB_FPU_RSLT_MGI_WORDS];
    } rslt_buf;
    C8_T ip_str[CMLIB_UTIL_IP_NETWORK_STR_SIZE];

    /* e.g.
     * ip=192.168.0.4/31, root-ip=192.168.0.0/29 (buf)
     * found root ile_idx=8192, iev_indir_idx=327680, trie_bmp=0x111, iev_idx=81920 (read from ADJ)
     *
     * - vrf_vld            is 1      (calculated from flag)
     * - msk_btot           is 3      (calculated from prefix)
     * - real_prefix        is 31
     * - root_prefix        is 29
     * - root_key           is 15
     *
     * - trie_bit           is 5      (0 or calculated from trie-bmp)
     * - rslt_shift         is 1      (0 or calculated from trie-bmp)
     *
     * - root_vld           is 1
     * - root_d_ile_idx     is 8192   (read from AVL)
     * - root_s_ile_idx     is 12288  (read from AVL)
     * - root_rslt_idx      is 327680 (read from HW)
     * - root_rslt_cnt      is 3      (read from HW)
     * - real_vld           is 1
     */
    UI32_T is_1x;            /* ILE is_1x                                */
    UI32_T vrf_vld;          /* ILE vrf_vld                              */
    UI32_T vrf_id;           /* ILE vrf_id                               */
    UI32_T option_exist_vld; /* option_exist_vld                         */
    UI32_T option_exist;     /* option_exist                             */
    UI32_T msk_btot;         /* ILE msk_btot                             */
    UI32_T real_prefix;
    UI32_T root_prefix;
    UI32_T root_key;       /* calculated block key [TCAM]              */

    UI32_T trie_bit;       /* based on root IP                         */
    UI32_T rslt_shift;     /* based on IEV_INDIR index                 */

    UI32_T root_vld;       /* root IP exists in HW                     */
    UI32_T root_d_ile_idx; /* root ILE DIP 1x      (only for root_vld) */
    UI32_T root_s_ile_idx; /* root ILE SIP 1x      (only for root_vld) */
    UI32_T root_rslt_idx;  /* root IEV indir index (only for root_vld) */
    UI32_T root_rslt_cnt;  /* root IEV indir count (only for root_vld) */
    UI32_T real_vld;       /* real IP exists in HW                     */

} HAL_MT_NAMCHABARWA_L3_ROUTE_RSRC_T;

/* Add For Bulk Route */
typedef struct HAL_MT_NAMCHABARWA_L3_ROUTE_EXT_RSRC_S {
    HAL_MT_NAMCHABARWA_L3_ROUTE_RSRC_T route_rsrc;
    UI32_T route_id; /* ip add order */
    UI32_T root_ip[HAL_L3_ROUTE_ROOT_WORD_NUM];
    UI32_T root_mask[HAL_L3_ROUTE_ROOT_WORD_NUM];
} HAL_MT_NAMCHABARWA_L3_ROUTE_EXT_RSRC_T;

typedef struct HAL_MT_NAMCHABARWA_L3_ROUTE_TRAV_COOKIE_S {
    UI32_T unit;

    /* [In] for traverseRoute() API, directly callback */
    UI32_T tbl_id;
    CMLIB_LIST_T *ptr_list;
    UI32_T cnt;

    /* [In] for setIpNode() API, move d_ile_idx/s_ile_idx in this range */
    UI32_T is_dip;
    UI32_T entry_num;
    UI32_T old_idx;
    UI32_T new_idx;

} HAL_MT_NAMCHABARWA_L3_ROUTE_TRAV_COOKIE_T;

#if 0 /* bulk route */
typedef struct HAL_MT_NAMCHABARWA_L3_ROUTE_TRAV_SW_COOKIE_S
{
    UI32_T                  unit;

    /* now only counter flag */
    UI32_T                  counter_only;
    UI32_T                  root_count;

} HAL_MT_NAMCHABARWA_L3_ROUTE_TRAV_SW_COOKIE_T;
#endif

/* Add for get l3 actual route count */
typedef struct HAL_MT_NAMCHABARWA_L3_ROUTE_NUM_S {
    UI32_T ipv4_num;
    UI32_T ipv6_num;
    /*  UI32_T                  ipv6_short_num; */
    /*  UI32_T                  ipv6_long_num;  */
    /*  UI32_T                  def_global_num; */
} HAL_MT_NAMCHABARWA_L3_ROUTE_NUM_T;

/* HOST */
typedef struct HAL_MT_NAMCHABARWA_L3_HOST_RSRC_S {
    UI32_T ipv4;
    UI32_T tbl_id;                       /* FPU hsh table ID       */
    UI32_T tcam_tbl_id;                  /* FPU tcam table ID      */
    UI32_T rslt_tbl_id;                  /* FPU rslt table ID      */
    HAL_SWC_HASH_TILE_BITMAP_T bank_bmp; /* FPU hsh bank bitmap    */
    UI32_T is_tcam;                      /* FPU tcam bank bitmap   */
    UI32_T acl_label;                    /* FPU in-band CIA result */
    UI32_T decr_ttl;                     /* FPU decr_ttl           */
    UI32_T sa_dc;                        /* FPU sa_dc              */
    UI32_T fwd_ptr;                      /* FPU fwd_ptr            */
    union {
        UI32_T ipv4_buf[MT_CDB_FPU_HSH_L3_V4_WORDS];
        UI32_T ipv6_buf[MT_CDB_FPU_HSH_L3_V6_WORDS];
    } buf;
    union {
        UI32_T ipv4_buf[MT_CDB_FPU_TCAM_FIB_V4_WORDS];
        UI32_T ipv6_buf[MT_CDB_FPU_TCAM_FIB_V6_4X_WORDS];
    } tcam_buf;
    union {
        UI32_T ip_buf[MT_CDB_FPU_RSLT_FIB_WORDS];
    } rslt_buf;
    UI32_T d_ile_idx;   /* TCAM DIP IDX         */
    UI32_T s_ile_idx;   /* TCAM SIP IDX         */
    UI32_T phy_fpu_idx; /* HASH IDX             */
    C8_T ip_str[CMLIB_UTIL_IP_ADDR_STR_SIZE];

    /* hitbit */
    UI32_T sip_hit;
    /* swdb */
    UI32_T vrf_id;
    CLX_L3_OUTPUT_TYPE_T output_type;
    UI32_T output_id;
    UI32_T subnet_bc_id;
    UI32_T mpls_label;
    UI32_T mpls_en;
    UI32_T uc_drop;
} HAL_MT_NAMCHABARWA_L3_HOST_RSRC_T;

/* ADJ */
typedef struct HAL_MT_NAMCHABARWA_L3_ADJ_CB_S {
    CMLIB_AVL_HEAD_T *ptr_avl; /* cmlib_avl_insert(HAL_L3_ADJ_NODE_T) when addAdj()
                                * cmlib_avl_delete(HAL_L3_ADJ_NODE_T) when delAdj()
                                * cmlib_list_insertToTail(UI32_T) when addGrpList() of ECMP and FRR
                                * cmlib_list_deleteByData(UI32_T) when delGrpList() of ECMP and FRR
                                */
    CLX_SEMAPHORE_ID_T sema;

    UI32_T *ptr_adj_alloc_bmp;
    UI32_T adj_max_count;
    HAL_SWC_HASH_TILE_BITMAP_T adj_arp_bmp;
    HAL_SWC_HASH_TILE_BITMAP_T adj_rpfc_bmp;
    HAL_MT_NAMCHABARWA_L3_RPF_TCAM_T rpfc_tcam_info[HAL_L3_RPF_TCAM_MAX_NUM];

} HAL_MT_NAMCHABARWA_L3_ADJ_CB_T;

typedef struct HAL_MT_L3_ECMP_NODE_S {
    /* AVL key */
    UI32_T grp_type; /* hw ecmp group type     */
    UI32_T grp_idx;  /* hw ecmp group idx     */

    /* AVL data */
    UI32_T grp_mode; /* hw ecmp group mode     */
    UI32_T hal_sel;
    UI32_T path_cnt;
    UI32_T orig_cnt;
    UI32_T weight_cnt;
    UI32_T weight_vld; /* only update weight_cnt when this field is 1 */
    UI32_T use_num;    /* reference count of host, route, fdl */
    UI32_T real_size;  /* real hash buckets for fine grain ECMP */
    UI32_T order_mode; /* order ecmp */
    UI32_T fine_grain; /* fine grain ecmp */
} HAL_MT_L3_ECMP_NODE_T;

typedef struct HAL_MT_L3_ECMP_INFO_S {
    UI32_T grp_id;                    /* hw ecmp group index    */
    CLX_L3_ECMP_MODE_TYPE_T grp_mode; /* hw ecmp group mode     */
    CLX_L3_OUTPUT_TYPE_T grp_type;    /* hw ecmp group type     */
    UI32_T hal_sel;                   /* flag for hal sel       */
    UI32_T path_cnt;
    UI32_T orig_cnt;
    UI32_T weight_cnt;
    UI32_T weight_vld; /* only update weight_cnt when this field is 1 */
    UI32_T use_num;    /* reference count of host, route */
    UI32_T real_size;  /* real hash buckets for fine grain ECMP */
    UI32_T order_mode; /* order ecmp */
    UI32_T fine_grain; /* fine grain ecmp */
} HAL_MT_L3_ECMP_INFO_T;

typedef struct HAL_MT_L3_ECMP_PATH_RSRC_S {
    /* group */
    HAL_MT_L3_ECMP_INFO_T ecmp_info; /* SWDB info */
    UI32_T grp_tbl_id;               /* ECMP_U */
    union {
        UI32_T adj_buf[MT_FPU_RSLT_ECMP_GRP_LAST_FIELD_ID];
        UI32_T nvo3_buf[MT_FWR_RSLT_TNL_ECMP_GRP_LAST_FIELD_ID];
        UI32_T l2_buf[MT_FPU_RSLT_L2_ECMP_GRP_LAST_FIELD_ID];
        UI32_T mpls_buf[MT_ICIA_RSLT_PBR_GRP_LAST_FIELD_ID];
    } grp_buf;

    /* [add/del] path from user
     * [get] path from hw
     */
    UI32_T path_weight; /* weight or 1 */
    UI32_T path_tbl_id; /* ECMP_PATH_U */
    union {
        UI32_T adj_buf[MT_FPU_RSLT_ECMP_MBR_LAST_FIELD_ID];
        UI32_T nvo3_buf[MT_FWR_RSLT_TNL_ECMP_MBR_LAST_FIELD_ID];
        UI32_T l2_buf[MT_FPU_RSLT_L2_ECMP_MBR_LAST_KEY_ID];
        UI32_T mpls_buf[MT_ICIA_RSLT_PBR_MPATH_LAST_FIELD_ID];
    } path_buf;

    /* [add/del] state from user
     * [get] state from hw
     */
    UI32_T fwd_ptr;
    UI32_T dst_idx;
    UI32_T tnl_bd;
    UI32_T state;

    UI32_T mpls_ctl;
    UI32_T mpls_label;

    /* metas from HW act */
    UI32_T act_offset; /* path offset */
    UI32_T act_weight; /* path count for hw, or sw_spray count for sw */
    UI32_T act_vld;
    UI32_T *act_list;  /* path list */

    /* metas from HW orig */
    UI32_T orig_offset;   /* path offset */
    UI32_T orig_weight;   /* path count */
    UI32_T orig_vld;      /* this path may be out of orig, but in act */
    UI32_T *orig_list;    /* path list */
    UI32_T reserved_path; /* path is reserved */

} HAL_MT_L3_ECMP_PATH_RSRC_T;

/* Warmboot */
typedef enum {
    HAL_MT_L3_WBDB_INTF_IEV_L2UC_DROP_IDX = 0, /* iev_l2uc_drop_idx     */
    HAL_MT_L3_WBDB_INTF_INTF2FDID,             /* ptr_intf2fdid         */
    HAL_MT_L3_WBDB_INTF_FDID2INTF,             /* ptr_fdid2intf         */
    HAL_MT_L3_WBDB_INTF_INTF2VRF,              /* ptr_intf2vrf          */
    HAL_MT_L3_WBDB_INTF_LAST

} HAL_MT_L3_WBDB_INTF_T;

typedef enum {
    HAL_MT_L3_WBDB_VRF_IPV4_STATE_BMP = 0, /* ptr_ipv4_state_bmp    */
    HAL_MT_L3_WBDB_VRF_IPV6_STATE_BMP,     /* ptr_ipv4_state_bmp    */
    HAL_MT_L3_WBDB_VRF_LAST

} HAL_MT_L3_WBDB_VRF_T;

typedef enum {
    HAL_MT_L3_WBDB_ADJ_AVL = 0,        /* ptr_avl               */
    HAL_MT_L3_WBDB_ADJ_ALLOC_BMP,      /* alloc idx bmp         */
    HAL_MT_L3_WBDB_ADJ_MAX_NUM,        /* total adj idx         */
    HAL_MT_L3_WBDB_ADJ_ARP_BANK_BMP,   /* arp bank bmp          */
    HAL_MT_L3_WBDB_ADJ_RPFC_BANK_BMP,  /* rpfc bank bmp         */
    HAL_MT_L3_WBDB_ADJ_RPFC_TCAM_INFO, /* rpfc_tcam_info        */
    HAL_MT_L3_WBDB_ADJ_LAST

} HAL_MT_L3_WBDB_ADJ_T;

typedef enum {
    HAL_MT_L3_WBDB_ECMP_AVL = 0,               /* ptr_avl               */
    HAL_MT_L3_WBDB_ECMP_SW_ECMP_PATH_BLOCK_SZ, /* sw_ecmp_path_block_sz */
    HAL_MT_L3_WBDB_ECMP_USE_ACT_EN,            /* use_act_en            */
    HAL_MT_L3_WBDB_ECMP_USE_ORIG_EN,           /* use_orig_en           */
    HAL_MT_L3_WBDB_ECMP_RESILIENT_EN,          /* resilient_en          */
    HAL_MT_L3_WBDB_ECMP_GRP_NUM,               /* ecmp grp num          */
    HAL_MT_L3_WBDB_ECMP_PATH_NUM,              /* add path num          */
    HAL_MT_L3_WBDB_ECMP_ALLOC_PATH_NUM,        /* alloc path num        */
    HAL_MT_L3_WBDB_ECMP_LAST

} HAL_MT_L3_WBDB_ECMP_T;

typedef enum {
    HAL_MT_L3_WBDB_HOST_IPV4_HASH_1X_CNT = 0, /* ipv4_hash_1x_cnt   */
    HAL_MT_L3_WBDB_HOST_IPV6_HASH_2X_CNT,     /* ipv6_hash_2x_cnt   */
    HAL_MT_L3_WBDB_HOST_IPV4_TCAM_1X_CNT,     /* ipv4_tcam_1x_cnt   */
    HAL_MT_L3_WBDB_HOST_IPV6_TCAM_4X_CNT,     /* ipv6_tcam_4x_cnt   */
    HAL_MT_L3_WBDB_HOST_HASH_V4_CNT,          /* per tile ipv4_hash_1x_cnt   */
    HAL_MT_L3_WBDB_HOST_HASH_V6_CNT,          /* per tile ipv6_hash_2x_cnt   */
    HAL_MT_L3_WBDB_HOST_TCAM_V4_CNT,          /* per bank ipv4_tcam_1x_cnt   */
    HAL_MT_L3_WBDB_HOST_TCAM_V6_CNT,          /* per bankipv6_tcam_4x_cnt   */
    HAL_MT_L3_WBDB_HOST_TCAM_SIP_EN,          /* host_tcam_sip_en   */
    HAL_MT_L3_WBDB_HOST_AVL,                  /* host_avl           */
    HAL_MT_L3_WBDB_HOST_LAST

} HAL_MT_L3_WBDB_HOST_T;

typedef enum {
    HAL_MT_L3_WBDB_ROUTE_TCAM_SIP_EN = 0,         /* tcam_sip_en           */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_2X_CNT,        /* tcam_bank_2x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_4X_CNT,        /* tcam_bank_4x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK,               /* tcam_bank             */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_1X,           /* tcam_block_1x         */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_2X,           /* tcam_block_2x         */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_4X,           /* tcam_block_4x         */
    HAL_MT_L3_WBDB_ROUTE_IPV4_TCAM_1X_CNT,        /* ipv4_tcam_1x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_TCAM_2X_CNT,        /* ipv6_tcam_2x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_TCAM_4X_CNT,        /* ipv6_tcam_4x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_USED_V4_CNT,             /* used_v4_cnt           */
    HAL_MT_L3_WBDB_ROUTE_USED_V6_CNT,             /* used_v6_cnt           */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_GLB_CNT,       /* tcam_bank_glb_cnt     */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_ENTRY_CNT,     /* tcam_bank_entry_cnt   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_GLB_ENTRY_CNT, /* tcam_bank_entry_cnt   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BMP,                /* tcam_route_bmp        */
    HAL_MT_L3_WBDB_ROUTE_HASH_BMP,                /* hash_route_bmp        */
    HAL_MT_L3_WBDB_ROUTE_ACL_LABEL_EN,            /* acl_label_en          */
    HAL_MT_L3_WBDB_ROUTE_BULK_EN,                 /* bulk_route_en         */
    HAL_MT_L3_WBDB_ROUTE_FLUSH_EN,                /* bulk_flush_en         */
    HAL_MT_L3_WBDB_ROUTE_V6_RSRC_MAXIMIZE,        /* v6_rsrc_maxmize       */
    HAL_MT_L3_WBDB_ROUTE_IPV4_1X_ROOT_NUM,        /* ipv4_1x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_2X_ROOT_NUM,        /* ipv6_2x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_4X_ROOT_NUM,        /* ipv6_4x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_LAST

} HAL_MT_L3_WBDB_ROUTE_T;

typedef enum {
    HAL_MT_L3_WBDB_MCAST_RP_ID_BMP = 0,    /* rp_id_bmp             */
    HAL_MT_L3_WBDB_MCAST_MGI_BANK_BMP,     /* mgi_bank_bmp          */
    HAL_MT_L3_WBDB_MCAST_MSGI_BANK_BMP,    /* mgi_bank_bmp          */
    HAL_MT_L3_WBDB_MCAST_RPFC_BANK_BMP,    /* rpfc_bank_bmp         */
    HAL_MT_L3_WBDB_MCAST_RPA_AVL,          /* ptr_rpa_avl           */
    HAL_MT_L3_WBDB_MCAST_GRP_AVL,          /* ptr_grp_avl           */
    HAL_MT_L3_WBDB_MCAST_SG_AVL,           /* ptr_sg_node_avl       */
    HAL_MT_L3_WBDB_MCAST_S_G_AVL,          /* ptr_s_or_g_node_avl   */
    HAL_MT_L3_WBDB_MCAST_IPV4_HASH_1X_CNT, /* ipv4_hash_1x_cnt      */
    HAL_MT_L3_WBDB_MCAST_IPV6_HASH_2X_CNT, /* ipv6_hash_2x_cnt      */
    HAL_MT_L3_WBDB_MCAST_SG_TCAM_CNT,      /* sg_hash_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV4_XG_CNT,      /* ipv4_xg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV6_XG_CNT,      /* ipv6_xg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV4_SG_CNT,      /* ipv4_sg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV6_SG_CNT,      /* ipv6_sg_cnt           */
    HAL_MT_L3_WBDB_MCAST_RPFC_TCAM_INFO,   /* rpfc_tcam_info        */
    HAL_MT_L3_WBDB_MCAST_LAST

} HAL_MT_NAMCHABARWA_L3_WBDB_MCAST_T;

typedef enum {
    HAL_MT_L3_WBDB_RMAC_IDX_INTF = 0, /* rmac idx to inff         */
    HAL_MT_L3_WBDB_RMAC_INTF_IDX,     /* intf to rmac             */
    HAL_MT_L3_WBDB_CPU_DI,            /* cpu di                   */
    HAL_MT_L3_WBDB_RMAC_LAST

} HAL_MT_NAMCHABARWA_L3_WBDB_RMAC_T;

#define HAL_MT_L3_WBDB_INTF_BASE  (0)
#define HAL_MT_L3_WBDB_VRF_BASE   (HAL_MT_L3_WBDB_INTF_BASE + HAL_MT_L3_WBDB_INTF_LAST)
#define HAL_MT_L3_WBDB_ADJ_BASE   (HAL_MT_L3_WBDB_VRF_BASE + HAL_MT_L3_WBDB_VRF_LAST)
#define HAL_MT_L3_WBDB_ECMP_BASE  (HAL_MT_L3_WBDB_ADJ_BASE + HAL_MT_L3_WBDB_ADJ_LAST)
#define HAL_MT_L3_WBDB_HOST_BASE  (HAL_MT_L3_WBDB_ECMP_BASE + HAL_MT_L3_WBDB_ECMP_LAST)
#define HAL_MT_L3_WBDB_ROUTE_BASE (HAL_MT_L3_WBDB_HOST_BASE + HAL_MT_L3_WBDB_HOST_LAST)
#define HAL_MT_L3_WBDB_MCAST_BASE (HAL_MT_L3_WBDB_ROUTE_BASE + HAL_MT_L3_WBDB_ROUTE_LAST)
#define HAL_MT_L3_WBDB_RMAC_BASE  (HAL_MT_L3_WBDB_MCAST_BASE + HAL_MT_L3_WBDB_MCAST_LAST)
#define HAL_MT_L3_WBDB_NUM        (HAL_MT_L3_WBDB_RMAC_BASE + HAL_MT_L3_WBDB_RMAC_LAST)
/*****************************************************************************
 * LOCAL SUBPROGRAM BODIES
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- MAIN */
/* Resource */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getCapacity(const UI32_T unit,
                                  const CLX_SWC_RSRC_T type,
                                  const UI32_T param,
                                  UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getUsage(const UI32_T unit,
                               const CLX_SWC_RSRC_T type,
                               const UI32_T param,
                               UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getDstIdx(const UI32_T unit, const CLX_PORT_T port, UI32_T *ptr_ueid_mgid);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_allocFpu(const UI32_T unit,
                               const CLX_L3_OUTPUT_TYPE_T output_type,
                               const UI32_T output_id,
                               const UI32_T subnet_bc_id,
                               UI32_T *ptr_fwd_ptr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_freeFpu(const UI32_T unit,
                              const CLX_L3_OUTPUT_TYPE_T output_type,
                              const UI32_T output_id,
                              const UI32_T subnet_bc_id,
                              const UI32_T hw_addr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getFpu(const UI32_T unit,
                             const UI32_T hw_addr,
                             CLX_L3_OUTPUT_TYPE_T *ptr_output_type,
                             UI32_T *ptr_output_id,
                             UI32_T *ptr_subnet_bc_id);

/* RPFC */
void
hal_mt_namchabarwa_l3_transRpfToHsh(const UI32_T unit,
                                    const HAL_L3_RPFC_TYPE_T type,
                                    const UI32_T ecmp_grp_id,
                                    const UI32_T intf_id,
                                    UI32_T *ptr_buf);

void
hal_mt_namchabarwa_l3_transRpfToTcam(const UI32_T unit,
                                     const HAL_L3_RPFC_TYPE_T type,
                                     const BOOL_T vld,
                                     const UI32_T ecmp_grp_id,
                                     const UI32_T intf_id,
                                     UI32_T *ptr_buf);

/* Init and Deinit */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_init(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_deinit(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_moveTblDma(const UI32_T unit,
                                 const UI32_T tbl_id,
                                 const BOOL_T delete_offset,
                                 const UI32_T offset,
                                 const UI32_T base_old,
                                 const UI32_T num_old,
                                 const UI32_T base_new);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_addEmiHshVlan(const UI32_T unit,
                                    const UI32_T lcl_intf,
                                    const UI32_T bdi,
                                    const UI32_T s_vlan,
                                    const UI32_T c_vlan);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_writeMplsLabel(const UI32_T unit,
                                     const CLX_L3_OUTPUT_TYPE_T output_type,
                                     const UI32_T output_id,
                                     const UI32_T mpls_en,
                                     const UI32_T mpls_label_val);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_readMplsLabel(const UI32_T unit,
                                    const CLX_L3_OUTPUT_TYPE_T output_type,
                                    const UI32_T output_id,
                                    UI32_T *mpls_en,
                                    UI32_T *mpls_label_val);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_freeMplsLabel(const UI32_T unit,
                                    const CLX_L3_OUTPUT_TYPE_T output_type,
                                    const UI32_T output_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getFlIdByPort(const UI32_T unit, const CLX_PORT_T port, UI32_T *pl_id);

/* Dump SWDB */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_dumpSwdb(const UI32_T unit, const UI32_T flags);

/* Properties */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_setUrpfCheck(const UI32_T unit, const UI32_T is_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getUrpfCheck(const UI32_T unit, UI32_T *ptr_is_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_setIcmpRedirect(const UI32_T unit, const UI32_T is_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getIcmpRedirect(const UI32_T unit, UI32_T *ptr_is_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_setValidateIp(const UI32_T unit, const UI32_T enable, const UI32_T fail_act);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getValidateIp(const UI32_T unit, UI32_T *ptr_enable, UI32_T *ptr_fail_act);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_setL3ExcptAct(const UI32_T unit,
                                    const CLX_SWC_PROPERTY_T property,
                                    const CLX_FWD_ACTION_T action);
/**
 * @brief Get L3 exceptions.
 *
 * Apply to the following reason:
 * - CLX_PKT_RX_REASON_IPV4_MC_LKP_MISS
 * - CLX_PKT_RX_REASON_IPV6_MC_LKP_MISS
 * - CLX_PKT_RX_REASON_IPV4_HDR_OPTION
 * - CLX_PKT_RX_REASON_IPV6_HOP_BY_HOP_EXT_HDR
 * - CLX_PKT_RX_REASON_IGR_L3_MTU_FAIL
 * - CLX_PKT_RX_REASON_EGR_L3_MTU_FAIL
 * - CLX_PKT_RX_REASON_IP_TTL_0
 * - CLX_PKT_RX_REASON_IP_TTL_1
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [out]     ptr_action - Action
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getL3ExcptAct(const UI32_T unit,
                                    const CLX_SWC_PROPERTY_T property,
                                    CLX_FWD_ACTION_T *ptr_action);
/**
 * @brief Set L3 Header error actions.
 *
 * Apply to the following reason:
 * - CLX_SWC_PROPERTY_IPV4_VER_ERR
 * - CLX_SWC_PROPERTY_IPV4_CHKSM_ERR
 * - CLX_SWC_PROPERTY_IPV4_OPT
 * - CLX_SWC_PROPERTY_IPV6_VER_ERR
 * CLX8600 not support len err
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [in]     action      - Action
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_setL3HdrErrAct(const UI32_T unit,
                                     const CLX_SWC_PROPERTY_T property,
                                     const CLX_FWD_ACTION_T action);
/**
 * @brief Get L3 Header error actions.
 *
 * Apply to the following reason:
 * - CLX_SWC_PROPERTY_IPV4_VER_ERR
 * - CLX_SWC_PROPERTY_IPV4_CHKSM_ERR
 * - CLX_SWC_PROPERTY_IPV4_OPT
 * - CLX_SWC_PROPERTY_IPV4_LEN_ERR
 * CLX8600 not support len err
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [out]    ptr_action  - Action
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getL3HdrErrAct(const UI32_T unit,
                                     const CLX_SWC_PROPERTY_T property,
                                     CLX_FWD_ACTION_T *ptr_action);

/* ----------------------------------------------------------------------------------- RMAC  */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getMyRouterMacIdx(const UI32_T unit, const UI32_T intf, UI32_T *ptr_index);
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_addMyRouterMac(const UI32_T unit,
                                     const UI32_T index,
                                     const CLX_L3_ROUTER_MAC_INFO_T *ptr_router_mac_info);
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_delMyRouterMac(const UI32_T unit, const UI32_T index);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getMyRouterMac(const UI32_T unit,
                                     const UI32_T index,
                                     CLX_L3_ROUTER_MAC_INFO_T *ptr_router_mac_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_traverseMyRouterMac(const UI32_T unit,
                                          const CLX_L3_ROUTER_MAC_TRAVERSE_FUNC_T callback,
                                          void *ptr_cookie);
/* ----------------------------------------------------------------------------------- INTF */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_init(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_deinit(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_getRsrc(const UI32_T unit,
                                   const UI32_T intf_id,
                                   HAL_L3_INTF_RSRC_T *ptr_intf_rsrc);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_fdid2intf(const UI32_T unit,
                                     const CLX_BRIDGE_DOMAIN_T bdid,
                                     UI32_T *ptr_intf_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_intf2fdid(const UI32_T unit,
                                     const UI32_T intf_id,
                                     CLX_BRIDGE_DOMAIN_T *ptr_bdid);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_getIntf_ext(const UI32_T unit,
                                       const UI32_T intf_id,
                                       CLX_L3_INTF_INFO_T *ptr_l3_intf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_addIntf_ext(const UI32_T unit,
                                       const UI32_T intf_id,
                                       CLX_L3_INTF_INFO_T *ptr_l3_intf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_getcb_ext(const UI32_T unit, HAL_L3_INTF_CB_T **ptr_intf_cb);

/* CLX API */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_addIntf(const UI32_T unit,
                                   const CLX_BRIDGE_DOMAIN_T bdid,
                                   CLX_L3_INTF_INFO_T *ptr_l3_intf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_delIntf(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_getIntf(const UI32_T unit,
                                   const CLX_BRIDGE_DOMAIN_T bdid,
                                   CLX_L3_INTF_INFO_T *ptr_l3_intf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_traverseIntf(const UI32_T unit,
                                        const CLX_L3_INTF_TRAVERSE_FUNC_T callback,
                                        void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_setIntfMyRouterMacIdx(const UI32_T unit,
                                                 const UI32_T intf_id,
                                                 const UI32_T rmac_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_getUsage(const UI32_T unit, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_intf_dumpSwdb(const UI32_T unit);

/* ----------------------------------------------------------------------------------- VRF */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_init(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_deinit(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_addDfltRoute(const UI32_T unit,
                                       const CLX_L3_ROUTE_INFO_T *ptr_route_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_delDfltRoute(const UI32_T unit,
                                       const CLX_L3_ROUTE_INFO_T *ptr_route_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_getDfltRoute(const UI32_T unit, CLX_L3_ROUTE_INFO_T *ptr_route_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_travDfltRoute(const UI32_T unit, CMLIB_LIST_T *ptr_list);

/* SWC property */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_setGlobalRouteMissAction(const UI32_T unit, const UI32_T action);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_getGlobalRouteMissAction(const UI32_T unit, UI32_T *ptr_action);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_getcb_ext(const UI32_T unit, HAL_L3_VRF_CB_T **ptr_vrf_cb);

/* CLX API */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_setVrf(const UI32_T unit,
                                 const UI32_T vrf_id,
                                 const CLX_L3_VRF_INFO_T *ptr_vrf_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_getVrf(const UI32_T unit,
                                 const UI32_T vrf_id,
                                 CLX_L3_VRF_INFO_T *ptr_vrf_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_vrf_dumpSwdb(const UI32_T unit);

/* ----------------------------------------------------------------------------------- ADJ */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_init(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_deinit(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_getAdjInfo(const UI32_T unit,
                                     const UI32_T adj_id,
                                     HAL_L3_ADJ_INFO_T *ptr_adj_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_updateAdjUseNum(const UI32_T unit, const UI32_T adj_id, const BOOL_T inc);

/* handle URPF */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_addEcmpGrpUrpf(/* for addEcmpPath */
                                         const UI32_T unit,
                                         const UI32_T ecmp_grp_id,
                                         const UI32_T intf_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_delEcmpGrpUrpf(/* for delEcmp, delEcmpPath */
                                         const UI32_T unit,
                                         const UI32_T ecmp_grp_id,
                                         const UI32_T intf_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_travGrpUpdateUrpf(/* for setIntf, delIntf */
                                            const UI32_T unit,
                                            const UI32_T is_add,
                                            const UI32_T intf_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_addEcmpGrpIdToList(/* for addEcmpPath */
                                             const UI32_T unit,
                                             const UI32_T ecmp_grp_id,
                                             const UI32_T adj_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_delEcmpGrpIdFromList(/* for delEcmp, delEcmpPath */
                                               const UI32_T unit,
                                               const UI32_T ecmp_grp_id,
                                               const UI32_T adj_id);

/* set Cpu di */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_updateCpuDi(const UI32_T unit, const UI32_T cpu_di);

/* CLX API */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_addAdj(const UI32_T unit,
                                 const CLX_L3_ADJ_INFO_T *ptr_adj_info,
                                 UI32_T *ptr_adj_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_delAdj(const UI32_T unit,
                                 const CLX_L3_ADJ_TYPE_T adj_type,
                                 const UI32_T adj_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_getAdj(const UI32_T unit,
                                 const UI32_T adj_id,
                                 CLX_L3_ADJ_INFO_T *ptr_adj_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_traverseAdj(const UI32_T unit,
                                      const CLX_L3_ADJ_TYPE_T adj_type,
                                      const CLX_L3_ADJ_TRAVERSE_FUNC_T callback,
                                      void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_getUsage(const UI32_T unit, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_dumpSwdb(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_getFwdPtr(const UI32_T unit, const UI32_T adj_id, UI32_T *ptr_fwd_ptr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_getHwAddr(const UI32_T unit, const UI32_T adj_id, UI32_T *ptr_hw_addr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_getAdjIdx(const UI32_T unit, const UI32_T fwr_ptr, UI32_T *ptr_adj_idx);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_getCapacity(const UI32_T unit, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_getUsage(const UI32_T unit, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_addSubBcFdb(const UI32_T unit,
                                      const UI32_T subnet_bc_id,
                                      UI32_T *ptr_hw_idx);
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_setMplsValid(const UI32_T unit, const UI32_T adj_id, const UI32_T valid);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_adj_delSubBcFdb(const UI32_T unit, const UI32_T hw_idx);
/* ----------------------------------------------------------------------------------- ECMP */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_setResilient(const UI32_T unit, const UI32_T is_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getResilient(const UI32_T unit, UI32_T *is_enable);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_setAlgoMode(const UI32_T unit, const CLX_L3_ECMP_ALGORITHM_MODE_T mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getAlgoMode(const UI32_T unit, CLX_L3_ECMP_ALGORITHM_MODE_T *mode);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_setGrpMaxMbrNum(const UI32_T unit, const UI32_T num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getGrpMaxMbrNum(const UI32_T unit, UI32_T *num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getGrpMaxPathCnt(const UI32_T unit, UI32_T *num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_init(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_deinit(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getEcmpInfo(const UI32_T unit,
                                       const UI32_T ecmp_grp_id,
                                       HAL_MT_L3_ECMP_INFO_T *ptr_ecmp_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_updateEcmpUseNum(const UI32_T unit,
                                            const UI32_T ecmp_grp_id,
                                            const BOOL_T inc);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getPathIdxByGrpAdjId(const UI32_T unit,
                                                const UI32_T ecmp_grp_id,
                                                const UI32_T adj_id,
                                                UI32_T *ptr_act_list,
                                                UI32_T *ptr_act_cnt,
                                                UI32_T *ptr_orig_list,
                                                UI32_T *ptr_orig_cnt);

/* CLX API */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_aclBindEcmpGrp(const UI32_T unit,
                                          const UI32_T old_ecmp_grp_id,
                                          UI32_T *new_ecmp_grp_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_aclUnbindEcmpGrp(const UI32_T unit,
                                            const UI32_T old_ecmp_grp_id,
                                            const UI32_T new_ecmp_grp_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_createEcmpGrp(const UI32_T unit,
                                         const CLX_L3_ECMP_GRP_INFO_T *ptr_ecmp_grp_info,
                                         UI32_T *ptr_ecmp_grp_id);
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_setEcmpGrp(const UI32_T unit,
                                      const UI32_T ecmp_grp_id,
                                      const CLX_L3_ECMP_GRP_INFO_T *ptr_ecmp_grp_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_delEcmpGrp(const UI32_T unit,
                                      const CLX_L3_OUTPUT_TYPE_T type,
                                      const UI32_T ecmp_grp_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getEcmpGrp(const UI32_T unit,
                                      const UI32_T ecmp_grp_id,
                                      CLX_L3_ECMP_GRP_INFO_T *ptr_ecmp_grp_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_traverseEcmpGrp(const UI32_T unit,
                                           const CLX_L3_OUTPUT_TYPE_T type,
                                           const CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T callback,
                                           void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_syncEcmpGrp(const UI32_T unit,
                                       const UI32_T old_grp_id,
                                       const UI32_T new_grp_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_addEcmpGrpPath(const UI32_T unit,
                                          const UI32_T ecmp_grp_id,
                                          const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_delEcmpGrpPath(const UI32_T unit,
                                          const UI32_T ecmp_grp_id,
                                          const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getEcmpGrpPathByIdx(const UI32_T unit,
                                               const UI32_T ecmp_grp_id,
                                               const UI32_T path_idx,
                                               CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_setEcmpGrpHashPath(const UI32_T unit,
                                              const UI32_T ecmp_grp_id,
                                              const UI32_T *ptr_hash_val_list,
                                              const UI32_T hash_val_cnt,
                                              const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getEcmpGrpHashPath(const UI32_T unit,
                                              const UI32_T ecmp_grp_id,
                                              const UI32_T hash_val_cnt,
                                              const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info,
                                              UI32_T *ptr_hash_val_list,
                                              UI32_T *ptr_actual_hash_val_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_hwidxTofwdptr(const UI32_T unit,
                                         const UI32_T ecmp_grp_id,
                                         UI32_T *ptr_fwd_ptr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_fwdptrTohwidx(const UI32_T unit,
                                         const UI32_T ptr_fwd_ptr,
                                         UI32_T *ecmp_grp_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getUsageGrp(const UI32_T unit, const UI32_T param, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getUsagePath(const UI32_T unit, const UI32_T param, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getUsageHash(const UI32_T unit, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_setBlockSize(const UI32_T unit, const UI32_T size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getBlockSize(const UI32_T unit, UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getGroupCapacity(const UI32_T unit,
                                            const UI32_T param,
                                            UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getPathCapacity(const UI32_T unit, const UI32_T param, UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_dumpSwdb(const UI32_T unit);

#if defined(CLX_HSH_LIB)
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getEcmpHashPath(const UI32_T unit,
                                           const CLX_SWC_HASH_TYPE_T hash_type,
                                           const CLX_SWC_FLOW_HASH_KEY_T *ptr_hash_key,
                                           const UI32_T ecmp_grp_id,
                                           CLX_L3_ECMP_HASHPATH_RSLT_INFO_T *ptr_rslt);
#endif

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_dumpL2EcmpMbrList(const UI32_T unit, const UI32_T ecmp_grp_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_dumpEcmpMbrList(const UI32_T unit, const UI32_T ecmp_grp_id);

/* Internal API */
/* Create Group */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_createL2Grp(const UI32_T unit,
                                       const CLX_L2_ECMP_GROUP_T *ptr_ecmp_info,
                                       UI32_T *ptr_ecmp_grp_id);

/* Set Group */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_setL2Grp(const UI32_T unit,
                                    const CLX_L2_ECMP_GROUP_T *ptr_ecmp_info,
                                    UI32_T ecmp_grp_id);

/* Del Group */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_delL2Grp(const UI32_T unit, const UI32_T ecmp_grp_id);

/* Get Group */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getL2Grp(const UI32_T unit,
                                    const UI32_T ecmp_grp_id,
                                    CLX_L2_ECMP_GROUP_T *ptr_ecmp_info);

/* Add path */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_addL2GrpPath(const UI32_T unit,
                                        const UI32_T ecmp_grp_id,
                                        const CLX_L2_ECMP_PATH_T *ptr_path_info);

/* Del path */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_delL2GrpPath(const UI32_T unit,
                                        const UI32_T ecmp_grp_id,
                                        const CLX_L2_ECMP_PATH_T *ptr_path_info);

/* Get path by idx */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getL2GrpPathByidx(const UI32_T unit,
                                             const UI32_T ecmp_grp_id,
                                             const UI32_T path_idx,
                                             CLX_L2_ECMP_PATH_T *ptr_path_info);

/* Set grp hsh */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_setL2GrpPathHsh(const UI32_T unit,
                                           const UI32_T ecmp_grp_id,
                                           const UI32_T *ptr_hash_val_list,
                                           const UI32_T hash_val_cnt,
                                           const CLX_L2_ECMP_PATH_T *ptr_path_info);

/* Get grp hsh */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_ecmp_getL2GrpPathHsh(const UI32_T unit,
                                           const UI32_T ecmp_grp_id,
                                           const UI32_T hash_val_cnt,
                                           const CLX_L2_ECMP_PATH_T *ptr_ecmp_path_info,
                                           UI32_T *ptr_hash_val_list,
                                           UI32_T *ptr_actual_hash_val_cnt);

/* set l3 cpu di */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_setL3CpuDi(const UI32_T unit, const UI32_T cpu_id, const UI32_T cpu_queue);
/* ----------------------------------------------------------------------------------- HOST */

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_init(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_deinit(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_getHostIdx(const UI32_T unit,
                                      const CLX_L3_HOST_INFO_T *ptr_host_info,
                                      UI32_T *is_tcam,
                                      UI32_T *ptr_host_idx);

/* CLX API */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_addHost(const UI32_T unit, const CLX_L3_HOST_INFO_T *ptr_host_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_delHost(const UI32_T unit, const CLX_L3_HOST_INFO_T *ptr_host_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_getHost(const UI32_T unit, CLX_L3_HOST_INFO_T *ptr_host_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_traverseHost(const UI32_T unit,
                                        const CLX_L3_HOST_TRAVERSE_FUNC_T callback,
                                        void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_addSubnetBcast(const UI32_T unit,
                                          const CLX_L3_SUBNET_BCAST_INFO_T *ptr_subnet_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_delSubnetBcast(const UI32_T unit,
                                          const CLX_L3_SUBNET_BCAST_INFO_T *ptr_subnet_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_getSubnetBcast(const UI32_T unit,
                                          CLX_L3_SUBNET_BCAST_INFO_T *ptr_subnet_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_traverseSubnetBcast(const UI32_T unit,
                                               const CLX_L3_BCAST_TRAVERSE_FUNC_T callback,
                                               void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_getCapacity(const UI32_T unit, const UI32_T param, UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_getUsage(const UI32_T unit, const UI32_T param, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_host_dumpSwdb(const UI32_T unit);
/* ----------------------------------------------------------------------------------- ROUTE */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_init(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_deinit(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

/* CLX API */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_addRoute(const UI32_T unit, const CLX_L3_ROUTE_INFO_T *ptr_route_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_delRoute(const UI32_T unit, const CLX_L3_ROUTE_INFO_T *ptr_route_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_getRoute(const UI32_T unit, CLX_L3_ROUTE_INFO_T *ptr_route_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_traverseRoute(const UI32_T unit,
                                          const CLX_L3_ROUTE_TRAVERSE_FUNC_T callback,
                                          void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_addBulkRoute(const UI32_T unit,
                                         const CLX_BULK_OP_MODE_T mode,
                                         const UI32_T route_cnt,
                                         const CLX_L3_ROUTE_INFO_T *ptr_route_info_list,
                                         CLX_ERROR_NO_T *ptr_rc_list);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_delBulkRoute(const UI32_T unit,
                                         const CLX_BULK_OP_MODE_T mode,
                                         const UI32_T route_cnt,
                                         const CLX_L3_ROUTE_INFO_T *ptr_route_info_list,
                                         CLX_ERROR_NO_T *ptr_rc_list);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_getBulkRoute(const UI32_T unit, CLX_L3_ROUTE_INFO_T *ptr_route_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_dumpBulkRouteSw(const UI32_T unit,
                                            const UI32_T count_only,
                                            const UI32_T ip_type_v4);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_getCapacity(const UI32_T unit, const UI32_T param, UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_getUsage(const UI32_T unit, const UI32_T param, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_route_dumpSwdb(const UI32_T unit);

/* ----------------------------------------------------------------------------------- MCAST */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_init(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_deinit(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

/* MEL for VEPA */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_delMemberAll(const UI32_T unit, const UI32_T mcast_id);

/* CLX API */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_addId(const UI32_T unit, const UI32_T flags, UI32_T *ptr_mcast_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_delId(const UI32_T unit, const UI32_T mcast_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_getId(const UI32_T unit,
                                  const UI32_T mcast_id,
                                  UI32_T *ptr_flags,
                                  CLX_PORT_BITMAP_T port_bitmap);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_addEgrIntfByPort(const UI32_T unit,
                                             const UI32_T mcast_id,
                                             const UI32_T port_id,
                                             const UI32_T egr_intf_cnt,
                                             const CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_delEgrIntfByPort(const UI32_T unit,
                                             const UI32_T mcast_id,
                                             const UI32_T port_id,
                                             const UI32_T egr_intf_cnt,
                                             const CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_setEgrIntfByPort(const UI32_T unit,
                                             const UI32_T mcast_id,
                                             const UI32_T port_id,
                                             const UI32_T egr_intf_cnt,
                                             const CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_getEgrIntfByPort(const UI32_T unit,
                                             const UI32_T mcast_id,
                                             const UI32_T port_id,
                                             const UI32_T egr_intf_cnt,
                                             CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf,
                                             UI32_T *ptr_actual_egr_intf_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_getEgrIntfCntByPort(const UI32_T unit,
                                                const UI32_T mcast_id,
                                                const UI32_T port_id,
                                                UI32_T *ptr_egr_intf_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_addGroup(const UI32_T unit,
                                     const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_delGroup(const UI32_T unit,
                                     const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_getGroup(const UI32_T unit, CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_traverseGroup(const UI32_T unit,
                                          const CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T callback,
                                          void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_addDfIntf(const UI32_T unit,
                                      const UI32_T intf_id,
                                      const CLX_IP_ADDR_T *ptr_rp_addr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_delDfIntf(const UI32_T unit,
                                      const UI32_T intf_id,
                                      const CLX_IP_ADDR_T *ptr_rp_addr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_getDfIntf(const UI32_T unit,
                                      const UI32_T intf_id,
                                      const UI32_T rp_addr_cnt,
                                      UI32_T *ptr_actual_rp_addr_cnt,
                                      CLX_IP_ADDR_T *ptr_rp_addr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_dumpSwdb(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_getCapacity(const UI32_T unit, const UI32_T param, UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_getUsage(const UI32_T unit, const UI32_T param, UI32_T *ptr_cnt);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_mcast_swEntryOper(const UI32_T unit,
                                        const HAL_CMN_ACTION_T type,
                                        HAL_MT_NAMCHABARWA_L3_MCAST_S_G_NODE_T *ptr_node_info);

/* ----------------------------------------------------------------------------------- FRR */
CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_createFrrStateId(const UI32_T unit,
                                       const CLX_L3_OUTPUT_TYPE_T type,
                                       UI32_T *ptr_state_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_destroyFrrStateId(const UI32_T unit,
                                        const CLX_L3_OUTPUT_TYPE_T type,
                                        const UI32_T state_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_addFrrPath(const UI32_T unit,
                                 const CLX_L3_OUTPUT_TYPE_T type,
                                 const UI32_T frr_grp,
                                 const BOOL_T is_stanby,
                                 const CLX_L3_FRR_PATH_INFO_T *path_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_delFrrPath(const UI32_T unit,
                                 const CLX_L3_OUTPUT_TYPE_T type,
                                 const UI32_T frr_grp,
                                 const BOOL_T is_stanby,
                                 const CLX_L3_FRR_PATH_INFO_T *path_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_setFrrState(const UI32_T unit,
                                  const CLX_L3_OUTPUT_TYPE_T type,
                                  const UI32_T state_id,
                                  const BOOL_T link_up);

CLX_ERROR_NO_T
hal_mt_namchabarwa_l3_getFrrState(const UI32_T unit,
                                  const CLX_L3_OUTPUT_TYPE_T type,
                                  const UI32_T state_id,
                                  BOOL_T *ptr_link_up);
#endif /* End of HAL_L3_H */
