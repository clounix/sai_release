/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_mpls.h
 * PURPOSE:
 *  Provides MPLS HAL API for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_MPLS_H
#define HAL_MT_NAMCHABARWA_MPLS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_initWarm(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_deinitWarm(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_deinitCfg(const UI32_T unit);

/**
 * @brief Create a MPLS tunnel port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of MPLS encapsulation label stack.
 * @param [out]    ptr_port    - Pointer of MPLS tunnel port.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_createPort(const UI32_T unit,
                                   const CLX_MPLS_ENCAP_KEY_T *ptr_key,
                                   CLX_PORT_T *ptr_port);

/**
 * @brief Destroy a MPLS tunnel port.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - MPLS tunnel port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_destroyPort(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Add a MPLS LSP tunnel initiation.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - MPLS tunnel port.
 * @param [in]     ptr_init    - Pointer of LSP tunnel initiation.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_addInit(const UI32_T unit,
                                const CLX_PORT_T port,
                                const CLX_MPLS_INIT_T *ptr_init);

/**
 * @brief Get MPLS tunnel port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of MPLS encapsulation label stack.
 * @param [out]    ptr_port    - Pointer of MPLS tunnel port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getPort(const UI32_T unit,
                                const CLX_MPLS_ENCAP_KEY_T *ptr_key,
                                CLX_PORT_T *ptr_port);

/**
 * @brief Delete a MPLS LSP tunnel initiation.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - MPLS tunnel port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_delInit(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get a MPLS LSP tunnel initiation.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - MPLS tunnel port.
 * @param [out]    ptr_init    - Pointer of LSP tunnel initiation.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getInit(const UI32_T unit,
                                const CLX_PORT_T port,
                                CLX_MPLS_INIT_T *ptr_init);

/**
 * @brief Get the encapsulation of a MPLS tunnel port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - MPLS tunnel port.
 * @param [out]    ptr_key    - Pointer of MPLS encapsulation label stack.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getKey(const UI32_T unit,
                               const CLX_PORT_T port,
                               CLX_MPLS_ENCAP_KEY_T *ptr_key);

/**
 * @brief Add a MPLS LSP tunnel termination.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of LSP tunnel termination match key.
 * @param [in]     ptr_term    - Pointer of LSP tunnel termination.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_addTerm(const UI32_T unit,
                                const CLX_MPLS_MATCH_KEY_T *ptr_key,
                                const CLX_MPLS_TERM_T *ptr_term);

/**
 * @brief Get a MPLS LSP tunnel termination.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of LSP tunnel termination match key.
 * @param [out]    ptr_term    - Pointer of LSP tunnel termination.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getTerm(const UI32_T unit,
                                const CLX_MPLS_MATCH_KEY_T *ptr_key,
                                CLX_MPLS_TERM_T *ptr_term);

/**
 * @brief Delete a MPLS LSP tunnel termination.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     ptr_key    - Pointer of LSP tunnel termination match key.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_delTerm(const UI32_T unit, const CLX_MPLS_MATCH_KEY_T *ptr_key);

/**
 * @brief Add a MPLS transit LSP.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_key      - Pointer of LSP transit match key.
 * @param [in]     ptr_nhlfe    - Pointer of LSP transit next hop information.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_addTransit(const UI32_T unit,
                                   const CLX_MPLS_MATCH_KEY_T *ptr_key,
                                   const CLX_MPLS_NHLFE_T *ptr_nhlfe);

/**
 * @brief Get a MPLS transit LSP.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_key      - Pointer of LSP transit match key.
 * @param [out]    ptr_nhlfe    - Pointer of LSP transit next hop information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getTransit(const UI32_T unit,
                                   const CLX_MPLS_MATCH_KEY_T *ptr_key,
                                   CLX_MPLS_NHLFE_T *ptr_nhlfe);

/**
 * @brief Delete a MPLS transit LSP.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     ptr_key    - Pointer of LSP transit match key.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_delTransit(const UI32_T unit, const CLX_MPLS_MATCH_KEY_T *ptr_key);

/**
 * @brief Get MPLS label value range.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     type             - MPLS label type.
 * @param [out]    ptr_min_value    - Pointer of minimum label value.
 * @param [out]    ptr_max_value    - Pointer of maximum label value.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getLabelRange(const UI32_T unit,
                                      const CLX_MPLS_LABEL_TYPE_T type,
                                      UI32_T *ptr_min_value,
                                      UI32_T *ptr_max_value);

/**
 * @brief Set MPLS label value range.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - MPLS label type.
 * @param [in]     min_value    - Minimum label value. Shall > 15.
 * @param [in]     max_value    - Maximum label value.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_setLabelRange(const UI32_T unit,
                                      const CLX_MPLS_LABEL_TYPE_T type,
                                      const UI32_T min_value,
                                      const UI32_T max_value);

/**
 * @brief Create a PW Interface Object.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of PW key.
 * @param [out]    ptr_port    - Pointer PW port.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_createPwPort(const UI32_T unit,
                                     const CLX_MPLS_PW_KEY_T *ptr_key,
                                     CLX_PORT_T *ptr_port);

/**
 * @brief Get the PW Interface port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of PW key.
 * @param [out]    ptr_port    - Pointer of PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getPwPort(const UI32_T unit,
                                  const CLX_MPLS_PW_KEY_T *ptr_key,
                                  CLX_PORT_T *ptr_port);

/**
 * @brief Destroy a PW Interface Object.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_destroyPwPort(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get the Key of a PW Interface Object.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - PW port.
 * @param [out]    ptr_key    - Pointer of pw key.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getPwKey(const UI32_T unit,
                                 const CLX_PORT_T port,
                                 CLX_MPLS_PW_KEY_T *ptr_key);

/**
 * @brief Add a MPLS PW.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - PW port.
 * @param [in]     ptr_pw    - Pointer of MPLS PW.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_addPw(const UI32_T unit,
                              const CLX_PORT_T port,
                              const CLX_MPLS_PW_T *ptr_pw);

/**
 * @brief Delete a MPLS PW.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_delPw(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get a MPLS PW.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - PW port.
 * @param [out]    ptr_pw    - Pointer of MPLS PW.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getPw(const UI32_T unit, const CLX_PORT_T port, CLX_MPLS_PW_T *ptr_pw);

/**
 * @brief Add a MPLS VPWS.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - PW port.
 * @param [in]     ptr_ac    - Pointer of PW AC information.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_addVpws(const UI32_T unit,
                                const CLX_PORT_T port,
                                const CLX_MPLS_AC_T *ptr_ac);

/**
 * @brief Delete a MPLS VPWS.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_delVpws(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get a MPLS VPWS.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Pw port.
 * @param [out]    ptr_ac    - Pointer of PW AC information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getVpws(const UI32_T unit, const CLX_PORT_T port, CLX_MPLS_AC_T *ptr_ac);

/**
 * @brief update vpws ac lag port.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     lag_id            - lag port.
 * @param [in]     add_member_cnt    - add port cnt.
 *                                     ptr_add_member_di        -- add port member.
 *                                     del_member_cnt        -- del port cnt
 *                                     ptr_del_member_di        -- del port member
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_updateVpwsLagMember(const UI32_T unit,
                                            const UI32_T lag_id,
                                            const UI32_T add_member_cnt,
                                            const UI32_T *ptr_add_member_di,
                                            const UI32_T del_member_cnt,
                                            const UI32_T *ptr_del_member_di);

/**
 * @brief Get all MPLS init entries.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_traverseInit(const UI32_T unit,
                                     const CLX_MPLS_INIT_TRAVERSE_FUNC_T callback,
                                     void *ptr_cookie);

/**
 * @brief Get all MPLS transit entries.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_traverseTransit(const UI32_T unit,
                                        const CLX_MPLS_TRANSIT_TRAVERSE_FUNC_T callback,
                                        void *ptr_cookie);

/**
 * @brief Get all MPLS term entries.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_traverseTerm(const UI32_T unit,
                                     const CLX_MPLS_TERM_TRAVERSE_FUNC_T callback,
                                     void *ptr_cookie);

/**
 * @brief Get all MPLS PW entries.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_traversePw(const UI32_T unit,
                                   const CLX_MPLS_PW_TRAVERSE_FUNC_T callback,
                                   void *ptr_cookie);

/**
 * @brief Get MPLS path information.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - MPLS tunnel or PW port.
 * @param [in]     ptr_vlan_tag    - L2VPN PW VLAN tag.
 * @param [in]     action          - L2VPN PW VLAN tag action.
 * @param [out]    ptr_path        - Pointer of the path info of the port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getPathInfo(const UI32_T unit,
                                    const CLX_PORT_T port,
                                    const CLX_VLAN_TAG_ACTION_T *ptr_vlan_tag,
                                    const CLX_VLAN_ACTION_T action,
                                    HAL_MPLS_PATH_T *ptr_path);

/**
 * @brief Get MPLS tunnel or PW por by path information.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_path    - Pointer of the path info of the port.
 *                               Shall specify the seg and th di of the path.
 * @param [out]    ptr_port        - MPLS tunnel or PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getPortByPathInfo(const UI32_T unit,
                                          const HAL_MPLS_PATH_T *ptr_path,
                                          CLX_PORT_T *ptr_port);

/**
 * @brief Get PW VLAN tag action
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - PW port.
 * @param [in]     vid1               - First VLAN ID.
 * @param [in]     vid2               - Second VLAN ID.
 * @param [in]     vid_ctl            - VID control.
 * @param [out]    ptr_tag_action     - Pointer of VLAN tag action.
 * @param [out]    ptr_vlan_action    - Pointer of VLAN action.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_getPwVlanTagAction(const UI32_T unit,
                                           const CLX_PORT_T port,
                                           const CLX_VLAN_T vid1,
                                           const CLX_VLAN_T vid2,
                                           const UI32_T vid_ctl,
                                           CLX_VLAN_TAG_ACTION_T *ptr_tag_action,
                                           CLX_VLAN_ACTION_T *ptr_vlan_action);

/**
 * @brief Translate L3 multicast egress interface to HW MEL info.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Egress physical port.
 * @param [in]     ptr_egr_intf      - Pointer of egress interface.
 * @param [out]    ptr_mel_info      - Pointer of MEL info.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_mcast_transEgrIntfToMelInfo(
    const UI32_T unit,
    const UI32_T port,
    const CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf,
    HAL_MT_NAMCHABARWA_L3_MCAST_MEL_INFO_T *ptr_mel_info);

/**
 * @brief Translate HW MEL info to L3 multicast egress interface.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Egress physical port.
 * @param [in]     ptr_mel_info      - Pointer of MEL info.
 * @param [out]    ptr_egr_intf      - Pointer of egress interface.
 * @param [out]    ptr_tag_action    - Pointer of VLAN tag action.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_mcast_transMelInfoToEgrIntf(
    const UI32_T unit,
    const UI32_T port,
    const HAL_MT_NAMCHABARWA_L3_MCAST_MEL_INFO_T *ptr_mel_info,
    CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf,
    CLX_VLAN_TAG_ACTION_T *ptr_tag_action);

/**
 * @brief Update adjacency information
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     adj_id    - Nvo3 adjacency ID.
 * @param [in]     port      - Egress port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mpls_updateNvo3AdjInfo(const UI32_T unit,
                                          const UI32_T adj_id,
                                          const CLX_PORT_T port);

#endif
