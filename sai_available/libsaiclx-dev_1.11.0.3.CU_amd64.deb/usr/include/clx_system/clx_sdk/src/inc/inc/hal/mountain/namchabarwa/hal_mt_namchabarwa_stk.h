/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_stk.h
 * PURPOSE:
 *      It provides hal stacking module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NAMCHABARWA_STK_H
#define HAL_MT_NAMCHABARWA_STK_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stk.h>
#include <clx_port.h>
#include <clx_swc.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum { HAL_CHIP_TYP_LC = 0, HAL_CHIP_TYP_FAB = 1 } HAL_CHIP_TYP_ENUM_T;

typedef enum { HAL_FL_TYP_ETH = 0, HAL_FL_TYP_FAB = 1 } HAL_FL_TYP_ENUM_T;

typedef enum {
    HAL_FL_HASH_SEL_MODULO = 0,
    HAL_FL_HASH_SEL_MULTIPLY_SHIFT = 1
} HAL_FL_HASH_SEL_ENUM_T;

typedef enum {
    HAL_REP_SCH_WITHOUT_LOCAL_MC_REP = 0,
    HAL_REP_SCH_WITH_LOCAL_MC_REP = 1
} HAL_REP_SCH_ENUM_T;

typedef enum {
    HAL_MT_NAMCHABARWA_STK_REDIRECT_TO_CPU_L2UC,
    HAL_MT_NAMCHABARWA_STK_REDIRECT_TO_CPU_L3UC,
} HAL_MT_NAMCHABARWA_STK_CPU_DI_SRC_T;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */

/**
 * @brief Initiate the stk software resource, such as software database and semaphore.
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_initRsrc(const UI32_T unit);

/**
 * @brief Initiate the stk hardware configuration.
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_initCfg(const UI32_T unit);

/**
 * @brief Set chip id.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     chip    - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_setMyChipId(const UI32_T unit, const UI32_T chip);

/**
 * @brief Add stacking port to a stacking group path.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Path id
 * @param [in]     port    - Port id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_addStackingPort(const UI32_T unit, const UI32_T path, const UI32_T port);

/**
 * @brief Delete stacking port from a stacking group path.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     path       - Path id
 * @param [in]     port       - Port id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_delStackingPort(const UI32_T unit, const UI32_T path, const UI32_T port);

/**
 * @brief Get stacking port list from a stacking group path.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     path             - Path id
 * @param [out]    ptr_port_list    - Port list
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */

CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_getStackingPort(const UI32_T unit,
                                       const UI32_T path,
                                       CLX_PORT_BITMAP_T *ptr_port_list);

/**
 * @brief Set a path to the remote chip.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Path id
 * @param [in]     chip    - Device chip id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_setPathToRemoteChip(const UI32_T unit, const UI32_T path, const UI32_T chip);

/**
 * @brief Set the DIL entry.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     di               - Destination index
 * @param [in]     ptr_dil_entry    - DIL entry
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_setDilEntry(const UI32_T unit,
                                   const UI32_T di,
                                   const CLX_STK_DIL_T *ptr_dil_entry);

/**
 * @brief Reset the DIL entry.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     di      - Destination index
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_resetDilEntry(const UI32_T unit, const UI32_T di);

/**
 * @brief Get the DIL entry.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     di               - Destination index
 * @param [out]    ptr_dil_entry    - DIL entry
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_getDilEntry(const UI32_T unit,
                                   const UI32_T di,
                                   CLX_STK_DIL_T *ptr_dil_entry);

/* EXPORTED HAL PROGRAMS
 */
/**
 * @brief Set the lag as fabric path.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     lag_id    - Lag id
 * @param [in]     is_fl     - Lag members with remote di or not
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_setDstLag(const UI32_T unit, const UI32_T lag_id, const UI32_T is_fl);

/**
 * @brief Get fabric port bitmap in hw plane port view.
 *
 * 1. For pp_pbmp size, please reference HAL_ITM_PBM_WORDS.
 *
 * @param [in]     unit           - Device unit number
 * @param [out]    ptr_pp_pbmp    - mgid port bitmap   (optional)
 * @param [out]    cl_pbmp        - CLX_PORT_BITMAP_T  (optional)
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_getFabPortBmp(const UI32_T unit,
                                     UI32_T *ptr_pp_pbmp,
                                     CLX_PORT_BITMAP_T cl_pbmp);

/**
 * @brief Check given port is used as fabric port or not.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port
 *                           0 : used as front port
 * @param [out]    ptr_is_fab             - status
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_checkFabPort(const UI32_T unit, const UI32_T port, BOOL_T *ptr_is_fab);

/**
 * @brief Set CPU DI priority and CPU queue ID.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [in]     value       - DI priority or queue ID value
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_setCpuDiProperty(const UI32_T unit,
                                        const CLX_SWC_CPU_DI_PROPERTY_T property,
                                        const UI32_T value);

/**
 * @brief Get CPU DI priority and CPU queue ID.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     property     - Property type
 * @param [out]    ptr_value    - DI priority or queue ID value
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_getCpuDiProperty(const UI32_T unit,
                                        const CLX_SWC_CPU_DI_PROPERTY_T property,
                                        UI32_T *ptr_value);

/**
 * @brief Get CPU DI.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     src           - CPU DI user
 * @param [out]    ptr_cpu_di    - CPU DI
 * @return         CLX_E_OK    - Operate success
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stk_getCpuDi(const UI32_T unit,
                                const HAL_MT_NAMCHABARWA_STK_CPU_DI_SRC_T src,
                                UI32_T *ptr_cpu_di);
/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif
