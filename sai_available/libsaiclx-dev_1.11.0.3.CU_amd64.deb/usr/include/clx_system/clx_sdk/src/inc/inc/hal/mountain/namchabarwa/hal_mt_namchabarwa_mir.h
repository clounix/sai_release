/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_mir.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8600.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_MIR_H
#define HAL_MT_NAMCHABARWA_MIR_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_mir.h>
#include <hal/hal_mir.h>

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_addLocalSpanSession(const UI32_T unit,
                                           const UI32_T entry_id,
                                           const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_addRspanSrcSession(const UI32_T unit,
                                          const UI32_T entry_id,
                                          const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_addRspanDstSession(const UI32_T unit,
                                          const UI32_T entry_id,
                                          const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_setRspanDstSession(const UI32_T unit,
                                          const UI32_T entry_id,
                                          const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_addErspanSrcSession(const UI32_T unit,
                                           const UI32_T entry_id,
                                           const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_setErspanSrcSession(const UI32_T unit,
                                           const UI32_T entry_id,
                                           const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_addErspanDstSession(const UI32_T unit,
                                           const UI32_T entry_id,
                                           const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_delLocalSpanSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_delRspanSrcSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_delRspanDstSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_delErspanSrcSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_delErspanDstSession(const UI32_T unit, const UI32_T entry_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_getLocalSpanSession(const UI32_T unit,
                                           const UI32_T entry_id,
                                           CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_getRspanSrcSession(const UI32_T unit,
                                          const UI32_T entry_id,
                                          CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_getRspanDstSession(const UI32_T unit,
                                          const UI32_T entry_id,
                                          CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_getErspanSrcSession(const UI32_T unit,
                                           const UI32_T entry_id,
                                           CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_getErspanDstSession(const UI32_T unit,
                                           const UI32_T entry_id,
                                           CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_setHwMirSrcPort(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_DIR_T dir,
                                       const UI32_T mir_session_bitmap);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_getHwMirSrcPort(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_DIR_T dir,
                                       UI32_T *ptr_mir_session_bitmap);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_addErspanTerm(const UI32_T unit,
                                     const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_delErspanTerm(const UI32_T unit,
                                     const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_findErspanTerm(const UI32_T unit,
                                      const CLX_MIR_ERSPAN_TERM_T *ptr_erspan_term_search,
                                      HAL_MIR_ERSPAN_TERM_T **ptr_erspan_term);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_setDestination(const UI32_T unit,
                                      const UI32_T entry_id,
                                      const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_checkParameter(const UI32_T unit, const CLX_MIR_SESSION_T *ptr_session);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_setErspanTermMissAction(const UI32_T unit, const UI32_T miss_action);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_getErspanTermMissAction(const UI32_T unit, UI32_T *ptr_miss_action);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_checkRspanMirrorPort(const UI32_T unit,
                                            const UI32_T port,
                                            UI32_T *ptr_is_rspan);

CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_updateHwLagPortEvent(const UI32_T unit,
                                            const UI32_T event,
                                            const CLX_PORT_T lag_port);
/**
 * @brief To set selective flow config
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_select_cfg      - Selective flow config
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         CLX_E_BAD_PARAMETER     - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_setSelectiveFlowMir(const UI32_T unit,
                                           const CLX_SWC_SELECTIVE_FLOW_CFG_T *ptr_select_cfg);

/**
 * @brief To get selective flow config
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [out]    ptr_select_cfg      - Selective flow config
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         CLX_E_BAD_PARAMETER     - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_mir_getSelectiveFlowMir(const UI32_T unit,
                                           CLX_SWC_SELECTIVE_FLOW_CFG_T *ptr_select_cfg);

#endif /* End of HAL_MT_NAMCHABARWA_MIR_H */
