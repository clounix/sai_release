/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  dcc_dma.h
 * PURPOSE:
 *  1. Provide the access interfaces of DMA and CLD DMA to chip Device Control Command(DCC).
 *  2. Define DCC DMA and CLD DMA related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_DMA_H
#define DCC_DMA_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <dcc/dcc.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define DCC_DMA_BYTES_PER_WORD    (4)
#define DCC_MAX_DMA_MOVE_DATA_LEN (8 * 1024) /* 8KB */

/* DATA TYPE DECLARATIONS
 */
/* DCC CLD DMA command type */
enum {
    CLD_CMD_SET_CLD = 0x1,
    CLD_CMD_SET_TASK,
    CLD_CMD_SET_TASK_IDLE,
    CLD_CMD_SET_BASE_ADDR,
    CLD_CMD_LAST
};

/* DCC table DMA and calendar channel error code */
enum {
    DMA_ERR_CODE_NORMAL = 0x0,
    DMA_ERR_CODE_DBUS_SLV_ERR = 0x1,
    DMA_ERR_CODE_DBUS_DEC_ERR = 0x2,
    DMA_ERR_CODE_PCIE_ERR = 0x4,
    DMA_ERR_CODE_BUF_ECC = 0x8,
    DMA_ERR_CODE_LAST
};

enum {
    DMA_D2D_ERR_CODE_NORMAL = 0x0,
    DMA_D2D_ERR_CODE_DBUS_SLV_SRC_ERR = 0x1,
    DMA_D2D_ERR_CODE_DBUS_DEC_SRC_ERR = 0x2,
    DMA_D2D_ERR_CODE_DBUS_SLV_DST_ERR = 0x4,
    DMA_D2D_ERR_CODE_DBUS_DEC_DST_ERR = 0x8,
    DMA_D2D_ERR_CODE_LAST
};

/* DCC CLD task status*/
typedef enum {
    DCC_CLD_STAT_IDLE = 0x00,
    DCC_CLD_STAT_BUSY = 0x01,
    DCC_CLD_STAT_RDY = 0x02,
    DCC_CLD_STAT_ERR = 0x05,
    DCC_CLD_STAT_PAUSE = 0xFE,
    DCC_CLD_STAT_LAST
} DCC_CLD_STAT_T;

/* DCC CLD task operating mode */
typedef enum {
    DCC_CLD_OP_MODE_FUPD = 0,
    DCC_CLD_OP_MODE_POLL,
    DCC_CLD_OP_MODE_INTR,
    DCC_CLD_OP_MODE_LAST
} DCC_CLD_OP_MODE_T;

typedef enum {
    DCC_DMA_TYPE_TBL_DMA_H2D = 0x0,
    DCC_DMA_TYPE_TBL_DMA_D2H,
    DCC_DMA_TYPE_TBL_DMA_D2D,
    DCC_DMA_TYPE_CLD_DMA,
    DCC_DMA_TYPE_LAST
} DCC_DMA_TYPE_T;

typedef enum {
    DCC_DMA_D2D_DIR_DESCENDING = 0x0,
    DCC_DMA_D2D_DIR_ASCENDING,
    DCC_DMA_D2D_DIR_LAST
} DCC_DMA_D2D_DIR_T;

typedef CLX_ERROR_NO_T (*DCC_CLD_FUNC_T)(const UI32_T unit, const UI32_T task_id);

/* DCC DMA task structure */
typedef struct DCC_TASK_S {
    UI32_T inst_idx;           /* instance index.           */
    UI32_T subinst_idx;        /* sub instance index.       */
    UI32_T table_id;           /* table ID.                 */
    UI32_T entry_idx;          /* entry index in table.     */
    UI32_T addr;               /* device address            */
    void *ptr_buf;             /* ptr to host address       */
    UI32_T entry_len;          /* length of an entry (byte) */
    UI32_T entry_num;          /* number of entries         */
    BOOL_T d_to_h;             /* device to host            */
    DCC_CLD_FUNC_T callback;   /* callback function for INT */
    DCC_CLD_OP_MODE_T op_mode; /* operation mode            */
} DCC_CLD_TASK_T;

/* DCC DMA channel status*/
enum {
    DMA_STAT_IDLE = 0x0,
    DMA_STAT_BSY = 0x1,
    DMA_STAT_RDY = 0x2,
    DMA_STAT_ERR = 0x5,
    DMA_STAT_ABT = 0xA,
    DMA_STAT_LAST
};

/* DCC CMD channel status*/
enum {
    CMD_STAT_IDLE = 0x0,
    CMD_STAT_BSY = 0x1,
    CMD_STAT_RDY = 0x2,
    CMD_STAT_ERR = 0x5,
    CMD_STAT_ABT = 0xA,
    CMD_STAT_LAST
};

typedef enum {
    DCC_DMA_CMD_UCP_SET = 0x0,
    DCC_DMA_CMD_TCAM_ECC_INIT,
    DCC_DMA_CMD_POLL_TCAM_SCAN_DONE,
    DCC_DMA_CMD_TRIGGER_TCAM_SCAN,
    DCC_DMA_CMD_ENABLE_TCAM_SCAN,
    DCC_DMA_CMD_LAST
} DCC_DMA_CMD_T;

/**
 * @brief dcc_dma_showDmaChannelInfo() is a function to display DCC DMA channel information.
 *
 * @param [in]     unit    - The specified unit number.
 */
void
dcc_dma_showDmaChannelInfo(const UI32_T unit);

/**
 * @brief dcc_dma_writeTbl() is a function to move table data from host to device.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_src_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred
 * @param [in]     entry_num      - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully write data from host to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to write data from host to device
 */
CLX_ERROR_NO_T
dcc_dma_writeTbl(const UI32_T unit,
                 void *ptr_src_buf,
                 const UI32_T addr,
                 const UI32_T entry_len,
                 const UI32_T entry_num);

/**
 * @brief dcc_dma_readTbl() is a function to move table data from device to host.
 *
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_dst_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred
 * @param [in]     entry_num      - Number of entries are going to be transferred
 * @return         CLX_E_OK               - Successfully read data from device to host
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to host
 */
CLX_ERROR_NO_T
dcc_dma_readTbl(const UI32_T unit,
                void *ptr_dst_buf,
                const UI32_T addr,
                const UI32_T entry_len,
                const UI32_T entry_num);

/**
 * @brief dcc_dma_copyTbl() is a function to copy table data from device to device.
 *
 * @param [in]     unit         - The specified unit number.
 * @param [in]     src_addr     - The start address of source device table address for DMA transfer.
 * This address should be a valid address inside chip.
 * @param [in]     dst_addr     - The start address of destination device table address for DMA
 * transfer.
 * @param [in]     dir          - The direction order for copy data.
 * @param [in]     entry_len    - The length of an entry is going to be transferred.
 * @param [in]     entry_num    - Number of entries are going to be transferred.
 * @return         CLX_E_OK               - Successfully copy data from device to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to device
 */
CLX_ERROR_NO_T
dcc_dma_copyTbl(const UI32_T unit,
                const UI32_T src_addr,
                const UI32_T dst_addr,
                const DCC_DMA_D2D_DIR_T dir,
                const UI32_T entry_len,
                const UI32_T entry_num);

/**
 * @brief dcc_dma_copyTcam() is a function to copy tcam table data from device to device.
 *
 * @param [in]     unit         - The specified unit number.
 * @param [in]     src_addr     - The start address of source device table address for DMA transfer.
 * This address should be a valid address inside chip.
 * @param [in]     dst_addr     - The start address of destination device table address for DMA
 * transfer.
 * @param [in]     dir          - The direction order for copy data.
 * @param [in]     entry_len    - The length of an entry is going to be transferred.
 * @param [in]     entry_num    - Number of entries are going to be transferred.
 * @return         CLX_E_OK               - Successfully copy data from device to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to device
 */
CLX_ERROR_NO_T
dcc_dma_copyTcam(const UI32_T unit,
                 const UI32_T src_addr,
                 const UI32_T dst_addr,
                 const DCC_DMA_D2D_DIR_T dir,
                 const UI32_T entry_len,
                 const UI32_T entry_num);

/**
 * @brief dcc_dma_showCldChannelInfo() is a function to display DCC CLD DMA channel information.
 *
 * @param [in]     unit    - The specified unit number.
 */

void
dcc_dma_showCldChannelInfo(const UI32_T unit);

/**
 * @brief dcc_dma_setCldMode() is a function to set DCC CLD DMA uP operation mode
 *
 * @param [in]     unit        - The specified unit number.
 * @param [in]     period      - Significant part of each task interval (1 ~ 65535)
 * @param [in]     exponent    - Exponent part of each task interval (2^exponent, 0 ~ 15)
 *                               -- The exact time interval is period
 * @param [in]     enable      - Enable CLD DMA
 * @param [in]     repeat      - Enable automatic repeat after all tasks complete
 * @return         CLX_E_OK               - Set uP operation mode successfully
 * @return         CLX_E_BAD_PARAMETER    - Invalid exponent parameter
 * @return         CLX_E_OTHERS           - Fail to set uP operation mode
 */

CLX_ERROR_NO_T
dcc_dma_setCldMode(const UI32_T unit,
                   const UI32_T period,
                   const UI32_T exponent,
                   const BOOL_T enable,
                   const BOOL_T repeat);

/*
 * PURPOSE:
 *      dcc_dma_addCldTask() is a function to add a calendar DMA task
 *
 * INPUT:
 *      unit                  -- The specified unit number
 *      ptr_task              -- Pointer to detailed task info
 * OUTPUT:
 *      ptr_task_id           -- task_id assigned to the new task
 * RETURN:
 *      CLX_E_OK              -- Task is successfully added into system
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_TABLE_FULL      -- Task table full, cannot add a new task
 *      CLX_E_OTHERS          -- Fail to add task into system due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_addCldTask(const UI32_T unit, const DCC_CLD_TASK_T *ptr_task, UI32_T *ptr_task_id);

/*
 * PURPOSE:
 *      dcc_dma_delCldTask() is a function to delete a calendar DMA task
 *
 * INPUT:
 *      unit                  -- The specified unit number
 *      task_id               -- The task to be deleted
 * OUTPUT:
 *       None
 * RETURN:
 *      CLX_E_OK              -- Task is successfully deleted from system
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_ENTRY_NOT_FOUND -- Task associated with the task_id does not exist
 *      CLX_E_OTHERS          -- Fail to delete task from system due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_delCldTask(const UI32_T unit, const UI32_T task_id);

/**
 * @brief dcc_dma_setCldTaskStatus() is a function to set a task status to the idle/pause state
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     task_id    - The task to be set status
 * @param [in]     state      - The new state of the task, valid settings are
 *                              1. DCC_CLD_STAT_IDLE
 *                              2. DCC_CLD_STAT_PAUSE
 * @return         CLX_E_OK                 - Task status is successfully set
 * @return         CLX_E_BAD_PARAMETER      - Input parameter has error configuration or value
 * @return         CLX_E_ENTRY_NOT_FOUND    - Task associated with the task_id doesn't exist
 * @return         CLX_E_OTHERS             - Fail to set task state due to internal error
 */

CLX_ERROR_NO_T
dcc_dma_setCldTaskStatus(const UI32_T unit, const UI32_T task_id, const DCC_CLD_STAT_T state);

/**
 * @brief dcc_dma_getCldTaskStatus() is a function to get a task's current status
 *
 * @param [in]     unit          - The specified unit number.
 * @param [in]     task_id       - The task to be queried
 * @param [out]    ptr_status    - Status of the task under study
 * @return         CLX_E_OK                 - Task status is successfully obtained
 * @return         CLX_E_BAD_PARAMETER      - Input parameter has error configuration or value
 * @return         CLX_E_ENTRY_NOT_FOUND    - Task associated with the task_id doesn't exist
 * @return         CLX_E_OTHERS             - Fail to read task status due to internal error
 */

CLX_ERROR_NO_T
dcc_dma_getCldTaskStatus(const UI32_T unit, const UI32_T task_id, DCC_CLD_STAT_T *ptr_status);

/**
 * @brief dcc_dma_showCldTaskInfo() is a function to show DCC CLD DMA task information.
 *
 * @param [in]     unit       - The specified unit number.
 * @param [in]     task_id    - task_id of the task under study
 */

CLX_ERROR_NO_T
dcc_dma_showCldTaskInfo(const UI32_T unit, const UI32_T task_id);

/**
 * @brief dcc_dma_txCmd() is a function to send custom command to DCE uP
 *
 * @param [in]     unit        - The specified unit number
 * @param [in]     cmd         - Custom command ID
 * @param [in]     ptr_data    - Pointer for the user data sent to DCE uP
 * @param [in]     data_len    - Valid word count in ptr_data
 * @return         CLX_E_OK    - Handle the command successfully
 */
CLX_ERROR_NO_T
dcc_dma_txCmd(const UI32_T unit,
              const DCC_DMA_CMD_T cmd,
              UI32_T *ptr_data,
              const UI32_T data_len); /* in word */
#endif                                /* END of DCC_H*/
