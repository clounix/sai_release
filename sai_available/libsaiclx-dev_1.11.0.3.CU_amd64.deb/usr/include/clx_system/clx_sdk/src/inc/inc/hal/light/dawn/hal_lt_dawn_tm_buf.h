/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_dawn_tm_buf.h
 * PURPOSE:
 *      It provides hal traffic management module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_LT_DAWN_TM_BUF_H
#define HAL_LT_DAWN_TM_BUF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>
#include <hal/hal.h>
#include <osal/osal.h>
#include <hal/hal_tbl.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_LT_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_GREEN  (32)
#define HAL_LT_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_RED    (32)
#define HAL_LT_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_YELLOW (32)
#define HAL_LT_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_GREEN      (32)
#define HAL_LT_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_RED        (32)
#define HAL_LT_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_YELLOW     (32)
#define HAL_LT_DAWN_MAX_NUM_OF_TM_DCTCP_THD_G_PROFILE                (32)

#define HAL_LT_DAWN_TM_WRED_PROFILE_CONFIG_MAX_THRESHOLD_WIDTH (16)
#define HAL_LT_DAWN_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH      (10)
#define HAL_LT_DAWN_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH      (6)

#define HAL_LT_DAWN_TM_BUF_FP_PORT_MAX_NUM (128)
#define HAL_LT_DAWN_TM_BUF_FC_SC           (7)

#define HAL_LT_DAWN_TM_ADM_AIP_PLANE_NUM \
    (HAL_LT_DAWN_TM_ADM_AIP_PLANE1_IDX - HAL_LT_DAWN_TM_ADM_AIP_PLANE0_IDX)
#define HAL_LT_DAWN_TM_ADM_AIP_PLANE0_IDX (0)
#define HAL_LT_DAWN_TM_ADM_AIP_PLANE1_IDX (36)
#define HAL_LT_DAWN_TM_ADM_AIP_PLANE2_IDX (72)
#define HAL_LT_DAWN_TM_ADM_AIP_PLANE3_IDX (108)

#define HAL_LT_DAWN_TM_ENB_FP_NUM      (36)
#define HAL_LT_DAWN_TM_ADM_FP_FP_ENTRY (144)

#define HAL_LT_DAWN_TM_IA_FP_NUM  (32)
#define HAL_LT_DAWN_TM_REP_NUM    (2)
#define HAL_LT_DAWN_TM_IA_CPI_NUM (1)
#define HAL_LT_DAWN_TM_IA_CPU_NUM (1)
#define HAL_LT_DAWN_TM_IA_NON_FP_NUM \
    (HAL_LT_DAWN_TM_REP_NUM + HAL_LT_DAWN_TM_IA_CPI_NUM + HAL_LT_DAWN_TM_IA_CPU_NUM)
#define HAL_LT_DAWN_TM_EA_FP_NUM            (17)
#define HAL_LT_DAWN_TM_MEA_FP_NUM           (HAL_LT_DAWN_TM_DEB_FP_NUM + HAL_LT_DAWN_TM_REP_NUM)
#define HAL_LT_DAWN_TM_DEB_FP_NUM           (32)
#define HAL_LT_DAWN_TM_AQM_FP_BIN_NUM       (64)
#define HAL_LT_DAWN_TM_IOS_SLC_FP_PLANE_NUM (16)

#define HAL_LT_DAWN_TM_IOS_SLC_CPI_IDX (1)

#define HAL_LT_DAWN_TM_IA_RECIR_P_IDX_0 (HAL_LT_DAWN_TM_IA_FP_NUM)
#define HAL_LT_DAWN_TM_IA_RECIR_P_IDX_1 (HAL_LT_DAWN_TM_IA_FP_NUM + 1)
#define HAL_LT_DAWN_TM_IA_CPI_P_IDX     (HAL_LT_DAWN_TM_IA_FP_NUM + HAL_LT_DAWN_TM_REP_NUM)
#define HAL_LT_DAWN_TM_IA_CPU_P_IDX \
    (HAL_LT_DAWN_TM_IA_FP_NUM + HAL_LT_DAWN_TM_REP_NUM + HAL_LT_DAWN_TM_IA_CPI_NUM)

#define HAL_LT_DAWN_TM_IA_CPU_P_SUB_INST_IDX (3)
#define HAL_LT_DAWN_TM_IA_CPU_P_INST_IDX     (HAL_LT_DAWN_TM_IA_P_PLANE_NUM - 1)

#define HAL_LT_DAWN_TM_ADM_P_SUB_INST_IDX (HAL_LT_DAWN_TM_ADM_SLICE_NUM - 1)
#define HAL_LT_DAWN_TM_ADM_P_INST_IDX     (HAL_LT_DAWN_TM_ADM_PLANE_NUM - 1)

#define HAL_LT_DAWN_TM_IA_P_PLANE_NUM  (1)
#define HAL_LT_DAWN_TM_IA_P_SLICE_NUM  (4)
#define HAL_LT_DAWN_TM_ADM_SLICE_NUM   (1)
#define HAL_LT_DAWN_TM_ADM_PLANE_NUM   (1)
#define HAL_LT_DAWN_TM_AQM_PLANE_NUM   (1)
#define HAL_LT_DAWN_TM_AQM_SLICE_NUM   (1)
#define HAL_LT_DAWN_TM_IOS_PLANE_NUM   (2)
#define HAL_LT_DAWN_TM_IOS_SLICE_NUM   (1)
#define HAL_LT_DAWN_TM_DEB_PLANE_NUM   (2)
#define HAL_LT_DAWN_TM_DEB_SLICE_NUM   (1)
#define HAL_LT_DAWN_TM_MIA_SLICE_NUM   (2)
#define HAL_LT_DAWN_TM_MEA_P_SLICE_NUM (2)
#define HAL_LT_DAWN_TM_MEA_G_SLICE_NUM (1)
#define HAL_LT_DAWN_TM_MEA_G_GROUP_NUM (4)

#define HAL_LT_DAWN_TM_MAX_PFC_SC_NUM (2)

#define HAL_LT_DAWN_TM_MEA_P_ENTRY_NUM \
    (HAL_LT_DAWN_TM_MEA_FP_NUM * (HAL_LT_DAWN_TM_MULTICAST_QUEUE_NUM))

#define HAL_LT_DAWN_TM_EA_RECIR_P_IDX_0 (HAL_LT_DAWN_TM_EA_FP_NUM - HAL_LT_DAWN_TM_REP_NUM)
#define HAL_LT_DAWN_TM_EA_RECIR_P_IDX_1 (HAL_LT_DAWN_TM_EA_FP_NUM - HAL_LT_DAWN_TM_REP_NUM + 1)
#define HAL_LT_DAWN_TM_EA_RECIR_S_IDX_1 (1)
#define HAL_LT_DAWN_TM_EA_RECIR_S_IDX_3 (3)

#define HAL_LT_DAWN_TM_IOS_IA_SC2PCP_NUM (128)
#define HAL_LT_DAWN_TM_PCP_NUM           (8)

#define HAL_LT_DAWN_TM_EA_PLANE_FP_NUM (HAL_LT_DAWN_TM_BUF_FP_PORT_MAX_NUM / 2)

#define HAL_LT_DAWN_TM_EA_CMQ_CPU_NUM (HAL_LT_DAWN_TM_CPU_QUEUE_NUM)
#define HAL_LT_DAWN_TM_EA_CMQ_CPI_NUM (HAL_LT_DAWN_TM_CPI_QUEUE_NUM)
#define HAL_LT_DAWN_TM_EA_CMQ_MIR_NUM (8)

#define HAL_LT_DAWN_TM_EA_CMQ_OFFSET_CPU (0)
#define HAL_LT_DAWN_TM_EA_CMQ_OFFSET_CPI0 \
    (HAL_LT_DAWN_TM_EA_CMQ_OFFSET_CPU + HAL_LT_DAWN_TM_EA_CMQ_CPU_NUM)
#define HAL_LT_DAWN_TM_EA_CMQ_OFFSET_CPI1 \
    (HAL_LT_DAWN_TM_EA_CMQ_OFFSET_CPI0 + HAL_LT_DAWN_TM_EA_CMQ_CPI_NUM)
#define HAL_LT_DAWN_TM_EA_CMQ_OFFSET_IMIR \
    (HAL_LT_DAWN_TM_EA_CMQ_OFFSET_CPI1 + HAL_LT_DAWN_TM_EA_CMQ_CPI_NUM)
#define HAL_LT_DAWN_TM_EA_CMQ_OFFSET_EMIR \
    (HAL_LT_DAWN_TM_EA_CMQ_OFFSET_IMIR + HAL_LT_DAWN_TM_EA_CMQ_MIR_NUM)

#define HAL_LT_DAWN_TM_ADM_SC_NUM (8)
#define HAL_LT_DAWN_TM_EA_Q_NUM \
    (HAL_LT_DAWN_TM_UNICAST_QUEUE_NUM + HAL_LT_DAWN_TM_MULTICAST_QUEUE_NUM)

#define HAL_LT_DAWN_TM_SC_BITMAP         (0xFF)
#define HAL_LT_DAWN_TM_IA_HGAP_EN_BITMAP (HAL_LT_DAWN_TM_SC_BITMAP)

#define HAL_LT_DAWN_TM_IA_MAX_DYNAMIC_TH    (128)
#define HAL_LT_DAWN_TM_EA_MAX_DYNAMIC_TH    (16)
#define HAL_LT_DAWN_TM_EA_MC_MAX_DYNAMIC_TH (2)

#define HAL_LT_DAWN_TM_IA_XON_TH_100G (350)
#define HAL_LT_DAWN_TM_IA_XON_TH_50G  (236)
#define HAL_LT_DAWN_TM_IA_XON_TH_40G  (212)
#define HAL_LT_DAWN_TM_IA_XON_TH_25G  (184)
#define HAL_LT_DAWN_TM_IA_XON_TH_10G  (144)

#define HAL_LT_DAWN_TM_CELL_SIZE (224)

#define HAL_LT_DAWN_TM_MTU             ((22 * 1024 + 9) / 10)
#define HAL_LT_DAWN_TM_GAP             (2 * HAL_LT_DAWN_TM_MTU / HAL_LT_DAWN_TM_CELL_SIZE)
#define HAL_LT_DAWN_TM_IA_XOFF_TH_100G (HAL_LT_DAWN_TM_IA_XON_TH_100G + HAL_LT_DAWN_TM_GAP)
#define HAL_LT_DAWN_TM_IA_XOFF_TH_50G  (HAL_LT_DAWN_TM_IA_XON_TH_50G + HAL_LT_DAWN_TM_GAP)
#define HAL_LT_DAWN_TM_IA_XOFF_TH_40G  (HAL_LT_DAWN_TM_IA_XON_TH_40G + HAL_LT_DAWN_TM_GAP)
#define HAL_LT_DAWN_TM_IA_XOFF_TH_25G  (HAL_LT_DAWN_TM_IA_XON_TH_25G + HAL_LT_DAWN_TM_GAP)
#define HAL_LT_DAWN_TM_IA_XOFF_TH_10G  (HAL_LT_DAWN_TM_IA_XON_TH_10G + HAL_LT_DAWN_TM_GAP)

#define HAL_LT_DAWN_TM_IA_MAX_TH_100G \
    (HAL_LT_DAWN_TM_IA_XOFF_TH_100G - HAL_LT_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)
#define HAL_LT_DAWN_TM_IA_MAX_TH_50G \
    (HAL_LT_DAWN_TM_IA_XOFF_TH_50G - HAL_LT_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)
#define HAL_LT_DAWN_TM_IA_MAX_TH_40G \
    (HAL_LT_DAWN_TM_IA_XOFF_TH_40G - HAL_LT_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)
#define HAL_LT_DAWN_TM_IA_MAX_TH_25G \
    (HAL_LT_DAWN_TM_IA_XOFF_TH_25G - HAL_LT_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)
#define HAL_LT_DAWN_TM_IA_MAX_TH_10G \
    (HAL_LT_DAWN_TM_IA_XOFF_TH_10G - HAL_LT_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)

#define HAL_LT_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF (0)
#define HAL_LT_DAWN_TM_IA_G_MIN_RESERV_POOL \
    (2 * HAL_LT_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF * HAL_LT_DAWN_TM_BUF_FP_PORT_MAX_NUM)

#define HAL_LT_DAWN_TM_MCA_UNIT (2)
#define HAL_LT_DAWN_TM_IEA_UNIT (1)

#define HAL_LT_DAWN_TM_IA_G_CP_POOL     (0)
#define HAL_LT_DAWN_TM_IA_G_CP_ALLOCATE (26)

#define HAL_LT_DAWN_TM_EA_CMQ_NUM  (80)
#define HAL_LT_DAWN_TM_EA_CMQ_TH   (46)
#define HAL_LT_DAWN_TM_EA_G_CM_TH  (1024)
#define HAL_LT_DAWN_TM_EA_G_STR_TH (128)
#define HAL_LT_DAWN_TM_EA_G_CM_POOL                                                     \
    (HAL_LT_DAWN_TM_EA_CMQ_NUM * HAL_LT_DAWN_TM_EA_CMQ_TH + HAL_LT_DAWN_TM_EA_G_CM_TH + \
     HAL_LT_DAWN_TM_EA_G_STR_TH)

#define HAL_LT_DAWN_TM_IEA_G_MSC_MIN_TH (6000)

#define HAL_LT_DAWN_TM_PERCNTAGE         (100)
#define HAL_LT_DAWN_TM_IEA_Q_MIN_CEILING (0xFFFF)
#define HAL_LT_DAWN_TM_IEA_Q_MIN         (16)
#define HAL_LT_DAWN_TM_EA_Q_MIN          (16)
#define HAL_LT_DAWN_TM_IEA_Q_MIN_100G    (HAL_LT_DAWN_TM_IEA_Q_MIN)
#define HAL_LT_DAWN_TM_EA_Q_MIN_100G     (50)

#define HAL_LT_DAWN_TM_G_MARGIN              (22856)
#define HAL_LT_DAWN_TM_EA_G_MIN_RESERV_POOL  (0)
#define HAL_LT_DAWN_TM_IEA_G_MIN_RESERV_POOL (0)

#define HAL_LT_DAWN_TM_EA_GS_MC_POOL (11200)

#define HAL_LT_DAWN_TM_MIA_MCB_POOL     (32 * 1024)
#define HAL_LT_DAWN_TM_MIA_MCB_Q_MIN_TH (HAL_LT_DAWN_TM_IEA_Q_MIN + 50)
#define HAL_LT_DAWN_TM_MIA_MCB_G_MIN_TH \
    (HAL_LT_DAWN_TM_MIA_MCB_Q_MIN_TH * HAL_LT_DAWN_TM_EA_PLANE_FP_NUM * 8 / 2)
#define HAL_LT_DAWN_TM_MIA_MCB_G_DROP_ON \
    (HAL_LT_DAWN_TM_MIA_MCB_POOL - HAL_LT_DAWN_TM_MIA_MCB_G_MIN_TH)

#define HAL_LT_DAWN_TM_MIA_CPB_POOL     (8 * 1024)
#define HAL_LT_DAWN_TM_MIA_CPB_Q_MIN_TH (100)
#define HAL_LT_DAWN_TM_MIA_CPB_G_MIN_TH (HAL_LT_DAWN_TM_MIA_CPB_Q_MIN_TH * 8)
#define HAL_LT_DAWN_TM_MIA_CPB_G_DROP_ON \
    (HAL_LT_DAWN_TM_MIA_CPB_POOL - HAL_LT_DAWN_TM_MIA_CPB_G_MIN_TH)
#define HAL_LT_DAWN_TM_MIA_CPB_Q_MAX_TH (HAL_LT_DAWN_TM_MIA_CPB_G_DROP_ON)

#define HAL_LT_DAWN_TM_MIA_MRB_POOL     (8 * 1024)
#define HAL_LT_DAWN_TM_MIA_MRB_Q_MIN_TH (100)
#define HAL_LT_DAWN_TM_MIA_MRB_G_MIN_TH (HAL_LT_DAWN_TM_MIA_MRB_Q_MIN_TH * 2)
#define HAL_LT_DAWN_TM_MIA_MRB_G_DROP_ON \
    (HAL_LT_DAWN_TM_MIA_MRB_POOL - HAL_LT_DAWN_TM_MIA_MRB_G_MIN_TH)
#define HAL_LT_DAWN_TM_MIA_MRB_Q_MAX_TH (HAL_LT_DAWN_TM_MIA_MRB_G_DROP_ON)

#define HAL_LT_DAWN_TM_MEA_CM_POOL     (152 * 1024 / 10)
#define HAL_LT_DAWN_TM_MEA_CM_Q_MIN_TH (300)
#define HAL_LT_DAWN_TM_MEA_CM_G_MIN_TH (HAL_LT_DAWN_TM_MEA_CM_Q_MIN_TH * 24)
#define HAL_LT_DAWN_TM_MEA_CM_G_DROP_ON \
    (HAL_LT_DAWN_TM_MEA_CM_POOL - HAL_LT_DAWN_TM_MEA_CM_G_MIN_TH)
#define HAL_LT_DAWN_TM_MEA_CM_Q_MAX_TH (HAL_LT_DAWN_TM_MEA_CM_G_DROP_ON)

#define HAL_LT_DAWN_TM_MEA_MCQ_POOL     (64 * 1024)
#define HAL_LT_DAWN_TM_MEA_MCQ_Q_MIN_TH (300)
#define HAL_LT_DAWN_TM_MEA_MCQ_G_MIN_TH \
    (HAL_LT_DAWN_TM_MEA_MCQ_Q_MIN_TH * HAL_LT_DAWN_TM_EA_PLANE_FP_NUM * 8 / 4)
#define HAL_LT_DAWN_TM_MEA_MCQ_G_DROP_ON \
    (HAL_LT_DAWN_TM_MEA_MCQ_POOL - HAL_LT_DAWN_TM_MEA_CM_POOL - HAL_LT_DAWN_TM_MEA_MCQ_G_MIN_TH)

/* IA per port */
#define HAL_LT_DAWN_TM_IA_PORT_MIN_THD_DEF (HAL_LT_DAWN_TM_IA_PCP_MIN_THD_PFC_DEF)

/* max value, Limit by HW design. */
#define HAL_LT_DAWN_TM_IA_MAX_DYNAMIC_VALUE        (12)
#define HAL_LT_DAWN_TM_IA_MAX_DYNAMIC_VALUE_OFFSET (0)
#define HAL_LT_DAWN_TM_EA_MAX_DYNAMIC_VALUE        (12)
#define HAL_LT_DAWN_TM_EA_MAX_DYNAMIC_VALUE_OFFSET (0)

#define HAL_LT_DAWN_TM_WRED_PROFILE_SW_NUM (HAL_LT_DAWN_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_GREEN)

#define HAL_LT_DAWN_TM_DCTCP_PROFILE_SW_NUM (HAL_LT_DAWN_MAX_NUM_OF_TM_DCTCP_THD_G_PROFILE)

/* WRED SMDP */
#define HAL_LT_DAWN_TM_UI16_WIDTH     (16)
#define HAL_LT_DAWN_TM_UI16_MAX_VALUE ((1U << (HAL_LT_DAWN_TM_UI16_WIDTH)) - 1)
#define HAL_LT_DAWN_TM_WRED_MAX_EXPONENT_SIGN_BIT \
    (1U << ((HAL_LT_DAWN_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH) - 1))
#define HAL_LT_DAWN_TM_WRED_MAX_EXPONENT_VALUE \
    ((1U << ((HAL_LT_DAWN_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH) - 1)) - 1)
#define HAL_LT_DAWN_TM_WRED_MAX_MANTISSA_VALUE \
    ((1U << (HAL_LT_DAWN_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH)) - 1)
#define HAL_LT_DAWN_TM_UI16_TO_MANTISSA_SHIFT \
    (HAL_LT_DAWN_TM_UI16_WIDTH - (HAL_LT_DAWN_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH))

#define HAL_LT_DAWN_TM_WRED_PROFILE_MAX_DROP_RATE (100)
#define HAL_LT_DAWN_TM_WRED_Q_WEIGHT_VALUE_SW_MAX (10000)
/* weight min = 1/2^HAL_LT_DAWN_TM_WRED_Q_WEIGHT_VALUE_HW_MAX */
#define HAL_LT_DAWN_TM_WRED_Q_WEIGHT_VALUE_HW_MAX (7)

#define HAL_LT_DAWN_TM_WRED_PROFILE_ID_MAX  (HAL_LT_DAWN_TM_WRED_PROFILE_SW_NUM - 1)
#define HAL_LT_DAWN_TM_DCTCP_PROFILE_ID_MAX (HAL_LT_DAWN_TM_DCTCP_PROFILE_SW_NUM - 1)

#define HAL_LT_DAWN_TM_WRED_PF_MAX_DROP (100)

/* DCTCP */
#define HAL_LT_DAWN_TM_DCTCP_PF_TH_G (0)
#define HAL_LT_DAWN_TM_DCTCP_PF_TH_Y (16)
#define HAL_LT_DAWN_TM_DCTCP_PF_TH_R (32)

typedef enum {
    HAL_LT_DAWN_TM_TYPE_ING = 0,
    HAL_LT_DAWN_TM_TYPE_EGR = 1,
    HAL_LT_DAWN_TM_TYPE_LAST
} HAL_LT_DAWN_TM_TYPE_T;

typedef enum {
    HAL_LT_DAWN_TM_EA_CMP_CPU = 0,
    HAL_LT_DAWN_TM_EA_CMP_CPI0 = 1,
    HAL_LT_DAWN_TM_EA_CMP_CPI1 = 2,
    HAL_LT_DAWN_TM_EA_CMP_IMIR = 3,
    HAL_LT_DAWN_TM_EA_CMP_EMIR = 4,
    HAL_LT_DAWN_TM_EA_CMP_LAST
} HAL_LT_DAWN_TM_EA_CMP_T;

typedef enum {
    HAL_LT_DAWN_TM_IA_P_FP = 0,
    HAL_LT_DAWN_TM_IA_P_CPI0 = 1,
    HAL_LT_DAWN_TM_IA_P_CPI1 = 2,
    HAL_LT_DAWN_TM_IA_P_IMIR = 3,
    HAL_LT_DAWN_TM_IA_P_EMIR = 4,
    HAL_LT_DAWN_TM_EA_P_LAST
} HAL_LT_DAWN_TM_IA_P_T;

typedef enum {
    HAL_LT_DAWN_TM_ADM_SC_TYPE_LOSSY = 0x0,
    HAL_LT_DAWN_TM_ADM_SC_TYPE_LOSSLESS = 0x2,
    HAL_LT_DAWN_TM_ADM_SC_TYPE_CTRL = 0x3,
    HAL_LT_DAWN_TM_ADM_SC_TYPE_LAST
} HAL_LT_DAWN_TM_ADM_SC_TYPE_T;

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_LT_DAWN_TM_HANDLER_ID_GET(handler, id)                            \
    do {                                                                      \
        (id) = ((handler) & ((1U << HAL_LT_DAWN_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_LT_DAWN_TM_BUF_RELEASE_NONE = 0,
    HAL_LT_DAWN_TM_BUF_RELEASE_SEMAPHORE = (1U << 0),
    HAL_LT_DAWN_TM_BUF_RELEASE_RESOURCE_1 = (1U << 1),
    HAL_LT_DAWN_TM_BUF_RELEASE_RESOURCE_2 = (1U << 2),
    HAL_LT_DAWN_TM_BUF_RELEASE_LAST = (1U << 3)
} HAL_LT_DAWN_TM_BUF_RELEASE_ACTION_T;

/* HAL layer API structure */
typedef struct HAL_LT_DAWN_TM_WRED_ENTRY_HW_S {
    UI32_T hw_min;
    UI32_T hw_max;
    UI32_T hw_mantissa;
    UI32_T hw_exponent;
} HAL_LT_DAWN_TM_WRED_ENTRY_HW_T;

typedef struct HAL_LT_DAWN_TM_DCTCP_PROFILE_HW_S {
    UI32_T hw_threshold[CLX_COLOR_LAST];
} HAL_LT_DAWN_TM_DCTCP_PROFILE_HW_T;

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The function is used to init TM buffer management HW & SW DB
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_initRsrc(const UI32_T unit);

/**
 * @brief The function is used to deinit TM buffer management HW & SW DB
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_deinitRsrc(const UI32_T unit);

/**
 * @brief The function is used to init TM buffer management configuration
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_initCfg(const UI32_T unit);

/**
 * @brief The function is used to deinit TM buffer management configuration
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_deinitCfg(const UI32_T unit);

/**
 * @brief The function is used to set flow control mode.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     mode    - flow control mode(lossy, FC, PFC)
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setFlowCtrlMode(const UI32_T unit, const UI32_T port, const HAL_TM_FC_T mode);

/**
 * @brief The function is used to get flow control mode.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port                - Physical port id.
 * @param [in]     pcp                 - (Optional) PFC pcp
 * @param [out]    ptr_mode            - flow control mode(lossy, FC, PFC)
 * @param [out]    ptr_pfc_tx_state    - (Optional) PFC TX state
 * @param [out]    ptr_pfc_rx_state    - (Optional) PFC RX state
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getFlowCtrlMode(const UI32_T unit,
                                   const UI32_T port,
                                   const UI32_T pcp,
                                   HAL_TM_FC_T *ptr_mode,
                                   BOOL_T *ptr_pfc_tx_state,
                                   BOOL_T *ptr_pfc_rx_state);

/**
 * @brief The function is used to set ingress buffer per pcp thresholds.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     pcp          - pcp value.
 * @param [in]     ptr_entry    - the entry which the user want to set.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setIgrBufPcpThreshold(const UI32_T unit,
                                         const UI32_T port,
                                         const UI32_T pcp,
                                         const CLX_TM_BUF_THRESHOLD_T *ptr_entry);

/**
 * @brief The function is used to update the Queue status with action for non-block used.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [in]     dir       - Ingress/egress/ingress and egress
 * @param [in]     status    - action (HAL_TM_PS_ACTIVED, HAL_TM_PS_NO_ACTIVED)
 * @param [in]     all_queue - 1: all queues, 0:1 queue.
 * @param [in]     handler   - queue handler
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_updateQueueState(const UI32_T unit,
                                    const UI32_T port,
                                    const CLX_DIR_T dir,
                                    const HAL_TM_SC_T status,
                                    const UI32_T all_queue,
                                    const CLX_TM_HANDLER_T handler);

/**
 * @brief The function is used to get ingress buffer per pcp thresholds.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     pcp          - pcp value.
 * @param [out]    ptr_entry    - the entry which the user want to get.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufPcpThreshold(const UI32_T unit,
                                         const UI32_T port,
                                         const UI32_T pcp,
                                         CLX_TM_BUF_THRESHOLD_T *ptr_entry);

/**
 * @brief The function is used to set ingress buffer per port thresholds.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     ptr_entry    - the entry which the user want to set.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setIgrBufPortThreshold(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_TM_BUF_THRESHOLD_T *ptr_entry);

/**
 * @brief The function is used to get ingress buffer per port thresholds.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [out]    ptr_entry    - the entry which the user want to get.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufPortThreshold(const UI32_T unit,
                                          const UI32_T port,
                                          CLX_TM_BUF_THRESHOLD_T *ptr_entry);

/**
 * @brief The function is used to set orginal pcp remap to ingress buffer pcp
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [in]     org_pcp       - orginal pcp.
 * @param [in]     ingbuf_pcp    - ingress buffer pcp.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setIgrBufPcpRemap(const UI32_T unit,
                                     const UI32_T port,
                                     const UI32_T org_pcp,
                                     const UI32_T ingbuf_pcp);

/**
 * @brief The function is used to get orginal pcp remap to ingress buffer pcp
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Physical port id.
 * @param [in]     org_pcp           - orginal pcp.
 * @param [out]    ptr_ingbuf_pcp    - ingress buffer pcp.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufPcpRemap(const UI32_T unit,
                                     const UI32_T port,
                                     const UI32_T org_pcp,
                                     UI32_T *ptr_ingbuf_pcp);

/**
 * @brief The function is used to set egress buffer per queue thresholds.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     handler      - tm handler.
 * @param [in]     ptr_entry    - the entry which the user want to set.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setEgrBufQueueThreshold(const UI32_T unit,
                                           const UI32_T port,
                                           const CLX_TM_HANDLER_T handler,
                                           const CLX_TM_BUF_THRESHOLD_T *ptr_entry);

/**
 * @brief The function is used to get egress buffer per queue thresholds.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     handler      - tm handler.
 * @param [out]    ptr_entry    - the entry which the user want to get.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufQueueThreshold(const UI32_T unit,
                                           const UI32_T port,
                                           const CLX_TM_HANDLER_T handler,
                                           CLX_TM_BUF_THRESHOLD_T *ptr_entry);

/**
 * @brief The function is used to set egress buffer per port thresholds.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     ptr_entry    - the entry which the user want to set.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setEgrBufPortThreshold(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_TM_BUF_THRESHOLD_T *ptr_entry);

/**
 * @brief The function is used to get egress buffer per port thresholds.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [out]    ptr_entry    - the entry which the user want to get.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufPortThreshold(const UI32_T unit,
                                          const UI32_T port,
                                          CLX_TM_BUF_THRESHOLD_T *ptr_entry);

/**
 * @brief The function is used to set the pcp which received from PFC pause frame
 *        remap to egress queue.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     pfc_pcp    - The pcp which received from PFC pause frame.
 * @param [in]     handler    - Egress queue handler.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setEgrBufPfcPcpRemapQueue(const UI32_T unit,
                                             const UI32_T port,
                                             const UI32_T pfc_pcp,
                                             const CLX_TM_HANDLER_T handler);

/**
 * @brief The function is used to get the pcp which received from PFC pause frame
 *        remap to which egress queue.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [in]     pfc_pcp        - The pcp which received from PFC pause frame.
 * @param [out]    ptr_handler    - Egress queue handler.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufPfcPcpRemapQueue(const UI32_T unit,
                                             const UI32_T port,
                                             const UI32_T pfc_pcp,
                                             CLX_TM_HANDLER_T *ptr_handler);

/**
 * @brief The function is used to get egress buffer per port packet usage.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [out]    ptr_usage    - per queue usage.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufPortPktUsage(const UI32_T unit, const UI32_T port, UI32_T *ptr_usage);

/**
 * @brief The function is used to get egress buffer per queue usage.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     handler      - tm handler.
 * @param [out]    ptr_usage    - per queue usage.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufQueueUsage(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_TM_HANDLER_T handler,
                                       UI32_T *ptr_usage);

/**
 * @brief The function is used to set Ingress Buffer mirror headroom
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     threshold    - Ingress Buffer mirror headroom
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setIgrBufMirHrm(const UI32_T unit, const UI32_T threshold);

/**
 * @brief The function is used to get Ingress Buffer mirror headroom
 *
 * @param [in]     unit             - Device unit number.
 * @param [out]    ptr_threshold    - Ingress Buffer mirror headroom
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufMirHrm(const UI32_T unit, UI32_T *ptr_threshold);

/**
 * @brief The function is used to set Ingress Buffer SDN headroom
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     threshold    - Ingress Buffer SDN headroom
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setIgrBufSdnHrm(const UI32_T unit, const UI32_T threshold);

/**
 * @brief The function is used to get Ingress Buffer SDN headroom
 *
 * @param [in]     unit             - Device unit number.
 * @param [out]    ptr_threshold    - Ingress Buffer SDN headroom
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufSdnHrm(const UI32_T unit, UI32_T *ptr_threshold);

/**
 * @brief The function is used to set egress buffer control packet headroom
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     threshold    - egress buffer control packet headroom
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setEgrBufCtrlPktHrm(const UI32_T unit, const UI32_T threshold);

/**
 * @brief The function is used to get egress buffer control packet headroom
 *
 * @param [in]     unit             - Device unit number.
 * @param [out]    ptr_threshold    - egress buffer control packet headroom
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufCtrlPktHrm(const UI32_T unit, UI32_T *ptr_threshold);

/**
 * @brief The function is used to set queue TM congestion control mode.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     handler    - Egress queue handler.
 * @param [in]     mode       - TM congestion control mode
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setCngCtrl(const UI32_T unit,
                              const UI32_T port,
                              const CLX_TM_HANDLER_T handler,
                              const CLX_TM_CNG_T mode);

/**
 * @brief The function is used to get queue TM congestion control mode.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [in]     handler     - Egress queue handler.
 * @param [out]    ptr_mode    - TM congestion control mode
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getCngCtrl(const UI32_T unit,
                              const UI32_T port,
                              const CLX_TM_HANDLER_T handler,
                              CLX_TM_CNG_T *ptr_mode);

/**
 * @brief The function is used to set WRED drop force state
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [in]     handler        - TM handler
 * @param [in]     force_en       - WRED drop force enable/disable
 * @param [in]     force_value    - WRED drop force on/off
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setWredDropForce(const UI32_T unit,
                                    const UI32_T port,
                                    const CLX_TM_HANDLER_T handler,
                                    const BOOL_T force_en,
                                    const BOOL_T force_value);

/**
 * @brief The function is used to get WRED drop force state
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port id.
 * @param [in]     handler            - TM handler
 * @param [out]    ptr_force_en       - WRED drop force enable/disable
 * @param [out]    ptr_force_value    - WRED drop force on/off
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getWredDropForce(const UI32_T unit,
                                    const UI32_T port,
                                    const CLX_TM_HANDLER_T handler,
                                    BOOL_T *ptr_force_en,
                                    BOOL_T *ptr_force_value);

/**
 * @brief The function is used to set WRED mark force state
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [in]     handler        - TM handler
 * @param [in]     force_en       - WRED mark force enable/disable
 * @param [in]     force_value    - WRED mark force on/off
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setWredMarkForce(const UI32_T unit,
                                    const UI32_T port,
                                    const CLX_TM_HANDLER_T handler,
                                    const BOOL_T force_en,
                                    const BOOL_T force_value);

/**
 * @brief The function is used to get WRED mark force state
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port id.
 * @param [in]     handler            - TM handler
 * @param [out]    ptr_force_en       - WRED mark force enable/disable
 * @param [out]    ptr_force_value    - WRED mark force on/off
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getWredMarkForce(const UI32_T unit,
                                    const UI32_T port,
                                    const CLX_TM_HANDLER_T handler,
                                    BOOL_T *ptr_force_en,
                                    BOOL_T *ptr_force_value);

/**
 * @brief The function is used to set DCTCP force state
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [in]     handler        - TM handler
 * @param [in]     force_en       - DCTCP force enable/disable
 * @param [in]     force_value    - DCTCP force on/off
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setDctcpForce(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_TM_HANDLER_T handler,
                                 const BOOL_T force_en,
                                 const BOOL_T force_value);

/**
 * @brief The function is used to get DCTCP force state
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port id.
 * @param [in]     handler            - TM handler
 * @param [out]    ptr_force_en       - DCTCP force enable/disable
 * @param [out]    ptr_force_value    - DCTCP force on/off
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getDctcpForce(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_TM_HANDLER_T handler,
                                 BOOL_T *ptr_force_en,
                                 BOOL_T *ptr_force_value);

/**
 * @brief The function is used to get WRED profile
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     profile_id    - WRED profile ID.
 * @param [in]     type          - traffic type.
 * @param [in]     color         - traffic color.
 * @param [out]    ptr_entry     - WRED profile entry.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getWredProfile(const UI32_T unit,
                                  const UI32_T profile_id,
                                  const CLX_TM_TRAFFIC_TYPE_T type,
                                  const CLX_COLOR_T color,
                                  CLX_TM_WRED_ENTRY_T *ptr_entry);

/**
 * @brief The function is used to create WRED profile
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     profile_id    - WRED profile ID.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_createWredProfile(const UI32_T unit, const UI32_T profile_id);

/**
 * @brief The function is used to set WRED profile
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     profile_id    - WRED profile ID.
 * @param [in]     type          - traffic type.
 * @param [in]     color         - traffic color.
 * @param [in]     ptr_entry     - WRED profile entry.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setWredProfile(const UI32_T unit,
                                  const UI32_T profile_id,
                                  const CLX_TM_TRAFFIC_TYPE_T type,
                                  const CLX_COLOR_T color,
                                  const CLX_TM_WRED_ENTRY_T *ptr_entry);

/**
 * @brief The function is used to delete WRED profile
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     profile_id    - WRED profile ID.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_delWredProfile(const UI32_T unit, const UI32_T profile_id);

/**
 * @brief The function is used to set per queue WRED configuration.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     handler      - Egress queue handler.
 * @param [in]     ptr_entry    - WRED configuration of egress queue.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setWredQueueConfig(const UI32_T unit,
                                      const UI32_T port,
                                      const CLX_TM_HANDLER_T handler,
                                      const CLX_TM_WRED_QUEUE_CFG_T *ptr_entry);

/**
 * @brief The function is used to get per queue WRED configuration.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     handler      - Egress queue handler.
 * @param [out]    ptr_entry    - WRED configuration of egress queue.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getWredQueueConfig(const UI32_T unit,
                                      const UI32_T port,
                                      const CLX_TM_HANDLER_T handler,
                                      CLX_TM_WRED_QUEUE_CFG_T *ptr_entry);

/**
 * @brief The function is used to get DCTCP profile.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     profile_id    - DCTCP profile ID.
 * @param [out]    ptr_entry     - DCTCP profile entry.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getDctcpProfile(const UI32_T unit,
                                   const UI32_T profile_id,
                                   CLX_TM_DCTCP_PROFILE_T *ptr_entry);

/**
 * @brief The function is used to create DCTCP profile.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     profile_id    - DCTCP profile ID.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_createDctcpProfile(const UI32_T unit, const UI32_T profile_id);

/**
 * @brief The function is used to set DCTCP profile.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     profile_id    - DCTCP profile ID.
 * @param [in]     ptr_entry     - DCTCP profile entry.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setDctcpProfile(const UI32_T unit,
                                   const UI32_T profile_id,
                                   const CLX_TM_DCTCP_PROFILE_T *ptr_entry);

/**
 * @brief The function is used to delete DCTCP profile.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     profile_id    - DCTCP profile ID.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_delDctcpProfile(const UI32_T unit, const UI32_T profile_id);

/**
 * @brief The function is used to set per queue DCTCP configuration.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [in]     handler       - Egress queue handler.
 * @param [in]     profile_id    - The DCTCP profile id is binded by the queue.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setDctcpQueueConfig(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_TM_HANDLER_T handler,
                                       const UI32_T profile_id);

/**
 * @brief The function is used to get per queue DCTCP configuration.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Physical port id.
 * @param [in]     handler           - Egress queue handler.
 * @param [out]    ptr_profile_id    - The DCTCP profile id is binded by the queue.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getDctcpQueueConfig(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_TM_HANDLER_T handler,
                                       UI32_T *ptr_profile_id);

/**
 * @brief The function is used to set the mapping of the PCP and the queue group.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     handler    - Egress queue handler.
 * @param [in]     ptr_pfc    - PFC interface struct.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setPfcMapping(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_TM_HANDLER_T handler,
                                 const CLX_TM_PFC_MAPPING_ENTRY_T *ptr_pfc);

/**
 * @brief The function is used to get the mapping of the PCP and the queue group.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     handler    - Egress queue handler.
 * @param [out]    ptr_pfc    - PFC interface struct.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getPfcMapping(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_TM_HANDLER_T handler,
                                 CLX_TM_PFC_MAPPING_ENTRY_T *ptr_pfc);

/**
 * @brief The function is used to set flow conctrol enable status.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     mode    - FC_802_3X/FC_PFC/FC_DISABLE.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setFlowCtrlEnable(const UI32_T unit, const UI32_T port, const UI32_T mode);

/**
 * @brief The function is used to get flow conctrol enable status.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [out]    ptr_mode    - get FC_802_3X/FC_PFC/FC_DISABLE.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getFlowCtrlEnable(const UI32_T unit, const UI32_T port, HAL_TM_FC_T *ptr_mode);

/**
 * @brief The function is used to get the definition of share_max_th and hrm_th of the PCP.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port                - Physical port id.
 * @param [out]    ptr_share_max_th    - The share_max_th of pcp.
 * @param [out]    ptr_hrm_th          - The ptr_hrm_th of pcp.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getHrmAndMaxTh(const UI32_T unit,
                                  const UI32_T port,
                                  UI32_T *ptr_share_max_th,
                                  UI32_T *ptr_hrm_th);

/**
 * @brief The function is used to get the definition of min_th of the queue.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Physical port id.
 * @param [out]    ptr_ea_min_th    - The min_th of the queue.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getAoqMinTh(const UI32_T unit, const UI32_T port, UI32_T *ptr_ea_min_th);

/**
 * @brief The function is used to get max threshold of share pool usage under IA accountable area.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     inst_idx             - Instance index number.
 * @param [out]    ptr_max_static_th    - max threshold of share pool usage under IA accountable
 * area.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufGsTh(const UI32_T unit,
                                 const UI32_T inst_idx,
                                 UI32_T *ptr_max_static_th);

/**
 * @brief The function is used to get max threshold of share pool usage under CM accountable area of
 * EA.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [out]    ptr_max_static_th    - max threshold of share pool usage under IA accountable
 * area.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufGsCmTh(const UI32_T unit, UI32_T *ptr_max_static_th);

/**
 * @brief The function is used to get max threshold of share pool usage under ingress lossy
 * accountable area.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     inst_idx          - Instance index number.
 * @param [out]    ptr_max_static_th - max threshold of share pool usage under IEA
 * accountable area.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getLsyBufGsTh(const UI32_T unit,
                                 const UI32_T inst_idx,
                                 UI32_T *ptr_max_static_th);

/**
 * @brief The function is used to get EA global share threshold.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     inst_idx      - Instance index.
 * @param [out]    ptr_gs_thd    - global share threshold.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufGsTh(const UI32_T unit, const UI32_T inst_idx, UI32_T *ptr_gs_thd);

/**
 * @brief The function is used to get EA MC global share threshold.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_gs_thd    - global share threshold.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufMcGsTh(const UI32_T unit, UI32_T *ptr_gs_thd);

/**
 * @brief The function is used to get sc type.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - The port number.
 * @param [in]     sc            - The sc number.
 * @param [out]    ptr_type_value    - sc type value.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getScType(const UI32_T unit,
                             const UI32_T port,
                             const UI32_T sc,
                             UI32_T *ptr_type_value);

/**
 * @brief The function is used to get per queue min threshold
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [in]     queue_type    - queue type.
 * @param [in]     queue_id      - queue ID.
 * @param [out]    ptr_min_th    - strict min threshold.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getEgrBufUmQueueMinTh(const UI32_T unit,
                                         const UI32_T port,
                                         const UI32_T queue_type,
                                         const UI32_T queue_id,
                                         UI32_T *ptr_min_th);

/**
 * @brief The function is used to get IA per PCP headroom.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     inst_idx        - Instance idex.
 * @param [in]     port            - Physical port id.
 * @param [in]     pcp             - pcp value.
 * @param [out]    ptr_headroom    - headroom threshold for the pcp.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufPcpHrm(const UI32_T unit,
                                   const UI32_T inst_idx,
                                   const UI32_T port,
                                   const UI32_T pcp,
                                   UI32_T *ptr_headroom);

/**
 * @brief The function is used to get IA max static threshold for the pcp.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     inst_idx             - Instance index number.
 * @param [in]     port                 - Physical port id.
 * @param [in]     pcp                  - pcp.
 * @param [out]    ptr_max_static_th    - max static threshold for the pcp.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufPcpMaxStaticTh(const UI32_T unit,
                                           const UI32_T inst_idx,
                                           const UI32_T port,
                                           const UI32_T pcp,
                                           UI32_T *ptr_max_static_th);

/**
 * @brief The function is used to get IA port max static threshold.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     port                 - Physical port id.
 * @param [out]    ptr_max_static_en    - Enable ingress buffer port max static threshold or not.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getIgrBufPortMaxStaticEn(const UI32_T unit,
                                            const UI32_T port,
                                            BOOL_T *ptr_max_static_en);

/**
 * @brief The function is used to update the port status with action.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [in]     status    - action (HAL_TM_PS_ACTIVED, HAL_TM_PS_NO_ACTIVED)
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_updatePortStatus(const UI32_T unit, const UI32_T port, const HAL_TM_SC_T status);

/**
 * @brief The function is used to get EA port empty.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - CLX port number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getAopEmpty(const UI32_T unit, const UI32_T port);

/**
 * @brief The function is used to get EA queue empty.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - CLX port number.
 * @param [in]     handler - Handler id number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getAoqEmpty(const UI32_T unit,
                               const UI32_T port,
                               const CLX_TM_HANDLER_T handler);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getAiqEmpty(const UI32_T unit, const UI32_T port, const UI32_T queue);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setBufThreshold(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_TM_HANDLER_T handler,
                                   const CLX_TM_BUF_TYPE_T type,
                                   const CLX_TM_BUF_THRESHOLD_T *ptr_entry);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getBufThreshold(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_TM_HANDLER_T handler,
                                   const CLX_TM_BUF_TYPE_T type,
                                   CLX_TM_BUF_THRESHOLD_T *ptr_entry);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getBufOccupancy(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_TM_HANDLER_T handler,
                                   const CLX_TM_BUF_TYPE_T type,
                                   CLX_TM_BUF_OCCUPANCY_T *ptr_entry);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getAopIdx(const UI32_T unit,
                             const UI32_T port,
                             UI32_T *ptr_inst_idx,
                             UI32_T *ptr_sub_idx,
                             UI32_T *ptr_entry_idx);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getWarmSize(const UI32_T unit, UI32_T *ptr_size);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_deinitWarm(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_initWarm(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

UI32_T
hal_lt_dawn_tm_buf_getAipSubIdx(const UI32_T unit, const UI32_T inst_idx, const UI32_T port);

UI32_T
hal_lt_dawn_tm_buf_getAiqIdx(const UI32_T unit, const UI32_T port, const UI32_T pcp);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getBufWatermark(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_TM_HANDLER_T handler,
                                   const CLX_TM_BUF_TYPE_T type,
                                   CLX_TM_BUF_WATERMARK_T *ptr_entry);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_clearBufWatermark(const UI32_T unit,
                                     const UI32_T port,
                                     const CLX_TM_HANDLER_T handler,
                                     const CLX_TM_BUF_TYPE_T type);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_getBufWatermarkList(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_TM_HANDLER_T *ptr_handler_list,
                                       const CLX_TM_BUF_TYPE_T type,
                                       const UI32_T list_cnt,
                                       CLX_TM_BUF_WATERMARK_T *ptr_entry_list);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_clearBufWatermarkList(const UI32_T unit,
                                         const UI32_T port,
                                         const CLX_TM_HANDLER_T *ptr_handler_list,
                                         const CLX_TM_BUF_TYPE_T type,
                                         const UI32_T list_cnt);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_setPortDefault(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_lt_dawn_tm_buf_resetPortDefault(const UI32_T unit, const UI32_T port);

#endif /*end of HAL_LT_DAWN_TM_BUF_H*/
