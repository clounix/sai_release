/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   ifmap_clx_vlan.h
 * PURPOSE:
 *      It provides user port to cl port translation for VLAN API.
 * NOTES:
 */

#ifndef IFMAP_CLX_VLAN_H
#define IFMAP_CLX_VLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Add member and untag port list of existing vlan entry.
 *
 * VLAN entry includes member port list and untag port list.
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     ptr_user_vlan_entry    - VLAN entry
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_setPort(const UI32_T unit, const CLX_VLAN_ENTRY_T *ptr_user_vlan_entry);

/**
 * @brief Get a vlan entry with specified 802.1Q vlan.
 *
 * @param [in]     unit                   - Device unit number
 * @param [out]    ptr_user_vlan_entry    - VLAN entry
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_getPort(const UI32_T unit, CLX_VLAN_ENTRY_T *ptr_user_vlan_entry);

/**
 * @brief Traverse vlan tagged/untagged member port for active vlan.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     user_callback      - The callback function to be called for each traversed vlan entry
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_traverseEntry(const UI32_T unit,
                             const CLX_VLAN_ENTRY_TRAVERSE_FUNC_T user_callback,
                             void *ptr_cookie);

/**
 * @brief Set a type-based vlan entry.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     index             - Index of the entry
 * @param [in]     ptr_user_entry    - Protocol-related and common L2 fields
 * @param [in]     ptr_action        - Assigned actions of vlan info
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_setTypeEntry(const UI32_T unit,
                            const UI32_T index,
                            const CLX_VLAN_CLASSIFY_TYPE_T *ptr_user_entry,
                            const CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Get a type-based vlan entry.
 *
 * Type-based entry includes protocol type.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     index             - Index of the entry
 * @param [out]    ptr_user_entry    - Protocol-related and common L2 fields
 * @param [out]    ptr_action        - Assigned actions of vlan info
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_getTypeEntry(const UI32_T unit,
                            const UI32_T index,
                            CLX_VLAN_CLASSIFY_TYPE_T *ptr_user_entry,
                            CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Set a address-based vlan entry.
 *
 * Address-based entry includes mac and ip address.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     index             - Index of the entry
 * @param [in]     ptr_user_entry    - L2/L3 address-related and common L2 fields
 * @param [in]     ptr_action        - Assigned actions of vlan info
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_setAddrEntry(const UI32_T unit,
                            const UI32_T index,
                            const CLX_VLAN_CLASSIFY_ADDR_T *ptr_user_entry,
                            const CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Get a address-based vlan entry.
 *
 * Address-based entry includes mac and ip address.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     index             - Index of the entry
 * @param [out]    ptr_user_entry    - L2/L3 address-related and common L2 fields
 * @param [out]    ptr_action        - Assigned actions of vlan info
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_getAddrEntry(const UI32_T unit,
                            const UI32_T index,
                            CLX_VLAN_CLASSIFY_ADDR_T *ptr_user_entry,
                            CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Add a pvlan entry for the primary vlan.
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     primary_vlan            - 802.1Q VLAN id
 * @param [in]     ptr_user_pvlan_entry    - Pvlan entry
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_addPvlanEntry(const UI32_T unit,
                             const CLX_VLAN_T primary_vlan,
                             const CLX_VLAN_PVLAN_ENTRY_T *ptr_user_pvlan_entry);

/**
 * @brief Get a pvlan entry for the primary vlan.
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     primary_vlan            - 802.1Q VLAN id
 * @param [out]    ptr_user_pvlan_entry    - Pvlan entry
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_getPvlanEntry(const UI32_T unit,
                             const CLX_VLAN_T primary_vlan,
                             CLX_VLAN_PVLAN_ENTRY_T *ptr_user_pvlan_entry);

#endif /* End of #ifndef IFMAP_CLX_VLAN_H */
