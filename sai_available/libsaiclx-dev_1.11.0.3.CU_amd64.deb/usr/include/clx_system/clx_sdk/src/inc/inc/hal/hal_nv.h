/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_nv.h
 * PURPOSE:
 *      It provides the CL8360 NV module HAL function prototypes.
 * NOTES:
 *
 */

#ifndef HAL_NV_H
#define HAL_NV_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
/* https://tools.ietf.org/html/draft-singh-nvo3-vxlan-router-alert-01 */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
/* |R|R|R|R|I|R|R|RA|           Reserved                           |  */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
/* |                VXLAN Network Identifier (VNI) |   Reserved    |  */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
#define HAL_NV_VXLAN_LOC_RA_BIT (0x01000000) /* 0000-I00[RA]-0000-0000 */

/* https://tools.ietf.org/html/draft-singh-nvo3-nvgre-router-alert-00 */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
/* |0| |1|0| Reserved0     RA| Ver |   Protocol Type 0x6558        |  */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
/* |               Virtual Subnet ID (VSID)        |   Reserved    |  */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
#define HAL_NV_NVGRE_LOC_RA_BIT (0x00080000)   /* 00I0-0000-0000-[RA]VVV */

#define HAL_NV_VXLANGPE_LOC_O_BIT (0x01000000) /* 00I0-0000-0000-[RA]VVV */

#define HAL_NV_VXLAN_CTL_IDX_RA    (0)         /* vxlan_bas_ctl_flg_[msk/val/eq]   */
#define HAL_NV_VXLANGPE_CTL_IDX_O  (0)         /* vxlan_gpe_ctl_flg_[msk/val/eq]_0 */
#define HAL_NV_VXLANGPE_CTL_IDX_RA (1)         /* vxlan_gpe_ctl_flg_[msk/val/eq]_1 */
#define HAL_NV_NVGRE_CTL_IDX_RA    (0)         /* gre_ctl_flg_[msk/val/eq]_0       */

#define HAL_NV_CTL_FLG_EXP_EQ  (1)
#define HAL_NV_CTL_FLG_EXP_nEQ (0)

/* 24-bit value to identify the virtual layer 2 network */
#define HAL_NV_SEGMENT_ID_MIN (1)
#define HAL_NV_SEGMENT_ID_MAX (0xffffff)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* from clx_nv_addSegService */
typedef struct HAL_NV_TNLFDIDSEG_AVL_NODE_S {
    UI32_T lcl_intf_grp;
    UI32_T fdid;
    UI32_T seg;
} HAL_NV_TNLFDIDSEG_AVL_NODE_T;

/* seg_in equals to seg_out, unless tunnel have different segments
 * between local and remote
 */
typedef struct HAL_NV_INTFBDID2SEG_AVL_NODE_S {
    CLX_PORT_T intf;
    UI32_T bdid;
    UI32_T seg_in;
    UI32_T seg_out;
} HAL_NV_INTFBDIDSEG_AVL_NODE_T;

typedef struct HAL_NV_CB_S {
    CMLIB_AVL_HEAD_T *_ptr_nv_tnlfdid2seg_avl;
    CMLIB_AVL_HEAD_T *_ptr_nv_tnlseg2fdid_avl;
    CMLIB_AVL_HEAD_T *_ptr_nv_intfbdid2segall_avl;
    CMLIB_AVL_HEAD_T *_ptr_nv_intfseglcl2bdid_avl;
    CMLIB_AVL_HEAD_T *_ptr_nv_intfsegrmt2bdid_avl;
    CLX_SEMAPHORE_ID_T nv_sema;
} HAL_NV_CB_T;

typedef HAL_NV_CB_T HAL_NV_CB_P[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize the NV module.
 *
 * @param [in]     unit    - Device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_nv_init(const UI32_T unit);

/**
 * @brief Deinitialize the NV module.
 *
 * @param [in]     unit    - Device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_nv_deinit(const UI32_T unit);

/**
 * @brief get seg by tunnel and fdid
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     fdid            - Forwarding domain
 * @param [in]     lcl_intf_grp    - Local interface group
 * @param [out]    ptr_seg         - Segment value (24 bits)
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_nv_getSegByTnlFdid(const UI32_T unit,
                       const UI32_T fdid,
                       const UI32_T lcl_intf_grp,
                       UI32_T *ptr_seg);

/**
 * @brief get seg by clx_port and fdid
 *
 * ptr_seg0 usually equals to ptr_seg1, unless there are
 * different segments between local and remote
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Port interface
 * @param [in]     bdid        - Bridge domain
 * @param [out]    ptr_seg0    - Segment0 of local
 * @param [out]    ptr_seg1    - Segment1 of remote
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_nv_getSegByPortBdid(const UI32_T unit,
                        const CLX_PORT_T port,
                        const UI32_T bdid,
                        UI32_T *ptr_seg0,
                        UI32_T *ptr_seg1);

/**
 * @brief get bdid by clx_port and seg
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port interface
 * @param [in]     seg     - Segment
 * @param [in]     dir     - Direction
 * @param [out]    bdid    - Bridge Domain
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_nv_getBdidByPortSeg(const UI32_T unit,
                        const CLX_PORT_T port,
                        const UI32_T seg,
                        const CLX_DIR_T dir,
                        UI32_T *bdid);

/**
 * @brief update swdb for seg <-> fdid for service composed of clx_port.
 *
 * @param [in]     unit      - device unit number
 * @param [in]     add       - 1 for add, 0 for del
 * @param [in]     port      - clx_port
 * @param [in]     seg0      - local segment
 * @param [in]     seg1      - remote segment (usually equal to seg0)
 * @param [in]     bdid      - bridge domain ID (don't care for del)
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_nv_updateClxPortDb(const UI32_T unit,
                       const UI32_T add,
                       const CLX_PORT_T port,
                       const UI32_T seg0,
                       const UI32_T seg1,
                       const UI32_T bdid);

HAL_NV_CB_P *
hal_nv_getCtrlBlock(const UI32_T unit);

CLX_ERROR_NO_T
hal_nv_dumpDb(const UI32_T unit);
#endif /* #ifndef HAL_NV_H */