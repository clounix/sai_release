/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_lightning_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_LT_LIGHTNING_STAT_H
#define HAL_LT_LIGHTNING_STAT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stat.h>
#include <clx_tm.h>
#include <dcc/dcc_dma.h>
#include <hal/hal_cmn.h>
#include <hal/hal_cmn_drv.h>
#include <hal/hal_stat.h>
#include <hal/hal_sec.h>
#include <hal/light/lightning/hal_lt_lightning_cmn.h>

/* #define HAL_LT_LIGHTNING_STAT_USE_CLD_DMA */
/* #define HAL_LT_LIGHTNING_STAT_EN_RSFEC_CNT */

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_LT_LIGHTNING_STAT_MIB_SRAM_LANE_IDX_OFFSET (6 * 13)
#define HAL_LT_LIGHTNING_STAT_SRV_CNT_IDX_OFFSET       (9)
#define HAL_LT_LIGHTNING_STAT_SRV_CNT_NUM_PER_BANK \
    ((1U << HAL_LT_LIGHTNING_STAT_SRV_CNT_IDX_OFFSET) * 6)
#define HAL_LT_LIGHTNING_STAT_SRV_CNT_BANK_NUM          (16)
#define HAL_LT_LIGHTNING_STAT_DST_CNT_NUM_PER_BANK      (256)
#define HAL_LT_LIGHTNING_STAT_DST_CNT_BANK_NUM          (4)
#define HAL_LT_LIGHTNING_STAT_TM_IOS_CNT_SUBINST_OFFSET (108)
#define HAL_LT_LIGHTNING_STAT_TM_IOS_CNT_PLANE_OFFSET \
    (HAL_LT_LIGHTNING_STAT_TM_IOS_CNT_SUBINST_OFFSET * 4)
#define HAL_LT_LIGHTNING_STAT_TM_TMI_CNT_TYPE_OFFSET (34)
#define HAL_LT_LIGHTNING_STAT_TM_TMI_CNT_PLANE_OFFSET \
    (HAL_LT_LIGHTNING_STAT_TM_TMI_CNT_TYPE_OFFSET * 7)
#define HAL_LT_LIGHTNING_STAT_TM_ENB_CNT_TYPE_OFFSET (34)
#define HAL_LT_LIGHTNING_STAT_TM_ENB_CNT_PLANE_OFFSET \
    (HAL_LT_LIGHTNING_STAT_TM_ENB_CNT_TYPE_OFFSET * 12)
#define HAL_LT_LIGHTNING_STAT_TM_CMS_CNT_BIN_OFFSET     (89 * 4)
#define HAL_LT_LIGHTNING_STAT_TM_ADM_CNT_PLANE_OFFSET   (396 * 4)
#define HAL_LT_LIGHTNING_STAT_TM_DEB_CNT_PLANE_OFFSET   (34)
#define HAL_LT_LIGHTNING_STAT_TM_EPM_CNT_PLANE_OFFSET   (34 * 2)
#define HAL_LT_LIGHTNING_STAT_TM_ADM_CMS_CNT_CPI_OFFSET (48)
#define HAL_LT_LIGHTNING_STAT_EXCPT_CNT_PLANE_OFFSET    (33)
#define HAL_LT_LIGHTNING_STAT_EXCPT_CNT_TYPE_NUM_IGR    (260)
#define HAL_LT_LIGHTNING_STAT_EXCPT_CNT_TYPE_NUM_EGR    (69)
#define HAL_LT_LIGHTNING_STAT_EXCPT_CNT_BMP_WORD_IGR \
    (((HAL_LT_LIGHTNING_STAT_EXCPT_CNT_TYPE_NUM_IGR - 1) / 32) + 1)
#define HAL_LT_LIGHTNING_STAT_EXCPT_CNT_BMP_WORD_EGR \
    (((HAL_LT_LIGHTNING_STAT_EXCPT_CNT_TYPE_NUM_EGR - 1) / 32) + 1)
#define HAL_LT_LIGHTNING_STAT_DIE_NUM                      (4)
#define HAL_LT_LIGHTNING_STAT_MAC_NUM_PER_DIE              (8)
#define HAL_LT_LIGHTNING_STAT_LANE_NUM_PER_MAC             (8)
#define HAL_LT_LIGHTNING_STAT_ETHL_LANE_NUM                (256)
#define HAL_LT_LIGHTNING_STAT_ETHX_LANE_NUM                (2)
#define HAL_LT_LIGHTNING_STAT_CPU_LANE_NUM                 (1)
#define HAL_LT_LIGHTNING_STAT_TM_QUEUECNT_NUM_PER_PLANE    (576)
#define HAL_LT_LIGHTNING_STAT_TM_CPU_QUEUE_NUM             (48)
#define HAL_LT_LIGHTNING_STAT_TM_CPI_QUEUE_NUM             (16)
#define HAL_LT_LIGHTNING_STAT_FLEX_CNT_ID_IGR_PARITY_DROP  (9)
#define HAL_LT_LIGHTNING_STAT_FLEX_CNT_ID_L3_IGR_BLACKHOLE (10)
#define HAL_LT_LIGHTNING_STAT_FLEX_CNT_ID_L3_IGR_DROP      (11)
#define HAL_LT_LIGHTNING_STAT_MAX_TOLORENCE_INTERVAL       (1350000)
#define HAL_LT_LIGHTNING_STAT_DEFAULT_POLLING_INTERVAL_MS  (500)
#define HAL_LT_LIGHTNING_STAT_MIN_POLLING_INTERVAL_MS      (250)
#define HAL_LT_LIGHTNING_STAT_MAX_POLLING_INTERVAL_MS      (1000)
#define HAL_LT_LIGHTNING_STAT_RSFEC_DEFAULT_UPDATE_INTVL   (1000000)
/* single-die all rsfec-cerr counter update time estimate is around 1500us, \
 * limit interval to be the safe side for suppporting 4-die */
#define HAL_LT_LIGHTNING_STAT_RSFEC_MIN_UPDATE_INTVL (10000)
/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_LT_LIGHTNING_STAT_RSFEC_LOCK(__unit__) \
    osal_takeSemaphore(&(_hal_stat_rsfec_cb[__unit__].sema), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_LT_LIGHTNING_STAT_RSFEC_UNLOCK(__unit__) \
    osal_giveSemaphore(&(_hal_stat_rsfec_cb[__unit__].sema))

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_LT_LIGHTNING_STAT_MIB_RX_US_GOOD_PKT = 0,
    HAL_LT_LIGHTNING_STAT_MIB_RX_US_BAD_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_OS_GOOD_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_OS_BAD_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_MTU_ERR_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_NA0_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_MCAST_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_BCAST_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_NUCAST_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_UCAST_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_64_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_GOOD_OCTET,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_65_127_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_128_255_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_256_511_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_512_1023_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_1024_1518_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_BAD_OCTET,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_1519_2047_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_2048_4095_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_4096_9216_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_9217_16383_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_NA1_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_NA2_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC0_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC1_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC2_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC3_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC4_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC5_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC6_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC7_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PAUSE_MC_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PFC_MC_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_PAUSE_UC_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_DROP_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_SYMBOL_ERR_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_RS_ERR_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_STOMP_CRC_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_CRC_ERR_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_UNK_OPC_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_RX_LENG_ERR_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_US_GOOD_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_US_BAD_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_OS_GOOD_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_OS_BAD_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_NA3_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_NA4_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_MCAST_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_BCAST_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_NUCAST_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_UCAST_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_64_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_GOOD_OCTET,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_65_127_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_128_255_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_256_511_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_512_1023_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_1024_1518_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_BAD_OCTET,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_1519_2047_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_2048_4095_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_4096_9216_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_LENG_9217_16383_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_NA5_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_NA6_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC0_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC1_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC2_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC3_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC4_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC5_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC6_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC7_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PAUSE_MC_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_PFC_MC_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_ERR_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_TX_DROP_PKT,
    HAL_LT_LIGHTNING_STAT_MIB_SRAM_TYPE_LAST
} HAL_LT_LIGHTNING_STAT_MIB_SRAM_TYPE_T;

typedef enum {
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV4_UC = 0,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV4_MC,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV4_RECV,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV4_INVALID_HEADER,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV4_INVALID_ADDR,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV4_DROP,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV6_UC,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV6_MC,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV6_RECV,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV6_INVALID_HEADER,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV6_INVALID_ADDR,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_IPV6_DROP,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_TAGGED,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_UNTAGGED,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_L3_DROP,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_ACL_DROP,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_ICC_DROP,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_ACL_DROP_CPU,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_ERR_DROP,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_DI_RANGE_CNT0,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_DI_RANGE_CNT1,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_DI_RANGE_CNT2,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_DI_RANGE_CNT3,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_DI_RANGE_CNT4,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_DI_RANGE_CNT5,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_DI_RANGE_CNT6,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_DI_RANGE_CNT7,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_EXCPT_CNT0,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_EXCPT_CNT1,
    HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_LAST
} HAL_LT_LIGHTNING_STAT_FLEX_CNT_IGR_TYPE_T;

typedef struct HAL_LT_LIGHTNING_STAT_RSFEC_TASK_S {
    UI32_T inst_idx;
    UI32_T subinst_idx;
    UI32_T entry_idx;
} HAL_LT_LIGHTNING_STAT_RSFEC_TASK_T;

typedef struct HAL_LT_LIGHTNING_STAT_RSFEC_CB_S {
    UI64_T *ptr_results;
    UI32_T task_cnt;
    UI32_T *ptr_tasks_id;
    HAL_LT_LIGHTNING_STAT_RSFEC_TASK_T *ptr_tasks;
    CLX_SEMAPHORE_ID_T sema;
    CLX_THREAD_ID_T update_thread_id;
    UI32_T sleep_intvl;
} HAL_LT_LIGHTNING_STAT_RSFEC_CB_T;

/* dbg analyze stat */
typedef enum {
    HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE_UC = 0,
    HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE_MC,
    HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE_IGR_MIR,
    HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE_EGR_MIR,
    HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE_EGR_EXP_CPU,
    HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE_EGR_CPY_CPU,
    HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE_LAST
} HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE;

typedef enum {
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_MAC_RX,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_MAC_TX,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_PDMA_RX,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_PDMA_TX,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_IPM,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_IOS,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_IOS_LBS,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_IPP,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_XBN,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_TM,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_EPP,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_EPM,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_EPM_LBK,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_LAST
} HAL_LT_LIGHTNING_STAT_DBG_STAGE;

typedef enum {
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_RESULT_OK,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_RESULT_DROP,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_RESULT_ERROR,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_RESULT_NONE,
    HAL_LT_LIGHTNING_STAT_DBG_STAGE_RESULT_LAST
} HAL_LT_LIGHTNING_STAT_DBG_STAGE_RESULT;

/* dbg analyze stat - mac */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_MAC_RX,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_MAC_TX,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_MAC_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_MAC;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_US_GOOD,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_US_BAD,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_OS_GOOD,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_OS_BAD,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_SYMBOL_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_RS_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_STOMP_CRC_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_CRC_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_UNK_OPC,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_LENG_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_RX_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_TX_US_GOOD,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_TX_US_BAD,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_TX_OS_GOOD,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_TX_OS_BAD,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_TX_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_TX_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_MAC;

/* dbg analyze stat - ipm */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IPM_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IPM_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IPM_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IPM;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPM_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPM_MERGE_DROP, /* default */
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPM_PORT_DISABLE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPM_SHORT_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPM_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPM;

/* dbg analyze stat - ios */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IOS_BUF,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IOS_LBS_BUF,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IOS_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IOS;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS_TRUNC,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS_BUF_NONEMPTY,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS_LBS_BUF_FULL_TRUNC,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS_LBS_NORMAL_TRUNC,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS_LBS_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS_LBS_BUF_NONEMPTY,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_IOS;

/* dbg analyze stat - ipp */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IPP_EXCPT,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IPP_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_IPP;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPP_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPP_EXCEPT,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPP_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_IPP;

/* dbg analyze stat - xbn */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_XBN_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_XBN;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_XBN_IPID_INVALID,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_XBN_LG_LB_NO_BIN,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_XBN_LG_AB_NO_BIN,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_XBN_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_XBN;

/* dbg analyze stat - tm */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_TM_DROP_EN_IGR,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_TM_DROP_EN_EGR,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_TM_TX_BLOCK,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_TM_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_TM;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_TMI_SOP_IPP_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_TMI_SINGLE_CELL_MISSING_EOP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_TMI_RAW_PBM_ZERO,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_TMI_PROTOCOL_ERR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_ENB_BUF_FULL_TRUNCATE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_ENB_IPP_ERR_TRUNCATE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_ENB_UNDERBOOK_TRUNCATE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_ADM_FAIL,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_TX_DISABLE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_RX_DISABLE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_RXTX_DISABLE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_DEB_BLOCK,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_EPM_BLOCK,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_MAC_TX_NONEMPTY,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_TX_BLOCK,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_TM;

/* dbg analyze stat - epp */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_EPP_EXCPT,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_EPP_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_EPP;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPP_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPP_EXCEPT,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPP_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPP;

/* dbg analyze stat - epm */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_EPM_BUF,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_EPM_BUF_LBK,
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_EPM_LAST,
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_EPM;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPM_ERROR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPM_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPM_LBK_ERROR,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPM_LBK_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPM_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_EPM;

/* dbg analyze stat - pdma */
typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_PDMA_LAST,
} HAL_LT_LIGHTNING_STAT_STAGE_ANALYZE_TYPE_PDMA;

typedef enum {
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_PDMA_RX_DROP,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_PDMA_TX_UNDERSIZE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_PDMA_TX_OVERSIZE,
    HAL_LT_LIGHTNING_STAT_STAGE_REASON_PDMA_LAST
} HAL_LT_LIGHTNING_STAT_STAGE_REASON_PDMA;

typedef CLX_ERROR_NO_T (*HAL_STAT_DBG_STAGE_RULE_FUNC_T)(
    const UI32_T unit,
    const UI32_T input_port,
    const UI32_T output_port,
    const UI32_T lbk_dst_port,
    const HAL_LT_LIGHTNING_STAT_DBG_STAGE stage,
    const HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE type,
    const UI64_T in_cnt,
    UI64_T *ptr_out_cnt);

typedef CLX_ERROR_NO_T (*HAL_STAT_DBG_STAGE_SNAKE_RULE_FUNC_T)(
    const UI32_T unit,
    const UI32_T input_port,
    const UI32_T output_port,
    const HAL_LT_LIGHTNING_STAT_DBG_STAGE stage,
    const UI32_T first_port,
    UI64_T *ptr_in_cnt,
    UI64_T *ptr_out_cnt,
    UI32_T *ptr_stop);

typedef CLX_ERROR_NO_T (*HAL_STAT_DBG_STAGE_ANALYSIS_FUNC_T)(const UI32_T unit,
                                                             const UI32_T port,
                                                             const UI32_T stage_analysis_type,
                                                             const UI64_T cnt,
                                                             UI32_T *ptr_flags);

typedef struct HAL_STAT_DBG_STAGE_INFO_S {
    HAL_STAT_DBG_STAGE_RULE_FUNC_T rule_func;
    HAL_STAT_DBG_STAGE_SNAKE_RULE_FUNC_T snake_rule_func;
    C8_T **ptr_reason;
    HAL_STAT_DBG_STAGE_ANALYSIS_FUNC_T analysis_func;
} HAL_STAT_DBG_STAGE_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init stat module control blocks.
 *
 * @param [in]     unit    - device unit number
 * @return         CLX_E_OK               - init success.
 * @return         CLX_E_NO_MEMORY        - allocate control block failed
 * @return         CLX_E_OTHERS           - init fail
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_init(const UI32_T unit);

/**
 * @brief Deinit stat module control blocks and free resource.
 *
 * @param [in]     unit    - device unit number
 * @return         CLX_E_OK               - deinit success
 * @return         CLX_E_OTHERS           - deInit fail
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_deinit(const UI32_T unit);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @param [out]    ptr_cnt    - Counter value
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getTmCnt(const UI32_T unit,
                               const UI32_T port,
                               const CLX_TM_HANDLER_T handler,
                               const CLX_STAT_TM_CNT_TYPE_T type,
                               CLX_STAT_TM_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearTmCnt(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_TM_HANDLER_T handler,
                                 const CLX_STAT_TM_CNT_TYPE_T type);

/**
 * @brief This API is used to get a distribution counter.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - Counter
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getDistCnt(const UI32_T unit,
                                 const UI32_T cnt_id,
                                 CLX_STAT_DIST_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear a distribution counter.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearDistCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get PP counter SW ID using HW index
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     hw_cnt_idx       - HW counter idx in HW table
 * @param [in]     cnt_type         - counter type
 * @param [out]    ptr_sw_cnt_id    - HW counter id
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getCntSWId(const UI32_T unit,
                                 const UI32_T hw_cnt_idx,
                                 const HAL_STAT_HW_TYPE_T cnt_type,
                                 UI32_T *ptr_sw_cnt_id);

/**
 * @brief This API is used to get port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @param [out]    ptr_cnt     - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getMibRaw(const UI32_T unit,
                                const UI32_T port,
                                const HAL_STAT_HW_TYPE_T hw_type,
                                const HAL_LT_LIGHTNING_STAT_MIB_SRAM_TYPE_T cnt_type,
                                UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearMibRaw(const UI32_T unit,
                                  const UI32_T port,
                                  const HAL_STAT_HW_TYPE_T hw_type,
                                  const HAL_LT_LIGHTNING_STAT_MIB_SRAM_TYPE_T cnt_type);

/**
 * @brief This API is used to get TM raw counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     inst_idx     - Instance index
 * @param [in]     sub_idx      - Sub-instance index
 * @param [in]     type         - TM counter type
 * @param [in]     entry_idx    - Entry index
 * @param [in]     field_id     - Counter index of the corresponding field
 * @param [out]    ptr_cnt      - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getTmRaw(const UI32_T unit,
                               const UI32_T inst_idx,
                               const UI32_T sub_idx,
                               const HAL_STAT_HW_TYPE_T type,
                               const UI32_T entry_idx,
                               const UI32_T field_id,
                               UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     inst_idx     - Instance index
 * @param [in]     sub_idx      - Sub-instance index
 * @param [in]     type         - TM counter type
 * @param [in]     entry_idx    - Entry index
 * @param [in]     field_id     - Counter index of the corresponding field
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearTmRaw(const UI32_T unit,
                                 const UI32_T inst_idx,
                                 const UI32_T sub_idx,
                                 const HAL_STAT_HW_TYPE_T type,
                                 const UI32_T entry_idx,
                                 const UI32_T field_id);

/**
 * @brief This API is used to get how many times the counter has been updated
 *
 * @param [in]     unit       - Device unit number
 * @param [out]    ptr_cnt    - Update count
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getUpdateCnt(const UI32_T unit, UI64_T *ptr_cnt);

/**
 * @brief This API is used to get PP exception counter by port
 *
 * It's caller's responsibility to pass an bitmap of correct size.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     dir           - Ingress or egress
 * @param [in]     port          - Physical port
 * @param [out]    excpt_bmap    - Exception state: bitmap for occurance indication
 * @param [out]    ptr_cnt       - Pointer to counter value
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getExcptCnt(const UI32_T unit,
                                  const CLX_DIR_T dir,
                                  const UI32_T port,
                                  UI32_T *excpt_bmap,
                                  UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear PP exception counter by port
 *
 * This API will clear both counter and exception state.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     dir     - Ingress or egress
 * @param [in]     port    - Physical port
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearExcptCnt(const UI32_T unit, const CLX_DIR_T dir, const UI32_T port);

/**
 * @brief This API is used to get PP storm control counter by index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     plane      - Plane number
 * @param [in]     cnt_idx    - The strom control counter index
 * @param [out]    ptr_cnt    - Pointer to corresponding counter entry (3 values)
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getStormCnt(const UI32_T unit,
                                  const UI32_T plane,
                                  const UI32_T cnt_idx,
                                  HAL_SEC_SCCOUNTER_ENTRY_T *ptr_cnt);

/**
 * @brief This API is used to clear PP storm control counter by index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     plane      - Plane number
 * @param [in]     cnt_idx    - The strom control counter index
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearStormCnt(const UI32_T unit, const UI32_T plane, const UI32_T cnt_idx);

/**
 * @brief This API is used to get value of the counter under study
 *
 * The number of counters value return is determined by the type of counter under study.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - The return counter values
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getCnt(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to show debug counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - CLX port number
 * @param [in]     stage_bmp    - The bitmap of stage:
 *                                bit0: mac; bit1: ipm; bit2: ios: bit3: ipp; bit4: xbn; bit5: tm;
 *                                bit6: epp; bit7: epm; bit8: lbm
 * @param [in]     flags        - Show the counter or not if it is zero
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_showDbgCnt(const UI32_T unit,
                                 const UI32_T port,
                                 const UI32_T stage_bmp,
                                 const UI32_T flags);

/**
 * @brief This API is used to clear all debug counter
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearDbgCnt(const UI32_T unit);

/**
 * @brief This API is used to trigger manually counter update to get latest counter value.
 *
 * The API takes time to collect latest counter please use it wisely.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK             - Success.
 * @return         CLX_E_NOT_SUPPORT    - Not support in current mode
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_refreshCnt(const UI32_T unit);

/**
 * @brief This API is used to get RS-FEC error distribution counter value.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port
 * @param [out]    ptr_cnt    - Pointer to counters
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getRsErrDistCnt(const UI32_T unit,
                                      const UI32_T port,
                                      HAL_STAT_RSERRDIST_CNT_ENTRY_T *ptr_cnt);

/**
 * @brief This API is used to clear RS-FEC error distribution counter value.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_clearRsErrDistCnt(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to set RS-FEC error distribution counter polling interval.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     interval    - polling interval (unit: microsecond)
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_setRsErrDistCntInterval(const UI32_T unit, const UI32_T interval);

/**
 * @brief This API is used to analyze debug counter.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     input_port         - Physical port of packet be sent from
 * @param [in]     output_portlist    - Physical portlist of packet be sent to
 * @param [in]     type               - Debug type and please align
 * HAL_LT_LIGHTNING_STAT_DBG_ANALYZE_TYPE
 * @param [in]     lbk_dst_port       - Physical port of packet be sent to after loopback
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_analyzeDbg(const UI32_T unit,
                                 const UI32_T input_port,
                                 const CLX_PORT_BITMAP_T output_portlist,
                                 const UI32_T type,
                                 const UI32_T lbk_dst_port);

/**
 * @brief This API is used to analyze debug counter of snake topology.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_portlist    - portlist in the order based on the topology of user
 * @param [in]     wire            - 1: user use wire;0: user use loopback
 * @param [in]     bi_dir          - 1: if wire=1, the portlist in the order is for bidirection
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_analyzeSnakeDbg(const UI32_T unit,
                                      const C8_T *ptr_portlist,
                                      const UI32_T wire,
                                      const UI32_T bi_dir);

/**
 * @brief This API is used to get PP counter HW index using SW index
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     sw_cnt_id         - SW counter id
 * @param [in]     cnt_type          - counter type
 * @param [in]     pp_obj_type       - PP binding object type
 * @param [out]    ptr_hw_cnt_idx    - HW counter idx
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_TABLE_FULL         - No available HW resource
 * @return         CLX_E_ENTRY_NOT_FOUND    - The SW counter has not been created.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getCntHWIdx(const UI32_T unit,
                                  const UI32_T sw_cnt_id,
                                  const HAL_STAT_HW_TYPE_T cnt_type,
                                  const HAL_STAT_PP_OBJ_TYPE_T pp_obj_type,
                                  UI32_T *ptr_hw_cnt_idx);

/**
 * @brief To get a PP HW counter bank Id and corresponding index Id
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     hw_cnt_id                  - HW counter Id
 * @param [in]     mode                       - Counter mode
 * @param [out]    ptr_bank_id                - The HW bank Id of the corresponding counter
 * @param [out]    ptr_sw_bmap_idx_of_bank    - The index the corresponding counter in the bank
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getPpBankId(const UI32_T unit,
                                  const UI32_T hw_cnt_id,
                                  const CLX_STAT_CNT_MODE_T mode,
                                  UI32_T *ptr_bank_id,
                                  UI32_T *ptr_sw_bmap_idx_of_bank);

/**
 * @brief This API is used to get TM queue counter index by TM handler.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     handler    - The handler of TM queue
 * @param [out]    ptr_idx    - Queue counter index
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_lightning_stat_getTmQueueCntIdx(const UI32_T unit,
                                       const CLX_TM_HANDLER_T handler,
                                       UI32_T *ptr_idx);
#endif /* End of HAL_LT_LIGHTNING_STAT_H */
