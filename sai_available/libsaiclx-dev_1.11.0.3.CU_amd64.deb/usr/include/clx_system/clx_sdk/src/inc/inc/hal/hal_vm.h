/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_vm.h
 * PURPOSE:
 *      It provide vm module hal level api.
 * NOTES:
 *  Description
 */

#ifndef HAL_VM_H
#define HAL_VM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <hal/hal_const_cmn.h>
#include <hal/hal_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_VM_VID_INFO_FLAGS_IS_L2_UC (1U << 0)

/* MACRO FUNCTION DECLARATIONS
 */
/* Hw-view to user-view : will not extend, can be full mapped */
#define HAL_VM_PORT_MODE_TO_VM_MODE(__port_mode__)   (_hal_vm_mode_map[(__port_mode__)])
#define HAL_VM_PORT_MODE_TO_VM_TYPE(__port_mode__)   (_hal_vm_type_map[(__port_mode__)])
#define HAL_VM_PORT_MODE_TO_PORT_ROLE(__port_mode__) (_hal_vm_port_role_map[(__port_mode__)])

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_VM_PORT_ROLE_EXT,
    HAL_VM_PORT_ROLE_CAS,
    HAL_VM_PORT_ROLE_UPS,
} HAL_VM_PORT_ROLE_T;

/* LOCAL SUBPROGRAM BODIES
 */
extern CLX_VM_MODE_T _hal_vm_mode_map[14];
extern CLX_VM_TAG_TYPE_T _hal_vm_type_map[14];
extern HAL_VM_PORT_ROLE_T _hal_vm_port_role_map[14];

/**
 * @brief initialize the vm module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - initialize success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - initialize failed
 */
CLX_ERROR_NO_T
hal_vm_init(const UI32_T unit);

/**
 * @brief Deinitialize the vm module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Deinitialization success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Deinitialization failed.
 */
CLX_ERROR_NO_T
hal_vm_deinit(const UI32_T unit);

#if defined(CLX_EN_VM)
/**
 * @brief dump vm swdb
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     flags    - SWDB option
 * @return    CLX_E_
 */
CLX_ERROR_NO_T
hal_vm_dumpDb(const UI32_T unit, const UI32_T flags);

/**
 * @brief Set chip vm mode.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     mode    - Chip virtual machine mode
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHER            - Operate failed.
 */
CLX_ERROR_NO_T
hal_vm_setVmMode(const UI32_T unit, const CLX_VM_MODE_T mode);

/**
 * @brief Get chip vm mode.
 *
 * @param [in]     unit        - Device unit number
 * @param [out]    ptr_mode    - Chip virtual machine mode
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHER            - Operate failed.
 */
CLX_ERROR_NO_T
hal_vm_getVmMode(const UI32_T unit, CLX_VM_MODE_T *ptr_mode);

/**
 * @brief This API is used to create a VM interface object for component port, vm tag type and vm
 * id. Because only cascade port and upstream port need to separate multiple vm id. Extented port is
 * not longer used to create interface object.
 *
 * 1. User should guarantee port type consist with vm_type.
 * 2. User should guarantee port_lag_intf has at least one port in current unit.
 * 3. User should never create vm interface object with an extended port.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Native port/unit port/LAG port
 * @param [in]     vm_id          - VM id
 * @param [in]     vm_type        - VM tag type
 * @param [out]    ptr_vm_port    - VM port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
hal_vm_createPort(const UI32_T unit,
                  const CLX_PORT_T port,
                  const CLX_VM_ID_T vm_id,
                  const CLX_VM_TAG_TYPE_T vm_type,
                  CLX_PORT_T *ptr_vm_port);

/**
 * @brief This API is used to destroy a VM interface object.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     vm_port    - VM port
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
CLX_ERROR_NO_T
hal_vm_destroyPort(const UI32_T unit, const CLX_PORT_T vm_port);

/**
 * @brief This API is used to get a VM port.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Port or LAG port
 * @param [in]     vm_id          - VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 * @param [in]     vm_type        - VM type
 * @param [out]    ptr_vm_port    - VM port
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - VM port is not created.
 */
CLX_ERROR_NO_T
hal_vm_getPort(const UI32_T unit,
               const CLX_PORT_T port,
               const CLX_VM_ID_T vm_id,
               const CLX_VM_TAG_TYPE_T vm_type,
               CLX_PORT_T *ptr_vm_port);

/**
 * @brief This API is used to get keys of a VM port.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     vm_port        - VM port
 * @param [out]    ptr_port       - Port or LAG port
 * @param [out]    ptr_vm_id      - VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 * @param [out]    ptr_vm_type    - VM type
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - VM port is not created or is destroyed.
 */
CLX_ERROR_NO_T
hal_vm_getKey(const UI32_T unit,
              const CLX_PORT_T vm_port,
              CLX_PORT_T *ptr_port,
              CLX_VM_ID_T *ptr_vm_id,
              CLX_VM_TAG_TYPE_T *ptr_vm_type);

/**
 * @brief Set upstream port for downstream port.
 *
 * 1. Should set chip vm mode to PE/IV first.
 * 2. The downstream_port must be
 * (1) port/lag port of extended port, or
 * (2) vm port of cascade port.
 * 3. The upstream_port must be port/lag port.
 * 4. Bad parameter conditions
 * (1) vm mode is not pe.
 * (2) given downstream port type is upstream.
 * (3) given upstream port type is not upstream.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     downstream_port    - Downstream port
 * @param [in]     upstream_port      - Upstream port
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_setUpstreamPort(const UI32_T unit,
                       const CLX_PORT_T downstream_port,
                       const CLX_PORT_T upstream_port);

/**
 * @brief Get upstream port for given downstream port.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     downstream_port      - Downstream port
 * @param [out]    ptr_upstream_port    - Upstream port
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_getUpstreamPort(const UI32_T unit,
                       const CLX_PORT_T downstream_port,
                       CLX_PORT_T *ptr_upstream_port);

/**
 * @brief Set upstream port for downstream port.
 *
 * 1. Should set chip vm mode to PE/IV first.
 * 2. The downstream_port must be
 * (1) port/lag port of extended port, or
 * (2) vm port of cascade port.
 * 3. Bad parameter conditions
 * (1) vm mode is not pe.
 * (2) given downstream port type is upstream.
 * (3) given upstream port type is not upstream.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     downstream_port    - Downstream port
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_resetUpstreamPort(const UI32_T unit, const CLX_PORT_T downstream_port);

/**
 * @brief Set VM related port properties such as
 *        vm port type, vm check fail action, vm rpf fail action... etc
 *
 * 1. Not support per port-based remove vepa tag.
 * Setting remove-egress vepa tag per forwarding entry.
 * 2. Only support per system-based tag_miss_action. (last will cover first)
 * 3. Only support per system-based rpf_fail_action. (last will cover first)
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Native port/unit port
 * @param [in]     ptr_prty    - VM related port property
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_setPortProperty(const UI32_T unit,
                       const CLX_PORT_T port,
                       const CLX_VM_PORT_PRTY_T *ptr_prty);

/**
 * @brief This API is used to get port property which providing VM function for the port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Native port or port interface object
 * @param [out]    ptr_prty    - VM related port property
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_getPortProperty(const UI32_T unit, const CLX_PORT_T port, CLX_VM_PORT_PRTY_T *ptr_prty);

/**
 * @brief Add an unicast entry in PE/IV.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - Unicast entry
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_pe_addUcastAddr(const UI32_T unit, const CLX_VM_PE_UCAST_ADDR_T *ptr_addr);

/**
 * @brief Delete an unicast entry in PE/IV.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - Unicast entry
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_pe_delUcastAddr(const UI32_T unit, const CLX_VM_PE_UCAST_ADDR_T *ptr_addr);

/**
 * @brief Get an unicast entry in PE/IV.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_addr    - Unicast entry,output the fields.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_pe_getUcastAddr(const UI32_T unit, CLX_VM_PE_UCAST_ADDR_T *ptr_addr);

/**
 * @brief Add a multicast entry in PE/IV.
 *
 * 1. Neither check src_port is upstream port nor vm type consistent or not.
 * Such entry will not be hit and user should not insert it.
 * 2. User should allocate mcast_id by L2 API before add mcast address.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_addr    - Multicast entry.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_pe_addMcastAddr(const UI32_T unit, const CLX_VM_PE_MCAST_ADDR_T *ptr_addr);

/**
 * @brief Delete a multicast entry in PE/IV.
 *
 * Neither check src_port is upstream port nor vm type consistent or not.
 * Such entry will not be hit and user should not insert it.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_addr    - Multicast entry.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_pe_delMcastAddr(const UI32_T unit, const CLX_VM_PE_MCAST_ADDR_T *ptr_addr);

/**
 * @brief Get a multicast entry in PE/IV.
 *
 * @param [in]     unit        - Device unit number
 * @param [out]    ptr_addr    - Result parts of multicast entry
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_pe_getMcastAddr(const UI32_T unit, CLX_VM_PE_MCAST_ADDR_T *ptr_addr);

/**
 * @brief This API is used to add interface of a port combined with multicast vm id, and
 *        set related interface properties.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - Native port or port interface object
 * @param [in]     vm_id           - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type         - VM type
 * @param [in]     ptr_property    - Interface property
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
hal_vm_addMcastIntfProperty(const UI32_T unit,
                            const CLX_PORT_T port,
                            const CLX_VM_ID_T vm_id,
                            const CLX_VM_TAG_TYPE_T vm_type,
                            const CLX_PORT_INTF_PROPERTY_T *ptr_property);

/**
 * @brief This API is used to delete interface of a port combined with multicast vm id.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Native port or port interface object
 * @param [in]     vm_id      - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type    - VM type
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not exists.
 */
CLX_ERROR_NO_T
hal_vm_delMcastIntfProperty(const UI32_T unit,
                            const CLX_PORT_T port,
                            const CLX_VM_ID_T vm_id,
                            const CLX_VM_TAG_TYPE_T vm_type);

/**
 * @brief This API is used to get interface properties of a port combined with multicast vm id.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - Native port or port interface object
 * @param [in]     vm_id           - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type         - VM type
 * @param [out]    ptr_property    - Interface property
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not exists.
 */
CLX_ERROR_NO_T
hal_vm_getMcastIntfProperty(const UI32_T unit,
                            const CLX_PORT_T port,
                            const CLX_VM_ID_T vm_id,
                            const CLX_VM_TAG_TYPE_T vm_type,
                            CLX_PORT_INTF_PROPERTY_T *ptr_property);

/**
 * @brief This API is used to add service of a port combined multicast vm-id and vlan.
 *        1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *        2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Port
 * @param [in]     vm_id          - 1BR p2mp or NIV vif-list VM id
 * @param [in]     vm_type        - VM type
 * @param [in]     seg0           - Segment parameter 0
 * @param [in]     seg1           - Segment parameter 1
 * @param [in]     ptr_srv        - Service
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
hal_vm_addMcastSegService(const UI32_T unit,
                          const CLX_PORT_T port,
                          const CLX_VM_ID_T vm_id,
                          const CLX_VM_TAG_TYPE_T vm_type,
                          const UI32_T seg0,
                          const UI32_T seg1,
                          const CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief This API is used to delete service of a port combined multicast vm-id and vlan.
 *        1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *        2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port
 * @param [in]     vm_type    - VM type
 * @param [in]     vm_id      - 1BR p2mp or NIV vif-list VM id
 * @param [in]     seg0       - Segment parameter 0
 * @param [in]     seg1       - Segment parameter 1
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
hal_vm_delMcastSegService(const UI32_T unit,
                          const CLX_PORT_T port,
                          const CLX_VM_ID_T vm_id,
                          const CLX_VM_TAG_TYPE_T vm_type,
                          const UI32_T seg0,
                          const UI32_T seg1);

/**
 * @brief This API is used to get service of a port combined multicast vm-id and vlan.
 *        1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *        2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *
 * 1. Only p2mp 1BR/NIV vmid.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port or lag interface object
 * @param [in]     vm_type    - VM type
 * @param [in]     vm_id      - 1BR p2mp or NIV vif-list VM id
 * @param [in]     seg0       - Segment parameter 0
 * @param [in]     seg1       - Segment parameter 1
 * @param [out]    ptr_srv    - Service
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
hal_vm_getMcastSegService(const UI32_T unit,
                          const CLX_PORT_T port,
                          const CLX_VM_ID_T vm_id,
                          const CLX_VM_TAG_TYPE_T vm_type,
                          const UI32_T seg0,
                          const UI32_T seg1,
                          CLX_PORT_SEG_SRV_T *ptr_srv);
#endif /* defined(CLX_EN_VM) */

/* EXPORTED HAL PROGRAMS
 */
/**
 * @brief check vm_id in valid range.
 *
 * @param [in]     vm_id      - vm id (for vntag, consist of p-bit)
 * @param [in]     vm_type    - vm tag type
 * @param [in]     is_p2p     - vm id is p2p or p2mp
 * @return         CLX_E_OK               - VM id is legal.
 * @return         CLX_E_BAD_PARAMETER    - VM id is illegal.
 */
CLX_ERROR_NO_T
hal_vm_checkVmId(const CLX_VM_ID_T vm_id, const CLX_VM_TAG_TYPE_T vm_type, const UI32_T is_p2p);

/**
 * @brief Set system default srv vrf for niv.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     vif_id    - vif id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Operate not support.
 */
CLX_ERROR_NO_T
hal_vm_setNivSrcVif(const UI32_T unit, const UI32_T vif_id);

/**
 * @brief Get system default srv vrf for niv.
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    ptr_vif_id    - Niv src_vif
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Operate not support.
 */
CLX_ERROR_NO_T
hal_vm_getNivSrcVif(const UI32_T unit, UI32_T *ptr_vif_id);

/**
 * @brief Set PE fcoe transit mode.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     enable    - Enable/Disable PE fcoe transit mode
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_setPeFcoeTransMode(const UI32_T unit, const UI32_T enable);

/**
 * @brief Get current PE fcoe transit mode status.
 *
 * @param [in]     unit              - Device unit number
 * @param [out]    ptr_enable        - PE Fcoe transit mode enabled or not
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_getPeFcoeTransMode(const UI32_T unit, UI32_T *ptr_enable);

/**
 * @brief Get per port src_supp_tag.
 *
 * Port/Lag can NOT call this API.
 * Because this api will call port/lag api to get per di sst,
 * will hang if caller is port/lag module.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - uc: vm_port, mc: native port
 * @param [out]    ptr_sst    - source suppression tag
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_getSrcSuppTag(const UI32_T unit, const CLX_PORT_T port, UI32_T *ptr_sst);

/**
 * @brief Get HW vid_ctl/1st/2nd info of vm port.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     vm_port           - VM port
 * @param [in]     vlan_action       - VLAN action
 * @param [in]     ptr_tag_action    - VLAN tag action
 * @param [in]     flags             - Refer HAL_VM_VID_INFO_FLAGS_XXX
 * @param [out]    ptr_info          - HW vlan info
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry doesn't exist
 * @return         CLX_E_BAD_PARAMETER      - Some of inputs are illegal
 */
CLX_ERROR_NO_T
hal_vm_getHwVidInfo(const UI32_T unit,
                    const CLX_PORT_T vm_port,
                    const CLX_VLAN_ACTION_T vlan_action,
                    const CLX_VLAN_TAG_ACTION_T *ptr_tag_action,
                    const UI32_T flags,
                    HAL_VLAN_VID_CTL_T *ptr_info);

/**
 * @brief Get user view vlan-action of vm-port
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     ptr_vid_ctl        - HW vlan info
 * @param [out]    ptr_vlan_action    - VLAN action
 * @param [out]    ptr_tag_action     - VLAN tag action
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry doesn't exist
 * @return         CLX_E_BAD_PARAMETER      - Some of inputs are illegal
 */
CLX_ERROR_NO_T
hal_vm_getSwVidInfo(const UI32_T unit,
                    const HAL_VLAN_VID_CTL_T *ptr_vid_ctl,
                    CLX_VLAN_ACTION_T *ptr_vlan_action,
                    CLX_VLAN_TAG_ACTION_T *ptr_tag_action);

/**
 * @brief Translate VM egress user data to HW info.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - uc: vm_port,    mc: native port
 * @param [in]     vm_type         - uc: don't care, mc: vm tag type
 * @param [in]     vm_id           - uc: don't care, mc: vm id
 *                                   ptr_dst_idx (option) -- uc: di,         mc: NULL
 * @param [out]    ptr_seg_vmid    - seg_vmid value
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_transToHwEgrInfo(const UI32_T unit,
                        const CLX_PORT_T port,
                        const CLX_VM_TAG_TYPE_T vm_type,
                        const UI32_T vm_id,
                        UI32_T *ptr_dst_idx,
                        UI32_T *ptr_seg_vmid);

/**
 * @brief Translate VM egress HW data to SW info.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     dst_idx        - dest idx
 * @param [in]     port_mode      - hw vm port mode
 * @param [in]     seg_vmid       - seg_vmid
 * @param [out]    ptr_vm_port    - uc: vm_port, mc: NULL
 * @param [out]    ptr_vm_id      - uc: NULL,    mc: vm id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vm_transToSwEgrInfo(const UI32_T unit,
                        const UI32_T dst_idx,
                        const HAL_VM_PORT_MODE_ENUM_T port_mode,
                        const UI32_T seg_vmid,
                        CLX_PORT_T *ptr_vm_port,
                        UI32_T *ptr_vm_id);

/**
 * @brief Get vm port mode by dst_idx.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     dst_idx          - dst_idx
 * @param [out]    ptr_port_mode    - hw defined vm port mode
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter if vm mode is not CB_XXX.
 */
CLX_ERROR_NO_T
hal_vm_getPortMode(const UI32_T unit, const UI32_T dst_idx, HAL_VM_PORT_MODE_ENUM_T *ptr_port_mode);

/**
 * @brief Check service idx belongs to vm upstream scenario used.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     srv_idx    - hw service idx
 * @return         CLX_E_OK                 - Is vm upstream service.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Not vm upstream service.
 */
CLX_ERROR_NO_T
hal_vm_checkIsUpstreamSrv(const UI32_T unit, const UI32_T srv_idx);

#endif /* HAL_VM_H */