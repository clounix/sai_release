/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME: dcc_lamp_sock.h
 * PURPOSE:
 *  1. Provide the interface of DCC to set MMIO.
 *
 * NOTE:
 *
 */
#ifndef DCC_LAMP_SOCK_H
#define DCC_LAMP_SOCK_H

/* INCLUDE FILE DECLARATONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <dcc/dcc.h>
#include <dcc/dcc_dma.h>
#include <dcc/lamp/sock/dcc_lamp_msg.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define DCC_LAMP_SOCK_IO_CMD_WORD_SIZE   (10)
#define DCC_LAMP_SOCK_IO_BUF_BYTE_SIZE   (MAX_ENTRY_SIZE)
#define DCC_LAMP_SOCK_IO_BUF_WORD_SIZE   (DCC_LAMP_SOCK_IO_BUF_BYTE_SIZE / sizeof(UI32_T))
#define DCC_LAMP_SOCK_TDMA_CMD_WORD_SIZE (8)
#define DCC_LAMP_SOCK_SDMA_CMD_WORD_SIZE (8)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* IO Descriptor Definition */
typedef struct {
    /* word_0 */
    UI32_T cmd_addr;
    /* word_1 */
    UI32_T cmd_len : 8;
    UI32_T cmd_opt : 8;
    UI32_T cmd_op : 8;
    UI32_T cmd_sn : 8;
    /* word_2 */
    UI32_T hash_rslt_len : 8;
    UI32_T : 24;
    /* word_3~7 */
    UI32_T rsv[5];
    /* word_8 */
    UI32_T rsp_len : 8;
    UI32_T rsp_status : 8;
    UI32_T rsp_code : 8;
    UI32_T rsp_sn : 8;
    /* word_9 */
    UI32_T rsp_data;
    /* word_10~73 */
    UI32_T data_buf[DCC_LAMP_SOCK_IO_BUF_WORD_SIZE];
} DCC_LAMP_SOCK_IO_FIELD_T;

typedef union {
    UI32_T reg[DCC_LAMP_SOCK_IO_CMD_WORD_SIZE + DCC_LAMP_SOCK_IO_BUF_WORD_SIZE];
    DCC_LAMP_SOCK_IO_FIELD_T field;
} DCC_LAMP_SOCK_IO_DSCP_T;

/* DMA Descriptor Definition */
typedef struct {
    /* word_0 */
    UI32_T host_addr_low;
    /* word_1 */
    UI32_T host_addr_high;
    /* word_2 */
    UI32_T dev_addr;
    /* word_3 */
    UI32_T doffs : 12;
    UI32_T : 4;
    UI32_T dbeat : 8;
    UI32_T mode_setting : 8;
    /* word_4 */
    UI32_T num : 16;
    UI32_T error_code : 8;
    UI32_T status : 8;
    /* word_5 */
    UI32_T rsv;
    /* word_6 */
    UI32_T host_status_addr_low;
    /* word_7 */
    UI32_T host_status_addr_high;
} DCC_LAMP_SOCK_TDMA_FIELD_T;

typedef union {
    UI32_T reg[DCC_LAMP_SOCK_TDMA_CMD_WORD_SIZE];
    DCC_LAMP_SOCK_TDMA_FIELD_T field;
} DCC_LAMP_SOCK_TDMA_DSCP_T;

/* Calendar DMA Definition */
typedef struct {
    /* word_0 */
    UI32_T calendar_id : 16;
    UI32_T rsv_0 : 8;
    UI32_T cmd : 8;
    /* word_1 */
    UI32_T task_id : 16;
    UI32_T rsv_1 : 16;
    /* word_2 */
    UI32_T host_addr_low;
    /* word_3 */
    UI32_T host_addr_high;
    /* word_4 */
    UI32_T dev_addr;
    /* word_5 */
    UI32_T doffs : 8;
    UI32_T : 8;
    UI32_T dbeat : 8;
    UI32_T mode_setting : 8;
    /* word_6 */
    UI32_T num : 16;
    UI32_T error_code : 8;
    UI32_T status : 8;
    /* word_7 */
    UI32_T rsv_2;
} DCC_LAMP_SOCK_SDMA_FIELD_T;

typedef union {
    UI32_T reg[DCC_LAMP_SOCK_SDMA_CMD_WORD_SIZE];
    DCC_LAMP_SOCK_SDMA_FIELD_T field;
} DCC_LAMP_SOCK_SDMA_DSCP_T;

typedef struct {
    UI32_T unit;
    UI32_T plane;
    UI32_T data_len;
    void *ptr_data;
    HAL_ISR_HANDLE_FUNC_T handler;
    UI32_T cookie;
    BOOL_T is_done;
} DCC_LAMP_SOCK_PDMA_DSCP_T;

/* DCC LAMP Control Block Definition */
typedef struct {
    DCC_LAMP_SOCK_IO_DSCP_T io_dscp;
    DCC_LAMP_SOCK_TDMA_DSCP_T tdma_h2d_dscp;
    DCC_LAMP_SOCK_TDMA_DSCP_T tdma_d2h_dscp;
    DCC_LAMP_SOCK_TDMA_DSCP_T tdma_d2d_dscp;
    DCC_LAMP_SOCK_SDMA_DSCP_T sdma_dscp;
    DCC_LAMP_SOCK_PDMA_DSCP_T pdma_tx_dscp;
    DCC_LAMP_SOCK_PDMA_DSCP_T pdma_rx_dscp;

    UI32_T cld_list[DCC_CLD_MAX_TASK];
    DCC_LAMP_SOCK_SDMA_DSCP_T task_list[DCC_CLD_MAX_TASK];
    UI32_T cld_exp;
    UI32_T cld_period;
    BOOL_T cld_en;
    BOOL_T cld_repeat;
    UI32_T cld_interval; /* cld_period*2^cld_exp */
    UI32_T cld_count;
    UI32_T *ptr_sdma_status;

    UI32_T chn_fd_list[DCC_LAMP_MSG_CHN_TYPE_LAST];
    UI32_T chn_log_list[DCC_LAMP_MSG_CHN_TYPE_LAST];
    UI32_T chn_sn_list[DCC_LAMP_MSG_CHN_TYPE_LAST];
    CLX_SEMAPHORE_ID_T pdma_sem_id;
    CLX_SEMAPHORE_ID_T sdma_sem_id;
} DCC_LAMP_SOCK_CB_T;

typedef enum {
    DCC_LAMP_SOCK_CMDL_CTL_RST = 0,
    DCC_LAMP_SOCK_CMDL_CTL_RUN,
    DCC_LAMP_SOCK_CMDL_CTL_LAST
} DCC_LAMP_SOCK_CMDL_CTL_T;

typedef struct {
    UI32_T ctl_fd;
    DCC_LAMP_SOCK_CMDL_CTL_T ctl_op;
    UI32_T ctl_sn;
    CLX_SEMAPHORE_ID_T ctl_sem_id;
    C8_T *ptr_pkt_path;
    BOOL_T is_done;
} DCC_LAMP_SOCK_CMDL_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief 1. Initialize the MMIO shadow buffer
 *        2. Initialize the DCE thread to maintain shadow buffer and communicate with LAMP
 *
 * @param [in]     unit    - number of ASIC
 * @return         CLX_E_OK                - operate successfully
 * @return         CLX_E_BAD_PARAMETER     - fail due to bad parameters
 * @return         CLX_E_NO_MEMORY         - fail due to no memory
 * @return         CLX_E_ALREADY_INITED    - fail due to multiple initializations
 * @return         CLX_E_OTHERS            - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_init(const UI32_T unit);

/**
 * @brief 1. Deinit the MMIO shadow buffer
 *        2. Deinit the DCE thread
 *
 * @param [in]     unit    - number of ASIC
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_NOT_INITED       - fail due to no initialization
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_deinit(const UI32_T unit);

/**
 * @brief 1. Set the cmodel server's name or ip address to connect
 *
 * @param [in]     ptr_svr_addr    - the host name or ip of cmodel server
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 */
CLX_ERROR_NO_T
dcc_lamp_sock_setSvrAddr(const C8_T *ptr_svr_addr);

/**
 * @brief 1. Read the MMIO IO register content
 *
 * @param [in]     unit           - number of ASIC
 * @param [in]     addr_offset    - address of register to be read
 * @param [in]     data_len       - length to be read
 * @param [out]    ptr_data       - pointer to read content
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_readIoReg(const UI32_T unit,
                        const UI32_T addr_offset,
                        UI32_T *ptr_data,
                        const UI32_T data_len);

/**
 * @brief 1. Read the MMIO D2D DMA register content
 *
 * @param [in]     unit           - number of ASIC
 * @param [in]     addr_offset    - address of register to be write
 * @param [in]     ptr_data       - pointer to written content
 * @param [in]     data_len       - length to be read
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_readTblDmaD2dReg(const UI32_T unit,
                               const UI32_T addr_offset,
                               UI32_T *ptr_data,
                               const UI32_T data_len);

/**
 * @brief 1. Write the MMIO IO register content
 *
 * @param [in]     unit           - number of ASIC
 * @param [in]     addr_offset    - address of register to be write
 * @param [in]     ptr_data       - pointer to written content
 * @param [in]     data_len       - length to be write
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_writeIoReg(const UI32_T unit,
                         const UI32_T addr_offset,
                         const UI32_T *ptr_data,
                         const UI32_T data_len);

/**
 * @brief 1. Write the MMIO H2D DMA register content
 *
 * @param [in]     unit           - number of ASIC
 * @param [in]     addr_offset    - address of register to be write
 * @param [in]     ptr_data       - pointer to written content
 * @param [in]     data_len       - length to be write
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_writeTblDmaH2dReg(const UI32_T unit,
                                const UI32_T addr_offset,
                                const UI32_T *ptr_data,
                                const UI32_T data_len);

/**
 * @brief 1. Write the MMIO D2H DMA register content
 *
 * @param [in]     unit           - number of ASIC
 * @param [in]     addr_offset    - address of register to be write
 * @param [in]     ptr_data       - pointer to written content
 * @param [in]     data_len       - length to be write
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_writeTblDmaD2hReg(const UI32_T unit,
                                const UI32_T addr_offset,
                                const UI32_T *ptr_data,
                                const UI32_T data_len);

/**
 * @brief 1. Write the MMIO D2D DMA register content
 *
 * @param [in]     unit           - number of ASIC
 * @param [in]     addr_offset    - address of register to be write
 * @param [in]     ptr_data       - pointer to written content
 * @param [in]     data_len       - length to be write
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_writeTblDmaD2dReg(const UI32_T unit,
                                const UI32_T addr_offset,
                                const UI32_T *ptr_data,
                                const UI32_T data_len);

/**
 * @brief 1. Write the MMIO Calendar DMA register content
 *
 * @param [in]     unit           - number of ASIC
 * @param [in]     addr_offset    - address of register to be write
 * @param [in]     ptr_data       - pointer to written content
 * @param [in]     data_len       - length to be write
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_writeCldDmaReg(const UI32_T unit,
                             const UI32_T addr_offset,
                             const UI32_T *ptr_data,
                             const UI32_T data_len);

/**
 * @brief 1. Send the packet to CMODEL
 *
 * @param [in]     unit       - number of ASIC
 * @param [in]     plane      - number of plane in chip
 * @param [in]     ptr_pkt    - pointer to sent content
 * @param [in]     pkt_len    - length to be sent
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_txPkt(const UI32_T unit,
                    const UI32_T plane,
                    const void *ptr_pkt,
                    const UI32_T pkt_len);

/**
 * @brief 1. Receive the packet from CMODEL
 *
 * @param [in]     unit           - number of ASIC
 * @param [in]     ptr_pkt        - pointer to received content
 * @param [in]     ptr_pkt_len    - length to be received
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_NO_MEMORY        - fail due to no memory
 */
CLX_ERROR_NO_T
dcc_lamp_sock_rxPkt(const UI32_T unit, void *ptr_pkt, UI32_T *ptr_pkt_len);

/**
 * @brief 1. Register the rx packet event handler
 *
 * @param [in]     unit       - number of ASIC
 * @param [in]     handler    - the handler function for the event
 * @param [in]     cookie     - the parameter of the handler function when event occurs
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_regRxPktEvent(const UI32_T unit,
                            const HAL_ISR_HANDLE_FUNC_T handler,
                            const UI32_T cookie);

/**
 * @brief 1. Send the packet to CMODEL
 *
 * @return         CLX_E_OK        - operate successfully
 * @return         CLX_E_OTHERS    - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_rstCmdl(void);

/**
 * @brief 1. Triger C-Model to inpute the packets from specified directory
 *
 * @param [in]     ptr_pkt_path    - input directory path at C-Model view
 * @return         CLX_E_OK               - operate successfully
 * @return         CLX_E_BAD_PARAMETER    - fail due to bad parameters
 * @return         CLX_E_OTHERS           - fail due to internal error
 */
CLX_ERROR_NO_T
dcc_lamp_sock_runCmdl(const C8_T *ptr_pkt_path);

#endif
