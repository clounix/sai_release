/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_acl.h
 * PURPOSE:
 *    Provide HAL driver API functions of ACL module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_ACL_H
#define HAL_MT_ACL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_acl.h>
#include <hal/hal_l3.h>
#include <hal/hal_cmn.h>
#include <hal/hal_acl.h>
#include <hal/hal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_ACL_PLANE_PORT_BITS                (32)
#define HAL_MT_ACL_FLW_L2_DA_SA_LBL_BITS          (10)
#define HAL_MT_ACL_DA_SA_LBL_BITS                 (16)
#define HAL_MT_ACL_UDF_INT_INTF_LBL_BITS          (16)
#define HAL_MT_ACL_UDF_INT_IGR_ACL_LABEL_BITS     (16)
#define HAL_MT_ACL_UDF_INT_TCP_FLAG_BITS          (12)
#define HAL_MT_ACL_UDF_INT_VID_BITS               (12)
#define HAL_MT_ACL_UDF_INT_PCP_DEI_BITS           (4)
#define HAL_MT_ACL_UDF_KEY_BITS                   (200)
#define HAL_MT_ACL_FLW_KEY_BITS                   (140)
#define HAL_MT_ACL_UDF_PKG_BITS                   (8)
#define HAL_MT_ACL_UDF_PROFILE_ID_BITS            (6)
#define HAL_MT_ACL_FLW_PKG_PROF_TLV_LST_WORDS_MAX (12)
#define HAL_MT_ACL_PKG_PROF_TLV_LST_WORDS_MAX     (24)
#define HAL_MT_ACL_KEY_1X_WORDS                   (14)
#define HAL_MT_ACL_BASEKEY_L3_WORDS_MAX           (HAL_MT_ACL_KEY_1X_WORDS * 2)
#define HAL_MT_ACL_BASEKEY_WORDS_MAX              (HAL_MT_ACL_KEY_1X_WORDS * 3)
#define HAL_MT_ACL_ACTION_NUM_MAX                 (4)
#define HAL_MT_ACL_KEY_WIDTH_MAX                  (4)
#define HAL_MT_ACL_FLOW_ACTION_NUM_MAX            (2)
#define HAL_MT_ACL_TILE_REGTION_SIZE              (8)
#define HAL_MT_ACL_BASE_LABEL_REPLACE_SA          (1U << 0)
#define HAL_MT_ACL_BASE_LABEL_REPLACE_DA          (1U << 1)
#define HAL_MT_ACL_IGR_ACL_GROUP_LABEL_MAX        (0xF000)
#define HAL_MT_ACL_ACTION_OFFSET                  (HAL_MT_ACL_KEY_WIDTH_MAX * HAL_MT_ACL_KEY_1X_WORDS)
#define HAL_MT_ACL_ACTION_QOS_PROF_PCP_DEI_VLD    (1U << 0)
#define HAL_MT_ACL_ACTION_QOS_PROF_EXP_VLD        (1U << 1)
#define HAL_MT_ACL_ACTION_QOS_PROF_DSCP_VLD       (1U << 2)
#define HAL_MT_ACL_ACTION_FCM_INST_MAX            (6)
#define HAL_MT_ACL_ACTION_FCM_BYTE_CNT_MAX        (4)
#define HAL_MT_ACL_ACTION_FCM_ENABLE              (0xF003)
#define HAL_MT_ACL_ACTION_TEML_IOAM_DELAY_BIT     (2)
#define HAL_MT_ACL_ACTION_TEML_IOAM_ENABLE_BIT    (1)
#define HAL_MT_ACL_ACTION_FWD_MASK_SOURCE_PRUNE   (0x03)
#define HAL_MT_ACL_ACTION_FWD_MASK_TTL            (0x1C)
#define HAL_MT_ACL_ACTION_FWD_MASK_RPF            (0x3E0)
#define HAL_MT_ACL_ACTION_TYPE_SRV_CNT            (7)
#define HAL_MT_ACL_ACTION_TYPE_SRV_CNT2           (8)
#define HAL_MT_ACL_PGK_TLV_BYTE_OFF_MAX           (215) /* 0-215 */

#define HAL_MT_ACL_SAMPLER_VALUE_DEFAULT_VALUE     (0xDEADBEEF)
#define HAL_MT_ACL_SAMPLER_TAPS_DEFAULT_VALUE      (0x80200003)
#define HAL_MT_ACL_SAMPLER_THRESHOLD_DEFAULT_VALUE (0)

#define HAL_MT_ACL_FLW_L2_DA_SA_LBL_FLD(__data__) \
    ((__data__) & HAL_ACL_UI32_MSK(HAL_MT_ACL_FLW_L2_DA_SA_LBL_BITS))
#define HAL_MT_ACL_UNPACK_ICMP_TYPE(__icmp_type__) ((__icmp_type__) >> 8)
#define HAL_MT_ACL_UNPACK_ICMP_CODE(__icmp_code__) (((__icmp_code__)) & 0xFF)
#define HAL_MT_ACL_UNPACK_IGMP_TYPE(__igmp_type__) ((__igmp_type__) >> 8)
#define HAL_MT_ACL_UCP_CFG_ENTRY_IDX(__frm_typ__)  ((__frm_typ__) * HAL_ACL_PER_UCP_FRM_TYPE_CFG_NUM)

#define HAL_MT_ACL_PACK_ICMP_TYPE_CODE(__icmp_type__, __icmp_code__) \
    (((UI32_T)((__icmp_type__) & 0xFF) << 8) + (((__icmp_code__) & 0xFF)))
#define HAL_MT_ACL_PACK_IGMP_TYPE(__igmp_type__) ((UI32_T)((__igmp_type__) & 0xFF) << 8)
#define HAL_MT_ACL_PACK_DA_SA_GROUP_LBL(__sa_lbl__, __da_lbl__)                                    \
    ((((__da_lbl__) & HAL_ACL_UI32_MSK(HAL_MT_ACL_DA_SA_LBL_BITS)) << HAL_MT_ACL_DA_SA_LBL_BITS) | \
     ((__sa_lbl__) & HAL_ACL_UI32_MSK(HAL_MT_ACL_DA_SA_LBL_BITS)))

#define HAL_MT_ACL_UNPACK_DA_SA_GROUP_LBL(__sa_lbl__, __da_lbl__, __data__)        \
    do {                                                                           \
        (__da_lbl__) = (__data__) >> (HAL_MT_ACL_DA_SA_LBL_BITS) &                 \
            HAL_ACL_UI32_MSK(HAL_MT_ACL_DA_SA_LBL_BITS);                           \
        (__sa_lbl__) = (__data__) & (HAL_ACL_UI32_MSK(HAL_MT_ACL_DA_SA_LBL_BITS)); \
    } while (0)

#define HAL_MT_ACL_PACK_LOU_KEY(__profile_idx__, __acl_lou_en__) \
    ((__profile_idx__) | (__acl_lou_en__) << 6)

#define HAL_MT_ACL_UNPACK_LOU_KEY(__profile_idx__, __acl_lou_en__, __data__)               \
    do {                                                                                   \
        (__profile_idx__) = (__data__) & HAL_ACL_UI32_MSK(HAL_MT_ACL_UDF_PROFILE_ID_BITS); \
        (__acl_lou_en__) = ((__data__) >> HAL_MT_ACL_UDF_PROFILE_ID_BITS) &                \
            HAL_ACL_UI32_MSK(HAL_ACL_UDF_INT_LOU_BITS);                                    \
    } while (0)

#define HAL_MT_ACL_GROUP_LOGICAL_2_PHYSICAL(__unit__, __type__, __group__) \
    ((__type__ == CLX_ACL_GROUP_INGRESS) ?                                 \
         (__group__) :                                                     \
         ((__group__) + PTR_HAL_CONST_INFO(__unit__, acl)->igr_group_num))

#define HAL_MT_ACL_UCP_LOGICAL_2_PHYSICAL(__unit__, __type__, __ucp_idx__) \
    ((__type__ == CLX_ACL_GROUP_INGRESS) ?                                 \
         (__ucp_idx__) :                                                   \
         ((__ucp_idx__) + PTR_HAL_CONST_INFO(__unit__, acl)->igr_ucp_num))

#define HAL_MT_ACL_GET_PHYSICAL_TILE_REGION_FLD(__base__, __ucp__) (__base__ + (__ucp__ + 1) / 9)

#define HAL_MT_ACL_GET_UCP_NUM(__ptr_acl_const__, __type__, __ucp_num__) \
    do {                                                                 \
        if (CLX_ACL_GROUP_INGRESS == __type__) {                         \
            __ucp_num__ = (ptr_acl_const->igr_ucp_num);                  \
        } else if (CLX_ACL_GROUP_EGRESS == __type__) {                   \
            __ucp_num__ = (ptr_acl_const->egr_ucp_num);                  \
        } else if (CLX_ACL_GROUP_INGRESS_POST == __type__) {             \
            __ucp_num__ = (ptr_acl_const->igr_post_ucp_num);             \
        } else if (CLX_ACL_GROUP_EGRESS_POST == __type__) {              \
            __ucp_num__ = (ptr_acl_const->egr_post_ucp_num);             \
        }                                                                \
    } while (0)

#define HAL_MT_ACL_GET_ALLOC_IDX(__unit__, __type__, __alloc_idx__) \
    do {                                                            \
        if (HAL_ACL_IS_DUAL_RESOURCE(unit)) {                       \
            if ((__type__ == CLX_ACL_GROUP_INGRESS_POST) ||         \
                (__type__ == CLX_ACL_GROUP_EGRESS_POST)) {          \
                __alloc_idx__ = 1;                                  \
            } else if (((__type__ == CLX_ACL_GROUP_INGRESS) ||      \
                        (__type__ == CLX_ACL_GROUP_EGRESS))) {      \
                __alloc_idx__ = 0;                                  \
            }                                                       \
        }                                                           \
    } while (0)

#define HAL_MT_ACL_GET_BCAST_IDX(__unit__, __bcast_idx__, __type__, __bcast_idx_by_type__)        \
    do {                                                                                          \
        if (((__type__ == CLX_ACL_GROUP_INGRESS_POST) ||                                          \
             (__type__ == CLX_ACL_GROUP_EGRESS_POST)) &&                                          \
            (__bcast_idx__ == CDB_INST_IDX_BCAST)) {                                              \
            __bcast_idx_by_type__ = CDB_ODD_INST_IDX_BCAST;                                       \
        } else if (((__type__ == CLX_ACL_GROUP_INGRESS) || (__type__ == CLX_ACL_GROUP_EGRESS)) && \
                   (__bcast_idx__ == CDB_INST_IDX_BCAST) &&                                       \
                   (HAL_IS_DEVICE_NAMCHABARWA_12_8T_FAMILY(__unit__))) {                          \
            __bcast_idx_by_type__ = CDB_EVEN_INST_IDX_BCAST;                                      \
        } else {                                                                                  \
            __bcast_idx_by_type__ = __bcast_idx__;                                                \
        }                                                                                         \
    } while (0)

#define HAL_MT_ACL_GET_TILE_REGION_FLD(__type__, __tile_region_fld__)                          \
    do {                                                                                       \
        if ((CLX_ACL_GROUP_INGRESS == __type__) || (CLX_ACL_GROUP_INGRESS_POST == __type__)) { \
            __tile_region_fld__ = MT_REG_CIAT_SLV_TILE_REGION_0_ID;                            \
        } else if ((CLX_ACL_GROUP_EGRESS == __type__) ||                                       \
                   (CLX_ACL_GROUP_EGRESS_POST == __type__)) {                                  \
            __tile_region_fld__ = MT_REG_CIAT_SLV_TILE_REGION_3_ID;                            \
        }                                                                                      \
    } while (0)

#define HAL_MT_ACL_GET_ENTRY_TBL_ID(__tbl_id__, __norm_width__) \
    do {                                                        \
        switch ((__norm_width__)) {                             \
            case (1):                                           \
                (__tbl_id__) = MT_TBL_CIAT_CIA_TCAM_UCP_1X_ID;  \
                break;                                          \
            case (2):                                           \
                (__tbl_id__) = MT_TBL_CIAT_CIA_TCAM_UCP_2X_ID;  \
                break;                                          \
            default: /* 4 */                                    \
                (__tbl_id__) = MT_TBL_CIAT_CIA_TCAM_UCP_4X_ID;  \
                break;                                          \
        }                                                       \
    } while (0)

#define HAL_MT_ACL_GET_UCP_VLD_FIELD_ID(__field__, __tbl_id__)         \
    do {                                                               \
        switch ((__tbl_id__)) {                                        \
            case (MT_TBL_CIAT_CIA_TCAM_UCP_1X_ID):                     \
                (__tbl_id__) = MT_CIAT_CIA_TCAM_UCP_1X_VLD_T_FIELD_ID; \
                break;                                                 \
            case (MT_TBL_CIAT_CIA_TCAM_UCP_2X_ID):                     \
                (__tbl_id__) = MT_CIAT_CIA_TCAM_UCP_2X_VLD_T_FIELD_ID; \
                break;                                                 \
            default: /* MT_TBL_CIAT_CIA_TCAM_UCP_4X_ID */              \
                (__tbl_id__) = MT_CIAT_CIA_TCAM_UCP_4X_VLD_T_FIELD_ID; \
                break;                                                 \
        }                                                              \
    } while (0)

#define HAL_MT_ACL_ACTION_CHECK_FCM_BYTE_CNT(__unit__, __idx__, __byte_cnt__, __expe_byte_cnt__) \
    do {                                                                                         \
        if ((__byte_cnt__) != (__expe_byte_cnt__)) {                                             \
            DIAG_PRINT(HAL_DBG_ACL, HAL_DBG_WARN,                                                \
                       "u=%u, rewr-cfg %u, invalid byte_cnt=%u, should be byte_cnt=%u\n",        \
                       (__unit__), (__idx__), (__byte_cnt__), __expe_byte_cnt__);                \
            return CLX_E_BAD_PARAMETER;                                                          \
        }                                                                                        \
    } while (0)

#define IPV6_H_BUF_TO_HW_IPV6(__unit__, __tbl_id__, __fld_id__, __key_buf__, __hw_ipv6__) \
    do {                                                                                  \
        UI32_T __ipv6_buf__[3];                                                           \
                                                                                          \
        osal_memset(__ipv6_buf__, 0, sizeof(__ipv6_buf__));                               \
        cdb_unpackField(__unit__, __tbl_id__, __fld_id__, __key_buf__, __ipv6_buf__);     \
        hw_ipv6[1] = __ipv6_buf__[0];                                                     \
        hw_ipv6[2] = __ipv6_buf__[1];                                                     \
        hw_ipv6[3] = __ipv6_buf__[2];                                                     \
    } while (0)

#if defined(CLX_ASICSIM)
#define HAL_MT_ACL_FAKE_VB_OFFSET (182)
#endif

typedef enum {
    HAL_MT_CIA_KEY_TCAM_L2 = 0,
    HAL_MT_CIA_KEY_TCAM_ARP = 1,
    HAL_MT_CIA_KEY_TCAM_L3_IPV4 = 2,
    HAL_MT_CIA_KEY_TCAM_MPLS = 3,
    HAL_MT_CIA_KEY_TCAM_UDF0 = 4,
    HAL_MT_CIA_KEY_TCAM_UDF1 = 5,
    HAL_MT_CIA_KEY_TCAM_L3_IPV6 = 6
} HAL_MT_CIA_TYP_ENUM_T;

typedef enum {
    HAL_MT_CIA_ACT_PBR_TYPE_MPATH = 0,
    HAL_MT_CIA_ACT_PBR_TYPE_FRC_L3 = 1,
    HAL_MT_CIA_ACT_PBR_TYPE_BD_DI = 2,
    HAL_MT_CIA_ACT_PBR_TYPE_DI_ONLY = 3,
    HAL_MT_CIA_ACT_PBR_TYPE_LAST
} HAL_MT_CAI_ACT_PBR_TYPE_T;

typedef enum {
    HAL_MT_CIA_ACT_FCM_OP_TYPE_NONE = 0,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_ADD_2B = 1,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_ADD_4B = 2,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_DEL_2B = 3,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_DEL_4B = 4,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_SET_2B_MASK = 5,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_SET_4B = 6,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_SET_FIX_OFFSET = 7,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_LAST
} HAL_MT_CIA_ACT_FCM_OP_TYPE_T;

typedef enum {
    HAL_MT_CIA_ACT_FCM_OP_CODE_DMAC_HI = 0,
    HAL_MT_CIA_ACT_FCM_OP_CODE_DMAC_LO = 1,
    HAL_MT_CIA_ACT_FCM_OP_CODE_SMAC_HI = 2,
    HAL_MT_CIA_ACT_FCM_OP_CODE_SMAC_LO = 3,
    HAL_MT_CIA_ACT_FCM_OP_CODE_L2_VLAN0 = 4,
    HAL_MT_CIA_ACT_FCM_OP_CODE_L2_VLAN1 = 5,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_DA_3 = 6,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_DA_2 = 7,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_DA_1 = 8,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_DA_0 = 9,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_SA_3 = 10,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_SA_2 = 11,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_SA_1 = 12,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_SA_0 = 13,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv4_DIP = 14,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv4_SIP = 15,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_TOS = 16,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv4_TOS = 17,
    HAL_MT_CIA_ACT_FCM_OP_CODE_L4_SPORT = 18,
    HAL_MT_CIA_ACT_FCM_OP_CODE_L4_DPORT = 19,
    HAL_MT_CIA_ACT_FCM_OP_CODE_LAST
} HAL_MT_CIA_ACT_FCM_OP_CODE_T;

typedef enum {
    HAL_MT_CIA_RSN_ACT_DISABLE = 0,
    HAL_MT_CIA_RSN_ACT_COPY = 1,
    HAL_MT_CIA_RSN_ACT_REDIR = 2,
    HAL_MT_CIA_RSN_ACT_DROP = 3,
    HAL_MT_CIA_RSN_ACT_LAST = 4
} HAL_MT_CIA_RSN_ACT_T;

typedef enum {
    HAL_MT_CIA_ACT_FWD_MASK_BIT_SOURCE_PRUNING = (1U << 0),
    HAL_MT_CIA_ACT_FWD_MASK_BIT_TTL = (1U << 1),
    HAL_MT_CIA_ACT_FWD_MASK_BIT_RPF = (1U << 2),
    HAL_MT_CIA_ACT_FWD_MASK_BIT_LAST,
} HAL_MT_CIA_ACT_FWD_MASK_BIT_T;

CLX_ERROR_NO_T
hal_mt_acl_checkGroup(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T prio,
                      const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile);

CLX_ERROR_NO_T
hal_mt_acl_addGroup(const UI32_T unit,
                    const CLX_ACL_GROUP_T type,
                    const UI32_T prio,
                    const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile,
                    UI32_T *ptr_group_id);

CLX_ERROR_NO_T
hal_mt_acl_setGroup(const UI32_T unit,
                    const CLX_ACL_GROUP_T type,
                    const UI32_T prio,
                    const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile,
                    UI32_T group_id);

CLX_ERROR_NO_T
hal_mt_acl_freeEntryAllocRsrc(const UI32_T unit,
                              const CLX_ACL_GROUP_T type,
                              const HAL_ACL_ENTRY_ALLOC_INFO_T *ptr_alloc_info);

CLX_ERROR_NO_T
hal_mt_acl_resetUcp(const UI32_T unit, const CLX_ACL_GROUP_T type, UI32_T ucp_bmp);

CLX_ERROR_NO_T
hal_mt_acl_getGroupProfile(const UI32_T unit,
                           const CLX_ACL_GROUP_T type,
                           const UI32_T group_id,
                           const UI32_T ucp_member_bmp,
                           CLX_ACL_GROUP_PROFILE_T *ptr_group_profile);

CLX_ERROR_NO_T
hal_mt_acl_getUcpPbmEn(const UI32_T unit,
                       const CLX_ACL_GROUP_T type,
                       const UI32_T group,
                       UI32_T *ptr_ucp_pbm_en);

CLX_ERROR_NO_T
hal_mt_acl_setAclPkgProf(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_prof_id,
                         const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile,
                         UI32_T *ptr_acl_pkg_vld,
                         UI32_T *ptr_pkg_0_cnt,
                         UI32_T *ptr_pkg_1_cnt,
                         UI32_T *ptr_pkg_0_consecutive_bmp,
                         UI32_T *ptr_pkg_1_consecutive_bmp);

CLX_ERROR_NO_T
hal_mt_acl_setFlwPkgProf(const UI32_T unit,
                         const UI32_T udf_prof_id,
                         const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile,
                         UI32_T *ptr_flw_pkg_vld,
                         UI32_T *ptr_flw_1_pkg_vld,
                         UI32_T *ptr_consecutive_bmp);

CLX_ERROR_NO_T
hal_mt_acl_setPkgLouProfIdx(const UI32_T unit,
                            const CLX_ACL_GROUP_T type,
                            const UI32_T udf_prof_id,
                            const UI32_T flw_pkg_vld,
                            const UI32_T pkg_vld,
                            const UI32_T lou_vld);

CLX_ERROR_NO_T
hal_mt_acl_setTcamPkgLou(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_key_profile_id,
                         const BOOL_T valid,
                         const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format);

CLX_ERROR_NO_T
hal_mt_acl_getPktFormat(const UI32_T unit,
                        const CLX_ACL_GROUP_T type,
                        const UI32_T udf_prof_id,
                        const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                        CLX_ACL_PKT_FORMAT_T *ptr_pkt_format);

CLX_ERROR_NO_T
hal_mt_acl_getPkgLouProfIdx(const UI32_T unit,
                            const CLX_ACL_GROUP_T type,
                            const UI32_T udf_prof_id,
                            UI32_T *ptr_flw_pkg_prof_vld,
                            UI32_T *ptr_flw_pkg_prof_idx,
                            UI32_T *ptr_acl_pkg_prof_vld,
                            UI32_T *ptr_acl_pkg_prof_idx,
                            UI32_T *ptr_lou_prof_vld,
                            UI32_T *ptr_lou_prof_idx);

CLX_ERROR_NO_T
hal_mt_acl_getAclPkgProf(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T acl_pkg_prof_idx,
                         const UI32_T acl_pkg_prof_vld,
                         const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                         CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

CLX_ERROR_NO_T
hal_mt_acl_getFlwPkgProf(const UI32_T unit,
                         const UI32_T flw_pkg_prof_idx,
                         const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                         CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

CLX_ERROR_NO_T
hal_mt_acl_getLouProf(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T udf_prof_id,
                      const UI32_T lou_id,
                      const HAL_ACL_LOU_INFO_T *ptr_lou_info,
                      CLX_ACL_LOU_CFG_T *ptr_lou);

CLX_ERROR_NO_T
hal_mt_acl_setLouProf(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T udf_prof_id,
                      const UI32_T lou_id,
                      const CLX_ACL_LOU_CFG_T *ptr_lou);

CLX_ERROR_NO_T
hal_mt_acl_getAclPkgProfLouInfo(const UI32_T unit,
                                const CLX_ACL_GROUP_T type,
                                const UI32_T acl_pkg_prof_idx,
                                UI32_T *ptr_acl_int_lou_vld,
                                UI32_T *ptr_acl_lou_en);

CLX_ERROR_NO_T
hal_mt_acl_getFlwPkgProfLouInfo(const UI32_T unit,
                                const UI32_T flw_pkg_prof_idx,
                                UI32_T *ptr_flw_int_lou_vld,
                                UI32_T *ptr_flw_lou_en,
                                UI32_T *ptr_flw_1_int_lou_vld,
                                UI32_T *ptr_flw_1_lou_en);

CLX_ERROR_NO_T
hal_mt_acl_setFlwPkgProfLouEn(const UI32_T unit,
                              const UI32_T flw_pkg_prof_idx,
                              const UI32_T lou_id,
                              const UI32_T flw_int_lou_vld,
                              const UI32_T flw_lou_en,
                              const UI32_T flw_1_int_lou_vld,
                              const UI32_T flw_1_lou_en);

CLX_ERROR_NO_T
hal_mt_acl_setAclPkgProfLouEn(const UI32_T unit,
                              const CLX_ACL_GROUP_T type,
                              const UI32_T acl_pkg_prof_idx,
                              const UI32_T acl_lou_en);

CLX_ERROR_NO_T
hal_mt_acl_getFlwUdfKeyInfo(const UI32_T unit,
                            const CLX_ACL_CLASSIFY_T *ptr_classify,
                            HAL_ACL_FLOW_ENTRY_PACK_UDF_KEY_T *ptr_flw_udf_key,
                            UI32_T *ptr_udf_prof_flw_key_typ);

CLX_ERROR_NO_T
hal_mt_acl_getUdfKeyInfo(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T group,
                         const CLX_ACL_CLASSIFY_T *ptr_classify,
                         HAL_ACL_ENTRY_PACK_UDF_KEY_T *ptr_udf_key);

CLX_ERROR_NO_T
hal_mt_acl_initCfg(const UI32_T unit);

/**
 * @brief The API is used to add/set an UCP entry from HW for mountain series.
 *
 * If both ptr_classify and ptr_action are NULL, the API will only modify valid bit of entry.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     entry_id        - entry id
 * @param [in]     entry_valid     - The status of the entry: TRUE for valid and FALSE for invalid
 * @param [in]     ptr_classify    - The classified information of the entry
 * @param [in]     ptr_action      - The action to be taken of the entry when the classified
 * information is matched
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_mt_acl_addEntry(const UI32_T unit,
                    const UI32_T entry_id,
                    const BOOL_T entry_valid,
                    const CLX_ACL_CLASSIFY_T *ptr_classify,
                    const CLX_ACL_ACTION_T *ptr_action);

CLX_ERROR_NO_T
hal_mt_acl_getFreeUcpPbm(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         UI32_T *ucp_num,
                         UI32_T *free_ucp_bmp);

CLX_ERROR_NO_T
hal_mt_acl_addUcpToGroup(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T group,
                         const UI32_T new_ucp);

CLX_ERROR_NO_T

hal_mt_acl_addFlowEntry(const UI32_T unit,
                        const CLX_ACL_GROUP_T type,
                        const UI32_T group_id,
                        const CLX_ACL_CLASSIFY_T *ptr_classify,
                        const CLX_ACL_ACTION_T *ptr_action,
                        UI32_T *ptr_entry_id);

CLX_ERROR_NO_T
hal_mt_acl_updateAdjInfo(const UI32_T unit,
                         const UI32_T adj_id,
                         const HAL_L3_ADJ_INFO_T *ptr_adj_info);

CLX_ERROR_NO_T
hal_mt_acl_updateEcmpInfo(const UI32_T unit,
                          const UI32_T ecmp_group_id,
                          const HAL_L3_ECMP_INFO_T *ptr_ecmp_info);

CLX_ERROR_NO_T
hal_mt_acl_updateResult(const UI32_T unit,
                        const UI32_T group_id,
                        UI32_T *key_buf,
                        const UI32_T new_rslt_tbl,
                        const UI32_T *rslt_buf,
                        HAL_ACL_FLOW_ENTRY_INFO_T *ptr_entry_info,
                        UI32_T *key_idx,
                        UI32_T *new_rslt_idx);

CLX_ERROR_NO_T
hal_mt_acl_getFlowEntry(const UI32_T unit,
                        const HAL_ACL_FLOW_ENTRY_INFO_T *ptr_entry_info,
                        CLX_ACL_CLASSIFY_T *ptr_classify,
                        CLX_ACL_ACTION_T *ptr_action);

CLX_ERROR_NO_T
hal_mt_acl_unpackEntry(const UI32_T unit,
                       const CLX_ACL_GROUP_T type,
                       const HAL_ACL_ENTRY_INFO_T *ptr_entry_info,
                       BOOL_T *ptr_entry_valid,
                       CLX_ACL_CLASSIFY_T *ptr_classify,
                       CLX_ACL_ACTION_T *ptr_action);

CLX_ERROR_NO_T
hal_mt_acl_enableGroup(const UI32_T unit,
                       const CLX_ACL_GROUP_T type,
                       const UI32_T group,
                       const UI32_T enable);

CLX_ERROR_NO_T
hal_mt_acl_getFlowEntryIdInfo(const UI32_T unit,
                              const UI32_T hw_entry_id,
                              CLX_ACL_GROUP_T *ptr_type,
                              UI32_T *ptr_group_id);

CLX_ERROR_NO_T
hal_mt_acl_checkFlowPreemptEntry(const UI32_T unit,
                                 const UI32_T group_id,
                                 const UI32_T ucp_member_bmp,
                                 UI32_T *ptr_flow_entry);

CLX_ERROR_NO_T
hal_mt_acl_freeFlowPreemptEntry(const UI32_T unit, const UI32_T ucp_member_bmp);

CLX_ERROR_NO_T
hal_mt_acl_delFlowEntry(const UI32_T unit,
                        const UI32_T group_id,
                        HAL_ACL_FLOW_ENTRY_INFO_T *ptr_entry_info);

CLX_ERROR_NO_T
hal_mt_acl_getFlowGroupEntryCapUsage(const UI32_T unit,
                                     const CLX_ACL_GROUP_T type,
                                     const UI32_T group_id,
                                     const UI32_T get_capacity,
                                     UI32_T *ptr_cnt);
CLX_ERROR_NO_T
hal_mt_acl_setTappingTpid(const UI32_T unit, const CLX_SWC_PROPERTY_T property, const UI32_T tpid);
CLX_ERROR_NO_T
hal_mt_acl_getTappingTpid(const UI32_T unit, const CLX_SWC_PROPERTY_T property, UI32_T *tpid);

CLX_ERROR_NO_T
hal_mt_acl_rim_alloc_fcm_idx(const UI32_T unit, const UI32_T is_flw, UI32_T *ptr_index);

CLX_ERROR_NO_T
hal_mt_acl_rim_free_fcm_idx(const UI32_T unit, const UI32_T is_flw, const UI32_T index);

CLX_ERROR_NO_T
hal_mt_acl_rim_setFcmAction(const UI32_T unit,
                            const UI32_T is_flw,
                            const UI32_T index,
                            const void *ptr_action);

CLX_ERROR_NO_T
hal_mt_acl_rim_getFcmAction(const UI32_T unit,
                            const UI32_T is_flw,
                            const UI32_T index,
                            const void *ptr_action);

CLX_ERROR_NO_T
hal_mt_acl_rim_travFcmAction(const UI32_T unit,
                             const UI32_T is_flw,
                             const CLX_ACL_RIM_TRAVERSE_FUNC_T callback,
                             void *ptr_cookie);
CLX_ERROR_NO_T
hal_mt_acl_allocEntryId(const UI32_T unit,
                        const CLX_ACL_GROUP_T type,
                        const UI32_T group_id,
                        const UI32_T entry_priority,
                        UI32_T *ptr_entry_id);

CLX_ERROR_NO_T
hal_mt_acl_getSwEntryInfo(UI32_T unit, UI32_T entry_id, CLX_ACL_GROUP_T *type, UI32_T *sw_entry_id);
#endif /* End of HAL_MT_ACL_H */
