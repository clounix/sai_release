/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_cmn_sflow.h
 * PURPOSE:
 *    Provide sflow hal layer api.
 *
 * NOTES:
 *
 */

#ifndef HAL_LT_CMN_SFLOW_H
#define HAL_LT_CMN_SFLOW_H

#define HAL_LT_SFLOW_PROFILE_ENTRY_NUM (8)

CLX_ERROR_NO_T
hal_lt_sflow_setIgrCfgSflwMir(const UI32_T unit,
                              const UI32_T profile_id,
                              const UI32_T sflw_mir_en,
                              const UI32_T sflw_mir_bidx);

CLX_ERROR_NO_T
hal_lt_sflow_getIgrCfgSflwMir(const UI32_T unit,
                              const UI32_T profile_id,
                              UI32_T *ptr_sflw_mir_en,
                              UI32_T *ptr_sflw_mir_bidx);

CLX_ERROR_NO_T
hal_lt_sflow_setEgrCfgSflwMir(const UI32_T unit,
                              const UI32_T profile_id,
                              const UI32_T sflw_mir_en,
                              const UI32_T sflw_mir_bidx);

CLX_ERROR_NO_T
hal_lt_sflow_getEgrCfgSflwMir(const UI32_T unit,
                              const UI32_T profile_id,
                              UI32_T *ptr_sflw_mir_en,
                              UI32_T *ptr_sflw_mir_bidx);

CLX_ERROR_NO_T
hal_lt_sflow_setIgrCfgSflw(const UI32_T unit,
                           const UI32_T profile_id,
                           const UI32_T sflw_cp_to_cpu_bidx,
                           const UI32_T sflw_splr_threshold,
                           const UI32_T sflw_ioam_en,
                           const UI32_T sflw_ioam_flw_lbl_val);

CLX_ERROR_NO_T
hal_lt_sflow_getIgrCfgSflw(const UI32_T unit,
                           const UI32_T profile_id,
                           UI32_T *ptr_sflw_cp_to_cpu_bidx,
                           UI32_T *ptr_sflw_ioam_en,
                           UI32_T *ptr_sflw_ioam_flw_lbl_val);

CLX_ERROR_NO_T
hal_lt_sflow_setEgrCfgSflw(const UI32_T unit,
                           const UI32_T profile_id,
                           const UI32_T sflw_cp_to_cpu_bidx,
                           const UI32_T sflw_splr_threshold);

CLX_ERROR_NO_T
hal_lt_sflow_getEgrCfgSflw(const UI32_T unit,
                           const UI32_T profile_id,
                           UI32_T *ptr_sflw_cp_to_cpu_bidx);

CLX_ERROR_NO_T
hal_lt_sflow_setHighLatencyCfg(const UI32_T unit, const UI32_T threshold, const UI32_T sflw_lat_en);

CLX_ERROR_NO_T
hal_lt_sflow_setCfgIoamFlwLbl(const UI32_T unit,
                              const UI32_T profile_id,
                              const UI32_T ioam_flw_lbl_val,
                              const UI32_T ioam_flw_lbl_msk);

CLX_ERROR_NO_T
hal_lt_sflow_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_sflow_allocProfile(const UI32_T unit,
                          const HAL_SFLOW_SRC_TYPE_T src_type,
                          const HAL_SFLOW_DST_TYPE_T dst_type,
                          const UI32_T mir_session_id,
                          const UI32_T profile_id,
                          const UI32_T sampling_rate,
                          const BOOL_T sample_high_latency);

#endif /* End of HAL_LT_CMN_SFLOW_H */
