/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_tm_rep.h
 * PURPOSE:
 * NOTES:
 *
 */

#ifndef HAL_MT_TM_REP_H
#define HAL_MT_TM_REP_H

#include <hal/hal.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
/* Murmur Hash */
#define HAL_MT_TM_REP_IR_POLY                             (0x8bb7)
#define HAL_MT_TM_REP_GF16_FAC                            (0x569a)
#define HAL_MT_TM_REP_GF16_SEED                           (0)
#define HAL_MT_TM_REP_GF16_MASK                           (0xFFFF)
#define HAL_MT_TM_REP_EMDB_MAX                            (8)
#define HAL_MT_TM_REP_MCDB_KEY_SIZE                       (27)
#define HAL_MT_TM_REP_GET_HASH_KEY(__mg_id__, __sn_num__) (((__mg_id__) << 12) | (__sn_num__))

#define HAL_MT_TM_REP_EMDB_INSERT      (0)
#define HAL_MT_TM_REP_EMDB_SEARCH      (1)
#define HAL_MT_TM_REP_EMDB_SEARCH_FREE (2)
#define HAL_MT_TM_REP_EMDB_WRITE       (3)
#define HAL_MT_TM_REP_EMDB_READ        (4)
#define HAL_MT_TM_REP_EMDB_DELETE      (5)

#define HAL_MT_TM_REP_EMDB_WAIT_TIMES (1000)

UI32_T
gf16_mul_calc(UI32_T a, UI32_T b);

UI32_T
murmur_hash(UI32_T key);

UI32_T
gf16_mul(UI32_T *ptr_lst, UI32_T fac, UI32_T seed_16_bits, UI32_T key_byte_size);

/**
 * @brief To insert emdb and return emdb idx
 *
 * @param [in]     unit            - Chip unit id
 * @param [in]     mg_id           - Mcast grp id
 * @param [in]     sn_num          - Mcast member sn id
 * @param [in]     mcdb_ptr        - Mcdb hw id
 * @param [out]    ptr_emdb_idx    - return emdb idx
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_insert_emdb(const UI32_T unit,
                          const UI32_T mg_id,
                          const UI32_T sn_num,
                          const UI32_T mcdb_ptr,
                          UI32_T *ptr_emdb_idx);

/**
 * @brief To insert emdb and return emdb idx
 *
 * @param [in]     unit            - Chip unit id
 * @param [in]     mg_id           - Mcast grp id
 * @param [in]     sn_num          - Mcast member sn id
 * @param [out]    ptr_mcdb_ptr    - return mcdb idx
 * @param [out]    ptr_emdb_id     - return emdb id
 * @param [out]    ptr_emdb_idx    - return emdb idx
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_search_emdb(const UI32_T unit,
                          const UI32_T mg_id,
                          const UI32_T sn_num,
                          UI32_T *ptr_mcdb_ptr,
                          UI32_T *ptr_emdb_id,
                          UI32_T *ptr_emdb_idx);

/**
 * @brief To delete emdb idx
 *
 * @param [in]     unit        - Chip unit id
 * @param [in]     mg_id       - Mcast grp id
 * @param [in]     sn_num      - Mcast member sn id
 * @param [in]     cp_index    - Mcast member need swap
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_delete_emdb(const UI32_T unit,
                          const UI32_T mg_id,
                          const UI32_T sn_num,
                          const UI32_T cp_index);

/**
 * @brief Get emdb id from sn
 *
 * @param [in]     unit           - Chip unit id
 * @param [in]     mg_id          - Mcast grp id
 * @param [in]     sn_num         - Mcast member sn id
 * @param [out]    ptr_emdb_id    - Emdb id
 * @return         CLX_E_OK    - Operation success
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_get_emdb(const UI32_T unit,
                       const UI32_T mg_id,
                       const UI32_T sn_num,
                       UI32_T *ptr_emdb_id);

/**
 * @brief Alloc mcdb idx
 *
 * @param [in]     unit            - Chip unit id
 * @param [in]     emdb_id         - Emdb id
 * @param [out]    ptr_mcdb_idx    - return idx
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_alloc_mcdb(const UI32_T unit, const UI32_T emdb_id, UI32_T *ptr_mcdb_idx);

/**
 * @brief add mcdb info
 *
 * @param [in]     unit       - Chip unit id
 * @param [in]     emdb_id    - Emdb id
 * @param [in]     mcdb_id    - Mcdb id
 * @param [in]     is_even    - Even or Odd
 * @param [in]     is_fl      - fabric link or non fabric link
 * @param [in]     di         - dst idx or fabric link id
 * @param [in]     cud        - mel idx
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_add_mcdb(const UI32_T unit,
                       const UI32_T emdb_id,
                       const UI32_T mcdb_id,
                       const UI32_T is_even,
                       const UI32_T is_fl,
                       const UI32_T di,
                       const UI32_T cud);

/**
 * @brief delete mcdb info
 *
 * @param [in]     unit       - Chip unit id
 * @param [in]     emdb_id    - Emdb id
 * @param [in]     mcdb_id    - Mcdb id
 * @param [in]     is_even    - Even or Odd
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_delete_mcdb(const UI32_T unit,
                          const UI32_T emdb_id,
                          const UI32_T mcdb_id,
                          const UI32_T is_even);

/**
 * @brief get mcdb info
 *
 * @param [in]     unit         - Chip unit id
 * @param [in]     emdb_id      - Emdb id
 * @param [in]     mcdb_id      - Mcdb id
 * @param [in]     is_even      - Even or Odd
 * @param [out]    ptr_is_fl    - fabric link or non fabric link
 * @param [out]    ptr_di       - Dst idx
 * @param [out]    ptr_cud      - Cud idx
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_get_mcdb(const UI32_T unit,
                       const UI32_T emdb_id,
                       const UI32_T mcdb_id,
                       const UI32_T is_even,
                       UI32_T *ptr_is_fl,
                       UI32_T *ptr_di,
                       UI32_T *ptr_cud);

/**
 * @brief free mcdb idx
 *
 * @param [in]     unit       - Chip unit id
 * @param [in]     emdb_id    - Emdb id
 * @param [in]     mcdb_id    - Mcdb id
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_free_mcdb(const UI32_T unit, const UI32_T emdb_id, const UI32_T mcdb_id);

/**
 * @brief free mcdb idx
 *
 * @param [in]     unit             - Chip unit id
 * @param [in]     mg_id            - Mcast grp id
 * @param [in]     mg_size          - Mcast grp size
 * @param [in]     leave_sn         - Leave member sn
 * @param [in]     swap_sn          - Swap member sn
 * @param [in]     leave_mcdb_id    - Leave member mcdb idx
 * @param [in]     swap_mcdb_id     - Swap member mcdb idx
 * @param [in]     swap_emdb_idx    - Swap member emdb hw idx
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_delete_mg_member(const UI32_T unit,
                               const UI32_T mg_id,
                               const UI32_T mg_size,
                               const UI32_T leave_sn,
                               const UI32_T swap_sn,
                               const UI32_T leave_mcdb_id,
                               const UI32_T swap_mcdb_id,
                               const UI32_T swap_emdb_idx);

/**
 * @brief delete all mc member in mc group
 *
 * @param [in]     unit       - Chip unit id
 * @param [in]     mg_id      - Mcast grp id
 * @param [in]     mg_size    - Mcast grp size
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_mt_tm_rep_delete_all_mg_member(const UI32_T unit, const UI32_T mg_id, const UI32_T mg_size);

#endif /* End of HAL_MT_TELM_H */
