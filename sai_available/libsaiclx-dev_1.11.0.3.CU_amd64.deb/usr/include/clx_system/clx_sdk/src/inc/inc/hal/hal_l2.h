/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_l2.h
 * PURPOSE:
 *    Provide HAL driver API functions of L2 module.
 *
 * NOTES:
 *
 */

#ifndef HAL_L2_H
#define HAL_L2_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_l2.h>
#include <hal/hal_const_cmn.h>
#include <hal/hal_lag.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_L2_FDB_ENTRY_MCAST_CP_TO_CPU_IDX (1)
#define HAL_L2_FDB_ENTRY_UCAST_CP_TO_CPU_IDX (1)
#define HAL_L2_FDB_NOTIFY_HANDLER_NUM        (4)
#define HAL_L2_FDB_SW_LEARN_HANDLER_NUM      (4)

/* maximun of LT and NB
 * LT SW FDB entry: LT_CDB_ICM_COM_1X_U_L2_FDB_WORDS(6),
 * NB SW FDB entry: MT_CDB_FPU_HSH_L2_WORDS(3),
 */
#define HAL_L2_FDB_ENTRY_WORDS_MAX (LT_CDB_ICM_COM_1X_U_L2_FDB_WORDS)

#define HAL_L2_FDB_MUTEX_SEMA_NAME      ("FDB_MUTEX_SEMA")
#define HAL_L2_NOTIFY_MUTEX_SEMA_NAME   ("NOTIFY_MUTEX_SEMA")
#define HAL_L2_SW_LEARN_MUTEX_SEMA_NAME ("SW_LEARN_MUTEX_SEMA")
#define HAL_L2_TRAVERSE_MUTEX_SEMA_NAME ("TRAVERSE_MUTEX_SEMA")
#define HAL_L2_CALLBACK_MUTEX_SEMA_NAME ("CALLBACK_MUTEX_SEMA")

#define HAL_L2_TRAVERSE_FDB_DMA_ENTRY_NUM    (512)
#define HAL_L2_TRAVERSE_FDB_SLEEP_USEC       (5 * 1000)
#define HAL_L2_TRAVERSE_FDB_SLEEP_TH_DMA_NUM (16)

#define HAL_L2_FAST_CMD_DONE_POLLING_USEC (1000)
#define HAL_L2_FAST_CMD_ENTRY_WORDS       (6)
#define HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS  (8)

#define HAL_L2_AGE_SEC_MIN     (3)
#define HAL_L2_AGE_SEC_MAX     (3145725) /* (2^20 - 1) * 3 */
#define HAL_L2_AGE_STEPS       (4)
#define HAL_L2_AGE_SEC_DEFAULT (300)

#define HAL_L2_MCAST_FDB_MUTEX_SEMA_NAME       ("MCAST_FDB_MUTEX_SEMA")
#define HAL_L2_MCAST_FDB_INDIR_RSLT_IDX_OFFSET (0x40000) /* (8 * 16k) */
#define HAL_L2_ITM_PER_PLANE_BMP_WORDS         (HAL_ITM_PBM_WORDS / HAL_PLANE_NUM_MAX)

#define HAL_L2_DEFAULT_MIR_KEEP_IGR_VLAN_TAGS (0)
#define HAL_L2_DI_FORWARD_DROP(unit)          (HAL_DROP_MIN(unit))

#define HAL_L2_OPERATING_MODE_POLLING (0)
#define HAL_L2_OPERATING_MODE_FIFO    (1)

#define HAL_L2_FIFO_TASK_NAME                      ("FIFO_TASK")
#define HAL_L2_FIFO_READ_PTR_UPDATE_THRESHOLD      (42)
#define HAL_L2_FIFO_TASK_SLEEP_USEC                (10 * 1000)
#define HAL_L2_FIFO_TASK_SLEEP_TH_ENTRY_NUM        (HAL_L2_FIFO_READ_PTR_UPDATE_THRESHOLD * 256)
#define HAL_L2_FIFO_RING_BUF_ADDR_SHIFT_BITS       (5)
#define HAL_L2_FIFO_RING_BUF_EXTRA_ENTRY_NUM       (16 * 1024)
#define HAL_L2_FIFO_ENTRY_BYTES                    (32)
#define HAL_L2_FIFO_ENTRY_SHIFT_BITS               (5)
#define HAL_L2_FIFO_UPLOAD_TH_FILL_COUNT           (42)
#define HAL_L2_FIFO_UPLOAD_TH_TIME                 (100)
#define HAL_L2_FIFO_SLOW_CLK_RATIO                 (1)
#define HAL_L2_FIFO_UPLOAD_TH_TIME_MODE            (HAL_L2_FIFO_UPLOAD_TH_TIME_MODE_SLOW)
#define HAL_L2_FIFO_UPLOAD_TH_TIME_MODE_SLOW       (1)
#define HAL_L2_FIFO_UPLOAD_TH_TIME_MODE_QUICK      (3)
#define HAL_L2_FIFO_BACK_PRESSURE_TH               (50)
#define HAL_L2_FIFO_UPLOAD_SEQ_NUM_BASE            (0)
#define HAL_L2_FIFO_UPLOAD_SEQ_NUM_MAX             (0xffffffff)
#define HAL_L2_FIFO_MAX_RING_BUF_ENTRY_NUM         (65535)
#define HAL_L2_FIFO_RING_BUF_DISABLE_LRN           (0)
#define HAL_L2_FIFO_RING_BUF_ENABLE_LRN            (1)
#define HAL_L2_FIFO_RING_BUF_DISABLE_LRN_ENTRY_NUM (16 * 1024)
#define HAL_L2_FIFO_RING_BUF_ENABLE_LRN_ENTRY_NUM  (17 * 1024)
#define HAL_L2_FIFO_FDB_AVL_NAME                   ("FIFO_FDB_AVL")
#define HAL_L2_FIFO_MC_FDB_AVL_NAME                ("FIFO_MC_FDB_AVL")

#define HAL_L2_POLLING_TASK_NAME       ("POLLING_TASK")
#define HAL_L2_POLLING_TASK_SLEEP_USEC (10 * 1000)

#define HAL_L2_POLL_BLOCK_INTERVAL_USEC_MIN (50 * 1000)
#define HAL_L2_POLL_BLOCK_DMA_NUM           (16)
#define HAL_L2_POLL_BLOCK_DMA_ENTRY_NUM     (512)
#define HAL_L2_POLL_BLOCK_ENTRY_NUM         (HAL_L2_POLL_BLOCK_DMA_NUM * HAL_L2_POLL_BLOCK_DMA_ENTRY_NUM)
#define HAL_L2_POLL_FDB_AVL_NAME            ("POLLING_FDB_AVL")

#define HAL_L2_TRAVERSE_TASK_NAME ("TRAVERSE_TASK")

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_L2_FDB_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].fdb_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_FDB_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].fdb_mutex_sema_id)
#define HAL_L2_NOTIFY_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].notify_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_NOTIFY_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].notify_mutex_sema_id)
#define HAL_L2_SW_LEARN_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].sw_learn_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_SW_LEARN_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].sw_learn_mutex_sema_id)
#define HAL_L2_MCAST_FDB_LOCK(_unit_)                                                 \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_mcast_fdb_cb[(_unit_)].mcast_fdb_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_MCAST_FDB_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_mcast_fdb_cb[(_unit_)].mcast_fdb_mutex_sema_id)
#define HAL_L2_CALLBACK_LOCK(_unit_)                                                \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_traverse_cb[(_unit_)].callback_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_CALLBACK_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_traverse_cb[(_unit_)].callback_mutex_sema_id)

#define HAL_L2_UI32_MSK(__bits__) (0xFFFFFFFF >> (32 - (__bits__)))
#define HAL_L2_UI32_FLD_MSK(__unit__, __tbl_id__, __fld_id__) \
    (HAL_L2_UI32_MSK((CDB_TABLE((__unit__), (__tbl_id__))->ptr_table_entry[(__fld_id__)].length)))

#define HAL_L2_PLANE_BMP_FOREACH(__unit__, __plane__)                           \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (CMLIB_BITMAP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

#define HAL_L2_DP_PLANE_PORT_BMP_FOREACH(__dp_plane_port_bmp__, __dp_plane_port__)    \
    for ((__dp_plane_port__) = HAL_PLANE_ETH_DP_PORT_MIN;                             \
         (__dp_plane_port__) <= HAL_PLANE_ETH_DP_PORT_MAX_CMN; (__dp_plane_port__)++) \
        if (CMLIB_BITMAP_BIT_CHK((__dp_plane_port_bmp__), (__dp_plane_port__)))

#define HAL_L2_CLEAR_FDB_UNSAVE_FIELD(__unit__, __fdb_entry__)                     \
    CMLIB_BITMAP_AND((__fdb_entry__), (_hal_l2_fdb_cb[(__unit__)].fdb_entry_mask), \
                     HAL_L2_FDB_ENTRY_WORDS_MAX)

#define HAL_L2_PRINT_FDB_ENTRY(__flags__, __prefix_str__, __hw_fdb_entry__, __postfix_str__) \
    do {                                                                                     \
        DIAG_PRINT(HAL_DBG_L2, (__flags__), "%sfdb-entry=%08x.%08x.%08x.%08x.%08x.%08x%s",   \
                   (__prefix_str__), (__hw_fdb_entry__)[5], (__hw_fdb_entry__)[4],           \
                   (__hw_fdb_entry__)[3], (__hw_fdb_entry__)[2], (__hw_fdb_entry__)[1],      \
                   (__hw_fdb_entry__)[0], (__postfix_str__));                                \
    } while (0)

#define HAL_L2_CHECK_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)             \
    do {                                                                                        \
        if (!HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)) {      \
            DIAG_PRINT(HAL_DBG_L2, HAL_DBG_WARN, "u=%u, invalid " #__value__ "=%d\n", __unit__, \
                       __value__);                                                              \
            return CLX_E_BAD_PARAMETER;                                                         \
        }                                                                                       \
    } while (0)

#define HAL_L2_ECMP_TYPEID_TO_GRPID(grpid, id)                 \
    do {                                                       \
        (id) = ((CLX_L3_OUTPUT_TYPE_L2_ECMP) << 29) + (grpid); \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_L2_TRAVERSE_ACTION_NOTIFY_CALLBACK = 0,
    HAL_L2_TRAVERSE_ACTION_GET_COUNT = 1,
    HAL_L2_TRAVERSE_ACTION_INIT_POLL = 2,
    HAL_L2_TRAVERSE_ACTION_INIT_FIFO = 3,
} HAL_L2_TRAVERSE_ACTION_T;

typedef enum {
    HAL_L2_FDB_HW_TYPE_HASH = 0,
    HAL_L2_FDB_HW_TYPE_TCAM,
} HAL_L2_FDB_HW_TYPE_T;
typedef enum {
    HAL_L2_TYPE_UC = 0,
    HAL_L2_TYPE_MC,
} HAL_L2_TYPE_T;
typedef enum {
    HAL_L2_CALLBACK_REASON_ADD = 0,
    HAL_L2_CALLBACK_REASON_MODIFY,
    HAL_L2_CALLBACK_REASON_DELETE,
    HAL_L2_CALLBACK_REASON_NEW_LEARN,
    HAL_L2_CALLBACK_REASON_MOVE,
    HAL_L2_CALLBACK_REASON_LAST,
} HAL_L2_CALLBACK_REASON_T;

typedef UI32_T HAL_L2_FAST_CMD_ENTRY_T[HAL_L2_FAST_CMD_ENTRY_WORDS];
typedef UI32_T HAL_L2_FAST_CMD_TCAM_ENTRY_T[HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS];

typedef UI32_T HAL_L2_FDB_ENTRY_T[HAL_L2_FDB_ENTRY_WORDS_MAX];

typedef UI32_T HAL_L2_ITM_PBM_T[HAL_ITM_PBM_WORDS];
typedef struct HAL_L2_CALLBACK_INFO_S {
    HAL_L2_CALLBACK_REASON_T reason;
    CLX_L2_ADDR_T addr;
} HAL_L2_CALLBACK_INFO_T;

typedef struct HAL_L2_BUM_MC_ID_S {
    UI32_T bc;
    UI32_T umc;
    UI32_T uuc;
} HAL_L2_BUM_MC_ID_T;
typedef struct HAL_L2_GROUP_MBR_INFO_S {
    CLX_L2_MCAST_EGR_INTF_TYPE_T type;
    UI32_T bdid;
    union {
        CLX_PORT_T port;
        UI32_T fl_id;
    };
    union {
        CLX_L2_MCAST_EGR_INTF_NV_T nv;
        CLX_L2_MCAST_EGR_INTF_MPLS_T mpls;
    };
} HAL_L2_GROUP_MBR_INFO_T;

typedef struct HAL_L2_GROUP_MBR_SN_INFO_S {
    UI32_T sn;
    UI32_T mel_id;
    HAL_L2_GROUP_MBR_INFO_T member_info;
} HAL_L2_GROUP_MBR_SN_INFO_T;

typedef struct HAL_L2_WARM_GROUP_INFO_S {
    UI32_T group_size;
    BOOL_T not_allow_reuse;
    UI32_T logical_mc_id_ref_cnt;
    union {
        CLX_PORT_BITMAP_T non_port_intf_pbm;
        UI32_T logical_mc_id;
    };
} HAL_L2_WARM_GROUP_INFO_T;
typedef struct HAL_L2_GROUP_INFO_S {
    UI32_T group_size;      /* Number of group member. */
    BOOL_T not_allow_reuse; /* Indicate this phy mcast id is not allowed to reuse.
                             * Only members with non replicate, non tnl and non fabric link
                             * mcast group can be reused.
                             */
    UI32_T logical_mc_id_ref_cnt;
    union {
        CLX_PORT_BITMAP_T non_port_intf_pbm; /* Group member port bitmap. Used when not_allow_reuse
                                                is FALSE */
        UI32_T logical_mc_id; /* The logical mcast id corresponding to this phy mcast id. Used when
                                 not_allow_reuse is TRUE */
    };
    CMLIB_LIST_T *ptr_member_list;
} HAL_L2_GROUP_INFO_T;

typedef struct HAL_L2_GROUP_FDID_INFO_S {
    UI32_T fdid;
    UI32_T ref_cnt;
    CLX_PORT_BITMAP_T non_port_intf_pbm; /* used for non replicate mcast group only */
} HAL_L2_GROUP_FDID_INFO_T;

typedef struct HAL_L2_MCAST_FDB_CB_S {
    CLX_SEMAPHORE_ID_T mcast_fdb_mutex_sema_id;
    UI32_T group_num;
    HAL_L2_GROUP_FDID_INFO_T *ptr_group_fdid_info; /* LT */
    UI32_T **pptr_hsh_mc_sc_ref_cnt;               /* per plane db */
    HAL_L3_MCAST_MEL_SUB_ENTRY_T *ptr_mel_entry;   /* used for get mcast egr intf */
    HAL_L2_GROUP_INFO_T *ptr_group_info;           /* NB */
} HAL_L2_MCAST_FDB_CB_T;

typedef struct HAL_L2_MC_SC_INTF_INFO_S {
    HAL_VLAN_VID_CTL_T vid_ctl;
    UI32_T src_supp_tag;
    UI32_T vmid;
    UI32_T is_vmid_valid;
    UI32_T nvo3_adj_idx;
    UI32_T nvo3_encap_idx;
    UI32_T seg;
} HAL_L2_MC_SC_INTF_INFO_T;

typedef struct HAL_L2_FDB_EGR_INFO_S {
    UI32_T ueid_mgid;
    UI32_T seg_vmid;
    UI32_T src_supp_tag;
    HAL_VLAN_VID_CTL_T vid_ctl;
} HAL_L2_FDB_EGR_INTF_INFO_T;

typedef struct HAL_L2_POLLING_SW_ENTRY_S {
    UI32_T fdid;       /* avl key */
    CLX_MAC_T clx_mac; /* avl key */
    UI32_T is_valid;
    UI32_T is_new_learn;
    UI32_T entry_idx;
    HAL_L2_FDB_ENTRY_T fdb_entry;
} HAL_L2_POLLING_SW_ENTRY_T;

typedef struct HAL_L2_FADING_INFO_S {
    UI32_T interval_sec;
    UI32_T loop_cnt;
    UI32_T loop_tot_cnt;

    HAL_L2_FDB_ENTRY_T *ptr_dma_fdb_entry_not_align;
    HAL_L2_FDB_ENTRY_T *ptr_dma_fdb_entry;
} HAL_L2_FADING_INFO_T;

typedef struct HAL_L2_RING_INFO_S {
    UI32_T marker_entry_di;
    UI32_T marker_entry_fdb_idx;
    UI32_T loop_tot_cnt;

    UI32_T bubble_cnt;
    UI32_T ring_fail_cnt;
    UI32_T ring_fail_reset_cnt;
    UI32_T dma_node_fail_cnt;
    UI32_T inconsistent_entry_cnt;

    HAL_L2_FDB_ENTRY_T *ptr_clone_entry_dma_buf_not_align;
    HAL_L2_FDB_ENTRY_T *ptr_clone_entry_dma_buf;

    HAL_L2_FAST_CMD_ENTRY_T fast_find_bit_entry;
    HAL_L2_FAST_CMD_ENTRY_T fast_find_mask_entry;
    HAL_L2_FAST_CMD_ENTRY_T fast_replace_bit_entry_rsvd_val_0;
    HAL_L2_FAST_CMD_ENTRY_T fast_replace_bit_entry_rsvd_val_1;
    HAL_L2_FAST_CMD_ENTRY_T fast_replace_mask_entry;
} HAL_L2_RING_INFO_T;

typedef struct HAL_L2_POLLING_CB_S {
    CLX_THREAD_ID_T polling_task_id;

    UI32_T loop_tot_cnt;
    UI32_T no_update;
    CMLIB_AVL_HEAD_T *ptr_fdb_avl;
    HAL_L2_POLLING_SW_ENTRY_T *ptr_sw_fdb;
    HAL_L2_FDB_ENTRY_T *ptr_dma_fdb_entry_not_align;
    HAL_L2_FDB_ENTRY_T *ptr_dma_fdb_entry;

    CMLIB_LIST_T *ptr_list_1;
    CMLIB_LIST_T *ptr_list_2;
    CMLIB_LIST_T *ptr_callback_list; /* point to ptr_list_1 or ptr_list_2 */

    HAL_L2_FADING_INFO_T fading_info;
    HAL_L2_RING_INFO_T ring_info;
} HAL_L2_POLLING_CB_T;
typedef struct HAL_L2_ENTRY_INDEX_S {
    HAL_L2_FDB_HW_TYPE_T type;
    union {
        UI32_T hash_idx; /* use for hash index,
                          * bit 0~14: idx, bit15~17: tile,
                          * bit 18~19: stage, bit 20~23: inst */
        UI32_T tcam_id;  /* tcam allocate index */
    };
} HAL_L2_ENTRY_INDEX_T;
typedef struct HAL_L2_FIFO_SW_ENTRY_S {
    UI32_T fdid;       /* avl key. NB */
    CLX_MAC_T clx_mac; /* avl key. NB */
    UI32_T is_valid;
    UI32_T is_new_learn;
    HAL_L2_ENTRY_INDEX_T entry_idx; /* NB */
    UI32_T age_event_bit;           /* NB */
    UI32_T logical_mc_id;           /* NB. For mc fdb */
    HAL_L2_FDB_ENTRY_T fdb_entry;
} HAL_L2_FIFO_SW_ENTRY_T;

typedef struct HAL_L2_FIFO_CB_S {
    CLX_THREAD_ID_T fifo_task_id;
    UI32_T intr_num;           /* LT */
    HAL_INTR_TYPE_T *ptr_intr; /* LT */

    HAL_L2_FIFO_SW_ENTRY_T *ptr_sw_fdb;
    HAL_L2_FIFO_SW_ENTRY_T *ptr_sw_mc_fdb; /* NB */
    UI8_T *ptr_ring_buf_start_not_align;
    UI8_T *ptr_ring_buf_start;
    UI8_T *ptr_ring_buf_nxt_read;
    UI8_T *ptr_ring_buf_desc_start_not_align; /* NB */
    UI8_T *ptr_ring_buf_desc_start;           /* NB */
    UI32_T ring_buf_entry_num;
    UI32_T nxt_seq_num;                       /* LT: entry sequence number. NB: work idx */
    UI32_T lrn_en;                            /* LT */
    CMLIB_AVL_HEAD_T *ptr_fdb_avl;            /* NB */
    CMLIB_AVL_HEAD_T *ptr_mc_fdb_avl;         /* NB */
} HAL_L2_FIFO_CB_T;

typedef struct HAL_L2_FDB_NORIFY_HANDLER_S {
    CLX_L2_ADDR_NOTIFY_FUNC_T callback;
    void *ptr_cookie;
} HAL_L2_FDB_NOTIFY_HANDLER_T;
typedef struct HAL_L2_FDB_SW_LEARN_HANDLER_S {
    CLX_L2_ADDR_SW_LEARN_FUNC_T callback;
    void *ptr_cookie;
} HAL_L2_FDB_SW_LEARN_HANDLER_T;
typedef struct HAL_L2_FDB_CB_S {
    UI32_T operating_mode;
    UI32_T thread_pri;
    UI32_T thread_stack_size;
    HAL_L2_POLLING_CB_T polling_cb;
    HAL_L2_FIFO_CB_T fifo_cb;

    CLX_SEMAPHORE_ID_T fdb_mutex_sema_id;
    CLX_SEMAPHORE_ID_T notify_mutex_sema_id;   /* protect ptr_notify_handler */
    CLX_SEMAPHORE_ID_T sw_learn_mutex_sema_id; /* protect ptr_sw_learn_handler */
    UI32_T entry_num;
    HAL_L2_FDB_NOTIFY_HANDLER_T *ptr_notify_handler;
    HAL_L2_FDB_SW_LEARN_HANDLER_T *ptr_sw_learn_handler;
    HAL_L2_FDB_ENTRY_T fdb_entry_mask; /* used to clear the unused fields of fdb entry, LT */

    void *ptr_traverse_dma_fdb_entry_not_align;
    void *ptr_traverse_dma_fdb_entry;
#if defined(CLX_MOCK)
    UI32_T use_entry_num; /* tmp for get usage in asicsim */
#endif
} HAL_L2_FDB_CB_T;
typedef struct HAL_L2_TRAVERSE_CALLBACK_NODE_S {
    CLX_L2_ADDR_TRAVERSE_FUNC_T uc_callback;
    CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T mc_callback;
} HAL_L2_TRAVERSE_CALLBACK_NODE_T;
typedef struct HAL_L2_TRAVERSE_CALLBACK_INFO_S {
    HAL_L2_TYPE_T type;
    HAL_L2_TRAVERSE_CALLBACK_NODE_T callback;
    void *cookie;
} HAL_L2_TRAVERSE_CALLBACK_INFO_T;
typedef struct HAL_L2_TRAVERSE_NON_BLOCKING_CB_S {
    /* Thread control */
    CLX_THREAD_ID_T task_id;
    UI32_T thread_pri;
    UI32_T thread_stack_size;
    CLX_SEMAPHORE_ID_T traverse_mutex_sema_id;
    CLX_SEMAPHORE_ID_T callback_mutex_sema_id; /* protect ptr_callback_list */

    /* User callback parameters */
    CMLIB_LIST_T *ptr_callback_list;

} HAL_L2_TRAVERSE_NON_BLOCKING_CB_T;

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */
extern HAL_L2_FDB_CB_T _hal_l2_fdb_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern HAL_L2_MCAST_FDB_CB_T _hal_l2_mcast_fdb_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern HAL_L2_TRAVERSE_NON_BLOCKING_CB_T _hal_l2_traverse_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

I32_T
hal_l2_cmpFdbAvlNode(void *ptr_user_param, void *ptr_user_data, void *ptr_node_data);

void
hal_l2_freeListNode(void *ptr_node_data);

void
hal_l2_freeAvlNode(void *ptr_user_param, void *ptr_node_data);

void
hal_l2_notifyAddrCallback(const UI32_T unit,
                          const CLX_L2_ADDR_NOTIFY_REASON_T reason,
                          const CLX_L2_ADDR_T *ptr_addr);

void
hal_l2_swLearnAddrCallback(const UI32_T unit,
                           const CLX_L2_ADDR_SW_LEARN_REASON_T reason,
                           const CLX_L2_ADDR_T *ptr_addr);

void
hal_l2_handleCallback(const UI32_T unit,
                      CMLIB_LIST_T **ptr_callback_list,
                      CMLIB_LIST_T *ptr_list_1,
                      CMLIB_LIST_T *ptr_list_2);

void
hal_l2_addCallbackNode(const UI32_T unit,
                       const HAL_L2_CALLBACK_REASON_T reason,
                       const CLX_L2_ADDR_T *ptr_addr,
                       CMLIB_LIST_T *ptr_callback_list);

CLX_ERROR_NO_T
hal_l2_addTraverseCallbackNode(const UI32_T unit,
                               const HAL_L2_TYPE_T type,
                               const HAL_L2_TRAVERSE_CALLBACK_NODE_T callback,
                               void *ptr_cookie);

CLX_ERROR_NO_T
hal_l2_registerAddrNotifyCallback(const UI32_T unit,
                                  const CLX_L2_ADDR_NOTIFY_FUNC_T callback,
                                  void *ptr_cookie);

CLX_ERROR_NO_T
hal_l2_deregisterAddrNotifyCallback(const UI32_T unit,
                                    const CLX_L2_ADDR_NOTIFY_FUNC_T callback,
                                    void *ptr_cookie);

CLX_ERROR_NO_T
hal_l2_registerAddrSwLearnCallback(const UI32_T unit,
                                   const CLX_L2_ADDR_SW_LEARN_FUNC_T callback,
                                   void *ptr_cookie);

CLX_ERROR_NO_T
hal_l2_deregisterAddrSwLearnCallback(const UI32_T unit,
                                     const CLX_L2_ADDR_SW_LEARN_FUNC_T callback,
                                     void *ptr_cookie);

CLX_ERROR_NO_T
hal_l2_checkPortIsMyChipId(const UI32_T unit, const CLX_PORT_T port, BOOL_T *ptr_is_my_chip_id);

void
hal_l2_traverseSwShadow(const UI32_T unit, const HAL_L2_TYPE_T type);

void
hal_l2_traverseMcMbr(const UI32_T unit, const UI32_T mcast_id);

void
hal_l2_printMcastId(const UI32_T unit, const UI32_T tbl_id);

#endif /* End of HAL_L2_H */
