/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_led.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8600.
 *
 * NOTES:
 *
 */

#ifndef __HAL_MT_NAMCHABARWA_LED_H__
#define __HAL_MT_NAMCHABARWA_LED_H__

#include <api/diag.h>
#include <math.h>
#include <hal/hal_port.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_mac.h>

#define HAL_MT_NAMCHABARWA_LED_SERIAL_MAX_NUM           (4)
#define HAL_MT_NAMCHABARWA_LED_MAX_LED_BIT_NUM          (2304)
#define HAL_MT_NAMCHABARWA_LED_BIT_NUM_WIDTH            (11)
#define HAL_MT_NAMCHABARWA_LED_MEM_DEPTH                (2304)
#define HAL_MT_NAMCHABARWA_LED_BIT_CTRL_MAX_ADDR        (2048)
#define HAL_MT_NAMCHABARWA_LED_BIT_CTRL_LANE_OFFSET     (0)
#define HAL_MT_NAMCHABARWA_LED_BIT_CTRL_SPEED_OFFSET    (8)
#define HAL_MT_NAMCHABARWA_LED_BIT_CTRL_ADMIN_OFFSET    (22)
#define HAL_MT_NAMCHABARWA_LED_BIT_CTRL_LINK_OFFSET     (23)
#define HAL_MT_NAMCHABARWA_LED_BIT_CTRL_ACTIVE_OFFSET   (24)
#define HAL_MT_NAMCHABARWA_LED_BIT_CTRL_FORCE_OFFSET    (26)
#define HAL_MT_NAMCHABARWA_LED_BIT_CTRL_CFG_DATA_OFFSET (5)
#define HAL_MT_NAMCHABARWA_LED_LANE_STAT_SPEED_OFFSET   (0)
#define HAL_MT_NAMCHABARWA_LED_LANE_STAT_ADMIN_OFFSET   (14)
#define HAL_MT_NAMCHABARWA_LED_LANE_STAT_ADMIN_OFFSET   (14)
#define HAL_MT_NAMCHABARWA_LED_LANE_STAT_LINK_OFFSET    (15)
#define HAL_MT_NAMCHABARWA_LED_LANE_STAT_TX_STAT_OFFSET (16)
#define HAL_MT_NAMCHABARWA_LED_LANE_STAT_RX_STAT_OFFSET (17)

typedef enum {
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_800GR8 = (1U << 0), /* 800G R8 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_400GR4 = (1U << 1), /* 400G R4 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_400GR8 = (1U << 2), /* 400G R8 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_200GR2 = (1U << 3), /* 200G R2 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_200GR4 = (1U << 4), /* 200G R4 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_200GR8 = (1U << 5), /* 200G R8 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_100GR1 = (1U << 6), /* 100G R1 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_100GR2 = (1U << 7), /* 100G R2 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_100GR4 = (1U << 8), /* 100G R4 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_50GR1 = (1U << 9),  /* 50G R1 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_50GR2 = (1U << 10), /* 50G R2 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_40GR4 = (1U << 11), /* 40G R4 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_25GR1 = (1U << 12), /* 25G R1 */
    HAL_MT_NAMCHABARWA_LED_SPEED_ABILITY_10GR1 = (1U << 13), /* 10G R1 */
} HAL_MT_NAMCHABARWA_LED_SPEED_T;

typedef enum {
    HAL_MT_NAMCHABARWA_LED_MODE_TYPE_NORMAL = 0x0,
    HAL_MT_NAMCHABARWA_LED_MODE_TYPE_BIT_ON,
    HAL_MT_NAMCHABARWA_LED_MODE_TYPE_BIT_OFF,
    HAL_MT_NAMCHABARWA_LED_MODE_TYPE_LAST
} HAL_MT_NAMCHABARWA_LED_MODE_TYPE_T;

typedef struct HAL_MT_NAMCHABARWA_LED_MEM_DATA_S {
    UI32_T lane_id;
    UI32_T speed_ability;
    UI32_T admin_en;
    UI32_T linkup;
    UI32_T active;
    HAL_MT_NAMCHABARWA_LED_MODE_TYPE_T force_mode;
    UI32_T tx_status;
    UI32_T rx_status;
} HAL_MT_NAMCHABARWA_LED_MEM_DATA_T;

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_transSpeedToSpeedAbi(UI32_T unit,
                                            HAL_MT_NAMCHABARWA_MAC_CHMODE_E port_speed_lane,
                                            HAL_MT_NAMCHABARWA_LED_SPEED_T *led_speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setCtlLedControl(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getCtlLedControl(UI32_T unit, UI32_T *buf);

/**
 * @brief To set led start
 *
 * @param [in]     unit      - Chip id
 * @param [in]     led_id    - led id, range 0-3
 * @param [in]     buf       - led start bit value
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setCtlLedStartAddr(UI32_T unit, UI32_T led_id, UI32_T *buf);

/**
 * @brief To get led start bit
 *
 * @param [in]     unit      - Chip id
 * @param [in]     led_id    - led id, range 0-3
 * @param [out]    buf       - led start bit value
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getCtlLedStartAddr(UI32_T unit, UI32_T led_id, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setCtlLedEndAddr(UI32_T unit, UI32_T led_id, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getCtlLedEndAddr(UI32_T unit, UI32_T led_id, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setCtlLedMemEccCtrl(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getCtlLedMemEccCtrl(UI32_T unit, UI32_T *buf);

/**
 * @brief To set led memory tod ecc interrupt, write 1 to clear
 *
 * bit0: ecc_single_err_int
 * bit1: ecc_double_err_int
 * write 1 to clear
 *
 * @param [in]     unit    - Chip id
 * @param [in]     buf     - led mem tod ecc
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setIntLedMemTodEcc(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getIntLedMemTodEcc(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setIntLedMemTodEccMsk(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getIntLedMemTodEccMsk(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setIntLedMemTodEccTst(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getIntLedMemTodEccTst(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getSymLedMemTopErrInfo(UI32_T unit, UI32_T *buf);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrlLaneId(UI32_T unit, UI32_T led_bit, UI32_T lane_id);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrlSpeed(UI32_T unit,
                                          UI32_T led_bit,
                                          HAL_MT_NAMCHABARWA_LED_SPEED_T speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrlSpeedAbility(UI32_T unit, UI32_T led_bit, UI32_T speed_ability);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrlAdminEn(UI32_T unit, UI32_T led_bit, UI32_T admin_en);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrlLinkup(UI32_T unit, UI32_T led_bit, UI32_T linkup);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrlActive(UI32_T unit, UI32_T led_bit, UI32_T active);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrlForceMode(UI32_T unit,
                                              UI32_T led_bit,
                                              HAL_MT_NAMCHABARWA_LED_MODE_TYPE_T force_mode);

/**
 * @brief To set led bit contrl message
 *
 * led memory shared by 4 led modules
 *
 * @param [in]     unit       - Chip id
 * @param [in]     led_bit    - led bit, range 0-2047
 *                              --  bit[7:0], lane_id, range 0-255
 *                              --  bit[21:8], speed ability
 *                              --  bit[22:22], admin_en
 *                              --  bit[23:23], linkup
 *                              --  bit[25:24], active, 2'b00/11:RXTX, 2'b01:TX, 2'b10:RX
 *                              --  bit[27:26], force_mode, 2'b00/11:actual, 2'b01: on, 2'b10: off
 * @param [in]     ptr_data   - led mem data
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrl(UI32_T unit,
                                     UI32_T led_bit,
                                     HAL_MT_NAMCHABARWA_LED_MEM_DATA_T *ptr_data);

/**
 * @brief To set led bit contrl message
 *
 * led memory shared by 4 led modules
 *
 * @param [in]     unit       - Chip id
 * @param [in]     led_bit    - led bit, range 0-2047
 * @param [out]    ptr_data   - led mem data
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getLedBitCtrl(UI32_T unit,
                                     UI32_T led_bit,
                                     HAL_MT_NAMCHABARWA_LED_MEM_DATA_T *ptr_data);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLedBitCtrlData(UI32_T unit, UI32_T led_bit, UI32_T *ptr_data);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLaneStatusSpeed(UI32_T unit,
                                          UI32_T port,
                                          HAL_MT_NAMCHABARWA_MAC_CHMODE_E speed);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLaneStatusAdminEn(UI32_T unit, UI32_T lane_id, UI32_T admin_en);

/**
 * @brief To set led lane status
 *
 * @param [in]     unit        - Chip id
 * @param [in]     lane_id     - lane_id, range 0-255
 * @param [in]     speed       - speed ability, bit[13:0]
 * @param [in]     admin_en    - bit[14:14]
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_led_setLaneStatus(UI32_T unit, UI32_T lane_id, UI32_T speed, UI32_T admin_en);

/**
 * @brief To set led lane status
 *
 * @param [in]     unit       - Chip id
 * @param [in]     lane_id    - lane_id, range 0-255
 * @param [out]    ptr_data   - led mem data
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getLaneStatus(UI32_T unit,
                                     UI32_T lane_id,
                                     HAL_MT_NAMCHABARWA_LED_MEM_DATA_T *ptr_data);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_getPortLedCfg(const UI32_T cfg_id, UI32_T **pptr_fw, UI32_T *ptr_fw_size);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_initMem(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_led_init(const UI32_T unit);

#endif
