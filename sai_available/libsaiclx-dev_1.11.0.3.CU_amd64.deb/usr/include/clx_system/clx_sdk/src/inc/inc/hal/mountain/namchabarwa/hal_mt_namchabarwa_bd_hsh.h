/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_bd_hsh.h
 * PURPOSE:
 *  Define the declartion for bd hash module for CL8600.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_BD_HSH_H
#define HAL_MT_NAMCHABARWA_BD_HSH_H

#include <clx_types.h>
#include <clx_error.h>
#include <clx_swc.h>
#include <clx_vlan.h>
#include <hal/hal_const_cmn.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum {
    HAL_MT_NAMCHABARWA_BD_HSH_MODULE_VLAN,
    HAL_MT_NAMCHABARWA_BD_HSH_MODULE_PORT,
    HAL_MT_NAMCHABARWA_BD_HSH_MODULE_PORT_VLAN,
    HAL_MT_NAMCHABARWA_BD_HSH_MODULE_PVLAN,
    HAL_MT_NAMCHABARWA_BD_HSH_MODULE_L3,
    HAL_MT_NAMCHABARWA_BD_HSH_MODULE_MPLS,
    HAL_MT_NAMCHABARWA_BD_HSH_MODULE_NV,
    HAL_MT_NAMCHABARWA_BD_HSH_MODULE_LAST,
} HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T;

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_NAMCHABARWA_BD_HSH_LOCK(unit)   hal_mt_namchabarwa_bd_lockhshResource(unit)
#define HAL_MT_NAMCHABARWA_BD_HSH_UNLOCK(unit) hal_mt_namchabarwa_bd_unlockhshResource(unit)

/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_MT_NAMCHABARWA_BD_HSH_BDI_INFO_S {
    UI32_T lcl_intf;        /* Key, logic interface */
    UI32_T s_vlan;          /* Key, service VLAN */
    UI32_T c_vlan;          /* Key, customer VLAN */
    UI32_T bdi;             /* Value, bridge domain ID */
    UI32_T pvlan_port_type; /* value, pvlan port type */
} HAL_MT_NAMCHABARWA_BD_HSH_BDI_INFO_T;

typedef struct HAL_MT_NAMCHABARWA_BD_HSH_VLAN_INFO_S {
    UI32_T lcl_intf;        /* Key, logic interface */
    UI32_T bdi;             /* Key, bridge domain ID */
    UI32_T s_vlan;          /* Value, service VLAN */
    UI32_T c_vlan;          /* Value, customer VLAN */
    UI32_T s_vlan_opt;      /* Value, service VLAN operation */
    UI32_T c_vlan_opt;      /* Value, customer VLAN operation */
    UI32_T pvlan_port_type; /* Value, pvlan port type */
    UI32_T keep_src_vlan;   /* Value, keep source VLAN tag */
} HAL_MT_NAMCHABARWA_BD_HSH_VLAN_INFO_T;

/* MACRO API DECLARATIONS
 */

/* Init dis_hsh_bdi info key */
#define HAL_MT_NAMCHABARWA_BD_INIT_HSH_BDI_INFO_KEY(hsh_info, lcl_port, svid, cvid) \
    do {                                                                            \
        (hsh_info).lcl_intf = lcl_port;                                             \
        (hsh_info).s_vlan = (svid);                                                 \
        (hsh_info).c_vlan = (cvid);                                                 \
    } while (0)

/* Init rwi_hsh_vlan info key */
#define HAL_MT_NAMCHABARWA_BD_INIT_HSH_VLAN_INFO_KEY(hsh_info, lcl_port, bdid) \
    do {                                                                       \
        (hsh_info).lcl_intf = lcl_port;                                        \
        (hsh_info).bdi = (bdid);                                               \
    } while (0)

/* Init dis_hsh_bdi info */
#define HAL_MT_NAMCHABARWA_BD_INIT_HSH_BDI_INFO(hsh_info, lcl_port, svid, cvid, bdid) \
    do {                                                                              \
        (hsh_info).lcl_intf = lcl_port;                                               \
        (hsh_info).s_vlan = (svid);                                                   \
        (hsh_info).c_vlan = (cvid);                                                   \
        (hsh_info).bdi = (bdid);                                                      \
        (hsh_info).pvlan_port_type = (HAL_MT_NAMCHABARWA_PVLAN_PORT_TYPE_NORMAL);     \
    } while (0)

/* Init rwi_hsh_vlan info */
#define HAL_MT_NAMCHABARWA_BD_INIT_HSH_VLAN_INFO(hsh_info, lcl_port, bdid, svid, cvid, s_opt, \
                                                 c_opt, keep_src)                             \
    do {                                                                                      \
        (hsh_info).lcl_intf = lcl_port;                                                       \
        (hsh_info).bdi = (bdid);                                                              \
        (hsh_info).s_vlan = (svid);                                                           \
        (hsh_info).c_vlan = (cvid);                                                           \
        (hsh_info).s_vlan_opt = (s_opt);                                                      \
        (hsh_info).c_vlan_opt = (c_opt);                                                      \
        (hsh_info).pvlan_port_type = (HAL_MT_NAMCHABARWA_PVLAN_PORT_TYPE_NORMAL);             \
        (hsh_info).keep_src_vlan = (keep_src);                                                \
    } while (0)

/**
 * @brief Dis_hsh_bdi/rwi_hsh_vlan lock.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_lockhshResource(const UI32_T unit);

/**
 * @brief Dis_hsh_bdi/rwi_hsh_vlan unlock.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_unlockhshResource(const UI32_T unit);

/**
 * @brief Add DIS_HSH_BDI hash table. Exposed to other module.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - Module ID
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_addDisHshBdi(const UI32_T unit,
                                   const HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T module,
                                   const HAL_MT_NAMCHABARWA_BD_HSH_BDI_INFO_T *hash_info);

/**
 * @brief Delete ingress DIS_HSH_BDI hash table. Exposed to other module.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - Module ID
 * @param [in]     hash_info    - Hash information, lcl_intf/svid/cvid is key
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_delDisHshBdi(const UI32_T unit,
                                   const HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T module,
                                   const HAL_MT_NAMCHABARWA_BD_HSH_BDI_INFO_T *hash_info);

/**
 * @brief Get DIS_HSH_BDI hash table. Exposed to other module.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - Module ID
 * @param [in]     hash_info    - Hash information, lcl_intf/svid/cvid
 * @param [out]    hash_info    - Hash information, bdid/pvlan_port_type
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_getDisHshBdi(const UI32_T unit,
                                   const HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T module,
                                   HAL_MT_NAMCHABARWA_BD_HSH_BDI_INFO_T *hash_info);

/**
 * @brief Update ingress hash table to vlan.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User mode
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_updateDisHshBdi(const UI32_T unit,
                                      const HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T module,
                                      const HAL_MT_NAMCHABARWA_BD_HSH_BDI_INFO_T *hash_info);

/**
 * @brief Add RWI_HSH_VLAN hash table. Exposed to other module.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User ID
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_addRwiHshVlan(const UI32_T unit,
                                    const HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T module,
                                    const HAL_MT_NAMCHABARWA_BD_HSH_VLAN_INFO_T *hash_info);

/**
 * @brief Delete egress hash table to vlan.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User mode
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK     - Operate success.
 * @return         others       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_delRwiHshVlan(const UI32_T unit,
                                    const HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T module,
                                    const HAL_MT_NAMCHABARWA_BD_HSH_VLAN_INFO_T *hash_info);

/**
 * @brief User update egress hash table.
 *
 * just for clx_port_setVlanTagCtrl use, other module use hal_mt_namchabarwa_bd_updateRwiHshVlan
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_userUpdateRwiHshVlan(const UI32_T unit,
                                           const HAL_MT_NAMCHABARWA_BD_HSH_VLAN_INFO_T *hash_info);

/**
 * @brief Update egress hash table to vlan.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User mode
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_updateRwiHshVlan(const UI32_T unit,
                                       const HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T module,
                                       const HAL_MT_NAMCHABARWA_BD_HSH_VLAN_INFO_T *hash_info);

/**
 * @brief Delete egress hash table to vlan.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User mode
 * @param [in]     hash_info    - Hash key, lcl_intf/bdid
 * @param [out]    hash_info    - Hash value, s_vlan/c_vlan/pvlan_port_type/keep_src_vlan
 * @return         CLX_E_OK     - Operate success.
 * @return         others       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_getRwiHshVlan(const UI32_T unit,
                                    const HAL_MT_NAMCHABARWA_BD_HSH_MODULE_T module,
                                    HAL_MT_NAMCHABARWA_BD_HSH_VLAN_INFO_T *hash_info);

/**
 * @brief Get egress hash table.
 *
 * just for clx_port_getVlanTagCtrl use, other module use hal_mt_namchabarwa_bd_updateRwiHshVlan
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     hash_info    - Hash key, lcl_intf/bdid
 * @param [out]    hash_info    - Hash value, s_vlan/c_vlan/pvlan_port_type/keep_src_vlan
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_userGetRwiHshVlan(const UI32_T unit,
                                        HAL_MT_NAMCHABARWA_BD_HSH_VLAN_INFO_T *hash_info);

/**
 * @brief Update hash entry when vlan tag mode change
 *
 * Must call in hsh lock
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     lcl_intf             - Logic interface
 * @param [in]     old_vlan_tag_mode    - Port old vlan tag mode
 * @param [in]     new_vlan_tag_mode    - New old vlan tag mode
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Operate fail.
 */
CLX_ERROR_NO_T
_hal_mt_namchabarwa_bd_updateVlanTagMode(
    const UI32_T unit,
    const UI32_T lcl_intf,
    const HAL_MT_NAMCHABARWA_HW_VLAN_TAG_MODE_T old_vlan_tag_mode,
    const HAL_MT_NAMCHABARWA_HW_VLAN_TAG_MODE_T new_vlan_tag_mode);

/**
 * @brief Warmboot init dis_hsh_bdi list.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Logic interface
 * @param [in]     obj         - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_igrHshListWarmInit(const UI32_T unit,
                                         const UI32_T lcl_intf,
                                         const HAL_IO_OBJ_META_T *obj);

/**
 * @brief Warmboot init rwi_hsh_vlan entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Logic interface
 * @param [in]     obj         - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_egrHshListWarmInit(const UI32_T unit,
                                         const UI32_T lcl_intf,
                                         const HAL_IO_OBJ_META_T *obj);

/**
 * @brief Warmboot init port isolated.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     obj     - Object meta
 */
void
hal_mt_namchabarwa_bd_portIsoWarmInit(const UI32_T unit, const HAL_IO_OBJ_META_T *obj);

/**
 * @brief Warmboot deinit dis_hsh_bdi hash entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Logic interface
 * @param [in]     obj         - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_igrHshListWarmDeinit(const UI32_T unit,
                                           const UI32_T lcl_intf,
                                           HAL_IO_OBJ_META_T *obj);

/**
 * @brief Warmboot deinit rwi_hsh_vlan hash entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Logic interface
 * @param [in]     obj         - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_egrHshListWarmDeinit(const UI32_T unit,
                                           const UI32_T lcl_intf,
                                           HAL_IO_OBJ_META_T *obj);

/**
 * @brief Warmboot deinit port isolated.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     obj     - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_portIsoWarmDeinit(const UI32_T unit, HAL_IO_OBJ_META_T *obj);

/**
 * @brief Init dis_hsh_bdi and rwi_hsh_vlan entry.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_HashInit(const UI32_T unit);

/**
 * @brief Deinit dis_hsh_bdi and rwi_hsh_vlan entry.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_hashDeinit(const UI32_T unit);

/**
 * @brief Show dis_hsh_bdi entry.
 *
 * support show hash entry by lcl-intf.
 * support show hash entry by lcl-intf + vlan
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - lcl intferface
 * @param [in]     s_vlan      - Service vlan
 * @param [in]     c_vlan      - Customer vlan
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_showDisHshBdiEntry(const UI32_T unit,
                                         const UI32_T lcl_intf,
                                         const CLX_VLAN_T s_vlan,
                                         const CLX_VLAN_T c_vlan);

/**
 * @brief Show rwi_hsh_vlan entry.
 *
 * support show hash entry by lcl-intf.
 * support show hash entry by lcl-intf + bdi
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - lcl intferface
 * @param [in]     bdi         - Bridge domain index
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_showRwiHshVlanEntry(const UI32_T unit,
                                          const UI32_T lcl_intf,
                                          const CLX_BRIDGE_DOMAIN_T bdi);

/**
 * @brief Add isolated port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Local interface
 * @param [in]     dir         - Set direction
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_addIsolatedPort(const UI32_T unit,
                                      const UI32_T lcl_intf,
                                      const CLX_DIR_T dir);

/**
 * @brief Delete isolated port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Local interface
 * @param [in]     dir         - Set direction
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_bd_delIsolatedPort(const UI32_T unit,
                                      const UI32_T lcl_intf,
                                      const CLX_DIR_T dir);

#endif
