/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_l3.h
 * PURPOSE:
 *      It provides hal l3 module API.
 * NOTES:
 *
 *
 */
#ifndef HAL_L3_H
#define HAL_L3_H

/*****************************************************************************
 * INCLUDE FILE DECLARATIONS
 *****************************************************************************
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_swc.h>
#include <clx_fcoe.h>
#include <clx_l3.h>
#include <cmlib/cmlib_util.h>
#include <cmlib/cmlib_avl.h>
#include <cmlib/cmlib_list.h>
#include <cmlib/cmlib_bit.h>
#include <cmlib/cmlib_bitmap.h>
#include <hal/hal_vlan.h>
#include <hal/hal_tbl.h>
#include <hal/hal_io.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
#define HAL_L3_ECMP_SW_MODE_SYNC (1)
#define HAL_L3_RPF_NUM           (16384)
#define HAL_L3_TAPPING_DISABLE   (0)

/* Capacity and Usage */
typedef enum HAL_L3_PARAM_E {
    HAL_L3_PARAM_V4_V6 = 0,
    HAL_L3_PARAM_V4,
    HAL_L3_PARAM_V6,
    HAL_L3_PARAM_V4_REALTIME_MAX,    /* available v4 count */
    HAL_L3_PARAM_V6_2X_REALTIME_MAX, /* available v6 mask 64 count */
    HAL_L3_PARAM_V6_4X_REALTIME_MAX, /* available v6 mask 128 count */
    HAL_L3_PARAM_TYPE_LAST
} HAL_L3_PARAM_T;

/* INTF */
#define HAL_L3_INTF_ENTRY_NUM(unit) \
    (HAL_TBL_INFO(unit, LT_TBL_IDS_RSLT_SRV_L3_INTF_ID)->entry_max_number)
#define HAL_L3_INTF_ENTRY_MIN(unit) (1) /* SW-reserved 0 to disable routing with vrf=all-1. */
#define HAL_L3_INTF_ENTRY_MAX(unit) \
    (HAL_L3_INTF_ENTRY_NUM(unit) - 2)   /* HW-reserved all-1 to use outer vid as L3 Intf */

#define HAL_L3_MTU_SIZE (16383)

/* VRF */
#define HAL_L3_VRF_ENTRY_NUM(unit) \
    (HAL_TBL_INFO(unit, LT_TBL_ILE_RSLT_VRF_ID)->entry_max_number / 2)
#define HAL_L3_VRF_ENTRY_MIN(unit) (0)
#define HAL_L3_VRF_ENTRY_MAX(unit) (HAL_L3_VRF_ENTRY_NUM(unit) - 2)
#define HAL_L3_VRF_ENTRY_ALL_1(unit) \
    (HAL_L3_VRF_ENTRY_NUM(unit) - 1) /* HW-reserved all-1 for (*,IP) */

#define HAL_L3_VRF_ADMIN_STATE_ENABLE  (1)
#define HAL_L3_VRF_ADMIN_STATE_DISABLE (0)

/* ADJ */
#define HAL_L3_FRR_INVALID_GRP_ID (0xFFFFFFFF)
#define HAL_L3_RESERVE_ADJ_ID     (0)

/* Route */
#define HAL_L3_ROUTE_ROOT_WORD_NUM (4)  /* Word32 num */
#define HAL_L3_ROUTE_ROOT_BYTE_NUM (16) /* Byte num */
#define HAL_L3_ROUTE_TRIE_BIT_MAX  (31) /* trie bit num */

#define HAL_L3_ROUTE_INSERT_TCAM (0)    /* tcam hw      */
#define HAL_L3_ROUTE_INSERT_HASH (1)    /* hash hw      */

#define HAL_L3_ROUTE_INSERT_MODE (0)    /* alloc iev for insert      */
#define HAL_L3_ROUTE_DELETE_MODE (1)    /* alloc iev fot delete      */

/* ECMP */
#define HAL_L3_ECMP_PATH_ENCAP_IDX_MIN (8192)

#define HAL_L3_ECMP_PATH_MAX_TOT         (1U << 13) /* act_tot = MAX      */
#define HAL_L3_ECMP_PATH_MAX_TOT_IN_CHIP (0)        /* act_tot = 0        */
#define HAL_L3_ECMP_HSH_MAX_TOT          (1U << 15) /* sw_spray_tot = MAX */
#define HAL_L3_ECMP_HSH_MAX_TOT_IN_CHIP  (0)        /* sw_spray_tot = 0   */

#define HAL_L3_ECMP_PATH_DFLT_BASE_IDX (16383)      /* default act_base or orig_base */
#define HAL_L3_ECMP_PATH_DFLT_TOT      (0)          /* default act_tot or orig_tot   */
#define HAL_L3_ECMP_HSH_DFLT_BASE_IDX  (32767)      /* default sw_spray_base         */
#define HAL_L3_ECMP_HSH_DFLT_TOT       (0)          /* default sw_spray_tot          */
#define HAL_L3_ECMP_HSH_DFLT_OFFSET    (8191)       /* default offset                */

/* MCAST */
#define HAL_L3_MCAST_PER_GROUP_PER_PORT_MAX_EGR_INTF_NUM (8192)

#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UI64_RSHIFT(dst, shift) ((dst) >>= (shift))
#define UI64_LSHIFT(dst, shift) ((dst) <<= (shift))
#else
#define UI64_RSHIFT(dst, shift)                             \
    do {                                                    \
        if (64 == (shift)) {                                \
            UI64_LOW(dst) = 0;                              \
            UI64_HI(dst) = 0;                               \
        } else if ((shift) >= 32) {                         \
            UI64_LOW(dst) = UI64_HI(dst) >> ((shift) - 32); \
            UI64_HI(dst) = 0;                               \
        } else if ((shift) > 0) {                           \
            UI32_T temp = 0;                                \
            UI64_LOW(dst) >>= (shift);                      \
            temp = UI64_HI(dst) & ((1U << (shift)) - 1);    \
            UI64_LOW(dst) |= temp << (32 - (shift));        \
            UI64_HI(dst) >>= (shift);                       \
        }                                                   \
    } while (0)

#define UI64_LSHIFT(dst, shift)                             \
    do {                                                    \
        if (64 == (shift)) {                                \
            UI64_HI(dst) = 0;                               \
            UI64_LOW(dst) = 0;                              \
        } else if ((shift) >= 32) {                         \
            UI64_HI(dst) = UI64_LOW(dst) << ((shift) - 32); \
            UI64_LOW(dst) = 0;                              \
        } else if ((shift) > 0) {                           \
            UI32_T temp = 0;                                \
            UI64_HI(dst) <<= (shift);                       \
            temp = UI64_LOW(dst) & (~(32 - (shift)));       \
            UI64_HI(dst) |= temp >> (32 - (shift));         \
            UI64_LOW(dst) <<= (shift);                      \
        }                                                   \
    } while (0)

#endif

/*****************************************************************************
 * MACRO FUNCTION DECLARATIONS
 *****************************************************************************
 */
/* Checker */
#define HAL_L3_IP_IS_MULTICAST(ptr_ip)                                               \
    ((TRUE == (ptr_ip)->ipv4) ? CLX_IPV4_IS_MULTICAST((ptr_ip)->ip_addr.ipv4_addr) : \
                                CLX_IPV6_IS_MULTICAST((ptr_ip)->ip_addr.ipv6_addr))

#define HAL_L3_IP_IS_ZERO(ptr_ip)                  \
    ((TRUE == (ptr_ip)->ipv4) ?                    \
         (0x0 == (ptr_ip)->ip_addr.ipv4_addr) :    \
         (0x0 == (ptr_ip)->ip_addr.ipv6_addr[0] && \
          0 == osal_memcmp((ptr_ip)->ip_addr.ipv6_addr, (ptr_ip)->ip_addr.ipv6_addr + 1, 15)))

#define HAL_L3_IP_MASK_IS_ZERO(ptr_ip)             \
    ((TRUE == (ptr_ip)->ipv4) ?                    \
         (0x0 == (ptr_ip)->ip_mask.ipv4_addr) :    \
         (0x0 == (ptr_ip)->ip_mask.ipv6_addr[0] && \
          0 == osal_memcmp((ptr_ip)->ip_mask.ipv6_addr, (ptr_ip)->ip_mask.ipv6_addr + 1, 15)))

#define HAL_L3_IP_MASK_IS_FULLMSK(ptr_ip)               \
    ((TRUE == (ptr_ip)->ipv4) ?                         \
         (0xFFFFFFFFU == (ptr_ip)->ip_mask.ipv4_addr) : \
         (0xFF == (ptr_ip)->ip_mask.ipv6_addr[0] &&     \
          0 == osal_memcmp((ptr_ip)->ip_mask.ipv6_addr, (ptr_ip)->ip_mask.ipv6_addr + 1, 15)))

#define HAL_L3_CHK_IP_VER_MATCH(ip1, ip2)         \
    do {                                          \
        if ((ip1).ipv4 != (ip2).ipv4) {           \
            HAL_CHECK_ERROR(CLX_E_BAD_PARAMETER); \
        }                                         \
    } while (0)

#define HAL_L3_CHK_FLW_LBL(__unit__, __tbl_id__, __field_id__, __flw_lbl__)                  \
    do {                                                                                     \
        if (!HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __flw_lbl__)) { \
            DIAG_PRINT(HAL_DBG_L3, HAL_DBG_WARN, "u=%u, invalid group_label=%d\n", __unit__, \
                       __flw_lbl__);                                                         \
            return CLX_E_BAD_PARAMETER;                                                      \
        }                                                                                    \
    } while (0)

/* utility */
#define HAL_L3_PLANE_BMP_FOREACH(__unit__, __plane__)                           \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (CMLIB_BITMAP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

#define HAL_L3_ERROR_RETRUN(module, rc, fmt, args...)                                          \
    {                                                                                          \
        if (CLX_E_OK != rc) {                                                                  \
            DIAG_PRINT(module, HAL_DBG_ERR, "[error:%s-%d]:" fmt, clx_error_getString(rc), rc, \
                       ##args);                                                                \
            return rc;                                                                         \
        }                                                                                      \
    }

#define HAL_L3_ERROR_NO_RETRUN(module, rc, fmt, args...)                                       \
    {                                                                                          \
        if (CLX_E_OK != rc) {                                                                  \
            DIAG_PRINT(module, HAL_DBG_ERR, "[error:%s-%d]:" fmt, clx_error_getString(rc), rc, \
                       ##args);                                                                \
        }                                                                                      \
    }

#define HAL_L3_WARN_NO_RETRUN(module, rc, fmt, args...)                                        \
    {                                                                                          \
        if (CLX_E_OK != rc) {                                                                  \
            DIAG_PRINT(module, HAL_DBG_WARN, "[warn:%s-%d]:" fmt, clx_error_getString(rc), rc, \
                       ##args);                                                                \
        }                                                                                      \
    }

#define HAL_L3_ERROR_GOTO_LABEL(module, rc, label, fmt, args...)                               \
    {                                                                                          \
        if (CLX_E_OK != rc) {                                                                  \
            DIAG_PRINT(module, HAL_DBG_ERR, "[error:%s-%d]:" fmt, clx_error_getString(rc), rc, \
                       ##args);                                                                \
            goto label;                                                                        \
        }                                                                                      \
    }

/*****************************************************************************
 * DATA TYPE DECLARATIONS
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- Common */
/* Dump SWDB */
typedef enum {
    HAL_L3_DB_DUMP_FLAGS_INTF = 0,
    HAL_L3_DB_DUMP_FLAGS_HOST,
    HAL_L3_DB_DUMP_FLAGS_ROUTE,
    HAL_L3_DB_DUMP_FLAGS_ADJ,
    HAL_L3_DB_DUMP_FLAGS_ECMP,
    HAL_L3_DB_DUMP_FLAGS_MCAST,
    HAL_L3_DB_DUMP_FLAGS_VRF,
    HAL_L3_DB_DUMP_FLAGS_RMAC,
    HAL_L3_DB_DUMP_FLAGS_LAST,

} HAL_L3_DB_DUMP_FLAGS_T;

typedef struct HAL_L3_IEV_RSRC_S {
    /* hal_l3_allocIev      get iev_idx by User data
     * hal_l3_freeIev       free iev_idx
     * hal_l3_getIev        read HW data
     * hal_l3_resolveIev    resolve HW data to User data
     * hal_l3_transIevInfo  resolve port and intf_id to HW data (packPathBuf)
     *                      resolve HW data to port and intf_id (unpackPathBuf)
     */

    /* HW data */
    UI32_T typ;       /* SubnetBcast|Mcast            */
    UI32_T adj_idx;   /* Host|Route                   */
    UI32_T ueid_mgid; /* Host|Route|SubnetBcast|Mcast */
    UI32_T seg_vmid;  /* Host|Route                   */
    UI32_T decr_ttl;  /* SubnetBcast                  */

    /* User data */
    CLX_L3_OUTPUT_TYPE_T output_type; /* Host|Route             */
    UI32_T output_id;                 /* Host|Route             */
    UI32_T subnet_bc_id;              /* SubnetBcast            */
    UI32_T subnet_bc_en;              /* SubnetBcast            */
    UI32_T mcast_id;                  /* Mcast                  */
    UI32_T mcast_en;                  /* Mcast                  */
    UI32_T mpls_label;                /* Host|Route             */
    UI32_T mpls_en;                   /* Host|Route             */
    UI32_T uc_drop;                   /* Host|Route             */
    UI32_T mc_drop;                   /* Mcast                  */
    UI32_T pim_reg;                   /* Mcast                  */

    /* Both */
    UI32_T cp_to_cpu_idx;   /* Mcast              */
    UI32_T pim_sm_spt_rdy;  /* Mcast              */
    UI32_T mrpf_fail_act;   /* Mcast              */
    UI32_T l3_intf_id;      /* Mcast              */
    UI32_T acc_intf_is_sig; /* Mcast              */

} HAL_L3_IEV_RSRC_T;

/* ----------------------------------------------------------------------------------- INTF */
typedef struct HAL_L3_INTF_RSRC_S {
    /* resources waited to be free */
    UI32_T ids_mtu_idx;    /* l3_mtu_idx       : IDS_RSLT_L3_MTU        */
    UI32_T ids_prof_idx;   /* cnt_mtr_prof_idx : ICIA_RSLT_CNT|CLR_PROF */
    UI32_T iev_mtu_idx;    /* l3_mtu_idx       : IEV_RSLT_L3_MTU        */
    UI32_T igr_sflw_idx;   /* sflw_idx */
    UI32_T igr_hw_mtr_idx; /* mtr_idx */
    UI32_T igr_hw_cnt_idx;
    UI32_T igr_hw_dist_cnt_idx;
    UI32_T emi_sa_idx;     /* l2_sa_idx        : EMI_RSLT_MAC_SA        */
    UI32_T emi_mtu_idx;    /* l3_mtu_idx       : EMI_RSLT_L3_MTU        */
    UI32_T emi_prof_idx;   /* cnt_mtr_prof_idx : ECIA_RSLT_CNT|CLR_PROF */
    UI32_T egr_sflw_idx;   /* sflw_idx */
    UI32_T egr_hw_mtr_idx; /* mtr_idx */
    UI32_T egr_hw_cnt_idx;
    UI32_T egr_hw_dist_cnt_idx;

    /* when these fields are changed, traverse ADJ to find (ecmp|frr, intf) */
    UI32_T urpf_mode;
    UI32_T icmpv4_redir;
    UI32_T icmpv6_redir;

} HAL_L3_INTF_RSRC_T;

typedef struct HAL_L3_INTF_MTU_RSRC_S {
    BOOL_T mtu_vld; /* Valid */
    UI32_T mtu;     /* L3 MTU size */
    UI32_T use_num; /* Reference count of MTU */

} HAL_L3_INTF_MTU_CFG_T;

typedef struct HAL_L3_INTF_CB_S {
    UI32_T iev_l2uc_drop_idx; /* Hit my_rte_mac but HW can't route */
    UI32_T *ptr_intf2fdid;    /* Array of l3 interface */
    UI32_T *ptr_intf2vrf;     /* Array of vrf */
    UI32_T *ptr_fdid2intf;    /* Array of bdid */
    CLX_SEMAPHORE_ID_T sema;

} HAL_L3_INTF_CB_T;

/* ----------------------------------------------------------------------------------- VRF */
typedef struct HAL_L3_VRF_CB_S {
    UI32_T iev_l3uc_drop_idx;   /* VRF or global default route to drop */
    UI32_T iev_l3uc_to_cpu_idx; /* VRF or global default route to cpu  */
    UI32_T *ptr_group_label;    /* VRF default group label */
    UI32_T *ptr_to_cpu_bmp;     /* VRF default action. 0: drop, 1: to-cpu */
    UI32_T *ptr_ipv4_state_bmp; /* VRF admin state. 0: diable, 1: enable */
    UI32_T *ptr_ipv6_state_bmp; /* VRF admin state. 0: diable, 1: enable */
    UI32_T global_to_cpu;       /* system default action. 0: drop, 1: to-cpu */
    CLX_SEMAPHORE_ID_T sema;

} HAL_L3_VRF_CB_T;

/* ----------------------------------------------------------------------------------- ADJ */
typedef struct HAL_L3_ADJ_CB_S {
    CMLIB_AVL_HEAD_T *ptr_avl; /* cmlib_avl_insert(HAL_L3_ADJ_NODE_T) when addAdj()
                                * cmlib_avl_delete(HAL_L3_ADJ_NODE_T) when delAdj()
                                * cmlib_list_insertToTail(UI32_T) when addGrpList() of ECMP and FRR
                                * cmlib_list_deleteByData(UI32_T) when delGrpList() of ECMP and FRR
                                */
    UI32_T *ptr_urpf_use_num;
    CLX_SEMAPHORE_ID_T sema;

} HAL_L3_ADJ_CB_T;

typedef struct HAL_L3_ADJ_NODE_S {
    /* AVL key */
    UI32_T adj_id; /* hw adj index           */

    /* AVL data */
    UI32_T iev_idx;              /* hw iev index           */
    UI32_T frr_idx;              /* hw frr addr, only valid for nb */
    UI32_T mpls_en;              /* sw mpls en, only valid for nb */
    CMLIB_LIST_T *ptr_ecmp_list; /* hw ecmp group-id list  */
    CMLIB_LIST_T *ptr_frr_list;  /* hw frr group-id list of this backup adj */
    UI32_T use_num;              /* reference count of host, route, ecmp, and frr */
    CLX_PORT_T port;             /* interface object       */

} HAL_L3_ADJ_NODE_T;

typedef struct HAL_L3_ADJ_INFO_S {
    UI32_T adj_id;     /* hw adj index,fpu_idx for mt                  */
    UI32_T iev_idx;    /* hw iev index                                 */
    UI32_T intf_id;    /* hw intf index                                */
    UI32_T seg_vmid;   /* hw seg_vmid, nb not support                  */
    UI32_T ueid_mgid;  /* hw ueid_mgid                                 */
    UI32_T decr_ttl;   /* flag for decr ttl, nb not support            */
    UI32_T urpf_en;    /* flag for strict urpf, nb not support         */
    UI32_T drop;       /* black hole                                   */
    UI32_T seg_id;     /* sw seg_id, nb not support                    */
    UI32_T frr_grp_id; /* frr group id, means frr hw addr nb           */
    UI32_T use_num;    /* reference count of host, route, ecmp, and frr */
    CLX_PORT_T port;   /* interface object                              */

    UI32_T hw_mac[2];  /* hw dst mac, only valid for nb                 */
    UI32_T mpls_en;    /* sw mpls_en, only valid for nb                 */

} HAL_L3_ADJ_INFO_T;

typedef struct HAL_L3_ADJ_TRAV_COOKIE_S {
    UI32_T unit;

    /* [Out] for traverseAdj() API, store the TRAV_DATA in list */
    CMLIB_LIST_T *ptr_list;

    /* [In] for travGrpUpdateUrpf(), add or del ECMP/FRR uRPF when change intf urpf_mode */
    UI32_T intf_id;
    UI32_T is_add;

} HAL_L3_ADJ_TRAV_COOKIE_T;

typedef struct HAL_L3_ADJ_TRAV_DATA_S {
    UI32_T adj_id;
    CLX_L3_ADJ_INFO_T adj_info;

} HAL_L3_ADJ_TRAV_DATA_T;

/* ----------------------------------------------------------------------------------- ECMP */
typedef struct HAL_L3_ECMP_NODE_S {
    /* AVL key */
    UI32_T grp_id; /* hw ecmp group index    */

    /* AVL data */
    UI32_T grp_mode; /* hw ecmp group mode     */
    UI32_T grp_type; /* hw ecmp group type     */
    UI32_T iev_idx;  /* hw iev index           */
    UI32_T path_cnt;
    UI32_T weight_cnt;
    UI32_T weight_vld;  /* only update weight_cnt when this field is 1 */
    UI32_T use_num;     /* reference count of host, route, fdl */
    UI32_T real_size;   /* real hash buckets for fine grain ECMP */
    UI32_T use_default; /* insert default path */
} HAL_L3_ECMP_NODE_T;

typedef struct HAL_L3_ECMP_INFO_S {
    UI32_T grp_id;                    /* hw ecmp group index    */
    CLX_L3_ECMP_MODE_TYPE_T grp_mode; /* hw ecmp group mode     */
    CLX_L3_OUTPUT_TYPE_T grp_type;    /* hw ecmp group type     */
    UI32_T iev_idx;                   /* hw iev index           */
    UI32_T decr_ttl;                  /* flag for decr ttl      */
    UI32_T urpf_en;                   /* flag for strict urpf   */
    UI32_T path_cnt;
    UI32_T weight_cnt;
    UI32_T weight_vld;  /* only update weight_cnt when this field is 1 */
    UI32_T use_num;     /* reference count of host, route */
    UI32_T real_size;   /* real hash buckets for fine grain ECMP */
    UI32_T use_default; /* insert default path */
    UI32_T order_mode;  /* order ecmp */
} HAL_L3_ECMP_INFO_T;

typedef struct HAL_L3_ECMP_PATH_RSRC_S {
    /* group */
    HAL_L3_ECMP_INFO_T ecmp_info; /* SWDB info */
    UI32_T grp_tbl_id;            /* ECMP_U */
    union {
        UI32_T hw_buf[LT_CDB_IEV_RSLT_ECMP_U_HW_WORDS];
        UI32_T sw_buf[LT_CDB_IEV_RSLT_ECMP_U_SW_WORDS];
    } grp_buf;

    /* [add/del] path from user
     * [get] path from hw
     */
    UI32_T path_weight; /* weight or 1 */
    UI32_T path_tbl_id; /* ECMP_PATH_U */
    union {
        UI32_T ep_l3_buf[LT_CDB_IEV_RSLT_ECMP_PATH_U_EP_L3_WORDS];
        UI32_T ul_l2_buf[LT_CDB_IEV_RSLT_ECMP_PATH_U_UL_L2_WORDS];
        UI32_T ul_l3_buf[LT_CDB_IEV_RSLT_ECMP_PATH_U_UL_L3_WORDS];
        UI32_T encap_buf[LT_CDB_IEV_RSLT_ECMP_PATH_ENCAP_WORDS];
    } path_buf;

    /* [add/del] state from user
     * [get] state from hw
     */
    UI32_T state_frr_id;
    UI32_T state_tbl_id; /* ECMP_ACT or NVO3_ECMP_ACT */
    union {
        UI32_T act_buf[LT_CDB_IEV_RSLT_ECMP_STATE_ACT_WORDS];
        UI32_T nvo3_act_buf[LT_CDB_IEV_RSLT_NVO3_ECMP_STATE_ACT_WORDS];
    } state_buf;

    /* metas from HW act */
    UI32_T new_num;    /* number of is_new=1 in this group */
    UI32_T act_offset; /* path offset */
    UI32_T act_weight; /* path count for hw, or sw_spray count for sw */
    UI32_T act_vld;

    /* metas from HW orig */
    UI32_T inact_num;     /* number of is_act=0 in this group */
    UI32_T orig_offset;   /* path offset */
    UI32_T orig_weight;   /* path count for hw */
    UI32_T orig_vld;      /* this path may be out of orig, but in act */
    UI32_T reserved_path; /* path is reserved */

} HAL_L3_ECMP_PATH_RSRC_T;

typedef enum {
    HAL_L3_TRANS_ECMP_L2_TO_L3 = 0, /* trans l3 hal to clx info */
    HAL_L3_TRANS_ECMP_L3_TO_L2 = 1, /* trans l3 clx to hal info */
    HAL_L3_TRANS_ECMP_TYPE_LAST
} HAL_L3_TRANS_ECMP_TYPE_T;
/* ----------------------------------------------------------------------------------- HOST */
typedef struct HAL_L3_HOST_CB_S {
    /* usage */
    UI32_T ipv4_hash_1x_cnt;
    UI32_T ipv6_hash_2x_cnt;
    UI32_T ipv6_hash_4x_cnt;

    /* semaphore */
    CLX_SEMAPHORE_ID_T sema;

} HAL_L3_HOST_CB_T;

typedef struct HAL_L3_HOST_RSRC_S {
    UI32_T ipv4;
    UI32_T tbl_id;              /* ILE table ID           */
    UI32_T bank_bmp;            /* ILE bank bitmap        */
    UI32_T flw_lbl;             /* ILE in-band IEV result */
    HAL_L3_IEV_RSRC_T iev_rsrc; /* IEV result             */
    union {
        UI32_T ipv4_buf[LT_CDB_ILE_HSH_1X_U_L3_IPV4_XA_WORDS];
        UI32_T ipv6_buf[LT_CDB_ILE_HSH_4X_U_L3_IPV6_XA_WORDS];
    } buf;
    C8_T ip_str[CMLIB_UTIL_IP_ADDR_STR_SIZE];

    /* hitbit */
    UI32_T dip_hit;
    UI32_T sip_hit;

} HAL_L3_HOST_RSRC_T;

/* ----------------------------------------------------------------------------------- ROUTE */
typedef struct HAL_L3_ROUTE_RSRC_S {
    UI32_T tbl_id;              /* ILE table ID             */
    UI32_T bank_bmp;            /* ILE bank bitmap [HASH]   */
    UI32_T free_exm;            /* ILE free EXM id [HASH]   */
    UI32_T flw_lbl;             /* IEV_INDIR result         */
    UI32_T iev_idx;             /* IEV index (getFcoe)      */
    HAL_L3_IEV_RSRC_T iev_rsrc; /* IEV result               */
    union {
        UI32_T fcoe_tcam_1x_buf[LT_CDB_ILE_COM_TCAM_1X_U_FCOE_FIB_WORDS];
        UI32_T ipv4_tcam_1x_buf[LT_CDB_ILE_COM_TCAM_1X_U_L3_FIB_IP_XA_WORDS];
        UI32_T ipv6_tcam_2x_buf[LT_CDB_ILE_COM_TCAM_2X_U_L3_FIB_IPV6_XA_WORDS];
        UI32_T ipv6_tcam_4x_buf[LT_CDB_ILE_COM_TCAM_4X_U_L3_FIB_IPV6_XA_WORDS];
        UI32_T ipv4_hash_1x_buf[LT_CDB_ILE_HSH_1X_U_L3_IPV4_XA_WORDS];
        UI32_T ipv6_hash_2x_buf[LT_CDB_ILE_HSH_2X_U_L3_IPV6_XA_WORDS];
        UI32_T ipv6_hash_4x_buf[LT_CDB_ILE_HSH_4X_U_L3_IPV6_XA_WORDS];
    } buf;
    C8_T ip_str[CMLIB_UTIL_IP_NETWORK_STR_SIZE];

    /* e.g.
     * ip=192.168.0.4/31, root-ip=192.168.0.0/29 (buf)
     * found root ile_idx=8192, iev_indir_idx=327680, trie_bmp=0x111, iev_idx=81920 (read from ADJ)
     *
     * - vrf_vld            is 1      (calculated from flag)
     * - msk_btot           is 3      (calculated from prefix)
     * - real_prefix        is 31
     * - root_prefix        is 29
     * - root_key           is 15
     *
     * - trie_bit           is 5      (0 or calculated from trie-bmp)
     * - rslt_shift         is 1      (0 or calculated from trie-bmp)
     *
     * - root_vld           is 1
     * - root_d_ile_idx     is 8192   (read from AVL)
     * - root_s_ile_idx     is 12288  (read from AVL)
     * - root_rslt_idx      is 327680 (read from HW)
     * - root_rslt_cnt      is 3      (read from HW)
     * - real_vld           is 1
     */
    UI32_T is_1x;    /* ILE is_1x                                */
    UI32_T vrf_vld;  /* ILE vrf_vld                              */
    UI32_T vrf_id;   /* ILE vrf_id                               */
    UI32_T msk_btot; /* ILE msk_btot                             */
    UI32_T real_prefix;
    UI32_T root_prefix;
    UI32_T root_key;       /* calculated block key [TCAM]              */

    UI32_T trie_bit;       /* based on root IP                         */
    UI32_T rslt_shift;     /* based on IEV_INDIR index                 */

    UI32_T root_vld;       /* root IP exists in HW                     */
    UI32_T root_d_ile_idx; /* root ILE DIP 1x      (only for root_vld) */
    UI32_T root_s_ile_idx; /* root ILE SIP 1x      (only for root_vld) */
    UI32_T root_rslt_idx;  /* root IEV indir index (only for root_vld) */
    UI32_T root_rslt_cnt;  /* root IEV indir count (only for root_vld) */
    UI32_T real_vld;       /* real IP exists in HW                     */

} HAL_L3_ROUTE_RSRC_T;

/* Add For Bulk Route */
typedef struct HAL_L3_ROUTE_EXT_RSRC_S {
    HAL_L3_ROUTE_RSRC_T route_rsrc;
    UI32_T route_id; /* ip add order */
    UI32_T root_ip[HAL_L3_ROUTE_ROOT_WORD_NUM];
    UI32_T root_mask[HAL_L3_ROUTE_ROOT_WORD_NUM];
} HAL_L3_ROUTE_EXT_RSRC_T;

typedef struct HAL_L3_ROUTE_TRAV_COOKIE_S {
    UI32_T unit;

    /* [In] for traverseRoute() API, directly callback */
    UI32_T tbl_id;
    CMLIB_LIST_T *ptr_list;
    UI32_T cnt;

    /* [In] for setIpNode() API, move d_ile_idx/s_ile_idx in this range */
    UI32_T is_dip;
    UI32_T entry_num;
    UI32_T old_idx;
    UI32_T new_idx;

} HAL_L3_ROUTE_TRAV_COOKIE_T;

typedef struct HAL_L3_ROUTE_TRAV_SW_COOKIE_S {
    UI32_T unit;

    /* now only counter flag */
    UI32_T counter_only;
    UI32_T root_count;

} HAL_L3_ROUTE_TRAV_SW_COOKIE_T;

/* Add for get l3 actual route count */
typedef struct HAL_L3_ROUTE_NUM_S {
    UI32_T ipv4_num;
    UI32_T ipv6_num;
    /*  UI32_T                  ipv6_short_num; */
    /*  UI32_T                  ipv6_long_num;  */
    /*  UI32_T                  def_global_num; */
} HAL_L3_ROUTE_NUM_T;
/* ----------------------------------------------------------------------------------- MCAST */
/* Mcast Egress Interface */
typedef struct HAL_L3_MCAST_MEL_SUB_ENTRY_S {
    /* ETM_RSLT_MEL_INFO */
    UI32_T src_supp_ck_vid;
    UI32_T src_supp_tag;
    HAL_VLAN_VID_CTL_T vid_info;

    /* EMI_RSLT_MC_SC */
    UI32_T nvo3_adj_idx;
    UI32_T nvo3_encap_idx;
    UI32_T seg_vmid;

} HAL_L3_MCAST_MEL_SUB_ENTRY_T;

typedef struct HAL_L3_MCAST_MEL_INFO_S {
    /* ETM_RSLT_MEL_INFO */
    UI32_T l3_intf_id;
    UI32_T decr_ttl;
    UI32_T src_supp_ck_vid;
    UI32_T src_supp_tag;

    /* EMI_RSLT_MEL */
    UI32_T nvo3_adj_idx;
    UI32_T nvo3_encap_idx;
    UI32_T seg_vmid;

    /* EMI_RSLT_ADJ */
    UI32_T da_mod;
    UI32_T sa_mod;
    CLX_MAC_T dmac;
    HAL_VLAN_VID_CTL_T vid_info;

} HAL_L3_MCAST_MEL_INFO_T;

typedef struct HAL_L3_MCAST_EGR_ENTRY_S {
    BOOL_T is_fab;
    BOOL_T is_routed;
    UI32_T entry_num;
    HAL_L3_MCAST_MEL_INFO_T *ptr_mel_info;

} HAL_L3_MCAST_EGR_ENTRY_T;

typedef struct HAL_L3_MCAST_EGR_RSRC_S {
    /* from user */
    UI32_T plane;
    UI32_T plane_port;

    /* from hw */
    UI32_T pbm[HAL_ITM_PBM_WORDS];
    UI32_T plane_port_num;

} HAL_L3_MCAST_EGR_RSRC_T;

/* Mcast Group */
typedef struct HAL_L3_MCAST_GRP_NODE_S {
    /* AVL key */
    UI32_T mcast_id;

    /* AVL data */
    UI32_T l3rc[HAL_PLANE_NUM_MAX][HAL_PLANE_PORT + 1]; /* 1 for CPI */
    UI32_T use_num;

} HAL_L3_MCAST_GRP_NODE_T;

typedef struct HAL_L3_MCAST_GRP_RSRC_S {
    UI32_T ipv4;
    UI32_T tbl_id;              /* ILE table ID           */
    UI32_T bank_bmp;            /* ILE bank bitmap        */
    UI32_T flw_lbl;             /* ILE in-band IEV result */
    HAL_L3_IEV_RSRC_T iev_rsrc; /* IEV result             */
    union {
        UI32_T ipv4_xg_buf[LT_CDB_ILE_HSH_1X_U_L3_IPV4_XA_WORDS];
        UI32_T ipv4_sg_buf[LT_CDB_ILE_HSH_2X_U_L3_IPV4_SG_WORDS];
        UI32_T ipv6_xg_buf[LT_CDB_ILE_HSH_4X_U_L3_IPV6_XA_WORDS];
        UI32_T ipv6_sg_buf[LT_CDB_ILE_HSH_4X_U_L3_IPV6_SG_WORDS];
    } buf;
    C8_T ip_str[CMLIB_UTIL_IP_ADDR_STR_SIZE];

    /* hitbit */
    UI32_T grp_hit;

} HAL_L3_MCAST_GRP_RSRC_T;

/* DF Interface */
typedef struct HAL_L3_MCAST_RPA_NODE_S {
    /* AVL key */
    CLX_IP_ADDR_T rp_addr;

    /* AVL data */
    UI32_T rp_id;
    UI32_T use_num;

} HAL_L3_MCAST_RPA_NODE_T;

typedef struct HAL_L3_MCAST_RPA_TRAV_COOKIE_S {
    UI32_T unit;

    /* [In] for getDfIntf() API, get all RPAs from intf ID */
    UI32_T intf_id;
    UI32_T cnt;
    UI32_T real_cnt;

    /* [In] for getGroup() API, get RPA from RP-ID */
    UI32_T rp_id;

    /* [Out] RPA */
    CLX_IP_ADDR_T *ptr_rp_addr;

} HAL_L3_MCAST_RPA_TRAV_COOKIE_T;

/* ----------------------------------------------------------------------------------- Function */
typedef CLX_ERROR_NO_T (*HAL_L3_ECMP_CALLBACK_FUNC_T)(const UI32_T unit,
                                                      const UI32_T adj_id,
                                                      const UI32_T ecmp_grp_id,
                                                      const void *ptr_cookie);

typedef CLX_ERROR_NO_T (*HAL_L3_FRR_CALLBACK_FUNC_T)(const UI32_T unit,
                                                     const UI32_T adj_id,
                                                     const UI32_T frr_grp_id,
                                                     const void *ptr_cookie);

/*****************************************************************************
 * LOCAL SUBPROGRAM BODIES
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- MAIN */
/* Utility */
CLX_ERROR_NO_T
hal_l3_dumpBitmap(const UI32_T *ptr_bmp, const UI32_T bmp_cnt);

UI32_T
hal_l3_getHitVal(const UI32_T val, const UI32_T offset, const UI32_T length);

void
hal_l3_setHitVal(const UI32_T offset, const UI32_T length, const UI32_T value, UI32_T *ptr_val);

void
hal_l3_clrHitVal(const UI32_T offset, const UI32_T length, UI32_T *ptr_val);

/* DMA */
CLX_ERROR_NO_T
hal_l3_moveTblDma(const UI32_T unit,
                  const UI32_T tbl_id,
                  const BOOL_T delete_offset,
                  const UI32_T offset,
                  const UI32_T base_old,
                  const UI32_T num_old,
                  const UI32_T base_new);

CLX_ERROR_NO_T
hal_l3_clearTblDma(const UI32_T unit,
                   const UI32_T tbl_id,
                   const UI32_T clear_base,
                   const UI32_T clear_num);

/* Properties */

/* Exceptions */

/* Chip Dispatcher */

/* Init and Deinit */

/* Dump SWDB */

/* ----------------------------------------------------------------------------------- INTF */

/* ----------------------------------------------------------------------------------- VRF */

/* ----------------------------------------------------------------------------------- ADJ */
I32_T
hal_l3_adj_cmpAdjListNode(void *ptr_node_data, void *ptr_user_data);

I32_T
hal_l3_adj_cmpAdjNode(void *ptr_user_param, void *ptr_user_data, void *ptr_node_data);

void
hal_l3_adj_destroyFrrListNode(/* for deinit */
                              void *ptr_node_data);

void
hal_l3_adj_destroyEcmpListNode(/* for deinit */
                               void *ptr_node_data);

void
hal_l3_adj_destroyAdjListNode(/* for traverse */
                              void *ptr_node_data);

void
hal_l3_adj_destroyAdjNode(/* for deinit */
                          void *ptr_user_param,
                          void *ptr_node_data);

CLX_ERROR_NO_T
hal_l3_adj_addGrpList(/* for addEcmpPath, addNvo3EcmpPath, addFrrPath, setFrrPath */
                      const UI32_T grp_id,
                      CMLIB_LIST_T *ptr_list);

CLX_ERROR_NO_T
hal_l3_adj_delGrpList(/* for delEcmp, delNvo3Ecmp, delEcmpPath, delNvo3EcmpPath, delFrrPath,
                         setFrrPath */
                      const UI32_T grp_id,
                      CMLIB_LIST_T *ptr_list);

/* traverse ECMP, nvo3-ECMP or FRR group-list by adj-id */
CLX_ERROR_NO_T
hal_l3_adj_travGrpList(/* for setAdj, setNvo3Adj */
                       const UI32_T unit,
                       CMLIB_LIST_T *ptr_list,
                       const UI32_T adj_id,
                       void *ptr_cookie,
                       HAL_L3_FRR_CALLBACK_FUNC_T callback);

/* ----------------------------------------------------------------------------------- ECMP */
CLX_ERROR_NO_T
hal_l3_getEcmpHashPath(const UI32_T unit,
                       const CLX_SWC_HASH_TYPE_T hash_type,
                       const CLX_SWC_FLOW_HASH_KEY_T *ptr_hash_key,
                       const UI32_T ecmp_grp_id,
                       CLX_L3_ECMP_HASHPATH_RSLT_INFO_T *ptr_rslt);

/* ----------------------------------------------------------------------------------- HOST */

/* ----------------------------------------------------------------------------------- ROUTE */

/* ----------------------------------------------------------------------------------- MCAST */

#endif /* End of HAL_L3_H */
