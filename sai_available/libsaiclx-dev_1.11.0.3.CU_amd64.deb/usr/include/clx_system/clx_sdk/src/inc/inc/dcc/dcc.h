/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  dcc.h
 * PURPOSE:
 *  1. Provide the chip Device Control Command(DCC) interfaces, it will include:
 *     a. Per channel init status.
 *     b. DCC Errror handler.
 *  2. Define DCC related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_H
#define DCC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_cfg.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <hal/hal_tbl.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define DCC_CMD_LENGTH_UNIT (4)  /* words, means 4 bytes */
#define DCC_HIGH_ADDR_WIDTH (32) /* High address width is 32 bits */
#define DCC_MAX_TIMEOUT_CNT (1000000)

#define DCC_LOG_MAX_LINES 10
#define DCC_LOG_LINE_SIZE 1024

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum { DCC_IO, DCC_DMA, DCC_LAST } DCC_LOG_TYPE_E;

/* DCC channel access mode (polling or interrupt) */
typedef enum { DCC_CH_OP_MODE_POLL = 0, DCC_CH_OP_MODE_INTR, DCC_CH_OP_MODE_LAST } DCC_CH_OP_MODE_T;

/* A-cmd action */
typedef enum {
    DCC_CMD_ACT_READ = 0x0,
    DCC_CMD_ACT_WRITE = 0x1,
    DCC_CMD_ACT_HASH = 0x2,
    DCC_CMD_ACT_ABORT = 0xE,
    DCC_CMD_ACT_CLR = 0xF,
    DCC_CMD_ACT_LAST
} DCC_CMD_ACT_T;

/* Hash cmd action */
typedef enum {
    DCC_CMD_HASH_ACT_INSERT_OVERWRITE = 0x0,
    DCC_CMD_HASH_ACT_READ = 0x1,
    DCC_CMD_HASH_ACT_INSERT_NONOVERWRITE = 0x2,
    DCC_CMD_HASH_ACT_DELETE = 0x3,
    DCC_CMD_HASH_ACT_LAST
} DCC_CMD_HASH_ACT_T;

/**
 * @brief dcc_init() is responsible for DCC initialization, it will do
 *        the following:
 *        1. Allocate an available DCC control block.
 *        2. Initialize DCC miscellaneous resources(DCC DMA buffers).
 *        3. Initialize DCC IO channel.
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */

CLX_ERROR_NO_T
dcc_init(const UI32_T unit);

/**
 * @brief dcc_chInit() is responsible for DCC initialization, it will do
 *        the following:
 *        1. Initialize DCC channels. It will include:
 *        a. DMA channel initialization.
 *        b. Calendar DMA channel initialization.
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */

CLX_ERROR_NO_T
dcc_chInit(const UI32_T unit);

/**
 * @brief dcc_deInit() is responsible for DCC de-initialization, it will
 *        do the following:
 *        1. De-initialize DCC channels.
 *        2. De-initialize DCC miscellaneous resource(DCC DMA buffers).
 *        3. De-initialize DCC control block.
 *
 * @param [in]     unit    - The unit number that would like to de-initialized.
 * @return         CLX_E_OK        - Successfully de-initialize DCC.
 * @return         CLX_E_OTHERS    - Fail to complete de-initialization procedure.
 */
CLX_ERROR_NO_T
dcc_deinit(const UI32_T unit);

void
dcc_log_message(DCC_LOG_TYPE_E dcc, const char *format, ...);
void
dcc_show_error_logs(DCC_LOG_TYPE_E dcc);
void
dcc_clear_error_logs(DCC_LOG_TYPE_E dcc);

#endif /* END of DCC_H*/
