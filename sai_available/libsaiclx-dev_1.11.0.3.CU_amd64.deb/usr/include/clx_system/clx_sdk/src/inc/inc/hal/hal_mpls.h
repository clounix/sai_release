/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mpls.h
 * PURPOSE:
 *  It provides MPLS HAL API.
 *
 * NOTES:
 *
 */

#ifndef HAL_MPLS_H
#define HAL_MPLS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_mpls.h>
#include <clx_vlan.h>
#include <hal/hal_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MPLS_MAX_NAME_SPACE   (3) /* Maximum name space */
#define HAL_MPLS_LBL_VLD_OFFSET   (21)
#define HAL_MPLS_CW_VLD_OFFSET    (23)
#define HAL_MPLS_PWEL_VLD_OFFSET  (22)
#define HAL_MPLS_EL_VLD_OFFSET    (20)
#define HAL_MPLS_L_LSP_VLD_OFFSET (23)

#define HAL_MPLS_PW_IDX_MIN (0)
#define HAL_MPLS_PW_IDX_MAX (16 * 1024)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MPLS_SEG_IS_LABEL_VALID(seg) \
    (((seg) < HAL_INVALID_SEG_VMID) && ((seg) & (1U << HAL_MPLS_LBL_VLD_OFFSET)))

#define HAL_MPLS_SEG_IS_LABEL_SWAP(seg) (HAL_MPLS_SEG_IS_LABEL_VALID(seg))

#define HAL_MPLS_ENCAP_LABEL_TO_SEG(lbl_val, el_vld, pwel_vld, cw_vld)                 \
    (((cw_vld) << HAL_MPLS_CW_VLD_OFFSET) | ((pwel_vld) << HAL_MPLS_PWEL_VLD_OFFSET) | \
     (1U << HAL_MPLS_LBL_VLD_OFFSET) | ((el_vld) << HAL_MPLS_EL_VLD_OFFSET) |          \
     ((lbl_val) & 0xFFFFF))

#define HAL_MPLS_PW_LABEL_TO_SEG(lbl_val, pwel_vld, cw_vld) \
    HAL_MPLS_ENCAP_LABEL_TO_SEG(lbl_val, 0, pwel_vld, cw_vld)

#define HAL_MPLS_SWAP_LABEL_TO_SEG(l_lsp_vld, el_vld, lbl_val)                      \
    (((l_lsp_vld) << HAL_MPLS_L_LSP_VLD_OFFSET) | (1U << HAL_MPLS_LBL_VLD_OFFSET) | \
     ((el_vld) << HAL_MPLS_EL_VLD_OFFSET) | ((lbl_val) & 0xFFFFF))

#define HAL_MPLS_SEG_TO_LABEL(seg) ((seg) & 0xFFFFF)

#define HAL_MPLS_SEG_TO_CW(seg) (((seg) & (1U << HAL_MPLS_CW_VLD_OFFSET)) ? 1 : 0)

#define HAL_MPLS_SEG_TO_PWEL(seg) (((seg) & (1U << HAL_MPLS_PWEL_VLD_OFFSET)) ? 1 : 0)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_MPLS_ENCAP_TYPE_P2P = 1,
    HAL_MPLS_ENCAP_TYPE_P2MP,
    HAL_MPLS_ENCAP_TYPE_FRR,
    HAL_MPLS_ENCAP_TYPE_ECMP,
    HAL_MPLS_ENCAP_TYPE_LAST
} HAL_MPLS_ENCAP_TYPE_T;

typedef struct HAL_MPLS_PATH_S {
    CLX_PORT_T intf;
    UI32_T di;
    UI32_T seg;
    UI32_T vid_ctl;
    UI32_T vid1;
    UI32_T vid2;
    UI32_T adj_id; /*not used in cl8600 */
    UI32_T nvo3_adj_id;
    UI32_T encap_idx;
    UI32_T encap_ecmp_idx;
    UI32_T l3_intf_id;
    UI32_T src_supp_tag; /*not used in cl8600 */
    UI32_T mpls_ctl;     /*for cl8600 */
    UI32_T pw_bdi;       /*for cl8600*/

#define HAL_MPLS_PATH_FLAGS_L2VPN         (1U << 0)
#define HAL_MPLS_PATH_FLAGS_SEG_VALID     (1U << 1)
#define HAL_MPLS_PATH_FLAGS_VID_CTL_VALID (1U << 2)
#define HAL_MPLS_PATH_FLAGS_PORT_VALID    (1U << 3)

    UI32_T flags;
} HAL_MPLS_PATH_T;

typedef struct HAL_MPLS_CB_S {
    CMLIB_AVL_HEAD_T *ptr_pw_avl;
    CMLIB_AVL_HEAD_T *ptr_pw_key_avl;
    CMLIB_AVL_HEAD_T *ptr_adj_iev_avl;
    CLX_SEMAPHORE_ID_T sema;
    UI32_T supp_tag_ul;
    UI32_T adj_id;            /* to remove L2 header */
    UI32_T srv_intf;          /* shared service */
    UI32_T srv_intf_refcnt;
    UI32_T ids_lcl_intf;      /* shared lcl_intf */
    UI32_T ids_lcl_intf_refcnt;
    UI32_T *ptr_encap_info;   /* index: encap_idx */
    UI32_T *ptr_pw_trunk_idx_bmp;
    UI32_T *ptr_sr_encap_bmp; /* bitmap of SR encap index */
    UI32_T sr_encap_idx_min;
    UI32_T sr_encap_idx_max;
    CMLIB_AVL_HEAD_T *ptr_iev_avl;
    CMLIB_AVL_HEAD_T *ptr_transit_avl;
    CMLIB_AVL_HEAD_T *ptr_term_avl;
    CMLIB_AVL_HEAD_T *ptr_mpls_lsp_hsh_avl;  /* tds mpls lsp hash key ref_cnt  only NB*/
    CMLIB_AVL_HEAD_T *ptr_mpls_vpws_lag_avl; /* vpws lag update  only NB*/
    UI32_T pw_port_idx_min;                  /*only NB*/
    UI32_T pw_port_idx_max;                  /*only NB*/
    UI32_T *ptr_pw_port_bmp;                 /* bitmap of pw port index only NB*/
} HAL_MPLS_CB_T;

typedef struct HAL_MPLS_TERM_TDSHSH_AVL_NODE_S {
    UI16_T entry_idx; /* tnl_decap's entry_idx */
    UI16_T ref_cnt;   /* reference count */
} HAL_MPLS_TERM_TDSHSH_AVL_NODE_T;

typedef struct HAL_MPLS_VPWS_LAG_UPDATE_AVL_NODE_S {
    UI16_T lag;
    CLX_VLAN_T vid1;
    CLX_VLAN_T vid2;
    UI32_T ac_pw_bdi;
    UI32_T pw_ac_bdi;
} HAL_MPLS_VPWS_LAG_UPDATE_AVL_NODE_T;

typedef HAL_MPLS_CB_T HAL_MPLS_CB_P[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

CLX_ERROR_NO_T
hal_mpls_addAdjIev(const UI32_T unit,
                   const CLX_L3_ADJ_TYPE_T adj_type,
                   const UI32_T adj_id,
                   const BOOL_T is_ecmp_path,
                   const UI32_T iev_idx);

CLX_ERROR_NO_T
hal_mpls_delAdjIev(const UI32_T unit,
                   const CLX_L3_ADJ_TYPE_T adj_type,
                   const UI32_T adj_id,
                   const BOOL_T is_ecmp_path,
                   const UI32_T iev_idx);

CLX_ERROR_NO_T
hal_mpls_updateIevCallback(void *ptr_user_param, void *ptr_node_data, void *ptr_cookie);

CLX_ERROR_NO_T
hal_mpls_updateIevByPort(const UI32_T unit, const CLX_PORT_T port, const UI32_T di);

CLX_ERROR_NO_T
hal_mpls_checkIevCallback(void *ptr_user_param, void *ptr_node_data, void *ptr_cookie);

CLX_ERROR_NO_T
hal_mpls_checkIevByPort(const UI32_T unit, const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_mpls_addIev(const UI32_T unit, const UI32_T iev_idx, const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_mpls_delIev(const UI32_T unit, const UI32_T iev_idx);

CLX_ERROR_NO_T
hal_mpls_updateIev(const UI32_T unit, const UI32_T iev_idx, const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_mpls_getIevPort(const UI32_T unit, const UI32_T iev_idx, CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_mpls_getDiByIntf(const UI32_T unit, const CLX_PORT_T intf, UI32_T *ptr_di);

CLX_ERROR_NO_T
hal_mpls_getAdjPathInfo(const UI32_T unit,
                        const UI32_T adj_id,
                        const CLX_L3_ADJ_TYPE_T adj_type,
                        HAL_MPLS_PATH_T *ptr_path);

CLX_ERROR_NO_T
hal_mpls_copyPwEntry(void *ptr_user_param, void *ptr_node_data, void *ptr_cookie);

CLX_ERROR_NO_T
hal_mpls_copyMatchKey(void *ptr_user_param, void *ptr_node_data, void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize MPLS module.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK                - Initialize success.
 * @return         CLX_E_OTHERS            - Initialize failed.
 * @return         CLX_E_ALREADY_INITED    - Already iniialized.
 */
CLX_ERROR_NO_T
hal_mpls_init(const UI32_T unit);

/**
 * @brief Deinitialize the MPLS module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Deinitialization success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Deinitialization failed.
 */
CLX_ERROR_NO_T
hal_mpls_deinit(const UI32_T unit);

/**
 * @brief Set the value of skip MPLS label stacking for MPLS payload parsing.
 *
 * @param [in]     unit     - Device unit number.
 * @param [in]     port     - Port number.
 * @param [in]     value    - value range:0~3
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_mpls_setSkipMpls(const UI32_T unit, const UI32_T port, const UI32_T value);

/**
 * @brief Get the value of skip MPLS label stacking.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Port number.
 * @param [out]    ptr_value    - Pointer of the value.
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_mpls_getSkipMpls(const UI32_T unit, const UI32_T port, UI32_T *ptr_value);

/**
 * @brief Set the value of deleting MPLS label stacking when decap miss.
 *
 * @param [in]     unit     - Device unit number.
 * @param [in]     port     - Port number.
 * @param [in]     value    - value range:0~1
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_mpls_setDelMpls(const UI32_T unit, const UI32_T port, const UI32_T value);

/**
 * @brief Get the value of deleting MPLS label stacking.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Port number.
 * @param [out]    ptr_value    - Pointer of the value.
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_mpls_getDelMpls(const UI32_T unit, const UI32_T port, UI32_T *ptr_value);

/**
 * @brief Get PW VLAN tag action
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - PW port.
 * @param [in]     vid1               - First VLAN ID.
 * @param [in]     vid2               - Second VLAN ID.
 * @param [in]     vid_ctl            - VID control.
 * @param [out]    ptr_tag_action     - Pointer of VLAN tag action.
 * @param [out]    ptr_vlan_action    - Pointer of VLAN action.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
hal_mpls_getPwVlanTagAction(const UI32_T unit,
                            const CLX_PORT_T port,
                            const CLX_VLAN_T vid1,
                            const CLX_VLAN_T vid2,
                            const UI32_T vid_ctl,
                            CLX_VLAN_TAG_ACTION_T *ptr_tag_action,
                            CLX_VLAN_ACTION_T *ptr_vlan_action);

/**
 * @brief Dump MPLS software DB
 *
 * @param [in]     unit     - Device unit number.
 * @param [in]     flags    - Dump flags.
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_mpls_dumpDb(const UI32_T unit, const UI32_T flags);

/**
 * @brief Get MPLS path DI.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - MPLS tunnel or PW port.
 * @param [out]    ptr_di    - Pointer of the DI of the port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 */
CLX_ERROR_NO_T
hal_mpls_getDi(const UI32_T unit, const CLX_PORT_T port, UI32_T *ptr_di);

/**
 * @brief Add IEV rslt info of output to LSP
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     iev_idx    - IEV rslt idx.
 * @param [in]     adj_id     - Adjacency ID.
 * @param [in]     port       - MPLS port.
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_mpls_addIevInfo(const UI32_T unit,
                    const UI32_T iev_idx,
                    const UI32_T adj_id,
                    const CLX_PORT_T port);

/**
 * @brief Delete IEV rslt info of output to LSP
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     iev_idx    - IEV rslt idx.
 * @param [in]     adj_id     - Adjacency ID.
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_mpls_delIevInfo(const UI32_T unit, const UI32_T iev_idx, const UI32_T adj_id);

HAL_MPLS_CB_P *
hal_mpls_getCtrlBlock(const UI32_T unit);
#endif
