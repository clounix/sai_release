/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  dcc_mt_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DCC_MT).
 *  2. Define DCC_MT IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_MT_IO_H
#define DCC_MT_IO_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <dcc/dcc_io.h>
#include <dcc/mountain/dcc_mt.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DCC_MT constant definition */
#define DCC_MT_IO_IND_CMD_CFG_OFFSET                       (0x0)
#define DCC_MT_IO_IND_ADDR_CFG_OFFSET                      (0x4)
#define DCC_MT_IO_IND_STATUS_STA_OFFSET                    (0x8)
#define DCC_MT_IO_IND_DATA_DHS_OFFSET                      (0xC)
#define DCC_MT_IO_IND_HASH_DATA_DHS_OFFSET                 (0x14)
#define DCC_MT_IO_IND_FPU_HASH_DATA_DHS_OFFSET             (0x54)
#define DCC_MT_IO_IND_PL_DATA_DHS_OFFSET                   (0x4)
#define DCC_MT_IO_IND_CIAT_TCAM_MOVE_CMD_CFG_OFFSET        (0x78)
#define DCC_MT_IO_IND_FPU_TCAM_SLC0_MOVE_CMD_CFG_OFFSET    (0x28)
#define DCC_MT_IO_IND_FPU_TCAM_SLC1_MOVE_CMD_CFG_OFFSET    (0x40)
#define DCC_MT_IO_IND_CIAT_TCAM_MOVE_STATUS_STA_OFFSET     (0x80)
#define DCC_MT_IO_IND_FPU_TCAM_SLC0_MOVE_STATUS_STA_OFFSET (0x30)
#define DCC_MT_IO_IND_FPU_TCAM_SLC1_MOVE_STATUS_STA_OFFSET (0x48)

#define DCC_MT_IO_IND_CMD_REG_WORD_SIZE             (1)
#define DCC_MT_IO_IND_ADDR_REG_WORD_SIZE            (1)
#define DCC_MT_IO_IND_STATUS_REG_WORD_SIZE          (1)
#define DCC_MT_IO_IND_HASH_STATUS_REG_WORD_SIZE     (3)
#define DCC_MT_IO_IND_FPU_HASH_STATUS_REG_WORD_SIZE (19)
#define DCC_MT_IO_IND_CMD_TCAM_MOVE_REG_WORD_SIZE   (2)

#define DCC_MT_IO_IND_STATUS_DOING      (0)
#define DCC_MT_IO_IND_STATUS_DONE       (1)
#define DCC_MT_IO_IND_STATUS_OP_FAIL    (0)
#define DCC_MT_IO_IND_STATUS_OP_SUCCESS (1)
/* unit of time: us, all times need for further check */
#ifdef NB_EMU_DEV
#define DCC_MT_IO_CMD_BUSY_POLL_CNT (3000000)
#else
#define DCC_MT_IO_CMD_BUSY_POLL_CNT (1000)
#endif

/* ERROR LOG */
#define DCC_MT_IO_CMST_ERR_RESP_IRQ     0x051C001C
#define DCC_MT_IO_CMST_ERR_RESP_IRQ_MSK 0x051C0020
#define DCC_MT_IO_CMST_ERR_RESP_ERR_LOG 0x051C0028

typedef enum {
    DCC_MT_TABLE_HASH = 0x0,
    DCC_MT_TABLE_HASH_FPU = 0x1,
    DCC_MT_TABLE_TCAM = 0x2,
    DCC_MT_TABLE_TCAM_FPU = 0x3,
    DCC_MT_TABLE_SRAM_PL = 0x4,
    DCC_MT_TABLE_SRAM_TM = 0x5,
    DCC_MT_TABLE_LAST
} DCC_MT_TABLE_TYPE_E;

typedef enum {
    DCC_MT_TABLE_KEY_1X = 0x0,
    DCC_MT_TABLE_KEY_2X = 0x1,
    DCC_MT_TABLE_KEY_4X = 0x2,
    DCC_MT_TABLE_KEY_LAST
} DCC_MT_TABLE_KEY_TYPE_E;

/* Hash cmd action */
typedef enum {
    DCC_MT_CMD_HASH_DIRECT_READ = 0x0,
    DCC_MT_CMD_HASH_DIRECT_WRITE = 0x1,
    DCC_MT_CMD_HASH_SEARCH = 0x2,
    DCC_MT_CMD_HASH_FIND = 0x3,
    DCC_MT_CMD_HASH_INSERT = 0x4,
    DCC_MT_CMD_HASH_DELETE = 0x5,
    DCC_MT_CMD_HASH_UPDATE = 0x6,
    DCC_MT_CMD_HASH_SCAN = 0xfff,
    DCC_MT_CMD_HASH_LAST
} DCC_MT_CMD_HASH_ACT_T;

typedef enum {
    DCC_MT_HASH_KEY_1X_IP = 0x0,
    DCC_MT_HASH_KEY_2X_IP = 0x1,
    DCC_MT_HASH_KEY_1X_MPLS_SID = 0x2,
    DCC_MT_HASH_KEY_2X_MPLS_SIP = 0x3,
    DCC_MT_HASH_KEY_LAST
} DCC_MT_HASH_KEY_TYPE_E;

/* Tcam cmd action */
typedef enum {
    DCC_MT_CMD_TCAM_READ = 0x0,
    DCC_MT_CMD_TCAM_WRITE = 0x1,
    DCC_MT_CMD_TCAM_CMP = 0x2,
    DCC_MT_CMD_TCAM_UNLOAD = 0x3,
    DCC_MT_CMD_TCAM_FLUSH = 0x4,
    DCC_MT_CMD_TCAM_VALID = 0x5,
    DCC_MT_CMD_TCAM_MOVE = 0xff,
    DCC_MT_CMD_TCAM_SCAN = 0xfff,
    DCC_MT_CMD_TCAM_LAST
} DCC_MT_CMD_TCAM_ACT_T;

#pragma pack(push, 1)
#if defined(CLX_EN_BIG_ENDIAN)
typedef union {
    UI32_T reg[DCC_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        UI32_T : 12;
        UI32_T ind_addr : 20;
    } field;
} DCC_MT_IO_REG_HASH_IND_ADDR_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_FPU_HASH_STATUS_REG_WORD_SIZE];
    struct {
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 32;
        UI32_T : 8;
        UI32_T cpu_fd_dup : 1;
        UI32_T cpu_fd_hit : 1;
        UI32_T cpu_fd_tile_no : 5;
        UI32_T cpu_fd_idx : 15;
        UI32_T op_suc : 1;
        UI32_T ind_access_done : 1;
    } field;
} DCC_MT_IO_REG_FPU_HASH_STAT_REG_T;

/* Response status */
typedef union {
    UI32_T reg[DCC_MT_IO_IND_HASH_STATUS_REG_WORD_SIZE];
    struct {
        UI32_T ind_result2 : 32;
        UI32_T ind_result1 : 32;
        UI32_T ind_result0 : 30;
        UI32_T op_suc : 1;
        UI32_T ind_access_done : 1;
    } field;
} DCC_MT_IO_REG_HASH_STAT_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T del_hit_op : 1;
        UI32_T insert_hit_op : 1;
        UI32_T acc_bmp : 24;
        UI32_T ecc_access : 1;
        UI32_T key_type : 2;
        UI32_T cmd : 3;
    } field;
} DCC_MT_IO_REG_FPU_HASH_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 28;
        UI32_T ecc_access : 1;
        UI32_T cmd : 3;
    } field;
    struct {
        UI32_T : 27;
        UI32_T ecc_access : 1;
        UI32_T key_type : 1;
        UI32_T cmd : 3;
    } field1;
} DCC_MT_IO_REG_HASH_CMD_REG_T;
typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 26;
        UI32_T ind_slc_select : 1;
        UI32_T mode : 2;
        UI32_T cmd : 3;
    } field;
} DCC_MT_IO_REG_FPU_TCAM_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 26;
        UI32_T mode : 3;
        UI32_T cmd : 3;
    } field;
} DCC_MT_IO_REG_TCAM_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        UI32_T : 17;
        UI32_T ind_mem_addr : 15;
    } field;
} DCC_MT_IO_REG_FPU_TCAM_ADDR_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        UI32_T : 18;
        UI32_T ind_mem_addr : 14;
    } field;
} DCC_MT_IO_REG_TCAM_ADDR_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        UI32_T : 31;
        UI32_T ind_access_done : 1;
    } field;
} DCC_MT_IO_REG_TCAM_STA_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_TCAM_MOVE_REG_WORD_SIZE];
    struct {
        UI32_T move_mode : 2;
        UI32_T op_num : 14;
        UI32_T dst_addr : 14;
        UI32_T src_addr : 14;
    } ciat_cmd;
    struct {
        UI32_T move_mode : 2;
        UI32_T op_num : 15;
        UI32_T dst_addr : 15;
        UI32_T src_addr : 15;
    } fpu_cmd;
} DCC_MT_IO_REG_TCAM_MOVE_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        UI32_T cur_src_ptr : 14;
        UI32_T move_done : 1;
        UI32_T ack_lock : 4;
        UI32_T cur_status : 3;
    } field;
} DCC_MT_IO_REG_TCAM_MOVE_STA_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 20;
        UI32_T mem_inst_sel : 4;
        UI32_T address : 8;
    } field;
} DCC_MT_IO_REG_IPL_CPX_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 22;
        UI32_T address : 10;
    } field;
} DCC_MT_IO_REG_IPL_CPX_FD_BUF_MEM_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 14;
        UI32_T mem_umac_id : 2;
        UI32_T mem_bank_id : 4;
        UI32_T address : 12;
    } field;
} DCC_MT_IO_REG_IPL_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 15;
        UI32_T mem_umac_id : 2;
        UI32_T address : 15;
    } field;
} DCC_MT_IO_REG_IPL_APP_FD_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 24;
        UI32_T mem_umac_id : 2;
        UI32_T address : 6;
    } field;
} DCC_MT_IO_REG_IPL_APP_FBM_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 20;
        UI32_T dp_sel : 1;
        UI32_T address : 11;
    } field;
} DCC_MT_IO_REG_IPL_LBM_WD_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 17;
        UI32_T mem_sel : 5;
        UI32_T dp_sel : 1;
        UI32_T address : 9;
    } field;
} DCC_MT_IO_REG_IPL_LBM_DATA_BUF_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 15;
        UI32_T umac_id_sel : 2;
        UI32_T bank_idx : 5;
        UI32_T address : 10;
    } field;
} DCC_MT_IO_REG_EPL_APP_UMAC_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 15;
        UI32_T umac_id_sel : 2;
        UI32_T bank_idx : 5;
        UI32_T address : 10;
    } field;
} DCC_MT_IO_REG_EPL_UMAC_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 17;
        UI32_T umac_id_sel : 2;
        UI32_T address : 13;
    } field;
} DCC_MT_IO_REG_EPL_UMAC_FD_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 20;
        UI32_T address : 7;
        UI32_T bank_id : 5;
    } field;
} DCC_MT_IO_REG_EPL_CPX_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 22;
        UI32_T address : 10;
    } field;
} DCC_MT_IO_REG_EPL_CPX_FD_BUF_MEM_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T : 20;
        UI32_T bank_id : 5;
        UI32_T address : 7;
    } field;
} DCC_MT_IO_REG_TM_EMU_VERF_MEM_IND_CMD_REG_T;

#elif defined(CLX_EN_LITTLE_ENDIAN)
typedef union {
    UI32_T reg[DCC_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        UI32_T ind_addr : 20;
        UI32_T : 12;
    } field;
} DCC_MT_IO_REG_HASH_IND_ADDR_REG_T;

/* Response status */
typedef union {
    UI32_T reg[DCC_MT_IO_IND_FPU_HASH_STATUS_REG_WORD_SIZE];
    struct {
        UI32_T ind_access_done : 1;
        UI32_T op_suc : 1;
        UI32_T cpu_fd_idx : 15;
        UI32_T cpu_fd_tile_no : 5;
        UI32_T cpu_fd_hit : 1;
        UI32_T cpu_fd_dup : 1;
        // UI32_T cpu_fd_hit_idx       :     360;
        // UI32_T cpu_fd_key_exist_bmp :     24;
        // UI32_T cpu_fd_row_freebmp   :     192;
    } field;
} DCC_MT_IO_REG_FPU_HASH_STAT_REG_T;

/* Response status */
typedef union {
    UI32_T reg[DCC_MT_IO_IND_HASH_STATUS_REG_WORD_SIZE];
    struct {
        UI32_T ind_access_done : 1;
        UI32_T op_suc : 1;
        UI32_T ind_result0 : 30;
        UI32_T ind_result1 : 32;
        UI32_T ind_result2 : 32;
    } field;
} DCC_MT_IO_REG_HASH_STAT_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T cmd : 3;
        UI32_T key_type : 2;
        UI32_T ecc_access : 1;
        UI32_T acc_bmp : 24;
        UI32_T insert_hit_op : 1;
        UI32_T del_hit_op : 1;
    } field;
} DCC_MT_IO_REG_FPU_HASH_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T cmd : 3;
        UI32_T ecc_access : 1;
    } field;
    struct {
        UI32_T cmd : 3;
        UI32_T key_type : 1;
        UI32_T ecc_access : 1;
    } field1;
} DCC_MT_IO_REG_HASH_CMD_REG_T;
typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T cmd : 3;
        UI32_T mode : 2;
        UI32_T ind_slc_select : 1;
    } field;
} DCC_MT_IO_REG_FPU_TCAM_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T cmd : 3;
        UI32_T mode : 3;
    } field;
} DCC_MT_IO_REG_TCAM_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        UI32_T ind_mem_addr : 15;
    } field;
} DCC_MT_IO_REG_FPU_TCAM_ADDR_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_ADDR_REG_WORD_SIZE];
    struct {
        UI32_T ind_mem_addr : 14;
    } field;
} DCC_MT_IO_REG_TCAM_ADDR_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        UI32_T ind_access_done : 1;
    } field;
} DCC_MT_IO_REG_TCAM_STA_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_TCAM_MOVE_REG_WORD_SIZE];
    struct {
        UI32_T src_addr : 14;
        UI32_T dst_addr : 14;
        UI32_T op_num : 14;
        UI32_T move_mode : 2;
    } ciat_cmd;
    struct {
        UI32_T src_addr : 15;
        UI32_T dst_addr : 15;
        UI32_T op_num : 15;
        UI32_T move_mode : 2;
    } fpu_cmd;
} DCC_MT_IO_REG_TCAM_MOVE_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_STATUS_REG_WORD_SIZE];
    struct {
        UI32_T cur_status : 3;
        UI32_T ack_lock : 4;
        UI32_T move_done : 1;
        UI32_T cur_src_ptr : 14;
    } field;
} DCC_MT_IO_REG_TCAM_MOVE_STA_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 8;
        UI32_T mem_inst_sel : 4;
    } field;
} DCC_MT_IO_REG_IPL_CPX_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 10;
    } field;
} DCC_MT_IO_REG_IPL_CPX_FD_BUF_MEM_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 12;
        UI32_T mem_bank_id : 4;
        UI32_T mem_umac_id : 2;
    } field;
} DCC_MT_IO_REG_IPL_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 15;
        UI32_T mem_umac_id : 2;
    } field;
} DCC_MT_IO_REG_IPL_APP_FD_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 6;
        UI32_T mem_umac_id : 2;
    } field;
} DCC_MT_IO_REG_IPL_APP_FBM_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 11;
        UI32_T dp_sel : 1;
    } field;
} DCC_MT_IO_REG_IPL_LBM_WD_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 9;
        UI32_T mem_sel : 5;
        UI32_T dp_sel : 1;
    } field;
} DCC_MT_IO_REG_IPL_LBM_DATA_BUF_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 10;
        UI32_T bank_idx : 5;
        UI32_T umac_id_sel : 2;
    } field;
} DCC_MT_IO_REG_EPL_APP_UMAC_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 10;
        UI32_T bank_idx : 5;
        UI32_T umac_id_sel : 2;
    } field;
} DCC_MT_IO_REG_EPL_UMAC_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 13;
        UI32_T umac_id_sel : 2;
    } field;
} DCC_MT_IO_REG_EPL_UMAC_FD_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T bank_id : 5;
        UI32_T address : 7;
    } field;
} DCC_MT_IO_REG_EPL_CPX_DATA_BUF_MEM_IND_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T address : 10;
    } field;
} DCC_MT_IO_REG_EPL_CPX_FD_BUF_MEM_CMD_REG_T;

typedef union {
    UI32_T reg[DCC_MT_IO_IND_CMD_REG_WORD_SIZE];
    struct {
        UI32_T bank_id : 5;
        UI32_T address : 7;
    } field;
} DCC_MT_IO_REG_TM_EMU_VERF_MEM_IND_CMD_REG_T;

#else
#error "Host endian is not defined!!\n"
#endif
#pragma pack(pop)

typedef struct {
    DCC_MT_IO_REG_FPU_TCAM_CMD_REG_T ind_cmd;
    DCC_MT_IO_REG_FPU_TCAM_ADDR_REG_T ind_addr;
    DCC_MT_IO_REG_TCAM_STA_REG_T ind_sta;
    UI32_T acc_bmp;
} DCC_MT_TCAM_FPU_INFO_T;

typedef struct {
    DCC_MT_IO_REG_TCAM_CMD_REG_T ind_cmd;
    DCC_MT_IO_REG_TCAM_ADDR_REG_T ind_addr;
    DCC_MT_IO_REG_TCAM_STA_REG_T ind_sta;
} DCC_MT_TCAM_INFO_T;

typedef struct {
    DCC_MT_IO_REG_FPU_HASH_CMD_REG_T ind_cmd;
    DCC_MT_IO_REG_HASH_IND_ADDR_REG_T ind_addr;
    DCC_MT_IO_REG_FPU_HASH_STAT_REG_T ind_sta;
} DCC_MT_HASH_FPU_INFO_T;

typedef struct {
    DCC_MT_IO_REG_HASH_CMD_REG_T ind_cmd;
    DCC_MT_IO_REG_HASH_IND_ADDR_REG_T ind_addr;
    DCC_MT_IO_REG_HASH_STAT_REG_T ind_sta;
} DCC_MT_HASH_INFO_T;

typedef struct {
    DCC_MT_IO_REG_TCAM_MOVE_CMD_REG_T ind_move_cmd;
    DCC_MT_IO_REG_TCAM_MOVE_STA_REG_T ind_move_sta;
} DCC_MT_TCAM_MOVE_INFO_T;

typedef union {
    DCC_MT_IO_REG_TM_EMU_VERF_MEM_IND_CMD_REG_T tm_emu_verf_mem_ind_cmd;
    DCC_MT_IO_REG_EPL_CPX_DATA_BUF_MEM_IND_CMD_REG_T epl_cpx_data_buf_mem_ind_cmd;
    DCC_MT_IO_REG_EPL_UMAC_FD_BUF_MEM_IND_CMD_REG_T epl_umac_fd_buf_mem_ind_cmd;
    DCC_MT_IO_REG_EPL_UMAC_DATA_BUF_MEM_IND_CMD_REG_T epl_umac_data_buf_mem_ind_cmd;
    DCC_MT_IO_REG_EPL_APP_UMAC_DATA_BUF_MEM_IND_CMD_REG_T epl_app_umac_data_buf_mem_ind_cmd;
    DCC_MT_IO_REG_IPL_LBM_DATA_BUF_IND_CMD_REG_T ipl_lbm_data_buf_ind_cmd;
    DCC_MT_IO_REG_IPL_LBM_WD_MEM_IND_CMD_REG_T ipl_lbm_wd_mem_ind_cmd;
    DCC_MT_IO_REG_IPL_APP_FBM_MEM_IND_CMD_REG_T ipl_app_fbm_mem_ind_cmd;
    DCC_MT_IO_REG_IPL_APP_FD_MEM_IND_CMD_REG_T ipl_app_fd_mem_ind_cmd;
    DCC_MT_IO_REG_IPL_DATA_BUF_MEM_IND_CMD_REG_T ipl_data_buf_mem_ind_cmd;
    DCC_MT_IO_REG_IPL_CPX_FD_BUF_MEM_CMD_REG_T ipl_cpx_fd_bum_mem_ind_cmd;
    DCC_MT_IO_REG_IPL_CPX_DATA_BUF_MEM_IND_CMD_REG_T ipl_cpx_data_buf_mem_ind_cmd;
} DCC_MT_PL_TM_IND_MEM_INFO_T;

typedef struct {
    UI32_T ind_cmd_addr;
    UI32_T ind_address_addr;
    UI32_T ind_status_addr;
    UI32_T ind_data_addr;
    UI32_T acc_bmp_addr;

    union {
        DCC_MT_TCAM_FPU_INFO_T tcam_fpu_info;
        DCC_MT_TCAM_INFO_T tcam_info;
        DCC_MT_HASH_FPU_INFO_T hash_fpu_info;
        DCC_MT_HASH_INFO_T hash_info;
        DCC_MT_PL_TM_IND_MEM_INFO_T tm_pl_info;
        DCC_MT_TCAM_MOVE_INFO_T tcam_move_info;
    };

    DCC_MT_TABLE_TYPE_E table_type;
    BOOL_T access_by_dma;

} DCC_MT_TABLE_META_T;

/* DCC CMST ERROR LOG */
#pragma pack(push, 1)
#if defined(CLX_EN_BIG_ENDIAN)
typedef struct {
    UI32_T req_addr_2 : 21;
    UI32_T req_mid : 3;
    UI32_T req_sn : 8;
    UI32_T : 3;
    UI32_T error_info_valid : 1;
    UI32_T master_id : 3;
    UI32_T cmst_error_code : 3;
    UI32_T req_type : 2;
    UI32_T req_attr : 3;
    UI32_T req_size : 6;
    UI32_T : 2;
    UI32_T req_addr_1 : 9;
} DCC_ERROR_CMST_CODE_T;

typedef struct {
    UI32_T req_addr_2 : 21;
    UI32_T req_mid : 3;
    UI32_T req_sn : 8;
    UI32_T : 3;
    UI32_T error_info_valid : 1;
    UI32_T master_id : 3;
    UI32_T cmst_error_code : 3;
    UI32_T req_type : 2;
    UI32_T req_attr : 3;
    UI32_T req_size : 6;
    UI32_T slv_error_code : 2;
    UI32_T req_addr_1 : 9;
} DCC_ERROR_CSLV_CODE_T;

typedef struct {
    UI32_T chain_id_2 : 5;
    UI32_T : 8;
    UI32_T req_addr_lsb : 8;
    UI32_T : 3;
    UI32_T : 8;
    UI32_T : 3;
    UI32_T error_info_valid : 1;
    UI32_T master_id : 3;
    UI32_T cmst_error_code : 3;
    UI32_T req_type : 2;
    UI32_T req_attr : 3;
    UI32_T req_size : 6;
    UI32_T : 2;
    UI32_T : 5;
    UI32_T chain_id_1 : 4;
} DCC_ERROR_OTHER_CODE_T;
#elif defined(CLX_EN_LITTLE_ENDIAN)
typedef struct {
    UI32_T req_sn : 8;
    UI32_T req_mid : 3;
    UI32_T req_addr_2 : 21;
    UI32_T req_addr_1 : 9;
    UI32_T : 2;
    UI32_T req_size : 6;
    UI32_T req_attr : 3;
    UI32_T req_type : 2;
    UI32_T cmst_error_code : 3;
    UI32_T master_id : 3;
    UI32_T error_info_valid : 1;
    UI32_T : 3;
} DCC_ERROR_CMST_CODE_T;

typedef struct {
    UI32_T req_sn : 8;
    UI32_T req_mid : 3;
    UI32_T req_addr_2 : 21;
    UI32_T req_addr_1 : 9;
    UI32_T slv_error_code : 2;
    UI32_T req_size : 6;
    UI32_T req_attr : 3;
    UI32_T req_type : 2;
    UI32_T cmst_error_code : 3;
    UI32_T master_id : 3;
    UI32_T error_info_valid : 1;
    UI32_T : 3;
} DCC_ERROR_CSLV_CODE_T;

typedef struct {
    UI32_T : 8;
    UI32_T : 3;
    UI32_T req_addr_lsb : 8;
    UI32_T : 8;
    UI32_T chain_id_2 : 5;
    UI32_T chain_id_1 : 4;
    UI32_T : 5;
    UI32_T : 2;
    UI32_T req_size : 6;
    UI32_T req_attr : 3;
    UI32_T req_type : 2;
    UI32_T cmst_error_code : 3;
    UI32_T master_id : 3;
    UI32_T error_info_valid : 1;
    UI32_T : 3;
} DCC_ERROR_OTHER_CODE_T;
#else
#error "Host endian is not defined!!\n"
#endif
#pragma pack(pop)

typedef struct {
    union {
        DCC_ERROR_CMST_CODE_T cmst_code;
        DCC_ERROR_CSLV_CODE_T cslv_code;
        DCC_ERROR_OTHER_CODE_T other_code;
    };

} DCC_ERROR_CODE_T;

typedef enum {
    DCC_RSP_TIMEOUT = 0,
    DCC_WR_SLAVE_ERROR,
    DCC_RD_SLAVE_ERROR,
    DCC_SNCK_REQ_DROP_ERROR,
    DCC_SNCK_RSP_DROP_ERROR,
    DCC_WR_ADDR_ERROR,
    DCC_RD_ADDR_ERROR,
    DCC_RSP_PROTOCOL_ERROR,
    DCC_ERROR_LAST
} DCC_ERR_CODE_E;

CLX_ERROR_NO_T
dcc_readIndEntry(const UI32_T unit,
                 const UI32_T entry_len,
                 const UI32_T entry_num,
                 UI32_T *ptr_data,
                 DCC_MT_TABLE_META_T *table_info);

CLX_ERROR_NO_T
dcc_writeIndEntry(const UI32_T unit,
                  const UI32_T entry_len,
                  const UI32_T entry_num,
                  const UI32_T *ptr_data,
                  DCC_MT_TABLE_META_T *table_info);

CLX_ERROR_NO_T
dcc_io_actHashEntry(const UI32_T unit,
                    const UI32_T entry_len,
                    const UI32_T *ptr_data,
                    DCC_MT_TABLE_META_T *table_info);

CLX_ERROR_NO_T
dcc_readIndSramEntry(const UI32_T unit,
                     const UI32_T entry_len,
                     const UI32_T entry_num,
                     UI32_T *ptr_data,
                     DCC_MT_TABLE_META_T *table_info);

CLX_ERROR_NO_T
dcc_writeIndSramEntry(const UI32_T unit,
                      const UI32_T entry_len,
                      const UI32_T entry_num,
                      const UI32_T *ptr_data,
                      DCC_MT_TABLE_META_T *table_info);

CLX_ERROR_NO_T
dcc_io_moveTcamEntry(const UI32_T unit, DCC_MT_TABLE_META_T *table_info);

/**
 * @brief dcc_mt_io_initIoThread() is responsible for thread of DCC_MT IO initialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_MT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_mt_io_initIoThread(const UI32_T unit);

/**
 * @brief dcc_mt_io_deinitIoThread() is responsible for thread of DCC_MT IO deinitialization
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DCC_MT.
 * @return         CLX_E_OTHERS       - Fail to complete initialization procedure.
 * @return         CLX_E_NO_MEMORY    - Fail to allocate memory.
 */
CLX_ERROR_NO_T
dcc_mt_io_deinitIoThread(const UI32_T unit);

#endif /* END of DCC_MT_IO_H*/
