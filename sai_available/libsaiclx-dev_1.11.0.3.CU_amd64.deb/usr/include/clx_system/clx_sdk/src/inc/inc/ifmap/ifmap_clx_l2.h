/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  ifmap_clx_l2.h
 * PURPOSE:
 *      It provide user port to CLX port translation L2 API.
 * NOTES:
 *
 */
#ifndef IFMAP_CLX_L2_H
#define IFMAP_CLX_L2_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_l2.h>

CLX_ERROR_NO_T
ifmap_clx_l2_addAddr(const UI32_T unit, const CLX_L2_ADDR_T *ptr_addr);

CLX_ERROR_NO_T
ifmap_clx_l2_getAddr(const UI32_T unit, CLX_L2_ADDR_T *ptr_addr);

CLX_ERROR_NO_T
ifmap_clx_l2_replaceAddr(const UI32_T unit,
                         const UI32_T match_field,
                         const CLX_L2_ADDR_T *ptr_match_addr,
                         const UI32_T replace_field,
                         const CLX_L2_ADDR_T *ptr_replace_addr);

CLX_ERROR_NO_T
ifmap_clx_l2_traverseAddr(const UI32_T unit,
                          const CLX_L2_ADDR_TRAVERSE_MODE_T mode,
                          const CLX_L2_ADDR_TRAVERSE_FUNC_T callback,
                          void *ptr_cookie);

CLX_ERROR_NO_T
ifmap_clx_l2_registerAddrNotifyCallback(const UI32_T unit,
                                        const CLX_L2_ADDR_NOTIFY_FUNC_T callback,
                                        void *ptr_cookie);

CLX_ERROR_NO_T
ifmap_clx_l2_deregisterAddrNotifyCallback(const UI32_T unit,
                                          const CLX_L2_ADDR_NOTIFY_FUNC_T callback,
                                          void *ptr_cookie);

CLX_ERROR_NO_T
ifmap_clx_l2_getMcastId(const UI32_T unit,
                        const UI32_T mcast_id,
                        UI32_T *ptr_flags,
                        CLX_PORT_BITMAP_T port_bitmap);

CLX_ERROR_NO_T
ifmap_clx_l2_addMcastEgrIntf(const UI32_T unit,
                             const UI32_T mcast_id,
                             const UI32_T egr_intf_cnt,
                             CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf);

CLX_ERROR_NO_T
ifmap_clx_l2_delMcastEgrIntf(const UI32_T unit,
                             const UI32_T mcast_id,
                             const UI32_T egr_intf_cnt,
                             CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf);

CLX_ERROR_NO_T
ifmap_clx_l2_getMcastEgrIntf(const UI32_T unit,
                             const UI32_T mcast_id,
                             const UI32_T egr_intf_cnt,
                             CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf,
                             UI32_T *ptr_actual_egr_intf_cnt);

#endif
