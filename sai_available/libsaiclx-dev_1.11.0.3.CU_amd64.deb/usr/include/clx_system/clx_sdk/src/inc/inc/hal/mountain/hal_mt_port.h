/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_MT_PORT_H
#define HAL_MT_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <hal/hal_mac.h>
#include <hal/hal_port.h>
#include <cmlib/cmlib_avl.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_mac.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NAMCHABARWA_PORT_LCL_MAX_NUM 8192
#define HAL_MT_NAMCHABARWA_PTP_MSG_ONE_STEP (0x1)
#define HAL_MT_NAMCHABARWA_PTP_MSG_TWO_STEP (0x2)
#define HAL_MT_NAMCHABARWA_PTP_MSG_DELAY    (0x1)
#define HAL_MT_NAMCHABARWA_PTP_MSG_PDELAY   (0x2)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_PORT_LOCK(unit)   hal_mt_port_lockPortResource(unit)
#define HAL_MT_PORT_UNLOCK(unit) hal_mt_port_unlockPortResource(unit)
/* EXPORTED SUBPROGRAM SPECIFICATIONS */

typedef enum {
    HAL_MT_PORT_TYPE_NOR = 0,
    HAL_MT_PORT_TYPE_REC = 1,
    HAL_MT_PORT_TYPE_CPU = 2,
    HAL_MT_PORT_TYPE_FAB = 3
} HAL_MT_PORT_TYPE_T;

/* Synce mode */
typedef enum {
    HAL_MT_PORT_SYNCE_MODE_DISABLE = 0x0,             /* Synce mode disable */
    HAL_MT_PORT_SYNCE_MODE_0 = CLX_PORT_SYNCE_MODE_0, /* Synce mode 0 */
    HAL_MT_PORT_SYNCE_MODE_1 = CLX_PORT_SYNCE_MODE_1, /* Synce mode 1 */
    HAL_MT_PORT_SYNCE_MODE_LAST
} HAL_MT_PORT_SYNCE_MODE_T;

typedef enum {
    HAL_MT_PORT_SPEED_CODE_DEFAULT = 0x0,
    HAL_MT_PORT_SPEED_CODE_10G = 0x1,
    HAL_MT_PORT_SPEED_CODE_25G = 0x2,
    HAL_MT_PORT_SPEED_CODE_40G = 0x4,
    HAL_MT_PORT_SPEED_CODE_50G = 0x8,
    HAL_MT_PORT_SPEED_CODE_100G = 0x10,
    HAL_MT_PORT_SPEED_CODE_200G = 0x20,
    HAL_MT_PORT_SPEED_CODE_400G = 0x40,
    HAL_MT_PORT_SPEED_CODE_800G = 0x80,
    HAL_MT_PORT_SPEED_CODE_LAST
} HAL_MT_PORT_SPEED_CODE_T;

typedef enum {
    HAL_PORT_PTP_MODE_DISABLE = 0,
    HAL_PORT_PTP_MODE_MASTER,
    HAL_PORT_PTP_MODE_SLAVE,
    HAL_PORT_PTP_MODE_TRANSPARENT,
    HAL_PORT_PTP_MODE_LAST,
} HAL_PORT_PTP_MODE_T;

typedef enum {
    HAL_MT_PORT_WBDB_ID_PBM = 0,
    HAL_MT_PORT_WBDB_ID_TXS,
    HAL_MT_PORT_WBDB_ID_RXS,
    HAL_MT_PORT_WBDB_ID_LANE_CNT,
    HAL_MT_PORT_WBDB_ID_LFC_TX,
    HAL_MT_PORT_WBDB_ID_PFC_TX,
    HAL_MT_PORT_WBDB_ID_PMD_INTF,
    HAL_MT_PORT_WBDB_ID_PHY_MSS,
    HAL_MT_PORT_WBDB_ID_PHY_TX_LANE_SWAP,
    HAL_MT_PORT_WBDB_ID_PHY_RX_LANE_SWAP,
    HAL_MT_PORT_WBDB_ID_PHY_NEXT_PAGE,
    HAL_MT_PORT_WBDB_ID_PHY_AN_ABILITY,
    HAL_MT_PORT_WBDB_ID_PHY_FEC,
    HAL_MT_PORT_WBDB_ID_PHY_ANLT_GROUP,
    HAL_MT_PORT_WBDB_ID_LAST
} HAL_MT_PORT_WBDB_ID_T;

CLX_ERROR_NO_T
hal_mt_port_transSpeedLaneCnt(const CLX_PORT_SPEED_T speed,
                              const UI32_T lane_cnt,
                              HAL_PORT_SPEED_LANT_T *ptr_speed_lane);

CLX_ERROR_NO_T
hal_mt_port_lockPortResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_port_unlockPortResource(const UI32_T unit);

/**
 * @brief To set the speed for a specific port.
 *
 * @param [in]     unit     - Device unit number.
 * @param [in]     port     - Physical port id.
 * @param [in]     speed    - The speed of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setSpeed(const UI32_T unit, const UI32_T port, const CLX_PORT_SPEED_T speed);

/**
 * @brief To get the speed for a specific port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [out]    ptr_speed    - The speed of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getSpeed(const UI32_T unit, const UI32_T port, CLX_PORT_SPEED_T *ptr_speed);

/**
 * @brief To get the PFC configuration of mac.
 *
 * @param [in]     unit          - Chip id
 * @param [in]     port          - Port id
 * @param [out]    ptr_pfc_tx    - pfc tx status
 * @param [out]    ptr_pfc_rx    - pfc rx status
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_mac_getMacPfc(const UI32_T unit, const UI32_T port, UI32_T *ptr_pfc_tx, UI32_T *ptr_pfc_rx);

/**
 * @brief To set the flow control configuration for a specific port.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     fc      - The flow control configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setFlowCtrl(const UI32_T unit, const UI32_T port, const CLX_PORT_FC_T fc);

/**
 * @brief To get the flow control configuration for a specific port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [out]    ptr_fc    - The flow control configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getFlowCtrl(const UI32_T unit, const UI32_T port, CLX_PORT_FC_T *ptr_fc);

/**
 * @brief To set the PFC configuration for a specific port.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     pri     - The priority number, CLX_PORT_FC_DEFAULT_PRI
 * @param [in]     pfc     - The PFC configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setPriFlowCtrl(const UI32_T unit,
                           const UI32_T port,
                           const UI8_T pri,
                           const CLX_PORT_FC_T pfc);

/**
 * @brief To get the PFC configuration for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     pri        - The priority number 0~7.
 * @param [out]    ptr_pfc    - The PFC configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getPriFlowCtrl(const UI32_T unit,
                           const UI32_T port,
                           const UI8_T pri,
                           CLX_PORT_FC_T *ptr_pfc);

/**
 * @brief To set pkt drop for tm module.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     drop_flg - drop flag
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setPktDrop(const UI32_T unit, const UI32_T port, const UI8_T drop_flg);

/**
 * @brief To set the EEE mode for a specific port.
 *
 * NB umac not support eee
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     mode    - The EEE mode of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setEeeMode(const UI32_T unit, const UI32_T port, const CLX_PORT_EEE_MODE_T mode);

/**
 * @brief To get the EEE mode for a specific port.
 *
 * NB umac not support eee
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [out]    ptr_mode    - The EEE mode of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getEeeMode(const UI32_T unit, const UI32_T port, CLX_PORT_EEE_MODE_T *ptr_mode);

/**
 * @brief To set the FEC configuration for a specific port.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     clx_fec - The FEC configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setFec(const UI32_T unit, const UI32_T port, const UI32_T clx_fec);

/**
 * @brief To get the FEC configuration for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [out]    ptr_fec    - The FEC configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getFec(const UI32_T unit, const UI32_T port, UI32_T *ptr_fec);

/**
 * @brief To set the administrative state for a specific port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [in]     enable    - To enable/disable the port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setAdminState(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief To get the administrative state for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - To enable/disable the port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getAdminState(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief To set the autonegotiation status for a specific port.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Physical port id.
 * @param [in]     anlt    - Toggle status of autonegotiation-linktraining per port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setAnLtStatus(const UI32_T unit, const UI32_T port, const UI32_T anlt);

/**
 * @brief To get the autonegotiation status for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_anlt      - Toggle status of autonegotiation per port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getAnLtStatus(const UI32_T unit, const UI32_T port, UI32_T *ptr_anlt);

/**
 * @brief To set the auto-negotiation advertisement for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [in]     ptr_ability    - Autonegotiation ability setting per port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setLocalAdvAbility(const UI32_T unit,
                               const UI32_T port,
                               const CLX_PORT_ABILITY_T *ptr_ability);

/**
 * @brief To get the auto-negotiation advertisement for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [in]     ptr_ability    - Autonegotiation ability setting per port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getLocalAdvAbility(const UI32_T unit,
                               const UI32_T port,
                               CLX_PORT_ABILITY_T *ptr_ability);

/**
 * @brief This API is used to get the auto-negotiation remote advertisement for a specific port.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Physical port ID
 * @param [out]    ptr_ability    - Autonegotiation ability setting per port
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getRemoteAdvAbility(const UI32_T unit,
                                const UI32_T port,
                                CLX_PORT_ABILITY_T *ptr_ability);

/**
 * @brief This API is used to set the loopback for a specific port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     lbtype      - Loopback type:
 *                               CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                               CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                               CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL: local PHY parallel
 * loopback. CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL: remote serial loopback.
 *                               CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL: remote parallel loopback
 * external phy. CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setLoopback(const UI32_T unit, const UI32_T port, const CLX_PORT_LOOPBACK_T lbtype);

/**
 * @brief This API is used to get the loopback for a specific port.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - Physical port ID
 * @param [out]    ptr_lbtype      - Loopback type:
 *                                   CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                                   CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                                   CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL: local PHY parallel
 * loopback. CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL: remote serial loopback.
 *                                   CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL: remote parallel
 * loopback external phy. CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getLoopback(const UI32_T unit, const UI32_T port, CLX_PORT_LOOPBACK_T *ptr_lbtype);

/**
 * @brief This API is used to set the loopback output for a specific port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port ID
 * @param [in]     enable    - 1 for enable loopback and output, and
 *                             0 for disable loopback and output.
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setLoopbackOutput(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief This API is used to get the loopback output for a specific port.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port          - Physical port ID
 * @param [out]    ptr_enable    - 1 for enable loopback and output, and
 *                                 0 for disable loopback and output.
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getLoopbackOutput(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief This API is used to probe a specific port
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_probe(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to initialize a specific port.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_initPort(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to deinitialize a specific port.
 *
 * All ports in the same sub-marco on CL8600 must
 * link/admin down first before deinit a port
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_deinitPort(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to set the lane count for a specific port.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @param [in]     cnt     - Lane count
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setLaneCnt(const UI32_T unit, const UI32_T port, const UI32_T cnt);

/**
 * @brief This API is used to get the lane count for a specific port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port ID
 * @param [out]    ptr_cnt    - Lane count
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getLaneCnt(const UI32_T unit, const UI32_T port, UI32_T *ptr_cnt);

/**
 * @brief This API is used to get the physical link status for a specific port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [out]    ptr_link    - Link status (Reference to CLX_PORT_LINK_XXX)
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getLink(const UI32_T unit, const UI32_T port, UI32_T *ptr_link);

/**
 * @brief This API is used to get the physical fault status for a specific port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [out]    ptr_fault    - Fault status (Reference to CLX_PORT_FAULT_XXX)
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getFault(const UI32_T unit, const UI32_T port, UI32_T *ptr_fault);

/**
 * @brief This API is used to set the medium type for a specific port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port ID
 * @param [in]     medium    - Medium type
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setMediumType(const UI32_T unit,
                          const UI32_T port,
                          const CLX_PORT_MEDIUM_TYPE_T medium);

/**
 * @brief This API is used to get the medium type for a specific port.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port          - Physical port ID
 * @param [out]    ptr_medium    - Medium type
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getMediumType(const UI32_T unit, const UI32_T port, CLX_PORT_MEDIUM_TYPE_T *ptr_medium);

/**
 * @brief This API is used to set the PHY configuration for a specific port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [in]     location     - PHY location
 * @param [in]     property     - PHY property type
 * @param [in]     value_cnt    - PHY property value count
 * @param [in]     ptr_value    - PHY property value array
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setPhyProperty(const UI32_T unit,
                           const UI32_T port,
                           const CLX_PORT_PHY_LOCATION_T location,
                           const CLX_PORT_PHY_PROPERTY_T property,
                           const UI32_T value_cnt,
                           const UI32_T *ptr_value);

/**
 * @brief This API is used to get the property for a specific port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [in]     location     - PHY location
 * @param [in]     property     - PHY property type
 * @param [in]     value_cnt    - PHY property value count
 * @param [out]    ptr_value    - PHY property value array
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getPhyProperty(const UI32_T unit,
                           const UI32_T port,
                           const CLX_PORT_PHY_LOCATION_T location,
                           const CLX_PORT_PHY_PROPERTY_T property,
                           const UI32_T value_cnt,
                           UI32_T *ptr_value);

/**
 * @brief Set all tx coefficients (CN3, CN2, CN1, C0, C1, C2, C3) for a specific lane
 *        Note 1: different switch family supports different coefficient number
 *        Note 2: when summation of coefficient is overflow, C0 got reduction
 *        Note 3: partial coefficients configuration is allowed (flags within struct config is
 * necessary)
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Physical port ID
 * @param [in]     lane_idx       - lane offset within th port
 * @param [in]     location       - PHY location
 * @param [in]     ptr_tx_coef    - The tx coefficients applied to the specific lane
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setTxCoef(const UI32_T unit,
                      const UI32_T port,
                      const UI32_T lane_idx,
                      const CLX_PORT_PHY_LOCATION_T location,
                      CLX_PORT_TX_COEF_T *ptr_tx_coef);

/**
 * @brief Set all tx coefficients (CN3, CN2, CN1, C0, C1, C2, C3) for a specific lane
 *        Note 1: different switch family supports different coefficient number
 *        Note 2: flags within the struct indicates the coefficients supported in this switch family
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Physical port ID
 * @param [in]     lane_idx       - lane offset within th port
 * @param [in]     location       - PHY location
 * @param [out]    ptr_tx_coef    - The tx coefficients applied to the specific lane
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getTxCoef(const UI32_T unit,
                      const UI32_T port,
                      const UI32_T lane_idx,
                      const CLX_PORT_PHY_LOCATION_T location,
                      CLX_PORT_TX_COEF_T *ptr_tx_coef);

/**
 * @brief This API is used to get src_supp_tag in port module for setting service l2 intf property.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - port id
 * @param [out]    ptr_value    - source suppression tag value
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getSrcSuppTag(const UI32_T unit, const CLX_PORT_T port, UI32_T *ptr_value);

/**
 * @brief This API is used to add a merged vlan group entry.
 *
 * 1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 * to merged_vid_min when loop-up port-seg service table.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     port              - Physical port ID
 * @param [in]     merged_vid_min    - Minimum value of merged vlan id
 * @param [in]     merged_vid_max    - Maximum value of merged vlan id
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_addSegServiceGroup(const UI32_T unit,
                               const UI32_T port,
                               const CLX_VLAN_T merged_vid_min,
                               const CLX_VLAN_T merged_vid_max);

/**
 * @brief This API is used to del a merged vlan group entry.
 *
 * 1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 * to merged_vid_min when loop-up port-seg service table.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     port              - Physical port ID
 * @param [in]     merged_vid_min    - Minimum value of merged vlan id
 * @param [in]     merged_vid_max    - Maximum value of merged vlan id
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_delSegServiceGroup(const UI32_T unit,
                               const UI32_T port,
                               const CLX_VLAN_T merged_vid_min,
                               const CLX_VLAN_T merged_vid_max);

/**
 * @brief This API is used to get a merged vlan group entry.
 *
 * 1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 * to merged_vid_min when loop-up port-seg service table.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     port              - Physical port ID
 * @param [in]     merged_vid_min    - Minimum value of merged vlan id
 * @param [in]     merged_vid_max    - Maximum value of merged vlan id
 * @return         CLX_E_OK                 - Entry exist
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not added
 */
CLX_ERROR_NO_T
hal_mt_port_getSegServiceGroup(const UI32_T unit,
                               const UI32_T port,
                               const CLX_VLAN_T merged_vid_min,
                               const CLX_VLAN_T merged_vid_max);

/**
 * @brief This API is used to traverse merged vlan group entry.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type
 * CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_mt_port_traverseSegServiceGroup(const UI32_T unit,
                                    const CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T callback,
                                    void *ptr_cookie);

/**
 * @brief This API is used to add port seg service. It is called by clx_port_addSegService()
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - interface object
 * @param [in]     seg0           - segment parameter 0, 0xFFFFFFFF means invalid value
 * @param [in]     seg1           - segment parameter 1, 0xFFFFFFFF means invalid value
 * @param [in]     ptr_seg_srv    - segment service
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_addSegService(const UI32_T unit,
                          const CLX_PORT_T port,
                          const UI32_T seg0,
                          const UI32_T seg1,
                          const CLX_PORT_SEG_SRV_T *ptr_seg_srv);

/**
 * @brief This API is used to del port seg service. It is called by clx_port_delSegService().
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - interface object
 * @param [in]     seg0    - segment parameter 0
 * @param [in]     seg1    - segment parameter 1
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_delSegService(const UI32_T unit,
                          const CLX_PORT_T port,
                          const UI32_T seg0,
                          const UI32_T seg1);

/**
 * @brief This API is used to get port seg service. It is called by clx_port_getSegService().
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - interface object
 * @param [in]     seg0           - segment parameter 0
 * @param [in]     seg1           - segment parameter 1
 * @param [out]    ptr_seg_srv    - segment service
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getSegService(const UI32_T unit,
                          const CLX_PORT_T port,
                          const UI32_T seg0,
                          const UI32_T seg1,
                          CLX_PORT_SEG_SRV_T *ptr_seg_srv);

/**
 * @brief To apply default properties for the new created port
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Port number
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Set port default fail.
 */
CLX_ERROR_NO_T
hal_mt_port_setPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief To clear default properties for the destroyed port
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - Port number
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Reset port default fail.
 */
CLX_ERROR_NO_T
hal_mt_port_resetPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief To initialize port module.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK                - Operate success.
 * @return         CLX_E_ALREADY_INITED    - Module is reinitialized
 * @return         CLX_E_OTHER             - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_port_init(const UI32_T unit);

/**
 * @brief To deinitialize the port module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK            - success
 * @return         CLX_E_NOT_INITED    - Module is not initialized
 * @return         CLX_E_OTHERS        - Deinitialization failed for other reasons.
 */
CLX_ERROR_NO_T
hal_mt_port_deinit(const UI32_T unit);

/**
 * @brief Set Port control property.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Port ID
 * @param [in]     property    - Property type
 * @param [in]     param0      - First parameter
 * @param [in]     param1      - Second parameter
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setProperty(const UI32_T unit,
                        const UI32_T port,
                        const CLX_PORT_PROPERTY_T property,
                        const UI32_T param0,
                        const UI32_T param1);

/**
 * @brief Get port control property.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Port ID
 * @param [in]     property    - Property type
 * @param [out]    ptr_param0  - value0 for property
 * @param [out]    ptr_param1  - value1 for property
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getProperty(const UI32_T unit,
                        const UI32_T port,
                        const CLX_PORT_PROPERTY_T property,
                        UI32_T *ptr_param0,
                        UI32_T *ptr_param1);

/**
 * @brief This API is used to get the mapping between unit/port and mac/lane
 *        number.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port             - Physical port ID
 * @param [out]    ptr_eth_macro    - physical MAC macro ID (shown in schematic)
 * @param [out]    ptr_lane         - Physical lane ID
 * @param [out]    ptr_max_speed    - The maximum speed of the physical port
 * @param [out]    ptr_flags        - Attributes of the physical port
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getLaneMap(const UI32_T unit,
                       const UI32_T port,
                       UI32_T *ptr_eth_macro,
                       UI32_T *ptr_lane,
                       CLX_PORT_SPEED_T *ptr_max_speed,
                       UI32_T *ptr_flags);

/**
 * @brief This API is used to set the properties for a specific interface object
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     intf            - Interface object
 * @param [out]    ptr_property    - The pointer of the interface properties
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setIntfProperty(const UI32_T unit,
                            const CLX_PORT_T intf,
                            const CLX_PORT_INTF_PROPERTY_T *ptr_property);

/**
 * @brief This API is used to set the properties for a specific interface object
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     intf            - Interface object
 * @param [out]    ptr_property    - The pointer of the interface properties
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getIntfProperty(const UI32_T unit,
                            const CLX_PORT_T intf,
                            CLX_PORT_INTF_PROPERTY_T *ptr_property);

/**
 * @brief Set port timestamp state.
 *
 * @param [in]     unit      - Chip id
 * @param [in]     port      - Port id
 * @param [in]     enable    - Timestamp state.
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_port_setTsState(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief Get port timestamp state.
 *
 * @param [in]     unit          - Chip id
 * @param [in]     port          - Port id
 * @param [out]    ptr_enable    - Timestamp state
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_port_getTsState(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief Get port tx timestamp entry information.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - Port id
 * @param [out]    ptr_ts_entry    - Timestamp entry information
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_port_getTsTxEntry(const UI32_T unit, const UI32_T port, CLX_PORT_TS_ENTRY_T *ptr_ts_entry);

/**
 * @brief Get port rx timestamp entry information.
 *
 * @param [in]     unit            - Chip id
 * @param [in]     port            - Port id
 * @param [out]    ptr_ts_entry    - Timestamp entry information
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_port_getTsRxEntry(const UI32_T unit, const UI32_T port, CLX_PORT_TS_ENTRY_T *ptr_ts_entry);

/**
 * @brief Set port rx/tx TS latency based on clock, port speed and FEC.
 *
 * @param [in]     unit    - Chip id
 * @param [in]     port    - Port id
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
hal_mt_port_updateTsLatency(const UI32_T unit, const UI32_T port);

/**
 * @brief Set unidirectional link feature per physical port.
 *
 * The port is always operationally up. The operational status does not
 * depend on local faults and remote faults.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [in]     enable    - 1 for enable unidirectional link, and
 *                             0 for disable unidirectional link.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setUnidirectionalLink(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief Get unidirectional link feature per physical port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [in]     ptr_enable    - 1 for enable unidirectional link, and
 *                                 0 for disable unidirectional link.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getUnidirectionalLink(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief Set tx state per physical port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - 1: enable tx state
 *                             0: disable tx state
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setTxState(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief Get tx state per physical port.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port          - Physical port id
 * @param [in]     ptr_enable    - 1: tx state is enalbed
 *                                 0: tx state is disabled
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getTxState(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief Set rx state per physical port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - 1: enable rx state
 *                             0: disable rx state
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setRxState(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief Get rx state per physical port.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port          - Physical port id
 * @param [in]     ptr_enable    - 1: rx state is enalbed
 *                                 0: rx state is disabled
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getRxState(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief Set led state for a specific port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [in]     chmode    - Mac chmode.
 * @param [in]     enable    - 1 for enable led, and
 *                             0 for disable led.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setLed(const UI32_T unit,
                   const UI32_T port,
                   HAL_MT_NAMCHABARWA_MAC_CHMODE_E chmode,
                   const UI32_T enable);

/**
 * @brief Set MxLink per physical port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - 1: enable MxLink
 *                             0: disable MxLink
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_NOT_SUPPORT      - Not support MxLink
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setMxLink(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief Get replace mac Enable per physical port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     property     - port property
 * @param [in]     port         - Physical port id
 * @param [out]    ptr_enable   - 0/1: disable/enable timestamp replace mac,
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getTsReplaceMacEn(const UI32_T unit,
                              const CLX_PORT_PROPERTY_T property,
                              const UI32_T port,
                              UI32_T *ptr_enable);

/**
 * @brief Set replace mac Enable per physical port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     property  - port property
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - 1: enable timestamp replace mac
 *                             0: disable timestamp replace mac
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setTsReplaceMacEn(const UI32_T unit,
                              const CLX_PORT_PROPERTY_T property,
                              const UI32_T port,
                              const BOOL_T enable);

/**
 * @brief Set MxHdr Enable per physical port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - 1: enable MxHdr
 *                             0: disable MxHdr
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_NOT_SUPPORT      - Not support MxHdr
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setMxHdrEn(const UI32_T unit, const UI32_T port, const BOOL_T enable);

/**
 * @brief Get MxHdr Enable per physical port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port id
 * @param [out]    ptr_enable   - 0/1: disable/enable MxHdr,
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_NOT_SUPPORT      - Not support MxHdr
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getMxHdrEn(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief Get MxLink per physical port.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port          - Physical port id
 * @param [in]     ptr_enable    - 1: MxLink is enalbed
 *                                 0: MxLink is disabled
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_NOT_SUPPORT      - Not support MxLink
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getMxLink(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief Set max length of mib counter per physical port.
 *
 * When packet length is larger than the max length, it will be counted to
 * over-size counter. For example, if MIB_MAX_LENGTH = 2000,
 * for packet with 1518 < length <= 2000, it will be counted to
 * MIB SRAM register of 1519_2560. And for packet length > 2000,
 * it will be counted to oversize_good or oversize_bad counter.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [in]     max_len    - Max length of mib counter
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setMibMaxLen(const UI32_T unit, const UI32_T port, const UI32_T max_len);

/**
 * @brief Get max length of mib counter per physical port.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Physical port id
 * @param [out]    ptr_max_len    - Max length of mib counter
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getMibMaxLen(const UI32_T unit, const UI32_T port, UI32_T *ptr_max_len);

/**
 * @brief Get the status per physical port.
 *
 * There is 8 bits for 8 RX priority flow control status in rx_pfc.
 * RX flow control status for priority x (x = 0~7) =
 * rx_pfc & (CLX_PORT_FC_STATUS_ON << x)
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port          - Physical port id
 * @param [out]    ptr_status    - Port status
 *                                 speed  - reference to CLX_PORT_SPEED_T
 *                                 link   - reference to CLX_PORT_LINK_XXX
 *                                 fault  - reference to CLX_PORT_FAULT_XXX
 *                                 rx_fc  - reference to CLX_PORT_FC_STATUS_XXX
 *                                 rx_pfc - reference to CLX_PORT_FC_STATUS_XXX
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getStatus(const UI32_T unit, const UI32_T port, CLX_PORT_STATUS_T *ptr_status);

/**
 * @brief Force to transmit remote fault out.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id.
 * @param [in]     enable    - 1: force to transmit remote fault out
 *                             0: work as usual
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setTxRemoteFault(const UI32_T unit, const UI32_T port, UI32_T enable);

/**
 * @brief Dump the database per physical port.
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     flags    - Database type
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_dumpDb(const UI32_T unit, const UI32_T flags);

/**
 * @brief This API is used to enable hub logic memory interrupt
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_enableHubLmIntr(const UI32_T unit, const UI32_T port);

/**
 * @brief To get the autonegotiation status for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_anlt      - Toggle status of autonegotiation per port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_getPhyAnLt(const UI32_T unit, const UI32_T port, UI32_T *ptr_anlt);

/**
 * @brief Set Mac property per physical port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port id
 * @param [in]     property     - Mac property type
 * @param [in]     value        - Mac property value
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setMacProperty(const UI32_T unit,
                           const UI32_T port,
                           const HAL_MAC_PROPERTY_T property,
                           const UI32_T value);

/**
 * @brief Set SyncE state per physical port.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port id
 * @param [in]     mode    - SyncE mode
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setSynceMode(const UI32_T unit, const UI32_T port, const CLX_PORT_SYNCE_MODE_T mode);

/**
 * @brief Get SyncE mode per physical port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port id
 * @param [out]    ptr_mode    - SyncE mode
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getSynceMode(const UI32_T unit, const UI32_T port, CLX_PORT_SYNCE_MODE_T *ptr_mode);

/**
 * @brief Get MAC property per physical port.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port id
 * @param [in]     property     - Mac property type
 * @param [out]    ptr_value    - Mac property value
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getMacProperty(const UI32_T unit,
                           const UI32_T port,
                           const HAL_MAC_PROPERTY_T property,
                           UI32_T *ptr_value);

/**
 * @brief This API is used to get link database for a specific port.
 *
 * There are 8 bits for 8 priority flow control state in pfc_tx.
 * Tx flow control state for priority x (x = 0~7) = pfc_tx & (1 << x)
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - Physical port id
 * @param [out]    ptr_tx_state    - Tx state
 * @param [out]    ptr_rx_state    - Rx state
 * @param [out]    ptr_lfc_tx      - Local flow control state
 * @param [out]    ptr_pfc_tx      - Priority flow control state
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_mt_port_getLinkDb(const UI32_T unit,
                      const UI32_T port,
                      UI32_T *ptr_tx_state,
                      UI32_T *ptr_rx_state,
                      UI32_T *ptr_lfc_tx,
                      UI32_T *ptr_pfc_tx);

/**
 * @brief Set meter per physical port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [in]     dir        - Ingress or egress
 * @param [in]     enable     - Enable meter or not
 * @param [in]     mtr_id     - Meter index
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_NOT_SUPPORT      - Not support meter
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setMeter(const UI32_T unit,
                     const UI32_T port,
                     const CLX_DIR_T dir,
                     const UI32_T enable,
                     const UI32_T mtr_id);

/**
 * @brief Get meter per physical port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [in]     dir        - Ingress or egress
 * @param [out]    ptr_enable     - Enable meter or not
 * @param [out]    ptr_mtr_id     - Meter index
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_NOT_SUPPORT      - Not support MxLink
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getMeter(const UI32_T unit,
                     const UI32_T port,
                     const CLX_DIR_T dir,
                     UI32_T *ptr_enable,
                     UI32_T *ptr_mtr_id);

/**
 * @brief Set split horizon per physical port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [in]     disable    - Enable/Disable split horizon
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_port_setSplitHorizon(const UI32_T unit, const UI32_T port, const UI32_T disable);

/**
 * @brief Get split horizon per physical port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [out]    disable    - Enable/Disable split horizon
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_port_getSplitHorizon(const UI32_T unit, const UI32_T port, UI32_T *disable);

/**
 * @brief Set extend vlan parsing enable.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [in]     enable     - Enable/Disable vlan parse.
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_port_setExtendVlanParse(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief Get extend vlan parse per physical port.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [out]    ptr_enable - Enable/Disable tvlan
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_port_getExtendVlanParse(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief This API is used to get the ability for a specific port.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Physical port ID
 * @param [out]    ptr_ability    - Port ability
 * @return         CLX_E_OK               - The operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getAbility(const UI32_T unit, const UI32_T port, CLX_PORT_ABILITY_T *ptr_ability);

/**
 * @brief Set egress high latency per physical port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     enable    - Enable/Disable high latency
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_port_setEgrHighLatency(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief Get high latency per physical port.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [out]    enable    - Enable/Disable high latency
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_port_getEgrHighLatency(const UI32_T unit, const UI32_T port, UI32_T *enable);

/**
 * @brief Set high latency threshold.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     threshold    - High latency threshold
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_port_setEgrHighLatencyThreshold(const UI32_T unit, const UI32_T threshold);

/**
 * @brief Get high latency threshold.
 *
 * @param [in]     unit         - Device unit number
 * @param [out]    threshold    - High latency threshold
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_mt_port_getEgrHighLatencyThreshold(const UI32_T unit, UI32_T *threshold);

/**
 * @brief This API is used to update the tad mode for a local interface
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     plane_id    - Plane ID
 * @param [in]     lcl_intf    - Local interface
 * @param [in]     tag_mode    - tag mode
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_updateIntfTagMode(const UI32_T unit,
                              const UI32_T plane_id,
                              const UI32_T lcl_intf,
                              const UI32_T tag_mode);

/**
 * @brief Set Mburst property.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     property    - Property type
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setMburstProperty(const UI32_T unit,
                              const UI32_T port,
                              const CLX_PORT_MBURST_PROPERTY_T *property);

/**
 * @brief Get Mburst property.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     property    - Property type
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getMburstProperty(const UI32_T unit,
                              const UI32_T port,
                              CLX_PORT_MBURST_PROPERTY_T *property);

/**
 * @brief get mburst statistic
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Physical port ID
 * @param [in]     dir          - Direction
 * @param [out]    ptr_stat     - mburst stat
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getMburstStat(const UI32_T unit,
                          const UI32_T port,
                          const CLX_DIR_T dir,
                          CLX_PORT_MBURST_STAT_T *ptr_stat);

/**
 * @brief get Mburst Histogram threshold.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     dir         - IPL or EPL
 * @param [in]     thrd_num    - Threshold num
 * @param [out]    ptr_count   - Mburst Histogram count
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getMburstHistCnt(const UI32_T unit,
                             const UI32_T port,
                             const CLX_DIR_T dir,
                             const UI32_T thrd_num,
                             UI32_T *ptr_count);

/**
 * @brief clear Mburst count.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port ID
 * @param [in]     dir     - IPL or EPL
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_clearMburstCnt(const UI32_T unit, const UI32_T port, const CLX_DIR_T dir);

/**
 * @brief Get capacity of port-related resource
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Resource type
 * @param [in]     param       - Parameter if necessary
 * @param [out]    ptr_size    - Size of capacity
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getCapacity(const UI32_T unit,
                        const CLX_SWC_RSRC_T type,
                        const UI32_T param,
                        UI32_T *ptr_size);

/**
 * @brief Get usage of port-related resource.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - Resource type
 * @param [in]     param      - Parameter if necessary
 * @param [out]    ptr_cnt    - Count of usage
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getUsage(const UI32_T unit,
                     const CLX_SWC_RSRC_T type,
                     const UI32_T param,
                     UI32_T *ptr_cnt);

/**
 * @brief Set phy prbs error inject.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port ID
 * @param [in]     num_err    - Parameter if necessary
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setPrbsErrInject(const UI32_T unit, const UI32_T port, const UI32_T num_err);

/**
 * @brief set port prbs error bits clear.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     lane_bmp    - lane bitmap
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setPrbsErrCntClear(const UI32_T unit, const UI32_T port, const UI32_T lane_bmp);

/**
 * @brief Get phy firmware version.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     port               - Physical port ID
 * @param [out]    ptr_version_eth    - Eth phy firmware version
 * @param [out]    ptr_version_cpi    - Cpi phy firmware version
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getPhyFwVersion(const UI32_T unit,
                            const UI32_T port,
                            UI32_T *ptr_version_eth,
                            UI32_T *ptr_version_cpi);

/**
 * @brief Get phy rate code.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [out]    pma_rate    - Phy rate code:
 *                               0: 10P3125
 *                               1: 25P78125
 *                               2: 26P5625
 *                               3: 53P125_NRZ
 *                               4: 53P125_PAM4
 *                               5: 56P25_PAM4
 *                               6: 106P25
 *                               7: 112P5
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getPhyRate(const UI32_T unit, const UI32_T port, UI32_T *pma_rate);

/**
 * @brief set phy to isolation mode.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     lane_bmp    - lane bitmap
 * @param [in]     enable      - enable/disable isolation mode
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setPhyIsolaMode(const UI32_T unit,
                            const UI32_T port,
                            const UI32_T lane_bmp,
                            const UI32_T enable);

/**
 * @brief set phy tx or rx powerup.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port          - Physical port ID
 * @param [in]     lane_bmp      - lane bitmap
 * @param [in]     module        - tx or rx
 * @param [in]     lane_speed    - serdes lane speed
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setPhyTxRxPowerup(const UI32_T unit,
                              const UI32_T port,
                              const UI32_T lane_bmp,
                              const CLX_PORT_PROPERTY_T module,
                              const CLX_PORT_LANE_SPEED_T lane_speed);

/**
 * @brief set phy tx elecidle.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     enable      - enable or disable
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setPhyTxElecidle(const UI32_T unit, const UI32_T port, const UI32_T enable);

/**
 * @brief get phy tx elecidle.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     port          - Physical port ID
 * @param [out]    ptr_enable    - phy tx elecidle
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getPhyTxElecidle(const UI32_T unit, const UI32_T port, UI32_T *ptr_enable);

/**
 * @brief set phy rx termination mode.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     lane_bmp    - lane bitmap
 * @param [in]     mode        - termination mode
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setPhyRxTermination(const UI32_T unit,
                                const UI32_T port,
                                const UI32_T lane_bmp,
                                const CLX_PORT_ACC_TERM_MODE_T mode);

/**
 * @brief get phy rx termination mode.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [out]    ptr_mode    - phy rx termination mode
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getPhyRxTermination(const UI32_T unit, const UI32_T port, UI32_T *ptr_mode);

/**
 * @brief get phy Atest or Pmon data.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     lane_bmp    - lane bitmap
 * @param [in]     mode        - atest mode
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getPhyAtestPmon(const UI32_T unit,
                            const UI32_T port,
                            const UI32_T lane_bmp,
                            const UI32_T mode);

/**
 * @brief get phy rx snr.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port ID
 * @param [in]     iir_alpha   - IIR fiter alpha value - 0p10 format
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_getPhyRxSnr(const UI32_T unit, const UI32_T port, const UI32_T iir_alpha);
/**
 * @brief set port ptp mode.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     port                  - Physical port ID
 * @param [in]     ptp_sync_mode_step    - ptp sync mode and sync step
 * @param [in]     mode                  - ptp mode
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_port_setPtpMode(const UI32_T unit,
                       const UI32_T port,
                       const UI32_T ptp_sync_mode_step,
                       const UI32_T mode);

/**
 * @brief This API is used to set the egress TPID0 as TPID1 value for RSPAN port
 *
 * Called by mirror module
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port             - Port Number
 * @param [in]     is_rspan_port    - Port is RSPAN port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_port_setEgrPortTpidForRspan(const UI32_T unit,
                                   const UI32_T port,
                                   const BOOL_T is_rspan_port);

CLX_ERROR_NO_T
hal_mt_port_updateLaneCnt(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_port_updateMacConfig(UI32_T unit, UI32_T port, UI32_T an_speed, UI32_T an_fec);
#endif /* #ifndef HAL_MT_PORT_H */
