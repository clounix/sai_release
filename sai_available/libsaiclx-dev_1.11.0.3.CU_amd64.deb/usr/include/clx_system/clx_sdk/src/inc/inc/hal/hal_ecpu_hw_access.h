/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecpu_hw_access.h
 * PURPOSE:
 *    Provide elink adaptation related hook functions.
 *
 * NOTES:
 *
 */

#ifndef HAL_ECPU_HW_ACCESS_H
#define HAL_ECPU_HW_ACCESS_H

/* INCLUDE FILE DECLARATIONS
 */
#include "stddef.h"

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef CLX_ERROR_NO_T (*HAL_ECPU_HW_INIT_FUNC_T)(void);
typedef CLX_ERROR_NO_T (*HAL_ECPU_HW_DEINIT_FUNC_T)(void);
typedef CLX_ERROR_NO_T (*HAL_ECPU_GET_SHARED_MEM_INFO_FUNC_T)(UI32_T *addr,
                                                              UI32_T *offset,
                                                              UI32_T *);
typedef CLX_ERROR_NO_T (*HAL_ECPU_MEM_SYNC_FUNC_T)(const void *addr, const UI32_T len);
typedef CLX_ERROR_NO_T (*HAL_ECPU_ISSUE_INTR_TO_ECPU_FUNC_T)(const UI32_T unit);
typedef CLX_ERROR_NO_T (*HAL_ECPU_CLEAR_INTR_FROM_ECPU_FUNC_T)(const UI32_T unit);
typedef CLX_ERROR_NO_T (*HAL_ECPU_ENABLE_INTR_FROM_ECPU_FUNC_T)(const UI32_T unit);

typedef struct {
    HAL_ECPU_HW_INIT_FUNC_T init;                            /* initialie the hw related part  */
    HAL_ECPU_HW_DEINIT_FUNC_T deinit;                        /* deinitialie the hw related part  */
    HAL_ECPU_GET_SHARED_MEM_INFO_FUNC_T get_shared_mem_info; /*return the shared memory info*/
    HAL_ECPU_MEM_SYNC_FUNC_T mem_sync;               /* sync memory between ecpu and host cpu */
    HAL_ECPU_ISSUE_INTR_TO_ECPU_FUNC_T issue_intr;   /* generate an interrupt to eCPU  */
    HAL_ECPU_CLEAR_INTR_FROM_ECPU_FUNC_T clear_intr; /* clear interrupt from eCPU */
    HAL_ECPU_ENABLE_INTR_FROM_ECPU_FUNC_T enable_intr;
} HAL_ECPU_HW_ACCESS_HANDLE_T;

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to register the impl into API layer, please note that the parameter should keep availablity
 * during the code runtime, in another word, stack variable is not accepted, you should use a global
 * variable for that.
 *
 *
 * @param [in]     ecpu_hw_access_impl         - readonly pointer to struct HAL_ECPU_HW_ACCESS_HANDLE_T
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ecpu_regHw(const HAL_ECPU_HW_ACCESS_HANDLE_T *ecpu_hw_access_impl);

/**
 * @brief This API is used to initialize the hardware related functions. If there is no hw related component needs to
 * initialize, we can put this function as a stub function.
 *
 *
 * @param [in]     void   - void
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_NOT_INITED       - Error happens, the impl will porvides more detail.
 */
CLX_ERROR_NO_T
hal_ecpu_hwInit(void);

/**
 * @brief This API is used to deinitialize the hardware related functions.
 *
 *
 * @param [in]     void - void
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_NOT_INITED       - Error happens, the impl will porvides more detail.
 */
CLX_ERROR_NO_T
hal_ecpu_hwDeinit(void);

/**
 * @brief This API is used to return the shared memory info in the purpose of communication bwtween eCPU and host CPU.
 * The shared memory includes the tx and rx shared memory, the upper layer code should be resonsible
 * for manage the control part, data part etc.
 *
 *
 * @param [in]      address               - An output parameter to carry out the address.
 * @param [in]      offset                - Offset of the address.
 * @param [in]      size                  - The size of the memory region.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
CLX_ERROR_NO_T
hal_ecpu_getSharedMemInfo(UI32_T *address, UI32_T *offset, UI32_T *size);

/**
 * @brief This API is used to issue an itnerrupt to eCPU.
 *
 *
 * @param [in]     unit         - Device unit number.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
CLX_ERROR_NO_T
hal_ecpu_issueIntrToeCPU(const UI32_T unit);

/**
 * @brief This API is used to clear the interrupt from eCPU.
 *
 *
 * @param [in]     unit         - Device unit number.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
CLX_ERROR_NO_T
hal_ecpu_clearIntrFromeCPU(const UI32_T unit);

/**
 * @brief This API is used to enable the interrupt from eCPU.
 *
 *
 * @param [in]     unit         - Device unit number.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
CLX_ERROR_NO_T
hal_ecpu_enableIntrFromeCPU(const UI32_T unit);

/**
 * @brief This API is used to trigger message sync.
 *
 *
 * @param [in]     addr         - Address pointer.
 * @param [in]     len          - The length of memory that needs to be synchronized.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
CLX_ERROR_NO_T
hal_ecpu_memSync(const void *addr, const UI32_T len);

#endif
