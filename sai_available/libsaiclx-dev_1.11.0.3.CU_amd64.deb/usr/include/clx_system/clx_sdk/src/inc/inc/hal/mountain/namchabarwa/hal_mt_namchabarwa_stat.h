/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_NAMCHABARWA_STAT_H
#define HAL_MT_NAMCHABARWA_STAT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stat.h>
#include <clx_tm.h>
#include <dcc/dcc_dma.h>
#include <hal/hal_cmn.h>
#include <hal/hal_cmn_drv.h>
#include <hal/hal_stat.h>
#include <hal/hal_sec.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_cmn.h>

/* #define HAL_MT_NAMCHABARWA_STAT_USE_CLD_DMA */
/* #define HAL_MT_NAMCHABARWA_STAT_EN_RSFEC_CNT */

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NAMCHABARWA_STAT_MIB_SRAM_LANE_IDX_OFFSET (128)
#define HAL_MT_NAMCHABARWA_STAT_SRV_CNT_IDX_OFFSET       (10)
#define HAL_MT_NAMCHABARWA_STAT_SRV_CNT_NUM_PER_BANK \
    ((1U << HAL_MT_NAMCHABARWA_STAT_SRV_CNT_IDX_OFFSET) * 6)
#define HAL_MT_NAMCHABARWA_STAT_SRV_CNT_IDX_SEL_OFFSET    (3)
#define HAL_MT_NAMCHABARWA_STAT_SRV_CNT_BANK_NUM          (16)
#define HAL_MT_NAMCHABARWA_STAT_DST_CNT_NUM_PER_BANK      (256)
#define HAL_MT_NAMCHABARWA_STAT_DST_CNT_BANK_NUM          (4)
#define HAL_MT_NAMCHABARWA_STAT_TM_IOS_CNT_SUBINST_OFFSET (108)
#define HAL_MT_NAMCHABARWA_STAT_TM_IOS_CNT_PLANE_OFFSET \
    (HAL_MT_NAMCHABARWA_STAT_TM_IOS_CNT_SUBINST_OFFSET * 4)
#define HAL_MT_NAMCHABARWA_STAT_TM_TMI_CNT_TYPE_OFFSET (34)
#define HAL_MT_NAMCHABARWA_STAT_TM_TMI_CNT_PLANE_OFFSET \
    (HAL_MT_NAMCHABARWA_STAT_TM_TMI_CNT_TYPE_OFFSET * 7)
#define HAL_MT_NAMCHABARWA_STAT_TM_ENB_CNT_TYPE_OFFSET (34)
#define HAL_MT_NAMCHABARWA_STAT_TM_ENB_CNT_PLANE_OFFSET \
    (HAL_MT_NAMCHABARWA_STAT_TM_ENB_CNT_TYPE_OFFSET * 12)
#define HAL_MT_NAMCHABARWA_STAT_TM_CMS_CNT_BIN_OFFSET     (89 * 4)
#define HAL_MT_NAMCHABARWA_STAT_TM_ADM_CNT_PLANE_OFFSET   (396 * 4)
#define HAL_MT_NAMCHABARWA_STAT_TM_DEB_CNT_PLANE_OFFSET   (34)
#define HAL_MT_NAMCHABARWA_STAT_TM_EPM_CNT_PLANE_OFFSET   (34 * 2)
#define HAL_MT_NAMCHABARWA_STAT_TM_ADM_CMS_CNT_CPI_OFFSET (48)
#define HAL_MT_NAMCHABARWA_STAT_EXCPT_CNT_PLANE_OFFSET    (33)
#define HAL_MT_NAMCHABARWA_STAT_EXCPT_CNT_TYPE_NUM_IGR    (260)
#define HAL_MT_NAMCHABARWA_STAT_EXCPT_CNT_TYPE_NUM_EGR    (69)
#define HAL_MT_NAMCHABARWA_STAT_EXCPT_CNT_BMP_WORD_IGR \
    (((HAL_MT_NAMCHABARWA_STAT_EXCPT_CNT_TYPE_NUM_IGR - 1) / 32) + 1)
#define HAL_MT_NAMCHABARWA_STAT_EXCPT_CNT_BMP_WORD_EGR \
    (((HAL_MT_NAMCHABARWA_STAT_EXCPT_CNT_TYPE_NUM_EGR - 1) / 32) + 1)
#define HAL_MT_NAMCHABARWA_STAT_DIE_NUM                      (4)
#define HAL_MT_NAMCHABARWA_STAT_MAC_NUM_PER_DIE              (8)
#define HAL_MT_NAMCHABARWA_STAT_LANE_NUM_PER_MAC             (8)
#define HAL_MT_NAMCHABARWA_STAT_ETHL_LANE_NUM                (256)
#define HAL_MT_NAMCHABARWA_STAT_ETHX_LANE_NUM                (2)
#define HAL_MT_NAMCHABARWA_STAT_CPU_LANE_NUM                 (1)
#define HAL_MT_NAMCHABARWA_STAT_TM_QUEUECNT_NUM_PER_PLANE    (576)
#define HAL_MT_NAMCHABARWA_STAT_TM_CPU_QUEUE_NUM             (48)
#define HAL_MT_NAMCHABARWA_STAT_TM_CPI_QUEUE_NUM             (16)
#define HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_ID_IGR_PARITY_DROP  (9)
#define HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_ID_L3_IGR_BLACKHOLE (10)
#define HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_ID_L3_IGR_DROP      (11)
#define HAL_MT_NAMCHABARWA_STAT_MAX_TOLORENCE_INTERVAL       (1350000)
#define HAL_MT_NAMCHABARWA_STAT_DEFAULT_POLLING_INTERVAL_MS  (500)
#define HAL_MT_NAMCHABARWA_STAT_MIN_POLLING_INTERVAL_MS      (250)
#define HAL_MT_NAMCHABARWA_STAT_MAX_POLLING_INTERVAL_MS      (1000)
#define HAL_MT_NAMCHABARWA_STAT_RSFEC_DEFAULT_UPDATE_INTVL   (1000000)
/* single-die all rsfec-cerr counter update time estimate is around 1500us, \
 * limit interval to be the safe side for suppporting 4-die */
#define HAL_MT_NAMCHABARWA_STAT_RSFEC_MIN_UPDATE_INTVL (10000)

#define HAL_MT_NAMCHABARWA_STAT_CFG_SAI_STAT_BANK0           (0)
#define HAL_MT_NAMCHABARWA_STAT_CFG_SAI_STAT_BANK1           (1)
#define HAL_MT_NAMCHABARWA_STAT_OQ_DROP_ECN_CNT_NUM          (4)
#define HAL_MT_NAMCHABARWA_STAT_SQ_NUM_PER_PLANE             (328)
#define HAL_MT_NAMCHABARWA_STAT_SQ_NUM_PER_PORT              (8)
#define HAL_MT_NAMCHABARWA_STAT_GET_SQ_ID(ppid, id)          (((ppid) << 3) + (id))
#define HAL_MT_NAMCHABARWA_STAT_PP_HEADER_LEN                (40)
#define HAL_MT_NAMCHABARWA_STAT_PL_FLAGS_MAC                 (1U << 0)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_TDS                 (1U << 1)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_DIS                 (1U << 2)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_FPU                 (1U << 3)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_ICIA                (1U << 4)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_FWR                 (1U << 5)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_TM                  (1U << 6)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_RWI                 (1U << 7)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_ECIA                (1U << 8)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_RWO                 (1U << 9)
#define HAL_MT_NAMCHABARWA_STAT_PP_FLAGS_ALL                 (0x1FF)
#define HAL_MT_NAMCHABARWA_TBL_CNT_RSLT_xPORT_ENTRY_NUM      (240)
#define HAL_MT_NAMCHABARWA_STAT_CNT_RSN_GRP0_xPORT_ENTRY_NUM (40)
#define HAL_MT_NAMCHABARWA_STAT_CNT_RSN_GRP0_ID              (0x7)
#define HAL_MT_NAMCHABARWA_STAT_CNT_RSN_GRP0_VALID           (0x1)

#define HAL_MT_NAMCHABARWA_STAT_UPDATE_TM_CNT(dst, src, clear) \
    do {                                                       \
        if (clear) {                                           \
            UI64_SET(src, _hal_mt_namchabarwa_stat_ui64_zero); \
        } else {                                               \
            dst += src;                                        \
        }                                                      \
    } while (0)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_MT_NAMCHABARWA_STAT_RSFEC_LOCK(__unit__) \
    osal_takeSemaphore(&(_hal_stat_rsfec_cb[__unit__].sema), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_NAMCHABARWA_STAT_RSFEC_UNLOCK(__unit__) \
    osal_giveSemaphore(&(_hal_stat_rsfec_cb[__unit__].sema))

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITOK = 0,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITALL,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITERROR,
    HAL_MT_NAMCHABARWA_STAT_MIB_OCTETSXMITOK,
    HAL_MT_NAMCHABARWA_STAT_MIB_OCTETSXMITALL,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITUNICAST,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITMULTICAST,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITBROADCAST,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPAUSE,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRIPAUSE,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITVLAN,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZELT64,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZEEQ64,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZE65TO127,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZE128TO255,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZE256TO511,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZE512TO1023 = 16,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZE1024TO1518,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZE1519TO2047,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZE2048TO4095,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZE4096TO8191,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESSMITSIZE8912TO9215,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITSIZEGT9216,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRI0,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRI1,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRI2,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRI3,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRI4,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRI5,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRI6,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPRI7,
    HAL_MT_NAMCHABARWA_STAT_MIB_XMITPRI0PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_XMITPRI1PAUSE1US = 32,
    HAL_MT_NAMCHABARWA_STAT_MIB_XMITPRI2PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_XMITPRI3PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_XMITPRI4PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_XMITPRI5PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_XMITPRI6PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_XMITPRI7PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITDRAINED,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITJABBERED,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITPADDED,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESXMITTRUNCATED,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDOK,
    HAL_MT_NAMCHABARWA_STAT_MIB_OCTECTSRCVDOK,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDALL,
    HAL_MT_NAMCHABARWA_STAT_MIB_OCTECTSRCVDALL,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDCRCERROR,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDERROR = 48,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDUNICAST,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDMULTICAST,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDBROADCAST,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPAUSE,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDLENERROR,
    HAL_MT_NAMCHABARWA_STAT_MIB_RESERVED0,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDOVERSIZED,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDFRAGMENTS,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDJABBER,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRIPAUSE,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDCRCERRSTOMP,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDMAXFRMSIZEVIO,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDVLAN,
    HAL_MT_NAMCHABARWA_STAT_MIB_RESERVED1,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZELT64,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZEEQ64 = 64,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE65TO127,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE128TO255,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE256TO511,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE512TO1023,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE1024TO1518,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE1419TO2047,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE2048TO4095,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE4096TO8191,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZE8912TO9215,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDSIZEGT9216,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRI0,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRI1,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRI2,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRI3,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRI4,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRI5 = 80,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRI6,
    HAL_MT_NAMCHABARWA_STAT_MIB_FRAMESRCVDPRI7,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDPRI0PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDPRI1PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDPRI2PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDPRI3PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDPRI4PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDPRI5PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDPRI6PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDPRI7PAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RCVDSTDPAUSE1US,
    HAL_MT_NAMCHABARWA_STAT_MIB_RESERVED2,
    HAL_MT_NAMCHABARWA_STAT_MIB_RESERVED3,
    HAL_MT_NAMCHABARWA_STAT_MIB_INVALIDPREAMBLE,
    HAL_MT_NAMCHABARWA_STAT_MIB_NORMALLENINVALIDCRC,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_BER_ERROR_COUNTER = 96,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_ERRORED_BLOCKS_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_VALID_ERRORED_BLOCK_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_UNKNOWN_ERRORED_BLOCK_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_INVALID_ERRORED_BLOCK_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_TEST_PATTERN_ERRORS_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_RESERVED4,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_BLOCK_LOCK_LOSS_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_HIBER_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_RESERVED5,
    HAL_MT_NAMCHABARWA_STAT_MIB_RESERVED6,
    HAL_MT_NAMCHABARWA_STAT_MIB_RSFEC_COUNTERED_CODEWORDS,
    HAL_MT_NAMCHABARWA_STAT_MIB_RSFEC_UNCOTTECTED_CODEWORDS,
    HAL_MT_NAMCHABARWA_STAT_MIB_RSFEC_CH_SYMBOL_ERROR_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_HSMC_PCS_LANE_BIP_N_ERRORS_COUNTER,
    HAL_MT_NAMCHABARWA_STAT_MIB_FCFEC_LANE_N_CORRECTED_CODEWORDS,
    HAL_MT_NAMCHABARWA_STAT_MIB_FCFEC_LANE_N_UNCORRECTED_CODEWORDS = 112,
    HAL_MT_NAMCHABARWA_STAT_MIB_RSFEC_LANE_N_SYMBOL_ERRORS,
    HAL_MT_NAMCHABARWA_STAT_MIB_SRAM_TYPE_LAST
} HAL_MT_NAMCHABARWA_STAT_MIB_SRAM_TYPE_T;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV4_UC = 0,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV4_MC,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV4_RECV,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV4_INVALID_HEADER,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV4_INVALID_ADDR,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV4_DROP,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV6_UC,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV6_MC,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV6_RECV,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV6_INVALID_HEADER,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV6_INVALID_ADDR,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_IPV6_DROP,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_TAGGED,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_UNTAGGED,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_L3_DROP,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_ACL_DROP,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_ICC_DROP,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_ACL_DROP_CPU,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_ERR_DROP,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_DI_RANGE_CNT0,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_DI_RANGE_CNT1,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_DI_RANGE_CNT2,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_DI_RANGE_CNT3,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_DI_RANGE_CNT4,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_DI_RANGE_CNT5,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_DI_RANGE_CNT6,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_DI_RANGE_CNT7,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_EXCPT_CNT0,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_EXCPT_CNT1,
    HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_LAST
} HAL_MT_NAMCHABARWA_STAT_FLEX_CNT_IGR_TYPE_T;

typedef struct HAL_MT_NAMCHABARWA_STAT_RSFEC_TASK_S {
    UI32_T inst_idx;
    UI32_T subinst_idx;
    UI32_T entry_idx;
} HAL_MT_NAMCHABARWA_STAT_RSFEC_TASK_T;

typedef struct HAL_MT_NAMCHABARWA_STAT_RSFEC_CB_S {
    UI64_T *ptr_results;
    UI32_T task_cnt;
    UI32_T *ptr_tasks_id;
    HAL_MT_NAMCHABARWA_STAT_RSFEC_TASK_T *ptr_tasks;
    CLX_SEMAPHORE_ID_T sema;
    CLX_THREAD_ID_T update_thread_id;
    UI32_T sleep_intvl;
} HAL_MT_NAMCHABARWA_STAT_RSFEC_CB_T;

typedef struct HAL_MT_NAMCHABARWA_STAT_OQ_DROP_CNT_INFO_S {
    HAL_STAT_HW_TYPE_T hw_cnt_type;
    UI32_T table_id;
} HAL_MT_NAMCHABARWA_STAT_OQ_DROP_CNT_INFO_T;
/* dbg analyze stat */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE_UC = 0,
    HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE_MC,
    HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE_IGR_MIR,
    HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE_EGR_MIR,
    HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE_EGR_EXP_CPU,
    HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE_EGR_CPY_CPU,
    HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE_LAST
} HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_MAC_RX,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_MAC_TX,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_PDMA_RX,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_PDMA_TX,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_IPM,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_IOS,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_IOS_LBS,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_IPP,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_XBN,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_TM,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_EPP,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_EPM,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_EPM_LBK,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_LAST
} HAL_MT_NAMCHABARWA_STAT_DBG_STAGE;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_RESULT_OK,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_RESULT_DROP,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_RESULT_ERROR,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_RESULT_NONE,
    HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_RESULT_LAST
} HAL_MT_NAMCHABARWA_STAT_DBG_STAGE_RESULT;

/* dbg analyze stat - mac */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_MAC_RX,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_MAC_TX,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_MAC_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_MAC;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_US_GOOD,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_US_BAD,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_OS_GOOD,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_OS_BAD,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_SYMBOL_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_RS_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_STOMP_CRC_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_CRC_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_UNK_OPC,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_LENG_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_RX_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_TX_US_GOOD,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_TX_US_BAD,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_TX_OS_GOOD,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_TX_OS_BAD,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_TX_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_TX_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_MAC;

/* dbg analyze stat - ipm */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IPM_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IPM_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IPM_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IPM;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPM_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPM_MERGE_DROP, /* default */
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPM_PORT_DISABLE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPM_SHORT_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPM_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPM;

/* dbg analyze stat - ios */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IOS_BUF,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IOS_LBS_BUF,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IOS_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IOS;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS_TRUNC,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS_BUF_NONEMPTY,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS_LBS_BUF_FULL_TRUNC,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS_LBS_NORMAL_TRUNC,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS_LBS_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS_LBS_BUF_NONEMPTY,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IOS;

/* dbg analyze stat - ipp */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IPP_EXCPT,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IPP_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_IPP;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPP_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPP_EXCEPT,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPP_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_IPP;

/* dbg analyze stat - xbn */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_XBN_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_XBN;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_XBN_IPID_INVALID,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_XBN_LG_LB_NO_BIN,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_XBN_LG_AB_NO_BIN,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_XBN_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_XBN;

/* dbg analyze stat - tm */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_TM_DROP_EN_IGR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_TM_DROP_EN_EGR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_TM_TX_BLOCK,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_TM_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_TM;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_TMI_SOP_IPP_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_TMI_SINGLE_CELL_MISSING_EOP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_TMI_RAW_PBM_ZERO,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_TMI_PROTOCOL_ERR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_ENB_BUF_FULL_TRUNCATE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_ENB_IPP_ERR_TRUNCATE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_ENB_UNDERBOOK_TRUNCATE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_ADM_FAIL,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_TX_DISABLE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_RX_DISABLE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_RXTX_DISABLE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_DEB_BLOCK,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_EPM_BLOCK,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_MAC_TX_NONEMPTY,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_TX_BLOCK,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_TM;

/* dbg analyze stat - epp */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_EPP_EXCPT,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_EPP_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_EPP;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPP_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPP_EXCEPT,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPP_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPP;

/* dbg analyze stat - epm */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_EPM_BUF,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_EPM_BUF_LBK,
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_EPM_LAST,
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_EPM;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPM_ERROR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPM_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPM_LBK_ERROR,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPM_LBK_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPM_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_EPM;

/* dbg analyze stat - pdma */
typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_PDMA_LAST,
} HAL_MT_NAMCHABARWA_STAT_STAGE_ANALYZE_TYPE_PDMA;

typedef enum {
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_PDMA_RX_DROP,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_PDMA_TX_UNDERSIZE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_PDMA_TX_OVERSIZE,
    HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_PDMA_LAST
} HAL_MT_NAMCHABARWA_STAT_STAGE_REASON_PDMA;

typedef CLX_ERROR_NO_T (*HAL_STAT_DBG_STAGE_RULE_FUNC_T)(
    const UI32_T unit,
    const UI32_T input_port,
    const UI32_T output_port,
    const UI32_T lbk_dst_port,
    const HAL_MT_NAMCHABARWA_STAT_DBG_STAGE stage,
    const HAL_MT_NAMCHABARWA_STAT_DBG_ANALYZE_TYPE type,
    const UI64_T in_cnt,
    UI64_T *ptr_out_cnt);

typedef CLX_ERROR_NO_T (*HAL_STAT_DBG_STAGE_SNAKE_RULE_FUNC_T)(
    const UI32_T unit,
    const UI32_T input_port,
    const UI32_T output_port,
    const HAL_MT_NAMCHABARWA_STAT_DBG_STAGE stage,
    const UI32_T first_port,
    UI64_T *ptr_in_cnt,
    UI64_T *ptr_out_cnt,
    UI32_T *ptr_stop);

typedef CLX_ERROR_NO_T (*HAL_STAT_DBG_STAGE_ANALYSIS_FUNC_T)(const UI32_T unit,
                                                             const UI32_T port,
                                                             const UI32_T stage_analysis_type,
                                                             const UI64_T cnt,
                                                             UI32_T *ptr_flags);

typedef struct HAL_STAT_DBG_STAGE_INFO_S {
    HAL_STAT_DBG_STAGE_RULE_FUNC_T rule_func;
    HAL_STAT_DBG_STAGE_SNAKE_RULE_FUNC_T snake_rule_func;
    C8_T **ptr_reason;
    HAL_STAT_DBG_STAGE_ANALYSIS_FUNC_T analysis_func;
} HAL_STAT_DBG_STAGE_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init stat module control blocks.
 *
 * @param [in]     unit    - device unit number
 * @return         CLX_E_OK               - init success.
 * @return         CLX_E_NO_MEMORY        - allocate control block failed
 * @return         CLX_E_OTHERS           - init fail
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_init(const UI32_T unit);

/**
 * @brief Deinit stat module control blocks and free resource.
 *
 * @param [in]     unit    - device unit number
 * @return         CLX_E_OK               - deinit success
 * @return         CLX_E_OTHERS           - deInit fail
 * @return         CLX_E_BAD_PARAMETER    - parameter invalid
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_deinit(const UI32_T unit);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @param [out]    ptr_cnt    - Counter value
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getTmCnt(const UI32_T unit,
                                 const UI32_T port,
                                 const CLX_TM_HANDLER_T handler,
                                 const CLX_STAT_TM_CNT_TYPE_T type,
                                 CLX_STAT_TM_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearTmCnt(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_TM_HANDLER_T handler,
                                   const CLX_STAT_TM_CNT_TYPE_T type);

/**
 * @brief This API is used to clear oq drop or ecn counter by port, queue.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearTmSaiOqCnt(const UI32_T unit,
                                        const UI32_T port,
                                        const CLX_TM_HANDLER_T handler);

/**
 * @brief This API is used to get a distribution counter.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - Counter
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getDistCnt(const UI32_T unit,
                                   const UI32_T cnt_id,
                                   CLX_STAT_DIST_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear a distribution counter.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearDistCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get PP counter SW ID using HW index
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     hw_cnt_idx       - HW counter idx in HW table
 * @param [in]     cnt_type         - counter type
 * @param [out]    ptr_sw_cnt_id    - HW counter id
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getCntSWId(const UI32_T unit,
                                   const UI32_T hw_cnt_idx,
                                   const HAL_STAT_HW_TYPE_T cnt_type,
                                   UI32_T *ptr_sw_cnt_id);

/**
 * @brief This API is used to get port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @param [out]    ptr_cnt     - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getMibRaw(const UI32_T unit,
                                  const UI32_T port,
                                  const HAL_STAT_HW_TYPE_T hw_type,
                                  const HAL_MT_NAMCHABARWA_STAT_MIB_SRAM_TYPE_T cnt_type,
                                  UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX
 * @param [in]     cnt_type    - The type of counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearMibRaw(const UI32_T unit,
                                    const UI32_T port,
                                    const HAL_STAT_HW_TYPE_T hw_type,
                                    const HAL_MT_NAMCHABARWA_STAT_MIB_SRAM_TYPE_T cnt_type);

/**
 * @brief This API is used to get TM raw counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     inst_idx     - Instance index
 * @param [in]     sub_idx      - Sub-instance index
 * @param [in]     type         - TM counter type
 * @param [in]     entry_idx    - Entry index
 * @param [in]     field_id     - Counter index of the corresponding field
 * @param [out]    ptr_cnt      - Pointer to counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getTmRaw(const UI32_T unit,
                                 const UI32_T inst_idx,
                                 const UI32_T sub_idx,
                                 const HAL_STAT_HW_TYPE_T type,
                                 const UI32_T entry_idx,
                                 const UI32_T field_id,
                                 UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     inst_idx     - Instance index
 * @param [in]     sub_idx      - Sub-instance index
 * @param [in]     type         - TM counter type
 * @param [in]     entry_idx    - Entry index
 * @param [in]     field_id     - Counter index of the corresponding field
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearTmRaw(const UI32_T unit,
                                   const UI32_T inst_idx,
                                   const UI32_T sub_idx,
                                   const HAL_STAT_HW_TYPE_T type,
                                   const UI32_T entry_idx,
                                   const UI32_T field_id);

/**
 * @brief This API is used to get how many times the counter has been updated
 *
 * @param [in]     unit       - Device unit number
 * @param [out]    ptr_cnt    - Update count
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getUpdateCnt(const UI32_T unit, UI64_T *ptr_cnt);

/**
 * @brief This API is used to get PP exception counter by port
 *
 * It's caller's responsibility to pass an bitmap of correct size.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     dir           - Ingress or egress
 * @param [in]     port          - Physical port
 * @param [out]    excpt_bmap    - Exception state: bitmap for occurance indication
 * @param [out]    ptr_cnt       - Pointer to counter value
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getExcptCnt(const UI32_T unit,
                                    const CLX_DIR_T dir,
                                    const UI32_T port,
                                    UI32_T *excpt_bmap,
                                    UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear PP exception counter by port
 *
 * This API will clear both counter and exception state.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     dir     - Ingress or egress
 * @param [in]     port    - Physical port
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearExcptCnt(const UI32_T unit, const CLX_DIR_T dir, const UI32_T port);

/**
 * @brief This API is used to get PP storm control counter by index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     plane      - Plane number
 * @param [in]     cnt_idx    - The strom control counter index
 * @param [out]    ptr_cnt    - Pointer to corresponding counter entry (3 values)
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getStormCnt(const UI32_T unit,
                                    const UI32_T plane,
                                    const UI32_T cnt_idx,
                                    HAL_SEC_SCCOUNTER_ENTRY_T *ptr_cnt);

/**
 * @brief This API is used to clear PP storm control counter by index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     plane      - Plane number
 * @param [in]     cnt_idx    - The strom control counter index
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearStormCnt(const UI32_T unit, const UI32_T plane, const UI32_T cnt_idx);

/**
 * @brief This API is used to show debug counter
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - CLX port number
 * @param [in]     stage_bmp    - The bitmap of stage:
 *                                bit0: mac; bit1: ipm; bit2: ios: bit3: ipp; bit4: xbn; bit5: tm;
 *                                bit6: epp; bit7: epm; bit8: lbm
 * @param [in]     flags        - Show the counter or not if it is zero
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_showDbgCnt(const UI32_T unit,
                                   const UI32_T port,
                                   const UI32_T stage_bmp,
                                   const UI32_T flags);

/**
 * @brief This API is used to clear all debug counter
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearDbgCnt(const UI32_T unit);

/**
 * @brief This API is used to trigger manually counter update to get latest counter value.
 *
 * The API takes time to collect latest counter please use it wisely.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK             - Success.
 * @return         CLX_E_NOT_SUPPORT    - Not support in current mode
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_refreshCnt(const UI32_T unit);

/**
 * @brief This API is used to set RS-FEC error distribution counter polling interval.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     interval    - polling interval (unit: microsecond)
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_setRsErrDistCntInterval(const UI32_T unit, const UI32_T interval);

/**
 * @brief This API is used to get PP counter HW index using SW index
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     sw_cnt_id         - SW counter id
 * @param [in]     cnt_type          - counter type
 * @param [in]     pp_obj_type       - PP binding object type
 * @param [out]    ptr_hw_cnt_idx    - HW counter idx
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_TABLE_FULL         - No available HW resource
 * @return         CLX_E_ENTRY_NOT_FOUND    - The SW counter has not been created.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getCntHWIdx(const UI32_T unit,
                                    const UI32_T sw_cnt_id,
                                    const HAL_STAT_HW_TYPE_T cnt_type,
                                    const HAL_STAT_PP_OBJ_TYPE_T pp_obj_type,
                                    UI32_T *ptr_hw_cnt_idx);

/**
 * @brief To get a PP HW counter bank Id and corresponding index Id
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     hw_cnt_id                  - HW counter Id
 * @param [in]     mode                       - Counter mode
 * @param [out]    ptr_bank_id                - The HW bank Id of the corresponding counter
 * @param [out]    ptr_sw_bmap_idx_of_bank    - The index the corresponding counter in the bank
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getPpBankId(const UI32_T unit,
                                    const UI32_T hw_cnt_id,
                                    const CLX_STAT_CNT_MODE_T mode,
                                    UI32_T *ptr_bank_id,
                                    UI32_T *ptr_sw_bmap_idx_of_bank);

/**
 * @brief This API is used to get value of the counter under study
 *
 * The number of counters value return is determined by the type of counter under study.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - The return counter values
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getCnt(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @param [out]    ptr_cnt           - The return counter values
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getReasonCnt(const UI32_T unit,
                                     const CLX_PKT_RX_REASON_T rx_reason_code,
                                     UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_clearReasonCnt(const UI32_T unit, const CLX_PKT_RX_REASON_T rx_reason_code);

/**
 * @brief This API is used to get TM queue counter index by TM handler.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     handler    - The handler of TM queue
 * @param [out]    ptr_idx    - Queue counter index
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getTmQueueCntIdx(const UI32_T unit,
                                         const CLX_TM_HANDLER_T handler,
                                         UI32_T *ptr_idx);

/* FUNCTION NAME:   hal_mt_namchabarwa_stat_getPortRateType
 * PURPOSE:
 *      This API is used to get port rate type from port cnt type.
 * INPUT:
 *    unit                  --  Device unit number
 *    type                  --  The type of port cnt
 *
 * OUTPUT:
 *    *rate_type            --  The type of traffic rate
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_stat_getPortRateType(const UI32_T unit,
                                        const CLX_STAT_PORT_CNT_TYPE_T type,
                                        CLX_STAT_RATE_TYPE_T *rate_type);
#endif /* End of HAL_MT_NAMCHABARWA_STAT_H */
