/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal.h
 * PURPOSE:
 *  1. Provide whole HAL resource initialization API.
 *  2. Provide HAL per-unit initialization and de-initialization function
 *     APIs.
 *  3. Provide HAL database access APIs.
 *  4. Provide a HAL multiplexing function vector.
 *
 * NOTES:
 */

#ifndef HAL_H
#define HAL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_cfg.h>
#include <clx_module.h>
#include <hal/hal_drv.h>
#include <hal/hal_tbl.h>
#include <hal/hal_intr.h>
#include <hal/hal_io.h>
#include <hal/hal_dbg.h>
#include <cmlib/cmlib_bitmap.h>
#include <api/diag.h>
#include <cdb/cdb.h>
#include <cmlib/cmlib_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_DEBUG                (1)
#define HAL_MAX_DCC_CMD          (16)
#define HAL_BCAST_ADDR_OFFSET    (0x80000000)
#define HAL_BYTES_OF_WORD        (4)
#define HAL_MAX_ENTRY_WORD_SIZE  (MAX_ENTRY_SIZE / HAL_BYTES_OF_WORD)
#define HAL_INVALID_ID           (CLX_INVALID_ID)
#define HAL_ENABLE_RESOURCE_LOCK (1)
#define HAL_LOCAL_INTF_AVL       "lcl_intf_avl"
#define HAL_LOCAL_INTF_INFO_AVL  "lcl_intf_info_avl"
#define HAL_SDB_ENABLE           (0)
/* HAL support maximum MAC/SERDES macro number, \
 * may need to adjust when chip support maximum capacity change */
#define HAL_MAX_MAC_MACRO_COUNT     (64)
#define HAL_MAX_MAC_MACRO_WORD_SIZE (CLX_BITMAP_SIZE(HAL_MAX_MAC_MACRO_COUNT))
/* HAL support maximum plane port number, \
 * may need to adjust when chip support maximum capacity change
 */
#define HAL_MAX_PLANE_PORT_COUNT     (96)
#define HAL_MAX_PLANE_PORT_WORD_SIZE (CLX_BITMAP_SIZE(HAL_MAX_PLANE_PORT_COUNT))
#define HAL_MAX_CPI_PORT_COUNT       (2) /* HAL support maximum CPI port number */
#define HAL_CPI_PORT_0               (0) /* HAL CPI port 0 index */
#define HAL_CPI_PORT_1               (1) /* HAL CPI port 1 index */
#define HAL_CPI_PLANE_PORT           (64)
#define HAL_CPI_DP_PLANE_PORT        (32)
#define HAL_DEVICE_PXP_REV_ID        (CLX_INVALID_ID)
#define HAL_MAX_RC_PORT_COUNT        (4)  /* HAL support maximum RC port number */
#define HAL_RC_PORT_0                (0)  /* HAL RC port 0 index */
#define HAL_RC_PORT_1                (1)  /* HAL RC port 1 index */
#define HAL_RC_PORT_2                (2)  /* HAL RC port 2 index */
#define HAL_RC_PORT_3                (3)  /* HAL RC port 3 index */
#define HAL_MAX_INT_RC_PORT_COUNT    (8)  /* HAL support internal maximum RC port number */
#define HAL_INT_RC_PORT_0            (0)  /* HAL internal RC port 0 index */
#define HAL_INT_RC_PORT_1            (1)  /* HAL internal RC port 1 index */
#define HAL_INT_RC_PORT_2            (2)  /* HAL internal RC port 2 index */
#define HAL_INT_RC_PORT_3            (3)  /* HAL internal RC port 3 index */
#define HAL_INT_RC_PORT_4            (4)  /* HAL internal RC port 4 index */
#define HAL_INT_RC_PORT_5            (5)  /* HAL internal RC port 5 index */
#define HAL_INT_RC_PORT_6            (6)  /* HAL internal RC port 6 index */
#define HAL_INT_RC_PORT_7            (7)  /* HAL internal RC port 7 index */
#define HAL_EXTENDED_CHIP_NUM        (32) /* HAL Extended chip*/
/* MACRO FUNCTION DECLARATIONS
 */

#define PTR_HAL_FUNC_VECTOR(unit)     _ext_ptr_chip_func_vector[unit]
#define PTR_HAL_EXT_CHIP_INFO(unit)   _ext_ptr_chip_info[unit]
#define PTR_HAL_CMN_FUNC_VECTOR(unit) _ext_ptr_chip_cmn_func_vector[unit]

/* hal related check macros */
#define HAL_IS_UNIT_VALID(__unit__)                     \
    (((__unit__) < CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM) && \
     (NULL != _ext_ptr_chip_func_vector[(__unit__)]))

#define HAL_IS_VLAN_VALID(__vlan__) (((__vlan__) >= 1) && ((__vlan__) <= 4095))

#define HAL_IS_ETH_PORT_VALID(__unit__, __port__) \
    (((__port__) < CLX_PORT_NUM) &&               \
     (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP_ETH((__unit__)), (__port__))))

#define HAL_IS_PORT_VALID(__unit__, __port__) \
    (((__port__) < CLX_PORT_NUM) && (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_IS_PP_PORT_VALID(__unit__, __port__) \
    (((__port__) < CLX_PORT_NUM) && (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP_PP((__unit__)), (__port__))))

#define HAL_IS_PHY_PORT_VALID(__unit__, __port__) \
    (((__port__) < CLX_PORT_NUM) &&               \
     (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP_PHY((__unit__)), (__port__))))

#define HAL_IS_RC_PORT_VALID(__unit__, __port__)               \
    ((((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_0)) ||  \
      ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_1)) ||  \
      ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_2)) ||  \
      ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_3))) && \
     (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_IS_CPI_PORT_VALID(__unit__, __port__)                \
    ((((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_0)) ||  \
      ((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_1))) && \
     (CMLIB_BITMAP_BIT_CHK(HAL_PORT_BMP((__unit__)), (__port__))))

#define HAL_IS_RC_PORT(__unit__, __port__)                   \
    (((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_0)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_1)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_2)) || \
     ((__port__) == HAL_RC_PORT(__unit__, HAL_RC_PORT_3)))

#define HAL_IS_CPI_PORT(__unit__, __port__)                    \
    (((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_0)) || \
     ((__port__) == HAL_CPI_PORT(__unit__, HAL_CPI_PORT_1)))

#define HAL_UI32_FLD_MSK(__unit__, __tbl__, __fld__) \
    (0xFFFFFFFF >> (32 - (CDB_TABLE((__unit__), (__tbl__))->ptr_table_entry[(__fld__)].length)))
#define HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl__, __fld__, __value__) \
    ((__value__) <= HAL_UI32_FLD_MSK((__unit__), (__tbl__), (__fld__)))
#define HAL_TRUNCATE_UI32_FLD(__unit__, __tbl__, __fld__, __value__) \
    ((__value__) & HAL_UI32_FLD_MSK((__unit__), (__tbl__), (__fld__)))

#define HAL_CHECK_ERROR(__rc__)                                           \
    do {                                                                  \
        CLX_ERROR_NO_T __rc = (__rc__);                                   \
        if (__rc != CLX_E_OK) {                                           \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, #__rc__ "=%d\n", __rc); \
            return __rc;                                                  \
        }                                                                 \
    } while (0)

#define HAL_CHECK_ERROR_GOTO(__rc__, __label__)                           \
    do {                                                                  \
        CLX_ERROR_NO_T __rc = (__rc__);                                   \
        if (__rc != CLX_E_OK) {                                           \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, #__rc__ "=%d\n", __rc); \
            goto __label__;                                               \
        }                                                                 \
    } while (0)

#define HAL_CHECK_UNIT(__unit__)                                                        \
    do {                                                                                \
        if (!HAL_IS_UNIT_VALID((__unit__))) {                                           \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, "invalid unit=%u, rc=%d\n", __unit__, \
                       CLX_E_BAD_PARAMETER);                                            \
            return CLX_E_BAD_PARAMETER;                                                 \
        }                                                                               \
    } while (0)

#define HAL_CHECK_VLAN(__vlan_id__)                       \
    do {                                                  \
        if (!HAL_IS_VLAN_VALID((__vlan_id__))) {          \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN,         \
                       "invalid " #__vlan_id__ "=%u,"     \
                       " range=1-4095, rc=%d\n",          \
                       __vlan_id__, CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                   \
        }                                                 \
    } while (0)

#define HAL_CHECK_PORT(__unit__, __port__)                                                    \
    do {                                                                                      \
        if (!HAL_IS_PORT_VALID((__unit__), (__port__))) {                                     \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, "u=%u, invalid port=%u, rc=%d\n", __unit__, \
                       __port__, CLX_E_BAD_PARAMETER);                                        \
            return CLX_E_BAD_PARAMETER;                                                       \
        }                                                                                     \
    } while (0)

#define HAL_CHECK_ETH_PORT(__unit__, __port__)                                                    \
    do {                                                                                          \
        if (!HAL_IS_ETH_PORT_VALID((__unit__), (__port__))) {                                     \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, "u=%u, invalid eth port=%u, rc=%d\n", __unit__, \
                       __port__, CLX_E_BAD_PARAMETER);                                            \
            return CLX_E_BAD_PARAMETER;                                                           \
        }                                                                                         \
    } while (0)

#define HAL_CHECK_PP_PORT(__unit__, __port__)                                                   \
    do {                                                                                        \
        if (!HAL_IS_PP_PORT_VALID((__unit__), (__port__))) {                                    \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_ERR, "u=%u, invalid pp port=%u, rc=%d\n", __unit__, \
                       __port__, CLX_E_BAD_PARAMETER);                                          \
            return CLX_E_BAD_PARAMETER;                                                         \
        }                                                                                       \
    } while (0)

#define HAL_CHECK_PHY_PORT(__unit__, __port__)                                                    \
    do {                                                                                          \
        if (!HAL_IS_PHY_PORT_VALID((__unit__), (__port__))) {                                     \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, "u=%u, invalid phy port=%u, rc=%d\n", __unit__, \
                       __port__, CLX_E_BAD_PARAMETER);                                            \
            return CLX_E_BAD_PARAMETER;                                                           \
        }                                                                                         \
    } while (0)

#define HAL_CHECK_PORT_BITMAP(__unit__, __port_bitmap__)                                          \
    do {                                                                                          \
        CLX_PORT_BITMAP_T __bitmap__;                                                             \
                                                                                                  \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP((__unit__)));                              \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__port_bitmap__));                                     \
                                                                                                  \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                                                 \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, "u=%u, invalid port bitmap, rc=%d\n", __unit__, \
                       CLX_E_BAD_PARAMETER);                                                      \
            return CLX_E_BAD_PARAMETER;                                                           \
        }                                                                                         \
    } while (0)

#define HAL_CHECK_ETH_PORT_BITMAP(__unit__, __port_bitmap__)             \
    do {                                                                 \
        CLX_PORT_BITMAP_T __bitmap__;                                    \
                                                                         \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_ETH((__unit__))); \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__port_bitmap__));            \
                                                                         \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                        \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN,                        \
                       "u=%u, invalid eth port bitmap, "                 \
                       "rc=%d\n",                                        \
                       __unit__, CLX_E_BAD_PARAMETER);                   \
            return CLX_E_BAD_PARAMETER;                                  \
        }                                                                \
    } while (0)

#define HAL_CHECK_PP_PORT_BITMAP(__unit__, __port_bitmap__)             \
    do {                                                                \
        CLX_PORT_BITMAP_T __bitmap__;                                   \
                                                                        \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_PP((__unit__))); \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__port_bitmap__));           \
                                                                        \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                       \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN,                       \
                       "u=%u, invalid pp port bitmap, "                 \
                       "rc=%d\n",                                       \
                       __unit__, CLX_E_BAD_PARAMETER);                  \
            return CLX_E_BAD_PARAMETER;                                 \
        }                                                               \
    } while (0)

#define HAL_CHECK_PHY_PORT_BITMAP(__unit__, __port_bitmap__)             \
    do {                                                                 \
        CLX_PORT_BITMAP_T __bitmap__;                                    \
                                                                         \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_PHY((__unit__))); \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__port_bitmap__));            \
                                                                         \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                        \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN,                        \
                       "u=%u, invalid phy port bitmap, "                 \
                       "rc=%d\n",                                        \
                       __unit__, CLX_E_BAD_PARAMETER);                   \
            return CLX_E_BAD_PARAMETER;                                  \
        }                                                                \
    } while (0)

#define HAL_CHECK_PTR(__ptr__)                                                          \
    do {                                                                                \
        if (NULL == (__ptr__)) {                                                        \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, #__ptr__ " is null pointer, rc=%d\n", \
                       CLX_E_BAD_PARAMETER);                                            \
            return CLX_E_BAD_PARAMETER;                                                 \
        }                                                                               \
    } while (0)

#define HAL_CHECK_ENUM_RANGE(__value__, __max__)                         \
    do {                                                                 \
        if ((__value__) >= (__max__)) {                                  \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN,                        \
                       "invalid " #__value__ "=%u, range=0-%u,"          \
                       " rc=%d\n",                                       \
                       __value__, ((__max__) - 1), CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                  \
        }                                                                \
    } while (0)

#define HAL_CHECK_MIN_MAX_RANGE(__value__, __min__, __max__)                              \
    do {                                                                                  \
        if (((__value__) > (__max__)) || ((__value__) < (__min__))) {                     \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN,                                         \
                       "invalid " #__value__ "=%u, range=%u-%u,"                          \
                       " rc=%d\n",                                                        \
                       __value__, (UI32_T)__min__, (UI32_T)__max__, CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                                   \
        }                                                                                 \
    } while (0)

#define HAL_CHECK_MAX_RANGE(__value__, __max__)                          \
    do {                                                                 \
        if ((__value__) > (__max__)) {                                   \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN,                        \
                       "invalid " #__value__ "=%u, range=0-%u,"          \
                       " rc=%d\n",                                       \
                       __value__, (UI32_T)__max__, CLX_E_BAD_PARAMETER); \
            return CLX_E_BAD_PARAMETER;                                  \
        }                                                                \
    } while (0)
#define HAL_CHECK_BOOL(__value__)                                                                  \
    do {                                                                                           \
        if (((FALSE) != (__value__)) && ((TRUE) != (__value__))) {                                 \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, #__value__ "=%u isn't bool, rc=%d\n", __value__, \
                       CLX_E_BAD_PARAMETER);                                                       \
            return CLX_E_BAD_PARAMETER;                                                            \
        }                                                                                          \
    } while (0)

#define HAL_CHECK_INIT(__unit__, __module_id__)                                              \
    do {                                                                                     \
        if (HAL_INIT_STAGE_NONE == HAL_MODULE_INITED((__unit__), (__module_id__))) {         \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN,                                            \
                       "u=%u, %s module isn't inited, "                                      \
                       "rc=%d\n",                                                            \
                       __unit__, clx_module_getModuleName(__module_id__), CLX_E_NOT_INITED); \
            return CLX_E_NOT_INITED;                                                         \
        }                                                                                    \
    } while (0)

#define HAL_CHECK_DEV_FAMILY(__unit__)                                                           \
    do {                                                                                         \
        if (HAL_DEVICE_FAMILY((__unit__)) >= HAL_DEV_FAMILY_LAST) {                              \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_WARN, "invalid device family=%u, rc=%d\n", __unit__, \
                       CLX_E_BAD_PARAMETER);                                                     \
            return CLX_E_BAD_PARAMETER;                                                          \
        }                                                                                        \
    } while (0)

#define HAL_PLANE_BMP_FOREACH(__unit__, __plane_idx__)                                      \
    for ((__plane_idx__) = 0; (__plane_idx__) < HAL_PLANE_NUM(__unit__); (__plane_idx__)++) \
        if (CMLIB_BITMAP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane_idx__)))

#define HAL_BANK_BMP_ID(idx) (1U << idx) /* idx is 0, 1, 2, or 3 */
#define HAL_BANK_BMP \
    (HAL_BANK_BMP_ID(0) | HAL_BANK_BMP_ID(1) | HAL_BANK_BMP_ID(2) | HAL_BANK_BMP_ID(3))

#define HAL_TBL_INFO(unit, tbl_id)     _ext_chip_control_block[unit].pptr_tbl_info[tbl_id]
#define HAL_TBL_KEY_INFO(unit, tbl_id) _ext_chip_control_block[unit].pptr_tbl_key_info[tbl_id]
#define HAL_SDB_INFO(unit, tbl_id, plane_id) \
    _ext_chip_control_block[unit].ppptr_sdb_info[tbl_id][plane_id]
#define HAL_SEMA_INFO(unit, tbl_id) &(_ext_chip_control_block[unit].ptr_sema_id[tbl_id])
#define HAL_ALLOC_INFO(unit, tbl_id) \
    _ext_chip_control_block[unit].ptr_alloc_info->ptr_alloc_tbl[tbl_id]
#define HAL_TCAM_INFO(unit, idx)         _ext_chip_control_block[unit].ptr_tcam_meta_info[idx]
#define HAL_HASH_INFO(unit, idx)         _ext_chip_control_block[unit].ptr_hash_meta_info[idx]
#define HAL_ALLOC_ENTRY_NUM(unit)        _ext_chip_control_block[unit].ptr_alloc_info->entry_num
#define HAL_HASH_TYPE_L2_BMP(unit)       _ext_chip_control_block[unit].ptr_hash_info->l2_bmp[0]
#define HAL_HASH_TYPE_L2_GROUP_BMP(unit) _ext_chip_control_block[unit].ptr_hash_info->l2_grp_bmp[0]
#define HAL_HASH_TYPE_L3_IPV6_128_BMP(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_128_bmp[0]
#define HAL_HASH_TYPE_L3_IPV6_64_BMP(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_64_bmp[0]
#define HAL_HASH_TYPE_L3_NO_PREFIX_BMP(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_no_prefix_bmp[0]
#define HAL_HASH_TYPE_L3_RPF_BMP(unit) _ext_chip_control_block[unit].ptr_hash_info->l3_rpf_bmp[0]
#define HAL_HASH_TYPE_SECURITY_BMP(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->security_bmp[0]
#define HAL_HASH_TYPE_MPLS_BMP(unit)         _ext_chip_control_block[unit].ptr_hash_info->mpls_bmp[0]
#define HAL_HASH_TYPE_L2_BMP_PTR(unit)       _ext_chip_control_block[unit].ptr_hash_info->l2_bmp
#define HAL_HASH_TYPE_L2_GROUP_BMP_PTR(unit) _ext_chip_control_block[unit].ptr_hash_info->l2_grp_bmp
#define HAL_HASH_TYPE_L3_IPV6_128_BMP_PTR(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_128_bmp
#define HAL_HASH_TYPE_L3_IPV6_64_BMP_PTR(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_ipv6_64_bmp
#define HAL_HASH_TYPE_L3_NO_PREFIX_BMP_PTR(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->l3_no_prefix_bmp
#define HAL_HASH_TYPE_L3_RPF_BMP_PTR(unit) _ext_chip_control_block[unit].ptr_hash_info->l3_rpf_bmp
#define HAL_HASH_TYPE_SECURITY_BMP_PTR(unit) \
    _ext_chip_control_block[unit].ptr_hash_info->security_bmp
#define HAL_HASH_TYPE_MPLS_BMP_PTR(unit) _ext_chip_control_block[unit].ptr_hash_info->mpls_bmp
#define HAL_HASH_TYPE_FLOW_BMP(unit)     _ext_chip_control_block[unit].ptr_hash_info->flow_bmp[0]
#define HAL_HASH_TYPE_FLOW_LEVEL_BMP(unit, level) \
    _ext_chip_control_block[unit].ptr_hash_info->flow_bmp[level]
#define HAL_OBJ_INFO_PTR(unit) _ext_chip_control_block[unit].ptr_obj_info
#define HAL_LCL_INTF_AVL(unit) _ext_chip_control_block[unit].ptr_obj_info->ptr_lcl_intf_avl
#define HAL_LCL_INTF_INFO_AVL(unit) \
    _ext_chip_control_block[unit].ptr_obj_info->ptr_lcl_intf_info_avl
#define HAL_INIT_STAGE(unit)             _ext_chip_control_block[unit].init_stage
#define HAL_MODULE_INFO(unit, module_id) _ext_chip_control_block[unit].ptr_module_info[module_id]
#define HAL_DRIVER_INFO(unit)            _ext_chip_control_block[unit].ptr_driver_info
#define HAL_ETH_MACRO_INFO_PTR(unit)     _ext_chip_control_block[unit].ptr_eth_macro_info
#define HAL_ETH_MACRO_NUM(unit)          _ext_chip_control_block[unit].ptr_eth_macro_info->macro_num
#define HAL_ETH_MACRO_MAP_INFO(unit, eth_macro) \
    _ext_chip_control_block[unit].ptr_eth_macro_info->ptr_macro_map[eth_macro]

#define HAL_MODULE_INITED(__unit__, __module__) (HAL_MODULE_INFO(__unit__, __module__).inited)

#define HAL_TBL_ADDR(__unit__, __tbl__, __inst__, __subinst__, __idx__)  \
    (HAL_TBL_INFO((__unit__), __tbl__)->table_addr +                     \
     HAL_TBL_INFO((__unit__), __tbl__)->slot_size * (__inst__) +         \
     HAL_TBL_INFO((__unit__), __tbl__)->subinst_offset * (__subinst__) + \
     HAL_TBL_INFO((__unit__), __tbl__)->entry_offset * (__idx__))

#define HAL_FUNC_CALL(__unit__, __module__, __func__, __param__)                                     \
    ({                                                                                               \
        CLX_ERROR_NO_T __rc = CLX_E_OK;                                                              \
        if ((NULL == PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec) ||                        \
            (NULL ==                                                                                 \
             PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec->hal_##__module__##_##__func__)) { \
            __rc = CLX_E_NOT_SUPPORT;                                                                \
        } else {                                                                                     \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_INFO, "[N]\n");                                          \
            __rc = (PTR_HAL_FUNC_VECTOR(__unit__)                                                    \
                        ->__module__##_func_vec->hal_##__module__##_##__func__ __param__);           \
        }                                                                                            \
        __rc;                                                                                        \
    })

#define HAL_CMN_FUNC_CALL(__unit__, __module__, __func__, __param__)                           \
    ({                                                                                         \
        CLX_ERROR_NO_T __rc = CLX_E_OK;                                                        \
        if ((NULL == PTR_HAL_CMN_FUNC_VECTOR(__unit__)->__module__##_cmn_func_vec) ||          \
            (NULL ==                                                                           \
             PTR_HAL_CMN_FUNC_VECTOR(__unit__)                                                 \
                 ->__module__##_cmn_func_vec->hal_##__module__##_##__func__)) {                \
            __rc = CLX_E_NOT_SUPPORT;                                                          \
        } else {                                                                               \
            DIAG_PRINT(HAL_DBG_HAL, HAL_DBG_INFO, "[N]\n");                                    \
            __rc = (PTR_HAL_CMN_FUNC_VECTOR(__unit__)                                          \
                        ->__module__##_cmn_func_vec->hal_##__module__##_##__func__ __param__); \
        }                                                                                      \
        __rc;                                                                                  \
    })

/* Macros for chip related information */
#define HAL_DEVICE_CHIP_ID(unit)             PTR_HAL_EXT_CHIP_INFO(unit)->device_id
#define HAL_DEVICE_REV_ID(unit)              PTR_HAL_EXT_CHIP_INFO(unit)->revision_id
#define HAL_DEVICE_FAMILY(unit)              PTR_HAL_EXT_CHIP_INFO(unit)->device_family
#define HAL_DEVICE_FREQ(unit)                PTR_HAL_EXT_CHIP_INFO(unit)->frequency
#define HAL_DEVICE_MODE(unit)                PTR_HAL_EXT_CHIP_INFO(unit)->mode
#define HAL_HW_CHIP_ID(unit)                 PTR_HAL_EXT_CHIP_INFO(unit)->hw_chip_id
#define HAL_LAG_EPOCH_ID(unit)               PTR_HAL_EXT_CHIP_INFO(unit)->lag_epoch_id
#define HAL_DIE_BMP(unit)                    PTR_HAL_EXT_CHIP_INFO(unit)->die_bmp
#define HAL_BIN_BMP(unit)                    PTR_HAL_EXT_CHIP_INFO(unit)->bin_bmp
#define HAL_BIN_NUM(unit)                    PTR_HAL_EXT_CHIP_INFO(unit)->bin_num
#define HAL_PLANE_BMP(unit)                  PTR_HAL_EXT_CHIP_INFO(unit)->plane_bmp
#define HAL_FPU_BMP(unit)                    PTR_HAL_EXT_CHIP_INFO(unit)->fpu_bmp
#define HAL_ETH_MACRO_BMP(unit)              PTR_HAL_EXT_CHIP_INFO(unit)->mac_macro_bmp
#define HAL_CPU_PORT(unit)                   PTR_HAL_EXT_CHIP_INFO(unit)->cpu_port
#define HAL_ECPU_PORT(unit)                  PTR_HAL_EXT_CHIP_INFO(unit)->ecpu_port
#define HAL_PORT_BMP(unit)                   PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap
#define HAL_PORT_BMP_ETH(unit)               PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_eth
#define HAL_PORT_BMP_PP(unit)                PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_pp
#define HAL_PORT_BMP_PHY(unit)               PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_phy
#define HAL_PORT_BMP_TOTAL(unit)             PTR_HAL_EXT_CHIP_INFO(unit)->port_bitmap_total
#define HAL_PLANE_ETH_MACRO_NUM(unit, plane) PTR_HAL_EXT_CHIP_INFO(unit)->plane_mac_macro_num
#define HAL_PLANE_FP_NUM(unit, plane)        PTR_HAL_EXT_CHIP_INFO(unit)->plane_fp_num
#define HAL_PLANE_ETH_PORT_NUM(unit)         PTR_HAL_EXT_CHIP_INFO(unit)->plane_eth_port_num
#define HAL_PORT_MAP_INFO(unit, port)        PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port]
#define HAL_CPI_PORT(unit, cpi_idx)          PTR_HAL_EXT_CHIP_INFO(unit)->cpi_port[cpi_idx]
#define HAL_PLANE_PORT_MAP_INFO(unit)        PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info
#define HAL_SERDES_PORT_MAP_INFO(unit)       PTR_HAL_EXT_CHIP_INFO(unit)->ppptr_serdes_port_map_info
#define HAL_CHIP_INFO_FLAGS(unit)            PTR_HAL_EXT_CHIP_INFO(unit)->flags
#define HAL_PLANE_PORT_BMP(unit, plane)      PTR_HAL_EXT_CHIP_INFO(unit)->ptr_plane_port_bitmap[plane]
#define HAL_RC_PORT(unit, rcp_idx)           PTR_HAL_EXT_CHIP_INFO(unit)->rc_port[rcp_idx]
#define HAL_INT_RC_PORT(unit, int_rcp_idx)   PTR_HAL_EXT_CHIP_INFO(unit)->int_rc_port[int_rcp_idx]
#define HAL_INT_RC_PORT_NUM(unit)            PTR_HAL_EXT_CHIP_INFO(unit)->int_rc_port_num
#define HAL_EXTENDED_CHIP_DI_BASE            PTR_HAL_EXT_CHIP_INFO(unit)->extended_di_base
#define HAL_EXTENDED_CHIP_DI_NUM             PTR_HAL_EXT_CHIP_INFO(unit)->extended_di_num

/* Macro to check CPI port working mode */
#define HAL_IS_CPI_PORT_ETH_MODE(unit, cpi_port)                           \
    ((cpi_port == HAL_CPI_PORT(unit, HAL_CPI_PORT_0)) ?                    \
         (HAL_CHIP_INFO_FLAGS(unit) & HAL_CHIP_INFO_FLAGS_CPI0_MODE_ETH) : \
         (HAL_CHIP_INFO_FLAGS(unit) & HAL_CHIP_INFO_FLAGS_CPI1_MODE_ETH))

typedef TABLE_INFO_T CDB_TABLE_T;
typedef PACKING_INFO_T CDB_FIELD_T;
typedef TCAM_TBL_META_T CDB_TCAM_T;
typedef HASH_TBL_META_T CDB_HASH_T;
#define CDB_TABLE HAL_TBL_INFO
#define CDB_TCAM  HAL_TCAM_INFO
#define CDB_HASH  HAL_HASH_INFO

#define HAL_IS_DEVICE_DAWN_FAMILY(unit)                    \
    ((HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8363) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8365) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8366) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8367) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8368) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8369))

#define HAL_IS_DEVICE_LIGHTNING_FAMILY(unit)               \
    ((HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8571) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8573) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8575) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8577) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8578) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8579))

#define HAL_IS_DEVICE_NAMCHABARWA_FAMILY(unit)                \
    ((HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8610) ||    \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8630) ||    \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8650) ||    \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8652) ||    \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860256) ||  \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860128P) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860080) ||  \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860160) ||  \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860128))

#define HAL_IS_DEVICE_NAMCHABARWA_12_8T_FAMILY(unit)         \
    ((HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL8652) ||   \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860080) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860128))

#define HAL_IS_DEVICE_NAMCHABARWA_25_6T_FAMILY(unit)         \
    ((HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860256) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860160) || \
     (HAL_DEVICE_CHIP_ID(unit) == HAL_DEVICE_ID_CL860128P))

#define HAL_WARM_BOOT_FLAGS_INIT   (1U << 0)
#define HAL_WARM_BOOT_FLAGS_DEINIT (1U << 1)
#define HAL_WARM_INIT(__value__)                                               \
    ((TRUE == __value__) ? (_ext_warm_boot_flag |= HAL_WARM_BOOT_FLAGS_INIT) : \
                           (_ext_warm_boot_flag &= ~HAL_WARM_BOOT_FLAGS_INIT))

#define HAL_WARM_DEINIT(__value__)                                               \
    ((TRUE == __value__) ? (_ext_warm_boot_flag |= HAL_WARM_BOOT_FLAGS_DEINIT) : \
                           (_ext_warm_boot_flag &= ~HAL_WARM_BOOT_FLAGS_DEINIT))

#define HAL_IS_WARM_INIT()   (_ext_warm_boot_flag & HAL_WARM_BOOT_FLAGS_INIT)
#define HAL_IS_WARM_DEINIT() (_ext_warm_boot_flag & HAL_WARM_BOOT_FLAGS_DEINIT)

/* Macros for CLX port related attributes */
#define HAL_CL_PORT_TO_DIE(unit, port)   PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].die
#define HAL_CL_PORT_TO_BIN(unit, port)   PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].bin
#define HAL_CL_PORT_TO_PLANE(unit, port) PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].plane
#define HAL_CL_PORT_TO_MAC_MACRO(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].hw_mac_macro

#ifndef HAL_MT_PORT_TO_MACRO_FOR_MAC
#define HAL_MT_PORT_TO_MACRO_FOR_MAC(__unit__, __port__)      \
    ((HAL_IS_DEVICE_NAMCHABARWA_12_8T_FAMILY(__unit__)) ?     \
         (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__) % 4) : \
         (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__)))
#endif

#define HAL_CL_PORT_TO_TM_MAC_MACRO(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].tm_mac_macro
#define HAL_CL_PORT_TO_SERDES_MACRO(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].serdes_mac_macro
#define HAL_CL_PORT_TO_MACRO_PORT(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].lane
#define HAL_CL_PORT_TO_TM_MAC_PORT(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].mpid
#define HAL_CL_PORT_TO_PLANE_PORT(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].ppid
#define HAL_CL_PORT_TO_ETH_MACRO(unit, port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].eth_macro

#define HAL_CL_PORT_TO_DP_PLANE_PORT(unit, port)                                         \
    ((HAL_CPI_PLANE_PORT == PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].ppid) ? \
         HAL_CPI_DP_PLANE_PORT :                                                         \
         PTR_HAL_EXT_CHIP_INFO(unit)->ptr_port_map_info[port].ppid)

#define HAL_PLANE_PORT_TO_CL_PORT(unit, plane, plane_port) \
    PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info[plane][plane_port]

/* In CL8570 PP, CPI plane_port is 64 for non-ITM bubble, and plane_port is 32 for ITM bubble.
 * It might need update when there are multiple CPI ports in a plane for later chips
 */
#define HAL_DP_PLANE_PORT_TO_CL_PORT(unit, plane, plane_port)                          \
    ((!HAL_IS_DEVICE_DAWN_FAMILY(unit)) && (plane_port == HAL_CPI_DP_PLANE_PORT) ?     \
         PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info[plane][HAL_CPI_PLANE_PORT] : \
         PTR_HAL_EXT_CHIP_INFO(unit)->pptr_pport_map_info[plane][plane_port])

#define HAL_SERDES_PORT_TO_CL_PORT(unit, die, serdes_macro, lane) \
    PTR_HAL_EXT_CHIP_INFO(unit)->ppptr_serdes_port_map_info[die][serdes_macro][lane]

/* Resource management related definitions */
#ifdef HAL_ENABLE_RESOURCE_LOCK
#define HAL_COMMON_CREATE_LOCK_RESOURCE(ptr_sema_name, ptr_semaphore_id) \
    osal_createSemaphore(ptr_sema_name, 1, ptr_semaphore_id)
#define HAL_COMMON_DESTROY_LOCK_RESOURCE(ptr_semaphore_id) osal_destroySemaphore(ptr_semaphore_id)
#define HAL_COMMON_LOCK_RESOURCE(ptr_sema, timeout)        osal_takeSemaphore((ptr_sema), (timeout))
#define HAL_COMMON_FREE_RESOURCE(ptr_sema)                 osal_giveSemaphore((ptr_sema))
/* mutex */
#define HAL_COMMON_CREATE_MUTEX_RESOURCE(lock_name, lock_mode, lock_id) \
    osal_createLock((lock_name), (lock_mode), (lock_id))
#define HAL_COMMON_FREE_MUTEX_RESOURCE(lock_id) osal_destroyLock((lock_id))
#define HAL_COMMON_MUTEX_LOCK(lock_id)          osal_acquireLock((lock_id))
#define HAL_COMMON_MUTEX_UNLOCK(lock_id)        osal_releaseLock((lock_id))
#else
#define HAL_COMMON_CREATE_LOCK_RESOURCE(ptr_sema_name, ptr_semaphore_id) CLX_E_OK
#define HAL_COMMON_DESTROY_LOCK_RESOURCE(ptr_semaphore_id)               CLX_E_OK
#define HAL_COMMON_LOCK_RESOURCE(ptr_sema, timeout)                      CLX_E_OK
#define HAL_COMMON_FREE_RESOURCE(ptr_sema)                               CLX_E_OK
/* mutex */
#define HAL_COMMON_CREATE_MUTEX_RESOURCE(lock_name, lock_mode, lock_id)  CLX_E_OK
#define HAL_COMMON_FREE_MUTEX_RESOURCE(lock_id)                          CLX_E_OK
#define HAL_COMMON_MUTEX_LOCK(lock_id)                                   CLX_E_OK
#define HAL_COMMON_MUTEX_UNLOCK(lock_id)                                 CLX_E_OK
#endif /* HAL_ENABLE_RESOURCE_LOCK */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_CHIP_MODE_SIG = 0,
    HAL_CHIP_MODE_PORT,
    HAL_CHIP_MODE_FAB,
    HAL_CHIP_MODE_LAST
} HAL_CHIP_MODE_T;

typedef enum {
    HAL_PLANE_MODE_ETH_SIG = 0,
    HAL_PLANE_MODE_ETH_LEAF,
    HAL_PLANE_MODE_FAB_LEAF,
    HAL_PLANE_MODE_FAB_SPINE,
    HAL_PLANE_MODE_LAST
} HAL_PLANE_MODE_T;

typedef struct HAL_PORT_MAP_S {
    UI32_T valid;
#define HAL_PORT_MAP_FLAGS_INIT_ACTIVE    (1U << 0)
#define HAL_PORT_MAP_FLAGS_GUARANTEE      (1U << 1)
#define HAL_PORT_MAP_FLAGS_CPI            (1U << 2)
#define HAL_PORT_MAP_FLAGS_RCP            (1U << 3)
#define HAL_PORT_MAP_FLAGS_STEERING       (1U << 4)
#define HAL_PORT_MAP_FLAGS_DUAL_UMAC_56G  (1U << 5)
#define HAL_PORT_MAP_FLAGS_DUAL_UMAC_112G (1U << 6)

    UI32_T flags;
    UI32_T eth_macro; /* eth macro id shown in schematic ethx/ethc */
    UI32_T lane;      /* lane id */
    UI32_T lane_cnt;  /* port lane number */
    CLX_PORT_SPEED_T max_speed;
    /* attributes of this CLX port */
    UI32_T die;              /* die index (die is same as bin on CL8360) */
    UI32_T bin;              /* bin index */
    UI32_T plane;            /* plane index */
    UI32_T hw_mac_macro;     /* hw mac macro index, macro_idx in plane*/
    UI32_T tm_mac_macro;     /* tm mac macro index */
    UI32_T serdes_mac_macro; /* serdes mac macro index */
    UI32_T mpid;             /* MAC port id */
    UI32_T ppid;             /* plane port id */
} HAL_PORT_MAP_T;

/* used to record chip's macro bitmap */
typedef UI32_T HAL_MAC_MACRO_BITMAP_T[HAL_MAX_MAC_MACRO_WORD_SIZE];

/* used to record chip plane port bitmap */
typedef UI32_T HAL_PLANE_PORT_BITMAP_T[HAL_MAX_PLANE_PORT_WORD_SIZE];

typedef enum {
    HAL_DEV_FAMILY_DAWN,
    HAL_DEV_FAMILY_LIGHTNING,
    HAL_DEV_FAMILY_NAMCHABARWA,
    HAL_DEV_FAMILY_LAST
} HAL_DEV_FAMILY_T;

typedef struct {
    UI32_T vendor_id;               /* vendor ID                                */
    UI32_T device_id;               /* device ID                                */
    UI32_T revision_id;             /* revision ID                              */
    HAL_DEV_FAMILY_T device_family; /*  Device family                             */
    UI32_T hw_chip_id;              /* hw chip ID(6 bits), used for pkt module  */
    UI32_T lag_epoch_id;            /* lag epoch ID(1 bit), used for pkt module */
    UI32_T frequency;               /* frequency (MHz)                          */
    UI32_T mode;                    /* 720G or 960G mode                        */
#define HAL_CHIP_INFO_FLAGS_USE_UNIT_PORT  (1U << 0)
#define HAL_CHIP_INFO_FLAGS_CPI0_MODE_ETH  (1U << 1)
#define HAL_CHIP_INFO_FLAGS_CPI1_MODE_ETH  (1U << 2)
#define HAL_CHIP_INFO_FLAGS_LAG_EPOCH      (1U << 3)
#define HAL_CHIP_INFO_FLAG_PORT_PREEMPTION (1U << 4)
    UI32_T flags;
    UI32_T die_bmp[1];                              /* chip die bitmap                          */
    UI32_T bin_num;                                 /* chip bin count                           */
    UI32_T bin_bmp[1];                              /* chip bin bitmap                          */
    UI32_T plane_bmp[1];                            /* chip plane bitmap                        */
    UI32_T fpu_bmp[1];                              /* chip fpu bitmap                          */
    HAL_MAC_MACRO_BITMAP_T mac_macro_bmp;           /* chip mac/serdes macro bitmap             */
    HAL_MAC_MACRO_BITMAP_T mac_macro_100g_bmp;      /* chip mac macro support 100G              */
    UI32_T plane_mac_macro_num;                     /* plane mac macro numbers                  */
    UI32_T plane_fp_num;                            /* plane front port numbers                 */
    UI32_T plane_eth_port_num;                      /* plane port eth numbers                   */
    UI32_T plane_max_port_num;                      /* plane maximum port numbers               */
    UI32_T cpu_port;                                /* cpu port id                              */
    UI32_T ecpu_port;                               /* ecpu port id                              */
    UI32_T total_port;                              /* total port numbers                       */
    CLX_PORT_BITMAP_T port_bitmap;                  /* total active port bitmap                 */
    CLX_PORT_BITMAP_T port_bitmap_eth;              /* total active ether port bitmap           */
    CLX_PORT_BITMAP_T port_bitmap_pp;               /* total active plane port bitmap (PP)      */
    CLX_PORT_BITMAP_T port_bitmap_phy;              /* total active PHY (Serdes) port bitmap    */
    CLX_PORT_BITMAP_T port_bitmap_total;            /* total port bitmap (active and inactive)  */
    HAL_PORT_MAP_T *ptr_port_map_info;              /* port and mac/lane map info               */
    UI32_T cpi_port[HAL_MAX_CPI_PORT_COUNT];
    UI32_T **pptr_pport_map_info;                   /* plane port to CL port map                */
    UI32_T ***ppptr_serdes_port_map_info;           /* serdes lane to CL port map               */
    HAL_PLANE_PORT_BITMAP_T *ptr_plane_port_bitmap; /* plane active port bitmap (per-plane)     */
    UI32_T phy_di_num;                              /* per chip used physical port di num       */
    UI32_T lcl_di[CLX_PORT_NUM];                    /* local port => local di                   */
    UI32_T di_map[CLX_PORT_NUM];                    /* local di   => local port                 */
    UI32_T *ptr_plane_mode;                         /* chassis plane mode                       */
    UI32_T rc_port[HAL_MAX_RC_PORT_COUNT];
    UI32_T ***ppptr_umac_port_map_info;             /* umac lane to CL port map                 */
    UI32_T extended_di_base;                        /* chip32-63 used base port di*/
    UI32_T extended_di_num;                         /* chip32-63 used physical port di num */
    UI32_T int_rc_port[HAL_MAX_INT_RC_PORT_COUNT];
    UI32_T int_rc_port_num;
} HAL_CHIP_INFO_T;

typedef enum {
    HAL_INIT_STAGE_NONE = 0,
    HAL_INIT_STAGE_LOW_LEVEL = (0x1U << 0),
    HAL_INIT_STAGE_TASK_RSRC = (0x1U << 1),
    HAL_INIT_STAGE_MODULE = (0x1U << 2),
    HAL_INIT_STAGE_TASK = (0x1U << 3),
} HAL_INIT_STAGE_T;

typedef struct {
    HAL_INIT_STAGE_T inited;
} HAL_MODULE_INFO_T;

typedef struct {
#define HAL_BANK_BMP_SIZE 2
    UI32_T l2_bmp[HAL_BANK_BMP_SIZE];
    UI32_T l2_grp_bmp[HAL_BANK_BMP_SIZE];
    UI32_T l3_ipv6_128_bmp[HAL_BANK_BMP_SIZE];
    UI32_T l3_ipv6_64_bmp[HAL_BANK_BMP_SIZE];
    UI32_T l3_no_prefix_bmp[HAL_BANK_BMP_SIZE];
    UI32_T l3_rpf_bmp[HAL_BANK_BMP_SIZE];
    UI32_T security_bmp[HAL_BANK_BMP_SIZE];
#define HAL_FLOW_BMP_LEVEL_MAX 24
    UI32_T flow_bmp[HAL_FLOW_BMP_LEVEL_MAX];
    UI32_T mpls_bmp[HAL_BANK_BMP_SIZE];
} HAL_HASH_INFO_T;

typedef struct HAL_INTF_OBJ_INFO_S {
    CLX_PORT_TYPE_T type;
#define HAL_INTF_OBJ_INFO_FLAGS_WITH_ID (1U << 0)
    UI32_T flag;
    UI32_T di; /* use di to put cl port for CL325x */
    UI32_T is_lag;
    UI32_T lag_id;
    UI32_T vm_id;
    UI32_T encap_idx;
} HAL_INTF_OBJ_INFO_T;

typedef struct HAL_OBJ_LCL_INTF_S {
    CLX_PORT_TYPE_T type;
    UI32_T port_id;
    UI32_T is_lag;
    UI32_T vm_id;
    UI32_T lcl_intf;
    UI32_T encap_idx;
} HAL_OBJ_LCL_INTF_T;

typedef struct HAL_OBJ_INFO_S {
    CLX_SEMAPHORE_ID_T *ptr_obj_sema_id;
    CMLIB_AVL_HEAD_T *ptr_lcl_intf_avl;
    CMLIB_AVL_HEAD_T *ptr_lcl_intf_info_avl;
} HAL_OBJ_INFO_T;

typedef struct {
    HAL_CHIP_INFO_T *ptr_chip_info;      /* chip information pointer */
    HAL_DRIVER_T *ptr_driver_info;       /* chip driver information pointer */
    TABLE_INFO_T **pptr_tbl_info;        /* table information pointer */
    PACKING_INFO_T **pptr_tbl_key_info;  /* table key information pointer for hash */
    TCAM_TBL_META_T *ptr_tcam_meta_info; /* tcam meta info pointer */
    HASH_TBL_META_T *ptr_hash_meta_info; /* tcam hash info pointer */
    UI32_T ***ppptr_sdb_info;            /* hw shadow database pointer */
    CLX_SEMAPHORE_ID_T *ptr_sema_id;     /* semaphore information pointer */
    HAL_ALLOC_INFO_T *ptr_alloc_info;
    HAL_INIT_STAGE_T init_stage;
    HAL_MODULE_INFO_T *ptr_module_info;       /* module information pointer */
    HAL_HASH_INFO_T *ptr_hash_info;
    HAL_ETH_MACRO_INFO_T *ptr_eth_macro_info; /* pointer of mac macro information of this device */
    HAL_OBJ_INFO_T *ptr_obj_info;
} HAL_CHIP_CB_T;

typedef enum {
    HAL_HASH_TYPE_L2 = 0,
    HAL_HASH_TYPE_L2_GROUP,
    HAL_HASH_TYPE_L3_IPV6_128,
    HAL_HASH_TYPE_L3_IPV6_64,
    HAL_HASH_TYPE_L3_NO_PREFIX,
    HAL_HASH_TYPE_L3_RPF,
    HAL_HASH_TYPE_SECURITY,
    HAL_HASH_TYPE_FLOW,
    HAL_HASH_TYPE_MPLS,
    HAL_HASH_TYPE_LAST
} HAL_HASH_TYPE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief hal_init() is responsible for HAL initialization, it will do
 *        the following:
 *        1. Construct chip control block.
 *        2. Initialize chip information.
 *        3. Initialize driver information.
 *
 * This function will be invoked by init module's initialization
 * framework.
 *
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK        - Successfully initialize HAL.
 * @return         CLX_E_OTHERS    - Fail to complete initialization procedure.
 */
CLX_ERROR_NO_T
hal_init(const UI32_T unit);

/**
 * @brief hal_deinit() is responsible for HAL de-initialization, it will
 *        do the following:
 *        1. Reset driver information.
 *        2. Reset chip information.
 *        3. Free the constructed chip control block.
 *
 * @param [in]     unit    - The unit number that would like to de-initialized.
 * @return         CLX_E_OK        - Successfully de-initialize HAL.
 * @return         CLX_E_OTHERS    - Fail to complete de-initialization procedure.
 */
CLX_ERROR_NO_T
hal_deinit(const UI32_T unit);

/**
 * @brief hal_getSystemUnitNum() is an API that allows to get current valid
 *        unit number information for this system.
 *
 * Please note this API will return current valid unit number
 * information. For example, if there are two units on this system,
 * it will return two from this API. If one of these two units has been
 * removed, it will return one from this API.
 *
 * @param [out]    ptr_unit_num    - The total unit number information.
 * @return         CLX_E_OK               - Get the system unit information successfully.
 * @return         CLX_E_BAD_PARAMETER    - Parameter, ptr_unit_num, is a NULL pointer.
 */
CLX_ERROR_NO_T
hal_getSystemUnitNum(UI32_T *ptr_unit_num);

/**
 * @brief hal_getUnitPortNum() is an API that allows to get total port
 *        number information for this unit.
 *
 * @param [in]     unit            - The specified unit number.
 * @param [out]    ptr_port_num    - The total port number information on the specified
 *                                   unit.
 * @return         CLX_E_OK               - Get the unit's port number information successfully.
 * @return         CLX_E_BAD_PARAMETER    - Parameter, ptr_port_num, is a NULL pointer.
 * @return         CLX_E_OTHERS           - Fail to get the port number information.
 */
CLX_ERROR_NO_T
hal_getUnitPortNum(const UI32_T unit, UI32_T *ptr_port_num);

/**
 * @brief hal_dumpChipInfo() is a function to dump chip information.
 *
 * @param [in]     unit    - The specified unit number.
 * @return         CLX_E_OK        - Dump chip information successfully.
 * @return         CLX_E_OTHERS    - Fail to dump chip information.
 */
CLX_ERROR_NO_T
hal_dumpChipInfo(const UI32_T unit);

/**
 * @brief hal_dumpDriverInfo() is a function to dump driver information.
 *
 * @param [in]     unit    - The specified unit number.
 * @return         CLX_E_OK        - Dump driver information successfully.
 * @return         CLX_E_OTHERS    - Fail to dump driver information.
 */
CLX_ERROR_NO_T
hal_dumpDriverInfo(const UI32_T unit);

/**
 * @brief hal_dumpPortMapInfo() is a function to dump port mapping information.
 *
 * @param [in]     unit    - The specified unit number.
 * @return         CLX_E_OK        - Dump port mapping information successfully.
 * @return         CLX_E_OTHERS    - Fail to dump port mapping information.
 */
CLX_ERROR_NO_T
hal_dumpPortMapInfo(const UI32_T unit);

/**
 * @brief hal_sema_lock() is responsible for lock specific table
 *
 * @param [in]     unit      - The unit number.
 * @param [in]     tbl_id    - The table id.
 * @return         CLX_E_OK        - Successfully read table.
 * @return         CLX_E_OTHERS    - Fail to read table.
 */
CLX_ERROR_NO_T
hal_sema_lock(const UI32_T unit, const UI32_T tbl_id);

/**
 * @brief hal_sema_unlock() is responsible for unlock specific table
 *
 * @param [in]     unit      - The unit number.
 * @param [in]     tbl_id    - The table id.
 * @return         CLX_E_OK        - Successfully read table.
 * @return         CLX_E_OTHERS    - Fail to read table.
 */
CLX_ERROR_NO_T
hal_sema_unlock(const UI32_T unit, const UI32_T tbl_id);

/**
 * @brief hal_cdb_sema_lock() is responsible for cdb
 *
 * @param [in]     unit      - The unit number.
 * @return         CLX_E_OK        - Successfully read table.
 * @return         CLX_E_OTHERS    - Fail to read table.
 */
CLX_ERROR_NO_T
hal_cdb_sema_lock(const UI32_T unit);

/**
 * @brief hal_cdb_sema_unlock() is responsible for unlock cdb
 *
 * @param [in]     unit      - The unit number.
 * @return         CLX_E_OK        - Successfully read table.
 * @return         CLX_E_OTHERS    - Fail to read table.
 */
CLX_ERROR_NO_T
hal_cdb_sema_unlock(const UI32_T unit);

/**
 * @brief hal_setHashBankBmp() is responsible for setting specific one hash bank bitmap.
 *
 * @param [in]     unit        - The unit number.
 * @param [in]     type        - The hash type.
 * @param [in]     bank_bmp    - bank bitmap.
 * @return         CLX_E_OK        - Successfully read table.
 * @return         CLX_E_OTHERS    - Fail to read table.
 */
CLX_ERROR_NO_T
hal_setHashBankBmp(const UI32_T unit, const HAL_HASH_TYPE_T type, const UI32_T bank_bmp);

/**
 * @brief hal_setHashMultiBankBmp() is responsible for setting specific many hash bank bitmap.
 *
 * @param [in]     unit        - The unit number.
 * @param [in]     type        - The hash type.
 * @param [in]     bank_bmp    - point of bank bitmap.
 *                               NULL
 * @return         CLX_E_OK        - Successfully read table.
 * @return         CLX_E_OTHERS    - Fail to read table.
 */
CLX_ERROR_NO_T
hal_setHashMultiBankBmp(const UI32_T unit, const HAL_HASH_TYPE_T type, const UI32_T *bank_bmp);

/**
 * @brief hal_updatePortBitmap is used to update port bitmap
 *
 * This function only update bitmap of front port.
 *
 * @param [in]     unit     - The chip unit number
 * @param [in]     port     - Physical port number
 * @param [in]     value    - Bit value (0 or 1)
 * @return         CLX_E_OK    - Operation successfully
 */
CLX_ERROR_NO_T
hal_updatePortBitmap(const UI32_T unit, const UI32_T port, const UI32_T value);

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the
 *        content in field buffer.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     offset       - Offset of the field.
 * @param [in]     length       - Length of the field.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [in]     ptr_field    - Pointer to the field buffer.
 * @param [out]    ptr_entry    - Pointer to the entry buffer.
 */
void
hal_packField(const UI32_T unit,
              const UI32_T table_id,
              const UI32_T field_id,
              const UI32_T offset,
              const UI32_T length,
              UI32_T *ptr_entry,
              const UI32_T *ptr_field);

/**
 * @brief Extract the specified field from an entry buffer info field buffer.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     offset       - Offset of the field.
 * @param [in]     length       - Length of the field.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [out]    ptr_field    - Pointer to the field buffer.
 */
void
hal_unpackField(const UI32_T unit,
                const UI32_T table_id,
                const UI32_T field_id,
                const UI32_T offset,
                const UI32_T length,
                const UI32_T *ptr_entry,
                UI32_T *ptr_field);

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the
 *        field value.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     offset       - Offset of the field.
 * @param [in]     length       - Length of the field.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [in]     field        - Field value.
 * @param [out]    ptr_entry    - Pointer to the entry buffer.
 */
void
hal_packUi32Field(const UI32_T unit,
                  const UI32_T table_id,
                  const UI32_T field_id,
                  const UI32_T offset,
                  const UI32_T length,
                  UI32_T *ptr_entry,
                  const UI32_T field);

/**
 * @brief Extract the specified field from an entry buffer.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     offset       - Offset of the field.
 * @param [in]     length       - Length of the field.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @return    Field value.
 */
UI32_T
hal_unpackUi32Field(const UI32_T unit,
                    const UI32_T table_id,
                    const UI32_T field_id,
                    const UI32_T offset,
                    const UI32_T length,
                    const UI32_T *ptr_entry);

/**
 * @brief hal_allocPortDi is used to allocate di for a port
 *
 * 1. Port should not be cpu port or cpi with cpu mode
 * 2. In warm init, just return previous allocated DI
 *
 * @param [in]     unit      - The chip unit number
 * @param [in]     port      - Port ID
 * @param [out]    ptr_di    - Phy port DI
 * @return         CLX_E_OK        - Initialized successfully
 * @return         CLX_E_OTHERS    - Internal error
 */
CLX_ERROR_NO_T
hal_allocPortDi(const UI32_T unit, const UI32_T port, UI32_T *ptr_di);

/**
 * @brief hal_updatePortDiMap is used to update per port used di and di map
 *
 * @param [in]     unit    - The chip unit number
 * @return         CLX_E_OK        - Initialized successfully
 * @return         CLX_E_OTHERS    - Internal error
 */
CLX_ERROR_NO_T
hal_updatePortDiMap(const UI32_T unit, const UI32_T port, const UI32_T di);

/**
 * @brief hal_dumpDb is used to dump hal swdb
 *
 * @param [in]     unit     - The chip unit number
 * @param [in]     flags    - dump flags
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_dumpDb(const UI32_T unit, const UI32_T flags);

/**
 * @brief hal_dumpCimRscByIdx is used to dump cim resoure use info by index
 *
 * @param [in]     unit     - The chip unit number
 * @param [in]     plane    - The chip plane number
 * @param [in]     index    - The cim resource table index
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_dumpCimRscByIdx(const UI32_T unit, const UI32_T plane, const UI32_T index);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
extern UI32_T _ext_warm_boot_flag;

extern const UI32_T _ext_hal_zero_buf[HAL_MAX_ENTRY_WORD_SIZE];

extern HAL_FUNC_VEC_T *_ext_ptr_chip_func_vector[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern HAL_CHIP_INFO_T *_ext_ptr_chip_info[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern HAL_CHIP_CB_T _ext_chip_control_block[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

extern HAL_CMN_FUNC_VEC_T *_ext_ptr_chip_cmn_func_vector[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
#endif /* #ifndef HAL_H */
