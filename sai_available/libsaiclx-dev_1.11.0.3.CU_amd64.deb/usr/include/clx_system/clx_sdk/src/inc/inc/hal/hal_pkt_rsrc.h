/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_PKT_RSRC_H
#define HAL_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_cfg.h>
#include <hal_pkt_rsrc_knl.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_PKT_PDMA_COMMON       (0x1UL << 0)
#define HAL_PKT_PDMA_TX           (0x1UL << 1)
#define HAL_PKT_PDMA_RX           (0x1UL << 2)
#define HAL_PKT_FORWARD_TO_CPUPKT (0x1UL << 3)

#if defined(CLX_EN_BIG_ENDIAN)
#define HAL_PKT_ENDIAN_SWAP32(val) (val)
#define HAL_PKT_ENDIAN_SWAP16(val) (val)
#else
#define HAL_PKT_ENDIAN_SWAP32(val)                                      \
    ((((UI32_T)(val) & 0xFF) << 24) | (((UI32_T)(val) & 0xFF00) << 8) | \
     (((UI32_T)(val) & 0xFF0000) >> 8) | (((UI32_T)(val) & 0xFF000000) >> 24))

#define HAL_PKT_ENDIAN_SWAP16(val) ((((UI16_T)(val) & 0xFF) << 8) | (((UI16_T)(val) & 0xFF00) >> 8))
#endif

typedef struct {
    BOOL_T enabled;
    UI32_T unit;
    UI32_T channel;
    UI32_T tc;
    CLX_COLOR_T color;
    CLX_PORT_BITMAP_T egr_port_bitmap;
    BOOL_T with_header;
} HAL_PKT_RX_FWD_CB_T;

typedef enum {
    HAL_PKT_RX_CALLBACK_ACTION_INSERT = 0,
    HAL_PKT_RX_CALLBACK_ACTION_APPEND = 1,
    HAL_PKT_RX_CALLBACK_ACTION_DELETE = 2,
    HAL_PKT_RX_CALLBACK_ACTION_DELETE_ALL = 3
} HAL_PKT_RX_CALLBACK_ACTION_T;

/* rfc definition */
#define HAL_PKT_L2_ARP                     (0x0806)
#define HAL_PKT_L2_ARP_OPERATION_DEFAULT   (0) /* both request & response */
#define HAL_PKT_L2_ARP_OPERATION_REQUEST   (1)
#define HAL_PKT_L2_ARP_OPERATION_RESPONSE  (2)
#define HAL_PKT_L2_RARP                    (0x8035)
#define HAL_PKT_L2_RARP_OPERATION_REQUEST  (3)
#define HAL_PKT_L2_RARP_OPERATION_RESPONSE (4)

#define HAL_PKT_IPV4_ICMP (1)
#define HAL_PKT_IPV6_ICMP (58)

#define HAL_PKT_PP_REASON_STR_LEN   (64)
#define HAL_PKT_RX_REASON_STR_LEN   (64)
#define HAL_PKT_DROP_REASON_STR_LEN (64)

/* field bits to mask */
#define HAL_PKT_UI32_MSK(__bits__) (0xFFFFFFFF >> (32 - (__bits__)))

/* LT_IEV_CFG_EXCPT_EN_W1_SDK_REDIRECT_TO_CPU_L2UC_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L2UC (192 + 23)

/* LT_IEV_CFG_EXCPT_EN_W1_SDK_REDIRECT_TO_CPU_L3UC_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L3UC (192 + 24)

/* LT_IEV_CFG_EXCPT_EN_W1_SDK_L3UC_DA_MISS_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_L3UC_DA_MISS (192 + 30)

/* LT_IEV_CFG_EXCPT_EN_W1_SDK_L3MC_PIM_REGISTER_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_L3MC_PIM_REGISTER (192 + 31)

/* LT_IEV_CFG_EXCPT_EN_W0_SDK_FLEX_DECAP_0_REASON_0_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_FLEX_DECAP_0_REASON_0 (224 + 8)

/* HW define offset
 * Module write IEV.cp_to_cpu_idx=1-3
 * Module write IEV_CFG_CP_TO_CPU_BIT_POS[offset + cp_to_cpu_idx - 1]
 */
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L2UC_DA (0)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L2MC_DA (3)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L2SA    (6)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_MPLS    (9)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_TRILL   (12)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_FCOE    (15)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L3UC_DA (18)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L3UC_SA (21)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L3MC    (24)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_FLW_UC  (27)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_FLW_MC  (30)

/* Control-to-CPU Decap Types */
typedef enum {
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_NONE = 0,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_TRILL,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_MPLS,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_GRE,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_VXLAN_GPE,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_VXLAN_BAS,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_RAW,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_FLEX,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_LAST
} HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_T;

/* Control-to-CPU Action Types */
typedef enum {
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_NONE = 0,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_CPU_QUE,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_REDIR,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_REDIR_IF_FWD,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_CP2CPU_IF_FWD,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_SUPP_CPU,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_DROP_ALL,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_INVALID
} HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T;

/* Control-to-CPU Types */
typedef enum {
    HAL_PKT_GET_REASON_BY_KET_QUEUE = 0,
    HAL_PKT_GET_REASON_BY_KET_LCL_CHIP_IDX,
    HAL_PKT_GET_REASON_BY_KET_RCL_CHIP_IDX,
    HAL_PKT_GET_REASON_BY_KET_LAST
} HAL_PKT_GET_REASON_BY_KET_T;

/* Control-to-CPU Types */
typedef enum {
    HAL_PKT_CTRL_TO_CPU_TYPE_L2 = 0,
    HAL_PKT_CTRL_TO_CPU_TYPE_IPV4,
    HAL_PKT_CTRL_TO_CPU_TYPE_IPV6,
    HAL_PKT_CTRL_TO_CPU_TYPE_ELSE,
    HAL_PKT_CTRL_TO_CPU_TYPE_ARP, /* CL8600 only */
    HAL_PKT_CTRL_TO_CPU_TYPE_LAST
} HAL_PKT_CTRL_TO_CPU_TYPE_T;

/* Key Value, L2 */
typedef struct {
    UI32_T vld;
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_T decap_typ;
    UI32_T is_router_mac;
    UI32_T is_router_mac_mask;
    UI32_T is_len;
    UI32_T is_len_mask;
    UI32_T l2_hdr_complete;
    UI32_T l2_hdr_complete_mask;
    UI32_T typ_len;
    UI32_T typ_len_mask;
    UI32_T l2_da[2];
    UI32_T l2_da_mask[2];
    UI32_T pld[3];
    UI32_T pld_mask[3];
    UI32_T pld_1[2];
    UI32_T pld_1_mask[2];
    UI32_T bd;      /* CL8600 only */
    UI32_T bd_mask; /* CL8600 only */
} HAL_PKT_CTRL_TO_CPU_L2_KEY_T;

/* Key Value, IPV4 */
typedef struct {
    UI32_T vld;
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_T decap_typ;
    UI32_T is_router_mac;
    UI32_T is_router_mac_mask;
    UI32_T l3_ip_rte_en;
    UI32_T l3_ip_rte_en_mask;
    UI32_T l3_da_rng_bmap;
    UI32_T l3_da_rng_bmap_mask;
    UI32_T l3_hdr_complete;
    UI32_T l3_ip_proto;
    UI32_T l3_ip_proto_mask;
    UI32_T l2_hdr_present;
    UI32_T l2_hdr_present_mask;
    UI32_T l3_ipv4_ihl;
    UI32_T l3_ipv4_ihl_mask;
    UI32_T l3_ipv4_ihl_ne_5;
    UI32_T l3_ipv4_ihl_ne_5_mask;
    UI32_T l3_ipv4_frg;
    UI32_T l3_ipv4_frg_mask;
    UI32_T pld[3];
    UI32_T pld_mask[3];
    UI32_T l3_da;
    UI32_T l3_da_mask;
    UI32_T pld_1[2];
    UI32_T pld_1_mask[2];
    UI32_T bd;      /* CL8600 only */
    UI32_T bd_mask; /* CL8600 only */
} HAL_PKT_CTRL_TO_CPU_IPV4_KEY_T;

/* Key Value, IPv6 */
typedef struct {
    UI32_T vld;
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_T decap_typ;
    UI32_T is_router_mac;
    UI32_T is_router_mac_mask;
    UI32_T l3_ip_rte_en;
    UI32_T l3_ip_rte_en_mask;
    UI32_T l3_da_rng_bmap;
    UI32_T l3_da_rng_bmap_mask;
    UI32_T l3_hdr_complete;
    UI32_T l3_ip_proto;
    UI32_T l3_ip_proto_mask;
    UI32_T l2_hdr_present;
    UI32_T l2_hdr_present_mask;
    UI32_T l3_da[4];
    UI32_T l3_da_mask[4];
    UI32_T pld[2];
    UI32_T pld_mask[2];
    UI32_T bd;             /* CL8600 only */
    UI32_T bd_mask;        /* CL8600 only */
    UI32_T opt_exist;      /* CL8600 only */
    UI32_T opt_exist_mask; /* CL8600 only */
} HAL_PKT_CTRL_TO_CPU_IPV6_KEY_T;

/* Key Value, ELSE */
typedef struct {
    UI32_T vld;
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_T decap_typ;
    UI32_T flex_typ;
    UI32_T mpls_typ;
    UI32_T pld[5];
    UI32_T pld_mask[5];
    UI32_T pld_1[2];
    UI32_T pld_1_mask[2];
} HAL_PKT_CTRL_TO_CPU_ELSE_KEY_T;

/* Key Value, ARP [CL8600 only] */
typedef struct {
    UI32_T vld;
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_T decap_typ;
    UI32_T is_router_mac;
    UI32_T is_router_mac_mask;
    UI32_T typ_len;
    UI32_T typ_len_mask;
    UI32_T l2_da[2];
    UI32_T l2_da_mask[2];
    UI32_T req;
    UI32_T req_mask;
    UI32_T res;
    UI32_T res_mask;
    UI32_T l2_da_is_bc;
    UI32_T l2_da_is_bc_mask;
    UI32_T l2_da_eq_tha;
    UI32_T l2_da_eq_tha_mask;
    UI32_T l2_sa_eq_sha;
    UI32_T l2_sa_eq_sha_mask;
    UI32_T bd;
    UI32_T bd_mask;
    UI32_T l2_sa[2];
    UI32_T l2_sa_mask[2];
    UI32_T sender_ip;
    UI32_T sender_ip_mask;
    UI32_T target_ip;
    UI32_T target_ip_mask;
} HAL_PKT_CTRL_TO_CPU_ARP_KEY_T;

/* Key Value */
typedef union {
    HAL_PKT_CTRL_TO_CPU_L2_KEY_T l2;
    HAL_PKT_CTRL_TO_CPU_IPV4_KEY_T ipv4;
    HAL_PKT_CTRL_TO_CPU_IPV6_KEY_T ipv6;
    HAL_PKT_CTRL_TO_CPU_ELSE_KEY_T other;
    HAL_PKT_CTRL_TO_CPU_ARP_KEY_T arp;
} HAL_PKT_CTRL_TO_CPU_KEY_T;

/* Entry of Control-to-CPU Table */
typedef struct {
    /* Key */
    HAL_PKT_CTRL_TO_CPU_TYPE_T typ;
    HAL_PKT_CTRL_TO_CPU_KEY_T key;

    /* Action */
    UI32_T supp_ep2ul;
    UI32_T supp_ul2ul;
    UI32_T frc_tc_15;
    UI32_T supp_topo_blk;
    UI32_T bum_fwd_ctl;
    UI32_T supp_l2_sa_lrn;
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T action;
    UI32_T code;
    UI32_T cpu_que;
} HAL_PKT_CTRL_TO_CPU_ENTRY_T;

#define HAL_PKT_RSRC_LOCK(unit) \
    osal_takeSemaphore(&_hal_pkt_rsrc_cb[unit].sema, CLX_SEMAPHORE_WAIT_FOREVER)

#define HAL_PKT_RSRC_UNLOCK(unit) osal_giveSemaphore(&_hal_pkt_rsrc_cb[unit].sema)

#define HAL_PKT_GET_BIT(flags, bit) ((((flags) & (bit)) > 0) ? 1 : 0)

/* Control block for PKT resource management */
typedef struct {
    CLX_SEMAPHORE_ID_T sema;
} HAL_PKT_RSRC_CB_T;

extern HAL_PKT_RSRC_CB_T _hal_pkt_rsrc_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief To map the reason from hw ipp exception bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapIppExcptToUser(const UI32_T unit,
                          const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                          CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp exception value to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     code             - The hw reason code
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapIppExcptCodeToUser(const UI32_T unit,
                              UI32_T code,
                              CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp l3 exception bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapIppL3ExcptToUser(const UI32_T unit,
                            const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                            CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp copy2cpu bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapIppCopyToCpuToUser(const UI32_T unit,
                              const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                              CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp rsn bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapIppRsnToUser(const UI32_T unit,
                        const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                        CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw ipp rsn code to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     code             - The hw reason code
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapIppRsnCodeToUser(const UI32_T unit, UI32_T code, CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw epp exception bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapEppExcptToUser(const UI32_T unit,
                          const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                          CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw epp exception code to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     code             - The hw reason code
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapEppExcptCodeToUser(const UI32_T unit,
                              UI32_T code,
                              CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from hw epp copy2cpu bitmap to user reason bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_hw_bitmap    - The hw reason bitmap
 * @param [out]    user_bitmap      - Pointer to the user reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapEppCopyToCpuToUser(const UI32_T unit,
                              const HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap,
                              CLX_PKT_RX_REASON_BITMAP_T user_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw ipp exception bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToIppExcpt(const UI32_T unit,
                          const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                          HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw ipp l3 excpt bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToIppL3Excpt(const UI32_T unit,
                            const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                            HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw ipp copy2cpu bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToIppCopyToCpu(const UI32_T unit,
                              const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                              HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw ipp rsn bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToIppRsn(const UI32_T unit,
                        const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                        HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw epp exception bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToEppExcpt(const UI32_T unit,
                          const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                          HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw epp copy2cpu bitmap.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     user_bitmap      - The user reason bitmap
 * @param [out]    ptr_hw_bitmap    - Pointer to the hw reason bitmap
 * @return         CLX_E_OK        - Success to map the reason
 * @return         CLX_E_OTHERS    - Fail to map the reason
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToEppCopyToCpu(const UI32_T unit,
                              const CLX_PKT_RX_REASON_BITMAP_T user_bitmap,
                              HAL_PKT_RX_REASON_BITMAP_T *ptr_hw_bitmap);

/**
 * @brief To configure the mapping from user-view reason to the RX CPU queue.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     queue            - The specified queue
 * @param [in]     reason_bitmap    - The reason bitmap
 * @return         CLX_E_OK        - Successfully configure the mapping.
 * @return         CLX_E_OTHERS    - Configure the mapping failed.
 */
CLX_ERROR_NO_T
hal_pkt_setRxQueueMapping(const UI32_T unit,
                          const UI32_T queue,
                          const CLX_PKT_RX_REASON_BITMAP_T reason_bitmap);

/**
 * @brief To get the mapping from user-view reason to the CPU queue.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     queue                - The specified queue
 * @param [out]    ptr_reason_bitmap    - Pointer to the reason bitmap
 * @return         CLX_E_OK        - Successfully get the mapping.
 * @return         CLX_E_OTHERS    - Get the mapping failed.
 */
CLX_ERROR_NO_T
hal_pkt_getRxQueueMapping(const UI32_T unit,
                          const UI32_T queue,
                          CLX_PKT_RX_REASON_BITMAP_T *ptr_reason_bitmap);

/**
 * @brief Set the reason bitmap to trap packets to the remote chip
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     chip             - Device chip id
 * @param [in]     reason_bitmap    - The reason bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_pkt_setRxChipMapping(const UI32_T unit,
                         const UI32_T chip,
                         const CLX_PKT_RX_REASON_BITMAP_T reason_bitmap);

/**
 * @brief Get the reason bitmap which traps packets to the target remote chip
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     chip                 - Device chip id
 * @param [in]     ptr_reason_bitmap    - Pointer to the reason bitmap obtained
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_pkt_getRxChipMapping(const UI32_T unit,
                         const UI32_T chip,
                         CLX_PKT_RX_REASON_BITMAP_T *ptr_reason_bitmap);

/**
 * @brief To de-initialize the SW resource.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Success to perform de-initializtion.
 * @return         CLX_E_OTHERS    - Fail to perform de-initializtion.
 */
CLX_ERROR_NO_T
hal_pkt_deinitPktRsrc(const UI32_T unit);

/**
 * @brief To initialize the resource.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Successfully initialize the resource.
 * @return         CLX_E_OTHERS    - Initialize the resource failed.
 */
CLX_ERROR_NO_T
hal_pkt_initPktRsrc(const UI32_T unit);

/**
 * @brief To set the CPU reason code to RX port and queue mapping.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     port             - The port ID indicating CPU or CPI
 * @param [in]     queue            - The specified queue
 * @param [in]     reason_bitmap    - The reason bitmap
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Fail
 */
CLX_ERROR_NO_T
hal_pkt_setRxMapping(const UI32_T unit,
                     const UI32_T port,
                     const UI32_T queue,
                     const CLX_PKT_RX_REASON_BITMAP_T reason_bitmap);

/**
 * @brief To get the CPU reason code to RX port and queue mapping.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     port                 - The port ID indicating CPU or CPI
 * @param [in]     queue                - The specified queue
 * @param [out]    ptr_reason_bitmap    - Pointer of the reason bitmap
 * @return         CLX_E_OK        - Successfully get the mapping.
 * @return         CLX_E_OTHERS    - Get the mapping failed.
 */
CLX_ERROR_NO_T
hal_pkt_getRxMapping(const UI32_T unit,
                     const UI32_T port,
                     const UI32_T queue,
                     CLX_PKT_RX_REASON_BITMAP_T *ptr_reason_bitmap);

CLX_ERROR_NO_T
hal_pkt_setStackingPortQueueMapping(const UI32_T unit,
                                    const UI32_T rmt_cpu_queue,
                                    const UI32_T stacking_queue);

CLX_ERROR_NO_T
hal_pkt_getStackingPortQueueMapping(const UI32_T unit,
                                    const UI32_T rmt_cpu_queue,
                                    UI32_T *ptr_stacking_queue);

#endif /* End of HAL_VLAN_H */
