/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_tm_sch.h
 * PURPOSE:
 *      It provides hal tm SCH module schedule block API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NAMCHABARWA_TM_SCH_H
#define HAL_MT_NAMCHABARWA_TM_SCH_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_tm.h>
#include <hal/mountain/namchabarwa/hal_mt_namchabarwa_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */

/*dwrr weight max*/
#define HAL_MT_NAMCHABARWA_TM_DWRR_WEIGHT_MAX (255)

#define HAL_MT_NAMCHABARWA_TM_DWRR_WEIGHT_BIT_NUM (3)
/*bandwidth rate in user-view is kbps unit*/
#define HAL_MT_NAMCHABARWA_TM_FRONT_PORT_BUCKET_RATE_USER_UNIT (1000)

/*1 byte is 8 bit*/
#define HAL_MT_NAMCHABARWA_TM_ONE_BYTE_BIT_LENGTH (8)

/*port max speed 800G that is 800000000(kbps) in shapers*/
#define HAL_MT_NAMCHABARWA_TM_PORT_SPEED_MAX (800000000)

/*front port's bucket rate's granularity 256kbps*/
#define HAL_MT_NAMCHABARWA_TM_FRONT_PORT_BUCKET_RATE_GRANULARITY (256)

/*front port's bucket size's granularity 64byte*/
#define HAL_MT_NAMCHABARWA_TM_FRONT_PORT_BUCKET_SIZE_GRANULARITY (64)

/*front port's min shaping rate 256k bps*/
#define HAL_MT_NAMCHABARWA_TM_SCH_FRONT_PORT_SHAPE_MIN (256)

/*max bucket size, 32767*2048 bytes*/
#define HAL_MT_NAMCHABARWA_TM_SCH_BURST_SIZE_LIMIT (67106816)

/*front port's bucket rate bitwidth in hardware*/
#define HAL_MT_NAMCHABARWA_TM_FRONT_PORT_BUCKET_RATE_MANTISSA_WIDTH (4)
#define HAL_MT_NAMCHABARWA_TM_FRONT_PORT_BUCKET_RATE_EXPONENT_WIDTH (11)

/*front port's bucket size bitwidth in hardware*/
#define HAL_MT_NAMCHABARWA_TM_FRONT_PORT_BUCKET_SIZE_MANTISSA_WIDTH (4)
#define HAL_MT_NAMCHABARWA_TM_FRONT_PORT_BUCKET_SIZE_EXPONENT_WIDTH (11)

/*cpu port's bucket rate's granularity 64pps*/
#define HAL_MT_NAMCHABARWA_TM_CPU_PORT_BUCKET_RATE_GRANULARITY (64)

/*cpu port's min shaping rate 64 pps*/
#define HAL_MT_NAMCHABARWA_TM_SCH_CPU_PORT_SHAPE_MIN (64)

/*cpu port's bucket size's granularity packet*/
#define HAL_MT_NAMCHABARWA_TM_CPU_PORT_BUCKET_SIZE_GRANULARITY (1)

/*cpu port's bucket rate bitwidth in hardware*/
#define HAL_MT_NAMCHABARWA_TM_CPU_PORT_BUCKET_RATE_WIDTH (21)

/*cpu port's bucket size bitwidth in hardware*/
#define HAL_MT_NAMCHABARWA_TM_CPU_PORT_BUCKET_SIZE_WIDTH (13)

/*cpi port's bucket rate's granularity 64pps*/
#define HAL_MT_NAMCHABARWA_TM_CPI_PORT_BUCKET_RATE_GRANULARITY (64)

/*cpi port's bucket size's granularity packet*/
#define HAL_MT_NAMCHABARWA_TM_CPI_PORT_BUCKET_SIZE_GRANULARITY (1)

/*cpi port's bucket rate bitwidth in hardware*/
#define HAL_MT_NAMCHABARWA_TM_CPI_PORT_BUCKET_RATE_WIDTH (21)

/*cpi port's bucket size bitwidth in hardware*/
#define HAL_MT_NAMCHABARWA_TM_CPI_PORT_BUCKET_SIZE_WIDTH (13)

#define HAL_MT_NAMCHABARWA_TM_SCH_HW_MAX_RATE        (0x7fff)
#define HAL_MT_NAMCHABARWA_TM_SCH_HW_MAX_BUCKET_SIZE (0x7a29)

/*default value of register FP_DWRR_EN. Notice its 4 bits which represent
 *the bit value of {SP_MIN_LIST, MIN_LIST, SP_MAX_LIST, MAX_LIST}
 */
#define HAL_MT_NAMCHABARWA_TM_SCH_FP_DWRR_EN_DEF (0x5)

#define HAL_MT_NAMCHABARWA_TM_SCH_BANDWIDTH_FIELD_VALID (1U << 0)
#define HAL_MT_NAMCHABARWA_TM_SCH_WEIGHT_FIELD_VALID    (1U << 1)

#define HAL_MT_NAMCHABARWA_TM_SCH_TOPOLOTY_FIELD_VALID     (1U << 0)
#define HAL_MT_NAMCHABARWA_TM_SCH_SP_FIELD_VALID           (1U << 1)
#define HAL_MT_NAMCHABARWA_TM_SCH_DWRR_EN_FIELD_VALID      (1U << 2)
#define HAL_MT_NAMCHABARWA_TM_SCH_DWRR_INTR_EN_FIELD_VALID (1U << 3)
#define HAL_MT_NAMCHABARWA_TM_SCH_SP_SEQ_FIELD_VALID       (1U << 4)

#define HAL_MT_NAMCHABARWA_TM_SAPER_STEP_RATE                   (128)
#define HAL_MT_NAMCHABARWA_TM_PORT_SPEED_TO_PORT_BANDWIDTH(val) val * 1000
/* MACRO FUNCTION DECLARATIONS
 */
/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_MT_NAMCHABARWA_TM_SCH_SHAPER_REG_S {
    UI32_T cir_rate_table_id;
    UI32_T cir_max_bucket_table_id;
    UI32_T cir_add_token_value_table_id;
    UI32_T cir_fraction_table_id;
    UI32_T pir_rate_table_id;
    UI32_T pir_max_bucket_table_id;
    UI32_T pir_add_token_value_table_id;
    UI32_T pir_fraction_table_id;
} HAL_MT_NAMCHABARWA_TM_SCH_SHAPER_REG_T;

typedef struct HAL_MT_NAMCHABARWA_TM_SHAPER_CONFIG_S {
    UI32_T cfg_cir_shaper_rate;
    UI32_T cfg_cir_shaper_max_bucket;
    UI32_T cfg_cir_add_token_value;
    UI32_T cfg_cir_fraction;
    UI32_T cfg_pir_shaper_rate;
    UI32_T cfg_pir_shaper_max_bucket;
    UI32_T cfg_pir_add_token_value;
    UI32_T cfg_pir_fraction;
} HAL_MT_NAMCHABARWA_TM_SHAPER_CONFIG_T;

typedef struct HAL_MT_NAMCHABARWA_TM_SCH_HW_INDEX_S {
    UI32_T inst_idx;
    UI32_T sub_idx;
    UI32_T entry_idx;
} HAL_MT_NAMCHABARWA_TM_SCH_HW_INDEX_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init tm module sch configuration.
 *
 * This function will configure all front-plane-ports to be default
 * topology.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_initCfg(const UI32_T unit);

/**
 * @brief Init tm module sch warmboot.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     ptr_db    - Warmboot database
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Init fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_initWarm(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_deinitWarm(const UI32_T unit, HAL_IO_WB_DB_T *ptr_db);

/**
 * @brief Configure min/max bandwidth for a handler.
 *
 * If maxbandwidth is 0, sdk will configure port speed to hardware.
 * If burst size is 0, sdk will calculate burst size itself.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Egress physical port id which to be written.
 * @param [in]     handler          - The handler which the bandwidth written on.
 * @param [in]     ptr_bandwidth    - Bandwidth informations.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_setBandwidth(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_TM_HANDLER_T handler,
                                       const CLX_TM_BANDWIDTH_T *ptr_bandwidth);

/**
 * @brief Get min/max bandwidth of a handler.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Egress physical port id which to be written.
 * @param [in]     handler          - The handler which the bandwidth to be got.
 * @param [out]    ptr_bandwidth    - The bandwidth of the handler.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_getBandwidth(const UI32_T unit,
                                       const UI32_T port,
                                       const CLX_TM_HANDLER_T handler,
                                       CLX_TM_BANDWIDTH_T *ptr_bandwidth);

/**
 * @brief Configure sp/dwrr weight for a handler.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Egress physical port id which to be written.
 * @param [in]     handler    - The handler which the bandwidth written on.
 * @param [in]     mode       - Schedule algorithm. sp or dwrr.
 * @param [in]     weight     - Weight of dwrr, valid only when mode parameter is dwrr.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_setScheduleMode(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_TM_HANDLER_T handler,
                                          const CLX_TM_SCH_MODE_T mode,
                                          const UI32_T weight);

/**
 * @brief Get sp/dwrr weight of a handler.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Egress physical port id which to be got.
 * @param [in]     handler       - The handler which to be got.
 * @param [out]    ptr_mode      - Schedule algorithm. sp or dwrr.
 * @param [out]    ptr_weight    - Weight of dwrr, valid only when mode parameter is dwrr.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_getScheduleMode(const UI32_T unit,
                                          const UI32_T port,
                                          const CLX_TM_HANDLER_T handler,
                                          CLX_TM_SCH_MODE_T *ptr_mode,
                                          UI32_T *ptr_weight);

/**
 * @brief Set shaper eir enable
 * @param [in]     unit      - Device unit number.
 * @param [in]     mode      - Share mode or Separate mode.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_setShaperEirEnable(const UI32_T unit, const UI32_T mode);

/**
 * @brief  *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_mode      - Share mode or Separate mode.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_getShaperEirEnable(const UI32_T unit, UI32_T *ptr_mode);

/**
 * @brief Configure the packet length whether include SFG(8byte)+IFG(12byte).
 *
 * @param [in]     unit     - Device unit number.
 * @param [in]     layer    - Physical layer means include SFG+IFG.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_setSchedulePacketLength(const UI32_T unit, const UI32_T layer);

/**
 * @brief Get configure the packet length whether include SFG(8byte)+IFG(12byte).
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_layer    - Physical layer means include SFG+IFG.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_getSchedulePacketLength(const UI32_T unit, UI32_T *ptr_layer);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_setPortDefault(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_sch_setSpeed(const UI32_T unit,
                                   const UI32_T port,
                                   const HAL_TM_PORT_SPEED_T speed);

#endif /* End of HAL_MT_NAMCHABARWA_TM_SCH_H */
