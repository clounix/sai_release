/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_telm.h
 * PURPOSE:
 *    Provide HAL driver API functions for NB.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_TELM_H
#define HAL_MT_TELM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_telm.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_TELM_INT_LFSR_IDX_OFFSET             (8)
#define HAL_MT_TELM_INT_PROFILE_NUM                 (8)
#define HAL_MT_TELM_TYPE_NUM                        (3)
#define HAL_MT_TELM_SAMPLER_THRESHOLD_DEFAULT_VALUE (0)
#define HAL_MT_TELM_SAMPLER_VALUE_DEFAULT_VALUE     (0xDEADBEEF)
#define HAL_MT_TELM_SAMPLER_TAPS_DEFAULT_VALUE      (0x80200003)
#define HAL_MT_TELM_INT_INSTR_BMP_DEFAULT_VALUE     (0)
#define HAL_MT_TELM_INT_CUD_ENTRY_NUM               (50)
#define HAL_MT_TELM_ROLE_TBL_PORT_NUM               (16)
#define HAL_MT_TELM_IS_EDGE_TBL_DI_NUM              (32)
#define HAL_MT_TELM_INSTR_MASK_DEFAULT_VALUE        (0xFFFE)

#define HAL_MT_TELM_REP_O_CUD_OFFSET (1)
#define HAL_MT_TELM_REP_C_ACT_OFFSET (6)
#define HAL_MT_TELM_REP_C_CUD_OFFSET (7)
#define HAL_MT_TELM_REP_R_ACT_OFFSET (12)
#define HAL_MT_TELM_REP_R_CUD_OFFSET (13)

#define HAL_MT_TELM_REP_O_ACT_FIELD_ID (0)
#define HAL_MT_TELM_REP_O_CUD_FIELD_ID (1)
#define HAL_MT_TELM_REP_C_ACT_FIELD_ID (2)
#define HAL_MT_TELM_REP_C_CUD_FIELD_ID (3)
#define HAL_MT_TELM_REP_R_ACT_FIELD_ID (4)
#define HAL_MT_TELM_REP_R_CUD_FIELD_ID (5)

#define HAL_MT_TELM_INT_IDENTS                                                    \
    (CLX_TELM_INT_DOMAIN_ATTR_IDENT_GENEVE | CLX_TELM_INT_DOMAIN_ATTR_IDENT_GRE | \
     CLX_TELM_INT_DOMAIN_ATTR_IDENT_VXLAN | CLX_TELM_INT_DOMAIN_ATTR_IDENT_TCP |  \
     CLX_TELM_INT_DOMAIN_ATTR_IDENT_UDP)
#define HAL_MT_TELM_IOAM_FIFO_NOTIFY_MUTEX_SEMA_NAME ("IOAM_FIFO_NOTIFY_MUTEX_SEMA")
#define HAL_MT_TELM_IOAM_FIFO_TASK_NAME              ("IOAM_FIFO_TASK")
#define HAL_MT_TELM_IOAM_FIFO_DMA_ENTRY_NUM \
    (32 * 1024) /* FIFO entry dma size is 256b in 2^N unit. */
#define HAL_MT_TELM_IOAM_MAX_RING_BUF_ENTRY_NUM          (65535)
#define HAL_MT_TELM_IOAM_FIFO_UPLOAD_SEQ_NUM_BASE        (0)
#define HAL_MT_TELM_IOAM_STATS_FIFO_THRESHOLD_COUNT      (0x20)
#define HAL_MT_TELM_IOAM_STATS_FIFO_ALM_FULL_DEFAULT     (0X4)
#define HAL_MT_TELM_IOAM_STATS_FIFO_TIMEOUT_DEFAULT      (0x2710) /* unit is 1/1.35Ghz */
#define HAL_MT_TELM_IOAM_CFG_FWR_SAMPLE_INTERVAL_DEFAULT (0x1000)

#define HAL_MT_TELM_IOAM_CFG_IP_PROTOCOL  (0xba) /* identify ioam header protocol for ipv4 */
#define HAL_MT_TELM_IFA_IP_PROTOCOL       (0x83) /* identify ifa header protocol for ipv4 */
#define HAL_MT_TELM_IOAM_CFG_HBH_OPT_TYPE (0x11) /* identify ioam header protocol for ipv6 */
#define HAL_MT_TELM_IOAM_CFG_HBH_OPT_TYPE_MASK \
    (0x1f) /* mask opt type, fix to 0x1f, not expose to user to set */

#define HAL_MT_TELM_IOAM_STATS_FIFO_READ_PTR_UPDATE_THRESHOLD \
    (HAL_MT_TELM_IOAM_STATS_FIFO_THRESHOLD_COUNT)
#define HAL_MT_TELM_IOAM_FIFO_ENTRY_BYTES (MT_CDB_RWI_SLV_IOAM_STATS_FIFO_WORDS * HAL_BYTES_OF_WORD)

#define HAL_MT_TELM_IOAM_FIFO_TASK_SLEEP_USEC (10 * 1000)
#define HAL_MT_TELM_IOAM_FIFO_TASK_SLEEP_TH_ENTRY_NUM \
    (HAL_MT_TELM_IOAM_STATS_FIFO_READ_PTR_UPDATE_THRESHOLD * 256)

#define HAL_MT_TELM_TM_LUT_ENTRY_PER_LC_MAX_NUM (25)

#define HAL_MT_TELM_RWI_MOD_RPT_CFG_DEFAULT_TNL_IDX  (0x1ffe)
#define HAL_MT_TELM_RWI_MOD_RPT_CFG_DEFAULT_INTR_BMP (0x800F)

#define HAL_MT_NAMCHABARWA_IOAM_FIFO_CHANNEL_NUM (19)
#define HAL_MT_NAMCHABARWA_IOAM_FIFO_CHANNEL_BMP (1 << HAL_MT_NAMCHABARWA_IOAM_FIFO_CHANNEL_NUM)
/* CH19_CLR/MASk offset bit is 17 */
#define HAL_MT_NAMCHABARWA_IOAM_FIFO_CHANNEL_CLR_BMP (1 << 17)

/* TODO: temp define here. interface.h */
#define HAL_MT_NAMCHABARWA_IFMON_ETH_LANE_NUM_PER_SLICE (32)
#define HAL_MT_NAMCHABARWA_IFMON_SLICE_NUM              (8)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_MT_TELM_CHECK_RC_RETURN(rc, module, level, format, arg...) \
    do {                                                               \
        if (rc != CLX_E_OK) {                                          \
            DIAG_PRINT(module, level, "rc:%u, " format, rc, ##arg);    \
            return rc;                                                 \
        }                                                              \
    } while (0);

#define HAL_MT_TELM_CHECK_RC_NOT_RETURN(rc, module, level, format, arg...) \
    do {                                                                   \
        if (rc != CLX_E_OK) {                                              \
            DIAG_PRINT(module, level, "rc:%u, " format, rc, ##arg);        \
        }                                                                  \
    } while (0);

#define CDB_WRITE_PSR_SLV_ENTRY(__unit__, __inst_idx__, __subinst_idx__, __table_id__,         \
                                __entry_idx__, __ptr_entry__)                                  \
    ({                                                                                         \
        rc += cdb_writeEntry(unit, __inst_idx__, __subinst_idx__,                              \
                             MT_REG_TDS_PSR_SLV_##__table_id__, __entry_idx__, __ptr_entry__); \
        rc += cdb_writeEntry(unit, __inst_idx__, __subinst_idx__,                              \
                             MT_REG_DIS_PSR_SLV_##__table_id__, __entry_idx__, __ptr_entry__); \
        rc += cdb_writeEntry(unit, __inst_idx__, __subinst_idx__,                              \
                             MT_REG_RWI_PSR_SLV_INNER_##__table_id__, __entry_idx__,           \
                             __ptr_entry__);                                                   \
        rc += cdb_writeEntry(unit, __inst_idx__, __subinst_idx__,                              \
                             MT_REG_RWI_PSR_SLV_OUTER_##__table_id__, __entry_idx__,           \
                             __ptr_entry__);                                                   \
    })

#define HAL_MT_TELM_TM_LUT_ENTRY_PACK(r_cud, r_act, c_cud, c_act, o_cud, o_act)          \
    ((r_cud << HAL_MT_TELM_REP_R_CUD_OFFSET) | (r_act << HAL_MT_TELM_REP_R_ACT_OFFSET) | \
     (c_cud << HAL_MT_TELM_REP_C_CUD_OFFSET) | (c_act << HAL_MT_TELM_REP_C_ACT_OFFSET) | \
     (o_cud << HAL_MT_TELM_REP_O_CUD_OFFSET) | o_act)

/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_MT_TELM_PROF_TBL_FLD_S {
    UI32_T lfsr_tbl_id;
    UI32_T lfsr_fld;
    UI32_T instr_tbl_id;
    UI32_T instr_fld;
} HAL_MT_TELM_PROF_TBL_FLD_T;

typedef enum {
    HAL_MT_TELM_CUD_UC = 0x0,
    HAL_MT_TELM_CUD_MC,
    HAL_MT_TELM_CUD_MIR,
    HAL_MT_TELM_CUD_CPU,
    HAL_MT_TELM_CUD_MOD,
    HAL_MT_TELM_CUD_INT_ENCAP_SHIM, // 5
    HAL_MT_TELM_CUD_INT_DECAP_SHIM,
    HAL_MT_TELM_CUD_INT_ENCAP_SHIM_META,
    HAL_MT_TELM_CUD_INT_ENCAP_META,
    HAL_MT_TELM_CUD_INT_DECAP_SHIM_META, // 9
    HAL_MT_TELM_CUD_INT_ENCAP_REPORT,    // a
    HAL_MT_TELM_CUD_INT_ENCAP_SHIM_TRUNC,
    HAL_MT_TELM_CUD_INT_ENCAP_SHIM_META_TRUNC,
    HAL_MT_TELM_CUD_INT_NO_DECAP_TRUNC,
    HAL_MT_TELM_CUD_INT_MASK,
    HAL_MT_TELM_CUD_INT_DECAP_SHIM_AND_MASK,
    HAL_MT_TELM_CUD_LAST
} HAL_MT_TELM_CUD_TYPE_T;

/*
 * INT LUT ENTRY
 * % # [17:13]  int_r_cud - INT report CUD type
 * % # [12]     int_r_act - INT report action
 * % # [11:07]  int_c_cud - INT clone  CUD type
 * % # [06]     int_c_act - INT clone  action
 * % # [05:01]  int_o_cud - INT origin CUD type
 * % # [00]     int_o_act - INT origin action
 */
typedef struct HAL_MT_TELM_LUT_ENTRY_S {
    BOOL_T rep_o_act;
    HAL_MT_TELM_CUD_TYPE_T rep_o_cud;
    BOOL_T rep_c_act;
    HAL_MT_TELM_CUD_TYPE_T rep_c_cud;
    BOOL_T rep_r_act;
    HAL_MT_TELM_CUD_TYPE_T rep_r_cud;
} HAL_MT_TELM_LUT_ENTRY_T;

typedef struct HAL_MT_TELM_INT_CB_S {
    UI32_T sample_rate[HAL_MT_TELM_INT_PROFILE_NUM];
} HAL_MT_TELM_INT_CB_T;

typedef enum { HAL_MT_TELM_WBDB_INT_CB, HAL_MT_TELM_WBDB_LAST } HAL_MT_TELM_WBDB_T;

typedef struct HAL_MT_TELM_IOAM_FIFO_NORIFY_HANDLER_S {
    CLX_TELM_IOAM_FIFO_READ_FUNC_T callback;
    void *ptr_cookie;
} HAL_MT_TELM_IOAM_FIFO_NORIFY_HANDLER_T;

typedef struct HAL_MT_TELM_IOAM_CB_S {
    /* ioam read fifo task thread */
    UI32_T thread_pri;
    UI32_T thread_stack_size;
    CLX_THREAD_ID_T thread_id;

    HAL_MT_TELM_IOAM_FIFO_NORIFY_HANDLER_T notify_handler;

    HAL_INTR_TYPE_T intr_type;

    UI8_T *ptr_ring_buf_start_not_align;
    UI8_T *ptr_ring_buf_start;
    UI8_T *ptr_ring_buf_desc_start_not_align;
    UI8_T *ptr_ring_buf_desc_start;
    UI8_T *ptr_ring_buf_nxt_read;
    UI32_T ring_buf_entry_num;
    UI32_T nxt_seq_num;

    /* new proc flow in NB.使用index代替addr做ringbuf的循环，
    记录上次的pop index（也即LT中的write pointer），和curr index比较，然后逐条read dma中fifo entry。
    最大条目数为work index（也就是LT中的read pointer）。 */
    UI32_T next_read_index;
    UI32_T work_index;
} HAL_MT_TELM_IOAM_CB_T;

typedef struct HAL_MT_TELM_MOD_CB_S {
    CLX_PKT_RX_REASON_T rx_reason;
} HAL_MT_TELM_MOD_CB_T;

typedef struct HAL_MT_TELM_HOP_CNT_ZERO_S {
    CLX_TELM_HOP_CNT_ZERO_FUNC_T callback;
    void *ptr_cookie;
} HAL_MT_TELM_HOP_CNT_ZERO_T;

typedef struct HAL_MT_TELM_IFA_EXCEED_NORIFY_HANDLER_S {
    CLX_TELM_IFA_MAX_LEN_EXCEED_FUNC_T callback;
    void *ptr_cookie;
} HAL_MT_TELM_IFA_EXCEED_NORIFY_HANDLER_T;

typedef struct HAL_MT_TELM_IRQ_CB_S {
    HAL_MT_TELM_HOP_CNT_ZERO_T hop_cnt_zero_notify_handler;
    HAL_MT_TELM_IFA_EXCEED_NORIFY_HANDLER_T ifa_exceed_notify_handler;
} HAL_MT_TELM_IRQ_CB_T;

typedef struct HAL_MT_TELM_CB_S {
    HAL_MT_TELM_INT_CB_T telm_int_cb;
    HAL_MT_TELM_IOAM_CB_T telm_ioam_cb;
    HAL_MT_TELM_MOD_CB_T telm_mod_cb;
    HAL_MT_TELM_IRQ_CB_T telm_irq_cb;
} HAL_MT_TELM_CB_T;

/* ioam缓存表，可能不需要 */
typedef struct HAL_MT_TELM_IOAM_FIFO_SW_ENTRY_S {
    UI32_T is_valid;
    CLX_TELM_IOAM_FIFO_ENTRY_T ioam_fifo_entry;
} HAL_MT_TELM_IOAM_FIFO_SW_ENTRY_T;

typedef struct HAL_MT_TELM_IOAM_DIAG_REG_CFG_S {
    UI32_T stats_fifo_threshold;
    UI32_T stats_fifo_timeout_l;
    UI32_T stats_fifo_timeout_h;
    UI32_T fast_reload;
    UI32_T color_switch_by_pkt;
    UI32_T fifo_alm_full;
} HAL_MT_TELM_IOAM_DIAG_REG_CFG_T;

typedef enum {
    /* port speed. 0: 10G;  1: 25G; 2: 40G; 3: 50G; 4:100G; 5:200G; 6:400G */
    HAL_RWI_PORT_SPEED_10G = 0,
    HAL_RWI_PORT_SPEED_25G,
    HAL_RWI_PORT_SPEED_40G,
    HAL_RWI_PORT_SPEED_50G,
    HAL_RWI_PORT_SPEED_100G,
    HAL_RWI_PORT_SPEED_200G,
    HAL_RWI_PORT_SPEED_400G,
    HAL_RWI_PORT_SPEED_800G,
    HAL_RWI_PORT_SPEED_LAST
} HAL_RWI_PORT_SPEED_T;

typedef enum {
    HAL_MT_TELM_TRUNC_TYPE_INT, /* clone truncate for INT CUD types */
    HAL_MT_TELM_TRUNC_TYPE_MOD, /* clone truncate for MOD CUD type */
    HAL_MT_TELM_TRUNC_TYPE_LAST
} HAL_MT_TELM_TRUNC_TYPE_T;

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_mt_telm_init(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_telm_deinit(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_telm_setPortProperty(const UI32_T unit,
                            const UI32_T port,
                            const CLX_PORT_PROPERTY_T property,
                            const UI32_T param0,
                            const UI32_T param1);

CLX_ERROR_NO_T
hal_mt_telm_getPortProperty(const UI32_T unit,
                            const UI32_T port,
                            const CLX_PORT_PROPERTY_T property,
                            UI32_T *ptr_param0,
                            UI32_T *ptr_param1);

CLX_ERROR_NO_T
hal_mt_telm_setProperty(const UI32_T unit,
                        const CLX_SWC_PROPERTY_T property,
                        const UI32_T param0,
                        const UI32_T param1);

CLX_ERROR_NO_T
hal_mt_telm_getProperty(const UI32_T unit,
                        const CLX_SWC_PROPERTY_T property,
                        UI32_T *ptr_param0,
                        UI32_T *ptr_param1);

CLX_ERROR_NO_T
hal_mt_telm_registerNotifyCallback(const UI32_T unit,
                                   const CLX_TELM_IRQ_TYPE_T irq_type,
                                   const void *callback,
                                   void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_telm_deregisterNotifyCallback(const UI32_T unit,
                                     const CLX_TELM_IRQ_TYPE_T irq_type,
                                     const void *callback,
                                     void *ptr_cookie);

CLX_ERROR_NO_T
hal_mt_telm_setTelmProperty(const UI32_T unit,
                            const CLX_TELM_PROPERTY_T property,
                            const CLX_TELM_PROPERTY_PARAM_T *ptr_param);

CLX_ERROR_NO_T
hal_mt_telm_getTelmProperty(const UI32_T unit,
                            const CLX_TELM_PROPERTY_T property,
                            CLX_TELM_PROPERTY_PARAM_T *ptr_param);

/* ========================= INT api list =========================== */

CLX_ERROR_NO_T
hal_mt_telm_setIntProfile(const UI32_T unit,
                          const UI32_T profile_id,
                          const CLX_TELM_INT_PROFILE_T *ptr_profile_cfg);

CLX_ERROR_NO_T
hal_mt_telm_getIntProfile(const UI32_T unit,
                          const UI32_T profile_id,
                          CLX_TELM_INT_PROFILE_T *ptr_profile_cfg);

CLX_ERROR_NO_T
hal_mt_telm_setIntGlobal(const UI32_T unit,
                         const CLX_TELM_INT_DOMAIN_T *ptr_domain_cfg,
                         const CLX_TELM_INT_DEVICE_T *ptr_device_cfg);

CLX_ERROR_NO_T
hal_mt_telm_getIntGlobal(const UI32_T unit,
                         CLX_TELM_INT_DOMAIN_T *ptr_domain_cfg,
                         CLX_TELM_INT_DEVICE_T *ptr_device_cfg);

/* ========================= IOAM api list =========================== */

CLX_ERROR_NO_T
hal_mt_telm_setIoamCfg(const UI32_T unit, const CLX_TELM_IOAM_CFG_T *ptr_ioam_cfg);

CLX_ERROR_NO_T
hal_mt_telm_getIoamCfg(const UI32_T unit, CLX_TELM_IOAM_CFG_T *ptr_ioam_cfg);

CLX_ERROR_NO_T
hal_mt_telm_getIoamDiagCfg(UI32_T unit, HAL_MT_TELM_IOAM_DIAG_REG_CFG_T *ptr_ioam_diag_reg);

/* ========================= IFA api list =========================== */

CLX_ERROR_NO_T
hal_mt_telm_setIfaCfg(const UI32_T unit, const CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

CLX_ERROR_NO_T
hal_mt_telm_getIfaCfg(const UI32_T unit, CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

/* ========================= ＭOD api list =========================== */

CLX_ERROR_NO_T
hal_mt_telm_getModCfg(const UI32_T unit, CLX_TELM_MOD_CFG_T *ptr_mod_cfg);

CLX_ERROR_NO_T
hal_mt_telm_setModCfg(const UI32_T unit, const CLX_TELM_MOD_CFG_T *ptr_mod_cfg);

CLX_ERROR_NO_T
hal_mt_telm_setIoamDiagCfg(UI32_T unit, HAL_MT_TELM_IOAM_DIAG_REG_CFG_T *ptr_ioam_diag_reg);

CLX_ERROR_NO_T
hal_mt_telm_setPortSpeed(const UI32_T unit, const UI32_T port, const CLX_PORT_SPEED_T speed);

#endif /* End of HAL_MT_TELM_H */
