/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_ifmap.h
 * PURPOSE:
 *      It provides user-port to cl-port hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_IFMAP_H
#define HAL_IFMAP_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_IFMAP_CB_FLAGS(__unit__) (_ext_hal_ifmap_cb[__unit__].flags)

#define HAL_IFMAP_USER_PORT_MAP_INFO(__unit__, __user_port__) \
    (_ext_hal_ifmap_cb[__unit__].ptr_user_port_map[__user_port__])

#define HAL_IFMAP_CL_PORT_MAP_INFO(__unit__, __cl_port__) \
    (_ext_hal_ifmap_cb[__unit__].ptr_cl_port_map[__cl_port__])

#define HAL_IFMAP_USER_PORT_BMP_TOTAL(__unit__) (_ext_hal_ifmap_cb[__unit__].user_port_bitmap_total)

#define HAL_IFMAP_USER_PORT_BMP(__unit__) (_ext_hal_ifmap_cb[__unit__].user_port_bitmap)

#define HAL_IFMAP_USER_PORT_BMP_ETH(__unit__) (_ext_hal_ifmap_cb[__unit__].user_port_bitmap_eth)

#define HAL_IFMAP_USER_PORT_BMP_PHY(__unit__) (_ext_hal_ifmap_cb[__unit__].user_port_bitmap_phy)

#define HAL_IFMAP_USER_PORT_BMP_PP(__unit__) (_ext_hal_ifmap_cb[__unit__].user_port_bitmap_pp)

#define HAL_IFMAP_CL_PORT_BMP(__unit__) (_ext_hal_ifmap_cb[__unit__].cl_port_bitmap)

#define HAL_IFMAP_USER_CPU_PORT(__unit__) (_ext_hal_ifmap_cb[__unit__].user_cpu_port)

#define HAL_IFMAP_USER_CPI_PORT(__unit__, __cpi_idx__) \
    (_ext_hal_ifmap_cb[__unit__].user_cpi_port[__cpi_idx__])

#define HAL_IFMAP_USER_RC_PORT(__unit__, __rc_idx__) \
    (_ext_hal_ifmap_cb[__unit__].user_rc_port[__rc_idx__])

/* macros for code decision */
#define HAL_IFMAP_IS_USER_TOTAL_PORT_VALID(__unit__, __user_port__) \
    (((__user_port__) < CLX_PORT_NUM) &&                            \
     (CMLIB_BITMAP_BIT_CHK(HAL_IFMAP_USER_PORT_BMP_TOTAL((__unit__)), (__user_port__))))

#define HAL_IFMAP_IS_USER_PORT_VALID(__unit__, __user_port__) \
    (((__user_port__) < CLX_PORT_NUM) &&                      \
     (CMLIB_BITMAP_BIT_CHK(HAL_IFMAP_USER_PORT_BMP((__unit__)), (__user_port__))))

#define HAL_IFMAP_IS_USER_ETH_PORT_VALID(__unit__, __user_port__) \
    (((__user_port__) < CLX_PORT_NUM) &&                          \
     (CMLIB_BITMAP_BIT_CHK(HAL_IFMAP_USER_PORT_BMP_ETH((__unit__)), (__user_port__))))

#define HAL_IFMAP_IS_USER_PHY_PORT_VALID(__unit__, __user_port__) \
    (((__user_port__) < CLX_PORT_NUM) &&                          \
     (CMLIB_BITMAP_BIT_CHK(HAL_IFMAP_USER_PORT_BMP_PHY((__unit__)), (__user_port__))))

#define HAL_IFMAP_IS_USER_PP_PORT_VALID(__unit__, __user_port__) \
    (((__user_port__) < CLX_PORT_NUM) &&                         \
     (CMLIB_BITMAP_BIT_CHK(HAL_IFMAP_USER_PORT_BMP_PP((__unit__)), (__user_port__))))

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_IFMAP_CB_S {
#define HAL_IFMAP_CB_FLAGS_WARMBOOT_RESTORED (1U << 0)
#define HAL_IFMAP_CB_FLAGS_PORT_MAP_INITED   (1U << 1)
    UI32_T flags;
    /* semaphore resource */
    CLX_SEMAPHORE_ID_T sema_id;    /* semaphore to protect user-port to cl-port mapping DB */
    CLX_SEMAPHORE_ID_T l2_sema_id; /* semaphore to protect ifmap layer's L2 register callback DB */
    CLX_SEMAPHORE_ID_T tm_sema_id; /* semaphore to protect ifmap layer's TM register callback DB */
    CLX_SEMAPHORE_ID_T
    ifmon_sema_id; /* semaphore to protect ifmap layer's IFMON register callback DB */
    CLX_SEMAPHORE_ID_T
    pkt_sema_id;   /* semaphore to protect ifmap layer's PKT register callback DB */
    /* user/cl port bitmap */
    CLX_PORT_BITMAP_T user_port_bitmap_total; /* user-port bitmap (total, include all active and
                                                 inactive ports) */
    CLX_PORT_BITMAP_T
    cl_port_bitmap; /* used cl-port bitmap (active/inactive, includefp/cpu/cpi/rc) */
    CLX_PORT_BITMAP_T user_port_bitmap;     /* user-port bitmap (active, eth+phy+pp) */
    CLX_PORT_BITMAP_T user_port_bitmap_eth; /* user-port bitmap eth (active) */
    CLX_PORT_BITMAP_T user_port_bitmap_phy; /* user-port bitmap phy (active) */
    CLX_PORT_BITMAP_T user_port_bitmap_pp;  /* user-port bitmap pp (active) */
    /* user CPU port id */
    UI32_T user_cpu_port; /* user cpu port id, can't overlap with user FP ports */
    /* user CPI port id */
    UI32_T user_cpi_port[HAL_MAX_CPI_PORT_COUNT];
    /* user RC port id */
    UI32_T user_rc_port[HAL_MAX_RC_PORT_COUNT];
    /* user FP port list to CL port mapping */
    UI32_T *ptr_user_port_map; /* user port list */
    /* CL port list to user port mapping */
    UI32_T *ptr_cl_port_map; /* used cl-port list */
} HAL_IFMAP_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_ifmap_lockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_unlockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_l2_lockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_l2_unlockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_tm_lockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_tm_unlockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_ifmon_lockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_ifmon_unlockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_pkt_lockResource(const UI32_T unit);

CLX_ERROR_NO_T
hal_ifmap_pkt_unlockResource(const UI32_T unit);

/**
 * @brief To init IFMAP HAL resource
 *
 * @param [in]     unit    - The chip unit number
 * @return         CLX_E_OK           - Resource is initialized successfully
 * @return         CLX_E_NO_MEMORY    - No memory
 * @return         CLX_E_OTHERS       - Internal error
 */
CLX_ERROR_NO_T
hal_ifmap_init(const UI32_T unit);

/**
 * @brief To deinit IFMAP HAL resource
 *
 * @param [in]     unit    - The chip unit number
 * @return         CLX_E_OK            - Resource is deinitialized successfully
 * @return         CLX_E_NOT_INITED    - Not inited
 */
CLX_ERROR_NO_T
hal_ifmap_deinit(const UI32_T unit);

/**
 * @brief To initialize the user port to cl port mapping.
 *
 * This function will initialize valid user port list.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     port_cnt              - Port count
 * @param [in]     ptr_user_port_list    - List of user ports want to map
 * @param [in]     ptr_cl_port_list      - List of cl port ID that user port map to
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_ifmap_initUserPortMap(const UI32_T unit,
                          const UI32_T port_cnt,
                          const UI32_T *ptr_user_port_list,
                          const UI32_T *ptr_cl_port_list);

/**
 * @brief To set the user port to cl port mapping.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     port_cnt              - Port count
 * @param [in]     ptr_user_port_list    - List of user ports want to set
 * @param [in]     ptr_cl_port_list      - List of cl port ID that user port map to
 * @param [in]     lock                  - With Semaphore protection or not
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_ifmap_setUserPortMap(const UI32_T unit,
                         const UI32_T port_cnt,
                         const UI32_T *ptr_user_port_list,
                         const UI32_T *ptr_cl_port_list,
                         const UI32_T lock);

/**
 * @brief To get the user port to cl port mapping.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     port_cnt              - Port count
 * @param [in]     ptr_user_port_list    - List of user ports want to get
 * @param [in]     ptr_cl_port_list      - List of cl port ID that user port map to
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_ifmap_getUserPortMap(const UI32_T unit,
                         const UI32_T port_cnt,
                         const UI32_T *ptr_user_port_list,
                         UI32_T *ptr_cl_port_list);

/**
 * @brief To update the user port active bitmap.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cl_port    - CL port ID
 * @param [in]     active     - Active (!0) or inactive (0)
 * @return         CLX_E_OK    - Operation success
 */
CLX_ERROR_NO_T
hal_ifmap_updatePortBitmap(const UI32_T unit, const UI32_T cl_port, const UI32_T active);

/**
 * @brief To check if the port list of user port to cl port mapping are valid.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     port_cnt              - Port count
 * @param [in]     ptr_user_port_list    - List of user ports want to set
 * @param [in]     ptr_cl_port_list      - List of cl port ID that user port map to
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_ifmap_checkMapPortListValid(const UI32_T unit,
                                const UI32_T port_cnt,
                                const UI32_T *ptr_user_port_list,
                                const UI32_T *ptr_cl_port_list);

/**
 * @brief To check if the port list of user port to cl port mapping are valid.
 *        User port must belong to initialized user ports and not allow cl port to
 *        overlap with existing cl port mapping.
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     port_cnt              - Port count
 * @param [in]     ptr_user_port_list    - List of user ports want to set
 * @param [in]     ptr_cl_port_list      - List of cl port ID that user port map to
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_ifmap_checkMapPortDataValid(const UI32_T unit,
                                const UI32_T port_cnt,
                                const UI32_T *ptr_user_port_list,
                                const UI32_T *ptr_cl_port_list);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
extern HAL_IFMAP_CB_T _ext_hal_ifmap_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

#endif /* end of #ifndef HAL_IFMAP_H */
