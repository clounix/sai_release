/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_sec.h
 * PURPOSE:
 *      Define the declaration for Security module.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_SEC_H
#define HAL_SEC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_cfg.h>
#include <clx_types.h>
#include <clx_error.h>
#include <clx_sec.h>
#include <clx_port.h>
#include <osal/osal.h>
#include <dcc/dcc.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* Macro function declarations for security module control block */
#define HAL_SEC_DOS_SEMA_NAME ("sec_dos") /* dos semaphore name */
#define HAL_SEC_SC_SEMA_NAME  ("sec_sc")  /* storm semaphore name */
#define HAL_SEC_SG_SEMA_NAME  ("sec_sg")  /* source guard semaphore name */
#define HAL_SEC_TI_SEMA_NAME  ("sec_ti")  /* traffic isolate semaphore name */

#define HAL_SEC_STORM_CTRL_RATE_NUM (6)   /* storm control rate mum */

/* storm meter bucket size max */
#define HAL_SEC_SCMETER_BUCKET_SIZE_MAX (64000000) /* 64M bytes */
/* storm meter bucket size default */
#define HAL_SEC_SCMETER_BUCKET_SIZE_DEFAULT (9216 + 20 + 64) /* static value: */

/* storm meter packet length in pps mode */
#define HAL_SEC_MTR_PKT_LEN (128)

/* storm meter translate packet to rate
 * rate = (((packet) * HAL_SEC_MTR_PKT_LEN * 8) / 1000)
 */
#define HAL_SEC_MTR_PKT_TO_RATE(packet, rate)                \
    do {                                                     \
        UI64_T __pkt1__;                                     \
        UI64_T __rate1__;                                    \
        osal_memset(&__pkt1__, 0, sizeof(UI64_T));           \
        osal_memset(&__rate1__, 0, sizeof(UI64_T));          \
        UI64_ADD_UI32(__pkt1__, packet);                     \
        UI64_MULT_UI32(__pkt1__, (HAL_SEC_MTR_PKT_LEN * 8)); \
        cmlib_bit64_divUi32(__pkt1__, 1000, &__rate1__);     \
        rate = UI64_LOW(__rate1__);                          \
    } while (0)

/* storm meter translate rate to packet
 * packet =  (((rate) * 1000) / (HAL_SEC_MTR_PKT_LEN * 8))
 */
#define HAL_SEC_MTR_RATE_TO_PKT(rate, packet)                                 \
    do {                                                                      \
        UI64_T __pkt2__;                                                      \
        UI64_T __rate2__;                                                     \
        osal_memset(&__pkt2__, 0, sizeof(UI64_T));                            \
        osal_memset(&__rate2__, 0, sizeof(UI64_T));                           \
        UI64_ADD_UI32(__rate2__, rate);                                       \
        UI64_MULT_UI32(__rate2__, (1000));                                    \
        cmlib_bit64_divUi32(__rate2__, (HAL_SEC_MTR_PKT_LEN * 8), &__pkt2__); \
        packet = UI64_LOW(__pkt2__);                                          \
    } while (0)

/* storm meter translate round rate to packet */
#define HAL_SEC_MTR_ROUND_RATE_TO_PKT(rate, packet)        \
    do {                                                   \
        UI32_T __pkt__ = 0;                                \
        UI32_T __rate__ = 0;                               \
        HAL_SEC_MTR_RATE_TO_PKT(rate, __pkt__);            \
        HAL_SEC_MTR_PKT_TO_RATE(__pkt__, __rate__);        \
        packet = __rate__ != rate ? __pkt__ + 1 : __pkt__; \
    } while (0)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_SEC_DOS_LOCK(unit)   hal_sec_sema((unit), HAL_SEC_ACT_LOCK, HAL_SEC_ST_DOS)
#define HAL_SEC_SC_LOCK(unit)    hal_sec_sema((unit), HAL_SEC_ACT_LOCK, HAL_SEC_ST_SC)
#define HAL_SEC_SG_LOCK(unit)    hal_sec_sema((unit), HAL_SEC_ACT_LOCK, HAL_SEC_ST_SG)
#define HAL_SEC_TI_LOCK(unit)    hal_sec_sema((unit), HAL_SEC_ACT_LOCK, HAL_SEC_ST_TI)
#define HAL_SEC_DOS_UNLOCK(unit) hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_DOS)
#define HAL_SEC_SC_UNLOCK(unit)  hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_SC)
#define HAL_SEC_SG_UNLOCK(unit)  hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_SG)
#define HAL_SEC_TI_UNLOCK(unit)  hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_TI)

/* DATA TYPE DECLARATIONS
 */

/* storm control type */
typedef enum {
    HAL_SEC_STORM_CTRL_TYPE_BC = 0,    /* bc */
    HAL_SEC_STORM_CTRL_TYPE_UUC,       /* uuc */
    HAL_SEC_STORM_CTRL_TYPE_UMC,       /* umc */
    HAL_SEC_STORM_CTRL_TYPE_L2UMC = 2, /* L2umc */
    HAL_SEC_STORM_CTRL_TYPE_L2MC,      /* L2mc */
    HAL_SEC_STORM_CTRL_TYPE_L3UMC,     /* L3umc */
    HAL_SEC_STORM_CTRL_TYPE_L3MC,      /* L3mc */
    HAL_SEC_STORM_CTRL_TYPE_LAST
} HAL_SEC_STORM_CTRL_TYPE_T;

/* storm control packet rate mode */
typedef enum {
    HAL_SEC_STORM_CTRL_PKT_RATE_MODE_KBPS, /* kbps */
    HAL_SEC_STORM_CTRL_PKT_RATE_MODE_PPS,  /* pps */
    HAL_SEC_STORM_CTRL_PKT_RATE_MODE_LAST
} HAL_SEC_STORM_CTRL_PKT_RATE_MODE_T;

/* storm control meter config */
typedef struct HAL_SEC_SC_METER_CFG_S {
    UI32_T meter_idx;                                 /* Storm control meter index, range: 0~101. */
    HAL_SEC_STORM_CTRL_PKT_RATE_MODE_T pkt_rate_mode; /* packet rate mode */
    UI32_T rate_limit;  /* Storm control rate limit. The rate unit is 1 Kbps. */
    UI32_T bucket_size; /* bucket size */
} HAL_SEC_SC_METER_CFG_T;

/* traffic isolation config */
typedef struct HAL_SEC_TI_CFG_S {
    CLX_PORT_BITMAP_T igr_pbm; /* ingress port bitmap */
    CLX_PORT_BITMAP_T egr_pbm; /* egress port bitmap */
} HAL_SEC_TI_CFG_T;

/* security control block */
typedef struct HAL_SEC_CB_S {
    UI32_T
    stm_type_flag[HAL_PORT_NUM_MAX * HAL_SEC_STORM_CTRL_RATE_NUM]; /* storm control type flag */
    HAL_SEC_TI_CFG_T ti; /* traffic isolation, CL8600 only */
} HAL_SEC_CB_T;

/* security warm boot database */
typedef enum {
    HAL_SEC_WBDB_STM_CTRL, /* storm control WBDB */
    HAL_SEC_WBDB_TI_CFG,   /* traffic isolation config */
    HAL_SEC_WBDB_LAST
} HAL_SEC_WBDB_T;

/* security action */
typedef enum {
    HAL_SEC_ACT_INIT,   /* init */
    HAL_SEC_ACT_DEINIT, /* deinit */
    HAL_SEC_ACT_LOCK,   /* lock */
    HAL_SEC_ACT_UNLOCK, /* unlock */
    HAL_SEC_ACT_LAST,
} HAL_SEC_ACTION_T;

/* Security SDK API Semaphore Type */
typedef enum {
    HAL_SEC_ST_DOS, /* semaphore type dos */
    HAL_SEC_ST_SC,  /* semaphore type storm control */
    HAL_SEC_ST_SG,  /* semaphore type source guard */
    HAL_SEC_ST_TI,  /* semaphore type traffic isolation */
    HAL_SEC_ST_LAST
} HAL_SEC_SEMAPHORE_TYPE_T;

/* storm control counter pool entry */
typedef struct HAL_SEC_SCCOUNTER_ENTRY_S {
    UI64_T cnt[3]; /* cnt[0]: fwd byte;
                    * cnt[1]: fwd packet;
                    * cnt[2]: drop packet
                    */
} HAL_SEC_SCCOUNTER_ENTRY_T;

/* security resource protection semaphores */
extern CLX_SEMAPHORE_ID_T _hal_sec_sema_dos[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM]; /* dos */
extern CLX_SEMAPHORE_ID_T _hal_sec_sema_sc[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];  /* storm control */
extern CLX_SEMAPHORE_ID_T _hal_sec_sema_sg[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];  /* source guard */
extern CLX_SEMAPHORE_ID_T _hal_sec_sema_ti[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];  /* traffic isolation
                                                                                */
extern HAL_SEC_CB_T _hal_sec_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM]; /* security control block */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize security module.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_sec_init(const UI32_T unit);

/**
 * @brief Deinitialize security module.
 *
 * @param [in]     unit    - Device unit number.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_sec_deinit(const UI32_T unit);

/**
 * @brief Operate security controlled semaphore
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     action    - Device resource action
 * @param [in]     type      - Device resource type
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_sec_sema(const UI32_T unit, const HAL_SEC_ACTION_T action, const HAL_SEC_SEMAPHORE_TYPE_T type);

/**
 * @brief get Dos Port profile info
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     port              - Port id
 * @param [in]     ptr_profile_id    - profile info
 * @param [in]     ptr_ref_cnt       - reference count
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_sec_getDosPortProfileInfo(const UI32_T unit,
                              const UI32_T port,
                              UI32_T *ptr_profile_id,
                              UI32_T *ptr_ref_cnt);

/**
 * @brief Get storm control counter on a physical port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [in]     type       - The storm control counter type.
 * @param [out]    ptr_cnt    - The storm control counter.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlCnt(const UI32_T unit,
                        const UI32_T port,
                        const CLX_SEC_STORM_CTRL_TYPE_T type,
                        CLX_SEC_STORM_CTRL_CNT_T *ptr_cnt);

/**
 * @brief Set storm control enable for control packets.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     enable    - Enable/Disable storm control for control packets.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_sec_setStormCtrlCtrlPktEn(const UI32_T unit, const UI32_T enable);

/**
 * @brief Set storm control enable for control packets.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - Enable/Disable storm control for control packets.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlCtrlPktEn(const UI32_T unit, UI32_T *ptr_enable);

/**
 * @brief Set storm control meter layer mode(L1/L2).
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     layer_mode    - storm control meter layer mode.
 *                                 1 - layer 1; 0 - layer 2
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_sec_setStormCtrlMeterLayer(const UI32_T unit, const UI32_T layer_mode);

/**
 * @brief Set storm control meter layer mode(global).
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_layer_mode    - storm control meter layer mode
 *                                     1 - layer 1; 0 - layer 2
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlMeterLayer(const UI32_T unit, UI32_T *ptr_layer_mode);

/**
 * @brief get port isolation bitmap
 *
 * @param [in]     unit               - The device unit
 * @param [in]     group              - group
 * @param [out]    igr_port_bitmap    - ingress port bitmap
 * @param [out]    egr_port_bitmap    - egress port bitmap
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
CLX_ERROR_NO_T
hal_sec_getPortIsolation(const UI32_T unit,
                         const UI32_T group,
                         CLX_PORT_BITMAP_T igr_port_bitmap,
                         CLX_PORT_BITMAP_T egr_port_bitmap);

#endif /* End of HAL_SEC_H */
