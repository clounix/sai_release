/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_cmn.h
 * PURPOSE:
 *  1. To maintain common internal utility API, such as src_supp_tag management,
 *     or exception code management.
 * NOTES:
 */

#ifndef HAL_CMN_H
#define HAL_CMN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <hal/hal_l3.h>
#include <hal/hal_pkt_rsrc.h>
#include <hal/hal_ecc.h>
#include <dcc/dcc_dma.h>
#include <cdb/cdb.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_CMN_PVLAN_CVLAN_NUM        (5)
#define HAL_CMN_MCLAG_NUM              (6)
#define HAL_CMN_MCAST_LAG_EPOCH_MASTER (0)
#define HAL_CMN_MCAST_LAG_EPOCH_BACKUP (1)

/* MACRO FUNCTION DECLARATIONS
 */

/* protect ITM_RSLT_LAG_SEL & IEV_LAG_EPOCH */
#define HAL_CMN_LOCK_MCAST_LAG_SEL(unit)                                     \
    HAL_COMMON_LOCK_RESOURCE(&_ext_hal_cmn_cb[(unit)].lag_mcast_sel_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_CMN_FREE_MCAST_LAG_SEL(unit) \
    HAL_COMMON_FREE_RESOURCE(&_ext_hal_cmn_cb[(unit)].lag_mcast_sel_sema_id)

/* protect L2 mcast lag member */
#define HAL_CMN_LOCK_L2_MCAST_LAG_MBR(unit)                                     \
    HAL_COMMON_LOCK_RESOURCE(&_ext_hal_cmn_cb[(unit)].l2_mcast_lag_mbr_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_CMN_FREE_L2_MCAST_LAG_MBR(unit) \
    HAL_COMMON_FREE_RESOURCE(&_ext_hal_cmn_cb[(unit)].l2_mcast_lag_mbr_sema_id)
/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_CMN_CB_S {
    CLX_SEMAPHORE_ID_T lag_mcast_sel_sema_id;    /* protect ITM_RSLT_LAG_SEL & IEV_LAG_EPOCH */
    CLX_SEMAPHORE_ID_T l2_mcast_lag_mbr_sema_id; /* protect L2 mcast lag member */
} HAL_CMN_CB_T;

typedef struct HAL_ACL_PLANE_BCAST_INFO_S {
    BOOL_T bcast_flag;
    UI32_T bcast_cont_plane_idx;
    UI32_T non_bcast_plane_bmp;
} HAL_ACL_PLANE_BCAST_INFO_T;

typedef enum {
    HAL_CMN_ACTION_ADD = 0,
    HAL_CMN_ACTION_DEL,
    HAL_CMN_ACTION_SET,
    HAL_CMN_ACTION_GET,
    HAL_CMN_ACTION_LAST
} HAL_CMN_ACTION_T;

/* for maintaining IEV_RSLT_U_xxx relation to l3_output (ecmp/adj) */
typedef struct HAL_CMN_RTE_NODE_S {
    UI32_T iev_idx;                   /* index to union IEV_RSLT or IEV_RSLT_NVO3_ENCAP */
    CLX_L3_OUTPUT_TYPE_T output_type; /* ecmp, adj, nvo3_adj */
    UI32_T output_id;

    struct HAL_CMN_RTE_NODE_S *ptr_prev_iev;
    struct HAL_CMN_RTE_NODE_S *ptr_next_iev;
} HAL_CMN_RTE_NODE_T;

typedef CLX_ERROR_NO_T (*HAL_CMN_ADJ_CALLBACK_FUNC_T)(const UI32_T unit,
                                                      const UI32_T iev_idx,
                                                      const HAL_L3_ADJ_INFO_T *ptr_adj_info);

typedef CLX_ERROR_NO_T (*HAL_CMN_NVO3_ADJ_CALLBACK_FUNC_T)(
    const UI32_T unit,
    const UI32_T iev_idx,   /* index to union
                               IEV_RSLT_ECMP_PATH
                             */
    const CLX_PORT_T port); /* nvo3_adj_info
                             */

typedef struct {
    UI32_T is_tbl_id;
    union {
        UI32_T tbl_id;
        UI32_T addr;
    };
    union {
        UI32_T field_id;
        UI32_T offset;
    };
    UI32_T entry_idx;
    UI32_T data;
} HAL_CMN_LATENCY_TBL_ENTRY_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_cmn_init(const UI32_T unit);

void
hal_cmn_deinit(const UI32_T unit);

/**
 * @brief The function is used to compare rte_node iev_idx in rte_avl tree.
 *
 * @param [in]     ptr_user_param    - user parameter
 * @param [in]     ptr_user_data     - user data
 * @param [in]     ptr_node_data     - node data
 * @return    <0 -- ptr_user_data.iev_idx < ptr_node_data.iev_idx
 *            =0 -- ptr_user_data.iev_idx = ptr_node_data.iev_idx
 *            >0 -- ptr_user_data.iev_idx > ptr_node_data.iev_idx
 */
I32_T
hal_cmn_cmpRteIev(void *ptr_user_param, void *ptr_user_data, void *ptr_node_data);

/**
 * @brief The function is used to compare rte_node output_id in rte_avl tree (adj only).
 *
 * @param [in]     ptr_user_param    - user parameter
 * @param [in]     ptr_user_data     - user data
 * @param [in]     ptr_node_data     - node data
 * @return    <0 -- ptr_user_data.output_id < ptr_node_data.output_id
 *            =0 -- ptr_user_data.output_id = ptr_node_data.output_id
 *            >0 -- ptr_user_data.output_id > ptr_node_data.output_id
 */
I32_T
hal_cmn_cmpRteAdj(void *ptr_user_param, void *ptr_user_data, void *ptr_node_data);

/**
 * @brief The function is used to save rte_node.
 *
 * @param [in]     ptr_user_param    - user parameter
 * @param [in]     ptr_node_data     - user data
 * @param [in]     pptr_cookie       - cookie
 * @return    CLX_E_OK
 */
CLX_ERROR_NO_T
hal_cmn_saveRteNodesCallback(void *ptr_user_param, void *ptr_node_data, void *pptr_cookie);

/**
 * @brief add or set IEV_RSLT_U_xxx's usage of l3_output (ecmp or adj) to swdb
 *
 * @param [in]     unit                 - device unit number
 * @param [in]     iev_idx              - index to IEV_RSLT_U_xxx
 * @param [in]     output_type          - ecmp or adj
 * @param [in]     output_id            - ecmp_id or adj_id
 * @param [in]     action               - set\get\del
 * @param [in]     pptr_nvo3_adj_arr    - pointer to nvo3_adj_arr
 * @param [in]     ptr_path_avl         - pointer to path_avl
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_cmn_cfgIevNvo3RteNode(const UI32_T unit,
                          const UI32_T iev_idx,
                          const CLX_L3_OUTPUT_TYPE_T output_type,
                          const UI32_T output_id,
                          const HAL_CMN_ACTION_T action,
                          HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                          CMLIB_AVL_HEAD_T *ptr_path_avl);

/**
 * @brief Add node with given path_idx.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     iev_idx              - Index to IEV_RSLT_NVO3_ENCAP
 * @param [in]     output_type          - L3 output type; CLX_L3_OUTPUT_TYPE_[ECMP|NVO3_ADJ]
 * @param [in]     output_id            - L3 output id
 * @param [in]     pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id
 * @param [in]     ptr_path_avl         - Avl head of path_idx
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_cmn_addIevNvo3RteNode(const UI32_T unit,
                          const UI32_T iev_idx,
                          const CLX_L3_OUTPUT_TYPE_T output_type,
                          const UI32_T output_id,
                          HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                          CMLIB_AVL_HEAD_T *ptr_path_avl);

/**
 * @brief Set node with given path_idx.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     iev_idx              - Index to IEV_RSLT_NVO3_ENCAP
 * @param [in]     output_type          - L3 output type; CLX_L3_OUTPUT_TYPE_[ECMP|NVO3_ADJ]
 * @param [in]     output_id            - L3 output id
 * @param [in]     pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id
 * @param [in]     ptr_path_avl         - Avl head of path_idx
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_cmn_setIevNvo3RteNode(const UI32_T unit,
                          const UI32_T iev_idx,
                          const CLX_L3_OUTPUT_TYPE_T output_type,
                          const UI32_T output_id,
                          HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                          CMLIB_AVL_HEAD_T *ptr_path_avl);

/**
 * @brief Delete node with given path_idx.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     iev_idx              - Index to IEV_RSLT_NVO3_ENCAP
 * @param [in]     pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id
 * @param [in]     ptr_path_avl         - Avl head of path_idx
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_cmn_delIevNvo3RteNode(const UI32_T unit,
                          const UI32_T iev_idx,
                          HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                          CMLIB_AVL_HEAD_T *ptr_path_avl);

/**
 * @brief save set-nvo3-adj-swdb for warm-deinit
 *
 * @param [in]     pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id
 * @param [in]     ptr_path_avl         - Avl head of path_idx
 * @param [in]     ptr_obj_meta         - Object Meta for the nonvolatile storage
 * @param [out]    ptr_obj_meta         - Object Meta for the nonvolatile storage
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_cmn_saveIevNvo3RteNodes(HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                            CMLIB_AVL_HEAD_T *ptr_path_avl,
                            HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief restore set-nvo3-adj-swdb for warm-init
 *
 * @param [in]     unit                 - device unit number
 * @param [in]     pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id
 * @param [in]     ptr_path_avl         - Avl head of path_idx
 * @param [in]     ptr_obj_meta         - Object Meta for the nonvolatile storage
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_cmn_restoreIevNvo3RteNodes(const UI32_T unit,
                               HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                               CMLIB_AVL_HEAD_T *ptr_path_avl,
                               const HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief update iev entries related to the input adj_id
 *
 * @param [in]     unit            - device unit number
 * @param [in]     adj_id          - adj_id that is updated
 * @param [in]     ptr_adj_info    - updated adj_info
 * @param [in]     ptr_adj_avl     - pointer to adj_avl
 * @param [in]     callback        - callback function handling iev modification
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_cmn_updateIevByAdj(const UI32_T unit,
                       const UI32_T adj_id,
                       const HAL_L3_ADJ_INFO_T *ptr_adj_info,
                       CMLIB_AVL_HEAD_T *ptr_adj_avl,
                       HAL_CMN_ADJ_CALLBACK_FUNC_T callback);

/**
 * @brief Update hw path info by traversing nodes using given nvo3_adj_id.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     nvo3_adj_id          - Nvo3 adjacency id
 * @param [in]     port                 - Info of nvo3_adj
 * @param [in]     pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id
 * @param [in]     callback             - Callback function to update path
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate fail
 */
CLX_ERROR_NO_T
hal_cmn_updateIevByNvo3Adj(const UI32_T unit,
                           const UI32_T nvo3_adj_id,
                           const CLX_PORT_T port,
                           HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                           HAL_CMN_NVO3_ADJ_CALLBACK_FUNC_T callback);

/**
 * @brief get di from clx_port/native port
 *
 * @param [in]     unit      - device unit number
 * @param [in]     port      - clx_port or native port
 * @param [in]     reason    - cpu reason if to_cpu
 * @param [out]    ptr_di    - di derived from input port
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_cmn_getDi(const UI32_T unit, const CLX_PORT_T port, const UI32_T reason, UI32_T *ptr_di);

/**
 * @brief Set latency normal mode
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_cmn_setLatencyMode(const UI32_T unit);

/**
 * @brief set chip default config value
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_cmn_setChipDfltCfg(const UI32_T unit);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
extern HAL_CMN_CB_T _ext_hal_cmn_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

#endif
