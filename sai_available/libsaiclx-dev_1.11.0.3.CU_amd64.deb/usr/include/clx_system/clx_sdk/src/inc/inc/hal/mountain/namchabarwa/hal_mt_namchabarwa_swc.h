/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_swc.h
 * PURPOSE:
 *      API & special number for CL8570. For example: IEV, EMI.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NAMCHABARWA_SWC_H
#define HAL_MT_NAMCHABARWA_SWC_H

#include <clx_cfg.h>
#include <clx_swc.h>

#include <hal/hal_swc.h>

#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_ENABLE          (1)
#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_DEFAULT_COUNTER (10000)
#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_DEFAULT_TIMER   (1000)

#define HAL_MT_NAMCHABARWA_SWC_EMI_BANK_NUM                (8)
#define HAL_MT_NAMCHABARWA_SWC_EMI_NSH_BANK_BASE           (HAL_MT_NAMCHABARWA_SWC_EMI_BANK_NUM - 1)
#define HAL_MT_NAMCHABARWA_SWC_PAGE_NUM_PER_BANK           (4)
#define HAL_MT_NAMCHABARWA_SWC_ILE_TCAM_BANK_NUM           (64)
#define HAL_MT_NAMCHABARWA_SWC_ILE_TCAM_ENTRY_NUM_PER_BANK (256)
#define HAL_MT_NAMCHABARWA_SWC_MASTER_DIE_ID               (4) /* t die */

#define HAL_MT_NAMCHABARWA_SWC_EPG_MAC_HDR_LEN (60)            /* bytes */
#define HAL_MT_NAMCHABARWA_SWC_EPG_MAC_MAX_IPG (1024)          /* register 10 bits */

#define HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD        0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD      1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD     2
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED 3

#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA           0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA           1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2           0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3           1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID 0xFFFF
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_2X      0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X      1

#if defined(CLX_ASICSIM)
#define HAL_MT_NAMCHABARWA_SWC_DEFAULT_DROP_REASON 63
#endif

typedef void (*HAL_MT_NAMCHABARWA_SWC_TCAM_CFG)(UI32_T unit,
                                                UI32_T tcam_table,
                                                UI32_T *tcam_field,
                                                UI32_T *stage_cfg_buf);

typedef struct {
    CLX_SWC_TCAM_TYPE_T tcam_type;
    HAL_MT_NAMCHABARWA_SWC_TCAM_CFG tcam_cfg;
} HAL_SWC_HAL_TCAM_CFG_T;

typedef struct {
    CLX_SWC_HASH_TILE_TYPE_T hash_tile;
    HAL_HASH_TYPE_T hash_type;
} HAL_SWC_HAL_TILE_BMP_T;

static inline void
hal_mt_namchabarwa_cfg_tcam_off(UI32_T unit,
                                UI32_T tcam_table,
                                UI32_T *tcam_field,
                                UI32_T *stage_cfg_buf)
{
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD],
                      stage_cfg_buf, 0);
}

static inline void
hal_mt_namchabarwa_cfg_tcam_l3sa(UI32_T unit,
                                 UI32_T tcam_table,
                                 UI32_T *tcam_field,
                                 UI32_T *stage_cfg_buf)
{
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD],
                      stage_cfg_buf, 1);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                          stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3);
    }
}

static inline void
hal_mt_namchabarwa_cfg_tcam_l3da(UI32_T unit,
                                 UI32_T tcam_table,
                                 UI32_T *tcam_field,
                                 UI32_T *stage_cfg_buf)
{
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD],
                      stage_cfg_buf, 1);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                          stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3);
    }
}

static inline void
hal_mt_namchabarwa_cfg_tcam_l3sa_4x(UI32_T unit,
                                    UI32_T tcam_table,
                                    UI32_T *tcam_field,
                                    UI32_T *stage_cfg_buf)
{
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD],
                      stage_cfg_buf, 1);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                          stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3);
    }
}

static inline void
hal_mt_namchabarwa_cfg_tcam_l3da_4x(UI32_T unit,
                                    UI32_T tcam_table,
                                    UI32_T *tcam_field,
                                    UI32_T *stage_cfg_buf)
{
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD],
                      stage_cfg_buf, 1);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                          stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3);
    }
}

static inline void
hal_mt_namchabarwa_cfg_tcam_l2uc_sa(UI32_T unit,
                                    UI32_T tcam_table,
                                    UI32_T *tcam_field,
                                    UI32_T *stage_cfg_buf)
{
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD],
                      stage_cfg_buf, 1);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                          stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2);
    }
}

static inline void
hal_mt_namchabarwa_cfg_tcam_l2uc_da(UI32_T unit,
                                    UI32_T tcam_table,
                                    UI32_T *tcam_field,
                                    UI32_T *stage_cfg_buf)
{
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD],
                      stage_cfg_buf, 1);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                          stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2);
    }
}

static inline void
hal_mt_namchabarwa_cfg_tcam_l2mc_da(UI32_T unit,
                                    UI32_T tcam_table,
                                    UI32_T *tcam_field,
                                    UI32_T *stage_cfg_buf)
{
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD],
                      stage_cfg_buf, 1);
    cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                      stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        cdb_packUi32Field(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                          stage_cfg_buf, HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2);
    }
}

#define HAL_MT_NAMCHABARWA_SWC_HASH_MAC_ENTRIES_PER_TILE      (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ARP_ENTRIES_PER_TILE      (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_AFIB_ENTRIES_PER_TILE     (64 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_L3_ENTRIES_PER_TILE       (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ARP_DEFAULT_TILE_NUM      (4)
#define HAL_MT_NAMCHABARWA_SWC_HASH_AFIB_DEFAULT_TILE_NUM     (5)
#define HAL_MT_NAMCHABARWA_SWC_HASH_L3_DEFAULT_TILE_NUM       (5)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MPLS_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_SRV6_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MGI_DEFAULT_TILE_NUM      (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MSGI_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ECMP_GRP_DEFAULT_TILE_NUM (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ECMP_MBR_DEFAULT_TILE_NUM (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_RPFC_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MAC_DEFAULT_TILE_NUM      (0)

#define HAL_MT_NAMCHABARWA_SWC_TCAM_TYPE_ONLY_L3    (0)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_TYPE_L2L3       (1)
#define HAL_MT_NAMCHABARWA_SWC_DMAC_TCAM_START      (16)
#define HAL_MT_NAMCHABARWA_SWC_DMAC_MAX_TCAM_NUM    (16)
#define HAL_MT_NAMCHABARWA_SWC_DIP_DEFAULT_TCAM_NUM (10)
#define HAL_MT_NAMCHABARWA_SWC_MAX_TCAM_NUM         (32)
#define HAL_MT_NAMCHABARWA_SWC_MAX_TILE_NUM         (24)
#define HAL_MT_NAMCHABARWA_ENTRIES_PER_TCAM         (1024)
#define HAL_MT_NAMCHABARWA_ENTRIES_PER_TCAM_BIT     (10)
#define HAL_MT_NAMCHABARWA_MAC_ENTRIES_PER_TCAM     (512)
#define HAL_MT_NAMCHABARWA_L3_ENTRIES_PER_TCAM      (1024)

#define HAL_MT_NAMCHABARWA_SWC_DUAL_MAX_TCAM_NUM (64)
#define HAL_MT_NAMCHABARWA_SWC_DUAL_MAX_TILE_NUM (48)
CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_initCfg(const UI32_T unit);

/**
 * @brief Set CPI port enacp.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - CPI port.
 * @param [in]     ptr_encap_hdr    - Struture of encap.
 * @return         CLX_E_NOT_SUPPORT    - Not support.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_setCpiEncap(const UI32_T unit,
                                   const UI32_T port,
                                   const CLX_SWC_CPI_ENCAP_HDR_T *ptr_encap_hdr);

/**
 * @brief Set CPI port enacp.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - CPI port.
 * @param [out]    ptr_encap_hdr    - Struture of encap.
 * @return         CLX_E_NOT_SUPPORT    - Not support.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_getCpiEncap(const UI32_T unit,
                                   const UI32_T port,
                                   CLX_SWC_CPI_ENCAP_HDR_T *ptr_encap_hdr);

CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_initEpgPkt(HAL_SWC_EPG_PKT_T *ptr_pkt);

/**
 * @brief Set MAC EPG packet related configuration (header, payload, ipg, ...)
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     ptr_pkt    - Packet information to be sent
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_setEpgMacHw(const UI32_T unit, const HAL_SWC_EPG_PKT_T *ptr_pkt);

/**
 * @brief Trigger MAC EPG to send packets
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - EPG ingress port
 * @param [in]     lpbk    - 0: Traffic is sent to PP; 1: MAC loopback
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_sendEpgMacPkt(const UI32_T unit, const UI32_T port, const UI32_T lpbk);

/**
 * @brief Trigger MAC EPG to send packets
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - EPG ingress port
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_chkEpgMacDone(const UI32_T unit, const UI32_T port);

/**
 * @brief Stop MAC EPG from sending packets
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - EPG ingress port
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_stopEpgMacPkt(const UI32_T unit, const UI32_T port);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_arp(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_afib(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_l3(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_mpls(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_srv6(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_l2uc(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_l2mc(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_mgi(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_msgi(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_ecmp_mbr(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_ecmp_grp(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_rpfc(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_policy(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_l2_ecmp_grp(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_hash_tile_l2_ecmp_mbr(const UI32_T unit, UI32_T entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_tcam_l2(const UI32_T unit, UI32_T uc_entry_num, UI32_T mc_entry_num);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_host_tcam(const UI32_T unit,
                                 UI32_T entry_2x_num,
                                 UI32_T entry_4x_num,
                                 UI32_T sip_check);

CLX_ERROR_NO_T
hal_mt_namchabarwa_cfg_route_tcam(const UI32_T unit,
                                  UI32_T entry_2x_num,
                                  UI32_T entry_4x_num,
                                  UI32_T sip_check);

CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_getTileType(const UI32_T unit,
                                   const UI32_T slice_id,
                                   const UI32_T stage_id,
                                   const UI32_T tile_id,
                                   UI32_T *ptr_tile_type);

CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_setTsValue(const UI32_T unit, UI16_T sec_hi, UI32_T sec_low, UI32_T nsec);

CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_getTsValue(const UI32_T unit,
                                  UI16_T *ptr_sec_hi,
                                  UI32_T *ptr_sec_low,
                                  UI32_T *ptr_nsec);

CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_getDeviceInfo(const UI32_T unit, CLX_SWC_DEVICE_INFO_T *ptr_device_info);

CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_setTsOffset(const UI32_T unit, const I32_T nsec);

CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_setCsoMode(const UI32_T unit, const CLX_SWC_CSO_MODE_T mode);

/**
 * @brief Get chip pll status.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                    - Device unit number.
 * @param [out]    ptr_pll_status          - Pointer to chip pll status.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_swc_getChipPllStatus(const UI32_T unit,
                                        CLX_SWC_CHIP_PLL_STATUS_T *ptr_pll_status);
#endif
