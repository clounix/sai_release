/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecpu.h
 * PURPOSE:
 *    Provide HAL driver API functions of ecpu module.
 *
 * NOTES:
 *
 */

#ifndef HAL_ECPU_H
#define HAL_ECPU_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_ECPU_WAIT_MEM_DONE_LOOP (1000)
/*for Elink*/
#define HAL_ECPU_ELINK_MAX_APP (32)
#define HAL_ECPU_CFG_TIMEOUT          (1000 * 1000 * 8) /*8s*/
#define HAL_ECPU_CFG_SEM_TAKE_TIMEOUT (1000)            /*1ms*/
#define HAL_ECPU_ELINK_NOTIFY_SEM_TAKE_TIMEOUT (1000 * 100)   /*100ms*/

/*for ecpu fw update*/
#define HAL_ECPU_FW_UPDATE_TIMEOUT    (1000 * 1000 * 300) /*300s*/
#define HAL_ECPU_MD5_LEN              (16)
#define HAL_ECPU_READ_BUFFER_SIZE     (256)
#define HAL_ECPU_VERSION_INFO_MAX_LEN (41)
#define HAL_ECPU_REGION_0             (1)
#define HAL_ECPU_REGION_1             (2)
#define HAL_ECPU_BOOT_MAGIC           (0x424f4f54)
#define HAL_ECPU_APP_MAGIC            (0x41505055)
#define HAL_ECPU_PCIE_CFGFILE_MAGIC   (0x50434945)
#define HAL_ECPU_UPDATE_END_MAGIC     (0x42594554)
#define HAL_ECPU_FW_SIZE_MAX          (0xe1000) /*900KB*/

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum { HAL_ECPU_WBDB_FW_PATH, HAL_ECPU_WBDB_STATE, HAL_ECPU_WBDB_LAST } HAL_ECPU_WBDB_T;

typedef enum {
    HAL_ECPU_CFG_APP_UPDATE,
    HAL_ECPU_CFG_GET_FW_VERSION,
    HAL_ECPU_CFG_SET_FW_DEFAULT_VERSION,
    HAL_ECPU_CFG_SET_FW_NEXT_VERSION,
    HAL_ECPU_CFG_SET_PCIE_DEFAULT_VERSION,
    HAL_ECPU_CFG_SET_PCIE_NEXT_VERSION,
    HAL_ECPU_CFG_GET_ELINK_INFO,
    HAL_ECPU_CFG_CLEAR_ELINK_STATICS,
    HAL_ECPU_CFG_GET_PORT_INFO,
    HAL_ECPU_CFG_CLEAR_PORT_STATICS,
    HAL_ECPU_CFG_GET_CPU_UTILIZATION,
    HAL_ECPU_CFG_GET_MEM_UTILIZATION,
    HAL_ECPU_CFG_GET_DIAG_BUF_INFO,
    HAL_ECPU_CFG_LAST
} HAL_ECPU_CFG_TYPE_T;

typedef enum {
    HAL_ECPU_CODE_E_NORMAL,
    HAL_ECPU_CODE_E_GET_METADATA,
    HAL_ECPU_CODE_E_SET_METADATA,
    HAL_ECPU_CODE_E_NO_VERSION,
    HAL_ECPU_CODE_E_NOT_SUPPORT,
    HAL_ECPU_CODE_E_OTHER,
    HAL_ECPU_CODE_E_LAST
} HAL_ECPU_CFG_CODE_T;

typedef enum update_code {
    HAL_ECPU_UPDATE_E_OK,
    HAL_ECPU_UPDATE_E_NOSTART,
    HAL_ECPU_UPDATE_E_SEQ,     /*sequence error*/
    HAL_ECPU_UPDATE_E_MAGIC,   /*magic error*/
    HAL_ECPU_UPDATE_E_LEN,     /*file length error*/
    HAL_ECPU_UPDATE_E_MSGLEN,  /*update message length error*/
    HAL_ECPU_UPDATE_E_ERASE,   /*flash erase error*/
    HAL_ECPU_UPDATE_E_READ,    /*flash read error*/
    HAL_ECPU_UPDATE_E_PROGRAM, /*flash write error*/
    HAL_ECPU_UPDATE_E_STRIP,   /*received data length is less than the file length*/
    HAL_ECPU_UPDATE_E_MD5,     /*file md5 error*/
    HAL_ECPU_UPDATE_E_OTHER
} HAL_ECPU_UPDATE_CODE_T;

typedef enum app_updatemsg_type {
    HAL_ECPU_UPDATE_BOOT_START, /*identify start boot-loader update*/
    HAL_ECPU_UPDATE_APP_START,
    HAL_ECPU_UPDATE_PCIEFILE_START,
    HAL_ECPU_UPDATE_DATA,
    HAL_ECPU_UPDATE_END
} HAL_ECPU_APP_UPDATEMSG_TYPE_T;

#pragma pack(1)
typedef struct update_common_msg_hdr {
    UI8_T msg_type;
    UI8_T data[0];
} HAL_ECPU_UPDATE_CMNMSG_HDR_T;

typedef struct update_startmsg_hdr {
    UI8_T msg_type;
    UI32_T magic;
    UI32_T length;
    C8_T version[HAL_ECPU_VERSION_INFO_MAX_LEN];
    UI8_T md5[HAL_ECPU_MD5_LEN];
} HAL_ECPU_UPDATE_START_MSG_HDR_T;

typedef struct update_datamsg_hdr {
    UI8_T msg_type;
    UI32_T seq; /*sequence*/
    UI8_T data[0];
} HAL_ECPU_UPDATE_DATAMSG_HDR_T;

typedef struct update_endmsg_hdr {
    UI8_T msg_type;
    UI32_T magic;
} HAL_ECPU_UPDATE_END_MSG_HDR_T;

typedef struct update_resp_hdr {
    UI8_T msg_type; /*HAL_ECPU_UPDATE_APP_START ...*/
    UI32_T seq;     /*sequence*/
} HAL_ECPU_UPDATE_RESP_HDR_T;

typedef struct config_datamsg_hdr {
    UI32_T cfg_type; /*HAL_ECPU_CFG_TYPE_T*/
    UI8_T data[0];
} HAL_ECPU_CFG_DATA_HDR_T;

typedef struct config_rspmsg_hdr {
    UI32_T cfg_type; /*HAL_ECPU_CFG_TYPE_T*/
    UI32_T code;
} HAL_ECPU_CFG_RSP_HDR_T;

typedef struct config_update_start_hdr {
    HAL_ECPU_CFG_DATA_HDR_T cfg; /*HAL_ECPU_CFG_TYPE_T*/
    HAL_ECPU_UPDATE_START_MSG_HDR_T start;
} HAL_ECPU_CFG_UPDATE_START_HDR_T;

typedef struct config_update_data_hdr {
    HAL_ECPU_CFG_DATA_HDR_T cfg; /*HAL_ECPU_CFG_TYPE_T*/
    HAL_ECPU_UPDATE_DATAMSG_HDR_T data;
} HAL_ECPU_CFG_UPDATE_DATA_HDR_T;

typedef struct config_update_end_hdr {
    HAL_ECPU_CFG_DATA_HDR_T cfg; /*HAL_ECPU_CFG_TYPE_T*/
    HAL_ECPU_UPDATE_END_MSG_HDR_T end;
} HAL_ECPU_CFG_UPDATE_END_HDR_T;

/*for fw update*/
typedef struct config_fw_update_rsp {
    HAL_ECPU_CFG_RSP_HDR_T rsp;
    HAL_ECPU_UPDATE_RESP_HDR_T update;
} HAL_ECPU_CFG_FW_UPDATE_RSP_T;

/*for diagnostic log buffer*/
typedef struct config_diag_buf_rsp {
    HAL_ECPU_CFG_RSP_HDR_T rsp;
    CLX_ECPU_DIAG_BUF_INFO_T buf_info;
} HAL_ECPU_CFG_DIAG_BUF_T;
#pragma pack()

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */
extern BOOL_T _ecpu_fw_running[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern C8_T *_ecpu_fw_path[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to read sram memory.
 *
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     addr    - start address
 * @param [in]     len     - memory length
 * @param [out]    pbuf    - memory data pointer
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ecpu_readMem(const UI32_T unit, const UI32_T addr, const UI32_T len, UI32_T *pbuf);

/**
 * @brief Initialize the ecpu module.
 *
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_ALREADY_INITED   - already inited.
 * @return         CLX_E_NO_MEMORY        - no available memory.
 * @return         CLX_E_ENTRY_NOT_FOUND  - not found entry.
 */
CLX_ERROR_NO_T
hal_ecpu_init(const UI32_T unit);

/**
 * @brief Deinitialize the ecpu module.
 *
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_NOT_INITED       - no inited.
 */
CLX_ERROR_NO_T
hal_ecpu_deinit(const UI32_T unit);

/**
 * @brief This API is used to read diagnostic log buffer.
 *
 *
 * @param [in]     unit    - Device unit number
 * @param [out]    ppbuf   - Diagnostic log buffer pointer
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ecpu_readDiagLog(const UI32_T unit, C8_T **ppbuf);

/**
 * @brief This API is used to send start updating message.
 *
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     type     - Application type
 * @param [in]     size     - Message size
 * @param [in]     pversion - Version pointer
 * @param [in]     md5      - Md5 pointer
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ecpu_sendUpdateStartMsg(const UI32_T unit,
                            const CLX_UPDATE_TYPE_T type,
                            const UI32_T size,
                            const UI8_T *pversion,
                            const UI8_T *md5);

/**
 * @brief This API is used to send end updating message.
 *
 *
 * @param [in]     unit     - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ecpu_sendUpdateEndMsg(const UI32_T unit);

/**
 * @brief This API is used to update flash firmware.
 *
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     path     - Flash firmware path
 * @param [in]     type     - Application type
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_TIMEOUT          - Time out.
 * @return         CLX_E_NOT_INITED       - No inited.
 */
CLX_ERROR_NO_T
hal_ecpu_updateFlashFw(const UI32_T unit, const C8_T *path, const CLX_UPDATE_TYPE_T type);

/**
 * @brief This API is used to set flash firmware path.
 *
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     path     - Flash firmware path
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_ecpu_setFwPath(const UI32_T unit, const C8_T *path);

/**
 * @brief This API is used to Check whether ecpu is running.
 *
 *
 * @param [in]     unit     - Device unit number
 * @return         TURE            - Ecpu is running.
 * @return         FALSE           - Ecpu is not running.
 */
BOOL_T
hal_ecpu_isRunning(const UI32_T unit);

/**
 * @brief This API is used to create application queue.
 *
 *
 * @param [in]     pname     - Application register name pointer
 * @param [in]     len       - Application register name length
 * @param [out]    pqueue    - Queue handler
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_createAppQue(const C8_T *pname, const UI32_T len, CLX_ELINK_QUEUE_T *pqueue);

/**
 * @brief This API is used to destroy application queue.
 *
 *
 * @param [in]    pqueue    - Queue handler
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_destroyAppQue(CLX_ELINK_QUEUE_T *pqueue);

/**
 * @brief This API is used to get application queue.
 *
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @param [out]   ppqueue   - Queue handler
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_getAppQue(const UI32_T unit, const UI8_T app_id, CLX_ELINK_QUEUE_T **ppqueue);

/**
 * @brief This API is used to clear application queue message buffer.
 *
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_elink_clearAppQue(const UI32_T unit, const UI8_T app_id);

/**
 * @brief This API is used to register application queue to elink.
 *
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @param [in]    pqueue    - Queue handler
 * @param [in]    deinit    - Deinit handler
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_TABLE_FULL       - Table is full.
 * @return         CLX_E_ENTRY_EXISTS     - Application is already registered.
 */
CLX_ERROR_NO_T
hal_elink_registerApp(const UI32_T unit,
                      const UI8_T app_id,
                      CLX_ELINK_QUEUE_T *pqueue,
                      const CLX_APP_DEINIT_FUNC_T deinit);

/**
 * @brief This API is used to deregister application queue to elink.
 *
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_deregisterApp(const UI32_T unit, const UI8_T app_id);

/**
 * @brief This API is used to send message to elink.
 *
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    msg_type  - Message type
 * @param [in]    app_id    - Application id
 * @param [in]    pdata     - Message buffer
 * @param [in]    len       - Message length
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_sendMsg(const UI32_T unit,
                  const CLX_ELINK_DATAMSG_TYPE_T msg_type,
                  const UI8_T app_id,
                  const UI8_T *pdata,
                  const UI16_T len);

/**
 * @brief This API is used to encapsulate the data into an elink request message and send it
 *
 * The memory pointed to by pdata is managed by APP, and elink does not release it.
 * pdata on the SDK side must use the memory requested by osal_alloc.
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @param [in]    pdata     - Message pointer
 * @param [in]    len       - Message length
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_sendReqMsg(const UI32_T unit, const UI8_T app_id, const UI8_T *pdata, const UI16_T len);

/**
 * @brief This API is used to encapsulate the data into an elink response message and send it
 *
 * The memory pointed to by pdata is managed by APP, and elink does not release it.
 * pdata on the SDK side must use the memory requested by osal_alloc.
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @param [in]    pdata     - Message pointer
 * @param [in]    len       - Message length
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_sendRspMsg(const UI32_T unit, const UI8_T app_id, const UI8_T *pdata, const UI16_T len);

/**
 * @brief This API is used to encapsulate the data into an elink notify message and send it
 *
 * The memory pointed to by pdata is managed by APP, and elink does not release it.
 * pdata on the SDK side must use the memory requested by osal_alloc.
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @param [in]    pdata     - Message pointer
 * @param [in]    len       - Message length
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_sendNtfMsg(const UI32_T unit, const UI8_T app_id, const UI8_T *pdata, const UI16_T len);

/**
 * @brief This API is used to receive response message from elink
 *
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @param [out]   ppmsg     - Received message pointer
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_elink_recvRspMsg(const UI32_T unit, UI8_T app_id, void **ppmsg);

/**
 * @brief This API is used to Check whether elink is up.
 *
 *
 * @param [in]     unit     - Device unit number
 * @return         CLX_E_OK            - Elink is up.
 * @return         CLX_E_OTHERS        - Elink is down.
 */
CLX_ERROR_NO_T
hal_elink_isUp(const UI32_T unit);

/**
 * @brief This API is used to register notify callback function.
 *
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @param [in]    func      - Callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ecpu_notify_register(const UI32_T unit, const UI8_T app_id, const CLX_APP_NOTIFY_FUNC_T func);

/**
 * @brief This API is used to unregister notify callback function.
 *
 *
 * @param [in]    unit      - Device unit number
 * @param [in]    app_id    - Application id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ecpu_notify_unregister(const UI32_T unit, const UI8_T app_id);

/**
 * @brief This API is used to start notify thread.
 *
 *
 * @param  [in]    void      - void
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ecpu_notify_start(void);

/**
 * @brief This API is used to stop notify thread.
 *
 *
 * @param    [in]    void      - void
 *
 * @return
 */
void
hal_ecpu_notify_stop(void);

#endif
