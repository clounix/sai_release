/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_pkt.h
 * PURPOSE:
 *    Define the declaration for pkt module.
 *
 * NOTES:
 *    None
 */

#ifndef HAL_MT_PKT_H
#define HAL_MT_PKT_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_pkt.h>
#include <hal/hal_pkt_rsrc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* define c2c key field bits */
#define HAL_MT_PKT_IPV4_KEY_HEADER_LEN_BITS (4)
#define HAL_MT_PKT_KEY_BDID_BITS            (14)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief To set a specify ctrl2cpu entry.
 *
 * Must get the entry first, and then modify the fields want to set.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     index        - The entry index in HW table which user want to set
 * @param [in]     ptr_entry    - The value of the entry user want to set.
 * @return         CLX_E_OK        - Success to set the ctrl2cpu entry.
 * @return         CLX_E_OTHERS    - Fail to set the ctrl2cpu entry.
 */
CLX_ERROR_NO_T
hal_mt_pkt_setCtrlToCpuEntry(const UI32_T unit,
                             const UI32_T index,
                             const CLX_PKT_CTRL_TO_CPU_ENTRY_T *ptr_entry);

/**
 * @brief To get the content of the target entry of ctrl2cpu table
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     index        - The target index
 * @param [out]    ptr_entry    - Pointer to the entry content
 * @return         CLX_E_OK        - Success to get the entry content.
 * @return         CLX_E_OTHERS    - Get the entry content failed.
 */
CLX_ERROR_NO_T
hal_mt_pkt_getCtrlToCpuEntry(const UI32_T unit,
                             const UI32_T index,
                             CLX_PKT_CTRL_TO_CPU_ENTRY_T *ptr_entry);

/**
 * @brief To delete all ctrl-to-CPU entries configured.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Fail
 */
CLX_ERROR_NO_T
hal_mt_pkt_delCtrlToCpuEntryAll(const UI32_T unit);

#endif /* End of HAL_MT_PKT_H */
