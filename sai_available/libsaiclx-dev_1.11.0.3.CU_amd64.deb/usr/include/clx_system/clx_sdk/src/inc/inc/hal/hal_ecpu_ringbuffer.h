/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_ecpu_ringbuffer.h
 * PURPOSE:
 *  1. Provide ring buffer macros and data structures.
 */

#ifndef HAL_MT_ECPU_RINGBUFFER_H
#define HAL_MT_ECPU_RINGBUFFER_H

#define HAL_RING_BUFFER_BLOCK_SIZE   (1024 * 32)
#define HAL_RING_BUFFER_CONTROL_SIZE (1024)                     /*ring buffer control area size*/
#define HAL_RING_BUFFER_SIZE \
    (HAL_RING_BUFFER_BLOCK_SIZE - HAL_RING_BUFFER_CONTROL_SIZE) /*ring buffer data area size*/
#define HAL_RING_BUFFER_BUFFER_SIZE (256)                       /*each buffer size*/

#define HAL_RING_BUFFER_OFFSET (0xf0000) /*Offset address of ring buffer in ITCM :64k*/

#ifdef CONFIG_ECPU_SIDE
#define HAL_RING_BUFFER_RXBUFF_ADDR (HAL_MT_NAMCHABARWA_ECPU_ITCMBASE + HAL_RING_BUFFER_OFFSET)
#define HAL_RING_BUFFER_RXBUFF_BASE \
    (HAL_RING_BUFFER_RXBUFF_ADDR + HAL_RING_BUFFER_CONTROL_SIZE) /*ecpu rxbuf*/

#define HAL_RING_BUFFER_TXBUFF_ADDR \
    (HAL_RING_BUFFER_RXBUFF_ADDR + HAL_RING_BUFFER_BLOCK_SIZE)   /*next 32k memory block*/
#define HAL_RING_BUFFER_TXBUFF_BASE \
    (HAL_RING_BUFFER_TXBUFF_ADDR + HAL_RING_BUFFER_CONTROL_SIZE) /*ecpu txbuf*/
#else
#define HAL_RING_BUFFER_TXBUFF_ADDR (HAL_MT_NAMCHABARWA_ECPU_ITCMBASE_CHAIN + HAL_RING_BUFFER_OFFSET)
#define HAL_RING_BUFFER_TXBUFF_BASE (HAL_RING_BUFFER_TXBUFF_ADDR + HAL_RING_BUFFER_CONTROL_SIZE)

#define HAL_RING_BUFFER_RXBUFF_ADDR (HAL_RING_BUFFER_TXBUFF_ADDR + HAL_RING_BUFFER_BLOCK_SIZE)
#define HAL_RING_BUFFER_RXBUFF_BASE (HAL_RING_BUFFER_RXBUFF_ADDR + HAL_RING_BUFFER_CONTROL_SIZE)
#endif

#define RESET_RING_DB(pdb)      \
    {                           \
        (pdb)->data_offset = 0; \
        (pdb)->size = 0;        \
        (pdb)->sop = 0;         \
        (pdb)->eop = 0;         \
    }

typedef struct hal_ring_buffer_descriptor {
    UI16_T size; /*length of data in the buffer*/
    UI8_T sop;   /*start of data*/
    UI8_T eop;   /*end of data*/
    UI32_T data_offset;
    UI32_T buf_addr;
} HAL_RING_DB_T;

typedef struct hal_ring_buf {
    struct hal_ring_buf *frags;
    const UI8_T *pdata;
    UI32_T offset;
    UI16_T len; /*data length*/
} HAL_RING_BUF_T;

typedef struct hal_ring_buffer_info {
    UI32_T ring_base;
    UI32_T write_idx;
    UI32_T read_idx;
    UI32_T ring_size; /*The number of buffers*/
    UI32_T size;      /*The length of each buffer*/
    UI32_T buf_base;
    HAL_RING_DB_T db[0];
} HAL_RING_INFO_T;

typedef struct hal_ring_buffer {
#ifdef CONFIG_ECPU_SIDE
    struct k_sem sem_sync;
    HAL_RING_INFO_T *pring;
#else
    CLX_SEMAPHORE_ID_T sem_sync;
    HAL_RING_INFO_T ring;
#endif
    UI32_T base; /*Ecpu memory address on chain or in soc*/
} HAL_RING_CTL_T;

/**
 * @brief This API is used to init received buffer.
 *
 *
 * @param [in]     pbuf         - The received buffer.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ring_buf_initRxbuf(HAL_RING_CTL_T *pbuf);

/**
 * @brief This API is used to init send buffer.
 *
 *
 * @param [in]     pbuf         - The send buffer.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_ring_buf_initTxbuf(HAL_RING_CTL_T *pbuf);

/**
 * @brief This API is used to get the number of free buffers.
 *
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     pring         - Ring buffer control block.
 *
 * @return         UI32_T               - The number of free buffers.
 */
UI32_T
hal_ring_buf_getFreeBufNum(const UI32_T unit, HAL_RING_CTL_T *pring);

/**
 * @brief This API is used to read data from ring buffer.
 *
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     pring        - Ring buffer control block.
 * @param [in]     ppdata       - Pointer to the data read from the ring buffer.
 *
 * @return         CLX_E_OK               - Successfully read ring buffer.
 * @return         CLX_E_ENTRY_NOT_FOUND  - Ring buffer is empty.
 * @return         CLX_E_NO_MEMORY        - Failed to osal_alloc memory.
 * @return         CLX_E_OTHERS           - Failed to read ring buffer.
 */
CLX_ERROR_NO_T
hal_ring_buf_readBuf(const UI32_T unit, HAL_RING_CTL_T *pring, void **ppdata);

/**
 * @brief This API is used to write data to the ring buffer.
 *
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     pring        - Ring buffer control block.
 * @param [in]     pbuf         - Pointer for the written data.
 *
 * @return         CLX_E_OK               - Successfully read ring buffer.
 * @return         CLX_E_OTHERS           - Failed to read ring buffer.
 */
CLX_ERROR_NO_T
hal_ring_buf_writeBuf(const UI32_T unit, HAL_RING_CTL_T *pring, HAL_RING_BUF_T *pbuf);

/**
 * @brief This API is used to get ring buffer read index.
 *
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     pinfo        - Pointer to ring info descriptor.
 * @param [out]    pindex       - Pointer to read index.
 *
 * @return         CLX_E_OK               - Successfully read ring buffer.
 * @return         CLX_E_OTHERS           - Failed to read ring buffer.
 */
CLX_ERROR_NO_T
hal_ring_buf_getReadIdx(const UI32_T unit, HAL_RING_INFO_T *pinfo, UI32_T *pindex);

/**
 * @brief This API is used to get ring buffer write index.
 *
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     pinfo        - Pointer to ring info descriptor.
 * @param [out]    pindex       - Pointer to write index.
 *
 * @return         CLX_E_OK               - Successfully read ring buffer.
 * @return         CLX_E_OTHERS           - Failed to read ring buffer.
 */
CLX_ERROR_NO_T
hal_ring_buf_getWriteIdx(const UI32_T unit, HAL_RING_INFO_T *pinfo, UI32_T *pindex);

#endif
