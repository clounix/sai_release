/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_vlan.h
 * PURPOSE:
 *  Define the declartion for VLAN module for CL8360, CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_VLAN_H
#define HAL_VLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_swc.h>
#include <clx_vlan.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* for setServiceRslt HAL API */
#define HAL_VLAN_SRV_RSLT_FLAGS_IGR_IS_NEW       (1U << 0)
#define HAL_VLAN_SRV_RSLT_FLAGS_EGR_IS_NEW       (1U << 1)
#define HAL_VLAN_SRV_RSLT_FLAGS_EGR_ALW_PRIO_TAG (1U << 2)
#define HAL_VLAN_SRV_RSLT_FLAGS_LRN_COPY2        (1U << 3)
#define HAL_VLAN_SRV_RSLT_FLAGS_ALW_QINQ_TRANS_C (1U << 4)

/* for getHwVidCtl */
#define HAL_VLAN_VID_CTL_FLAGS_KEEP_FRM_VID (1U << 0)
#define HAL_VLAN_VID_CTL_FLAGS_NO_L2        (1U << 1)

/********** IDS_RSLT_SRV_FDID **********/
#define HAL_VLAN_FDID_ENTRY_NUM (16384)
#define HAL_VLAN_FDID_ENTRY_MIN (1)
#define HAL_VLAN_FDID_ENTRY_MAX (16382) /* 16K - 2 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_VLAN_VID_CTL_S {
    HAL_VID_CTL_TYP_ENUM_T vid_ctl;
    UI16_T vid_1st;
    UI16_T vid_2nd;
} HAL_VLAN_VID_CTL_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */

/**
 * @brief Init vlan module.
 *
 * 1) Create default vlan and add all port as untagged member.
 * 2) Create default bridge domain and bind default vlan to that.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK                - Operate success.
 * @return         CLX_E_ALREADY_INITED    - Unexpected init.
 * @return         CLX_E_OTHER             - Init fail.
 */
CLX_ERROR_NO_T
hal_vlan_init(const UI32_T unit);

/**
 * @brief Deinit vlan module.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK            - Operate success.
 * @return         CLX_E_NOT_INITED    - Unexpected deinit.
 * @return         CLX_E_OTHER         - Init fail.
 */
CLX_ERROR_NO_T
hal_vlan_deinit(const UI32_T unit);

/**
 * @brief Apply default vlan related properties for the new created port:
 *        (1) Join default vlan as untagged member port
 *        (2) Join default vlan flooding member
 *
 * (1) CLX/Hw design support modify member port of an un-active VLAN.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port number
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Operate fail.
 */
CLX_ERROR_NO_T
hal_vlan_setPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief Reset default vlan related properties for the deleted port:
 *        (1) Remove from default vlan member port
 *        (2) Remove from default vlan flooding member
 *
 * (1) CLX/Hw design support modify member port of an un-active VLAN.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port number
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Operate fail.
 */
CLX_ERROR_NO_T
hal_vlan_resetPortDefault(const UI32_T unit, const UI32_T port);

/**
 * @brief Dump db for debug.
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     flags    - Reference HAL_VLAN_DB_DUMP_FLAGS_XXX
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_dumpDb(const UI32_T unit, const UI32_T flags);

/**
 * @brief Dump table/register for debug.
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     flags    - Reference HAL_VLAN_REG_DUMP_FLAGS_XXX
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_dumpReg(const UI32_T unit, const UI32_T flags);

/**
 * @brief Create a vlan entry.
 *
 * 1. Default member/untagged member is empty.
 * 2. NOT create a bridge domain & binding the vlan to that bridge domain.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vid     - 802.1Q VLAN associated with the entry.
 *                           The 802.1Q VLAN id range is 1-4094.
 * @return         CLX_E_OK              - Operate success.
 * @return         CLX_E_ENTRY_EXISTS    - Duplicated create.
 * @return         CLX_E_OTHER           - Operate fail.
 */
CLX_ERROR_NO_T
hal_vlan_createVlan(const UI32_T unit, const UI32_T vid);

/**
 * @brief Delete a vlan entry.
 *
 * 1. Clear member/untagged member is empty.
 * 2. Unbinding with the bridge domainm, but not destroy that bridge domain.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vid     - 802.1Q VLAN associated with the entry.
 *                           The 802.1Q VLAN id range is 1-4095.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Unexpected delete.
 * @return         CLX_E_OTHER              - Operate fail.
 */
CLX_ERROR_NO_T
hal_vlan_delVlan(const UI32_T unit, const UI32_T vid);

/**
 * @brief Create a bridge domain.
 *
 * Will enable fdid only.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - The Bridge domain id started from 1.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vlan_createBridgeDomain(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief Destory a forwarding domain entry.
 *
 * Will disable fdid only.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - L2 bridge domain id started from 1.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vlan_destroyBridgeDomain(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief Set properties of the bridge domain.
 *
 * User should create this bridge domain before setting property.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     bdid        - Vlan or BD ID
 * @param [in]     property    - Property type
 * @param [in]     param0      - First parameter
 * @param [in]     param1      - Second parameter
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_setProperty(const UI32_T unit,
                     const CLX_BRIDGE_DOMAIN_T bdid,
                     const CLX_VLAN_PROPERTY_T property,
                     const UI32_T param0,
                     const UI32_T param1);

/**
 * @brief Get properties of the bridge domain.
 *
 * User should create this bridge domain before getting property.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     bdid        - Bridge domain id
 * @param [in]     property    - Property type
 * @param [out]    ptr_param0  - First parameter
 * @param [out]    ptr_param1  - Second parameter
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_getProperty(const UI32_T unit,
                     const CLX_BRIDGE_DOMAIN_T bdid,
                     const CLX_VLAN_PROPERTY_T property,
                     UI32_T *ptr_param0,
                     UI32_T *ptr_param1);

/**
 * @brief Set vlan-based service l2.
 *
 * Should create VLAN and bridge domain first.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     vid        - VLAN id.
 * @param [in]     ptr_srv    - Service control.
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_setService(const UI32_T unit, const CLX_VLAN_T vid, const CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Get vlan-based service l2.
 *
 * Should create VLAN first.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     vid        - VLAN id.
 * @param [out]    ptr_srv    - Service control.
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter
 * @return         CLX_E_OTHERS       - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_getService(const UI32_T unit, const CLX_VLAN_T vid, CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Add member and untag port list of existing vlan entry.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_entry         - VLAN and port member entry.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
CLX_ERROR_NO_T
hal_vlan_setPort(const UI32_T unit, const CLX_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Get a vlan entry with specified 802.1Q vlan.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_entry         - Fileld "vlan".
 * @param [out]    ptr_entry         - Fileld "port_bitmap" and "ut_port_bitmap".
 * @return         CLX_E_OK                 - Operation is success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry in VLAN table.
 */
CLX_ERROR_NO_T
hal_vlan_getPort(const UI32_T unit, CLX_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Traverse vlan tagged/untagged member port for active vlan.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function to be called for each traversed vlan entry
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
hal_vlan_traverseEntry(const UI32_T unit,
                       const CLX_VLAN_ENTRY_TRAVERSE_FUNC_T callback,
                       void *ptr_cookie);

/**
 * @brief Add a mac-based vlan entry.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - MAC VLAN entry
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_TABLE_FULL       - No more memory
 */
CLX_ERROR_NO_T
hal_vlan_addMacVlan(const UI32_T unit, const CLX_VLAN_MAC_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Delete a mac-based vlan entry.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Field "mac"
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
hal_vlan_delMacVlan(const UI32_T unit, const CLX_VLAN_MAC_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Get a mac-based vlan entry.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Field "mac"
 * @param [out]    ptr_entry    - Field "vlan", "pcp" and "dei"
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
hal_vlan_getMacVlan(const UI32_T unit, CLX_VLAN_MAC_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Set a type vlan assignment entry.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     index         - The index number of the entry.
 * @param [in]     ptr_entry     - Consist of protocol-related and common L2 fields.
 * @param [in]     ptr_action    - Assigned actions of vlan info.
 * @return         CLX_E_OK                 - Operation is success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry in VLAN table.
 */
CLX_ERROR_NO_T
hal_vlan_setTypeEntry(const UI32_T unit,
                      const UI32_T index,
                      const CLX_VLAN_CLASSIFY_TYPE_T *ptr_entry,
                      const CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Get a type vlan assignment entry.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     index         - The index number of the entry.
 * @param [out]    ptr_entry     - Consist of protocol-related and common L2 fields.
 * @param [out]    ptr_action    - Assigned actions of vlan info.
 * @return         CLX_E_OK                 - Operation is success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry in VLAN table.
 */
CLX_ERROR_NO_T
hal_vlan_getTypeEntry(const UI32_T unit,
                      const UI32_T index,
                      CLX_VLAN_CLASSIFY_TYPE_T *ptr_entry,
                      CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Set a address-based vlan assignment entry.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     index         - The index number of the entry.
 * @param [in]     ptr_entry     - Consist of mac/subnet-related and common L2 fields.
 * @param [in]     ptr_action    - Assigned actions of vlan info.
 * @return         CLX_E_OK               - Operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_vlan_setAddrEntry(const UI32_T unit,
                      const UI32_T index,
                      const CLX_VLAN_CLASSIFY_ADDR_T *ptr_entry,
                      const CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Get a address-based vlan assignment entry.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     index         - The index number of the entry.
 * @param [in]     ptr_entry     - flags(CLX_VLAN_CLASSIFY_ADDR_FLAGS_IPV6_ENTRY)
 * @param [out]    ptr_entry     - Consist of mac/subnet-related and common L2 fields.
 * @param [out]    ptr_action    - Assigned actions of vlan info.
 * @return         CLX_E_OK                 - Operation is success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry in VLAN table.
 */
CLX_ERROR_NO_T
hal_vlan_getAddrEntry(const UI32_T unit,
                      const UI32_T index,
                      CLX_VLAN_CLASSIFY_ADDR_T *ptr_entry,
                      CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief add pvlan entry for a primary vlan.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     primary_vlan       - 802.1Q VLAN associated with the entry.
 *                                      The 802.1Q VLAN id range is 1-4094.
 * @param [in]     ptr_pvlan_entry    - The pvlan entry will be set.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
CLX_ERROR_NO_T
hal_vlan_addPvlanEntry(const UI32_T unit,
                       const UI32_T primary_vlan,
                       const CLX_VLAN_PVLAN_ENTRY_T *ptr_pvlan_entry);

/**
 * @brief delete pvlan entry for a primary vlan.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     primary_vlan    - 802.1Q VLAN associated with the entry.
 *                                   The 802.1Q VLAN id range is 1-4094.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
CLX_ERROR_NO_T
hal_vlan_delPvlanEntry(const UI32_T unit, const UI32_T primary_vlan);

/**
 * @brief get pvlan entry for a primary vlan.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     primary_vlan       - 802.1Q VLAN associated with the entry.
 *                                      The 802.1Q VLAN id range is 1-4094.
 * @param [out]    ptr_pvlan_entry    - The pvlan entry will be set.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
CLX_ERROR_NO_T
hal_vlan_getPvlanEntry(const UI32_T unit,
                       const UI32_T primary_vlan,
                       CLX_VLAN_PVLAN_ENTRY_T *ptr_pvlan_entry);

/************************************/
/* EXPOSED HAL PROGRAMS             */
/************************************/
/**
 * @brief [HAL] Configure ingress/egress service hw table with default value
 *
 * 1. Should allocate srv idx by each module.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     srv_idx    - Index of service table
 * @param [in]     dir        - Configure igr/egr/both service table
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_initServiceRslt(const UI32_T unit, const UI32_T srv_idx, const CLX_DIR_T dir);

/**
 * @brief [HAL] Configure ingress/egress service hw table
 *
 * 1. Should allocate srv idx by each module.
 * 2. Should create bridge domain first.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     srv_idx              - Index of service table
 * @param [in]     dir                  - Configure igr/egr/both service table
 * @param [in]     ptr_srv              - Service control
 * @param [in]     sst                  - Per service suppression tag value (0-31)
 * @param [in]     flags                - [0] igr_is_new: 1 means first config this igr srv idx,
 * will skip igr resource check
 *                                        -- [1] egr_is_new: 1 means first config this egr srv idx,
 * will skip egr resource check
 *                                        -- [2] alw_prio_tag = 1 - Allow egress frame content
 * priority tag 0 - pop priority tag
 *                                        -- please reference HAL_VLAN_SRV_RSLT_FLAGS_
 * @param [in]     set_vid_ctl_as_is    - Set IEV_RSLT_U_L2.vid_ctl = as_is
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_setServiceRslt(const UI32_T unit,
                        const UI32_T srv_idx,
                        const CLX_DIR_T dir,
                        const CLX_PORT_SEG_SRV_T *ptr_srv,
                        const UI32_T sst,
                        const UI32_T flags,
                        const UI32_T set_vid_ctl_as_is);

/**
 * @brief [HAL] Get configured ingress/egress service hw table
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     srv_idx    - Index of service table
 * @param [in]     dir        - Get igr/egr/both service table
 * @param [out]    ptr_srv    - Service control
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_getServiceRslt(const UI32_T unit,
                        const UI32_T srv_idx,
                        const CLX_DIR_T dir,
                        CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief [HAL] Free all profile idx in service entry allocated by setServiceRslt.
 *
 * Will NOT free service entry since srv_idx in controlled by each module.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     srv_idx    - Index of service table
 * @param [in]     dir        - Configure igr/egr/both service table
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
CLX_ERROR_NO_T
hal_vlan_freeServiceRsltProf(const UI32_T unit, const UI32_T srv_idx, const CLX_DIR_T dir);

/**
 * @brief [HAL] Translate interface view precedence to hw view precedence value.
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     precedence           - User interface view precedence
 * @param [out]    ptr_hw_precedence    - Hw interface view precedence
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate failed
 */
CLX_ERROR_NO_T
hal_vlan_transIntfToHwPrecedence(const UI32_T unit,
                                 const CLX_VLAN_PRECEDENCE_T precedence,
                                 UI32_T *ptr_hw_precedence);

/**
 * @brief [HAL] Translate hw view precedence to interface view precedence value.
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hw_precedence     - Hw interface view precedence
 * @param [out]    ptr_precedence    - User interface view precedence
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Operate failed
 */
CLX_ERROR_NO_T
hal_vlan_transHwToIntfPrecedence(const UI32_T unit,
                                 const UI32_T hw_precedence,
                                 CLX_VLAN_PRECEDENCE_T *ptr_precedence);

/**
 * @brief Set igr/egr vlan filtering enable/disable.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     dir       - Config igr or egr setting
 * @param [in]     enable    - Enable/Disable vlan filtering
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
hal_vlan_setVlanFilter(const UI32_T unit,
                       const UI32_T port,
                       const CLX_DIR_T dir,
                       const UI32_T enable);

/**
 * @brief Get igr/egr vlan filtering enable/disable.
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     port      - Physical port id
 * @param [in]     dir       - Config igr or egr getting
 * @param [out]    ptr_enable       - Filter enable/disable
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
hal_vlan_getVlanFilter(const UI32_T unit,
                       const UI32_T port,
                       const CLX_DIR_T dir,
                       UI32_T *ptr_enable);

/**
 * @brief Check given port is used as following scenario which allow learning keep:
 *        1. PVLAN trunk port
 *        2. QinQ NNI port
 *        3. Remote port (cannot check, treated as not-allow)
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port (native/unit/lag port)
 * @return         CLX_E_OK               - Check pass
 * @return         CLX_E_BAD_PARAMETER    - Check fail
 */
CLX_ERROR_NO_T
hal_vlan_checkPortUseVlanKeep(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get hw-view vid_ctl/1st/2nd from user-view vlan action for end-point port
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     vlan_act    - User-view vlan action
 * @param [in]     ptr_tag_act - Tag vlan action
 * @param [in]     flags       - Refer HAL_VLAN_VID_CTL_FLAGS_*
 * @param [out]    ptr_vid_ctl - Hw-view vid_ctl/1st/2nd
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
hal_vlan_transToHwVidCtl(const UI32_T unit,
                         const CLX_VLAN_ACTION_T vlan_act,
                         const CLX_VLAN_TAG_ACTION_T *ptr_tag_act,
                         const UI32_T flags,
                         HAL_VLAN_VID_CTL_T *ptr_vid_ctl);

/**
 * @brief Get user-view vlan action from hw-view vid_ctl for end-point port
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     ptr_vid_ctl    - Hw-view vid_ctl/1st/2nd
 * @param [in]     flags          - Refer HAL_VLAN_VID_CTL_FLAGS_*
 * @param [out]    ptr_vlan_act   - User-view vlan action
 * @param [out]    ptr_tag_act    - Vlan tag info
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
hal_vlan_transToSwVlanAct(const UI32_T unit,
                          const HAL_VLAN_VID_CTL_T *ptr_vid_ctl,
                          const UI32_T flags,
                          CLX_VLAN_ACTION_T *ptr_vlan_act,
                          CLX_VLAN_TAG_ACTION_T *ptr_tag_act);

/**
 * @brief Get capacity of vlan-related hw resource type
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Vlan-related hw resource type
 * @param [in]     param       - Optional parameter
 * @param [out]    ptr_size    - Capacity size
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_vlan_getCapacity(const UI32_T unit,
                     const CLX_SWC_RSRC_T type,
                     const UI32_T param,
                     UI32_T *ptr_size);

/**
 * @brief Get used of vlan-related hw resource type
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - Vlan-related hw resource type
 * @param [in]     param      - Optional parameter
 * @param [out]    ptr_cnt    - Count of usage
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
hal_vlan_getUsage(const UI32_T unit, const CLX_SWC_RSRC_T type, const UI32_T param, UI32_T *ptr_cnt);

/**
 * @brief Set keep dei setting
 *
 * 1. CL8360 not support (not register in cmn drv vector)
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     enable    - Keep dei is enable or not
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
hal_vlan_setKeepDei(const UI32_T unit, const UI32_T enable);

/**
 * @brief Get keep dei setting
 *
 * 1. CL8360 not support (not register in cmn drv vector)
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    ptr_enable    - Keep dei is enable or not
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
hal_vlan_getKeepDei(const UI32_T unit, UI32_T *ptr_enable);

/**
 * @brief Bind fdid to the L3 intf
 *
 * 1. NB not support (no need to bind bd to L3 intf)
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - Bridge domain ID
 * @param [in]     bind    - Bind L3 intf to the BD or not
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
hal_vlan_bindL3Intf(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid, const BOOL_T bind);

/**
 * @brief Print created bridge domain ID
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success
 */
CLX_ERROR_NO_T
hal_vlan_printCreatedBdId(const UI32_T unit);

/**
 * @brief This function is to get VLAN chip configurable information.
 *
 * @param [in]     unit     - Device unit number, get chip configuration is required, but get global
 * configuration is not required
 * @param [in]     type     - Type for get chip configurable information
 * @param [in]     para0    - Parameter0 if necessary
 * @param [in]     para1    - Parameter1 if necessary
 *                            ptr_value
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         other                - Operate fail
 */
CLX_ERROR_NO_T
hal_vlan_getChipCfgInfo(const UI32_T unit,
                        const CLX_SWC_CHIP_CFG_INFO_TYPE_T type,
                        const UI32_T para0,
                        const UI32_T para1,
                        UI32_T *ptr_value);

#endif /* End of HAL_VLAN_H */
