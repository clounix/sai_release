/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_namchabarwa_ecc.h
 * PURPOSE:
 *  Provide HAL ECC manipulation APIs for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_ECC_H
#define HAL_MT_NAMCHABARWA_ECC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_ecc.h>
#include <clx_swc.h>
#include <hal/hal_ecc.h>
#include <hal/mountain/hal_mt_intr.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_MT_CDB_FPUHSH_SLV_HASH_TILE_MAX          (24)  /* max tile num */
#define HAL_MT_CDB_FPUHSH_SLV_HASH_MEM_MAX           (25)  /* memory max num per tile */
#define HAL_MT_CDB_FPUHSH_SLV_HASH_MEM_LINE_NUM_MAX  (128) /* line max num per memory */
#define HAL_MT_CDB_FPUHSH_SLV_HASH_MEM_ENTRY_NUM_MAX (8)   /* entry max num per line(ipv4) */
#define HAL_MT_ECC_SERR_TYPE                         (0)
#define HAL_MT_ECC_DERR_TYPE                         (1)
#define HAL_MT_ECC_INVALID_TYPE                      (0xFF)

#define HAL_MT_ECC_HANDLE_THREAD_PRI   (50)
#define HAL_MT_ECC_HANDLE_THREAD_STACK (32 * 1024)

/* in 4 FPU entry is same for 25.6T, \
 * 12.8T: FPU0 and FPU2 entry is same FPU1 and FPU3 is same */
#define HAL_MT_ECC_FPU_NUM (2)

/* table id type for malloc cache */
typedef enum {
    /* TDS table id */
    HAL_ECC_TDS_HSH_BDO = 0,
    HAL_ECC_TDS_DIR_POC,

    /* DIS table id */
    HAL_ECC_DIS_HSH_BDI_MEM,
    HAL_ECC_DIS_DIR_LCL,

    /* FPU table id */
    HAL_ECC_FPU_L2,
    HAL_ECC_FPU_L3,
    HAL_ECC_FPU_MPLS,
    HAL_ECC_FPU_SRV6,

    HAL_ECC_CACHED_LAST, /* cache array max num */
} HAL_ECC_CACHE_TABLE_TYPE_T;

typedef struct HAL_ECC_CACHE_MEMORY_TABLE_INFO_S {
    /* define table data and valid */
    UI32_T table_id;   /* cached table id */
    UI32_T valid;      /* table valid if enable ecc */
    UI32_T table_size; /* all entry size for the table_id */

    /* 25.6T: 4 fpu in NB, and table entry content is same in every fpu */
    UI8_T *ptr_data; /* point to data memory. malloc data memory, if enable ecc recovery. per slc
                        per pointer?? */

} HAL_ECC_CACHE_MEMORY_TABLE_INFO_T;

typedef struct HAL_ECC_CACHE_MEMORY_ALL_TABLE_S { /* for sram table in tds/dis/rwi/rwo */
    HAL_ECC_CACHE_MEMORY_TABLE_INFO_T cache_tab_info;
    CLX_SEMAPHORE_ID_T mutex_sema_id;

} HAL_ECC_CACHE_MEMORY_ALL_TABLE_T;

typedef struct HAL_ECC_CACHE_MEMORY_S { /* for sram table in fpu */
    HAL_ECC_CACHE_MEMORY_TABLE_INFO_T cache_tab_info;
    /* fpu has 24 tile, lock cache table per tile */
    CLX_SEMAPHORE_ID_T mutex_sema_id[HAL_MT_CDB_FPUHSH_SLV_HASH_TILE_MAX];

} HAL_ECC_CACHE_MEMORY_FPU_TABLE_T;

extern HAL_ECC_CACHE_MEMORY_FPU_TABLE_T
    _hal_mt_namchabarwa_ecc_fpu_cache_table[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_MT_ECC_FPU_NUM];

/* MACRO  DECLARATIONS
 */

#define HAL_MT_ECC_ARRAY_SIZE(__array__) (sizeof(__array__) / sizeof(__array__[0]))

#define HAL_MT_NAMCHABARWA_ECC_CB_LOCK(_unit_)                                    \
    HAL_COMMON_LOCK_RESOURCE(&_hal_mt_namchabarwa_ecc_cb[(_unit_)].mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)

#define HAL_MT_NAMCHABARWA_ECC_CB_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_mt_namchabarwa_ecc_cb[(_unit_)].mutex_sema_id)

/* 针对每个缓存表添加lock，在区分到具体table后，加锁。防止在处理L3的时候，L2过来write缓存表，此时被锁住的情况发生
 */
#define HAL_MT_NAMCHABARWA_ECC_CACHE_LOCK(_unit_, _inst_, _table_id_, _bank_bmp_)      \
    do {                                                                               \
        UI32_T _inst_idx_ = 0;                                                         \
        if (CDB_TABLE(_unit_, _table_id_)->duplicate_type == HAL_HW_DUP_TYPE_FPU) {    \
            if (HAL_IS_DEVICE_NAMCHABARWA_12_8T_FAMILY(_unit_)) {                      \
                if (_inst_ == CDB_ODD_INST_IDX_BCAST || _inst_ == 1 || _inst_ == 3) {  \
                    _inst_idx_ = 1;                                                    \
                }                                                                      \
            }                                                                          \
            for (int _tile_idx_ = 0; _tile_idx_ < HAL_MT_CDB_FPUHSH_SLV_HASH_TILE_MAX; \
                 _tile_idx_++) {                                                       \
                if ((_bank_bmp_) & (1 << _tile_idx_)) {                                \
                    HAL_COMMON_LOCK_RESOURCE(                                          \
                        &_hal_mt_namchabarwa_ecc_fpu_cache_table[(_unit_)][_inst_idx_] \
                             .mutex_sema_id[_tile_idx_],                               \
                        CLX_SEMAPHORE_WAIT_FOREVER);                                   \
                }                                                                      \
            }                                                                          \
        }                                                                              \
    } while (0);

#define HAL_MT_NAMCHABARWA_ECC_CACHE_UNLOCK(_unit_, _inst_, _table_id_, _bank_bmp_)    \
    do {                                                                               \
        UI32_T _inst_idx_ = 0;                                                         \
        if (CDB_TABLE(_unit_, _table_id_)->duplicate_type == HAL_HW_DUP_TYPE_FPU) {    \
            if (HAL_IS_DEVICE_NAMCHABARWA_12_8T_FAMILY(_unit_)) {                      \
                if (_inst_ == CDB_ODD_INST_IDX_BCAST || _inst_ == 1 || _inst_ == 3) {  \
                    _inst_idx_ = 1;                                                    \
                }                                                                      \
            }                                                                          \
            for (int _tile_idx_ = 0; _tile_idx_ < HAL_MT_CDB_FPUHSH_SLV_HASH_TILE_MAX; \
                 _tile_idx_++) {                                                       \
                if ((_bank_bmp_) & (1 << _tile_idx_)) {                                \
                    HAL_COMMON_FREE_RESOURCE(                                          \
                        &_hal_mt_namchabarwa_ecc_fpu_cache_table[(_unit_)][_inst_idx_] \
                             .mutex_sema_id[_tile_idx_]);                              \
                }                                                                      \
            }                                                                          \
        }                                                                              \
    } while (0);

#define HAL_MT_ECC_CHECK_RC_RETURN(_rc_, _module_, _level_, format, arg...) \
    do {                                                                    \
        if (_rc_ != CLX_E_OK) {                                             \
            DIAG_PRINT(_module_, _level_, "rc:%u, " format, _rc_, ##arg);   \
            return _rc_;                                                    \
        }                                                                   \
    } while (0);

#define HAL_MT_ECC_CHECK_RC_NOT_RETURN(_rc_, _module_, _level_, format, arg...) \
    do {                                                                        \
        if (_rc_ != CLX_E_OK) {                                                 \
            DIAG_PRINT(_module_, _level_, "rc:%u, " format, _rc_, ##arg);       \
        }                                                                       \
    } while (0);

#define HAL_MT_ECC_CHECK_RC_GOTO(_rc_, _module_, _level_, _goto_, format, arg...) \
    do {                                                                          \
        if (_rc_ != CLX_E_OK) {                                                   \
            DIAG_PRINT(_module_, _level_, "rc:%u, " format, _rc_, ##arg);         \
            goto _goto_;                                                          \
        }                                                                         \
    } while (0);

/* DATA TYPE DECLARATIONS
 */

/* register for recover double ecc error */
typedef void (*HAL_ECC_RECOVERY_NOTIFY_FUNC_T)(const UI32_T unit,
                                               const UI32_T inst_idx,
                                               const UI32_T subinst_idx,
                                               const UI32_T table_id,
                                               const UI32_T entry_idx,
                                               const UI32_T data_size,
                                               const UI32_T *ptr_data);

typedef void (*HAL_ECC_ENTRY_BLOCKED_NOTIFY_FUNC_T)(const UI32_T unit,
                                                    const UI32_T inst_idx,
                                                    const UI32_T subinst_idx,
                                                    const UI32_T table_id,
                                                    const UI32_T entry_idx,
                                                    const UI32_T entry_cnt,
                                                    void *ptr_data);

typedef struct {
    UI32_T serr_irq_id; /* SLV single error irq register id, such as
                           MT_REG_FPUHSH_SLV_IRQS_HASH_IRQS_MEM_0_SERR_IRQ_ID */
    UI32_T derr_irq_id; /* SLV double error irq register id, such as
                           MT_REG_FPUHSH_SLV_IRQS_HASH_IRQS_MEM_0_DERR_IRQ_ID */
} HAL_MT_ECC_SERR_DERR_REG_ID;

typedef struct HAL_MT_NAMCHABARWA_ECC_CB_S {
    CLX_SEMAPHORE_ID_T mutex_sema_id;

    HAL_ECC_LOG_INFO_T log_arr[HAL_ECC_LOG_NUM];
    UI32_T next_log_entry_id;

    /* add callback register for recovery or notify ecc always happend */
    HAL_ECC_RECOVERY_NOTIFY_FUNC_T recovery_cb; /* recover ecc table by each service */
    /* notify L2/L3 after rewrite table entry by dirty data */
    HAL_ECC_ENTRY_BLOCKED_NOTIFY_FUNC_T entry_blocked_ntf_cb;
} HAL_MT_NAMCHABARWA_ECC_CB_T;

typedef enum {
    HAL_ECC_CFG_REG_TYPE_GEN_EN = 0,
    HAL_ECC_CFG_REG_TYPE_DETECT_EN,
    HAL_ECC_CFG_REG_TYPE_CORRECT_EN,
    HAL_ECC_CFG_REG_TYPE_CAPTURE_EN,
    HAL_ECC_CFG_REG_TYPE_CAPTURE_DERR_ONLY,

} HAL_ECC_CFG_REG_TYPE_T;
typedef struct _HAL_ECC_CFG_S {
    HAL_ECC_CFG_REG_TYPE_T reg_type; /* register type: gen_en/detect_en */
    UI32_T table_id;                 /* cfg regist table id */
    UI32_T table_words;              /* number of words occupied by this table id */
} HAL_ECC_CFG_REG_T;

/* FUNCTION MACRO DECLARATIONS
 */

/**
 * @brief This API is used to write cache table when L2/L3 addHash or write entry in FPU
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     inst_idx       - inst index
 * @param [in]     subinst_idx    - subinst index
 * @param [in]     tab_id         - table id
 * @param [in]     entry_index    - Entry index in table.
 * @param [in]     entry_size     - Entry size.
 * @param [in]     ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecc_writeCacheTable(const UI32_T unit,
                                       const UI32_T inst_idx,
                                       const UI32_T subinst_idx,
                                       const UI32_T tab_id,
                                       const UI32_T entry_index,
                                       const UI32_T entry_size,
                                       UI32_T *ptr_entry);

/**
 * @brief This API is used to delete cache table when L2/L3 addHash or write entry in FPU
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     inst_idx       - inst index
 * @param [in]     subinst_idx    - subinst index
 * @param [in]     tab_id         - table id
 * @param [in]     entry_index    - Entry index in table.
 * @param [in]     entry_size     - Entry size.
 * @param [in]     ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecc_delCacheTable(const UI32_T unit,
                                     const UI32_T inst_idx,
                                     const UI32_T subinst_idx,
                                     const UI32_T tab_id,
                                     const UI32_T entry_index,
                                     const UI32_T entry_size,
                                     UI32_T *ptr_entry);

/**
 * @brief This API is used to get table id by tile index for FPU
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     tile_index     - Tile index, max is HAL_SWC_HASH_TILE_NUM
 * @param [out]    ptr_table_id   - Output table id if the tile index.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecc_tileIdGetTableId(const UI32_T unit,
                                        const UI32_T tile_index,
                                        UI32_T *ptr_table_id);

/**
 * @brief This API is used to get cached hash table entry by one line(8 entry)
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     inst           - Inst index
 * @param [in]     table_id       - Table id
 * @param [in]     tile_index     - Tile index, max is HAL_SWC_HASH_TILE_NUM
 * @param [in]     mem_idx        - Memory index of each tile.
 * @param [in]     line_idx       - Line index of each memofy.
 * @param [out]    ptr_data       - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecc_getHashCachedLineEntry(const UI32_T unit,
                                              const UI32_T inst,
                                              const UI32_T table_id,
                                              const UI32_T tile_index,
                                              const UI32_T mem_idx,
                                              const UI32_T line_idx,
                                              UI32_T *ptr_data);

/**
 * @brief This API is used to get cached direct entry
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     inst           - Inst index
 * @param [in]     table_id       - Table id
 * @param [in]     entry_index    - Entry index in table.
 * @param [out]    ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecc_getDirectCache(const UI32_T unit,
                                      const UI32_T inst,
                                      const UI32_T table_id,
                                      const UI32_T entry_index,
                                      UI32_T *ptr_entry);

/**
 * @brief This API is used to handle interrupt
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     ptr_cookie     - Interrupt HAL_MT_INTR_REG_NODE_T info
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
hal_mt_namchabarwa_ecc_handleIntr(const UI32_T unit, void *ptr_cookie);

/**
 * @brief This API is used to recover HW entry from cached entry data.
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     inst_idx       - inst index
 * @param [in]     subinst_idx    - subinst index
 * @param [in]     table_id       - table id
 * @param [in]     entry_index    - Entry index in table.
 * @param [in]     ptr_cached_data - Pointer to the cached entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
_hal_mt_namchabarwa_ecc_recoverFromCache(const UI32_T unit,
                                         const UI32_T inst_idx,
                                         const UI32_T subinst_idx,
                                         const UI32_T table_id,
                                         const UI32_T entry_index,
                                         UI32_T *ptr_cached_data);

#endif /* #ifndef HAL_MT_NAMCHABARWA_ECC_H */
