/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_lag.h
 * PURPOSE:
 *    Provide sflow hal layer api.
 *
 * NOTES:
 *
 */

#ifndef HAL_LT_LAG_H
#define HAL_LT_LAG_H

#define HAL_LT_LAG_PORT_LIST_ENTRY_NUM    (1024)
#define HAL_LT_LAG_PORT_LIST_ENTRY_ID_MAX (HAL_LT_LAG_PORT_LIST_ENTRY_NUM - 1)

CLX_ERROR_NO_T
hal_lt_lag_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_lag_searchFdl(const UI32_T unit, const UI32_T lag_id, UI32_T *ptr_fdl_grp_idx);

CLX_ERROR_NO_T
hal_lt_lag_allocateFdl(const UI32_T unit, const UI32_T lag_id, UI32_T *ptr_fdl_grp_idx);

CLX_ERROR_NO_T
hal_lt_lag_enableFdlGroupByDi(const UI32_T unit,
                              const UI32_T member_di,
                              const UI32_T fdl_grp_idx,
                              const UI32_T enable);

CLX_ERROR_NO_T
hal_lt_lag_clearFdlStatic(const UI32_T unit,
                          const UI32_T ori_member_cnt,
                          const UI32_T *ptr_ori_member_di);

CLX_ERROR_NO_T
hal_lt_lag_enableFdlGroup(const UI32_T unit,
                          const UI32_T lag_id,
                          const UI32_T fdl_grp_idx,
                          const UI32_T enable,
                          const CLX_FDL_INFO_T *ptr_fdl_info);

CLX_ERROR_NO_T
hal_lt_lag_syncMemberForFdl(const UI32_T unit,
                            const UI32_T lag_id,
                            const UI32_T fdl_grp_idx,
                            const UI32_T add_member_cnt,
                            const UI32_T *ptr_add_member_di,
                            const UI32_T del_member_cnt,
                            const UI32_T *ptr_del_member_di);

CLX_ERROR_NO_T
hal_lt_lag_freeOriActList(const UI32_T unit, const UI32_T lag_id, HAL_LAG_INFO_T *ptr_lag_info);

CLX_ERROR_NO_T
hal_lt_lag_allocOriActList(const UI32_T unit, const UI32_T lag_id, HAL_LAG_INFO_T *ptr_lag_info);

CLX_ERROR_NO_T
hal_lt_lag_setBackupEpochMcPathAutoUpdate(const UI32_T unit,
                                          const UI32_T master_epoch,
                                          const UI32_T backup_epoch,
                                          const UI32_T orig_member_cnt,
                                          const UI32_T *ptr_orig_member_di,
                                          const UI32_T new_member_cnt_mod,
                                          const UI32_T *ptr_new_member_di_mod,
                                          const HAL_LAG_INFO_T *ptr_new_lag_info,
                                          const UI32_T new_member_cnt,
                                          const UI32_T *ptr_new_member_di,
                                          const UI32_T del_member_cnt,
                                          const UI32_T *ptr_del_member_di);

CLX_ERROR_NO_T
hal_lt_lag_updateMasterEpochMcPath(const UI32_T unit,
                                   const UI32_T master_epoch,
                                   const UI32_T backup_epoch);

CLX_ERROR_NO_T
hal_lt_lag_setMemberPortSi(const UI32_T unit,
                           const UI32_T lag_di,
                           const UI32_T add_member_cnt,
                           const UI32_T *ptr_add_member_di,
                           const UI32_T del_member_cnt,
                           const UI32_T *ptr_del_member_di);

CLX_ERROR_NO_T
hal_lt_lag_getInfo(const UI32_T unit,
                   const UI32_T lag_id,
                   UI32_T *ptr_member_cnt,
                   UI32_T *ptr_member_di,
                   HAL_LAG_INFO_T *ptr_lag_info);

CLX_ERROR_NO_T
hal_lt_lag_setInfo(const UI32_T unit, const UI32_T lag_id, const HAL_LAG_INFO_T *ptr_lag_info);

CLX_ERROR_NO_T
hal_lt_lag_setAttr(const UI32_T unit, const CLX_PORT_T lag_port, const CLX_LAG_ATTRIB_T *ptr_attr);

CLX_ERROR_NO_T
hal_lt_lag_getAttr(const UI32_T unit, const CLX_PORT_T lag_port, CLX_LAG_ATTRIB_T *ptr_attr);

CLX_ERROR_NO_T
hal_lt_lag_getMemberCnt(const UI32_T unit, const CLX_PORT_T lag_port, UI32_T *ptr_member_cnt);

CLX_ERROR_NO_T
hal_lt_lag_createMglag(const UI32_T unit, const UI32_T flags, UI32_T *ptr_mglag_id);

CLX_ERROR_NO_T
hal_lt_lag_destroyMglag(const UI32_T unit, const UI32_T mglag_id);

CLX_ERROR_NO_T
hal_lt_lag_setMglagMbr(const UI32_T unit,
                       const UI32_T mglag_id,
                       const UI32_T member_cnt,
                       const UI32_T *ptr_member);

CLX_ERROR_NO_T
hal_lt_lag_getMglagMbr(const UI32_T unit,
                       const UI32_T mglag_id,
                       const UI32_T member_cnt,
                       UI32_T *ptr_member,
                       UI32_T *ptr_actual_member_cnt);

CLX_ERROR_NO_T
hal_lt_lag_getMglagMbrCnt(const UI32_T unit, const UI32_T mglag_id, UI32_T *ptr_member_cnt);

CLX_ERROR_NO_T
hal_lt_lag_getLagMemberCnt(const UI32_T unit, const CLX_PORT_T lag_port, UI32_T *ptr_member_cnt);

#endif /* End of HAL_LT_LAG_H */
