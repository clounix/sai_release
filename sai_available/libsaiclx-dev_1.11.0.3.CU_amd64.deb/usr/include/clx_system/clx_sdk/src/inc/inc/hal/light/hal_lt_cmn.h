/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_cmn.h
 * PURPOSE:
 *  1. To maintain common internal utility API, such as src_supp_tag management,
 *     or exception code management.
 * NOTES:
 */

#ifndef HAL_LT_CMN_H
#define HAL_LT_CMN_H

/* INCLUDE FILE DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    /* ep with port-prune */
    HAL_LT_CMN_SST_ROLE_EP_START = 0,
    HAL_LT_CMN_SST_ROLE_EP_PORT_PRUNE_START = HAL_LT_CMN_SST_ROLE_EP_START,
    HAL_LT_CMN_SST_ROLE_NORMAL = HAL_LT_CMN_SST_ROLE_EP_PORT_PRUNE_START,
    HAL_LT_CMN_SST_ROLE_PVLAN_START,
    HAL_LT_CMN_SST_ROLE_PVLAN_P = HAL_LT_CMN_SST_ROLE_PVLAN_START,
    HAL_LT_CMN_SST_ROLE_PVLAN_IT,
    HAL_LT_CMN_SST_ROLE_PVLAN_I,
    HAL_LT_CMN_SST_ROLE_PVLAN_C0,
    HAL_LT_CMN_SST_ROLE_PVLAN_C1,
    HAL_LT_CMN_SST_ROLE_PVLAN_C2,
    HAL_LT_CMN_SST_ROLE_PVLAN_C3,
    HAL_LT_CMN_SST_ROLE_PVLAN_C4,
    HAL_LT_CMN_SST_ROLE_PVLAN_END = HAL_LT_CMN_SST_ROLE_PVLAN_C4,
    HAL_LT_CMN_SST_ROLE_MCLAGX_EP_ON_START,
    HAL_LT_CMN_SST_ROLE_MCLAG0_EP_ON = HAL_LT_CMN_SST_ROLE_MCLAGX_EP_ON_START,
    HAL_LT_CMN_SST_ROLE_MCLAG1_EP_ON,
    HAL_LT_CMN_SST_ROLE_MCLAG2_EP_ON,
    HAL_LT_CMN_SST_ROLE_MCLAG3_EP_ON,
    HAL_LT_CMN_SST_ROLE_MCLAG4_EP_ON,
    HAL_LT_CMN_SST_ROLE_MCLAG5_EP_ON,
    HAL_LT_CMN_SST_ROLE_MCLAGX_EP_ON_END = HAL_LT_CMN_SST_ROLE_MCLAG5_EP_ON,
    HAL_LT_CMN_SST_ROLE_MCLAGX_EP_OFF_START,
    HAL_LT_CMN_SST_ROLE_MCLAG0_EP_OFF = HAL_LT_CMN_SST_ROLE_MCLAGX_EP_OFF_START,
    HAL_LT_CMN_SST_ROLE_MCLAG1_EP_OFF,
    HAL_LT_CMN_SST_ROLE_MCLAG2_EP_OFF,
    HAL_LT_CMN_SST_ROLE_MCLAG3_EP_OFF,
    HAL_LT_CMN_SST_ROLE_MCLAG4_EP_OFF,
    HAL_LT_CMN_SST_ROLE_MCLAG5_EP_OFF,
    HAL_LT_CMN_SST_ROLE_MCLAGX_EP_OFF_END = HAL_LT_CMN_SST_ROLE_MCLAG5_EP_OFF,
    HAL_LT_CMN_SST_ROLE_EP_PORT_PRUNE_END = HAL_LT_CMN_SST_ROLE_MCLAGX_EP_OFF_END,
    HAL_LT_CMN_SST_ROLE_VM,
    HAL_LT_CMN_SST_ROLE_EP_END = HAL_LT_CMN_SST_ROLE_VM,
    /* uplink */
    HAL_LT_CMN_SST_ROLE_UP_START,
    HAL_LT_CMN_SST_ROLE_NV_UP = HAL_LT_CMN_SST_ROLE_UP_START,
    HAL_LT_CMN_SST_ROLE_TRILL_UP,
    HAL_LT_CMN_SST_ROLE_MPLS_UP,
    HAL_LT_CMN_SST_ROLE_MCLAGX_UP_START,
    HAL_LT_CMN_SST_ROLE_MCLAG0_UP = HAL_LT_CMN_SST_ROLE_MCLAGX_UP_START,
    HAL_LT_CMN_SST_ROLE_MCLAG1_UP,
    HAL_LT_CMN_SST_ROLE_MCLAG2_UP,
    HAL_LT_CMN_SST_ROLE_MCLAG3_UP,
    HAL_LT_CMN_SST_ROLE_MCLAG4_UP,
    HAL_LT_CMN_SST_ROLE_MCLAG5_UP,
    HAL_LT_CMN_SST_ROLE_MCLAGX_UP_END = HAL_LT_CMN_SST_ROLE_MCLAG5_UP,
    HAL_LT_CMN_SST_ROLE_UP_END = HAL_LT_CMN_SST_ROLE_MCLAGX_UP_END,
    /* last */
    HAL_LT_CMN_SST_ROLE_VALID_LAST = HAL_LT_CMN_SST_ROLE_UP_END,
    HAL_LT_CMN_SST_ROLE_BYPASS_PRUNE = 31 /* HW bypass prune when sst all 1 */
} HAL_LT_CMN_SST_ROLE_T;

#define HAL_LT_CMN_TRANS_TO_LRN_SST(__sst__)                           \
    do {                                                               \
        if (HAL_LT_CMN_SST_ROLE_PVLAN_IT == (__sst__)) {               \
            (__sst__) = HAL_LT_CMN_SST_ROLE_PVLAN_P;                   \
        } else if (((__sst__) >= HAL_LT_CMN_SST_ROLE_MCLAG0_EP_ON) &&  \
                   ((__sst__) <= HAL_LT_CMN_SST_ROLE_MCLAG5_EP_OFF)) { \
            (__sst__) = HAL_LT_CMN_SST_ROLE_NORMAL;                    \
        } else if (((__sst__) >= HAL_LT_CMN_SST_ROLE_MCLAG0_UP) &&     \
                   ((__sst__) <= HAL_LT_CMN_SST_ROLE_MCLAG5_UP)) {     \
            (__sst__) = HAL_LT_CMN_SST_ROLE_TRILL_UP;                  \
        }                                                              \
    } while (0)

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Common Hw resource table/lock init.
 *
 * For lightning.
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_cmn_init(const UI32_T unit);

/**
 * @brief Common Hw resource table/lock deinit.
 *
 * For lightning.
 *
 * @param [in]     unit    - device unit number
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_cmn_deinit(const UI32_T unit);

/**
 * @brief configure nvo3_encap_idx's egress path,
 *        including nvo3_adj and nvo3_ecmp
 *
 * This api configures a tunnel's output to nvo3_adj or nvo3_ecmp.
 * It handles the following scenarios:
 * # N/A       -> nvo3_adj/nvo3_ecmp
 * # nvo3_adj  -> nvo3_adj/nvo3_ecmp
 * # nvo3_ecmp -> nvo3_adj/nvo3_ecmp
 * User only needs to input ptr_buf if output_type=nvo3_adj.
 * Both nvo3_adj/nvo3_ecmp would save into swdb (To sync with L3RteNode)
 *
 * @param [in]     unit                 - device unit number
 * @param [in]     nvo3_encap_idx       - index to IEV_RSLT_NVO3_ENCAP
 * @param [in]     output_type          - nvo3_ecmp or nvo3_adj
 * @param [in]     output_id            - nvo3_ecmp_id or nvo3_adj_id
 * @param [in]     ptr_path_buf         - cdb_buf of IEV_RSLT_ECMP_PATH_U_EP_L3 (nvo3_adj only)
 * @param [in]     pptr_nvo3_adj_arr    - Array of pointer to first node of each nvo3_adj_id
 * @param [in]     ptr_path_avl         - Avl head of path_idx
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_cmn_addNvo3Route(const UI32_T unit,
                        const UI32_T nvo3_encap_idx,
                        const CLX_L3_OUTPUT_TYPE_T output_type,
                        const UI32_T output_id,
                        const UI32_T *ptr_path_buf,
                        HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                        CMLIB_AVL_HEAD_T *ptr_path_avl);

CLX_ERROR_NO_T
hal_lt_cmn_delNvo3Route(const UI32_T unit,
                        const UI32_T nvo3_encap_idx,
                        HAL_CMN_RTE_NODE_T **pptr_nvo3_adj_arr,
                        CMLIB_AVL_HEAD_T *ptr_path_avl);

/**
 * @brief add or set IEV_RSLT_U_xxx's usage of l3_output (ecmp or adj) to swdb
 *
 * @param [in]     unit           - device unit number
 * @param [in]     iev_idx        - index to IEV_RSLT_U_xxx
 * @param [in]     output_type    - ecmp or adj
 * @param [in]     output_id      - ecmp_id or adj_id
 * @param [in]     ptr_adj_avl    - pointer to adj_avl
 * @param [in]     ptr_iev_avl    - pointer to iev_avl
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_cmn_addIevL3RteNode(const UI32_T unit,
                           const UI32_T iev_idx,
                           const CLX_L3_OUTPUT_TYPE_T output_type,
                           const UI32_T output_id,
                           CMLIB_AVL_HEAD_T *ptr_adj_avl,
                           CMLIB_AVL_HEAD_T *ptr_iev_avl);

/**
 * @brief remove IEV_RSLT_U_xxx's usage of l3_output (ecmp or adj) to swdb
 *
 * @param [in]     unit           - device unit number
 * @param [in]     iev_idx        - index to IEV_RSLT_U_xxx
 * @param [in]     ptr_adj_avl    - pointer to adj_avl
 * @param [in]     ptr_iev_avl    - pointer to iev_avl
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_cmn_delIevL3RteNode(const UI32_T unit,
                           const UI32_T iev_idx,
                           CMLIB_AVL_HEAD_T *ptr_adj_avl,
                           CMLIB_AVL_HEAD_T *ptr_iev_avl);

/**
 * @brief Get rte_node from avl by specified id
 *
 * whether id is iev_idx or adj_id is determined by which input avl is not NULL
 * (e.g.) if ptr_adj_avl != NULL, id is adj_id
 *
 * @param [in]     unit           - device unit number
 * @param [in]     id             - iev_idx or adj_id (depends on which avl is not NULL)
 * @param [in]     ptr_adj_avl    - pointer to adj_avl
 * @param [in]     ptr_iev_avl    - pointer to iev_avl
 * @param [out]    pptr_node      - found rte_node
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_cmn_getIevL3RteNode(const UI32_T unit,
                           const UI32_T id,
                           CMLIB_AVL_HEAD_T *ptr_adj_avl,
                           CMLIB_AVL_HEAD_T *ptr_iev_avl,
                           HAL_CMN_RTE_NODE_T **pptr_node);

/**
 * @brief save set-l3-adj-swdb for warm-deinit
 *
 * @param [in]     ptr_adj_avl     - pointer to adj_avl
 * @param [in]     ptr_iev_avl     - pointer to iev_avl
 * @param [in]     ptr_obj_meta    - Object Meta for the nonvolatile storage
 * @param [out]    ptr_obj_meta    - Object Meta for the nonvolatile storage
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_cmn_saveIevL3RteNodes(CMLIB_AVL_HEAD_T *ptr_adj_avl,
                             CMLIB_AVL_HEAD_T *ptr_iev_avl,
                             HAL_IO_OBJ_META_T *ptr_obj_meta);

/**
 * @brief restore set-l3-adj-swdb for warm-init
 *
 * @param [in]     unit            - device unit number
 * @param [in]     ptr_adj_avl     - pointer to adj_avl
 * @param [in]     ptr_iev_avl     - pointer to iev_avl
 * @param [in]     ptr_obj_meta    - Object Meta for the nonvolatile storage
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
hal_lt_cmn_restoreIevL3RteNodes(const UI32_T unit,
                                CMLIB_AVL_HEAD_T *ptr_adj_avl,
                                CMLIB_AVL_HEAD_T *ptr_iev_avl,
                                const HAL_IO_OBJ_META_T *ptr_obj_meta);

#endif
