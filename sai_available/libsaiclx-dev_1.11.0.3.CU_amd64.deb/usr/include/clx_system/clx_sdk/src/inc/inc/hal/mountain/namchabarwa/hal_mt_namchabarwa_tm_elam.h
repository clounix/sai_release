/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_namchabarwa_tm.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_MT_NAMCHABARWA_TM_ELAM_H
#define HAL_MT_NAMCHABARWA_TM_ELAM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>
#include <clx_swc.h>
#include <clx_tm.h>

typedef struct HAL_TM_MT_NAMCHABARWA_TCB_IPP2PDBWR_S {
    UI32_T drop_reason_code : 6;
    UI32_T sport : 6;
    UI32_T rec_vld : 1;
    UI32_T frag_size : 8;
    UI32_T eop : 1;
    UI32_T sop : 1;
    UI32_T rsv_fd : 4;
    UI32_T pkj : 1;
    UI32_T meter_color : 2;
    UI32_T flow_hash : 10;
    UI32_T cpa_en : 1;
    UI32_T acl_redirect_trunc_en : 1;
    UI32_T mod_en : 1;
    UI32_T mirror_session : 8;
    UI32_T pkt_size : 14;
    UI32_T ct_mode : 1;
    UI32_T cpu_queue : 6;
    UI32_T cpu_dest : 2;
    UI32_T cpu_redir : 1;
    UI32_T cpu_valid : 1;
    UI32_T tc : 3;
    UI32_T int_clone : 1;
    UI32_T int_mode : 2;
    UI32_T int_role : 2;
    UI32_T di : 16;
    UI32_T rsvd_pd : 3;
    UI32_T valid : 1;
    UI32_T resverved : 24;
} HAL_TM_MT_NAMCHABARWA_TCB_IPP2PDBWR_T;

typedef struct HAL_TM_MT_NAMCHABARWA_TCB_PDBRD2EPP_S {
    UI32_T pd_fifo_num : 2;
    UI32_T dport : 6;
    UI32_T error : 1;
    UI32_T frag_size : 8;
    UI32_T eop : 1;
    UI32_T sop : 1;
    UI32_T rsvd_fd : 4;
    UI32_T trunc : 1;
    UI32_T cpa_mark : 1;
    UI32_T ecn_mark : 1;
    UI32_T cud_value : 16;
    UI32_T cud_type : 5;
    UI32_T oq : 12;
    UI32_T pkt_size : 14;
    UI32_T rsvd_pd : 3;
    UI32_T vld : 1;
    UI32_T resverved0 : 19;
    UI32_T resverved1 : 32;
} HAL_TM_MT_NAMCHABARWA_TCB_PDBRD2EPP_T;

typedef enum {
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_TBL_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_TBL_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_LAST_TBL_ID
} HAL_MT_NAMCHABARWA_TM_ELAM_TBL_ID;

typedef enum {
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_FD_PD_FIFO_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_FD_DPORT_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_FD_ERROR_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_FD_FRAG_SIZE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_FD_EOP_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_FD_SOP_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_FD_RSVD_FD_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_PD_TRUNC_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_PD_CPA_MARK_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_PD_ECN_MARK_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_PD_CUD_VALUE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_PD_CUD_TYPE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_PD_OQ_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_PD_PKT_SIZE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_PD_RSVD_PD_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_VALID_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_RESERVED_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_LAST_FIELD_ID
} HAL_MT_NAMCHABARWA_TM_ELAM_PDBRD2EPP_FIELD_ID;

typedef enum {
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_FD_DROP_REASON_CODE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_FD_SPORT_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_FD_RCV_VLD_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_FD_FRAG_SIZE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_FD_EOP_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_FD_SOP_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_FD_RSVD_FD_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_PKJ_JOURNAL_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_METER_COLOR_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_FLOW_HASH_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_CPA_EN_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_ACL_REDIRECT_TRUNC_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_MOD_EN_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_MIRROR_SESSION_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_PKT_SIZE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_CT_MODE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_CPU_QID_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_CPU_DEST_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_CPU_REDIR_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_CPU_VALID_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_TC_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_INT_CLONE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_INT_MODE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_INT_ROLE_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_DI_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_PD_RSVD_PD_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_VALID_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_RESERVED_FIELD_ID,
    HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_LAST_FIELD_ID
} HAL_MT_NAMCHABARWA_TM_ELAM_IPP2PDBWR_FIELD_ID;

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_tcb_init(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_tcb_setCaptureKey(const UI32_T unit,
                                        const HAL_TM_TCB_CAPTURE_KEY_T *ptr_capture);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_tcb_getCaptureKey(const UI32_T unit, HAL_TM_TCB_CAPTURE_KEY_T *ptr_capture);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_tcb_getCaptureData(const UI32_T unit,
                                         const UI32_T count,
                                         UI32_T *ptr_real_count,
                                         HAL_TM_TCB_CAPTURE_DATA_T *ptr_capture_data_list);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_tcb_start(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_tcb_clear(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_elam_init(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_elam_setTriggerConfig(const UI32_T unit,
                                            const HAL_TM_ELAM_TRIGGER_CONFIG_T *ptr_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_elam_getTriggerConfig(const UI32_T unit,
                                            HAL_TM_ELAM_TRIGGER_CONFIG_T *ptr_cfg);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_elam_setTriggerKey(const UI32_T unit,
                                         const HAL_TM_ELAM_TRIGGER_KEY_T *ptr_trigger_key);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_elam_getTriggerKey(const UI32_T unit,
                                         HAL_TM_ELAM_TRIGGER_KEY_T *ptr_trigger_key);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_elam_start(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_elam_clear(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_elam_getCaptureData(const UI32_T unit,
                                          const UI32_T count,
                                          UI32_T *ptr_real_count,
                                          HAL_TM_ELAM_CAPTURE_DATA_T *ptr_trigger_data_list);
void
hal_mt_namchabarwa_tm_tcb_showSwPktBuf(const UI32_T unit);

void
hal_mt_namchabarwa_tm_tcb_showSwTrigData(const UI32_T unit);

CLX_ERROR_NO_T
hal_mt_namchabarwa_tm_tcb_showHwStatus(const UI32_T unit);

#endif /* #ifndef HAL_MT_NAMCHABARWA_TM_ELAM_H */
