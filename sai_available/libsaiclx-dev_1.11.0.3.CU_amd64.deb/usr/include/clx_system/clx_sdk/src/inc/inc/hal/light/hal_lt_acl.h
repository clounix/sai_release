/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_acl.h
 * PURPOSE:
 *    Provide HAL driver API functions of ACL module.
 *
 * NOTES:
 *
 */

#ifndef HAL_LT_ACL_H
#define HAL_LT_ACL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_acl.h>
#include <hal/hal_l3.h>
#include <hal/hal_cmn.h>
#include <hal/hal_acl.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_LT_ACL_KEY_1X_WORDS          (LT_CDB_ICIA_KEY_TCAM_1X_U_L2_WORDS)
#define HAL_LT_ACL_PLANE_PORT_BITS       (34)
#define HAL_LT_ACL_DA_SA_LBL_BITS        (12)
#define HAL_LT_ACL_UDF_INT_INTF_LBL_BITS (10)
#define HAL_LT_ACL_UDF_INT_VID_BITS      (13)
#define HAL_LT_ACL_UDF_INT_PCP_DEI_BITS  (5)
#define HAL_LT_ACL_UDF_KEY_BITS          (208)
#define HAL_LT_ACL_UDF_PKG_BITS          (9) /* HAL_ACL_UDF_PKG_DATA_BITS + 1 (valid bit)*/
/* CL8360 IDS_RSLT_FLW_PKG_PROF_TLV_LST words */
#define HAL_LT_ACL_FLW_PKG_PROF_TLV_LST_WORDS_MAX (35)
#define HAL_LT_ACL_PGK_TLV_BYTE_OFF_EXTR_END_BIT  (7) /* not support in CL8360 */
#define HAL_LT_ACL_NON_ENCODE_TCP_FLAGS_VLD_BMP   (0x7f)
#define HAL_LT_ACL_FCM_1X_TLV_BITS                (72)
#define HAL_LT_ACL_FCM_2X_TLV_BITS                (144)
#define HAL_LT_ACL_FCM_4X_TLV_BITS                (296)
#define HAL_LT_ACL_FCM_4X_TLV_WORDS               (10)
#define HAL_LT_ACL_INVALID_CP_TO_CPU_IDX          (0)
#define HAL_LT_ACL_COPY_TO_CPU_IDX_MAX            (8) /* only accept cp to cpu reason (0+1)~(7+1) */
#define HAL_LT_ACL_PGK_TLV_BYTE_OFF_MAX           (0x7f)

/* qos/fwd action flags of CLX_ACL_ACTION_T_T (union of CL8360/Non-CL8360) */
#define HAL_LT_ACL_QOS_ACTION_FLAGS                                                               \
    (CLX_ACL_ACTION_FLAGS_METER_VALID | CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_BLIND |             \
     CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_GREEN | CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_YELLOW | \
     CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_RED)
#define HAL_LT_ACL_FWD_ACTION_FLAGS                                                     \
    (CLX_ACL_ACTION_FLAGS_DROP | CLX_ACL_ACTION_FLAGS_TO_CPU_DROP |                     \
     CLX_ACL_ACTION_FLAGS_CANCEL_LEARN | CLX_ACL_ACTION_FLAGS_BYPASS_RPF_CHECK_FAIL |   \
     CLX_ACL_ACTION_FLAGS_BYPASS_TTL_CHECK_FAIL | CLX_ACL_ACTION_FLAGS_ALLOW_STEERING | \
     CLX_ACL_ACTION_FLAGS_REDIRECT | CLX_ACL_ACTION_FLAGS_KEEP_TTL |                    \
     CLX_ACL_ACTION_FLAGS_PKT_REWRITE | CLX_ACL_ACTION_FLAGS_TS_REPLACE_MAC)

typedef enum {
    HAL_LT_CIA_KEY_TCAM_PKG = 0,
    HAL_LT_CIA_KEY_TCAM_L2 = 1,
    HAL_LT_CIA_KEY_TCAM_FCOE = 2,
    HAL_LT_CIA_KEY_TCAM_L3_IPV4 = 3,
    HAL_LT_CIA_KEY_TCAM_L3_IPV6 = 4,
    HAL_LT_CIA_KEY_TCAM_ARP = 5,
    HAL_LT_CIA_KEY_TCAM_ARP_W_L2 = 6,
    HAL_LT_CIA_KEY_TCAM_W_L2 = 7
} HAL_LT_CIA_TYP_ENUM_T;

#define HAL_LT_ACL_GET_ENTRY_TBL_ID(__tbl_id__, __type__, __norm_width__) \
    do {                                                                  \
        if (CLX_ACL_GROUP_INGRESS == (__type__)) {                        \
            switch ((__norm_width__)) {                                   \
                case (1):                                                 \
                    (__tbl_id__) = LT_TBL_ICIA_COM_TCAM_1X_ID;            \
                    break;                                                \
                case (2):                                                 \
                    (__tbl_id__) = LT_TBL_ICIA_COM_TCAM_2X_ID;            \
                    break;                                                \
                default: /* 4 */                                          \
                    (__tbl_id__) = LT_TBL_ICIA_COM_TCAM_4X_ID;            \
                    break;                                                \
            }                                                             \
        } else /* CLX_ACL_GROUP_EGRESS == (__type__) */                   \
        {                                                                 \
            switch ((__norm_width__)) {                                   \
                case (1):                                                 \
                    (__tbl_id__) = LT_TBL_ECIA_COM_TCAM_1X_ID;            \
                    break;                                                \
                case (2):                                                 \
                    (__tbl_id__) = LT_TBL_ECIA_COM_TCAM_2X_ID;            \
                    break;                                                \
                default: /* 4 */                                          \
                    (__tbl_id__) = LT_TBL_ECIA_COM_TCAM_4X_ID;            \
                    break;                                                \
            }                                                             \
        }                                                                 \
    } while (0)

#define HAL_LT_ACL_GET_REWR_1X_IDX(__rewr_1x_idx__, __rewr_page__, __fcm_1x_idx__) \
    do {                                                                           \
        (__rewr_1x_idx__) = ((__rewr_page__) << 10) + ((__fcm_1x_idx__) & 0x3ff);  \
    } while (0)

CLX_ERROR_NO_T
hal_lt_acl_checkGroup(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T prio,
                      const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile);

CLX_ERROR_NO_T
hal_lt_acl_addGroup(const UI32_T unit,
                    const CLX_ACL_GROUP_T type,
                    const UI32_T prio,
                    const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile,
                    UI32_T *ptr_group_id);

CLX_ERROR_NO_T
hal_lt_acl_setGroup(const UI32_T unit,
                    const CLX_ACL_GROUP_T type,
                    const UI32_T prio,
                    const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile,
                    UI32_T group_id);

CLX_ERROR_NO_T
hal_lt_acl_freeEntryAllocRsrc(const UI32_T unit,
                              const CLX_ACL_GROUP_T type,
                              const HAL_ACL_ENTRY_ALLOC_INFO_T *ptr_alloc_info);

CLX_ERROR_NO_T
hal_lt_acl_resetUcp(const UI32_T unit, const CLX_ACL_GROUP_T type, UI32_T ucp_bmp);

CLX_ERROR_NO_T
hal_lt_acl_getGroupProfile(const UI32_T unit,
                           const CLX_ACL_GROUP_T type,
                           const UI32_T group_id,
                           const UI32_T ucp_member_bmp,
                           CLX_ACL_GROUP_PROFILE_T *ptr_group_profile);

CLX_ERROR_NO_T
hal_lt_acl_getUcpPbmEn(const UI32_T unit,
                       const CLX_ACL_GROUP_T type,
                       const UI32_T group,
                       UI32_T *ptr_ucp_pbm_en);

CLX_ERROR_NO_T
hal_lt_acl_setAclPkgProf(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_prof_id,
                         const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile,
                         UI32_T *ptr_acl_pkg_vld,
                         UI32_T *ptr_pkg_0_cnt,
                         UI32_T *ptr_pkg_1_cnt,
                         UI32_T *ptr_pkg_0_consecutive_bmp,
                         UI32_T *ptr_pkg_1_consecutive_bmp);

CLX_ERROR_NO_T
hal_lt_acl_setFlwPkgProf(const UI32_T unit,
                         const UI32_T udf_prof_id,
                         const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile,
                         UI32_T *ptr_flw_pkg_vld,
                         UI32_T *ptr_flw_1_pkg_vld,
                         UI32_T *ptr_consecutive_bmp);

CLX_ERROR_NO_T
hal_lt_acl_setPkgLouProfIdx(const UI32_T unit,
                            const CLX_ACL_GROUP_T type,
                            const UI32_T udf_prof_id,
                            const UI32_T flw_pkg_vld,
                            const UI32_T pkg_vld,
                            const UI32_T lou_vld);

CLX_ERROR_NO_T
hal_lt_acl_setTcamPkgLou(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_key_profile_id,
                         const BOOL_T valid,
                         const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format);

CLX_ERROR_NO_T
hal_lt_acl_getPktFormat(const UI32_T unit,
                        const CLX_ACL_GROUP_T type,
                        const UI32_T udf_prof_id,
                        const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                        CLX_ACL_PKT_FORMAT_T *ptr_pkt_format);

CLX_ERROR_NO_T
hal_lt_acl_getPkgLouProfIdx(const UI32_T unit,
                            const CLX_ACL_GROUP_T type,
                            const UI32_T udf_prof_id,
                            UI32_T *ptr_flw_pkg_prof_vld,
                            UI32_T *ptr_flw_pkg_prof_idx,
                            UI32_T *ptr_acl_pkg_prof_vld,
                            UI32_T *ptr_acl_pkg_prof_idx,
                            UI32_T *ptr_lou_prof_vld,
                            UI32_T *ptr_lou_prof_idx);

CLX_ERROR_NO_T
hal_lt_acl_getAclPkgProf(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T acl_pkg_prof_idx,
                         const UI32_T acl_pkg_prof_vld,
                         const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                         CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

CLX_ERROR_NO_T
hal_lt_acl_getFlwPkgProf(const UI32_T unit,
                         const UI32_T flw_pkg_prof_idx,
                         const HAL_ACL_UDF_INFO_T *ptr_udf_info,
                         CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

CLX_ERROR_NO_T
hal_lt_acl_getLouProf(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T udf_prof_id,
                      const UI32_T lou_id,
                      const HAL_ACL_LOU_INFO_T *ptr_lou_info,
                      CLX_ACL_LOU_CFG_T *ptr_lou);

CLX_ERROR_NO_T
hal_lt_acl_setLouProf(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T udf_prof_id,
                      const UI32_T lou_id,
                      const CLX_ACL_LOU_CFG_T *ptr_lou);

CLX_ERROR_NO_T
hal_lt_acl_getAclPkgProfLouInfo(const UI32_T unit,
                                const CLX_ACL_GROUP_T type,
                                const UI32_T acl_pkg_prof_idx,
                                UI32_T *ptr_acl_int_lou_vld,
                                UI32_T *ptr_acl_lou_en);

CLX_ERROR_NO_T
hal_lt_acl_getFlwPkgProfLouInfo(const UI32_T unit,
                                const UI32_T flw_pkg_prof_idx,
                                UI32_T *ptr_flw_int_lou_vld,
                                UI32_T *ptr_flw_lou_en,
                                UI32_T *ptr_flw_1_int_lou_vld,
                                UI32_T *ptr_flw_1_lou_en);

CLX_ERROR_NO_T
hal_lt_acl_setFlwPkgProfLouEn(const UI32_T unit,
                              const UI32_T flw_pkg_prof_idx,
                              const UI32_T lou_id,
                              const UI32_T flw_int_lou_vld,
                              const UI32_T flw_lou_en,
                              const UI32_T flw_1_int_lou_vld,
                              const UI32_T flw_1_lou_en);

CLX_ERROR_NO_T
hal_lt_acl_setAclPkgProfLouEn(const UI32_T unit,
                              const CLX_ACL_GROUP_T type,
                              const UI32_T acl_pkg_prof_idx,
                              const UI32_T acl_lou_en);

CLX_ERROR_NO_T
hal_lt_acl_getFlwUdfKeyInfo(const UI32_T unit,
                            const CLX_ACL_CLASSIFY_T *ptr_classify,
                            HAL_ACL_FLOW_ENTRY_PACK_UDF_KEY_T *ptr_flw_udf_key,
                            UI32_T *ptr_udf_prof_flw_key_typ);

CLX_ERROR_NO_T
hal_lt_acl_getUdfKeyInfo(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T group,
                         const CLX_ACL_CLASSIFY_T *ptr_classify,
                         HAL_ACL_ENTRY_PACK_UDF_KEY_T *ptr_udf_key);

/**
 * @brief The API is used to add/set an UCP entry from HW for light series.
 *
 * If both ptr_classify and ptr_action are NULL, the API will only modify valid bit of entry.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     entry_id        - entry id
 * @param [in]     entry_valid     - The status of the entry: TRUE for valid and FALSE for invalid
 * @param [in]     ptr_classify    - The classified information of the entry
 * @param [in]     ptr_action      - The action to be taken of the entry when the classified
 * information is matched
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_lt_acl_addEntry(const UI32_T unit,
                    const UI32_T entry_id,
                    const BOOL_T entry_valid,
                    const CLX_ACL_CLASSIFY_T *ptr_classify,
                    const CLX_ACL_ACTION_T *ptr_action);

CLX_ERROR_NO_T
hal_lt_acl_getFreeUcpPbm(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         UI32_T *ucp_num,
                         UI32_T *free_ucp_bmp);

CLX_ERROR_NO_T
hal_lt_acl_addUcpToGroup(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T group,
                         const UI32_T new_ucp);

CLX_ERROR_NO_T
hal_lt_acl_unpackEntry(const UI32_T unit,
                       const CLX_ACL_GROUP_T type,
                       const HAL_ACL_ENTRY_INFO_T *ptr_entry_info,
                       BOOL_T *ptr_entry_valid,
                       CLX_ACL_CLASSIFY_T *ptr_classify,
                       CLX_ACL_ACTION_T *ptr_action);

CLX_ERROR_NO_T
hal_lt_acl_enableGroup(const UI32_T unit,
                       const CLX_ACL_GROUP_T type,
                       const UI32_T group,
                       const UI32_T enable);

CLX_ERROR_NO_T
hal_lt_acl_getFlowEntry(const UI32_T unit,
                        const HAL_ACL_FLOW_ENTRY_INFO_T *ptr_entry_info,
                        CLX_ACL_CLASSIFY_T *ptr_classify,
                        CLX_ACL_ACTION_T *ptr_action);

/**
 * @brief The API is used to add an exact match entry to HW.
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - UCP group type: Ingress/Egress
 * @param [in]     group_id        - Group id
 * @param [in]     ptr_classify    - The classified information of the entry
 * @param [in]     ptr_action      - The action to be taken of the entry when the classified
 * information is matched
 * @param [out]    ptr_entry_id    - The returned entry id from HW
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
hal_lt_acl_addFlowEntry(const UI32_T unit,
                        const CLX_ACL_GROUP_T type,
                        const UI32_T group_id,
                        const CLX_ACL_CLASSIFY_T *ptr_classify,
                        const CLX_ACL_ACTION_T *ptr_action,
                        UI32_T *ptr_entry_id);

CLX_ERROR_NO_T
hal_lt_acl_updateEcmpInfo(const UI32_T unit,
                          const UI32_T ecmp_group_id,
                          const HAL_L3_ECMP_INFO_T *ptr_ecmp_info);

CLX_ERROR_NO_T
hal_lt_acl_updateAdjInfo(const UI32_T unit,
                         const UI32_T adj_id,
                         const HAL_L3_ADJ_INFO_T *ptr_adj_info);

CLX_ERROR_NO_T
hal_lt_acl_setUcpPrio(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T group_id,
                      const HAL_ACL_UCP_PRIO_T *ucp_prio);

CLX_ERROR_NO_T
hal_lt_acl_initCfg(const UI32_T unit);

CLX_ERROR_NO_T
hal_lt_acl_getFlowEntryIdInfo(const UI32_T unit,
                              const UI32_T hw_entry_id,
                              CLX_ACL_GROUP_T *ptr_type,
                              UI32_T *ptr_group_id);

CLX_ERROR_NO_T
hal_lt_acl_delFlowEntry(const UI32_T unit,
                        const UI32_T group_id,
                        HAL_ACL_FLOW_ENTRY_INFO_T *ptr_entry_info);

CLX_ERROR_NO_T
hal_lt_acl_getFlowGroupEntryCapUsage(const UI32_T unit,
                                     const CLX_ACL_GROUP_T type,
                                     const UI32_T group_id,
                                     const UI32_T get_capacity,
                                     UI32_T *ptr_cnt);
CLX_ERROR_NO_T
hal_lt_acl_allocEntryId(const UI32_T unit,
                        const CLX_ACL_GROUP_T type,
                        const UI32_T group_id,
                        const UI32_T entry_priority,
                        UI32_T *ptr_entry_id);

CLX_ERROR_NO_T
hal_lt_acl_getSwEntryInfo(const UI32_T unit,
                          const UI32_T entry_id,
                          CLX_ACL_GROUP_T *type,
                          UI32_T *sw_entry_id);

CLX_ERROR_NO_T
hal_lt_acl_rim_alloc_fcm_idx(const UI32_T unit, const UI32_T is_flw, UI32_T *ptr_index);

CLX_ERROR_NO_T
hal_lt_acl_rim_free_fcm_idx(const UI32_T unit, const UI32_T is_flw, const UI32_T index);

CLX_ERROR_NO_T
hal_lt_acl_rim_setFcmAction(const UI32_T unit,
                            const UI32_T is_flw,
                            const UI32_T index,
                            const void *ptr_action);

CLX_ERROR_NO_T
hal_lt_acl_rim_getFcmAction(const UI32_T unit,
                            const UI32_T is_flw,
                            const UI32_T index,
                            const void *ptr_action);

CLX_ERROR_NO_T
hal_lt_acl_rim_travFcmAction(const UI32_T unit,
                             const UI32_T is_flw,
                             const CLX_ACL_RIM_TRAVERSE_FUNC_T callback,
                             void *ptr_cookie);

CLX_ERROR_NO_T
hal_lt_acl_rim_allocRedirIdx(const UI32_T unit, const CLX_ACL_RIM_ALLOC_T type, UI32_T *ptr_index);

CLX_ERROR_NO_T
hal_lt_acl_rim_freeRedirIdx(const UI32_T unit, const CLX_ACL_RIM_ALLOC_T type, const UI32_T index);

CLX_ERROR_NO_T
hal_lt_acl_rim_setRedirIdx(const UI32_T unit,
                           const CLX_ACL_RIM_ALLOC_T type,
                           const UI32_T index,
                           const CLX_ACL_REDIRECT_ACTION_T *ptr_redir_act);

CLX_ERROR_NO_T
hal_lt_acl_rim_getRedirIdx(const UI32_T unit,
                           const CLX_ACL_RIM_ALLOC_T type,
                           const UI32_T index,
                           CLX_ACL_REDIRECT_ACTION_T *ptr_redir_act);

CLX_ERROR_NO_T
hal_lt_acl_rim_travRedirIdx(const UI32_T unit,
                            const CLX_ACL_RIM_ALLOC_T type,
                            const CLX_ACL_RIM_TRAVERSE_FUNC_T callback,
                            void *ptr_cookie);

#endif /* End of HAL_LT_ACL_H */
