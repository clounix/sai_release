
/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_lt_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_LT_STAT_H
#define HAL_LT_STAT_H

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief To update PP Service counter table in accordance with counter config
 *
 * @param [in]     unit                   - Chip unit id
 * @param [in]     is_ingress             - Ingress counter or not
 * @param [in]     bank_id                - HW bank index
 * @param [in]     sw_bmap_idx_of_bank    - HW 1x counter index of the bank
 * @param [in]     cnt_cfg                - The configuration of counter
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters
 * @return         CLX_E_OTHERS           - HW operation error.
 */
CLX_ERROR_NO_T
hal_lt_stat_writeSrvCntHwTbl(const UI32_T unit,
                             const UI32_T is_ingress,
                             const UI32_T bank_id,
                             const UI32_T sw_bmap_idx_of_bank,
                             const CLX_STAT_CNT_CFG_T cnt_cfg);

/**
 * @brief This API is used to choose ingress or egress source.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     is_ingress    - Select ingress or egress
 * @param [in]     bank_id       - HW bank index
 * @param [in]     cnt_type      - The type user wants to set
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
hal_lt_stat_setCntCfgSource(const UI32_T unit,
                            const UI32_T is_ingress,
                            const UI32_T bank_id,
                            const HAL_STAT_HW_TYPE_T cnt_type);

#endif /* End of HAL_LT_STAT_H */