/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME: cdb.h
 * PURPOSE:
 *     Chip database (CDB) driver
 * NOTES:
 */

#ifndef CDB_H
#define CDB_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_swc.h>
#include <hal/hal_tbl.h>
/* NAMING CONSTANT DECLARATIONS
 */

/* special inst_idx for broadcast */
#define CDB_ODD_INST_IDX_BCAST  0x8FFFFFFF
#define CDB_EVEN_INST_IDX_BCAST 0x9FFFFFFF

/* special sub_inst_idx for fpu read/write slice1, high 16 bit for slice1, low 16 for sub inst index
 */
#define CDB_FPU_SLC1_SUB_INST_IDX 0xaFFF0000

#define CDB_INST_IDX_BCAST 0xFFFFFFFF

#define CDB_ADDR_BCAST 0x80000000
/* MACRO FUNCTION DECLARATIONS
 */
#define CDB_DMA_MEM_ALLOC(__ptr_orig__, __ptr_align__, __size__)                               \
    do {                                                                                       \
        (__ptr_orig__) = osal_dma_alloc((__size__) + 32);                                      \
        if (NULL != (__ptr_orig__)) {                                                          \
            (__ptr_align__) = (void *)(__ptr_orig__) + 16 - ((CLX_HUGE_T)(__ptr_orig__) % 16); \
        } else {                                                                               \
            (__ptr_align__) = NULL;                                                            \
        }                                                                                      \
    } while (0)

#define CDB_WRITE_MEM(_unit_, _addr_, _buf_, __memory_type__, __entry_size__)            \
    do {                                                                                 \
        if (MEMORY_TYPE_REG_MMIO == __memory_type__) {                                   \
            aml_writeReg(_unit_, _addr_, _buf_, __entry_size__);                         \
        } else {                                                                         \
            rc = dcc_io_txCmd(_unit_, DCC_CMD_ACT_WRITE, _addr_, _buf_, __entry_size__); \
        }                                                                                \
    } while (0)

#define CDB_READ_MEM(_unit_, _addr_, _buf_, __memory_type__, __entry_size__)            \
    do {                                                                                \
        if (MEMORY_TYPE_REG_MMIO == __memory_type__) {                                  \
            aml_readReg(_unit_, _addr_, _buf_, __entry_size__);                         \
        } else {                                                                        \
            rc = dcc_io_txCmd(_unit_, DCC_CMD_ACT_READ, _addr_, _buf_, __entry_size__); \
        }                                                                               \
    } while (0)

#define CDB_SUBINST_FOREACH(__unit__, __tbl_id__, __sub_inst__)                               \
    for (__sub_inst__ = 0; __sub_inst__ < CDB_TABLE((__unit__), (__tbl_id__))->subinst_count; \
         __sub_inst__++)

#define CDB_IS_FPU_SLC1_SUBINST(__sub_inst__) \
    (CDB_FPU_SLC1_SUB_INST_IDX == ((__sub_inst__) & 0xFFFF0000))

#define CDB_GET_FPU_SLC1_SUBINST_IDX(__sub_inst__) ((__sub_inst__) & 0x0000FFFF)

#define CDB_SET_FPU_SLC1_SUBINST(__sub_inst__) (CDB_FPU_SLC1_SUB_INST_IDX | (__sub_inst__))

/*
 * Example is as below.
 *  CLX_MAC_T clx_mac = {0x0, 0x1, 0x2, 0x3, 0x4, 0x5};
 *  UI32_T    hw_mac[2];
 *
 *  After CLX_MAC_TO_HW_MAC(hw_mac, clx_mac),
 *  hw_mac[0] = 0x02030405;
 *  hw_mac[1] = 0x0001;
 */
#define CLX_MAC_TO_HW_MAC(__hw_mac__, __clx_mac__)                                     \
    do {                                                                               \
        (__hw_mac__)[0] = ((UI32_T)((__clx_mac__)[2]) << 24 | (__clx_mac__)[3] << 16 | \
                           (__clx_mac__)[4] << 8 | (__clx_mac__)[5]);                  \
        (__hw_mac__)[1] = ((__clx_mac__)[0] << 8 | (__clx_mac__)[1]);                  \
    } while (0)

/*
 * Example is as below.
 *  CLX_MAC_T clx_mac;
 *  UI32_T    hw_mac[2] = {0x02030405, 0x0001};
 *
 *  After HW_MAC_TO_CLX_MAC(clx_mac, hw_mac),
 *  clx_mac[2] = 0x02; clx_mac[3] = 0x03, clx_mac[4] = 0x4, clx_mac[5] = 0x5;
 *  clx_mac[0] = 0x00; clx_mac[1] = 0x01;
 */
#define HW_MAC_TO_CLX_MAC(__clx_mac__, __hw_mac__)               \
    do {                                                         \
        (__clx_mac__)[0] = ((__hw_mac__)[1] & 0x0000FF00) >> 8;  \
        (__clx_mac__)[1] = ((__hw_mac__)[1] & 0x000000FF);       \
        (__clx_mac__)[2] = ((__hw_mac__)[0] & 0xFF000000) >> 24; \
        (__clx_mac__)[3] = ((__hw_mac__)[0] & 0x00FF0000) >> 16; \
        (__clx_mac__)[4] = ((__hw_mac__)[0] & 0x0000FF00) >> 8;  \
        (__clx_mac__)[5] = ((__hw_mac__)[0] & 0x000000FF);       \
    } while (0)
/*
 * Example is as below.
 *  CLX_IPV6_T clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x00, 0x01,
 *                         0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 *  UI32_T     hw_ipv6[4];
 *
 *  After CLX_IPV6_TO_HW_IPV6(clx_mac, hw_mac),
 *  hw_ipv6[0] = 0xFEA7686B;
 *  hw_ipv6[1] = 0x0A0020FF;
 *  hw_ipv6[2] = 0x1F8D0001;
 *  hw_ipv6[3] = 0x3FFE0B80;
 */
#define CLX_IPV6_TO_HW_IPV6(__hw_ipv6__, __clx_ipv6__)                                     \
    do {                                                                                   \
        (__hw_ipv6__)[0] = (UI32_T)((__clx_ipv6__)[12]) << 24 | (__clx_ipv6__)[13] << 16 | \
            (__clx_ipv6__)[14] << 8 | (__clx_ipv6__)[15];                                  \
        (__hw_ipv6__)[1] = (UI32_T)((__clx_ipv6__)[8]) << 24 | (__clx_ipv6__)[9] << 16 |   \
            (__clx_ipv6__)[10] << 8 | (__clx_ipv6__)[11];                                  \
        (__hw_ipv6__)[2] = (UI32_T)((__clx_ipv6__)[4]) << 24 | (__clx_ipv6__)[5] << 16 |   \
            (__clx_ipv6__)[6] << 8 | (__clx_ipv6__)[7];                                    \
        (__hw_ipv6__)[3] = (UI32_T)((__clx_ipv6__)[0]) << 24 | (__clx_ipv6__)[1] << 16 |   \
            (__clx_ipv6__)[2] << 8 | (__clx_ipv6__)[3];                                    \
    } while (0)
/*
 * Example is as below.
 *  CLX_IPV6_T clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x34, 0x01,
 *                         0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 *  UI32_T     hw_ipv6[5];
 *
 *  After CLX_IPV6_TO_HW_IPV6(hw_ipv6[5], clx_ipv6),
 *  hw_ipv6[0] = 0xFEA7686B;
 *  hw_ipv6[1] = 0x0A0020FF;
 *  hw_ipv6[2] = 0x00000401;
 *
 *  hw_ipv6[3] = 0xB801F8D3;
 *  hw_ipv6[4] = 0x0003FFE0;
 */
#define CLX_IPV6_TO_HW_IPV6_MT(__hw_ipv6__, __clx_ipv6__)                                       \
    do {                                                                                        \
        (__hw_ipv6__)[0] = (UI32_T)((__clx_ipv6__)[12]) << 24 | (__clx_ipv6__)[13] << 16 |      \
            (__clx_ipv6__)[14] << 8 | (__clx_ipv6__)[15];                                       \
        (__hw_ipv6__)[1] = (UI32_T)((__clx_ipv6__)[8]) << 24 | (__clx_ipv6__)[9] << 16 |        \
            (__clx_ipv6__)[10] << 8 | (__clx_ipv6__)[11];                                       \
        (__hw_ipv6__)[2] = ((UI32_T)((__clx_ipv6__)[6]) << 8 | (__clx_ipv6__)[7]) & 0x00000FFF; \
        (__hw_ipv6__)[3] = (UI32_T)((__clx_ipv6__)[2]) << 28 | (__clx_ipv6__)[3] << 20 |        \
            (__clx_ipv6__)[4] << 12 | (__clx_ipv6__)[5] << 4 | (__clx_ipv6__)[6] >> 4;          \
        (__hw_ipv6__)[4] = (UI32_T)((__clx_ipv6__)[0]) << 12 | (__clx_ipv6__)[1] << 4 |         \
            (__clx_ipv6__)[2] >> 4;                                                             \
    } while (0)
/*
 * Example is as below.
 *  CLX_IPV6_T clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x00, 0x01,
 *                         0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 *
 *  After HW_IPV6_TO_CLX_IPV6(__clx_ipv6__, __hw_ipv6__),
 *  hw_ipv6[0] = 0xFEA7686B;
 *  hw_ipv6[1] = 0x0A0020FF;
 *  hw_ipv6[2] = 0x1F8D0001;
 *  hw_ipv6[3] = 0x3FFE0B80;
 *
 */
#define HW_IPV6_TO_CLX_IPV6(__clx_ipv6__, __hw_ipv6__)              \
    do {                                                            \
        (__clx_ipv6__)[0] = ((__hw_ipv6__)[3] & 0xFF000000) >> 24;  \
        (__clx_ipv6__)[1] = ((__hw_ipv6__)[3] & 0x00FF0000) >> 16;  \
        (__clx_ipv6__)[2] = ((__hw_ipv6__)[3] & 0x0000FF00) >> 8;   \
        (__clx_ipv6__)[3] = ((__hw_ipv6__)[3] & 0x000000FF);        \
        (__clx_ipv6__)[4] = ((__hw_ipv6__)[2] & 0xFF000000) >> 24;  \
        (__clx_ipv6__)[5] = ((__hw_ipv6__)[2] & 0x00FF0000) >> 16;  \
        (__clx_ipv6__)[6] = ((__hw_ipv6__)[2] & 0x0000FF00) >> 8;   \
        (__clx_ipv6__)[7] = ((__hw_ipv6__)[2] & 0x000000FF);        \
        (__clx_ipv6__)[8] = ((__hw_ipv6__)[1] & 0xFF000000) >> 24;  \
        (__clx_ipv6__)[9] = ((__hw_ipv6__)[1] & 0x00FF0000) >> 16;  \
        (__clx_ipv6__)[10] = ((__hw_ipv6__)[1] & 0x0000FF00) >> 8;  \
        (__clx_ipv6__)[11] = ((__hw_ipv6__)[1] & 0x000000FF);       \
        (__clx_ipv6__)[12] = ((__hw_ipv6__)[0] & 0xFF000000) >> 24; \
        (__clx_ipv6__)[13] = ((__hw_ipv6__)[0] & 0x00FF0000) >> 16; \
        (__clx_ipv6__)[14] = ((__hw_ipv6__)[0] & 0x0000FF00) >> 8;  \
        (__clx_ipv6__)[15] = ((__hw_ipv6__)[0] & 0x000000FF);       \
    } while (0)
/*
 * Example is as below.
 *  CLX_IPV6_T clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x34, 0x01,
 *                         0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 *
 *  After HW_IPV6_TO_CLX_IPV6(__clx_ipv6__, __hw_ipv6__),
 *  hw_ipv6[0] = 0xFEA7686B;
 *  hw_ipv6[1] = 0x0A0020FF;
 *  hw_ipv6[2] = 0x00000401;
 *
 *  hw_ipv6[3] = 0xB801F8D3;
 *  hw_ipv6[4] = 0x0003FFE0;
 */
#define HW_IPV6_TO_CLX_IPV6_MT(__clx_ipv6__, __hw_ipv6__)           \
    do {                                                            \
        (__clx_ipv6__)[0] = ((__hw_ipv6__)[4] & 0x000FF000) >> 12;  \
        (__clx_ipv6__)[1] = ((__hw_ipv6__)[4] & 0x00000FF0) >> 4;   \
        (__clx_ipv6__)[2] = ((__hw_ipv6__)[4] & 0x0000000F) << 4 |  \
            ((__hw_ipv6__)[3] & 0xF0000000) >> 28;                  \
        (__clx_ipv6__)[3] = ((__hw_ipv6__)[3] & 0x0FF00000) >> 20;  \
        (__clx_ipv6__)[4] = ((__hw_ipv6__)[3] & 0x000FF000) >> 12;  \
        (__clx_ipv6__)[5] = ((__hw_ipv6__)[3] & 0x00000FF0) >> 4;   \
        (__clx_ipv6__)[6] = ((__hw_ipv6__)[3] & 0x0000000F) << 4 |  \
            ((__hw_ipv6__)[2] & 0x00000F00) >> 8;                   \
        (__clx_ipv6__)[7] = ((__hw_ipv6__)[2] & 0x000000FF);        \
        (__clx_ipv6__)[8] = ((__hw_ipv6__)[1] & 0xFF000000) >> 24;  \
        (__clx_ipv6__)[9] = ((__hw_ipv6__)[1] & 0x00FF0000) >> 16;  \
        (__clx_ipv6__)[10] = ((__hw_ipv6__)[1] & 0x0000FF00) >> 8;  \
        (__clx_ipv6__)[11] = ((__hw_ipv6__)[1] & 0x000000FF);       \
        (__clx_ipv6__)[12] = ((__hw_ipv6__)[0] & 0xFF000000) >> 24; \
        (__clx_ipv6__)[13] = ((__hw_ipv6__)[0] & 0x00FF0000) >> 16; \
        (__clx_ipv6__)[14] = ((__hw_ipv6__)[0] & 0x0000FF00) >> 8;  \
        (__clx_ipv6__)[15] = ((__hw_ipv6__)[0] & 0x000000FF);       \
    } while (0)
/* DATA TYPE DECLARATIONS
 */
typedef struct {
    UI32_T field_id;
    union {
        UI32_T *ptr_value;
        UI32_T value;
    };
} CDB_FVP_T;

typedef enum { CDB_MEM_TYPE_HASH, CDB_MEM_TYPE_TCAM, CDB_MEM_TYPE_LAST } CDB_MEM_TYPE_T;

typedef enum {
    CDB_BCAST_NONE = 0,
    CDB_BCAST_INST_ODD = 1,
    CDB_BCAST_INST_EVEN = 2,
    CDB_BCAST_SUBINST = 3,
    CDB_BCAST_ALL = 7,
    CDB_BCAST_LAST
} CDB_BCAST_TYPE_T;

typedef struct {
    CDB_MEM_TYPE_T mem_type;
    union {
        CLX_SWC_HASH_TILE_TYPE_T hash_type;
        CLX_SWC_TCAM_TYPE_T tcam_type;
    };

} CDB_MEM_SERVICE_T;

typedef enum {
    CDB_MEM_MODE_LOG = 0,
    CDB_MEM_MODE_FAILURE = 1,
    CDB_MEM_MODE_REWRITE = 2,
    CDB_MEM_MODE_LAST
} CDB_MEM_CHECK_MODE_T;

typedef struct {
    UI32_T flag;
    CDB_MEM_CHECK_MODE_T mode;
} CDB_MEM_CHECK_T;

typedef CLX_ERROR_NO_T (*CDB_WRITE_ENTRY)(const UI32_T unit,
                                          const UI32_T inst_idx,
                                          const UI32_T subinst_idx,
                                          const UI32_T table_id,
                                          const UI32_T entry_idx,
                                          const UI32_T *ptr_entry);

typedef CLX_ERROR_NO_T (*CDB_READ_ENTRY)(const UI32_T unit,
                                         const UI32_T inst_idx,
                                         const UI32_T subinst_idx,
                                         const UI32_T table_id,
                                         const UI32_T entry_idx,
                                         UI32_T *ptr_entry);

typedef CLX_ERROR_NO_T (*CDB_MODIFY_FIELD)(const UI32_T unit,
                                           const UI32_T inst_idx,
                                           const UI32_T subinst_idx,
                                           const UI32_T table_id,
                                           const UI32_T entry_idx,
                                           const UI32_T field_id,
                                           const UI32_T *ptr_field);

typedef CLX_ERROR_NO_T (*CDB_MODIFY_MULTIFIELDS)(const UI32_T unit,
                                                 const UI32_T inst_idx,
                                                 const UI32_T subinst_idx,
                                                 const UI32_T table_id,
                                                 const UI32_T entry_idx,
                                                 const UI32_T fvp_count,
                                                 const CDB_FVP_T *ptr_fvp);

typedef CLX_ERROR_NO_T (*CDB_MODIFY_UI32FILED)(const UI32_T unit,
                                               const UI32_T inst_idx,
                                               const UI32_T subinst_idx,
                                               const UI32_T table_id,
                                               const UI32_T entry_idx,
                                               const UI32_T field_id,
                                               const UI32_T field);

typedef CLX_ERROR_NO_T (*CDB_ADD_HASH_ENTRY)(const UI32_T unit,
                                             const UI32_T inst_idx,
                                             const UI32_T subinst_idx,
                                             const UI32_T bank_bmp,
                                             const UI32_T table_id,
                                             const UI32_T flag,
                                             const UI32_T *ptr_entry,
                                             UI32_T *ptr_entry_idx);

typedef CLX_ERROR_NO_T (*CDB_UPDATE_HASH_ENTRY)(const UI32_T unit,
                                                const UI32_T inst_idx,
                                                const UI32_T subinst_idx,
                                                const UI32_T bank_bmp,
                                                const UI32_T table_id,
                                                const UI32_T flag,
                                                const UI32_T *ptr_entry,
                                                UI32_T *ptr_entry_idx);

typedef CLX_ERROR_NO_T (*CDB_LOOKUP_HASH_ENTRY)(const UI32_T unit,
                                                const UI32_T inst_idx,
                                                const UI32_T subinst_idx,
                                                const UI32_T bank_bmp,
                                                const UI32_T table_id,
                                                UI32_T *ptr_entry,
                                                UI32_T *ptr_entry_idx);

typedef CLX_ERROR_NO_T (*CDB_DEL_HASH_ENTRY)(const UI32_T unit,
                                             const UI32_T inst_idx,
                                             const UI32_T subinst_idx,
                                             const UI32_T bank_bmp,
                                             const UI32_T table_id,
                                             const UI32_T *ptr_entry,
                                             UI32_T *ptr_entry_idx);

typedef CLX_ERROR_NO_T (*CDB_DMA_WRITE_ENTRY)(const UI32_T unit,
                                              const UI32_T inst_idx,
                                              const UI32_T subinst_idx,
                                              const UI32_T bank_bmp,
                                              const UI32_T table_id,
                                              const UI32_T entry_idx,
                                              const UI32_T entry_num,
                                              UI32_T *ptr_entry);

typedef CLX_ERROR_NO_T (*CDB_DMA_READ_ENTRY)(const UI32_T unit,
                                             const UI32_T inst_idx,
                                             const UI32_T subinst_idx,
                                             const UI32_T bank_bmp,
                                             const UI32_T table_id,
                                             const UI32_T entry_idx,
                                             const UI32_T entry_num,
                                             UI32_T *ptr_entry);

typedef CLX_ERROR_NO_T (*CDB_COPY_TABLE)(const UI32_T unit,
                                         const UI32_T inst_idx,
                                         const UI32_T subinst_idx,
                                         const UI32_T table_id,
                                         const UI32_T src_entry_idx,
                                         const UI32_T dst_entry_idx,
                                         const UI32_T entry_num);

typedef CLX_ERROR_NO_T (*CDB_RESET_TABLE)(const UI32_T unit,
                                          const UI32_T inst_idx,
                                          const UI32_T subinst_idx,
                                          const UI32_T table_id,
                                          const UI32_T *ptr_entry);

typedef CLX_ERROR_NO_T (*CDB_INDEX_LOGIC2PHY)(const UI32_T unit,
                                              const CDB_MEM_SERVICE_T *mem_service,
                                              const UI32_T table_id,
                                              const UI32_T entry_idx,
                                              UI32_T *ptr_entry_idx);

typedef CLX_ERROR_NO_T (*CDB_INDEX_PHY2LOGIC)(const UI32_T unit,
                                              const CDB_MEM_SERVICE_T *mem_service,
                                              const UI32_T table_id,
                                              const UI32_T entry_idx,
                                              UI32_T *ptr_entry_idx);

typedef BOOL_T (*CDB_INDEX_ISVALID)(const UI32_T unit,
                                    const UI32_T table_id,
                                    const UI32_T entry_idx);

typedef CLX_ERROR_NO_T (*CDB_SET_ENTRYVALID)(const UI32_T unit,
                                             const UI32_T inst_idx,
                                             const UI32_T subinst_idx,
                                             const UI32_T table_id,
                                             const UI32_T entry_idx,
                                             const BOOL_T entry_valid);

typedef CLX_ERROR_NO_T (*CDB_READ_UI32FIELD)(const UI32_T unit,
                                             const UI32_T inst_idx,
                                             const UI32_T subinst_idx,
                                             const UI32_T table_id,
                                             const UI32_T entry_idx,
                                             const UI32_T field_id,
                                             UI32_T *ptr_field);

typedef struct {
    CDB_WRITE_ENTRY cdb_writeEntry;
    CDB_READ_ENTRY cdb_readEntry;
    CDB_MODIFY_FIELD cdb_modify_field;
    CDB_MODIFY_UI32FILED cdb_modify_ui32filed;
    CDB_MODIFY_MULTIFIELDS cdb_modify_multifields;
    CDB_ADD_HASH_ENTRY cdb_addHashEntry;
    CDB_UPDATE_HASH_ENTRY cdb_updateHashEntry;
    CDB_LOOKUP_HASH_ENTRY cdb_lookupHashEntry;
    CDB_DEL_HASH_ENTRY cdb_delHashEntry;
    CDB_DMA_WRITE_ENTRY cdb_dma_writeEntry;
    CDB_DMA_READ_ENTRY cdb_dma_readEntry;
    CDB_COPY_TABLE cdb_copy_table;
    CDB_RESET_TABLE cdb_reset_table;
    CDB_INDEX_LOGIC2PHY cdb_index_logic2phy;
    CDB_INDEX_PHY2LOGIC cdb_index_phy2logic;
    CDB_WRITE_ENTRY cdb_writeEntryNoCache;
    CDB_INDEX_ISVALID cdb_index_isValid;
    CDB_SET_ENTRYVALID cdb_set_entryValid;
    CDB_READ_UI32FIELD cdb_read_ui32field;
} CDB_PROC_TABLE;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the
 *        content in field buffer.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [in]     ptr_field    - Pointer to the field buffer
 * @param [out]    ptr_entry    - Pointer to the entry buffer.
 */
void
cdb_packField(const UI32_T unit,
              const UI32_T table_id,
              const UI32_T field_id,
              UI32_T *ptr_entry,
              const UI32_T *ptr_field);

/**
 * @brief Extract the specified field from an entry buffer info field buffer.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [out]    ptr_field    - Pointer to the field buffer.
 */
void
cdb_unpackField(const UI32_T unit,
                const UI32_T table_id,
                const UI32_T field_id,
                const UI32_T *ptr_entry,
                UI32_T *ptr_field);

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the
 *        field value.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [in]     field        - Field value.
 * @param [out]    ptr_entry    - Pointer to the entry buffer.
 */
void
cdb_packUi32Field(const UI32_T unit,
                  const UI32_T table_id,
                  const UI32_T field_id,
                  UI32_T *ptr_entry,
                  const UI32_T field);

/**
 * @brief Extract the specified field from an entry buffer.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @return    Field value.
 */
UI32_T
cdb_unpackUi32Field(const UI32_T unit,
                    const UI32_T table_id,
                    const UI32_T field_id,
                    const UI32_T *ptr_entry);

/**
 * @brief Read a memory mapped location in hardware.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @return    Entry value.
 */
UI32_T
cdb_readMmio(const UI32_T unit,
             const UI32_T inst_idx,
             const UI32_T subinst_idx,
             const UI32_T table_id,
             const UI32_T entry_idx);

/**
 * @brief Write a memory mapped location in hardware.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [in]     value          - Entry value.
 */
void
cdb_writeMmio(const UI32_T unit,
              const UI32_T inst_idx,
              const UI32_T subinst_idx,
              const UI32_T table_id,
              const UI32_T entry_idx,
              const UI32_T value);

/**
 * @brief Read an entry from hardware to entry buffer.
 *        1. When reading TCAM table id, please use table id whose
 *        memory type is "MEMORY_TYPE_TABLE_TCAM_COM".
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [out]    ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Read success.
 * @return         CLX_E_OTHERS    - Read fail.
 */
CLX_ERROR_NO_T
cdb_readEntry(const UI32_T unit,
              const UI32_T inst_idx,
              const UI32_T subinst_idx,
              const UI32_T table_id,
              const UI32_T entry_idx,
              UI32_T *ptr_entry);

/**
 * @brief Write an entry from entry buffer to hardware.
 *        1. When writing TCAM table id, please use table id whose
 *        memory type is "MEMORY_TYPE_TABLE_TCAM_COM".
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [in]     ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
cdb_writeEntry(const UI32_T unit,
               const UI32_T inst_idx,
               const UI32_T subinst_idx,
               const UI32_T table_id,
               const UI32_T entry_idx,
               const UI32_T *ptr_entry);

/**
 * @brief Write an entry from entry buffer to hardware and not write ecc cache table.
 *        1. When writing TCAM table id, please use table id whose
 *        memory type is "MEMORY_TYPE_TABLE_TCAM_COM".
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [in]     ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
cdb_writeEntryNoCache(const UI32_T unit,
                      const UI32_T inst_idx,
                      const UI32_T subinst_idx,
                      const UI32_T table_id,
                      const UI32_T entry_idx,
                      const UI32_T *ptr_entry);

/**
 * @brief Modify the specified field of the specified entry in hardware with the
 *        content in field buffer.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [in]     field_id       - Field ID.
 * @param [in]     ptr_field      - Pointer to the new value for the field.
 * @return         CLX_E_OK        - Modify success.
 * @return         CLX_E_OTHERS    - Read or write fail.
 */
CLX_ERROR_NO_T
cdb_modifyField(const UI32_T unit,
                const UI32_T inst_idx,
                const UI32_T subinst_idx,
                const UI32_T table_id,
                const UI32_T entry_idx,
                const UI32_T field_id,
                const UI32_T *ptr_field);

/**
 * @brief Modify the specified "short" field of the specified entry in hardware
 *        with field value, this can be used for field with width of 32-bit or
 *        less.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [in]     field_id       - Field ID.
 * @param [in]     field          - New value for the field.
 * @return         CLX_E_OK        - Modify success.
 * @return         CLX_E_OTHERS    - Read or write fail.
 */
CLX_ERROR_NO_T
cdb_modifyUi32Field(const UI32_T unit,
                    const UI32_T inst_idx,
                    const UI32_T subinst_idx,
                    const UI32_T table_id,
                    const UI32_T entry_idx,
                    const UI32_T field_id,
                    const UI32_T field);

/**
 * @brief Modify multiple fields of the specified entry in hardware.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [in]     fvp_count      - Number of valid entries in ptr_fvp array.
 * @param [in]     ptr_fvp        - Pointer to array of field-value pair (FVP)
 * @return         CLX_E_OK        - Modify success.
 * @return         CLX_E_OTHERS    - Read or write fail.
 */
CLX_ERROR_NO_T
cdb_modifyMultiFields(const UI32_T unit,
                      const UI32_T inst_idx,
                      const UI32_T subinst_idx,
                      const UI32_T table_id,
                      const UI32_T entry_idx,
                      const UI32_T fvp_count,
                      const CDB_FVP_T *ptr_fvp);

/**
 * @brief Add a hash entry into hardware.
 *
 * @param [in]     unit             - Unit number.
 * @param [in]     inst_idx         - Instance index.
 * @param [in]     subinst_idx      - Sub instance index.
 * @param [in]     bank_bmp         - The bank bitmap of hash engine.
 * @param [in]     table_id         - Table ID.
 * @param [in]     ptr_entry        - Pointer to the buffer of the new entry
 * @param [out]    ptr_entry_idx    - The returned entry index.
 * @return         CLX_E_OK        - Add success.
 * @return         CLX_E_OTHERS    - Add fail.
 */
CLX_ERROR_NO_T
cdb_addHashEntry(const UI32_T unit,
                 const UI32_T inst_idx,
                 const UI32_T subinst_idx,
                 const UI32_T bank_bmp,
                 const UI32_T table_id,
                 const UI32_T *ptr_entry,
                 UI32_T *ptr_entry_idx);

/**
 * @brief update a hash entry data into hardware.
 *
 * @param [in]     unit             - Unit number.
 * @param [in]     inst_idx         - Instance index.
 * @param [in]     subinst_idx      - Sub instance index.
 * @param [in]     bank_bmp         - The bank bitmap of hash engine.
 * @param [in]     table_id         - Table ID.
 * @param [in]     ptr_entry        - Pointer to the buffer of the new entry
 * @param [out]    ptr_entry_idx    - The returned entry index.
 * @return         CLX_E_OK        - Add success.
 * @return         CLX_E_OTHERS    - Add fail.
 */
CLX_ERROR_NO_T
cdb_updateHashEntry(const UI32_T unit,
                    const UI32_T inst_idx,
                    const UI32_T subinst_idx,
                    const UI32_T bank_bmp,
                    const UI32_T table_id,
                    const UI32_T *ptr_entry,
                    UI32_T *ptr_entry_idx);

/**
 * @brief Search a hash entry from hardware.
 *
 * @param [in]     unit             - Unit number.
 * @param [in]     inst_idx         - Instance index.
 * @param [in]     subinst_idx      - Sub instance index.
 * @param [in]     bank_bmp         - The bank bitmap of hash engine.
 * @param [in]     table_id         - Table ID.
 * @param [in]     ptr_entry        - Pointer to the buffer of the entry
 * @param [out]    ptr_entry_idx    - The returned entry index.
 * @return         CLX_E_OK        - Search success.
 * @return         CLX_E_OTHERS    - Search fail.
 */
CLX_ERROR_NO_T
cdb_lookupHashEntry(const UI32_T unit,
                    const UI32_T inst_idx,
                    const UI32_T subinst_idx,
                    const UI32_T bank_bmp,
                    const UI32_T table_id,
                    UI32_T *ptr_entry,
                    UI32_T *ptr_entry_idx);

/**
 * @brief Delete a hash entry from hardware.
 *
 * @param [in]     unit             - Unit number.
 * @param [in]     inst_idx         - Instance index.
 * @param [in]     subinst_idx      - Sub instance index.
 * @param [in]     bank_bmp         - The bank bitmap of hash engine.
 * @param [in]     table_id         - Table ID.
 * @param [in]     ptr_entry        - Pointer to the buffer of the entry to be deleted
 * @param [out]    ptr_entry_idx    - The returned entry index.
 * @return         CLX_E_OK        - Delete success.
 * @return         CLX_E_OTHERS    - Delete fail.
 */
CLX_ERROR_NO_T
cdb_delHashEntry(const UI32_T unit,
                 const UI32_T inst_idx,
                 const UI32_T subinst_idx,
                 const UI32_T bank_bmp,
                 const UI32_T table_id,
                 const UI32_T *ptr_entry,
                 UI32_T *ptr_entry_idx);

/**
 * @brief Read many entries from hardware to entry buffer by DMA.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     bank_bmp       - The bank bitmap of hash engine.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_num      - Entry num.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [out]    ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Read success.
 * @return         CLX_E_OTHERS    - Read fail.
 */
CLX_ERROR_NO_T
cdb_dma_readEntry(const UI32_T unit,
                  const UI32_T inst_idx,
                  const UI32_T subinst_idx,
                  const UI32_T bank_bmp,
                  const UI32_T table_id,
                  const UI32_T entry_idx,
                  const UI32_T entry_num,
                  UI32_T *ptr_entry);

/**
 * @brief Write many entries from entry buffer to hardware by DMA.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     bank_bmp       - The bank bitmap of hash engine.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [in]     entry_num      - Entry num.
 * @param [in]     ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
CLX_ERROR_NO_T
cdb_dma_writeEntry(const UI32_T unit,
                   const UI32_T inst_idx,
                   const UI32_T subinst_idx,
                   const UI32_T bank_bmp,
                   const UI32_T table_id,
                   const UI32_T entry_idx,
                   const UI32_T entry_num,
                   UI32_T *ptr_entry);

/**
 * @brief Write whole table entries with initialized vlue.
 *
 * Namchabarwa chip not support reset fpu hash and tcam table
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     ptr_entry      - The entry with initialized value.
 * @return         CLX_E_OK        - Reset success.
 * @return         CLX_E_OTHERS    - Reset fail.
 */
CLX_ERROR_NO_T
cdb_resetTable(const UI32_T unit,
               const UI32_T inst_idx,
               const UI32_T subinst_idx,
               const UI32_T table_id,
               const UI32_T *ptr_entry);

/**
 * @brief copy table data from device to device.
 *
 * 1.The Namchabarwa chip supports only acl and fpu tcam for replication
 *
 * @param [in]     unit             - The specified unit number.
 * @param [in]     inst_idx         - Instance index.
 * @param [in]     subinst_idx      - Sub instance index.
 * @param [in]     table_id         - Table ID.
 * @param [in]     src_entry_idx    - Source entry index in table.
 * @param [in]     dst_entry_idx    - Destination entry index in table.dir
 * @param [in]     entry_num        - Number of entries are going to be transferred.
 * @return         CLX_E_OK               - Successfully copy data from device to device
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_OTHERS           - Fail to read data from device to device
 * @return         CLX_E_NOT_SUPPORT      - table not support copy
 */
CLX_ERROR_NO_T
cdb_copyTable(const UI32_T unit,
              const UI32_T inst_idx,
              const UI32_T subinst_idx,
              const UI32_T table_id,
              const UI32_T src_entry_idx,
              const UI32_T dst_entry_idx,
              const UI32_T entry_num);

/**
 * @brief Table entry index mapping logic to phy
 *
 * @param [in]     unit             - Unit number.
 * @param [in]     mem_service      - The memory service
 * @param [in]     table_id         - Table ID.
 * @param [in]     ptr_entry_idx    - The entry index.
 * @param [out]    ptr_entry_idx    - The mapping entry index.
 * @return         CLX_E_OK        - Mapping success.
 * @return         CLX_E_OTHERS    - Mapping fail.
 */
CLX_ERROR_NO_T
cdb_index_logic2phy(const UI32_T unit,
                    const CDB_MEM_SERVICE_T *mem_service,
                    const UI32_T table_id,
                    const UI32_T entry_idx,
                    UI32_T *ptr_entry_idx);

/**
 * @brief Table entry index mapping phy to logic
 *
 * @param [in]     unit             - Unit number.
 * @param [in]     mem_service      - The memory service
 * @param [in]     table_id         - Table ID.
 * @param [in]     entry_idx        - The entry index.
 * @param [out]    ptr_entry_idx    - The mapping entry index.
 * @return         CLX_E_OK        - Mapping success.
 * @return         CLX_E_OTHERS    - Mapping fail.
 */
CLX_ERROR_NO_T
cdb_index_phy2logic(const UI32_T unit,
                    const CDB_MEM_SERVICE_T *mem_service,
                    const UI32_T table_id,
                    const UI32_T entry_idx,
                    UI32_T *ptr_entry_idx);

/**
 * @brief Check Table entry index is valid or not
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     entry_idx    - The entry index.
 * @return         TRUE            - Table entry index is valid.
 * @return         CLX_E_OTHERS    - Table entry index is invalid.
 */
BOOL_T
cdb_index_isValid(const UI32_T unit, const UI32_T table_id, const UI32_T entry_idx);

/**
 * @brief Set tcam entry valid
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - The entry index.
 * @param [in]     entry_valid    - valid flag.
 * @return         CLX_E_OK               - Successfully sets tcam entry valid
 * @return         CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value
 * @return         CLX_E_NOT_SUPPORT      - Only supports tcam on nb chip
 */
CLX_ERROR_NO_T
cdb_set_entryValid(const UI32_T unit,
                   const UI32_T inst_idx,
                   const UI32_T subinst_idx,
                   const UI32_T table_id,
                   const UI32_T entry_idx,
                   const BOOL_T entry_valid);

/**
 * @brief Read the specified "short" field of the specified entry in hardware
 *        with field value, this can be used for field with width of 32-bit or
 *        less.
 *
 * @param [in]     unit           - Unit number.
 * @param [in]     inst_idx       - Instance index.
 * @param [in]     subinst_idx    - Sub instance index.
 * @param [in]     table_id       - Table ID.
 * @param [in]     entry_idx      - Entry index in table.
 * @param [in]     field_id       - Field ID.
 * @param [out]    ptr_field      - Pointer to the entry field buffer.
 * @return         CLX_E_OK               - Read success.
 * @return         CLX_E_BAD_PARAMETER    - bad parameter.
 * @return         CLX_E_OTHERS           - Read fail.
 */
CLX_ERROR_NO_T
cdb_readUi32Field(const UI32_T unit,
                  const UI32_T inst_idx,
                  const UI32_T subinst_idx,
                  const UI32_T table_id,
                  const UI32_T entry_idx,
                  const UI32_T field_id,
                  UI32_T *ptr_field);
/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
#endif /* End of CDB_H */
