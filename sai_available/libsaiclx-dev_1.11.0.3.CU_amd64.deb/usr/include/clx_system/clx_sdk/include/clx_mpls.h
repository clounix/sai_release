/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_mpls.h
 * PURPOSE:
 *      It provides the declarations of the MPLS Module APIs.
 * NOTES:
 */

#ifndef CLX_MPLS_H
#define CLX_MPLS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <clx_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_MPLS_MAX_LABEL_NUM (4) /* Maximum label number(exclude ELI/EL) */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* MPLS label stack operation */
typedef enum {
    CLX_MPLS_EL_LABEL_NONE = 0, /* No el label */
    CLX_MPLS_EL_LABEL_ABOVE_LBL0 = 1,
    CLX_MPLS_EL_LABEL_UNDER_LBL0 = 2,
    CLX_MPLS_EL_LABEL_UNDER_LBL1 = 3,
    CLX_MPLS_EL_LABEL_LAST
} CLX_MPLS_EL_LABEL_POS_T;

/* MPLS Label Stack Entry(LSE) */
typedef struct CLX_MPLS_LSE_S {
    UI32_T label_value;             /* MPLS label value */
    UI32_T ttl;                     /* TTL value for setting TTL. Range:0~255 */
    UI32_T exp;                     /* EXP value for setting EXP. Range:0~7 */
    CLX_MPLS_EL_LABEL_POS_T el_pos; /* el label position. nb only*/

/* Set TTL into label flag.                                    \
 * Set this flag means using pipe/short-pipe model at ingress. \
 * Otherwise, uniform model: TTL is coppied from inner header. \
 */
#define CLX_MPLS_LSE_FLAGS_SET_TTL (1U << 0)

/* Set QoS into label flag.                                    \
 * Set this flag means using pipe/short-pipe model at ingress. \
 * Otherwise, uniform model: QoS is coppied from inner TC.     \
 */
#define CLX_MPLS_LSE_FLAGS_SET_EXP (1U << 1)

#define CLX_MPLS_LSE_FLAGS_EL (1U << 2) /* Push Entropy label flag */
    UI32_T flags;
} CLX_MPLS_LSE_T;

typedef struct CLX_MPLS_ENCAP_KEY_S {
    UI32_T label_num;                    /* Push label number */
    CLX_MPLS_LSE_T
    label_stack[CLX_MPLS_MAX_LABEL_NUM]; /* Encapsulation label stack, 0 is topmost label */
    CLX_PORT_T
    underlay_port; /* The underlay tunnel port ID. Used for MPLS-over-IP tunnel.lt only */

/* The underlay tunnel port is valid flag.lt only  */
#define CLX_MPLS_ENCAP_FLAGS_UNDERLAY_INTF (1U << 0)
#define CLX_MPLS_ENCAP_FLAGS_WITH_ID       (1U << 1) /* Specified the tunnel port */
#define CLX_MPLS_ENCAP_FLAGS_SR            (1U << 2) /* MPLS Segment routing flag.lt only */

    UI32_T flags;
} CLX_MPLS_ENCAP_KEY_T;

typedef struct CLX_MPLS_MATCH_KEY_S {
    UI32_T name_space; /* Namespace value. Range:0~3.lt only */
    UI32_T label_num;  /* Match label number. Range:0~CLX_MPLS_MAX_LABEL_NUM */
    UI32_T label_stack[CLX_MPLS_MAX_LABEL_NUM];      /* Match label values in label stack,max 4*/
    UI32_T vrf;                                      /*MT transit match key vrf.nb only*/
#define CLX_MPLS_NH_MATCH_KEY_FLAGS_NO_LSP (1U << 0) /* input only has pw label.nb only */
    UI32_T flags;
} CLX_MPLS_MATCH_KEY_T;

/* MPLS LSP Tunnel Initiation Entry */
typedef struct CLX_MPLS_INIT_S {
    UI32_T nvo3_adj_id;               /* LSP NVO3 adjacency ID */
    UI32_T l3_intf_id;                /* L3 interface ID.lt only */
    UI32_T group_label;               /* Group label (Optional)*/
    UI32_T pcp;                       /* The PCP of MPLS tunnel L2 header (Optional).lt only*/
    UI32_T meter_id;                  /* Meter ID (Optional) */
    UI32_T cnt_id;                    /* Service counter ID (Optional) */
    UI32_T dist_cnt_id;               /* Distribution counter ID (Optional) */
    UI32_T sampling_rate;             /* Sampling rate (Optional) */
    UI32_T sample_to_mir_session_id;  /* Sample packets to a mirror session (Optional) */
    UI32_T mir_session_bitmap;        /* Mirror session ID bitmap (Optional) */
    UI32_T phb_to_exp_profile_id;     /* PHB to EXP mapping profile ID.(Optional) */
    UI32_T phb_to_pcp_dei_profile_id; /* PHB to PCP/DEI mapping profile ID.(Optional) */
    UI16_T l2_mtu_size;               /* L2 mtu size. cl8600 only */
    UI32_T frr_state_id;              /* FRR state ID.lt only */
    CLX_PORT_T frr_backup_lsp;        /* FRR backup LSP port ID.lt only */
    CLX_PORT_VLAN_TAG_T vlan_tag;     /* VLAN TAG of inner payload (Optional). */
    UI32_T dtel_profile_id;           /* IOAM/IFA profile ID (Optional).lt only */

#define CLX_MPLS_INIT_FLAGS_P2MP     (1U << 0) /* P2MP LSP tunnel flag */
#define CLX_MPLS_INIT_FLAGS_PCP      (1U << 1) /* L2 header PCP/DEI valid flag.lt only */
#define CLX_MPLS_INIT_FLAGS_DEI      (1U << 2) /* L2 header DEI set flag.lt only */
#define CLX_MPLS_INIT_FLAGS_METER    (1U << 3) /* Meter valid flag */
#define CLX_MPLS_INIT_FLAGS_CNT      (1U << 4) /* Service counter valid flag */
#define CLX_MPLS_INIT_FLAGS_DIST_CNT (1U << 5) /* Distribution counter valid flag */
/* PHB to EXP mapping profile valid flag */
#define CLX_MPLS_INIT_FLAGS_PHB_TO_EXP_PROFILE (1U << 6)
/* PHB to PCP/DEI mapping profile valid flag */
#define CLX_MPLS_INIT_FLAGS_PHB_TO_PCP_PROFILE  (1U << 7)
#define CLX_MPLS_INIT_FLAGS_FRR                 (1U << 8)  /* FRR is valid.lt only */
#define CLX_MPLS_INIT_FLAGS_VLAN_TAG            (1U << 9)  /* VLAN_TAG valid flag. */
#define CLX_MPLS_INIT_FLAGS_SAMPLE_TO_MIR       (1U << 10) /* Sample packets to a mirror session */
#define CLX_MPLS_INIT_FLAGS_SAMPLE_HIGH_LATENCY (1U << 11) /* Sample high latency packets */
#define CLX_MPLS_INIT_PROPERTY_FLAGS_DTEL       (1U << 12) /* IOAM/IFA profile valid flag.lt only */
#define CLX_MPLS_INIT_FLAGS_CW                  (1U << 13) /* Control word valid flag.nb only */
#define CLX_MPLS_INIT_FLAGS_PWEL                (1U << 14) /* Flow entropy label valid flag.nb only*/
#define CLX_MPLS_INIT_FLAGS_ESI                 (1U << 15) /* NEW push ESI label encap esi label flag.nb only */
#define CLX_MPLS_INIT_FLAGS_KEEP_INNER_TAG      (1U << 16) /* set to 1 if keep inner tag..nb only */
    UI32_T flags;
} CLX_MPLS_INIT_T;

/* MPLS LSP Tunnel Termination Entry */
typedef struct CLX_MPLS_TERM_S {
    CLX_BRIDGE_DOMAIN_T bdid;         /* LSP forwarding domain */
    CLX_PORT_VLAN_TAG_T vlan_tag;     /* VLAN TAG of inner payload (Optional) */
    UI32_T default_pcp;               /* Default PCP for inner payload (Optional) */
    UI32_T meter_id;                  /* Meter ID (Optional)*/
    UI32_T cnt_id;                    /* Service counter ID (Optional)*/
    UI32_T dist_cnt_id;               /* Distribution counter ID (Optional)*/
    UI32_T exp_to_phb_profile_id;     /* EXP to PHB mapping profile ID (Optional) */
    UI32_T pcp_dei_to_phb_profile_id; /* PCP/DEI to PHB mapping profile ID (Optional) */
    UI32_T dscp_to_phb_profile_id;    /* DSCP to PHB mapping profile ID (Optional) */
    UI32_T l2_mtu;                    /* L2 MTU value (Optional) */
    UI32_T group_label;               /* Group label (Optional) */
    UI32_T sampling_rate;             /* Sampling rate (Optional) */
    UI32_T sample_to_mir_session_id;  /* Sample packets to a mirror session (Optional) */
    UI32_T mir_session_bitmap;        /* Mirror session ID bitmap (Optional) */
    UI32_T dtel_profile_id;           /* IOAM/IFA profile ID (Optional).lt only */
    CLX_PORT_T lsp_port_bind;         /* term lcl idx bind with a lsp port.nb only */

/* Copy popped label's TTL to inner.                  \
 * Set this flag means using uniform model at egress. \
 * Otherwise, using pipe/short-pipe model             \
 */
#define CLX_MPLS_TERM_FLAGS_COPY_TTL_TO_INNER (1U << 0)
#define CLX_MPLS_TERM_FLAGS_KEEP_INNER_QOS    (1U << 1) /* Keep inner QoS flag */
#define CLX_MPLS_TERM_FLAGS_USE_INNER_PHB     (1U << 2) /* User EXP of inner LSE for PHB flag */
#define CLX_MPLS_TERM_FLAGS_DEFAULT_PCP       (1U << 3) /* Default PCP/DEI valid flag */
/* Default DEI value while Default PCP/DEI valid */
#define CLX_MPLS_TERM_FLAGS_DEFAULT_DEI        (1U << 4)
#define CLX_MPLS_TERM_FLAGS_METER              (1U << 5) /* Meter ID valid flag */
#define CLX_MPLS_TERM_FLAGS_CNT                (1U << 6) /* Service counter ID valid flag */
#define CLX_MPLS_TERM_FLAGS_DIST_CNT           (1U << 7) /* Distribution counter ID valid flag */
#define CLX_MPLS_TERM_FLAGS_EXP_TO_PHB_PROFILE (1U << 8) /* EXP to PHB profile ID valid flag */
/* PCP/DEI to PHB profile ID valid flag */
#define CLX_MPLS_TERM_FLAGS_PCP_TO_PHB_PROFILE  (1U << 9)
#define CLX_MPLS_TERM_FLAGS_DSCP_TO_PHB_PROFILE (1U << 10) /* DESP to PHB profile ID valid flag */
#define CLX_MPLS_TERM_FLAGS_VLAN_TAG            (1U << 11) /* VLAN-TAG valid flag*/
#define CLX_MPLS_TERM_FLAGS_USE_OUTER_SRV       (1U << 12) /* Use outer service flag.lt only*/
#define CLX_MPLS_TERM_FLAGS_SAMPLE_TO_MIR       (1U << 13) /* Sample packets to a mirror session */
#define CLX_MPLS_TERM_PROPERTY_FLAGS_DTEL       (1U << 14) /* IOAM/IFA profile valid flag.lt only*/
#define CLX_MPLS_TERM_FLAGS_PWCW                (1U << 15) /* Check PW CW valid flag.NB only*/
/* outer copy to inner qos_dnt_modify=1 qos_tnl_uniform=1 qos_phb_inner=0.NB only*/
#define CLX_MPLS_TERM_FLAGS_QOS_TNL_UNIFORM   (1U << 16)
#define CLX_MPLS_TERM_FLAGS_L2VPN             (1U << 17) /* is L2VPN .NB only*/
#define CLX_MPLS_TERM_FLAGS_DISABLE_MAC_LEARN (1U << 18) /* disabel mac learn.NB only*/

    UI32_T flags;
} CLX_MPLS_TERM_T;

/* MPLS label stack operation */
typedef enum {
    CLX_MPLS_LABEL_ACTION_NONE = 0,  /* No label operation */
    CLX_MPLS_LABEL_ACTION_PUSH,      /* Push labels */
    CLX_MPLS_LABEL_ACTION_SWAP,      /* Swap top label */
    CLX_MPLS_LABEL_ACTION_PHP,       /* PHP operation */
    CLX_MPLS_LABEL_ACTION_POP,       /* Pop labels */
    CLX_MPLS_LABEL_ACTION_SWAP_PUSH, /* Swap top label and then push labels */
    CLX_MPLS_LABEL_ACTION_LAST
} CLX_MPLS_LABEL_ACTION_T;

/* MPLS LSP Next Hop Label Forwarding Entry(NHLFE) for transit LSR */
typedef struct CLX_MPLS_NHLFE_S {
    CLX_BRIDGE_DOMAIN_T bdid;                  /* LSP forwarding domain.nb only */
    CLX_MPLS_LABEL_ACTION_T label_action;      /* label operation action */
    UI32_T mpls_label;                         /* swap label value */
    CLX_L3_OUTPUT_TYPE_T output_type;          /* output path type */
    UI32_T output_id;                          /* output path id */
    UI32_T frr_state_id;                       /* FRR state ID.lt only */
    CLX_L3_OUTPUT_TYPE_T frr_backup_path_type; /* FRR backup path type.lt only */
    UI32_T frr_backup_path;                    /* FRR backup path ID.lt only */
    UI32_T frr_backup_label;                   /* swap label value for FRR backup path.lt only */
    UI32_T tc;                                 /* Remark TC value. Range:0~15.lt only */
    UI32_T exp_to_phb_profile_id;              /* EXP to PHB mapping profile ID (Optional).nb only*/
    UI16_T l2_mtu_size;                        /* L2 mtu size. cl8600 only */

#define CLX_MPLS_NH_FLAGS_REMARK_TC         (1U << 0) /* Remark L-LSP Traffic Class flag.lt only */
#define CLX_MPLS_NH_FLAGS_KEEP_INNER_QOS    (1U << 1) /* Keep inner Qos for PHP case */
#define CLX_MPLS_NH_FLAGS_COPY_TTL_TO_INNER (1U << 2) /* Copy TTL to inner flag */
#define CLX_MPLS_NH_FLAGS_FRR               (1U << 3) /* FRR valid flag.lt only */
#define CLX_MPLS_NH_FLAGS_NO_DEC_TTL        (1U << 4) /* Don't decrement TTL*/
/* P2MP LSP. If the flag is set, the output_id is mcast_id */
#define CLX_MPLS_NH_FLAGS_P2MP (1U << 5)
#define CLX_MPLS_NH_FLAGS_EXP_TO_PHB_PROFILE                                             \
    (1U << 6)                                     /* EXP to PHB profile ID valid flag.nb \
                                                     only*/
#define CLX_MPLS_NH_FLAGS_USE_INNER_PHB (1U << 7) /* Use inner exp for PHB flag.nb only*/
    UI32_T flags;
} CLX_MPLS_NHLFE_T;

typedef enum {
    CLX_MPLS_PW_VPLS,  /* PW type VPLS*/
    CLX_MPLS_PW_VPWS,  /* PW type VPWS*/
    CLX_MPLS_PW_L3VPN, /* PW type L3VPN*/
    CLX_MPLS_PW_LAST
} CLX_MPLS_PW_TYPE_T;

typedef struct CLX_MPLS_PW_KEY_S {
    CLX_MPLS_PW_TYPE_T type;          /* PW type. */
    UI32_T outbound_label;            /* Outbound VPN label. */
    CLX_MPLS_MATCH_KEY_T inbound_key; /* Inbound match key, include VPN and tunnel labels. */
    CLX_VLAN_T svid; /* Service VID of trunking PW inner payload. (Optional).lt only */
    CLX_VLAN_T cvid; /* Customer VID of trunking PW inner payload. (Optional).lt only */
    CLX_L3_OUTPUT_TYPE_T output_type;             /* Outbound path type */
    UI32_T output_id;                             /* Outbound path ID */

#define CLX_MPLS_PW_KEY_FLAGS_OUT_VALID (1U << 0) /* Outbound valid flag. */
#define CLX_MPLS_PW_KEY_FLAGS_CW        (1U << 1) /* Control word valid flag.lt only*/
#define CLX_MPLS_PW_KEY_FLAGS_PWEL      (1U << 2) /* Flow entropy label valid flag.lt only */
#define CLX_MPLS_PW_KEY_FLAGS_TRUNK     (1U << 3) /* Trunking PW(nto1) flag.lt only */
#define CLX_MPLS_PW_KEY_FLAGS_SVID      (1U << 4) /* Service VLAN ID valid flag.lt only */
#define CLX_MPLS_PW_KEY_FLAGS_CVID      (1U << 5) /* Customer VLAN ID valid flag.lt only */
#define CLX_MPLS_PW_KEY_FLAGS_NO_LSP    (1U << 6) /* input only has pw label.nb only */
    UI32_T flags;
} CLX_MPLS_PW_KEY_T;

typedef struct CLX_MPLS_PW_S {
    CLX_BRIDGE_DOMAIN_T bdid;     /* L2 Forwarding Domain */
    UI32_T outbound_meter_id;     /* Meter ID for outbound PW. (Optional).lt only*/
    UI32_T inbound_meter_id;      /* Meter ID for inbound PW. (Optional).lt only*/
    UI32_T outbound_cnt_id;       /* Service counter ID for outbound PW. (Optional)..lt only */
    UI32_T inbound_cnt_id;        /* Service counter ID for inbound PW. (Optional).lt only */
    UI32_T outbound_dist_cnt_id;  /* Distribution counter ID for outbound PW. (Optional).lt only */
    UI32_T inbound_dist_cnt_id;   /* Distribution counter ID for inbound PW. (Optional).lt only */
    UI32_T phb_to_exp_profile_id; /* PHB to EXP mapping profile ID for outbound PW. (Optional).lt
                                     only */
    UI32_T phb_to_pcp_dei_profile_id; /* PHB to PCP/DEI mapping profile ID for outbound PW.
                                         (Optional).lt only */
    UI32_T pcp_dei_to_phb_profile_id; /* PCP/DEI to PHB mapping profile ID for inbound PW.
                                         (Optional).lt only */
    UI32_T exp_to_phb_profile_id;     /* EXP to PHB mapping profile ID for inbound PW. (Optional).lt
                                         only */
    UI32_T dscp_to_phb_profile_id; /* DSCP to PHB mapping profile ID for inbound PW. (Optional) .lt
                                      only*/
    CLX_PORT_T frr_backup_path;    /* interface of FRR backup path for outbound PW.lt only */
    UI32_T frr_state_id;           /* FRR State ID. (Optional).lt only */
    UI32_T bc_mcast_id;            /* The mcast_id of VPLS broadcast. (Optional).lt only */
    UI32_T uuc_mcast_id;           /* The mcast_id of VPLS Unknown unicast. (Optional).lt only */
    UI32_T umc_mcast_id;           /* The mcast_id of VPLS Unknown multicast. (Optional).lt only */
    UI32_T bud_mcast_id; /* The mcast_id of the underlay P2MP-LSP BUD. (Optional).lt only */
    UI32_T l3_intf_id;   /* The l3 interface-id of the underlay LSP. (Optional).lt only */

#define CLX_MPLS_PW_FALGS_INBOUND_METER  (1U << 0) /* Inbound meter ID valid flag.lt only */
#define CLX_MPLS_PW_FALGS_OUTBOUND_METER (1U << 1) /* Outbound meter ID valid flag.lt only */
/* Inbound service counter ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_INBOUND_CNT (1U << 2)
/* Outbound service counter ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_OUTBOUND_CNT (1U << 3)
/* Inbound distribution counter ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_INBOUND_DIST_CNT (1U << 4)
/* Outbound distribution counter ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_OUTBOUND_DIST_CNT (1U << 5)
/* PHB to EXP profile ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_PHB_TO_EXP_PROFILE (1U << 6)
/* PHB to EXP profile ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_PHB_TO_PCP_PROFILE (1U << 7)
/* EXP to PHB profile ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_EXP_TO_PHB_PROFILE (1U << 8)
/* PCP/DEI to PHB proflie ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_PCP_TO_PHB_PROFILE (1U << 9)
/* DSCP to PHB profile ID valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_DSCP_TO_PHB_PROFILE (1U << 10)
/* Don't modify inner packet's Qos attribute.lt only */
#define CLX_MPLS_PW_FLAGS_KEEP_INNER_QOS (1U << 11)
/* Use inner packet's Qos attribute for PHB.lt only */
#define CLX_MPLS_PW_FLAGS_USE_INNER_PHB     (1U << 12)
#define CLX_MPLS_PW_FLAGS_FRR               (1U << 13) /* FRR valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_COPY_TTL_TO_INNER (1U << 14) /* Copy ttl to inner flag.lt only */
#define CLX_MPLS_PW_FLAGS_ENABLE_LEARN      (1U << 15) /* Enable VPLS FDB learning flag.lt only  */
#define CLX_MPLS_PW_FLAGS_BC_MCAST_VALID    (1U << 16) /* Broadcast mcast_id valid flag.lt only */
/* Unknown unicast mcast_id valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_UUC_MCAST_VALID (1U << 17)
/* Unknown multicast mcast_id valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_UMC_MCAST_VALID (1U << 18)
#define CLX_MPLS_PW_FLAGS_BUD_MCAST_VALID (1U << 19) /* BUD mcast_id valid flag.lt only */
#define CLX_MPLS_PW_FLAGS_L3_INTF_VALID   (1U << 20) /* L3 interface ID valid flag.lt only */

    UI32_T flags;
} CLX_MPLS_PW_T;

typedef struct CLX_MPLS_AC_S {
    CLX_PORT_T port;                     /* Attachment circuit interface */
    CLX_VLAN_T svid;                     /* Service VLAN ID for AC.  */
    CLX_VLAN_T cvid;                     /* Customer VLAN ID for AC. */
    UI32_T ac_pw_bdi;                    /*ac to pw bdi.nb only*/
    UI32_T pw_ac_bdi;                    /*pw to ac bdi.nb only*/

#define CLX_MPLS_AC_FLAGS_SVID (1U << 0) /* Service VLAN ID valid flag.*/
#define CLX_MPLS_AC_FLAGS_CVID (1U << 1) /* Customer VLAN ID  valid flag.*/

    UI32_T flags;
} CLX_MPLS_AC_T;

typedef enum {
    CLX_MPLS_LABEL_TYPE_P2P_UHP = 0, /* MPLS LABEL TYPE P2P.*/
    CLX_MPLS_LABEL_TYPE_P2MP_UHP,    /* MPLS LABEL TYPE P2MP.*/
    CLX_MPLS_LABEL_TYPE_LAST
} CLX_MPLS_LABEL_TYPE_T;

/* Traverse Callbacks */
typedef CLX_ERROR_NO_T (*CLX_MPLS_INIT_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                        const CLX_PORT_T port,
                                                        const CLX_MPLS_ENCAP_KEY_T *ptr_key,
                                                        const CLX_MPLS_INIT_T *ptr_init,
                                                        void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_MPLS_TRANSIT_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                           const CLX_MPLS_MATCH_KEY_T *ptr_key,
                                                           const CLX_MPLS_NHLFE_T *ptr_nhlfe,
                                                           void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_MPLS_TERM_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                        const CLX_MPLS_MATCH_KEY_T *ptr_key,
                                                        const CLX_MPLS_TERM_T *ptr_term,
                                                        void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_MPLS_PW_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                      const UI32_T port,
                                                      const CLX_MPLS_PW_KEY_T *ptr_key,
                                                      const CLX_MPLS_PW_T *ptr_pw,
                                                      void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Create a MPLS tunnel port.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of MPLS encapsulation label stack.
 * @param [out]    ptr_port    - Pointer of MPLS tunnel port.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_createPort(const UI32_T unit, const CLX_MPLS_ENCAP_KEY_T *ptr_key, CLX_PORT_T *ptr_port);

/**
 * @brief Destroy a MPLS tunnel port.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - MPLS tunnel port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_destroyPort(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get MPLS tunnel port.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of MPLS encapsulation label stack.
 * @param [out]    ptr_port    - Pointer of MPLS tunnel port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getPort(const UI32_T unit, const CLX_MPLS_ENCAP_KEY_T *ptr_key, CLX_PORT_T *ptr_port);

/**
 * @brief Get the encapsulation of a MPLS tunnel port.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - MPLS tunnel port.
 * @param [out]    ptr_key    - Pointer of MPLS encapsulation label stack.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getKey(const UI32_T unit, const CLX_PORT_T port, CLX_MPLS_ENCAP_KEY_T *ptr_key);

/**
 * @brief Add a MPLS LSP tunnel initiation.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - MPLS tunnel port.
 * @param [in]     ptr_init    - Pointer of LSP tunnel initiation.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_addInit(const UI32_T unit, const CLX_PORT_T port, const CLX_MPLS_INIT_T *ptr_init);

/**
 * @brief Delete a MPLS LSP tunnel initiation.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - MPLS tunnel port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_delInit(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get a MPLS LSP tunnel initiation.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - MPLS tunnel port.
 * @param [out]    ptr_init    - Pointer of LSP tunnel initiation.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getInit(const UI32_T unit, const CLX_PORT_T port, CLX_MPLS_INIT_T *ptr_init);

/**
 * @brief Add a MPLS LSP tunnel termination.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of LSP tunnel termination match key.
 * @param [in]     ptr_term    - Pointer of LSP tunnel termination.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_addTerm(const UI32_T unit,
                 const CLX_MPLS_MATCH_KEY_T *ptr_key,
                 const CLX_MPLS_TERM_T *ptr_term);

/**
 * @brief Delete a MPLS LSP tunnel termination.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     ptr_key    - Pointer of LSP tunnel termination match key.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_delTerm(const UI32_T unit, const CLX_MPLS_MATCH_KEY_T *ptr_key);

/**
 * @brief Get a MPLS LSP tunnel termination.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of LSP tunnel termination match key.
 * @param [out]    ptr_term    - Pointer of LSP tunnel termination.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getTerm(const UI32_T unit, const CLX_MPLS_MATCH_KEY_T *ptr_key, CLX_MPLS_TERM_T *ptr_term);

/**
 * @brief Add a MPLS transit LSP.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_key      - Pointer of LSP transit match key.
 * @param [in]     ptr_nhlfe    - Pointer of LSP transit next hop information.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_addTransit(const UI32_T unit,
                    const CLX_MPLS_MATCH_KEY_T *ptr_key,
                    const CLX_MPLS_NHLFE_T *ptr_nhlfe);

/**
 * @brief Delete a MPLS transit LSP.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     ptr_key    - Pointer of LSP transit match key.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_delTransit(const UI32_T unit, const CLX_MPLS_MATCH_KEY_T *ptr_key);

/**
 * @brief Get a MPLS transit LSP.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_key      - Pointer of LSP transit match key.
 * @param [out]    ptr_nhlfe    - Pointer of LSP transit next hop information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getTransit(const UI32_T unit,
                    const CLX_MPLS_MATCH_KEY_T *ptr_key,
                    CLX_MPLS_NHLFE_T *ptr_nhlfe);

/**
 * @brief Create a PW port.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of PW key.
 * @param [out]    ptr_port    - Pointer PW port.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_createPwPort(const UI32_T unit, const CLX_MPLS_PW_KEY_T *ptr_key, CLX_PORT_T *ptr_port);

/**
 * @brief Destroy a PW port.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_destroyPwPort(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get a PW port.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_key     - Pointer of PW key.
 * @param [out]    ptr_port    - Pointer of PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getPwPort(const UI32_T unit, const CLX_MPLS_PW_KEY_T *ptr_key, CLX_PORT_T *ptr_port);

/**
 * @brief Get the Key of a PW port.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - PW port.
 * @param [out]    ptr_key    - Pointer of pw key.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getPwKey(const UI32_T unit, const CLX_PORT_T port, CLX_MPLS_PW_KEY_T *ptr_key);

/**
 * @brief Add a MPLS PW.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - PW port.
 * @param [in]     ptr_pw    - Pointer of MPLS PW.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_addPw(const UI32_T unit, const CLX_PORT_T port, const CLX_MPLS_PW_T *ptr_pw);

/**
 * @brief Delete a MPLS PW.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_delPw(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get a MPLS PW.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - PW port.
 * @param [out]    ptr_pw    - Pointer of MPLS PW.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getPw(const UI32_T unit, const CLX_PORT_T port, CLX_MPLS_PW_T *ptr_pw);

/**
 * @brief Add a MPLS VPWS.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - PW port.
 * @param [in]     ptr_ac    - Pointer of PW AC information.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_addVpws(const UI32_T unit, const CLX_PORT_T port, const CLX_MPLS_AC_T *ptr_ac);

/**
 * @brief Delete a MPLS VPWS.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     port    - PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_delVpws(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get a MPLS VPWS.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Pw port.
 * @param [out]    ptr_ac    - Pointer of PW AC information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getVpws(const UI32_T unit, const CLX_PORT_T port, CLX_MPLS_AC_T *ptr_ac);

/**
 * @brief Set MPLS label value range.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - MPLS label type.
 * @param [in]     min_value    - Minimum label value. Shall > 15.
 * @param [in]     max_value    - Maximum label value.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_setLabelRange(const UI32_T unit,
                       const CLX_MPLS_LABEL_TYPE_T type,
                       const UI32_T min_value,
                       const UI32_T max_value);

/**
 * @brief Get MPLS label value range.
 *
 * support_chip all
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     type             - MPLS label type.
 * @param [out]    ptr_min_value    - Pointer of minimum label value.
 * @param [out]    ptr_max_value    - Pointer of maximum label value.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_getLabelRange(const UI32_T unit,
                       const CLX_MPLS_LABEL_TYPE_T type,
                       UI32_T *ptr_min_value,
                       UI32_T *ptr_max_value);

/**
 * @brief This API is used to get all MPLS init entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_traverseInit(const UI32_T unit,
                      const CLX_MPLS_INIT_TRAVERSE_FUNC_T callback,
                      void *ptr_cookie);

/**
 * @brief This API is used to get all MPLS transit entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_traverseTransit(const UI32_T unit,
                         const CLX_MPLS_TRANSIT_TRAVERSE_FUNC_T callback,
                         void *ptr_cookie);

/**
 * @brief This API is used to get all MPLS term entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_traverseTerm(const UI32_T unit,
                      const CLX_MPLS_TERM_TRAVERSE_FUNC_T callback,
                      void *ptr_cookie);

/**
 * @brief This API is used to get all MPLS PW entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_mpls_traversePw(const UI32_T unit,
                    const CLX_MPLS_PW_TRAVERSE_FUNC_T callback,
                    void *ptr_cookie);

#endif
