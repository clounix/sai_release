/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_swc.h
 * PURPOSE:
 *      It provides switch control module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_SWC_H
#define CLX_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>
#include <clx_port.h>
#include <clx_pkt.h>

/* NAMING CONSTANT DECLARATIONS
 */

typedef enum {
    CLX_SWC_PROPERTY_IPV4_VER_ERR,   /* IPv4 header version err action. */
    CLX_SWC_PROPERTY_IPV4_CHKSM_ERR, /* IPv4 header checksum err action. */
    CLX_SWC_PROPERTY_IPV4_OPT,       /* IPv4 packet has options action. */
    CLX_SWC_PROPERTY_IPV4_LEN_ERR,   /* IPv4 header length is unmatched to payload length action. */
    CLX_SWC_PROPERTY_IPV6_VER_ERR,   /* IPv6 header version err action. */
    CLX_SWC_PROPERTY_IPV6_LEN_ERR,   /* IPv6 header total length does not cover 40-Bytes IPv6 base
                                        header. action */
    CLX_SWC_PROPERTY_GLOBAL_ROUTE_MISS_ACTION, /* Global route search miss action. */
    CLX_SWC_PROPERTY_L2_AGING_TIME,            /* Set L2 entry aging time. */
    CLX_SWC_PROPERTY_PENDING_LEARN,   /* Enable pending Learn. param0: 0: HW learn, 1: SW learn,
                                         CL8600 not support. */
    CLX_SWC_PROPERTY_ICMP_REDIRECT,   /* Packet icmp redirect type. */
    CLX_SWC_PROPERTY_L3_SELF_FORWARD, /* ICMP redirect packet copy to cpu. */
    CLX_SWC_PROPERTY_L3_URPF,         /* URPF fail action. */
    CLX_SWC_PROPERTY_L3_MCAST_ADDR_VALIDATE, /* Multicast packet destination MAC not match
                                                destination IP action. */
    CLX_SWC_PROPERTY_VXLAN_ROUTER_ALERT, /* Enable VXLAN router alert bit, CL8600 not support. */
    CLX_SWC_PROPERTY_VXLAN_UDP_PORT,     /* Set UDP destination port of VXLAN packet. */
    CLX_SWC_PROPERTY_NVGRE_ROUTER_ALERT, /* Enable NVGRE router alert bit, CL8600 not support. */
    CLX_SWC_PROPERTY_NIV_SRC_VIF, /* Set network interface virtualization source virtual interface,
                                     CL8600 not support. */
    CLX_SWC_PROPERTY_VM_FCOE_TRANS_MODE,     /* Set VM FCOE translation mode, CL8600 not support. */
    CLX_SWC_PROPERTY_MIR_ERSPAN_MISS_ACTION, /* ERSPAN term miss action. */
    CLX_SWC_PROPERTY_MIR_METER_LAYER,        /* Set mirror meter layer mode. */
    CLX_SWC_PROPERTY_STORM_CTRL_METER_LAYER, /* Enable storm control meter layer 1 IPG and Preamble.
                                              */
    CLX_SWC_PROPERTY_STORM_CTRL_CTRL_PKT_CHECK,   /* Storm control control packet check, CL8600 not
                                                     support. */
    CLX_SWC_PROPERTY_SOURCE_GUARD_DHCP_PKT_CHECK, /* IP source guard DHCP packet check, CL8600 not
                                                     support. */
    CLX_SWC_PROPERTY_FCOE_CLV_SWITCH_ENABLE,      /* Enable FCOE CLV switch, CL8600 not support. */
    CLX_SWC_PROPERTY_FCOE_DROP_UNKNOWN_MAC, /* Enable FCOE drop unknown MAC, CL8600 not support. */
    CLX_SWC_PROPERTY_STEERING_EN,           /* Enable steering. */
    /* exceptions, param0 is CLX_FWD_ACTION_T */
    CLX_SWC_PROPERTY_L2_SA_MOVE_ACTION,       /* Set source address move action, param0 is
                                                 CLX_FWD_ACTION_T */
    CLX_SWC_PROPERTY_L2_SA_MISS_ACTION,       /* Set source address miss action, param0 is
                                                 CLX_FWD_ACTION_T */
    CLX_SWC_PROPERTY_L3_IPV4_MC_MISS_ACTION,  /* IPv4 multicast search fail action. */
    CLX_SWC_PROPERTY_L3_IPV6_MC_MISS_ACTION,  /* IPv6 multicast search fail action.*/
    CLX_SWC_PROPERTY_L3_IPV4_OPT_HDR_ACTION,  /* IPv4 with option action. */
    CLX_SWC_PROPERTY_L3_IPV6_OPT_HDR_ACTION,  /* IPv6 with next header action. */
    CLX_SWC_PROPERTY_L3_IGR_MTU_FAIL_ACTION,  /* L3 ingress mtu error action. */
    CLX_SWC_PROPERTY_L3_EGR_MTU_FAIL_ACTION,  /* L3 egress mtu err action. */
    CLX_SWC_PROPERTY_L3_TTL0_ACTION,          /* L3 ttl0 action. */
    CLX_SWC_PROPERTY_L3_IGR_TTL1_ACTION,      /* L3 ingress ttl1 action, only for L3 unicast. */
    CLX_SWC_PROPERTY_L3_EGR_TTL1_ACTION,      /* L3 egress ttl1 action, CL8600 not support. */
    CLX_SWC_PROPERTY_L3T_TTL0_ACTION,         /* IP tunnel ingress ttl0 action. */
    CLX_SWC_PROPERTY_L3T_TTL1_ACTION,         /* IP tunnel ingress ttl1 action. */
    CLX_SWC_PROPERTY_L3T_IPV6_EXT_HDR_ACTION, /* IP tunnel ingress ipv6 with ext header action. */
    CLX_SWC_PROPERTY_L3T_IPV4_AH_HDR_ACTION,  /* IP tunnel ingress ipv4 with AH header action. */
    CLX_SWC_PROPERTY_L3T_IPV6_AH_HDR_ACTION,  /* IP tunnel ingress ipv6 with AH header action. */
    CLX_SWC_PROPERTY_L3_ECMP_BLOCK_SIZE, /* Configure the weighted SW mode ECMP block size, CL8600
                                            not support. */
    CLX_SWC_PROPERTY_KEEP_DEI,           /* Enable keep DEI */
    /* Configure the latency threshold to sample high latency packets for sflow. */
    /*  Lightning */
    /*  param0 is below values: */
    /*  0:disable, 512ns,    1024ns,    2048ns,    4096ns,   8192ns,*/
    /*  16384ns,   32768ns,   65536ns,   131072ns,  262144ns,       */
    /*  524288ns,  1048576ns, 2097152ns, 4194304ns, 8388608ns       */
    /*  NB */
    /*  0:disable, 1-65535ns */
    CLX_SWC_PROPERTY_SAMPLE_HIGH_LATENCY_THRESHOLD,
    CLX_SWC_PROPERTY_DTEL_IFA_MIR_ID,            /* DTEL IFA mirror ID, CL8600 not support. */
    CLX_SWC_PROPERTY_DTEL_IFA_STEER_MIR,         /* DTEL IFA steer mirror, CL8600 not support. */
    CLX_SWC_PROPERTY_DTEL_IOAM_COPY_TO_CPU,      /* DTEL IOAM copy to CPU property for ingress port,
                                                    CL8600 not support. */
    CLX_SWC_PROPERTY_DTEL_IOAM_LOOPBACK_TO_CPU,  /* DTEL IOAM loopback to CPU property for egress
                                                  * port,  should enable loopback bit in IOAM header,
                                                  * CL8600 not support.
                                                  */
    CLX_SWC_PROPERTY_DTEL_IOAM_EXCEPTION_TO_CPU, /* DTEL IOAM exception to CPU property for egress
                                                  * port, CL8600 not support. e.g. when IOAM node
                                                  * length misalignment.
                                                  */
    /* Configure whether tm traffic type is determined by inner or outer header, CL8600 not support.
     */
    CLX_SWC_PROPERTY_ECN_REMARK_USE_INNER_TCP,
    CLX_SWC_PROPERTY_L3T_LINK_LOCAL_ACTION, /* Set action when ip-tnl has Link Local IP, CL8600 not
                                               support. */
    CLX_SWC_PROPERTY_DTEL_IFA_ENABLE,       /* Enable global IFA. */
    CLX_SWC_PROPERTY_DTEL_DPP_ENABLE,       /* Enable global DPP. */
    CLX_SWC_PROPERTY_L3T_TPID_PROF,         /* L3T TPID profile, CL8600 only. */
    CLX_SWC_PROPERTY_TELM_FORCE_OFF,        /* Telemetry force off, CL8600 only. */
    CLX_SWC_PROPERTY_TELM_CLONE_PRIORITY,   /* Telemetry clone priority, CL8600 only. */
    CLX_SWC_PROPERTY_PORT_HIGH_LATENCY_THRESHOLD, /* Configure the latency threshold to high latency
                                                     packets for port. param0: 0-0x7FFF8000. CL8600
                                                     only */
    CLX_SWC_PROPERTY_L3T_TNL_PSR_ENABLE,  /* Set hw parsering different tunnel type status, default
                                             en. */
    CLX_SWC_PROPERTY_L3T_ECN_MAP,         /* IP tunnel decap ecn map. */
    CLX_SWC_PROPERTY_L2_SA_MISS_1_ACTION, /* Set source address miss 1 action, param0 is
                                             CLX_FWD_ACTION_T. Only support on CL8600 */
    CLX_SWC_PROPERTY_L3_ECMP_RESILIENT_ENABLE,      /* Set L3 Ecmp Resilient Enable. */
    CLX_SWC_PROPERTY_L3_ECMP_ALGO_MODE,             /* Set L3 Ecmp Algo Mode. */
    CLX_SWC_PROPERTY_L3_ECMP_GRPMAXNUM,             /* Set L3 Ecmp Grp Max Num. */
    CLX_SWC_PROPERTY_METER_PLANE_RATE_MAX,          /* plane meter rate max : kbps */
    CLX_SWC_PROPERTY_METER_PLANE_BUCKET_SIZE_MAX,   /* plane meter bucket size max, unit:byte */
    CLX_SWC_PROPERTY_METER_GLOBAL_RATE_MAX,         /* global meter rate max, unit:kbps */
    CLX_SWC_PROPERTY_METER_GLOBAL_BUCKET_SIZE_MAX,  /* global bucket size max, unit:byte */
    CLX_SWC_PROPERTY_METER_RATE_GRANULARITY,        /* meter rate granularity, unit:kbps */
    CLX_SWC_PROPERTY_METER_BUCKET_SIZE_GRANULARITY, /* bucket size granularity, unit:byte */
    CLX_SWC_PROPERTY_METER_PACKET_PLANE_RATE_MAX,   /* plane meter packet rate max, unit:pps */
    CLX_SWC_PROPERTY_METER_PACKET_PLANE_BUCKET_SIZE_MAX, /* plane meter packet bucket size, unit:
                                                            packet */
    CLX_SWC_PROPERTY_METER_PACKET_GLOBAL_RATE_MAX, /* global meter packet rate max, unit:pps */
    CLX_SWC_PROPERTY_METER_PACKET_GLOBAL_BUCKET_SIZE_MAX,  /* global meter packet bucket size, unit:
                                                              packet */
    CLX_SWC_PROPERTY_METER_PACKET_RATE_GRANULARITY,        /* packet rate granularity, unit: pps */
    CLX_SWC_PROPERTY_METER_PACKET_BUCKET_SIZE_GRANULARITY, /* packet bucket size granularity, unit:
                                                              packet */
    CLX_SWC_PROPERTY_CPU_DI_PROPERTY, /* Param0 is CLX_SWC_CPU_DI_PROPERTY_T, and param1 is value.
                                         Only support on CL8600 */
    CLX_SWC_PROPERTY_REASON_BLOOM_FILTER,  /* Set reason bloom filter configuration. Only support on
                                              CL8600 */
    CLX_SWC_PROPERTY_CPA,                  /* CPA mark property , Only support on CL8600
                                            * param0: CPA property type, define in CLX_SWC_PROPERTY_CPA_TYPE_T
                                            * param1: the value of the cpa property type */
    CLX_SWC_PROPERTY_CIA_TRUNC_SIZE,       /* CIA allow TM truncate size, CL8600 only*/
    CLX_SWC_PROPERTY_LAG_RESILIENT_ENABLE, /* Set Lag Resilient Enable. */
    CLX_SWC_PROPERTY_LAG_ALGO_MODE,        /* SET Lag algorithm */
    CLX_SWC_PROPERTY_CIA_ACTION_TRACING_VLAN_TPID, /* ACL vid action - push tracing vlan tpid, only
                                                      support on CL860256 */
    CLX_SWC_PROPERTY_CIA_ACTION_RULE_VLAN_TPID,    /* ACL vid action - push rule vlan tpid, only
                                                      support on CL860256 */
    CLX_SWC_PROPERTY_MEMORY_CHECK, /* Set memory check mode, only support on CL860256 */
    CLX_SWC_PROPERTY_LAST
} CLX_SWC_PROPERTY_T;

typedef enum {
    /*nvo3 key*/
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_OUTER_VID,      /* Hash key : outer L2 header outer VLAN ID. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_INNER_VID,      /* Hash key : outer L2 header inner VLAN ID. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_ETHERTYPE,      /* Hash key : outer L2 header EtherType. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_DMAC,           /* Hash key : outer L2 header destination MAC.*/
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_SMAC,           /* Hash key : outer L2 header source MAC .*/
    CLX_SWC_HASH_KEY_TYPE_OUTER_L2_MAC_NORMALIZE,  /* Hash key : outer L2 header MAC normalize. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_FLOW_LABEL,   /* Hash key : outer IPv6 flow label. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_NEXT_HEADER,  /* Hash key : outer IPv6 next header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_DIP,          /* Hash key : outer IPv6 destination IP. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_SIP,          /* Hash key : outer IPv6 source IP. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_IP_NORMALIZE, /* Hash key : outer IPv6 IP normalize. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_DPORT,    /* Hash key : outer IPv6 UDP destination port. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_SPORT,    /* Hash key : outer IPv6 UDP source port. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV6_UDP_PORT_NORMALIZE, /* Hash key : outer IPv6 UDP port
                                                            normalize. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_PROTOCOL,           /* Hash key : outer IPv4 protocol. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_DIP,                /* Hash key : outer IPv4 destination IP. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_SIP,                /* Hash key : outer IPv4 source IP. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_IP_NORMALIZE,       /* Hash key : outer IPv4 IP normalize. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_DPORT, /* Hash key : outer IPv4 UDP destination port. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_SPORT, /* Hash key : outer IPv4 UDP source port. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_IPV4_UDP_PORT_NORMALIZE, /* Hash key : outer IPv4 UDP port
                                                            normalize. */
    CLX_SWC_HASH_KEY_TYPE_TRILL_FGL,
    CLX_SWC_HASH_KEY_TYPE_TRILL_VL,
    CLX_SWC_HASH_KEY_TYPE_TRILL_EGR_RN,
    CLX_SWC_HASH_KEY_TYPE_TRILL_IGR_RN,
    CLX_SWC_HASH_KEY_TYPE_TRILL_RN_NORMALIZE,
    CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV6, /* Hash key : Vni in the IPv6-GENEVE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_GENEVE_VNI_IPV4, /* Hash key : Vni in the IPv4-GENEVE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV4, /* Hash key : Key field in the IPv4-GRE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_GRE_FLOWID_IPV6, /* Hash key : Key field in the IPv6-GRE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV4,  /* Hash key : Vni in the IPv4-VXLAN-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_VXLAN_VNI_IPV6,  /* Hash key : Vni in the IPv6-VXLAN-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV4, /* Hash key : Vsid in the IPv4-NVGRE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_NVGRE_VSID_IPV6, /* Hash key : Vsid in the IPv6-NVGRE-tunnel header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL0,     /* Hash key : 1st label in the MPLS-over-IP-tunnel
                                                    header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL1,     /* Hash key : 2nd label in the MPLS-over-IP-tunnel
                                                    header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL2,     /* Hash key : 3rd label in the MPLS-over-IP-tunnel
                                                    header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL3,     /* Hash key : 4th label in the MPLS-over-IP-tunnel
                                                    header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_MPLS_LABEL4,     /* Hash key : 5th label in the MPLS-over-IP-tunnel
                                                    header. */
    CLX_SWC_HASH_KEY_TYPE_NSH_SRV_IDX,           /* Hash key : service index in the NSH header. */
    CLX_SWC_HASH_KEY_TYPE_NSH_SRV_PATH,          /* Hash key : service path in the NSH header. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L3_DIP,          /* Hash key : outer destination IP, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L3_SIP,          /* Hash key : outer source IP, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L3_IP_NORMALIZE, /* Hash key : outer IP normalize, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L3_PROTOCOL, /* Hash key : outer transport layer protocol number,
                                                CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L4_DPORT, /* Hash key : outer L4 destination port, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L4_SPORT, /* Hash key : outer L4 source port, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_OUTER_L4_PORT_NORMALIZE, /* Hash key : outer L4 port normalize, CL8600
                                                      only. */
    /*srv key*/
    CLX_SWC_HASH_KEY_TYPE_VNTAG_SVMID,
    CLX_SWC_HASH_KEY_TYPE_VNTAG_DVMID,
    CLX_SWC_HASH_KEY_TYPE_ETAG_SVMID,
    CLX_SWC_HASH_KEY_TYPE_ETAG_DVMID,
    CLX_SWC_HASH_KEY_TYPE_VEPA_SVID,
    CLX_SWC_HASH_KEY_TYPE_L2_OUTER_VID,             /* Hash key : L2 header outer VLAN ID. */
    CLX_SWC_HASH_KEY_TYPE_L2_INNER_VID,             /* Hash key : L2 header inner VLAN ID. */
    CLX_SWC_HASH_KEY_TYPE_L2_ETHERTYPE,             /* Hash key : L2 header EtherType. */
    CLX_SWC_HASH_KEY_TYPE_L2_DMAC,                  /* Hash key : L2 header destination MAC. */
    CLX_SWC_HASH_KEY_TYPE_L2_SMAC,                  /* Hash key : L2 header source MAC. */
    CLX_SWC_HASH_KEY_TYPE_L2_MAC_NORMALIZE,         /* Hash key : L2 header MAC normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_FLOW_LABEL,          /* Hash key : IPv6 flow label. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_NEXT_HEADER,         /* Hash key : IPv6 next header. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_DIP,                 /* Hash key : IPv6 destination IP. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_SIP,                 /* Hash key : IPv6 source IP. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_IP_NORMALIZE,        /* Hash key : IPv6 IP normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_DPORT,           /* Hash key : IPv6 UDP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_SPORT,           /* Hash key : IPv6 UDP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_UDP_PORT_NORMALIZE,  /* Hash key : IPv6 UDP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_DPORT,           /* Hash key : IPv6 TCP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_SPORT,           /* Hash key : IPv6 TCP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_TCP_PORT_NORMALIZE,  /* Hash key : IPv6 TCP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_DPORT,          /* Hash key : IPv6 SCTP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_SPORT,          /* Hash key : IPv6 SCTP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV6_SCTP_PORT_NORMALIZE, /* Hash key : IPv6 SCTP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_PROTOCOL,            /* Hash key : IPv4 UDP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_DIP,                 /* Hash key : IPv4 destination IP. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_SIP,                 /* Hash key : IPv4 source IP. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_IP_NORMALIZE,        /* Hash key : IPv4 IP normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_DPORT,           /* Hash key : IPv4 UDP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_SPORT,           /* Hash key : IPv4 UDP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_UDP_PORT_NORMALIZE,  /* Hash key : IPv4 UDP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_DPORT,           /* Hash key : IPv4 TCP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_SPORT,           /* Hash key : IPv4 TCP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_TCP_PORT_NORMALIZE,  /* Hash key : IPv4 TCP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_DPORT,          /* Hash key : IPv4 SCTP destination port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_SPORT,          /* Hash key : IPv4 SCTP source port. */
    CLX_SWC_HASH_KEY_TYPE_IPV4_SCTP_PORT_NORMALIZE, /* Hash key : IPv4 SCTP port normalize. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_VFID,                /* Hash key : FCOE VFID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_SEQID,               /* Hash key : FCOE SEQID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_DID,                 /* Hash key : FCOE DID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_SID,                 /* Hash key : FCOE SID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_ID_NORMALIZE,        /* Hash key : FCOE ID normalize. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_RXID,                /* Hash key : FCOE RXID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_OXID,                /* Hash key : FCOE OXID. */
    CLX_SWC_HASH_KEY_TYPE_FCOE_XID_NORMALIZE,       /* Hash key : FCOE XID normalize. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL0,              /* Hash key : 1st label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL1,              /* Hash key : 2nd label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL2,              /* Hash key : 3rd label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL3,              /* Hash key : 4th label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_MPLS_LABEL4,              /* Hash key : 5th label in the MPLS header. */
    CLX_SWC_HASH_KEY_TYPE_IGR_PORT,                 /* Hash key : Ingress port. */
    CLX_SWC_HASH_KEY_TYPE_EGR_PORT,                 /* Hash key : Egress port. */
    CLX_SWC_HASH_KEY_TYPE_VM_TUNNEL,                /* Hash key : VM tunel. */
    CLX_SWC_HASH_KEY_TYPE_USE_INNER,                /* Hash key : Use inner. */
    CLX_SWC_HASH_KEY_TYPE_COMPRESS_IP,              /* Hash key : Compress IP. */
    CLX_SWC_HASH_KEY_TYPE_NORMALIZE,                /* Hash key : Normalize. */
    CLX_SWC_HASH_KEY_TYPE_ENTROPY,                  /* Hash key : Entropy, CL8600 only */
    CLX_SWC_HASH_KEY_TYPE_L3_DIP,                   /* Hash key : L3 destination IP, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_L3_SIP,                   /* Hash key : L3 source IP, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_L3_IP_NORMALIZE,          /* Hash key : L3 IP normalize, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_L3_PROTOCOL,       /* Hash key : L3 protocol number, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_L4_DPORT,          /* Hash key : L4 destination port, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_L4_SPORT,          /* Hash key : L4 source port, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_L4_PORT_NORMALIZE, /* Hash key : L4 port normalize, CL8600 only. */
    CLX_SWC_HASH_KEY_TYPE_NV_SEGMENT, /* Hash key : Segment ID in the NV-tunnel header, CL8600 only.
                                       */
    CLX_SWC_HASH_KEY_TYPE_LAST
} CLX_SWC_HASH_KEY_TYPE_T;

typedef enum {
    CLX_SWC_RSRC_L2_UC_ADDR = 0,                  /* L2 unicast entry resource. */
    CLX_SWC_RSRC_L2_MC_ID,                        /* L2 mcast ID resource. */
    CLX_SWC_RSRC_L3_ECMP_GROUP,                   /* L3 ECMP group resource. */
    CLX_SWC_RSRC_L3_ECMP_PATH,                    /* L3 ECMP path resource. */
    CLX_SWC_RSRC_L3_ECMP_HASH,                    /* L3 ECMP hash resource. */
    CLX_SWC_RSRC_L3_ECMP_MAX_PATH_CNT,            /* L3 ECMP max path cnt resource. */
    CLX_SWC_RSRC_L3_INTF,                         /* L3 interface resource. */
    CLX_SWC_RSRC_L3_ADJ,                          /* L3 adjacency resource. */
    CLX_SWC_RSRC_L3_ROUTER_MAC,                   /* L3 router MAC resource. */
    CLX_SWC_RSRC_L3_HOST,                         /* L3 host resource. */
    CLX_SWC_RSRC_L3_ROUTE,                        /* L3 route resource. */
    CLX_SWC_RSRC_L3_MCAST,                        /* L3 mutlcast resource. */
    CLX_SWC_RSRC_L3_RESOURCE,                     /* L3 resource. */
    CLX_SWC_RSRC_ACL_INGRESS_UCP,                 /* ACL ingress UCP resource. */
    CLX_SWC_RSRC_ACL_INGRESS_POST_UCP,            /* ACL ingress post UCP resource. */
    CLX_SWC_RSRC_ACL_UCP_ENTRY,                   /* ACL UCP entry resource. */
    CLX_SWC_RSRC_ACL_INGRESS_GROUP,               /* ACL ingress group resource. */
    CLX_SWC_RSRC_ACL_INGRESS_POST_GROUP,          /* ACL ingress post group resource. */
    CLX_SWC_RSRC_ACL_INGRESS_GROUP_ENTRY,         /* ACL ingress group entry resource. */
    CLX_SWC_RSRC_ACL_INGRESS_POST_GROUP_ENTRY,    /* ACL ingress post group entry resource. */
    CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE,     /* ACL ingress UDF key profile resource. */
    CLX_SWC_RSRC_ACL_INGRESS_UDF_KEY_PROFILE_LOU, /* ACL UDF key profile LOU resource. */
    CLX_SWC_RSRC_ACL_INGRESS_FLOW_GROUP,          /* ACL ingress flow group resource */
    CLX_SWC_RSRC_ACL_INGRESS_FLOW_GROUP_ENTRY,    /* ACL ingress flow group entry resource */
    CLX_SWC_RSRC_ACL_INGRESS_FLOW_GROUP_ID_MIN,   /* ACL ingress flow group id min */
    CLX_SWC_RSRC_ACL_INGRESS_FLOW_GROUP_ID_MAX,   /* ACL ingress flow group id max */
    CLX_SWC_RSRC_ACL_EGRESS_UCP,                  /* ACL egress UCP resource. */
    CLX_SWC_RSRC_ACL_EGRESS_POST_UCP,             /* ACL egress post UCP resource. */
    CLX_SWC_RSRC_ACL_EGRESS_GROUP,                /* ACL egress group resource. */
    CLX_SWC_RSRC_ACL_EGRESS_POST_GROUP,           /* ACL egress post group resource. */
    CLX_SWC_RSRC_ACL_EGRESS_GROUP_ENTRY,          /* ACL egress group entry resource. */
    CLX_SWC_RSRC_ACL_EGRESS_POST_GROUP_ENTRY,     /* ACL egress post group entry resource. */
    CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE,      /* ACL UDF key profile resource. */
    CLX_SWC_RSRC_ACL_EGRESS_UDF_KEY_PROFILE_LOU,  /* ACL UDF key profile LOU resource. */
    CLX_SWC_RSRC_LAG_GROUP,                       /* LAG group resource. */
    CLX_SWC_RSRC_VLAN_BDID,                       /* L2 vlan resource. */
    CLX_SWC_RSRC_PORT_LOCAL_INTF,                 /* Port local interface resource */
    CLX_SWC_RSRC_PORT_SUB_MACRO_LANE_NUM,         /* Port sub-macro lane number */
    CLX_SWC_RSRC_MAX_TS_SEC,                      /* max timestamp seconds value */
    CLX_SWC_RSRC_MIR_INGRESS_SESSION,             /* ingress mirror session number */
    CLX_SWC_RSRC_MIR_EGRESS_SESSION,              /* egress mirror session number */
    CLX_SWC_RSRC_LAST
} CLX_SWC_RSRC_T;

typedef enum {
    CLX_SWC_DATA_TYPE_REG_TABLE,   /* Register table. */
    CLX_SWC_DATA_TYPE_PP_REASON,   /* Hardware reason. */
    CLX_SWC_DATA_TYPE_DROP_REASON, /* Drop reason, CL8600 only. */
    CLX_SWC_DATA_TYPE_LAST
} CLX_SWC_DATA_TYPE_T;

typedef struct CLX_SWC_STEERING_ENTRY_S {
    UI32_T hdr_size; /* Maximum bytes(0~63); 0 means 64 bytes */
#define CLX_SWC_FLAGS_STEERING_HDR_EN     (0x1 << 0)
#define CLX_SWC_FLAGS_STEERING_HDR_UDP_EN (0x1 << 1)
    UI32_T flags;
    UI32_T port;
    CLX_TM_HANDLER_T handler;
    UI32_T tc;
    UI32_T color;
    UI32_T hdr[16];
    UI32_T vid_num;
    UI32_T ipv4_tlen_bidx; /* IPv4 total length byte index. */
    UI16_T ipv4_checksum;
    UI32_T ipv6_plen_bidx; /* IPv6 payload length byte index. */
} CLX_SWC_STEERING_ENTRY_T;

#define CLX_SWC_HASH_KEY_NUM        (CLX_SWC_HASH_KEY_TYPE_LAST)
#define CLX_SWC_HASH_KEY_WORD_WIDTH (32)
#define CLX_SWC_HASH_KEY_BITMAP_SIZE \
    (((CLX_SWC_HASH_KEY_NUM - 1) / CLX_SWC_HASH_KEY_WORD_WIDTH) + 1)

typedef UI32_T CLX_SWC_HASH_KEY_BITMAP_T[CLX_SWC_HASH_KEY_BITMAP_SIZE];

#define CLX_SWC_SET_HASHKEYBIT(key_bitmap, hash_key)                   \
    (((UI32_T *)key_bitmap)[hash_key / CLX_SWC_HASH_KEY_WORD_WIDTH] |= \
     (0x1UL << (hash_key % CLX_SWC_HASH_KEY_WORD_WIDTH)))
#define CLX_SWC_CLEAR_HASHKEYBIT(key_bitmap, hash_key)                 \
    (((UI32_T *)key_bitmap)[hash_key / CLX_SWC_HASH_KEY_WORD_WIDTH] &= \
     ~(0x1UL << (hash_key % CLX_SWC_HASH_KEY_WORD_WIDTH)))
#define CLX_SWC_CHK_HASHKEYBIT(key_bitmap, hash_key)                  \
    (((UI32_T *)key_bitmap)[hash_key / CLX_SWC_HASH_KEY_WORD_WIDTH] & \
     (0x1UL << (hash_key % CLX_SWC_HASH_KEY_WORD_WIDTH)))
#define CLX_SWC_FOREACH_HASHKEYBIT(key_bitmap, hash_key)            \
    for (hash_key = 0; hash_key < CLX_SWC_HASH_KEY_NUM; hash_key++) \
        if (CLX_SWC_CHK_HASHKEYBIT(key_bitmap, hash_key))

typedef enum {
    CLX_SWC_HASH_TYPE_ECMP_L3,    /* For egress path is normal L3 flow. */
    CLX_SWC_HASH_TYPE_ECMP_NVO3,  /* For egress path is nvo3 flow. */
    CLX_SWC_HASH_TYPE_MPLS,       /* For egress path is MPLS flow, support on CL8600. */
    CLX_SWC_HASH_TYPE_LAG,        /* LAG loading balance. */
    CLX_SWC_HASH_TYPE_LAG_FABRIC, /* LAG loading balance for fabric port selection. */
    CLX_SWC_HASH_TYPE_ECMP_L2,    /* For egress path is normal L2 flow, support on CL8600. */
    CLX_SWC_HASH_TYPE_VXLAN_UDP_SRC_PORT, /* UDP header UDP source port generation for VXLAN tunnel
                                             initiation. */
    CLX_SWC_HASH_TYPE_NVGRE_FLOW_ID, /* NVGRE header flow ID generation for NVGRE tunnel initiation.
                                      */
    CLX_SWC_HASH_TYPE_L3T_IPV6_FLOW_LABEL, /* IPv6 header flow label generation for IPv6 tunnel
                                              initiation. */
    CLX_SWC_HASH_TYPE_MPLS_ENTROPY_LABEL,  /* MPLS header entrypylable generation for tunnel
                                              initiation. */
    CLX_SWC_HASH_TYPE_MPLS_FLOW_LABEL,     /* MPLS header label generation for tunnel initiation. */
    CLX_SWC_HASH_TYPE_LAST
} CLX_SWC_HASH_TYPE_T;

typedef enum {
    CLX_SWC_ERROR_SRC_ECC = 0, /* SWC error source is ECC. */
    CLX_SWC_ERROR_SRC_LAST,
} CLX_SWC_ERROR_SRC_T;

typedef enum {
    CLX_SWC_ECC_NON_CORRECTABLE = 0, /* Error non-correctable. */
    CLX_SWC_ECC_CORRECTED,           /* Error corrected. */
} CLX_SWC_ECC_CORRECTION_T;

#define CLX_SWC_ECC_ERROR_INFO_INVALID_HUB      (0xFFFFFFFF) /* Invalid hub. */
#define CLX_SWC_ECC_ERROR_INFO_INVALID_MEMORY   (0xFFFFFFFF) /* Invalid memory0 */
#define CLX_SWC_ECC_ERROR_INFO_INVALID_TABLE_ID (0xFFFFFFFF) /* Invalid table ID. */

typedef enum {
    CLX_SWC_HASH_STAGE_TYPE_OFF = 0,
    CLX_SWC_HASH_STAGE_TYPE_8_PARALLEL,
    CLX_SWC_HASH_STAGE_TYPE_4_BY_4,
    CLX_SWC_HASH_STAGE_TYPE_2_BY_2_BY_4,
    CLX_SWC_HASH_STAGE_TYPE_4_BY_2_BY_2,
    CLX_SWC_HASH_STAGE_TYPE_2_BY_2_BY_2_BY_2,
    CLX_SWC_HASH_STAGE_TYPE_LAST
} CLX_SWC_HASH_STAGE_TYPE_T;

typedef enum {
    /*Don't modify*/
    CLX_SWC_HASH_TILE_TYPE_OFF = 0,
    CLX_SWC_HASH_TILE_TYPE_MGI,
    CLX_SWC_HASH_TILE_TYPE_MSGI,
    CLX_SWC_HASH_TILE_TYPE_POLICY,
    CLX_SWC_HASH_TILE_TYPE_L3 = 8,
    CLX_SWC_HASH_TILE_TYPE_AFIB,
    CLX_SWC_HASH_TILE_TYPE_L2UC,
    CLX_SWC_HASH_TILE_TYPE_RPFC,
    CLX_SWC_HASH_TILE_TYPE_ECMP_GRP,
    CLX_SWC_HASH_TILE_TYPE_ECMP_MBR,
    CLX_SWC_HASH_TILE_TYPE_L2_ECMP_GRP,
    CLX_SWC_HASH_TILE_TYPE_L2_ECMP_MBR,
    /*Don't modify*/
    CLX_SWC_HASH_TILE_TYPE_MPLS,
    CLX_SWC_HASH_TILE_TYPE_ARP,
    CLX_SWC_HASH_TILE_TYPE_L2MC,
    CLX_SWC_HASH_TILE_TYPE_SRV6,
    CLX_SWC_HASH_TILE_TYPE_LAST
} CLX_SWC_HASH_TILE_TYPE_T;

typedef enum {
    CLX_SWC_HASH_STAGE_0 = 0,
    CLX_SWC_HASH_STAGE_1,
    CLX_SWC_HASH_STAGE_2,
    CLX_SWC_HASH_STAGE_3,
    CLX_SWC_HASH_STAGE_4,
    CLX_SWC_HASH_STAGE_5,
    CLX_SWC_HASH_STAGE_LAST,
} CLX_SWC_HASH_STAGE_T;

typedef enum {
    CLX_SWC_HASH_TILE_0 = 0,
    CLX_SWC_HASH_TILE_1,
    CLX_SWC_HASH_TILE_2,
    CLX_SWC_HASH_TILE_3,
    CLX_SWC_HASH_TILE_4,
    CLX_SWC_HASH_TILE_5,
    CLX_SWC_HASH_TILE_6,
    CLX_SWC_HASH_TILE_7,
    CLX_SWC_HASH_TILE_LAST,
} CLX_SWC_HASH_TILE_T;

typedef enum {
    CLX_SWC_TCAM_TYPE_OFF = 0,
    CLX_SWC_TCAM_TYPE_L3_ROUTE_DA_4X,
    CLX_SWC_TCAM_TYPE_L3_ROUTE_DA,
    CLX_SWC_TCAM_TYPE_L3_ROUTE_SA_4X,
    CLX_SWC_TCAM_TYPE_L3_ROUTE_SA,
    CLX_SWC_TCAM_TYPE_L3_HOST_DA_4X,
    CLX_SWC_TCAM_TYPE_L3_HOST_DA,
    CLX_SWC_TCAM_TYPE_L3_HOST_SA_4X,
    CLX_SWC_TCAM_TYPE_L3_HOST_SA,
    CLX_SWC_TCAM_TYPE_L2UC_DA,
    CLX_SWC_TCAM_TYPE_L2UC_SA,
    CLX_SWC_TCAM_TYPE_L2MC_DA,
    CLX_SWC_TCAM_TYPE_LAST
} CLX_SWC_TCAM_TYPE_T;

typedef enum {
    CLX_SWC_TCAM_0 = 0,
    CLX_SWC_TCAM_1,
    CLX_SWC_TCAM_2,
    CLX_SWC_TCAM_3,
    CLX_SWC_TCAM_4,
    CLX_SWC_TCAM_5,
    CLX_SWC_TCAM_6,
    CLX_SWC_TCAM_7,
    CLX_SWC_TCAM_8,
    CLX_SWC_TCAM_9,
    CLX_SWC_TCAM_10,
    CLX_SWC_TCAM_11,
    CLX_SWC_TCAM_12,
    CLX_SWC_TCAM_13,
    CLX_SWC_TCAM_14,
    CLX_SWC_TCAM_15,
    CLX_SWC_TCAM_16,
    CLX_SWC_TCAM_17,
    CLX_SWC_TCAM_18,
    CLX_SWC_TCAM_19,
    CLX_SWC_TCAM_20,
    CLX_SWC_TCAM_21,
    CLX_SWC_TCAM_22,
    CLX_SWC_TCAM_23,
    CLX_SWC_TCAM_24,
    CLX_SWC_TCAM_25,
    CLX_SWC_TCAM_26,
    CLX_SWC_TCAM_27,
    CLX_SWC_TCAM_28,
    CLX_SWC_TCAM_29,
    CLX_SWC_TCAM_30,
    CLX_SWC_TCAM_31,
    CLX_SWC_TCAM_32,
    CLX_SWC_TCAM_33,
    CLX_SWC_TCAM_34,
    CLX_SWC_TCAM_35,
    CLX_SWC_TCAM_36,
    CLX_SWC_TCAM_37,
    CLX_SWC_TCAM_38,
    CLX_SWC_TCAM_39,
    CLX_SWC_TCAM_40,
    CLX_SWC_TCAM_41,
    CLX_SWC_TCAM_42,
    CLX_SWC_TCAM_43,
    CLX_SWC_TCAM_44,
    CLX_SWC_TCAM_45,
    CLX_SWC_TCAM_46,
    CLX_SWC_TCAM_47,
    CLX_SWC_TCAM_48,
    CLX_SWC_TCAM_49,
    CLX_SWC_TCAM_50,
    CLX_SWC_TCAM_51,
    CLX_SWC_TCAM_52,
    CLX_SWC_TCAM_53,
    CLX_SWC_TCAM_54,
    CLX_SWC_TCAM_55,
    CLX_SWC_TCAM_56,
    CLX_SWC_TCAM_57,
    CLX_SWC_TCAM_58,
    CLX_SWC_TCAM_59,
    CLX_SWC_TCAM_60,
    CLX_SWC_TCAM_61,
    CLX_SWC_TCAM_62,
    CLX_SWC_TCAM_63,
    CLX_SWC_TCAM_LAST
} CLX_SWC_TCAM_T;

typedef enum {
    CLX_SWC_CPU_DI_PROPERTY_PRIORITY,
    CLX_SWC_CPU_DI_PROPERTY_L2UC_CPU_PORT,
    CLX_SWC_CPU_DI_PROPERTY_L2UC_CPU_QUEUE,
    CLX_SWC_CPU_DI_PROPERTY_L3UC_CPU_PORT,
    CLX_SWC_CPU_DI_PROPERTY_L3UC_CPU_QUEUE,
} CLX_SWC_CPU_DI_PROPERTY_T;

typedef enum {
    CLX_SWC_REASON_BLOOM_FILTER_TYPE_ENABLE = 0, /* Enable bloom filter. */
    CLX_SWC_REASON_BLOOM_FILTER_TYPE_COUNTER,    /* Set bloom filter counter. (1 ~ (2^32)-1) */
    CLX_SWC_REASON_BLOOM_FILTER_TYPE_TIMER,      /* Set bloom filter timer (1ns ~ 3s) */
    CLX_SWC_REASON_BLOOM_FILTER_TYPE_LAST
} CLX_SWC_REASON_BLOOM_FILTER_TYPE_T;

typedef enum {
    CLX_SWC_PROPERTY_TRUNC_SIZE_NONE = 0, /* 0: disable trunction */
    CLX_SWC_PROPERTY_TRUNC_SIZE_64,       /* 1: 64 if pkt size > 64 */
    CLX_SWC_PROPERTY_TRUNC_SIZE_128,      /* 2: 128 if pkt size > 128 */
    CLX_SWC_PROPERTY_TRUNC_SIZE_192,      /* 3: 192 if pkt size > 192 */
    CLX_SWC_PROPERTY_TRUNC_SIZE_256,      /* 4: 256 if pkt size > 256 */
    CLX_SWC_PROPERTY_TRUNC_SIZE_512,      /* 5: 512 if pkt size > 512 */
    CLX_SWC_PROPERTY_TRUNC_SIZE_984,      /* 6: 984 if pkt size > 984 */
    CLX_SWC_PROPERTY_TRUNC_SIZE_LAST
} CLX_SWC_PROPERTY_TRUNC_SIZE_T;

typedef enum {
    CLX_SWC_PROPERTY_CPA_TYPE_EN,               /* Enable cpa mark */
    CLX_SWC_PROPERTY_CPA_TYPE_PPL_IDX,          /* CPA PPL index in tcp reserved field */
    CLX_SWC_PROPERTY_CPA_TYPE_CPA_IDX,          /* CPA support index in tcp reserved field */
    CLX_SWC_PROPERTY_CPA_TYPE_REDO_QOS_EN,      /* CPA redo qos enable */
    CLX_SWC_PROPERTY_CPA_TYPE_REDO_QOS_DSCP,    /* CPA redo qos dscp value */
    CLX_SWC_PROPERTY_CPA_TYPE_REDO_QOS_DCP_DEI, /* CPA redo qos pcp and dei value */
    CLX_SWC_PROPERTY_CPA_TYPE_HIGH_PRI_QUEUE,   /* CPA packet high priority queue */
    CLX_SWC_PROPERTY_CPA_TYPE_TRUNCATION_SIZE,  /* CPA truncation size, only support
                                                 * 64/128/192/256/512/1024 byte,  value define in
                                                 * CLX_SWC_PROPERTY_TRUNC_SIZE_T */
    CLX_SWC_PROPERTY_CPA_TYPE_LAST
} CLX_SWC_PROPERTY_CPA_TYPE_T;

typedef enum {
    CLX_SWC_CPUDI_CPU_ID = 0,
    CLX_SWC_CPUDI_ECPU_ID,
    CLX_SWC_CPUDI_CPI0_ID,
    CLX_SWC_CPUDI_CPI1_ID,
    CLX_SWC_CPUDI_LAST
} CLX_SWC_CPUDI_T;

typedef enum {
    CLX_SWC_HASH_PKT_TYPE_NORMAL,
    CLX_SWC_HASH_PKT_TYPE_NON_DECAP_TUNNEL,
    CLX_SWC_HASH_PKT_TYPE_DEDCAP_TUNNEL,
    CLX_SWC_HASH_PKT_TYPE_LAST
} CLX_SWC_HASH_PKT_TYPE_T;

typedef struct {
    UI32_T hub;                            /* Invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_HUB. */
    UI32_T memory;                         /* Invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_MEMORY. */
    UI32_T single_error_addr;              /* Single error address. */
    UI32_T double_error_addr;              /* Double error address. */

    UI32_T inst;                           /* Table inst. */
    UI32_T sub_inst;                       /* Table sub-inst. */
    UI32_T table_id;                       /* Invalid : CLX_SWC_ECC_ERROR_INFO_INVALID_TABLE_ID. */
    UI32_T single_error_table_entry_start; /* Single error table entry start. */
    UI32_T single_error_table_entry_end;   /* Single error table entry end. */
    UI32_T double_error_table_entry_start; /* Double error table entry start. */
    UI32_T double_error_table_entry_end;   /* Double error table entry end. */

    UI32_T single_error_cnt;               /* Single error count. */
    UI32_T double_error_cnt;               /* Double error count. */

    CLX_SWC_ECC_CORRECTION_T single_error_correction; /* Single error correction state. */
    CLX_SWC_ECC_CORRECTION_T double_error_correction; /* Double error correction state. */
} CLX_SWC_ERROR_INFO_ECC_T;

typedef struct {
    union {
        CLX_SWC_ERROR_INFO_ECC_T ecc_info; /* ECC error info. */
    };
} CLX_SWC_ERROR_INFO_T;

typedef void (*CLX_SWC_ERROR_FUNC_T)(const UI32_T unit,
                                     const CLX_SWC_ERROR_INFO_T *ptr_error_info,
                                     void *ptr_cookie);

typedef struct CLX_SWC_DEVICE_INFO_S {
    UI32_T vendor_id;
    UI32_T device_id;
    C8_T device_pn[32];
    UI32_T revision_id;
} CLX_SWC_DEVICE_INFO_T;

typedef struct CLX_SWC_PORT_CONFIG_S {
    CLX_PORT_BITMAP_T bitmap_all;    /* Include active, inactive eth, mxlink, cpu, and cpi ports. */
    CLX_PORT_BITMAP_T bitmap_active; /* Include active eth, mxlink, cpu, and cpi ports. */
    CLX_PORT_BITMAP_T bitmap_mxlink; /* Active mxlink ports. */
    CLX_PORT_BITMAP_T bitmap_breakout; /* Active breakout ports. */
    CLX_PORT_BITMAP_T bitmap_cpu;      /* Active cpu ports. */
    CLX_PORT_BITMAP_T bitmap_cpi;      /* Active cpi ports. */
    CLX_PORT_BITMAP_T bitmap_rcp;      /* Active recirculation ports. */
    CLX_PORT_BITMAP_T bitmap_1g;       /* Active 1g ports. */
    CLX_PORT_BITMAP_T bitmap_10g;      /* Active 10g ports. */
    CLX_PORT_BITMAP_T bitmap_25g;      /* Active 25g ports. */
    CLX_PORT_BITMAP_T bitmap_40g;      /* Active 40g ports. */
    CLX_PORT_BITMAP_T bitmap_50g;      /* Active 50g ports. */
    CLX_PORT_BITMAP_T bitmap_100g;     /* Active 100g ports. */
    CLX_PORT_BITMAP_T bitmap_200g;     /* Active 200g ports. */
    CLX_PORT_BITMAP_T bitmap_400g;     /* Active 400g ports. */
    CLX_PORT_BITMAP_T bitmap_800g;     /* Active 800g ports. */
} CLX_SWC_PORT_CONFIG_T;

typedef enum {
    CLX_SWC_CSO_MODE_SLAVE = 0, /* CSO mode slave. */
    CLX_SWC_CSO_MODE_MASTER,    /* CSO mode master. */
    CLX_SWC_CSO_MODE_LAST
} CLX_SWC_CSO_MODE_T;

typedef struct CLX_SWC_CPI_ENCAP_HDR_S {
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_EN        (0x1 << 0)
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN (0x1 << 1) /* If set, use udp_source_port. */
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_CPU_QUEUE_EN                                    \
    (0x1 << 2)              /* If set, CPI queue will be encoded in UDP source port.   \
                             * invalid when flag CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN \
                             * is set. */
#define CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_PORT_EN                                        \
    (0x1 << 3)              /* If set, ingress port or egress port will be encoded in \
                             * UDP source port. Invalid when flag                     \
                             * CLX_SWC_FLAGS_CPI_ENCAP_UDP_SP_FIX_EN is set. */
    UI32_T flags;
    UI32_T encap_size;      /* 0: no encap. */
    UI8_T hdr[64];
    UI32_T ipv4_tlen_bidx;  /* IPv4 total length byte index. */
    UI16_T ipv4_checksum;   /* IPv4 checksum with total length of 0. */
    UI16_T udp_source_port; /* UDP header source port value. */
} CLX_SWC_CPI_ENCAP_HDR_T;

typedef struct {
    BOOL_T hash_engine_enable;          /* 0: disable; 1: enable */
    BOOL_T inner_five_tuple_enable;     /* 0: disable; 1: enable */
    BOOL_T ip_fragment_l4_inner_enable; /* 0: disable; 1: enable */
    BOOL_T ip_fragment_l4_outer_enable; /* 0: disable; 1: enable */
    UI32_T inner_l4_src_port_mask;      /* mask for inner l4 source port */
    UI32_T outer_l4_src_port_mask;      /* mask for outer l4 source port */
    BOOL_T hash_algo_murmur;            /* 0: GF16; 1: Murmur */
    UI32_T seed;                        /* seed for Murmur or GF16 algorithm */
    UI32_T fac; /* fac for GF16 algorithm. if the fac is 0, use the first 16 bits of the original
                   seed value as the parameter. */
#define CLX_SWC_HASH_ENGINE_ATTR_ENABLE               (1U << 0)
#define CLX_SWC_HASH_ENGINE_ATTR_INNER_FIVE_TUPLE     (1U << 1)
#define CLX_SWC_HASH_ENGINE_ATTR_IP_FRG_L4_INNER_PORT (1U << 2)
#define CLX_SWC_HASH_ENGINE_ATTR_IP_FRG_L4_OUTER_PORT (1U << 3)
#define CLX_SWC_HASH_ENGINE_ATTR_INNER_L4_SRC_PORT    (1U << 4)
#define CLX_SWC_HASH_ENGINE_ATTR_OUTER_L4_SRC_PORT    (1U << 5)
#define CLX_SWC_HASH_ENGINE_ATTR_ALGORITHM            (1U << 6)
#define CLX_SWC_HASH_ENGINE_ATTR_ALL                  0xFFFFFFFF
    UI32_T attr_bitmap;
} CLX_SWC_HASH_ENGINE_T;

/* RX Packet Reasons Aciton */
typedef struct {
    CLX_FWD_ACTION_T action;
    CLX_SWC_CPUDI_T cpu_id;
    UI32_T cpu_queue;
    CLX_PKT_DROP_REASON_T drop_reason;
    BOOL_T sa_learn;
    BOOL_T bloom_filter_en;
#define CLX_SWC_CPU_REASON_ATTR_ACTION       (1U << 0)
#define CLX_SWC_CPU_REASON_ATTR_CPU_QUEUE    (1U << 1)
#define CLX_SWC_CPU_REASON_ATTR_DROP_REASON  (1U << 2)
#define CLX_SWC_CPU_REASON_ATTR_SA_LEARN     (1U << 3)
#define CLX_SWC_CPU_REASON_ATTR_BLOOM_FILTER (1U << 4)
#define CLX_SWC_CPU_REASON_ATTR_ALL          0xFFFFFFFF
    UI32_T attr_bitmap;
} CLX_SWC_RX_REASON_ACTION_T;

typedef struct CLX_SWC_FLOW_HASH_SI_L2_KEY_S {
    UI32_T si;
    CLX_MAC_T dmac;
    CLX_MAC_T smac;
} CLX_SWC_FLOW_HASH_SI_L2_KEY_T;

typedef struct CLX_SWC_FLOW_HASH_L2_VID_KEY_S {
    UI32_T svlan;
    UI32_T cvlan;
    UI32_T ether_type;
} CLX_SWC_FLOW_HASH_L2_VID_KEY_T;

typedef struct CLX_SWC_FLOW_HASH_L3_IP_KEY_S {
    CLX_IP_T ip_addr;
    BOOL_T ipv4;
} CLX_SWC_FLOW_HASH_L3_IP_KEY_T;

typedef struct CLX_SWC_FLOW_HASH_L4_KEY_S {
    UI32_T l3_ipv6_flw_lbl;
    UI32_T l3_ulp;
    UI32_T l4_dp;
    UI32_T l4_sp;
    UI32_T tnl_vni;
    UI32_T entropy;
} CLX_SWC_FLOW_HASH_L4_KEY_T;

typedef struct CLX_SWC_FLOW_HASH_MPLS_KEY_S {
    UI32_T mpls_label[4];
} CLX_SWC_FLOW_HASH_MPLS_KEY_T;

typedef struct CLX_SWC_FLOW_HASH_L4_INNER_KEY_S {
    UI32_T l3_ulp;
    UI32_T l4_dp;
    UI32_T l4_sp;
} CLX_SWC_FLOW_HASH_L4_INNER_KEY_T;

typedef struct CLX_SWC_FLOW_HASH_KEY_S {
    CLX_SWC_FLOW_HASH_SI_L2_KEY_T si_l2_key;
    CLX_SWC_FLOW_HASH_L2_VID_KEY_T l2_vid_key;
    CLX_SWC_FLOW_HASH_L3_IP_KEY_T l3_dip_key;
    CLX_SWC_FLOW_HASH_L3_IP_KEY_T l3_sip_key;
    CLX_SWC_FLOW_HASH_MPLS_KEY_T mpls_key;
    CLX_SWC_FLOW_HASH_L4_KEY_T l4_key;
    CLX_SWC_FLOW_HASH_L3_IP_KEY_T l3_dip_inner_key;
    CLX_SWC_FLOW_HASH_L3_IP_KEY_T l3_sip_inner_key;
    CLX_SWC_FLOW_HASH_L4_INNER_KEY_T l4_inner_key;
#define CLX_SWC_FLOW_HASH_MPLS_KEY_VALID (1 << 0)
#define CLX_SWC_FLOW_HASH_KEY_IS_OUTER   (1 << 1)
#define CLX_SWC_FLOW_HASH_KEY_IS_IP_FRG  (1 << 2)
#define CLX_SWC_FLOW_HASH_KEY_NO_CARE_HW (1 << 3)
    UI32_T flags;
} CLX_SWC_FLOW_HASH_KEY_T;

#define CLX_SWC_THERMAL_NUM_MAX  (32)
#define CLX_SWC_THERMAL_NAME_LEN (32)

typedef struct {
    C8_T thermal_name[CLX_SWC_THERMAL_NAME_LEN];
    I32_T thermal_value;
} CLX_SWC_THERMAL_T;

typedef struct {
    UI32_T thermal_count;
    CLX_SWC_THERMAL_T thermal_list[CLX_SWC_THERMAL_NUM_MAX];
} CLX_SWC_THERMAL_LIST_T;

typedef struct CLX_SWC_HASH_PATH_RSLT_INFO_S {
    UI32_T port_id;
    CLX_PORT_TYPE_T port_type;
    UI32_T output_id;
    UI32_T hash_value;
} CLX_SWC_HASH_PATH_RSLT_INFO_T;

typedef struct CLX_SWC_HASH_PATH_PKT_INFO_S {
    CLX_SWC_HASH_PKT_TYPE_T pkt_type;
    BOOL_T ip_fragment;
    BOOL_T mpls;
} CLX_SWC_HASH_PATH_PKT_INFO_T;

typedef struct CLX_SWC_SELECT_FLOW_KEY_S {
    UI32_T enable;                 /* enable/disable selective flow */
    CLX_SWC_HASH_TYPE_T hash_type; /* only support CLX_SWC_HASH_TYPE_LAG */
    UI32_T hash_value;
    UI32_T hash_mask;
    UI32_T src_port;
    UI32_T mir_id;
#define CLX_SWC_SELECTIVE_FLOW_FLAGS_SRC_PORT (1U << 0)  /* set source port */
    UI32_T flags;
#define CLX_SWC_SELECTIVE_FLOW_ATTR_ENABLE     (1U << 0) /* set/get enable */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_HASH_TYPE  (1U << 1) /* set/get hash_type */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_HASH_VALUE (1U << 2) /* set/get hash_value */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_HASH_MASK  (1U << 3) /* set/get hash_mask */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_SRC_PORT   (1U << 4) /* set/get src_port */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_MIR_ID     (1U << 5) /* set/get mir_id */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_ALL        0xffffffff
    UI32_T attr_bitmap;
} CLX_SWC_SELECTIVE_FLOW_CFG_T;

typedef enum {
    CLX_SWC_CHIP_CFG_INFO_TYPE_BD_ID_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_BD_ID_MAX,

    CLX_SWC_CHIP_CFG_INFO_TYPE_VLAN_ID_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_VLAN_ID_MAX,

    CLX_SWC_CHIP_CFG_INFO_TYPE_TYPE_VLAN_INDEX_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TYPE_VLAN_INDEX_MAX,

    CLX_SWC_CHIP_CFG_INFO_TYPE_L2_AGE_SEC_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_L2_AGE_SEC_MAX,

    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_CPU_QUEUE_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_PORT_PFC_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_CELL_SIZE,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_LEGACY_QUEUE_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_UNICAST_QUEUE_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_MULTICAST_QUEUE_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_BURST_SIZE_MAX_NUM,

    CLX_SWC_CHIP_CFG_INFO_TYPE_LAST
} CLX_SWC_CHIP_CFG_INFO_TYPE_T;

typedef enum {
    CLX_SWC_CHIP_PLL_STATUS_LOCKED,
    CLX_SWC_CHIP_PLL_STATUS_UNLOCKED,
    CLX_SWC_CHIP_PLL_STATUS_ERROR,
    CLX_SWC_CHIP_PLL_STATUS_IDLE,
    CLX_SWC_CHIP_PLL_STATUS_BUSY
} CLX_SWC_CHIP_PLL_STATUS_T;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/**
 * @brief Set switch control hash keys.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     hash_type     - Hash type
 * @param [in]     key_bitmap    - Hash key bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_setHashKey(const UI32_T unit,
                   const CLX_SWC_HASH_TYPE_T hash_type,
                   const CLX_SWC_HASH_KEY_BITMAP_T key_bitmap);

/**
 * @brief Get switch control hash keys.
 *
 * support_chip all
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     hash_type        - Hash type
 * @param [out]    ptr_key_bitmap   - Hash key bitmap
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getHashKey(const UI32_T unit,
                   const CLX_SWC_HASH_TYPE_T hash_type,
                   CLX_SWC_HASH_KEY_BITMAP_T *ptr_key_bitmap);

/**
 * @brief Set hash engine configuration.
 *
 * support_chip CL8600
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     hash_type      - Hash engine
 * @param [in]     hash_engine    - Hash engine attributes
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
clx_swc_setHashEngine(const UI32_T unit,
                      const CLX_SWC_HASH_TYPE_T hash_type,
                      const CLX_SWC_HASH_ENGINE_T *hash_engine);

/**
 * @brief Get hash engine configuration.
 *
 * support_chip CL8600
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     hash_type      - Hash engine
 * @param [out]    hash_engine    - Pointer to hash engine attributes
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
clx_swc_getHashEngine(const UI32_T unit,
                      const CLX_SWC_HASH_TYPE_T hash_type,
                      CLX_SWC_HASH_ENGINE_T *hash_engine);

/**
 * @brief Set switch control property.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [in]     param0      - First parameter
 * @param [in]     param1      - Second parameter
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_setProperty(const UI32_T unit,
                    const CLX_SWC_PROPERTY_T property,
                    const UI32_T param0,
                    const UI32_T param1);

/**
 * @brief Get switch control property.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [out]    ptr_param0  - First parameter
 * @param [out]    ptr_param1  - Second parameter
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */

CLX_ERROR_NO_T
clx_swc_getProperty(const UI32_T unit,
                    const CLX_SWC_PROPERTY_T property,
                    UI32_T *ptr_param0,
                    UI32_T *ptr_param1);

/**
 * @brief Set timestamp value of system.
 *
 * support_chip all
 *
 * @param [in]     unit       - Chip id
 * @param [in]     sec_hi     - Bit[47:32] seconds for timestamp
 * @param [in]     sec_low    - Bit[31:0]  seconds for timestamp
 * @param [in]     nsec       - Bit[29:0]  nano seconds for timestamp
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
clx_swc_setTsValue(const UI32_T unit, UI16_T sec_hi, UI32_T sec_low, UI32_T nsec);

/**
 * @brief Get timestamp value of system.
 *
 * support_chip all
 *
 * @param [in]     unit           - Chip id
 * @param [out]    ptr_sec_hi     - Bit[47:32] seconds for timestamp
 * @param [out]    ptr_sec_low    - Bit[31:0]  seconds for timestamp
 * @param [out]    ptr_nsec       - Bit[29:0]  nano seconds for timestamp
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
clx_swc_getTsValue(const UI32_T unit, UI16_T *ptr_sec_hi, UI32_T *ptr_sec_low, UI32_T *ptr_nsec);

/**
 * @brief Set timestamp offset.
 *
 * support_chip all
 *
 * @param [in]     unit    - Chip id
 * @param [in]     nsec    - Signed nano seconds for timestamp offset
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
clx_swc_setTsOffset(const UI32_T unit, const I32_T nsec);

/**
 * @brief Set the configuration of egress view of steering.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_str_entry    - Structure of egress steering
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_setSteering(const UI32_T unit, const CLX_SWC_STEERING_ENTRY_T *ptr_str_entry);

/**
 * @brief Get the configuration of egress view of steering.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit             - Device unit number
 * @param [out]    ptr_str_entry    - Structure of egress steering
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getSteering(const UI32_T unit, CLX_SWC_STEERING_ENTRY_T *ptr_str_entry);

/**
 * @brief Set hash engine polynomial coefficients
 *
 * It's caller's responsibility to pass an array of correct size.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     count             - Size (number of elements) of array pointed by ptr_hash_const
 * @param [in]     ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
clx_swc_setHashConstant(const UI32_T unit,
                        const CLX_SWC_HASH_TYPE_T hash_type,
                        const UI32_T count,
                        const UI32_T *ptr_hash_const);

/**
 * @brief Get hash engine polynomial coefficients
 *
 * It's caller's responsibility to pass an array of correct size.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     count             - Size (number of elements) of array pointed by ptr_hash_const
 * @param [out]    ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getHashConstant(const UI32_T unit,
                        const CLX_SWC_HASH_TYPE_T hash_type,
                        const UI32_T count,
                        UI32_T *ptr_hash_const);

/**
 * @brief Set hash engine polynomial coefficients by a specific key field
 *
 * It's caller's responsibility to pass an array of correct size.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     key               - Hash key of interest
 * @param [in]     ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHER            - Config fail
 */
CLX_ERROR_NO_T
clx_swc_setHashConstantByKey(const UI32_T unit,
                             const CLX_SWC_HASH_TYPE_T hash_type,
                             const CLX_SWC_HASH_KEY_TYPE_T key,
                             const UI32_T *ptr_hash_const);

/**
 * @brief Get hash engine polynomial coefficients by a specific key field
 *
 * It's caller's responsibility to pass an array of correct size.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     hash_type         - Hash engine to be config
 * @param [in]     key               - Hash key of interest
 * @param [out]    ptr_hash_const    - Pointer to array of constants
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getHashConstantByKey(const UI32_T unit,
                             const CLX_SWC_HASH_TYPE_T hash_type,
                             const CLX_SWC_HASH_KEY_TYPE_T key,
                             UI32_T *ptr_hash_const);

/**
 * @brief Register error callback function.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     error         - error source type
 * @param [in]     callback      - The callback function of type CLX_SWC_ERROR_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_registerErrorCallback(const UI32_T unit,
                              const CLX_SWC_ERROR_SRC_T error,
                              const CLX_SWC_ERROR_FUNC_T callback,
                              void *ptr_cookie);

/**
 * @brief Deregister error callback function.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     error         - error source type
 * @param [in]     callback      - The callback function of type CLX_SWC_ERROR_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_deregisterErrorCallback(const UI32_T unit,
                                const CLX_SWC_ERROR_SRC_T error,
                                const CLX_SWC_ERROR_FUNC_T callback,
                                void *ptr_cookie);

/**
 * @brief Get device information.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number
 * @param [out]    ptr_device_info    - The device information
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getDeviceInfo(const UI32_T unit, CLX_SWC_DEVICE_INFO_T *ptr_device_info);

/**
 * @brief Get port bitmap of current config.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number
 * @param [out]    ptr_port_config    - Port bitmaps of current config
 * @return         CLX_E_OK        - Operation success
 * @return         CLX_E_OTHERS    - Error occurs
 */
CLX_ERROR_NO_T
clx_swc_getPortConfig(const UI32_T unit, CLX_SWC_PORT_CONFIG_T *ptr_port_config);

/**
 * @brief Get resource capacity
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Resource type
 * @param [in]     param       - Parameter if necessary
 * @param [out]    ptr_size    - Size of capacity
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getCapacity(const UI32_T unit,
                    const CLX_SWC_RSRC_T type,
                    const UI32_T param,
                    UI32_T *ptr_size);

/**
 * @brief Get resource usage.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - Resource type
 * @param [in]     param      - Parameter if necessary
 * @param [out]    ptr_cnt    - Count of usage
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getUsage(const UI32_T unit, const CLX_SWC_RSRC_T type, const UI32_T param, UI32_T *ptr_cnt);

/**
 * @brief Set clock servo mode.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     mode    - Clock servo mode
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_setCsoMode(const UI32_T unit, const CLX_SWC_CSO_MODE_T mode);

/**
 * @brief Get clock servo mode.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [out]    ptr_mode    - Clock servo mode
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getCsoMode(const UI32_T unit, CLX_SWC_CSO_MODE_T *ptr_mode);

/**
 * @brief Get chip temperature.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_swc_getChipTemperature(const UI32_T unit, I32_T *ptr_temperature);

/**
 * @brief Get chip temperature.
 *
 * support_chip CL8500, CL8600
 *
 * @param [in]     unit                    - Device unit number.
 * @param [out]    ptr_temperature_list    - Chip temperature list
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_swc_getChipTemperatureList(const UI32_T unit, CLX_SWC_THERMAL_LIST_T *ptr_temperature_list);

/**
 * @brief Get chip pll status.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                    - Device unit number.
 * @param [out]    ptr_pll_status          - Pointer to chip pll status.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_swc_getChipPLLStatus(const UI32_T unit, CLX_SWC_CHIP_PLL_STATUS_T *ptr_pll_status);

/**
 * @brief Set CPI port enacp.
 *
 * support_chip all
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - CPI port.
 * @param [in]     ptr_encap_hdr    - Structure of encap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 */
CLX_ERROR_NO_T
clx_swc_setCpiEncap(const UI32_T unit,
                    const UI32_T port,
                    const CLX_SWC_CPI_ENCAP_HDR_T *ptr_encap_hdr);

/**
 * @brief Get CPI port enacp.
 *
 * support_chip all
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - CPI port.
 * @param [out]    ptr_encap_hdr    - Structure of encap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 */

CLX_ERROR_NO_T
clx_swc_getCpiEncap(const UI32_T unit, const UI32_T port, CLX_SWC_CPI_ENCAP_HDR_T *ptr_encap_hdr);

/**
 * @brief Set RX reason action.
 *        Asign drop reason code if fowarding action is dropping.
 *        Asign CPU qeueu if fowarding action is copy to CPU or redirect to CPU.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     rx_reason_code      - rx reason code
 * @param [in]     rx_reason_action    - rx reason aciton
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_setRxReasonAction(const UI32_T unit,
                          const CLX_PKT_RX_REASON_T rx_reason_code,
                          const CLX_SWC_RX_REASON_ACTION_T *rx_reason_action);

/**
 * @brief Get RX reason action. Get drop reason code or cpu queue.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     rx_reason_code      - rx reason code
 * @param [in]     rx_reason_action    - rx reason aciton
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getRxReasonAction(const UI32_T unit,
                          const CLX_PKT_RX_REASON_T rx_reason_code,
                          CLX_SWC_RX_REASON_ACTION_T *rx_reason_action);

/**
 * @brief This function is to set reason priority.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @param [in]     priority          - reason priority
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_setRxReasonPriority(const UI32_T unit,
                            const CLX_PKT_RX_REASON_T rx_reason_code,
                            const UI32_T priority);

/**
 * @brief This function is to get reason priority.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @param [out]    priority          - reason priority
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getRxReasonPriority(const UI32_T unit,
                            const CLX_PKT_RX_REASON_T rx_reason_code,
                            UI32_T *priority);

/**
 * @brief This function is to get Tod Info.
 *
 * support_chip all
 *
 * @param [in]     unit    - device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getTodInfo(const UI32_T unit);

/**
 * @brief This function is to get chip configurable information.
 *
 * support_chip all
 *
 * @param [in]     unit     - Device unit number, get chip configuration is required, but get global
 * configuration is not required
 * @param [in]     type     - Type for get chip configurable information
 * @param [in]     para0    - Parameter0 if necessary
 * @param [in]     para1    - Parameter1 if necessary
 *                            ptr_value
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         other                - Operate fail
 */
CLX_ERROR_NO_T
clx_swc_getChipCfgInfo(const UI32_T unit,
                       const CLX_SWC_CHIP_CFG_INFO_TYPE_T type,
                       const UI32_T para0,
                       const UI32_T para1,
                       UI32_T *ptr_value);

/**
 * @brief This function retrieves the string name based on the index.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     data_type       - Data Type
 * @param [in]     index           - Index
 * @param [in]     str_len         - String length
 * @param [out]    str_name        - String name
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         other                - Operate fail
 */
CLX_ERROR_NO_T
clx_swc_getStringNameById(const UI32_T unit,
                          const CLX_SWC_DATA_TYPE_T data_type,
                          const UI32_T index,
                          const UI32_T str_len,
                          C8_T *str_name);

/**
 * @brief To get packet hash path.
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     hash_type       - Hash type
 * @param [in]     ptr_hash_key    - Pointer of hash key
 * @param [in]     id              - Lag id / ECMP group id
 * @param [out]    ptr_rslt        - Pointer of result
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHER     - Init fail
 */
CLX_ERROR_NO_T
clx_swc_getPktHashPath(const UI32_T unit,
                       const CLX_SWC_HASH_TYPE_T hash_type,
                       const CLX_SWC_FLOW_HASH_KEY_T *ptr_hash_key,
                       const UI32_T id,
                       CLX_SWC_HASH_PATH_RSLT_INFO_T *ptr_rslt);

/**
 * @brief To get hash path key
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     hash_type       - Hash type
 * @param [in]     pkt_info        - Packet info
 * @param [out]    ptr_key_bitmap  - Pointer of key bitmap
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_OTHER     - Init fail
 */
CLX_ERROR_NO_T
clx_swc_getHashPathKey(const UI32_T unit,
                       const CLX_SWC_HASH_TYPE_T hash_type,
                       const CLX_SWC_HASH_PATH_PKT_INFO_T pkt_info,
                       CLX_SWC_HASH_KEY_BITMAP_T *ptr_key_bitmap);

/**
 * @brief To set selective flow config
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_select_cfg      - Selective flow config
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         CLX_E_BAD_PARAMETER     - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_setSelectiveFlowMir(const UI32_T unit, const CLX_SWC_SELECTIVE_FLOW_CFG_T *ptr_select_cfg);

/**
 * @brief To get selective flow config
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [out]    ptr_select_cfg      - Selective flow config
 * @return         CLX_E_OK        - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not support
 * @return         CLX_E_BAD_PARAMETER     - Bad parameter
 */
CLX_ERROR_NO_T
clx_swc_getSelectiveFlowMir(const UI32_T unit, CLX_SWC_SELECTIVE_FLOW_CFG_T *ptr_select_cfg);
#endif
