/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_acl.h
 * PURPOSE:
 *      It provides ACL module API.
 * NOTES:
 */

#ifndef CLX_ACL_H
#define CLX_ACL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <clx_pkt.h>
#include <clx_fcoe.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_ACL_PKG_NUM          (48) /* Maximum ACL PKG key byte number for ACL */
#define CLX_ACL_FLOW_PKG_NUM     (31) /* Maximum ACL PKG key byte number for Flow */
#define CLX_ACL_FLOW_1_PKG_NUM   (16) /* Maximum ACL PKG key byte number for Flow_1 */
#define CLX_ACL_LOU_NUM          (16) /* Maximum LOU number for each udf profile */
#define CLX_ACL_REWRITE_NUM      (9)  /* Maximum FCM rewrite profile number */
#define CLX_ACL_REWRITE_DATA_NUM (16) /* Maximum FCM rewrite byte number without mask */
#define CLX_ACL_REWRITE_MASK_NUM (8)  /* Maximum FCM rewrite byte number with mask */
#define CLX_ACL_FLOW_WORDS       (5)

/* MACRO FUNCTION DECLARATIONS */

/* DATA TYPE DECLARATIONS
 */

typedef enum {
    CLX_ACL_GROUP_INGRESS = 0,  /* ingress stage */
    CLX_ACL_GROUP_EGRESS,       /* egress stage */
    CLX_ACL_GROUP_INGRESS_POST, /* ingress post stage */
    CLX_ACL_GROUP_EGRESS_POST,  /* egress post stage */
    CLX_ACL_GROUP_LAST
} CLX_ACL_GROUP_T;

typedef enum {
    CLX_ACL_L2_FRAME_ETHERNET = 0, /* Ethernet frame */
    CLX_ACL_L2_FRAME_RFC1042,      /* RFC1042 */
    CLX_ACL_L2_FRAME_SNAP_OTHER, /* DSAP=0xAA, SSAP=0xAA, Control=0x3, Org Code not zero, CL8600 not
                                    support.*/
    CLX_ACL_L2_FRAME_LLC_OTHER,  /* L2 has LLC header but not SNAP */
    CLX_ACL_L2_FRAME_LAST
} CLX_ACL_L2_FRAME_T;

typedef enum {
    CLX_ACL_VM_TAG_NONE = 0, /* No VM tag */
    CLX_ACL_VM_TAG_ETAG,     /* Etag */
    CLX_ACL_VM_TAG_VNTAG,    /* VNTAG */
    CLX_ACL_VM_TAG_VEPA,     /* VEPA */
    CLX_ACL_VM_TAG_LAST
} CLX_ACL_VM_TAG_T;

typedef enum {
    CLX_ACL_TNL_IPV4 = 0,   /* IPv4 tunnel type */
    CLX_ACL_TNL_IPV4_GRE,   /* IPv4 GRE tunnel type, CL8600 not support */
    CLX_ACL_TNL_IPV4_VXLAN, /* IPv4 Vxlan tunnel type, CL8600 not support */
    CLX_ACL_TNL_MPLS,       /* MPLS tunnel type, CL8600 only */
    CLX_ACL_TNL_IPV6,       /* IPv6 tunnel type */
    CLX_ACL_TNL_IPV6_GRE,   /* IPv6 GRE tunnel type, CL8600 not support*/
    CLX_ACL_TNL_IPV6_VXLAN, /* IPv6 Vxlan tunnel type, CL8600 not support */
    CLX_ACL_TNL_LAST
} CLX_ACL_TNL_T;

typedef enum {
    CLX_ACL_FCOE_HDR_NOT_EXISTED = 0, /* header not exist */
    CLX_ACL_FCOE_HDR_STD,             /* std header */
    CLX_ACL_FCOE_HDR_VFT,             /* vft header */
    CLX_ACL_FCOE_HDR_IFR,             /* ifr header */
    CLX_ACL_FCOE_HDR_ENCAP,           /* encap header */
    CLX_ACL_FCOE_HDR_UNKNOWN,         /* unknown header */
    CLX_ACL_FCOE_HDR_LAST
} CLX_ACL_FCOE_HDR_T;

typedef enum {
    CLX_ACL_FRG_NONE = 0, /* None fragment packet */
    CLX_ACL_FRG_FIRST,    /* First fragment packet, fragment offset field is zero */
    CLX_ACL_FRG_MIDDLE,   /* Middle fragment packet, fragment offset and more fragments flag fields
                             are not zero */
    CLX_ACL_FRG_END,      /* Final fragment packet, more fragments flag is 0 in the flags field */
    CLX_ACL_FRG_LAST
} CLX_ACL_FRG_T;

typedef enum {
    CLX_ACL_TTL_ZERO = 0, /* TTL is 0 */
    CLX_ACL_TTL_ONE,      /* TTL is 1 */
    CLX_ACL_TTL_GT_ONE,   /* TTL is grater than 1 */
    CLX_ACL_TTL_LAST
} CLX_ACL_TTL_T;

typedef enum {
    CLX_ACL_ARP_FRAME_ARP_REQUEST = 0, /* ARP frame type is ARP request */
    CLX_ACL_ARP_FRAME_ARP_RESPONSE,    /* ARP frame type is ARP response */
    CLX_ACL_ARP_FRAME_LAST,
} CLX_ACL_ARP_FRAME_T;

typedef enum {
    CLX_ACL_MAC_FRAME_PKT_NO_VLAN = 0, /* no vlan tag packet */
    CLX_ACL_MAC_FRAME_PKT_SINGLE_VLAN, /* match svid in 1ad; match cvid in 1q
                                        * treat cvid as 1st vid if s_tpid is the same as c_tpid */
    CLX_ACL_MAC_FRAME_PKT_DOUBLE_VLAN, /* double vlan tag packet */
    CLX_ACL_MAC_FRAME_PKT_VLAN_LAST,
} CLX_ACL_PKT_VLAN_TYPE_T;

typedef enum {
    /* for BASE_L2 KEY/BASE L3 KEY,
     * if use tc_color as key, can not use pcp/dei/dscp/ecn as key */
    CLX_ACL_GROUP_FORMAT_TC_COLOR = (1U << 0),
    CLX_ACL_GROUP_FORMAT_UDF_KEY_SINGLE = (1U << 1), /* single udf key */
    CLX_ACL_GROUP_FORMAT_UDF_KEY_DOUBLE = (1U << 2), /* double udf key, not supported on CL8360*/
    /* replace lsb 32bits as L3 da/sa label of udf key. defeature*/
    CLX_ACL_GROUP_FORMAT_UDF_L3_FLOW_LABEL_ENABLE = (1U << 3),
    CLX_ACL_GROUP_FORMAT_L2_BIDIR = (1U << 4),    /* l2 sa/da bi-direction */
    CLX_ACL_GROUP_FORMAT_L3_BIDIR = (1U << 5),    /* l3 sa/da bi-direction */
    CLX_ACL_GROUP_FORMAT_L4_BIDIR = (1U << 6),    /* l4 dp/sp bi-direction */
    CLX_ACL_GROUP_FORMAT_BASE_KEY_L2 = (1U << 7), /* l2 base key */
    CLX_ACL_GROUP_FORMAT_BASE_KEY_L3 = (1U << 8), /* l3 base key */
    /* replace BASE IP DA addr by flow_label  */
    CLX_ACL_GROUP_FORMAT_BASE_LABEL_REPLACE_DA = (1U << 9),
    /* replace BASE IP SA addr by flow_label  */
    CLX_ACL_GROUP_FORMAT_BASE_LABEL_REPLACE_SA = (1U << 10),
} CLX_ACL_GROUP_FORMAT_T;

typedef enum {
    CLX_ACL_RIM_ALLOC_FCM = 0,                /* fcm */
    CLX_ACL_RIM_ALLOC_FLOW_FCM,               /* flow fcm */
    CLX_ACL_RIM_ALLOC_REDIRECT_TYPE_L2_UC,    /* redirect l2_uc */
    CLX_ACL_RIM_ALLOC_REDIRECT_TYPE_L3_UC,    /* redirect l3_uc */
    CLX_ACL_RIM_ALLOC_REDIRECT_TYPE_L3_ECMP,  /* redirect l3_ecmp */
    CLX_ACL_RIM_ALLOC_REDIRECT_TYPE_L2_MC,    /* redirect l2_mc */
    CLX_ACL_RIM_ALLOC_REDIRECT_TYPE_L3_MC,    /* redirect l3_mc */
    CLX_ACL_RIM_ALLOC_REDIRECT_TYPE_CPU,      /* redirect cpu */
    CLX_ACL_RIM_ALLOC_REDIRECT_TYPE_L2_MGLAG, /* redirect l2_mglag */
    CLX_ACL_RIM_ALLOC_LAST
} CLX_ACL_RIM_ALLOC_T;

typedef CLX_ERROR_NO_T (*CLX_ACL_RIM_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                      const void *ptr_action,
                                                      void *ptr_cookie);

typedef struct CLX_ACL_GROUP_PROFILE_S {
    UI32_T mac_pkt_format_bitmap;  /* CLX_ACL_GROUP_FORMAT_T, acl search only */
    UI32_T arp_pkt_format_bitmap;  /* CLX_ACL_GROUP_FORMAT_T, acl search only */
    UI32_T ipv4_pkt_format_bitmap; /* CLX_ACL_GROUP_FORMAT_T, acl search only */
    UI32_T ipv6_pkt_format_bitmap; /* CLX_ACL_GROUP_FORMAT_T, acl search only */
    UI32_T fcoe_pkt_format_bitmap; /* CLX_ACL_GROUP_FORMAT_T, acl search only. Not support CL8600 */
    UI32_T mpls_pkt_format_bitmap; /* CLX_ACL_GROUP_FORMAT_T, acl search only. CL8600 only */
    UI32_T flow_ignore_mask[CLX_ACL_FLOW_WORDS]; /* set to 1 to mask out corresponding bit as don’t
                                                    care on flw_key, CL8600 only */
    UI32_T group_size; /* Fixed group size, should be multiple of 1024 for lt,
                        * 512 for mt series. Not support auto-extend if assign group_size */

/* acl search only.                                       \
 * for pure BASE_L2/L3_KEY, if use port bitmap as key,    \
 * can not use intf_group_label, l2/l3_da/sa_group_label, \
 * ingress_acl_group_label, arp.tpa as key.               \
 */
#define CLX_ACL_GROUP_PROFILE_FLAGS_PORT_BITMAP (1U << 0)
/* CL8600 only, select lou                                       \
 * availible only if CLX_ACL_GROUP_PROFILE_FLAGS_PORT_BITMAP and \
 * CLX_ACL_GROUP_PROFILE_FLAGS_GROUP_LABEL are not selected.     \
 */
#define CLX_ACL_GROUP_PROFILE_FLAGS_LOU (1U << 1)
/* CL8600 only, IGR: da/sa group label; EGR: igr_group_label. \
 * conflict with CLX_ACL_GROUP_PROFILE_FLAGS_PORT_BITMAP.     \
 */
#define CLX_ACL_GROUP_PROFILE_FLAGS_GROUP_LABEL (1U << 2)
#define CLX_ACL_GROUP_PROFILE_FLAGS_ARP_TPA                                                       \
    (1U << 3) /* CL8600 arp pkt_format only, conflict with                                        \
               * CLX_ACL_GROUP_PROFILE_FLAGS_PORT_BITMAP, CLX_ACL_GROUP_PROFILE_FLAGS_GROUP_LABEL \
               * and CLX_ACL_GROUP_PROFILE_FLAGS_LOU.                                             \
               */
#define CLX_ACL_GROUP_PROFILE_FLAGS_FLOW_IGNORE_MASK (1U << 4)
#define CLX_ACL_GROUP_PROFILE_FLAGS_FLOW             (1U << 5) /* flow only */
/* CL8600 flow only, replace lsb 16 bits as da_label of udf key. */
#define CLX_ACL_GROUP_PROFILE_FLAGS_FLOW_DA_LABEL (1U << 6)
/* CL8600 flow only, replace lsb 16 bits as sa_label of udf key. */
#define CLX_ACL_GROUP_PROFILE_FLAGS_FLOW_SA_LABEL (1U << 7)
/* acl only, not support auto-extend if enable this flag \
 * for light series should be multiples of 1024          \
 * for mountain series should be multiples of 512 */
#define CLX_ACL_GROUP_PROFILE_FLAGS_SIZE (1U << 8)
/* acl only, indicate acl flow entry could use action pointer to acl result. \
 * Not allow to add acl entry into this group anymore */
#define CLX_ACL_GROUP_PROFILE_FLAGS_PREEMPT_BY_FLOW (1U << 9)
    UI32_T flags; /* CLX_ACL_GROUP_PROFILE_XXX flags */
} CLX_ACL_GROUP_PROFILE_T;

typedef struct CLX_ACL_PKT_FORMAT_S {
    UI16_T ethertype;                 /* ethertype key */
    UI16_T ethertype_mask;            /* ethertype key mask */
    UI8_T protocol;                   /* ip protocol */
    UI8_T protocol_mask;              /* ip protocol mask */
    UI16_T src_port;                  /* l4 source port */
    UI16_T src_port_mask;             /* l4 source port mask */
    UI16_T dst_port;                  /* l4 destination port */
    UI16_T dst_port_mask;             /* l4 destination port mask */
    CLX_ACL_L2_FRAME_T l2_frame_type; /* l2 frame type */
    CLX_ACL_VM_TAG_T vm_tag_type;     /* vm tag type, ingress only */
    CLX_ACL_TNL_T tnl_type;           /* tunnel type and decap pass = 1, ingress only */

#define CLX_ACL_PKT_FORMAT_FLAGS_L2_FRAME_TYPE_VALID (1U << 0) /* l2 frame type flag */
#define CLX_ACL_PKT_FORMAT_FLAGS_VM_TAG_TYPE_VALID   (1U << 1) /* vm tag type flag, ingress only */
#define CLX_ACL_PKT_FORMAT_FLAGS_TNL_TYPE_VALID      (1U << 2) /* tunnel type flag, ingress only */
#define CLX_ACL_PKT_FORMAT_FLAGS_STAG_VALID          (1U << 3) /* service vlan tag valid flag */
#define CLX_ACL_PKT_FORMAT_FLAGS_CTAG_VALID          (1U << 4) /* custom vlan tag valid flag */
/* indicates ctag_valid is in 1'st or 2'nd vlan */
#define CLX_ACL_PKT_FORMAT_FLAGS_VLAN_TAG_MODE_1Q (1U << 5)
#define CLX_ACL_PKT_FORMAT_FLAGS_L2_SKIP_0_VALID  (1U << 6) /* L2 skip tag valid flag */
#define CLX_ACL_PKT_FORMAT_FLAGS_L2_SKIP_1_VALID  (1U << 7) /* L2 skip tag valid flag */
    UI32_T flags;                                           /* CLX_ACL_PKT_FORMAT_XXX flags*/
    UI32_T flags_mask;                                      /* CLX_ACL_PKT_FORMAT_XXX flags*/
} CLX_ACL_PKT_FORMAT_T;

typedef enum {
    CLX_ACL_PKG_BASE_NONE = 0,
    CLX_ACL_PKG_BASE_START_TNL_HDR, /* tunnel header start, not supported on CL8600, ingress only */
    CLX_ACL_PKG_BASE_START_L2_HDR,  /* l2 header start */
    CLX_ACL_PKG_BASE_START_L3_HDR,  /* l3 header start */
    CLX_ACL_PKG_BASE_START_L4_HDR,  /* l4 header start */
    CLX_ACL_PKG_BASE_END_TNL_HDR, /* tunnel header end, not supported on CL8360 and CL8600, ingress
                                     only */
    CLX_ACL_PKG_BASE_END_L2_HDR,  /* l2 header end, not supported on CL8360 and CL8600 */
    CLX_ACL_PKG_BASE_END_L3_HDR,  /* l3 header end, not supported on CL8360 and CL8600 */
    CLX_ACL_PKG_BASE_END_L4_HDR,  /* l4 header end, not supported on CL8360 and CL8600 */
    CLX_ACL_PKG_BASE_LAST
} CLX_ACL_PKG_BASE_T;

typedef struct CLX_ACL_PKG_CFG_S {
    CLX_ACL_PKG_BASE_T type; /* pkg type */
    UI32_T offset;           /* byte offset */
    UI32_T mask;             /* pkg data mask, acl search only */

/* Both first and second must select this flag. \
 * For consecutive byte, type, offset mask must be zero. */
#define CLX_ACL_PKG_FLAGS_CONSECUTIVE_BYTE (1U << 0)
    UI32_T flags; /* CLX_ACL_PKG_FLAGS_XXX */
} CLX_ACL_PKG_CFG_T;

typedef enum {
    /* l2 sa group label, lt: ingress only; mt: ingress flow only */
    CLX_ACL_UDF_INTERNAL_KEY_L2_SA_GROUP_LABEL = (1U << 0),
    /* l2 da group label, lt: ingress only; mt: ingress flow only */
    CLX_ACL_UDF_INTERNAL_KEY_L2_DA_GROUP_LABEL = (1U << 1),
    /* l3 sa group label, need to enable
     * CLX_CFG_TYPE_TCAM_L3_SIP_ENABLE
     * for Tcam search, lt: ingress only; mt: ingress flow only */
    CLX_ACL_UDF_INTERNAL_KEY_L3_SA_GROUP_LABEL = (1U << 2),
    /* l3 da group label, lt: ingress only; mt: ingress flow only */
    CLX_ACL_UDF_INTERNAL_KEY_L3_DA_GROUP_LABEL = (1U << 3),
    CLX_ACL_UDF_INTERNAL_KEY_INTF_GROUP_LABEL = (1U << 4), /* interface group label, ingress only */
    /* l2 service group label, not supported on CL8600, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_SERVICE_GROUP_LABEL = (1U << 5),
    CLX_ACL_UDF_INTERNAL_KEY_LOU = (1U << 6),         /* lou key.*/
    CLX_ACL_UDF_INTERNAL_KEY_PORT_BITMAP = (1U << 7), /* port bitmap key, supported on CL8570 and
                                                         acl search only. not support flow entry */
    CLX_ACL_UDF_INTERNAL_KEY_BDID = (1U << 8),        /* bridge domain id, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_VRF = (1U << 9), /* virtual routing and forwarding id, ingress only */
    /* l3 interface id, not supported on CL8600, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_L3_INTF_ID = (1U << 10),
    /* service vlan id, not supported on CL8360 and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_STAG_VID = (1U << 11),
    /* custom vlan id, not supported on CL8360 and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_CTAG_VID = (1U << 12),
    /* service vlan pcp/dei, not supported on CL8360 and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_STAG_PCP_DEI = (1U << 13),
    /* custom vlan pcp/dei, not supported on CL8360 and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_CTAG_PCP_DEI = (1U << 14),
    /* vlan tag mode 802.1q, not supported on CL8360, ingress only,
       indicates ctag_vid/pcp_dei is in 1'st or 2'nd vlan */
    CLX_ACL_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q = (1U << 15),
    CLX_ACL_UDF_INTERNAL_KEY_L3_ROUTE = (1U << 16),  /* is l3 routing, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_TCP_FLAGS = (1U << 17), /* 12 bits TCP flags, CL8600 only */
    /* 16 bits ingress acl group label, CL8600 egr only */
    CLX_ACL_UDF_INTERNAL_KEY_IGR_ACL_GROUP_LABEL = (1U << 18),
} CLX_ACL_UDF_INTERNAL_KEY_T;

typedef struct CLX_ACL_UDF_KEY_PROFILE_S {
    CLX_ACL_PKG_CFG_T pkg_cfg[CLX_ACL_PKG_NUM]; /* pkg key config */
    UI32_T pkg_cnt;             /* CL8360: max 41, CL8570: max 46, CL8600: 48 for consective mode.*/
    UI32_T internal_key_bitmap; /* CLX_ACL_UDF_INTERNAL_KEY_T */

    CLX_ACL_PKG_CFG_T flow_pkg_cfg[CLX_ACL_FLOW_PKG_NUM]; /* ingress only */
    UI32_T flow_pkg_cnt;                                  /* ingress only */
    UI32_T flow_internal_key_bitmap;                      /* ingress only */
    UI32_T flow_profile_id; /* Not supported on CL8360 and CL8600, ingress only.
                               If flow 1 search is invalid, value of flow_profile_id
                               must be (udf_key_profile_id & 0x3c/3d/3e/3f) */
    CLX_ACL_PKG_CFG_T flow_1_pkg_cfg[CLX_ACL_FLOW_1_PKG_NUM]; /* Not supported on CL8360 and CL8600,
                                                                 ingress only */
    UI32_T flow_1_pkg_cnt;             /* Not supported on CL8360 and CL8600, ingress only */
    UI32_T flow_1_internal_key_bitmap; /* Not supported on CL8360 and CL8600, ingress only */
    UI32_T flow_1_profile_id;          /* Not supported on CL8360 and CL8600, ingress only */
#define CLX_ACL_UDF_KEY_PROFILE_FLAGS_FLOW_PROFILE_ID_VALID   (1U << 0) /* flow profile flag */
#define CLX_ACL_UDF_KEY_PROFILE_FLAGS_FLOW_1_PROFILE_ID_VALID (1U << 1) /* flow 1 profile flag */
    UI32_T flags; /*CLX_ACL_UDF_KEY_PROFILE_FLAGS_XXX flags*/
} CLX_ACL_UDF_KEY_PROFILE_T;

typedef enum {
    CLX_ACL_LOU_NONE = 0,      /* No lou*/
    CLX_ACL_LOU_SVID,          /* service vlan range */
    CLX_ACL_LOU_CVID,          /* custom vlan range */
    CLX_ACL_LOU_IP_TTL,        /* ip ttl range */
    CLX_ACL_LOU_SRC_PORT,      /* l4 source port range */
    CLX_ACL_LOU_DST_PORT,      /* l4 destination port range */
    CLX_ACL_LOU_PKG,           /* pkg key range */
    CLX_ACL_LOU_IP_TOTAL_LEN,  /* IP packet total length range */
    CLX_ACL_LOU_VID_NUM,       /* VID number, CL8600 ingress only*/
    CLX_ACL_LOU_IP_TOS,        /* IP TOS range */
    CLX_ACL_LOU_FRAME_LEN,     /* L2 frame length range, CL8600 ingress only*/
    CLX_ACL_LOU_VRF,           /* L3 VRF range, ingress only */
    CLX_ACL_LOU_BDID,          /* Bridge domain range */
    CLX_ACL_LOU_IGR_ACL_LABEL, /* ingress acl group label, CL8600 egress only */
    CLX_ACL_LOU_LAST
} CLX_ACL_LOU_T;

typedef struct CLX_ACL_LOU_CFG_S {
    CLX_ACL_LOU_T type;                         /* lou type */
    CLX_ACL_PKG_BASE_T pkg_base_type;           /* pkg base type if select CLX_ACL_LOU_PKG */
    UI32_T pkg_offset;                          /* pkg byte offset */
    UI16_T val_mask;                            /* value mask */
    UI16_T val_max;                             /* range value maximum */
    UI16_T val_min;                             /* range value minimum */
    UI8_T lou_or_bmap;                          /* each bit set to 1 indicates the corresponding
                                                 * lou participates in the logical "OR" operation of
                                                 * bit map profile, lou_or_bmap is zero means logical "AND"
                                                 * within 16 lou of udf key profile */
#define CLX_ACL_LOU_CFG_FLAGS_INVERSE (1U << 0) /* range inverse */
/* indicates lou_cvid is in 1'st or 2'nd vlan */
#define CLX_ACL_LOU_CFG_FLAGS_VLAN_TAG_MODE_1Q (1U << 1)
#define CLX_ACL_LOU_CFG_FLAGS_ACL_VALID        (1U << 2) /* acl search only*/
#define CLX_ACL_LOU_CFG_FLAGS_FLOW_VALID       (1U << 3) /* ingress only */
/* Not supported on CL8360 and CL8600, ingress only */
#define CLX_ACL_LOU_CFG_FLAGS_FLOW_1_VALID (1U << 4)
    UI32_T flags; /* CLX_ACL_LOU_CFG_XXX flags*/
} CLX_ACL_LOU_CFG_T;

typedef enum {
    CLX_ACL_CLASSIFY_KEY_MAC = 0, /* mac frame classify key */
    CLX_ACL_CLASSIFY_KEY_ARP,     /* arp frame classify key */
    CLX_ACL_CLASSIFY_KEY_IPV4,    /* ipv4 frame classify key */
    CLX_ACL_CLASSIFY_KEY_IPV6,    /* ipv6 frame classify key */
    CLX_ACL_CLASSIFY_KEY_FCOE,    /* fcoe frame classify key */
    CLX_ACL_CLASSIFY_KEY_MPLS,    /* mpls frame classify key */
    CLX_ACL_CLASSIFY_KEY_UDF,     /* udf frame classify key */
    CLX_ACL_CLASSIFY_KEY_LAST
} CLX_ACL_CLASSIFY_KEY_T;

typedef struct CLX_ACL_MAC_KEY_S {
    CLX_MAC_T dmac;                                         /* destination mac */
    CLX_MAC_T dmac_mask;                                    /* destination mac mask */
    CLX_MAC_T smac;                                         /* source mac */
    CLX_MAC_T smac_mask;                                    /* source mac mask */
    UI16_T ether_type;                                      /* ether type */
    UI16_T ether_type_mask;                                 /* ether type mask */
    CLX_ACL_PKT_VLAN_TYPE_T pkt_vlan_type;                  /* packet vlan tag type */

#define CLX_ACL_MAC_KEY_FLAGS_PKT_VLAN_TYPE_VALID (1U << 0) /* packet vlan tag type flag */
/* indicates ctag_valid is in 1'st or 2'nd vlan */
#define CLX_ACL_MAC_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 1)
    UI32_T flags; /* CLX_ACL_MAC_KEY_FLAGS_XXX flags */
} CLX_ACL_MAC_KEY_T;

typedef struct CLX_ACL_ARP_KEY_S {
    CLX_MAC_T sender_mac;                      /* sender mac */
    CLX_MAC_T sender_mac_mask;                 /* sender mac mask */
    CLX_IPV4_T sender_ip;                      /* sender ip address */
    CLX_IPV4_T sender_ip_mask;                 /* sender ip address mask */
    CLX_MAC_T target_mac;                      /* target mac */
    CLX_MAC_T target_mac_mask;                 /* target mac mask*/
    CLX_IPV4_T target_ip;                      /* target ip address */
    CLX_IPV4_T target_ip_mask;                 /* target ip address mask */
    CLX_ACL_ARP_FRAME_T arp_frame_type;        /* arp frame type */

#define CLX_ACL_ARP_FRAME_TYPE_VALID (1U << 0) /* arp frame valid flag */
    UI32_T flags;                              /* CLX_ACL_ARP_XXX flags */
} CLX_ACL_ARP_KEY_T;

typedef struct CLX_ACL_IPV4_KEY_S {
    CLX_IPV4_T dip;         /* destination ip address */
    CLX_IPV4_T dip_mask;    /* destination ip address mask */
    CLX_IPV4_T sip;         /* source ip address */
    CLX_IPV4_T sip_mask;    /* source ip address mask*/
    UI8_T protocol;         /* ip protocol */
    UI8_T protocol_mask;    /* ip protocol mask */
    UI16_T dst_port;        /* l4 destination port */
    UI16_T dst_port_mask;   /* l4 destination port mask */
    UI16_T src_port;        /* l4 source port */
    UI16_T src_port_mask;   /* l4 source port mask */
    UI16_T tcp_flag;        /* tcp flag lt: 7bits encode, mt: 12bits */
    UI16_T tcp_flag_mask;   /* tcp flag mask, must be all one or all zero for lt */
    UI8_T icmp_type;        /* icmp type value */
    UI8_T icmp_type_mask;   /* icmp type mask */
    UI8_T icmp_code;        /* icmp code value */
    UI8_T icmp_code_mask;   /* icmp code value mask */
    UI8_T igmp_type;        /* igmp type value */
    UI8_T igmp_type_mask;   /* igmp type value mask */
    CLX_ACL_FRG_T frg_type; /* ip fragment type */
    CLX_ACL_TTL_T ttl_type; /* ttl type */

#define CLX_ACL_IPV4_KEY_FLAGS_FRG_TYPE_VALID (1U << 0) /* ip fragment type valid flag */
#define CLX_ACL_IPV4_KEY_FLAGS_TTL_TYPE_VALID (1U << 1) /* ttl type valid flag */
#define CLX_ACL_IPV4_KEY_FLAGS_AUTH_HDR_EXIST (1U << 2) /* Authentication header exist flag */
#define CLX_ACL_IPV4_KEY_FLAGS_OPT_HDR_EXIST  (1U << 3) /* option header exist flag */
    UI32_T flags;                                       /* CLX_ACL_IPV4_KEY_XXX flags */
    UI32_T flags_mask;                                  /* CLX_ACL_IPV4_KEY_XXX flags mask */
} CLX_ACL_IPV4_KEY_T;

typedef struct CLX_ACL_IPV6_KEY_S {
    CLX_IPV6_T dip;                     /* destination ip address */
    CLX_IPV6_T dip_mask;                /* destination ip address mask */
    CLX_IPV6_T sip;                     /* source ip address */
    CLX_IPV6_T sip_mask;                /* source ip address mask */
    UI8_T protocol;                     /* ip protocol */
    UI8_T protocol_mask;                /* ip protocol mask */
    UI32_T flow_label;                  /* flow label */
    UI32_T flow_label_mask;             /* flow label mask */
    UI8_T first_ext_hdr_protocol;       /* first extension header protocol */
    UI8_T first_ext_hdr_protocol_mask;  /* first extension header protocol mask, must be all one or
                                           all zero */
    UI8_T second_ext_hdr_protocol;      /* second extension header protocol */
    UI8_T second_ext_hdr_protocol_mask; /* second extension header protocol, must be all one or all
                                           zero */
    UI16_T dst_port;                    /* l4 destination port */
    UI16_T dst_port_mask;               /* l4 destination port mask */
    UI16_T src_port;                    /* l4 source port */
    UI16_T src_port_mask;               /* l4 source port mask */
    UI16_T tcp_flag;                    /* tcp flag lt: 7bits encode, mt: 12bits */
    UI16_T tcp_flag_mask;               /* tcp flag mask, must be all one or all zero for lt */
    UI8_T icmp_type;                    /* icmp type value */
    UI8_T icmp_type_mask;               /* icmp type value mask */
    UI8_T icmp_code;                    /* icmp code value */
    UI8_T icmp_code_mask;               /* icmp code value mask */
    UI8_T igmp_type;                    /* igmp type value */
    UI8_T igmp_type_mask;               /* igmp type value mask */
    CLX_ACL_FRG_T frg_type;             /* ip fragment type */
    CLX_ACL_TTL_T ttl_type;             /* ttl type */

#define CLX_ACL_IPV6_KEY_FLAGS_FRG_TYPE_VALID (1U << 0) /* ip fragment type valid flag */
#define CLX_ACL_IPV6_KEY_FLAGS_TTL_TYPE_VALID (1U << 1) /* ttl type valid flag */
#define CLX_ACL_IPV6_KEY_FLAGS_AUTH_HDR_EXIST (1U << 2) /* Authentication header exist flag */
    UI32_T flags;                                       /* CLX_ACL_IPV6_KEY_XXX flags */
    UI32_T flags_mask;                                  /* CLX_ACL_IPV6_KEY_XXX flags mask */
} CLX_ACL_IPV6_KEY_T;

typedef struct CLX_ACL_FCOE_KEY_S {
    UI8_T sof;                     /* sof */
    UI8_T sof_mask;                /* sof mask*/
    UI8_T r_ctl;                   /* r control */
    UI8_T r_ctl_mask;              /* r control mask */
    UI8_T type;                    /* type */
    UI8_T type_mask;               /* type mask */
    CLX_FCOE_FCID_T dst_fcid;      /* destination fcid */
    CLX_FCOE_FCID_T dst_fcid_mask; /* destination fcid mask */
    CLX_FCOE_FCID_T src_fcid;      /* source fcid */
    CLX_FCOE_FCID_T src_fcid_mask; /* source fcid mask */
    UI8_T cs_ctl;                  /* cs control */
    UI8_T cs_ctl_mask;             /* cs control mask */
    UI8_T df_ctl;                  /* df control */
    UI8_T df_ctl_mask;             /* df control mask */
    UI16_T ox_id;                  /* originator exchange id */
    UI16_T ox_id_mask;             /* originator exchange id mask */
    UI16_T rx_id;                  /* responder exchange id*/
    UI16_T rx_id_mask;             /* responder exchange id mask */
    UI8_T vft_type;                /* vft type */
    UI8_T vft_type_mask;           /* vft type mask */
    UI32_T flags;                  /* no used */
} CLX_ACL_FCOE_KEY_T;

typedef struct CLX_ACL_MPLS_KEY_S {
    UI32_T label0;                                      /* MPLS label 0 */
    UI32_T label0_mask;                                 /* MPLS label 0 mask */
    UI32_T label1;                                      /* MPLS label 1 */
    UI32_T label1_mask;                                 /* MPLS label 1 mask */
    UI32_T label2;                                      /* MPLS label 2 */
    UI32_T label2_mask;                                 /* MPLS label 2 mask */
    UI32_T label3;                                      /* MPLS label 3 */
    UI32_T label3_mask;                                 /* MPLS label 3 mask */
    CLX_ACL_TTL_T ttl_type;                             /* ttl type */

#define CLX_ACL_MPLS_KEY_FLAGS_TTL_TYPE_VALID (1U << 1) /* ttl type valid flag */
    UI32_T flags;                                       /* CLX_ACL_MPLS_KEY_XXX flags */
    UI32_T flags_mask;                                  /* CLX_ACL_MPLS_KEY_XXX flags mask */
} CLX_ACL_MPLS_KEY_T;

typedef struct CLX_ACL_QOS_KEY_S {
    UI8_T pcp;         /* service vlan pcp for 1ad mode, custom vlan pcp for 1q mode */
    UI8_T pcp_mask;    /* service vlan pcp mask for 1ad mode, custom pcp mask for 1q mode  */
    UI8_T dei;         /* service vlan dei for 1ad mode, custom dei for 1q mode */
    UI8_T dei_mask;    /* service vlan dei mask for 1ad mode, custom dei mask for 1q mode  */
    UI8_T dscp;        /* dscp for l3 packet */
    UI8_T dscp_mask;   /* dscp mask for l3 packet */
    UI8_T exp;         /* exp for mpls packet, CL8600 only  */
    UI8_T exp_mask;    /* exp mask for mpls packet, CL8600 only  */
    UI8_T ecn;         /* ecn for l3 packet */
    UI8_T ecn_mask;    /* ecn mask for l3 packet */
    UI8_T tc;          /* tc */
    UI8_T tc_mask;     /* tc mask */
    CLX_COLOR_T color; /* color type */

#define CLX_ACL_QOS_KEY_FLAGS_STAG_PCP_DEI (1U << 0) /* service vlan pcp/dei for 1ad mode flag */
#define CLX_ACL_QOS_KEY_FLAGS_CTAG_PCP_DEI (1U << 1) /* custom vlan pcp/dei for 1q mode flag */
#define CLX_ACL_QOS_KEY_FLAGS_DSCP_ECN     (1U << 2) /* dscp/ecn flag */
#define CLX_ACL_QOS_KEY_FLAGS_TC_COLOR     (1U << 3) /* enable both tc and color flag */
#define CLX_ACL_QOS_KEY_FLAGS_COLOR_VALID  (1U << 4) /* color valid flag */
/* indicates ctag_pcp_dei is in 1'st or 2'nd vlan */
#define CLX_ACL_QOS_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 5)
#define CLX_ACL_QOS_KEY_FLAGS_EXP              (1U << 6) /* mpls exp flag, CL8600 only  */
    UI32_T flags;                                        /* CLX_ACL_QOS_KEY_FLAGS_XXX */
} CLX_ACL_QOS_KEY_T;

typedef struct CLX_ACL_PP_INFO_KEY_S {
    UI32_T intf_group_label;      /* lt: 12 bits, mt: 16 bits, local interface group label*/
    UI32_T intf_group_label_mask; /* lt: 12 bits, mt: 16 bits, local interface group label mask */
    UI32_T service_group_label;   /* 12 bits, service interface group label, lt only */
    UI32_T service_group_label_mask; /* 12 bits, service interface group label mask, lt only */
    UI32_T l3_intf_group_label;      /* 14 bits, l3 interface group label, lt only */
    UI32_T l3_intf_group_label_mask; /* 14 bits, l3 interface group label, lt only mask */
    UI32_T ingress_acl_group_label;  /* lt: 10 bits, mt: 16 bits, ingress acl search group label,
                                        egress match only */
    UI32_T ingress_acl_group_label_mask; /* lt: 10 bits, mt: 16 bits, ingress acl search group label
                                            mask, egress match only */
    UI32_T l2_da_group_label; /* lt: 12 bits, mt: 16 bits, l2 destination address group label */
    UI32_T l2_da_group_label_mask; /* lt: 12 bits, mt: 16 bits, l2 destination address group label
                                      mask */
    UI32_T l2_sa_group_label;      /* lt: 12 bits, mt: 16 bits, l2 source address group label */
    UI32_T l2_sa_group_label_mask; /* lt: l2 bits, mt: 16 bits, l2 source address group label mask
                                    */
    UI32_T l3_da_group_label;      /* lt: 12 bits, mt: 16 bits need to enable
                                    * CLX_ACL_GROUP_FORMAT_BASE_LABEL_REPLACE_DA, l3 destination
                                    * address group label */
    UI32_T l3_da_group_label_mask; /* lt: 12 bits, mt: 16 bits, l3 destination address group label
                                      mask */
    UI32_T l3_sa_group_label;      /* lt: 12 bits, mt: 16 bits need to enable
                                    * CLX_ACL_GROUP_FORMAT_BASE_LABEL_REPLACE_SA, l3 source
                                    * address group label */
    UI32_T
    l3_sa_group_label_mask; /* lt: 12 bits, mt: 16 bits, l3 source address group label mask */
    UI32_T bdid;            /* Ingress : match ingress fdid
                               Egress  : match egress bdid, must match flags_l3_route=0 simultaneously */
    UI32_T bdid_mask;
    UI32_T l3_intf_id;      /* lt only.
                               Ingress : match ingress l3_intf_id
                               Egress  : match egress l3_intf_id, must match flags_l3_route=1
                               simultaneously */
    UI32_T l3_intf_id_mask; /* 14 bits, l3 interface index mask */
    CLX_ACL_L2_FRAME_T l2_frame_type; /* l2 frame type */

    UI32_T svid;                      /* Not supported on CL8360 and CL8600, ingress only */
    UI32_T svid_mask;                 /* Not supported on CL8360 and CL8600, ingress only */
    UI32_T cvid;                      /* Not supported on CL8360 and CL8600, ingress only */
    UI32_T cvid_mask;                 /* Not supported on CL8360 and CL8600, ingress only.
                                         Can not match service/l3_intf_group_label/bdid/l3_intf_id
                                         if matching svid/cvid.
                                         Need to enable CLX_PORT_PROPERTY_ACL_MATCH_PACKET_VLAN
                                         if want to match svid/cvid. */

#define CLX_ACL_PP_INFO_KEY_FLAGS_L2_FRAME_TYPE_VALID (1U << 0) /* l2 frame type valid flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE            (1U << 1) /* is l3 route flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_STAG_VALID          (1U << 2) /* service vlan tag valid flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_CTAG_VALID          (1U << 3) /* custom vlan tag valid flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_TNL_TERM            (1U << 4) /* is tunnel decap pass flag */
/* indicates cvid/ctag_valid is in 1'st or 2'nd vlan */
#define CLX_ACL_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 5)
    UI32_T flags;      /* CLX_ACL_PP_INFO_KEY_FLAG_XXX */
    UI32_T flags_mask; /* CLX_ACL_PP_INFO_KEY_FLAG_XXX */
} CLX_ACL_PP_INFO_KEY_T;

typedef struct CLX_ACL_PKG_KEY_S {
    UI32_T l2_sa_group_label;      /* lt: 12 bits, mt:10 bits, l2 source address group label */
    UI32_T l2_sa_group_label_mask; /* lt: 12 bits, mt:10 bits, l2 source address group label mask */
    UI32_T l2_da_group_label;      /* lt: 12 bits, mt:10 bits, l2 destination address group label */
    UI32_T l2_da_group_label_mask; /* lt: 12 bits, mt:10 bits, l2 destination address group label
                                      mask */
    UI32_T l3_sa_group_label;      /* lt: 12 bits, mt:16 bits, l3 source address group label */
    UI32_T l3_sa_group_label_mask; /* lt: 12 bits, mt:16 bits, l3 source address group label mask */
    UI32_T l3_da_group_label;      /* lt: 12 bits, mt:16 bits, l3 destination address group label */
    UI32_T l3_da_group_label_mask; /* lt: 12 bits, mt:16 bits, l3 destination address group label
                                      mask */
    UI32_T intf_group_label;       /* lt: 12 bits, mt:16 bits, local interface group label*/
    UI32_T intf_group_label_mask;  /* lt: 12 bits, mt:16 bits, local interface group label mask */
    UI32_T service_group_label;    /* 12 bits, service interface group label, lt only */
    UI32_T service_group_label_mask;     /* 12 bits, service interface group label mask, lt only */
    UI32_T ingress_acl_group_label;      /* 12 bits, ingress acl search group label, CL8600 only */
    UI32_T ingress_acl_group_label_mask; /* 12 bits, ingress acl search group label mask, CL8600
                                            only */
    UI32_T vrf;                          /* 13 bits, virtual routing forwarding index */
    UI32_T vrf_mask;                     /* 13 bits, virtual routing forwarding index mask */
    UI32_T bdid;                         /* 14 bits, bridge domain index */
    UI32_T bdid_mask;                    /* 14 bits, bridge domain index mask */
    UI32_T l3_intf_id;                   /* 14 bits, l3 interface index group label, lt only */
    UI32_T l3_intf_id_mask;              /* 14 bits, l3 interface index group label, lt only */
    UI32_T tcp_flag;                     /* 12 bits, tcp flag, CL8600 only */
    UI32_T tcp_flag_mask;                /* 12 bits, tcp flag mask, CL8600 only */

    UI16_T svid;                         /* service vlan id, not supported on CL8360 */
    UI16_T svid_mask;                    /* service vlan id mask, not supported on CL8360 */
    UI8_T spcp;                          /* service vlan pcp, not supported on CL8360 */
    UI8_T spcp_mask;                     /* service vlan pcp mask, not supported on CL8360 */
    UI8_T sdei;                          /* service vlan dei, not supported on CL8360 */
    UI8_T sdei_mask;                     /* service vlan dei mask, not supported on CL8360 */
    UI16_T cvid;                         /* custom vlan id, not supported on CL8360 */
    UI16_T cvid_mask;                    /* custom vlan id mask, not supported on CL8360 */
    UI8_T cpcp;                          /* custom vlan pcp, not supported on CL8360 */
    UI8_T cpcp_mask;                     /* custom vlan pcp mask, not supported on CL8360 */
    UI8_T cdei;                          /* custom vlan dei, not supported on CL8360 */
    UI8_T cdei_mask;                     /* custom vlan dei mask, not supported on CL8360 */

    UI32_T pkg_cnt;                      /* pkg key byte count */
    UI32_T data[CLX_ACL_PKG_NUM];        /* pkg key data */
    UI32_T mask[CLX_ACL_PKG_NUM];        /* pkg key data mask */

/* indicates cvid/cpcp/cdei is in 1'st or 2'nd vlan */
#define CLX_ACL_PKG_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 0)
#define CLX_ACL_PKG_KEY_FLAGS_L3_ROUTE         (1U << 1) /* is l3 route */
    UI32_T flags;                                        /* CLX_ACL_PKG_KEY_FLAGS_XXX */
    UI32_T flags_mask;                                   /* CLX_ACL_PKG_KEY_FLAGS_XXX */
} CLX_ACL_PKG_KEY_T;

typedef struct CLX_ACL_LOU_KEY_S {
    UI32_T lou_cnt;                 /* lou count */
    UI32_T lou_id[CLX_ACL_LOU_NUM]; /* lou index */
} CLX_ACL_LOU_KEY_T;

typedef enum {
    CLX_ACL_UDF_KEY_AUTO = 0, /* udf key auto */
    CLX_ACL_UDF_KEY_UDF_0,    /* udf key 0, flow and acl search */
    CLX_ACL_UDF_KEY_UDF_1,    /* Not supported on CL8360 and CL8600, flow only */
    CLX_ACL_UDF_KEY_LAST
} CLX_ACL_UDF_KEY_T;

typedef struct CLX_ACL_CLASSIFY_S {
    CLX_ACL_CLASSIFY_KEY_T
    classify_key_type;                 /* CLX_ACL_CLASSIFY_KEY_MAC  : mac/qos/pp_info/pkg/lou_key
                                          CLX_ACL_CLASSIFY_KEY_ARP  : mac/arp/qos/pp_info/pkg/lou_key
                                          CLX_ACL_CLASSIFY_KEY_IPV4 : mac/ipv4/qos/pp_info/pkg/lou_key
                                          CLX_ACL_CLASSIFY_KEY_IPV6 : mac/ipv6/qos/pp_info/pkg/lou_key
                                          CLX_ACL_CLASSIFY_KEY_MPLS : mac/mpls/qos/pp_info/pkg/lou_key
                                          CLX_ACL_CLASSIFY_KEY_FCOE : mac/fcoe/qos/pp_info/pkg/lou_key
                                          CLX_ACL_CLASSIFY_KEY_UDF  : pkg/lou_key */
    CLX_PORT_BITMAP_T port_bitmap;     /* ingress/egress port bitmap for ingress/egress stage */
    CLX_ACL_MAC_KEY_T mac_key;         /* mac key */
    CLX_ACL_ARP_KEY_T arp_key;         /* arp key */
    CLX_ACL_IPV4_KEY_T ipv4_key;       /* ipv4 key */
    CLX_ACL_IPV6_KEY_T ipv6_key;       /* ipv6 key */
    CLX_ACL_MPLS_KEY_T mpls_key;       /* mpls key, CL8600 only */
    CLX_ACL_FCOE_KEY_T fcoe_key;       /* fcoe key */
    CLX_ACL_QOS_KEY_T qos_key;         /* qos key */
    CLX_ACL_PP_INFO_KEY_T pp_info_key; /* pp info key */
    CLX_ACL_PKG_KEY_T pkg_key;         /* pkg key */
    CLX_ACL_LOU_KEY_T lou_key;         /* lou key */
    UI32_T udf_key_profile_id;         /* udf key profile id */
    UI32_T udf_key_profile_id_mask;    /* udf key profile id mask */
    CLX_ACL_UDF_KEY_T udf_key_type;    /* udf key type */

#define CLX_ACL_CLASSIFY_FLAGS_MAC_KEY (1U << 0) /* mac key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_ARP_KEY (1U << 1) /* arp key flag, depends on classify_key_type */
/* ipv4 key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_IPV4_KEY (1U << 2)
/* ipv6 key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_IPV6_KEY (1U << 3)
/* mpls key flag, depends on classify_key_type, CL8600 only */
#define CLX_ACL_CLASSIFY_FLAGS_MPLS_KEY (1U << 4)
/* fcoe key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_FCOE_KEY (1U << 5)
#define CLX_ACL_CLASSIFY_FLAGS_QOS_KEY  (1U << 6) /* qos key flag, depends on classify_key_type */
/* pp info key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_PP_INFO_KEY (1U << 7)
#define CLX_ACL_CLASSIFY_FLAGS_PKG_KEY     (1U << 8) /* pkg key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_LOU_KEY     (1U << 9) /* lou key flag, depends on classify_key_type */
/* udf key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_UDF_VALID (1U << 10)
/* port bitmap key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_PORT_BITMAP_VALID (1U << 11)
    UI32_T flags; /* CLX_ACL_CLASSIFY_FLAGS_XXX */
} CLX_ACL_CLASSIFY_T;

typedef struct CLX_ACL_QOS_ACTION_S {
    UI8_T pcp;                                          /* remark pcp */
    UI8_T dei;                                          /* remark dei */
    UI8_T dscp;                                         /* remark dscp */
    UI8_T ecn;                                          /* remark ecn */
    UI8_T exp;                                          /* remark exp */
    UI8_T tc;                                           /* remark tc */
    CLX_COLOR_T color;                                  /* remark color */

#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_PCP   (1U << 0) /* remark pcp flag, CL8600: egress only */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_DEI   (1U << 1) /* remark dei flag, CL8600: egress only */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_DSCP  (1U << 2) /* remark dscp flag, CL8600: egress only */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_ECN   (1U << 3) /* remark ecn flag */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_EXP   (1U << 4) /* remark exp flag, CL8600: egress only */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_TC    (1U << 5) /* remark tc flag */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_COLOR (1U << 6) /* remark color flag */
#define CLX_ACL_QOS_ACTION_FLAGS_DROP         (1U << 7) /* per qos color decision drop forward flag */
#define CLX_ACL_QOS_ACTION_FLAGS_TO_CPU_DROP  (1U << 8) /* per qos color decision drop cpu flag */
/* qos do not modify, CL8600: ingress only */
#define CLX_ACL_QOS_ACTION_FLAGS_QOS_DO_NOT_MODIFY (1U << 9)
    UI32_T flags; /* CLX_ACL_QOS_ACTION_FLAGS_XXX */
} CLX_ACL_QOS_ACTION_T;

typedef enum {
    CLX_ACL_REDIRECT_L2_UC,    /* redirect to L2 unicast */
    CLX_ACL_REDIRECT_L3_UC,    /* redirect to L3 unicast */
    CLX_ACL_REDIRECT_L3_ECMP,  /* redirect to L3 ecmp group */
    CLX_ACL_REDIRECT_L2_MC,    /* redirect to L2 multicast group */
    CLX_ACL_REDIRECT_L3_MC,    /* redirect to L3 multicast group */
    CLX_ACL_REDIRECT_L3_MPLS,  /* redirect to L25 mpls, CL8600 only */
    CLX_ACL_REDIRECT_CPU,      /* redirect to cpu port */
    CLX_ACL_REDIRECT_L2_MGLAG, /* redirect to lag multicast group, not supported on CL8600 */
    CLX_ACL_REDIRECT_LAST
} CLX_ACL_REDIRECT_T;

typedef struct CLX_ACL_REDIRECT_ACTION_S {
    CLX_ACL_REDIRECT_T redirect_type;
    CLX_PORT_T port;                                         /* used for L2_UC */
    CLX_BRIDGE_DOMAIN_T bdid;                                /* used for L2_UC(nv) */
    UI32_T adj_id;                                           /* used for L3_UC */
    UI32_T ecmp_group_id;                                    /* used for L3_ECMP */
    UI32_T mcast_id;                                         /* used for L2/L3_MC */
    UI32_T swap_label;                                       /* used for L25 MPLS, CL8600 only */
    CLX_PKT_RX_REASON_BITMAP_T cpu_reason_bitmap;            /* used for CPU */
    UI32_T redirect_idx;                                     /* redirect idx */
#define CLX_ACL_REDIRECT_ACTION_FLAGS_BYPASS_PRUNE (1U << 0) /* used for L2_UC */
#define CLX_ACL_REDIRECT_ACTION_FLAGS_SWAP_LABEL   (1U << 1) /* used for L25, CL8600 only */
#define CLX_ACL_REDIRECT_ACTION_FLAGS_INDEX_MODE   (1U << 2) /* used for index mode */
    UI32_T flags;                                            /* CLX_ACL_REDIRECT_ACTION_FLAGS_XXX */
} CLX_ACL_REDIRECT_ACTION_T;

typedef enum {
    CLX_ACL_REWRITE_DEL = 1,       /* del packet info */
    CLX_ACL_REWRITE_ADD,           /* add packet info */
    CLX_ACL_REWRITE_SET,           /* replace packet info */
    CLX_ACL_REWRITE_SET_WITH_MASK, /* replace packet info with mask */
    CLX_ACL_REWRITE_SET_INCR,      /* increase packet info, lt only  */
    CLX_ACL_REWRITE_LAST
} CLX_ACL_REWRITE_ACTION_T;

typedef enum {
    CLX_ACL_REWRITE_TYPE_UDF = 0,     /* User define tlv format */
    CLX_ACL_REWRITE_TYPE_CVLAN,       /* CLX_ACL_REWRITE_SET_WITH_MASK 2Bytes, custom vlan */
    CLX_ACL_REWRITE_TYPE_SVLAN,       /* CLX_ACL_REWRITE_SET_WITH_MASK 2Bytes, service vlan */
    CLX_ACL_REWRITE_TYPE_SRC_MAC_HI,  /* CLX_ACL_REWRITE_SET 2Bytes, source mac address
                                         high */
    CLX_ACL_REWRITE_TYPE_SRC_MAC_LO,  /* CLX_ACL_REWRITE_SET 4Bytes, source mac address low */
    CLX_ACL_REWRITE_TYPE_DST_MAC_HI,  /* CLX_ACL_REWRITE_SET 2Bytes, destination mac
                                         address high */
    CLX_ACL_REWRITE_TYPE_DST_MAC_LO,  /* CLX_ACL_REWRITE_SET 4Bytes, destination mac address low */
    CLX_ACL_REWRITE_TYPE_SRC_IPV4,    /* CLX_ACL_REWRITE_SET 4Bytes, source IPv4 address */
    CLX_ACL_REWRITE_TYPE_DST_IPV4,    /* CLX_ACL_REWRITE_SET 4Bytes, destination IPv4 address */
    CLX_ACL_REWRITE_TYPE_SRC_IPV6_0,  /* CLX_ACL_REWRITE_SET 4Bytes, source IPv6 address 0 */
    CLX_ACL_REWRITE_TYPE_SRC_IPV6_1,  /* CLX_ACL_REWRITE_SET 4Bytes, source IPv6 address 1*/
    CLX_ACL_REWRITE_TYPE_SRC_IPV6_2,  /* CLX_ACL_REWRITE_SET 4Bytes, source IPv6 address 2*/
    CLX_ACL_REWRITE_TYPE_SRC_IPV6_3,  /* CLX_ACL_REWRITE_SET 4Bytes, source IPv6 address 3*/
    CLX_ACL_REWRITE_TYPE_DST_IPV6_0,  /* CLX_ACL_REWRITE_SET 4Bytes, destination IPv6 address 0 */
    CLX_ACL_REWRITE_TYPE_DST_IPV6_1,  /* CLX_ACL_REWRITE_SET 4Bytes, destination IPv6 address 1 */
    CLX_ACL_REWRITE_TYPE_DST_IPV6_2,  /* CLX_ACL_REWRITE_SET 4Bytes, destination IPv6 address 2 */
    CLX_ACL_REWRITE_TYPE_DST_IPV6_3,  /* CLX_ACL_REWRITE_SET 4Bytes, destination IPv6 address 3 */
    CLX_ACL_REWRITE_TYPE_TOS_IPV4,    /* CLX_ACL_REWRITE_SET_WITH_MASK 1Byte, IPv4 TOS */
    CLX_ACL_REWRITE_TYPE_TOS_IPV6,    /* CLX_ACL_REWRITE_SET_WITH_MASK 1Byte, IPv6 TOS */
    CLX_ACL_REWRITE_TYPE_L4_SRC_PORT, /* CLX_ACL_REWRITE_SET 2Bytes, l4 source port */
    CLX_ACL_REWRITE_TYPE_L4_DST_PORT, /* CLX_ACL_REWRITE_SET 2Bytes, l4 destination port
                                       */
    CLX_ACL_REWRITE_TYPE_LAST
} CLX_ACL_REWRITE_TYPE_T;

typedef struct CLX_ACL_REWRITE_CFG_S {
    CLX_ACL_REWRITE_TYPE_T rewrite_type;  /* udf or internal pre-define offset*/
    CLX_ACL_REWRITE_ACTION_T type;        /* rewrite action type */
    CLX_ACL_PKG_BASE_T pkg_base_type;     /* rewrite base type */
    UI32_T byte_offset;                   /* value should be multiple of two bytes */
    UI32_T byte_cnt;                      /* value should be multiple of two bytes */
    UI8_T data[CLX_ACL_REWRITE_DATA_NUM]; /* rewrite data */
    UI8_T mask[CLX_ACL_REWRITE_MASK_NUM]; /* rewrite data mask */
} CLX_ACL_REWRITE_CFG_T;

typedef struct CLX_ACL_PKT_REWRITE_S {
    CLX_ACL_REWRITE_CFG_T rewrite_cfg[CLX_ACL_REWRITE_NUM]; /* rewrite config array */
    UI32_T rewrite_cnt;                                     /* rewrite config count */
    UI32_T rewrite_idx;                                     /* index mode */
#define CLX_ACL_PKT_REWRITE_FLAGS_INDEX_MODE (1U << 0)
    UI32_T flags;
} CLX_ACL_PKT_REWRITE_T;

typedef struct CLX_ACL_CMCC_IOAM_S {
    UI8_T delay;        /* 2 bits delay */
    UI8_T color_enable; /* 1 bit color */
    UI16_T flow_id;     /* flow id */
} CLX_ACL_CMCC_IOAM_T;

typedef enum {
    CLX_ACL_TELM_TYPE_INT = 0,   /* INT */
    CLX_ACL_TELM_TYPE_CMCC_IOAM, /* CMCC IOAM */
    CLX_ACL_TELM_TYPE_LAST
} CLX_ACL_TELM_TYPE_T;

typedef struct CLX_ACL_TELM_S {
    BOOL_T enable;                   /* Telemetry enable */
    CLX_ACL_TELM_TYPE_T type;        /* Telemetry type */
    CLX_ACL_CMCC_IOAM_T ioam_config; /* CMCC IOAM config */
    UI8_T int_profile_id;            /* INT profile index */
} CLX_ACL_TELM_T;

typedef enum {
    CLX_ACL_MIRROR_POLICER_TYPE_MIRROR = 0, /* mirror policer type mirror */
    CLX_ACL_MIRROR_POLICER_TYPE_COPP,       /* mirror policer type copp */
    CLX_ACL_MIRROR_POLICER_TYPE_LAST
} CLX_ACL_MIRROR_POLICER_TYPE_T;

typedef enum {
    CLX_ACL_MIRROR_POLICER_ACTION_NONE = 0, /* No policer action */
    CLX_ACL_MIRROR_POLICER_ACTION_DROP,     /* policer action drop */
    CLX_ACL_MIRROR_POLICER_ACTION_LAST
} CLX_ACL_MIRROR_POLICER_ACTION_T;

typedef struct CLX_ACL_MIRROR_POLICER_S {
    CLX_ACL_MIRROR_POLICER_TYPE_T type;            /* mirror policer type */
    CLX_ACL_MIRROR_POLICER_ACTION_T yellow_action; /* policer yellow action */
    UI32_T meter_id;                               /* meter id */
} CLX_ACL_MIRROR_POLICER_T;

typedef enum {
    CLX_ACL_VID_TRY_POP_1, /* try to pop 1 tag */
    CLX_ACL_VID_TRY_POP_2, /* try to pop 2 tags */
    CLX_ACL_VID_TRY_POP_3, /* try to pop 3 tags */
    CLX_ACL_VID_TRY_POP_4, /* try to pop 4 tags */
    CLX_ACL_VID_KEEP_1,    /* keep 1 tag */
    CLX_ACL_VID_KEEP_2,    /* keep 2 tags */
    CLX_ACL_VID_KEEP_ALL,  /* keep all tags */
    CLX_ACL_VID_LAST
} CLX_ACL_VID_CTRL_TYPE_T;

typedef struct CLX_ACL_VID_ACTION_S {
    CLX_ACL_VID_CTRL_TYPE_T vid_ctrl_type;

#define CLX_ACL_VID_ACTION_FLAGS_PUSH_TRACING_VLAN (1U << 0)
#define CLX_ACL_VID_ACTION_FLAGS_PUSH_RULE_VLAN    (1U << 1)
#define CLX_ACL_VID_ACTION_FLAGS_VID_CTRL_VALID    (1U << 2)
    UI32_T flags;
} CLX_ACL_VID_ACTION_T;

typedef struct CLX_ACL_ACTION_S {
    UI32_T priority;                 /* value :
                                        lt: 0-15, can only set to 0 if
                                        CLX_ACL_ACTION_FLAGS_QOS_ACTION_INVALID and
                                        CLX_ACL_ACTION_FLAGS_FWD_ACTION_INVALID is set
                                        mt: 0-15, can only set to 0 for flow
                                        1-15 for acl */
    UI32_T mir_session_bitmap;       /* Mirror session ID bitmap */
    UI32_T sampling_rate;            /* Sampling rate */
    UI32_T sample_to_mir_session_id; /* Sample packets to mirror session, not supported on CL8360 */
    UI32_T meter_id;                 /* meter index */
    UI32_T counter_id;               /* counter index */
    UI32_T dist_counter_id;          /* distribution counter index */
    UI32_T ingress_acl_group_label;  /* write ingress acl group label */
    UI32_T da_group_label;           /* flow only, not support on CL8600 */
    CLX_ACL_QOS_ACTION_T qos_action_color_blind;  /* color blind qos action */
    CLX_ACL_QOS_ACTION_T qos_action_color_green;  /* color green qos action, lt only */
    CLX_ACL_QOS_ACTION_T qos_action_color_yellow; /* color yellow qos action */
    CLX_ACL_QOS_ACTION_T qos_action_color_red;    /* color red qos action */
    CLX_PKT_RX_REASON_BITMAP_T cpu_reason_bitmap; /* can only set one bit of the bitmap */
    CLX_ACL_REDIRECT_ACTION_T redirect_action;    /* redirect action */
    CLX_ACL_PKT_REWRITE_T pkt_rewrite;            /* packet rewrite action */
    UI32_T dtel_profile_id;     /* data plane telemetry action, Not supported on CL8360 */
    CLX_ACL_TELM_T telm_action; /* int/cmcc-ioam action */
    CLX_ACL_MIRROR_POLICER_T mirror_policer; /* mirror policer */
    CLX_ACL_VID_ACTION_T vid_action;         /* vid control action */
    BOOL_T mod_en;                           /* mirror on drop enable, CL8600 ingress only */
#define CLX_ACL_ACTION_FLAGS_METER_VALID        (1U << 0) /* meter valid flag */
#define CLX_ACL_ACTION_FLAGS_COUNTER_VALID      (1U << 1) /* counter valid flag */
#define CLX_ACL_ACTION_FLAGS_DIST_COUNTER_VALID (1U << 2) /* distribution counter valid flag */
/* color blind qos action valid flag */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_BLIND (1U << 3)
/* color green qos action valid flag */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_GREEN (1U << 4)
/* color yellow qos action valid flag */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_YELLOW (1U << 5)
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_RED    (1U << 6) /* color red qos action valid flag */
#define CLX_ACL_ACTION_FLAGS_CANCEL_LEARN            (1U << 7) /* ingress only */
#define CLX_ACL_ACTION_FLAGS_BYPASS_RPF_CHECK_FAIL   (1U << 8) /* ingress only */
#define CLX_ACL_ACTION_FLAGS_COPY_TO_CPU             (1U << 9) /* copy to cpu action valid flag */
#define CLX_ACL_ACTION_FLAGS_REDIRECT                (1U << 10) /* redirect action, ingress only */
#define CLX_ACL_ACTION_FLAGS_DROP                    (1U << 11) /* drop normal port/redirect to cpu packet */
/* drop copy/exception to cpu packet, not supported on CL8600*/
#define CLX_ACL_ACTION_FLAGS_TO_CPU_DROP (1U << 12)
/* packet rewrite action valid flag, ingress only */
#define CLX_ACL_ACTION_FLAGS_PKT_REWRITE (1U << 13)
/* write l3 da label valid flag, flow only, not supported on CL8600 */
#define CLX_ACL_ACTION_FLAGS_L3_DA_GROUP_LABEL (1U << 14)
/* allow steering, ingress only, not supported on CL8600 */
#define CLX_ACL_ACTION_FLAGS_ALLOW_STEERING (1U << 15)
/* bypass ttl check fail, ingress only */
#define CLX_ACL_ACTION_FLAGS_BYPASS_TTL_CHECK_FAIL (1U << 16)
/* Sample packets to mirror session, not supported on CL8360 */
#define CLX_ACL_ACTION_FLAGS_SAMPLE_TO_MIR (1U << 17)
/* Sample high latency packets, not supported on CL8360, egress only */
#define CLX_ACL_ACTION_FLAGS_SAMPLE_HIGH_LATENCY (1U << 18)
/* Not supported on CL8360, ingress only. \
 * If this flag is set, not support redirect action */
#define CLX_ACL_ACTION_FLAGS_KEEP_TTL (1U << 19)
/* timestamp replace mac, Not supported on CL8360,CL8600, egress only */
#define CLX_ACL_ACTION_FLAGS_TS_REPLACE_MAC (1U << 20)
/* data plane telemetry valid flag, Not supported on CL8360,CL8600 */
#define CLX_ACL_ACTION_FLAGS_DTEL_VALID (1U << 21)
/* qos action invalid flag, not supported on CL8600 */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_INVALID (1U << 22)
/* forward action invalid flag, lt only */
#define CLX_ACL_ACTION_FLAGS_FWD_ACTION_INVALID (1U << 23)
/* telemetry action config valid flag, CL8600 only*/
#define CLX_ACL_ACTION_FLAGS_TELM_ACTION_VALID (1U << 24)
#define CLX_ACL_ACTION_FLAGS_XOR_LFSR          (1U << 25) /* xor LFSR to final hash, CL8600 ingress only */
/* allow tm to do truncate, CL8600 ingress only */
#define CLX_ACL_ACTION_FLAGS_ALLOW_TRUNCATE (1U << 26)
/* force remove outer IP/MPLS, CL8600 ingress only */
#define CLX_ACL_ACTION_FLAGS_FORCE_DECAP (1U << 27)
/* Mirror policer valid, CL8600 only */
#define CLX_ACL_ACTION_FLAGS_MIRROR_POLICER_VALID (1U << 28)
/* Vid action valid, CL8600 ingress only */
#define CLX_ACL_ACTION_FLAGS_VID_ACTION_VALID (1U << 29)
    UI32_T flags;
} CLX_ACL_ACTION_T;

typedef struct CLX_ACL_GROUP_INFO_S {
    CLX_ACL_GROUP_T type;                  /* acl group stage type */
    UI32_T group_id;                       /* acl group index */
    UI32_T priority;                       /* group priority */
    CLX_ACL_GROUP_PROFILE_T group_profile; /* group profile */
} CLX_ACL_GROUP_INFO_T;

typedef CLX_ERROR_NO_T (*CLX_ACL_GROUP_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                        const CLX_ACL_GROUP_INFO_T *ptr_group_info,
                                                        void *ptr_cookie);

typedef struct CLX_ACL_ENTRY_INFO_S {
    CLX_ACL_GROUP_T type;        /* group stage type */
    UI32_T group_id;             /* group index */
    UI32_T entry_id;             /* entry index */
    UI32_T priority;             /* flow entry : ignore this field */
    BOOL_T entry_valid;          /* flow entry : ignore this field */
    UI32_T hw_entry_id;          /* hardware entry index */
    UI32_T norm_width;           /* key width of entry */
    CLX_ACL_CLASSIFY_T classify; /* entry classify */
    CLX_ACL_ACTION_T action;     /* entry action */
} CLX_ACL_ENTRY_INFO_T;

typedef CLX_ERROR_NO_T (*CLX_ACL_ENTRY_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                        const CLX_ACL_ENTRY_INFO_T *ptr_entry_info,
                                                        void *ptr_cookie);

typedef struct CLX_ACL_UDF_INFO_S {
    CLX_ACL_GROUP_T type;
    UI32_T udf_key_profile_id;
    CLX_ACL_PKT_FORMAT_T pkt_format;
    CLX_ACL_UDF_KEY_PROFILE_T profile;
} CLX_ACL_UDF_INFO_T;

typedef CLX_ERROR_NO_T (*CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_ACL_UDF_INFO_T *ptr_udf_info,
    void *ptr_cookie);

typedef struct CLX_ACL_LOU_INFO_S {
    CLX_ACL_GROUP_T type;      /* group stage */
    UI32_T id;                 /* udf key profile index */
    UI32_T lou_id;             /* lou index, 0-15 */
    CLX_ACL_LOU_CFG_T lou_cfg; /* lou config */
} CLX_ACL_LOU_INFO_T;

typedef CLX_ERROR_NO_T (*CLX_ACL_LOU_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                      const CLX_ACL_LOU_INFO_T *ptr_lou_info,
                                                      void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The API is used to add a UCP group.
 *
 * support_chip all
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     type                 - UCP group type: Ingress/Egress
 * @param [in]     priority             - UCP group priority
 * @param [in]     ptr_group_profile    - UCP group profile
 * @param [out]    ptr_group_id         - UCP group id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_addGroup(const UI32_T unit,
                 const CLX_ACL_GROUP_T type,
                 const UI32_T priority,
                 const CLX_ACL_GROUP_PROFILE_T *ptr_group_profile,
                 UI32_T *ptr_group_id);

/**
 * @brief The API is used to delete a UCP group.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - UCP group type: Ingress/Egress
 * @param [in]     group_id    - The UCP group id to be deleted
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_delGroup(const UI32_T unit, const CLX_ACL_GROUP_T type, const UI32_T group_id);

/**
 * @brief The API is used to get the configuration information of UCP group.
 *
 * support_chip all
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     type                 - UCP group type: Ingress/Egress
 * @param [in]     group_id             - The UCP group id to be deleted
 * @param [out]    ptr_priority         - UCP group priority to be returned
 * @param [out]    ptr_group_profile    - UCP group profile to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_getGroup(const UI32_T unit,
                 const CLX_ACL_GROUP_T type,
                 const UI32_T group_id,
                 UI32_T *ptr_priority,
                 CLX_ACL_GROUP_PROFILE_T *ptr_group_profile);

/**
 * @brief The API is used to add a udf key profile.
 *
 * ACL udf key (non flow key) generation rule :
 * - udf-key-0 length : 168(CL8360) / 208(non CL8360) bits
 * - udf-key-1 length : 208 bits
 * - internal key : Always generate at udf-key-0.
 * - l2/l3_da/sa_group_label : 12 bits
 * - intf_group_label : 10 bits
 * - service_group_label : 12 bits
 * - lou : 16 bits
 * - port_bitmap : 34 bits
 * - stag/ctag_vid : 13 bits
 * - stag/ctag_pcp_dei : 5 bits
 * - bdid : 14 bits
 * - l3_intf_id : 14 bits
 * - pkg key : Generate at udf-key-0 first. If length of udf-key-0 is not enough, generate at
 * udf-key-1.
 * - each pkg : 9 bits
 *
 * support_chip all
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     type                  - UCP group type: Ingress/Egress
 * @param [in]     udf_key_profile_id    - The udf key profile id to be added
 * @param [in]     ptr_pkt_format        - The packet format
 * @param [in]     ptr_profile           - The programming key format
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_addUdfKeyProfile(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_key_profile_id,
                         const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format,
                         const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

/**
 * @brief The API is used to delete a udf key profile.
 *
 * support_chip all
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     type                  - UCP group type: Ingress/Egress
 * @param [in]     udf_key_profile_id    - udf key profile id to be deleted
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_delUdfKeyProfile(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_key_profile_id);

/**
 * @brief The API is used to get the configuration information of udf key profile.
 *
 * support_chip all
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     type                  - UCP group type: Ingress/Egress
 * @param [in]     udf_key_profile_id    - The udf key profile id to be get
 * @param [out]    ptr_pkt_format        - The packet format information to be returned
 * @param [out]    ptr_profile           - The programming key format information to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_getUdfKeyProfile(const UI32_T unit,
                         const CLX_ACL_GROUP_T type,
                         const UI32_T udf_key_profile_id,
                         CLX_ACL_PKT_FORMAT_T *ptr_pkt_format,
                         CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

/**
 * @brief The API is used to add/set the LOU configuration information.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - UCP group type: Ingress/Egress
 * @param [in]     id         - Udf key profile id.
 * @param [in]     lou_id     - The LOU id to be added/set
 * @param [in]     ptr_lou    - The LOU configuration information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_addLou(const UI32_T unit,
               const CLX_ACL_GROUP_T type,
               const UI32_T id,
               const UI32_T lou_id,
               const CLX_ACL_LOU_CFG_T *ptr_lou);

/**
 * @brief The API is used to delete the LOU configuration information.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     type      - UCP group type: Ingress/Egress
 * @param [in]     id        - Udf key profile id.
 * @param [in]     lou_id    - The LOU id to be deleted
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_delLou(const UI32_T unit, const CLX_ACL_GROUP_T type, const UI32_T id, const UI32_T lou_id);

/**
 * @brief The API is used to get the LOU configuration information.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     type       - UCP group type: Ingress/Egress
 * @param [in]     id         - Udf key profile id.
 * @param [in]     lou_id     - The LOU id to be get
 * @param [out]    ptr_lou    - The LOU configuration information to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_getLou(const UI32_T unit,
               const CLX_ACL_GROUP_T type,
               const UI32_T id,
               const UI32_T lou_id,
               CLX_ACL_LOU_CFG_T *ptr_lou);

/**
 * @brief The API is used to allocate a logic id for UCP entry.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     type              - UCP group type: Ingress/Egress
 * @param [in]     group_id          - Allocate a entry id from UCP group
 * @param [in]     entry_priority    - entry priority
 * @param [out]    ptr_entry_id      - The entry id to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_allocEntryId(const UI32_T unit,
                     const CLX_ACL_GROUP_T type,
                     const UI32_T group_id,
                     const UI32_T entry_priority,
                     UI32_T *ptr_entry_id);

/**
 * @brief The API is used to free the logic id for UCP entry.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     entry_id    - entry id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_freeEntryId(const UI32_T unit, const UI32_T entry_id);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * support_chip all
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     entry_id              - Entry id
 * @param [out]    ptr_type              - the UCP group type of the entry id to be returned
 * @param [out]    ptr_group_id          - the group id of the entry id to be returned
 * @param [out]    ptr_entry_priority    - the entry priority of the entry id to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_getEntryIdInfo(const UI32_T unit,
                       const UI32_T entry_id,
                       CLX_ACL_GROUP_T *ptr_type,
                       UI32_T *ptr_group_id,
                       UI32_T *ptr_entry_priority);

/**
 * @brief The API is used to add/set an UCP entry from HW.
 *
 * If both ptr_classify and ptr_action are NULL, the API will only modify valid bit of entry.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     entry_id        - entry id
 * @param [in]     entry_valid     - The status of the entry: TRUE for valid and FALSE for invalid
 * @param [in]     ptr_classify    - The classified information of the entry
 * @param [in]     ptr_action      - The action to be taken of the entry when the classified
 * information is matched
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_addEntry(const UI32_T unit,
                 const UI32_T entry_id,
                 const BOOL_T entry_valid,
                 const CLX_ACL_CLASSIFY_T *ptr_classify,
                 const CLX_ACL_ACTION_T *ptr_action);

/**
 * @brief The API is used to delete an UCP entry from HW.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     entry_id    - entry id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_delEntry(const UI32_T unit, const UI32_T entry_id);

/**
 * @brief The API is used to get an UCP entry from HW.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     entry_id        - entry id
 * @param [out]    ptr_entry_valid - The status of the entry to be returned
 * @param [out]    ptr_classify    - The classified information of the entry to be returned
 * @param [out]    ptr_action      - The action to be taken of the entry to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_getEntry(const UI32_T unit,
                 const UI32_T entry_id,
                 BOOL_T *ptr_entry_valid,
                 CLX_ACL_CLASSIFY_T *ptr_classify,
                 CLX_ACL_ACTION_T *ptr_action);

/**
 * @brief The API is used to add an exact match entry to HW.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - UCP group type: Ingress/Egress
 * @param [in]     group_id        - Group id
 * @param [in]     ptr_classify    - The classified information of the entry
 * @param [in]     ptr_action      - The action to be taken of the entry when the classified
 * information is matched
 * @param [out]    ptr_entry_id    - The returned entry id from HW
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_addFlowEntry(const UI32_T unit,
                     const CLX_ACL_GROUP_T type,
                     const UI32_T group_id,
                     const CLX_ACL_CLASSIFY_T *ptr_classify,
                     const CLX_ACL_ACTION_T *ptr_action,
                     UI32_T *ptr_entry_id);

/**
 * @brief The API is used to delete an exact match entry from HW.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - UCP group type: Ingress/Egress
 * @param [in]     group_id    - Group id
 * @param [in]     entry_id    - Entry id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_delFlowEntry(const UI32_T unit,
                     const CLX_ACL_GROUP_T type,
                     const UI32_T group_id,
                     const UI32_T entry_id);

/**
 * @brief The API is used to get an exact match entry from HW.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - UCP group type: Ingress/Egress
 * @param [in]     group_id        - Group id
 * @param [in]     entry_id        - Entry id
 * @param [out]    ptr_classify    - The classified information of the entry
 * @param [out]    ptr_action      - The action to be taken of the entry
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_getFlowEntry(const UI32_T unit,
                     const CLX_ACL_GROUP_T type,
                     const UI32_T group_id,
                     const UI32_T entry_id,
                     CLX_ACL_CLASSIFY_T *ptr_classify,
                     CLX_ACL_ACTION_T *ptr_action);

/**
 * @brief The API is used to traverse UCP groups.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - UCP group type: Ingress/Egress
 * @param [in]     callback      - The callback function of type CLX_ACL_GROUP_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_traverseGroup(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const CLX_ACL_GROUP_TRAVERSE_FUNC_T callback,
                      void *ptr_cookie);

/**
 * @brief The API is used to traverse UCP entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - UCP group type: Ingress/Egress
 * @param [in]     group_id      - Group id
 * @param [in]     callback      - The callback function of type CLX_ACL_ENTRY_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_traverseEntry(const UI32_T unit,
                      const CLX_ACL_GROUP_T type,
                      const UI32_T group_id,
                      const CLX_ACL_ENTRY_TRAVERSE_FUNC_T callback,
                      void *ptr_cookie);

/**
 * @brief The API is used to traverse udf key profile.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - UCP group type: Ingress/Egress
 * @param [in]     callback      - The callback function of type
 * CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_traverseUdfKeyProfile(const UI32_T unit,
                              const CLX_ACL_GROUP_T type,
                              const CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T callback,
                              void *ptr_cookie);

/**
 * @brief The API is used to traverse lou.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - UCP group type: Ingress/Egress
 * @param [in]     id            - Udf key profile id.
 * @param [in]     callback      - The callback function of type CLX_ACL_LOU_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_acl_traverseLou(const UI32_T unit,
                    const CLX_ACL_GROUP_T type,
                    const UI32_T id,
                    const CLX_ACL_LOU_TRAVERSE_FUNC_T callback,
                    void *ptr_cookie);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     entry_id        - Flow entry id
 * @param [out]    ptr_type        - the UCP group type of the entry id to be returned
 * @param [out]    ptr_group_id    - the group id of the entry id to be returned
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
CLX_ERROR_NO_T
clx_acl_getFlowEntryIdInfo(const UI32_T unit,
                           const UI32_T entry_id,
                           CLX_ACL_GROUP_T *ptr_type,
                           UI32_T *ptr_group_id);

/**
 * @brief The API is used to alloc resource index.
 *
 * support_chip all
 *
 * @param [in]  unit                - Device unit number
 * @param [in]  type                - Resouce index type
 * @param [out] ptr_index           - alloc index
 * @return CLX_E_OK            - Operate success
 * @return CLX_E_BAD_PARAMETER - Bad parameter
 * @return CLX_E_OTHERS        - Other error
 */
CLX_ERROR_NO_T
clx_acl_rim_alloc(const UI32_T unit, const CLX_ACL_RIM_ALLOC_T type, UI32_T *ptr_index);

/**
 * @brief The API is used to free resource index.
 *
 * support_chip all
 *
 * @param [in]  unit                - Device unit number
 * @param [in]  type                - Resouce index type
 * @param [in]  index           - free index
 * @return CLX_E_OK            - Operate success
 * @return CLX_E_BAD_PARAMETER - Bad parameter
 * @return CLX_E_OTHERS        - Other error
 */
CLX_ERROR_NO_T
clx_acl_rim_free(const UI32_T unit, const CLX_ACL_RIM_ALLOC_T type, const UI32_T index);

/**
 * @brief The API is used to set index action.
 *
 * support_chip all
 *
 * @param [in]  unit                - Device unit number
 * @param [in]  type                - Resouce index type
 * @param [in]  index           - Set index
 * @param [in]  ptr_action   - Set index action
 * @return CLX_E_OK            - Operate success
 * @return CLX_E_BAD_PARAMETER - Bad parameter
 * @return CLX_E_OTHERS        - Other error
 */
CLX_ERROR_NO_T
clx_acl_rim_setAction(const UI32_T unit,
                      const CLX_ACL_RIM_ALLOC_T type,
                      const UI32_T index,
                      const void *ptr_action);

/**
 * @brief The API is used to get index action.
 *
 * support_chip all
 *
 * @param [in]  unit                - Device unit number
 * @param [in]  type                - Resouce index type
 * @param [in]  index           - Get index
 * @param [out] ptr_action     - Get index action
 * @return CLX_E_OK            - Operate success
 * @return CLX_E_BAD_PARAMETER - Bad parameter
 * @return CLX_E_OTHERS        - Other error
 */
CLX_ERROR_NO_T
clx_acl_rim_getAction(const UI32_T unit,
                      const CLX_ACL_RIM_ALLOC_T type,
                      const UI32_T index,
                      void *ptr_action);

/**
 * @brief The API is used to traverse rim resouce.
 *
 * support_chip all
 *
 * @param [in]  unit                - Device unit number.
 * @param [in]  type                - Resouce index type.
 * @param [in]  callback           - The callback function of type CLX_ACL_RIM_TRAVERSE_FUNC_T.
 * @param [in]  ptr_cookie       - The cookie data as input parameter of callback function.
 * @param [out] ptr_cookie       - The cookie data as output parameter of callback function.
 * @return CLX_E_OK            - Operate success
 * @return CLX_E_BAD_PARAMETER - Bad parameter
 * @return CLX_E_OTHERS        - Other error
 */
CLX_ERROR_NO_T
clx_acl_rim_traverseAction(const UI32_T unit,
                           const CLX_ACL_RIM_ALLOC_T type,
                           const CLX_ACL_RIM_TRAVERSE_FUNC_T callback,
                           void *ptr_cookie);

#endif /* End of CLX_ACL_H */
