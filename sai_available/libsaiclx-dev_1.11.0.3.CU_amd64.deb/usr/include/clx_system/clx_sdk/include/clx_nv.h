/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_nv.h
 * PURPOSE:
 *      It provides the declarations of the APIs of nv(network virtualization,including VXLAN/NVGRE)
 * module.
 *
 * NOTES:
 *
 */

#ifndef CLX_NV_H
#define CLX_NV_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_vlan.h>
#include <clx_port.h>
#include <clx_l2.h>
#include <clx_l3t.h>

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to add or set a tunnel to a specified segment and related service.
 *
 * The ptr_seg_srv->bdid value modification is not allowed.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     seg            - Segment value(24 bits)
 * @param [in]     ptr_key        - Tunnel key
 * @param [in]     ptr_seg_srv    - (seg, tunnel) service
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists
 * @return         CLX_E_TABLE_FULL       - The table is full.
 * @return         CLX_E_NOT_SUPPORT      - Not Supported
 */
CLX_ERROR_NO_T
clx_nv_addSegService(const UI32_T unit,
                     const UI32_T seg,
                     const CLX_TUNNEL_KEY_T *ptr_key,
                     const CLX_PORT_SEG_SRV_T *ptr_seg_srv);

/**
 * @brief This API is used to delete a tunnel from a specified segment.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     seg        - Segment value(24 bits)
 * @param [in]     ptr_key    - Tunnel key
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found
 * @return         CLX_E_NOT_SUPPORT        - Not Supported
 */
CLX_ERROR_NO_T
clx_nv_delSegService(const UI32_T unit, const UI32_T seg, const CLX_TUNNEL_KEY_T *ptr_key);

/**
 * @brief This API is used to get the service of a (segment, tunnel) pair.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     seg            - Segment value(24 bits)
 * @param [in]     ptr_key        - Tunnel key
 * @param [out]    ptr_seg_srv    - (seg, tunnel) service
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found
 * @return         CLX_E_NOT_SUPPORT        - Not Supported
 */
CLX_ERROR_NO_T
clx_nv_getSegService(const UI32_T unit,
                     const UI32_T seg,
                     const CLX_TUNNEL_KEY_T *ptr_key,
                     CLX_PORT_SEG_SRV_T *ptr_seg_srv);

#endif /*#ifndef CLX_NV_H */
