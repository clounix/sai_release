/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_vlan.h
 * PURPOSE:
 *      It provides vlan module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_VLAN_H
#define CLX_VLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    CLX_VLAN_PROPERTY_IPMC,                     /* L2 IPv4/IPv6 multicast property. */
    CLX_VLAN_PROPERTY_METER_ID,                 /* VLAN meter id property. */
    CLX_VLAN_PROPERTY_METER_COLOR_RESOLVE_TYPE, /* VLAN meter color resolve type property. */
    CLX_VLAN_PROPERTY_SERVICE_COUNTER_ID,       /* Service counter ID. */
    CLX_VLAN_PROPERTY_DIST_COUNTER_ID,          /* Distribution counter ID. */
    CLX_VLAN_PROPERTY_LAST
} CLX_VLAN_PROPERTY_T;

/* This is the frame type value (FTV) which is used as part of a key to look up the protocol based
 * VLAN table. */
typedef UI8_T CLX_VLAN_FTV_T[5];

/* Private VLAN type of community, isolated and primary */
typedef enum {
    CLX_VLAN_PVLAN_TYPE_NORMAL = 0, /* None private VLAN. */
    CLX_VLAN_PVLAN_TYPE_PRIMARY,    /* Primary VLAN. */
    CLX_VLAN_PVLAN_TYPE_COMMUNITY,  /* Community VLAN. */
    CLX_VLAN_PVLAN_TYPE_ISOLATED,   /* Isolated VLAN. */
    CLX_VLAN_PVLAN_TYPE_LAST
} CLX_VLAN_PVLAN_TYPE_T;

/* VLAN Entry */
typedef struct CLX_VLAN_ENTRY_S {
    CLX_VLAN_T vlan;                  /* 802.1Q VLAN ID. Range is 1-4094. */
    CLX_PORT_BITMAP_T port_bitmap;    /* Tagged VLAN members. */
    CLX_PORT_BITMAP_T ut_port_bitmap; /* Untag VLAN members. */
} CLX_VLAN_ENTRY_T;

/* MAC VLAN Entry */
typedef struct CLX_VLAN_MAC_VLAN_ENTRY_S {
    UI32_T port;   /* Physical port ID, not use. */
    CLX_MAC_T mac; /* Mac address. */
    CLX_VLAN_T
    vlan;      /* 802.1Q VLAN is associated with the entry. The 802.1Q VLAN ID range is 1-4094. */
    UI8_T pcp; /* Priority code point of 802.1Q VLAN header. The 802.1Q PCP range is 0-7. */
    UI8_T dei; /* 1Q mode for CFI, 1AD mode for DEI*/
} CLX_VLAN_MAC_VLAN_ENTRY_T;

/* The frame type of protocol-based VLAN */
typedef enum {
    CLX_VLAN_FRAME_TYPE_ETHERNET = 0, /* Ethernet type. */
    CLX_VLAN_FRAME_TYPE_RFC1042,      /* RFC1042 type. */
    CLX_VLAN_FRAME_TYPE_SNAP_OTHER,   /* SNAP type. */
    CLX_VLAN_FRAME_TYPE_LLC_OTHER,    /* LLC type. */
    CLX_VLAN_FRAME_TYPE_LAST
} CLX_VLAN_FRAME_TYPE_T;

/* EVPN type */
typedef enum {
    CLX_VLAN_EVPN_TYPE_NONE = 0,
    CLX_VLAN_EVPN_TYPE_NVO3,
    CLX_VLAN_EVPN_TYPE_MPLS,
    CLX_VLAN_EVPN_TYPE_SRV6,
    CLX_VLAN_EVPN_TYPE_LAST,
} CLX_VLAN_EVPN_TYPE_T;

typedef struct CLX_VLAN_CLASSIFY_TYPE_S {
    UI32_T port;                      /* Classify port. */
    UI8_T pcp;                        /* Priority control point. */
    UI8_T pcp_mask;                   /* Priority control point mask. */
    UI8_T dei;                        /* 1Q mode for CFI, 1AD mode for DEI. */
    UI8_T dei_mask;                   /* CFI or DEI mask. */
    CLX_VLAN_T svid;                  /* Service VLAN ID. */
    CLX_VLAN_T svid_mask;             /* Service VLAN ID mask. */
    CLX_VLAN_T cvid;                  /* Customer VLAN ID. */
    CLX_VLAN_T cvid_mask;             /* Customer VLAN ID mask. */
    CLX_VLAN_FRAME_TYPE_T frame_type; /* Frame type. */
    UI16_T ethertype;                 /* Link layer protocol type. */
    UI16_T ethertype_mask;            /* Link layer protocol type mask. */
    UI8_T ip_protocol;                /* Network layer protocol type. */
    UI8_T ip_protocol_mask;           /* Network layer protocol type mask. */
    UI16_T src_port;                  /* Transport layer source port. */
    UI16_T src_port_mask;             /* Transport layer source port mask. */
    UI16_T dst_port;                  /* Transport layer destination port. */
    UI16_T dst_port_mask;             /* Transport layer destination port mask. */

/* For trust/untrust port */
/* Trust frame VLAN ID valid flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_VID_VALID     (1U << 0)
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_VID           (1U << 1) /* Trust VLAN ID to match flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_PCP_DEI_VALID (1U << 2) /* Trust PCP/DEI valid flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_TRUST_PCP_DEI       (1U << 3) /* Trust PCP/DEI to match flag. */
/* For frame which has s-tag/c-tag */
/* Service tag exist valid flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_STAG_EXIST_VALID (1U << 4)
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_STAG_EXIST       (1U << 5) /* Service tag exist to match flag. */
/* Customer tag exist valid flag. */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_CTAG_EXIST_VALID (1U << 6)
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_CTAG_EXIST       (1U << 7) /* Customer tag exist to match flag. */
/* For care port or not */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_PORT_VALID (1U << 8) /* Port valid flag. */
/* sw references only */
#define CLX_VLAN_CLASSIFY_TYPE_FLAGS_VLAN_TAG_MODE_1Q (1U << 9) /* 1AD mode valid flag. */
    UI32_T flags;                                               /* Flag in bitmap form. */
} CLX_VLAN_CLASSIFY_TYPE_T;

typedef struct CLX_VLAN_CLASSIFY_ADDR_S {
    UI32_T port;            /* Port number. */
    UI8_T pcp;              /* Priority control point. */
    UI8_T pcp_mask;         /* Priority control point mask. */
    UI8_T dei;              /* 1Q mode for CFI, 1AD mode for DEI. */
    UI8_T dei_mask;         /* CFI or DEI mask. */
    CLX_VLAN_T svid;        /* Service VLAN ID. */
    CLX_VLAN_T svid_mask;   /* Service VLAN ID mask. */
    CLX_VLAN_T cvid;        /* Customer VLAN ID. */
    CLX_VLAN_T cvid_mask;   /* Customer VLAN ID mask. */
    CLX_MAC_T dmac;         /* Destination MAC address. */
    CLX_MAC_T dmac_mask;    /* Destination MAC address mask. */
    CLX_MAC_T smac;         /* Source MAC address. */
    CLX_MAC_T smac_mask;    /* Source MAC address mask. */
    CLX_IP_T dip;           /* Destination IPv4/IPv6 address. */
    CLX_IP_T dip_mask;      /* Destination IPv4/IPv6 address mask. */
    CLX_IP_T sip;           /* Source IPv4/IPv6 address. */
    CLX_IP_T sip_mask;      /* Source IPv4/IPv6 address mask. */
    UI8_T tos;              /* Type of service(TOS). */
    UI8_T tos_mask;         /* TOS value mask. */
    UI32_T flow_label;      /* IPv6 flow label for routing. */
    UI32_T flow_label_mask; /* IPv6 flow label mask. */

/* For trust/untrust port */
/* CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_VID valid flag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_VID_VALID (1U << 0)
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_VID       (1U << 1) /* Trust packet VID. */
/* CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_PCP_DEI valid flag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_PCP_DEI_VALID (1U << 2)
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_TRUST_PCP_DEI       (1U << 3) /* Trust packet PCP/DEI */
/* For frame which has s-tag/c-tag */
/* CLX_VLAN_CLASSIFY_ADDR_FLAGS_STAG_EXIST valid flag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_STAG_EXIST_VALID (1U << 4)
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_STAG_EXIST       (1U << 5) /* Match Service tag. */
/* CLX_VLAN_CLASSIFY_ADDR_FLAGS_CTAG_EXIST valid flag. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_CTAG_EXIST_VALID (1U << 6)
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_CTAG_EXIST       (1U << 7) /* Match Customer tag. */
/* For care port or not */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_PORT_VALID (1U << 8) /* Port valid flag. */
/* sw references only */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_IPV6_ENTRY (1U << 9) /* IPv6 for match. */
/* If set VLAN 1Q, STAG will be ignored. */
#define CLX_VLAN_CLASSIFY_ADDR_FLAGS_VLAN_TAG_MODE_1Q (1U << 10)
    UI32_T flags; /* CLX_VLAN_CLASSIFY_ADDR_FLAGS_XXX. */
} CLX_VLAN_CLASSIFY_ADDR_T;

typedef struct CLX_VLAN_TAG_ACTION_S {
    CLX_VLAN_T svid;                                      /* Service VLAN ID. */
    CLX_VLAN_T cvid;                                      /* Customer VLAN ID. */
    UI8_T pcp;                                            /* Priority control point. */
    UI8_T dei;                                            /* 1Q mode for CFI, 1AD mode for DEI. */

#define CLX_VLAN_TAG_ACTION_FLAGS_SVID_VALID    (1U << 0) /* Service VLAN ID valid flag. */
#define CLX_VLAN_TAG_ACTION_FLAGS_CVID_VALID    (1U << 1) /* Customer VLAN ID valid flag. */
#define CLX_VLAN_TAG_ACTION_FLAGS_PCP_DEI_VALID (1U << 2) /* PCP and DEI valid flag. */
    UI32_T flags;                                         /* CLX_VLAN_TAG_ACTION_FLAGS_XXX. */
} CLX_VLAN_TAG_ACTION_T;

/* Primary VLAN Information of Private VLAN Entry*/
typedef struct CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_S {
    CLX_VLAN_T vlan_id;                    /* Primary VLAN ID. */
    CLX_PORT_BITMAP_T primary_port_bitmap; /* Primary VLAN port members. */
    CLX_PORT_BITMAP_T trunk_port_bitmap;   /* Primary VLAN trunk ports. */
} CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_T;

/* Secondary VLAN Information of Private VLAN Entry */
typedef struct CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_S {
    CLX_VLAN_T vlan_id;            /* Secondary VLAN ID. */
    CLX_PORT_BITMAP_T port_bitmap; /* Secondary VLAN port members. */
} CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T;

/* Private Vlan Entry */
typedef struct CLX_VLAN_PVLAN_ENTRY_S {
    CLX_VLAN_PVLAN_PRIMARY_VLAN_INFO_T primary_vlan;               /* Primary VLAN information. */
    CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T isolated_vlan;            /* Isolated VLAN information. */
    CLX_VLAN_PVLAN_SECONDARY_VLAN_INFO_T *ptr_community_vlan_list; /* Community VLAN information. */
    UI16_T community_vlan_num;                                     /* Number of community VLANs. */
    UI32_T mcast_id;                                               /* L2 multicast ID. */
    CLX_BRIDGE_DOMAIN_T bdid;                                      /* Bridge Domain ID. */
} CLX_VLAN_PVLAN_ENTRY_T;

/* Just supported on CL8600 */
typedef struct CLX_BD_PROPERTY_S {
    /* qos phb profile is silently ignored, no application need. */
    CLX_BUM_INFO_T
    bc_info;  /* boardcast info, just support CLX_BUM_INFO_FLAGS_MCAST_VALID and mcast_id */
    CLX_BUM_INFO_T
    umc_info; /* multicast info, just support CLX_BUM_INFO_FLAGS_MCAST_VALID and mcast_id*/
    CLX_BUM_INFO_T
    uuc_info; /* unicast info, just support CLX_BUM_INFO_FLAGS_MCAST_VALID and mcast_id*/
    UI32_T igr_sampling_rate; /* sample rate for ingress, available for not L3 only intf */
    UI32_T igr_sample_to_mir_session_id; /* sample to mirror session id for ingress, available for
                                            not L3 only intf */
    UI32_T egr_sampling_rate; /* sample rate for egress, available for not L3 only intf */
    UI32_T egr_sample_to_mir_session_id; /* sample to mirror session id for egress, available for
                                            not L3 only intf */
    UI32_T igr_mir_session_bitmap; /* mirror session bitmap for ingress, available for not L3 only
                                      intf */
    UI32_T egr_mir_session_bitmap; /* mirror session bitmap for egress,available for not L3 only
                                      intf */
    UI32_T mstp_id;
    UI32_T igr_meter_id;           /* Ingress meter ID, available for not L3 only intf */
    UI32_T egr_meter_id;           /* Egress meter ID, available for not L3 only intf */
    UI32_T igr_counter_id;         /* Ingress counter ID, available for not L3 only intf */
    UI32_T egr_counter_id;         /* Egress counter ID, available for not L3 only intf */
    UI32_T igr_dist_counter_id; /* Ingress destination counter ID, available for not L3 only intf */
    UI32_T egr_dist_counter_id; /* Egress destination counter ID, available for not L3 only intf */
    UI32_T pcp_dei_to_phb_profile_id; /* Profile ID is valid if PCP/DEI is used to
                                       * initialize the traffic class and color.
                                       */
    UI32_T dscp_to_phb_profile_id;    /* profile ID is valid if  DSCP is used to
                                       * initialize the traffic class and color
                                       */
    UI32_T phb_to_pcp_dei_profile_id; /* Profile ID is valid if PCP/DEI is remarked by
                                       * traffic class and color.
                                       */
    UI32_T phb_to_dscp_profile_id;    /* Profile ID is valid if DSCP is remarked by
                                       * traffic class and color.
                                       */
    CLX_SA_MISS_REASON_T sa_rsn;      /* CLX_SA_MISS_REASON_0/ CLX_SA_MISS_REASON_1 */
    UI32_T seg_id;                    /* Segment id applied to NV/MPLS header.
                                       * Used when hash lookup fails to get a segment/label
                                       */
    CLX_VLAN_EVPN_TYPE_T evpn_enable; /* Enable nvo3-evpn, mpls-evpn, or srv6-evpn */

#define CLX_BD_PROPERTY_FLAGS_ENABLE_LEARN                 (1U << 0) /* Enable learn */
#define CLX_BD_PROPERTY_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID (1U << 1) /* Pcp dei to phb field */
#define CLX_BD_PROPERTY_FLAGS_DSCP_TO_PHB_PROFILE_VALID    (1U << 2) /* Dscp to phb field */
#define CLX_BD_PROPERTY_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID (1U << 3) /* Phb to pcp dei field */
#define CLX_BD_PROPERTY_FLAGS_PHB_TO_DSCP_PROFILE_VALID    (1U << 4) /* Phb to dscp dei field */
/* Ingress meter field, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_IGR_METER_VALID (1U << 5)
/* Egress meter field, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_EGR_METER_VALID (1U << 6)
/* Ingress meter counter field, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_IGR_COUNTER_VALID (1U << 7)
/* Egress meter counter field, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_EGR_COUNTER_VALID (1U << 8)
/* Ingress destination counter field, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_IGR_DIST_COUNTER_VALID (1U << 9)
/* Egress destination counter field, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_EGR_DIST_COUNTER_VALID (1U << 10)
/* while L3_ONLY set, the bdid is invalid, l2 function disable, and use l3_intf_id. */
#define CLX_BD_PROPERTY_FLAGS_L3_ONLY (1U << 11) /* L3 flag */
/* Sample packets to a mirror session, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_IGR_SAMPLE_TO_MIR (1U << 12)
/* Sample packets to a mirror session, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_EGR_SAMPLE_TO_MIR (1U << 13)
/* Sample high latency packets, available for not L3 only intf */
#define CLX_BD_PROPERTY_FLAGS_EGR_SAMPLE_HIGH_LATENCY (1U << 14)
#define CLX_BD_PROPERTY_FLAGS_DISABLE_UC_SRC_PRUNE    (1U << 15) /* Disable uc source prune */
#define CLX_BD_PROPERTY_FLAGS_DISABLE_MC_SRC_PRUNE    (1U << 16) /* Disable mc source prune */
#define CLX_BD_PROPERTY_FLAGS_ENABLE_MLD_SNOOPING     (1U << 17) /* Enable MLD snooping */
#define CLX_BD_PROPERTY_FLAGS_ENABLE_IGMP_SNOOPING    (1U << 18) /* Enable IGMP snooping */
/* For tunnel transit packet, favor inner layer for hash generation */
#define CLX_BD_PROPERTY_FLAGS_HSH_FAVOR_INNER (1U << 19)
/* For tunnel transit packet, favor inner layer for cia key generation */
#define CLX_BD_PROPERTY_FLAGS_ACL_FAVOR_INNER (1U << 20)
    UI32_T flags;

#define CLX_BD_PROPERTY_ATTR_BUM (1ULL << 0)  /* Set BUM flag, bc_info/umc_info/uuc_info */
#define CLX_BD_PROPERTY_ATTR_IGR_QOS                                                                                       \
    (1ULL << 1)                               /* Set ingress qos, pcp_dei_to_phb_profile_id/                               \
                                               * dscp_to_phb_profile_id/CLX_BD_PROPERTY_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID \
                                               * CLX_BD_PROPERTY_FLAGS_DSCP_TO_PHB_PROFILE_VALID                           \
                                               */
#define CLX_BD_PROPERTY_ATTR_EGR_QOS                                                                \
    (1ULL << 2)                               /* Set egrss qos, phb_to_pcp_dei_profile_id/          \
                                               * phb_to_dscp_profile_id/                            \
                                               * CLX_BD_PROPERTY_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID \
                                               * CLX_BD_PROPERTY_FLAGS_PHB_TO_DSCP_PROFILE_VALID    \
                                               */
#define CLX_BD_PROPERTY_ATTR_IGR_SAMPLE                                                          \
    (1ULL << 3)                               /* Set ingress sample flag,                        \
                                               * igr_sampling_rate/igr_sample_to_mir_session_id/ \
                                               * CLX_BD_PROPERTY_FLAGS_IGR_SAMPLE_TO_MIR         \
                                               */
#define CLX_BD_PROPERTY_ATTR_EGR_SAMPLE                                                          \
    (1ULL << 4)                               /* Set egress sample flag,                         \
                                               * egr_sampling_rate/egr_sample_to_mir_session_id/ \
                                               * CLX_BD_PROPERTY_FLAGS_EGR_SAMPLE_TO_MIR/        \
                                               * CLX_BD_PROPERTY_FLAGS_EGR_SAMPLE_HIGH_LATENCY   \
                                               */
#define CLX_BD_PROPERTY_ATTR_IGR_MIR \
    (1ULL << 5)                               /* Set ingress mirror flag, igr_mir_session_bitmap */
#define CLX_BD_PROPERTY_ATTR_EGR_MIR \
    (1ULL << 6)                               /* Set egress mirror flag, egr_mir_session_bitmap */
#define CLX_BD_PROPERTY_ATTR_MSTP (1ULL << 7) /* Set ingress mstp flag, mstp_id */
#define CLX_BD_PROPERTY_ATTR_IGR_METER                                                 \
    (1ULL << 8)                               /* Set egress meter flag, igr_meter_id/  \
                                               * CLX_BD_PROPERTY_FLAGS_IGR_METER_VALID \
                                               */
#define CLX_BD_PROPERTY_ATTR_EGR_METER                                                 \
    (1ULL << 9)                               /* Set egress meter flag, egr_meter_id/  \
                                               * CLX_BD_PROPERTY_FLAGS_EGR_METER_VALID \
                                               */
#define CLX_BD_PROPERTY_ATTR_IGR_COUNTER                                                  \
    (1ULL << 10)                              /* Set ingress counter flag, igr_counter_id \
                                               * CLX_BD_PROPERTY_FLAGS_IGR_COUNTER_VALID  \
                                               */
#define CLX_BD_PROPERTY_ATTR_EGR_COUNTER                                                 \
    (1ULL << 11)                              /* Set egress counter flag, egr_counter_id \
                                               * CLX_BD_PROPERTY_FLAGS_EGR_COUNTER_VALID \
                                               */
#define CLX_BD_PROPERTY_ATTR_IGR_DIST_COUNTER                                                                      \
    (1ULL << 12)                              /* Set ingress destination counter flag,                             \
                                               * igr_dist_counter_id, CLX_BD_PROPERTY_FLAGS_IGR_DIST_COUNTER_VALID \
                                               */
#define CLX_BD_PROPERTY_ATTR_EGR_DIST_COUNTER                                         \
    (1ULL << 13)                              /* Set egress destination counter flag, \
                                               * egr_dist_counter_id, CLX_BD_PROPERTY_FLAGS_EGR_DIST_COUNTER_VALID */
#define CLX_BD_PROPERTY_ATTR_SA_MISS_REASON (1ULL << 14) /* Set source mac miss reasion, sa_rsn */
#define CLX_BD_PROPERTY_ATTR_MAC_LEARN \
    (1ULL << 15) /* Set mac learn, CLX_BD_PROPERTY_FLAGS_ENABLE_LEARN */
#define CLX_BD_PROPERTY_ATTR_L3_ONLY (1ULL << 16) /* Set L3 only, CLX_BD_PROPERTY_FLAGS_L3_ONLY */
#define CLX_BD_PROPERTY_ATTR_UC_SRC_PRUNE \
    (1ULL << 17) /* Set uc source prune, CLX_BD_PROPERTY_FLAGS_DISABLE_UC_SRC_PRUNE */
#define CLX_BD_PROPERTY_ATTR_MC_SRC_PRUNE \
    (1ULL << 18) /* Set mc source prune, CLX_BD_PROPERTY_FLAGS_DISABLE_MC_SRC_PRUNE */
#define CLX_BD_PROPERTY_ATTR_MLD_SNOOPING \
    (1ULL << 19) /* Set MLD snooping, CLX_BD_PROPERTY_FLAGS_ENABLE_MLD_SNOOPING */
#define CLX_BD_PROPERTY_ATTR_IGMP_SNOOPING \
    (1ULL << 20) /* Set IGMP snooping, CLX_BD_PROPERTY_FLAGS_ENABLE_IGMP_SNOOPING */
#define CLX_BD_PROPERTY_ATTR_EVPN_ENABLE (1ULL << 21) /* Set EVPN, evpn_enable */
#define CLX_BD_PROPERTY_ATTR_HSH_FAVOR_INNER                                                   \
    (1ULL << 22)                                 /* Set favor inner layer for hash generation, \
                                                  * CLX_BD_PROPERTY_FLAGS_HSH_FAVOR_INNER      \
                                                  */
#define CLX_BD_PROPERTY_ATTR_ACL_FAVOR_INNER                                                      \
    (1ULL << 23)                                 /* Set favor inner layer for cia key generation, \
                                                  * CLX_BD_PROPERTY_FLAGS_ACL_FAVOR_INNER         \
                                                  */
#define CLX_BD_PROPERTY_ATTR_SEG_ID (1ULL << 24) /* Set segment id, seg_id */
#define CLX_BD_PROPERTY_ATTR_ALL    0xFFFFFFFFFFFFFFFF /* Set all fields */
    UI64_T attr_bitmap;                                /* Mark which fields to set */
} CLX_BD_PROPERTY_T;

typedef CLX_ERROR_NO_T (*CLX_VLAN_ENTRY_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                         const CLX_VLAN_ENTRY_T *ptr_entry,
                                                         void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Set properties of the bridge domain.
 *
 * Should create the bridge domain before setting the property.
 * support_chip CL8300 CL8500
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     bdid        - Bridge domain id
 * @param [in]     property    - Property type
 * @param [in]     param0      - First parameter
 * @param [in]     param1      - Second parameter
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Operate failed
 */
CLX_ERROR_NO_T
clx_vlan_setProperty(const UI32_T unit,
                     const CLX_BRIDGE_DOMAIN_T bdid,
                     const CLX_VLAN_PROPERTY_T property,
                     const UI32_T param0,
                     const UI32_T param1);

/**
 * @brief Get properties of the bridge domain.
 *
 * Should create this bridge domain before getting the property.
 * support_chip CL8300 CL8500
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     bdid          - Bridge domain id
 * @param [in]     property      - Property type
 * @param [out]    ptr_param0    - First parameter
 * @param [out]    ptr_param1    - Second parameter
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Operate failed
 */
CLX_ERROR_NO_T
clx_vlan_getProperty(const UI32_T unit,
                     const CLX_BRIDGE_DOMAIN_T bdid,
                     const CLX_VLAN_PROPERTY_T property,
                     UI32_T *ptr_param0,
                     UI32_T *ptr_param1);

/**
 * @brief Create vlan entries.
 *
 * This function will create vlan entry and set fields of vlan entry include
 * portlist, untag portlist to default value.
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vid     - 802.1Q VLAN id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_vlan_createVlan(const UI32_T unit, const CLX_VLAN_T vid);

/**
 * @brief Delete a vlan entry.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vid     - 802.1Q VLAN id
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_delVlan(const UI32_T unit, const CLX_VLAN_T vid);

/**
 * @brief Add member and untag port list of existing vlan entry.
 *
 * VLAN entry includes member port list and untag port list.
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_vlan_entry    - VLAN entry
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_setPort(const UI32_T unit, const CLX_VLAN_ENTRY_T *ptr_vlan_entry);

/**
 * @brief Get a vlan entry with specified 802.1Q vlan.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_vlan_entry    - Field "vlan"
 * @param [out]    ptr_vlan_entry    - Field "port_bitmap" and "ut_port_bitmap"
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_getPort(const UI32_T unit, CLX_VLAN_ENTRY_T *ptr_vlan_entry);

/**
 * @brief Traverse vlan tagged/untagged member port for active vlan.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function to be called for each traversed vlan entry
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK             - Operate success
 * @return         CLX_E_NOT_SUPPORT    - Not supported feature
 */
CLX_ERROR_NO_T
clx_vlan_traverseEntry(const UI32_T unit,
                       const CLX_VLAN_ENTRY_TRAVERSE_FUNC_T callback,
                       void *ptr_cookie);

/**
 * @brief Create a bridge domain.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - Bridge domain id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_vlan_createBridgeDomain(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief Destroy a bridge domain.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - Bridge domain id
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_vlan_destroyBridgeDomain(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief Set vlan-based service.
 *
 * Service properties includes:
 * 1) Bridge domain id
 * 2) Flooding mcast id
 * 3) Learning control
 * ...
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     vid        - 802.1Q VLAN id
 * @param [in]     ptr_srv    - Service properties
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_vlan_setService(const UI32_T unit, const CLX_VLAN_T vid, const CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Get vlan-based service.
 *
 * Service properties includes:
 * 1) Bridge domain id
 * 2) Flooding mcast id
 * 3) Learning control
 * ...
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     vid        - 802.1Q VLAN id
 * @param [out]    ptr_srv    - Service properties
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_vlan_getService(const UI32_T unit, const CLX_VLAN_T vid, CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Add a mac-based vlan entry.
 *
 * support_chip CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - MAC VLAN entry
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_TABLE_FULL       - No more memory
 */
CLX_ERROR_NO_T
clx_vlan_addMacVlan(const UI32_T unit, const CLX_VLAN_MAC_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Delete a mac-based vlan entry.
 *
 * support_chip CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Field "mac"
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_delMacVlan(const UI32_T unit, const CLX_VLAN_MAC_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Get a mac-based vlan entry.
 *
 * support_chip CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - Field "mac"
 * @param [out]    ptr_entry    - Field "vlan", "pcp" and "dei"
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_getMacVlan(const UI32_T unit, CLX_VLAN_MAC_VLAN_ENTRY_T *ptr_entry);

/**
 * @brief Set a type-based vlan entry.
 *
 * support_chip CL8300 CL8500
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     index         - Index of the entry
 * @param [in]     ptr_entry     - Protocol-related and common L2 fields
 * @param [in]     ptr_action    - Assigned actions of vlan info
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_vlan_setTypeEntry(const UI32_T unit,
                      const UI32_T index,
                      const CLX_VLAN_CLASSIFY_TYPE_T *ptr_entry,
                      const CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Get a type-based vlan entry.
 *
 * Type-based entry includes protocol type.
 * support_chip CL8300 CL8500
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     index         - Index of the entry
 * @param [out]    ptr_entry     - Protocol-related and common L2 fields
 * @param [out]    ptr_action    - Assigned actions of vlan info
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_getTypeEntry(const UI32_T unit,
                      const UI32_T index,
                      CLX_VLAN_CLASSIFY_TYPE_T *ptr_entry,
                      CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Set a address-based vlan entry.
 *
 * Address-based entry includes mac and ip address.
 * support_chip CL8300 CL8500
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     index         - Index of the entry
 * @param [in]     ptr_entry     - L2/L3 address-related and common L2 fields
 * @param [in]     ptr_action    - Assigned actions of vlan info
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_setAddrEntry(const UI32_T unit,
                      const UI32_T index,
                      const CLX_VLAN_CLASSIFY_ADDR_T *ptr_entry,
                      const CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Get a address-based vlan entry.
 *
 * Address-based entry includes mac and ip address.
 * support_chip CL8300 CL8500
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     index         - Index of the entry
 * @param [out]    ptr_entry     - L2/L3 address-related and common L2 fields
 * @param [out]    ptr_action    - Assigned actions of vlan info
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_getAddrEntry(const UI32_T unit,
                      const UI32_T index,
                      CLX_VLAN_CLASSIFY_ADDR_T *ptr_entry,
                      CLX_VLAN_TAG_ACTION_T *ptr_action);

/**
 * @brief Add a pvlan entry for the primary vlan.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     primary_vlan       - 802.1Q VLAN id
 * @param [in]     ptr_pvlan_entry    - Pvlan entry
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_addPvlanEntry(const UI32_T unit,
                       const CLX_VLAN_T primary_vlan,
                       const CLX_VLAN_PVLAN_ENTRY_T *ptr_pvlan_entry);

/**
 * @brief Delete a pvlan entry for the primary vlan.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     primary_vlan    - 802.1Q VLAN id
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_delPvlanEntry(const UI32_T unit, const CLX_VLAN_T primary_vlan);

/**
 * @brief Get a pvlan entry for the primary vlan.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     primary_vlan       - 802.1Q VLAN id
 * @param [out]    ptr_pvlan_entry    - Pvlan entry
 * @return         CLX_E_OK                 - Operate success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry
 */
CLX_ERROR_NO_T
clx_vlan_getPvlanEntry(const UI32_T unit,
                       const CLX_VLAN_T primary_vlan,
                       CLX_VLAN_PVLAN_ENTRY_T *ptr_pvlan_entry);

/**
 * @brief This API is used to set properties of the bridge domain.
 *
 * support_chip CL8600
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     bdid               - BD ID
 * @param [in]     ptr_bd_property    - BD property
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_vlan_setBdProperty(const UI32_T unit,
                       const CLX_BRIDGE_DOMAIN_T bdid,
                       const CLX_BD_PROPERTY_T *ptr_bd_property);

/**
 * @brief This API is used to get properties of the bridge domain.
 *
 * support_chip CL8600
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     bdid               - BD ID
 * @param [out]    ptr_bd_property    - BD property
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_vlan_getBdProperty(const UI32_T unit,
                       const CLX_BRIDGE_DOMAIN_T bdid,
                       CLX_BD_PROPERTY_T *ptr_bd_property);

#endif /* End of CLX_VLAN_H */
