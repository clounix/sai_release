/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_telm.h
 * PURPOSE:
 *      It provides TELM module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_TELM_H
#define CLX_TELM_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>
#include <clx_swc.h>
#include <clx_pkt.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_TELM_INT_PORT_ROLE_DISABLE (0)                  /* telemetry INT port role disabled */
#define CLX_TELM_INT_PORT_ROLE_SOURCE  (1)                  /* telemetry INT port role is source */
#define CLX_TELM_INT_PORT_ROLE_TRANSIT (2)                  /* telemetry INT port role is transit */
#define CLX_TELM_INT_PORT_ROLE_SINK    (3)                  /* telemetry INT port role is sink */

#define CLX_TELM_INT_INSTR_TYPE_NODE_ID        (0x1U << 15) /* globlal node id */
#define CLX_TELM_INT_INSTR_TYPE_L1_IF_ID       (0x1U << 14) /* level 1 ingress/egress interface ID */
#define CLX_TELM_INT_INSTR_TYPE_HOP_LATENCY    (0x1U << 13) /* hop latency */
#define CLX_TELM_INT_INSTR_TYPE_QUE_ID_OCCUP   (0x1U << 12) /* queue ID and queue occupancy */
#define CLX_TELM_INT_INSTR_TYPE_IGR_TS         (0x1U << 11) /* ingress timestamp */
#define CLX_TELM_INT_INSTR_TYPE_EGR_TS         (0x1U << 10) /* egress timestamp */
#define CLX_TELM_INT_INSTR_TYPE_L2_IF_ID       (0x1U << 9) /* level 2 ingress/egress interface ID */
#define CLX_TELM_INT_INSTR_TYPE_EGR_IF_TX_UTIL (0x1U << 8) /* egress interface tx utilization */
#define CLX_TELM_INT_INSTR_TYPE_BUF_ID_OCCUP   (0x1U << 7) /* buffer ID and buffer occupancy */
/* bit0 is drop reason. defult enable drop bit, if user not need, config this bit to 1 */
#define CLX_TELM_INT_INSTR_TYPE_DROP_REASON_INVALID (0x1U << 0)

/* telemetry port speed in rwi */
#define CLX_TELM_PORT_SPEED_10  (0) /* 0: 10G;  */
#define CLX_TELM_PORT_SPEED_25  (1) /* 1: 25G;  */
#define CLX_TELM_PORT_SPEED_40  (2) /* 2: 40G;  */
#define CLX_TELM_PORT_SPEED_50  (3) /* 3: 50G;  */
#define CLX_TELM_PORT_SPEED_100 (4) /* 4:100G;  */
#define CLX_TELM_PORT_SPEED_200 (5) /* 5:200G;  */
#define CLX_TELM_PORT_SPEED_400 (6) /* 6:400G;  */
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* Telemetry type */
typedef enum {
    CLX_TELM_INT = 0,  /* INT type */
    CLX_TELM_IOAM = 1, /* IOAM type */
    CLX_TELM_IFA = 2,  /* IFA type */
    CLX_TELM_TYPE_LAST
} CLX_TELM_TYPE_T;

/* Telemetry irq */
typedef enum {
    CLX_TELM_IRQ_HOP_CNT_ZERO,       /* IRQ for INT or IFA hop cnt zero */
    CLX_TELM_IRQ_IFA_MAX_LEN_EXCEED, /* IRQ for IFA max len exceed */
    CLX_TELM_IRQ_IOAM_READ_FIFO,     /* IRQ for IOAM read FIFO */
    CLX_TELM_IRQ_LAST
} CLX_TELM_IRQ_TYPE_T;

typedef enum {
    CLX_TELM_PROPERTY_EGR_PORT_IS_EDGE, /* Egress port is INT edge */
    CLX_TELM_PROPERTY_LAST
} CLX_TELM_PROPERTY_T;

typedef struct CLX_TELM_PROPERTY_PARAM_S {
    CLX_PORT_T port;
    BOOL_T enable;
} CLX_TELM_PROPERTY_PARAM_T;

/* int struct */
typedef enum {
    /* value same with asic */
    CLX_TELM_MX = 0, /* INT-MX mode */
    CLX_TELM_MD = 1, /* INT-MD mode */
    CLX_TELM_XD = 2, /* INT-XD mode */
    CLX_TELM_LAST
} CLX_TELM_MODE_T;

typedef enum {
    CLX_TELM_INT_VERSION_2 = 2, /* Telemetry report specification defines version 2 */
    CLX_TELM_INT_VERSION_LAST
} CLX_TELM_INT_VERSION_T;

typedef enum {
    CLX_TELM_INT_USE_IP_DSCP,   /* use ip dscp as identifier for tcp/udp over INT */
    CLX_TELM_INT_USE_DEST_PORT, /* use tcp/udp dest port as identifier for tcp/udp over INT */
    CLX_TELM_INT_LAST
} CLX_TELM_INT_L4_TYPE_T;

typedef struct CLX_TELM_INT_L4_S {
    BOOL_T valid;        /* enable int over tcp/udp, default off */
    CLX_TELM_INT_L4_TYPE_T
    type;                /* use ip dscp or tcp/udp dest port for INT shim, default use dscp */
    UI16_T dst_port_val; /* dest port value as INT identifier */
    UI8_T dscp_val;      /* ip dscp value as INT identifier */
    UI8_T dscp_mask;     /* mask for ip dscp, check for INT identifier */
} CLX_TELM_INT_L4_T;

typedef struct CLX_TELM_INT_IDENTIFIER_S {
    UI16_T geneve_val;     /* geneve.opt value as INT identifier */
    UI16_T gre_val;        /* gre.proto value as INT identifier */
    UI8_T vxlan_val;       /* vxlan.gpe.proto value as INT identifier */
    CLX_TELM_INT_L4_T tcp; /* ip.dscp or tcp.dest_port vlaue for INT shim */
    CLX_TELM_INT_L4_T udp; /* ip.dscp or udp.dest_port vlaue for INT shim */
} CLX_TELM_INT_IDENTIFIER_T;

typedef struct CLX_TELM_INT_DOMAIN_S {
    CLX_TELM_MODE_T telm_mode;                             /* INT mode */
    CLX_TELM_INT_VERSION_T int_ver;                        /* INT version */
    BOOL_T int_clone;                                      /* INT clone mode */
    CLX_TELM_INT_IDENTIFIER_T identifier;                  /* INT indentifier */

#define CLX_TELM_INT_DOMAIN_ATTR_MODE         (0x1U << 0)  /* set or get telm mode */
#define CLX_TELM_INT_DOMAIN_ATTR_VER          (0x1U << 1)  /* set or get int version */
#define CLX_TELM_INT_DOMAIN_ATTR_CLONE        (0x1U << 2)  /* set or get int clone */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_GENEVE (0x1U << 3)  /* set or get int geneve identifier  */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_GRE    (0x1U << 4)  /* set or get int gre identifier */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_VXLAN  (0x1U << 5)  /* set or get int vxlan identifier */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_TCP    (0x1U << 6)  /* set or get int tcp identifier */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_UDP    (0x1U << 7)  /* set or get int udp identifier */
#define CLX_TELM_INT_DOMAIN_ATTR_ALL          (0xFFFFFFFF) /* set or get all */
    UI32_T attr_bitmap;                                    /* CLX_TELM_INT_DOMAIN_ATTR_XXX flags */
} CLX_TELM_INT_DOMAIN_T;

typedef struct CLX_TELM_RESTORE_DSCP_S {
    BOOL_T tcp; /* restore tcp dscp when decap INT */
    BOOL_T udp; /* restore udp dscp when decap INT */
} CLX_TELM_RESTORE_DSCP_T;

typedef enum {
    CLX_TELM_TRUNC_TO_64,  /* 0: 64 if pkt size > 64 */
    CLX_TELM_TRUNC_TO_128, /* 1:128 if pkt size > 128 */
    CLX_TELM_TRUNC_TO_192, /* 2:192 if pkt size > 192 */
    CLX_TELM_TRUNC_TO_256, /* 3:256 if pkt size > 256 */
    CLX_TELM_TRUNC_TO_512, /* 4:512 if pkt size > 512, for MOD, 472 (512-40) is the real pkt size
                              after truncated */
    CLX_TELM_TRUNC_TO_984, /* 5:984 if pkt size > 984, MOD not support */
    CLX_TELM_TRUNC_LAST
} CLX_TELM_TRUNC_PKT_SIZE_T;

typedef struct CLX_TELM_TRUNC_S {
    BOOL_T cut_en;                      /* cut enable. default is 0, not cut */
    CLX_TELM_TRUNC_PKT_SIZE_T pkt_size; /* packet size after truncation */
} CLX_TELM_TRUNC_T;

typedef struct CLX_TELM_REP_TUNNEL_CFG_S {
    CLX_PORT_T tnl_port; /* tnl_port created by clx_l3t_createPort, transit tnl_port to tunnel idx,
                          for derive IP hdr information for telemetry report */
                         //    UI16_T                   tnl_port_idx;    /* use default value:
                         //    HAL_L3T_PORT_MERGE_DEFAULT, not configed by user */
    UI32_T nvo3_adj_id;  /* nvo3_adj_id = tunnel bd, to derive L2 hdr information for telemetry
                            report */
} CLX_TELM_REP_TUNNEL_CFG_T;

typedef enum {
    CLX_TELM_INT_L2_INTF_USE_SRC_AND_DST_IDX, /* use source and dest index as L2 interface
                                                 information */
    CLX_TELM_INT_L2_INTF_USE_BD,              /* use BD as L2 interface information */
    CLX_TELM_INT_L2_INTF_LAST
} CLX_TELM_INT_L2_INTF_T;

typedef struct CLX_TELM_INT_MATA_INFO_S {
    UI32_T latency_comp;    /* hop latency compensation to compensate the PL latency */
    UI8_T buf_id;           /* buffer id, default is 0 */
    BOOL_T expand_oq_width; /* an option to expand output queue size in metadata */
    CLX_TELM_INT_L2_INTF_T
    l2_intf;                /* metadata L2 interface information, default use src and dest idx */
} CLX_TELM_INT_MATA_INFO_T;

typedef struct CLX_TELM_INT_DEVICE_S {
    UI32_T node_id;                /* the unique ID of this node with the management domain */
    CLX_TELM_RESTORE_DSCP_T
    dscp_restore;                  /* restore dscp when terminate INT, default is to restore */
    CLX_TELM_TRUNC_T int_truncate; /* int truncate clone packets into a specific size */
    CLX_TELM_TRUNC_T mod_truncate; /* mod truncate packets into a specific size */
    UI16_T instr_mask;             /* instruction mask */

    /* Report */
    UI16_T int_report_di;                 /* int report di */
    CLX_TELM_REP_TUNNEL_CFG_T report_tnl; /* report tunnel info */
    UI16_T udp_dest_port;                 /* udp dest port of telemetry report */

    /* Meta MD header */
    UI32_T max_hop_cnt; /* hop cnt value put in INT shim header in INT-source */

    /* Meta Info */
    CLX_TELM_INT_MATA_INFO_T meta_info;                   /* metadata info */

#define CLX_TELM_INT_DEVICE_ATTR_NODE_ID      (0x1U << 0) /* set or get int node id */
#define CLX_TELM_INT_DEVICE_ATTR_DSCP_RESTORE (0x1U << 1) /* set or get int dscp restore */
#define CLX_TELM_INT_DEVICE_ATTR_INT_TRUNCATE (0x1U << 2) /* set or get int clone trancate */
#define CLX_TELM_INT_DEVICE_ATTR_MOD_TRUNCATE (0x1U << 3) /* set or get mod trancate */
#define CLX_TELM_INT_DEVICE_ATTR_INSTR_MASK   (0x1U << 4) /* set or get instruction mask  */
#define CLX_TELM_INT_DEVICE_ATTR_REP_DI       (0x1U << 5) /* set or get report di */
#define CLX_TELM_INT_DEVICE_ATTR_REP_TNL      (0x1U << 6) /* set or get report tunnel info */
#define CLX_TELM_INT_DEVICE_ATTR_REP_UDP_DP   (0x1U << 7) /* set or get report udp dest port */
#define CLX_TELM_INT_DEVICE_ATTR_MAX_HOP_CNT \
    (0x1U << 8)                                         /* set or get max hop cnt for meta header */
#define CLX_TELM_INT_DEVICE_ATTR_META_INFO (0x1U << 9)  /* set or get meta info */
#define CLX_TELM_INT_DEVICE_ATTR_ALL       (0xFFFFFFFF) /* set or get all */
    UI32_T attr_bitmap;                                 /* CLX_TELM_INT_DEVICE_ATTR_XXX flags */
} CLX_TELM_INT_DEVICE_T;

typedef struct CLX_TELM_INT_PROFILE_S {
    UI32_T sampling_rate; /* sampling rate for int profile */
    UI16_T int_instr_bmp; /* CLX_TELM_INT_INSTR_TYPE_XXX flags */
} CLX_TELM_INT_PROFILE_T;

typedef struct CLX_TELM_HOP_CNT_ZERO_INFO_S {
    UI32_T telm_type; /* telm type is INT or IFA */
    UI32_T node_id;   /* INT node id */
} CLX_TELM_HOP_CNT_ZERO_INFO_T;

typedef void (*CLX_TELM_HOP_CNT_ZERO_FUNC_T)(
    const UI32_T unit,
    const CLX_TELM_HOP_CNT_ZERO_INFO_T *ptr_hop_cnt_zero_info,
    void *ptr_cookie);

/* ioam struct */
typedef struct CLX_TELM_IOAM_CFG_S {
    UI32_T ipv4_next_prot;    /* ipv4 next protocol, for identify IOAM header: 0xba */
    UI32_T ipv6_hbh_opt_type; /* opt type in ipv6 hbh ext header: 0x11, high 3 bits=0 */
    // UI32_T color_en;                /* color enable flag, set in src node by add icia action
    // entry */
    UI32_T color_disa_interval; /* if color_en=0, sample window size, clock frequency is 1.35GHz */
    // UI32_T dci_en;                  /* enable dci flag, move to per port attr */
    UI32_T color_en_interval_low;  /* if color_en=1, 40b sample interval low32 */
    UI32_T color_en_interval_high; /* if color_en=1, 40b sample interval high*/

} CLX_TELM_IOAM_CFG_T;

typedef struct CLX_TELM_IOAM_FIFO_ENTRY_S {
    UI64_T color_cnt;          /* 40b counter */
    UI32_T color_en;           /* color enable flag */
    UI32_T color;              /* color */
    UI32_T flow_id;            /* ioam flow id */
    UI32_T delay_en;           /* delay enable */
    UI32_T igr_timestamp;      /* ingress timestamp */
    UI32_T egr_timestamp;      /* egress timestamp */
    UI32_T egr_timestamp_h16b; /* egress timestamp high 16b */
} CLX_TELM_IOAM_FIFO_ENTRY_T;

typedef void (*CLX_TELM_IOAM_FIFO_READ_FUNC_T)(const UI32_T unit,
                                               const CLX_TELM_IOAM_FIFO_ENTRY_T *ptr_fifo_entry,
                                               void *ptr_cookie);

/* ifa struct */
typedef struct CLX_TELM_IFA_CFG_S {
    UI32_T ip_prot;       /* IFA protocol type in IPv4/v6 header */
    UI32_T node_id;       /* node_id in metadata, set rwi_slv */
    UI32_T lcl_namespace; /* local namespace in metadata */

} CLX_TELM_IFA_CFG_T;

typedef struct CLX_TELM_IFA_MAX_LEN_EXCEED_INFO_S {
    UI32_T node_id;       /* node_id in metadata, set rwi_slv */
    UI32_T lcl_namespace; /* local namespace in metadata */
} CLX_TELM_IFA_MAX_LEN_EXCEED_INFO_T;

typedef void (*CLX_TELM_IFA_MAX_LEN_EXCEED_FUNC_T)(
    const UI32_T unit,
    const CLX_TELM_IFA_MAX_LEN_EXCEED_INFO_T *ptr_max_len_exceed_info,
    void *ptr_cookie);

/* mod struct */
typedef struct CLX_TELM_MOD_CFG_S {
    UI32_T mod_en; /* enable mod */
    // CLX_PKT_RX_REASON_T rx_reason;            /* user reason, translite to hw reason set epp
    // redir register */ CLX_PKT_DROP_REASON_T drop_reason;         /* drop reason on monitor. GET
    // drop reason from swc */
    // UI32_T dst_index;           /* report output port DI, modify to out_port and out_queue */
    UI32_T drp_rsn_bmp[2]; /* CLX_PKT_DROP_REASON_T drop reason bitmap(64bits) */
    // UI32_T cud_en_bmp;      /* HAL_MT_TELM_CUD_UC enabled cud bitmap(32bits) */
    UI32_T out_port;            /* report output port */
    UI32_T out_queue;           /* queue of out port, ucq or mcq */
    CLX_PORT_T report_tnl_port; /* convert tnl_port to tnl_idx, report tunnel index for
                                   IP_TNL_TELM_INT tnl type */
    UI32_T report_nvo3_adj_id;  /* tnl_bd in register mod_rpt_cfg0, for derive L2 header */

    UI32_T report_instr_bmp;    /* report instr bitmap, bit0 is drop reason */
    UI32_T
    filter_type; /* 2'b00:none, 2'b01:bloom, 2'b10:LFSR, 2'b11:bloom and LFSR. default:'b11 */
    UI32_T compress_rate; /* filtertype=lfsr, 0->10:1, 1->100:1, 2->1000:1, 3->10000:1. Default:
                             10000:1 */
} CLX_TELM_MOD_CFG_T;

typedef enum {
    CLX_TELM_MOD_FILTER_TYPE_NONE,
    CLX_TELM_MOD_FILTER_TYPE_BLOOM,
    CLX_TELM_MOD_FILTER_TYPE_LFSR,
    CLX_TELM_MOD_FILTER_TYPE_BOTH,
    CLX_TELM_MOD_FILTER_TYPE_LAST
} CLX_TELM_MOD_FILTER_TYPE_T;

typedef enum {
    CLX_TELM_MOD_COMPRESS_RATE_10_TO_1, /* 0-> 10:1 */
    CLX_TELM_MOD_COMPRESS_RATE_100_TO_1,
    CLX_TELM_MOD_COMPRESS_RATE_1000_TO_1,
    CLX_TELM_MOD_COMPRESS_RATE_10000_TO_1,
    CLX_TELM_MOD_COMPRESS_RATE_LAST
} CLX_TELM_MOD_COMPRESS_RATE_T;

/* telm api */

/**
 * @brief This API is used to register a callback function that will be called
 *        whenever TELM IRQ trigger.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     irq_type      - The TELM IRQ type
 * @param [in]     callback      - The callback function of TELM IRQ
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_telm_registerNotifyCallback(const UI32_T unit,
                                const CLX_TELM_IRQ_TYPE_T irq_type,
                                const void *callback,
                                void *ptr_cookie);

/**
 * @brief This API is used to deregister a callback function
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     irq_type      - The TELM IRQ type
 * @param [in]     callback      - The callback function of TELM IRQ
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_telm_deregisterNotifyCallback(const UI32_T unit,
                                  const CLX_TELM_IRQ_TYPE_T irq_type,
                                  const void *callback,
                                  void *ptr_cookie);

/**
 * @brief Set telemetry property.
 *
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [in]     ptr_param   - Parameters
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_telm_setTelmProperty(const UI32_T unit,
                         const CLX_TELM_PROPERTY_T property,
                         const CLX_TELM_PROPERTY_PARAM_T *ptr_param);

/**
 * @brief Get telemetry property.
 *
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     property    - Property type
 * @param [out]    ptr_param   - Parameters
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_telm_getTelmProperty(const UI32_T unit,
                         const CLX_TELM_PROPERTY_T property,
                         CLX_TELM_PROPERTY_PARAM_T *ptr_param);

/* int api */

/**
 * @brief Set telemetry INT profile information with instruction bitmap and sample rate.
 *
 * support_chip CL8600
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     profile_id         - Profile id.
 * @param [in]     ptr_profile_cfg    - INT profile config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_setIntProfile(const UI32_T unit,
                       const UI32_T profile_id,
                       const CLX_TELM_INT_PROFILE_T *ptr_profile_cfg);

/**
 * @brief Get telemetry profile information with ACL configuration and LFSR sampler.
 *
 * support_chip CL8600
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     profile_id         - Profile id.
 * @param [out]    ptr_profile_cfg    - INT profile config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_getIntProfile(const UI32_T unit,
                       const UI32_T profile_id,
                       CLX_TELM_INT_PROFILE_T *ptr_profile_cfg);

/**
 * @brief Set telemetry domain and device information for INT usage.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_domain_cfg    - INT domain config.
 * @param [in]     ptr_device_cfg    - INT device config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_setIntGlobal(const UI32_T unit,
                      const CLX_TELM_INT_DOMAIN_T *ptr_domain_cfg,
                      const CLX_TELM_INT_DEVICE_T *ptr_device_cfg);

/**
 * @brief Get telemetry domain and device information for INT usage.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_domain_cfg    - TELM INT domain config.
 * @param [out]    ptr_device_cfg    - TELM INT device config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_getIntGlobal(const UI32_T unit,
                      CLX_TELM_INT_DOMAIN_T *ptr_domain_cfg,
                      CLX_TELM_INT_DEVICE_T *ptr_device_cfg);

/* ioam api */

/**
 * @brief Set telemetry ioam config information.
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_ioam_cfg    - ioam config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_setIoamCfg(const UI32_T unit, const CLX_TELM_IOAM_CFG_T *ptr_ioam_cfg);

/**
 * @brief Get telemetry configuration information for IOAM usage.
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number.
 * @param [out]    ptr_ioam_cfg    - TELM IOAM config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_getIoamCfg(const UI32_T unit, CLX_TELM_IOAM_CFG_T *ptr_ioam_cfg);

/* ifa api */

/**
 * @brief Set telemetry IFA config information.
 *
 * support_chip CL8600
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_ifa_cfg    - ifa config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_setIfaCfg(const UI32_T unit, const CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

/**
 * @brief Get telemetry configuration information for IFA usage.
 *
 * support_chip CL8600
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_ifa_cfg    - TELM IFA config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_getIfaCfg(const UI32_T unit, CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

/* mod api */

/**
 * @brief Set telemetry MOD config information.
 *
 * support_chip CL8600
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_mod_cfg    - mod config information struct.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_setModCfg(const UI32_T unit, const CLX_TELM_MOD_CFG_T *ptr_mod_cfg);

/**
 * @brief Get telemetry configuration information for MOD usage.
 *
 * support_chip CL8600
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_mod_cfg    - TELM MOD config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_getModCfg(const UI32_T unit, CLX_TELM_MOD_CFG_T *ptr_mod_cfg);

#endif /* End of CLX_TELM_H */
