/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_init.h
 * PURPOSE:
 *      Custom configuration on CLX SDK.
 * NOTES:
 */
#ifndef CLX_INIT_H
#define CLX_INIT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_module.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_INIT_DBG_FLAG_ERR  (1U << 0)
#define CLX_INIT_DBG_FLAG_WARN (1U << 1)
#define CLX_INIT_DBG_FLAG_INFO (1U << 2)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef void (*CLX_INIT_WRITE_FUNC_T)(const void *ptr_buf, UI32_T len);

typedef CLX_ERROR_NO_T (*CLX_INIT_OPEN_NONVOLATILE_FUNC_T)(void);

typedef CLX_ERROR_NO_T (*CLX_INIT_CLOSE_NONVOLATILE_FUNC_T)(void);

typedef I32_T (*CLX_INIT_WRITE_NONVOLATILE_FUNC_T)(const void *ptr_buf, UI32_T num_bytes);

typedef I32_T (*CLX_INIT_READ_NONVOLATILE_FUNC_T)(void *ptr_buf, UI32_T num_bytes);

typedef struct CLX_INIT_PARAM_S {
    CLX_INIT_WRITE_FUNC_T dsh_write_func;            /* Write function for diag shell */
    CLX_INIT_WRITE_FUNC_T debug_write_func;          /* Write function for debug message */
    CLX_INIT_OPEN_NONVOLATILE_FUNC_T open_nv_func;   /* Open non-volatile function file */
    CLX_INIT_CLOSE_NONVOLATILE_FUNC_T close_nv_func; /* Close non-volatile function file */
    CLX_INIT_WRITE_NONVOLATILE_FUNC_T write_nv_func; /* Write non-volatile function into file */
    CLX_INIT_READ_NONVOLATILE_FUNC_T read_nv_func;   /* Read non-volatile function from file */
} CLX_INIT_PARAM_T;

typedef enum {
    CLX_INIT_MODE_WARM_INIT = 0, /* reload config in init stage */
    CLX_INIT_MODE_WARM_DEINIT,   /* save config in deinit stage */
    CLX_INIT_MODE_LAST
} CLX_INIT_MODE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to initialize the common modules.
 *
 * support_chip all
 *
 * @param [in]     ptr_init_param    - The sdk_demo callback functions.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_initCmnModule(CLX_INIT_PARAM_T *ptr_init_param);

/**
 * @brief This API is used to deinitialize the common modules.
 *
 * support_chip all
 *
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_deinitCmnModule(void);

/**
 * @brief This API is used to initialize the low level modules.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_initLowLevel(const UI32_T unit);

/**
 * @brief This API is used to deinitialize the low level modules.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_deinitLowLevel(const UI32_T unit);

/**
 * @brief This API is used to initialize the task resources of the modules.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_initTaskRsrc(const UI32_T unit);

/**
 * @brief This API is used to deinitialize the task resources of the modules.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_deinitTaskRsrc(const UI32_T unit);

/**
 * @brief This API is used to initialize the modules.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_initModule(const UI32_T unit);

/**
 * @brief This API is used to deinitialize the modules.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_deinitModule(const UI32_T unit);

/**
 * @brief This API is used to initialize the tasks of the modules.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_initTask(const UI32_T unit);

/**
 * @brief This API is used to deinitialize the tasks of the modules.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_deinitTask(const UI32_T unit);

/**
 * @brief This API is used to get the unit numbers.
 *
 * support_chip all
 *
 * @param [out]    ptr_num    - The unit numbers
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_getUnitNum(UI32_T *ptr_num);

/**
 * @brief This API is used to deinitialize the CLX SDK.
 *
 * support_chip all
 *
 * @return         CLX_E_OK        - Successfully de-initialize SDK.
 * @return         CLX_E_OTHERS    - Fail to complete de-initialization procedure.
 */
CLX_ERROR_NO_T
clx_deinit(void);

/**
 * @brief This API is used to set init Mode.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     mode      - warm init, or deinit mode
 * @param [in]     enable    - TRUE, FALSE
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_setInitMode(const UI32_T unit, const CLX_INIT_MODE_T mode, const BOOL_T enable);

/**
 * @brief This API is used to get init Mode.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     mode          - warm init, or deinit mode
 * @param [out]    ptr_enable    - TRUE, FALSE
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_getInitMode(const UI32_T unit, const CLX_INIT_MODE_T mode, BOOL_T *ptr_enable);

/**
 * @brief This API is used to set debug flag on each module. Once module's
 *        debug flag has been set, the corresponding debug messages will be
 *        dumpped by debug_write_func.
 *
 * Device unit number is meaningless on this API.
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     task_id      - task id
 * @param [in]     module_id    - selected module item
 * @param [in]     submodule    - submodule id
 * @param [in]     dbg_flag     - The debug flag defined by CLX_INIT_DBG_FLAG_XXX
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_setModuleDebugFlag(const UI32_T unit,
                            const UI32_T task_id,
                            const UI32_T module_id,
                            const UI32_T submodule,
                            const UI32_T dbg_flag);

/**
 * @brief This API is used to get debug flag setting from each module.
 *
 * Device unit number is meaningless on this API.
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     task_id         - task id
 * @param [in]     module_id       - selected module item
 * @param [in]     submodule       - submodule id
 * @param [out]    ptr_dbg_flag    - The debug flag defined by CLX_INIT_DBG_FLAG_XXX
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation failed.
 */
CLX_ERROR_NO_T
clx_init_getModuleDebugFlag(const UI32_T unit,
                            const UI32_T task_id,
                            const CLX_MODULE_T module_id,
                            const UI32_T submodule,
                            UI32_T *ptr_dbg_flag);

#endif /* CLX_INIT_H */
