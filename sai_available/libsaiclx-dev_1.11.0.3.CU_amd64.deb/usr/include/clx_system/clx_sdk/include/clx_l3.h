/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_l3.h
 * PURPOSE:
 *      It provide L3 module API.
 * NOTES:
 *
 */
#ifndef CLX_L3_H
#define CLX_L3_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_vlan.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
#define CLX_L3_MCAST_FLAGS_WITH_ID (1U << 1) /* Use the specified multicast ID while creating */
#define CLX_L3_SRV_TYPE_FD         (0x10000) /* Specific forwarding domain */
#define CLX_L3_SRV_TYPE_L3_INTF    (0x20000) /* Specific L3 interface */

/* L3 URPF Check Mode, per Interface Configurable */
typedef enum {
    CLX_L3_URPF_CHECK_MODE_DISABLED = 0,         /* No URPF check */
    CLX_L3_URPF_CHECK_MODE_STRICT,               /* Strict mode: Ingress interface of packet must
                                                  * equal to out interface of search result when
                                                  * search source IP in FIB table, check pass, else
                                                  * check fail.
                                                  */
    CLX_L3_URPF_CHECK_MODE_LOOSE,                /* Loose mode: If find match route when search
                                                  * source IP in FIB table, check pass, else check fail.
                                                  */
    CLX_L3_URPF_CHECK_MODE_LOOSE_IGNORE_DEFAULT, /* If find match non-default route when
                                                  * search source IP in FIB table, check pass,
                                                  * else check fail.
                                                  */
    CLX_L3_URPF_CHECK_MODE_LAST
} CLX_L3_URPF_CHECK_MODE_T;

/* L3 Multicast RPF Check Fail Action */
typedef enum {
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_DROP = 0, /* Drop when multicast RPF check failure */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_SEND2CPU, /* Send to CPU when multicast RPF check failure */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_L2MC_LOOKUP, /* Fall back to L2 result when multicast RPF
                                                       check failure */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_NONE,        /* NO multicast RPF check */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_LAST
} CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T;

/* Actions for IP Multicast Lookup Miss, per Interface Configurable */
typedef enum {
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_DROP = 0,    /* Drop when multicast look up miss */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_SEND2CPU,    /* Send to CPU when multicast look up miss */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_L2MC_LOOKUP, /* Fall back to L2 result when multicast look up
                                                    miss */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_FORWARD,     /* Forward when multicast look up miss */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_LAST
} CLX_L3_MCAST_LOOKUP_MISS_ACTION_T;

/* IP Multicast Egress Interface Type */
typedef enum {
    CLX_L3_MCAST_EGR_INTF_TYPE_L3 = 0,  /* For L3 */
    CLX_L3_MCAST_EGR_INTF_TYPE_VM_1BR,  /* For 802.1BR */
    CLX_L3_MCAST_EGR_INTF_TYPE_VM_NIV,  /* For NIV */
    CLX_L3_MCAST_EGR_INTF_TYPE_VM_VEPA, /* For 802.1Qbg VEPA */
    CLX_L3_MCAST_EGR_INTF_TYPE_NV,      /* For Network Virtualization */
    CLX_L3_MCAST_EGR_INTF_TYPE_TRILL,   /* For TRILL */
    CLX_L3_MCAST_EGR_INTF_TYPE_MPLS,    /* For MPLS */
    CLX_L3_MCAST_EGR_INTF_TYPE_LAST
} CLX_L3_MCAST_EGR_INTF_TYPE_T;

/* Output type */
typedef enum {
    CLX_L3_OUTPUT_TYPE_ADJ = 0,    /* Specify output type is L3 adjacency */
    CLX_L3_OUTPUT_TYPE_ECMP,       /* Specify output type is ECMP */
    CLX_L3_OUTPUT_TYPE_NVO3_ADJ,   /* Specify output type is NVO3 */
    CLX_L3_OUTPUT_TYPE_MPLS_LSP,   /* Specify output type is MPLS Label Switch Path */
    CLX_L3_OUTPUT_TYPE_MPLS_PW,    /* Specify output type is MPLS Pseudowire */
    CLX_L3_OUTPUT_TYPE_L2_ECMP,    /* New in CL8600, Specify output type is L2 ECMP */
    CLX_L3_OUTPUT_TYPE_MPLS_TRANS, /* New in CL8600, Specify output type is MPLS Transit */
    CLX_L3_OUTPUT_TYPE_NONE,       /* Not use */
    CLX_L3_OUTPUT_TYPE_LAST
} CLX_L3_OUTPUT_TYPE_T;

/* IP Network Address */
typedef struct CLX_L3_IP_NETWORK_ADDR_S {
    CLX_IP_T ip_addr; /* IP address. For default route, set all to zero.*/
    CLX_IP_T ip_mask; /* IP address mask. For default route, set all to zero.*/
    BOOL_T ipv4;      /* This IP network address is IPV4 address or not.*/
} CLX_L3_IP_NETWORK_ADDR_T;

/* L3 Interface Information */
typedef struct CLX_L3_INTF_INFO_S {
    UI32_T intf_id; /* L3 interface ID. */
    CLX_MAC_T mac;  /* L3 interface MAC address; it will be used as Source MAC when IP packet is
                       egressed from this interface. */
    CLX_L3_URPF_CHECK_MODE_T
    urpf_mode;      /* For detailed information, refer to the enum definition. */
    UI32_T vrf_id;  /* Virtual Routing Forwarding ID of L3 interface. */

#define CLX_L3_INTF_FLAGS_IPV4_UC (1U << 0) /* IPV4 unicast enable in this L3 interface. */
#define CLX_L3_INTF_FLAGS_IPV6_UC (1U << 1) /* IPV6 unicast enable in this L3 interface. */
#define CLX_L3_INTF_FLAGS_IPV4_MC (1U << 2) /* IPV4 multicast enable in this L3 interface. */
#define CLX_L3_INTF_FLAGS_IPV6_MC (1U << 3) /* IPV6 multicast enable in this L3 interface. */
/* Not modify Source MAC address when packet forwarding from this interface. */
#define CLX_L3_INTF_FLAGS_NO_MOD_SA (1U << 4)
/* Not modify destination MAC address when packet forwarding from this interface. */
#define CLX_L3_INTF_FLAGS_NO_MOD_DA (1U << 5)
/* Not modify VLAN ID when packet forwarding from this interface. */
#define CLX_L3_INTF_FLAGS_NO_MOD_VLAN     (1U << 6)
#define CLX_L3_INTF_FLAGS_ICMPV4_REDIR_EN (1U << 7) /* ICMPV4 Redirect check enable. */
#define CLX_L3_INTF_FLAGS_ICMPV6_REDIR_EN (1U << 8) /* ICMPV6 Redirect check enable. */
/* IPV4 Packet with option header would trap to CPU to do SW forward. */
#define CLX_L3_INTF_FLAGS_IPV4_OPTION_HEADER_SW_FWD_EN (1U << 9)
/* IPV6 Packet with option header would trap to CPU to do SW forward. */
#define CLX_L3_INTF_FLAGS_IPV6_OPTION_HEADER_SW_FWD_EN (1U << 10)
#define CLX_L3_INTF_FLAGS_WITH_ID                      (1U << 11) /* Use user input intf_id. */
#define CLX_L3_INTF_FLAGS_IGR_METER_VALID              (1U << 12) /* igr_meter_id is valid. */
#define CLX_L3_INTF_FLAGS_EGR_METER_VALID              (1U << 13) /* egr_meter_id is valid. */
#define CLX_L3_INTF_FLAGS_IGR_CNT_VALID                (1U << 14) /* igr_cnt_id is valid. */
#define CLX_L3_INTF_FLAGS_EGR_CNT_VALID                (1U << 15) /* egr_cnt_id is valid. */
#define CLX_L3_INTF_FLAGS_IGR_DIST_CNT_VALID           (1U << 16) /* igr_dist_cnt_id is valid. */
#define CLX_L3_INTF_FLAGS_EGR_DIST_CNT_VALID           (1U << 17) /* egr_dist_cnt_id is valid. */
/* Sample to mirror session id for ingress, CL8600 only. */
#define CLX_L3_INTF_FLAGS_IGR_SAMPLE_TO_MIR (1U << 18)
/* Sample to mirror session id for egress, CL8600 only. */
#define CLX_L3_INTF_FLAGS_EGR_SAMPLE_TO_MIR (1U << 19)
/* Sample high latency packets, egress only, CL8600 only. */
#define CLX_L3_INIT_FLAGS_EGR_SAMPLE_HIGH_LATENCY (1U << 20)
/* igr_mir_session_bitmap is valid, CL8600 only. */
#define CLX_L3_INTF_FLAGS_IGR_MIRROR_VALID (1U << 21)
/* egr_mir_session_bitmap is valid, CL8600 only. */
#define CLX_L3_INTF_FLAGS_EGR_MIRROR_VALID (1U << 22)
/* Skip router mac check, CL8600 only. */
#define CLX_L3_INTF_FLAGS_ROUTER_MAC_CHECK_SKIP (1U << 23)

    UI32_T flags;                         /* Refer to CLX_L3_INTF_FLAGS_XX. */
    UI16_T igr_mtu_size;                  /* MTU size used by ingress process. */
    UI16_T egr_mtu_size;                  /* MTU size used by egress process. */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_T
    ipv4_lookup_miss_action;              /* L3 multicast look up miss action for IPV4 packet. */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_T
    ipv6_lookup_miss_action;              /* L3 multicast look up miss action for IPV6 packet. */
    CLX_FWD_ACTION_T igr_mtu_fail_action; /* Ingress MTU check fail action. */
    CLX_FWD_ACTION_T egr_mtu_fail_action; /* Egress MTU check fail action. */
    CLX_FWD_ACTION_T urpf_fail_action;    /* URPF check fail action. */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T
    ipv4_mrpf_fail_action;                /* IPv4 MRPF check fail action, CL8600 only. */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T
    ipv6_mrpf_fail_action;                /* IPv6 MRPF check fail action, CL8600 only. */
    UI32_T igr_meter_id;                  /* Ingress meter ID. */
    UI32_T egr_meter_id;                  /* Egress meter ID. */
    UI32_T igr_cnt_id;                    /* Ingress counter ID. */
    UI32_T egr_cnt_id;                    /* Egress counter ID. */
    UI32_T igr_dist_cnt_id;               /* Ingress distribution counter ID. */
    UI32_T egr_dist_cnt_id;               /* Egress distribution counter ID. */
    UI32_T igr_mir_session_bitmap;        /* Mirror session bitmap for ingress, CL8600 only. */
    UI32_T egr_mir_session_bitmap;        /* Mirror session bitmap for egress, CL8600 only. */
    UI32_T igr_sampling_rate;             /* Sample rate for ingress, CL8600 only. */
    UI32_T igr_sample_to_mir_session_id;  /* Sample packets to a mirror session for ingress, CL8600
                                             only. */
    UI32_T egr_sampling_rate;             /* Sample rate for egress, CL8600 only. */
    UI32_T egr_sample_to_mir_session_id;  /* Sample packets to a mirror session for egress, CL8600
                                             only. */
    UI32_T igr_group_label;               /* group label for ICIA, not supported on CL8600. */
    UI32_T egr_group_label;               /* group label for ECIA, not supported on CL8600. */
} CLX_L3_INTF_INFO_T;

/* IP Host Information */
typedef struct CLX_L3_HOST_INFO_S {
    CLX_IP_ADDR_T ip_host_addr;       /* Key: IP address of host entry  */
    UI32_T vrf_id;                    /* Key: virtual routing forwarding domain ID */
    CLX_L3_OUTPUT_TYPE_T output_type; /* Output type not support CLX_L3_OUTPUT_TYPE_NVO3_ADJ */
    UI32_T output_id;                 /* Adjacency id, ECMP group id, MPLS tunnel or MPLS port */
    UI32_T tc;                        /* Traffic class remark value     */

#define CLX_L3_HOST_FLAGS_DROP          (1U << 0) /* Black hole. The output_id field will be invalid. */
#define CLX_L3_HOST_FLAGS_KEEP_TTL      (1U << 1) /* Not modify TTL        */
#define CLX_L3_HOST_FLAGS_SIP_TC_REMARK (1U << 2) /* SIP TC remark         */
#define CLX_L3_HOST_FLAGS_DIP_TC_REMARK (1U << 3) /* DIP TC remark         */
#define CLX_L3_HOST_FLAGS_TC_STICKY     (1U << 4) /* Sticky TC will not be changed by ICIA */
/* Indicates entry was hit on DIP address, not supported on CL8600. */
#define CLX_L3_HOST_FLAGS_DST_HIT       (1U << 5)
#define CLX_L3_HOST_FLAGS_SRC_HIT       (1U << 6) /* Indicates entry was hit on SIP address */
#define CLX_L3_HOST_FLAGS_MPLS_LABEL_EN (1U << 7) /* Enable MPLS label     */

    UI32_T flags;                                 /* Refer to CLX_L3_HOST_FLAGS_XX  */
    UI32_T group_label;                           /* group label for CIA            */
    UI32_T mpls_label;                            /* MPLS label                     */
    UI32_T sa_dc;                                 /* New in CL8600,PIM-SM source DR flag */
} CLX_L3_HOST_INFO_T;

/* Subnet Broadcast Information */
typedef struct CLX_L3_SUBNET_BCAST_INFO_S {
    CLX_IP_ADDR_T ip_subnet_addr;                    /* Key: IP address of Subnet  */
    UI32_T vrf_id;                                   /* Key: virtual routing forwarding domain ID */
    UI32_T mcast_id;                                 /* Mcast ID                   */
    UI32_T group_label;                              /* group label for CIA        */

#define CLX_L3_SUBNET_BCAST_FLAGS_KEEP_TTL (1U << 1) /* Not modify TTL    */

    UI32_T flags;                                    /* Refer to CLX_L3_SUBNET_BCAST_FLAGS_XX */
} CLX_L3_SUBNET_BCAST_INFO_T;

/* IP Route Information */
typedef struct CLX_L3_ROUTE_INFO_S {
    CLX_L3_IP_NETWORK_ADDR_T ip_network_addr; /* Key: IP network address. */
    UI32_T vrf_id;                            /* Key: Virtual routing forwarding domain ID. */
    UI32_T option_exist; /* Key: IPv4 option exist or IPv6 extention header exist, CL8600 only. */
    CLX_L3_OUTPUT_TYPE_T output_type; /* Output type not support CLX_L3_OUTPUT_TYPE_NVO3_ADJ. */
    UI32_T output_id;                 /* Adjacency id, ECMP group id, MPLS tunnel or MPLS port. */

#define CLX_L3_ROUTE_FLAGS_DROP     (1U << 0) /* Black hole. The output_id field will be invalid. */
#define CLX_L3_ROUTE_FLAGS_KEEP_TTL (1U << 1) /* Not modify TTL. */
/* Indicates entry was hit on DIP address, not supported on CL8600. */
#define CLX_L3_ROUTE_FLAGS_DST_HIT       (1U << 2)
#define CLX_L3_ROUTE_FLAGS_SRC_HIT       (1U << 3) /* Indicates entry was hit on SIP address. */
#define CLX_L3_ROUTE_FLAGS_MPLS_LABEL_EN (1U << 4) /* Enable MPLS label. */
/* Configure global route (vrf_id is wildcard). */
#define CLX_L3_ROUTE_FLAGS_GLOBAL_ROUTE       (1U << 5)
#define CLX_L3_ROUTE_FLAGS_OPTION_EXIST_VALID (1U << 6) /* option_exist is valid, CL8600 only. */

    UI32_T flags;                                       /* Refer to CLX_L3_ROUTE_FLAGS_XX. */
    UI32_T group_label;                                 /* group label for CIA. */
    UI32_T mpls_label;                                  /* MPLS label. */
} CLX_L3_ROUTE_INFO_T;

/* ECMP mode type */
typedef enum {
    CLX_L3_ECMP_MODE_TYPE_HW = 0, /* Chip uses hardware hash threshold based path
                                   * selection. The incoming packets with different
                                   * packet hash values will be sent to different
                                   * egresses.The default hash mode is HW.
                                   */
    CLX_L3_ECMP_MODE_TYPE_SW,     /* Chip uses software hash threshold based
                                   * path selection. User can specify different
                                   * egresses with different packet hash values of the
                                   * incoming packets (API:clx_l3_setEcmpGrpHashPath).
                                   */
    CLX_L3_ECMP_MODE_TYPE_LAST
} CLX_L3_ECMP_MODE_TYPE_T;

/* ECMP Group SW mode Information */
typedef struct CLX_L3_ECMP_GRP_SW_MODE_INFO_S {
    UI32_T sw_hash_val_cnt; /* CL8600 only support Fine Grain Ecmp.
                             * 1. Hash entry count in software hash mode.
                             * 2. User must set this count > 0.
                             * 3. When delete ECMP path, the corresponding sw_hash_val_cnt
                             *    in the ECMP group will be subtracted.
                             * 4. When user update a larger value (API: clx_l3_setEcmpGrp),
                             *    just add an ECMP path (API: clx_l3_addEcmpGrpPath)
                             *    and assign hash_values (API: clx_l3_setEcmpGrpHashPath),
                             *    or user can reconfigure the whole hash_list.
                             * 5. When user update a smaller value (API: clx_l3_setEcmpGrp),
                             *    user MUST reconfigure the whole hash_list.
                             */
} CLX_L3_ECMP_GRP_SW_MODE_INFO_T;

/* ECMP Group SW mode Information */
typedef struct CLX_L3_ECMP_GRP_HW_MODE_INFO_S {
    UI32_T hw_hash_val_cnt; /* CL8600 only support */
} CLX_L3_ECMP_GRP_HW_MODE_INFO_T;

/* ECMP Dynamic Load Balance Configuration */
typedef struct CLX_L3_ECMP_DLB_CFG_S {
/* Whether the Dynamic Load Balance is enabled in  \
 * this ECMP group. For detailed description of    \
 * dynamic load balance, refer to the Dynamic Load \
 * Balance API Guide.                              \
 */
#define CLX_L3_ECMP_DLB_FLAGS_DLB (1U << 0)
#define CLX_L3_ECMP_DLB_FLAGS_ET  (1U << 1) /* Elephant trap enable */
    UI32_T flags;                           /* Refer to CLX_L3_ECMP_DLB_FLAGS_XX. */
    UI32_T et_id;                           /* Specify elephant trap ID for this ECMP group. */
} CLX_L3_ECMP_DLB_CFG_T;

/* ECMP Hash Configuration */
typedef struct CLX_L3_ECMP_HASH_CFG_S {
    CLX_L3_ECMP_MODE_TYPE_T hash_mode;           /* If hash_mode is set to 0 (hardware mode), chip
                                                  * uses hardware hash threshold based path
                                                  * selection. The incoming packets with different
                                                  * packet hash values will be sent to different
                                                  * egresses. If hash_mode is set to 1 (software
                                                  * mode), chip uses software hash threshold based
                                                  * path selection. User can specify different
                                                  * egresses with different packet hash values of the
                                                  * incoming packets (API: clx_l3_setEcmpGrpHashPath).
                                                  * The default hash mode is 0.
                                                  */
    CLX_L3_ECMP_GRP_SW_MODE_INFO_T sw_mode_info; /* Will be ignored when hash_mode is hw. */
    CLX_L3_ECMP_GRP_HW_MODE_INFO_T hw_mode_info; /* Will be ignored when hash_mode is sw. */

    UI32_T hash_sel; /* New in CL8600, Support user select which Hash engine  */

#define CLX_L3_ECMP_GRP_HSH_CFG_FLAGS_SEL_EN (1U << 0) /* New in CL8600, Enable set hash_sel. */

    UI32_T flags; /* New in CL8600, Refer to CLX_L3_ECMP_GRP_HSH_CFG_FLAGS_XX. */
} CLX_L3_ECMP_HASH_CFG_T;

/* ECMP Group Configuration */
typedef struct CLX_L3_ECMP_GRP_INFO_S {
    CLX_L3_OUTPUT_TYPE_T type;       /* Group type not support CLX_L3_OUTPUT_TYPE_ECMP. */
    UI32_T path_cnt;                 /* The total ecmp path number currently. This number
                                      * is valid only when user uses clx_l3_getEcmpGrp to
                                      * get ECMP group information.
                                      */
    UI32_T weight_cnt;               /* The total ecmp group weight currently. This
                                      * number is valid only when user uses clx_l3_getEcmpGrp
                                      * to get ECMP group information.
                                      */
    CLX_L3_ECMP_HASH_CFG_T hash_cfg; /* Refer to CLX_L3_ECMP_HASH_CFG_T. */
    CLX_L3_ECMP_DLB_CFG_T dlb_cfg;   /* Refer to CLX_L3_ECMP_DLB_CFG_T, CL8600 not support.  */

#define CLX_L3_ECMP_GRP_FLAGS_KEEP_TTL (1U << 0) /* No modify TTL, CL8600 not support. */
/* Enable URPF strict mode, CL8600 not support. */
#define CLX_L3_ECMP_GRP_FLAGS_URPF_STRICT_EN (1U << 1)
#define CLX_L3_ECMP_GRP_FLAGS_WECMP_EN       (1U << 2) /* Enable weighted ECMP */
#define CLX_L3_ECMP_GRP_FLAGS_ORDER          (1U << 3) /* Enable order ECMP. */
#define CLX_L3_ECMP_GRP_FLAGS_FINE_GRAIN     (1U << 4) /* Fine Grain ECMP. */
    UI32_T flags;                                      /* Refer to CLX_L3_ECMP_GRP_FLAGS_XX. */
} CLX_L3_ECMP_GRP_INFO_T;

/* ECMP Path for Hash Value and Next Hop Configuration */
typedef struct CLX_L3_ECMP_PATH_INFO_S {
    CLX_L3_OUTPUT_TYPE_T type; /* Path type not support CLX_L3_OUTPUT_TYPE_ECMP. */
    UI32_T output_path_id;     /* L3 adjacency ID, NVO3 adjacency ID or MPLS port. */
    UI32_T mpls_adj_id;        /* New in CL8600, L3 adjacency ID. */
    UI32_T monitor_id;         /* Rebalance monitor ID which is used by DLB. If it
                                * is not set, fill in 0.
                                */
    UI32_T frr_state_id;       /* CL8600 not support, L3 only. State id for fast-reroute. */
    UI32_T mpls_label;         /* MPLS label */
    UI32_T weight;             /* The weight of weighted ECMP path. */

#define CLX_L3_ECMP_PATH_FLAGS_MPLS_LABEL_VALID (1U << 0) /* mpls_label is valid */
#define CLX_L3_ECMP_PATH_FLAGS_ACT_LIST         (1U << 1) /* only operation act list */

    UI32_T flags;                                         /* Refer to CLX_L3_ECMP_PATH_FLAGS_XX. */
} CLX_L3_ECMP_PATH_INFO_T;

/* Ecmp Algorithm mode */
typedef enum CLX_L3_ECMP_ALGORITHM_MODE_E {
    CLX_L3_ECMP_ALGORITHM_MODE_ORIG = 0, /* only use orig list */
    CLX_L3_ECMP_ALGORITHM_MODE_ACT,      /* only use act list */
    CLX_L3_ECMP_ALGORITHM_MODE_BOTH,     /* use orig and act list */
    CLX_L3_ECMP_ALGORITHM_MODE_LAST
} CLX_L3_ECMP_ALGORITHM_MODE_T;

/* Frr Path Configuration */
typedef struct CLX_L3_FRR_PATH_INFO_S {
    UI32_T output_path_id;                               /* L3 adjacency ID or MPLS port. */
    UI32_T mpls_label;                                   /* MPLS label */

#define CLX_L3_FRR_PATH_FLAGS_MPLS_LABEL_VALID (1U << 0) /* mpls_label is valid */

    UI32_T flags;                                        /* Refer to CLX_L3_FRR_PATH_FLAGS_XX. */
} CLX_L3_FRR_PATH_INFO_T;

/* My Router MAC Information */
typedef struct CLX_L3_ROUTER_MAC_INFO_S {
    CLX_MAC_T mac;       /* My MAC address       */
    CLX_MAC_T mac_mask;  /* Mask of my MAC       */
    UI32_T intf_id;      /* Interface ID         */
    UI32_T intf_id_mask; /* Mask of interface ID */
} CLX_L3_ROUTER_MAC_INFO_T;

/* VRF Information */
typedef struct CLX_L3_VRF_INFO_S {
    CLX_FWD_ACTION_T option_header_action; /* CL8600 not support, IPV4 packet with option header
                                              forward action */
    CLX_FWD_ACTION_T lkp_miss_action; /* CL8600 not support, Unicast packet lookup miss action */
    CLX_FWD_ACTION_T ttl0_action;     /* CL8600 not support, Packet with ttl =0 forward action */
    CLX_FWD_ACTION_T ttl1_action;     /* CL8600 not support, Packet with ttl =1 forward action */
    UI32_T meter_id;                  /* CL8600 not support, Meter ID                   */
    UI32_T cnt_id;                    /* CL8600 not support, Counter ID                 */
    UI32_T dist_cnt_id;               /* CL8600 not support, Distribution counter ID    */
    CLX_METER_COLOR_RESOLVE_TYPE_T
    color_resolve_type;               /* CL8600 not support, Meter color resolve type   */
    UI32_T group_label;               /* CL8600 not support, Group label for CIA        */
    UI32_T ipv4_state;                /* ipv4 admin state control   */
    UI32_T ipv6_state;                /* ipv6 admin state control   */

/* CL8600 not support, TRUE: Enable fall-back to global route */
#define CLX_L3_VRF_FLAGS_FALL_BACK_EN (1U << 0)
#define CLX_L3_VRF_FLAGS_METER_VALID  (1U << 1) /* CL8600 not support, meter_id is valid */
#define CLX_L3_VRF_FLAGS_CNT_VALID    (1U << 2) /* CL8600 not support, cnt_id is valid            */
/* CL8600 not support, dist_cnt_id is valid       */
#define CLX_L3_VRF_FLAGS_DIST_CNT_VALID   (1U << 3)
#define CLX_L3_VRF_FLAGS_IPV4_ADMIN_VALID (1U << 4) /* ipv4 admin state valid     */
#define CLX_L3_VRF_FLAGS_IPV6_ADMIN_VALID (1U << 5) /* ipv6 admin state valid     */

    UI32_T flags;                                   /* Refer to CLX_L3_VRF_FLAGS_XX */
} CLX_L3_VRF_INFO_T;

/* IP Multicast Group Information */
typedef struct CLX_L3_MCAST_GROUP_INFO_S {
    UI32_T vrf_id;        /* Key: Virtual Routing Forwarding ID*/
    CLX_IP_ADDR_T src_ip; /* Key: Source IP address of L3 multicast group,
                           * which needs to be set for (S, G) group. For (, G)
                           * group, src_ip.ip_addr must be set to 0, and the
                           * IP version must be the same with group IP.
                           */
    CLX_IP_ADDR_T grp_ip; /* Key: Multicast group IP address */
    UI32_T mcast_id;      /* multicast forwarding ID */

/* Per G entry                     \
 * If set to 1, PIM-BIDIR support, \
 * else support PIM-SM             \
 */
#define CLX_L3_MCAST_FLAGS_PIM_BIDIR (1U << 0)
/* Per (*,G) or (S,G)                 \
 * If set to 1, the packet match this \
 * group entry will be dropped.       \
 */
#define CLX_L3_MCAST_FLAGS_DROP (1U << 1)
/* Per (*,G) or (S,G)           \
 * If set to 1, not modify TTL, \
 * else modify TTL.             \
 */
#define CLX_L3_MCAST_FLAGS_NO_MODIFY_TTL (1U << 2)
/* Per (S,G) group config                                \
 * If set to 1, forward packet from S to G.              \
 * If user uses PIM-SM protocol, before the              \
 * Short-Path tree is ready, this flag should set to 0,  \
 * multicast packet will send to CPU and encapsulated    \
 * as unicast packet, then, routing to RP. RP will       \
 * unpack this tunnel packet back to multicast packet    \
 * and send to host join this group. After Short-Path    \
 * tree is ready, hardware table entry for multicast     \
 * packet forwarding is OK, this bit should to set to 1, \
 * the multicast packet will not be send to CPU again.   \
 */
#define CLX_L3_MCAST_FLAGS_SPT_READY (1U << 3)
#define CLX_L3_MCAST_FLAGS_HIT       (1U << 4) /* Indicates Multicast group was hit */
#define CLX_L3_MCAST_FLAGS_TO_CPU    (1U << 5) /* Copy to CPU */
/* src ip direct connect to src DR, means need to encap mc to uc pkt, \
 * CL8600 new field */
#define CLX_L3_MCAST_FLAGS_SA_DC (1U << 6)

    UI32_T flags;          /* Refer to CLX_L3_MCAST_FLAGS_XXX */
    CLX_IP_ADDR_T rp_addr; /* Rendezvous Point address used in BIDIR-PIM
                            * protocol. User can use clx_l3_addMcastDfIntf to
                            * add the RP address to the DF state for one
                            * interface.
                            */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T mrpf_check_fail_action; /* If multicast reverse path
                                                                  * forwarding check is
                                                                  * failed, multicast packet
                                                                  * will do action by the
                                                                  * setting of this field.
                                                                  */
    UI32_T rpf_intf_id;                                          /* Interface ID used by RPF check.
                                                                  * If CLX_L3_MCAST_FLAGS_PIM_BIDIR flag is set to 1,
                                                                  * the RPF check will fail when the ingress interface
                                                                  * is not included in the DF interface of this group.
                                                                  * If CLX_L3_MCAST_FLAGS_PIM_BIDIR flag is set to 0,
                                                                  * the RPF check will fail when the ingress interface
                                                                  * is not equal to rpf_intf_id.
                                                                  */
    UI32_T group_label; /* Group label for CIA, CL8600 not support */
} CLX_L3_MCAST_GROUP_INFO_T;

/* IP Multicast Egress Interface Setting For NV */
typedef struct CLX_L3_MCAST_EGR_INTF_NV_S {
    CLX_TUNNEL_KEY_T tunnel_key; /* MC Tunnel */
    CLX_PORT_T port;             /* UC Tunnel */
    UI32_T nvo3_adj_id;          /* For tunnel encapsulation */
} CLX_L3_MCAST_EGR_INTF_NV_T;

/* IP Multicast Egress Interface Setting For TRILL */
typedef struct CLX_L3_MCAST_EGR_INTF_TRILL_S {
    CLX_TRILL_NICKNAME_T egr_nickname; /* Egress nickname */
    UI32_T nvo3_adj_id;                /* For tunnel encapsulation */
} CLX_L3_MCAST_EGR_INTF_TRILL_T;

/* IP Multicast Egress Interface Setting For MPLS */
typedef struct CLX_L3_MCAST_EGR_INTF_MPLS_S {
    UI32_T mpls_label;                                /* MPLS label */
    CLX_PORT_T port;                                  /* Tunnel port */
    UI32_T nvo3_adj_id;                               /* For tunnel encapsulation */
    UI32_T swap_label;                                /* MPLS LSP label, CL8600 new field */

#define CLX_L3_MCAST_EGR_MPLS_FLAGS_LABEL   (1U << 0) /* MPLS label valid flag */
#define CLX_L3_MCAST_EGR_MPLS_FLAGS_TUNNEL  (1U << 1) /* Tunnel port valid flag */
#define CLX_L3_MCAST_EGR_MPLS_FLAGS_TRASIT  (1U << 2) /* trasit valid flag, CL8600 new field */
#define CLX_L3_MCAST_EGR_MPLS_FLAGS_IS_SWAP (1U << 3) /* swap valid, CL8600 new field */

    UI32_T flags;                                     /* Refer to CLX_L3_MCAST_EGR_MPLS_FLAGS_XX. */
} CLX_L3_MCAST_EGR_INTF_MPLS_T;

/* IP Multicast Egress Interface Setting */
typedef struct CLX_L3_MCAST_EGR_INTF_S {
    CLX_L3_MCAST_EGR_INTF_TYPE_T intf_type;  /* Multicast egress interface type */
    UI32_T intf_id;                          /* L3 egress interface ID */
    CLX_VLAN_ACTION_T vlan_action;           /* VLAN action, CL8600 Not Support */
    CLX_VLAN_T svid;                         /* Service VLAN ID, CL8600 Not Support */
    CLX_VLAN_T cvid;                         /* Customer VLAN ID, CL8600 Not Support */
    CLX_MAC_T dmac;                          /* Destination MAC, CL8600 Not Support */
    union {
        UI32_T vm_id;                        /* VM ID, CL8600 Not Support */
        CLX_L3_MCAST_EGR_INTF_NV_T nv;       /* Setting For NV */
        CLX_L3_MCAST_EGR_INTF_TRILL_T trill; /* Setting For TRILL, CL8600 Not Support */
        CLX_L3_MCAST_EGR_INTF_MPLS_T mpls;   /* Setting For MPLS */
    };

/* Indicate if svid is applied to packet, CL8600 Not Support */
#define CLX_L3_MCAST_EGR_FLAGS_SVID_VALID (1U << 0)
/* Indicate if cvid is applied to packet, CL8600 Not Support */
#define CLX_L3_MCAST_EGR_FLAGS_CVID_VALID (1U << 1)
/* No modify Destination MAC, CL8600 Not Support */
#define CLX_L3_MCAST_EGR_FLAGS_KEEP_DMAC (1U << 2)
#define CLX_L3_MCAST_EGR_FLAGS_KEEP_SMAC (1U << 3) /* No modify Source MAC, CL8600 Not Support */
#define CLX_L3_MCAST_EGR_FLAGS_KEEP_TTL  (1U << 4) /* No modify TTL, CL8600 Not Support */

    UI32_T flags;                                  /* Refer to CLX_L3_MCAST_EGR_FLAGS_XX. */
} CLX_L3_MCAST_EGR_INTF_T;

/* BFD Global Configure Information */
typedef struct CLX_L3_BFD_INFO_S {
    UI32_T s_hop_port;                             /* BFD single hop UDP destination port  */
    UI32_T m_hop_port;                             /* BFD multi hop UDP destination port   */
    UI32_T echo_port;                              /* BFD echo UDP destination port        */

#define CLX_L3_BFD_FLAGS_ICMPV4_REDIR_EN (1U << 0) /* ICMPv4 redirect enabled flag */
#define CLX_L3_BFD_FLAGS_ICMPV6_REDIR_EN (1U << 1) /* ICMPv6 redirect enabled flag */
#define CLX_L3_BFD_FLAGS_CHECK_EN        (1U << 2) /* BFD globally enabled flag */
/* BFD echo bypass source check. If this flag is \
 * false, BFD echo packet may be dropped due to  \
 * source check in IP safe guard, URPF, or       \
 * icmp-redirect process.                        \
 */
#define CLX_L3_BFD_FLAGS_BYPASS_SOURCE_CHECK (1U << 3)

    UI32_T flags; /* Refer to CLX_L3_BFD_FLAGS_XX. */
} CLX_L3_BFD_INFO_T;

/* Adjacency type */
typedef enum CLX_L3_ADJ_TYPE_E {
    CLX_L3_ADJ_TYPE_L3 = 0, /* l3 adjacency */
    CLX_L3_ADJ_TYPE_NVO3,   /* nvo3 adjacency */
    CLX_L3_ADJ_TYPE_LAST
} CLX_L3_ADJ_TYPE_T;

/* Adjacency Information */
typedef struct CLX_L3_ADJ_INFO_S {
    CLX_L3_ADJ_TYPE_T adj_type; /* Adjacency type */
    CLX_MAC_T dst_mac;          /* Destination MAC */
    UI32_T intf_id;             /* Egress interface ID. L3 only */
    CLX_MAC_T src_mac;          /* nvo3 only */
    CLX_VLAN_T svid;            /* Service VLAN ID, CL8600 not support. */
    CLX_VLAN_T cvid;            /* Customer VLAN ID, CL8600 only valid support nvo3. */
    UI8_T pcp; /* New: CL8600 nvo3 only, outer header's vlan tag pcp,originally implemented by
                  clx_l3t_addInit */
    UI8_T dei; /* New: CL8600 nvo3 only, outer header's vlan tag dei,originally implemented by
                  clx_l3t_addInit */

/* Indicate if svid is applied to packet, CL8600 not support. */
#define CLX_L3_ADJ_FLAGS_SVID_VALID (1U << 0)
/* Indicate if cvid is applied to packet, CL8600 only valid support nvo3. */
#define CLX_L3_ADJ_FLAGS_CVID_VALID    (1U << 1)
#define CLX_L3_ADJ_FLAGS_DST_MAC_VALID (1U << 2) /* Indicate if dst_mac is applied to packet */
/* Keep source MAC address when packet forwarding from this adjacency,
 * CL8600 not support. */
#define CLX_L3_ADJ_FLAGS_KEEP_SA (1U << 3)
/* Keep VLAN when packet forwarding from this adjacency.        \
 * For nvo3 adjacency it indicates the inner vlan modification. \
 * CL8600 not support.                                          \
 */
#define CLX_L3_ADJ_FLAGS_KEEP_VLAN (1U << 4)
/* L3 only. Enable the fast-reroute on this adjacency. */
#define CLX_L3_ADJ_FLAGS_FRR_EN (1U << 5)
/* L3: Set adjacency with the input *ptr_adj_id.          \
 * nvo3: Add or Set adjacency with the input *ptr_adj_id. \
 */
#define CLX_L3_ADJ_FLAGS_WITH_ID  (1U << 6)
#define CLX_L3_ADJ_FLAGS_KEEP_TTL (1U << 7) /* No modify TTL, CL8600 not support. */
/* Enable URPF strict mode on this adjacency, CL8600 not support. */
#define CLX_L3_ADJ_FLAGS_URPF_STRICT_EN (1U << 8)
/* Black hole. The port field will be invalid. \
 * Only support L3 unicast Host or Route.      \
 * Not support FRR, ECMP and nvo3.             \
 */
#define CLX_L3_ADJ_FLAGS_DROP (1U << 9)
/* indicate if seg_id is applied to packet when configuring adjacency, \
 * not applied to clx_l3_getAdj, CL8600 not support */
#define CLX_L3_ADJ_FLAGS_SEG_ID_VALID (1U << 10)
/* New: CL8600 nvo3 only,Copy pcp_dei from inner frame. \
 * Set to 1 if pcp_dei value from inner vlan tag.       \
 * Set to 0 use specific pcp_dei.                       \
 */
#define CLX_L3_ADJ_FLAGS_QOS_TNL_UNIFORM (1U << 11)

    UI32_T flags;           /* Refer to CLX_L3_ADJ_FLAGS_XX. */
    CLX_PORT_T port;        /* Destination Interface Object id. */
    UI16_T s_tpid;          /* nvo3 only, CL8600 not support */
    UI16_T c_tpid;          /* nvo3 only, CL8600 not support */
    UI16_T mtu_size;        /* nvo3 only */
    UI32_T frr_backup_path; /* L3 only. Backup adjacency for fast-reroute. */
    UI32_T frr_state_id;    /* L3 only. State id for fast-reroute. */
    UI32_T seg_id;          /* Segment id, CL8600 not support */
} CLX_L3_ADJ_INFO_T;

/* L3 Packet with Option Header Action Configuration */
typedef struct CLX_L3_OPTION_HEADER_INFO_S {
    CLX_FWD_ACTION_T ipv4_action; /* Action of IPV4 Packet with option header */
    CLX_FWD_ACTION_T ipv6_action; /* Action of IPV6 Packet with option header */
} CLX_L3_OPTION_HEADER_INFO_T;

/* IP Multicast PIM-register Setting */
typedef struct CLX_L3_PIM_REG_INFO_S {
    UI32_T vrf_id;                   /* key: Virtual Routing Forwarding ID */
    CLX_L3_IP_NETWORK_ADDR_T src_ip; /* key: IP subnet */
    UI32_T rpf_intf_id;              /* Interface ID used for RPF check. */
    UI32_T mcast_id;                 /* multicast forwarding ID */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T mrpf_check_fail_action; /* If multicast rpf check failed,
                                                                  * packet will do action by the
                                                                  * setting of this field.
                                                                  */

/* If enable this bit, mcast_id will be ignore */
#define CLX_L3_PIM_REG_INFO_FLAGS_TO_CPU (1U << 0)

    UI32_T flags; /* Refer to CLX_L3_PIM_REG_INFO_FLAGS_XX. */
} CLX_L3_PIM_REG_INFO_T;

/* ecmp hash path result info */
typedef struct CLX_L3_ECMP_HASHPATH_RSLT_INFO_S {
    UI32_T hash_value;   /* flow hash value, hash value only use 0-11 bit */
    UI32_T hash_path_di; /* ecmp hash path di */
    UI32_T hash_path_bd; /* ecmp hash path bd */
    UI32_T output_type;  /* ecmp member type  */
    UI32_T output_id;    /* ecmp member id    */
    CLX_PORT_TYPE_T port_type;
    UI32_T port_id;
} CLX_L3_ECMP_HASHPATH_RSLT_INFO_T;

/* host type */
typedef enum CLX_L3_HOST_TYPE_E {
    CLX_L3_HASH_V4_V6 = 0,
    CLX_L3_HASH_V4,
    CLX_L3_HASH_V6,
    CLX_L3_TCAM_V4,
    CLX_L3_TCAM_V6,
    CLX_L3_V4_ALL,
    CLX_L3_V6_ALL,
    CLX_L3_HOST_TYPE_LAST
} CLX_L3_HOST_TYPE_T;

/* -------------------------------------------------------------- Traverse Callbacks */
typedef CLX_ERROR_NO_T (*CLX_L3_ADJ_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                     const UI32_T adj_id,
                                                     const CLX_L3_ADJ_INFO_T *ptr_adj_info,
                                                     void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3_INTF_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                      const CLX_BRIDGE_DOMAIN_T bdid,
                                                      const CLX_L3_INTF_INFO_T *ptr_intf_info,
                                                      void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3_ROUTER_MAC_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_L3_ROUTER_MAC_INFO_T *ptr_router_mac_info,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const UI32_T ecmp_grp_id,
    const CLX_L3_ECMP_GRP_INFO_T *ptr_ecmp_grp_info,
    const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3_HOST_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                      const CLX_L3_HOST_INFO_T *ptr_host_info,
                                                      void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3_BCAST_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_L3_SUBNET_BCAST_INFO_T *ptr_bcast_info,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3_ROUTE_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                       const CLX_L3_ROUTE_INFO_T *ptr_route_info,
                                                       void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info,
    void *ptr_cookie);

/**
 * @brief This API is used to add the interface based on Bridge Domain ID.
 *        User should specify the Bridge Domain ID and the interface configuration.
 *
 * While create L3 interface for router-only L2 interface, user do not need to specify a BDID.
 * While create L3 interface for both bridging and routing L2 interface, user needs to create bridge
 * domain by this BDID firstly, otherwise, interface cannot work correctly.
 * User only needs to fill in VRF ID and MAC if a VLAN based interface is created.
 * If this L3 Interface is existed, this API may change the configure of Interface.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     bdid           - Bridge Domain ID
 * @param [in]     ptr_l3_intf    - The Interface information
 *                                  ptr_l3_intf->intf_id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can't be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_addIntf(const UI32_T unit, const CLX_BRIDGE_DOMAIN_T bdid, CLX_L3_INTF_INFO_T *ptr_l3_intf);

/**
 * @brief This API is used to delete the interface based on Bridge Domain ID.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     srv_id    - Service ID, specific bridge domain ID or L3 interface ID
 *                             The service type can be specified by CLX_L3_SRV_TYPE_XX, otherwise,
 *                             srv_id is regarded as the bridge domain ID
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified interface has not been created
 */
CLX_ERROR_NO_T
clx_l3_delIntf(const UI32_T unit, const UI32_T srv_id);

/**
 * @brief This API is used to get interface information according to specified Bridge Domain ID.
 *
 * This API is used get the interface property according to the specified service ID.
 * While specify the service ID is BDID, the L3 interface binded with the BDID will be retrieved.
 * User must create interface first. If the IP network address bound to this interface cannot be
 * obtained, user needs to use clx_l3_getHost and clx_l3_getRoute to get the host and route entry
 * added.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     srv_id         - Service ID, specific bridge domain ID or L3 interface ID
 *                                  The service type can be specified by CLX_L3_SRV_TYPE_XX,
 * otherwise, srv_id is regarded as the bridge domain ID
 * @param [out]    ptr_l3_intf    - Interface property, including MAC, VRF ID, MTU, URPF check mode
 * and etc
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified interface has not been created
 */
CLX_ERROR_NO_T
clx_l3_getIntf(const UI32_T unit, const UI32_T srv_id, CLX_L3_INTF_INFO_T *ptr_l3_intf);

/**
 * @brief This API is used to get all Interfaces.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_traverseIntf(const UI32_T unit,
                    const CLX_L3_INTF_TRAVERSE_FUNC_T callback,
                    void *ptr_cookie);

/**
 * @brief This API is used to add my router MAC address and interface to my router MAC table.
 *        User should specify the entry index, interface ID and my MAC address.
 *
 * User needs to specify the index of MyRouterMAC
 * table and the data of entry, including the interface ID, MAC address, and the mask of them.
 * MyRouterMAC table is used to judge the incoming packet whether need to send to L3 unicast packet
 * flow. Unicast IP routing can be enabled on per port or per forwarding domain basis.
 * When packet arrives, ingress L3 interface will be derived. If IPv4/IPv6 routing is enabled,
 * the ingress L3 interface together with the Layer 2 destination MAC address are used to lookup
 * the MyRouterMAC table, if the ingress interface ID and destination MAC address of incoming packet
 * can't match, packet will not go to L3 unicast packet flow.
 * User can set mask bit to 0 in order to multiplex one entry by multiple interface ID and MAC
 * address.
 *
 * support_chip all
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     index                  - Hardware access index
 * @param [in]     ptr_router_mac_info    - myRouterMAC information including MAC/MAC mask and
 * ifidx/ifidx mask
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can't be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_addMyRouterMac(const UI32_T unit,
                      const UI32_T index,
                      const CLX_L3_ROUTER_MAC_INFO_T *ptr_router_mac_info);

/**
 * @brief This API is used to delete my router MAC address and interface to my router MAC table.
 *        User should specify the entry index.
 *
 * support_chip all
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     index    - Hardware access index
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified interface has not been created
 */
CLX_ERROR_NO_T
clx_l3_delMyRouterMac(const UI32_T unit, const UI32_T index);

/**
 * @brief Get my router MAC information in my router MAC table.
 *
 * support_chip all
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     index                  - Hardware access index
 * @param [out]    ptr_router_mac_info    - myRouterMAC information, MAC/MAC mask and ifidx/ifidx
 * mask
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified interface has not been created
 */
CLX_ERROR_NO_T
clx_l3_getMyRouterMac(const UI32_T unit,
                      const UI32_T index,
                      CLX_L3_ROUTER_MAC_INFO_T *ptr_router_mac_info);

/**
 * @brief This API is used to get all my router MAC entries.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_traverseMyRouterMac(const UI32_T unit,
                           const CLX_L3_ROUTER_MAC_TRAVERSE_FUNC_T callback,
                           void *ptr_cookie);

/**
 * @brief This API is used to add/set an adjacency.
 *
 * This API is used to add/set an adjacency for a host, route or ecmp group.
 * If the ptr_adj_info->flags & CLX_L3_ADJ_FLAGS_WITH_ID is 0, means add a new adjacency,
 * and the *ptr_adj_id will be the returned value. Otherwise, set an existing adjacency,
 * and the *ptr_adj_id will be the inputted value.
 * If this adjacency is used by host, route, or ecmp group, the packet will be
 * affected when the adjacency is set.
 *
 * support_chip all
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     ptr_adj_info         - Adjacency information.
 * @param [out]    ptr_adj_id           - Adjacency ID.
 * @return         CLX_E_OK             - Operate success.
 * @return         CLX_E_BAD_PARAMETER  - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_addAdj(const UI32_T unit, const CLX_L3_ADJ_INFO_T *ptr_adj_info, UI32_T *ptr_adj_id);

/**
 * @brief This API is used to delete an adjacency.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     type      - Adjacency type.
 * @param [in]     adj_id    - Adjacency ID
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_delAdj(const UI32_T unit, const CLX_L3_ADJ_TYPE_T type, const UI32_T adj_id);

/**
 * @brief This API is used to get the Adjacency information
 *
 * support_chip all
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     adj_id               - Adjacency ID.
 * @param [in]     ptr_adj_info         - Adjacency information.
 * @return         CLX_E_OK             - Operate success.
 * @return         CLX_E_BAD_PARAMETER  - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getAdj(const UI32_T unit, const UI32_T adj_id, CLX_L3_ADJ_INFO_T *ptr_adj_info);

/**
 * @brief This API is used to get all Adjacencies.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - Adjacency type.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_traverseAdj(const UI32_T unit,
                   const CLX_L3_ADJ_TYPE_T type,
                   const CLX_L3_ADJ_TRAVERSE_FUNC_T callback,
                   void *ptr_cookie);

/**
 * @brief This API is used to add an l3 host entry.
 *
 * The detailed information of L3 host entry refers to structure of CLX_L3_HOST_INFO_T.
 * Key of entry is IP address and VRF ID.
 * For packets which are attached to the Host lookup L3 host to find adjacency and egress
 * interface information, the lookup process uses the whole destination IP address in the
 * packet and the VRF ID assigned to packet's ingress interface. If a matched entry is found,
 * the egress interface will be used for delivery.
 * If the host entry exists, this API will change the attribute of entry. The key of entry cannot be
 * changed. NV and VM modules can also call this API to add the host entry.
 *
 * support_chip all
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_host_info    - L3 host information, including IP address, VRF ID, output path
 * ID.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can't be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_addHost(const UI32_T unit, const CLX_L3_HOST_INFO_T *ptr_host_info);

/**
 * @brief This API is used to delete an l3 host entry.
 *
 * User only needs to fill the IP address and VRF ID into ptr_host_info.
 * NV and VM modules can also call this API to delete the host entry.
 *
 * support_chip all
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_host_info    - L3 host information, including IP address, VRF ID, output path
 * ID.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified host entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_delHost(const UI32_T unit, const CLX_L3_HOST_INFO_T *ptr_host_info);

/**
 * @brief This API is used to get an L3 host entry.
 *
 * User only needs to fill IP address and VRF ID into ptr_host_info.
 * NV and VM modules can also call this API to get the host entry.
 *
 * support_chip all
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_host_info    - Only need L3 host's key: IP address and VRF ID.
 * @param [out]     ptr_host_info    - L3 host information, including IP address, VRF ID, output
 * path ID.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified host entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_getHost(const UI32_T unit, CLX_L3_HOST_INFO_T *ptr_host_info);

/**
 * @brief This API is used to get all host entries.
 *
 * NV and VM modules can also call this API to traverse all host entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function user provided by user, user can do self
 *                                 action for every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_traverseHost(const UI32_T unit,
                    const CLX_L3_HOST_TRAVERSE_FUNC_T callback,
                    void *ptr_cookie);

/**
 * @brief This API is used to add an L3 Subnet Broadcast entry.
 *
 * IP subnet address and VRF ID need to be filled into ptr_subnet_info.
 * If the subnet entry exists, some attributes of this entry will be changed.
 * The key of entry cannot be changed.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     ptr_subnet_info    - Subnet Broadcast information, including subnet address, VRF
 * ID, mcast ID. Key is the subnet address and VRF ID.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, the entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_addSubnetBcast(const UI32_T unit, const CLX_L3_SUBNET_BCAST_INFO_T *ptr_subnet_info);

/**
 * @brief This API is used to delete an L3 Route entry.
 *
 * The detailed information of route refers to structure of CLX_L3_SUBNET_BCAST_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     ptr_subnet_info    - Subnet Broadcast information, IP subnet address and VRF ID
 * must be input.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_delSubnetBcast(const UI32_T unit, const CLX_L3_SUBNET_BCAST_INFO_T *ptr_subnet_info);

/**
 * @brief This API is used to get an L3 Subnet Broadcast entry.
 *
 * User only needs to fill in IP subnet address and VRF ID.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     ptr_subnet_info    - Subnet Broadcast information, only including key: IP subnet
 * address, VRF ID
 * @param [out]    ptr_subnet_info    - Subnet Broadcast information, including IP subnet address,
 * VRF ID, the output path ID and so on.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_getSubnetBcast(const UI32_T unit, CLX_L3_SUBNET_BCAST_INFO_T *ptr_subnet_info);

/**
 * @brief This API is used to add an L3 Route entry.
 *
 * The detailed information of route refers to structure of CLX_L3_ROUTE_INFO_T.
 * If the route entry exists, some attributes of this entry will be changed.
 * The key of entry cannot be changed.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_route_info    - Route information, including network address, VRF ID,
 *                                     the output path ID and etc.
 *                                     Key is the network address and VRF ID.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, the entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_addRoute(const UI32_T unit, const CLX_L3_ROUTE_INFO_T *ptr_route_info);

/**
 * @brief This API is used to delete an L3 Route entry.
 *
 * IP network address and VRF ID need to be filled into ptr_route_info.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_route_info    - Route information, IP network address and VRF ID must be
 * input.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_delRoute(const UI32_T unit, const CLX_L3_ROUTE_INFO_T *ptr_route_info);

/**
 * @brief This API is used to get an L3 Route entry.
 *
 * User only needs to fill in IP network address and VRF ID.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_route_info    - The route information, only including key: IP network
 * address, VRF ID
 * @param [out]    ptr_route_info    - The route information, including IP network address, VRF ID,
 *                                     the output path ID and so on.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_getRoute(const UI32_T unit, CLX_L3_ROUTE_INFO_T *ptr_route_info);

/**
 * @brief This API is used to get all Route entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_traverseRoute(const UI32_T unit,
                     const CLX_L3_ROUTE_TRAVERSE_FUNC_T callback,
                     void *ptr_cookie);

/**
 * @brief This API is used to create an ECMP route Group.
 *        User should specify the configuration of the ECMP route group.
 *        The group ID will be output.
 *
 * Equal-cost multi-path (ECMP) is a routing technique for routing packets along
 * multiple paths of equal cost. The forwarding engine identifies paths by adjacency.
 * When forwarding a packet, the router must decide which adjacency to use. For
 * detailed information of ECMP group, refer to CLX_L3_ECMP_GRP_INFO_T.
 * User can set the property of ECMP route group when creating the ECMP group or use
 * API clx_l3_setEcmpGrp to modify property of ECMP group at a later time.
 * In order to add the ECMP route, user can follow the steps below:
 * 1) Create ECMP route group with API: clx_l3_createEcmpGrp. Group index will be
 * allocated and returned to user.
 * 2) Set the property of ECMP route group with API: clx_l3_setEcmpGrp.
 * 3) Add one or multiple ECMP paths to this ECMP group with API:  clx_l3_addEcmpGrpPath.
 * 4) Add one ECMP route using this ECMP group with API: clx_l3_addRoute.
 *
 * support_chip all
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     ptr_ecmp_grp_info    - ECMP group information including
 *                                        hash mode, SW hash value count,
 *                                        and DLB flag
 * @param [out]    ptr_ecmp_grp_id      - ECMP group ID allocated
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can't be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_createEcmpGrp(const UI32_T unit,
                     const CLX_L3_ECMP_GRP_INFO_T *ptr_ecmp_grp_info,
                     UI32_T *ptr_ecmp_grp_id);

/**
 * @brief This API is used to set the property of the ECMP route Group.
 *        User should specify the configuration of the ECMP route group changed. The group
 *        ID must be input.
 *
 * Allow to change normal HW mode to SW mode, and vice versa.
 * Not allow the followings:
 * - normal HW mode <-> weighted HW/SW mode
 * - normal SW mode <-> weighted HW/SW mode
 * - weighted HW mode <-> weighted SW mode
 * For detailed information of ECMP group, refer to CLX_L3_ECMP_GRP_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     ecmp_grp_id          - Specify group ID to be set
 * @param [in]     ptr_ecmp_grp_info    - ECMP group information, including
 *                                        hash mode, SW hash value count,
 *                                        DLB flag and IPV4 flag
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_setEcmpGrp(const UI32_T unit,
                  const UI32_T ecmp_grp_id,
                  const CLX_L3_ECMP_GRP_INFO_T *ptr_ecmp_grp_info);

/**
 * @brief This API is used to delete an ECMP route group.
 *        User should specify the group ID of the ECMP route group.
 *
 * This API is used to delete an ECMP group entry. All ECMP paths and ECMP hash paths will be
 * deleted. If an ECMP route uses this deleted ECMP group, this route will be invalid. User
 * needs to delete this route and add this route again with the new adjacency information.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     type           - ECMP group type.
 * @param [in]     ecmp_grp_id    - Specify group ID to be deleted
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_delEcmpGrp(const UI32_T unit, const CLX_L3_OUTPUT_TYPE_T type, const UI32_T ecmp_grp_id);

/**
 * @brief This API is used to get ECMP route group information.
 *        User should specify the group ID of the ECMP route group.
 *
 * For detailed information of the ECMP group, refer to CLX_L3_ECMP_GRP_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     ecmp_grp_id          - Specify group ID to be obtained
 * @param [out]    ptr_ecmp_grp_info    - ECMP group information, including
 *                                        hash mode, SW hash value count,
 *                                        DLB flag and IPV4 flag.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified host entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_getEcmpGrp(const UI32_T unit,
                  const UI32_T ecmp_grp_id,
                  CLX_L3_ECMP_GRP_INFO_T *ptr_ecmp_grp_info);

/**
 * @brief This API is used to get all ECMP groups.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     type          - ECMP group type.
 * @param [in]     callback      - Callback function provided by user, user can do self
 *                                 action to every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_traverseEcmpGrp(const UI32_T unit,
                       const CLX_L3_OUTPUT_TYPE_T type,
                       const CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T callback,
                       void *ptr_cookie);

/**
 * @brief This API is used to sync two ecmp group member.
 *
 * Now only support hw mode ecmp without weight and L3 type.
 *
 * support_chip CL8500, CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ori_grp_id    - original ECMP group.
 * @param [in]     new_grp_id    - current ECMP group.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_syncEcmpGrp(const UI32_T unit, const UI32_T ori_grp_id, const UI32_T new_grp_id);

/**
 * @brief This API is used to add an ECMP path to an ECMP route group.
 *        User should specify the group ID of the ECMP route group and the ECMP path information.
 *
 * For detailed information of the ECMP path, refer to CLX_L3_ECMP_PATH_INFO_T.
 * User can add multiple ECMP paths to one ECMP group.
 *
 * support_chip all
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     ecmp_grp_id           - Specify ECMP group ID
 * @param [in]     ptr_ecmp_path_info    - It includes output path ID.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_addEcmpGrpPath(const UI32_T unit,
                      const UI32_T ecmp_grp_id,
                      const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info);

/**
 * @brief This API is used to delete an ECMP path to an ECMP route group.
 *        User should specify the group ID of the ECMP route group and the ECMP path information.
 *        User should not delete all paths from a group if the group is used by others.
 *
 * For detailed information of the ECMP path, refer to CLX_L3_ECMP_PATH_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     ecmp_grp_id           - Specify group ID
 * @param [in]     ptr_ecmp_path_info    - ECMP path to be deleted,
 *                                         including output path ID.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group entry or ECMP path has not
 * been created
 */
CLX_ERROR_NO_T
clx_l3_delEcmpGrpPath(const UI32_T unit,
                      const UI32_T ecmp_grp_id,
                      const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info);

/**
 * @brief This API is used to get an ECMP path from an ECMP route group according to index.
 *        User should specify the group ID of the ECMP route group and the ECMP path
 *        index. The ECMP path information will be output.
 *
 * Detail information of the ECMP path refers to CLX_L3_ECMP_PATH_INFO_T.
 * User can get the total path number by API: clx_l3_getEcmpGrp; the path_cnt in structure
 * CLX_L3_ECMP_GRP_INFO_T is the total path number. Path index starts from 0 to path number-1.
 * The ECMP path is sorted by the order by which user adds the ECMP path. The new ECMP path is
 * always the last in the order.But if user deletes an ECMP path, the ECMP path belonging to the
 * same ECMP group will be re-sorted.
 *
 * support_chip all
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     ecmp_grp_id           - Specify group ID
 * @param [in]     path_idx              - ECMP path index
 * @param [out]    ptr_ecmp_path_info    - ECMP path information for path index,
 *                                         including output path IP.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group entry or
 *                                            ECMP path entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_getEcmpGrpPathByIdx(const UI32_T unit,
                           const UI32_T ecmp_grp_id,
                           const UI32_T path_idx,
                           CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info);

/**
 * @brief This API is used to set the hash value for an ECMP path.
 *        User should specify the ECMP route group ID, the hash value and the ECMP path information.
 *
 * For detailed information of the ECMP path, refer to CLX_L3_ECMP_PATH_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                  - Device unit number
 * @param [in]     ecmp_grp_id           - Specify ECMP group ID
 * @param [in]     ptr_hash_val_list     - hash value (list) needed for configuration, share same
 * ECMP path
 * @param [in]     hash_val_cnt          - hash value count needed for configuration
 * @param [in]     ptr_ecmp_path_info    - ECMP path information, including output path ID.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group or ECMP path entry has not
 * been created
 */
CLX_ERROR_NO_T
clx_l3_setEcmpGrpHashPath(const UI32_T unit,
                          const UI32_T ecmp_grp_id,
                          const UI32_T *ptr_hash_val_list,
                          const UI32_T hash_val_cnt,
                          const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info);

/**
 * @brief This API is used to get the hash value of an ECMP path.
 *        User should specify the ECMP route group ID and the ECMP path information.
 *        The hash value list will be output.
 *
 * For detailed information of the ECMP path, refer to CLX_L3_ECMP_PATH_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     ecmp_grp_id                - ECMP group ID
 * @param [in]     hash_val_cnt               - Count of specified hash value
 * @param [in]     ptr_ecmp_path_info         - ECMP path information, including output path ID.
 * @param [out]    ptr_hash_val_list          - Hash value array: the array unit number is the value
 * of ptr_actual_hash_val_cnt.
 * @param [out]    ptr_actual_hash_val_cnt    - Actual ECMP hash value count
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group or ECMP path entry has not
 * been created
 */
CLX_ERROR_NO_T
clx_l3_getEcmpGrpHashPath(const UI32_T unit,
                          const UI32_T ecmp_grp_id,
                          const UI32_T hash_val_cnt,
                          const CLX_L3_ECMP_PATH_INFO_T *ptr_ecmp_path_info,
                          UI32_T *ptr_hash_val_list,
                          UI32_T *ptr_actual_hash_val_cnt);

/**
 * @brief This API is used to set the packet handling action on a Virtual Routing Forwarding.
 *        User should specify the VRF ID and the packet handling action.
 *
 * For detailed packet handling configuration, refer to CLX_L3_VRF_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     vrf_id              - Virtual Routing Forwarding ID
 * @param [in]     ptr_pkt_handling    - Packet handling configuration
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified VRF has not been created
 */
CLX_ERROR_NO_T
clx_l3_setPktHandlingByVrf(const UI32_T unit,
                           const UI32_T vrf_id,
                           const CLX_L3_VRF_INFO_T *ptr_pkt_handling);

/**
 * @brief This API is used to get the packet handling action on a Virtual Routing Forwarding.
 *        User should specify the VRF ID. The packet handling action will be output.
 *
 * For detailed packet handling configuration, refer to CLX_L3_VRF_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     vrf_id              - Virtual Routing Forwarding ID
 * @param [out]    ptr_pkt_handling    - Packet handling configuration
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified VRF has not been created.
 */
CLX_ERROR_NO_T
clx_l3_getPktHandlingByVrf(const UI32_T unit,
                           const UI32_T vrf_id,
                           CLX_L3_VRF_INFO_T *ptr_pkt_handling);

/**
 * @brief This API is used to allocate a multicast forwarding ID.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     flags           - The L3 multicast flags, refer to CLX_L3_MCAST_FLAGS_XXX
 * @param [out]    ptr_mcast_id    - The allocated multicast forwarding ID
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - No more memory for the entry.
 */
CLX_ERROR_NO_T
clx_l3_addMcastId(const UI32_T unit, const UI32_T flags, UI32_T *ptr_mcast_id);

/**
 * @brief This API is used to release a multicast forwarding ID.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     mcast_id    - The multicast forwarding ID
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_delMcastId(const UI32_T unit, const UI32_T mcast_id);

/**
 * @brief This API is used to get the rough info on a multicast forwarding ID.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     mcast_id       - The multicast forwarding ID
 * @param [out]    ptr_flags      - The L3 multicast flags, refer to CLX_L3_MCAST_FLAGS_XXX
 * @param [out]    port_bitmap    - The egress port bitmap. If a bit is set to 1, the
 *                                  corresponding port is the member port.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The multicast forwarding ID is not used.
 */
CLX_ERROR_NO_T
clx_l3_getMcastId(const UI32_T unit,
                  const UI32_T mcast_id,
                  UI32_T *ptr_flags,
                  CLX_PORT_BITMAP_T port_bitmap);

/**
 * @brief This API is used to add an IP multicast group.
 *
 * The VRF ID, multicast group IP address must be set for adding (*.G) group, the source IP address
 * also needs to be set for adding (S,G) group. If the multicast group exists, update the group
 * property. For other group property, refer to the description of CLX_L3_MCAST_GROUP_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_group_info    - The multicast group information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - No more memory for the entry.
 */
CLX_ERROR_NO_T
clx_l3_addMcastGroup(const UI32_T unit, const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

/**
 * @brief This API is used to delete an IP multicast group.
 *
 * Only need to fill VRF ID and multicast group IP address in  ptr_group_info
 * for deleting (*,G) group.
 * The source IP address is also needed for deleting (S,G) group.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_group_info    - The multicast group information
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
CLX_ERROR_NO_T
clx_l3_delMcastGroup(const UI32_T unit, const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

/**
 * @brief This API is used to get an IP multicast group information.
 *
 * For detailed group information, refer to description of CLX_L3_MCAST_GROUP_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_group_info    - The multicast group information. Only need to
 *                                     fill VRF ID and multicast group IP address for
 *                                     (*,G) group. The source IP address also need for (S,G) group.
 * @param [out]    ptr_group_info    - Other multicast data information
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
CLX_ERROR_NO_T
clx_l3_getMcastGroup(const UI32_T unit, CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

/**
 * @brief This API is used to add the egress interface of an IP multicast group in an egress port.
 *
 * If the egress port is the CPU port, the egress interface count must be 0.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     mcast_id        - The multicast forwarding ID
 * @param [in]     port_id         - The egress port ID
 * @param [in]     egr_intf_cnt    - The egress interface count
 * @param [in]     ptr_egr_intf    - The egress interface information
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - No more memory for the entry.
 */
CLX_ERROR_NO_T
clx_l3_addMcastEgrIntfByPort(const UI32_T unit,
                             const UI32_T mcast_id,
                             const UI32_T port_id,
                             const UI32_T egr_intf_cnt,
                             const CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf);

/**
 * @brief This API is used to delete the egress interface of an IP multicast group in an egress
 * port.
 *
 * If the egress port is the CPU port, the egress interface count must be 0.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     mcast_id        - The multicast forwarding ID
 * @param [in]     port_id         - The egress port ID
 * @param [in]     egr_intf_cnt    - The egress interface count
 * @param [in]     ptr_egr_intf    - The egress interface information
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
CLX_ERROR_NO_T
clx_l3_delMcastEgrIntfByPort(const UI32_T unit,
                             const UI32_T mcast_id,
                             const UI32_T port_id,
                             const UI32_T egr_intf_cnt,
                             const CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf);

/**
 * @brief This API is used to replace the whole egress interface list  on a port for a multicast
 * forwarding ID.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     mcast_id        - The multicast forwarding ID
 * @param [in]     port_id         - The egress port ID
 * @param [in]     egr_intf_cnt    - The egress interface count
 * @param [in]     ptr_egr_intf    - The egress interface information
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
CLX_ERROR_NO_T
clx_l3_setMcastEgrIntfByPort(const UI32_T unit,
                             const UI32_T mcast_id,
                             const UI32_T port_id,
                             const UI32_T egr_intf_cnt,
                             const CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf);

/**
 * @brief This API is used to get the egress interface number of an IP multicast group in an egress
 * port.
 *
 * This API is used to get egress interface number of an egress port of IP
 * multicast group. One L3 multicast group can have multiple egress ports,
 * and one egress port can be sent out from multiple egress interfaces.
 * Therefore, user needs to use this API to get the interface number per port,
 * and then use the API "clx_l3_getMcastEgrIntfCntByPort"  to get all egress
 * interfaces listed in this port.
 *
 * support_chip all
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     mcast_id            - The multicast forwarding ID
 * @param [in]     port_id             - The egress port ID
 * @param [out]    ptr_egr_intf_cnt    - The egress interface count of the egress port
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getMcastEgrIntfCntByPort(const UI32_T unit,
                                const UI32_T mcast_id,
                                const UI32_T port_id,
                                UI32_T *ptr_egr_intf_cnt);

/**
 * @brief This API is used to get all egress interfaces of an IP multicast group in an egress port.
 *
 * support_chip all
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     mcast_id                   - The multicast forwarding ID
 * @param [in]     port_id                    - The egress port ID
 * @param [in]     egr_intf_cnt               - The egress interface count of the egress port
 * @param [out]    ptr_egr_intf               - The egress interface information
 * @param [out]    ptr_actual_egr_intf_cnt    - The actual egress interface count
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getMcastEgrIntfByPort(const UI32_T unit,
                             const UI32_T mcast_id,
                             const UI32_T port_id,
                             const UI32_T egr_intf_cnt,
                             CLX_L3_MCAST_EGR_INTF_T *ptr_egr_intf,
                             UI32_T *ptr_actual_egr_intf_cnt);

/**
 * @brief This API is used to add a specific interface as the DF interface for a multicast group.
 *
 * This API is used to add a specific interface as the DF interface
 * for a multicast group. This API is only used before a multicast group
 * is set to BIDIR-PIM mode. Otherwise, it will return fail when set/add the multicast group.
 * The ptr_rp_addr is set in one multicast group.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     intf_id        - The logical interface ID
 * @param [in]     ptr_rp_addr    - The RP IP address
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_addMcastDfIntf(const UI32_T unit, const UI32_T intf_id, const CLX_IP_ADDR_T *ptr_rp_addr);

/**
 * @brief This API is used to delete a specific interface as the DF interface for a multicast group.
 *
 * This API is only used  for PIM-BIDIR mode.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     intf_id        - The logical interface ID
 * @param [in]     ptr_rp_addr    - The RP IP address
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_delMcastDfIntf(const UI32_T unit, const UI32_T intf_id, const CLX_IP_ADDR_T *ptr_rp_addr);

/**
 * @brief This API is used to get the RP IP address list if the specified interface is a DF
 * interface.
 *
 * This API is only used  for PIM-BIDIR mode.
 *
 * support_chip all
 *
 * @param [in]     unit                      - Device unit number
 * @param [in]     intf_id                   - The logical interface ID
 * @param [in]     rp_addr_cnt               - The RP IP address count t0 be obtained by user
 * @param [out]    ptr_actual_rp_addr_cnt    - The actual RP IP address count
 * @param [out]    ptr_rp_addr               - The RP IP address
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getMcastDfIntf(const UI32_T unit,
                      const UI32_T intf_id,
                      const UI32_T rp_addr_cnt,
                      UI32_T *ptr_actual_rp_addr_cnt,
                      CLX_IP_ADDR_T *ptr_rp_addr);

/**
 * @brief This API is used to get all group entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function user provided by user, user can do self
 *                                 action for every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_traverseMcastGroup(const UI32_T unit,
                          const CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T callback,
                          void *ptr_cookie);

/**
 * @brief This API is used to set the configuration of Bidirectional Forwarding Detection.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_bfd_info    - Refer to CLX_L3_BFD_INFO_T
 * @return         CLX_E_OK               - operate success.
 * @return         CLX_E_BAD_PARAMETER    - bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_setBfdInfo(const UI32_T unit, const CLX_L3_BFD_INFO_T *ptr_bfd_info);

/**
 * @brief This API is used to get the configuration of Bidirectional Forwarding Detection.
 *
 * User can enable/disable BFD, or set the UDP port of BFD control packet
 * and echo packet. User also can use this API to set whether bypass
 * source check for BFD echo packet.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit            - Device unit number
 * @param [out]    ptr_bfd_info    - Refer to CLX_L3_BFD_INFO_T
 * @return         CLX_E_OK               - operate success.
 * @return         CLX_E_BAD_PARAMETER    - bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getBfdInfo(const UI32_T unit, CLX_L3_BFD_INFO_T *ptr_bfd_info);

/**
 * @brief This API is used to set the action for the packet with option header.
 *
 * support_chip CL8300
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     action    - Refer to CLX_FWD_ACTION_T.
 * @return         CLX_E_OK               - operate success.
 * @return         CLX_E_BAD_PARAMETER    - bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_setOptionHeaderAction(const UI32_T unit, const CLX_L3_OPTION_HEADER_INFO_T action);

/**
 * @brief This API is used to get the action for the packet with option header.
 *
 * support_chip CL8300
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_action    - Refer to CLX_FWD_ACTION_T.
 * @return         CLX_E_OK               - operate success.
 * @return         CLX_E_BAD_PARAMETER    - bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getOptionHeaderAction(const UI32_T unit, CLX_L3_OPTION_HEADER_INFO_T *ptr_action);

/**
 * @brief This API is used to create a state_id for Fast Re-Route. This ID
 *        can be used in CLX_L3_ECMP_PATH_INFO_T or CLX_L3_ADJ_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     type            - Egress type. Only support ADJ & NVO3_ADJ
 * @param [out]    ptr_state_id    - State ID
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_createFrrStateId(const UI32_T unit, const CLX_L3_OUTPUT_TYPE_T type, UI32_T *ptr_state_id);

/**
 * @brief This API is used to destroy a state ID.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Egress type. Only support ADJ & NVO3_ADJ
 * @param [in]     state_id    - State ID for Fast Re-Route
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_destroyFrrStateId(const UI32_T unit, const CLX_L3_OUTPUT_TYPE_T type, const UI32_T state_id);

/**
 * @brief This API is used to add frr path.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     type         - FRR group type
 * @param [in]     frr_grp      - FRR group ID
 * @param [in]     is_stanby    - is stanby path
 * @param [in]     path_info    - FRR path info,
 *                                including output path ID, mpls label.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_addFrrPath(const UI32_T unit,
                  const CLX_L3_OUTPUT_TYPE_T type,
                  const UI32_T frr_grp,
                  const BOOL_T is_stanby,
                  const CLX_L3_FRR_PATH_INFO_T *path_info);

/**
 * @brief This API is used to del frr path.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     type         - FRR group type
 * @param [in]     frr_grp      - FRR group ID
 * @param [in]     is_stanby    - is stanby path
 * @param [in]     path_info    - FRR path info,
 *                                including output path ID, mpls label.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_delFrrPath(const UI32_T unit,
                  const CLX_L3_OUTPUT_TYPE_T type,
                  const UI32_T frr_grp,
                  const BOOL_T is_stanby,
                  const CLX_L3_FRR_PATH_INFO_T *path_info);

/**
 * @brief This API is used to set the linkup status for a specific state ID.
 *        The status of the state_id can imply the status of a specific port or
 *        path.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Egress type
 * @param [in]     state_id    - State ID for Fast Re-Route
 * @param [in]     link_up     - The linkup status for this state_id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_setFrrState(const UI32_T unit,
                   const CLX_L3_OUTPUT_TYPE_T type,
                   const UI32_T state_id,
                   const BOOL_T link_up);

/**
 * @brief This API is used to get the linkup status for a specific state ID.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     type           - Egress type
 * @param [in]     state_id       - State ID for the Fast Re-Route
 * @param [out]    ptr_link_up    - The setting status for the state_id
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getFrrState(const UI32_T unit,
                   const CLX_L3_OUTPUT_TYPE_T type,
                   const UI32_T state_id,
                   BOOL_T *ptr_link_up);

/**
 * @brief This API is used to add a IP subnet for PIM register.
 *
 * PIM register packet could forward to a specific multicast-id or to CPU.
 * Multicast-id and CPU cannot be set to the same IP subnet.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     ptr_info             - The information for pim register.
 * @return         CLX_E_OK             - Operate success.
 * @return         CLX_E_BAD_PARAMETER  - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_addSrcForPimReg(const UI32_T unit, const CLX_L3_PIM_REG_INFO_T *ptr_info);

/**
 * @brief This API is used to delete a IP subnet for PIM register.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     ptr_info             - The information for pim register, only need the keys:
 * vrf_id and src_ip.
 * @return         CLX_E_OK             - Operate success.
 * @return         CLX_E_BAD_PARAMETER  - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_delSrcForPimReg(const UI32_T unit, const CLX_L3_PIM_REG_INFO_T *ptr_info);

/**
 * @brief This API is used to get PIM register information by a specific VRF and IP subnet.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     ptr_info             - The information for pim register, only need the keys:
 * vrf_id and src_ip.
 * @return         CLX_E_OK             - Operate success.
 * @return         CLX_E_BAD_PARAMETER  - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getSrcForPimReg(const UI32_T unit, CLX_L3_PIM_REG_INFO_T *ptr_info);

/**
 * @brief This API is used to add a VRRP entry.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vrid    - Virtual router identifier (VRID)
 * @param [in]     bdid    - Bridge Domain ID
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Table full.
 */
CLX_ERROR_NO_T
clx_l3_addVrrp(const UI32_T unit, const UI32_T vrid, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief This API is used to delete a VRRP entry.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vrid    - Virtual router identifier (VRID)
 * @param [in]     bdid    - Bridge Domain ID
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
CLX_ERROR_NO_T
clx_l3_delVrrp(const UI32_T unit, const UI32_T vrid, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief This API is used to check VRRP entry exist or not.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     vrid    - Virtual router identifier (VRID)
 * @param [in]     bdid    - Bridge Domain ID
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
CLX_ERROR_NO_T
clx_l3_getVrrp(const UI32_T unit, const UI32_T vrid, const CLX_BRIDGE_DOMAIN_T bdid);

/**
 * @brief This API is used to enable FDL for the ECMP group.
 *
 * support_chip CL8500
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ecmp_grp_id     - ECMP group ID
 * @param [in]     ptr_fdl_info    - property of FDL
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_addFdlEcmpGroup(const UI32_T unit,
                       const UI32_T ecmp_grp_id,
                       const CLX_FDL_INFO_T *ptr_fdl_info);

/**
 * @brief This API is used to disable FDL for the ECMP group.
 *
 * support_chip CL8500
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     ecmp_grp_id    - ECMP group ID
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_delFdlEcmpGroup(const UI32_T unit, const UI32_T ecmp_grp_id);

/**
 * @brief This API is used to get the property of FDL for the ECMP group.
 *
 * support_chip CL8500
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ecmp_grp_id     - ECMP group ID
 * @param [out]    ptr_fdl_info    - property of FDL
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_l3_getFdlEcmpGroup(const UI32_T unit, const UI32_T ecmp_grp_id, CLX_FDL_INFO_T *ptr_fdl_info);

/**
 * @brief This API is used to add bulk L3 Route entries.
 *
 * The detailed information of route refers to structure of CLX_L3_ROUTE_INFO_T.
 * If the route entry exists, some attributes of this entry will be changed.
 * The key of entry cannot be changed.
 *
 * support_chip CL8500, CL8600
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     mode                   - Bulk Mode, no use now because wirte hw only one times
 * @param [in]     route_cnt              - Route number
 * @param [in]     ptr_route_info_list    - Route information array, including network address, VRF
 * ID, the output path ID and etc.  Key is the network address and VRF ID.
 * @param [out]    ptr_rc_list            - Pointer of a return code array
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, the entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3_addBulkRoute(const UI32_T unit,
                    const CLX_BULK_OP_MODE_T mode,
                    const UI32_T route_cnt,
                    const CLX_L3_ROUTE_INFO_T *ptr_route_info_list,
                    CLX_ERROR_NO_T *ptr_rc_list);

/**
 * @brief This API is used to delete bulk L3 Route entries.
 *
 * IP network address and VRF ID need to be filled into ptr_route_info.
 *
 * support_chip CL8500, CL8600
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     mode                   - Bulk Mode, no use now because wirte hw only one times
 * @param [in]     route_cnt              - Route number
 * @param [in]     ptr_route_info_list    - Route information array, IP network address and VRF ID
 * must be input.
 * @param [out]    ptr_rc_list            - Pointer of a return code array
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been deleted
 */
CLX_ERROR_NO_T
clx_l3_delBulkRoute(const UI32_T unit,
                    const CLX_BULK_OP_MODE_T mode,
                    const UI32_T route_cnt,
                    const CLX_L3_ROUTE_INFO_T *ptr_route_info_list,
                    CLX_ERROR_NO_T *ptr_rc_list);

/**
 * @brief This API is used to get bulk L3 Route entries.
 *
 * User only needs to fill in IP network address and VRF ID.
 *
 * support_chip CL8500, CL8600
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     mode                   - Bulk Mode
 * @param [in]     route_cnt              - Route number
 * @param [in]     ptr_route_info_list    - Route information array, only including key: IP network
 * address, VRF ID
 * @param [out]    ptr_route_info_list    - Route information array, including IP network address,
 * VRF ID, the output path ID and so on.
 * @param [out]    ptr_rc_list            - Pointer of a return code array
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created
 */
CLX_ERROR_NO_T
clx_l3_getBulkRoute(const UI32_T unit,
                    const CLX_BULK_OP_MODE_T mode,
                    const UI32_T route_cnt,
                    CLX_L3_ROUTE_INFO_T *ptr_route_info_list,
                    CLX_ERROR_NO_T *ptr_rc_list);

#endif