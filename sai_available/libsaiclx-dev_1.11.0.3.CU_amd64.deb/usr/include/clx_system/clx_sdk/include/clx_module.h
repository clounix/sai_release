/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_module.h
 * PURPOSE:
 *      Define the software modules in CLX SDK.
 * NOTES:
 */

#ifndef CLX_MODULE_H
#define CLX_MODULE_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define CLX_MODULE_MAX_LENGTH_OF_NAME (8)
#define MODULE_LIST(maker)                                                                         \
    maker(IFMAP, ifmap) maker(VLAN, vlan) maker(PORT, port) maker(IFMON, ifmon) maker(L2, l2)      \
        maker(STP, stp) maker(LAG, lag) maker(MIR, mir) maker(L3, l3) maker(L3T, l3t)              \
            maker(SWC, swc) maker(QOS, qos) maker(METER, meter) maker(PKT, pkt) maker(ACL, acl)    \
                maker(STAT, stat) maker(SEC, sec) maker(SFLOW, sflow) maker(TM, tm) maker(VM, vm)  \
                    maker(FCOE, fcoe) maker(TRILL, trill) maker(SDN, sdn) maker(DIAG, diag)        \
                        maker(CLI, cli) maker(LOG, log) maker(OSAL, osal) maker(DCC, dcc)          \
                            maker(AML, aml) maker(HAL, hal) maker(PHY, phy) maker(INIT, init)      \
                                maker(CMLIB, cmlib) maker(NV, nv) maker(MPLS, mpls)                \
                                    maker(SFC, sfc) maker(CHIP, chip) maker(DCC_CH, dcc - channel) \
                                        maker(MISC, misc) maker(STK, stacking) maker(PPPOE, pppoe) \
                                            maker(DTEL, dtel) maker(TELM, telm) maker(SRV6, srv6)  \
                                                maker(ECC, ecc) maker(ECPU, ecpu) maker(TOD, tod)  \
                                                    maker(INTR, intr) maker(ALL, all)              \
                                                        maker(LAST, )
#define MODULE_ENUM(module, module_name)   CLX_MODULE_##module,
#define MODULE_STRING(module, module_name) #module_name,

/* DATA TYPE DECLARATIONS
 */
typedef enum CLX_MODULE_E { MODULE_LIST(MODULE_ENUM) } CLX_MODULE_T;

#define CLX_MODULE_NUMER_OF_MODULES (CLX_MODULE_LAST)

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief This API returns the module name by given module ID. All modules could
 *        invoke this API.
 *
 * Prepare memory to receive this output. The maximum length of module name is
 * CLX_MODULE_MAX_LENGTH_OF_NAME.
 * support_chip all
 *
 * @param [in]     module_id    -  Module ID, range from 0 to (CLX_MODULE_LAST - 1)
 * @return         C8_T *       - Pointer of output module name.
 */
const C8_T *
clx_module_getModuleName(const UI32_T module_id);
#endif /* CLX_MODULE_H */
