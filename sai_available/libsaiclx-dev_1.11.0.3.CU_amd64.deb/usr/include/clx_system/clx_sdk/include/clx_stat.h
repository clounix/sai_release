/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_stat.h
 * PURPOSE:
 *      Define the declartion for Statistics module in CLX SDK.
 * NOTES:
 *
 */

#ifndef CLX_STAT_H
#define CLX_STAT_H

#include <clx_types.h>
#include <clx_error.h>
#include <clx_init.h>
#include <clx_l3.h>
#include <clx_tm.h>
#include <clx_pkt.h>

#define CLX_STAT_CFG_TX_DROP_FILTER (1U << 0)
#define CLX_STAT_INVALID_CNT_ID     (0xFFFFFFFF)

typedef enum {
    /* RFC2863 */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_OCTETS = 0,         /* ifInOctets */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_UCAST_PKTS,         /* ifInUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_NUCAST_PKTS,        /* ifInNUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_DISCARDS,           /* ifInDiscards */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_ERRORS,             /* ifInErrors */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_UNKNOWN_PROTOS,     /* ifInUnknownProtos, not support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_OCTETS,            /* ifOutOctets */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_UCAST_PKTS,        /* ifOutUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_NUCAST_PKTS,       /* ifOutNUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_DISCARDS,          /* ifOutDiscards */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_ERRORS,            /* ifOutErrors */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_MULTICAST_PKTS,     /* ifInMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_IN_BROADCAST_PKTS,     /* ifInBroadcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_MULTICAST_PKTS,    /* ifOutMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_OUT_BROADCAST_PKTS,    /* ifOutBroadcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_OCTETS,          /* ifHCInOctets */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_UCAST_PKTS,      /* ifHCInUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_MULTICAST_PKTS,  /* ifHCInMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_IN_BROADCAST_PKTS,  /* ifHCInBroadcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_OCTETS,         /* ifHCOutOctets */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_UCAST_PKTS,     /* ifHCOutUcastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_MULTICAST_PKTS, /* ifHCOutMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_IF_HC_OUT_BROADCAST_PKTS, /* ifHCOutBroadcastPkts */
                                                     /* end */

                                                     /* RFC2819 */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_DROP_EVENTS, /* etherStatsDropEvents, not support on CL8600
                                                     */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_OCTETS,      /* etherStatsOctets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS,        /* etherStatsPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_BROADCAST_PKTS,   /* etherStatsBroadcastPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_MULTICAST_PKTS,   /* etherStatsMulticastPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_CRC_ALIGN_ERRORS, /* etherStatsCRCAlignErrors, not support on
                                                            CL8600 */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_UNDERSIZE_PKTS,   /* etherStatsUndersizePkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_OVERSIZE_PKTS,    /* etherStatsOversizePkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_FRAGMENTS,        /* etherStatsFragments */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_JABBERS,          /* etherStatsJabbers */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_COLLISIONS, /* etherStatsCollisions, not support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_64_OCTETS,           /* etherStatsPkts64Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_65_TO_127_OCTETS,    /* etherStatsPkts65to127Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_128_TO_255_OCTETS,   /* etherStatsPkts128to255Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_256_TO_511_OCTETS,   /* etherStatsPkts256to511Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_512_TO_1023_OCTETS,  /* etherStatsPkts512to1023Octets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_PKTS_1024_TO_1518_OCTETS, /* etherStatsPkts1024to1518Octets
                                                                  */
                                                                 /* end */

                                                                 /* RFC3635 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_ALIGNMENT_ERRORS, /* dot3StatsAlignmentErrors, not support on
                                                           CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_FCS_ERRORS,       /* dot3StatsFCSErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SINGLE_COLLISION_FRAMES,   /* dot3StatsSingleCollisionFrames,
                                                                    not support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_MULTIPLE_COLLISION_FRAMES, /* dot3StatsMultipleCollisionFrames,
                                                                    not support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SQE_TEST_ERRORS, /* dot3StatsSQETestErrors, not support on
                                                          CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_DEFERRED_TRANSMISSIONS, /* dot3StatsDeferredTransmissions, not
                                                                 support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_LATE_COLLISIONS, /* dot3StatsLateCollisions, not support on
                                                          CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_EXCESSIVE_COLLISIONS, /* dot3StatsExcessiveCollisions, not
                                                               support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS, /* dot3StatsInternalMacTransmitErrors
                                                                     */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_CARRIER_SENSE_ERRORS, /* dot3StatsCarrierSenseErrors, not
                                                               support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_FRAME_TOO_LONGS,      /* dot3StatsFrameTooLongs */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_RECEIVE_ERRORS, /* dot3StatsInternalMacReceiveErrors
                                                                    */
    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_SYMBOL_ERRORS, /* dot3StatsSymbolErrors, not support on CL8600
                                                      */

    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_ALIGNMENT_ERRORS, /* dot3HCStatsAlignmentErrors, not
                                                              support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_FCS_ERRORS,       /* dot3HCStatsFCSErrors */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_INTERNAL_MAC_TRANSMIT_ERRORS, /* dot3HCStatsInternalMacTransmitErrors
                                                                        */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_FRAME_TOO_LONGS,             /* dot3HCStatsFrameTooLongs */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_INTERNAL_MAC_RECEIVE_ERRORS, /* dot3HCStatsInternalMacReceiveErrors
                                                                       */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_STATS_SYMBOL_ERRORS, /* dot3HCStatsSymbolErrors, not support on
                                                           CL8600 */

    CLX_STAT_PORT_CNT_TYPE_DOT3_CONTROL_IN_UNKNOWN_OPCODES,    /* dot3ControlInUnknownOpcodes, not
                                                                  support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_CONTROL_IN_UNKNOWN_OPCODES, /* dot3HCControlInUnknownOpcodes, not
                                                                  support on CL8600 */

    CLX_STAT_PORT_CNT_TYPE_DOT3_IN_PAUSE_FRAMES,               /* dot3InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_DOT3_OUT_PAUSE_FRAMES,              /* dot3OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_IN_PAUSE_FRAMES,            /* dot3HCInPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_DOT3_HC_OUT_PAUSE_FRAMES,           /* dot3HCOutPauseFrames */
                                                               /* end */

                                                               /* RFC3273, not support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DROP_EVENTS,      /* mediaIndependentDropEvents */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DROPPED_FRAMES,   /* mediaIndependentDroppedFrames */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_PKTS,          /* mediaIndependentInPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OVERFLOW_PKTS, /* mediaIndependentInOverflowPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_PKTS, /* mediaIndependentInHighCapacityPkts
                                                                     */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_PKTS,              /* mediaIndependentOutPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OVERFLOW_PKTS, /* mediaIndependentOutOverflowPkts
                                                                 */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_PKTS, /* mediaIndependentOutHighCapacityPkts
                                                                      */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OCTETS,              /* mediaIndependentInOctets */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_OVERFLOW_OCTETS, /* mediaIndependentInOverflowOctets
                                                                  */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_OCTETS, /* mediaIndependentInHighCapacityOctets
                                                                       */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OCTETS,          /* mediaIndependentOutOctets */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_OVERFLOW_OCTETS, /* mediaIndependentOutOverflowOctets
                                                                   */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_OCTETS, /* mediaIndependentOutHighCapacityOctets
                                                                        */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_PKTS, /* mediaIndependentInNUCastPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_OVERFLOW_PKTS, /* mediaIndependentInNUCastOverflowPkts
                                                                       */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_NUCAST_HIGH_CAPACITY_PKTS, /* mediaIndependentInNUCastHighCapacityPkts
                                                                            */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_PKTS, /* mediaIndependentOutNUCastPkts */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_OVERFLOW_PKTS, /* mediaIndependentOutNUCastOverflowPkts
                                                                        */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_NUCAST_HIGH_CAPACITY_PKTS, /* mediaIndependentOutNUCastHighCapacityPkts
                                                                             */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_IN_ERRORS,      /* mediaIndependentInErrors */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_OUT_ERRORS,     /* mediaIndependentOutErrors */
    CLX_STAT_PORT_CNT_TYPE_MEDIA_INDEPENDENT_DUPLEX_CHANGES, /* mediaIndependentDuplexChanges */

    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS, /* etherStatsHighCapacityOverflowPkts
                                                                     */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS,          /* etherStatsHighCapacityPkts */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_OCTETS, /* etherStatsHighCapacityOverflowOctets
                                                                       */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OCTETS, /* etherStatsHighCapacityOctets */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_64_OCTETS, /* etherStatsHighCapacityOverflowPkts64Octets
                                                                               */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_64_OCTETS, /* etherStatsHighCapacityPkts64Octets
                                                                      */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_65_TO_127_OCTETS, /* etherStatsHighCapacityOverflowPkts65to127Octets
                                                                                      */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_65_TO_127_OCTETS, /* etherStatsHighCapacityPkts65to127Octets
                                                                             */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_128_TO_255_OCTETS, /* etherStatsHighCapacityOverflowPkts128to255Octets
                                                                                       */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_128_TO_255_OCTETS, /* etherStatsHighCapacityPkts128to255Octets
                                                                              */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_256_TO_511_OCTETS, /* etherStatsHighCapacityOverflowPkts256to511Octets
                                                                                       */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_256_TO_511_OCTETS, /* etherStatsHighCapacityPkts256to511Octets
                                                                              */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_512_TO_1023_OCTETS, /* etherStatsHighCapacityOverflowPkts512to1023Octets
                                                                                        */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_512_TO_1023_OCTETS, /* etherStatsHighCapacityPkts512to1023Octets
                                                                               */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_1024_TO_1518_OCTETS, /* etherStatsHighCapacityOverflowPkts1024to1518Octets
                                                                                         */
    CLX_STAT_PORT_CNT_TYPE_ETHER_STATS_HIGH_CAPACITY_PKTS_1024_TO_1518_OCTETS, /* etherStatsHighCapacityPkts1024to1518Octets
                                                                                */
                                                                               /* end */

    /* RFC4836, not support on CL8600 */
    CLX_STAT_PORT_CNT_TYPE_RP_MAU_MEDIA_AVAILABLE_STATE_EXITS, /* rpMauMediaAvailableStateExits */
    CLX_STAT_PORT_CNT_TYPE_RP_MAU_FALSE_CARRIERS,              /* rpMauFalseCarriers */

    CLX_STAT_PORT_CNT_TYPE_IF_MAU_MEDIA_AVAILABLE_STATE_EXITS, /* ifMauMediaAvailableStateExits */
    CLX_STAT_PORT_CNT_TYPE_IF_MAU_FALSE_CARRIERS,              /* ifMauFalseCarriers */
    CLX_STAT_PORT_CNT_TYPE_IF_MAU_HC_FALSE_CARRIERS,           /* ifMauHCFalseCarriers */
                                                               /* end */

    /* IEEE P802.1Q(TM) Priority-based Flow Control MIB */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_REQUESTS,               /* ieee8021PfcRequests */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_INDICATIONS,            /* ieee8021PfcIndications */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E0_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE0InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E0_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE0OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E1_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE1InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E1_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE1OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E2_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE2InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E2_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE2OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E3_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE3InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E3_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE3OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E4_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE4InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E4_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE4OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E5_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE5InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E5_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE5OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E6_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE6InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E6_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE6OutPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E7_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE7InPauseFrames */
    CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_HC_E7_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE7OutPauseFrames */
                                                                 /* end */

    CLX_STAT_PORT_CNT_TYPE_RX_FRAMES_RECEIVED_OK,                /* The total count of
                                                                  * CLX_STAT_PORT_CNT_TYPE_IF_IN_UCAST_PKTS,
                                                                  *                    CLX_STAT_PORT_CNT_TYPE_IF_IN_MULTICAST_PKTS,
                                                                  *                    CLX_STAT_PORT_CNT_TYPE_IF_IN_BROADCAST_PKTS.
                                                                  */
    CLX_STAT_PORT_CNT_TYPE_RX_PAUSE_MAC_CTRL_FRAMES_RECEIVED,    /* The total count of
                                                                  * CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_INDICATIONS,
                                                                  *                    CLX_STAT_PORT_CNT_TYPE_DOT3_IN_PAUSE_FRAMES
                                                                  */
    CLX_STAT_PORT_CNT_TYPE_RX_MAC_CONTROL_FRAMES_RECEIVED,       /* The same as
                                                                    CLX_STAT_PORT_CNT_TYPE_IF_IN_UNKNOWN_PROTOS,
                                                                    not support on CL8600. */
    CLX_STAT_PORT_CNT_TYPE_RX_IN_RANGE_LENGTH_ERROES, /* Rx length error, not support on CL8600. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_1519_TO_2560_OCTETS,  /* Count if pkt length is in the range
                                                            between 1519 and 2560. Dawn only. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_2561_TO_MAX_OCTETS,   /* Count if pkt length is larger then 2561.
                                                            Dawn only. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_1519_TO_2047_OCTETS,  /* Count if pkt length is in the range
                                                            between 1519 and 2047. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_2048_TO_4095_OCTETS,  /* Count if pkt length is in the range
                                                            between 2048 and 4095. Not support on
                                                            dawn. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_4096_TO_9216_OCTETS,  /* Count if pkt length is in the range
                                                            between 4096 and 9216. Not support on
                                                            CL8600. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_9217_TO_16383_OCTETS, /* Count if pkt length is in the range
                                                            between 9217 and 16383. Not support on
                                                            CL8600. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_4096_TO_8191_OCTETS,  /* Count if pkt length is in the range
                                                            between 4096 and 8191. CL8600 only. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_8192_TO_9215_OCTETS,  /* Count if pkt length is in the range
                                                            between 8192 and 9215. CL8600 only. */
    CLX_STAT_PORT_CNT_TYPE_RX_PKTS_9216_TO_MAX_OCTETS,   /* Count if pkt length is larger then 9216.
                                                            CL8600 only. */
    CLX_STAT_PORT_CNT_TYPE_TX_FRAMES_TRANSMITTED_OK,     /* The total count of
                                                          * CLX_STAT_PORT_CNT_TYPE_IF_OUT_UCAST_PKTS,
                                                          *                     CLX_STAT_PORT_CNT_TYPE_IF_OUT_MULTICAST_PKTS,
                                                          *                     CLX_STAT_PORT_CNT_TYPE_IF_OUT_BROADCAST_PKTS
                                                          *
                                                          */
    CLX_STAT_PORT_CNT_TYPE_TX_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED, /* The total count of
                                                                  * CLX_STAT_PORT_CNT_TYPE_IEEE_8021_PFC_REQUESTS,
                                                                  *                     CLX_STAT_PORT_CNT_TYPE_DOT3_OUT_PAUSE_FRAMES
                                                                  */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_CRC_ERR,                      /* The same as
                                                                    CLX_STAT_PORT_CNT_TYPE_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS
                                                                  */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_64_OCTETS,         /* Count if pkt length is less then 64.*/
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_65_TO_127_OCTETS,  /* Count if pkt length is in the range between
                                                         65 and 127. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_128_TO_255_OCTETS, /* Count if pkt length is in the range between
                                                         128 and 255. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_256_TO_511_OCTETS, /* Count if pkt length is in the range between
                                                         256 and 511. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_512_TO_1023_OCTETS,   /* Count if pkt length is in the range
                                                            between 512 and 1023. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1024_TO_1518_OCTETS,  /* Count if pkt length is in the range
                                                            between 1024 and 1518. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1519_TO_2560_OCTETS,  /* Count if pkt length is in the range
                                                            between 1519 and 2560. Dawn only */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_2561_TO_MAX_OCTETS,   /* Count if pkt length is larger then 2561.
                                                            Dawn only */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_1519_TO_2047_OCTETS,  /* Count if pkt length is in the range
                                                            between 1519 and 2047. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_2048_TO_4095_OCTETS,  /* Count if pkt length is in the range
                                                            between 2048 and 4095. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_4096_TO_9216_OCTETS,  /* Count if pkt length is in the range
                                                            between 4096 and 9216. Not support on
                                                            CL8600. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_9217_TO_16383_OCTETS, /* Count if pkt length is in the range
                                                            between 9217 and 16383. Not support on
                                                            CL8600. */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_4096_TO_8191_OCTETS,  /* Count if pkt length is in the range
                                                            between 4096 and 8191. CL8600 only */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_8192_TO_9215_OCTETS,  /* Count if pkt length is in the range
                                                            between 8192 and 9215. CL8600 only */
    CLX_STAT_PORT_CNT_TYPE_TX_PKTS_GT_9216_OCTETS, /* Count if pkt length is greater than 9216.
                                                      CL8600 only */
    CLX_STAT_PORT_CNT_TYPE_DROP_CNT_RECEIVE,       /* Dawn only */
    CLX_STAT_PORT_CNT_TYPE_DROP_CNT_TRANSMIT,      /* Dawn only */

                                                   /* Drop counter, not support on CL8600.*/
    CLX_STAT_PORT_CNT_TYPE_TX_OVERSIZE_PKTS, /* Tx oversize pkt */
    CLX_STAT_PORT_CNT_TYPE_L3_DISCARDS, /* The same as CLX_STAT_PORT_CNT_TYPE_INGRESS_L3_DISCARDS */
    CLX_STAT_PORT_CNT_TYPE_INGRESS_L3_DISCARDS,          /* Ingress l3 discard packet */
    CLX_STAT_PORT_CNT_TYPE_EGRESS_L3_DISCARDS,           /* Egress l3 discard packet */
    CLX_STAT_PORT_CNT_TYPE_L3_BLACKHOLE_DISCARDS,        /* L3 blackhole discard packet */
    CLX_STAT_PORT_CNT_TYPE_INGRESS_PARITY_DISCARDS,      /* Ingress parity discard packet */
    CLX_STAT_PORT_CNT_TYPE_EGRESS_NON_QUEUE_DISCARDS,    /* Egress non-queue discard packet */
    CLX_STAT_PORT_CNT_TYPE_EGRESS_INVALID_VLAN_DISCARDS, /* Egress invalid vlan discard packet */
    CLX_STAT_PORT_CNT_TYPE_INGRESS_L2_MTU_DISCARDS,      /* Ingress L2 MTU discard packet */
    CLX_STAT_PORT_CNT_TYPE_BUFFER_DISCARDS,              /* Buffer discard pkts */
    CLX_STAT_PORT_CNT_TYPE_INGRESS_NON_QUEUE_DISCARDS,   /* Ingress non-queue discard packet */
                                                         /* end */

                                                         /* CL8600 only */
    CLX_STAT_PORT_CNT_TYPE_IN_DROP_NON_IP_PKTS, /* The total number of drop non-IP packets received
                                                 */
    CLX_STAT_PORT_CNT_TYPE_IN_DROP_NON_IP_OCTETS, /* The total number of drop non-IP octets received
                                                   */
    CLX_STAT_PORT_CNT_TYPE_IN_DROP_IPV4_PKTS,   /* The total number of drop IPv4 packets received */
    CLX_STAT_PORT_CNT_TYPE_IN_DROP_IPV4_OCTETS, /* The total number of drop IPv4 octets  received */
    CLX_STAT_PORT_CNT_TYPE_IN_DROP_IPV6_PKTS,   /* The total number of drop IPv6 packets received */
    CLX_STAT_PORT_CNT_TYPE_IN_DROP_IPV6_OCTETS, /* The total number of drop IPv6 octets received */
    CLX_STAT_PORT_CNT_TYPE_IN_PKTS,             /* The total number of good packets received */
    CLX_STAT_PORT_CNT_TYPE_IN_OCTETS,           /* The total number of good octets received */
    CLX_STAT_PORT_CNT_TYPE_IN_IPV4_PKTS,        /* The total number of good IPv4 packets received */
    CLX_STAT_PORT_CNT_TYPE_IN_IPV4_OCTETS,      /* The total number of good IPv4 octets received */
    CLX_STAT_PORT_CNT_TYPE_IN_IPV6_PKTS,        /* The total number of good IPv6 packets received */
    CLX_STAT_PORT_CNT_TYPE_IN_IPV6_OCTETS,      /* The total number of good IPv6 octets received */
    CLX_STAT_PORT_CNT_TYPE_OUT_DROP_NON_IP_PKTS,   /* The total number of drop non-IP packets
                                                      transmitted */
    CLX_STAT_PORT_CNT_TYPE_OUT_DROP_NON_IP_OCTETS, /* The total number of drop non-IP octets
                                                      transmitted */
    CLX_STAT_PORT_CNT_TYPE_OUT_DROP_IPV4_PKTS, /* The total number of drop IPv4 packets transmitted
                                                */
    CLX_STAT_PORT_CNT_TYPE_OUT_DROP_IPV4_OCTETS, /* The total number of drop IPv4 octets transmitted
                                                  */
    CLX_STAT_PORT_CNT_TYPE_OUT_DROP_IPV6_PKTS, /* The total number of drop IPv6 packets transmitted
                                                */
    CLX_STAT_PORT_CNT_TYPE_OUT_DROP_IPV6_OCTETS, /* The total number of drop IPv6 octets transmitted
                                                  */
    CLX_STAT_PORT_CNT_TYPE_OUT_PKTS,             /* The total number of good packets transmitted */
    CLX_STAT_PORT_CNT_TYPE_OUT_OCTETS,           /* The total number of good octets transmitted */
    CLX_STAT_PORT_CNT_TYPE_OUT_IPV4_PKTS,   /* The total number of good IPv4 packets transmitted
                                             */
    CLX_STAT_PORT_CNT_TYPE_OUT_IPV4_OCTETS, /* The total number of good IPv4 octets transmitted
                                             */
    CLX_STAT_PORT_CNT_TYPE_OUT_IPV6_PKTS,   /* The total number of good IPv6 packets transmitted
                                             */
    CLX_STAT_PORT_CNT_TYPE_OUT_IPV6_OCTETS, /* The total number of good IPv6 octets transmitted
                                             */
                                            /* end */
    CLX_STAT_PORT_CNT_TYPE_LAST
} CLX_STAT_PORT_CNT_TYPE_T;

typedef enum {
    CLX_STAT_TM_CNT_TYPE_PORT_DROP_RECEIVE = 0, /* TM port rx drop counter */
    CLX_STAT_TM_CNT_TYPE_PORT_DROP_TRANSMIT,    /* TM port tx drop counter */
    CLX_STAT_TM_CNT_TYPE_PORT_CNT_RECEIVE,      /* TM port rx counter */
    CLX_STAT_TM_CNT_TYPE_PORT_CNT_TRANSMIT,     /* TM port tx counter */
    CLX_STAT_TM_CNT_TYPE_PORT_ECN_TRANSMIT,     /* TM port tx ECN counter */
    CLX_STAT_TM_CNT_TYPE_QUEUE_CNT,             /* TM (port , queue) counter */
    CLX_STAT_TM_CNT_TYPE_QUEUE_DROP_IGR_BUF, /* TM (port , queue) drop counter due to igr buf full
                                              */
    CLX_STAT_TM_CNT_TYPE_QUEUE_DROP_EGR_BUF, /* TM (port , queue) drop counter due to egr buf full
                                              */

    CLX_STAT_TM_CNT_TYPE_QUEUE_ECN_EGR_BUF,  /* TM (port , queue) ECN marked counter due to egr buf
                                              * full
                                              */

    CLX_STAT_TM_CNT_TYPE_LAST
} CLX_STAT_TM_CNT_TYPE_T;

typedef struct CLX_STAT_TM_CNT_S {
    UI64_T pkt_cnt;  /* The packet counter */
    UI64_T byte_cnt; /* The packet byte counter */
} CLX_STAT_TM_CNT_T;

typedef CLX_STAT_TM_CNT_T CLX_STAT_TM_QUEUE_CNT_T;

typedef struct CLX_STAT_DIST_CNT_S {
    UI64_T total_byte_cnt;            /* The total number of packet octets (including
                                       * bad/dropped packets, broadcast packets, and
                                       * multicast packets) received
                                       */
    UI64_T total_pkt_cnt;             /* The total number of packets (including
                                       * bad/dropped packets, broadcast packets, and
                                       * multicast packets) received
                                       */
    UI64_T good_pkt_cnt_bc;           /* The total number of good packets received and
                                       * directed to the broadcast address
                                       */
    UI64_T good_pkt_cnt_mc;           /* The total number of good packets received and
                                       * directed to the multicast address
                                       */
    UI64_T pkt_cnt_len_less_equal_64; /* pktlen <= 64Bytes */
    UI64_T pkt_cnt_len_65_to_127;     /* 65 Bytes <= pktlen <= 127 Bytes */
    UI64_T pkt_cnt_len_128_to_255;    /* 128 Bytes <= pktlen <= 255 Bytes */
    UI64_T pkt_cnt_len_256_to_511;    /* 256 Bytes <= pktlen <= 511 Bytes */
    UI64_T pkt_cnt_len_512_to_1023;   /* 512 Bytes <= pktlen <= 1023 Bytes */
    UI64_T pkt_cnt_len_1024_to_1518;  /* 1024 Bytes <= pktlen <= 1518 Bytes */
    UI64_T pkt_cnt_len_1519_to_2560;  /* 1519 Bytes <= pktlen <= 2560 Bytes used in CL8360 */
    UI64_T pkt_cnt_len_2561_to_9216;  /* 2561 Bytes <= pktlen <= 9216 Bytes used in CL8360 */
    UI64_T pkt_cnt_len_1519_to_2047; /* 1519 Bytes <= pktlen <= 2047 Bytes. Not support in CL8360 */
    UI64_T pkt_cnt_len_2048_to_9216; /* 2048 Bytes <= pktlen <= 9216 Bytes. Not support in CL8360 */
} CLX_STAT_DIST_CNT_T;

#define CLX_STAT_CNT_NUM (6)

typedef enum {
    CLX_STAT_CNT_MODE_SINGLE = 0, /* Regular counter single mode */
    CLX_STAT_CNT_MODE_DOUBLE,     /* Regular counter double mode */
    CLX_STAT_CNT_MODE_TRIPLE,     /* Regular counter triple mode */
    CLX_STAT_CNT_MODE_SIXFOLD,    /* Regular counter sixfold mode */
    CLX_STAT_CNT_MODE_LAST
} CLX_STAT_CNT_MODE_T;

typedef struct CLX_STAT_CNT_CFG_S {
    CLX_STAT_CNT_MODE_T mode;
#define CLX_STAT_CNT_FLAGS_FORWARD      (1U << 0) /* Count Forward */
#define CLX_STAT_CNT_FLAGS_DROP         (1U << 1) /* Count Drop */
#define CLX_STAT_CNT_FLAGS_BYTE         (1U << 2) /* Count Byte */
#define CLX_STAT_CNT_FLAGS_COLOR_RED    (1U << 3) /* Count Red */
#define CLX_STAT_CNT_FLAGS_COLOR_YELLOW (1U << 4) /* Count Yellow */
#define CLX_STAT_CNT_FLAGS_COLOR_GREEN  (1U << 5) /* Count Green */
#define CLX_STAT_CNT_FLAGS_COLOR_ALL              /* Count All colors */ \
    (CLX_STAT_CNT_FLAGS_COLOR_GREEN | CLX_STAT_CNT_FLAGS_COLOR_YELLOW |  \
     CLX_STAT_CNT_FLAGS_COLOR_RED)
    UI32_T flags[CLX_STAT_CNT_NUM]; /* Counter configuration */
} CLX_STAT_CNT_CFG_T;

typedef struct CLX_STAT_CNT_S {
    UI64_T cnt[CLX_STAT_CNT_NUM]; /* The counter. Counting is based on the configuration */
} CLX_STAT_CNT_T;

typedef enum {
    CLX_STAT_CNT_GROUP_MODE_SERVICE = 0, /* Group for service counter */
    CLX_STAT_CNT_GROUP_MODE_FLOW,        /* Group for cia */
    CLX_STAT_CNT_GROUP_MODE_LAST
} CLX_STAT_CNT_GROUP_MODE_T;

typedef enum {
    CLX_STAT_RATE_RX_BYTE_L1, /* Bps */
    CLX_STAT_RATE_RX_BYTE,    /* Bps */
    CLX_STAT_RATE_RX_PKT,     /* Pps */
    CLX_STAT_RATE_TX_BYTE_L1, /* Bps */
    CLX_STAT_RATE_TX_BYTE,    /* Bps */
    CLX_STAT_RATE_TX_PKT,     /* Pps */
    CLX_STAT_RATE_IF_OUT_DISCARDS,
    CLX_STAT_RATE_TM_START,
    CLX_STAT_RATE_TX_DROP_EGR_BUF = CLX_STAT_RATE_TM_START,
    CLX_STAT_RATE_TYPE_LAST
} CLX_STAT_RATE_TYPE_T;

/**
 * @brief This API is used to get port counter by physical port.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port
 * @param [in]     type       - The type of counter
 * @param [out]    ptr_cnt    - Counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_getPortCnt(const UI32_T unit,
                    const UI32_T port,
                    const CLX_STAT_PORT_CNT_TYPE_T type,
                    UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port counter by physical port.
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Physical port
 * @param [in]     type    - The type of counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_clearPortCnt(const UI32_T unit, const UI32_T port, const CLX_STAT_PORT_CNT_TYPE_T type);

/**
 * @brief This API is used to get port counter list by physical port.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     ptr_type    - The type list of counter
 * @param [in]     list_cnt    - The number of the ptr_type and ptr_cnt
 * @param [out]    ptr_cnt     - Counter list
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_getPortCntList(const UI32_T unit,
                        const UI32_T port,
                        const CLX_STAT_PORT_CNT_TYPE_T *ptr_type,
                        const UI32_T list_cnt,
                        UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear port counter list by physical port.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     ptr_type    - The type list of counter
 * @param [in]     list_cnt    - The number of the ptr_type.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_clearPortCntList(const UI32_T unit,
                          const UI32_T port,
                          const CLX_STAT_PORT_CNT_TYPE_T *ptr_type,
                          const UI32_T list_cnt);

/**
 * @brief This API is used to set port ID and TM queue counter used for port.
 *
 * support_chip CL8500
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - TM port ID
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - Allocate memory failed
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
clx_stat_setTmQueueCntForPort(const UI32_T unit, const UI32_T port);

/**
 * @brief This API is used to get port ID and TM queue counter used for port
 *
 * support_chip CL8500
 *
 * @param [in]     unit        - Device unit number
 * @param [out]    ptr_port    - TM port ID
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_getTmQueueCntForPort(const UI32_T unit, UI32_T *ptr_port);

/**
 * @brief This API is used to set CPU queue ID and TM queue counter used for CPU.
 *
 * support_chip CL8500
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     handler        - The handler of TM queue
 * @param [in]     cpu_handler    - The handler of CPU queue
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - Allocate memory failed
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
clx_stat_setTmQueueCntForCpu(const UI32_T unit,
                             const CLX_TM_HANDLER_T handler,
                             const CLX_TM_HANDLER_T cpu_handler);

/**
 * @brief This API is used to get CPU queue ID and TM queue counter used for CPU.
 *
 * support_chip CL8500
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     handler            - The handler of TM queue
 * @param [out]    ptr_cpu_handler    - The handler of CPU queue
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_getTmQueueCntForCpu(const UI32_T unit,
                             const CLX_TM_HANDLER_T handler,
                             CLX_TM_HANDLER_T *ptr_cpu_handler);

/**
 * @brief This API is used to get TM counter by TM queue.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     handler    - The handler of TM queue
 * @param [out]    ptr_cnt    - Queue counter
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_getTmQueueCnt(const UI32_T unit,
                       const CLX_TM_HANDLER_T handler,
                       CLX_STAT_TM_QUEUE_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear TM counter by TM queue.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     handler    - The handler of TM queue
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - Allocate memory failed
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
clx_stat_clearTmQueueCnt(const UI32_T unit, const CLX_TM_HANDLER_T handler);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @param [out]    ptr_cnt    - Counter value
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
clx_stat_getTmCnt(const UI32_T unit,
                  const UI32_T port,
                  const CLX_TM_HANDLER_T handler,
                  const CLX_STAT_TM_CNT_TYPE_T type,
                  CLX_STAT_TM_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     handler    - The handler of TM queue
 * @param [in]     type       - The TM counter type
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed
 */
CLX_ERROR_NO_T
clx_stat_clearTmCnt(const UI32_T unit,
                    const UI32_T port,
                    const CLX_TM_HANDLER_T handler,
                    const CLX_STAT_TM_CNT_TYPE_T type);

/**
 * @brief This API is used to create a distribution counter for
 *        ingress interface (L2, L3, tunnel), egress interface (L2, L3, tunnel),
 *        domain (VLAN, FD, VRF) and flow (ingress ACL and egress ACL).
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    ptr_cnt_id    - Counter logic ID.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - There is no counter to serve the cnt_type.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
CLX_ERROR_NO_T
clx_stat_createDistCnt(const UI32_T unit, UI32_T *ptr_cnt_id);

/**
 * @brief This API is used to destroy a distribution counter.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter logic ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
CLX_ERROR_NO_T
clx_stat_destroyDistCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get a distribution counter.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - Counter
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
CLX_ERROR_NO_T
clx_stat_getDistCnt(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_DIST_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear a distribution counter.
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed
 */
CLX_ERROR_NO_T
clx_stat_clearDistCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to create a counter for interface (ingress, egress) or
 *        domain (forward domain, VRF), or flow (ingress ACL or egress ACL).
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_cfg       - The type of counter
 * @param [out]    ptr_cnt_id    - Counter ID.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - There is no counter available.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
CLX_ERROR_NO_T
clx_stat_createCnt(const UI32_T unit, const CLX_STAT_CNT_CFG_T *ptr_cfg, UI32_T *ptr_cnt_id);

/**
 * @brief This API is used to destroy a counter create via clx_stat_createCnt
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
clx_stat_destroyCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get value of the counter under study
 *
 * The number of counters value return is determined by the type of counter under study.
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cnt    - The return counter values
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
clx_stat_getCnt(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_CNT_T *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study
 *
 * support_chip all
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     cnt_id    - Counter ID
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
clx_stat_clearCnt(const UI32_T unit, const UI32_T cnt_id);

/**
 * @brief This API is used to get config of the counter under study
 *
 * The number of counters value return is determined by the type of counter under study.
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     cnt_id     - Counter ID
 * @param [out]    ptr_cfg    - The return counter values
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
CLX_ERROR_NO_T
clx_stat_getCntCfg(const UI32_T unit, const UI32_T cnt_id, CLX_STAT_CNT_CFG_T *ptr_cfg);

/**
 * @brief This API is used to get port traffic rate by physical port.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Physical port
 * @param [in]     type        - The type of traffic rate
 * @param [out]    ptr_rate    - Rate
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_getPortRate(const UI32_T unit,
                     const UI32_T port,
                     const CLX_STAT_RATE_TYPE_T type,
                     UI64_T *ptr_rate);

/**
 * @brief This API is used to trigger manually counter update to get latest counter value.
 *
 * The API takes time to collect latest counter please use it wisely.
 * support_chip CL8500
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_SUPPORT      - This API is not support in this chip.
 */
CLX_ERROR_NO_T
clx_stat_refreshCnt(const UI32_T unit);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @param [out]    ptr_cnt           - The return counter values
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_stat_getReasonCnt(const UI32_T unit, const CLX_PKT_RX_REASON_T rx_reason_code, UI64_T *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - device unit number
 * @param [in]     rx_reason_code    - rx reason code
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_stat_clearReasonCnt(const UI32_T unit, const CLX_PKT_RX_REASON_T rx_reason_code);
#endif /* End of CLX_STAT_H */
