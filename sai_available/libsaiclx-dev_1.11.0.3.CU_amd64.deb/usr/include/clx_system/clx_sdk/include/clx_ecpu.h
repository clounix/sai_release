/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_ecpu.h
 *
 * PURPOSE:
 *      It provides ecpu module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_ECPU_H
#define CLX_ECPU_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <cmlib/cmlib_queue.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef CLX_ERROR_NO_T (*CLX_APP_DEINIT_FUNC_T)(UI32_T unit);

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    CLX_UPDATE_TYPE_BOOTLOADER = 1,
    CLX_UPDATE_TYPE_APP,
    CLX_UPDATE_TYPE_PCIEFILE,
    CLX_UPDATE_TYPE_LAST
} CLX_UPDATE_TYPE_T;

typedef enum app_id {
    CLX_APP_TYPE_MISC,
    CLX_APP_TYPE_PTP,
    CLX_APP_TYPE_DIAG,
    CLX_APP_TYPE_LAST
} CLX_APP_ID_T;

typedef struct elink_queue {
    CMLIB_QUEUE_T *pfifo;
    CLX_SEMAPHORE_ID_T sem;
    CLX_SEMAPHORE_ID_T sync; /*Used to notify threads to dequeue */
} CLX_ELINK_QUEUE_T;

#pragma pack(1)
/*
 *   ---------------------------------------------------
 *  | ELINK_MSG_HDR | ELINK_MSG_DATA_HDR | APP_DATA_HDR |
 *   ---------------------------------------------------
 */
typedef struct elink_msg_hdr {
    UI8_T machine_id; /*0: host CPU， 1 - eCPU1， 2-eCPU2... */
    UI8_T msg_type;   /*connect,disconnect,keepalive,data,ack,connectack...*/
    UI16_T seq_id;
    UI16_T len;       /*load length*/
    UI8_T data[0];
} CLX_ELINK_MSG_HDR_T;

typedef struct elink_msg_data_hdr {
    UI8_T data_type : 6; /*CLX_ELINK_DATAMSG_TYPE_T:0:req, 1:rsp, 2:noitfy */
    UI8_T flags : 2;     /*bit0:start of the msg  bit1:end of the msg*/
    UI8_T app_id;        /*Data message sub-type: cfg,ptp,port-map,couter...*/
    UI8_T data[0];       /*APP message header*/
} CLX_ELINK_MSG_DATA_HDR_T;

typedef struct elink_hdr {
    CLX_ELINK_MSG_HDR_T mhdr;
    CLX_ELINK_MSG_DATA_HDR_T dhdr;
} CLX_ELINK_HDR_T;

typedef CLX_ERROR_NO_T (*CLX_APP_NOTIFY_FUNC_T)(UI32_T unit, CLX_ELINK_MSG_DATA_HDR_T *dmsg);

#pragma pack()

typedef struct elink_queue_info {
    UI32_T unit;
    CLX_ELINK_MSG_HDR_T *pmsg;
} CLX_ELINK_QUEUE_INFO_T;

typedef enum elink_datamsg_type {
    CLX_DATA_MSG_TYPE_REQ,
    CLX_DATA_MSG_TYPE_RSP,
    CLX_DATA_MSG_TYPE_NTF
} CLX_ELINK_DATAMSG_TYPE_T;

typedef struct diag_buf_info {
    UI32_T addr;
    UI32_T len;
} CLX_ECPU_DIAG_BUF_INFO_T;

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief This API is used to reboot ecpu.
 *
 * support_chip CL8600
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_reboot(const UI32_T unit);

/**
 * @brief This API is used to stop the ecpu from running.
 *
 * support_chip CL8600
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_stop(const UI32_T unit);

/**
 * @brief This API is used to read ecpu sram.
 *
 * The memory to be read needs to be within the memory space of the ecpu.
 * support_chip CL8600
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     addr    - Ecpu memory address space
 * @param [in]     len     - Length of memory to read
 * @param [out]    pbuf    - Memory data
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed
 */
CLX_ERROR_NO_T
clx_ecpu_readMem(const UI32_T unit, const UI32_T addr, const UI32_T len, UI32_T *pbuf);

/**
 * @brief This API is used to read the ecpu diagnostic log buffer.
 *
 * support_chip CL8600
 *
 * @param [in]     unit     - Device unit number
 * @param [out]    ppbuf    - Data buffer
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed
 */
CLX_ERROR_NO_T
clx_ecpu_readDiagLog(const UI32_T unit, C8_T **ppbuf);

/**
 * @brief This API is used to upgrade file on ecpu flash.
 *
 * support_chip CL8600
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Upgrade file name, use absolute path
 * @param [in]     type    - Upgrade type
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed
 * @return         CLX_E_TIMEOUT          - Ecpu response timeout
 */
CLX_ERROR_NO_T
clx_ecpu_updateFlashFw(const UI32_T unit, const C8_T *path, const CLX_UPDATE_TYPE_T type);

/**
 * @brief This API is used to set the firmware default path running in sram.
 *
 * Before starting the ecpu, the path to the firmware file should be set.
 * support_chip CL8600
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Firmware file name, use absolute path
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed
 */
CLX_ERROR_NO_T
clx_ecpu_setFwPath(const UI32_T unit, const C8_T *path);

/**
 * @brief This API is used to upgrade firmware running in sram.
 *
 * When path is NULL, the default path set by clx_ecpu_setFwPath is used.
 * support_chip CL8600
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     path    - Firmware file name, use absolute path
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed
 */
CLX_ERROR_NO_T
clx_ecpu_updateSramFw(const UI32_T unit, C8_T *path);

/**
 * @brief This API is used to create elink application queue and semaphore.
 *
 * support_chip CL8600
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     pname     - The queue name, max length is CMLIB_NAME_MAX_LEN(include '\0')
 * @param [in]     len       - The queue capacity, it should be 1~N.
 * @param [out]    pqueue    - The new queue head
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_createAppQue(const UI32_T unit,
                      const C8_T *pname,
                      const UI32_T len,
                      CLX_ELINK_QUEUE_T *pqueue);

/**
 * @brief This API is used to destroy a queue and release queue head, semaphore and resource.
 *
 * support_chip CL8600
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     pqueue    - The queue will be destroyed
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_ecpu_destroyAppQue(const UI32_T unit, CLX_ELINK_QUEUE_T *pqueue);

/**
 * @brief This API is used to unregister a callback function for ecpu notify 
 *
 * support_chip CL8600
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     app_type    - app type for  ptp ,diag ...
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_ecpu_notify_unregister(const UI32_T unit, const UI8_T app_type);

/**
 * @brief This API is used to register a callback function for ecpu notify 
 *
 * support_chip CL8600
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     app_type  - The queue will be destroyed
 * @param [in]     func      - callback function
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_ecpu_notify_register(const UI32_T unit, const UI8_T app_type, const CLX_APP_NOTIFY_FUNC_T func);

/**
 * @brief This API is used to get the application's elink queue.
 *
 * support_chip CL8600
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     app_id     - Application ID, range 1~31
 * @param [out]    ppqueue    - Elink queue for application
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_getAppQue(const UI32_T unit, const UI8_T app_id, CLX_ELINK_QUEUE_T **ppqueue);

/**
 * @brief This API is used to clear the application's elink queue.
 *
 * support_chip CL8600
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     app_id     - Application ID, range 1~31
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_clearAppQue(const UI32_T unit, const UI8_T app_id);

/**
 * @brief This API is used to register application queue.
 *
 * support_chip CL8600
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     app_id    - Application ID, range 1~31
 * @param [in]     pqueue    - Application queue, ref 'clx_ecpu_createAppQue'
 * @param [in]     deinit    - Application deinit callback function
 *                             Non
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Application is already registered
 * @return         CLX_E_TABLE_FULL       - Registration table is full
 */
CLX_ERROR_NO_T
clx_ecpu_registerApp(const UI32_T unit,
                     const UI8_T app_id,
                     CLX_ELINK_QUEUE_T *pqueue,
                     const CLX_APP_DEINIT_FUNC_T deinit);

/**
 * @brief This API is used to deregister application queue.
 *
 * support_chip CL8600
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     app_id    - Application ID, range 1~31
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_deregisterApp(const UI32_T unit, const UI8_T app_id);

/**
 * @brief This API is used to encapsulate the data into an elink request message and send it to ecpu.
 *
 * The memory pointed to by pdata is managed by APP,and elink does not release it. pdata must use
 * the memory requested by osal_alloc.
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     app_id      - Application ID, range 0~31
 * @param [in]     pdata       - Data buffer
 * @param [in]     len         - Data length
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_sendReqMsg(const UI32_T unit,
                 const UI8_T app_id,
                 const UI8_T *pdata,
                 const UI16_T len);

/**
 * @brief This API is used to encapsulate the data into an elink response message and send it to ecpu.
 *
 * The memory pointed to by pdata is managed by APP,and elink does not release it. pdata must use
 * the memory requested by osal_alloc.
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     app_id      - Application ID, range 0~31
 * @param [in]     pdata       - Data buffer
 * @param [in]     len         - Data length
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_sendRspMsg(const UI32_T unit,
                 const UI8_T app_id,
                 const UI8_T *pdata,
                 const UI16_T len);

/**
 * @brief This API is used to encapsulate the data into an elink notify message and send it to ecpu.
 *
 * The memory pointed to by pdata is managed by APP,and elink does not release it. pdata must use
 * the memory requested by osal_alloc.
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     app_id      - Application ID, range 0~31
 * @param [in]     pdata       - Data buffer
 * @param [in]     len         - Data length
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_sendNtfMsg(const UI32_T unit,
                 const UI8_T app_id,
                 const UI8_T *pdata,
                 const UI16_T len);

/**
 * @brief This API is used to receive response message from ecpu.
 *
 * The memory pointed to by ppmsg is managed by APP,and elink does not release it.
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     app_id      - Application ID, range 0~31
 * @param [out]    ppmsg       - Response message
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
CLX_ERROR_NO_T
clx_ecpu_recvRspMsg(const UI32_T unit, 
                    const UI8_T app_id, 
                    void **ppmsg);

/**
 * @brief This API is used to check elink channel status.
 *
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @return         CLX_E_OK        - Elink is up.
 * @return         CLX_E_OTHERS    - Elink is down.
 */
CLX_ERROR_NO_T
clx_ecpu_isUp(const UI32_T unit);

/**
 * @brief This API is used to check whether ecpu is running.
 *
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @return         TRUE        - Ecpu is running.
 * @return         FALSE       - Ecpu is no running.
 */
BOOL_T
clx_ecpu_isRunning(const UI32_T unit);

#endif /* End of CLX_ECPU_H */
