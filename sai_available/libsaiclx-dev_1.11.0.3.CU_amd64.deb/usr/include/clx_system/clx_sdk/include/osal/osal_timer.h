#include <clx_error.h>
typedef int OSAL_TIMER_ID_T;

typedef void (*OSAL_TIMER_HANDLER_T)(void *arg);

/* EXPORTED SUBPROGRAM BODIES
 */

/**
 * @brief OS abstration API to init osal timer task and resource.
 *        This function can ignore when init. Because the timer
 *        start function will also check timer task status. If timer task not start, it will init
 * it.
 *
 * @return         CLX_E_OK        - Successfully init.
 * @return         CLX_E_OTHERS    - timer init failed
 */
CLX_ERROR_NO_T
osal_timer_init(void);

/**
 * @brief OS abstration API to deinit osal timer task and resource.
 *
 * @return         CLX_E_OK        - Successfully deinit.
 * @return         CLX_E_OTHERS    - Trigger timer task failed
 */
CLX_ERROR_NO_T
osal_timer_deinit(void);

/**
 * @brief OS abstration API to start a timmer.
 *
 * @param [in]     time_value_ms    - Timer value in ms
 * @param [in]     func             - Callback function when timeout
 * @param [in]     arg              - Arg for callback function
 * @param [out]    out_timerid      - timerid
 * @return         CLX_E_OK            - Successfully get time.
 * @return         CLX_E_TABLE_FULL    - No Timer resource
 * @return         CLX_E_OTHERS        - Fail to get time.
 */
CLX_ERROR_NO_T
osal_timer_start(OSAL_TIMER_ID_T *out_timerid,
                 const UI32_T time_value_ms,
                 const OSAL_TIMER_HANDLER_T func,
                 const void *arg);

/**
 * @brief OS abstration API to stop running timer.
 *
 * @param [in]     timerid     - timerid
 * @param [out]    func_arg    - Output user configure func_arg, if NULL, will ignore it.
 * @return         CLX_E_OK               - Successfully stop timer.
 * @return         CLX_E_BAD_PARAMETER    - Wrong timerid.
 * @return         CLX_E_OTHERS           - Stop timer failed
 */
CLX_ERROR_NO_T
osal_timer_stop(OSAL_TIMER_ID_T timerid, void **func_arg);