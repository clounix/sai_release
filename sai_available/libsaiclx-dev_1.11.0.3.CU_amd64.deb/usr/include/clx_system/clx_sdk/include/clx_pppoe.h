/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_pppoe.h
 * PURPOSE:
 *      It provide pppoe module api.
 * NOTES:
 *
 */
#ifndef CLX_PPPOE_H
#define CLX_PPPOE_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Set PPPoE server mac
 * support_chip CL8500
 * @param [in]     unit    - Device unit number
 * @param [in]     mac     - PPPoE server mac
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_pppoe_setServerMac(const UI32_T unit, const CLX_MAC_T mac);

/**
 * @brief Get PPPoE server mac
 * support_chip CL8500
 * @param [in]     unit       - Device unit number
 * @param [out]    ptr_mac    - PPPoE server mac
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_pppoe_getServerMac(const UI32_T unit, CLX_MAC_T *ptr_mac);

/**
 * @brief Add PPPoE service with session_id and vlan.
 * support_chip CL8500
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Phyical port or unit port
 * @param [in]     sess_id        - PPPoE session id
 * @param [in]     seg0           - Segment parameter 0
 * @param [in]     seg1           - Segment parameter 1
 * @param [in]     ptr_seg_srv    - Segment service
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_pppoe_addSegService(const UI32_T unit,
                        const CLX_PORT_T port,
                        const UI32_T sess_id,
                        const UI32_T seg0,
                        const UI32_T seg1,
                        const CLX_PORT_SEG_SRV_T *ptr_seg_srv);

/**
 * @brief Delete PPPoE service with session_id and vlan.
 * support_chip CL8500
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Phyical port or unit port
 * @param [in]     sess_id    - PPPoE session id
 * @param [in]     seg0       - Segment parameter 0
 * @param [in]     seg1       - Segment parameter 1
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_pppoe_delSegService(const UI32_T unit,
                        const CLX_PORT_T port,
                        const UI32_T sess_id,
                        const UI32_T seg0,
                        const UI32_T seg1);

/**
 * @brief Get PPPoE service with session_id and vlan.
 * support_chip CL8500
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Phyical port or unit port
 * @param [in]     sess_id        - PPPoE session id
 * @param [in]     seg0           - Segment parameter 0
 * @param [in]     seg1           - Segment parameter 1
 * @param [out]    ptr_seg_srv    - Segment service
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_pppoe_getSegService(const UI32_T unit,
                        const CLX_PORT_T port,
                        const UI32_T sess_id,
                        const UI32_T seg0,
                        const UI32_T seg1,
                        CLX_PORT_SEG_SRV_T *ptr_seg_srv);

#endif