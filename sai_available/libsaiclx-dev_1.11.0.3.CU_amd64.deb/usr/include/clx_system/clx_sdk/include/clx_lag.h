/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_lag.h
 * PURPOSE:
 *      It provides LAG module API.
 * NOTES:
 *
 */

#ifndef CLX_LAG_H
#define CLX_LAG_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <clx_swc.h>
/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    CLX_LAG_HW_TYPE = 0,
    CLX_LAG_SW_TYPE,
    CLX_LAG_RR_TYPE,
    CLX_LAG_WEIGHT_TYPE,
    CLX_LAG_LAST_TYPE,
} CLX_LAG_TYPE_T;

/* Lag Algorithm mode */
typedef enum CLX_LAG_ALGORITHM_MODE_E {
    CLX_LAG_ALGORITHM_MODE_ORIG = 0, /* only use orig list */
    CLX_LAG_ALGORITHM_MODE_ACT,      /* only use act list */
    CLX_LAG_ALGORITHM_MODE_BOTH,     /* use orig and act list */
    CLX_LAG_ALGORITHM_MODE_LAST
} CLX_LAG_ALGORITHM_MODE_T;

typedef struct CLX_LAG_ATTRIB_S {
#define CLX_LAG_ATTRIBUTE_FLAGS_LAG_TYPE_VALID         (1U << 0)
#define CLX_LAG_ATTRIBUTE_FLAGS_UC_LAG_HASH_TYPE_VALID (1U << 1)
#define CLX_LAG_ATTRIBUTE_FLAGS_MC_LAG_HASH_TYPE_VALID (1U << 2)
    UI32_T flags; /* CLX_LAG_ATTRIBUTE_FLAGS_XXX */
    CLX_LAG_TYPE_T lag_type;
    CLX_SWC_HASH_TYPE_T uc_hash_type;
    CLX_SWC_HASH_TYPE_T mc_hash_type;
} CLX_LAG_ATTRIB_T;

typedef struct CLX_LAG_TRAVERSE_INFO_S {
    UI32_T lag_id;       /* Link aggregation group ID */
    CLX_PORT_T lag_port; /* LAG port*/
} CLX_LAG_TRAVERSE_INFO_T;

/* lag hash path result info */
typedef struct CLX_LAG_HASHPATH_RSLT_INFO_S {
    UI32_T hash_value;   /* flow hash value, lag only use 0-9 bit flow hash value */
    UI32_T hash_path_di; /* lag hash path di */
} CLX_LAG_HASHPATH_RSLT_INFO_T;

/* lag member info */
typedef struct CLX_LAG_MEMBER_INFO_S {
    CLX_PORT_T member; /* Lag member. */
    UI32_T weight;     /* The weight of lag member. */
} CLX_LAG_MEMBER_INFO_T;

typedef CLX_ERROR_NO_T (*CLX_LAG_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                  const CLX_LAG_TRAVERSE_INFO_T *ptr_info,
                                                  void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to create LAG port.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lag_id          - IEEE802.1AX link aggregation ID
 * @param [out]    ptr_lag_port    - The pointer of the LAG port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
clx_lag_createPort(const UI32_T unit, const UI32_T lag_id, CLX_PORT_T *ptr_lag_port);

/**
 * @brief This API is used to destroy LAG port.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lag_port    - LAG port
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
CLX_ERROR_NO_T
clx_lag_destroyPort(const UI32_T unit, const CLX_PORT_T lag_port);

/**
 * @brief This API is used to set LAG member.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     lag_port      - LAG port
 * @param [in]     member_cnt    - Member port count
 * @param [in]     ptr_member    - Member port list
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_setMember(const UI32_T unit,
                  const CLX_PORT_T lag_port,
                  const UI32_T member_cnt,
                  const CLX_PORT_T *ptr_member);

/**
 * @brief This API is used to get LAG member.
 *
 * support_chip all
 *
 * @param [in]     unit                     - Device unit number
 * @param [in]     lag_port                 - LAG port
 * @param [in]     member_cnt               - Get member port count
 * @param [out]    ptr_member               - Member port list
 * @param [out]    ptr_actual_member_cnt    - Actual member port count
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getMember(const UI32_T unit,
                  const CLX_PORT_T lag_port,
                  const UI32_T member_cnt,
                  CLX_PORT_T *ptr_member,
                  UI32_T *ptr_actual_member_cnt);

/**
 * @brief This API is used to get LAG member count.
 *
 * support_chip all
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     lag_port          - LAG port
 * @param [out]    ptr_member_cnt    - Member port count
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getMemberCnt(const UI32_T unit, const CLX_PORT_T lag_port, UI32_T *ptr_member_cnt);

/**
 * @brief The API is used to traverse LAG.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_LAG_TRAVERSE_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK               - Operate success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_OTHERS           - Other error
 */
CLX_ERROR_NO_T
clx_lag_traversePort(const UI32_T unit, const CLX_LAG_TRAVERSE_FUNC_T callback, void *ptr_cookie);

/**
 * @brief This API is used to get LAG range.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [out]    ptr_range    - LAG range information
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getRange(const UI32_T unit, CLX_RANGE_INFO_T *ptr_range);

/**
 * @brief This API is used to get LAG port from LAG ID.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lag_id          - IEEE802.1AX link aggregation ID
 * @param [out]    ptr_lag_port    - The pointer of the LAG port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getPort(const UI32_T unit, const UI32_T lag_id, CLX_PORT_T *ptr_lag_port);

/**
 * @brief This API is used to get LAG ID from LAG port.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     lag_port      - LAG port
 * @param [out]    ptr_lag_id    - The pointer of the LAG Id
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getKey(const UI32_T unit, const CLX_PORT_T lag_port, UI32_T *ptr_lag_id);

/**
 * @brief This API is used to enable FDL for the LAG port.
 *
 * support_chip CL8500
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lag_port        - LAG port
 * @param [in]     ptr_fdl_info    - property of FDL
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_addFdlGroup(const UI32_T unit,
                    const CLX_PORT_T lag_port,
                    const CLX_FDL_INFO_T *ptr_fdl_info);

/**
 * @brief This API is used to get the property of FDL for the LAG port.
 *
 * support_chip CL8500
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     lag_port        - LAG port
 * @param [out]    ptr_fdl_info    - property of FDL
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getFdlGroup(const UI32_T unit, const CLX_PORT_T lag_port, CLX_FDL_INFO_T *ptr_fdl_info);

/**
 * @brief This API is used to disable FDL for the LAG port.
 *
 * support_chip CL8500
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lag_port    - LAG port
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_delFdlGroup(const UI32_T unit, const CLX_PORT_T lag_port);

/**
 * @brief This API is used to set the lag attributes.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lag_port    - LAG port
 * @param [in]     ptr_attr    - Pointer of the lag attribute
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_setAttr(const UI32_T unit, const CLX_PORT_T lag_port, const CLX_LAG_ATTRIB_T *ptr_attr);

/**
 * @brief This API is used to get the lag attributes..
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lag_port    - LAG port
 * @param [out]    ptr_attr    - Pointer of the lag attribute
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getAttr(const UI32_T unit, const CLX_PORT_T lag_port, CLX_LAG_ATTRIB_T *ptr_attr);

/**
 * @brief This API is used to create mglag.
 *
 * support_chip CL8500
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     flags           - Attributes  refer to mglag
 * @param [out]    ptr_mglag_id    - The pointer of the mglag id
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
CLX_ERROR_NO_T
clx_lag_createMglag(const UI32_T unit, const UI32_T flags, UI32_T *ptr_mglag_id);

/**
 * @brief This API is used to destroy mglag.
 *
 * support_chip CL8500
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     mglag_id    - mglag id
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
CLX_ERROR_NO_T
clx_lag_destroyMglag(const UI32_T unit, const UI32_T mglag_id);

/**
 * @brief This API is used to set mglag member.
 *
 * support_chip CL8500
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     mglag_id      - mglag id
 * @param [in]     member_cnt    - Member port count
 * @param [in]     ptr_member    - Member port list
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_setMglagMbr(const UI32_T unit,
                    const UI32_T mglag_id,
                    const UI32_T member_cnt,
                    const UI32_T *ptr_member);

/**
 * @brief This API is used to get mglag member.
 *
 * support_chip CL8500
 *
 * @param [in]     unit                     - Device unit number
 * @param [in]     mglag_id                 - mglag id
 * @param [in]     member_cnt               - Get member port count
 * @param [out]    ptr_member               - Member port list
 * @param [out]    ptr_actual_member_cnt    - Actual member port count
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getMglagMbr(const UI32_T unit,
                    const UI32_T mglag_id,
                    const UI32_T member_cnt,
                    UI32_T *ptr_member,
                    UI32_T *ptr_actual_member_cnt);

/**
 * @brief This API is used to get mglag member count.
 *
 * support_chip CL8500
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     mglag_id          - mglag id
 * @param [out]    ptr_member_cnt    - Member port count
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getMglagMbrCnt(const UI32_T unit, const UI32_T mglag_id, UI32_T *ptr_member_cnt);

/**
 * @brief This API is used to set LAG member with weight.
 *
 * support_chip all
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     lag_port           - LAG port
 * @param [in]     member_cnt         - Member port count
 * @param [in]     ptr_member_info    - Member info
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_setWeightMember(const UI32_T unit,
                        const CLX_PORT_T lag_port,
                        const UI32_T member_cnt,
                        const CLX_LAG_MEMBER_INFO_T *ptr_member_info);

/**
 * @brief This API is used to get LAG member with weight.
 *
 * support_chip all
 *
 * @param [in]     unit                     - Device unit number
 * @param [in]     lag_port                 - LAG port
 * @param [in]     member_cnt               - Get member port count
 * @param [in]     ptr_actual_member_cnt    - Actual member port count
 * @param [out]    ptr_member_info          - Member info
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_lag_getWeightMember(const UI32_T unit,
                        const CLX_PORT_T lag_port,
                        const UI32_T member_cnt,
                        CLX_LAG_MEMBER_INFO_T *ptr_member_info,
                        UI32_T *ptr_actual_member_cnt);
#endif /* End of CLX_LAG_H */
