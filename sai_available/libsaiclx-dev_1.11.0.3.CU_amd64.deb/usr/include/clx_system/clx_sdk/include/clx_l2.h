/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_l2.h
 *
 * PURPOSE:
 *      It provides L2 switching module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_L2_H
#define CLX_L2_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* If this flag is set, more than one replications of a packet \
 * can be forwarded on a port.                                 \
 * If this flag is not set, only one replication of a pakcet   \
 * can be forwarded on a port.                                 \
 * Not supported on CL8600                                     \
 */
#define CLX_L2_MCAST_FLAGS_REPLICATION (1U << 0)
/* Use the specified multicast ID while creating */
#define CLX_L2_MCAST_FLAGS_ADD_WITH_ID      (1U << 1)
#define CLX_L2_MCAST_FLAGS_BYPASS_LAG_PRUNE (1U << 2)
/* Logical mcast id can not be compressed. Only supported on CL8600. */
#define CLX_L2_MCAST_FLAGS_LOGICAL_ID_NO_COMPRESS (1U << 3)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct CLX_L2_ADDR_S {
    CLX_BRIDGE_DOMAIN_T bdid; /* Bridge domain ID */
    CLX_MAC_T mac;            /* 802.3 MAC address */
    CLX_PORT_T port;          /* Port number */
    CLX_VLAN_ACTION_T action; /* CLX_VLAN_ACTION_XXX action. Not supported on CL8600. */
    CLX_VLAN_T svid;          /* Service VLAN ID. Not supported on CL8600. */
    CLX_VLAN_T cvid;          /* Customer VLAN ID. Not supported on CL8600. */
    UI32_T group_label;       /* ACL label */

/* Set entry static.                                                     \
 * In CL8600 means this entry does not allow aging and station movement. \
 * In CL8360 means this entry does not allow aging.                      \
 */
#define CLX_L2_ADDR_FLAGS_STATIC  (1U << 0)
#define CLX_L2_ADDR_FLAGS_PENDING (1U << 1) /* Set entry pending. Not supported on CL8600. */
#define CLX_L2_ADDR_FLAGS_DROP    (1U << 2) /* Frames which hit this entry will be dropped */
#define CLX_L2_ADDR_FLAGS_SECURE  (1U << 3) /* Set entry secure */
/* Set entry svid vaild. Not supported on CL8600. */
#define CLX_L2_ADDR_FLAGS_SVID_VALID (1U << 4)
/* Set entry cvid vaild. Not supported on CL8600. */
#define CLX_L2_ADDR_FLAGS_CVID_VALID (1U << 5)
#define CLX_L2_ADDR_FLAGS_TO_CPU     (1U << 6) /* Copy to cpu. Not supported on CL8600 */
/* Support when operation mode is polling mode.                     \
 * The l2 polling events will not be generated if this flag is set. \
 */
#define CLX_L2_ADDR_FLAGS_NO_CALLBACK (1U << 7)
/* Not supported on CL8360.                       \
 * Overwrite entry while the hash bucket is full. \
 */
#define CLX_L2_ADDR_FLAGS_OVERWRITE_DYNAMIC (1U << 8)
    UI32_T flags; /* CLX_L2_ADDR_FLAGS_XXX flags */
} CLX_L2_ADDR_T;

typedef enum {
    /* Replace all L2 entries matching given static status */
    CLX_L2_ADDR_MATCH_FIELD_STATIC = (1U << 0),
    CLX_L2_ADDR_MATCH_FIELD_BDID = (1U << 1), /* Replace all L2 entries matching given bdid */
    CLX_L2_ADDR_MATCH_FIELD_PORT = (1U << 2), /* Replace all L2 entries matching given port */
    /* Replace all L2 entries matching given pending status. Not supported on CL8600. */
    CLX_L2_ADDR_MATCH_FIELD_PENDING = (1U << 3),
    CLX_L2_ADDR_MATCH_FIELD_UNEQUAL = (1U << 4), /* Only supported on CL8600. */
    CLX_L2_ADDR_MATCH_FIELD_LAST
} CLX_L2_ADDR_MATCH_FIELD_T;

typedef enum {
    /* Delete L2 unicast MAC address entries.
     * If this field is set, other fields will be ignored.
     */
    CLX_L2_ADDR_REPLACE_FIELD_DEL = (1U << 0),
    CLX_L2_ADDR_REPLACE_FIELD_STATIC = (1U << 1), /* Replace static field */
    /* Replace pending field. Not supported on CL8600 */
    CLX_L2_ADDR_REPLACE_FIELD_PENDING = (1U << 2),
    CLX_L2_ADDR_REPLACE_FIELD_DROP = (1U << 3),   /* Replace drop field */
    CLX_L2_ADDR_REPLACE_FIELD_SECURE = (1U << 4), /* Replace secure field */
    /* Replace port.
     * Need to specify bdid value if port type is ip/trill/nsh tnl.
     */
    CLX_L2_ADDR_REPLACE_FIELD_PORT = (1U << 5),
    /* Replace action/svid/cvid/SVID_VALID flag/CVID_VALID flag.
     * To replace vlan, need to replace port at the same time.
     * Not supported on CL8600.
     */
    CLX_L2_ADDR_REPLACE_FIELD_VLAN = (1U << 6),
    CLX_L2_ADDR_REPLACE_FIELD_LAST
} CLX_L2_ADDR_REPLACE_FIELD_T;

typedef enum {
    CLX_L2_ADDR_NOTIFY_ADD = 0, /* New entry added in L2 FDB */
    CLX_L2_ADDR_NOTIFY_MODIFY,  /* Entry modified in L2 FDB */
    CLX_L2_ADDR_NOTIFY_DELETE,  /* Entry deleted in L2 FDB */
    CLX_L2_ADDR_NOTIFY_LAST
} CLX_L2_ADDR_NOTIFY_REASON_T;

typedef enum {
    CLX_L2_ADDR_SW_LEARN_NEW_LEARN, /* Entry new learn in L2 FDB. */
    CLX_L2_ADDR_SW_LEARN_MOVE,      /* Entry moved in L2 FDB. */
    CLX_L2_ADDR_SW_LEARN_LAST
} CLX_L2_ADDR_SW_LEARN_REASON_T;

/* Callback function use for receiving notification about insertions into,
 * modifications, and deletions from the L2 table dynamically as they occur.
 */
typedef void (*CLX_L2_ADDR_NOTIFY_FUNC_T)(const UI32_T unit,
                                          const CLX_L2_ADDR_NOTIFY_REASON_T reason,
                                          const CLX_L2_ADDR_T *ptr_addr,
                                          void *ptr_cookie);
typedef void (*CLX_L2_ADDR_SW_LEARN_FUNC_T)(const UI32_T unit,
                                            const CLX_L2_ADDR_SW_LEARN_REASON_T reason,
                                            const CLX_L2_ADDR_T *ptr_addr,
                                            void *ptr_cookie);

/* L2 traverse unicast entry callback */
typedef CLX_ERROR_NO_T (*CLX_L2_ADDR_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                      const CLX_L2_ADDR_T *ptr_addr,
                                                      void *ptr_cookie);

typedef enum {
    CLX_L2_ADDR_TRAVERSE_MODE_BLOCKING = 0, /* Traverse blocking mode */
    CLX_L2_ADDR_TRAVERSE_MODE_NON_BLOCKING, /* Traverse non blocking mode */
    CLX_L2_ADDR_TRAVERSE_MODE_LAST
} CLX_L2_ADDR_TRAVERSE_MODE_T;

typedef enum {
    /* If use this type,
     *  - for uni/nni port, egress s-vlan tag will be removed/added.
     *  - for non uni/nni port,
     *    egress vlan will be the same as ingress classified vlan.
     */
    CLX_L2_MCAST_EGR_INTF_TYPE_PORT = 0,
    CLX_L2_MCAST_EGR_INTF_TYPE_L2,      /* If use this type, user can set CLX_VLAN_ACTION_XXX and
                                         * ETM_HSH_MC_SC_U_FDID will hit.      Not supported on CL8600.
                                         */
    CLX_L2_MCAST_EGR_INTF_TYPE_VM_1BR,  /* Not supported on CL8600. */
    CLX_L2_MCAST_EGR_INTF_TYPE_VM_NIV,  /* Not supported on CL8600. */
    CLX_L2_MCAST_EGR_INTF_TYPE_VM_VEPA, /* Not supported on CL8600. */
    CLX_L2_MCAST_EGR_INTF_TYPE_NV,
    CLX_L2_MCAST_EGR_INTF_TYPE_TRILL,   /* Not supported on CL8600. */
    CLX_L2_MCAST_EGR_INTF_TYPE_MPLS,
    CLX_L2_MCAST_EGR_INTF_TYPE_FL,      /* Fabric link. Only supported on CL8600 */
    CLX_L2_MCAST_EGR_INTF_TYPE_LAST
} CLX_L2_MCAST_EGR_INTF_TYPE_T;

typedef struct CLX_L2_MCAST_EGR_INTF_NV_S {
    CLX_PORT_T tnl_port;      /* unicast tunnel */
    CLX_TUNNEL_KEY_T tnl_key; /* multicast tunnel */
    UI32_T nvo3_adj_id;
} CLX_L2_MCAST_EGR_INTF_NV_T;

typedef struct CLX_L2_MCAST_EGR_INTF_TRILL_S {
    CLX_TRILL_NICKNAME_T egr_nickname;
    UI32_T nvo3_adj_id;
} CLX_L2_MCAST_EGR_INTF_TRILL_T;

typedef struct CLX_L2_MCAST_EGR_INTF_MPLS_S {
    CLX_PORT_T pw_port;
} CLX_L2_MCAST_EGR_INTF_MPLS_T;

typedef struct CLX_L2_MCAST_EGR_INTF_S {
    CLX_L2_MCAST_EGR_INTF_TYPE_T type; /* If (type == CLX_L2_MCAST_EGR_INTF_TYPE_PORT),
                                          only the port field should be filled,
                                          the other fileds will be ignored. */
    union {
        CLX_PORT_T port;               /* Port number.
                                        * Only support port type CLX_PORT_TYPE_NORMAL
                                        * and CLX_PORT_TYPE_LAG  */
        UI32_T fl_id;                  /* Fabric link ID. Only supported on CL8600. */
    };
    CLX_BRIDGE_DOMAIN_T bdid;          /* Bridge domain ID. Not supported on CL8600. */
    CLX_VLAN_ACTION_T action; /* CLX_VLAN_ACTION_XXX action. Only supported mc tunnel on CL8600. */
    CLX_VLAN_T svid;          /* Service VLAN ID. Only supported mc tunnel on CL8600. */
    CLX_VLAN_T cvid;          /* Customer VLAN ID. Only supported mc tunnel on CL8600. */
    union {
        UI32_T vm_id;         /* Not supported on CL8600. */
        CLX_L2_MCAST_EGR_INTF_NV_T nv;
        CLX_L2_MCAST_EGR_INTF_TRILL_T trill; /* Not supported on CL8600. */
        CLX_L2_MCAST_EGR_INTF_MPLS_T mpls;
    };
/* Set entry svid vaild. Not supported on CL8600. */
#define CLX_L2_MCAST_EGR_INTF_FLAGS_SVID_VALID (1U << 0)
/* Set entry cvid vaild. Not supported on CL8600. */
#define CLX_L2_MCAST_EGR_INTF_FLAGS_CVID_VALID (1U << 1)
    UI32_T flags; /* CLX_L2_MCAST_EGR_INTF_FLAGS_XXX flags */
} CLX_L2_MCAST_EGR_INTF_T;

typedef struct CLX_L2_MCAST_ADDR_S {
    CLX_BRIDGE_DOMAIN_T bdid; /* Bridge domain ID */
    CLX_MAC_T mac;            /* 802.3 mac address */
    UI32_T mcast_id;          /* Multicast ID */
    UI32_T group_label;       /* ACL label */
    CLX_VLAN_ACTION_T action; /* CLX_VLAN_ACTION_XXX action. Not supported on CL8600. */
    UI32_T svid;              /* Service VLAN ID. Not supported on CL8600. */

#define CLX_L2_MCAST_ADDR_FLAGS_DROP   (1U << 0) /* Frames which hit this entry will be dropped */
#define CLX_L2_MCAST_ADDR_FLAGS_TO_CPU (1U << 1) /* copy to cpu. Not supported on CL8600. */
/* Not supported on CL8360, used for qinq. Not supported on CL8600. */
#define CLX_L2_MCAST_ADDR_FLAGS_SVID_VALID (1U << 2)
    UI32_T flags; /* CLX_L2_MCAST_ADDR_FLAGS_XXX flags */
} CLX_L2_MCAST_ADDR_T;

/* L2 traverse multicast entry callback */
typedef CLX_ERROR_NO_T (*CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                            const CLX_L2_MCAST_ADDR_T *ptr_addr,
                                                            void *ptr_cookie);

typedef struct CLX_L2_IP_MCAST_GROUP_S {
    CLX_BRIDGE_DOMAIN_T bdid; /* Bridge domain ID */
    CLX_IP_ADDR_T grp_ip;     /* Multicast group IP */
    CLX_IP_ADDR_T src_ip;     /* Value of grp_ip.ipv4 and src_ip.ipv4 should synchornized.
                               * If src_ip.ip_addr is all zero, use group only.
                               */
    UI32_T mcast_id;          /* Multicast ID */
    UI32_T group_label;       /* ACL label */
    UI32_T svid;              /* Service VLAN ID */

/* Frames which hit this entry will be dropped */
#define CLX_L2_IP_MCAST_GROUP_FLAGS_DROP   (1U << 0)
#define CLX_L2_IP_MCAST_GROUP_FLAGS_TO_CPU (1U << 1) /* copy to cpu */
/* Not supported on CL8360, used for qinq */
#define CLX_L2_IP_MCAST_GROUP_FLAGS_SVID_VALID (1U << 2)
    UI32_T flags; /* CLX_L2_IP_MCAST_GROUP_FLAGS_XXX flags */
} CLX_L2_IP_MCAST_GROUP_T;

typedef struct CLX_L2_ECMP_GROUP_S {
    UI32_T sw_en;                                /* 0: hardware, 1: software. The default is 0. */
    UI32_T hash_sel;                             /* select Hash engine. */
    UI32_T path_cnt;                             /* total ecmp path number, only valid when get. */

#define CLX_L2_ECMP_GRP_FLAGS_SEL_EN   (1U << 0) /* enable set hash_sel. */
#define CLX_L2_ECMP_GRP_FLAGS_WECMP_EN (1U << 1) /* Enable weighted ECMP */

    UI32_T flags; /* Refer to CLX_L2_ECMP_GRP_FLAGS_XX, do not use now. */
} CLX_L2_ECMP_GROUP_T;

typedef struct CLX_L2_ECMP_PATH_S {
    UI32_T output_path_id; /* support tunnel port only. */
    UI32_T weight;         /* weight */
} CLX_L2_ECMP_PATH_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to add/set a L2 unicast MAC address entry.
 *        If the address entry does not exist, it will add the entry;
 *        if the address entry already exists, it will set the entry with user input value.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 address entry to be added/set
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_addAddr(const UI32_T unit, const CLX_L2_ADDR_T *ptr_addr);

/**
 * @brief This API is used to delete a L2 unicast MAC address entry.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 address entry to be deleted.
 *                               User should only fill the key fields "bdid" and "mac". The other
 * fields will be ignored.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_delAddr(const UI32_T unit, const CLX_L2_ADDR_T *ptr_addr);

/**
 * @brief This API is used to get a L2 unicast MAC address entry.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 address entry to be obtained.
 *                               User should only fill the key fields "bdid" and "mac". The other
 * fields will be ignored.
 * @param [out]    ptr_addr    - The fully filled L2 address entry obtained.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getAddr(const UI32_T unit, CLX_L2_ADDR_T *ptr_addr);

/**
 * @brief This API is used to replace L2 unicast MAC address entries which match the specified
 * criteria with the newly specified values.
 *
 * When user specifies the "replace_field" with CLX_L2_ADDR_REPLACE_FIELD_DEL set,
 * other values which are included by "replace_field" parameter will be ignored,
 * and the parameter "ptr_replace_addr" can be NULL.
 *
 * support_chip all
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     match_field         - Indicate which fields of L2 uncast MAC address entry are
 * used to match the given "ptr_match_addr". User can choose one or more fields to do matching.
 *                                       Refer to CLX_L2_ADDR_MATCH_FIELD_XXX.
 * @param [in]     ptr_match_addr      - Specify the values of matched fields used to perform
 * matching. User need to input values of these fields which are chosen by "match_field" parameter.
 * @param [in]     replace_field       - Indicate which fields' values will be replaced with new
 * values. Refer to CLX_L2_ADDR_REPLACE_FIELD_XXX.
 * @param [in]     ptr_replace_addr    - Specify the new values used to replace the old values for
 * the matched MAC address entries. User need to input values of these fields which are chosen by
 * "replace_field" parameter.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_replaceAddr(const UI32_T unit,
                   const UI32_T match_field,
                   const CLX_L2_ADDR_T *ptr_match_addr,
                   const UI32_T replace_field,
                   const CLX_L2_ADDR_T *ptr_replace_addr);

/**
 * @brief This API is used to traverse all the L2 unicast MAC address entries, and handle it by
 * user's callback.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     mode          - The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 * @param [in]     callback      - The callback function to be called when each L2 address entry is
 * traversed
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_traverseAddr(const UI32_T unit,
                    const CLX_L2_ADDR_TRAVERSE_MODE_T mode,
                    const CLX_L2_ADDR_TRAVERSE_FUNC_T callback,
                    void *ptr_cookie);

/**
 * @brief This API is used to register a callback function that will be called
 *        whenever the L2 unicast MAC address table is updated.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_L2_ADDR_NOTIFY_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_registerAddrNotifyCallback(const UI32_T unit,
                                  const CLX_L2_ADDR_NOTIFY_FUNC_T callback,
                                  void *ptr_cookie);

/**
 * @brief This API is used to degister a callback function that will be called
 *        whenever the L2 unicast MAC address table is updated.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_L2_ADDR_NOTIFY_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_deregisterAddrNotifyCallback(const UI32_T unit,
                                    const CLX_L2_ADDR_NOTIFY_FUNC_T callback,
                                    void *ptr_cookie);

/**
 * @brief This API is used to register a callback function that will be called
 *        whenever the L2 unicast entry needs to be learned by sofware.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_L2_ADDR_SW_LEARN_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_registerAddrSwLearnCallback(const UI32_T unit,
                                   const CLX_L2_ADDR_SW_LEARN_FUNC_T callback,
                                   void *ptr_cookie);

/**
 * @brief This API is used to degister a callback function that will be called
 *        whenever the L2 unicast entry needs to be learned by sofware.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - The callback function of type CLX_L2_ADDR_SW_LEARN_FUNC_T
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_deregisterAddrSwLearnCallback(const UI32_T unit,
                                     const CLX_L2_ADDR_SW_LEARN_FUNC_T callback,
                                     void *ptr_cookie);

/**
 * @brief This API is used to add a L2 multicast ID.
 *        After the L2 multicast ID is added, L2 multicast egress interfaces can be added to it.
 *        If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set, this API will add L2 multicast ID with the ID
 * pointed by ptr_mcast_id; if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a
 * L2 multicast ID.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     flags           - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [in]     ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                                   this field specifies the L2 multicast ID to be added.
 * @param [out]    ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                                   this field specifies the allocated L2 multicast ID.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_addMcastId(const UI32_T unit, const UI32_T flags, UI32_T *ptr_mcast_id);

/**
 * @brief This API is used to delete a L2 multicast ID.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     mcast_id    - The L2 multicast ID to be deleted
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_delMcastId(const UI32_T unit, const UI32_T mcast_id);

/**
 * @brief This API is used to get a L2 multicast ID.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     mcast_id       - The L2 multicast ID to be obtained
 * @param [out]    ptr_flags      - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [out]    port_bitmap    - The egress port bitmap
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getMcastId(const UI32_T unit,
                  const UI32_T mcast_id,
                  UI32_T *ptr_flags,
                  CLX_PORT_BITMAP_T port_bitmap);

/**
 * @brief This API is used to add egress interface for a L2 multicast ID.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     mcast_id        - The L2 multicast ID
 * @param [in]     egr_intf_cnt    - The number of egress interfaces to be added
 * @param [in]     ptr_egr_intf    - The egress interface list to be added
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_addMcastEgrIntf(const UI32_T unit,
                       const UI32_T mcast_id,
                       const UI32_T egr_intf_cnt,
                       CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf);

/**
 * @brief This API is used to delete egress interface for a L2 multicast ID.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     mcast_id        - The L2 multicast ID
 * @param [in]     egr_intf_cnt    - The number of egress interfaces to be deleted
 * @param [in]     ptr_egr_intf    - The egress interface list to be deleted.
 *                                   If CLX_L2_MCAST_FLAGS_REPLICATION of the L2 multicast ID is not
 * set, user should only fill the "type", "bdid" and "port" fields, and the other fields will be
 * ignored.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_delMcastEgrIntf(const UI32_T unit,
                       const UI32_T mcast_id,
                       const UI32_T egr_intf_cnt,
                       CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf);

/**
 * @brief This API is used to get egress interface count for a L2 multicast ID.
 *
 * support_chip all
 *
 * @param [in]     unit                - Device unit number
 * @param [in]     mcast_id            - The L2 multicast ID
 * @param [out]    ptr_egr_intf_cnt    - The egress interface count
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getMcastEgrIntfCnt(const UI32_T unit, const UI32_T mcast_id, UI32_T *ptr_egr_intf_cnt);

/**
 * @brief This API is used to get egress interface for a L2 multicast ID.
 *
 * support_chip all
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     mcast_id                   - The L2 multicast ID
 * @param [in]     egr_intf_cnt               - The number of egress interfaces to be get
 * @param [out]    ptr_egr_intf               - The egress interface list obtained
 * @param [out]    ptr_actual_egr_intf_cnt    - The actual number of egress interface obtained
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getMcastEgrIntf(const UI32_T unit,
                       const UI32_T mcast_id,
                       const UI32_T egr_intf_cnt,
                       CLX_L2_MCAST_EGR_INTF_T *ptr_egr_intf,
                       UI32_T *ptr_actual_egr_intf_cnt);

/**
 * @brief This API is used to add/set a L2 multicast MAC address entry.
 *        If the multicast address entry does not exist, it will add the entry;
 *        if the multicast address entry already exists, it will set the entry with user input
 * value.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 multicast address entry to be added/set
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_addMcastAddr(const UI32_T unit, const CLX_L2_MCAST_ADDR_T *ptr_addr);

/**
 * @brief This API is used to delete a L2 multicast address entry.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 multicast entry to be deleted.
 *                               User should only fill the key fields "bdid" and "mac". The other
 * fields will be ignored.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_delMcastAddr(const UI32_T unit, const CLX_L2_MCAST_ADDR_T *ptr_addr);

/**
 * @brief This API is used to get a L2 multicast address entry.
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_addr    - The L2 multicast address entry to be obtained.
 *                               User should only fill the key fields "bdid" and "mac". The other
 * fields will be ignored.
 * @param [out]    ptr_addr    - The full filled L2 multicast address entry obtained
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getMcastAddr(const UI32_T unit, CLX_L2_MCAST_ADDR_T *ptr_addr);

/**
 * @brief This API is used to traverse all the L2 multicast MAC address entries, and handle it by
 * user's callback.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     mode          - The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 * @param [in]     callback      - The callback function to be called when each L2 multicast address
 * entry is traversed
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_traverseMcastAddr(const UI32_T unit,
                         const CLX_L2_ADDR_TRAVERSE_MODE_T mode,
                         const CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T callback,
                         void *ptr_cookie);

/**
 * @brief This API is used to add/set a L2 IP multicast group entry.
 *        If the IP multicast entry does not exist, it will add the entry;
 *        if the IP multicast entry already exists, it will set the entry with user input value.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_group    - The IP multicast entry to be added/set
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_addIpMcastGroup(const UI32_T unit, const CLX_L2_IP_MCAST_GROUP_T *ptr_group);

/**
 * @brief This API is used to delete a L2 IP multicast group entry.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_group    - The L2 IP multicast entry to be deleted.
 *                                User should only fill the key fields "bdid", "grp_ip" and
 * "src_ip". Other fields will be ignored.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_delIpMcastGroup(const UI32_T unit, const CLX_L2_IP_MCAST_GROUP_T *ptr_group);

/**
 * @brief This API is used to get a L2 IP multicast group entry.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_group    - The L2 IP multicast entry to be obtained.
 *                                User should only fill the key fields "bdid", "grp_ip" and
 * "src_ip". Other fields will be ignored.
 * @param [out]    ptr_group    - The full filled L2 IP multicast entry obtained
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getIpMcastGroup(const UI32_T unit, CLX_L2_IP_MCAST_GROUP_T *ptr_group);

/**
 * @brief This API is used to create l2 ecmp port.
 *
 * support_chip CL8600
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_ecmp_info    - The l2 ecmp info.
 * @param [out]    ptr_ecmp_port    - The l2 ecmp port obtained
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_addEcmp(const UI32_T unit,
               const CLX_L2_ECMP_GROUP_T *ptr_ecmp_info,
               CLX_PORT_T *ptr_ecmp_port);

/**
 * @brief This API is used to set l2 ecmp port. User can change ecmp mode or hsh_sel or close
 * resilient.
 *
 * support_chip CL8600
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_ecmp_info    - The l2 ecmp info.
 * @param [in]     ecmp_port        - The l2 ecmp port
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_setEcmp(const UI32_T unit,
               const CLX_L2_ECMP_GROUP_T *ptr_ecmp_info,
               const CLX_PORT_T ecmp_port);

/**
 * @brief This API is used to del l2 ecmp port.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ecmp_port    - The l2 ecmp port
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_delEcmp(const UI32_T unit, const CLX_PORT_T ecmp_port);

/**
 * @brief This API is used to get l2 ecmp port.
 *
 * support_chip CL8600
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ecmp_port        - The l2 ecmp port
 * @param [out]    ptr_ecmp_info    - The l2 ecmp info obtained
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getEcmp(const UI32_T unit, const CLX_PORT_T ecmp_port, CLX_L2_ECMP_GROUP_T *ptr_ecmp_info);

/**
 * @brief This API is used to add l2 ecmp path and only support tunnel port now.
 *
 * support_chip CL8600
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ecmp_port        - The l2 ecmp port
 * @param [in]     ptr_path_info    - The l2 ecmp path info.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_addGrpPath(const UI32_T unit,
                  const CLX_PORT_T ecmp_port,
                  const CLX_L2_ECMP_PATH_T *ptr_path_info);

/**
 * @brief This API is used to del l2 ecmp path.
 *
 * support_chip CL8600
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ecmp_port        - The l2 ecmp port
 * @param [in]     ptr_path_info    - The l2 ecmp path info.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_delGrpPath(const UI32_T unit,
                  const CLX_PORT_T ecmp_port,
                  const CLX_L2_ECMP_PATH_T *ptr_path_info);

/**
 * @brief This API is used to get l2 ecmp path by idx.
 *
 * support_chip CL8600
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ecmp_port        - The l2 ecmp port
 * @param [in]     path_idx         - The l2 ecmp path index.
 * @param [out]    ptr_path_info    - The l2 ecmp path info.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getPathByidx(const UI32_T unit,
                    const CLX_PORT_T ecmp_port,
                    const UI32_T path_idx,
                    CLX_L2_ECMP_PATH_T *ptr_path_info);

/**
 * @brief This API is used to get l2 ecmp set path offset.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     ecmp_port            - The l2 ecmp port
 * @param [in]     ptr_hash_val_list    - hash value list
 * @param [in]     hash_val_cnt         - total hash value count
 * @param [in]     ptr_path_info        - The l2 ecmp path info.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_setGrpPathHsh(const UI32_T unit,
                     const CLX_PORT_T ecmp_port,
                     const UI32_T *ptr_hash_val_list,
                     const UI32_T hash_val_cnt,
                     const CLX_L2_ECMP_PATH_T *ptr_path_info);

/**
 * @brief This API is used to get l2 ecmp get path offset.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                       - Device unit number
 * @param [in]     ecmp_port                  - The l2 ecmp port
 * @param [in]     hash_val_cnt               - Total hash value count
 * @param [in]     ptr_path_info              - The l2 ecmp path info.
 * @param [out]    ptr_hash_val_list          - hash value list
 * @param [out]    ptr_actual_hash_val_cnt    - Actual hash value count
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_getGrpPathHsh(const UI32_T unit,
                     const CLX_PORT_T ecmp_port,
                     const UI32_T hash_val_cnt,
                     const CLX_L2_ECMP_PATH_T *ptr_path_info,
                     UI32_T *ptr_hash_val_list,
                     UI32_T *ptr_actual_hash_val_cnt);

/**
 * @brief This API is used to add a L2 multicast ID.
 *        After the L2 multicast ID is added, L2 multicast egress interfaces can be added to it.
 *        If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set, this API will add L2 multicast ID with the ID
 * pointed by ptr_mcast_id; if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a
 * set of L2 multicast ID.
 *
 * support_chip all
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     flags           - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [in]     mcast_id_cnt    - The number of L2 multicast ID need to be added.
 * @param [in]     ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                                   this field specifies the L2 multicast ID to be added.
 * @param [out]    ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                                   this field specifies the first allocated L2 multicast ID.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
CLX_ERROR_NO_T
clx_l2_addMultiMcastId(const UI32_T unit,
                       const UI32_T flags,
                       const UI32_T mcast_id_cnt,
                       UI32_T *ptr_mcast_id);
#endif /* End of CLX_L2_H */
