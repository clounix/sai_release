/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_l3t.h
 * PURPOSE:
 *      It provides l3 tunnel module api.
 * NOTES:
 *
 */

#ifndef CLX_L3T_H
#define CLX_L3T_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_l3.h>
#include <clx_qos.h>
#include <clx_types.h>

#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_L3T_FLAGS_WITH_ID (0x1U << 0) /* Use user input tnl_port to set parameter */
#define CLX_L3T_EVPN_FLAGS_WITH_ID \
    (0x1U << 0) /* Use user input eg_group to create ethernet segment group */

#define CLX_L3T_FLAGS_FLEX_TUNNEL_UDP_IPV4_CHKSUM0_EN (0x1U << 0) /* Enable udp ipv4 checksum */
#define CLX_L3T_FLAGS_FLEX_TUNNEL_UDP_IPV6_CHKSUM0_EN (0x1U << 1) /* Enable udp ipv6 checksum */

#define CLX_L3T_FLEX_TUNNEL_HEADER_NUM (6)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* Multicast Tunnel PIM mode
 * PIM-BIDIR https://www.rfc-editor.org/rfc/rfc7761.html
 * PIM-SM    https://www.rfc-editor.org/rfc/rfc5015.html
 */
typedef enum {
    CLX_L3T_PIM_MODE_SM = 0, /* PIM-SM mode */
    CLX_L3T_PIM_MODE_BIDIR,  /* PIM-BIDIR mode */
    CLX_L3T_PIM_MODE_LAST
} CLX_L3T_PIM_MODE_T;

/* Tunnel MAC Entry */
typedef struct CLX_L3T_MAC_INFO_S {
    CLX_PORT_T port;           /* Key: Physical port or LAG port ID */
    CLX_VLAN_T cvid;           /* Key: C-VLAN ID */
    CLX_VLAN_T cvid_mask;      /* Mask for the VID. lt only */
    CLX_VLAN_T svid;           /* Key: S-VLAN ID. lt only */
    CLX_VLAN_T svid_mask;      /* Mask for the VID. lt only */
    CLX_MAC_T tunnel_mac;      /* Key: Tunnel MAC address */
    CLX_MAC_T tunnel_mac_mask; /* Mask for the tunnel MAC */

#define CLX_L3T_MAC_INFO_FLAGS_PORT_VALID                                                     \
    (0x1U << 0)                                           /* Enable port comparison,          \
                                                             set to 1 to compare port_lag_id; \
                                                             set to 0 to mask port_lag_id.    \
                                                           */
#define CLX_L3T_MAC_FLAGS_SVID_VALID          (0x1U << 1) /* Indicate if svid is valid. lt only */
#define CLX_L3T_MAC_FLAGS_CVID_VALID          (0x1U << 2) /* Indicate if cvid is valid */
#define CLX_L3T_MAC_FLAGS_VLAN_TAG_MODE_1Q    (0x1U << 3) /* Indicate vlan tag mode. lt only */
#define CLX_L3T_MAC_FLAGS_MPLS_EN             (0x1U << 4) /* Enable MPLS */
#define CLX_L3T_MAC_FLAGS_TRILL_EN            (0x1U << 5) /* Enable TRILL. lt only*/
#define CLX_L3T_MAC_FLAGS_IP_TUNNEL_EN        (0x1U << 6) /* Enable IP_TUNNEL. lt only */
#define CLX_L3T_MAC_FLAGS_NSH_EN              (0x1U << 7) /* Enable NSH. lt only */
#define CLX_L3T_MAC_FLAGS_TRILL_MC_RPF_CHK_EN (0x1U << 8) /* Enable TRILL. lt only */
#define CLX_L3T_MAC_FLAGS_TRILL_MC_ADJ_CHK_EN \
    (0x1U << 9)  /* Enable TRILL multicast adjacency check. lt only */
#define CLX_L3T_MAC_FLAGS_TRILL_UC_ADJ_CHK_EN \
    (0x1U << 10) /* Enable TRILL unicast adjacency check. lt only */
#define CLX_L3T_MAC_FLAGS_MPLS_RMAC_CHK_EXCPT \
    (0x1U << 11) /* Raise exception if MPLS packets rmac check fail. cl8600 only */
#define CLX_L3T_MAC_FLAGS_GIPO_MISS_DROP \
    (0x1U << 12) /* Drop if outer multicast IP address lookup miss. cl8600 only */
#define CLX_L3T_MAC_FLAGS_RPF_CHK_EN (0x1U << 13) /* Enable PIM rpf check. cl8600 only */
#define CLX_L3T_MAC_FLAGS_RMAC_SRAM_CHK                                                          \
    (0x1U << 14)                 /* Select to use tcam or sram table for rmac check. cl8600 only \
                                  * set to 1 use sram table check mac address.                   \
                                  * set to 0 use tcam table check mac address.                   \
                                  */
#define CLX_L3T_MAC_FLAGS_SRV6_ONLY                                                                       \
    (0x1U << 15)                 /* Enable SRv6 packet only. cl8600 only                                  \
                                  * Set to 1 to disable IPv6 Tunnel decapsulation and MPLS decapsulation. \
                                  * MUST set if locator length less then 4 bytes.                         \
                                  */
    UI32_T flags;                /* Refer to CLX_L3T_MAC_FLAGS_XXX */
    UI32_T l3_intf_id;           /* L3 interface id. lt only */
    UI8_T mpls_namespace;        /* MPLS namespace. lt only */
    UI16_T l3_mtu_size;          /* L3 mtu size */
    UI16_T stpo_id;              /* STP check index. cl8600 only */
    UI16_T vrfo;                 /* Vrf id of the underlay network. cl8600 only */
    CLX_L3T_PIM_MODE_T rpf_mode; /* PIM rpf check mode. cl8600 only */
    UI16_T
    rpf_intf_or_bmp;             /* PIM rpf check interface id or RP group bitmap.
                                  * if rpf_mode is CLX_L3T_PIM_MODE_SM, the rpf check will fail when the
                                  * TDS_HSH_MXGO.rpf_bd is not equal rpf_intf_id_or_bmp. if
                                  * rpf_mode is CLX_L3T_PIM_MODE_BIDIR, the rpf check will fail when
                                  * the lower 3 bits of TDS_HSH_MGO.rpf_bd which is RP
                                  * group is not set in rpf_intf_id_or_bmp
                                  */
} CLX_L3T_MAC_INFO_T;

/* Tunnel ECN Value */
/*    https://datatracker.ietf.org/doc/rfc3168                          */
/*    +-----+-----+                                                     */
/*    | ECN FIELD |                                                     */
/*    +-----+-----+                                                     */
/*      ECT   CE         [Obsolete] RFC 2481 names for the ECN bits.    */
/*       0     0         Not-ECT                                        */
/*       0     1         ECT(1)                                         */
/*       1     0         ECT(0)                                         */
/*       1     1         CE                                             */
typedef enum {
    CLX_L3T_ECN_NONE = 0, /* Not-ECT */
    CLX_L3T_ECN_1,        /* ECT(1) */
    CLX_L3T_ECN_0,        /* ECT(0) */
    CLX_L3T_ECN_CE,       /* CE */
    CLX_L3T_ECN_LAST
} CLX_L3T_ECN_CODE_T;

/* tunnel Initiation Information. */
typedef struct CLX_L3T_INIT_INFO_S {
    CLX_TUNNEL_KEY_T key;                          /* L3 tunnel key */
#define CLX_L3T_INIT_FLAGS_DST_IP_FROM_IPV6                                                     \
    (0x1U << 0)                                    /* Per tunnel init and only for auto tunnel, \
                                                    * set to 1 if destination IPv4 address      \
                                                    * derived from inner destination IPv6       \
                                                    * address. lt only                          \
                                                    */
#define CLX_L3T_INIT_FLAGS_TTL_FROM_INNER                                                    \
    (0x1U << 1)                                    /* Per tunnel init.                       \
                                                    * set to 1 if outer TTL value from inner \
                                                    * header TTL.                            \
                                                    */
#define CLX_L3T_INIT_FLAGS_FLOWLABEL_FROM_INNER                                                 \
    (0x1U << 2)                                    /* Per tunnel init and only for IPv6 tunnel. \
                                                    * set to 1 if outer header flowlabel        \
                                                    * value from inner header flowlabel.        \
                                                    */
#define CLX_L3T_INIT_FLAGS_SET_DF                                                               \
    (0x1U << 3)                                    /* Per tunnel init and only for IPv4 tunnel. \
                                                    * set to 1 if set DF bit  in outer IPv4     \
                                                    * header.                                   \
                                                    */
#define CLX_L3T_INIT_FLAGS_QOS_FROM_INNER                                                    \
    (0x1U << 4)                                    /* Per tunnel init.                       \
                                                    * Set to 1 if outer QoS value from inner \
                                                    * header QoS. lt only                    \
                                                    */
#define CLX_L3T_INIT_FLAGS_QOS_TNL_UNIFORM                                                   \
    (0x1U << 5)                                    /* Per tunnel init.                       \
                                                    * Set to 1 if outer QoS value from inner \
                                                    * header QoS. cl8600 only                \
                                                    */
#define CLX_L3T_INIT_FLAGS_ECN_FROM_INNER                                                \
    (0x1U << 6)                                    /* Per tunnel init.                   \
                                                    * Set to 1 if outer header ECN value \
                                                    * from inner header ECN.             \
                                                    */
#define CLX_L3T_INIT_FLAGS_KEEP_INNER_TAG                                         \
    (0x1U << 7)                                    /* Per tunnel init.            \
                                                    * set to 1 if keep inner tag. \
                                                    * cl8600 only                 \
                                                    */
#define CLX_L3T_INIT_FLAGS_PHB_TO_DSCP_PROFILE_VALID                                    \
    (0x1U << 8)                                    /* Per tunnel init.                  \
                                                    * set to 1 if remark egress DSCP by \
                                                    * traffic class and color.          \
                                                    */
#define CLX_L3T_INIT_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID                                    \
    (0x1U << 9)                                    /* Per tunnel init.                     \
                                                    * set to 1 if remark egress PCP/DEI by \
                                                    * traffic class and color.             \
                                                    */
#define CLX_L3T_INIT_FLAGS_METER_VALID                                                 \
    (0x1U << 10)                                   /* Per tunnel init.                 \
                                                    * set to 1 if meter_id is applied. \
                                                    */
#define CLX_L3T_INIT_FLAGS_CNT_VALID                                                 \
    (0x1U << 11)                                   /* Per tunnel init.               \
                                                    * set to 1 if cnt_id is applied. \
                                                    */
#define CLX_L3T_INIT_FLAGS_DIST_CNT_VALID                                                 \
    (0x1U << 12)                                   /* Per tunnel init.                    \
                                                    * set to 1 if dist_cnt_id is applied. \
                                                    */
#define CLX_L3T_INIT_FLAGS_SAMPLE_TO_MIR                                                              \
    (0x1U << 13)                                   /* Sample packets to a mirror session              \
                                                    * set to 1 if sample packets to a mirror session. \
                                                    * set to 0 if sample packets to CPU.              \
                                                    */
#define CLX_L3T_INIT_FLAGS_SAMPLE_HIGH_LATENCY                                    \
    (0x1U << 14)                                   /* Sample high latency packets \
                                                    * set to 1 if enable.         \
                                                    */
#define CLX_L3T_INIT_FLAGS_IOAM_VALID (0x1U << 15) /* set to 1 to enable IOAM. lt only */
#define CLX_L3T_INIT_FLAGS_DTEL       (0x1U << 16) /* set to 1 if dtel_profile_id is applied. lt only */
#define CLX_L3T_INIT_FLAGS_GBP_ENABLE \
    (0x1U << 17)  /* set to 1 to encapsulate gbp tag to Vxlan header. cl8600 only */

    UI32_T flags; /* Refer to CLX_L3T_INIT_FLAGS_XXX. */
    UI32_T phb_to_dscp_profile_id;      /* Profile ID is valid if DSCP is remarked by
                                         * traffic class and color.
                                         */
    UI32_T phb_to_pcp_dei_profile_id;   /* Profile ID is valid if PCP/DEI is remarked by
                                         * traffic class and color.
                                         */
    UI8_T dscp;                         /* If the outer header QOS is not from the inner
                                         * header, assign the outer header DSCP value.
                                         */
    UI8_T pcp;                          /* If the outer header QOS is not from the inner
                                         * header, assign the outer header PCP value.
                                         * lt only
                                         */
    UI8_T dei;                          /* If the outer header QOS is not from the inner
                                         * header, assign the outer header DEI value.
                                         * lt only
                                         */
    UI8_T ttl;                          /* If the outer header TTL is not from the inner
                                         * header, assign the outer header TTL value.
                                         */
    UI32_T mir_session_bitmap;          /* Mirror session ID bitmap */
    UI32_T group_label;                 /* Group label */
    UI32_T meter_id;                    /* Meter ID */
    UI32_T cnt_id;                      /* Service counter ID */
    UI32_T dist_cnt_id;                 /* Distribution counter ID */
    UI16_T l2_mtu_size;                 /* L2 mtu size. cl8600 only */

    UI32_T sampling_rate;               /* Sampling rate */
    UI32_T sample_to_mir_session_id;    /* Sample packets to a mirror session */
    UI32_T dtel_profile_id;             /* DTEL profile ID. lt only */

    CLX_PORT_VLAN_TAG_T inner_vlan_tag; /* Inner header's TPID setting. */
} CLX_L3T_INIT_INFO_T;

/* Tunnel termination, MRPF mode */
typedef enum {
    CLX_L3T_MC_MODE_NONE = 0,
    CLX_L3T_MC_MODE_MGO_ONLY,  /* only set MGO table */
    CLX_L3T_MC_MODE_MSGO_ONLY, /* only set MSGO table, need to create MGO with sg_only=1 */
    // CLX_L3T_MC_MODE_MSGO,       /* set both MSGO and MGO table */
    CLX_L3T_MC_MODE_LAST
} CLX_L3T_MC_MODE_T;

/* Tunnel termination Information */
typedef struct CLX_L3T_TERM_INFO_S {
    CLX_TUNNEL_KEY_T key; /* L3 tunnel key */
#define CLX_L3T_TERM_FLAGS_AUTO_TUNNEL_SIP_CHECK                        \
    (0x1U << 0)           /* Per tunnel term.                           \
                           * set to 1 if check auto tunnel inner header \
                           * SIP consistent with outer header SIP       \
                           * lt only                                    \
                           */
#define CLX_L3T_TERM_FLAGS_AUTO_TUNNEL_DIP_CHECK                        \
    (0x1U << 1)           /* Per tunnel term.                           \
                           * set to 1 if check auto tunnel inner header \
                           * DIP consistent with outer  header DIP      \
                           * lt only                                    \
                           */
#define CLX_L3T_TERM_FLAGS_AUTO_TUNNEL_ISATAP_CHECK                       \
    (0x1U << 2)           /* Per tunnel term.                             \
                           * set to 1 if check isatap tunnel inner header \
                           * IP consistent with outer  header IP          \
                           * NB only                                      \
                           */
#define CLX_L3T_TERM_FLAGS_AUTO_TUNNEL_6TO4_CHECK                       \
    (0x1U << 3)           /* Per tunnel term.                           \
                           * set to 1 if check 6to4 tunnel inner header \
                           * IP consistent with outer  header IP        \
                           * NB only                                    \
                           */
#define CLX_L3T_TERM_FLAGS_USE_INNER_PHB                                \
    (0x1U << 4)           /* Per tunnel term.                           \
                           * set to 1 if user inner header QoS(DSCP/PCP \
                           * /DEI) as traffic class and color source    \
                           */
#define CLX_L3T_TERM_FLAGS_KEEP_INNER_QOS                          \
    (0x1U << 5)           /* Per tunnel term.                      \
                           * set to 1 if don't modify inner header \
                           * QoS(DSCP/PCP/DEI) value               \
                           */
#define CLX_L3T_TERM_FLAGS_QOS_TNL_UNIFORM                                                  \
    (0x1U << 6)           /* Per tunnel term.                                               \
                           * set to 1 if outer copy qos value into inner                    \
                           * need set qos_dont_modify to 1 first, when this flag is working \
                           * NB only                                                        \
                           */
#define CLX_L3T_TERM_FLAGS_COPY_OUTER_TTL_2_INNER                      \
    (0x1U << 7)           /* Per tunnel term.                          \
                           * set to 1 if copy outer TTL  to inner TTL. \
                           */
#define CLX_L3T_TERM_FLAGS_FORWARD_INNER_TAGGED_PACKET                \
    (0x1U << 8)           /* Per tunnel term and only for vxlan.      \
                           * For nvgre, this flag must be 0.          \
                           * set to 1 if forward inner tagged packet. \
                           */
#define CLX_L3T_TERM_FLAGS_DSCP_TO_PHB_PROFILE_VALID            \
    (0x1U << 9)           /* Per tunnel term.                   \
                           * set to 1 if use DSCP to initialize \
                           * traffic class and color.           \
                           */
#define CLX_L3T_TERM_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID            \
    (0x1U << 10)          /* Per tunnel term.                      \
                           * set to 1 if use PCP/DEI to initialize \
                           * traffic class and color.              \
                           */
#define CLX_L3T_TERM_FLAGS_METER_VALID                        \
    (0x1U << 11)          /* Per tunnel term.                 \
                           * set to 1 if meter_id is applied. \
                           */
#define CLX_L3T_TERM_FLAGS_CNT_VALID                        \
    (0x1U << 12)          /* Per tunnel term.               \
                           * set to 1 if cnt_id is applied. \
                           */
#define CLX_L3T_TERM_FLAGS_DIST_CNT_VALID                        \
    (0x1U << 13)          /* Per tunnel term.                    \
                           * set to 1 if dist_cnt_id is applied. \
                           */
#define CLX_L3T_TERM_FLAGS_ECN_DISABLE                \
    (0x1U << 14)          /* Per tunnel term entry,   \
                           * set to 1 if disable ECN. \
                           */
#define CLX_L3T_TERM_FLAGS_ADDR_DONT_LEARN                                 \
    (0x1U << 15)          /* Per tunnel term and only for vxlan and nvgre. \
                           * set to 1 to disable MAC address learning.     \
                           */
#define CLX_L3T_TERM_FLAGS_SAMPLE_TO_MIR                                     \
    (0x1U << 16)          /* Sample packets to a mirror session              \
                           * set to 1 if sample packets to a mirror session. \
                           * set to 0 if sample packets to CPU.              \
                           */
#define CLX_L3T_TERM_FLAGS_DTEL           (0x1U << 17) /* set to 1 if dtel_profile_id is applied */
#define CLX_L3T_TERM_FLAGS_L3_MC_ID_VALID (0x1U << 18) /* Indicate if l3_mc_id is valid */
#define CLX_L3T_TERM_FLAGS_MCAST_RPF_FAIL_TO_CPU                                                  \
    (0x1U << 19)                        /* Per tunnel term and only for multicast tunnel          \
                                         * set to 1 if multicast packets rpf fail and copy to CPU \
                                         * NB only                                                \
                                         */
#define CLX_L3T_TERM_FLAGS_TEP_BIND                                                      \
    (0x1U << 20)                        /* Per tunnel term.                              \
                                         * set to 1 if check src_tep and dst_tep binding \
                                         * NB only                                       \
                                         */
#define CLX_L3T_TERM_FLAGS_GBP_ENABLE \
    (0x1U << 21)                        /* set to 1 to get gbp tag from Vxlan header. cl8600 only */
    UI32_T flags;                       /* Refer to CLX_L3T_TERM_FLAGS_XXX. */
    UI32_T intf_id;                     /* Tunnel interface ID */
    UI8_T default_pcp;                  /* The default PCP will be used if the native packet
                                         * is untagged, or the native VLAN tag is distrusted.
                                         */
    UI8_T default_dei;                  /* The default DEI will be used if the native packet
                                         * is untagged or the native VLAN tag is distrusted.
                                         */
    CLX_TRUST_MODE_T trust_mode;        /* Whether to trust 1p */
    UI32_T dscp_to_phb_profile_id;      /* profile ID is valid if  DSCP is used to
                                         * initialize the traffic class and color
                                         */
    UI32_T pcp_dei_to_phb_profile_id;   /* Profile ID is valid if PCP/DEI is used to
                                         * initialize the traffic class and color.
                                         */
    UI32_T mir_session_bitmap;          /* Mirror session ID bitmap */
    UI32_T group_label;                 /* Group label */
    UI32_T meter_id;                    /* Meter ID */
    UI32_T cnt_id;                      /* Service counter ID */
    UI32_T dist_cnt_id;                 /* Distribution counter ID */
    CLX_PORT_T port;                    /* Tunnel for mac learning */
    UI32_T sampling_rate;               /* Sampling rate */
    UI32_T sample_to_mir_session_id;    /* Sample packets to a mirror session */
    UI32_T dtel_profile_id;             /* DTEL profile ID */
    UI16_T l2_mtu_size;                 /* L2 mtu size */
    UI8_T mpls_namespace;               /* MPLS namespace */
    CLX_PORT_VLAN_TAG_T inner_vlan_tag; /* Inner header's TPID setting */
    UI32_T l3_mc_id;                    /* L3 multicast id for transit copy */
    UI32_T es_group;                    /* use to esi filter
                                         * NB only
                                         */
    UI8_T rpf_bd;                       /* use to check mrpf
                                         * NB only
                                         */
    CLX_L3T_MC_MODE_T mc_mode;          /* use to set mrpf mode
                                         * NB only
                                         */
    CLX_SA_MISS_REASON_T sa_rsn;        /* CLX_SA_MISS_REASON_0/1 */
} CLX_L3T_TERM_INFO_T;

/* NVO3 Route Information*/
typedef struct CLX_L3T_NVO3_ROUTE_INFO_S {
    CLX_TUNNEL_KEY_T key;             /* L3 tunnel key */
    CLX_L3_OUTPUT_TYPE_T output_type; /* Refer to CLX_L3_OUTPUT_TYPE_T */
    UI32_T output_id;                 /* Support ADJ and ECMP type */
} CLX_L3T_NVO3_ROUTE_INFO_T;

typedef struct CLX_L3T_FLEX_TUNNEL_PROFILE_UDP_S {
    UI32_T reserved[CLX_L3T_FLEX_TUNNEL_HEADER_NUM - 1]; /* decrease size of destination port and
                                                            source port */
    UI16_T destination_port;
    UI16_T source_port;
} CLX_L3T_FLEX_TUNNEL_PROFILE_UDP_T;

typedef struct CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_S {
    union {
        UI32_T user_defined[CLX_L3T_FLEX_TUNNEL_HEADER_NUM];
        CLX_L3T_FLEX_TUNNEL_PROFILE_UDP_T udp_header;
    } header;
    UI8_T ip_protocol;
    UI8_T len; /* Flexible encap header length in bytes.
                  The maximum encap len is 24 and only even number of len is allowed.
                  example: UDP = 8
                */
} CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T;

/* Physical port information for tunnel use */
typedef UI32_T CLX_DF_BITMAP_T[1];
typedef struct CLX_L3T_PORT_INFO_S {
    UI32_T dflt_pcp;                                 /* Default pcp of tunnel header vlan tag */
    UI32_T dflt_dei;                                 /* Default dei of tunnel header vlan tag */
    UI32_T dflt_vid;                                 /* Default vid of tunnel header vlan tag */
    UI32_T igr_l2_mtu_size;                          /* L2 mtu size */

#define CLX_L3T_PORT_INFO_FLAGS_TRUST_1P   (1U << 0) /* Trust 802.1p of tunnel header vlan tag */
#define CLX_L3T_PORT_INFO_FLAGS_TRUST_VLAN (1U << 1) /* Trust vlan id of tunnel header vlan tag */
/* Merge port to same tunnel rmac.         \
 * Set to 1 if the tunnel is allowed to be \
 * terminated on multiple ports.           \
 */
#define CLX_L3T_PORT_INFO_FLAGS_RMAC_MERGE (1U << 2)
/* Decapsulation of c-tag-only packets is not allowed */
#define CLX_L3T_PORT_INFO_FLAGS_NOT_ALLOW_CTAG (1U << 3)
#define CLX_L3T_PORT_INFO_FLAGS_TNL_SKIP_CHECK (1U << 4) /* Skip outer l2/l3 address check. */

    UI32_T flags;
    UI32_T esi;                                       /* EVPN esi label */
    CLX_DF_BITMAP_T df_bitmap;                        /* EVPN designated forwarder bitmap.
                                                       * bit0(1) set to 1 means this link is DF of
                                                       * bridge domain 0(1), 32(33), 64(65)...
                                                       */
    UI16_T s_tpid;                                    /* Service vlan TPID */
    UI16_T c_tpid;                                    /* Customer vlan TPID */

#define CLX_L3T_PORT_INFO_ATTR_DFLT_PCP   (1ULL << 0) /* Set dflt_pcp */
#define CLX_L3T_PORT_INFO_ATTR_DFLT_DEI   (1ULL << 1) /* Set dflt_dei */
#define CLX_L3T_PORT_INFO_ATTR_DFLT_VID   (1ULL << 2) /* Set dflt_vid */
#define CLX_L3T_PORT_INFO_ATTR_TRUST_1P   (1ULL << 3) /* Set CLX_L3T_PORT_INFO_FLAGS_TRUST_1P */
#define CLX_L3T_PORT_INFO_ATTR_TRUST_VLAN (1ULL << 4) /* Set CLX_L3T_PORT_INFO_FLAGS_TRUST_VLAN */
#define CLX_L3T_PORT_INFO_ATTR_RMAC_MERGE (1ULL << 5) /* Set rmac merge mode */
#define CLX_L3T_PORT_INFO_ATTR_IGR_MTU    (1ULL << 6) /* Set l2_mtu_size */
#define CLX_L3T_PORT_INFO_ATTR_ESI        (1ULL << 7) /* Set esi */
#define CLX_L3T_PORT_INFO_ATTR_DF         (1ULL << 8) /* Set df_bitmap */
#define CLX_L3T_PORT_INFO_ATTR_TPID       (1ULL << 9) /* Set c_tpid s_tpid */
#define CLX_L3T_PORT_INFO_ATTR_NOT_ALLOW_CTAG \
    (1ULL << 10) /* Set CLX_L3T_PORT_INFO_FLAGS_NOT_ALLOW_CTAG */
#define CLX_L3T_PORT_INFO_ATTR_TNL_SKIP_CHECK \
    (1ULL << 11) /* Set CLX_L3T_PORT_INFO_FLAGS_TNL_SKIP_CHECK */
#define CLX_L3T_PORT_INFO_ATTR_ALL (0xFFFFFFFFFFFFFFFF) /* Set all fields */
    UI64_T attr_bitmap;                                 /* Mark which fields to set */
} CLX_L3T_PORT_INFO_T;

typedef enum {
    CLX_L3T_FLEX_TUNNEL_TYPE_GENEVE,       /* Tunnel type GENEVE, use one entry */
    CLX_L3T_FLEX_TUNNEL_TYPE_PIM,          /* Tunnel type PIM, use one entry */
    CLX_L3T_FLEX_TUNNEL_TYPE_GTP,          /* Tunnel type GTP, use two entries */
    CLX_L3T_FLEX_TUNNEL_TYPE_USER_DEFINED, /* User defined tunnel type */
    CLX_L3T_FLEX_TUNNEL_TYPE_TEREDO, /* Tunnel type TEREDO, use two entries in lightning, use one
                                        entry in namchabarwa */
    CLX_L3T_FLEX_TUNNEL_TYPE_TEREDO_SIMP, /* Tunnel type TEREDO SIMP, use one entry in namchabarwa
                                           */
    CLX_L3T_FLEX_TUNNEL_TYPE_L2TP_WITHOUT_LEN, /* Tunnel type L2TP with len filed is zero, use one
                                                  entry */
    CLX_L3T_FLEX_TUNNEL_TYPE_L2TP,             /* Tunnel type L2TP, use one entry */
    CLX_L3T_FLEX_TUNNEL_TYPE_LAST
} CLX_L3T_FLEX_TUNNEL_TYPE_T;

typedef enum {
    CLX_L3T_TNL_PSR_TYPE_ALL = 0,
    CLX_L3T_TNL_PSR_TYPE_GRE,
    CLX_L3T_TNL_PSR_TYPE_VXLAN,
    CLX_L3T_TNL_PSR_TYPE_IPINIP,
    CLX_L3T_TNL_PSR_TYPE_GTP,
    CLX_L3T_TNL_PSR_TYPE_LAST,
} CLX_L3T_TNL_PSR_TYPE_T;

typedef CLX_ERROR_NO_T (*CLX_L3T_TUNNEL_MAC_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const UI32_T index,
    const CLX_L3T_MAC_INFO_T *ptr_tunnel_mac_info,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3T_INIT_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_L3T_INIT_INFO_T *ptr_tunnel_init_info,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3T_TERM_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_L3T_TERM_INFO_T *ptr_tunnel_term_info,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3T_NVO3_ROUTE_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_L3T_NVO3_ROUTE_INFO_T *ptr_nvo3_route_info,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_L3T_PORT_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                       const CLX_TUNNEL_KEY_T *ptr_key,
                                                       const CLX_PORT_T port,
                                                       void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Add a tunnel MAC entry.
 *
 * This API is used to add a tunnel MAC entry. User needs to specify the index of
 * My Tunnel MAC table and the data of entry, including the port LAG ID, S-VLAN ID,
 * C-VLAN ID, tunnel MAC address and the mask of them.
 * My Tunnel MAC table is used to judge whether the incoming packet needs to be
 * sent via the tunnel termination packet flow.
 * When packet arrives, if the tunnel is enabled, the ingress port ID,
 * outer destination MAC address, and outer VLAN ID are used to lookup the MyTunnelMAC table.
 * If the search result is hit, and outer source IP address and outer destination IP address
 * are both hit in the tunnel term table, the packet will go through the tunnel termination packet
 * flow. User can set the mask bit to 0 in order to multiplex one entry by multiple port IDs, VLAN
 * IDs and MAC addresses.
 *
 * support_chip all
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     index                  - The entry index
 * @param [in]     ptr_tunnel_mac_info    - The entry to be added
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter. "unit"  is invalid or index beyond the
 * range.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
clx_l3t_addTunnelMac(const UI32_T unit,
                     const UI32_T index,
                     const CLX_L3T_MAC_INFO_T *ptr_tunnel_mac_info);

/**
 * @brief Delete a tunnel MAC entry.
 *
 * support_chip all
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     index    - The entry index
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter. "unit"  is invalid or index beyond the
 * range.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input port_id or lag_id,MAC,
 * VLAN id.
 * @return         CLX_E_NO_MEMORY          - No available memory
 */
CLX_ERROR_NO_T
clx_l3t_delTunnelMac(const UI32_T unit, const UI32_T index);

/**
 * @brief Get a tunnel MAC entry.
 *
 * support_chip all
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     index                  - The entry index
 * @param [out]    ptr_tunnel_mac_info    - The tunnel MAC entry to be obtained
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter. "unit"  is invalid or index beyond the
 * range.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input port_id or lag_id,
 *                                            MAC,VLAN id.
 */
CLX_ERROR_NO_T
clx_l3t_getTunnelMac(const UI32_T unit,
                     const UI32_T index,
                     CLX_L3T_MAC_INFO_T *ptr_tunnel_mac_info);

/**
 * @brief Traverse all configured tunnel mac entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_traverseTunnelMac(const UI32_T unit,
                          const CLX_L3T_TUNNEL_MAC_TRAVERSE_FUNC_T callback,
                          void *ptr_cookie);

/**
 * @brief Add a tunnel initiation for IP tunnel. If the tunnel initiation existed, the tunnel
 *        initiation attributes will be updated.
 *
 * Source IP, destination IP, tunnel type and tunnel interface ID must be specified in
 * ptr_tunnel_init_info. For automatic tunnel, DIP is not required. For detailed description of
 * tunnel init information, refer to CLX_L3T_INIT_INFO_T. If the incoming packet needs to go
 * through the tunnel initiation process, user can add the outer IP header to the original packet by
 * this API. The outer IP header information, such as QOS and TTL, can be obtained from the inner IP
 * header or by reassigning a new value. If the outer SIP and outer DIP are the same, VxLAN
 * tunnel, NVGRE tunnel and other L3 GRE tunnel must share the same tunnel initiation configuration
 * with IP in IP tunnel and automatic tunnel (6to4 and ISATAP).
 *
 * support_chip all
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     ptr_tunnel_init_info    - The tunnel init information to be added
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter. "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3t_addInit(const UI32_T unit, const CLX_L3T_INIT_INFO_T *ptr_tunnel_init_info);

/**
 * @brief Delete a tunnel initiation entry for IP tunnel.
 *
 * Source IP, Destination IP and tunnel type must be specified in ptr_tunnel_init_info.
 * But for automatic tunnel, SIP is not required.
 * For detailed description of tunnel init information, refer to CLX_L3T_INIT_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     ptr_tunnel_init_info    - The tunnel init information will be deleted.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel init information.
 * @return         CLX_E_NO_MEMORY          - No available memory
 */
CLX_ERROR_NO_T
clx_l3t_delInit(const UI32_T unit, const CLX_L3T_INIT_INFO_T *ptr_tunnel_init_info);

/**
 * @brief Get a tunnel initiation entry for IP tunnel.
 *
 * Source IP, destination IP and tunnel_type must be specified in ptr_tunnel_init_info.
 * But for automatic tunnel, SIP is not required.
 * Detail description for tunnel init information refers to CLX_L3T_INIT_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                    - Device unit number
 * @param [out]    ptr_tunnel_init_info    - The tunnel init information to be obtained.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel init information.
 */
CLX_ERROR_NO_T
clx_l3t_getInit(const UI32_T unit, CLX_L3T_INIT_INFO_T *ptr_tunnel_init_info);

/**
 * @brief Traverse all configured tunnel init entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_traverseInit(const UI32_T unit,
                     const CLX_L3T_INIT_TRAVERSE_FUNC_T callback,
                     void *ptr_cookie);

/**
 * @brief Add a tunnel termination entry for IP tunnel. If the tunnel termination existed,
 *        the tunnel termination attributes will be updated.
 *
 * This API is used to add a tunnel termination entry. For automatic tunnel, SIP is not required;
 * Source IP, Destination IP, tunnel type and tunnel interface ID must be specified in
 * ptr_tunnel_term_info.  For detailed information of the tunnel terms, refer to
 * CLX_L3T_TERM_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     ptr_tunnel_term_info    - The tunnel termination information will be added.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3t_addTerm(const UI32_T unit, const CLX_L3T_TERM_INFO_T *ptr_tunnel_term_info);

/**
 * @brief Delete a tunnel termination entry for IP tunnel.
 *
 * Source IP, destination IP and tunnel type must be specified in ptr_tunnel_term_info.
 * But for automatic tunnel, SIP is not required.
 * For detailed information of the terms, refer to CLX_L3T_TERM_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     ptr_tunnel_term_info    - The tunnel termination information to be deleted; it
 *                                           need to specify src_dip, dst_ip and tunnel_type.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel termination
 * information.
 * @return         CLX_E_NO_MEMORY          - No available memory
 */
CLX_ERROR_NO_T
clx_l3t_delTerm(const UI32_T unit, const CLX_L3T_TERM_INFO_T *ptr_tunnel_term_info);

/**
 * @brief Get a specified tunnel termination entry for IP tunnel.
 *
 * Source IP, destination IP and tunnel type must be specified in ptr_tunnel_term_info.
 * But for automatic tunnel, SIP is not required.
 * For detailed information of the tunnel terms, refer to CLX_L3T_TERM_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                    - Device unit number
 * @param [out]    ptr_tunnel_term_info    - The tunnel termination information to be obtained
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel termination
 * information.
 */
CLX_ERROR_NO_T
clx_l3t_getTerm(const UI32_T unit, CLX_L3T_TERM_INFO_T *ptr_tunnel_term_info);

/**
 * @brief Traverse all configured tunnel termination entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_traverseTerm(const UI32_T unit,
                     const CLX_L3T_TERM_TRAVERSE_FUNC_T callback,
                     void *ptr_cookie);

/**
 * @brief Add a NVO3 route. If ECMP flag is set, add a NVO3 ECMP route.
 *
 * When user needs to set an IP packet forward from tunnel, it can be used
 * to set the IP packet which matches one route entry forwarded from a tunnel.
 *
 * support_chip all
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     ptr_nvo3_route_info    - The NVO3 route information to be added.
 *                                          For ECMP route, the NVO3 ECMP group ID needs to be
 * specified.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3t_addNvo3Route(const UI32_T unit, const CLX_L3T_NVO3_ROUTE_INFO_T *ptr_nvo3_route_info);

/**
 * @brief Delete NVO3 route for IP tunnel.
 *
 * Destination IP, source IP and tunnel type must be specified in ptr_nvo3_route_info.
 * For detailed information of NVO3 route, refer to CLX_L3T_NVO3_ROUTE_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     ptr_nvo3_route_info    - The NVO3 route information to be deleted
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_l3t_delNvo3Route(const UI32_T unit, const CLX_L3T_NVO3_ROUTE_INFO_T *ptr_nvo3_route_info);

/**
 * @brief Get a NVO3 route of IP tunnel.
 *
 * Destination IP must be specified in ptr_nvo3_route_info.
 * For detailed information of NVO3 route, refer to CLX_L3T_NVO3_ROUTE_INFO_T.
 *
 * support_chip all
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     ptr_nvo3_route_info    - The key of NVO3 route information:  dst_ip
 * @param [out]    ptr_nvo3_route_info    - The NVO3 route information to be obtained.
 *                                          If it is ECMP route, it will return the ECMP group ID.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input destination IP.
 */
CLX_ERROR_NO_T
clx_l3t_getNvo3Route(const UI32_T unit, CLX_L3T_NVO3_ROUTE_INFO_T *ptr_nvo3_route_info);

/**
 * @brief Traverse all configured nvo3_route entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_traverseNvo3Route(const UI32_T unit,
                          const CLX_L3T_NVO3_ROUTE_TRAVERSE_FUNC_T callback,
                          void *ptr_cookie);

/**
 * @brief Set unused tunnel ECN action.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit      - Device unit number
 * @param [in]     action    - Unused tunnel ECN action
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_setUnusedEcnAction(const UI32_T unit, const CLX_FWD_ACTION_T action);

/**
 * @brief Get unused tunnel ECN action.
 *
 * support_chip CL8300, CL8500
 *
 * @param [in]     unit         - Device unit number
 * @param [out]    ptr_action   - Pointer to the unused tunnel ECN action
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_getUnusedEcnAction(const UI32_T unit, CLX_FWD_ACTION_T *ptr_action);

/**
 * @brief Create tunnel port
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_key     - Tunnel key
 * @param [in]     flag        - Refers to CLX_L3T_FLAGS_XXX
 * @param [out]    ptr_port    - Pointer to the generated tunnel port
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_createPort(const UI32_T unit,
                   const CLX_TUNNEL_KEY_T *ptr_key,
                   const UI32_T flag,
                   CLX_PORT_T *ptr_port);

/**
 * @brief Destroy tunnel port
 *
 * support_chip all
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Tunnel port
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_destroyPort(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Get tunnel port from tunnel key
 *
 * support_chip all
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     ptr_key     - Tunnel key
 * @param [out]    ptr_port    - Tunnel port
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_getPort(const UI32_T unit, const CLX_TUNNEL_KEY_T *ptr_key, CLX_PORT_T *ptr_port);

/**
 * @brief Get tunnel key from tunnel port
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Tunnel port
 * @param [out]    ptr_key    - Tunnel key
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_getKey(const UI32_T unit, const CLX_PORT_T port, CLX_TUNNEL_KEY_T *ptr_key);

/**
 * @brief Traverse all configured tunnel port entries.
 *
 * support_chip all
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_traversePort(const UI32_T unit,
                     const CLX_L3T_PORT_TRAVERSE_FUNC_T callback,
                     void *ptr_cookie);

/**
 * @brief Add flexible tunnel pattern
 *
 * support_chip all
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     index    - Index of flexible tunnel pattern
 * @param [in]     type     - Flexible tunnel type
 * @param [in]     flags    - Refers to CLX_L3T_FLAGS_FLEX_TUNNEL_XXX
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_addFlexTunnel(const UI32_T unit,
                      const UI32_T index,
                      const CLX_L3T_FLEX_TUNNEL_TYPE_T type,
                      const UI32_T flags);

/**
 * @brief Delete flexible tunnel pattern
 *
 * support_chip all
 *
 * @param [in]     unit     - Device unit number
 * @param [in]     index    - Index of flexible tunnel pattern
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_delFlexTunnel(const UI32_T unit, const UI32_T index);

/**
 * @brief Get flexible tunnel type by index
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     index        - Index of flexible tunnel pattern
 * @param [out]    ptr_type     - Flexible tunnel type
 * @param [out]    ptr_flags    - Refers to CLX_L3T_FLAGS_FLEX_TUNNEL_XXX
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_getFlexTunnel(const UI32_T unit,
                      const UI32_T index,
                      CLX_L3T_FLEX_TUNNEL_TYPE_T *ptr_type,
                      UI32_T *ptr_flags);

/**
 * @brief Set flexible tunnel Udf profile
 *
 * Flex tunnel used profile parameter when type is CLX_L3T_FLEX_TUNNEL_TYPE_USER_DEFINED
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     index          - Index of flexible tunnel pattern
 * @param [in]     ptr_profile    - Profile pointer
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_setFlexTunnelUdfProfile(const UI32_T unit,
                                const UI32_T index,
                                CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

/**
 * @brief Get flexible tunnel Udf profile by index
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     index          - Index of flexible tunnel pattern
 * @param [out]    ptr_profile    - Profile pointer
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_l3t_getFlexTunnelUdfProfile(const UI32_T unit,
                                const UI32_T index,
                                CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

/**
 * @brief Set Physical Port property.
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - Interface object
 * @param [in]     ptr_portinfo    - The pointer of the physical port properties
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_l3t_setPhyPort(const UI32_T unit,
                   const CLX_PORT_T port,
                   const CLX_L3T_PORT_INFO_T *ptr_portinfo);

/**
 * @brief Get Physical Port property.
 *
 * support_chip CL8600
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     port            - Interface object
 * @param [out]    ptr_portinfo    - The pointer of the physical port properties
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
CLX_ERROR_NO_T
clx_l3t_getPhyPort(const UI32_T unit, const CLX_PORT_T port, CLX_L3T_PORT_INFO_T *ptr_portinfo);

/**
 * @brief Create an ethernet segment group
 *
 * This API is used to add or set an ethernet segment group, which is used to filter looped
 * multi-copy packets in NVO encapsulation(VxLAN/NVGRE/GENEVE) EVPN. EVPN needs some mechanisms for
 * split-horizon filtering to support all-active multihoming. MPLS encapsulation(including MPLS over
 * GRE) uses MPLS label to achieve this goal while network virtualization overlay
 * encapsulation(VxLAN/NVGRE/GENEVE) use local bias to implement it. Every NVE tracks the IP
 * address(es) associated with the other NVE(s) with which it has shared multihomed ESs. When the
 * NVE receives a multi-copy frame from the overlay network, it examines the source IP address in
 * the tunnel header (which corresponds to the ingress NVE) and filters out the frame on all local
 * interfaces connected to ESs that are shared with the ingress NVE. This is local bias mentioned
 * above.
 *
 * support_chip CL8600
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     flags          - Refers to CLX_L3T_EVPN_FLAGS_XX
 * @param [in]     ptr_esgroup    - The Pointer of ethernet segment group index
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter. "unit"  is invalid or index beyond the
 * range.
 * @return         CLX_E_ENTRY_IN_USE     - Entry is in use.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
clx_l3t_createEtherSegGroup(const UI32_T unit, const UI32_T flags, UI32_T *ptr_esgroup);

/**
 * @brief Destroy an ethernet segment group
 *
 * support_chip CL8600
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     esgroup    - The entry index
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter. "unit"  is invalid or index beyond the
 * range.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
clx_l3t_destroyEtherSegGroup(const UI32_T unit, const UI32_T esgroup);

/**
 * @brief Add ethernet segment group port member
 *
 * support_chip CL8600
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     esgroup            - The entry index
 * @param [in]     ptr_port_member    - The pointer of esgroup member port array
 * @param [in]     port_num           - Add esgroup member count
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter. "unit"  is invalid or index beyond the
 * range.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
clx_l3t_addEtherSegGroupPort(const UI32_T unit,
                             const UI32_T esgroup,
                             const CLX_PORT_T *ptr_port_member,
                             const UI32_T port_num);

/**
 * @brief Delete ethernet segment group port member
 *
 * support_chip CL8600
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     esgroup            - The entry index
 * @param [in]     ptr_port_member    - The pointer of esgroup member port array
 * @param [in]     port_num           - Delete esgroup member count
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter. "unit"  is invalid or index beyond the
 * range.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
clx_l3t_delEtherSegGroupPort(const UI32_T unit,
                             const UI32_T esgroup,
                             const CLX_PORT_T *ptr_port_member,
                             const UI32_T port_num);

/**
 * @brief Get ethernet segment group port member
 *
 * support_chip CL8600
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     esgroup            - The entry index
 * @param [out]    ptr_port_member    - The pointer of esgroup member port array
 * @param [out]    ptr_port_num       - The pointer of esgroup member count
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter. "unit"  is invalid or index beyond the
 * range.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
CLX_ERROR_NO_T
clx_l3t_getEtherSegGroupPort(const UI32_T unit,
                             const UI32_T esgroup,
                             CLX_PORT_T *ptr_port_member,
                             UI32_T *ptr_port_num);

#endif
