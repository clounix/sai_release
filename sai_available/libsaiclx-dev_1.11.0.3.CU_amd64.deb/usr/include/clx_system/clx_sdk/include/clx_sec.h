/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_sec.h
 * PURPOSE:
 *      Define the declaration for Security module in CLX SDK.
 *
 * NOTES:
 *
 */

#ifndef CLX_SEC_H
#define CLX_SEC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* STORM CONTROL */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* DoS check Action */
typedef enum {
    CLX_SEC_DOS_ACTION_DROP = 0,      /* DoS action drop */
    CLX_SEC_DOS_ACTION_DROP_COPY2CPU, /* DoS action drop cpu2cpu */
    CLX_SEC_DOS_ACTION_NONE,          /* DoS action none */
    CLX_SEC_DOS_ACTION_LAST
} CLX_SEC_DOS_ACTION_T;

/* Dos check item */
typedef enum {
    CLX_SEC_DOS_CHECK_ITEM_MAC_DA_EQ_SA = 0,     /* smac eq dmac */
    CLX_SEC_DOS_CHECK_ITEM_MAC_SA_INVALID,       /* smac invalid */
    CLX_SEC_DOS_CHECK_ITEM_MAC_ALL_ZEROS,        /* smac or dmac is all zeros */
    CLX_SEC_DOS_CHECK_ITEM_LEN_ENCAP_ERR,        /* L2 length encap error */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_MARTIAN_ADDR,    /* ipv4 martian address */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_LOOPBACK_ADDR,   /* ipv4 loopback address */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_CLASS_E_ADDR,    /* ipv4 class E address */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_MARTIAN_ADDR,    /* ipv6 martian address */
    CLX_SEC_DOS_CHECK_ITEM_TCP_NULL_SCAN,        /* tcp null scan */
    CLX_SEC_DOS_CHECK_ITEM_TCP_XMAS_SCAN,        /* tcp xmas scan */
    CLX_SEC_DOS_CHECK_ITEM_TCP_FIN_SCAN,         /* tcp fin scan */
    CLX_SEC_DOS_CHECK_ITEM_TCP_SYN_FIN_SCAN,     /* tcp syn fin scan */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_FRAG_ICMP,       /* ipv4 icmp fragment */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_FRAG_ICMP,       /* ipv6 icmp fragment */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_ICMP_SIZE_EN,    /* ipv4 icmp size enable*/
    CLX_SEC_DOS_CHECK_ITEM_IPV6_ICMP_SIZE_EN,    /* ipv6 icmp size enable */
    CLX_SEC_DOS_CHECK_ITEM_DIP_EQ_SIP,           /* dip eq sip */
    CLX_SEC_DOS_CHECK_ITEM_DPORT_EQ_SPORT,       /* l4 dport eq sport */
    CLX_SEC_DOS_CHECK_ITEM_UDP_FRAGGLE,          /* udp raggle */
    CLX_SEC_DOS_CHECK_ITEM_UDP_SNORK,            /* udp snork */
    CLX_SEC_DOS_CHECK_ITEM_UDP_BOMB,             /* udp bomb */
    CLX_SEC_DOS_CHECK_ITEM_TCP_TINY_FRAG_EN,     /* tcp tiny fragment enable */
    CLX_SEC_DOS_CHECK_ITEM_TCP_HDR_SIZE_EN,      /* tcp header size enable */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_FRAG_SIZE_EN,    /* ipv6 fragment size enable */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_ROUTING_TYPE_0,  /* ipv6 routing type 0 */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_FRG_ERR,         /* ipv4 fragment error */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_FRG_OFF_ERR,     /* ipv4 fragment offset error */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_FRG_OFF_ERR,     /* ipv6 fragment offset error */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_MIN_LEN_ERR,     /* ipv4 min length error */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_MIN_LEN_ERR,     /* ipv6 min length error */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_HDR_LEN_ERR,     /* ipv4 header length error */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_NXT_HDR_MAX_ERR, /* ipv6 next header max error */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_PT_MAX_ERR,      /* ipv4 protocol max error */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_SCTP_MIN_SZ,     /* ipv4 sctp min size */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_SCTP_MIN_SZ,     /* ipv6 sctp min size */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_SCTP_TINY_FRG,   /* ipv4 sctp tiny fragment */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_SCTP_TINY_FRG,   /* ipv6 sctp tiny fragment */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_UDP_MIN_SZ,      /* ipv4 udp min size */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_UDP_MIN_SZ,      /* ipv6 udp min size */
    CLX_SEC_DOS_CHECK_ITEM_IPV4_UDP_TINY_FRG,    /* ipv4 udp tiny fragment */
    CLX_SEC_DOS_CHECK_ITEM_IPV6_UDP_TINY_FRG,    /* ipv6 udp tiny fragment */
    CLX_SEC_DOS_CHECK_ITEM_SUPP_UL2UL,        /* [CL8600 not Support] suppress uplink to uplink */
    CLX_SEC_DOS_CHECK_ITEM_LAND_ATTACK_UDP,   /* [CL8570 CL8600] land attack udp */
    CLX_SEC_DOS_CHECK_ITEM_LAND_ATTACK_TCP,   /* [CL8570 CL8600] land attack tcp */
    CLX_SEC_DOS_CHECK_ITEM_ICMPV4_TYPE_CHECK, /* [CL8600 only] icmpv4 unknown type check */
    CLX_SEC_DOS_CHECK_ITEM_ICMPV6_TYPE_CHECK, /* [CL8600 only] icmpv6 unknown type check */
    CLX_SEC_DOS_CHECK_ITEM_LAST
} CLX_SEC_DOS_CHECK_ITEM_T;

/* Storm control type */
typedef enum {
    CLX_SEC_STORM_CTRL_TYPE_BC = 0,    /* Broadcast */
    CLX_SEC_STORM_CTRL_TYPE_UUC,       /* Unkown unicast */
    CLX_SEC_STORM_CTRL_TYPE_UMC,       /* Unknown multicast */
    CLX_SEC_STORM_CTRL_TYPE_L2UMC = 2, /* [CL8570 only] L2 unknown unicast */
    CLX_SEC_STORM_CTRL_TYPE_L2MC,      /* [CL8570 only] L2 multicast */
    CLX_SEC_STORM_CTRL_TYPE_L3UMC,     /* [CL8570 only] L3 unknown multicast */
    CLX_SEC_STORM_CTRL_TYPE_L3MC,      /* [CL8570 only] L3 multicast */
    CLX_SEC_STORM_CTRL_TYPE_LAST
} CLX_SEC_STORM_CTRL_TYPE_T;

/* Storm control rate number */
#define CLX_SEC_STORM_CTRL_RATE_NUM (6)

/* Source guard action */
typedef enum {
    CLX_SEC_SG_FAIL_ACTION_COPY2CPU = 0, /* source guard fail action copy2cpu */
    CLX_SEC_SG_FAIL_ACTION_DROP,         /* source guard fail action drop */
    CLX_SEC_SG_FAIL_ACTION_NONE,         /* source guard fail action none */
    CLX_SEC_SG_FAIL_ACTION_LAST
} CLX_SEC_SG_FAIL_ACTION_T;

/* DoS check item number */
#define CLX_SEC_DOS_CHECK_ITEM_NUM (CLX_SEC_DOS_CHECK_ITEM_LAST)
/* Security word width */
#define CLX_SEC_WORD_WIDTH (32)
/* DoS check item bitmap size */
#define CLX_SEC_DOS_CHECK_ITEM_BITMAP_SIZE \
    (((CLX_SEC_DOS_CHECK_ITEM_NUM - 1) / CLX_SEC_WORD_WIDTH) + 1)

/* DoS check item bitmap */
typedef UI32_T CLX_SEC_DOS_CHECK_ITEM_BITMAP_T[CLX_SEC_DOS_CHECK_ITEM_BITMAP_SIZE];

/* DoS check item bit set */
#define CLX_SEC_SET_DOS_ITEM_BIT(bitmap, dos_check_item)            \
    (((UI32_T *)(bitmap))[(dos_check_item) / CLX_SEC_WORD_WIDTH] |= \
     (0x1U << ((dos_check_item) % CLX_SEC_WORD_WIDTH)))
/* DoS check item bit clear */
#define CLX_SEC_CLR_DOS_ITEM_BIT(bitmap, dos_check_item)            \
    (((UI32_T *)(bitmap))[(dos_check_item) / CLX_SEC_WORD_WIDTH] &= \
     ~(0x1U << ((dos_check_item) % CLX_SEC_WORD_WIDTH)))
/* DoS check item bit check */
#define CLX_SEC_CHK_DOS_ITEM_BIT(bitmap, dos_check_item)           \
    (((UI32_T *)(bitmap))[(dos_check_item) / CLX_SEC_WORD_WIDTH] & \
     (0x1U << ((dos_check_item) % CLX_SEC_WORD_WIDTH)))

/* DoS check Port config */
typedef struct CLX_SEC_DOS_PORT_CONFIG_S {
    CLX_SEC_DOS_CHECK_ITEM_BITMAP_T dos_check_item;
} CLX_SEC_DOS_PORT_CONFIG_T;

/* DoS check global config */
typedef struct CLX_SEC_DOS_CONFIG_S {
    UI16_T max_icmpv4_size;    /* max icmpv4 size */
    UI16_T max_icmpv6_size;    /* max icmpv6 size */
    UI16_T min_ipv6_frag_size; /* min ipv6 fragment size */
    UI16_T min_tcp_size;       /* min tcp size */
    UI16_T min_tcp_frg_off;    /* min tcp fragment offset */
    UI16_T min_sctp_size;      /* min sctp size */
    UI16_T min_sctp_frg_off;   /* min sctp fragment offset */
    UI16_T min_udp_size;       /* min udp size */
    UI16_T min_udp_frg_off;    /* min udp fragment offset */
    UI16_T max_l4_prot;        /* max L4 protocol */

    CLX_SEC_DOS_ACTION_T
    dos_action[CLX_SEC_DOS_CHECK_ITEM_LAST]; /* [CL8600 not support] DoS check item action */
} CLX_SEC_DOS_CONFIG_T;

/* storm control entry */
typedef struct CLX_SEC_STORM_CTRL_ENTRY_S {
    UI32_T sc_rate;                                    /* storm control rate */

#define CLX_SEC_STORM_CTRL_ENTRY_FLAGS_BC    (1U << 0) /* broadcast */
#define CLX_SEC_STORM_CTRL_ENTRY_FLAGS_UUC   (1U << 1) /* unkown unicast */
#define CLX_SEC_STORM_CTRL_ENTRY_FLAGS_UMC   (1U << 2) /* unkown multicast */
#define CLX_SEC_STORM_CTRL_ENTRY_FLAGS_L2UMC (1U << 3) /* [CL8570 only] L2 unkown multicast */
#define CLX_SEC_STORM_CTRL_ENTRY_FLAGS_L2MC  (1U << 4) /* [CL8570 only] L2 multicast. */
#define CLX_SEC_STORM_CTRL_ENTRY_FLAGS_L3UMC (1U << 5) /* [CL8570 only] L3 unkown multicast. */
#define CLX_SEC_STORM_CTRL_ENTRY_FLAGS_L3MC  (1U << 6) /* [CL8570 only] L3 multicast. */

    UI32_T flags;                                      /* storm control entry flags */
} CLX_SEC_STORM_CTRL_ENTRY_T;

/* storm control */
typedef struct CLX_SEC_STORM_CTRL_S {
    CLX_SEC_STORM_CTRL_ENTRY_T sc_entry[CLX_SEC_STORM_CTRL_RATE_NUM]; /* storm control entry */

#define CLX_SEC_STORM_CTRL_FLAGS_PACKET_RATE (1U << 0)                /* packet rate */
#define CLX_SEC_STORM_CTRL_FLAGS_BC_EN       (1U << 1)                /* broadcast enable  */
#define CLX_SEC_STORM_CTRL_FLAGS_BC_CNT_EN   (1U << 2)                /* broadcast count enable */
#define CLX_SEC_STORM_CTRL_FLAGS_UUC_EN      (1U << 3)                /* unkown unicast enable */
#define CLX_SEC_STORM_CTRL_FLAGS_UUC_CNT_EN  (1U << 4) /* unkown unicast count enable */
#define CLX_SEC_STORM_CTRL_FLAGS_UMC_EN      (1U << 5) /* unkown multicast enable */
#define CLX_SEC_STORM_CTRL_FLAGS_UMC_CNT_EN  (1U << 6) /* unkown multicast count enable */
#define CLX_SEC_STORM_CTRL_FLAGS_L2UMC_EN    (1U << 5) /* [CL8570 only] L2 unkown multicast enable */
/* [CL8570 only] L2 unkown multicast count enable */
#define CLX_SEC_STORM_CTRL_FLAGS_L2UMC_CNT_EN (1U << 6)
#define CLX_SEC_STORM_CTRL_FLAGS_L2MC_EN      (1U << 7) /* [CL8570 only] L2 multicast enable */
/* [CL8570 only] L2 multicast count enable */
#define CLX_SEC_STORM_CTRL_FLAGS_L2MC_CNT_EN (1U << 8)
#define CLX_SEC_STORM_CTRL_FLAGS_L3UMC_EN    (1U << 9) /* [CL8570 only] L3 unkown multicast enable */
/* [CL8570 only] L3 unkown multicast count enable */
#define CLX_SEC_STORM_CTRL_FLAGS_L3UMC_CNT_EN (1U << 10)
#define CLX_SEC_STORM_CTRL_FLAGS_L3MC_EN      (1U << 11) /* [CL8570 only] L3 multicast enable */
/* [CL8570 only] L3 multicast count enable */
#define CLX_SEC_STORM_CTRL_FLAGS_L3MC_CNT_EN (1U << 12)
    UI32_T flags; /* storm control flags */
} CLX_SEC_STORM_CTRL_T;

/* storm control count */
typedef struct CLX_SEC_STORM_CTRL_CNT_S {
    UI64_T fwd_b_cnt;  /* byte count */
    UI64_T fwd_p_cnt;  /* packet count*/
    UI64_T drop_p_cnt; /* packet count*/
} CLX_SEC_STORM_CTRL_CNT_T;

/* source guard config */
typedef struct CLX_SEC_SG_CONFIG_S {
#define CLX_SEC_SG_PROPERTY_FLAGS_IP_SRC_PHY_LAG_CHECK (1U << 0) /* ip source port check */
#define CLX_SEC_SG_PROPERTY_FLAGS_IP_MAC_ADDR_CHECK    (1U << 1) /* ip mac address check */
#define CLX_SEC_SG_PROPERTY_FLAGS_IP_VID_BDID_CHECK    (1U << 2) /* ip bdid check */
/* [CL8600 not support]fcoe source port check */
#define CLX_SEC_SG_PROPERTY_FLAGS_FCOE_SRC_PHY_LAG_CHECK (1U << 3)
/* [CL8600 not support]fcoe mac address check */
#define CLX_SEC_SG_PROPERTY_FLAGS_FCOE_MAC_ADDR_CHECK (1U << 4)
/* [CL8600 not support]fcoe bdid check */
#define CLX_SEC_SG_PROPERTY_FLAGS_FCOE_VID_BDID_CHECK (1U << 5)

    UI32_T flags; /* check flags */
} CLX_SEC_SG_PROPERTY_T;

/* source guard entry */
typedef struct CLX_SEC_SG_ENTRY_S {
    UI32_T vrf_id;             /* [CL8600 not support] vrf id */
    union {
        CLX_IP_ADDR_T ip_addr; /* ip address */
        UI32_T fcoe_sid;       /* [CL8600 not support]fcoe sid */
    };

    CLX_MAC_T mac;                                /* source mac address */
    CLX_PORT_T port;                              /* port */
    UI32_T seg0;                                  /* segment 0 */
    UI32_T seg1;                                  /* segment 1 */
    UI32_T pppoe_ses_id;                          /* [CL8570 only] pppoe session id */

#define CLX_SEC_SG_ENTRY_FLAGS_IP_ENTRY (1U << 0) /* flag ip entry */
#define CLX_SEC_SG_ENTRY_FLAGS_MAC      (1U << 1) /* flag mac address */
#define CLX_SEC_SG_ENTRY_FLAGS_VLAN     (1U << 2) /* flag vlan */
#define CLX_SEC_SG_ENTRY_FLAGS_PORT     (1U << 3) /* flag port */
#define CLX_SEC_SG_ENTRY_FLAGS_PPPoE    (1U << 4) /* [CL8600 not support] flag pppoe */

    UI32_T flags;                                 /* field flags */
} CLX_SEC_SG_ENTRY_T;

/**
 * @brief set port DoS configuration. (add profile or record reference counter)
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - physical port ID.
 * @param [in]     ptr_entry    - DoS per port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_setDosPortConfig(const UI32_T unit,
                         const UI32_T port,
                         const CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry);

/**
 * @brief get port DoS configuration. (get the port DoS profile id, and get dos profile entry)
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - physical port ID.
 * @param [out]    ptr_entry    - DoS per port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_getDosPortConfig(const UI32_T unit,
                         const UI32_T port,
                         CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry);

/**
 * @brief set global DoS configuration. (update all profile)
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - DoS global configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_setDosConfig(const UI32_T unit, const CLX_SEC_DOS_CONFIG_T *ptr_entry);

/**
 * @brief get global DoS configuration. (get profile 0)
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_entry    - DoS global configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_getDosConfig(const UI32_T unit, CLX_SEC_DOS_CONFIG_T *ptr_entry);

/**
 * @brief This API is used to set storm control properties.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Port ID
 * @param [in]     ptr_entry    - The storm control properties for the specified port
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_setStormCtrlProperty(const UI32_T unit,
                             const UI32_T port,
                             const CLX_SEC_STORM_CTRL_T *ptr_entry);

/**
 * @brief This API is used to get storm control properties.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Port ID
 * @param [out]    ptr_entry    - The storm control properties for the specified port
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_getStormCtrlProperty(const UI32_T unit, const UI32_T port, CLX_SEC_STORM_CTRL_T *ptr_entry);

/**
 * @brief This API is used to get storm control counter information.
 *
 * support_chip all
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Port ID
 * @param [in]     type       - The storm control traffic type
 * @param [out]    ptr_cnt    - The storm control counter information for the specified traffic type
 * which will be provided by the specified port.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_getStormCtrlCnt(const UI32_T unit,
                        const UI32_T port,
                        const CLX_SEC_STORM_CTRL_TYPE_T type,
                        CLX_SEC_STORM_CTRL_CNT_T *ptr_cnt);

/**
 * @brief This API is used to set source guard properties.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Port ID
 * @param [in]     ptr_entry    - The source guard properties for the specified port
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_setSourceGuardProperty(const UI32_T unit,
                               const CLX_PORT_T port,
                               const CLX_SEC_SG_PROPERTY_T *ptr_entry);

/**
 * @brief This API is used to get source guard properties.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     port         - Port ID
 * @param [out]    ptr_entry    - The source guard properties for the specified port
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_getSourceGuardProperty(const UI32_T unit,
                               const CLX_PORT_T port,
                               CLX_SEC_SG_PROPERTY_T *ptr_entry);

/**
 * @brief This API is used to set source guard bridge domain properties.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     bdid         - Bridge Domain Id
 * @param [in]     ptr_entry    - The source guard properties for the Bridge Domain
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_setSourceGuardBDProperty(const UI32_T unit,
                                 const CLX_BRIDGE_DOMAIN_T bdid,
                                 const CLX_SEC_SG_PROPERTY_T *ptr_entry);

/**
 * @brief This API is used to get source guard bridge domain properties.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     bdid         - Bridge Domain Id
 * @param [out]    ptr_entry    - The source guard properties for the bridge domain
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_getSourceGuardBDProperty(const UI32_T unit,
                                 const CLX_BRIDGE_DOMAIN_T bdid,
                                 CLX_SEC_SG_PROPERTY_T *ptr_entry);

/**
 * @brief This API is used to add a source guard entry or set an existing source guard entry.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - The source guard entry which will be added or set. It should at
 * least be filled with the keys.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_TABLE_FULL       - Table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_addSourceGuardEntry(const UI32_T unit, const CLX_SEC_SG_ENTRY_T *ptr_entry);

/**
 * @brief This API is used to delete a source guard entry.
 *
 * Once the input source guard entry keys matches an existing source guard entry keys,
 * no matter the source guard entry contents are matched or not, the entry will be deleted.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - The source guard entry which will be deleted. It should at least
 * be filled with the keys.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory for this operation.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The entry doesn't exist.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_delSourceGuardEntry(const UI32_T unit, const CLX_SEC_SG_ENTRY_T *ptr_entry);

/**
 * @brief This API is used to get a source guard entry.
 *
 * support_chip all
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     ptr_entry    - The source guard entry which will be provided. It should be filled
 * with the keys, which are used to get the source guard entry.
 * @param [out]    ptr_entry    - The source guard entry which will be provided. It includes keys
 * and checked contents.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_getSourceGuardEntry(const UI32_T unit, CLX_SEC_SG_ENTRY_T *ptr_entry);

/**
 * @brief This API is used to set egress ports of an ingress port.
 *
 * For a given ingress port, the packet is allowed to be sent to the egress port only if the
 * corresponding bit of the port is set in the port bitmap.  If user wants to add an egress port
 * to the given ingress port, set the corresponding bit to 1 in the port_bitmap.  If user wants
 * to delete an egress port from the given ingress port, set the corresponding bit to 0 in the
 * port_bitmap. CL8600: All ports share the same egress port bitmap, and the egress bitmap is
 * updated with the latest parameters. When the egress bitmap is full, the configuration data will
 * be cleared. If user wants to isolate an egress port from the given ingress port, set the
 * corresponding bit to 0 in the port_bitmap.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Ingress port ID
 * @param [in]     port_bitmap    - Egress port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_setEgressPort(const UI32_T unit, const UI32_T port, const CLX_PORT_BITMAP_T port_bitmap);

/**
 * @brief This API is used to get egress ports of an ingress port.
 *
 * For a given ingress port, the packet is allowed to be sent to the egress port only
 * if the corresponding bit of the port is set to 1 in the port bitmap.
 *
 * support_chip all
 *
 * @param [in]     unit           - Device unit number
 * @param [in]     port           - Ingress port ID
 * @param [out]    port_bitmap    - Egress port bitmap
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
CLX_ERROR_NO_T
clx_sec_getEgressPort(const UI32_T unit, const UI32_T port, CLX_PORT_BITMAP_T port_bitmap);

#endif /* CLX_SEC_H */
