/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_srv6.h
 *
 * PURPOSE:
 *      It provides IPv6 Segment Route module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_SRV6_H
#define CLX_SRV6_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <clx_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_SRV6_FLAGS_WITH_ID (0x1U << 0) /* Use user input srv6_port to set parameter */

typedef enum {
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END = 0,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_T = CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_X = 1,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_B6_INSERT = 2,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_B6_ENCAPS = 3,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_BM = 4,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DX6 = 5,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DX4 = 6,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DT6 = 7,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DT4 = 8,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DT46 = 9,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DX2 = 10,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DX2V = 11,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DT2U = 12,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_DT2M = 13,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_B6_INSERT_RED = 14,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_B6_ENCAPS_RED = 15,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_NEXT_ONLY_CSID = 16,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_X_NEXT_ONLY_CSID = 17,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_RSVD = 18,
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_END_RSVD_MAX = 32
} CLX_SRV6_MYSID_ENTRY_BEHAVIOR_T;

typedef enum {
    CLX_SRV6_ENCAPS_BEH_H_ENCAPS = 0,
    CLX_SRV6_ENCAPS_BEH_H_ENCAPS_RED = 1,
    CLX_SRV6_ENCAPS_BEH_H_ENCAPS_L2 = 2, /* Inner is L2 Frame */
    CLX_SRV6_ENCAPS_BEH_H_ENCAPS_L2_RED = 3,
    CLX_SRV6_ENCAPS_BEH_H_INSERT = 4,    /* L2 is get from RWI, L3 is get from RWO */
    CLX_SRV6_ENCAPS_BEH_H_INSERT_RED = 5,
    CLX_SRV6_ENCAPS_BEH_END_B6_INSERT = 6,
    CLX_SRV6_ENCAPS_BEH_END_B6_ENCAPS = 7,
    CLX_SRV6_ENCAPS_BEH_END_BM = 8,
    CLX_SRV6_ENCAPS_BEH_END_B6_INSERT_RED = 9,
    CLX_SRV6_ENCAPS_BEH_END_B6_ENCAPS_RED = 10,
    CLX_SRV6_ENCAPS_BEH_LAST
} CLX_SRV6_ENCAPS_BEH_E;

typedef enum {
    CLX_SRV6_HASH_TYPE_BDO = 0,
    CLX_SRV6_HASH_TYPE_SRC_TEP,
    CLX_SRV6_HASH_TYPE_MGO,
    CLX_SRV6_HASH_TYPE_MSGO,
    CLX_SRV6_HASH_TYPE_MPLS_LSP,
    CLX_SRV6_HASH_TYPE_ALL,
    CLX_SRV6_HASH_TYPE_LAST
} CLX_SRV6_HASH_TYPE_T;

typedef struct CLX_SRV6_ENDPOINT_POLICY_S {
    UI16_T vrf;                       /* Key: Vrf id of the SRv6, default is zero */
    UI32_T seg_lbl;                   /* Key: Segment re-route domain label */
    CLX_L3_OUTPUT_TYPE_T output_type; /* Refer to CLX_L3_OUTPUT_TYPE_T */
    UI32_T output_id;                 /* Support ADJ and ECMP type */
    UI32_T acl_lbl;                   /* ACL label result */
#define CLX_SRV6_ENDPOINT_POLICY_FLAGS_DECREMENT_TTL (0x1U << 0) /* Decrement the SRv6 IPv6 TTL */
    UI32_T flags; /* Reference the CLX_SRV6_ENDPOINT_POLICY_FLAGS_XXX */
#define CLX_SRV6_ENDPOINT_POLICY_ATTR_DECREMENT_TTL (0x1ULL << 0)
#define CLX_SRV6_ENDPOINT_POLICY_ATTR_OUTPUT_TYPE   (0x1ULL << 1)
#define CLX_SRV6_ENDPOINT_POLICY_ATTR_ACL_LBL       (0x1ULL << 2)
#define CLX_SRV6_ENDPOINT_POLICY_ATTR_ALL           (0xFFFFFFFFFFFFFFFF)
    UI64_T attr_bitmap; /* Mark which fields to set */
} CLX_SRV6_ENDPOINT_POLICY_T;
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
// typedef struct CLX_SRV6_KEY_S
// {
//     CLX_IPV6_T               src_ipv6;            /* key: The source IP address used by srv6
//     port. */ UI16_T                   vrfo;                /* Key: Vrf id of the SRv6, default is
//     zero */ CLX_TUNNEL_TYPE_T        tunnel_type;         /* The SRv6 port type */
// } CLX_SRV6_KEY_T;

typedef struct CLX_SRV6_SIDLIST_S {
    UI8_T segments_left;
    CLX_IPV6_T segment_list[4];
} CLX_SRV6_SIDLIST_T;

typedef struct CLX_SRV6_LOCAL_S {
    CLX_PORT_T srv6_port;                /* Key: Srv6 tunnel port */
    CLX_IPV6_T src_ipv6;                 /* The source IP address of source node */
    UI32_T vrfo;                         /* Vrf id of the SRv6, default is zero */
    UI16_T default_inner_vid;            /* default inner VLAN */
    CLX_PORT_VLAN_TAG_T inner_vlan_tag;  /* Inner header's TPID setting */
    UI32_T dscp_to_phb_profile_id;       /* DSCP to PHB profile ID */
    UI32_T pcp_dei_to_phb_profile_id;    /* PCP/DEI to PHB profile ID */
    UI8_T default_pcp;                   /* The default PCP will be used if the native packet
                                          * is untagged, or the native VLAN tag is distrusted.
                                          */
    UI8_T default_dei;                   /* The default DEI will be used if the native packet
                                          * is untagged or the native VLAN tag is distrusted.
                                          */
    UI16_T default_bdid;                 /* if BD lookup miss, use default BD. */
    UI32_T sampling_rate;                /* Sampling rate */
    UI32_T sample_to_mir_session_id;     /* Sample packets to a mirror session */
    UI32_T mir_session_bitmap;           /* Mirror session ID bitmap */
    UI32_T meter_id;                     /* Meter ID */
    UI16_T l2_mtu_size;                  /* L2 mtu size */
    UI32_T lcl_acl_label;                /* Port ACL label label */
    UI32_T cnt_reg_id;                   /* Regular,Service counter ID */
    UI32_T cnt_dst_id;                   /* Distribution counter ID */
    CLX_PORT_ACCEPTABLE_TYPE_T drop_pkt; /* Acceptable Frame Type */
    CLX_SA_MISS_REASON_T sa_rsn;         /* CLX_SA_MISS_REASON_0/1 */
#define CLX_SRV6_LOCAL_FLAGS_TRUST_VID                                        \
    (0x1U << 0) /* 0: don't trust incoming  frame's VLAN, use default vlan ID \
                 * 1: trust incoming frame's VLAN id's, perform BD lookup by  \
                 *    using pkt vlan                                          \
                 */
#define CLX_SRV6_LOCAL_FLAGS_TRUST_PCP_DEI                                             \
    (0x1U << 1) /* 0: don't trust ingress frame's PCP/DEI, force to use dflt_{pcp,dei} \
                 * 1: if ingress frame has pcp/dei, use them for PHB                   \
                 */
#define CLX_SRV6_LOCAL_FLAGS_PRIO_TAG_ENABLE       (0x1U << 2) /* accept priority tagged frame */
#define CLX_SRV6_LOCAL_FLAGS_VLAN_NOT_ALW_2ND_ONLY (0x1U << 3) /* Not allow 2nd only */
#define CLX_SRV6_LOCAL_FLAGS_QOS_PHB_INNER \
    (0x1U << 4) /* For tunnel decap, use inner to PHB profile */
#define CLX_SRV6_LOCAL_FLAGS_DISABLE_BD_LEARN          \
    (0x1U << 5) /* disable the remote SRC MAC learning \
                 */
#define CLX_SRV6_LOCAL_FLAGS_SAMPLE_TO_MIR                         \
    (0x1U << 6) /* Sample packets to a mirror session              \
                 * set to 1 if sample packets to a mirror session. \
                 * set to 0 if sample packets to CPU.              \
                 */
#define CLX_SRV6_LOCAL_FLAGS_IPV4_SRC_GUARD_EN (0x1U << 7) /* IPv4 source guard enable */
#define CLX_SRV6_LOCAL_FLAGS_IPV6_SRC_GUARD_EN (0x1U << 8) /* IPv6 source guard enable */
#define CLX_SRV6_LOCAL_FLAGS_ECN_DISABLE       (0x1U << 9) /* 1: disable ECN service. */
#define CLX_SRV6_LOCAL_FLAGS_QOS_DNT_MODIFY                               \
    (0x1U << 10) /* 0: allow IGR to map tc/color to line PCP/DEI/EXP/DSCP \
                  * 1: skip IGR for tc/color to line PCP/DEI/EXP/DSCP map \
                  * Same as KEEP_INNER_QOS                                \
                  */
#define CLX_SRV6_LOCAL_FLAGS_DECAP_PROP_TTL \
    (0x1U << 11) /* Tunnel Decap but prop TTL to inner if need */
#define CLX_SRV6_LOCAL_FLAGS_QOS_TNL_UNIFORM (0x1U << 12) /* Copy outer qos value into inner */
#define CLX_SRV6_LOCAL_FLAGS_METER_VLD       (0x1U << 13) /* set to 1 if meter_id is applied. */
#define CLX_SRV6_LOCAL_FLAGS_CNT_REG_VLD     (0x1U << 14) /* set to 1 if cnt_id is applied. */
#define CLX_SRV6_LOCAL_FLAGS_CNT_DST_VLD     (0x1U << 15) /* set to 1 if dist_cnt_id is applied */
#define CLX_SRV6_LOCAL_FLAGS_GBP_ENABLE \
    (0x1U << 16)  /* set to 1 if write gbp tag into SRv6 or VXLAN-base when encap */
#define CLX_SRV6_LOCAL_FLAGS_WHICH_L2_SA_MISS_REASON \
    (0x1U << 17)  /* if l2 sa miss exception happens, choose either rsn0 or rsn1 to use */
#define CLX_SRV6_LOCAL_FLAGS_DSCP_TO_PHB_PROFILE_VALID  \
    (0x1U << 18)  /* Per srv6 local term.               \
                   * set to 1 if use DSCP to initialize \
                   * traffic class and color.           \
                   */
#define CLX_SRV6_LOCAL_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID  \
    (0x1U << 19)  /* Per srv6 local term.                  \
                   * set to 1 if use PCP/DEI to initialize \
                   * traffic class and color.              \
                   */
    UI32_T flags; /* Refer to CLX_SRV6_LOCAL_XXXXX */
#define CLX_SRV6_LOCAL_ATTR_TRUST_VID                 (0x1ULL << 0)
#define CLX_SRV6_LOCAL_ATTR_TRUST_PCP_DEI             (0x1ULL << 1)
#define CLX_SRV6_LOCAL_ATTR_PRIO_TAG_ENABLE           (0x1ULL << 2)
#define CLX_SRV6_LOCAL_ATTR_VLAN_NOT_ALW_2ND_ONLY     (0x1ULL << 3)
#define CLX_SRV6_LOCAL_ATTR_QOS_PHB_INNER             (0x1ULL << 4)
#define CLX_SRV6_LOCAL_ATTR_DISABLE_BD_LEARN          (0x1ULL << 5)
#define CLX_SRV6_LOCAL_ATTR_IPV4_SRC_GUARD_EN         (0x1ULL << 6)
#define CLX_SRV6_LOCAL_ATTR_IPV6_SRC_GUARD_EN         (0x1ULL << 7)
#define CLX_SRV6_LOCAL_ATTR_ECN_DISABLE               (0x1ULL << 8)
#define CLX_SRV6_LOCAL_ATTR_QOS_DNT_MODIFY            (0x1ULL << 9)
#define CLX_SRV6_LOCAL_ATTR_DECAP_PROP_TTL            (0x1ULL << 10)
#define CLX_SRV6_LOCAL_ATTR_QOS_TNL_UNIFORM           (0x1ULL << 11)
#define CLX_SRV6_LOCAL_ATTR_GBP_ENABLE                (0x1ULL << 12)
#define CLX_SRV6_LOCAL_ATTR_WHICH_L2_SA_MISS_REASON   (0x1ULL << 13)
#define CLX_SRV6_LOCAL_ATTR_DEFAULT_INNER_VID         (0x1ULL << 15)
#define CLX_SRV6_LOCAL_ATTR_INNER_VLAN_TAG            (0x1ULL << 16)
#define CLX_SRV6_LOCAL_ATTR_DSCP_TO_PHB_PROFILE_ID    (0x1ULL << 17)
#define CLX_SRV6_LOCAL_ATTR_PCP_DEI_TO_PHB_PROFILE_ID (0x1ULL << 18)
#define CLX_SRV6_LOCAL_ATTR_DEFAULT_PCP               (0x1ULL << 19)
#define CLX_SRV6_LOCAL_ATTR_DEFAULT_DEI               (0x1ULL << 20)
#define CLX_SRV6_LOCAL_ATTR_DEFAULT_BDID              (0x1ULL << 21)
#define CLX_SRV6_LOCAL_ATTR_SAMPLE                    (0x1ULL << 22)
#define CLX_SRV6_LOCAL_ATTR_MIR_SESSION_BITMAP        (0x1ULL << 23)
#define CLX_SRV6_LOCAL_ATTR_METER_ID                  (0x1ULL << 24)
#define CLX_SRV6_LOCAL_ATTR_L2_MTU_SIZE               (0x1ULL << 25)
#define CLX_SRV6_LOCAL_ATTR_LCL_ACL_LABEL             (0x1ULL << 26)
#define CLX_SRV6_LOCAL_ATTR_CNT_REG_ID                (0x1ULL << 27)
#define CLX_SRV6_LOCAL_ATTR_CNT_DST_ID                (0x1ULL << 28)
#define CLX_SRV6_LOCAL_ATTR_DROP_PKT                  (0x1ULL << 29)
#define CLX_SRV6_LOCAL_ATTR_SA_RSN                    (0x1ULL << 30)
#define CLX_SRV6_LOCAL_ATTR_ALL                       (0xFFFFFFFFFFFFFFFF)
    UI64_T attr_bitmap; /* Mark which fields to set */
} CLX_SRV6_LOCAL_T;

typedef struct CLX_SRV6_MYSID_ENTRY_S {
    UI16_T vrfo;             /* Key: Locator IPv6 address vrf */
    CLX_IPV6_T mysid;        /* Key: IPv6 Address for My SID */
    CLX_IPV6_T locator_mask; /* Key: Locator IP mask which is mysid locator part */
    CLX_SRV6_MYSID_ENTRY_BEHAVIOR_T end_beh_code; /* Endpoint behavior code*/
    UI32_T vpn_lbl; /* Srv6 VPN: Segment reoute domain label for END.D* code exclude END.DX2V */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_SRV6_DISABLE (0x1U << 0) /* Disable SRv6 */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_USID_FUNC_EN \
    (0x1U << 1) /* if enable, there would be a function field in usid */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_USID_ARG_EN \
    (0x1U << 2) /* if enable, there would be an argument field in usid */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_REDIR2CPU (0x1U << 3) /* 1: redirect to cpu */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_COC_NXTCSID \
    (0x1U << 4) /* 0: normal sid, 1: next sid is csid or coc flavor */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_PSP (0x1U << 5) /* PSP flavor */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_USP (0x1U << 6) /* USP flavor */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_USD (0x1U << 7) /* USD flavor */
#define CLX_SRV6_MYSID_ENTRY_FLAGS_USE_DST_TEP_2X \
    (0x1U << 8)   /* when tds_rslt_bdo.srv6_pkt_only=0 && global_profile.locator_len<=4 */
                  /* we use tds_tcam_dst_tep_2x, must set this flag*/
    UI32_T flags; /* Refer to CLX_SRV6_MYSID_ENTRY_FLAGS_XXX */
#define CLX_SRV6_MYSID_ENTRY_ATTR_SRV6_DISABLE (0x1ULL << 0)
#define CLX_SRV6_MYSID_ENTRY_ATTR_USID_FUNC_EN (0x1ULL << 1)
#define CLX_SRV6_MYSID_ENTRY_ATTR_USID_ARG_EN  (0x1ULL << 2)
#define CLX_SRV6_MYSID_ENTRY_ATTR_REDIR2CPU    (0x1ULL << 3)
#define CLX_SRV6_MYSID_ENTRY_ATTR_COC_NXTCSID  (0x1ULL << 4)
#define CLX_SRV6_MYSID_ENTRY_ATTR_PSP          (0x1ULL << 5)
#define CLX_SRV6_MYSID_ENTRY_ATTR_USP          (0x1ULL << 6)
#define CLX_SRV6_MYSID_ENTRY_ATTR_USD          (0x1ULL << 7)
#define CLX_SRV6_MYSID_ENTRY_ATTR_END_BEH_CODE (0x1ULL << 8)
#define CLX_SRV6_MYSID_ENTRY_ATTR_VPN_LBL      (0x1ULL << 9)
#define CLX_SRV6_MYSID_ENTRY_ATTR_ALL          (0xFFFFFFFFFFFFFFFF)
    UI64_T attr_bitmap; /* Mark which fields to set */
} CLX_SRV6_MYSID_ENTRY_T;

typedef enum {
    CLX_SRV6_SID_MODE_DISABLE = 0,
    CLX_SRV6_SID_MODE_SRV6 = 1,
    CLX_SRV6_SID_MODE_USID = 2,
    CLX_SRV6_SID_MODE_GSRV6 = 3,
    CLX_SRV6_SID_MODE_LAST
} CLX_SRV6_SID_MODE_E;

typedef struct CLX_SRV6_SID_GLOBAL_PROFILE_S {
    CLX_SRV6_SID_MODE_E mode;   /* Select srv6 parse mode */
    UI32_T locator_len;         /* Locator size in octets */
    UI32_T func_len;            /* Function size in octets， up to 4 bytes */
    UI32_T arg_len;             /* Argument size in octets, up to 2 bytes */
    UI32_T usid_block_len;      /* uSID block size in octets, up to 7 bytes */
    UI32_T usid_node_id_len;    /* uSID ID size in octets
                                 * uSID locator length equals block size plus node id size.
                                 */
    UI32_T gsrv6_prefix_len;    /* G-SRv6 prefix length in otects, up to 12 byte */
    UI32_T gsrv6_si_offset_len; /* Offset of the G-SRv6 SID index */
    CLX_MAC_T dx2v_mac;         /* Configure dst-mac for END.DX2V */
#define CLX_SRV6_SID_GLOBAL_PROFILE_FLAGS_ENCAPS_RED \
    (0x1U << 0)                 /* H.encaps with reduced encapsulation */
#define CLX_SRV6_SID_GLOBAL_PROFILE_FLAGS_INSERT_RED \
    (0x1U << 1)                 /* H.insert with reduced insertion */
    UI32_T flags;               /* Refer to CLX_SRV6_SID_GLOBAL_PROFILE_FLAGS. */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_MODE         (0x1ULL << 0) /* set mode */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_LOCATOR      (0x1ULL << 1) /* set locator_len */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_FUNC         (0x1ULL << 2) /* set func_len */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_ARG          (0x1ULL << 3) /* set arg_len */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_USID_BLOCK   (0x1ULL << 4) /* set usid_block_len */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_USID_NODE    (0x1ULL << 5) /* set usid_node_id_len */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_GSRV6_PREFIX (0x1ULL << 6) /* set gsrv6_prefix_len */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_GSRV6_SI_OFFSET                                       \
    (0x1ULL << 7)                                                   /* set gsrv6_si_offset_len \
                                                                     */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_DX2V_MAC (0x1ULL << 8)     /* set dx2v_mac */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_ENCAPS_RED \
    (0x1ULL << 9)  /* set CLX_SRV6_SID_GLOBAL_PROFILE_FLAGS_ENCAPS_RED */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_INSERT_RED \
    (0x1ULL << 10) /* set CLX_SRV6_SID_GLOBAL_PROFILE_FLAGS_INSERT_RED */
#define CLX_SRV6_SID_GLOBAL_PROFILE_ATTR_ALL (0xFFFFFFFFFFFFFFFF) /* Set all fields */
    UI64_T attr_bitmap;                                           /* Mark which fields to set */
} CLX_SRV6_SID_GLOBAL_PROFILE_T;

typedef struct CLX_SRV6_ENCAPS_S {
    CLX_PORT_T srv6_port;                 /* Key: Srv6 tunnel port */
    CLX_SRV6_SIDLIST_T sid_list;          /* Key: encaps or insert SR policys */
    CLX_IPV6_T encap_src_ip;              /* Key: encaps source IP */
    CLX_SRV6_ENCAPS_BEH_E encap_beh_code; /* SRv6 headend behavior or endpoint encap behavior */
    UI8_T outer_ttl;                      /* If the outer header TTL is not from the inner
                                           * header, assign the outer header TTL value.
                                           */
    UI8_T outer_dscp;                     /* If the outer header QOS is not from the inner
                                           * header, assign the outer header DSCP value.
                                           */
    UI8_T outer_ecn_ctrl;                 /* select from 2 mapping mode rfc6040, outer header enc.
                                           * 0: Compatibility mode
                                           * 1: Normal mode
                                           */
    UI32_T sampling_rate;                 /* Sampling rate */
    UI32_T sample_to_mir_session_id;      /* Sample packets to a mirror session */
    UI32_T mir_session_bitmap;            /* Mirror session ID bitmap */
    UI32_T meter_id;                      /* Meter ID */
    UI32_T cnt_reg_id;                    /* Regular,Service counter ID */
    UI32_T cnt_dst_id;                    /* Distribution counter ID */
    UI32_T lcl_acl_label;                 /* ACL grouping label */
    UI16_T s_tpid;                        /* Service vlan TPID */
    UI16_T c_tpid;                        /* Customer vlan TPID */
    UI32_T phb_to_dscp_profile_id;        /* Profile ID to DSCP */
    UI32_T phb_to_pcp_dei_profile_id;     /* Profile ID to PCP_DEI */
    UI16_T l2_mtu_size;                   /* L2 mtu size */

#define CLX_SRV6_ENCAPS_FLAGS_UNIFORM_TTL \
    (0x1U << 0) /* 1: copy TTL from inner IP header; 0:  use specified ttl */
#define CLX_SRV6_ENCAPS_FLAGS_QOS_TNL_UNIFORM \
    (0x1U << 1) /* 1: copy dscp from inner frame; 0: use specified dscp*/
#define CLX_SRV6_ENCAPS_FLAGS_KEEP_ALL_VLAN (0x1U << 2) /* Set 1 to keep packet inner vlan*/
#define CLX_SRV6_ENCAPS_FLAGS_SAMPLE_TO_MIR                                                                \
    (0x1U << 3)                                         /* Sample packets to a mirror session              \
                                                         * set to 1 if sample packets to a mirror session. \
                                                         * set to 0 if sample packets to CPU.              \
                                                         */
#define CLX_SRV6_ENCAPS_FLAGS_SAMPLE_HIGH_LATENCY                                      \
    (0x1U << 4)                                         /* Sample high latency packets \
                                                         * set to 1 if enable.         \
                                                         */
#define CLX_SRV6_ENCAPS_FLAGS_PHB_TO_DSCP_PROFILE_VALID                                      \
    (0x1U << 5)                                         /* set to 1 if remark egress DSCP by \
                                                         * traffic class and color.          \
                                                         */
#define CLX_SRV6_ENCAPS_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID                                      \
    (0x1U << 6)                                         /* set to 1 if remark egress PCP/DEI by \
                                                         * traffic class and color.             \
                                                         */
#define CLX_SRV6_ENCAPS_FLAGS_METER_VLD   (0x1U << 7)   /* set to 1 if meter_id is applied. */
#define CLX_SRV6_ENCAPS_FLAGS_CNT_REG_VLD (0x1U << 8)   /* set to 1 if cnt_reg_idx is applied. */
#define CLX_SRV6_ENCAPS_FLAGS_CNT_DST_VLD (0x1U << 9)   /* set to 1 if cnt_dst_idx is applied. */
#define CLX_SRV6_ENCAPS_FLAGS_TNL_L2VPN                       \
    (0x1U << 10)  /* indicate encap keep L2 header for FWD_L3 \
                   */
#define CLX_SRV6_ENCAPS_FLAGS_GBP_ENABLE \
    (0x1U << 11)  /* Enable if write gbp tag into SRv6 or VXLAN-base when encap */
#define CLX_SRV6_ENCAPS_FLAGS_FLOWLABEL_FROM_INNER      \
    (0x1U << 12)  /* set to 1 if outer header flowlabel \
                   * value from inner header flowlabel. \
                   */
    UI32_T flags; /* Refer to CLX_SRV6_ENCAPS_FLAGS_XXX. */
#define CLX_SRV6_ENCAPS_ATTR_UNIFORM_TTL (0x1ULL << 0) /* set CLX_SRV6_ENCAPS_FLAGS_UNIFORM_TTL */
#define CLX_SRV6_ENCAPS_ATTR_QOS_TNL_UNIFORM \
    (0x1ULL << 1) /* set CLX_SRV6_ENCAPS_FLAGS_QOS_TNL_UNIFORM */
#define CLX_SRV6_ENCAPS_ATTR_KEEP_ALL_VLAN \
    (0x1ULL << 2) /* set CLX_SRV6_ENCAPS_FLAGS_KEEP_ALL_VLAN */
#define CLX_SRV6_ENCAPS_ATTR_TNL_L2VPN  (0x1ULL << 3) /* set CLX_SRV6_ENCAPS_FLAGS_TNL_L2VPN */
#define CLX_SRV6_ENCAPS_ATTR_GBP_ENABLE (0x1ULL << 4) /* set CLX_SRV6_ENCAPS_FLAGS_GBP_ENABLE */
#define CLX_SRV6_ENCAPS_ATTR_FLOWLABEL_FROM_INNER \
    (0x1ULL << 5) /* set CLX_SRV6_ENCAPS_FLAGS_FLOWLABEL_FROM_INNER */
#define CLX_SRV6_ENCAPS_ATTR_BEH_CODE       (0x1ULL << 6) /* set encap_beh_code */
#define CLX_SRV6_ENCAPS_ATTR_OUTER_TTL      (0x1ULL << 7) /* set outer_ttl */
#define CLX_SRV6_ENCAPS_ATTR_OUTER_DSCP     (0x1ULL << 8) /* set outer_dscp */
#define CLX_SRV6_ENCAPS_ATTR_OUTER_ECN_CTRL (0x1ULL << 9) /* set outer_ecn_ctrl */
#define CLX_SRV6_ENCAPS_ATTR_SAMPLE                                \
    (0x1ULL << 10) /* set sampling_rate, sample_to_mir_session_id, \
                    * CLX_SRV6_ENCAPS_FLAGS_SAMPLE_TO_MIR,         \
                    * CLX_SRV6_ENCAPS_FLAGS_SAMPLE_HIGH_LATENCY    \
                    */
#define CLX_SRV6_ENCAPS_ATTR_MIRROR_ID (0x1ULL << 11) /* set mir_session_bitmap */
#define CLX_SRV6_ENCAPS_ATTR_METER_ID \
    (0x1ULL << 12) /* set meter_id, CLX_SRV6_ENCAPS_FLAGS_METER_VLD */
#define CLX_SRV6_ENCAPS_ATTR_COUNTER_REG_ID \
    (0x1ULL << 13) /* set cnt_reg_id, CLX_SRV6_ENCAPS_FLAGS_CNT_REG_VLD */
#define CLX_SRV6_ENCAPS_ATTR_COUNTER_DST_ID \
    (0x1ULL << 14) /* set cnt_dst_id, CLX_SRV6_ENCAPS_FLAGS_CNT_DST_VLD */
#define CLX_SRV6_ENCAPS_ATTR_LCL_ACL_LABEL (0x1ULL << 15)      /* set lcl_acl_label */
#define CLX_SRV6_ENCAPS_ATTR_TPID          (0x1ULL << 16)      /* set s_tpid, c_tpid */
#define CLX_SRV6_ENCAPS_ATTR_PHB_TO_DSCP_PROFILE_ID                                                               \
    (0x1ULL << 17)                                             /* set phb_to_dscp_profile_id,                     \
                                                                * CLX_SRV6_ENCAPS_FLAGS_PHB_TO_DSCP_PROFILE_VALID \
                                                                */
#define CLX_SRV6_ENCAPS_ATTR_PHB_TO_PCP_DEI_PROFILE_ID                                                               \
    (0x1ULL << 18)                                             /* set phb_to_pcp_dei_profile_id,                     \
                                                                * CLX_SRV6_ENCAPS_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID \
                                                                */
#define CLX_SRV6_ENCAPS_ATTR_L2_MTU_SIZE  (0x1ULL << 19)       /* set l2_mtu_size */
#define CLX_SRV6_ENCAPS_ATTR_SEGMENT_LIST (0x1ULL << 20)       /* set sid_list */
#define CLX_SRV6_ENCAPS_ATTR_ENCAP_SRC_IP (0x1ULL << 21)       /* set encap_src_ip */
#define CLX_SRV6_ENCAPS_ATTR_ALL          (0xFFFFFFFFFFFFFFFF) /* Set all fields */
    UI64_T attr_bitmap;                                        /* Mark which fields to set */
} CLX_SRV6_ENCAPS_T;

typedef struct CLX_SRV6_NVO3_ROUTE_INFO_S {
    CLX_PORT_T srv6_port;             /* Key: Srv6 tunnel port */
    CLX_L3_OUTPUT_TYPE_T output_type; /* Refer to CLX_L3_OUTPUT_TYPE_T */
    UI32_T output_id;                 /* Support ADJ and ECMP type */
} CLX_SRV6_NVO3_ROUTE_INFO_T;

typedef struct CLX_SRV6_HASH_ACTION_S {
    BOOL_T hash_algo_murmur[4]; /* 0: GF16; 1: Murmur */
    UI32_T seed[4];             /* seed for Murmur or GF16 algorithm */
    UI32_T fac[4];              /* fac for GF16 algorithm */
    // #define CLX_SRV6_HASH_ACTION_ATTR_HASH_ALGO_MURMUR              (0x1ULL << 0)
    // #define CLX_SRV6_HASH_ACTION_ATTR_SEED                          (0x1ULL << 1)
    // #define CLX_SRV6_HASH_ACTION_ATTR_FAC                           (0x1ULL << 2)
    // #define CLX_SRV6_HASH_ACTION_ATTR_ALL                           (0xFFFFFFFFFFFFFFFF)
    // UI64_T                  attr_bitmap;                            /* Mark which fields to set
    // */
} CLX_SRV6_HASH_ACTION_T;

typedef CLX_ERROR_NO_T (*CLX_SRV6_PORT_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                        const CLX_PORT_T port,
                                                        void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_SRV6_LOCAL_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                         const CLX_SRV6_LOCAL_T *ptr_local,
                                                         void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_SRV6_MYSIDLOCATORLABEL_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                                     const UI32_T *ptr_locator_lbl,
                                                                     void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_SRV6_MYSIDENTRY_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_SRV6_MYSID_ENTRY_T *ptr_mysid_entry,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_SRV6_ENCAPS_TRAVERSE_FUNC_T)(const UI32_T unit,
                                                          const CLX_SRV6_ENCAPS_T *ptr_encaps,
                                                          void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_SRV6_ENDPOINTPOLICY_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy,
    void *ptr_cookie);

typedef CLX_ERROR_NO_T (*CLX_SRV6_NVO3_ROUTE_TRAVERSE_FUNC_T)(
    const UI32_T unit,
    const CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route,
    void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Create SRv6 port
 *
 * support_chip CL8600
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     flag        - Refers to CLX_SRV6_FLAGS_XXX
 * @param [out]    ptr_port    - Pointer to the generated SRv6 port
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_createPort(const UI32_T unit, const UI32_T flag, CLX_PORT_T *ptr_port);

/**
 * @brief Destroy SRv6 port
 *
 * support_chip CL8600
 *
 * @param [in]     unit    - Device unit number
 * @param [out]    port    - SRv6 port
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_destroyPort(const UI32_T unit, const CLX_PORT_T port);

/**
 * @brief Traverse all configured SRv6 port entries.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return    CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_traversePort(const UI32_T unit,
                      const CLX_SRV6_PORT_TRAVERSE_FUNC_T callback,
                      void *ptr_cookie);

/**
 * @brief Add a local entry for SRv6 port.
 *
 * This API is used to add a SRv6 local entry.
 * For detailed information of the SRv6 local entry, refer to CLX_SRV6_LOCAL_T.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_srv6_local    - The SRv6 local information will be added.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_addSrv6Local(const UI32_T unit, const CLX_SRV6_LOCAL_T *ptr_srv6_local);

/**
 * @brief Delete a local entry for SRv6 port
 *
 * This API is used to delete a SRv6 local entry.
 * For detailed information of the SRv6 local entry, refer to CLX_SRV6_LOCAL_T.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_srv6_local    - The SRv6 local information will be deleted.
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_delSrv6Local(const UI32_T unit, const CLX_SRV6_LOCAL_T *ptr_srv6_local);

/**
 * @brief Set a local entry for SRv6 port.
 *
 * This API is used to set a SRv6 local entry.
 * For detailed information of the SRv6 local entry, refer to CLX_SRV6_LOCAL_T.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_srv6_local    - The SRv6 local information will be set.
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_setSrv6Local(const UI32_T unit, const CLX_SRV6_LOCAL_T *ptr_srv6_local);

/**
 * @brief Get a local entry for SRv6 port.
 *
 * This API is used to get a SRv6 local entry.
 * For detailed information of the SRv6 local entry, refer to CLX_SRV6_LOCAL_T.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number
 * @param [out]    ptr_srv6_local    - The SRv6 local information will be obtained.
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_getSrv6Local(const UI32_T unit, CLX_SRV6_LOCAL_T *ptr_srv6_local);

/**
 * @brief Traverse all configured Srv6 local entries.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_traverseSrv6Local(const UI32_T unit,
                           const CLX_SRV6_LOCAL_TRAVERSE_FUNC_T callback,
                           void *ptr_cookie);

/**
 * @brief Add a SRv6 MySID entry.
 *
 * This API is used to add a SRv6 MySID entry.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     ptr_srv6_mysid_entry    - The SRv6 MySID entry will be added.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_addMySidEntry(const UI32_T unit, const CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

/**
 * @brief Delete a SRv6 MySID entry.
 *
 * This API is used to delete a SRv6 MySID entry.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     ptr_srv6_mysid_entry    - The SRv6 MySID entry will be deleted.
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_delMySidEntry(const UI32_T unit, const CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

/**
 * @brief Set a SRv6 MySID entry.
 *
 * This API is used to set a SRv6 MySID entry.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                    - Device unit number
 * @param [in]     ptr_srv6_mysid_entry    - The SRv6 MySID entry will be set.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_setMySidEntry(const UI32_T unit, const CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

/**
 * @brief Get a SRv6 MySID entry.
 *
 * This API is used to get a SRv6 MySID entry.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                    - Device unit number
 * @param [out]    ptr_srv6_mysid_entry    - The SRv6 MySID entry will be obtained.
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_getMySidEntry(const UI32_T unit, CLX_SRV6_MYSID_ENTRY_T *ptr_srv6_mysid_entry);

/**
 * @brief Traverse all configured SRv6 MySID entries.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_traverseMySidEntry(const UI32_T unit,
                            const CLX_SRV6_MYSIDENTRY_TRAVERSE_FUNC_T callback,
                            void *ptr_cookie);

/**
 * @brief Set SRv6 global register config.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     ptr_sid_prof  - The SRv6 global profile will be set
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_setSrv6SidGlobalProfile(const UI32_T unit,
                                 const CLX_SRV6_SID_GLOBAL_PROFILE_T *ptr_sid_prof);

/**
 * @brief Get SRv6 global register config.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [out]    ptr_sid_prof  - The SRv6 global profile will be obtained
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_getSrv6SidGlobalProfile(const UI32_T unit, CLX_SRV6_SID_GLOBAL_PROFILE_T *ptr_sid_prof);

/**
 * @brief Add a SRv6 encapsulation entry for Srv6 port.
 *
 * This API is used to add a SRv6 encap entry.
 * For detailed information of the SRv6 encap entry, refer to CLX_SRV6_ENCAPS_T.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_srv6_encaps   - The SRv6 encap information will be added.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_addEncaps(const UI32_T unit, const CLX_SRV6_ENCAPS_T *ptr_srv6_encaps);

/**
 * @brief Delete a SRv6 encapsulation entry for Srv6 port.
 *
 * This API is used to delete a SRv6 encap entry.
 * For detailed information of the SRv6 encap entry, refer to CLX_SRV6_ENCAPS_T.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_srv6_encaps   - The SRv6 encap information will be added.
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_delEncaps(const UI32_T unit, const CLX_SRV6_ENCAPS_T *ptr_srv6_encaps);

/**
 * @brief Set a SRv6 encapsulation entry for Srv6 port.
 *
 * This API is used to set a SRv6 encap entry.
 * For detailed information of the SRv6 encap entry, refer to CLX_SRV6_ENCAPS_T.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number
 * @param [in]     ptr_srv6_encaps   - The SRv6 encap information will be set.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_setEncaps(const UI32_T unit, const CLX_SRV6_ENCAPS_T *ptr_srv6_encaps);

/**
 * @brief Get a SRv6 encapsulation entry for Srv6 port.
 *
 * This API is used to get a SRv6 encap entry.
 * For detailed information of the SRv6 encap entry, refer to CLX_SRV6_ENCAPS_T.
 *
 * support_chip CL8600
 *
 * @param [in]     unit              - Device unit number
 * @param [out]    ptr_srv6_encaps   - The SRv6 encap information will be obtained.
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_getEncaps(const UI32_T unit, CLX_SRV6_ENCAPS_T *ptr_srv6_encaps);

/**
 * @brief Traverse all configured SRv6 encapsulation entries.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_traverseEncaps(const UI32_T unit,
                        const CLX_SRV6_ENCAPS_TRAVERSE_FUNC_T callback,
                        void *ptr_cookie);

/**
 * @brief Add a NVo3 route. If ECMP flag is set, add a NVo3 ECMP route.
 *
 * When user needs to set an IP packet forward from SRv6 port, it can be used
 * to set the IP packet which matches one route entry forwarded from a SRv6 port.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     ptr_srv6_nvo3_route    - The NVo3 route information to be added.
 *                                          For ECMP route, the NVo3 ECMP group ID needs to be
 *                                          specified.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_addNvo3Route(const UI32_T unit, const CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

/**
 * @brief Set a NVo3 route. If ECMP flag is set, set a NVo3 ECMP route.
 *
 * When user needs to set an IP packet forward from srv6 tunnel, it can be used
 * to set the IP packet which matches one route entry forwarded from a SRv6 port.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     ptr_srv6_nvo3_route    - The NVo3 route information to be added.
 *                                          For ECMP route, the NVo3 ECMP group ID needs to be
 *                                          specified.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_setNvo3Route(const UI32_T unit, const CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

/**
 * @brief Delete NVo3 route for SRv6 port.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     ptr_srv6_nvo3_route    - The NVo3 route information to be deleted
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_delNvo3Route(const UI32_T unit, const CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

/**
 * @brief Get a NVo3 route of SRV6 port.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                   - Device unit number
 * @param [in]     ptr_srv6_nvo3_route    - The key of NVo3 route information
 * @param [out]    ptr_srv6_nvo3_route    - The NVo3 route information to be obtained.
 *                                          If it is ECMP route, it will return the ECMP group ID.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input destination IP.
 */
CLX_ERROR_NO_T
clx_srv6_getNvo3Route(const UI32_T unit, CLX_SRV6_NVO3_ROUTE_INFO_T *ptr_srv6_nvo3_route);

/**
 * @brief Traverse all configured NVo3 route entries.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_traverseNvo3Route(const UI32_T unit,
                           const CLX_SRV6_NVO3_ROUTE_TRAVERSE_FUNC_T callback,
                           void *ptr_cookie);

/**
 * @brief Add a SRv6 endpoint policy.
 *
 * This API is used to add a SRv6 endpoint policy.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                        - Device unit number
 * @param [in]     ptr_srv6_endpoint_policy    - The SRv6 EndPointPolicy information will be added.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_addEndPointPolicy(const UI32_T unit,
                           const CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy);

/**
 * @brief Delete a SRv6 endpoint policy.
 *
 * This API is used to delete a SRv6 endpoint policy.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                        - Device unit number
 * @param [in]     ptr_srv6_endpoint_policy    - The SRv6 EndPointPolicy information will be
 * deleted.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_delEndPointPolicy(const UI32_T unit,
                           const CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy);

/**
 * @brief Set a SRv6 endpoint policy.
 *
 * This API is used to set a SRv6 endpoint policy.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                        - Device unit number
 * @param [in]     ptr_srv6_endpoint_policy    - The SRv6 EndPointPolicy information will be set.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_setEndPointPolicy(const UI32_T unit,
                           const CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy);

/**
 * @brief Get a SRv6 endpoint policy.
 *
 * This API is used to get a SRv6 endpoint policy.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                        - Device unit number
 * @param [out]    ptr_srv6_endpoint_policy    - The SRv6 EndPointPolicy information will be
 *                                               obtained.
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_getEndPointPolicy(const UI32_T unit, CLX_SRV6_ENDPOINT_POLICY_T *ptr_srv6_endpoint_policy);

/**
 * @brief Traverse all configured Srv6 endpoint policies.
 *
 * support_chip CL8600
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - input parameter of callback function
 * @param [out]    ptr_cookie    - output parameter of callback function
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_traverseEndPointPolicy(const UI32_T unit,
                                const CLX_SRV6_ENDPOINTPOLICY_TRAVERSE_FUNC_T callback,
                                void *ptr_cookie);

/**
 * @brief Add a SRv6 segment service.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     srv6_port    - SRv6 port
 * @param [in]     vpn_lbl      - SRv6 vpn label
 * @param [in]     ptr_srv      - The service infomation will be added.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_addSegService(const UI32_T unit,
                       const CLX_PORT_T srv6_port,
                       const UI32_T vpn_lbl,
                       const CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Delete a SRv6 segment service.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     srv6_port    - SRv6 port
 * @param [in]     vpn_lbl      - SRv6 vpn label
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_delSegService(const UI32_T unit, const CLX_PORT_T srv6_port, const UI32_T vpn_lbl);

/**
 * @brief Set a SRv6 segment service.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     srv6_port    - SRv6 port
 * @param [in]     vpn_lbl      - SRv6 vpn label
 * @param [in]     ptr_srv      - The service infomation will be set.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_setSegService(const UI32_T unit,
                       const CLX_PORT_T srv6_port,
                       const UI32_T vpn_lbl,
                       const CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Get a SRv6 segment service.
 *
 * support_chip CL8600
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     srv6_port    - SRv6 port
 * @param [in]     vpn_lbl      - SRv6 vpn label
 * @param [out]    ptr_srv      - The service infomation will be obtained.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
CLX_ERROR_NO_T
clx_srv6_getSegService(const UI32_T unit,
                       const CLX_PORT_T srv6_port,
                       const UI32_T vpn_lbl,
                       CLX_PORT_SEG_SRV_T *ptr_srv);

/**
 * @brief Set SRv6 HashAction information.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     hash_type            - SRv6 hash type
 * @param [in]     srv6_hash_action     - SRv6 hash action
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_setHashAction(const UI32_T unit,
                       const CLX_SRV6_HASH_TYPE_T hash_type,
                       const CLX_SRV6_HASH_ACTION_T *srv6_hash_action);

/**
 * @brief Get SRv6 HashAction information.
 *
 * support_chip CL8600
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     hash_type            - SRv6 hash type
 * @param [out]    srv6_hash_action     - SRv6 hash action
 * @return         CLX_ERROR_NO_T
 */
CLX_ERROR_NO_T
clx_srv6_getHashAction(const UI32_T unit,
                       const CLX_SRV6_HASH_TYPE_T hash_type,
                       CLX_SRV6_HASH_ACTION_T *srv6_hash_action);

#endif /* End of CLX_SRV6_H */
