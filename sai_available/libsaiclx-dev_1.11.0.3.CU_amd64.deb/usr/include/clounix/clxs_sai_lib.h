/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_LIB_H__)
#define __CLXS_LIB_H__


#define MAX_KEY_STR_LEN                 200
#define MAX_VALUE_STR_LEN               500
#define MAX_LIST_VALUE_STR_LEN          1000
#ifdef PATH_MAX
#undef PATH_MAX
#endif
#define PATH_MAX                        256
#define CLXS_SWITCH_SAI_CMD_BUF_SZ      (512)

#define CHECK_RET_FAIL_RETURN(ret, unlock, level, fmt, arg ...)  do {\
    if ((ret)!= SAI_STATUS_SUCCESS) \
    {\
        (void)(unlock);\
        CLXS_LOG_##level(__MODULE__, fmt" "#ret"=%d", ##arg, (ret));\
        return ret;\
    }\
}while (0)
#define CHECK_RET_ERR_RETURN(fmt, arg ...)  CHECK_RET_FAIL_RETURN(ret, (ret), ERR, fmt, ##arg)
#define CHECK_RET_ERR_CLEAR_RETURN(unlock, fmt, arg ...)  CHECK_RET_FAIL_RETURN(ret, unlock, ERR, fmt, ##arg)

#define CHECK_RC_FAIL_RETURN(rc, unlock, level, fmt, arg ...)  do {\
    if ((rc)!= CLX_E_OK) \
    {\
        (void)(unlock);\
        CLXS_LOG_##level(__MODULE__, fmt" - %s", ##arg, clx_error_getString(rc));\
        return CLXS_STATUS_TO_SAI(rc);\
    }\
}while (0)
#define CHECK_RC_ERR_RETURN(fmt, arg ...)  CHECK_RC_FAIL_RETURN(rc, (rc), ERR, fmt, ##arg)
#define CHECK_RC_ERR_CLEAR_RETURN(unlock, fmt, arg ...)  CHECK_RC_FAIL_RETURN(rc, unlock, ERR, fmt, ##arg)

#define CHECK_UNIT_ERR_RETURN(unit)  do {\
    if (!CLXS_IS_UNIT_VALID(unit))\
    {\
        CLXS_LOG_ERR(__MODULE__, "Invalid unit %d", unit);\
        return SAI_STATUS_INVALID_PARAMETER;\
    }\
}while (0)

#define CHECK_UNIT_ERR_VOID_RETURN(unit)  do {\
    if (!CLXS_IS_UNIT_VALID(unit))\
    {\
        CLXS_LOG_ERR(__MODULE__, "Invalid unit %d", unit);\
        return;\
    }\
}while (0)

#define IS_NON_ZERO_CLX_MAC(__clx_mac__)                          \
    (((__clx_mac__)[0]) || ((__clx_mac__)[1]) || ((__clx_mac__)[2]) ||    \
     ((__clx_mac__)[3]) || ((__clx_mac__)[4]) || ((__clx_mac__)[5]))

#define IS_NON_ZERO_CLX_IPV6(__clx_ipv6__)                        \
    (((__clx_ipv6__)[0])  || ((__clx_ipv6__)[1])  ||                      \
     ((__clx_ipv6__)[2])  || ((__clx_ipv6__)[3])  ||                      \
     ((__clx_ipv6__)[4])  || ((__clx_ipv6__)[5])  ||                      \
     ((__clx_ipv6__)[6])  || ((__clx_ipv6__)[7])  ||                      \
     ((__clx_ipv6__)[8])  || ((__clx_ipv6__)[9])  ||                      \
     ((__clx_ipv6__)[10]) || ((__clx_ipv6__)[11]) ||                      \
     ((__clx_ipv6__)[12]) || ((__clx_ipv6__)[13]) ||                      \
     ((__clx_ipv6__)[14]) || ((__clx_ipv6__)[15]))

#define ARRAY_SIZE(_x) (sizeof(_x) / sizeof(_x[0]))
/* API DECLARATIONS
 */
sai_status_t
_sai_lib_ipv4_to_str(
    sai_ip4_t       value,
    uint32_t        max_length,
    char            *ptr_value_str,
    int             *ptr_chars_written);

sai_status_t
_sai_lib_ipv6_to_str(
    sai_ip6_t       value,
    uint32_t        max_length,
    char            *ptr_value_str,
    int             *ptr_chars_written);
void
sai_lib_mac_to_str(
    _In_ sai_mac_t mac,
    _In_ uint32_t max_length,
    _Out_ char *key_str,
    _Out_ uint32_t *key_len);

sai_status_t
sai_lib_ip_prefix_to_str(
    _In_ sai_ip_prefix_t value,
    _In_ uint32_t max_length,
    _Out_ char *value_str);

sai_status_t
sai_lib_ip_addr_to_str(
    _In_ sai_ip_address_t value,
    _In_ uint32_t         max_length,
    _Out_ char            *value_str,
    _Out_ int             *chars_written);

sai_status_t
sai_lib_fillObjList(
    sai_object_id_t *data,
    uint32_t count,
    sai_object_list_t *list);

sai_status_t
sai_lib_fill_u32list(
    uint32_t *data,
    uint32_t count,
    sai_u32_list_t *list);

sai_status_t
sai_lib_fillS32List(
    int32_t *data,
    uint32_t count,
    sai_s32_list_t *list);

sai_status_t
sai_lib_fillVlanList(
    sai_vlan_id_t *data,
    uint32_t count,
    sai_vlan_list_t *list);

sai_status_t
sai_lib_fillAttrObjList(
    _In_ sai_object_list_t   *ptr_list_src,
    _Inout_ sai_object_list_t   *ptr_attr_list);

sai_status_t
sai_lib_refillObjList(
    _In_ const sai_object_list_t   *ptr_list_src,
    _Inout_ sai_object_list_t   *ptr_list_dst);

sai_status_t
sai_lib_refill_u32list(
    _In_ const sai_u32_list_t   *ptr_list_src,
    _Inout_ sai_u32_list_t   *ptr_list_dst);

#define CLXS_ACCEPT_TYPE_TO_DROPFLAGS(accept_type, drop_untag, drop_tag) \
{\
    (void) drop_untag;\
    (void) drop_tag;\
    drop_untag = (accept_type == CLX_PORT_ACCEPTABLE_TYPE_TAGGED)||(accept_type == CLX_PORT_ACCEPTABLE_TYPE_NONE);\
    drop_tag = (accept_type == CLX_PORT_ACCEPTABLE_TYPE_UNTAGGED)||(accept_type == CLX_PORT_ACCEPTABLE_TYPE_NONE);\
}

#define CLXS_DROPFLAGS_TO_ACCEPT_TYPE(drop_untag, drop_tag, accept_type) \
    (drop_untag)?((accept_type) = (drop_tag) ? CLX_PORT_ACCEPTABLE_TYPE_NONE: CLX_PORT_ACCEPTABLE_TYPE_TAGGED):\
        ((accept_type) = (drop_tag) ? CLX_PORT_ACCEPTABLE_TYPE_UNTAGGED: CLX_PORT_ACCEPTABLE_TYPE_ALL)
#define SAI_KEY_INIT_LED_FILE                     "SAI_INIT_LED_CONFIG_FILE"

void
sai_lib_pbm_to_str(
    CLX_PORT_BITMAP_T pbm,
    char* str);

sai_status_t
sai_lib_ip_addr_to_sdk(
    _In_ const sai_ip_address_t *sai_addr,
    _Out_ CLX_IP_ADDR_T *sdk_addr);

sai_status_t
sai_lib_sdk_ip_addr_to_sai(
    _In_ const CLX_IP_ADDR_T *sdk_addr,
    _Out_ sai_ip_address_t *sai_addr);

sai_status_t
sai_lib_ip_prefix_to_sdk(
    _In_ const sai_ip_prefix_t      *sai_prefix,
    _Out_ CLX_L3_IP_NETWORK_ADDR_T *sdk_prefix);

sai_status_t
sai_lib_sdk_ip_prefix_to_sai(
    _In_ const CLX_L3_IP_NETWORK_ADDR_T *sdk_prefix,
    _Out_ sai_ip_prefix_t               *sai_prefix);

sai_status_t
sai_lib_ipv4_len_to_ui32_mask(
    const uint32_t        len,
    uint32_t        *ptr_mask);

sai_status_t
sai_lib_ipv6_len_to_ui32_mask(
    const uint32_t        len,
    uint32_t        *ptr_mask);

I32_T sai_lib_ipAddressCmp(void *s, void *d);

bool sai_lib_ipAddressIsZero(sai_ip_address_t ipaddr);

CLX_ERROR_NO_T
sai_lib_getAvlFirstData(
    const CMLIB_AVL_HEAD_T  *ptr_head,
    void                    **pptr_first_data);

void sai_lib_trimString(C8_T *src_str);

sai_status_t
sai_lib_portObjList_to_portBitMap(
    uint32_t                            unit,
    sai_object_list_t                   port_objlist,
    CLX_PORT_BITMAP_T                   port_bitmap);

#endif /* __CLXS_LIB_H__ */
