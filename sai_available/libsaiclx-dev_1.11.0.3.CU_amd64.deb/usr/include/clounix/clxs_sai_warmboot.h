/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_WARMBOOT_H__)
#define __CLXS_WARMBOOT_H__

/* DATA TYPE DECLARATIONS
 */

/* API DECLARATIONS
 */
bool
clxs_wb_dataAllZero(
    const char *ptr_data,
    const uint32_t data_size);

sai_status_t
clxs_wb_saveArrayWithIdx(
    const uint32_t  length,
    const uint32_t  count,
    const void  *ptr_array,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clxs_wb_restoreArrayWithIdx(
    const uint32_t       length,
    const uint32_t       count,
    void    *ptr_array,
    const HAL_IO_OBJ_META_T *ptr_obj_meta);

sai_status_t
clxs_wb_restoreList(
    const UI32_T             length,
    const CMLIB_LIST_T       *ptr_list,
    const HAL_IO_OBJ_META_T  *ptr_obj_meta);

sai_status_t
clxs_wb_saveList(
    const UI32_T       length,
    const CMLIB_LIST_T *ptr_list,
    HAL_IO_OBJ_META_T  *ptr_obj_meta);

void
clxs_wb_destoryWbObjList(
    uint32_t    wbdb_obj_list_cnt,
    HAL_IO_OBJ_META_T   *wbdb_obj_list);

sai_status_t
clxs_wb_saveAvlTree(
    const uint32_t           length,
    const CMLIB_AVL_HEAD_T *ptr_avl,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clxs_wb_saveGeneralData(
    const uint32_t  length,
    const char  *ptr_data,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clxs_wb_nonvolatileToDb(
    _In_ uint32_t   *module_length,
    _In_ void   **module_data,
    _In_ uint32_t   module_ver,
    _Out_ HAL_IO_WB_DB_T  **pptr_db);

sai_status_t
clxs_wb_dbToNonvolatile(
    _In_ HAL_IO_WB_DB_T  *ptr_db,
    _In_ uint32_t   module_ver,
    _Out_ uint32_t  *module_length,
    _Out_ void  **module_data);

sai_status_t
clxs_wb_getWbObj(
    const HAL_IO_WB_DB_T *ptr_db,
    UI32_T               obj_id,
    HAL_IO_OBJ_META_T    *ptr_obj);

CLX_ERROR_NO_T
clxs_io_saveAvlTree(
    const CMLIB_AVL_HEAD_T *ptr_avl,
    CMLIB_AVL_TRAV_FUNC_T trav_func,
    HAL_IO_OBJ_META_T      *ptr_obj_meta);

CLX_ERROR_NO_T
clxs_io_restoreAvlTree(
    CMLIB_AVL_HEAD_T  *ptr_avl,
    CMLIB_AVL_TRAV_FUNC_T trav_func,
    HAL_IO_OBJ_META_T *ptr_obj_meta);

sai_status_t
clxs_wb_restoreHashTable(
    const UI32_T             length,
    const CMLIB_HASH_TBL_T   *ptr_hash_tbl,
    HAL_IO_OBJ_META_T        *ptr_obj_meta);

sai_status_t
clxs_wb_saveHashTable(
    const uint32_t           length,
    const CMLIB_HASH_TBL_T   *ptr_hash_tbl,
    HAL_IO_OBJ_META_T        *ptr_obj_meta);

#endif /* __CLXS_WARMBOOT_H__ */
