/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_SWITCH_H__)
#define __CLXS_SWITCH_H__

/* GLOBAL VARIABLE DECLARATIONS
 */

#define SAI_COLD_BOOT               0
#define SAI_WARM_BOOT               1
#define SAI_FAST_BOOT               2

#ifdef CLX_PFC_WD_TIMER_INTERVAL_EN
#define CLX_SWITCH_MAX_PFCWD_POLLING_INTERVAL   (100)
#define CLX_SWITCH_MIN_PFCWD_POLLING_INTERVAL   (1)
#endif

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    _CLXS_SWITCH_MAC = 0,
    _CLXS_DEFAULT_VXLAN_ROUTER_MAC
}SWITCH_MAC_TYPE;

typedef enum
{
    CLX_CFG_TYPE_EXTEND_DIAG_LOG_SEVERITY = CLX_CFG_TYPE_LAST + 1,
    CLX_CFG_TYPE_PORT_BREAKOUT_LANE_NUM_MAX,
    CLX_CFG_TYPE_EXTEND_SDK_LOG_SEVERITY,
    CLX_CFG_TYPE_EXTEND_ECMP_RH_HASH_SEED,
    CLX_CFG_TYPE_EXTEND_LAG_RH_HASH_SEED,
    CLX_CFG_TYPE_EXTEND_ECMP_FDL_THRESHOLD,
    CLX_CFG_TYPE_EXTEND_ECMP_FDL_PROBABILITY,
    CLX_CFG_TYPE_EXTEND_ECMP_MEMBERS_MAX_COUNT,
#ifdef CLX_TAM_MOD_ENABLE
    CLX_CFG_TYPE_EXTEND_MOD_PP_QUEUE_CIR,
    CLX_CFG_TYPE_EXTEND_MOD_TM_QUEUE_CIR,
#endif
    CLX_CFG_TYPE_EXTEND_LAST
}CLX_CFG_TYPE_EXTEND_T;

typedef sai_status_t (*SAI_MODULE_BACKUP_FUNC)(
    _In_ const uint32_t unit,
    _Out_ uint32_t* module_length,
    _Out_ void** module_data);

extern BOOL_T                           clxs_schedule_legacy;
extern const sai_switch_api_t           switch_api;
extern SAI_MODULE_BACKUP_FUNC           sai_module_backer[CLXS_API_MAX];
extern CLX_SEMAPHORE_ID_T               clxs_tm_mutex[CLXS_MAX_CHIP_NUM];
extern CLX_SEMAPHORE_ID_T               clxs_db_mutex[CLXS_MAX_CHIP_NUM];
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T switch_stats_capability_info;

#define SAI_REGISTER_WARM_BACKER(func)   do { sai_module_backer[__MODULE__] = func; } while (0)
#define SAI_IS_WARM_BOOT(unit)  (get_fake_warm_reboot() || clxs_switch_getBootType(unit) == SAI_WARM_BOOT)
#define SAI_IS_FAST_BOOT(unit)  (clxs_switch_getBootType(unit) == SAI_FAST_BOOT)
#define SAI_IS_WARM_DEINIT(unit)  clxs_switch_getDeinitType(unit)

#define CLXS_SWC_IPP_HASH_COEF_NUM   (24)
#define CLXS_SWC_IPP_HASH_TYPE_NUM   (6)

#define CLXS_TM_LOCK(unit)          sai_osal_mutex_lock(clxs_tm_mutex[unit])
#define CLXS_TM_UNLOCK(unit)        sai_osal_mutex_unlock(clxs_tm_mutex[unit])
#define CLXS_DB_LOCK(unit)          sai_osal_mutex_lock(clxs_db_mutex[unit])
#define CLXS_DB_UNLOCK(unit)        sai_osal_mutex_unlock(clxs_db_mutex[unit])

#ifdef CLX_TAM_MOD_ENABLE
#define CLXS_SWITCH_MOD_TM_STEERING_PORT_NUM   (4)
#define CLXS_SWITCH_MOD_INVALID_STEERING_PORT   (0xFFFFFFFF)
#endif

typedef struct
{
    sai_packet_action_t uuc;
    sai_packet_action_t umc;
    sai_packet_action_t bc;
} CLXS_SWITCH_FDB_MISS_ACTION_T;

typedef struct
{
    uint32_t    default_value[CLXS_SWC_IPP_HASH_COEF_NUM];
    uint32_t    config_value;
} CLXS_SWITCH_HASH_CONSTANT_T;


typedef struct CLXS_SWITCH_CB_S
{
    uint32_t                                        inited_num;
    uint32_t                                        unit_inited[CLXS_MAX_CHIP_NUM];
#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
    sai_switch_type_t                               switch_type[CLXS_MAX_CHIP_NUM];
#endif
    sai_switch_shutdown_request_notification_fn     srn_fn[CLXS_MAX_CHIP_NUM];
    sai_switch_state_change_notification_fn         scn_fn[CLXS_MAX_CHIP_NUM];
    void*                                             fdb_event_ntf_fn[CLXS_MAX_CHIP_NUM];
    void*                                             port_state_ntf_fn[CLXS_MAX_CHIP_NUM];
    void*                                             packet_event_ntf_fn[CLXS_MAX_CHIP_NUM];
    void*                                             queue_pfc_ntf_fn[CLXS_MAX_CHIP_NUM];
    sai_mac_t                                       switch_mac[CLXS_MAX_CHIP_NUM];
    sai_mac_t                                       default_vxlan_router_mac[CLXS_MAX_CHIP_NUM];
    CLXS_SWITCH_FDB_MISS_ACTION_T                    fdb_action[CLXS_MAX_CHIP_NUM];
    uint32_t                                        profile_id[CLXS_MAX_CHIP_NUM];
    char                                            sdk_cfg_path[SAI_MAX_FIRMWARE_PATH_NAME_LEN];
    char                                            sdk_led_cfg_path[SAI_MAX_FIRMWARE_PATH_NAME_LEN];
    char                                            fw_path[CLXS_MAX_CHIP_NUM][SAI_MAX_FIRMWARE_PATH_NAME_LEN];
    bool                                            uninit_data_plane_on_removal[CLXS_MAX_CHIP_NUM];
    bool                                            pre_shutdown[CLXS_MAX_CHIP_NUM];
    bool                                            restart_warm[CLXS_MAX_CHIP_NUM];
    bool                                            restart_warm_only[CLXS_MAX_CHIP_NUM];
    uint32_t                                      boot_type[CLXS_MAX_CHIP_NUM];
    bool                                            warm_recover[CLXS_MAX_CHIP_NUM];
    CLXS_SWITCH_HASH_CONSTANT_T                     hash_constant[CLXS_MAX_CHIP_NUM][CLXS_SWC_IPP_HASH_TYPE_NUM];
    char*                                          warm_read_filename[CLXS_MAX_CHIP_NUM];
    char*                                          warm_write_filename[CLXS_MAX_CHIP_NUM];
    char*                                          warm_sdk_filename[CLXS_MAX_CHIP_NUM];
    FILE*                                          warm_sdk_file[CLXS_MAX_CHIP_NUM];
    void*                                          warm_data[CLXS_MAX_CHIP_NUM];
    uint32_t                                       init_connect[CLXS_MAX_CHIP_NUM];
    uint32_t                                       hash_algorithm[CLXS_MAX_CHIP_NUM][CLXS_SWC_IPP_HASH_TYPE_NUM];
    uint32_t                                       fdb_aging_time[CLXS_MAX_CHIP_NUM];
#ifdef CLX_ECMP_FASTLINK_CONVERGE_EN
    bool                                           ecmp_fast_converge[CLXS_MAX_CHIP_NUM];
#endif

    bool                                           hash_symmetric[CLXS_MAX_CHIP_NUM][CLXS_SWC_IPP_HASH_TYPE_NUM];
    uint32_t                                       ecmp_members_max_count[CLXS_MAX_CHIP_NUM];
#ifdef CLX_TAM_MOD_ENABLE
    sai_object_list_t                              tamlist[CLXS_MAX_CHIP_NUM];      /**tam mod use*/
    uint32_t                                       mod_tm_steering_port[CLXS_MAX_CHIP_NUM][CLXS_SWITCH_MOD_TM_STEERING_PORT_NUM];
#endif
    sai_object_id_t                                 qosmap_oid[CLXS_MAX_CHIP_NUM][CLXS_QOSMAP_TYPES_MAX];
} CLXS_SWITCH_CB_T;

/* API DECLARATIONS
 */

extern CLXS_SWITCH_CB_T _clxs_switch_cb;

#define CLXS_SWITCH_MAX_TEMP_SENSORS(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->dev.temp_sensor_num):0)
#define CLXS_SWITCH_SUPPORT_HW_STATIC_MAC_MOVE(__unit__)           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->dev.hw_static_mac_move):0)

/* API DECLARATIONS
 */
#if 0
extern UI32_T      _ext_aml_forced_dev_id;
extern void dcc_lamp_setSrvPort(UI32_T  srv_port);
int clxs_switch_init_netif(
    _In_ const uint32_t              unit);
#endif

sai_status_t
clxs_switch_getUnitId(
    _In_ sai_object_id_t        switch_id,
    _Out_ uint32_t              *ptr_unit_id);

sai_status_t
clxs_switch_getFdbMissAction(
    _In_ const uint32_t             unit,
    _In_ const CLXS_SRV_BUM_TYPE_T   type,
    _Out_ sai_packet_action_t       *ptr_action);

sai_status_t
clxs_switch_getCfgValue(
    _In_ const UI32_T unit,
    _In_ const CLX_CFG_TYPE_T in_cfg_type,
    _Inout_ CLX_CFG_VALUE_T * ptr_in_value);

bool
clxs_switch_get_restart_warm_only(
    uint32_t unit);

const char *
clxs_switch_get_module_name(
    uint32_t index);

sai_status_t
clxs_switch_getSrcMac(
    _In_ const uint32_t              unit,
    _In_ const uint32_t              type,
    _Out_ sai_mac_t                 *mac);

sai_status_t
clxs_switch_getDefaultVxlanRouterMac(
    _In_ const uint32_t              unit,
    _Out_ sai_mac_t                 *mac);

uint32_t
clxs_switch_getUnitInited(
    uint32_t unit);

sai_status_t
clxs_get_switch_count(
    _Out_ uint32_t *count);

void
clxs_switch_printf(
    const void      *ptr_buf,
    UI32_T          len);

const char *
clxs_switch_get_profile(
    _In_ const UI32_T   unit,
    _In_ char   *profile_name);

sai_status_t
clxs_switch_initModule(
    _In_ uint32_t       unit);

CLX_ERROR_NO_T
_clxs_switch_getCfgValue(
    const UI32_T            unit,
    const UI32_T            in_cfg_type,
    CLX_CFG_VALUE_T         *ptr_in_value);

BOOL_T _clxs_switch_checkSDKDefaultConfigEnable(
    const UI32_T            unit,
    const UI32_T            defalut_config);

sai_status_t
clxs_sai_restore_module_data(
    uint32_t unit,
    char*filename,
    uint32_t *length);

extern sai_status_t clxs_sai_get_module_warm_data(
    _In_ sai_api_t module,
    _In_ uint32_t unit,
    _Out_ uint32_t* length,
    _Out_ void** data);

uint32_t clxs_switch_getBootType(
    uint32_t unit);

bool clxs_switch_getDeinitType(
    uint32_t unit);

void set_fake_warm_reboot(
    bool warm);

int get_fake_warm_reboot(void);

sai_status_t
clxs_switch_getEcmpRhEnable(
    _In_ const uint32_t     unit,
    _In_ bool               *rh_enable);

#ifdef CLX_ECMP_FASTLINK_CONVERGE_EN
bool
clxs_switch_getEcmpFastConvergeEnable(
    _In_ const uint32_t             unit);
#endif

sai_status_t clxs_switch_get_enum_values_capability(
    _In_ uint32_t unit,
    _In_ sai_attr_id_t attr_id,
    _Inout_ sai_s32_list_t *enum_values_capability);

sai_status_t
clxs_switch_getHashSymEnable(
    _In_ uint32_t                  unit,
    _In_ uint32_t                  hash_engine,
    _Out_ bool                     *enable);

uint32_t
clxs_switch_get_boot_type(
    _In_ const UI32_T   unit);

sai_status_t clxs_switch_getEcmpMemberCounts(
        _In_   uint32_t   unit,
        _Out_  uint32_t*  ecmp_count);

#ifdef CLX_TAM_MOD_ENABLE
bool clxs_switch_check_port_is_steering_port(
    UI32_T    unit,
    UI32_T    port
);

#define CLXS_PORT_IS_MOD_STEERING_PORT(__unit__, __port__)                  \
    if (clxs_switch_check_port_is_steering_port(__unit__, __port__))

sai_status_t clxs_switch_get_streeing_ports(
    _In_ uint32_t unit,
    _Inout_ uint32_t *steering_port);
#endif

sai_status_t
_clxs_switch_shutdownRequestNotification(
    _In_ uint32_t       unit);

sai_status_t clxs_switch_getQosmap(
    _In_    uint32_t            unit,
    _In_    sai_qos_map_type_t  type,
    _Out_   sai_object_id_t     *ptr_qosmap_oid);

#endif /* __CLXS_SWITCH_H__ */
