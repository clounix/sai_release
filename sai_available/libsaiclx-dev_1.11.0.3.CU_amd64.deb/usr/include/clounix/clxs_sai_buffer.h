/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_BUFFER_H__)
#define __CLXS_BUFFER_H__

#define CLXS_BUF_ING_POOL_NUM       (10)
#define CLXS_BUF_EGR_POOL_NUM       (10)
#define CLXS_BUF_POOL_NUM           (CLXS_BUF_ING_POOL_NUM + CLXS_BUF_ING_POOL_NUM)
#define CLXS_BUF_MAX_PROFILE_NUM    (128)

#define CLXS_BUF_UC_QUEUE_NUM(unit)             (CLXS_QUEUE_UC_NUM(unit))
#define CLXS_BUF_MC_QUEUE_NUM(unit)             (CLXS_QUEUE_MC_NUM(unit))
#define CLXS_BUF_IGR_PG_NUM_PER_PORT(unit)      (CLXS_QUEUE_LEGACY_NUM(unit))
#define CLXS_BUF_EGR_QUEUE_NUM_PER_PORT(unit)   (CLXS_BUF_UC_QUEUE_NUM(unit) + CLXS_BUF_MC_QUEUE_NUM(unit))

#define CLXS_BUF_HW_PROFILE_MAX_NUM(unit) ((CLXS_BUF_EGR_PROFILE_NUM(unit) > CLXS_BUF_IGR_PROFILE_NUM(unit)) ? \
                                        CLXS_BUF_EGR_PROFILE_NUM(unit) : CLXS_BUF_IGR_PROFILE_NUM(unit))
#define CLXS_BUF_HW_PROFILE_START_ID    (0)
#define CLXS_BUFFER_HW_PROFILE_PTR(__unit__, __hw_type__, __idx__)    \
                                                    ((CLXS_BUFFER_HW_PROF_DB_T *)(_clxs_buffer_cb[unit]->buffer_hw_profiles + \
                                                        (__hw_type__ * CLXS_BUF_HW_PROFILE_MAX_NUM(__unit__) + __idx__)))



#define CLXS_BUF_POOL(unit, id) (_clxs_buffer_cb[unit]->buffer_pools[id])
#define CLXS_BUF_PG_OBJ(_unit_, _port_, _index_)    _clxs_buffer_cb[_unit_]->clxs_port_db[_port_].pg[_index_]

typedef enum _sai_buffer_alpha_bounds_t {
    SAI_BUFFER_ALPHA_1_128 = -7,
    SAI_BUFFER_ALPHA_1_64  = -6,
    SAI_BUFFER_ALPHA_1_32  = -5,
    SAI_BUFFER_ALPHA_1_16  = -4,
    SAI_BUFFER_ALPHA_1_8   = -3,
    SAI_BUFFER_ALPHA_1_4   = -2,
    SAI_BUFFER_ALPHA_1_2   = -1,

    SAI_BUFFER_ALPHA_1  = 0,
    SAI_BUFFER_ALPHA_2  = 1,
    SAI_BUFFER_ALPHA_4  = 2,
    SAI_BUFFER_ALPHA_8  = 3,
    SAI_BUFFER_ALPHA_16 = 4,
    SAI_BUFFER_ALPHA_32 = 5,
    SAI_BUFFER_ALPHA_64 = 6,
} sai_buffer_alpha_bounds_t;

typedef enum _CLXS_BUFFER_HW_TYPE_T
{
    PORT_BUFF_HW_TYPE_START,
    PORT_BUFF_HW_TYPE_IGR_PORT = PORT_BUFF_HW_TYPE_START,
    PORT_BUFF_HW_TYPE_IGR_QUEUE,
    PORT_BUFF_HW_TYPE_EGR_PORT,
    PORT_BUFF_HW_TYPE_EGR_QUEUE,
    PORT_BUFF_HW_TYPE_END
} CLXS_BUFFER_HW_TYPE_T;

typedef enum _CLXS_BUFFER_PORT_TYPE_T
{
    PORT_BUFF_TYPE_INGRESS,
    PORT_BUFF_TYPE_EGRESS,
    PORT_BUFF_TYPE_PG,
    PORT_BUFF_TYPE_QUEUE
} CLXS_BUFFER_PORT_TYPE_T;

typedef struct _CLXS_BUFFER_POOL_ATTR_T
{
    uint32_t                    clxs_pool_id;
    /*size in bytes*/
    uint64_t                    pool_size;
    uint64_t                    pool_xoff_size;
    sai_buffer_pool_type_t      pool_type;
    sai_buffer_pool_threshold_mode_t pool_mode;
    sai_object_id_t             wred_profile_id;
} CLXS_BUFFER_POOL_ATTR_T;

typedef struct _CLXS_BUFFER_MAX_THD_T {
    sai_buffer_profile_threshold_mode_t mode;
    union {
        sai_int8_t   alpha;
        sai_uint64_t static_th;
    } max;
} CLXS_BUFFER_MAX_THD_T;

typedef struct _CLXS_BUFFER_HW_PROF_DB_T {
    bool        is_valid;
    uint32_t    hw_profile_id;
    uint32_t    ref_cnt;
} CLXS_BUFFER_HW_PROF_DB_T;

typedef struct _CLXS_BUFFER_PROF_DB_T {
    sai_object_id_t            sai_pool;
    uint64_t                   pool_size;
    uint64_t                   reserved_size;
    CLXS_BUFFER_MAX_THD_T      shared_max;
    uint64_t                   xon;
    uint64_t                   xon_offset;
    uint64_t                   xoff;
    uint64_t                   headroom;
    uint32_t                   hw_profile_id;
    CLXS_BUFFER_HW_TYPE_T      hw_type;
} CLXS_BUFFER_PROF_DB_T;

typedef struct _CLXS_BUFFER_PROF_CB_T {
    CLXS_BUFFER_PROF_DB_T       *ptr_db;
    bool                       is_valid;
} CLXS_BUFFER_PROF_CB_T;


typedef struct _CLXS_PG_DB_T {
    bool                        is_valid;
    sai_object_id_t             object_id;
#if SAI_API_VERSION >= SAI_VERSION(1,5,0)    /*micro-burst begin*/
    sai_object_list_t             tamlist;
#endif/*micro-burst end*/
} CLXS_PG_DB_T;


typedef struct _CLXS_PORT_TYPE_DB_T {
    CLXS_PG_DB_T *  pg;
} CLXS_PORT_TYPE_DB_T;

typedef struct _CLXS_BUFFER_POOL_DB_T {
    bool                                is_valid;
    CLXS_BUFFER_POOL_ATTR_T             pool_attr;
} CLXS_BUFFER_POOL_DB_T;

typedef struct _CLXS_BUF_DB_T {
    /*
     *  The size of the array is 1 + MAX_BUFFER_PROFILE.
     *  index[0] is a sentinel entry.
     */
    CLXS_BUFFER_PROF_CB_T       buffer_profiles[1 + CLXS_BUF_MAX_PROFILE_NUM];
    uint32_t                    default_igr_lossy_prof_id;
    uint32_t                    default_igr_lossless_prof_id;
    uint32_t                    default_egr_lossy_prof_id;
    CLXS_BUFFER_HW_PROF_DB_T    *buffer_hw_profiles;
    /*
     *  To contain indexes of buffer profiles.
     */
    uint32_t                    *profile_index_in_target;
    uint32_t                    *profile_igr_index;
    CLXS_BUFFER_POOL_DB_T       buffer_pools[CLXS_BUF_POOL_NUM];
    CLXS_PORT_TYPE_DB_T         clxs_port_db[CLXS_MAX_PORT_NUM];
    CLXS_PG_DB_T                *port_pg_db_ptr;
    /*must be at the end of the struct*/
} CLXS_BUF_DB_T;

extern const sai_buffer_api_t           buffer_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T ing_pg_stats_capability_info;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T buffer_pool_stats_capability_info;
extern CLXS_BUF_DB_T *_clxs_buffer_cb[CLXS_MAX_CHIP_NUM];

sai_status_t
clxs_buffer_set_profile_to_obj(
    _In_ CLXS_BUFFER_PORT_TYPE_T port_buff_type,
    _In_ sai_object_id_t object_id,
    _In_ sai_object_id_t profile);

sai_status_t
clxs_buffer_get_port_profile_list(
    _In_ CLXS_BUFFER_PORT_TYPE_T port_buff_type,
    _In_ sai_object_id_t    object_id,
    _Inout_ sai_attribute_value_t       *ptr_value);

sai_status_t
clxs_buffer_get_port_pool_list(
    _In_ sai_object_id_t    object_id,
    _Inout_ sai_attribute_value_t       *ptr_value);

sai_status_t
clxs_buffer_init(uint32_t unit);

sai_status_t
clxs_buffer_addDefaultProflieToPort(
    _In_ uint32_t unit,
    _In_ uint32_t port);

sai_status_t
clxs_buffer_delProfileFromPort(
    _In_ uint32_t unit,
    _In_ uint32_t port);

sai_status_t
clxs_buffer_deinit(uint32_t unit);

sai_status_t
clxs_buffer_getPriorityGroupCount(
    _In_ sai_object_id_t port_object_id,
    _Out_ uint32_t *ptr_count);

sai_status_t
clxs_buffer_getPriorityGroupList(
    _In_ sai_object_id_t port_object_id,
    _Out_ sai_object_id_t *ptr_list);

sai_status_t
clxs_buffer_updatePortPgBuffer(
    _In_ uint32_t    unit,
    _In_ uint32_t    port,
    _In_ uint32_t    pg_idx,
    _In_ uint32_t    pfc_enable);

CLX_ERROR_NO_T
clxs_buffer_getHandler(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ uint32_t type,
    _In_ uint32_t queue_id,
    _Out_ CLX_TM_HANDLER_T *ptr_handler);

uint32_t
clxs_buffer_clxs_cells_to_bytes( uint32_t unit,uint32_t cells);

sai_status_t
clxs_buffer_get_pool_data_ext(
    _In_ sai_object_id_t             sai_pool,
    _Out_ CLXS_BUFFER_POOL_ATTR_T *ptr_sai_pool_attr);

sai_status_t
clxs_buffer_getPgIdInfo(
    _In_ sai_object_id_t pg_oid,
    _Out_ uint32_t       *ptr_unit,
    _Out_ uint32_t       *ptr_port,
    _Out_ uint32_t       *ptr_pg_index);

sai_status_t
clxs_get_buffer_pool_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_buffer_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_buffer_get_port_index_array(
    uint32_t               unit,
    uint32_t               port,
    CLXS_BUFFER_PORT_TYPE_T buff_type,
    uint32_t               **ptr_ptr_index_arr);

sai_status_t
clxs_get_buffer_pool_stats_ext(
    _In_  sai_object_id_t                pool_id,
    _In_  uint32_t                       number_of_counters,
    _In_  const sai_stat_id_t            *ptr_counter_ids,
    _In_  sai_stats_mode_t               mode,
    _Out_ uint64_t                       *ptr_counters);

sai_status_t
clxs_clear_buffer_pool_stats(
    _In_ sai_object_id_t pool_id,
    _In_ uint32_t number_of_counters,
    _In_ const sai_stat_id_t *ptr_counter_ids);

sai_status_t
clxs_get_ingress_priority_group_stats_ext(
    _In_ sai_object_id_t ingress_pg_id,
    _In_ uint32_t number_of_counters,
#if SAI_API_VERSION >= SAI_VERSION(1,4,0)
    _In_ const sai_stat_id_t *ptr_counter_ids,
#else
    _In_ const sai_ingress_priority_group_stat_t *ptr_counter_ids,
#endif
    _In_ sai_stats_mode_t mode,
    _Out_ uint64_t* ptr_counters);

sai_status_t
clxs_clear_ingress_priority_group_stats(
    _In_ sai_object_id_t ingress_pg_id,
    _In_ uint32_t number_of_counters,
#if SAI_API_VERSION >= SAI_VERSION(1,4,0)
    _In_ const sai_stat_id_t *ptr_counter_ids);
#else
    _In_ const sai_ingress_priority_group_stat_t *ptr_counter_ids);
#endif


#endif
