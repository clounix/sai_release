/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_MIRROR_H__)
#define __CLXS_MIRROR_H__
#define CLXS_MIRROR_LOCK(_unit_) \
    osal_takeSemaphore(&(_clxs_mirror_cb[_unit_]->sema), CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_MIRROR_UNLOCK(_unit_) \
    osal_giveSemaphore(&(_clxs_mirror_cb[_unit_]->sema));

typedef enum
{
    CLXS_MIRROR_ENCAP_ERSPAN = 0,
    CLXS_MIRROR_ENCAP_NVGRE,
    CLXS_MIRROR_ENCAP_UDP_TUNNEL,

    /* PN: Mirror2Sflow, Time: 2021-11, Description: sample packets and mirror to a remote destination using sflow encapsulation */
#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
    CLXS_MIRROR_ENCAP_SFLOW,
#endif
    CLXS_MIRROR_ENCAP_LAST
} CLXS_MIRROR_ENCAP_TYPE_T;

typedef struct
{
    CLX_MIR_SESSION_T           mir_session;
    uint32_t                    igr_session_id;
    uint32_t                    egr_session_id;
    bool                        igr_created;
    bool                        egr_created;
    /* caller set para, in SFLOW usecase, mir_type of mir_session first use ERSPAN_SRC, then, set mir_typ as 0, set tnl_type as 3 */
    CLXS_MIRROR_ENCAP_TYPE_T    encap_type;
    /* PN: Mirror2Sflow, Time: 2021-11, Description: reuse udp_port */
    uint32_t                    udp_port;                   /* bit0-15: dst port, bit16-31: src port */
    sai_object_id_t             policer_id;
    uint16_t                    gre_protocol_type;
    sai_object_id_t             tam_int_oid;

    /* PN: Mirror2Sflow, Time: 2021-11, Description: sample packets and mirror to a remote destination using sflow encapsulation */
#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
    /* Used in UDP-TUNNEL or SFLOW TUNNEL usecase */
    uint16_t                    erspan_ver;
    uint16_t                    encap_tnl_type;
#endif

} CLXS_MIR_ENTRY_T;

typedef struct
{
    bool                valid;
    CLXS_MIR_ENTRY_T    *session_entry;
} CLXS_MIR_DB_T;

typedef struct
{
    uint8_t                 sys_tc;
    CLX_SEMAPHORE_ID_T      sema;
    /*db must be an the end of struct*/
    CLXS_MIR_DB_T           db[0];
} CLXS_MIR_CB_T;

extern const sai_mirror_api_t           mirror_api;
extern CLXS_MIR_CB_T *_clxs_mirror_cb[CLXS_MAX_CHIP_NUM];
sai_status_t clxs_mirror_syncSes(
    _In_ uint32_t               unit,
    _In_ sai_object_id_t        mir_obj_idx,
    _In_ CLX_MIR_DIRECTION_T    dir,
    _Out_ uint32_t              *ptr_mir_session);

sai_status_t clxs_mirror_getMirType(
    _In_ uint32_t           unit,
    _In_ sai_object_id_t    mir_obj_idx,
    _Out_ CLX_MIR_TYPE_T    *mir_type);

sai_status_t clxs_mirror_setNvgreCtrl(
    uint32_t        unit,
    sai_object_id_t mir_obj_idx);

/* Get session id from mirror idx*/
sai_status_t clxs_mirror_getSesId(
    _In_ uint32_t               unit,
    _In_ CLX_MIR_DIRECTION_T    dir,
    _In_ uint32_t               mir_idx,
    _Out_ sai_object_id_t       *ptr_mir_ses_obj_id);

sai_status_t clxs_mirror_init(
    uint32_t unit);

sai_status_t clxs_mirror_deinit(
    uint32_t unit);

sai_status_t clxs_mirror_getSysTc(
    uint32_t    unit,
    uint8_t     *ptr_sys_tc);

sai_status_t clxs_mirror_setSysTc(
    uint32_t    unit,
    uint8_t     new_sys_tc);

sai_status_t clxs_mirror_applyTcToAllSession(
    uint32_t    unit,
    uint8_t     new_tc);

sai_status_t clxs_mirror_getSdkSesId(
    _In_ sai_object_id_t    session_oid,
    _Inout_ uint32_t        *sdk_ses_id);

sai_status_t clxs_mirror_getSessionCount(
    _In_ const uint32_t unit,
    _Out_ uint32_t      *count);

void _clxs_mirror_getSes(
    uint32_t            unit,
    uint32_t            mir_ses_id,
    CLXS_MIR_ENTRY_T    **entry);

#endif