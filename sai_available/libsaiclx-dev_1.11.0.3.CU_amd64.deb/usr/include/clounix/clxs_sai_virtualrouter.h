/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_VIRTUAL_ROUTER_H__)
#define __CLXS_VIRTUAL_ROUTER_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define INVALID_VRF_ID 0xffffffff

#define CLXS_VRF_LOCK(unit)    do {\
        if (CLXS_IS_UNIT_VALID(unit))\
        {\
            osal_takeSemaphore(&ptr_clxs_vrf_cb[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER);\
        }\
    }while (0)

#define CLXS_VRF_UNLOCK(unit)   do {\
        if (CLXS_IS_UNIT_VALID(unit))\
        {\
            osal_giveSemaphore(&ptr_clxs_vrf_cb[unit]->sema);\
        }\
    }while (0)

/* DATA TYPE DECLARATIONS
 */
typedef struct
{
    CLX_MAC_T           src_mac;
    CLX_FWD_ACTION_T    mc_miss_action;

} CLXS_VRF_ENTRY_T;
#define CLXS_VRF_BITMAP_SIZE(__unit__)   (CLX_BITMAP_SIZE(CLXS_MAX_VRF_NUM(__unit__)))

typedef struct
{
    CLXS_VRF_ENTRY_T     *ptr_vrf_entry;
    CLX_SEMAPHORE_ID_T  sema;
    sai_object_id_t     default_vrf_id;
    uint32_t * vrf_bitmap;
} CLXS_VRF_CB_T;

/* GLOBAL VARIABLE DECLARATIONS
 */
extern CLXS_VRF_CB_T* ptr_clxs_vrf_cb[];
extern const sai_virtual_router_api_t   virtualrouter_api;

/* MACRO FUNCTION DECLARATIONS
 */
#define VRF_FOREACH(unit, vrf_id)  CMLIB_BITMAP_FOREACH(ptr_clxs_vrf_cb[unit]->vrf_bitmap, vrf_id, CLXS_VRF_BITMAP_SIZE(unit))

/* API DECLARATIONS
 */
sai_status_t clxs_vrf_init(
    const uint32_t    unit);

sai_status_t clxs_vrf_deinit(
    const uint32_t    unit);

sai_status_t clxs_vrf_getInfo(
    _In_ const sai_object_id_t  obj_id,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_vrf_id,
    _Out_ CLX_MAC_T             *ptr_src_mac,
    _Out_ CLX_FWD_ACTION_T      *ptr_fwd_act);

sai_status_t clxs_vrf_getObject(
    _In_ const uint32_t         vrf_id,
    _In_ const uint32_t         unit,
    _Out_ sai_object_id_t       *ptr_obj_id);

sai_status_t clxs_vrf_getDefaultVrf(
    _In_ const uint32_t unit,
    _Out_ sai_object_id_t *ptr_obj_id);

sai_status_t
clxs_get_vrf_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
_clxs_vrf_getEntry(
    const uint32_t  unit,
    const uint32_t  vrf_id,
    CLXS_VRF_ENTRY_T **pptr_entry);

#endif /* __CLXS_VIRTUAL_ROUTER_H__ */
