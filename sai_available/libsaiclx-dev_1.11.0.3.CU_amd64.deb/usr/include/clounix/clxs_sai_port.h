/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_PORT_H__)
#define __CLXS_PORT_H__

#define CLXS_PORT_MAX_PFC_COUNT            (8)
#define CLXS_PORT_UINT32_INVALID_VALUE                   (0xFFFFFFFF)
#define CLXS_PORT_SPEED_NAME_SIZE          (32)

#define CLXS_PORT_FOREACH(__unit__, __port__)                              \
    if ( __unit__ < CLXS_MAX_CHIP_NUM&&NULL != _clxs_port_cb[__unit__].port_db_ptr)                 \
    for (__port__ = 0; __port__ < CLX_PORT_NUM; __port__++)    \
    if (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port)

#define CLXS_FRONT_PORT_FOREACH(__unit__, __port__)                              \
    if ( __unit__ < CLXS_MAX_CHIP_NUM&&NULL != _clxs_port_cb[__unit__].port_db_ptr)                 \
    for (__port__ = 0; __port__ < CLX_PORT_NUM; __port__++)    \
    if ((CLXS_CPU_PORT(unit) != __port__) && (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port))

#define CLXS_PORT_DB_PTR(__unit__, __port__)        ((CLXS_PORT_UNIT_PORT_PRPRTY_T *)(_clxs_port_cb[__unit__].port_db_ptr + __port__ ))
#define CLXS_PORT_MAP_PTR(__unit__, __port__)       ((CLXS_PORT_MAP_T *)(_clxs_port_cb[__unit__].port_map + __port__))

#define CLXS_PORT_QOSMAP_PTR(__unit__, __port__, __qosmap_type__)   \
                                                    ((CLXS_PORT_QOSMAP_T *)(_clxs_port_cb[__unit__].ptr_qosmap +  \
                                                        __port__*CLXS_QOSMAP_TYPES_MAX + __qosmap_type__))

#define CLXS_PORT_PFC_PTR(__unit__, __port__)       ((CLXS_PORT_PFC_T *)(_clxs_port_cb[__unit__].ptr_pfc + __port__))

#define CLXS_IS_ETH_PORT_VALID(__unit__, __port__)  ((__port__ < CLXS_MAX_PORT_NUM) && ((NULL == _clxs_port_cb[__unit__].port_db_ptr) ? false : (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port)))
#define CLXS_IS_PORT_VALID(__unit__, __port__)      ((__port__ < CLXS_MAX_PORT_NUM) && ((NULL == _clxs_port_cb[__unit__].port_db_ptr) ? false : (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port)))

#define CHECK_PORT_ERR_RETURN(unit, port)  do {\
    CHECK_UNIT_ERR_RETURN(unit);    \
    if (!CLXS_IS_PORT_VALID(unit, port))\
    {\
        CLXS_LOG_ERR(__MODULE__, "Invalid unit %d, port %d", unit, port);\
        return SAI_STATUS_INVALID_PARAMETER;\
    }\
}while (0)

#define CLXS_PORT_LOCK(unit) \
        sai_osal_mutex_lock(_clxs_port_cb[unit].sema);

#define CLXS_PORT_UNLOCK(unit) \
        sai_osal_mutex_unlock(_clxs_port_cb[unit].sema);


#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_PORT_IP_COUNT_PTR(__unit__, __port__)  ((CLXS_PORT_IP_COUNTER_DB_T *)(_clxs_port_cb[__unit__].port_ip_count_info + __port__))
#endif

#if SAI_API_VERSION < SAI_VERSION(1,10,0)
/**
 * Before version 1.10, SAI did not support the 400G interface type.
 * However, the SDK does support CR8 and LR8.
 * Therefore, we need to extend the `sai_port_interface_type_t` here.
 */
typedef enum _ext_sai_port_interface_type_t
{
    /** Interface type CR8 */
    SAI_PORT_INTERFACE_TYPE_CR8 = SAI_PORT_INTERFACE_TYPE_XGMII+1,

    /** Interface type SR8 */
    SAI_PORT_INTERFACE_TYPE_SR8,

    /** Interface type KR8 */
    SAI_PORT_INTERFACE_TYPE_KR8,

    /** Interface type LR8 */
    SAI_PORT_INTERFACE_TYPE_LR8
} ext_sai_port_interface_type_t;
#endif

typedef enum
{
    CLXS_PORT_BREAKOUT_CAPABILITY_NONE       = 0,
    CLXS_PORT_BREAKOUT_CAPABILITY_TWO        = 1,
    CLXS_PORT_BREAKOUT_CAPABILITY_FOUR       = 2,
    CLXS_PORT_BREAKOUT_CAPABILITY_TWO_FOUR   = 3     /*TODO: clarify this purpose*/
} clxs_port_breakout_capability_t;

/* Consistent with the order of sec_cmd_showStormControlPortInfo */
typedef enum
{
    CLXS_STORM_CTRL_TYPE_BROADCAST = 0,
    CLXS_STORM_CTRL_TYPE_FLOOD,
    CLXS_STORM_CTRL_TYPE_MULTICAST,
    CLXS_STORM_CTRL_TYPE_RESERVE,
    CLXS_STORM_CTRL_TYPE_LAST
} CLX_STORM_CTRL_TYPE_T;

typedef enum
{
    CLXS_PORT_POLICER_ACTION_ADD,
    CLXS_PORT_POLICER_ACTION_DELETE,
    CLXS_PORT_POLICER_ACTION_MODIFY,
    CLXS_PORT_POLICER_ACTION_LAST
} CLXS_PORT_POLICER_ACTION_T;

typedef enum
{
    CLXS_PORT_POLICER_TYPE_REGULAR_INDEX     = 0,
    CLXS_PORT_POLICER_TYPE_FLOOD_INDEX       = 1,
    CLXS_PORT_POLICER_TYPE_BROADCAST_INDEX   = 2,
    CLXS_PORT_POLICER_TYPE_MULTICAST_INDEX   = 3,
    CLXS_PORT_POLICER_TYPE_MAX               = 4
} clxs_port_policer_type;

typedef enum
{
    CLXS_PORT_200G_SLOWDOWN_4x25G           = (1U << 0),//default
    CLXS_PORT_200G_SLOWDOWN_2x50G           = (1U << 1),
    CLXS_PORT_400G_SLOWDOWN_4x25G           = (1U << 2),//default
    CLXS_PORT_400G_SLOWDOWN_2x50G           = (1U << 3),
    CLXS_PORT_400G_SLOWDOWN_4x50G           = (1U << 4),//default
    CLXS_PORT_400G_SLOWDOWN_8x25G           = (1U << 5),
    CLXS_PORT_800G_SLOWDOWN_4x25G           = (1U << 6),
    CLXS_PORT_800G_SLOWDOWN_2x50G           = (1U << 7),
    CLXS_PORT_800G_SLOWDOWN_4x50G           = (1U << 8),
    CLXS_PORT_800G_SLOWDOWN_8x25G           = (1U << 9),
    CLXS_PORT_800G_SLOWDOWN_4x100G          = (1U << 10),
    CLXS_PORT_800G_SLOWDOWN_8x50G           = (1U << 11),
    CLXS_PORT_SPEED_SLOWDOWN_MODE_MAX
} CLXS_PORT_SPEED_SLOWDOWN_MODE_T;


typedef struct CLXS_PORT_UNIT_PORT_PRPRTY_S
{
    uint8_t                         valid;
    CLX_PORT_T                      clx_port;
    CLX_PORT_SPEED_T                max_speed;
    CLX_PORT_MEDIUM_TYPE_T          medium_type;
    uint32_t                        lane_grp;  /*First lane number in the list*/
    uint8_t                         lane_num;
    uint8_t                         lane_max_num;
    uint8_t                         default_tc;
    uint16_t                        pvid;
    bool                            is_present;
    uint32_t                        admin_state;
    /*  SAI Port can have up to CLXS_PORT_POLICER_TYPE_MAX SDK port storm
     *  policers in use internally.  For each storm item we keep type of
     *  traffic it'll handle and SAI policer id which contains the policer
     *  attributes (cbs, pir, etc.) if SAI_NULL_OBJECT_ID == policer_id then
     *  given storm item is not in use currently.
     */
    sai_object_id_t                 ingress_policers[CLXS_PORT_POLICER_TYPE_MAX];
    sai_object_id_t                 ingress_samplepacket_obj;
    sai_object_id_t                 egress_samplepacket_obj;
    sai_object_id_t                 ingress_sample_mirror_session_obj;
    sai_object_id_t                 egress_sample_mirror_session_obj;
    sai_object_id_t                 wred_id;
    sai_object_id_t                 isolation_group_id;
    sai_object_id_t                 ing_acl_object;
    sai_object_id_t                 egr_acl_object;
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 1)
    sai_object_id_t                 port_serdes_id;
#endif
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
    sai_object_list_t            tamlist;
#endif
#define CLXS_PORT_UNIT_PORT_FLAG_PARENT    (1 << 0)
#define CLXS_PORT_UNIT_PORT_FLAG_FRESH     (1 << 1) /* port first admin up will be delay when startup  */
    uint32_t                        flags;
    uint64_t                        admin_up_us;
    uint32_t                        loopback;
    uint32_t                        internal_loopback;
    uint32_t                        speed;
    uint32_t                        autoneg;
    uint32_t                        fec;
    uint32_t                        fec_ext;
    uint32_t                        link_training;
    uint32_t                        media_type;
    uint32_t                        interface_type;
    uint32_t                        adver_pause;
    uint32_t                        adver_speed;
    uint32_t                        adver_fec;
    uint32_t                        adver_media;
    bool                            ext_phy;    /* Indicate that the port has a ext phy */
    uint32_t                        slot;
}CLXS_PORT_UNIT_PORT_PRPRTY_T;

#ifdef CLX_PORT_IP_COUNT_USING_ACL
/*iptype for ip count*/
typedef enum
{
    CLXS_PORT_IPCOUNT_IPTYPE_IPV4,
    CLXS_PORT_IPCOUNT_IPTYPE_IPV6,
    CLXS_PORT_IPCOUNT_IPTYPE_MAX
} CLXS_PORT_IPCOUNT_IPTYPE_T;

/*ip count db info*/
typedef struct CLXS_PORT_IP_COUNTER_DB_S
{
    bool        valid;
    uint32_t    unit;
    uint32_t    port;
    uint32_t    ing_acl_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];   /*ingress 2 acl, 0-ipv4, 1-ipv6*/
    uint32_t    egr_acl_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];   /*egress 2 acl, 0-ipv4, 1-ipv6*/
    uint32_t    ing_counter_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];	 /*ingress 2 2xcounters, 0-ipv4,1-ipv6*/
    uint32_t    egr_counter_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];	 /*egress 2 2xcounters, 0-ipv4,1-ipv6*/
}CLXS_PORT_IP_COUNTER_DB_T;
#endif

typedef struct CLXS_PORT_MAP_S
{
    bool                        valid;
    uint32_t                    unit;
    uint32_t                    port;
    CLX_PORT_T                  clx_port;
    uint32_t                    dst_idx;
    sai_object_id_t             obj;
    char                        hostif_name[SAI_HOSTIF_NAME_SIZE];
    uint32_t                    hostif_id;
}CLXS_PORT_MAP_T;

typedef struct  CLXS_PORT_LINK_S
{
    sai_pointer_t               callback_func;
    CLX_SEMAPHORE_ID_T          mutex;
    CLX_SEMAPHORE_ID_T          sema;
    CLX_THREAD_ID_T             thread_id;
    CMLIB_LIST_T                *event_list;
}CLXS_PORT_LINK_T;

typedef struct CLXS_PORT_QOSMAP_S{
    sai_object_id_t qosmap_oid;
    uint32_t        hw_profile_id;
} CLXS_PORT_QOSMAP_T;

typedef struct CLXS_PORT_PFC_S{
    sai_port_priority_flow_control_mode_t   ctrl_mode;
    uint8_t                                 rx_enable;
    uint8_t                                 tx_enable;
    uint32_t                                queue_bitmap;
} CLXS_PORT_PFC_T;

typedef struct  CLXS_PORT_CB_S
{
    CLXS_PORT_UNIT_PORT_PRPRTY_T *port_db_ptr;
    CLXS_PORT_LINK_T            port_link;
    CLX_SEMAPHORE_ID_T          sema;
    CLX_SEMAPHORE_ID_T          thread_sync;
    uint32_t                    port_count;
    CLXS_PORT_MAP_T             *port_map;
#ifdef CLX_PORT_IP_COUNT_USING_ACL
    CLXS_PORT_IP_COUNTER_DB_T   *port_ip_count_info;
    uint32_t                     acl_ing_group_id;
    uint32_t                     acl_egr_group_id;
#endif
    uint32_t                    ext_phy_type;
    CLXS_PORT_QOSMAP_T          *ptr_qosmap;
    CLXS_PORT_PFC_T             *ptr_pfc;
} CLXS_PORT_CB_T;

typedef struct  CLXS_PORT_STAT_PFC_CB_S
{
    uint64_t                    rx_duration[CLXS_MAX_PORT_NUM][CLXS_PORT_MAX_PFC_COUNT];
    uint32_t                    interval_us;
    UI32_T                      thread_pri;
    CLX_THREAD_ID_T             thread_id;
    CLX_SEMAPHORE_ID_T          sema;
} CLXS_PORT_STAT_PFC_CB_T;

extern CLXS_PORT_STAT_PFC_CB_T *_clxs_port_stat_pfc_cb[];

typedef struct CLXS_PORT_LAG_COMMON_ATTRS_S
{
    uint16_t        pvid;
}CLXS_PORT_LAG_COMMON_ATTRS_T;

extern const sai_port_api_t             port_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T port_stats_capability_info;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T port_pool_stats_capability_info;

typedef struct CLXS_PORT_SPEED_LANE_MAP_S{
    CLX_PORT_SPEED_T                   lane_speed;
    uint8_t                            port_lane_num;
    CLX_PORT_SPEED_T                   target_speed;
    CLXS_PORT_SPEED_SLOWDOWN_MODE_T    mode;
    uint8_t                            speed_lane_num;
}CLXS_PORT_SPEED_LANE_MAP_T;

typedef struct CLXS_PORT_INTERFACE_MEDIUM_TYPE_TABLE_S{
    int32_t                 interface_type;
    CLX_PORT_SPEED_T        sdk_speed;
    CLX_PORT_MEDIUM_TYPE_T  medium_type;
} CLXS_PORT_INTERFACE_MEDIUM_TYPE_TABLE_T;

#ifdef CLX_STORMCONTROL_VALUE0_USE_ACL
/**add policer type. If considering other protocol types
 *  in the future, they need to be added in these enumerations*/
typedef enum
{
    CLXS_PORT_BC_STC_PROTOCOL_DROP_ARP = 0,
    CLXS_PORT_BC_STC_PROTOCOL_DROP_DHCP,
    CLXS_PORT_BC_STC_PROTOCOL_DROP_MAX_NUM,
} CLXS_PORT_BC_STC_PROTOCOL_DROP_T;

typedef enum
{
    CLXS_PORT_UMC_STC_PROTOCOL_DROP_ND = 0,
    CLXS_PORT_UMC_STC_PROTOCOL_DROP_MAX_NUM,
} CLXS_PORT_UMC_STC_PROTOCOL_DROP_T;

typedef enum
{
    CLXS_PORT_STORMCONTROL_TYPE_BC = 0,
    CLXS_PORT_STORMCONTROL_TYPE_UMC,
    CLXS_PORT_STORMCONTROL_TYPE_UUC,
    CLXS_PORT_STORMCONTROL_TYPE_MAX_NUM,
} CLXS_PORT_STORMCONTROL_TYPE_T;

typedef struct  CLXS_PORT_STORMCONTROL_BY_ACL_CB_S
{
    uint32_t                        acl_group_id_for_stormcontrol;
    uint32_t                        acl_entry_id_for_bc_stromcontrol[CLXS_ACL_UDF_PROFILE_NUM][CLX_ACL_CLASSIFY_KEY_LAST];
    uint32_t                        acl_entry_id_for_umc_stromcontrol[CLXS_ACL_UDF_PROFILE_NUM][CLX_ACL_CLASSIFY_KEY_LAST];
    uint32_t                        acl_entry_id_for_uuc_stromcontrol[CLXS_ACL_UDF_PROFILE_NUM][CLX_ACL_CLASSIFY_KEY_LAST];
    uint32_t                        acl_entry_id_bc_stc_protocol_drop[CLXS_PORT_BC_STC_PROTOCOL_DROP_MAX_NUM][CLXS_HOSTIF_MAX_ACL_ENTRY_PER_TRAP];
    uint32_t                        acl_entry_id_umc_stc_protocol_drop[CLXS_PORT_UMC_STC_PROTOCOL_DROP_MAX_NUM][CLXS_HOSTIF_MAX_ACL_ENTRY_PER_TRAP];
    uint32_t                        meter_id_for_port_stormcontrol[CLXS_MAX_PORT_NUM][CLXS_PORT_STORMCONTROL_TYPE_MAX_NUM];

} CLXS_PORT_STORMCONTROL_BY_ACL_CB_T;

extern CLXS_PORT_STORMCONTROL_BY_ACL_CB_T port_stormcontrol_by_acl[CLXS_MAX_CHIP_NUM];
#endif

extern CLXS_PORT_CB_T _clxs_port_cb[];

#define CLXS_REGISTER_PORT_STATS_NOTIFY_UPDATE(func)   do { clxs_port_stats_notify_update[__MODULE__] = func; } while (0)

typedef sai_status_t (*CLXS_PORT_STATS_NOTIFY_UPDATE)(
    _In_ const UI32_T                      unit,
    _In_ const UI32_T                      port,
    _In_ const CLX_STAT_PORT_CNT_TYPE_T    *cnt_type,
    _In_ const UI32_T                      cnt_num,
    _In_ UI64_T                            *cnt);

extern CLXS_PORT_STATS_NOTIFY_UPDATE clxs_port_stats_notify_update[CLXS_API_MAX];

sai_status_t
clxs_port_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_port_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_port_to_object(
    uint32_t            unit,
    uint32_t            port,
    sai_object_id_t     *ptr_object_id);

sai_status_t
clxs_port_registerCallback(
    _In_ const uint32_t         unit,
    _In_ void                   *func);

uint32_t clxs_port_getUnitPortNumber(
    _In_ const uint32_t unit);

sai_status_t clxs_port_getPortNumber(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clxs_port_getMaxPortNumber(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clxs_port_getPortList(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clxs_port_getCpuPort(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clxs_port_getTpid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const sai_switch_attr_t attr,
    _Out_ uint16_t * ptr_tpid);

sai_status_t clxs_port_setTpid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const sai_switch_attr_t attr,
    _In_ const uint16_t ptr_tpid);

sai_status_t
clxs_port_setBindEgrTable(
    sai_object_id_t     port_object,
    uint32_t        intf_group_label,
    bool        is_add);

sai_status_t
clxs_port_getPortMap(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _Out_ CLXS_PORT_MAP_T *ptr_port_map);

sai_status_t
clxs_port_updatePortMap(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const char *port_name,
    _In_ const uint32_t hostif_id);

sai_status_t
clxs_port_updateLagMbr(
    _In_ const sai_object_id_t              port_oid,
    _In_ const CLXS_PORT_LAG_COMMON_ATTRS_T *attrs,
    _In_ const bool                         is_add);

sai_status_t
clxs_port_getMirrorSessionOid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ bool igr,
    _Out_ sai_object_id_t *ptr_mirrorsession_oid);

sai_status_t
clxs_get_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_port_get_plane_id(
    UI32_T unit,
    UI32_T port,
    UI32_T *bin,
    UI32_T *plane_id);

sai_status_t
clxs_port_get_portlist(
    UI32_T unit, UI32_T bin,
    UI32_T plane_id,
    UI32_T *plist,
    UI32_T *count);


sai_status_t clxs_port_pool_getWredProfileID(
        uint32_t unit,uint32_t port,
        _Out_ sai_object_id_t* wredId);

void
_clxs_port_state_change_notify(
        _In_ uint32_t unit,
        _In_ uint32_t count,
        _In_ const sai_port_oper_status_notification_t *data);

CLX_ERROR_NO_T clxs_port_link_event_init(
    _In_ const uint32_t     unit);

sai_status_t clxs_port_getClxPort(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _Out_ CLX_PORT_T *ptr_clx_port);

sai_status_t clxs_port_getPortId(
    _In_ uint32_t unit,
    _In_ CLX_PORT_T clx_port,
    _Out_ uint32_t *ptr_port);

sai_status_t clxs_create_port(
    _Out_ sai_object_id_t *port_id,
    _In_ sai_object_id_t switch_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);

sai_status_t clxs_remove_port(
    _In_ sai_object_id_t port_id);

sai_status_t clxs_set_port_attribute(
    _In_ sai_object_id_t port_id,
    _In_ const sai_attribute_t *attr);

sai_status_t clxs_get_port_attribute(
    _In_ sai_object_id_t port_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list);

sai_status_t clxs_get_port_stats_ext(
        _In_ sai_object_id_t port_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids,
        _In_ sai_stats_mode_t mode,
        _Out_ uint64_t *counters);

sai_status_t clxs_clear_port_stats(
        _In_ sai_object_id_t port_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);

sai_status_t clxs_port_getPortName(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _Out_ char *ptr_name);

sai_status_t _clxs_port_setUnitPortFec(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t    fec_mode);

sai_status_t _clxs_port_setUnitPortInterfaceType(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t    interface_type);

sai_status_t _clxs_port_setUnitPortLinkTraining(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const bool       link_training);

sai_status_t _clxs_port_setUnitPortMediaType(
    _In_ const uint32_t    unit,
    _In_ const uint32_t    port,
    _In_ const int32_t     media_type);

sai_status_t _clxs_port_setUnitPortAutoNegotiation(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ bool             port_an_status);

sai_status_t _clxs_port_setUnitPortSpeed(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const uint32_t   speed);

sai_status_t _clxs_port_setUnitPortLoopback(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t    loopback);

sai_status_t _clxs_port_setUnitPortFec(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t   fec_mode);

sai_status_t _clxs_port_setUnitPortFecExt(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t   fec_mode);

#if SAI_API_VERSION >= SAI_VERSION(1,9,0)
sai_status_t _clxs_port_getUnitUseExtFec(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Out_ bool   *fec_ext_mode_enable);
#endif

sai_status_t _clxs_port_setUnitPortAdmin(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const uint32_t   admin);

sai_status_t _clxs_port_getUnitPortAutoNegotiation(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ bool          *port_autoneg);

sai_status_t _clxs_port_getUnitPortFecMode(
    _In_ const uint32_t       unit,
    _In_ const uint32_t       port,
    _Inout_ int32_t           *fec_mode);

sai_status_t _clxs_port_getUnitPortFecExt(
    _In_ const uint32_t       unit,
    _In_ const uint32_t       port,
    _Inout_ int32_t           *fec_ext_mode);

sai_status_t _clxs_port_getUnitPortLinkTraining(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ bool          *port_link_training);

sai_status_t _clxs_port_setUnitPortInternalLoopback(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t    internal_loopback);

sai_status_t _clxs_port_getUnitPortAdmin(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ bool          *admin_mode);

sai_status_t _clxs_port_getUnitPortSpeed(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ uint32_t      *speed);

sai_status_t _clxs_port_getUnitPortInterfaceType(
    _In_ const uint32_t       unit,
    _In_ const uint32_t       port,
    _Inout_ int32_t           *interface_type);

sai_status_t _clxs_port_getUnitPortMediaType(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ int32_t       *media);

sai_status_t _clxs_port_getPortDefaultConfigFromHW(
    _In_ const uint32_t unit,
    _In_ const uint32_t port);

sai_status_t
clxs_port_setPfcAction(
    _In_ uint32_t               unit,
    _In_ uint32_t               port,
    _In_ CLX_TM_PFCWD_ACTION_T  action);

sai_status_t
clxs_port_setPfcDetectTime(
    _In_ uint32_t               unit,
    _In_ uint32_t               port,
    _In_ sai_map_list_t         maplist);

sai_status_t
clxs_port_setPfcRecoveryTime(
    _In_ uint32_t               unit,
    _In_ uint32_t               port,
    _In_ sai_map_list_t         maplist);

sai_status_t  clxs_port_setSwitchQosmap(
    _In_    uint32_t            unit,
    _In_    sai_qos_map_type_t  type,
    _In_    sai_object_id_t     qosmap_oid);

sai_status_t clxs_port_getPfcRxEnable(
    _In_ uint32_t        unit,
    _In_ uint32_t        port,
    _In_ uint32_t        pg_id,
    _Out_ BOOL_T         *rx_enable);

sai_status_t clxs_port_updatePfcMap(
    _In_    uint32_t            unit,
    _In_    sai_qos_map_type_t  type,
    _In_    sai_object_id_t     qosmap_oid,
    _In_    sai_qos_map_list_t  qosmap_list);

sai_status_t clxs_port_getLink(
    _In_ uint32_t           unit,
    _In_ uint32_t           port,
    _Out_ uint32_t          *ptr_link_status);

sai_status_t clxs_port_updateLocalAdverPause(
    _In_ const uint32_t            unit,
    _In_ const uint32_t            port,
    _In_ const bool                enable);

sai_status_t
clxs_port_setDefaultVlanId(
    _In_ uint32_t               unit,
    _In_ CLX_PORT_T             clx_port,
    _In_ uint32_t               vid);

sai_status_t
clxs_port_getDefaultVlanId(
    _In_ uint32_t               unit,
    _In_ CLX_PORT_T             clx_port,
    _Out_ uint32_t              *vid);

#endif /* __CLXS_PORT_H__ */
