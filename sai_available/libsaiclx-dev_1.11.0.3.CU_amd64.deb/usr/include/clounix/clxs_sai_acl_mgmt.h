/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Hangzhou Clounix Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_ACL_MGMT_H__)
#define __CLXS_ACL_MGMT_H__

#if 0
#define CLXS_ACL_MAX_IGR_GROUP_PRIORITY     SHAL_ACL_MAX_IGR_GROUP_PRIORITY
#define CLXS_ACL_MAX_EGR_GROUP_PRIORITY     SHAL_ACL_MAX_EGR_GROUP_PRIORITY
#define CLXS_ACL_MAX_IGR_ACTION_PRIORITY    SHAL_ACL_MAX_IGR_ACTION_PRIORITY
#define CLXS_ACL_MAX_EGR_ACTION_PRIORITY    SHAL_ACL_MAX_EGR_ACTION_PRIORITY
#define CLXS_ACL_MAX_MODULE_GROUP           SHAL_ACL_MAX_MODULE_GROUP
#define CLXS_ACL_MAX_MODULE_GROUP_MEMBER    SHAL_ACL_MAX_MODULE_GROUP_MEMBER

#define CLXS_ACL_ENTRY_MAX_PRIORITY         SHAL_ACL_ENTRY_MAX_PRIORITY
#define CLXS_ACL_ENTRY_USER_MAX_PRIORITY    SHAL_ACL_ENTRY_USER_MAX_PRIORITY
#define CLXS_ACL_INVALID_PRIORITY           SHAL_ACL_INVALID_PRIORITY
#endif

typedef enum clxs_acl_module_type_s
{
    ACL_TYPE_START,
    ACL_TYPE_COPP = ACL_TYPE_START,
    ACL_TYPE_USER_ACL,
    ACL_TYPE_IP_CNT,
    ACL_TYPE_ECN_MARK,
    ACL_TYPE_STORM_CTRL,
    ACL_TYPE_L3_CNT,
    ACL_TYPE_POLICER,
    ACL_TYPE_ECMP_TRACE,
    ACL_TYPE_TAM_MOD,
    ACL_TYPE_INVALID,
    ACL_TYPE_MAX = ACL_TYPE_INVALID,
} clxs_acl_module_type_t;

#define CLXS_ACL_SET_MODULE_TYPE(type, id)    ((type << 16) + id)
#define CLXS_ACL_GET_ID(id)                   (id & 0xffff)
#define CLXS_ACL_GET_MODULE_TYPE(id)          (id >> 16)

CLX_ERROR_NO_T clxs_acl_addTable(
    _In_ const uint32_t                   unit,
    _In_ const clxs_acl_module_type_t     type,
    _In_ const CLX_ACL_GROUP_T            stage,
    _In_ const CLX_ACL_GROUP_PROFILE_T    *ptr_group_profile,
    _Out_ uint32_t                        *ptr_group_id
);

CLX_ERROR_NO_T clxs_acl_delTable(
    _In_ const uint32_t                  unit,
    _In_ const CLX_ACL_GROUP_T           stage,
    _In_ const uint32_t                  group_id
);

CLX_ERROR_NO_T clxs_acl_allocEntryId(
    _In_ const uint32_t                  unit,
    _In_ const CLX_ACL_GROUP_T           stage,
    _In_ const uint32_t                  group_id,
    _In_ const uint32_t                  entry_pri,
    _Out_ uint32_t                       *ptr_entry_id);

CLX_ERROR_NO_T clxs_acl_freeEntryId(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id);

CLX_ERROR_NO_T clxs_acl_addEntry(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id,
    _In_ const BOOL_T                    entry_valid,
    _In_ const CLX_ACL_CLASSIFY_T        *ptr_classify,
    _In_       CLX_ACL_ACTION_T          *ptr_action);

CLX_ERROR_NO_T clxs_acl_delEntry(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id);

CLX_ERROR_NO_T clxs_acl_getEntry(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         id,
    _Out_ BOOL_T                *ptr_entry_valid,
    _Out_ CLX_ACL_CLASSIFY_T    *ptr_classify,
    _Out_ CLX_ACL_ACTION_T      *ptr_action);

CLX_ERROR_NO_T clxs_acl_allocAddAclEntry(
    _In_ const uint32_t                  unit,
    _In_ CLX_ACL_GROUP_T                 stage,
    _In_ const uint32_t                  group_id,
    _In_ const uint32_t                  entry_pri,
    _In_ const BOOL_T                    entry_valid,
    _In_ const CLX_ACL_CLASSIFY_T        *ptr_classify,
    _Inout_    CLX_ACL_ACTION_T          *ptr_action,
    _Out_      uint32_t                  *ptr_entry_id);

sai_status_t clxs_acl_freeDelEntry(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id);

CLX_ERROR_NO_T clxs_acl_updateEntry(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id,
    _In_ const CLX_ACL_CLASSIFY_T        *ptr_classify,
    _In_       CLX_ACL_ACTION_T          *ptr_action);

CLX_ERROR_NO_T clxs_acl_setEntryValid(
    _In_ const uint32_t    unit,
    _In_ const uint32_t    entry_id,
    _In_ const BOOL_T      entry_valid);

CLX_ERROR_NO_T clxs_acl_getPriorityGroupId(
    _In_ const uint32_t             unit,
    _In_ const CLX_ACL_GROUP_T      stage,
    _In_ const uint32_t             priority,
    _Out_ uint32_t                  *ptr_group_id
);

CLX_ERROR_NO_T clxs_acl_dumpModuleStageInfo(
    _In_ const uint32_t                  unit,
    _In_ const clxs_acl_module_type_t    module_type,
    _In_ const CLX_ACL_GROUP_T           stage);

CLX_ERROR_NO_T clxs_acl_dumpGroupInfo(
    _In_ const uint32_t           unit,
    _In_ const CLX_ACL_GROUP_T    stage,
    _In_ const uint32_t           group_id);

CLX_ERROR_NO_T clxs_acl_getModuleName(
    _In_ const clxs_acl_module_type_t    module_type,
    _Out_ char                            *module_name);

sai_status_t clxs_acl_mgmt_init(
    _In_ const uint32_t    unit);

sai_status_t clxs_acl_mgmt_deinit(
    _In_ const uint32_t unit);
#endif /*__CLXS_ACL_MGMT_H__*/
