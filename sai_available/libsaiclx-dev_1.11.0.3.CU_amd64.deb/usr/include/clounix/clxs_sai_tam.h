/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_TAM_H__)
#define __CLXS_TAM_H__

#define CLXS_TAM_MAX_TAM_NUM             (80)
#define CLXS_TAM_MAX_REPORT_NUM          (10)
#define CLXS_TAM_MAX_TRANSPORT_NUM       (10)
#define CLXS_TAM_MAX_COLLECTOR_NUM       (10)
#define CLXS_TAM_MAX_MATH_FUNC_NUM       (20)
#define CLXS_TAM_MAX_EVENT_THRESHOLD_NUM (30)
#define CLXS_TAM_MAX_EVENT_ACTION_NUM    (40)
#define CLXS_TAM_MAX_TELEMETRY_TYPE_NUM  (20)
#define CLXS_TAM_MAX_TELEMETRY_NUM       (20)
#define CLXS_TAM_MAX_EVENT_NUM           (60)

#ifdef CLX_TAM_MOD_ENABLE

#define CLXS_TAM_MOD_STEERING_HEADER_SIZE   (14)
#define CLXS_TAM_MOD_STEERING_HEADER_ETHERTYPE   (0x4444)

#define CLXS_TAM_MOD_QUEUE_BINDWIDTH   (2048)
#define CLXS_TAM_MOD_QUEUE_BURST       (8191)

typedef enum
{
    CLXS_TAM_MOD_TYPE_PP,
    CLXS_TAM_MOD_TYPE_TM,
    CLXS_TAM_MOD_TYPE_MAX_NUM
}CLXS_TAM_MOD_TYPE_T;

#endif

typedef enum
{
    CLXS_TEL_PORT_STATS_RX_OCTETS,
    CLXS_TEL_PORT_STATS_RX_PKTS,
    CLXS_TEL_PORT_STATS_RX_UCAST_PKTS,
    CLXS_TEL_PORT_STATS_RX_MULTICAST_PKTS,
    CLXS_TEL_PORT_STATS_RX_BROADCAST_PKTS,
    CLXS_TEL_PORT_STATS_RX_ERR_PKTS,
    CLXS_TEL_PORT_STATS_RX_DROP_PKTS,
    CLXS_TEL_PORT_STATS_RX_UNDERSIZE_PKTS,
    CLXS_TEL_PORT_STATS_RX_FRAGMENTS,
    CLXS_TEL_PORT_STATS_RX_OVERSIZE_PKTS,
    CLXS_TEL_PORT_STATS_RX_JABBERS,
    CLXS_TEL_PORT_STATS_RX_SYMBOL_ERRORS,
    CLXS_TEL_PORT_STATS_RX_COLLISIONS,
    CLXS_TEL_PORT_STATS_RX_CRC_ALIGN_ERRORS,
    CLXS_TEL_PORT_STATS_RX_FRAME_TOO_LONGS,
    CLXS_TEL_PORT_STATS_RX_UNKNOWN_OPCODES,
    CLXS_TEL_PORT_STATS_RX_L2_MTU_DISCARDS,
    CLXS_TEL_PORT_STATS_RX_L3_DISCARDS,
    CLXS_TEL_PORT_STATS_RX_L3_BLACKHOLE_DISCARDS,
    CLXS_TEL_PORT_STATS_RX_NON_QUEUE_DISCARDS,
    CLXS_TEL_PORT_STATS_RX_PARITY_DISCARDS,
    CLXS_TEL_PORT_STATS_RX_PAUSE_PKTS,
    CLXS_TEL_PORT_STATS_RX_PFC_0_PKTS,
    CLXS_TEL_PORT_STATS_RX_PFC_1_PKTS,
    CLXS_TEL_PORT_STATS_RX_PFC_2_PKTS,
    CLXS_TEL_PORT_STATS_RX_PFC_3_PKTS,
    CLXS_TEL_PORT_STATS_RX_PFC_4_PKTS,
    CLXS_TEL_PORT_STATS_RX_PFC_5_PKTS,
    CLXS_TEL_PORT_STATS_RX_PFC_6_PKTS,
    CLXS_TEL_PORT_STATS_RX_PFC_7_PKTS,
    CLXS_TEL_PORT_STATS_RX_PKTS_64_OCTETS,
    CLXS_TEL_PORT_STATS_RX_PKTS_65_TO_127_OCTETS,
    CLXS_TEL_PORT_STATS_RX_PKTS_128_TO_255_OCTETS,
    CLXS_TEL_PORT_STATS_RX_PKTS_256_TO_511_OCTETS,
    CLXS_TEL_PORT_STATS_RX_PKTS_512_TO_1023_OCTETS,
    CLXS_TEL_PORT_STATS_RX_PKTS_1024_TO_1518_OCTETS,
    CLXS_TEL_PORT_STATS_RX_PKTS_1519_TO_MAX_OCTETS,

    CLXS_TEL_PORT_STATS_RX_LAST
} CLXS_TEL_PORT_STATS_RX_T;

typedef enum
{
    CLXS_TEL_PORT_STATS_TX_OCTETS,
    CLXS_TEL_PORT_STATS_TX_PKTS,
    CLXS_TEL_PORT_STATS_TX_UCAST_PKTS,
    CLXS_TEL_PORT_STATS_TX_MULTICAST_PKTS,
    CLXS_TEL_PORT_STATS_TX_BROADCAST_PKTS,
    CLXS_TEL_PORT_STATS_TX_ERR_PKTS,
    CLXS_TEL_PORT_STATS_TX_DROP_PKTS,
    CLXS_TEL_PORT_STATS_TX_L3_DISCARDS,
    CLXS_TEL_PORT_STATS_TX_NON_QUEUE_DISCARDS,
    CLXS_TEL_PORT_STATS_TX_INVALID_VLAN_DISCARDS,
    CLXS_TEL_PORT_STATS_BUFFER_DISCARDS,
    CLXS_TEL_PORT_STATS_TX_OVERSIZE_PKTS,
    CLXS_TEL_PORT_STATS_TX_PAUSE_PKTS,
    CLXS_TEL_PORT_STATS_TX_PFC_0_PKTS,
    CLXS_TEL_PORT_STATS_TX_PFC_1_PKTS,
    CLXS_TEL_PORT_STATS_TX_PFC_2_PKTS,
    CLXS_TEL_PORT_STATS_TX_PFC_3_PKTS,
    CLXS_TEL_PORT_STATS_TX_PFC_4_PKTS,
    CLXS_TEL_PORT_STATS_TX_PFC_5_PKTS,
    CLXS_TEL_PORT_STATS_TX_PFC_6_PKTS,
    CLXS_TEL_PORT_STATS_TX_PFC_7_PKTS,
    CLXS_TEL_PORT_STATS_TX_PKTS_64_OCTETS,
    CLXS_TEL_PORT_STATS_TX_PKTS_65_TO_127_OCTETS,
    CLXS_TEL_PORT_STATS_TX_PKTS_128_TO_255_OCTETS,
    CLXS_TEL_PORT_STATS_TX_PKTS_256_TO_511_OCTETS,
    CLXS_TEL_PORT_STATS_TX_PKTS_512_TO_1023_OCTETS,
    CLXS_TEL_PORT_STATS_TX_PKTS_1024_TO_1518_OCTETS,
    CLXS_TEL_PORT_STATS_TX_PKTS_1519_TO_MAX_OCTETS,

    CLXS_TEL_PORT_STATS_TX_LAST
} CLXS_TEL_PORT_STATS_TX_T;

typedef enum
{
    CLXS_TEL_QUEUE_STATS_OCTETS,         //chip not support.
    CLXS_TEL_QUEUE_STATS_PKTS,
    CLXS_TEL_QUEUE_STATS_DROP_OCTETS,         //chip not support.
    CLXS_TEL_QUEUE_STATS_DROP_PKTS,
    CLXS_TEL_QUEUE_STATS_LAST
}CLXS_TEL_QUEUE_STATS_T;

typedef struct
{
    uint32_t    tv_sec;
    uint32_t    tv_usec;
}CLXS_TM_VAL;

typedef enum
{
    CLXS_TEL_PORT_STATS_RATE_PKTS,
    CLXS_TEL_PORT_STATS_RATE_BYTES,
    CLXS_TEL_PORT_STATS_RATE_LAST,
}CLXS_PORT_STAT_RATE_T;


#define CLXS_TAM_BUF_SNAPSHOT_RECORD_MAX     (120)
#define CLXS_TAM_BUF_SNAPSHOT_POOL_CNT       (4)
#define CLXS_TAM_BUF_SNAPSHOT_TYPE_PERIODIC      (1 << 0)
#define CLXS_TAM_BUF_SNAPSHOT_TYPE_THRESHOLD_EGR_GLOBAL      (1 << 1)

typedef struct
{
    uint32_t    igr_glb_lossless;
    uint32_t    igr_glb_headroom;
    uint32_t    egr_glb_share;
}CLXS_TM_POOL_SNAPSHOT_T;

typedef struct
{
    uint32_t    *igr_queue;
    uint32_t    *egr_uc_queue;
    uint32_t    *egr_mc_queue;
}CLXS_TM_PORT_SNAPSHOT_T;

typedef struct
{
    uint32_t                index;
    CLXS_TM_VAL             time[CLXS_TAM_BUF_SNAPSHOT_RECORD_MAX];
    uint32_t                type[CLXS_TAM_BUF_SNAPSHOT_RECORD_MAX];
    CLXS_TM_POOL_SNAPSHOT_T pool[CLXS_TAM_BUF_SNAPSHOT_RECORD_MAX][CLXS_TAM_BUF_SNAPSHOT_POOL_CNT];
    CLXS_TM_PORT_SNAPSHOT_T ***port;
    uint32_t                **cpu;
}CLXS_TM_SNAPSHOT_T;

typedef struct
{
    bool                    valid;
    sai_tam_report_type_t   type;
    sai_uint32_t            histogram_bins;
    sai_u32_list_t          bin_boundary;
    sai_uint32_t            quota;
    sai_tam_report_mode_t   report_mode;
    sai_uint32_t            report_interval;
    sai_uint32_t            enterprise_number;
}CLXS_TAM_REPORT_DB_T;

typedef struct
{
    bool                            valid;
    sai_tam_transport_type_t        type;
    sai_uint32_t                    src_port;
    sai_uint32_t                    dst_port;
    sai_tam_transport_auth_type_t   auth_type;
    sai_uint32_t                    mtu;
#ifdef CLX_TAM_MOD_ENABLE
    sai_mac_t                       smac;            /*new for mod function*/
    sai_mac_t                       dmac;            /*new for mod function*/
    sai_uint16_t                    vlan_tpid;       /*new for mod function*/
    sai_uint16_t                    vlan_id;         /*new for mod function*/
    sai_uint8_t                     vlan_pri;        /*new for mod function*/
    sai_uint8_t                     vlan_cfi;        /*new for mod function*/
#endif
}CLXS_TAM_TRANSPORT_DB_T;

typedef struct
{
    bool                valid;
    sai_ip_address_t    src_ip;
    sai_ip_address_t    dst_ip;
    bool                localhost;
    sai_object_id_t     virtual_router_oid;
    sai_uint16_t        truncate_size;
    sai_object_id_t     tranport_oid;
    sai_uint8_t         dscp;
}CLXS_TAM_COLLECTOR_DB_T;

typedef struct
{
    bool                            valid;
    sai_tam_tel_math_func_type_t    type;
}CLXS_TAM_MATH_FUNC_DB_T;

typedef struct
{
    bool                            valid;
    sai_uint32_t                    hi_watermark;
    sai_uint32_t                    lo_watermark;
    sai_uint32_t                    latency;
    sai_uint32_t                    rate;
    sai_uint32_t                    abs_value;
    sai_tam_event_threshold_unit_t  unit;
}CLXS_TAM_EVENT_THRESHOLD_DB_T;

typedef struct
{
    bool            valid;
    sai_object_id_t report_type_oid;
    sai_uint32_t    qos_action_type;
}CLXS_TAM_EVENT_ACTION_DB_T;

typedef struct
{
    bool                        valid;
    sai_tam_telemetry_type_t    type;
    sai_uint32_t                identifier;
    bool                        enable_port_stats;
    bool                        enable_port_stats_ingress;
    bool                        enable_port_stats_egress;
    bool                        enable_virtual_queue_stats;
    bool                        enable_output_queue_stats;
    bool                        enable_mmu_stats;
    bool                        enable_fabric_stats;
    bool                        enable_filter_stats;
    bool                        enable_resource_utilization_stats;
    bool                        enable_fabric_q;
    bool                        enable_networking_element;
    sai_uint8_t                 dscp;
    sai_object_id_t             math_func_oid;
    sai_object_id_t             report_oid;
}CLXS_TAM_TEL_TYPE_DB_T;

typedef struct
{
    bool                        valid;
    sai_object_list_t           tel_type_objs;
    sai_object_list_t           collector_objs;
    sai_tam_reporting_unit_t    reporting_unit;
    sai_uint32_t                reporting_interval;
}CLXS_TAM_TEL_DB_T;

typedef struct
{
    bool                    valid;
    sai_tam_event_type_t    type;
    sai_object_list_t       action_objs;
    sai_object_list_t       collector_objs;
    sai_object_id_t         threshold_oid;
    sai_uint8_t             dscp;
#ifdef CLX_TAM_MOD_ENABLE
    sai_uint32_t            aging_interval;              /*new for mod function*/
    sai_uint32_t            event_id;                    /*new for mod function*/
    sai_uint32_t            device_id;                   /*new for mod function*/
    sai_u32_list_t          ipp_reason_list;             /*new for mod function*/
    sai_u32_list_t          mmu_reason_list;             /*new for mod function*/
    sai_u32_list_t          epp_reason_list;             /*new for mod function*/
    sai_uint32_t            sampling_rate;               /*new for mod function*/
    sai_uint16_t            user_meta_data;              /*new for mod function，fixed value*/
    sai_object_id_t         ingress_samplepacket_rate;   /*new for mod function*/
    sai_object_list_t       extensions_collector_objs;   /*new for mod function*/
    uint32_t                netlink_id;
    uint32_t                netlink_profile_id;
    bool                    modify_ttl_acl_entry;
    uint32_t                mmu_egress_acl_group_id;
    uint32_t                mmu_egress_acl_entry_id;
    uint32_t                mmu_egress_stat_id;
#endif
}CLXS_TAM_EVENT_DB_T;

typedef struct
{
    bool                valid;
    sai_object_list_t   telemetry_objs;
    sai_object_list_t   events_objs;
    sai_object_list_t   int_objs;
    sai_uint32_t        bind_point_type_bmp;
}CLXS_TAM_TAM_DB_T;

typedef struct
{
    CLX_SEMAPHORE_ID_T              sema;
    CLXS_TAM_TAM_DB_T               tam[CLXS_TAM_MAX_TAM_NUM];
    CLXS_TAM_REPORT_DB_T            report[CLXS_TAM_MAX_REPORT_NUM];
    CLXS_TAM_TRANSPORT_DB_T         transport[CLXS_TAM_MAX_TRANSPORT_NUM];
    CLXS_TAM_COLLECTOR_DB_T         collector[CLXS_TAM_MAX_COLLECTOR_NUM];
    CLXS_TAM_MATH_FUNC_DB_T         math_func[CLXS_TAM_MAX_MATH_FUNC_NUM];
    CLXS_TAM_EVENT_THRESHOLD_DB_T   event_threshold[CLXS_TAM_MAX_EVENT_THRESHOLD_NUM];
    CLXS_TAM_EVENT_ACTION_DB_T      event_action[CLXS_TAM_MAX_EVENT_ACTION_NUM];
    CLXS_TAM_TEL_TYPE_DB_T          tel_type[CLXS_TAM_MAX_TELEMETRY_TYPE_NUM];
    CLXS_TAM_TEL_DB_T               telemetry[CLXS_TAM_MAX_TELEMETRY_NUM];
    CLXS_TAM_EVENT_DB_T             event[CLXS_TAM_MAX_EVENT_NUM];
} CLXS_TAM_DB_T;

extern const sai_tam_api_t  tam_api;

sai_status_t clxs_tam_init(
    _In_ const uint32_t unit);

sai_status_t clxs_tam_deinit(
    _In_ const uint32_t unit);

#if SAI_API_VERSION >= SAI_VERSION(1,5,0)
sai_status_t clxs_tam_setTamObjList(
    _In_ sai_object_id_t            bind_obj,
    _In_ const sai_object_list_t    *ptr_tam_obj_list);

sai_status_t
clxs_tam_getTamObjList(
    _In_ sai_object_id_t            bind_obj,
    _Inout_ sai_attribute_value_t   *value);

sai_status_t clxs_tam_getTamIntObjList(
    _In_ sai_object_id_t        tam_obj,
    _Inout_ sai_object_list_t   *tam_int_list);

#endif
CLXS_TAM_TAM_DB_T *_clxs_tam_tam_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_REPORT_DB_T *_clxs_tam_report_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_TRANSPORT_DB_T *_clxs_tam_transport_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_COLLECTOR_DB_T *_clxs_tam_collector_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_MATH_FUNC_DB_T *_clxs_tam_math_func_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_EVENT_THRESHOLD_DB_T *_clxs_tam_event_threshold_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_EVENT_ACTION_DB_T *_clxs_tam_event_action_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_TEL_TYPE_DB_T *_clxs_tam_tel_type_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_TEL_DB_T *_clxs_tam_telemetry_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

CLXS_TAM_EVENT_DB_T *_clxs_tam_event_getEntry(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id);

#ifdef CLX_TAM_MOD_ENABLE
bool clxs_tam_getModIppEnable(_In_ uint32_t  unit);
#endif
#endif //__CLXS_TAM_H__