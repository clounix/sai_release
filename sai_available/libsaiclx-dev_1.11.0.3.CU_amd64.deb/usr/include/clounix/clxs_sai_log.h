/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_LOG_H__)
#define __CLXS_LOG_H__

#define CLXS_LOG_PRINT(module, severity, fmt, arg ...)                       \
    do {                                                                    \
        clxs_log_print(module, severity,                                   \
                        "%s:%d " fmt,  __FUNCTION__,__LINE__, ## arg);                 \
    } while (0)
#define CLXS_LOG_PRINT_WITHOUT_CODE_INFO(module, severity, fmt, arg ...)                \
    do {                                                                    \
        clxs_log_print(module, severity, fmt, ## arg);                 \
    } while (0)
#define CLXS_LOG_PRINT_WITH_BACKTRACE(module, severity, fmt, arg ...)          \
    do {                                                                       \
        clxs_log_print(module, severity,                                       \
                        "%s:%d " fmt,  __FUNCTION__,__LINE__, ## arg);         \
        clxs_log_print_backtrace(module, severity);                            \
    } while (0)

#define CLXS_LOG_TYPE_SAI      0
#define CLXS_LOG_TYPE_DIAG   1
#define CLXS_LOG_DBG(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_DEBUG,   fmt, ## arg)
#define CLXS_LOG_INF(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_INFO,    fmt, ## arg)
#define CLXS_LOG_WRN(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_WARN,    fmt, ## arg)
#define CLXS_LOG_ERR(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_ERROR,   fmt, ## arg)
#define CLXS_LOG_NTC(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_NOTICE,  fmt, ## arg)
#define CLXS_LOG_CTL(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_CRITICAL,fmt, ## arg)

#define CLXS_ATTRIBS_LOG(_module,_clxs_range_attr_arr,_dbg_level) \
{\
    if (clxs_log_isModuleLogLevelOn((_module), (_dbg_level)))\
    {\
        char _list_str[MAX_LIST_VALUE_STR_LEN] = {0};\
        clxs_sai_attr_list_to_str(attr_count, attr_list, _clxs_range_attr_arr, MAX_LIST_VALUE_STR_LEN, _list_str);\
        CLXS_LOG_PRINT(_module, _dbg_level,"%s", _list_str);\
    }\
}

#define CLXS_ATTR_VALUE_LOG(module, _id, _attr_value, _clxs_range_attr_arr, _dbg_level) \
{\
    char _value_str[MAX_VALUE_STR_LEN] = {0};\
    clxs_sai_attr_value_to_str(_id, _attr_value, _clxs_range_attr_arr, MAX_VALUE_STR_LEN, _value_str);\
    CLXS_LOG_PRINT(module, _dbg_level, "%s", _value_str);\
}

#define CHECK_RET_FAIL_LOG(ret, level, fmt, arg ...)  do {\
    if ((ret)!= SAI_STATUS_SUCCESS) \
    {\
        CLXS_LOG_##level(__MODULE__, fmt" "#ret"=%d", ##arg, (ret));\
    }\
}while (0)

#define CHECK_RET_ERR_LOG(fmt, arg ...)  CHECK_RET_FAIL_LOG(ret, ERR, fmt, ##arg)

#define CLXS_COUNTER_ID_LOG(module, _num_of_cnt, _cnt_ids, _dbg_level)\
{\
    uint32_t _cnt_id_idx = 0;\
    for (_cnt_id_idx=0;_cnt_id_idx<_num_of_cnt;_cnt_id_idx++)\
    {\
        CLXS_LOG_PRINT(module, _dbg_level, "counter id[%u]=%u",_cnt_id_idx,_cnt_ids[_cnt_id_idx]);\
    }\
}

#define CLXS_COUNTER_ID_AND_VALUE_LOG(module, _num_of_cnt, _cnt_ids, _cnt_value, _dbg_level)\
{\
    uint32_t _cnt_idx = 0;\
    for (_cnt_idx=0;_cnt_idx<_num_of_cnt;_cnt_idx++)\
    {\
        CLXS_LOG_PRINT(module, _dbg_level, "counter id[%u]=%d,value=%#" PRIx64 ,_cnt_idx,_cnt_ids[_cnt_idx],_cnt_value[_cnt_idx]);\
    }\
}

extern uint32_t _clxs_sdk_dbg_flag;

/* API DECLARATIONS
 */
void
clxs_log_print(
    const clxs_api_t        module,
    const sai_log_level_t       severity,
    const C8_T                  *ptr_fmt,
    ...)
__attribute__ ((__format__ (__printf__, 3, 4)));

void
clxs_log_print_backtrace(
    const clxs_api_t        module,
    const sai_log_level_t       severity);

BOOL_T
clxs_log_isModuleLogLevelOn(
    const clxs_api_t        module,
    const sai_log_level_t       severity);

CLX_ERROR_NO_T
clxs_log_setModuleLogLevel(
    const clxs_api_t        module,
    const uint32_t              type,
    const sai_log_level_t       severity);

CLX_ERROR_NO_T
clxs_log_getModuleLogLevel(
    const clxs_api_t        module,
    const uint32_t              type,
    sai_log_level_t             *severity);

sai_status_t
clxs_bulk_statuses_log(
    _In_ const char         *object_type_str,
    _In_ const sai_status_t *object_statuses,
    _In_ uint32_t            object_count,
    _In_ sai_common_api_t    api);

void
clxs_log_setDiagCfg(_In_ const uint32_t  unit);

void clxs_sai_printVersion();

void clxs_log_init(void);

uint32_t
clxs_log_getSyslogLevel(_In_ const sai_log_level_t level);

#endif /* __CLXS_LOG_H__ */
