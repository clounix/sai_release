/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_SCHEDULER_H__)
#define __CLXS_SCHEDULER_H__

#define CLXS_MAX_SCHEDULER_PROFILE_NUM(__unit__)   ((CLXS_MAX_PORT_NUM) * ( CLXS_QUEUE_UC_NUM(__unit__) +CLXS_QUEUE_MC_NUM(__unit__) ))  /* all ports with 8 uc and 8 mc*/


typedef struct CLXS_SCHEDULER_PROFILE_S{
    sai_object_id_t             id;
    CLX_TM_SCH_MODE_T           sch_type;
    uint32_t                    weight;
    CLX_TM_BANDWIDTH_MODE_T     bandwidth_mode;
    bool                        min_enable;
    bool                        max_enable;
    uint64_t                    min_rate;
    uint64_t                    min_burst;
    uint64_t                    max_rate;
    uint64_t                    max_burst;
} CLXS_SCHEDULER_PROFILE_T;

typedef struct CLXS_SCHEDULER_PROF_VALID_S{
    bool valid;
    CLXS_SCHEDULER_PROFILE_T *ptr_scheduler_entry;
} CLXS_SCHEDULER_PROF_VALID_T;

typedef struct CLXS_SCHEDULER_CB_S{
    sai_object_id_t             clxs_scheduler_id_port[CLXS_MAX_PORT_NUM];
    CLXS_SCHEDULER_PROF_VALID_T  clxs_scheduler_prof_map[0];
} CLXS_SCHEDULER_CB_T;

extern const sai_scheduler_api_t        scheduler_api;
extern CLXS_SCHEDULER_CB_T *_clxs_scheduler_cb[CLXS_MAX_CHIP_NUM];
/* API DECLARATIONS
 */
sai_status_t clxs_scheduler_setToPort(
    sai_object_id_t     object_id,
    sai_object_id_t     scheduler_id);

sai_status_t clxs_scheduler_getFromPort(
    sai_object_id_t     object_id,
    sai_object_id_t     *ptr_scheduler_id);

sai_status_t clxs_scheduler_applyToQueueGroup(
    sai_object_id_t     scheduler_id,
    uint32_t            port,
    CLX_TM_HANDLER_T    handler);

sai_status_t clxs_scheduler_init(
    uint32_t unit);

sai_status_t clxs_scheduler_deinit(
    uint32_t unit);

sai_status_t clxs_get_scheduler_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_scheduler_getInfo(
    sai_object_id_t object_id,
    uint32_t        *ptr_unit,
    uint32_t        *ptr_profile_id);

#endif /* __CLXS_SCHEDULER_H__ */
