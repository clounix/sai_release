/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_SAI_H__)
#define __CLXS_SAI_H__

#include <clxs_sai_version.h>
#ifndef CLXS_SAI_HEAD_VERSION
#define CLXS_SAI_HEAD_VERSION                 "1.7.1"
#endif

#ifndef SAI_VERSION
#define SAI_VERSION(major, minor, revision) (10000 * (major) + 100 * (minor) + (revision))
#endif

#ifndef SAI_API_VERSION
/* SAI_MAJOR, SAI_MINOR, SAI_REVISION is defined in clxs_sai_version.h when SAI VERSION < 1.8.0 */
#define SAI_API_VERSION SAI_VERSION(SAI_MAJOR, SAI_MINOR, SAI_REVISION)
#endif

#if defined(CLX_STATIC_EN)
#define STATIC static
#else
#define STATIC
#endif

#include <sai.h>
#include <saiextensions.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>
#include <stdarg.h>
#include <assert.h>
#include <inttypes.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <clxs_sdk.h>
#include <clxs_sai_dispatch.h>
#include <clxs_sai_lib.h>
#include <clxs_sai_osal.h>
#include <clxs_sai_log.h>
#include <clxs_sai_warmboot.h>
#include <clxs_sai_oid.h>
#include <clxs_sai_object.h>
#include <clxs_sai_acl_mgmt.h>
#include <clxs_sai_port.h>
#include <clxs_sai_port_link_delay.h>
#include <clxs_sai_qosmap.h>
#include <clxs_sai_switch.h>
#include <clxs_sai_switch_feature.h>
#include <clxs_sai_bridge.h>
#include <clxs_sai_vlan.h>
#include <clxs_sai_fdb.h>
#include <clxs_sai_lag.h>
#include <clxs_sai_l2mc.h>
#include <clxs_sai_nexthop.h>
#include <clxs_sai_nexthopgroup.h>
#include <clxs_sai_policer.h>
#include <clxs_sai_queue.h>
#include <clxs_sai_route.h>
#include <clxs_sai_routerinterface.h>
#include <clxs_sai_rpfgroup.h>
#include <clxs_sai_samplepacket.h>
#include <clxs_sai_scheduler.h>
#include <clxs_sai_schedulergroup.h>
#include <clxs_sai_stp.h>
#include <clxs_sai_tunnel.h>
#include <clxs_sai_udf.h>
#include <clxs_sai_wred.h>
#include <clxs_sai_virtualrouter.h>
#include <clxs_sai_acl.h>
#include <clxs_pkt_rx.h>
#include <clxs_sai_buffer.h>
#include <clxs_sai_counter.h>
#include <clxs_sai_debugcounter.h>
#include <clxs_sai_hash.h>
#include <clxs_sai_hostif.h>
#include <clxs_sai_ipmc.h>
#include <clxs_sai_ipmcgroup.h>
#include <clxs_sai_isolationgroup.h>
#include <clxs_sai_l2mcgroup.h>
#include <clxs_sai_mcastfdb.h>
#include <clxs_sai_mirror.h>
#include <clxs_sai_neighbor.h>
#include <clxs_sai_mpls.h>
#include <clxs_sai_segmentroute.h>
#include <clxs_sai_dtel.h>
#include <clxs_sai_bfd.h>
#include <clxs_sai_nat.h>
#include <clxs_sai_macsec.h>
#include <clxs_sai_systemport.h>
#include <clxs_sai_monitor.h>
#if SAI_API_VERSION >= SAI_VERSION(1,9,0)
#include <clxs_sai_ipsec.h>
#include <clxs_sai_mymac.h>
#include <clxs_sai_srv6.h>
#endif
#if SAI_API_VERSION >= SAI_VERSION(1,11,0)
#include <clxs_sai_genericprogrammable.h>
#endif
#include <clxs_sai_tam_int.h>
#include <clxs_sai_tam.h>
#include <clxs_diag.h>
#include <clxs_sai_ext_phy.h>
#include <clxs_sai_bmtor.h>
#include <clxs_sai_hotpatch_init.h>

#include <parser/dsh_parser.h>
#include <parser/dsh_util.h>

#include <execinfo.h>

#include <shal/shal.h>
extern sai_service_method_table_t       g_services;

typedef struct SHAL_FUNC_VEC_S
{
    SHAL_PORT_FUNC_VEC_T            *shal_port_func_vec;
    SHAL_SWITCH_FUNC_VEC_T          *shal_switch_func_vec;
    SHAL_VLAN_FUNC_VEC_T            *shal_vlan_func_vec;
    SHAL_VRF_FUNC_VEC_T             *shal_vrf_func_vec;
    SHAL_ROUTE_FUNC_VEC_T           *shal_route_func_vec;
    SHAL_NEXTHOP_FUNC_VEC_T         *shal_nexthop_func_vec;
    SHAL_NEXTHOPGROUP_FUNC_VEC_T    *shal_nexthopgroup_func_vec;
    SHAL_RIF_FUNC_VEC_T             *shal_rif_func_vec;
    SHAL_NEIGHBOR_FUNC_VEC_T        *shal_neighbor_func_vec;
    SHAL_MIRROR_FUNC_VEC_T          *shal_mirror_func_vec;
    SHAL_ISOLATIONGROUP_FUNC_VEC_T  *shal_isolationgroup_func_vec;
    SHAL_HASH_FUNC_VEC_T            *shal_hash_func_vec;
    SHAL_STP_FUNC_VEC_T             *shal_stp_func_vec;
    SHAL_FDB_FUNC_VEC_T             *shal_fdb_func_vec;
    SHAL_LAG_FUNC_VEC_T             *shal_lag_func_vec;
    SHAL_BRIDGE_FUNC_VEC_T          *shal_bridge_func_vec;
    SHAL_ACL_FUNC_VEC_T             *shal_acl_func_vec;
    SHAL_TUNNEL_FUNC_VEC_T          *shal_tunnel_func_vec;
    SHAL_SCHEDULERGROUP_FUNC_VEC_T  *shal_schedulergroup_func_vec;
    SHAL_L2MCGROUP_FUNC_VEC_T       *shal_l2mcgroup_func_vec;
    SHAL_QOSMAP_FUNC_VEC_T          *shal_qosmap_func_vec;
    SHAL_HOSTIF_FUNC_VEC_T          *shal_hostif_func_vec;
    SHAL_SAMPLEPACKET_FUNC_VEC_T    *shal_samplepacket_func_vec;
    SHAL_UDF_FUNC_VEC_T             *shal_udf_func_vec;
    SHAL_BUFFER_FUNC_VEC_T          *shal_buffer_func_vec;
    SHAL_WRED_FUNC_VEC_T            *shal_wred_func_vec;
    SHAL_QUEUE_FUNC_VEC_T           *shal_queue_func_vec;
    SHAL_POLICER_FUNC_VEC_T         *shal_policer_func_vec;
}CLXS_SHAL_FUNC_VEC_T;

extern  CLXS_SHAL_FUNC_VEC_T  *clxs_shal_func_vec;

#define _SHAL_FUNC_CALL(__func_vec__, __func__, __param__, __rc__) ({               \
        CLX_ERROR_NO_T __rc = CLX_E_OK;                                             \
        if ((NULL == clxs_shal_func_vec)||(NULL == clxs_shal_func_vec->__func_vec__) || (NULL == clxs_shal_func_vec->__func_vec__->__func__))             \
        {                                                                           \
            CLXS_LOG_NTC(SAI_API_UNSPECIFIED, "not support this function");         \
            __rc = __rc__;                                                          \
        }                                                                           \
        else                                                                        \
        {                                                                           \
            __rc = (clxs_shal_func_vec->__func_vec__->__func__ __param__);               \
        }                                                                           \
        __rc;                                                                       \
    })

#define SHAL_FUNC_CALL(__module__,__func__, __param__) \
        _SHAL_FUNC_CALL(shal_##__module__##_func_vec, __func__, __param__, CLX_E_NOT_SUPPORT)
#endif /* __CLXS_SAI_H__ */
