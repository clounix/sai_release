/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_POLICER_H__)
#define __CLXS_POLICER_H__
#define CLXS_POLICER_MAX_METER_NUMBER(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_meterid_num):0)

#define CLXS_POLICER_MAX_METER_GLOBAL_BS(unit)        (_ptr_clxs_policer_cb[unit]->is_global_bs)
#define CLXS_POLICER_MAX_METER_GLOBAL_IR(unit)        (_ptr_clxs_policer_cb[unit]->is_global_ir)

#define CLXS_POLICER_MAX_METER_GLOBAL_PACKET_BS(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_global_packet_bs):0)
#define CLXS_POLICER_MAX_METER_GLOBAL_BYTE_BS(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_global_byte_bs):0)
#define CLXS_POLICER_MAX_METER_PLANE_PACKET_BS(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_plane_packet_bs):0)
#define CLXS_POLICER_MAX_METER_PLANE_BYTE_BS(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_plane_byte_bs):0)

#define CLXS_POLICER_MAX_METER_GLOBAL_PACKET_IR(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_global_packet_ir):0)
#define CLXS_POLICER_MAX_METER_GLOBAL_BYTE_IR(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_global_byte_ir):0)
#define CLXS_POLICER_MAX_METER_PLANE_PACKET_IR(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_plane_packet_ir):0)
#define CLXS_POLICER_MAX_METER_PLANE_BYTE_IR(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_plane_byte_ir):0)

#define CLXS_POLICER_LOCK(unit) \
    osal_takeSemaphore(&_ptr_clxs_policer_cb[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_POLICER_UNLOCK(unit) \
    osal_giveSemaphore(&_ptr_clxs_policer_cb[unit]->sema);

typedef struct
{
    uint32_t    meter_id;
    bool    pbs_flag;    /* Indicates whether pbs has been set */
    CLX_METER_CFG_T     meter_cfg;
}CLXS_METER_INFO_T;

typedef struct
{
    CLX_SEMAPHORE_ID_T      sema;
    bool                    acl_group_created[CLX_ACL_GROUP_LAST];
    bool                    is_global_bs;
    bool                    is_global_ir;
    uint32_t                acl_group[CLX_ACL_GROUP_LAST];
    uint32_t                acl_entry_id[CLX_ACL_GROUP_LAST][CLXS_MAX_PORT_NUM];

    CLXS_METER_INFO_T       meter_cfg_info[0];
} CLXS_POLICER_CB_T;

extern const sai_policer_api_t          policer_api;
extern CLXS_POLICER_CB_T *_ptr_clxs_policer_cb[CLXS_MAX_CHIP_NUM];

#define CLXS_REGISTER_POLICER_CHANGE(func)   do { clxs_policer_notify_update[__MODULE__] = func; } while (0)

typedef sai_status_t (*CLXS_POLICER_NOTIFY_UPDATE)(
    _In_ const uint32_t      unit,
    _In_ sai_object_id_t     object_id,
    _In_ CLX_METER_CFG_T     old_meter_cfg,
    _In_ CLX_METER_CFG_T     new_meter_cfg);

extern CLXS_POLICER_NOTIFY_UPDATE clxs_policer_notify_update[CLXS_API_MAX];

/* API DECLARATIONS
 */
sai_status_t
clxs_policer_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_policer_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_policer_getUnitId(
    _In_ const sai_object_id_t  policer_id,
    _Out_ uint32_t              *ptr_unit);

sai_status_t
clxs_policer_addColorAct(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         port,
    _In_ const CLX_ACL_GROUP_T  type,
    _In_ const sai_object_id_t  policer_id);

sai_status_t
clxs_policer_delColorAct(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         port,
    _In_ const CLX_ACL_GROUP_T  type,
    _In_ const sai_object_id_t  policer_id);

#define CLXS_POLICER_GN_PKT_ACT_DROP             (0x1 << CLX_COLOR_GREEN)
#define CLXS_POLICER_YL_PKT_ACT_DROP             (0x1 << CLX_COLOR_YELLOW)
#define CLXS_POLICER_RD_PKT_ACT_DROP             (0x1 << CLX_COLOR_RED)

#define CLXS_POLICER_INVALID_METER_ID            (0xFFFFFFFF)

sai_status_t
clxs_policer_getMeterCfg(
    _In_ const sai_object_id_t      policer_id,
    _Out_ uint32_t      *ptr_meter_id,
    _Out_ CLX_METER_CFG_T   *ptr_meter_cfg);

#endif /* __CLXS_POLICER_H__ */
