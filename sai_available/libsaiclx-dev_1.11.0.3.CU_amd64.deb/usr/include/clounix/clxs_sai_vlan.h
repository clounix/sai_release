/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_VLAN_H__)
#define __CLXS_VLAN_H__

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_vlan_api_t             vlan_api;

#define CLXS_VLAN_BC_LABEL  0x1
#define CLXS_VLAN_UMC_LABEL 0x2
#define CLXS_VLAN_UUC_LABEL 0x3

typedef struct CLXS_VLAN_INFO_S
{
    int32_t             flood_type[CLXS_SRV_BUM_TYPE_LAST]; /* 0 is for bc, 1 is for unknown mc and  2 is for unknown uc */
    uint32_t            flood_all_mgid;   /* flood all mgid, can be shared by uuc,umc and bc */
    uint32_t            flood_none_mgid;   /* flood none mgid, can be shared by uuc,umc and bc  */
    uint32_t            flood_group_mgid[CLXS_SRV_BUM_TYPE_LAST]; /* 0 is for bc, 1 is for unknown mc and  2 is for unknown uc */
    bool                  igmp_snooping;
    CLX_STAT_CNT_T      igr_cnt;
    CLX_STAT_CNT_T      egr_cnt;
    uint32_t            mbr_cnt;
#define CLXS_VLAN_FLOOD_IPMC   (1<<0)
    uint32_t            flags;
    sai_object_id_t     ing_acl_object;
    sai_object_id_t     egr_acl_object;
} CLXS_VLAN_INFO_T;

typedef struct CLXS_VLAN_MBR_NODE_S
{
    uint16_t            vid;        /* KEY */
    uint32_t            bd_port_id; /* KEY */
    bool                untag;
} CLXS_VLAN_MBR_NODE_T;

typedef struct CLXS_VLAN_MBR_COOKIE_S
{
    uint32_t            unit;
    uint16_t            vid;
    uint32_t            bd_port_id;
    sai_object_id_t     **pptr_oid;
} CLXS_VLAN_MBR_COOKIE_T;

typedef struct CLXS_VLAN_CB_S
{
    CLXS_VLAN_INFO_T     vlan_info[CLXS_MAX_VLAN_NUM];
    uint32_t            valid_vlan_bmp[CLXS_VLAN_BMP_SIZE];
    CMLIB_AVL_HEAD_T    *ptr_mbr_avl;
    CLX_SEMAPHORE_ID_T  sema;
} CLXS_VLAN_CB_T;

extern CLXS_VLAN_CB_T* ptr_clxs_vlan_cb[CLXS_MAX_CHIP_NUM];

/* API DECLARATIONS
 */
sai_status_t
clxs_vlan_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_vlan_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_vlan_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint16_t                  *ptr_vid);

sai_status_t
clxs_vlan_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint16_t             vid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_vlan_setFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLXS_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act);

sai_status_t
clxs_vlan_updateLagMbr(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  bd_port_id,
    _In_ const CLXS_BRIDGE_PORT_INFO_T    *ptr_port_info,
    _In_ const bool                      is_add);

sai_status_t
clxs_vlan_update_flood_all_mgid(
    _In_ const uint32_t unit,
    _In_ const uint32_t vid,
    _In_ const uint32_t flags,
    _Out_ uint32_t *mcast_id
    );

sai_status_t clxs_vlan_valid_check(
    _In_ const uint32_t unit,
    _In_ const uint16_t vid);

sai_status_t clxs_vlan_setDtelProfile (
    _In_ const uint32_t unit,
    _In_ const uint16_t vid,
    _In_ const uint32_t profile);

sai_status_t clxs_get_vlan_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_vlan_member_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_create_vlan_member(
    _Out_ sai_object_id_t         *vlan_member_id,
    _In_ sai_object_id_t          switch_id,
    _In_ uint32_t                 attr_count,
    _In_ const sai_attribute_t    *attr_list);

sai_status_t
clxs_remove_vlan_member(
    _In_ sai_object_id_t     vlan_member_id);

#if 0
bool clxs_vlan_isIpProxySet(
    _In_ bool isND);
#endif
#endif /* __CLXS_VLAN_H__ */
