/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_LAG_H__)
#define __CLXS_LAG_H__

#define CLXS_LAG(unit) (_clxs_lag[unit])
#define CLXS_LAG_ATTR(unit, id) (CLXS_LAG(unit).grp_attr[id])
#define CLXS_LAG_NUM_WORD(unit)   CLX_BITMAP_SIZE(CLXS_MAX_LAG_NUM(unit))

#define CLXS_LAG_LOCK(unit) \
    sai_osal_mutex_lock(CLXS_LAG(unit).mutex)
#define CLXS_LAG_UNLOCK(unit) \
    sai_osal_mutex_unlock(CLXS_LAG(unit).mutex)
    
typedef struct CLXS_LAG_ATTR_S {
    CLX_PORT_T lag_port;
    bool drop_untagged;
    bool drop_tagged;
    uint8_t pri;
    uint16_t pvid;
    uint16_t tpid;
    uint32_t egr_group_label;
    sai_object_id_t ingress_acl_table_group_id;
    sai_object_id_t egress_acl_table_group_id;
} CLXS_LAG_ATTR_T;

typedef struct CLXS_LAG_ENTRY_S {
    uint32_t *valid;
    CLXS_LAG_ATTR_T *grp_attr;
    CMLIB_AVL_HEAD_T *mbr_avl;
    CLX_SEMAPHORE_ID_T  mutex;
} CLXS_LAG_ENTRY_T;

typedef struct CLXS_LAG_MBR_NODE_S
{
    uint32_t lag_id; /* KEY */
    CLX_PORT_T port; /* KEY */
    bool ingress_disable;
    bool egress_disable;
} CLXS_LAG_MBR_NODE_T;


extern const sai_lag_api_t              lag_api;
extern CLXS_LAG_ENTRY_T _clxs_lag[CLXS_MAX_CHIP_NUM];

/* API DECLARATIONS
 */
sai_status_t
clxs_lag_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_lag_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_lag_getInfo(
    _In_ const sai_object_id_t oid,
    _Out_ uint32_t             *ptr_unit,
    _Out_ CLX_PORT_T           *ptr_lag_port);

sai_status_t
clxs_lag_getObject(
    _In_ const uint32_t   unit,
    _In_ const CLX_PORT_T lag_port,
    _Out_ sai_object_id_t *ptr_oid);

sai_status_t
clxs_lag_setBindEgrTable(
    sai_object_id_t    lag_object,
    uint32_t        intf_group_label,
    bool        is_add);

sai_status_t
clxs_get_lag_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_lag_member_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#ifdef CLX_LAG_MEMBER_AUTO_UPDATE
void
clxs_lag_member_fail_handler (
    _In_ sai_object_id_t            port_id,
    _In_ sai_port_oper_status_t     port_state);
#endif

sai_status_t clxs_create_lag_member(
        _Out_ sai_object_id_t *lag_member_id,
        _In_ sai_object_id_t switch_id,
        _In_ uint32_t attr_count,
        _In_ const sai_attribute_t *attr_list);

sai_status_t clxs_remove_lag_member(
        _In_ sai_object_id_t lag_member_id);

#endif /* __CLXS_LAG_H__ */
