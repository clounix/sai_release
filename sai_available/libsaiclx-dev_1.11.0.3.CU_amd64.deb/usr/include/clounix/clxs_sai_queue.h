/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_QUEUE_H__)
#define __CLXS_QUEUE_H__

/* MACRO FUNCTION DECLARATIONS
 */


/* DATA TYPE DECLARATIONS
 */
typedef struct CLXS_QUEUE_DB_S
{
    bool                        is_used;
    sai_object_id_t             object_id;
    sai_object_id_t             parent_id;
    sai_object_id_t             scheduler_id;
    sai_object_id_t             wred_id;
    sai_object_id_t             buffer_id;
    CLX_TM_SCH_TOPOLOGY_ENTRY_T topology_entry;
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
    sai_object_list_t            tamlist;
#endif
    uint64_t                    last_drop_pkts;             /**The previous statistical values of drop pkts*/
    uint64_t                    last_drop_bytes;            /**The previous statistical values of drop bytes*/
    uint64_t                    historical_wred_drop_pkts;  /**Historical cumulative values of wred drop pkts*/
    uint64_t                    historical_wred_drop_bytes; /**Historical cumulative values of wred drop bytes*/
#ifdef CLX_WRED_ECN_MARKED_COUNT_USING_ACL
    uint64_t                    historical_ecn_marked_pkts;   /**Historical cumulative values of ecn marked pkts*/
    uint64_t                    historical_ecn_marked_bytes;  /**Historical cumulative values of ecn marked bytes*/
    uint64_t                    last_ecn_marked_pkts;         /**The previous statistical value of ECN marked pkts.*/
    uint64_t                    last_ecn_marked_bytes;        /**The previous statistical value of ECN marked bytes.*/
#endif
} CLXS_QUEUE_DB_T;

typedef struct CLXS_QUEUE_TYPE_DB_S{
    CLXS_QUEUE_DB_T *   uc_queue;
    CLXS_QUEUE_DB_T *   mc_queue;
} CLXS_QUEUE_TYPE_DB_T;

typedef struct CLXS_QUEUE_CB_S{
    void*                   clxs_pfcdl_callback;
    CLXS_QUEUE_TYPE_DB_T     clxs_queue_db[CLXS_MAX_PORT_NUM];
    CLXS_QUEUE_DB_T *         clxs_cpu_queue;
    CLXS_QUEUE_DB_T *     clxs_queue_db_ptr;
} CLXS_QUEUE_CB_T;

extern const sai_queue_api_t            queue_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T queue_stats_capability_info;
extern CLXS_QUEUE_CB_T *_clxs_queue_cb[CLXS_MAX_CHIP_NUM];

/* API DECLARATIONS
 */
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
 /*micro-burst begin*/

#define CLXS_TAM_CONFIG_ADD               (1)
#define CLXS_TAM_CONFIG_DEL                (0)

#endif

#define CLXS_REGISTER_QUEUE_STATS_NOTIFY_UPDATE(func)   do { clxs_queue_stats_notify_update[__MODULE__] = func; } while (0)

typedef sai_status_t (*CLXS_QUEUE_STATS_NOTIFY_UPDATE)(
    _In_ const UI32_T             unit,
    _In_ const UI32_T             port,
    _In_ CLX_TM_HANDLER_TYPE_T    handler_type,
    _In_ const UI32_T             queue_index,
    _In_ UI64_T                   pkt_cnt,
    _In_ UI64_T                   drop_cnt);


extern CLXS_QUEUE_STATS_NOTIFY_UPDATE clxs_queue_stats_notify_update[CLXS_API_MAX];

sai_status_t
clxs_queue_registerCallback(
    _In_ const uint32_t unit,
    _In_ void           *func);

sai_status_t clxs_queue_getQueueDb(
    uint32_t            unit,
    uint32_t            port,
    sai_queue_type_t    type,
    uint32_t            queue_id,
    CLXS_QUEUE_DB_T      *ptr_queue_db);

sai_status_t clxs_queue_setQueueDb(
    uint32_t            unit,
    uint32_t            port,
    sai_queue_type_t    type,
    uint32_t            queue_id,
    CLXS_QUEUE_DB_T      *ptr_queue_db);

sai_status_t clxs_queue_getNum(
    sai_object_id_t     port_object_id,
    uint32_t             *ptr_num);

sai_status_t clxs_queue_getList(
    sai_object_id_t     port_object_id,
    sai_object_id_t     *ptr_list);

sai_status_t clxs_queue_init(
    uint32_t unit);

sai_status_t clxs_queue_deinit(
    uint32_t unit);

sai_status_t clxs_port_wred_apply(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ sai_object_id_t wred_id);

sai_status_t clxs_get_queue_stats_ext(
    _In_ sai_object_id_t queue_id,
    _In_ uint32_t number_of_counters,
    _In_ const sai_stat_id_t *counter_ids,
    _In_ sai_stats_mode_t mode,
    _Out_ uint64_t *counters);

sai_status_t clxs_clear_queue_stats(
        _In_ sai_object_id_t queue_id,
        _In_ uint32_t number_of_counters,
        _In_ const sai_stat_id_t *counter_ids);

#endif /* __CLXS_QUEUE_H__ */
