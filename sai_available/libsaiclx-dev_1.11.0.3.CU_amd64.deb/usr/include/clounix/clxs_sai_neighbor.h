/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_NEIGHBOR_H__)
#define __CLXS_NEIGHBOR_H__
#define MAX_VLAN_ID 4096
#define CLXS_NEIGHBOR_CB(unit) (ptr_clxs_neighbor_cb[unit])

#define CLXS_NEIGHBOR_LOCK(unit) \
    osal_takeSemaphore(&ptr_clxs_neighbor_cb[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER)

#define CLXS_NEIGHBOR_UNLOCK(unit) \
    osal_giveSemaphore(&ptr_clxs_neighbor_cb[unit]->sema)
    
typedef struct
{
    UI32_T intf_id;  /* L3 egress interface ID */
    UI32_T  mc_id;
    uint16_t enable;
    uint8_t intf_mac[6];
    uint32_t vrf_id;
    CMLIB_LIST_T        *ip_list; /* ip list */
    CLX_PORT_BITMAP_T   port_bitmap;
}CLXS_BC_NEIGH_DB_T;

typedef struct
{
    uint32_t adj_id;                        /**next hop id*/
    sai_object_id_t rif_id;                 /**rif*/
}CLXS_NEIGHBOR_ADJ_DATA_T;

typedef struct
{
    uint32_t                vrf_id;         /**key*/
    sai_ip_address_t        ip_address;     /**key*/
    sai_object_id_t         switch_id;
    sai_object_id_t         counter_id;
    sai_packet_action_t     pkt_action;
    bool                    no_host;
    uint32_t                adj_in_use;
    uint32_t                user_meta;
    CMLIB_LIST_T            *adj_list;     /**different rif\adj by each, date type:CLXS_NEIGHBOR_ADJ_DATA_T*/
} CLXS_NEIGHBOR_ENTRY_T;
typedef struct
{
    CMLIB_AVL_HEAD_T        *ptr_neighbor_avl;
    CLX_SEMAPHORE_ID_T      sema;

} CLXS_NEIGHBOR_CB_T;

extern const sai_neighbor_api_t    neighbor_api;
extern CLXS_NEIGHBOR_CB_T          *ptr_clxs_neighbor_cb[CLXS_MAX_CHIP_NUM];

sai_status_t clxs_neighbor_init(
    _In_ const uint32_t           unit);

sai_status_t clxs_neighbor_deinit(
    _In_ const uint32_t           unit);

sai_status_t clxs_neighbor_getInfo(
    _In_ const sai_neighbor_entry_t     *ptr_neighbor,
    _Out_ CLX_L3_HOST_INFO_T            *ptr_host_info,
    _Out_ uint32_t                      *ptr_adj_id,
    _Out_ CLX_L3_ADJ_INFO_T             *ptr_adj_info);
sai_status_t
clxs_neighbor_getMaxCount(_In_ UI32_T unit, _Out_ UI32_T* count);
#if 0
sai_status_t clxs_neighbor_route_add_update(
    UI32_T unit,
    CLX_L3_ROUTE_INFO_T* route_info,
    UI32_T intf_id);

sai_status_t clxs_neighbor_route_delete_update(
    UI32_T unit,
    CLX_L3_ROUTE_INFO_T* route_info,
    UI32_T intf_id);
#endif
sai_status_t clxs_bc_neigh_update_vlan_member(
    _In_ BOOL_T add,
    _In_  uint32_t unit,
    _In_ CLX_VLAN_T vlan,
    _In_ CLX_PORT_BITMAP_T port_bitmap);

sai_status_t
clxs_create_neighbor_entry(
    _In_ const sai_neighbor_entry_t *neighbor_entry,
    _In_ uint32_t                   attr_count,
    _In_ const sai_attribute_t      *attr_list);

sai_status_t
clxs_remove_neighbor_entry(
    _In_ const sai_neighbor_entry_t *neighbor_entry);

sai_status_t
clxs_set_neighbor_entry_attribute(
    _In_ const sai_neighbor_entry_t *neighbor_entry,
    _In_ const sai_attribute_t      *attr);

sai_status_t
clxs_get_neighbor_entry_attribute(
    _In_ const sai_neighbor_entry_t *neighbor_entry,
    _In_ uint32_t               attr_count,
    _Inout_ sai_attribute_t     *attr_list);

CLXS_BC_NEIGH_DB_T *
_clxs_get_bc_neigh_db(_In_ UI32_T unit, _In_ CLX_VLAN_T vlan);

#endif
