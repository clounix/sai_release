/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_NEXTHOP_H__)
#define __CLXS_NEXTHOP_H__

/* NAMING CONSTANT DECLARATIONS
 */
 /* to use in list, void* high half keeping 1 to avoid null checks */
#define U32_TO_PVOID(x) ((void *)((char *)(1L << 32) + (uint32_t)(x)))
#define PVOID_TO_U32(x) ((uint32_t)((char *)(x) - (char *)(1L << 32)))
#define INVALID_L3_ADJ_ID 0xffffffff
#define  CLXS_NEXTHOP_CB(__unit__) (_ptr_clxs_nexthop_cb[(__unit__)])
#define CLXS_NEXTHOP_LOCK(unit) sai_osal_mutex_lock(_ptr_clxs_nexthop_sema[unit])

#define CLXS_NEXTHOP_UNLOCK(unit) sai_osal_mutex_unlock(_ptr_clxs_nexthop_sema[unit])

#define CREATE_NEXTHOP  (1 << 0)
#define REMOVE_NEXTHOP  (1 << 1)
#define ADD_MACADDR     (1 << 2)
#define DEL_MACADDR     (1 << 3)
#define SET_ADJACTION   (1 << 4)

/*although these cmds can not exist at same time, maybe we can use enum to describe it
   but i keep the possibility something can do together*/
#define SET_TUNNEL_VNI     (1 << 0)
#define UNSET_TUNNEL_VNI     (1 << 1)
#define SET_TUNNEL_MAC      (1 << 2)
#define UPDATE_VRF_VNI      (1 << 3)
#define ADD_ROUTE      (1 << 4)
#define DELETE_ROUTE      (1 << 5)

typedef struct
{
    CLX_BRIDGE_DOMAIN_T     bdid;
    CLX_MAC_T               mac;
    CLX_PORT_T              port;
    CMLIB_LIST_T            *adj_id_list;
} CLXS_NEXTHOP_L2_T;

typedef struct
{
    sai_next_hop_type_t     type;       /* SAI_NEXT_HOP_ATTR_TYPE                */
    sai_ip_address_t        ip;         /* SAI_NEXT_HOP_ATTR_IP  OR
                                                    SAI_NEXT_HOP_TYPE_MPLS OR
                                                    SAI_NEXT_HOP_TYPE_TUNNEL_ENCAP  */
    sai_object_id_t         rif_id;     /* SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID */
    sai_object_id_t         tunnel_id;  /* SAI_NEXT_HOP_ATTR_TUNNEL_ID           */
    sai_uint32_t             tunnel_vni;  /* SAI_NEXT_HOP_ATTR_TUNNEL_VNI        */
    sai_mac_t                tunnel_mac;  /* SAI_NEXT_HOP_ATTR_TUNNEL_MAC      */
#define CLXS_NEXTHOP_TUNNEL_VNI_CONFIGURED   (1<<0)
#define CLXS_NEXTHOP_TUNNEL_MAC_CONFIGURED   (1<<1)
    uint32_t                flags;
#if SAI_API_VERSION < SAI_VERSION(1,9,0)
	sai_object_id_t         segr_slt_id;  /* SAI_NEXT_HOP_ATTR_SEGMENTROUTE_SIDLIST_ID           */
    sai_next_hop_endpoint_type_t      segr_ept_type;  /* SAI_NEXT_HOP_ATTR_SEGMENTROUTE_ENDPOINT_TYPE           */
    sai_next_hop_endpoint_pop_type_t     segr_eptp_type; /* SAI_NEXT_HOP_ATTR_SEGMENTROUTE_ENDPOINT_POP_TYPE           */
#endif
	sai_u32_list_t       labelstack;     /* SAI_NEXT_HOP_ATTR_LABELSTACK           */
    bool                    invalid;
    uint32_t                nexthop_id;     /* clxssai-metadata */
    uint32_t                ref_cnt;
    CMLIB_LIST_T            *vrf_adj_list;   /*adj_id on each vrf*/
} CLXS_NEXTHOP_DB_T;

typedef struct
{
    CMLIB_AVL_HEAD_T    *ptr_nh_info_avl;             /*nexthop info avl*/
    CMLIB_AVL_HEAD_T    *ptr_nh_id_avl;               /*nexthop id avl*/
    CMLIB_AVL_HEAD_T    *ptr_nh_l2addr_avl;           /*nexthop l2addr avl */
    CMLIB_AVL_HEAD_T    *ptr_nh_adjid_tunnel_map_avl; /*nexthop adjid avl, it's only for tunnel encap*/
    uint32_t             default_vrf_id;
    uint32_t             last_tunnel_encap_adj_id;

} CLXS_NEXTHOP_CB_T;

extern const sai_next_hop_api_t         nexthop_api;
extern CLX_SEMAPHORE_ID_T _ptr_clxs_nexthop_sema[CLXS_MAX_CHIP_NUM];
extern CLXS_NEXTHOP_CB_T     *_ptr_clxs_nexthop_cb[CLXS_MAX_CHIP_NUM];

/* API DECLARATIONS
 */
sai_status_t
clxs_nexthop_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthop_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthop_getObj(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         adj_id,
    _Out_ sai_object_id_t       *ptr_next_hop_id);

sai_status_t
clxs_nexthop_getInfo(
    _In_ const sai_object_id_t  next_hop_id,
    _In_ const uint32_t  vrf_id,
    _In_ const uint32_t  flags,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_adj_id);

sai_status_t clxs_nexthop_updateL2Addr(
    _In_ const uint32_t              unit,
    _In_ const CLX_L2_ADDR_T         *ptr_l2_addr,
    _In_ const uint32_t              reason);


void clxs_nexthop_tunnel_map_encap_update(uint32_t unit, uint32_t vrf_id, uint32_t vni);
void clxs_nexthop_switch_vxlan_mac_update(uint32_t unit);

sai_status_t
clxs_nexthop_set_ip_adj(
    _In_  uint32_t              unit,
    _In_ sai_object_id_t        rif_id,
    _In_ sai_ip_address_t       ip_address,
    _In_ uint32_t               flags,
    _In_ void                   *mac_addr,
    _Out_ uint32_t              *out_adj_id);

sai_status_t clxs_nexthop_update_by_adj_id(
    _In_  uint32_t              unit,
    _In_  uint32_t              vrf_id,
    _In_  uint32_t              adj_id);

sai_status_t
clxs_nexthop_get_adj_id(
    _In_ uint32_t               unit,
    _In_ sai_object_id_t        rif_id,
    _In_ sai_ip_address_t       ip_address,
    _Out_ uint32_t              *out_adj_id);


#endif /* __CLXS_NEXTHOP_H__ */
