/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_PKT_RX_H__)
#define __CLXS_PKT_RX_H__

#define CLXS_PKT_MAC_LEN_BYTE                     (6)
#define CLXS_PKT_VXLAN_LEN_WORD                   (2)
#define CLXS_PKT_IPV4_LEN_WORD                    (5)
#define CLXS_PKT_IPV6_LEN_WORD                    (10)
#define CLXS_PKT_ETH_P_8021Q     0x8100 /* 802.1q Service VLAN */
#define CLXS_PKT_ETH_P_8021AD    0x88A8 /* 802.1ad Service VLAN */
#define CLXS_PKT_ETHERTYPE_IPV4  0x0800
#define CLXS_PKT_ETHERTYPE_IPV6  0x86dd
#define SAI_PACKET_ACTION_MAX           8


extern const CLX_FWD_ACTION_T           ext_sai_action_to_clx_map[SAI_PACKET_ACTION_MAX];
extern const sai_packet_action_t        ext_clx_action_to_sai_map[CLX_FWD_ACTION_LAST];
extern const CLX_FWD_ACTION_T           swc_sai_action_to_clx_map[SAI_PACKET_ACTION_MAX];

#define SAI_FWD_ACTION_TO_CLXS(__action__)     ext_sai_action_to_clx_map[__action__]
#define CLXS_FWD_ACTION_TO_SAI(__action__)     ext_clx_action_to_sai_map[__action__]
#define CLXS_PKT_PORT_INDEX_TO_PHYPORT(__port__)        ((__port__ & 0x000000ff))

/* CLXS_PKT ETH/ETH_VLAN/VXLAN_EVPN_IPV4/VXLAN_EVPN_VLAN_IPV4/VXLAN_EVPN_QINQ/VXLAN_EVPN_IPV6/VXLAN_EVPN_VLAN_IPV6/VXLAN_EVPN_QINQ_IPV6 PKT struct START */
typedef struct
{
    uint8_t  dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
} CLXS_PKT_ETH_T;

typedef struct
{
    uint8_t  dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
} CLXS_PKT_ETH_VLAN_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
    uint32_t outer_ipv4[CLXS_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_IPV4_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv4[CLXS_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_VLAN_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t outer_vlan_type;
    uint16_t outer_vlan_tag;
    uint16_t inner_vlan_type;
    uint16_t inner_vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv4[CLXS_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_QINQ_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
    uint32_t outer_ipv6[CLXS_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_IPV6_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv6[CLXS_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_VLAN_IPV6_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t outer_vlan_type;
    uint16_t outer_vlan_tag;
    uint16_t inner_vlan_type;
    uint16_t inner_vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv6[CLXS_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_QINQ_IPV6_T;
/* CLXS_PKT ETH/ETH_VLAN/VXLAN_EVPN_IPV4/VXLAN_EVPN_VLAN_IPV4/VXLAN_EVPN_QINQ/VXLAN_EVPN_IPV6/VXLAN_EVPN_VLAN_IPV6/VXLAN_EVPN_QINQ_IPV6 PKT struct END */



sai_status_t
clxs_pkt_rx_registerCallback(
    _In_ const uint32_t         unit,
    _In_ void                   *ptr_func);

sai_status_t
clxs_pkt_rx_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_pkt_rx_deinit(
    _In_ const uint32_t         unit);
#endif
