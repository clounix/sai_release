/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_TUNNEL_H__)
#define __CLXS_TUNNEL_H__

#if SAI_API_VERSION >= SAI_VERSION(1,7,3)
#define CLXS_MAX_TUNNEL_TYPES_NUM SAI_TUNNEL_TYPE_MPLS + 1
#endif

/* MACRO FUNCTION DECLARATIONS
 */
 #define CLXS_TNL_LOCK(__unit__)                                  \
    sai_osal_mutex_lock(_clxs_tunnel_cb[(__unit__)].tnl_sema)
#define CLXS_TNL_UNLOCK(__unit__)                                \
    sai_osal_mutex_unlock(_clxs_tunnel_cb[(__unit__)].tnl_sema)

#define CLXS_TUNNEL_QOSMAP_PROF_INDEX_BASE        (CLXS_MAX_PORT_NUM)

#define CLXS_TUNNEL_FOREACH(__unit__, __tunnel__)                              \
    for (__tunnel__ = 0; __tunnel__ < CLXS_MAX_TUNNEL_NUM(__unit__); __tunnel__++)    \


/* tunnel_map_entry */
typedef struct CLXS_TUNNEL_MAP_ENTRY_S
{
    UI32_T id;
    sai_attribute_value_t key; /* (key, val) mapping */
    sai_attribute_value_t val;
}   CLXS_TUNNEL_MAP_ENTRY_T;

/* tunnel_map */
typedef struct CLXS_TUNNEL_MAP_S
{
    UI32_T map_id;  /* key of avl tree, sai_obj_id.data, not sai_obj_id */
    sai_tunnel_map_type_t type;
    /*add new member before this line*/
    CMLIB_LIST_T  *ptr_list;    /* CLXS_TUNNEL_MAP_ENTRY_T */
    UI32_T last_entry_id;       /* last map_id in ptr_list */
    /* the number always increases even any is removed */
}   CLXS_TUNNEL_MAP_T;

/* clx tunnel */
typedef struct CLXS_TUNNEL_CLX_S
{
    CLX_TUNNEL_KEY_T key;   /* key of list lookup */
    /* init direction, regardless of uc/mc */

    UI32_T clx_id;          /* term only, for tunnel_term_obj_id */

    UI32_T flags;           /* refers CLXS_TUNNEL_FLAGS_xxx */
    UI32_T clx_port;        /* 0: invalid, >0: clx_l3t_createPort()'s return value */

    sai_api_t init_caller;  /* init is created by which module */
    /* this is used to avoid incorrect deletion by other module */

    /* from sai_tunnel_term_table_entry_attr_t */
    sai_object_id_t sai_term_vr_id;
    sai_tunnel_term_table_entry_type_t sai_term_type;
}   CLXS_TUNNEL_CLX_T;

#define VNI_ASSIGNED (1 << 0)
typedef struct CLXS_TUNNEL_NEXTHOP_TUNNEL_S
{
    uint32_t nexthop_id; /*key*/
    sai_ip_address_t endpoint_ip;
    uint32_t vni;
    CLX_PORT_T port;
    uint32_t flags;

} CLXS_TUNNEL_NEXTHOP_TUNNEL_T;

/*if  added vni assigned nexthop tunnel, and the vni not in our maps
   create it and add segService with invalid bdid or rif_id, if map entry added later, cover it.
   with vrf/bdid/rif_id valid.
   if map entry removed, search from  vni assigned nexthop_tunnel, if still exist, renew the seg, or delete it*/
typedef struct CLXS_TUNNEL_VNI_MAP_S
{
    CLX_PORT_T port;    /*key*/
    uint32_t vni;       /*key*/
    uint32_t vrf_id;
    uint32_t bdid;
    uint32_t rif_id;
    uint32_t vni_assigned_count;
} CLXS_TUNNEL_VNI_MAP_T;

/* sai tunnel */
typedef struct CLXS_TUNNEL_SAI_S
{
    UI32_T sai_id;  /* key of avl tree, sai_obj_id.data, not sai_obj_id */

    /* from sai_tunnel_attr_t */
    sai_tunnel_type_t sai_tunnel_type;
    sai_object_id_t sai_underlay_rif;   /* l3_intf for init */
    sai_object_id_t sai_overlay_rif;    /* l3_intf for term */
    UI32_T encap_gre_key_valid;
    UI32_T gre_key;                     /* valid when encap_gre_key_valid=1 */
    sai_tunnel_encap_ecn_mode_t encap_ecn_mode;
    sai_tunnel_decap_ecn_mode_t decap_ecn_mode;

    /* clx related settings */
    CLX_L3T_INIT_INFO_T init_info;
    CLX_L3T_TERM_INFO_T term_info;
    /* refs to the bridge-port for this tunnel if exist, default is zero
         maybe in the future one tunnel can bind to more then one bridge?
         but now design do not support it, if support it in the future,
         we can use sai_object_list_t instead*/
    sai_object_id_t bridge_port_id;
    bool bridge_port_learn;
    bool bridge_port_admin;

    /*add new member before this line*/
    sai_object_list_t encap_mappers;
    sai_object_list_t decap_mappers;
    CMLIB_LIST_T  *ptr_nexthop_tunnel_list; /* CLXS_TUNNEL_NEXTHOP_TUNNEL_T */
    CMLIB_LIST_T  *ptr_vni_map_list;        /* CLXS_TUNNEL_VNI_MAP_T */
    CMLIB_LIST_T  *ptr_tnl_list;            /* CLXS_TUNNEL_CLX_T */
    UI32_T last_clx_id;                     /* last clx_id in ptr_tnl_list */
    UI32_T is_attr_config_flag;
    sai_object_id_t qosmap_oid[CLXS_QOSMAP_TYPES_MAX];
    UI32_T hw_profile_id[CLXS_QOSMAP_TYPES_MAX];
    /* the number always increases even any is removed */
}   CLXS_TUNNEL_SAI_T;


typedef struct
{
    bool is_valid;
    UI32_T attr_flag;
    sai_object_id_t switch_tunnel_id;

    sai_packet_action_t  packet_loopback_action;

    sai_tunnel_encap_ecn_mode_t encap_ecn_mode;
    sai_tunnel_decap_ecn_mode_t decap_ecn_mode;
    sai_object_list_t encap_mappers;
    sai_object_list_t decap_mappers;

    uint16_t                          src_port_base;
    uint8_t                           src_port_mask;

#if (SAI_API_VERSION >= SAI_VERSION(1,7,3) && SAI_API_VERSION < SAI_VERSION(1,9,0)) || \
    (SAI_API_VERSION >= SAI_VERSION(1,10,2))
    sai_tunnel_vxlan_udp_sport_mode_t src_port_mode;
    sai_object_id_t              encap_qos_tc_and_color_to_dscp;
    sai_object_id_t              encap_qos_tc_to_queue;
    sai_object_id_t              decap_qos_dscp_to_tc;
    sai_object_id_t              decap_qos_tc_to_pg;
#endif
} CLXS_SWITCH_TUNNEL_ATTR_T;

typedef struct
{
    CMLIB_AVL_HEAD_T    *ptr_sai_avl;   /* CLXS_TUNNEL_SAI_T */
    UI32_T              last_sai_id;    /* last tnl_id in ptr_tnl_avl */
    /* the number always increases even any is removed */

    CMLIB_AVL_HEAD_T    *ptr_tnl_map_avl;           /* CLXS_TUNNEL_MAP_T */
    UI32_T              last_tnl_map_id;            /* last map_id in ptr_tnl_map_avl */
    /* the number always increases even any is removed */
    CMLIB_AVL_HEAD_T    *ptr_dstip_avl;             /*TUNNEL_DSTIP_MAP_T*/
    CMLIB_AVL_HEAD_T    *ptr_nvo3_output_info_avl;  /*NVO3_OUTPUT_INFO_T*/
    CMLIB_AVL_HEAD_T    *ptr_tnl_port_avl;          /*struct tunnel_port_map*/

#if (SAI_API_VERSION >= SAI_VERSION(1,7,3))
    CLXS_SWITCH_TUNNEL_ATTR_T switch_tunnel[CLXS_MAX_TUNNEL_TYPES_NUM];
#endif

    CLX_SEMAPHORE_ID_T  tnl_sema;
    CLX_SEMAPHORE_ID_T  map_sema;
    
}   CLXS_TUNNEL_CB_T;

struct nvo3_ecmp_grp
{
    UI32_T nvo3_ecmp_grp_id;
    UI32_T nvo3_adj_id; /*used for l2mc,record which adj id is used for l2mc, if l2mc support ecmp, it is useless*/
    /*add new member before this line*/
    CMLIB_LIST_T* group_members;
};

typedef struct nvo3_output_info
{
    CLX_L3_OUTPUT_TYPE_T type;/*only NVO3_ADJ OR ECMP is valid now*/
    union
    {
        UI32_T ecmp_grp_id;
        UI32_T l3_adj_id;
    } ref;
    /*add new member after this line*/
    UI32_T refcnt;
    union
    {
        struct nvo3_ecmp_grp ecmp_grp;
        UI32_T nvo3_adj_id;
    } u;
} NVO3_OUTPUT_INFO_T;

typedef struct tunnel_dstip_map
{
    UI32_T                      vrf_id;
    sai_ip_address_t   addr;
    sai_ip_address_t   mask; /*the netmask of route found---that means route with shorter mask not refers to me*/
    UI32_T refcnt;

    /*add new member before this line*/
    NVO3_OUTPUT_INFO_T* output_info;
} TUNNEL_DSTIP_MAP_T;

struct tunnel_port_map
{
    CLX_PORT_T tunnel_port;/* key of avl tree*/
    UI32_T sai_id;
    sai_ip_address_t   dst_ip;
};

extern const sai_tunnel_api_t           tunnel_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T tunnel_stats_capability_info;
extern CLXS_TUNNEL_CB_T _clxs_tunnel_cb[CLXS_MAX_CHIP_NUM];

/* API DECLARATIONS
 */
sai_status_t
clxs_tunnel_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_tunnel_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_tunnel_getInfo(
    _In_ const sai_api_t init_caller,
    _In_ const sai_object_id_t tunnel_id,
    _In_ const sai_ip_address_t *ptr_dip,
    _Out_ uint32_t *ptr_unit,
    _Out_ CLX_TUNNEL_KEY_T *ptr_key,
    _Out_ CLX_PORT_T *ptr_port);

sai_status_t
clxs_tunnel_get_tunnel_port_vni(
    _In_ sai_object_id_t tunnel_id,
    _In_ uint32_t vrf_id,
    _In_ sai_ip_address_t ipaddr,
    _Out_ CLX_PORT_T *port,
    _Out_ uint32_t *vni,
    _Out_ uint32_t *l3_intf_id);

sai_status_t
clxs_tunnel_add_nexthop_tunnel(
    UI32_T unit, UI32_T clxs_next_hop_id,
    sai_object_id_t  sai_tunnel_id,
    sai_ip_address_t endpoint_ip, UI32_T tunnel_vni,
    UI32_T vni_configured);

sai_status_t
clxs_tunnel_remove_nexthop_tunnel(
    UI32_T unit, UI32_T clxs_next_hop_id,
    sai_object_id_t sai_tunnel_id,
    sai_ip_address_t endpoint_ip, UI32_T tunnel_vni,
    UI32_T vni_configured);

sai_status_t
clxs_tunnel_update_nexthop_tunnel_vni(
    UI32_T unit, sai_object_id_t sai_tunnel_id,
    UI32_T clxs_next_hop_id, UI32_T tunnel_vni);

sai_status_t
clxs_get_tunnel_portList(
    _In_ const sai_object_id_t tunnel_id,
    _Out_ uint32_t *unit,
    _Out_ CLX_PORT_T port_list[CLX_PORT_NUM],
    _Out_ uint32_t *pcount);

bool clxs_tunnel_is_vxlan(
    _In_ sai_object_id_t tunnel_id);

sai_status_t
clxs_tunnel_port_get_ref_bridge_port(
    _In_ const UI32_T unit,
    _In_ const CLX_PORT_T tunnel_port,
    _Out_ sai_object_id_t* bridge_port_id,
    _Out_ sai_ip_address_t* dst_ip);

sai_status_t
clxs_tunnel_set_ref_bridge_port(
    _In_ const sai_object_id_t tunnel_id,
    _In_ const sai_object_id_t bridge_port_id);

sai_status_t
clxs_tunnel_host_update(
    UI32_T unit,
    CLX_L3_HOST_INFO_T* host_info);

sai_status_t
clxs_tunnel_adj_update(
    UI32_T unit,
    UI32_T l3_adj_id);

sai_status_t
clxs_tunnel_route_update(
    UI32_T unit,
    CLX_L3_ROUTE_INFO_T* route_info);

sai_status_t
clxs_tunnel_ecmp_grp_update(
    UI32_T unit,
    UI32_T ecmp_grp_id,
    BOOL_T add,
    UI32_T adj_id);

sai_status_t
clxs_set_tunnel_port_lrn(
    _In_ const uint32_t   unit,
    _In_ const sai_object_id_t tunnel_id,
    _In_ const bool  lrn_en,
    _In_ const bool  fwd,
    _In_ const bool  to_cpu);

sai_status_t
clxs_set_tunnel_port_admin(
    _In_ const uint32_t   unit,
    _In_ const sai_object_id_t tunnel_id,
    _In_ const bool  admin);

sai_status_t
clxs_get_tunnel_map_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_term_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_map_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#if SAI_API_VERSION >= SAI_VERSION(1,7,3)
sai_status_t _clxs_tunnel_get_switch_tunnel_attr(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t switch_tunnel_type,
    _In_  sai_switch_tunnel_attr_t id,
    _Out_ sai_attribute_value_t *ptr_val);
sai_status_t
 _clxs_tunnel_set_switch_tunnel_attr(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t switch_tunnel_type,
    _In_  sai_switch_tunnel_attr_t id,
    _In_  const sai_attribute_value_t *ptr_val);

sai_status_t _clxs_tunnel_create_switch_tunnel(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t tunnel_type,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);

sai_status_t _clxs_tunnel_remove_switch_tunnel(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t tunnel_type);

sai_status_t clxs_tunnel_get_switch_tunnel(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t tunnel_type,
    _Out_ sai_object_id_t *ptr_switch_tunnel_id);

sai_status_t clxs_tunnel_set_switch_tunnel(
    _In_ UI32_T unit,
    _In_ sai_object_id_t switch_tunnel_id);
#endif

sai_status_t clxs_create_tunnel(
    _Out_ sai_object_id_t *ptr_tunnel_id,
    _In_ sai_object_id_t switch_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);
sai_status_t clxs_remove_tunnel(
    _In_ sai_object_id_t tunnel_id);
sai_status_t
clxs_set_tunnel_attribute(
    _In_ sai_object_id_t tunnel_id,
    _In_ const sai_attribute_t *ptr_attr);
sai_status_t
clxs_get_tunnel_attribute(
    _In_ sai_object_id_t tunnel_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *ptr_attr_list);

#endif /* __CLXS_TUNNEL_H__ */
