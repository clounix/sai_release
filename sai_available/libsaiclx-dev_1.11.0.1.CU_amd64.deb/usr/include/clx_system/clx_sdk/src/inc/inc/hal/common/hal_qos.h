/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_qos.h
 * PURPOSE:
 *      It provides hal qos module API.
 * NOTES:
 *      None.
 */

#ifndef HAL_QOS_H
#define HAL_QOS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_qos.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_QOS_PHB_PROFILE_NUM          (128)          /* qos phb_prof_idx max alloc number */
#define HAL_QOS_TC_NUM                   (16)           /* total number of traffice class for qos mapping */

/* MACRO FUNCTION DECLARATIONS
 */


/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_QOS_INTF_TYPE_LCL_INTF,
    HAL_QOS_INTF_TYPE_SRV_INTF,
    HAL_QOS_INTF_TYPE_LAST
} HAL_QOS_INTF_TYPE_T;


/* LOCAL SUBPROGRAM DECLARATIONS
 */


/* FUNCTION NAME:   hal_qos_init
 * PURPOSE:
 *     Init qos module.
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    --  Operate success.
 *      CLX_E_OTHER --  Init fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_qos_init(
    const UI32_T                 unit);




/* FUNCTION NAME:   hal_qos_deinit
 * PURPOSE:
 *      Deinitialize Qos module.
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      --  Deinitialize success.
 *      CLX_E_OTHERS  --  Deinitialize failed.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_qos_deinit(
    const UI32_T                 unit);




/* FUNCTION NAME:   hal_qos_createProfile
 * PURPOSE:
 *      create a priority mapping profile.
 * INPUT:
 *      unit          --  Device unit number.
 *      mapping_type  --  The type of the mapping profile.
 *                            CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                the mapping of ingress pcp/dei to phb.
 *                            CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                the mapping of ingress dscp to phb.
 *                            CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                the mapping of ingress exp to phb.
 *                            CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                the mapping of egress phb to pcp/dei.
 *                            CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                the mapping of egress phb to dscp.
 *                            CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                the mapping of egress phb to exp.
 *      profile_id    --  an int value which means the mapping profile id and aslo the index in hardware table.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_TABLE_FULL    --  NO more memory for the entry.
 *      CLX_E_EXISTS        --  The mapping proile is alreaded created.
 * NOTES:
 *      Use this API to create a new mapping profile.
 */
CLX_ERROR_NO_T
hal_qos_createProfile (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profile_id);




/* FUNCTION NAME:   hal_qos_delProfile
 * PURPOSE:
 *      delete a priority mapping profile.
 * INPUT:
 *      unit          --  Device unit number.
 *      mapping_type  --  The type of the mapping profile.
 *                            CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                the mapping of ingress pcp/dei to phb.
 *                            CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                the mapping of ingress dscp to phb.
 *                            CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                the mapping of ingress exp to phb.
 *                            CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                the mapping of egress phb to pcp/dei.
 *                            CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                the mapping of egress phb to dscp.
 *                            CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                the mapping of egress phb to exp.
 *      profile_id     --  an int value which means the mapping profile id and also the index in hardware table.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              --  Operate success.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  The mapping proile is not exist.
 *      CLX_E_NOT_SUPPORT     --  Not support to delete the mapping profile.
 *                              (eg. the mapping profile has been applied to a port/vm/interface/tunnel and so on)
 * NOTES:
 *      Use this API to destroy a  mapping profile.  Only when the mapping profile is not used by other objects
 *      (such as port/vm/interface/tunnel and so on) can destroy it.
 *       if "profile_id" is 0, return CLX_E_NOT_SUPPORT because chip must
 *  have the default mapping of ingress pcp/dei to phb.
 */
CLX_ERROR_NO_T
hal_qos_delProfile (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profile_id);




/* FUNCTION NAME:   hal_qos_setProfileEntry
 * PURPOSE:
 *      configure a priority mapping entry.
 * INPUT:
 *      unit          --  Device unit number.
 *      mapping_type  --  The type of the mapping profile.
 *                            CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                the mapping of ingress pcp/dei to phb.
 *                            CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                the mapping of ingress dscp to phb.
 *                            CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                the mapping of ingress exp to phb.
 *                            CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                the mapping of egress phb to pcp/dei.
 *                            CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                the mapping of egress phb to dscp.
 *                            CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                the mapping of egress phb to exp.
 *      profile_id  --  an int value which means the mapping profile id and also the index in hardware table.
 *      entry       --  the entry of the priority mapping.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              --  Operate success.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  The mapping proile is not found.
 * NOTES:
 *      Use this API to configure a mapping entry.
 *      User should set all fields needed according to the "mapping_type" parameter in entry.
 *      if "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB,
 *          fields "pcp","dei", "tc", "color" must be input by user and ignor other fields.
 *      if "mapping_type" is CLX_QOS_MAPPING_DSCP_TO_PHB,
 *          fields "dscp", "tc", "color" must be input by user and ignor other fields.
 *      if "mapping_type" is CLX_QOS_MAPPING_EXP_TO_PHB,
 *          fields "exp", "tc", "color" must be input by user and ignor other fields.
 *      if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI,
 *          fields "pcp", "dei", "tc", "color" must be input by user and ignor other fields.
 *      if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_DSCP,
 *          fields "dscp", "tc", "color" must be input by user and ignor other fields.
 *      if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_EXP,
 *          fields "exp", "tc", "color" must be input by user and ignor other fields.
 */
CLX_ERROR_NO_T
hal_qos_setProfileEntry (
    const UI32_T                     unit,
    const CLX_QOS_MAPPING_TYPE_T     mapping_type,
    const UI32_T                     profile_id,
    const CLX_QOS_MAPPING_ENTRY_T   *ptr_entry);




/* FUNCTION NAME:   hal_qos_getProfileEntry
 * PURPOSE:
 *      get a priority mapping entry.
 * INPUT:
 *      unit          --  Device unit number.
 *      mapping_type  --  The type of the mapping profile.
 *                            CLX_QOS_MAPPING_PCP_DEI_TO_PHB means
 *                                the mapping of ingress pcp/dei to phb.
 *                            CLX_QOS_MAPPING_DSCP_TO_PHB means
 *                                the mapping of ingress dscp to phb.
 *                            CLX_QOS_MAPPING_EXP_TO_PHB means
 *                                the mapping of ingress exp to phb.
 *                            CLX_QOS_MAPPING_PHB_TO_PCP_DEI means
 *                                the mapping of egress phb to pcp/dei.
 *                            CLX_QOS_MAPPING_PHB_TO_DSCP means
 *                                the mapping of egress phb to dscp.
 *                            CLX_QOS_MAPPING_PHB_TO_EXP means
 *                                the mapping of egress phb to exp.
 *      profile_id    --  an int value which means the mapping profile id and also the index in hardware table.
 *      ptr_entry     --  the entry which the user want to get.
 *                            if "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB,
 *                                fields "pcp", "dei" are the input.
 *                            if "mapping_type" is CLX_QOS_MAPPING_DSCP_TO_PHB,
 *                                fields "dscp" is the input.
 *                            if "mapping_type" is CLX_QOS_MAPPING_EXP_TO_PHB,
 *                                fields "exp" is the input.
 *                            if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI or CLX_QOS_MAPPING_PHB_TO_DSCP or
 *                           "CLX_QOS_MAPPING_PHB_TO_EXP"
 *                                fields "tc", "color" are the input.
 * OUTPUT:
 *      ptr_entry     --  the entry which return to the user.
 *                      if "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB or CLX_QOS_MAPPING_DSCP_TO_PHB
 *                          or CLX_QOS_MAPPING_EXP_TO_PHB, fields "tc", "color" are output.
 *                      if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI, fields "pcp", "dei" are output.
 *                      if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_DSCP, fields "dscp" is output.
 *                      if "mapping_type" is CLX_QOS_MAPPING_PHB_TO_EXP, fields "exp" is output.
 * RETURN:
 *      CLX_E_OK              --  Operate success.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  the mapping profile_id is not exists.
 * NOTES:
 *      Use this API to get a mapping entry.
 */
CLX_ERROR_NO_T
hal_qos_getProfileEntry (
    const UI32_T                     unit,
    const CLX_QOS_MAPPING_TYPE_T     mapping_type,
    const UI32_T                     profile_id,
    CLX_QOS_MAPPING_ENTRY_T         *ptr_entry);




/* FUNCTION NAME:   hal_qos_applyProfile
 * PURPOSE:
 *      apply or unapply a priority mapping profile.
 * INPUT:
 *      unit          --  Device unit number.
 *      intf_type   -- Interface type: Local interface and L2 service interface.
 *      mapping_type  --  The type of the mapping profile.
 *                                  CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress pcp/dei to phb
 *                                  CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb
 *                                  CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp to phb
 *                                  CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei
 *                                  CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb to dscp
 *                                  CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp
 *      profile_id    --  an int value which means the mapping profile id and aslo the index in hardware table.
 *                        0 ~ 127: apply profile; CLX_QOS_INVALID_PROFILE_ID: cancel to apply profile.
 *      ptr_phb_prof_idx  --  Pointer for the old phb_prof_idx in table L2_LCL_INTF or L2_SRV_INTF.
 * OUTPUT:
 *      ptr_phb_prof_idx  --  qos module return a new phb_prof_idx to applier.
 * RETURN:
 *      CLX_E_OK             --  Operate success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_TABLE_FULL     --  NO more memory for apply.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_qos_applyProfile(
    const UI32_T                    unit,
    const HAL_QOS_INTF_TYPE_T   intf_type,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profile_id,
    UI32_T                         *ptr_phb_prof_idx);




#endif  /* End of HAL_QOS_H */


