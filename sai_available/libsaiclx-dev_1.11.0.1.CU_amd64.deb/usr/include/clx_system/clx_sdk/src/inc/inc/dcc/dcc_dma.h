/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  dcc_dma.h
 * PURPOSE:
 *  1. Provide the access interfaces of DMA and CLD DMA to chip Device Control Command(DCC).
 *  2. Define DCC DMA and CLD DMA related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_DMA_H
#define DCC_DMA_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <dcc/dcc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DCC constant definition */
#define DCC_DMA_BYTES_PER_WORD          (4)
#define DCC_MAX_DMA_MOVE_DATA_LEN       (8 * 1024) /* 8KB */
#define DCC_CLD_MAX_TASK                (512) /* CLD DMA has 512 tasks */
#define DCC_CLD_INT_REG_WIDTH           (32) /* Each register is a word, 32 bits */
#define DCC_CLD_INT_REG_CNT             (DCC_CLD_MAX_TASK/DCC_CLD_INT_REG_WIDTH) /* 32 task status per reg */
#define DCC_DMA_HTOD_TRIGGER_OFFSET     (0)
#define DCC_DMA_DTOH_TRIGGER_OFFSET     (2)
#define DCC_DMA_DTOD_TRIGGER_OFFSET     (5)
#define DCC_CLD_CMD_TRIGGER_OFFSET      (4)
#define DCC_CMD_TRIGGER_OFFSET          (10)
#define DCC_DMA_DTOD_TCAM_TRIGGER_OFFSET (11)
#define DCC_CLD_TMR_PRD_VALUE           (1024)
#define DCC_CLD_TMR_PRD_WIDTH           (16)
#define DCC_CLD_TMR_PRD_OFFSET          (0)
#define DCC_CLD_CTL_ENABLE_OFFSET       (0)
#define DCC_CLD_CTL_REPEAT_OFFSET       (8)
#define DCC_CLD_CTL_EXP_VALUE           (1)
#define DCC_CLD_CTL_EXP_WIDTH           (4)
#define DCC_CLD_CTL_EXP_OFFSET          (16)
#define DCC_DMA_ENTRY_LEN_WIDTH         (8)
#define DCC_DMA_ENTRY_NUM_WIDTH         (16)
#define DCC_CLD_ENTRY_LEN_WIDTH         (8)
#define DCC_CLD_ENTRY_NUM_WIDTH         (16)
/* unit of time: us, all times need for further check */
#define DCC_DMA_HTOD_SUSPEND_TIME       (2)
#define DCC_DMA_DTOH_SUSPEND_TIME       (2)
#define DCC_DMA_DTOD_SUSPEND_TIME       (2)
#define DCC_CLD_CMD_SUSPEND_TIME        (2)
#define DCC_DMA_BUSY_POLL_CNT           (10)


/* MACRO FUNCTION DECLARATIONS
 */

#define DCC_INIT_CLD_TASK(task, addr_in, ptr_buf_in, entry_len_in, entry_num_in, d_to_h_in, callback_in, op_mode_in) \
    do { \
        (task).addr        = (addr_in);        \
        (task).ptr_buf     = (ptr_buf_in);     \
        (task).entry_len   = (entry_len_in);   \
        (task).entry_num   = (entry_num_in);   \
        (task).d_to_h      = (d_to_h_in);      \
        (task).callback    = (callback_in);    \
        (task).op_mode     = (op_mode_in);     \
    } while(0)

/* DATA TYPE DECLARATIONS
 */
/* DCC DMA channel status*/
enum
{
    DMA_STAT_IDLE = 0x0,
    DMA_STAT_BSY = 0x1,
    DMA_STAT_RDY = 0x2,
    DMA_STAT_ERR = 0x5,
    DMA_STAT_ABT = 0xA,
    DMA_STAT_LAST
};

/* DCC CMD channel status*/
enum
{
    CMD_STAT_IDLE = 0x0,
    CMD_STAT_BSY = 0x1,
    CMD_STAT_RDY = 0x2,
    CMD_STAT_ERR = 0x5,
    CMD_STAT_ABT = 0xA,
    CMD_STAT_LAST
};

/* DCC CLD DMA command type */
enum
{
    CLD_CMD_SET_CLD = 0x1,
    CLD_CMD_SET_TASK,
    CLD_CMD_SET_TASK_IDLE,
    CLD_CMD_SET_BASE_ADDR,
    CLD_CMD_LAST
};

/* DCC table DMA and calendar channel error code */
enum
{
    DMA_ERR_CODE_NORMAL = 0x0,
    DMA_ERR_CODE_DBUS_SLV_ERR = 0x1,
    DMA_ERR_CODE_DBUS_DEC_ERR = 0x2,
    DMA_ERR_CODE_PCIE_ERR = 0x4,
    DMA_ERR_CODE_BUF_ECC = 0x8,
    DMA_ERR_CODE_LAST
};

enum
{
    DMA_D2D_ERR_CODE_NORMAL = 0x0,
    DMA_D2D_ERR_CODE_DBUS_SLV_SRC_ERR = 0x1,
    DMA_D2D_ERR_CODE_DBUS_DEC_SRC_ERR = 0x2,
    DMA_D2D_ERR_CODE_DBUS_SLV_DST_ERR = 0x4,
    DMA_D2D_ERR_CODE_DBUS_DEC_DST_ERR = 0x8,
    DMA_D2D_ERR_CODE_LAST
};

/* DCC CLD task status*/
typedef enum
{
    DCC_CLD_STAT_IDLE = 0x00,
    DCC_CLD_STAT_BUSY = 0x01,
    DCC_CLD_STAT_RDY  = 0x02,
    DCC_CLD_STAT_ERR  = 0x05,
    DCC_CLD_STAT_PAUSE= 0xFE,
    DCC_CLD_STAT_LAST
} DCC_CLD_STAT_T;

/* DCC CLD task operating mode */
typedef enum
{
    DCC_CLD_OP_MODE_FUPD = 0,
    DCC_CLD_OP_MODE_POLL,
    DCC_CLD_OP_MODE_INTR,
    DCC_CLD_OP_MODE_LAST
} DCC_CLD_OP_MODE_T;

typedef enum
{
    DCC_DMA_TYPE_TBL_DMA_H2D = 0x0,
    DCC_DMA_TYPE_TBL_DMA_D2H,
    DCC_DMA_TYPE_TBL_DMA_D2D,
    DCC_DMA_TYPE_CLD_DMA,
    DCC_DMA_TYPE_LAST
} DCC_DMA_TYPE_T;

typedef enum
{
    DCC_DMA_D2D_DIR_DESCENDING = 0x0,
    DCC_DMA_D2D_DIR_ASCENDING,
    DCC_DMA_D2D_DIR_LAST
} DCC_DMA_D2D_DIR_T;

typedef enum
{
    DCC_DMA_CMD_UCP_SET = 0x0,
    DCC_DMA_CMD_TCAM_ECC_INIT,
    DCC_DMA_CMD_POLL_TCAM_SCAN_DONE,
    DCC_DMA_CMD_TRIGGER_TCAM_SCAN,
    DCC_DMA_CMD_ENABLE_TCAM_SCAN,
    DCC_DMA_CMD_LAST
} DCC_DMA_CMD_T;

#define DCC_DMA_CH_IRQ      (1<<4)
#define DCC_DMA_CH_UPD      (1<<5)
#define DCC_DMA_CH_DIR      (1<<6)
#define DCC_DMA_CH_HTOD     (0<<7)

#ifdef CLX_EN_BIG_ENDIAN
/* DMA command OPD */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T opd                           :     8;
        UI32_T dbeat                         :     8;
        UI32_T                               :     4;
        UI32_T doffs                         :    12;
    } field;
} DCC_DMA_H2D_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T status                        :     8;
        UI32_T err_code                      :     8;
        UI32_T num                           :    16;
    } field;
} DCC_DMA_H2D_CMD_OPD2_REG_T;

/* DMA command OPD */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T opd                           :     8;
        UI32_T dbeat                         :     8;
        UI32_T                               :     4;
        UI32_T doffs                         :    12;
    } field;
} DCC_DMA_D2H_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T status                        :     8;
        UI32_T err_code                      :     8;
        UI32_T num                           :    16;
    } field;
} DCC_DMA_D2H_CMD_OPD2_REG_T;

/* DMA command OPD */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T opd                           :     8;
        UI32_T dbeat                         :     8;
        UI32_T                               :     4;
        UI32_T doffs                         :    12;
    } field;
} DCC_DMA_D2D_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T status                        :     8;
        UI32_T err_code                      :     8;
        UI32_T num                           :    16;
    } field;
} DCC_DMA_D2D_CMD_OPD2_REG_T;
#else
/* DMA command OPD */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T doffs                         :    12;
        UI32_T                               :     4;
        UI32_T dbeat                         :     8;
        UI32_T opd                           :     8;
    } field;
} DCC_DMA_H2D_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T num                           :    16;
        UI32_T err_code                      :     8;
        UI32_T status                        :     8;
    } field;
} DCC_DMA_H2D_CMD_OPD2_REG_T;

/* DMA command OPD */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T doffs                         :    12;
        UI32_T                               :     4;
        UI32_T dbeat                         :     8;
        UI32_T opd                           :     8;
    } field;
} DCC_DMA_D2H_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T num                           :    16;
        UI32_T err_code                      :     8;
        UI32_T status                        :     8;
    } field;
} DCC_DMA_D2H_CMD_OPD2_REG_T;

/* DMA command OPD */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T doffs                         :    12;
        UI32_T                               :     4;
        UI32_T dbeat                         :     8;
        UI32_T opd                           :     8;
    } field;
} DCC_DMA_D2D_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T num                           :    16;
        UI32_T err_code                      :     8;
        UI32_T status                        :     8;
    } field;
} DCC_DMA_D2D_CMD_OPD2_REG_T;
#endif

typedef struct
{
    /* Host to device */
    UI32_T  htod_haddr_mmio_addr;
    UI32_T  htod_haddrh_mmio_addr;
    UI32_T  htod_daddr_mmio_addr;
    UI32_T  htod_cmd_opd_mmio_addr;
    UI32_T  htod_cmd_opd2_mmio_addr;
    UI32_T  htod_hsta_adr_mmio_addr;
    UI32_T  htod_hsta_adrh_mmio_addr;
    /* Device to host */
    UI32_T  dtoh_haddr_mmio_addr;
    UI32_T  dtoh_haddrh_mmio_addr;
    UI32_T  dtoh_daddr_mmio_addr;
    UI32_T  dtoh_cmd_opd_mmio_addr;
    UI32_T  dtoh_cmd_opd2_mmio_addr;
    UI32_T  dtoh_hsta_adr_mmio_addr;
    UI32_T  dtoh_hsta_adrh_mmio_addr;
    /* Device to device */
    UI32_T  dtod_src_daddr_mmio_addr;
    UI32_T  dtod_dst_daddr_mmio_addr;
    UI32_T  dtod_cmd_opd_mmio_addr;
    UI32_T  dtod_cmd_opd2_mmio_addr;
    UI32_T  dtod_hsta_adr_mmio_addr;
    UI32_T  dtod_hsta_adrh_mmio_addr;
    /* uP control */
    UI32_T  upctl_dev_int_set_mmio_addr;
    UI32_T  upctl_up_hsterr_int_en_mmio_addr;
    UI32_T  upctl_up_hsterr_int_mask_mmio_addr;
    UI32_T  upctl_up_hsterr_int_clr_mmio_addr;
    UI32_T  upctl_up_hsterr_int_stat_mmio_addr;
    UI32_T  upctl_upctl_info1_mmio_addr;
} DCC_DMA_MMIO_ADDR_CB_T;

typedef struct
{
    UI32_T  max_entry_len;
    UI32_T  max_entry_num;
    UI32_T  max_dma_len;
} DCC_DMA_DMA_ATTRIB_T;

/* DCC CLD DMA command operand structure */

#define DCC_CLD_CH_IRQ      (1<<4)
#define DCC_CLD_CH_FUPD     (1<<5)
#define DCC_CLD_CH_HTOD     (1<<7)


typedef
CLX_ERROR_NO_T
(*DCC_CLD_FUNC_T)(
    const UI32_T  unit,
    const UI32_T  task_id);

#ifdef CLX_EN_BIG_ENDIAN
/* Task command2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T cmd                           :     8;
        UI32_T                               :     8;
        UI32_T opd2                          :    16;
    } field;
} DCC_CLD_TASK_CMD2_REG_T;

/* Task command1 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                               :    16;
        UI32_T opd1                          :    16;
    } field;
} DCC_CLD_TASK_CMD1_REG_T;

/* DMA command OPD */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T opd                           :     8;
        UI32_T dbeat                         :     8;
        UI32_T                               :     4;
        UI32_T doffs                         :    12;
    } field;
} DCC_CLD_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T status                        :     8;
        UI32_T err_code                      :     8;
        UI32_T num                           :    16;
    } field;
} DCC_CLD_CMD_OPD2_REG_T;

/* TASK_STA_FAIL_IDX */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T                               :    16;
        UI32_T task_sta_fail_idx             :    16;
    } field;
} DCC_CLD_TASK_STA_FAIL_IDX_REG_T;
#else
/* Task command2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T opd2                          :    16;
        UI32_T                               :     8;
        UI32_T cmd                           :     8;
    } field;
} DCC_CLD_TASK_CMD2_REG_T;

/* Task command1 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T opd1                          :    16;
        UI32_T                               :    16;
    } field;
} DCC_CLD_TASK_CMD1_REG_T;

/* DMA command OPD */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T doffs                         :    12;
        UI32_T                               :     4;
        UI32_T dbeat                         :     8;
        UI32_T opd                           :     8;
    } field;
} DCC_CLD_CMD_OPD_REG_T;

/* DMA command OPD2 */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T num                           :    16;
        UI32_T err_code                      :     8;
        UI32_T status                        :     8;
    } field;
} DCC_CLD_CMD_OPD2_REG_T;

/* TASK_STA_FAIL_IDX */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T task_sta_fail_idx             :    16;
        UI32_T                               :    16;
    } field;
} DCC_CLD_TASK_STA_FAIL_IDX_REG_T;
#endif

typedef struct
{
    UI32_T  task_cmd2_mmio_addr;
    UI32_T  task_cmd1_mmio_addr;
    UI32_T  haddr_mmio_addr;
    UI32_T  haddrh_mmio_addr;
    UI32_T  daddr_mmio_addr;
    UI32_T  cmd_opd_mmio_addr;
    UI32_T  cmd_opd2_mmio_addr;
    UI32_T  task_sta_fail_idx_mmio_addr;
    /* uP control */
    UI32_T  upctl_uptst_rw_1_mmio_addr;
    UI32_T  upctl_tmr0_ctl0_mmio_addr;
    UI32_T  upctl_tmr0_ctl1_mmio_addr;
    UI32_T  upctl_dev_int_set_mmio_addr;
    UI32_T  upctl_up_comm_clr_mmio_addr[DCC_CLD_INT_REG_CNT];
    UI32_T  upctl_up_comm_sta_mmio_addr[DCC_CLD_INT_REG_CNT];
} DCC_CLD_MMIO_ADDR_CB_T;

typedef struct
{
    UI32_T  ctrl_mmio_addr;
    UI32_T  rsp_mmio_addr;
    UI32_T  data_mmio_addr;
} DCC_CMD_MMIO_ADDR_CB_T;

typedef struct
{
    UI32_T  max_entry_len;
    UI32_T  max_entry_num;
    UI32_T  max_dma_len;
} DCC_CLD_DMA_ATTRIB_T;

/* DCC CLD DMA command structure */
typedef struct DCC_CLD_CMD_S
{
    DCC_CLD_TASK_CMD2_REG_T  cmd2;    /* 1st word:     command type and opd2     */
    DCC_CLD_TASK_CMD1_REG_T  cmd1;    /* 2nd word:     command opd1              */
    DCC_HOST_ADDR_T          haddr;   /* 3rd/4th word: host address              */
    UI32_T                   daddr;   /* 5th word:     device addres             */
    DCC_CLD_CMD_OPD_REG_T    opd;     /* 6th word:     flags, dbeat, and doffs   */
    DCC_CLD_CMD_OPD2_REG_T   opd2;    /* 7th word:     status, err code, and num */
} DCC_CLD_CMD_T;

/* DCC CLD DMA task structure */
typedef struct DCC_CLD_TASK_S
{
    UI32_T             addr;      /* device address            */
    void               *ptr_buf;  /* ptr to host address       */
    UI32_T             entry_len; /* length of an entry (byte) */
    UI32_T             entry_num; /* number of entries         */
    BOOL_T             d_to_h;    /* device to host            */
    DCC_CLD_FUNC_T     callback;  /* callback function for INT */
    DCC_CLD_OP_MODE_T  op_mode;   /* operation mode            */
} DCC_CLD_TASK_T;

/* DCC DMA channel control block structure */
typedef struct
{

    /* channel OS resource */
    CLX_SEMAPHORE_ID_T      htod_protect_sema; /* channel protection semaphore */
    CLX_SEMAPHORE_ID_T      dtoh_protect_sema; /* channel protection semaphore */
    CLX_SEMAPHORE_ID_T      dtod_protect_sema; /* channel protection semaphore */

    volatile void           *ptr_htod_status_buf;  /* point to dma mem to save htod execution status */
    volatile void           *ptr_dtoh_status_buf;  /* point to dma mem to save dtoh execution status */
    volatile void           *ptr_dtod_status_buf;  /* point to dma mem to save dtoh execution status */

    /* channel operation mode */
    DCC_CH_OP_MODE_T        htod_op_mode;        /* operation is polling or interrupt */
    UI32_T                  htod_op_timeout_cnt; /* time-out count while channel access operation */

    DCC_CH_OP_MODE_T        dtoh_op_mode;        /* operation is polling or interrupt */
    UI32_T                  dtoh_op_timeout_cnt; /* time-out count while channel access operation */

    DCC_CH_OP_MODE_T        dtod_op_mode;        /* operation is polling or interrupt */
    UI32_T                  dtod_op_timeout_cnt; /* time-out count while channel access operation */

    /* debug counters */
    UI32_T                  htod_abt_cnt; /* abort count */
    UI32_T                  htod_err_cnt; /* error count */

    UI32_T                  dtoh_abt_cnt; /* abort count */
    UI32_T                  dtoh_err_cnt; /* error count */

    UI32_T                  dtod_abt_cnt; /* abort count */
    UI32_T                  dtod_err_cnt; /* error count */

    BOOL_T                  htod_start; /* indicate DMA htod channel is executing */
    BOOL_T                  dtoh_start; /* indicate DMA dtoh channel is executing */
    BOOL_T                  dtod_start; /* indicate DMA dtoh channel is executing */

    /* performance timestamp */
    CLX_TIME_T              htod_cmd_start; /* dma host to device start execution time */
    CLX_TIME_T              htod_cmd_stop; /* dma host to device end execution time */
    CLX_TIME_T              htod_cmd_max_time; /* dma host to device command Max execution time */
    CLX_TIME_T              htod_cmd_min_time; /* dma host to device command min execution time */

    CLX_TIME_T              dtoh_cmd_start; /* dma device to host start execution time */
    CLX_TIME_T              dtoh_cmd_stop; /* dma device to host end execution time */
    CLX_TIME_T              dtoh_cmd_max_time; /* dma device to host command Max execution time */
    CLX_TIME_T              dtoh_cmd_min_time; /* dma device to host command min execution time */

    CLX_TIME_T              dtod_cmd_start; /* dma device to device start execution time */
    CLX_TIME_T              dtod_cmd_stop; /* dma device to device end execution time */
    CLX_TIME_T              dtod_cmd_max_time; /* dma device to device command Max execution time */
    CLX_TIME_T              dtod_cmd_min_time; /* dma device to device command min execution time */

    /* mmio addr control block */
    DCC_DMA_MMIO_ADDR_CB_T  mmio_addr_cb;

    /* dma channel attribute */
    DCC_DMA_DMA_ATTRIB_T      dma_attrib;
} DCC_DMA_CH_CB_T;


/* DCC CLD DMA channel control block structure */
typedef struct DCC_CLD_CH_CB_S
{

    /* uP interrupt control register */
    UI32_T                  up_comm_reg_stat[DCC_CLD_INT_REG_CNT]; /* uP interrupt status register */
    UI32_T                  up_comm_reg_clear[DCC_CLD_INT_REG_CNT]; /* uP interrupt clear register */
    /* channel OS resource */
    CLX_SEMAPHORE_ID_T      protect_sema; /* channel protection semaphore */
    UI16_T                  cld_idx[DCC_CLD_MAX_TASK]; /* calendar array */
    DCC_CLD_TASK_T          tasks[DCC_CLD_MAX_TASK]; /* task array */
    volatile CLX_HUGE_T     *ptr_task_status; /* task status array, pointer to DMA memory */
    UI16_T                  next_avail_task_id; /* next available task ID to assign */
    BOOL_T                  up_redownload;  /* indecate uP of CLD DMA need to be redownload
                                                                 * TRUE: CLD DMA needs to redownload uP
                                                                 * FALSE: CLD DMA does not need to redownload uP
                                                                 */
    /* debug counters */
    UI32_T                  rst_cnt_htod; /* reset count */
    UI32_T                  rst_cnt_dtoh; /* reset count */
    UI32_T                  err_cnt_htod; /* error count */
    UI32_T                  err_cnt_dtoh; /* error count */
    UI32_T                  err_cnt_cmd; /* error count */

    /* performance timestamp */
    CLX_TIME_T              cmd_start;
    CLX_TIME_T              cmd_stop;

    /* mmio addr control block */
    DCC_CLD_MMIO_ADDR_CB_T  mmio_addr_cb;

    /* cld channel attribute */
    DCC_CLD_DMA_ATTRIB_T    dma_attrib;
} DCC_CLD_CH_CB_T;

typedef struct DCC_CMD_CH_CB_S
{
    CLX_SEMAPHORE_ID_T      protect_sema;
    BOOL_T                  cmd_start;

    UI32_T                  seq_num;

    /* performance timestamp */
    CLX_TIME_T              cmd_start_time;
    CLX_TIME_T              cmd_stop_time;

    /* mmio addr control block */
    DCC_CMD_MMIO_ADDR_CB_T  mmio_addr_cb;

} DCC_CMD_CH_CB_T;



/* FUNCTION NAME:   dcc_dma_initDmaRsrc
 * PURPOSE:
 *      dcc_dma_initDmaRsrc() is responsible for resource of DCC DMA initialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_dma_initDmaRsrc(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_dma_initCldRsrc
 * PURPOSE:
 *      dcc_dma_initCldRsrc() is responsible for resource of DCC CLD initialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_dma_initCldRsrc(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_dma_initDmaThread
 * PURPOSE:
 *      dcc_dma_initDmaThread() is responsible for thread of DCC DMA initialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_dma_initDmaThread(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_dma_initCldThread
 * PURPOSE:
 *      dcc_dma_initCldThread() is responsible for thread of DCC CLD initialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_dma_initCldThread(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_dma_deinitDmaRsrc
 * PURPOSE:
 *      dcc_dma_deinitDmaRsrc() is responsible for resource of DCC DMA deinitialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
/* dcc channel deinit */
CLX_ERROR_NO_T
dcc_dma_deinitDmaRsrc(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_dma_deinitCldRsrc
 * PURPOSE:
 *      dcc_dma_deinitCldRsrc() is responsible for resource of DCC DMA deinitialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_dma_deinitCldRsrc(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_dma_deinitDmaThread
 * PURPOSE:
 *      dcc_dma_deinitDmaThread() is responsible for thread of DCC DMA deinitialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_dma_deinitDmaThread(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_dma_deinitCldThread
 * PURPOSE:
 *      dcc_dma_deinitCldThread() is responsible for thread of DCC CLD deinitialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_dma_deinitCldThread(
    const UI32_T                unit);


/* FUNCTION NAME:   dcc_dma_showDmaChannelInfo
 * PURPOSE:
 *      dcc_dma_showDmaChannelInfo() is a function to display DCC DMA channel information.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 *
 * NOTES:
 *      None
 *
 */
void
dcc_dma_showDmaChannelInfo(
    const UI32_T unit);

/* FUNCTION NAME:   dcc_dma_writeTbl
 * PURPOSE:
 *      dcc_dma_writeTbl() is a function to move table data from host to device.
 *
 * INPUT:
 *      unit           -- The specified unit number.
 *      ptr_src_buf  -- The start address of host memory for DMA transfer. Please note that this
 *                            address is virtual address.
 *      addr  --  The start address of device table address for DMA transfer. This address should
 *                   be a valid address inside chip.
 *      entry_len  --  The length of an entry is going to be transferred
 *      entry_num  --  Number of entries are going to be transferred
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Successfully write data from host to device
 *      CLX_E_BAD_PARAMETER  --  Input parameter has error configuration or value
 *      CLX_E_OTHERS  --  Fail to write data from host to device
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_writeTbl(
    const UI32_T           unit,
    void                   *ptr_src_buf,
    const UI32_T           addr,
    const UI32_T           entry_len,
    const UI32_T           entry_num );


/* FUNCTION NAME:   dcc_dma_readTbl
 * PURPOSE:
 *      dcc_dma_readTbl() is a function to move table data from device to host.
 *
 * INPUT:
 *      unit           -- The specified unit number.
 *      ptr_dst_buf  -- The start address of host memory for DMA transfer. Please note that this
 *                            address is virtual address.
 *      addr  --  The start address of device table address for DMA transfer. This address should
 *                   be a valid address inside chip.
 *      entry_len  --  The length of an entry is going to be transferred
 *      entry_num  --  Number of entries are going to be transferred
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Successfully read data from device to host
 *      CLX_E_BAD_PARAMETER  --  Input parameter has error configuration or value
 *      CLX_E_OTHERS  --  Fail to read data from device to host
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_readTbl(
    const UI32_T           unit,
    void                   *ptr_dst_buf,
    const UI32_T           addr,
    const UI32_T           entry_len,
    const UI32_T           entry_num );

/* FUNCTION NAME:   dcc_dma_copyTbl
 * PURPOSE:
 *      dcc_dma_copyTbl() is a function to copy table data from device to device.
 *
 * INPUT:
 *      unit        --  The specified unit number.
 *      src_addr    --  The start address of source device table address for DMA transfer. This address should
 *                      be a valid address inside chip.
 *      dst_addr    --  The start address of destination device table address for DMA transfer.
 *      dir         --  The direction order for copy data.
 *      entry_len   --  The length of an entry is going to be transferred.
 *      entry_num   --  Number of entries are going to be transferred.
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            --  Successfully copy data from device to device
 *      CLX_E_BAD_PARAMETER --  Input parameter has error configuration or value
 *      CLX_E_OTHERS        --  Fail to read data from device to device
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_copyTbl(
    const UI32_T                unit,
    const UI32_T                src_addr,
    const UI32_T                dst_addr,
    const DCC_DMA_D2D_DIR_T     dir,
    const UI32_T                entry_len,
    const UI32_T                entry_num);

/* FUNCTION NAME:   dcc_dma_copyTcam
 * PURPOSE:
 *      dcc_dma_copyTcam() is a function to copy tcam table data from device to device.
 *
 * INPUT:
 *      unit        --  The specified unit number.
 *      src_addr    --  The start address of source device table address for DMA transfer. This address should
 *                      be a valid address inside chip.
 *      dst_addr    --  The start address of destination device table address for DMA transfer.
 *      dir         --  The direction order for copy data.
 *      entry_len   --  The length of an entry is going to be transferred.
 *      entry_num   --  Number of entries are going to be transferred.
 *
 * OUTPUT:
 *      None
 *
 * RETURN:
 *      CLX_E_OK            --  Successfully copy data from device to device
 *      CLX_E_BAD_PARAMETER --  Input parameter has error configuration or value
 *      CLX_E_OTHERS        --  Fail to read data from device to device
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_copyTcam(
    const UI32_T                unit,
    const UI32_T                src_addr,
    const UI32_T                dst_addr,
    const DCC_DMA_D2D_DIR_T     dir,
    const UI32_T                entry_len,
    const UI32_T                entry_num);

/* FUNCTION NAME:   dcc_dma_setDmaHToDOperationMode
 * PURPOSE:
 *      dcc_dma_setDmaHToDOperationMode() is a function to change DCC host to device DMA channel
 *      operation mode to be poll or interrupt.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      op_mode       -- The DMA channel operation mode, valid are:
 *                       1. DCC_CH_OP_MODE_POLL
 *                       2. DCC_CH_OP_MODE_INTR
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Set DMA channel operation mode successfully.
 *      CLX_E_OTHERS  -- Fail to set DMA channel operation mode.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_setDmaHToDOperationMode(
    const UI32_T unit,
    const DCC_CH_OP_MODE_T op_mode);

/* FUNCTION NAME:   dcc_dma_setDmaDToHOperationMode
 * PURPOSE:
 *      dcc_dma_setDmaDToHOperationMode() is a function to change DCC device to host DMA channel
 *      operation mode to be poll or interrupt.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      op_mode       -- The DMA channel operation mode, valid are:
 *                       1. DCC_CH_OP_MODE_POLL
 *                       2. DCC_CH_OP_MODE_INTR
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Set DMA channel operation mode successfully.
 *      CLX_E_OTHERS  -- Fail to set DMA channel operation mode.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_setDmaDToHOperationMode(
    const UI32_T unit,
    const DCC_CH_OP_MODE_T op_mode);

/* FUNCTION NAME:   dcc_dma_setDmaDToDOperationMode
 * PURPOSE:
 *      dcc_dma_setDmaDToDOperationMode() is a function to change DCC device to device DMA channel
 *      operation mode to be poll or interrupt.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      op_mode       -- The DMA channel operation mode, valid are:
 *                       1. DCC_CH_OP_MODE_POLL
 *                       2. DCC_CH_OP_MODE_INTR
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Set DMA channel operation mode successfully.
 *      CLX_E_OTHERS  -- Fail to set DMA channel operation mode.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_setDmaDToDOperationMode(
    const UI32_T unit,
    const DCC_CH_OP_MODE_T op_mode);

/* FUNCTION NAME:   dcc_dma_setDmaHToDOperationTimeoutCnt
 * PURPOSE:
 *      dcc_dma_setDmaHToDOperationTimeoutCnt() is a function to change DCC host to device DMA channel
 *      operation time-out count.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      timeout_cnt   -- The DMA channel operation time-out count for polling mode.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Set DMA channel operation time-out count successfully.
 *      CLX_E_OTHERS  -- Fail to set DMA channel operation time-out count.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_setDmaHToDOperationTimeoutCnt(
    const UI32_T unit,
    const UI32_T timeout_cnt);

/* FUNCTION NAME:   dcc_dma_setDmaDToHOperationTimeoutCnt
 * PURPOSE:
 *      dcc_dma_setDmaDToHOperationTimeoutCnt() is a function to change DCC device to host DMA channel
 *      operation time-out count.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      timeout_cnt   -- The DMA channel operation time-out count for polling mode.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Set DMA channel operation time-out count successfully.
 *      CLX_E_OTHERS  -- Fail to set DMA channel operation time-out count.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_setDmaDToHOperationTimeoutCnt(
    const UI32_T unit,
    const UI32_T timeout_cnt);

/* FUNCTION NAME:   dcc_dma_setDmaDToDOperationTimeoutCnt
 * PURPOSE:
 *      dcc_dma_setDmaDToDOperationTimeoutCnt() is a function to change DCC device to device DMA channel
 *      operation time-out count.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      timeout_cnt   -- The DMA channel operation time-out count for polling mode.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Set DMA channel operation time-out count successfully.
 *      CLX_E_OTHERS  -- Fail to set DMA channel operation time-out count.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_setDmaDToDOperationTimeoutCnt(
    const UI32_T unit,
    const UI32_T timeout_cnt);

/* FUNCTION NAME:   dcc_dma_showCldChannelInfo
 * PURPOSE:
 *      dcc_dma_showCldChannelInfo() is a function to display DCC CLD DMA channel information.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 *
 * NOTES:
 *      None
 *
 */

void
dcc_dma_showCldChannelInfo(
    const UI32_T          unit);

/* FUNCTION NAME:   dcc_dma_setCldMode
 * PURPOSE:
 *      dcc_dma_setCldMode() is a function to set DCC CLD DMA uP operation mode
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      period        -- Significant part of each task interval (1 ~ 65535)
 *      exponent      -- Exponent part of each task interval (2^exponent, 0 ~ 15)
 *                    -- The exact time interval is period*2^exponent us
 *      enable        -- Enable CLD DMA
 *      repeat        -- Enable automatic repeat after all tasks complete
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             -- Set uP operation mode successfully
 *      CLX_E_BAD_PARAMETER  -- Invalid exponent parameter
 *      CLX_E_OTHERS         -- Fail to set uP operation mode
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_setCldMode(
    const UI32_T unit,
    const UI32_T period,
    const UI32_T exponent,
    const BOOL_T enable,
    const BOOL_T repeat);

/*
 * PURPOSE:
 *      dcc_dma_addCldTask() is a function to add a calendar DMA task
 *
 * INPUT:
 *      unit                  -- The specified unit number
 *      ptr_task              -- Pointer to detailed task info
 * OUTPUT:
 *      ptr_task_id           -- task_id assigned to the new task
 * RETURN:
 *      CLX_E_OK              -- Task is successfully added into system
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_TABLE_FULL      -- Task table full, cannot add a new task
 *      CLX_E_OTHERS          -- Fail to add task into system due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_addCldTask(
    const UI32_T          unit,
    const DCC_CLD_TASK_T  *ptr_task,
    UI32_T                *ptr_task_id);

/*
 * PURPOSE:
 *      dcc_dma_delCldTask() is a function to delete a calendar DMA task
 *
 * INPUT:
 *      unit                  -- The specified unit number
 *      task_id               -- The task to be deleted
 * OUTPUT:
 *       None
 * RETURN:
 *      CLX_E_OK              -- Task is successfully deleted from system
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_ENTRY_NOT_FOUND -- Task associated with the task_id does not exist
 *      CLX_E_OTHERS          -- Fail to delete task from system due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_delCldTask(
    const UI32_T          unit,
    const UI32_T          task_id);

/* FUNCTION NAME:   dcc_dma_setCldTaskStatus
 * PURPOSE:
 *      dcc_dma_setCldTaskStatus() is a function to set a task status to the idle/pause state
 *
 * INPUT:
 *      unit                  -- The specified unit number.
 *      task_id               -- The task to be set status
 *      state                 -- The new state of the task, valid settings are
 *                               1. DCC_CLD_STAT_IDLE
 *                               2. DCC_CLD_STAT_PAUSE
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Task status is successfully set
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_ENTRY_NOT_FOUND -- Task associated with the task_id doesn't exist
 *      CLX_E_OTHERS          -- Fail to set task state due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_setCldTaskStatus(
    const UI32_T          unit,
    const UI32_T          task_id,
    const DCC_CLD_STAT_T  state);

/* FUNCTION NAME:   dcc_dma_getCldTaskStatus
 * PURPOSE:
 *      dcc_dma_getCldTaskStatus() is a function to get a task's current status
 *
 * INPUT:
 *      unit                  -- The specified unit number.
 *      task_id               -- The task to be queried
 * OUTPUT:
 *      ptr_status            -- Status of the task under study
 * RETURN:
 *      CLX_E_OK              -- Task status is successfully obtained
 *      CLX_E_BAD_PARAMETER   -- Input parameter has error configuration or value
 *      CLX_E_ENTRY_NOT_FOUND -- Task associated with the task_id doesn't exist
 *      CLX_E_OTHERS          -- Fail to read task status due to internal error
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_getCldTaskStatus(
    const UI32_T          unit,
    const UI32_T          task_id,
    DCC_CLD_STAT_T        *ptr_status);

/* FUNCTION NAME:   dcc_dma_showCldTaskInfo
 * PURPOSE:
 *      dcc_dma_showCldTaskInfo() is a function to show DCC CLD DMA task information.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      task_id       -- task_id of the task under study
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 *
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_showCldTaskInfo(
    const UI32_T          unit,
    const UI32_T          task_id);


/* FUNCTION NAME:   dcc_dma_dmaUpError
 * PURPOSE:
 *      dcc_dma_dmaUpError() is a function to handle dma up error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle tdma uP error successfully
 *      CLX_E_OTHERS  -- fail to handle tdma uP error
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_dmaUpError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_cldStaUpdError
 * PURPOSE:
 *      dcc_dma_cldStaUpdError() is a function to handle CLD DMA status update error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle cld dma status update error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_cldStaUpdError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_tdmaStaUpdError
 * PURPOSE:
 *      dcc_dma_tdmaStaUpdError() is a function to handle tdma status update error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle tdma status update error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_tdmaStaUpdError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_cldDmaDtoHError
 * PURPOSE:
 *      dcc_dma_cldDmaHtoDError() is a function to handle cld dma device to host error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle cld dma device to host error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_cldDmaDtoHError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_cldDmaHtoDError
 * PURPOSE:
 *      dcc_dma_cldDmaHtoDError() is a function to handle cld dma host to device error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle cld dma host to device error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_cldDmaHtoDError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_dmaTableHtoDError
 * PURPOSE:
 *      dcc_dma_dmaTableHtoDError() is a function to handle host to device tdma error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle tdma host to device error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_dmaTableHtoDError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_dmaTableDtoHError
 * PURPOSE:
 *      dcc_dma_dmaTableDtoHError() is a function to handle device to host tdma error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle tdma device to host error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_dmaTableDtoHError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_dmaTableDtoDError
 * PURPOSE:
 *      dcc_dma_dmaTableDtoDError() is a function to handle device to device tdma error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle tdma device to host error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_dmaTableDtoDError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_recoverDmaChannel
 * PURPOSE:
 *      dcc_dma_recoverDmaChannel() is a function to recover DMA channel while DMA uP is damaged.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      dma_type  -- The specified dma type, include cld DMA, table DMA write, and table DMA read.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- recover Dma channel error successfully
 *      CLX_E_OTHERS  -- recover Dma channel error failed
 * NOTES:
 *      None
 *
 */

CLX_ERROR_NO_T
dcc_dma_recoverDmaChannel(
    const UI32_T    unit,
    DCC_DMA_TYPE_T  dma_type);

/* FUNCTION NAME:   dcc_dma_recoverDmaDoubleEccError
 * PURPOSE:
 *      dcc_dma_recoverDmaDoubleEccError() is a function to handle program memory double bit ECC error for Dma uP.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- handle cld dma device to host error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_recoverDmaDoubleEccError(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* DMA channel ISR */
CLX_ERROR_NO_T
dcc_dma_cldChIsr(
    const UI32_T unit,
    const UI32_T isr_cookie);

/* FUNCTION NAME:   dcc_dma_txCmd
 * PURPOSE:
 *      dcc_dma_txCmd() is a function to send custom command to DCE uP
 *
 * INPUT:
 *      unit        -- The specified unit number
 *      cmd         -- Custom command ID
 *      ptr_data    -- Pointer for the user data sent to DCE uP
 *      data_len    -- Valid word count in ptr_data
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  -- Handle the command successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_dma_txCmd(
    const UI32_T            unit,
    const DCC_DMA_CMD_T     cmd,
    UI32_T                  *ptr_data,
    const UI32_T            data_len);  /* in word */
#endif /* END of DCC_H*/
