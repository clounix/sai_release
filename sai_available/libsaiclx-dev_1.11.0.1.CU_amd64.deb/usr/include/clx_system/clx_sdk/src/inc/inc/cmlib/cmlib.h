/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  cmlib.h
 * PURPOSE:
 *  this file is used to provide init common library operations to other users.
 * NOTES:
 *  it contains operations as below:
 *      1. init common library
 *      2. deinit common library.
 *      3. register debug commands for all sub-modules.
 *      4. deregister debug commands for all sub-modules.
 *      5. provide debug functions for sub-modules.
 *
 *
 *
 */
#ifndef CMLIB_H
#define CMLIB_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CMLIB_NAME_MAX_LEN        (32)

/* MACRO FUNCTION DECLARATIONS
 */


/* FUNCTION NAME: CMLIB_MULTI_OVERFLOW
 * PURPOSE:
 *      it is used to test if two 32-bit unsigned operand multiply will be overflow
 * INPUT:
 *      ui32a  -- operand a
 *      ui32b  -- operand b
 * OUTPUT:
 *      None.
 * RETURN:
 *      0     -- not overflow
 *      non 0 -- overflow
 * NOTES:
 *
 */
#define CMLIB_MULTI_OVERFLOW(ui32a, ui32b) \
    ((ui32a) ? ((~0U/(UI32_T)(ui32a)) < (UI32_T)(ui32b)) : 0)

/* FUNCTION NAME: CMLIB_ADD_OVERFLOW
 * PURPOSE:
 *      it is used to test if two operands add overflow.
 * INPUT:
 *      ui32a  -- operand a
 *      ui32b  -- operand b
 * OUTPUT:
 *      None.
 * RETURN:
 *      0     -- not overflow
 *      non 0 -- overflow
 * NOTES:
 *
 */
#define CMLIB_ADD_OVERFLOW(ui32a, ui32b) \
    ((UI32_T)(ui32a) > ~((UI32_T)(ui32b)))

/* DATA TYPE DECLARATIONS
 */

typedef struct CMLIB_DBG_LIST_NODE_S
{
    void                         *ptr_data;
    struct CMLIB_DBG_LIST_NODE_S *ptr_next;
} CMLIB_DBG_LIST_NODE_T;


typedef struct
{
    CMLIB_DBG_LIST_NODE_T *ptr_front;
    CLX_SEMAPHORE_ID_T    sem;
} CMLIB_DBG_HEAD_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

#endif /* End of CMLIB_H */

