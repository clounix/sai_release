/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_drv.h
 * PURPOSE:
 *  Provide HAL driver structure and driver help APIs.
 *
 * NOTES:
 */

#ifndef HAL_DRV_H
#define HAL_DRV_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <clx_ifmon.h>
#include <clx_vlan.h>
#include <clx_netif.h>
#include <clx_pkt.h>
#include <clx_acl.h>
#include <clx_sec.h>
#include <clx_l2.h>
#include <clx_stp.h>
#include <clx_lag.h>
#include <clx_mir.h>
#include <clx_l3.h>
#include <clx_l3t.h>
#include <clx_vm.h>
#include <clx_fcoe.h>
#include <clx_qos.h>
#include <clx_nv.h>
#include <clx_swc.h>
#include <clx_meter.h>
#include <clx_stat.h>
#include <clx_mpls.h>
#include <clx_trill.h>
#include <clx_sfc.h>
#include <clx_tm.h>
#include <clx_pppoe.h>
#include <clx_init.h>
#include <clx_stk.h>
#include <clx_telm.h>
#include <hal/common/hal_intr.h>
#include <hal/common/hal_ecc.h>
#include <hal/common/hal_tbl.h>
#include <hal/common/hal_const.h>
#include <hal/common/hal_cmn_drv.h>
#include <hal/common/hal_pkt_rsrc.h>
#include <hal/common/hal_dflt.h>
#include <hal/common/hal_pkj.h>
#include <hal/common/hal_dev.h>

#ifdef CLX_EXTENSION
#include <hal/common/hal_ext_drv.h>
#endif

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_RUN_CHIP_MODE           (0x0)
#define HAL_RUN_FPGA_MODE           (0x1)
#define HAL_RUN_PXP_MODE            (0x2)
#define HAL_RUN_PCIE_BYPASS_MODE    (0x3)
#define HAL_MAX_NUM_OF_PLANE        (8)
#define HAL_CIM_SW_TBL_BASE_ID      (1U << 31)

#if defined(CLX_LAMP)
#define HAL_RUN_LAMP_MODE           (0x4)
#endif

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef CLX_ERROR_NO_T \
(*HAL_UP_INIT_DCE_UP_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              idx) ;

typedef CLX_ERROR_NO_T \
(*HAL_CHIP_MMIO_INIT_FUNC_T) (
    const   UI32_T              unit) ;

typedef CLX_ERROR_NO_T \
(*HAL_CHIP_INIT_FUNC_T) (
    const   UI32_T              unit) ;

typedef CLX_ERROR_NO_T \
(*HAL_CHIP_DEINIT_FUNC_T) (
    const   UI32_T              unit) ;

/* vlan multiplexing functions */

typedef CLX_ERROR_NO_T
(*HAL_VLAN_INIT_FUNC_T) (
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_DEINIT_FUNC_T) (
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_CREATEVLAN_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    vid);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_DELVLAN_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    vid);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_CREATEBRIDGEDOMAIN_FUNC_T) (
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_DESTROYBRIDGEDOMAIN_FUNC_T) (
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_SETPROPERTY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const CLX_VLAN_PROPERTY_T       property,
    UI32_T                          param0,
    UI32_T                          param1);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_GETPROPERTY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const CLX_VLAN_PROPERTY_T       property,
    UI32_T                          *ptr_param0,
    UI32_T                          *ptr_param1);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_TRAVERSEENTRY_FUNC_T) (
    const UI32_T                            unit,
    const CLX_VLAN_ENTRY_TRAVERSE_FUNC_T    callback,
    void                                    *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_SETSERVICE_FUNC_T) (
    const   UI32_T                  unit,
    const   CLX_VLAN_T              vid,
    const   CLX_PORT_SEG_SRV_T      *ptr_srv);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_GETSERVICE_FUNC_T) (
    const   UI32_T                  unit,
    const   CLX_VLAN_T              vid,
    CLX_PORT_SEG_SRV_T              *ptr_srv);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_SETPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_VLAN_ENTRY_T          *ptr_vlan_entry);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_GETPORT_FUNC_T) (
    const UI32_T                    unit,
    CLX_VLAN_ENTRY_T                *ptr_vlan_entry);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_SETVLANISOLATION_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        vid,
    const CLX_VLAN_ISOLATION_ENTRY_T    *ptr_prty);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_GETVLANISOLATION_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    vid,
    CLX_VLAN_ISOLATION_ENTRY_T      *ptr_prty);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_ADDMACVLAN_FUNC_T) (
    const UI32_T                    unit,
    const CLX_VLAN_MAC_VLAN_ENTRY_T *ptr_prty);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_DELMACVLAN_FUNC_T) (
    const UI32_T                    unit,
    const CLX_VLAN_MAC_VLAN_ENTRY_T *ptr_prty);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_GETMACVLAN_FUNC_T) (
    const UI32_T                    unit,
    CLX_VLAN_MAC_VLAN_ENTRY_T       *ptr_prty);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_SETTYPEENTRY_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    index,
    const CLX_VLAN_CLASSIFY_TYPE_T  *ptr_entry,
    const CLX_VLAN_TAG_ACTION_T     *ptr_action);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_GETTYPEENTRY_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    index,
    CLX_VLAN_CLASSIFY_TYPE_T        *ptr_entry,
    CLX_VLAN_TAG_ACTION_T           *ptr_action);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_SETADDRENTRY_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    index,
    const CLX_VLAN_CLASSIFY_ADDR_T  *ptr_entry,
    const CLX_VLAN_TAG_ACTION_T     *ptr_action);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_GETADDRENTRY_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    index,
    CLX_VLAN_CLASSIFY_ADDR_T        *ptr_entry,
    CLX_VLAN_TAG_ACTION_T           *ptr_action);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_ADDPVLANENTRY) (
    const UI32_T                    unit,
    const UI32_T                    primary_vlan,
    const CLX_VLAN_PVLAN_ENTRY_T    *ptr_pvlan_entry);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_DELETEPVLANENTRY) (
    const UI32_T                    unit,
    const UI32_T                    primary_vlan);

typedef CLX_ERROR_NO_T
(*HAL_VLAN_GETPVLANENTRY) (
    const UI32_T                    unit,
    const UI32_T                    primary_vlan,
    CLX_VLAN_PVLAN_ENTRY_T          *ptr_pvlan_entry);

/* Port multiplexing functions */
typedef CLX_ERROR_NO_T
(*HAL_PORT_SETPROPERTY_FUNC_T) (
    const UI32_T              unit,
    const UI32_T              port,
    const CLX_PORT_PROPERTY_T property,
    UI32_T                    param0,
    UI32_T                    param1);

typedef CLX_ERROR_NO_T
(*HAL_PORT_GETPROPERTY_FUNC_T) (
    const UI32_T              unit,
    const UI32_T              port,
    const CLX_PORT_PROPERTY_T property,
    UI32_T                    *ptr_param0,
    UI32_T                    *ptr_param1);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETSPEED_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_SPEED_T            speed );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETSPEED_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_PORT_SPEED_T                    *ptr_speed );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETFLOWCTRL_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_FC_T               fc );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETFLOWCTRL_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_PORT_FC_T                       *ptr_fc );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETPRIFLOWCTRL_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   UI8_T                       pri,
    const   CLX_PORT_FC_T               pfc );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETPRIFLOWCTRL_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   UI8_T                       pri,
    CLX_PORT_FC_T                       *ptr_pfc );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETEEEMODE_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_EEE_MODE_T         mode );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETEEEMODE_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_PORT_EEE_MODE_T                 *ptr_mode  );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETLOCALADVABILITY_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_ABILITY_T          *ptr_ability );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETLOCALADVABILITY_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_PORT_ABILITY_T                  *ptr_ability );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETREMOTEADVABILITY_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_PORT_ABILITY_T                  *ptr_ability );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETABILITY_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_PORT_ABILITY_T                  *ptr_ability );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETLOOPBACK) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_LOOPBACK_T         lbtype );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETLOOPBACK) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_PORT_LOOPBACK_T                 *ptr_lbtype );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_PROBE) (
    const   UI32_T                      unit,
    const   UI32_T                      port );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_INITPORT) (
    const   UI32_T                      unit,
    const   UI32_T                      port );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_DEINITPORT) (
    const   UI32_T                      unit,
    const   UI32_T                      port );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETMACADDR) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_MAC_T                   mac );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETMACADDR) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_MAC_T                           *ptr_mac );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETLINK) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    UI32_T                              *ptr_link );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETFAULT) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    UI32_T                              *ptr_fault );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETTEMPERATURE) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    I32_T                               *ptr_temp );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETMEDIUCLYPE) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_MEDIUM_TYPE_T      medium );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETMEDIUCLYPE) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    CLX_PORT_MEDIUM_TYPE_T              *ptr_medium );

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETPHYPROPERTY) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_PHY_LOCATION_T     location,
    const   CLX_PORT_PHY_PROPERTY_T     property,
    const   UI32_T                      value_cnt,
    const   UI32_T                      *ptr_value);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETPHYPROPERTY) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_PHY_LOCATION_T     location,
    const   CLX_PORT_PHY_PROPERTY_T     property,
    const   UI32_T                      value_cnt,
    UI32_T                              *ptr_value);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_ADDSEGSERVICEGROUP) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_VLAN_T                  merged_vid_min,
    const   CLX_VLAN_T                  merged_vid_max);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_DELSEGSERVICEGROUP) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_VLAN_T                  merged_vid_min,
    const   CLX_VLAN_T                  merged_vid_max);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETSEGSERVICEGROUP) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_VLAN_T                  merged_vid_min,
    const   CLX_VLAN_T                  merged_vid_max);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_TRAVERSESEGSERVICEGROUP) (
    const UI32_T                                    unit,
    const CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T    callback,
    void                                            *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_ADDSEGSERVICE) (
    const   UI32_T                      unit,
    const   CLX_PORT_T                  intf,
    const   UI32_T                      seg0,
    const   UI32_T                      seg1,
    const   CLX_PORT_SEG_SRV_T          *ptr_seg_srv);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_DELSEGSERVICE) (
    const   UI32_T                      unit,
    const   CLX_PORT_T                  intf,
    const   UI32_T                      seg0,
    const   UI32_T                      seg1);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETSEGSERVICE) (
    const   UI32_T                      unit,
    const   CLX_PORT_T                  intf,
    const   UI32_T                      seg0,
    const   UI32_T                      seg1,
    CLX_PORT_SEG_SRV_T                  *ptr_seg_srv);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_INIT_FUNC_T) (
    const   UI32_T                      unit);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_DEINIT_FUNC_T) (
    const   UI32_T                      unit);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETPROPERTY)(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_PORT_PROPERTY_T    property,
    const UI32_T            param0,
    const UI32_T            param1);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETPROPERTY)(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_PORT_PROPERTY_T    property,
    UI32_T                  *ptr_param0,
    UI32_T                  *ptr_param1);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETLANEMAP)(
    const UI32_T             unit,
    const UI32_T             port,
    const UI32_T             mac_macro,
    const UI32_T             lane,
    const CLX_PORT_SPEED_T   max_speed,
    const UI32_T             bit_flags);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETLANEMAP)(
    const UI32_T             unit,
    const UI32_T             port,
    UI32_T                   *ptr_mac_macro,
    UI32_T                   *ptr_lane,
    CLX_PORT_SPEED_T         *ptr_max_speed,
    UI32_T                   *ptr_bit_flags);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_CREATEPORT)(
    const UI32_T                   unit,
    const UI32_T                   port,
    CLX_PORT_T                     *ptr_intf);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_DESTROYPORT)(
    const UI32_T                   unit,
    CLX_PORT_T                     intf);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETINTFPROPERTY)(
    const UI32_T                    unit,
    const CLX_PORT_T                intf,
    const CLX_PORT_INTF_PROPERTY_T  *ptr_property);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETINTFPROPERTY)(
    const UI32_T                    unit,
    const CLX_PORT_T                intf,
    CLX_PORT_INTF_PROPERTY_T        *ptr_property);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETTSTXENTRY)(
    const UI32_T                unit,
    const UI32_T                port,
    CLX_PORT_TS_ENTRY_T         *ptr_ts_entry);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETTSRXENTRY)(
    const UI32_T                unit,
    const UI32_T                port,
    CLX_PORT_TS_ENTRY_T         *ptr_ts_entry);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETPORTTYPE)(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    CLX_PORT_TYPE_T     *ptr_type);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETSTATUS)(
    const UI32_T         unit,
    const CLX_PORT_T     port,
    CLX_PORT_STATUS_T    *ptr_status);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETPORT)(
    const UI32_T    unit,
    const UI32_T    port,
    CLX_PORT_T      *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETPORTFROMCLXPORT)(
    const UI32_T     unit,
    const CLX_PORT_T clx_port,
    UI32_T           *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETTXCOEF)(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   UI32_T                  lane_idx,
    const   CLX_PORT_PHY_LOCATION_T location,
    CLX_PORT_TX_COEF_T              *ptr_tx_coef);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETTXCOEF)(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   UI32_T                  lane_idx,
    const   CLX_PORT_PHY_LOCATION_T location,
    CLX_PORT_TX_COEF_T              *ptr_tx_coef);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETANEN)(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_AUTO_NEG_TYPE_T        *an_en);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_SETANEN)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_PORT_AUTO_NEG_TYPE_T      an_en);

typedef CLX_ERROR_NO_T \
(*HAL_PORT_GETLINKTRNGEN)(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_PORT_LINK_TRAINING_T           *enable);

typedef CLX_ERROR_NO_T
(*HAL_PORT_SETLINKTRNGEN)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        enable);

typedef CLX_ERROR_NO_T  \
(*HAL_PORT_GETLINKTRAININGRESULT)(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_PORT_LINK_TRAINING_RESULT_T     *ptr_status);

typedef CLX_ERROR_NO_T  \
(*HAL_PORT_SETADVERTISEDINTFTYPE)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        intf_type);

/* lag multiplexing functions */
typedef CLX_ERROR_NO_T
(*HAL_LAG_INIT_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T
(*HAL_LAG_DEINIT_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T
(*HAL_LAG_CREATEPORT_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    lag_id,
    CLX_PORT_T      *ptr_lag_port);

typedef CLX_ERROR_NO_T
(*HAL_LAG_DESTROYPORT_FUNC_T)(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port);

typedef CLX_ERROR_NO_T
(*HAL_LAG_SETMEMBER_FUNC_T)(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    const UI32_T        member_cnt,
    const CLX_PORT_T    *ptr_member);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GETMEMBER_FUNC_T)(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    const UI32_T        member_cnt,
    CLX_PORT_T          *ptr_member,
    UI32_T              *ptr_actual_member_cnt);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GETMEMBERCNT_FUNC_T)(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    UI32_T              *ptr_member_cnt);

typedef CLX_ERROR_NO_T
(*HAL_LAG_TRAVERSEPORT_FUNC_T)(
    const UI32_T                     unit,
    const CLX_LAG_TRAVERSE_FUNC_T    callback,
    void                             *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GETRANGE_FUNC_T)(
    const UI32_T        unit,
    CLX_RANGE_INFO_T    *ptr_range);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GETPORT_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    lag_id,
    CLX_PORT_T      *ptr_lag_port);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GETKEY_FUNC_T)(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    UI32_T              *ptr_lag_id);

typedef CLX_ERROR_NO_T
(*HAL_LAG_ADDFDLGROUP_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        lag_port,
    const CLX_FDL_INFO_T    *ptr_fdl_info);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GETFDLGROUP_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        lag_port,
    CLX_FDL_INFO_T          *ptr_fdl_info);

typedef CLX_ERROR_NO_T
(*HAL_LAG_DELFDLGROUP_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        lag_port);

typedef CLX_ERROR_NO_T
(*HAL_LAG_SET_ATTR_FUNC_T)(
    const UI32_T              unit,
    const CLX_PORT_T          lag_port,
    const CLX_LAG_ATTRIB_T    *ptr_attr);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GET_ATTR_FUNC_T)(
    const UI32_T              unit,
    const CLX_PORT_T          lag_port,
    CLX_LAG_ATTRIB_T    *ptr_attr);
	
typedef CLX_ERROR_NO_T
(*HAL_LAG_CREATEMGLAG_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    flags,
    UI32_T          *ptr_mglag_id);

typedef CLX_ERROR_NO_T
(*HAL_LAG_DESTROYMGLAG_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    mglag_id);

typedef CLX_ERROR_NO_T
(*HAL_LAG_SETMGLAGMBR_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        mglag_id,
    const UI32_T        member_cnt,
    const UI32_T        *ptr_member);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GETMGLAGMBR_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        mglag_id,
    const UI32_T        member_cnt,
    CLX_PORT_T          *ptr_member,
    UI32_T              *ptr_actual_member_cnt);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GETMGLAGMBRCNT_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        mglag_id,
    UI32_T              *ptr_member_cnt);

typedef CLX_ERROR_NO_T
(*HAL_LAG_SET_WEIGHTMEMBER_FUNC_T)(
    const UI32_T                unit,
    const CLX_PORT_T            lag_port,
    const UI32_T                member_cnt,
    const CLX_LAG_MEMBER_INFO_T *ptr_member_info);

typedef CLX_ERROR_NO_T
(*HAL_LAG_GET_WEIGHTMEMBER_FUNC_T)(
    const UI32_T           unit,
    const CLX_PORT_T       lag_port,
    const UI32_T           member_cnt,
    CLX_LAG_MEMBER_INFO_T  *ptr_member_info,
    UI32_T                 *ptr_actual_member_cnt);

/*mirror multiplexing functions */
typedef CLX_ERROR_NO_T
(*HAL_MIR_INIT_FUNC_T)(
    const  UI32_T           unit);

typedef CLX_ERROR_NO_T
(*HAL_MIR_DEINIT_FUNC_T)(
    const UI32_T            unit);

typedef CLX_ERROR_NO_T
(*HAL_MIR_ADDSESSION_FUNC_T)(
    const UI32_T                        unit,
    const CLX_MIR_SESSION_T             *ptr_session);

typedef CLX_ERROR_NO_T
(*HAL_MIR_DELSESSION_FUNC_T)(
    const UI32_T                   unit,
    const UI8_T                    session_id,
    const CLX_MIR_DIRECTION_T      direction);

typedef CLX_ERROR_NO_T
(*HAL_MIR_GETSESSION_FUNC_T)(
    const UI32_T                unit,
    CLX_MIR_SESSION_T           *ptr_session);

typedef CLX_ERROR_NO_T
(*HAL_MIR_ADDERSPANTERM_FUNC_T)(
    const UI32_T                        unit,
    const CLX_MIR_ERSPAN_TERM_T         *ptr_erspan_term);

typedef CLX_ERROR_NO_T
(*HAL_MIR_DELERSPANTERM_FUNC_T)(
    const UI32_T                        unit,
    const CLX_MIR_ERSPAN_TERM_T         *ptr_erspan_term);

typedef CLX_ERROR_NO_T
(*HAL_MIR_GETERSPANTERM_FUNC_T)(
    const UI32_T                        unit,
    CLX_MIR_ERSPAN_TERM_T               *ptr_erspan_term);

/*l3 multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_L3_INIT_FUNC_T)(
    const UI32_T          unit);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DEINIT_FUNC_T)(
    const UI32_T          unit);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDINTF_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    CLX_L3_INTF_INFO_T              *ptr_l3_intf);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELINTF_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETINTF_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    CLX_L3_INTF_INFO_T              *ptr_l3_intf);

typedef CLX_ERROR_NO_T \
(*HAL_L3_TRAVERSEINTF_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_INTF_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDMYROUTERMAC_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    index ,
    const CLX_L3_ROUTER_MAC_INFO_T  *ptr_router_mac_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELMYROUTERMAC_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    index);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETMYROUTERMAC_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    index,
    CLX_L3_ROUTER_MAC_INFO_T        *ptr_router_mac_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDADJ_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_ADJ_INFO_T         *ptr_adj_info,
    UI32_T                          *ptr_adj_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELADJ_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_ADJ_TYPE_T         type,
    const UI32_T                    adj_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETADJ_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    adj_id,
    CLX_L3_ADJ_INFO_T               *ptr_adj_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_TRAVERSEADJ_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_ADJ_TYPE_T             type,
    const CLX_L3_ADJ_TRAVERSE_FUNC_T    callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDHOST_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_HOST_INFO_T        *ptr_host_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELHOST_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_HOST_INFO_T        *ptr_host_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETHOST_FUNC_T)(
    const UI32_T                    unit,
    CLX_L3_HOST_INFO_T              *ptr_host_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_TRAVERSEHOST_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_HOST_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDSUBNETBCAST_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_SUBNET_BCAST_INFO_T    *ptr_subnet_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELSUBNETBCAST_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_SUBNET_BCAST_INFO_T    *ptr_subnet_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETSUBNETBCAST_FUNC_T)(
    const UI32_T                        unit,
    CLX_L3_SUBNET_BCAST_INFO_T          *ptr_subnet_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_TRAVERSESUBNETBCAST_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_BCAST_TRAVERSE_FUNC_T  callback,
    void                                *ptr_subnet_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDROUTE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_ROUTE_INFO_T       *ptr_route_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELROUTE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_ROUTE_INFO_T       *ptr_route_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELROUTEALL_FUNC_T)(
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETROUTE_FUNC_T)(
    const UI32_T                    unit,
    CLX_L3_ROUTE_INFO_T             *ptr_route_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_TRAVERSEROUTE_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_ROUTE_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3_CREATEECMPGRP_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_ECMP_GRP_INFO_T    *ptr_ecmp_grp_info,
    UI32_T                          *ptr_ecmp_grp_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_SETECMPGRP_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_GRP_INFO_T    *ptr_ecmp_grp_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELECMPGRP_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_OUTPUT_TYPE_T      type,
    const UI32_T                    ecmp_grp_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETECMPGRP_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    CLX_L3_ECMP_GRP_INFO_T          *ptr_ecmp_grp_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_TRAVERSEECMPGRP_FUNC_T)(
    const UI32_T                            unit,
    const CLX_L3_OUTPUT_TYPE_T              type,
    const CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T   callback,
    void                                    *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3_SYNCECMPGRP_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    ori_ecmp_grp_id,
    const UI32_T                    curr_ecmp_grp_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDECMPGRPPATH_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELECMPGRPPATH_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETECMPGRPPATHBYIDX_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const UI32_T                    path_idx,
    CLX_L3_ECMP_PATH_INFO_T         *ptr_ecmp_path_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_SETECMPGRPHASHPATH_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const UI32_T                    *ptr_hash_val_list,
    const UI32_T                    hash_val_cnt,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETECMPGRPHASHPATH_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const UI32_T                    hash_val_cnt,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info,
    UI32_T                          *ptr_hash_val_list,
    UI32_T                          *ptr_actual_hash_val_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_L3_SETPKTHANDLINGPERVRF_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    vrf_id,
    const CLX_L3_VRF_INFO_T         *ptr_pkt_handling);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETPKTHANDLINGPERVRF_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    vrf_id,
    CLX_L3_VRF_INFO_T               *ptr_pkt_handling);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETBDBYINTFID_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    intf_id,
    CLX_BRIDGE_DOMAIN_T             *ptr_bdid);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDFDLECMPGROUP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const CLX_FDL_INFO_T        *ptr_fdl_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELFDLECMPGROUP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETFDLECMPGROUP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    CLX_FDL_INFO_T              *ptr_fdl_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DUMPECMPMBRLIST_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id);

/*l3 multicast multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_ADDID_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        flags,
    UI32_T              *ptr_mcast_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_DELID_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        mcast_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_GETID_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        mcast_id,
    UI32_T              *ptr_flags,
    CLX_PORT_BITMAP_T   port_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_ADDGROUP_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_MCAST_GROUP_INFO_T     *ptr_group_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_DELGROUP_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_MCAST_GROUP_INFO_T     *ptr_group_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_GETGROUP_FUNC_T)(
    const UI32_T                        unit,
    CLX_L3_MCAST_GROUP_INFO_T           *ptr_group_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_ADDEGRINTFBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T       *ptr_egr_intf);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_DELEGRINTFBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T       *ptr_egr_intf);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_SETEGRINTFBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T       *ptr_egr_intf);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_GETEGRINTFCNTBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    UI32_T                              *ptr_egr_intf_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_GETEGRINTFBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        egr_intf_cnt,
    CLX_L3_MCAST_EGR_INTF_T             *ptr_egr_intf,
    UI32_T                              *ptr_actual_egr_intf_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_ADDDFINTF_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                intf_id,
    const CLX_IP_ADDR_T         *ptr_rp_addr);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_DELDFINTF_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                intf_id,
    const CLX_IP_ADDR_T         *ptr_rp_addr);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_GETDFINTF_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                intf_id,
    const UI32_T                rp_addr_cnt,
    UI32_T                      *ptr_actual_rp_addr_cnt,
    CLX_IP_ADDR_T               *ptr_rp_addr);

typedef CLX_ERROR_NO_T \
(*HAL_L3_MCAST_TRAVERSEGROUP_FUNC_T)(
    const UI32_T                                unit,
    const CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T    callback,
    void                                        *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3_SETBFDINFO_FUNC_T)(
    const UI32_T                unit,
    const CLX_L3_BFD_INFO_T     *ptr_bfd_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETBFDINFO_FUNC_T)(
    const UI32_T                unit,
    CLX_L3_BFD_INFO_T           *ptr_bfd_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_SETBFDCHECKFAILACTION_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                port_id,
    const CLX_FWD_ACTION_T      action);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETBFDCHECKFAILACTION_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                port_id,
    CLX_FWD_ACTION_T            *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_L3_SETOPTIONHEADERACTION_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_OPTION_HEADER_INFO_T   action);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETOPTIONHEADERACTION_FUNC_T)(
    const UI32_T                        unit,
    CLX_L3_OPTION_HEADER_INFO_T         *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_L3_CREATEFRRSTATEID_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    UI32_T                              *ptr_state_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DESTROYFRRSTATEID_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id);

typedef CLX_ERROR_NO_T \
(*HAL_L3_SETFRRSTATE_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id,
    const BOOL_T                        link_up);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETFRRSTATE_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id,
    BOOL_T                              *ptr_link_up);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDSRCFORPIMREG_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_PIM_REG_INFO_T     *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELSRCFORPIMREG_FUNC_T)(
    const UI32_T                    unit,
    const CLX_L3_PIM_REG_INFO_T     *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETSRCFORPIMREG_FUNC_T)(
    const UI32_T                    unit,
    CLX_L3_PIM_REG_INFO_T           *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3_ADDVRRP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

typedef CLX_ERROR_NO_T \
(*HAL_L3_DELVRRP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

typedef CLX_ERROR_NO_T \
(*HAL_L3_GETVRRP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

/*l3 tunnel multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_L3T_INIT_FUNC_T) (
    const UI32_T         unit);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_DEINIT_FUNC_T) (
    const UI32_T         unit);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_ADDTUNNELMAC_FUNC_T) (
    const UI32_T              unit,
    const UI32_T              index,
    const CLX_L3T_MAC_INFO_T *ptr_tunnel_mac_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_DELTUNNELMAC_FUNC_T) (
    const UI32_T              unit,
    const UI32_T              index);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETTUNNELMAC_FUNC_T) (
    const UI32_T              unit,
    const UI32_T              index,
    CLX_L3T_MAC_INFO_T        *ptr_tunnel_mac_info);


typedef CLX_ERROR_NO_T \
(*HAL_L3T_TRAVERSETUNNELMAC_FUNC_T) (
    const UI32_T                                unit,
    const CLX_L3T_TUNNEL_MAC_TRAVERSE_FUNC_T    callback,
    void                                        *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_ADDINIT_FUNC_T) (
    const UI32_T                   unit,
    const CLX_L3T_INIT_INFO_T     *ptr_tunnel_init_info );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_DELINIT_FUNC_T) (
    const UI32_T                   unit,
    const CLX_L3T_INIT_INFO_T     *ptr_tunnel_init_info );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETINIT_FUNC_T) (
    const UI32_T            unit,
    CLX_L3T_INIT_INFO_T     *ptr_tunnel_init_info );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_TRAVERSEINIT_FUNC_T) (
    const UI32_T                        unit,
    const CLX_L3T_INIT_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_ADDTERM_FUNC_T) (
    const UI32_T                   unit,
    const CLX_L3T_TERM_INFO_T      *ptr_tunnel_term_info);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_DELTERM_FUNC_T) (
    const UI32_T                   unit,
    const CLX_L3T_TERM_INFO_T     *ptr_tunnel_term_info );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETTERM_FUNC_T) (
    const UI32_T            unit,
    CLX_L3T_TERM_INFO_T     *ptr_tunnel_term_info );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_TRAVERSETERM_FUNC_T) (
    const UI32_T                        unit,
    const CLX_L3T_TERM_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_ADDNVO3ROUTE_FUNC_T) (
    const UI32_T                       unit,
    const CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_DELNVO3ROUTE_FUNC_T) (
    const UI32_T                       unit,
    const CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETNVO3ROUTE_FUNC_T) (
    const UI32_T                 unit,
    CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_TRAVERSENVO3ROUTE_FUNC_T) (
    const UI32_T                             unit,
    const CLX_L3T_NVO3_ROUTE_TRAVERSE_FUNC_T callback,
    void                                     *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_SETUNUSEDECNACTION_FUNC_T) (
    const UI32_T               unit,
    const CLX_FWD_ACTION_T     action );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETUNUSEDECNACTION_FUNC_T) (
    const UI32_T               unit,
    CLX_FWD_ACTION_T           *ptr_action );

typedef CLX_ERROR_NO_T \
(*HAL_L3T_CREATEPORT_FUNC_T) (
    const UI32_T            unit,
    const CLX_TUNNEL_KEY_T  *ptr_key,
    const UI32_T            flag,
    CLX_PORT_T              *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_DESTROYPORT_FUNC_T) (
    const UI32_T            unit,
    const CLX_PORT_T        port);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETPORT_FUNC_T) (
    const UI32_T            unit,
    const CLX_TUNNEL_KEY_T  *ptr_key,
    CLX_PORT_T              *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETKEY_FUNC_T) (
    const UI32_T            unit,
    const CLX_PORT_T        port,
    CLX_TUNNEL_KEY_T        *ptr_key);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_TRAVERSEPORT_FUNC_T) (
    const UI32_T                        unit,
    const CLX_L3T_PORT_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_ADDFLEXTUNNEL_FUNC_T) (
    const UI32_T unit,
    const UI32_T index,
    const CLX_L3T_FLEX_TUNNEL_TYPE_T type,
    const UI32_T flags);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_DELFLEXTUNNEL_FUNC_T) (
    const UI32_T unit,
    const UI32_T index);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETFLEXTUNNEL_FUNC_T) (
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_TYPE_T *ptr_type,
    UI32_T *ptr_flags);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_SETFLEXTUNNELUDFPROFILE_FUNC_T) (
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

typedef CLX_ERROR_NO_T \
(*HAL_L3T_GETFLEXTUNNELUDFPROFILE_FUNC_T) (
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

/* ifmon multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_IFMON_INIT_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_IFMON_DEINIT_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_IFMON_REGISTER_FUNC_T) (
    const UI32_T                     unit,
    const CLX_IFMON_NOTIFY_FUNC_T    notify_func,
    void                             *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_IFMON_DEREGISTER_FUNC_T) (
    const UI32_T                     unit,
    const CLX_IFMON_NOTIFY_FUNC_T    notify_func,
    void                             *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_IFMON_GETMODE_FUNC_T) (
    const UI32_T         unit,
    CLX_IFMON_MODE_T     *ptr_mode,
    CLX_PORT_BITMAP_T    *ptr_port_bitmap,
    UI32_T               *ptr_interval);

typedef CLX_ERROR_NO_T \
(*HAL_IFMON_SETMODE_FUNC_T) (
    const UI32_T               unit,
    const CLX_IFMON_MODE_T     mode,
    const CLX_PORT_BITMAP_T    port_bitmap,
    const UI32_T               interval);

typedef CLX_ERROR_NO_T \
(*HAL_IFMON_GETMONITORSTATE_FUNC_T) (
    const UI32_T    unit,
    BOOL_T          *ptr_enable);

typedef CLX_ERROR_NO_T \
(*HAL_IFMON_SETMONITORSTATE_FUNC_T) (
    const UI32_T    unit,
    const BOOL_T    enable);

typedef CLX_ERROR_NO_T \
(*HAL_IFMON_GETCALLBACKCNT_FUNC_T) (
    const UI32_T    unit,
    UI32_T          *ptr_callback_cnt);

/*l2 multiplexing functions */
typedef CLX_ERROR_NO_T
(*HAL_L2_INIT_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T
(*HAL_L2_DEINIT_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T
(*HAL_L2_ADDADDR_FUNC_T)(
    const UI32_T           unit,
    const CLX_L2_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T
(*HAL_L2_DELADDR_FUNC_T)(
    const UI32_T           unit,
    const CLX_L2_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T
(*HAL_L2_GETADDR_FUNC_T)(
    const UI32_T     unit,
    CLX_L2_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T
(*HAL_L2_REPLACEADDR_FUNC_T)(
    const UI32_T           unit,
    const UI32_T           match_field,
    const CLX_L2_ADDR_T    *ptr_match_addr,
    const UI32_T           replace_field,
    const CLX_L2_ADDR_T    *ptr_replace_addr);

typedef CLX_ERROR_NO_T
(*HAL_L2_TRAVERSEADDR_FUNC_T) (
    const UI32_T                         unit,
    const CLX_L2_ADDR_TRAVERSE_MODE_T    mode,
    const CLX_L2_ADDR_TRAVERSE_FUNC_T    callback,
    void                                 *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_L2_REGISTERADDRNOTIFYCALLBACK_FUNC_T)(
    const UI32_T                       unit,
    const CLX_L2_ADDR_NOTIFY_FUNC_T    callback,
    void                               *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_L2_DEREGISTERADDRNOTIFYCALLBACK_FUNC_T)(
    const UI32_T                       unit,
    const CLX_L2_ADDR_NOTIFY_FUNC_T    callback,
    void                               *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_L2_ADDMCASTID_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    flags,
    UI32_T          *ptr_mcast_id);

typedef CLX_ERROR_NO_T
(*HAL_L2_DELMCASTID_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    mcast_id);

typedef CLX_ERROR_NO_T
(*HAL_L2_GETMCASTID_FUNC_T)(
    const UI32_T         unit,
    const UI32_T         mcast_id,
    UI32_T               *ptr_flags,
    CLX_PORT_BITMAP_T    port_bitmap);

typedef CLX_ERROR_NO_T
(*HAL_L2_ADDMCASTEGRINTF_FUNC_T)(
    const UI32_T                     unit,
    const UI32_T                     mcast_id,
    const UI32_T                     egr_intf_cnt,
    CLX_L2_MCAST_EGR_INTF_T          *ptr_egr_intf);

typedef CLX_ERROR_NO_T
(*HAL_L2_DELMCASTEGRINTF_FUNC_T)(
    const UI32_T                     unit,
    const UI32_T                     mcast_id,
    const UI32_T                     egr_intf_cnt,
    CLX_L2_MCAST_EGR_INTF_T          *ptr_egr_intf);

typedef CLX_ERROR_NO_T
(*HAL_L2_GETMCASTEGRINTFCNT_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    mcast_id,
    UI32_T          *ptr_egr_intf_cnt);

typedef CLX_ERROR_NO_T
(*HAL_L2_GETMCASTEGRINTF_FUNC_T)(
    const UI32_T               unit,
    const UI32_T               mcast_id,
    const UI32_T               egr_intf_cnt,
    CLX_L2_MCAST_EGR_INTF_T    *ptr_egr_intf,
    UI32_T                     *ptr_actual_egr_intf_cnt);

typedef CLX_ERROR_NO_T
(*HAL_L2_ADDMCASTADDR_FUNC_T)(
    const UI32_T                 unit,
    const CLX_L2_MCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T
(*HAL_L2_DELMCASTADDR_FUNC_T)(
    const UI32_T                 unit,
    const CLX_L2_MCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T
(*HAL_L2_GETMCASTADDR_FUNC_T)(
    const UI32_T           unit,
    CLX_L2_MCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T
(*HAL_L2_ADDIPMCASTGROUP_FUNC_T)(
    const UI32_T                     unit,
    const CLX_L2_IP_MCAST_GROUP_T    *ptr_group);

typedef CLX_ERROR_NO_T
(*HAL_L2_DELIPMCASTGROUP_FUNC_T)(
    const UI32_T                     unit,
    const CLX_L2_IP_MCAST_GROUP_T    *ptr_group);

typedef CLX_ERROR_NO_T
(*HAL_L2_GETIPMCASTGROUP_FUNC_T)(
    const UI32_T               unit,
    CLX_L2_IP_MCAST_GROUP_T    *ptr_group);

typedef CLX_ERROR_NO_T
(*HAL_L2_TRAVERSEMCASTADDR_FUNC_T)(
    const UI32_T                               unit,
    const CLX_L2_ADDR_TRAVERSE_MODE_T          mode,
    const CLX_L2_MCAST_ADDR_TRAVERSE_FUNC_T    callback,
    void                                       *ptr_cookie);

/* stp multiplexing functions */

typedef CLX_ERROR_NO_T \
(*HAL_STP_INIT_FUNC_T)(
    const UI32_T                unit);

typedef CLX_ERROR_NO_T \
(*HAL_STP_DEINIT_FUNC_T)(
    const UI32_T                unit);

typedef CLX_ERROR_NO_T \
(*HAL_STP_CREATESTG_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                stg);

typedef CLX_ERROR_NO_T \
(*HAL_STP_DESTROYSTG_FUNC_T) (
    const UI32_T                unit,
    const UI32_T                stg);

typedef CLX_ERROR_NO_T \
(*HAL_STP_SETBRIDGEDOMAINSTG_FUNC_T)(
    const UI32_T                unit,
    const CLX_BRIDGE_DOMAIN_T   bdid,
    const UI32_T                stg);

typedef CLX_ERROR_NO_T \
(*HAL_STP_GETBRIDGEDOMAINSTG_FUNC_T)(
    const UI32_T                unit,
    const CLX_BRIDGE_DOMAIN_T   bdid,
    UI32_T                      *ptr_stg);

typedef CLX_ERROR_NO_T \
(*HAL_STP_SETPORTSTATE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                stg,
    const UI32_T                port,
    const CLX_STP_PORTSTATE_T   portstate);

typedef CLX_ERROR_NO_T \
(*HAL_STP_GETPORTSTATE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                stg,
    const UI32_T                port,
    CLX_STP_PORTSTATE_T         *ptr_portstate);

typedef CLX_ERROR_NO_T \
(*HAL_STP_ISSTGVALID_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                stg);

/* Pkt multiplexing functions */

typedef CLX_ERROR_NO_T \
(*HAL_PKT_INIT_FUNC_T)(
    const UI32_T                unit);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_DEINIT_FUNC_T)(
    const UI32_T                unit);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETRXCONFIG_FUNC_T)(
    const UI32_T                unit,
    const CLX_PKT_RX_CFG_T      *ptr_rx_cfg);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETRXCONFIG_FUNC_T)(
    const UI32_T                unit,
          CLX_PKT_RX_CFG_T      *ptr_rx_cfg);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETPDMALOOPBACK_FUNC_T)(
    const UI32_T                unit,
    const BOOL_T                enabled);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SENDPACKET_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel,
    const CLX_PKT_TX_PKT_T      *ptr_pkt);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETCTRLTOCPUENTRY_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        index,
    const CLX_PKT_CTRL_TO_CPU_ENTRY_T   *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETCTRLTOCPUENTRY_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        index,
    CLX_PKT_CTRL_TO_CPU_ENTRY_T         *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETRXDEFAULTQUEUE_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        queue);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETRXDEFAULTQUEUED_FUNC_T)(
    const UI32_T                        unit,
    UI32_T                              *ptr_queue);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETRXQUEUEMAPPING_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        queue,
    const CLX_PKT_RX_REASON_BITMAP_T    reason_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETRXQUEUEMAPPING_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        queue,
          CLX_PKT_RX_REASON_BITMAP_T    *ptr_reason_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETRXTOCPUPRI_FUNC_T)(
    const UI32_T                        unit,
    const CLX_PKT_TO_CPU_PRI_T          pri);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETRXTOCPUPRI_FUNC_T)(
    const UI32_T                        unit,
    CLX_PKT_TO_CPU_PRI_T                *ptr_pri);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETRXREDIRECTTOCPU_FUNC_T)(
    const UI32_T                        unit,
    const CLX_PKT_RX_REASON_BITMAP_T    reason_bitmap,
    const BOOL_T                        enable);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETRXREDIRECTTOCPU_FUNC_T)(
    const UI32_T                        unit,
    CLX_PKT_RX_REASON_BITMAP_T          *ptr_reason_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETQUEUETORXCHANNEL_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                queue,
    const UI32_T                channel);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETQUEUETORXCHANNEL_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                queue,
    UI32_T                      *prt_channel);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETQUEUETRUNCATESIZE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                queue,
    const UI32_T                truncate_size);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETQUEUETRUNCATESIZE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                queue,
    UI32_T                      *ptr_truncate_size);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETTXCHANNELCOSBITMAP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel,
    const UI8_T                 cos_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETTXCHANNELCOSBITMAP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel,
    UI8_T                       *ptr_cos_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETTXCNT_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel,
          CLX_PKT_TX_CNT_T      *ptr_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETRXCNT_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel,
          CLX_PKT_RX_CNT_T      *ptr_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_CLEARTXCNT_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_CLEARRXCNT_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_CREATEINTF_FUNC_T)(
    const UI32_T                unit,
          CLX_NETIF_INTF_T      *ptr_net_intf,
          UI32_T                *ptr_intf_id);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_DESTROYINTF_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                id);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETINTF_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                id,
          CLX_NETIF_INTF_T      *ptr_net_intf);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETINTF_FUNC_T)(
    const UI32_T                unit,
    const CLX_NETIF_INTF_T      *ptr_net_intf);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_CREATEPROFILE_FUNC_T)(
    const UI32_T                unit,
          CLX_NETIF_PROFILE_T   *ptr_net_profile,
          UI32_T                *ptr_profile_id);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_DESTROYPROFILE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                id);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETPROFILE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                id,
          CLX_NETIF_PROFILE_T   *ptr_net_profile);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETINTFCNT_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                id,
          CLX_NETIF_INTF_CNT_T  *ptr_intf_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_CLEARINTFCNT_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                id);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SHOWTXDBGCNT_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SHOWRXDBGCNT_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                channel);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_DELCTRLTOCPUENTRYALL_FUNC_T)(
    const UI32_T                unit);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETRXMAPPING_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        queue,
    const CLX_PKT_RX_REASON_BITMAP_T    reason_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETRXMAPPING_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        queue,
          CLX_PKT_RX_REASON_BITMAP_T    *ptr_reason_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETINTFPROPERTY_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        id,
    const CLX_NETIF_INTF_PROPERTY_T     property,
    const UI32_T                        param0,
    const UI32_T                        param1);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETINTFPROPERTY_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_NETIF_INTF_PROPERTY_T     property,
    UI32_T                              *ptr_param0,
    UI32_T                              *ptr_param1);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETPPREASON_FUNC_T)(
    const UI32_T                 unit,
    const UI32_T                 pp_reason,
    const UI32_T str_len,
          C8_T                   *str_pp_reason);

#if defined(NETIF_EN_NETLINK)
typedef CLX_ERROR_NO_T \
(*HAL_PKT_CREATENETLINK_FUNC_T)(
    const UI32_T                        unit,
    CLX_NETIF_NETLINK_T                 *ptr_netlink,
    UI32_T                              *ptr_netlink_id);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_DESTROYNETLINK_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        netlink_id);

typedef CLX_ERROR_NO_T \
(*HAL_PKT_GETNETLINK_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        id,
    CLX_NETIF_NETLINK_T                 *ptr_netlink);

#endif

typedef CLX_ERROR_NO_T \
(*HAL_PKT_SETSWITCHID_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        switch_id);
/*acl multiplexing functions start*/

typedef CLX_ERROR_NO_T \
(*HAL_ACL_INIT_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_DEINIT_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_ADDGROUP_FUNC_T)(
    const UI32_T                     unit,
    const CLX_ACL_GROUP_T            type,
    const UI32_T                     priority,
    const CLX_ACL_GROUP_PROFILE_T    *ptr_group_profile,
    UI32_T                           *ptr_group_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_DELGROUP_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_GETGROUP_FUNC_T)(
    const UI32_T               unit,
    const CLX_ACL_GROUP_T      type,
    const UI32_T               group_id,
    UI32_T                     *ptr_priority,
    CLX_ACL_GROUP_PROFILE_T    *ptr_group_profile);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_ADDUDFKEYPROFILE_FUNC_T)(
    const UI32_T                       unit,
    const CLX_ACL_GROUP_T              type,
    const UI32_T                       udf_key_profile_id,
    const CLX_ACL_PKT_FORMAT_T         *ptr_pkt_format,
    const CLX_ACL_UDF_KEY_PROFILE_T    *ptr_profile);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_DELUDFKEYPROFILE_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             udf_key_profile_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_GETUDFKEYPROFILE_FUNC_T)(
    const UI32_T                 unit,
    const CLX_ACL_GROUP_T        type,
    const UI32_T                 udf_key_profile_id,
    CLX_ACL_PKT_FORMAT_T         *ptr_pkt_format,
    CLX_ACL_UDF_KEY_PROFILE_T    *ptr_profile);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_ADDLOU_FUNC_T)(
    const UI32_T                  unit,
    const CLX_ACL_GROUP_T         type,
    const UI32_T                  id,
    const UI32_T                  lou_id,
    const CLX_ACL_LOU_CFG_T       *ptr_lou);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_DELLOU_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             id,
    const UI32_T             lou_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_GETLOU_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             id,
    const UI32_T             lou_id,
    CLX_ACL_LOU_CFG_T        *ptr_lou);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_ALLOCENTRYID_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id,
    const UI32_T             entry_priority,
    UI32_T                   *ptr_entry_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_FREEENTRYID_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    entry_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_GETENTRYIDINFO_FUNC_T)(
    const UI32_T       unit,
    const UI32_T       entry_id,
    CLX_ACL_GROUP_T    *ptr_type,
    UI32_T             *ptr_group_id,
    UI32_T             *ptr_entry_priority);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_ADDENTRY_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                entry_id,
    const BOOL_T                entry_valid,
    const CLX_ACL_CLASSIFY_T    *ptr_classify,
    const CLX_ACL_ACTION_T      *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_DELENTRY_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    entry_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_GETENTRY_FUNC_T)(
    const UI32_T          unit,
    const UI32_T          entry_id,
    BOOL_T                *ptr_entry_valid,
    CLX_ACL_CLASSIFY_T    *ptr_classify,
    CLX_ACL_ACTION_T      *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_ADDFLOWENTRY_FUNC_T)(
    const UI32_T                unit,
    const CLX_ACL_GROUP_T       type,
    const UI32_T                group_id,
    const CLX_ACL_CLASSIFY_T    *ptr_classify,
    const CLX_ACL_ACTION_T      *ptr_action,
    UI32_T                      *ptr_entry_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_DELFLOWENTRY_FUNC_T)(
    const UI32_T                unit,
    const CLX_ACL_GROUP_T       type,
    const UI32_T                group_id,
    const UI32_T                entry_id);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_GETFLOWENTRY_FUNC_T)(
    const UI32_T                unit,
    const CLX_ACL_GROUP_T       type,
    const UI32_T                group_id,
    const UI32_T                entry_id,
    CLX_ACL_CLASSIFY_T          *ptr_classify,
    CLX_ACL_ACTION_T            *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_TRAVERSEGROUP_FUNC_T)(
    const UI32_T                           unit,
    const CLX_ACL_GROUP_T                  type,
    const CLX_ACL_GROUP_TRAVERSE_FUNC_T    callback,
    void                                   *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_TRAVERSEENTRY_FUNC_T)(
    const UI32_T                           unit,
    const CLX_ACL_GROUP_T                  type,
    const UI32_T                           group_id,
    const CLX_ACL_ENTRY_TRAVERSE_FUNC_T    callback,
    void                                   *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_TRAVERSEUDFKEYPROFILE_FUNC_T)(
    const UI32_T                                     unit,
    const CLX_ACL_GROUP_T                            type,
    const CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T    callback,
    void                                             *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_TRAVERSELOU_FUNC_T)(
    const UI32_T                         unit,
    const CLX_ACL_GROUP_T                type,
    const UI32_T                         id,
    const CLX_ACL_LOU_TRAVERSE_FUNC_T    callback,
    void                                 *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_RIM_ALLOC_FUNC_T)(
    const UI32_T                         unit,
    const CLX_ACL_RIM_ALLOC_T            type,
    UI32_T                               *ptr_index);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_RIM_FREE_FUNC_T)(
    const UI32_T                         unit,
    const CLX_ACL_RIM_ALLOC_T            type,
    const UI32_T                         index);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_RIM_SETACTION_FUNC_T)(
    const UI32_T                         unit,
    const CLX_ACL_RIM_ALLOC_T            type,
    const UI32_T                         index,
    const void                           *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_RIM_GETACTION_FUNC_T)(
    const UI32_T                         unit,
    const CLX_ACL_RIM_ALLOC_T            type,
    const UI32_T                         index,
    void                                 *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_ACL_RIM_TRAVERSEACTION_FUNC_T)(
    const UI32_T                           unit,
    const CLX_ACL_RIM_ALLOC_T              type,
    const CLX_ACL_RIM_TRAVERSE_FUNC_T      callback,
    void                                   *ptr_cookie);

/*acl multiplexing functions end*/

/* security multiplexing functions end */

typedef CLX_ERROR_NO_T \
(*HAL_SEC_INIT_FUNC_T)(
    const UI32_T             unit);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_DEINIT_FUNC_T)(
    const UI32_T             unit);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_SETDOSPORTCONFIG_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_SEC_GETDOSPORTCONFIG_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SEC_DOS_PORT_CONFIG_T       *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_SEC_SETDOSCONFIG_FUNC_T)(
    const UI32_T                    unit,
    const CLX_SEC_DOS_CONFIG_T      *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_GETDOSCONFIG_FUNC_T)(
    const UI32_T                    unit,
    CLX_SEC_DOS_CONFIG_T            *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_SEC_SETSTORMCTRLPROPERTY_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_STORM_CTRL_T      *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_GETSTORMCTRLPROPERTY_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SEC_STORM_CTRL_T            *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_GETSTORMCTRLCNT_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_STORM_CTRL_TYPE_T type,
    CLX_SEC_STORM_CTRL_CNT_T        *ptr_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_SETSOURCEGUARDPROPERTY_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_SG_PROPERTY_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_GETSOURCEGUARDPROPERTY_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SEC_SG_PROPERTY_T           *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_ADDSOURCEGUARDENTRY_FUNC_T)(
    const UI32_T                    unit,
    const CLX_SEC_SG_ENTRY_T        *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_DELSOURCEGUARDENTRY_FUNC_T)(
    const UI32_T                    unit,
    const CLX_SEC_SG_ENTRY_T        *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_GETSOURCEGUARDENTRY_FUNC_T)(
    const UI32_T                    unit,
    CLX_SEC_SG_ENTRY_T              *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_SETEGRESSPORT_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_BITMAP_T         port_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_GETEGRESSPORT_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_BITMAP_T               port_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_SETPROPERTY_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    type,
    const UI32_T                    param0,
    const UI32_T                    param1);

typedef CLX_ERROR_NO_T \
(*HAL_SEC_GETPROPERTY_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    type,
    const UI32_T                    *ptr_param0,
    const UI32_T                    *ptr_param1);


/* security multiplexing functions end */

/* sflow multiplexing functions start */

typedef CLX_ERROR_NO_T \
(*HAL_SFLOW_INIT_FUNC_T) (
    const UI32_T            unit);

typedef CLX_ERROR_NO_T \
(*HAL_SFLOW_DEINIT_FUNC_T) (
    const UI32_T            unit);

typedef CLX_ERROR_NO_T \
(*HAL_SFLOW_SETSFLOWPROFILE_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    const UI32_T                        sampling_rate);

typedef CLX_ERROR_NO_T \
(*HAL_SFLOW_GETSFLOWPROFILE_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    UI32_T                              *ptr_sampling_rate);

/* sflow multiplexing functions end */

/*vm multiplexing functions start*/

typedef CLX_ERROR_NO_T \
(*HAL_VM_INIT_FUNC_T)(
    const UI32_T            unit);

typedef CLX_ERROR_NO_T \
(*HAL_VM_DEINIT_FUNC_T)(
    const UI32_T            unit);

typedef CLX_ERROR_NO_T \
(*HAL_VM_SETVMMODE_FUNC_T)(
    const UI32_T            unit,
    const CLX_VM_MODE_T     mode);

typedef CLX_ERROR_NO_T \
(*HAL_VM_GETVMMODE_FUNC_T)(
    const UI32_T            unit,
    CLX_VM_MODE_T           *ptr_mode);

typedef CLX_ERROR_NO_T \
(*HAL_VM_CREATEPORT_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        port,
    const CLX_VM_ID_T       vm_id,
    const CLX_VM_TAG_TYPE_T vm_type,
    CLX_PORT_T              *ptr_vm_port);

typedef CLX_ERROR_NO_T \
(*HAL_VM_DESTROYPORT_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        vm_port);

typedef CLX_ERROR_NO_T \
(*HAL_VM_GETPORT_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        port,
    const CLX_VM_ID_T       vm_id,
    const CLX_VM_TAG_TYPE_T vm_type,
    CLX_PORT_T              *ptr_vm_port);

typedef CLX_ERROR_NO_T \
(*HAL_VM_GETKEY_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        vm_port,
    CLX_PORT_T              *ptr_port,
    CLX_VM_ID_T             *ptr_vm_id,
    CLX_VM_TAG_TYPE_T       *ptr_vm_type);

typedef CLX_ERROR_NO_T \
(*HAL_VM_SETUPSTREAMPORT_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        downstream_port,
    const CLX_PORT_T        upstream_port);

typedef CLX_ERROR_NO_T \
(*HAL_VM_GETUPSTREAMPORT_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        downstream_port,
    CLX_PORT_T              *ptr_upstream_port);

typedef CLX_ERROR_NO_T \
(*HAL_VM_RESETUPSTREAMPORT_FUNC_T)(
    const UI32_T            unit,
    const CLX_PORT_T        downstream_port);

typedef CLX_ERROR_NO_T \
(*HAL_VM_SETPORTPROPERTY_FUNC_T)(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_PORT_PRTY_T    *ptr_prty);

typedef CLX_ERROR_NO_T \
(*HAL_VM_GETPORTPROPERTY_FUNC_T)(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_VM_PORT_PRTY_T          *ptr_prty);

typedef CLX_ERROR_NO_T \
(*HAL_VM_PE_ADDUCASTADDR_FUNC_T)(
    const UI32_T                    unit,
    const CLX_VM_PE_UCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T \
(*HAL_VM_PE_DELUCASTADDR_FUNC_T)(
    const UI32_T                    unit,
    const CLX_VM_PE_UCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T \
(*HAL_VM_PE_GETUCASTADDR_FUNC_T)(
    const UI32_T                    unit,
    CLX_VM_PE_UCAST_ADDR_T          *ptr_addr);

typedef CLX_ERROR_NO_T \
(*HAL_VM_PE_ADDMCASTADDR_FUNC_T)(
    const UI32_T                    unit,
    const CLX_VM_PE_MCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T \
(*HAL_VM_PE_DELMCASTADDR_FUNC_T)(
    const UI32_T                    unit,
    const CLX_VM_PE_MCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T \
(*HAL_VM_PE_GETMCASTADDR_FUNC_T)(
    const UI32_T                    unit,
    CLX_VM_PE_MCAST_ADDR_T          *ptr_addr);

typedef CLX_ERROR_NO_T \
(*HAL_VM_PE_ADDMCASTMEMBERPORT_FUNC_T)(
    const UI32_T                    unit,
    const CLX_VM_PE_MCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T \
(*HAL_VM_PE_DELMCASTMEMBERPORT_FUNC_T)(
    const UI32_T                    unit,
    const CLX_VM_PE_MCAST_ADDR_T    *ptr_addr);

typedef CLX_ERROR_NO_T \
(*HAL_VM_ADDMCASTINTFPROPERTY_FUNC_T)(
    const UI32_T                      unit,
    const CLX_PORT_T                  port,
    const CLX_VM_ID_T                 vm_id,
    const CLX_VM_TAG_TYPE_T           vm_type,
    const CLX_PORT_INTF_PROPERTY_T    *ptr_intf_prop);

typedef CLX_ERROR_NO_T \
(*HAL_VM_DELMCASTINTFPROPERTY_FUNC_T)(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type);

typedef CLX_ERROR_NO_T \
(*HAL_VM_GETMCASTINTFPROPERTY_FUNC_T)(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type,
    CLX_PORT_INTF_PROPERTY_T    *ptr_intf_prop);

typedef CLX_ERROR_NO_T \
(*HAL_VM_ADDMCASTSEGSERVICE_FUNC_T)(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type,
    const UI32_T                seg0,
    const UI32_T                seg1,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

typedef CLX_ERROR_NO_T \
(*HAL_VM_DELMCASTSEGSERVICE_FUNC_T)(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type,
    const UI32_T                seg0,
    const UI32_T                seg1);

typedef CLX_ERROR_NO_T \
(*HAL_VM_GETMCASTSEGSERVICE_FUNC_T)(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type,
    const UI32_T                seg0,
    const UI32_T                seg1,
    CLX_PORT_SEG_SRV_T          *ptr_seg_srv);

/*vm multiplexing functions end*/

/*nv multiplexing functions start */

typedef CLX_ERROR_NO_T \
(*HAL_NV_INIT_FUNC_T)(
    const UI32_T                unit) ;


typedef CLX_ERROR_NO_T \
(*HAL_NV_DEINIT_FUNC_T)(
    const UI32_T                unit);


typedef CLX_ERROR_NO_T \
(*HAL_NV_SETP2PPRUNECONTROL_FUNC_T)(
    const UI32_T                            unit,
    const CLX_NV_P2P_PRUNE_T            p2p_prune);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETP2PPRUNECONTROL_FUNC_T)(
    const UI32_T                            unit,
    CLX_NV_P2P_PRUNE_T                  *ptr_p2p_prune);

typedef CLX_ERROR_NO_T \
(*HAL_NV_SETPAYLAODTYPE_FUNC_T)(
    const UI32_T                             unit,
    const CLX_BRIDGE_DOMAIN_T                bdid,
    const CLX_NV_PAYLOAD_TYPE_T              payload_type);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETPAYLAODTYPE_FUNC_T)(
    const UI32_T                            unit,
    const CLX_BRIDGE_DOMAIN_T               bdid,
    CLX_NV_PAYLOAD_TYPE_T                   *ptr_payload);

typedef CLX_ERROR_NO_T \
(*HAL_NV_SETSPLITHORIZONCHECK_FUNC_T)(
    const UI32_T                            unit,
    const CLX_TUNNEL_KEY_T                  *ptr_tunnel_key,
    const BOOL_T                            enable);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETSPLITHORIZONCHECK_FUNC_T)(
    const UI32_T                            unit,
    const CLX_TUNNEL_KEY_T                  *ptr_tunnel_key,
    BOOL_T                                  *ptr_enable);

typedef CLX_ERROR_NO_T \
(*HAL_NV_SETP2PSPLITHORIZONCHECK_FUNC_T)(
    const UI32_T                            unit,
    const CLX_BRIDGE_DOMAIN_T               bdid,
    const BOOL_T                            enable);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETP2PSPLITHORIZONCHECK_FUNC_T)(
    const UI32_T                            unit,
    const CLX_BRIDGE_DOMAIN_T               bdid,
    BOOL_T                                  *ptr_enable);

typedef CLX_ERROR_NO_T \
(*HAL_NV_SETP2PUCASTTUNNELADJ_FUNC_T)(
    const UI32_T                            unit,
    const CLX_IP_ADDR_T                  *ptr_local_vtep_addr,
    const CLX_IP_ADDR_T                  *ptr_remote_vtep_addr,
    const UI32_T                          nvo3_adj_id);

typedef CLX_ERROR_NO_T \
(*HAL_NV_DELP2PUCASTTUNNELADJ_FUNC_T)(
    const UI32_T                            unit,
    const CLX_IP_ADDR_T                  *ptr_src_vtep_addr,
    const CLX_IP_ADDR_T                  *ptr_dst_vtep_addr);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETP2PUCASTTUNNELADJ_FUNC_T)(
    const UI32_T                            unit,
    const CLX_IP_ADDR_T                  *ptr_local_vtep_addr,
    const CLX_IP_ADDR_T                  *ptr_remote_vtep_addr,
    UI32_T                               *ptr_nvo3_adj_id);

typedef CLX_ERROR_NO_T \
(*HAL_NV_BINDMCASTTUNNEL_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T     bdid,
    const CLX_IP_ADDR_T          *ptr_local_vtep_ip,
    const CLX_IP_ADDR_T          *ptr_mcast_group_ip,
    const CLX_NV_TYPE_T             nv_type);

typedef CLX_ERROR_NO_T \
(*HAL_NV_UNBINDMCASTTUNNEL_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETMCASTTUNNELBINDING_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T     bdid,
    CLX_IP_ADDR_T                *ptr_local_vtep_ip,
    CLX_IP_ADDR_T                *ptr_mcast_group_ip,
    CLX_NV_TYPE_T                   *ptr_nv_type);

typedef CLX_ERROR_NO_T \
(*HAL_NV_VXLAN_ADDVNI_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    vni,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T \
(*HAL_NV_VXLAN_DELVNI_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    vni,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T \
(*HAL_NV_VXLAN_GETVNI_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T  bdid,
    UI32_T                    *ptr_vni);

typedef CLX_ERROR_NO_T \
(*HAL_NV_ADDNVO3GROUP_FUNC_T)(
    const UI32_T            unit,
    const CLX_IP_ADDR_T  *ptr_group_ip);

typedef CLX_ERROR_NO_T \
(*HAL_NV_DELNVO3GROUP_FUNC_T)(
    const UI32_T            unit,
    const CLX_IP_ADDR_T  *ptr_group_ip);

typedef CLX_ERROR_NO_T \
(*HAL_NV_ADDNVO3GROUPEGRINTF_FUNC_T)(
    const UI32_T              unit,
    const CLX_IP_ADDR_T       *ptr_group_ip,
    const UI32_T              port_id,
    const UI32_T              nvo3_adj_id);

typedef CLX_ERROR_NO_T \
(*HAL_NV_DELNVO3GROUPEGRPORT_FUNC_T)(
    const UI32_T              unit,
    const CLX_IP_ADDR_T         *ptr_group_ip,
    const UI32_T              port_id);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETNVO3GROUPEGRPORTLIST_FUNC_T)(
    const UI32_T            unit,
    const CLX_IP_ADDR_T  *ptr_group_ip,
    CLX_PORT_BITMAP_T       *ptr_port_list);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETNVO3GROUPEGRINFO_FUNC_T)(
    const UI32_T                unit,
    const CLX_IP_ADDR_T         *ptr_group_ip,
    const UI32_T                port_id,
    UI32_T                      *ptr_nvo3_adj_id);

typedef CLX_ERROR_NO_T \
(*HAL_NV_NVGRE_ADDVSID_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    vsid,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T \
(*HAL_NV_NVGRE_DELVSID_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    vsid,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T \
(*HAL_NV_NVGRE_GETVSID_FUNC_T)(
    const UI32_T                   unit,
    const CLX_BRIDGE_DOMAIN_T bdid,
    UI32_T                   *ptr_vsid);


typedef CLX_ERROR_NO_T \
(*HAL_NV_ADDSEGSERVICE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                seg,
    const CLX_TUNNEL_KEY_T      *ptr_key,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

typedef CLX_ERROR_NO_T \
(*HAL_NV_DELSEGSERVICE_FUNC_T)(
    const UI32_T            unit,
    const UI32_T            seg,
    const CLX_TUNNEL_KEY_T  *ptr_tnl_key);

typedef CLX_ERROR_NO_T \
(*HAL_NV_GETSEGSERVICE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                seg,
    const CLX_TUNNEL_KEY_T      *ptr_key,
          CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/*nv multiplexing functions end */
/*switch control multiplexing functions start*/

typedef CLX_ERROR_NO_T \
(*HAL_SWC_INIT_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_DEINIT_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETPROPERTY)(
    const UI32_T            unit,
    const CLX_SWC_PROPERTY_T    property,
    const UI32_T            param0,
    const UI32_T            param1);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETPROPERTY)(
    const UI32_T            unit,
    const CLX_SWC_PROPERTY_T    property,
    UI32_T                  *ptr_param0,
    UI32_T                  *ptr_param1);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETCHIPTEMPERATURE)(
    const UI32_T   unit,
    I32_T          *ptr_chip_temperature);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETHASHKEY)(
    const UI32_T                    unit,
    const CLX_SWC_HASH_TYPE_T       hash_type,
    const CLX_SWC_HASH_KEY_BITMAP_T key_bitmap);


typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETHASHKEY)(
    const UI32_T                    unit,
    const CLX_SWC_HASH_TYPE_T       hash_type,
    CLX_SWC_HASH_KEY_BITMAP_T       *ptr_key_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETTSVALUE)(
    const UI32_T                unit,
    UI16_T                      sec_hi,
    UI32_T                      sec_low,
    UI32_T                      nsec);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETTSVALUE)(
    const UI32_T                unit,
    UI16_T                      *ptr_sec_hi,
    UI32_T                      *ptr_sec_low,
    UI32_T                      *ptr_nsec);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETTSOFFSET)(
    const UI32_T                unit,
    const I32_T                 nsec);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETSTEERING)(
    const UI32_T                    unit,
    const CLX_SWC_STEERING_ENTRY_T  *ptr_str_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETSTEERING)(
    const UI32_T                    unit,
    CLX_SWC_STEERING_ENTRY_T        *ptr_str_entry);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETHASHCONSTANT)(
    const UI32_T              unit,
    const CLX_SWC_HASH_TYPE_T hash_type,
    const UI32_T              count,
    const UI32_T              *ptr_hash_const);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETHASHCONSTANT)(
    const UI32_T              unit,
    const CLX_SWC_HASH_TYPE_T hash_type,
    const UI32_T              count,
    UI32_T                    *ptr_hash_const);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETHASHCONSTANTBYKEY)(
    const UI32_T                  unit,
    const CLX_SWC_HASH_TYPE_T     hash_type,
    const CLX_SWC_HASH_KEY_TYPE_T key,
    const UI32_T                  *ptr_hash_const);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETHASHCONSTANTBYKEY)(
    const UI32_T                  unit,
    const CLX_SWC_HASH_TYPE_T     hash_type,
    const CLX_SWC_HASH_KEY_TYPE_T key,
    UI32_T                        *ptr_hash_const);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_REGISTERERRORCALLBACK)(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_FUNC_T    callback,
    void                          *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_DEREGISTERERRORCALLBACK)(
    const UI32_T                  unit,
    const CLX_SWC_ERROR_SRC_T     error,
    const CLX_SWC_ERROR_FUNC_T    callback,
    void                          *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETDEVICEINFO_FUNC_T)(
    const UI32_T                unit,
    CLX_SWC_DEVICE_INFO_T       *ptr_device_info);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETPORTCONFIG_FUNC_T)(
    const UI32_T                unit,
    CLX_SWC_PORT_CONFIG_T       *ptr_port_config);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETCAPACITY_FUNC_T)(
    const UI32_T         unit,
    const CLX_SWC_RSRC_T type,
    const UI32_T         param,
    UI32_T               *ptr_size);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETUSAGE_FUNC_T)(
    const UI32_T         unit,
    const CLX_SWC_RSRC_T type,
    const UI32_T         param,
    UI32_T               *ptr_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETCSOMODE_FUNC_T)(
    const UI32_T                unit,
    const CLX_SWC_CSO_MODE_T    mode);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETCSOMODE_FUNC_T)(
    const UI32_T        unit,
    CLX_SWC_CSO_MODE_T  *ptr_mode);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETCPIENCAP_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SWC_CPI_ENCAP_HDR_T   *ptr_encap_hdr);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_GETCPIENCAP_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                port,
    CLX_SWC_CPI_ENCAP_HDR_T     *ptr_encap_hdr);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETEXCEPTION_FUNC_T)(
    const UI32_T            unit,
    const UI32_T            enable,
    const CLX_FWD_ACTION_T  action);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETTRAPALL_FUNC_T)(
    const UI32_T            unit,
    const UI32_T            enable);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SETEPGMACHW_FUNC_T)(
    const UI32_T            unit,
    const HAL_SWC_EPG_PKT_T *ptr_pkt);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_SENDEPGMACPKT_FUNC_T)(
    const UI32_T unit,
    const UI32_T port,
    const UI32_T lpbk);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_CHKEPGMACDONE_FUNC_T)(
    const UI32_T unit,
    const UI32_T port);

typedef CLX_ERROR_NO_T \
(*HAL_SWC_STOPEPGMACPKT_FUNC_T)(
    const UI32_T unit,
    const UI32_T port);

typedef CLX_ERROR_NO_T
(*HAL_SWC_GETCHIPCFGINFO_T) (
    const UI32_T    unit,
    const CLX_SWC_CHIP_CFG_INFO_TYPE_T type,
    const UI32_T    para0,
    const UI32_T    para1,
    UI32_T          *ptr_value);

typedef CLX_ERROR_NO_T (*HAL_SWC_GETTBLNAME_T)(const UI32_T unit,
                                               const UI32_T tbl_id,
                                               const UI32_T tbl_name_len,
                                               C8_T *ptr_tbl_name);

typedef CLX_ERROR_NO_T (*HAL_SWC_GETSTRINGNAMEBYID_T)(const UI32_T unit,
                                                      const CLX_SWC_DATA_TYPE_T data_type,
                                                      const UI32_T index,
                                                      const UI32_T str_len,
                                                      C8_T *str_name);


/*switch control multiplexing functions end*/

/* fcoe command */

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_INIT_FUNC_T)(
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_DEINIT_FUNC_T)(
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_ADDINTF_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const CLX_FCOE_INTF_INFO_T      *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_DELINTF_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETINTF_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    CLX_FCOE_INTF_INFO_T            *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_ADDHOST_FUNC_T)(
    const UI32_T                    unit,
    const CLX_FCOE_HOST_INFO_T      *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_DELHOST_FUNC_T)(
    const UI32_T                    unit,
    const CLX_FCOE_HOST_INFO_T      *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETHOST_FUNC_T)(
    const UI32_T                    unit,
    CLX_FCOE_HOST_INFO_T            *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_ADDROUTE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_FCOE_ROUTE_INFO_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_DELROUTE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_FCOE_ROUTE_INFO_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETROUTE_FUNC_T)(
    const UI32_T                    unit,
    CLX_FCOE_ROUTE_INFO_T           *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_SETVNTOVNENABLE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const BOOL_T                    enable);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETVNTOVNENABLE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    BOOL_T                          *ptr_enable);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_SETZONECHECK_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const BOOL_T                    enable);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETZONECHECK_FUNC_T)(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    BOOL_T                          *ptr_enable);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_ADDZONE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_FCOE_ZONE_T           *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_DELZONE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_FCOE_ZONE_T           *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETZONE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_FCOE_ZONE_T           *ptr_entry,
    BOOL_T                          *ptr_is_set);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_SETPORTCLVCONFIG_FUNC_T)(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    const CLX_FCOE_CLV_PORT_INFO_T  *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETPORTCLVCONFIG_FUNC_T)(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_FCOE_CLV_PORT_INFO_T        *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_SETFRAMETYPEACTION_FUNC_T)(
    const UI32_T                        unit,
    const CLX_FCOE_FC_FRAME_ACTION_T    *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETFRAMETYPEACTION_FUNC_T)(
    const UI32_T                    unit,
    CLX_FCOE_FC_FRAME_ACTION_T      *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_CREATEPORT_FUNC_T)(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_PORT_T                      *ptr_intf);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_DESTROYPORT_FUNC_T)(
    const UI32_T                    unit,
    const CLX_PORT_T                intf);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_SETPACKETPASER_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    enable);

typedef CLX_ERROR_NO_T \
(*HAL_FCOE_GETPACKETPASER_FUNC_T)(
    const UI32_T    unit,
    UI32_T          *enable);

/* qos multiplexing functions start */

typedef CLX_ERROR_NO_T \
(*HAL_QOS_INIT_FUNC_T) (
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T \
(*HAL_QOS_DEINIT_FUNC_T) (
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T \
(*HAL_QOS_CREATEPROFILE_FUNC_T) (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profileId );

typedef CLX_ERROR_NO_T \
(*HAL_QOS_DELPROFILE_FUNC_T) (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profileId );

typedef CLX_ERROR_NO_T \
(*HAL_QOS_SETPROFILEENTRY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profileId,
    const CLX_QOS_MAPPING_ENTRY_T   *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_QOS_GETPROFILEENTRY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profileId,
    CLX_QOS_MAPPING_ENTRY_T         *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_QOS_SETCOSQMAPPING_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    tc,
    const UI32_T                    queue_id );

typedef CLX_ERROR_NO_T \
(*HAL_QOS_GETCOSQMAPPING_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    tc,
    UI32_T                          *ptr_queue_id );

/* qos multiplexing functions end */

/* meter multiplexing functions start */
typedef CLX_ERROR_NO_T
(*HAL_METER_INIT_FUNC_T)(
    const UI32_T            unit);

typedef CLX_ERROR_NO_T
(*HAL_METER_DEINIT_FUNC_T)(
    const UI32_T            unit);

typedef CLX_ERROR_NO_T
(*HAL_METER_CREATEMETER_FUNC_T)(
    const UI32_T                unit,
    const CLX_METER_CFG_T       *ptr_meter_cfg,
    UI32_T                      *ptr_meter_id);

typedef CLX_ERROR_NO_T
(*HAL_METER_DESTROYMETER_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                meter_id);

typedef CLX_ERROR_NO_T
(*HAL_METER_GETMETER_FUNC_T)(
    const UI32_T            unit,
    const UI32_T            meter_id,
    CLX_METER_CFG_T         *ptr_meter_cfg);

typedef CLX_ERROR_NO_T
(*HAL_METER_SETMETERPARAM_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    meter_id,
    const CLX_METER_PARAMETER_T     *ptr_meter_param);

typedef CLX_ERROR_NO_T
(*HAL_METER_SETIGRPORTMETER_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_METER_PORT_CFG_T      *ptr_cfg);

typedef CLX_ERROR_NO_T
(*HAL_METER_GETIGRPORTMETER_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_METER_PORT_CFG_T            *ptr_cfg);

/* meter multiplexing functions end */

/* stat multiplexing functions start */
typedef CLX_ERROR_NO_T
(*HAL_STAT_INIT_FUNC_T)(
    const UI32_T            unit);

typedef CLX_ERROR_NO_T
(*HAL_STAT_DEINIT_FUNC_T)(
    const UI32_T            unit);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETPORTCNT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_STAT_PORT_CNT_TYPE_T      type,
    UI64_T                              *ptr_cnt);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CLEARPORTCNT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_STAT_PORT_CNT_TYPE_T      type);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETTMCNT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_STAT_TM_CNT_TYPE_T        type,
    CLX_STAT_TM_CNT_T                   *ptr_cnt);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CLEARTMCNT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_STAT_TM_CNT_TYPE_T        type);

typedef CLX_ERROR_NO_T
(*HAL_STAT_SETTMQUEUECNTFORPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETTMQUEUECNTFORPORT_FUNC_T)(
    const UI32_T                        unit,
    UI32_T                              *ptr_port);

typedef CLX_ERROR_NO_T
(*HAL_STAT_SETTMQUEUECNTFORCPU_FUNC_T)(
    const UI32_T                        unit,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_HANDLER_T              cpu_handler);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETTMQUEUECNTFORCPU_FUNC_T)(
    const UI32_T                        unit,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_HANDLER_T                    *ptr_cpu_handler);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETTMQUEUECNT_FUNC_T)(
    const UI32_T                    unit,
    const CLX_TM_HANDLER_T          handler,
    CLX_STAT_TM_QUEUE_CNT_T         *ptr_cnt);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CLEARTMQUEUECNT_FUNC_T)(
    const UI32_T                    unit,
    const CLX_TM_HANDLER_T          handler);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CREATEDISTCNT_FUNC_T)(
    const UI32_T                    unit,
    UI32_T                          *ptr_cnt_id);

typedef CLX_ERROR_NO_T
(*HAL_STAT_DESTROYDISTCNT_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    cnt_id);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETDISTCNT_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    cnt_id,
    CLX_STAT_DIST_CNT_T             *ptr_cnt);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CLEARDISTCNT_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    cnt_id);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CREATECNT_FUNC_T)(
    const UI32_T              unit,
    const CLX_STAT_CNT_CFG_T  *ptr_cfg,
    UI32_T                    *ptr_cnt_id);

typedef CLX_ERROR_NO_T
(*HAL_STAT_DESTROYCNT_FUNC_T)(
    const UI32_T              unit,
    UI32_T                    cnt_id);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETCNT_FUNC_T)(
    const UI32_T            unit,
    const UI32_T            cnt_id,
    CLX_STAT_CNT_T          *ptr_cnt);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CLEARCNT_FUNC_T)(
    const UI32_T              unit,
    const UI32_T              cnt_id);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETCNTCFG_FUCT_T)(
    const UI32_T              unit,
    const UI32_T              cnt_id,
    CLX_STAT_CNT_CFG_T        *ptr_cfg
);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETPORTRATE_FUNC_T)(
    const UI32_T                     unit,
    const UI32_T                     port,
    const CLX_STAT_RATE_TYPE_T       type,
    UI64_T                           *ptr_rate);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETPORTRATETYPE_FUNC_T)(
    const UI32_T                     unit,
    const CLX_STAT_PORT_CNT_TYPE_T   type,
    CLX_STAT_RATE_TYPE_T             *rate_type);

typedef CLX_ERROR_NO_T
(*HAL_STAT_REFRESHCNT_FUCT_T)(
    const UI32_T              unit
);

typedef CLX_ERROR_NO_T
(*HAL_STAT_SETFLOWGROUPMODE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_DIR_T                 dir,
    const UI32_T                    grp_id,
    const CLX_STAT_CNT_GROUP_MODE_T grp_mode);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETFLOWGROUPMODE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_DIR_T                 dir,
    const UI32_T                    grp_id,
    CLX_STAT_CNT_GROUP_MODE_T       *ptr_mode);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETFLOWGROUPCAPACITY_FUNC_T)(
    const UI32_T                        unit,
    const CLX_DIR_T                     dir,
    const UI32_T                        grp_id,
    UI32_T                              *ptr_capacity);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETCNTIDBYFLOWGROUP_FUNC_T)(
    const UI32_T                        unit,
    const CLX_DIR_T                     dir,
    const UI32_T                        grp_id,
    const UI32_T                        id_cnt,
    UI32_T                              *ptr_cnt_id,
    UI32_T                              *ptr_actual_cnt_id_cnt);

typedef CLX_ERROR_NO_T
(*HAL_STAT_SHOWDBGCNT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        stage_bmp,
    const UI32_T                        flags);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CLEARDBGCNT_FUNC_T)(
    const UI32_T                        unit);

typedef CLX_ERROR_NO_T
(*HAL_STAT_GETRSERRDISTCNT)(
    const UI32_T                            unit,
    const UI32_T                            port,
    HAL_STAT_RSERRDIST_CNT_ENTRY_T          *ptr_cnt);

typedef CLX_ERROR_NO_T
(*HAL_STAT_CLEARRSERRDISTCNT)(
    const UI32_T                            unit,
    const UI32_T                            port);

typedef CLX_ERROR_NO_T
(*HAL_STAT_SETRSERRDISTCNTINTERVAL)(
    const UI32_T                            unit,
    const UI32_T                            interval);

typedef CLX_ERROR_NO_T
(*HAL_STAT_ANALYZEDBG_FUNC_T)(
    const UI32_T                            unit,
    const UI32_T                            input_port,
    const CLX_PORT_BITMAP_T                 output_portlist,
    const UI32_T                            type,
    const UI32_T                            lbk_dst_port);

typedef CLX_ERROR_NO_T
(*HAL_STAT_ANALYZESNAKEDBG_FUNC_T)(
    const UI32_T                            unit,
    const C8_T                              *ptr_portlist,
    const UI32_T                            wire,
    const UI32_T                            bi_dir);

/* stat multiplexing functions end */

/* tm multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_TM_INIT_FUNC_T) (
    const UI32_T                        unit);

typedef CLX_ERROR_NO_T \
(*HAL_TM_DEINIT_FUNC_T) (
    const UI32_T                        unit);

typedef CLX_ERROR_NO_T \
(*HAL_TM_CREATEHANDLER_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_TYPE_T         handler_type,
    const UI32_T                        queue_id,
    CLX_TM_HANDLER_T                    *ptr_handler ) ;

typedef CLX_ERROR_NO_T \
(*HAL_TM_DELETEHANDLER_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETSCHEDULETOPOLOGY_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_SCH_TOPOLOGY_ENTRY_T   *ptr_topology_entry,
    const UI32_T                        entry_count);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETSCHEDULETOPOLOGY_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_TM_SCH_TOPOLOGY_ENTRY_T         *ptr_topology_entry,
    UI32_T                              entry_count,
    UI32_T                              *ptr_actual_entry_count);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SCH_SETBANDWIDTH_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BANDWIDTH_T            *ptr_bandwidth );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SCH_GETBANDWIDTH_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_BANDWIDTH_T                  *ptr_bandwidth );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SCH_SETSCHEDULEMODE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_SCH_MODE_T             mode,
    const UI32_T                        weight);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SCH_GETSCHEDULEMODE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_SCH_MODE_T                   *ptr_mode,
    UI32_T                              *ptr_weight);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETTCQUEUEMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        tc,
    const CLX_TM_HANDLER_TYPE_T         type,
    const CLX_TM_HANDLER_T              handler);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETTCQUEUEMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        tc,
    const CLX_TM_HANDLER_TYPE_T         type,
    CLX_TM_HANDLER_T                    *ptr_handler );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETIGRBUFPCPREMAP_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        org_pcp,
    const UI32_T                        igrbuf_pcp);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETIGRBUFPCPREMAP_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        org_pcp,
    UI32_T                              *ptr_igrbuf_pcp);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETEGRBUFPFCPCPREMAPQUEUE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        pfc_pcp,
    const CLX_TM_HANDLER_T              handler);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETEGRBUFPFCPCPREMAPQUEUE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        pfc_pcp,
    CLX_TM_HANDLER_T                    *ptr_handler);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETPROPERTY_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_PROPERTY_T             property,
    const UI32_T                        param0,
    const UI32_T                        param1 );

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETPROPERTY_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_PROPERTY_T             property,
    UI32_T                              *ptr_param0,
    UI32_T                              *ptr_param1);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETCNGCTRL_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_CNG_T                  mode );

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETCNGCTRL_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_CNG_T                        *ptr_mode );

typedef CLX_ERROR_NO_T \
(*HAL_TM_CREATEWREDPROFILE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        profile_id );

typedef CLX_ERROR_NO_T \
(*HAL_TM_DELWREDPROFILE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        profile_id );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETWREDPROFILE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    const CLX_TM_TRAFFIC_TYPE_T         type,
    const CLX_COLOR_T                   color,
    const CLX_TM_WRED_ENTRY_T           *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETWREDPROFILE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    const CLX_TM_TRAFFIC_TYPE_T         type,
    const CLX_COLOR_T                   color,
    CLX_TM_WRED_ENTRY_T                 *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETWREDQUEUECONFIG_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_WRED_QUEUE_CFG_T       *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETWREDQUEUECONFIG_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_WRED_QUEUE_CFG_T             *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_TM_CREATEDCTCPPROFILE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        profile_id );

typedef CLX_ERROR_NO_T \
(*HAL_TM_DELDCTCPPROFILE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        profile_id );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETDCTCPPROFILE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    const CLX_TM_DCTCP_PROFILE_T        *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETDCTCPPROFILE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    CLX_TM_DCTCP_PROFILE_T              *ptr_entry );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETDCTCPQUEUECONFIG_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        profile_id );

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETDCTCPQUEUECONFIG_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_profile_id );

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETPFCMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETPFCMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETBUFTHRESHOLD_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    const CLX_TM_BUF_THRESHOLD_T        *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETBUFTHRESHOLD_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_THRESHOLD_T              *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETBUFOCCUPANCY_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_OCCUPANCY_T              *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETBUFWATERMARK_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_WATERMARK_T              *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TM_CLEARBUFWATERMARK_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETBUFWATERMARKLIST_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T             type,
    const UI32_T                        list_cnt,
    CLX_TM_BUF_WATERMARK_T              *ptr_entry_list);

typedef CLX_ERROR_NO_T \
(*HAL_TM_CLEARBUFWATERMARKLIST_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T             type,
    const UI32_T                        list_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_TM_REGISTERBUFSNAPSHOTCALLBACK_FUNC_T) (
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_FUNC_T        notify_function,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_TM_DEREGISTERBUFSNAPSHOTCALLBACK_FUNC_T) (
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_FUNC_T        notify_function,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETPAUSESTATUS_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_status);

typedef CLX_ERROR_NO_T \
(*HAL_TM_DUMPREG_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        flags);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETQUEUEENABLE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        enable);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETQUEUEENABLE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_enable);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETPCPPFCMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETPCPPFCMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETDSCPPFCMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        dscp_count,
    UI32_T                              *ptr_dscp_list);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETDSCPPFCMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_dscp_count,
    UI32_T                              *ptr_dscp_list);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETQUEUEPFCPRIMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETQUEUEPFCPRIMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETPFCPRIQUEUEMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    const CLX_TM_HANDLER_T              handler);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETPFCPRIQUEUEMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    CLX_TM_HANDLER_T                    *ptr_handler);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETPFCPRIQUEUEMAPPING_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    CLX_TM_HANDLER_T                    *ptr_handler);

typedef CLX_ERROR_NO_T \
(*HAL_TM_REGISTERPFCWDCALLBACK_FUNC_T) (
    const UI32_T                        unit,
    const CLX_TM_PFCWD_HANDLE_FUNC_T    notify_function,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_TM_DEREGISTERPFCWDCALLBACK_FUNC_T) (
    const UI32_T                        unit,
    const CLX_TM_PFCWD_HANDLE_FUNC_T    notify_function,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_TM_SETPFCWD_FUNC_T) (
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_ENTRY_T                *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETPFCWD_FUNC_T) (
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_ENTRY_T                *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TM_GETPFCWDSTATE_FUNC_T) (
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_STATE_T                *ptr_state);

/* tm multiplexing functions end */

/* MPLS multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_MPLS_INIT_FUNC_T) (
    const  UI32_T           unit);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_DEINIT_FUNC_T) (
    const UI32_T           unit);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_CREATEPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_ENCAP_KEY_T      *ptr_key,
    CLX_PORT_T                      *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_DESTROYPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_ENCAP_KEY_T      *ptr_key,
    CLX_PORT_T                      *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETKEY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_MPLS_ENCAP_KEY_T            *ptr_key);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_ADDINIT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    const CLX_MPLS_INIT_T           *ptr_init);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_DELINIT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETINIT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_MPLS_INIT_T                 *ptr_init);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_ADDTERM_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_MATCH_KEY_T      *ptr_key,
    const CLX_MPLS_TERM_T           *ptr_term);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_DELTERM_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_MATCH_KEY_T      *ptr_key);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETTERM_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_MATCH_KEY_T      *ptr_key,
    CLX_MPLS_TERM_T                 *ptr_term);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_ADDTRANSIT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_MATCH_KEY_T      *ptr_key,
    const CLX_MPLS_NHLFE_T          *ptr_nhlfe);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_DELTRANSIT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_MATCH_KEY_T      *ptr_key);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETTRANSIT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_MATCH_KEY_T      *ptr_key,
    CLX_MPLS_NHLFE_T                *ptr_nhlfe);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_CREATEPWPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_PW_KEY_T         *ptr_key,
    CLX_PORT_T                      *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_DESTROYPWPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETPWPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_MPLS_PW_KEY_T         *ptr_key,
    CLX_PORT_T                      *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETPWKEY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_MPLS_PW_KEY_T               *ptr_key);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_ADDPW_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    const CLX_MPLS_PW_T             *ptr_pw);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_DELPW_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETPW_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_MPLS_PW_T                   *ptr_pw);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_ADDVPWS_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    const CLX_MPLS_AC_T             *ptr_ac);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_DELVPWS_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETVPWS_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_MPLS_AC_T                   *ptr_ac);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_SETLABELRANGE_FUNC_T) (
    const UI32_T                unit,
    const CLX_MPLS_LABEL_TYPE_T type,
    const UI32_T                min_value,
    const UI32_T                max_value);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_GETLABELRANGE_FUNC_T) (
    const UI32_T                unit,
    const CLX_MPLS_LABEL_TYPE_T type,
    UI32_T                      *ptr_min_value,
    UI32_T                      *ptr_max_value);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_TRAVERSEINIT_FUNC_T) (
    const UI32_T                        unit,
    const CLX_MPLS_INIT_TRAVERSE_FUNC_T callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_TRAVERSETRANSIT_FUNC_T) (
    const UI32_T                            unit,
    const CLX_MPLS_TRANSIT_TRAVERSE_FUNC_T  callback,
    void                                    *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_TRAVERSETERM_FUNC_T) (
    const UI32_T                        unit,
    const CLX_MPLS_TERM_TRAVERSE_FUNC_T callback,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T \
(*HAL_MPLS_TRAVERSEPW_FUNC_T) (
    const UI32_T                        unit,
    const CLX_MPLS_PW_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);
/* MPLS multiplexing functions end */

/* TRILL multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_TRILL_INIT_FUNC_T) (
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DEINIT_FUNC_T) (
    const UI32_T                    unit);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_SETMYNICKNAME_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_NICKNAME_T      nickname);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETMYNICKNAME_FUNC_T) (
    const UI32_T                    unit,
    CLX_TRILL_NICKNAME_T            *ptr_nickname);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_SETPKTHANDLING_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_PKT_HANDLING_T  *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETPKTHANDLING_FUNC_T) (
    const UI32_T                    unit,
    CLX_TRILL_PKT_HANDLING_T        *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_CREATEPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_NICKNAME_T      egr_nickname,
    const UI32_T                    flags,
    CLX_PORT_T                      *ptr_tnl_port);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DESTROYPORT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_PORT_T                tnl_port);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_ADDINIT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_INIT_INFO_T     *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DELINIT_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_INIT_INFO_T     *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETINIT_FUNC_T) (
    const UI32_T                    unit,
    CLX_TRILL_INIT_INFO_T           *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_ADDTERM_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_TERM_INFO_T     *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DELTERM_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_TERM_INFO_T     *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETTERM_FUNC_T) (
    const UI32_T                    unit,
    CLX_TRILL_TERM_INFO_T           *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_ADDSEGSERVICE_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_NICKNAME_T      igr_nickname,
    const CLX_TRILL_NICKNAME_T      egr_nickname,
    const UI32_T                    vl_fgl_high,
    const UI32_T                    fgl_low,
    const CLX_PORT_SEG_SRV_T        *ptr_srv);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DELSEGSERVICE_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_NICKNAME_T      igr_nickname,
    const CLX_TRILL_NICKNAME_T      egr_nickname,
    const UI32_T                    vl_fgl_high,
    const UI32_T                    fgl_low);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETSEGSERVICE_FUNC_T) (
     const UI32_T                   unit,
     const CLX_TRILL_NICKNAME_T     igr_nickname,
     const CLX_TRILL_NICKNAME_T     egr_nickname,
     const UI32_T                   vl_fgl_high,
     const UI32_T                   fgl_low,
     CLX_PORT_SEG_SRV_T             *ptr_srv);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_ADDROUTE_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_ROUTE_INFO_T    *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DELROUTE_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_ROUTE_INFO_T    *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETROUTE_FUNC_T) (
    const UI32_T                    unit,
    CLX_TRILL_ROUTE_INFO_T          *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_ADDTREE_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_TREE_INFO_T     *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DELTREE_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_TREE_INFO_T     *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETTREE_FUNC_T) (
    const UI32_T                    unit,
    CLX_TRILL_TREE_INFO_T           *ptr_info);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_ADDADJCHECKENTRY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_ADJ_CHECK_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DELADJCHECKENTRY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_ADJ_CHECK_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETADJCHECKENTRY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_ADJ_CHECK_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_ADDRPFCHECKENTRY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_RPF_CHECK_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DELRPFCHECKENTRY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_RPF_CHECK_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETRPFCHECKENTRY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_RPF_CHECK_T     *ptr_entry);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_ADDVIRTUALRB_FUNC_T) (
    const UI32_T                    unit,
    const CLX_TRILL_NICKNAME_T      nickname,
    const UI32_T                    flags,
    UI32_T                          *ptr_rbv_id);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_DELVIRTUALRB_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    rbv_id);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETVIRTUALRB_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    rbv_id,
    CLX_TRILL_NICKNAME_T            *ptr_nickname);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_SETPORTPROPERTY_FUNC_T) (
    const UI32_T                       unit,
    const CLX_PORT_T                   port,
    const CLX_TRILL_PORT_PROPERTY_T    *ptr_property);

typedef CLX_ERROR_NO_T \
(*HAL_TRILL_GETPORTPROPERTY_FUNC_T) (
    const UI32_T                       unit,
    const CLX_PORT_T                   port,
    CLX_TRILL_PORT_PROPERTY_T          *ptr_property);

/* TRILL multiplexing functions end */

/* SFC multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_SFC_INIT_FUNC_T) (
    const UI32_T unit);

typedef CLX_ERROR_NO_T \
(*HAL_SFC_DEINIT_FUNC_T) (
    const UI32_T unit);

typedef CLX_ERROR_NO_T \
(*HAL_SFC_CREATEPORT_FUNC_T) (
    const UI32_T unit,
    const CLX_SFC_ENCAP_KEY_T *ptr_key,
    CLX_PORT_T *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_SFC_DESTROY_FUNC_T) (
    const UI32_T unit,
    const CLX_PORT_T port);

typedef CLX_ERROR_NO_T \
(*HAL_SFC_GETPORT_FUNC_T) (
    const UI32_T unit,
    const CLX_SFC_ENCAP_KEY_T *ptr_key,
    CLX_PORT_T *ptr_port);

typedef CLX_ERROR_NO_T \
(*HAL_SFC_GETKEY_FUNC_T) (
    const UI32_T unit,
    const CLX_PORT_T port,
    CLX_SFC_ENCAP_KEY_T *ptr_key);

typedef CLX_ERROR_NO_T \
(*HAL_SFC_ADDFORWARDER_FUNC_T) (
    const UI32_T unit,
    const CLX_SFC_FORWARDER_T *ptr_forwarder);

typedef CLX_ERROR_NO_T \
(*HAL_SFC_DELFORWARDER_FUNC_T) (
    const UI32_T unit,
    const CLX_SFC_FORWARDER_T *ptr_forwarder);

typedef CLX_ERROR_NO_T \
(*HAL_SFC_GETFORWARDER_FUNC_T) (
    const UI32_T unit,
    CLX_SFC_FORWARDER_T *ptr_forwarder);

/* SFC multiplexing functions end */

/* Stacking multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_STK_INIT_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_STK_DEINIT_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_STK_SETMYCHIPID_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    chip);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETMYCHIPID_FUNC_T) (
    const UI32_T    unit,
    UI32_T          *ptr_chip);

typedef CLX_ERROR_NO_T \
(*HAL_STK_SETNEIGHBORCHIPID_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    chip);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETNEIGHBORCHIPID_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    path,
    UI32_T          *ptr_chip);

typedef CLX_ERROR_NO_T \
(*HAL_STK_SETCUTOFFCHIPID_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    chip);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETCUTOFFCHIPID_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    path,
    UI32_T          *ptr_chip);

typedef CLX_ERROR_NO_T \
(*HAL_STK_ADDSTACKINGPORT_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    port);

typedef CLX_ERROR_NO_T \
(*HAL_STK_DELSTACKINGPORT_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    port);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETSTACKINGPORT_FUNC_T) (
    const UI32_T         unit,
    const UI32_T         path,
    CLX_PORT_BITMAP_T    *ptr_port_list);

typedef CLX_ERROR_NO_T \
(*HAL_STK_SETPATHTOREMOTECHIP_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    chip);

typedef CLX_ERROR_NO_T \
(*HAL_STK_SETREASONMAPPING_FUNC_T) (
    const UI32_T                     unit,
    const UI32_T                     chip,
    const CLX_PKT_RX_REASON_BITMAP_T reason_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETREASONMAPPING_FUNC_T) (
    const UI32_T                     unit,
    const UI32_T                     chip,
    CLX_PKT_RX_REASON_BITMAP_T       *ptr_reason_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_STK_ADDSTACKINGPORTTOCPU_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    cpu_path,
    const UI32_T    port);

typedef CLX_ERROR_NO_T \
(*HAL_STK_DELSTACKINGPORTTOCPU_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    cpu_path,
    const UI32_T    port);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETSTACKINGPORTTOCPU_FUNC_T) (
    const UI32_T         unit,
    const UI32_T         cpu_path,
    CLX_PORT_BITMAP_T    *ptr_port_list);

typedef CLX_ERROR_NO_T \
(*HAL_STK_SETCPUPATHTOREMOTECHIP_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    cpu_path,
    const UI32_T    chip);

typedef CLX_ERROR_NO_T \
(*HAL_STK_SETSTACKINGPORTQUEUEMAPPING_FUNC_T) (
    const UI32_T       unit,
    const UI32_T       rmt_cpu_queue,
    const UI32_T       stacking_queue);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETSTACKINGPORTQUEUEMAPPING_FUNC_T) (
    const UI32_T       unit,
    const UI32_T       rmt_cpu_queue,
    UI32_T             *ptr_stacking_queue);

typedef CLX_ERROR_NO_T \
(*HAL_STK_SETDILENTRY_FUNC_T) (
    const UI32_T        unit,
    const UI32_T        di,
    const CLX_STK_DIL_T *ptr_dil_entry);

typedef CLX_ERROR_NO_T \
(*HAL_STK_RESETDILENTRY_FUNC_T) (
    const UI32_T        unit,
    const UI32_T        di);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETDILENTRY_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    di,
    CLX_STK_DIL_T   *ptr_dil_entry);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETEXTCHIPDIINFO_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    chip,
    UI32_T   *ptr_di_base,
    UI32_T   *ptr_di_num);

typedef CLX_ERROR_NO_T \
(*HAL_STK_GETCHIPMODE_FUNC_T) (
    const UI32_T    unit,
    UI32_T          *ptr_chip_mode);

/* Stacking multiplexing functions end */

/* PPPoE multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_PPPOE_INIT_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_PPPOE_DEINIT_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_PPPOE_SETSERVERMAC_FUNC_T) (
    const UI32_T    unit,
    const CLX_MAC_T mac);

typedef CLX_ERROR_NO_T \
(*HAL_PPPOE_GETSERVERMAC_FUNC_T) (
    const UI32_T    unit,
    CLX_MAC_T       *ptr_mac);

typedef CLX_ERROR_NO_T \
(*HAL_PPPOE_ADDSEGSERVICE_FUNC_T) (
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const UI32_T                sess_id,
    const UI32_T                seg0,
    const UI32_T                seg1,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

typedef CLX_ERROR_NO_T \
(*HAL_PPPOE_DELSEGSERVICE_FUNC_T) (
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        sess_id,
    const UI32_T        seg0,
    const UI32_T        seg1);

typedef CLX_ERROR_NO_T \
(*HAL_PPPOE_GETSEGSERVICE_FUNC_T) (
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        sess_id,
    const UI32_T        seg0,
    const UI32_T        seg1,
    CLX_PORT_SEG_SRV_T  *ptr_seg_srv);
/* PPPoE multiplexing functions end */

/* DTEL multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_DTEL_INIT_FUNC_T) (
    const UI32_T                unit);

typedef CLX_ERROR_NO_T \
(*HAL_DTEL_DEINIT_FUNC_T) (
    const UI32_T                unit);

typedef CLX_ERROR_NO_T \
(*HAL_DTEL_SETDPPLOOPBACK_FUNC_T) (
    const UI32_T                unit,
    const CLX_DTEL_DPP_T        *ptr_dpp);

typedef CLX_ERROR_NO_T \
(*HAL_DTEL_GETDPPLOOPBACK_FUNC_T) (
    const UI32_T                unit,
    CLX_DTEL_DPP_T              *ptr_dpp);

typedef CLX_ERROR_NO_T \
(*HAL_DTEL_GETPROFILE_FUNC_T) (
    const UI32_T                unit,
    const UI32_T                profile_id,
    CLX_DTEL_CFG_T              *ptr_cfg);


typedef CLX_ERROR_NO_T (*HAL_TELM_INIT_FUNC_T)(const UI32_T unit);

typedef CLX_ERROR_NO_T (*HAL_TELM_DEINIT_FUNC_T)(const UI32_T unit);
typedef CLX_ERROR_NO_T (*HAL_TELM_GETIFACFG_FUNC_T)(const UI32_T unit,
                                                    CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

typedef CLX_ERROR_NO_T (*HAL_TELM_SETIFACFG_FUNC_T)(const UI32_T unit,
                                                    const CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

typedef CLX_ERROR_NO_T (*HAL_TELM_PREPAREIFATXPKT_FUNC_T)(const UI32_T unit,
                                        const CLX_PKT_RX_PKT_T *ptr_rx_pkt,
                                        void *ptr_cookie);

typedef void * (*HAL_TELM_IFA_DMA_ALLOCRXPKT_FUNC_T)(void);

typedef CLX_ERROR_NO_T (*HAL_TELM_IFA_DMA_FREEPKT_FUNC_T)(const void *ptr_dma_mem);

typedef CLX_ERROR_NO_T (*HAL_TELM_IFA_SENDTASKINIT)(UI32_T unit, UI32_T port);
typedef CLX_ERROR_NO_T (*HAL_TELM_IFA_SENDTASKDEINIT)(UI32_T unit, UI32_T port);
typedef CLX_ERROR_NO_T (*HAL_TELM_CFGPKT)(UI32_T unit);
typedef CLX_ERROR_NO_T (*HAL_TELM_DECFGPKT)(UI32_T unit);


typedef CLX_ERROR_NO_T \
(*HAL_DTEL_SETPROFILE_FUNC_T) (
    const UI32_T                unit,
    const UI32_T                profile_id,
    const CLX_DTEL_CFG_T        *ptr_cfg);
/* DTEL multiplexing functions end */

/* Debug dump multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_DUMP_DB_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    flags);/* flags is used to indicate which db */

typedef CLX_ERROR_NO_T \
(*HAL_DUMP_REG_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    flags);/* flags is used to indicate which reg/table */
/* Debug dump multiplexing functions end */

typedef struct
{
    HAL_UP_INIT_DCE_UP_FUNC_T                   hal_up_initDceUp;
} HAL_UP_FUNC_VEC_T;

typedef struct
{
    HAL_CHIP_MMIO_INIT_FUNC_T                   hal_chip_mmio_init;
    HAL_CHIP_INIT_FUNC_T                        hal_chip_init;
    HAL_CHIP_DEINIT_FUNC_T                      hal_chip_deinit;
} HAL_CHIP_FUNC_VEC_T;

typedef struct
{
    HAL_VLAN_INIT_FUNC_T                        hal_vlan_init;
    HAL_VLAN_DEINIT_FUNC_T                      hal_vlan_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_vlan_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_vlan_resetPortDefault;
    HAL_VLAN_SETPROPERTY_FUNC_T                 hal_vlan_setProperty;
    HAL_VLAN_GETPROPERTY_FUNC_T                 hal_vlan_getProperty;
    HAL_VLAN_CREATEVLAN_FUNC_T                  hal_vlan_createVlan;
    HAL_VLAN_DELVLAN_FUNC_T                     hal_vlan_delVlan;
    HAL_VLAN_SETPORT_FUNC_T                     hal_vlan_setPort;
    HAL_VLAN_GETPORT_FUNC_T                     hal_vlan_getPort;
    HAL_VLAN_SETVLANISOLATION_FUNC_T            hal_vlan_setVlanIsolation;
    HAL_VLAN_GETVLANISOLATION_FUNC_T            hal_vlan_getVlanIsolation;
    HAL_VLAN_ADDMACVLAN_FUNC_T                  hal_vlan_addMacVlan;
    HAL_VLAN_DELMACVLAN_FUNC_T                  hal_vlan_delMacVlan;
    HAL_VLAN_GETMACVLAN_FUNC_T                  hal_vlan_getMacVlan;
    HAL_VLAN_ADDPVLANENTRY                      hal_vlan_addPvlanEntry;
    HAL_VLAN_DELETEPVLANENTRY                   hal_vlan_delPvlanEntry;
    HAL_VLAN_GETPVLANENTRY                      hal_vlan_getPvlanEntry;
    HAL_VLAN_SETTYPEENTRY_FUNC_T                hal_vlan_setTypeEntry;
    HAL_VLAN_GETTYPEENTRY_FUNC_T                hal_vlan_getTypeEntry;
    HAL_VLAN_SETADDRENTRY_FUNC_T                hal_vlan_setAddrEntry;
    HAL_VLAN_GETADDRENTRY_FUNC_T                hal_vlan_getAddrEntry;
    HAL_VLAN_SETSERVICE_FUNC_T                  hal_vlan_setService;
    HAL_VLAN_GETSERVICE_FUNC_T                  hal_vlan_getService;
    HAL_VLAN_CREATEBRIDGEDOMAIN_FUNC_T          hal_vlan_createBridgeDomain;
    HAL_VLAN_DESTROYBRIDGEDOMAIN_FUNC_T         hal_vlan_destroyBridgeDomain;
    HAL_VLAN_TRAVERSEENTRY_FUNC_T               hal_vlan_traverseEntry;
    HAL_DUMP_DB_FUNC_T                          hal_vlan_dumpDb;
    HAL_DUMP_REG_FUNC_T                         hal_vlan_dumpReg;
} HAL_VLAN_FUNC_VEC_T;

typedef struct
{
    HAL_PORT_INIT_FUNC_T                        hal_port_init;
    HAL_PORT_DEINIT_FUNC_T                      hal_port_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_port_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_port_resetPortDefault;
    HAL_PORT_SETPROPERTY                        hal_port_setProperty;
    HAL_PORT_GETPROPERTY                        hal_port_getProperty;
    HAL_PORT_SETSPEED_FUNC_T                    hal_port_setSpeed;
    HAL_PORT_GETSPEED_FUNC_T                    hal_port_getSpeed;
    HAL_PORT_SETFLOWCTRL_FUNC_T                 hal_port_setFlowCtrl;
    HAL_PORT_GETFLOWCTRL_FUNC_T                 hal_port_getFlowCtrl;
    HAL_PORT_SETPRIFLOWCTRL_FUNC_T              hal_port_setPriFlowCtrl;
    HAL_PORT_GETPRIFLOWCTRL_FUNC_T              hal_port_getPriFlowCtrl;
    HAL_PORT_SETEEEMODE_FUNC_T                  hal_port_setEeeMode;
    HAL_PORT_GETEEEMODE_FUNC_T                  hal_port_getEeeMode;
    HAL_PORT_SETLOCALADVABILITY_FUNC_T          hal_port_setLocalAdvAbility;
    HAL_PORT_GETLOCALADVABILITY_FUNC_T          hal_port_getLocalAdvAbility;
    HAL_PORT_GETREMOTEADVABILITY_FUNC_T         hal_port_getRemoteAdvAbility;
    HAL_PORT_GETABILITY_FUNC_T                  hal_port_getAbility;
    HAL_PORT_SETLOOPBACK                        hal_port_setLoopback;
    HAL_PORT_GETLOOPBACK                        hal_port_getLoopback;
    HAL_PORT_PROBE                              hal_port_probe;
    HAL_PORT_INITPORT                           hal_port_initPort;
    HAL_PORT_DEINITPORT                         hal_port_deinitPort;
    HAL_PORT_SETMACADDR                         hal_port_setMacAddr;
    HAL_PORT_GETMACADDR                         hal_port_getMacAddr;
    HAL_PORT_GETLINK                            hal_port_getLink;
    HAL_PORT_GETFAULT                           hal_port_getFault;
    HAL_PORT_SETMEDIUCLYPE                      hal_port_setMediumType;
    HAL_PORT_GETMEDIUCLYPE                      hal_port_getMediumType;
    HAL_PORT_SETPHYPROPERTY                     hal_port_setPhyProperty;
    HAL_PORT_GETPHYPROPERTY                     hal_port_getPhyProperty;
    HAL_PORT_SETLANEMAP                         hal_port_setLaneMap;
    HAL_PORT_GETLANEMAP                         hal_port_getLaneMap;
    HAL_PORT_ADDSEGSERVICE                      hal_port_addSegService;
    HAL_PORT_DELSEGSERVICE                      hal_port_delSegService;
    HAL_PORT_GETSEGSERVICE                      hal_port_getSegService;
    HAL_PORT_CREATEPORT                         hal_port_createPort;
    HAL_PORT_DESTROYPORT                        hal_port_destroyPort;
    HAL_PORT_SETINTFPROPERTY                    hal_port_setIntfProperty;
    HAL_PORT_GETINTFPROPERTY                    hal_port_getIntfProperty;
    HAL_PORT_GETTSTXENTRY                       hal_port_getTsTxEntry;
    HAL_PORT_GETTSRXENTRY                       hal_port_getTsRxEntry;
    HAL_PORT_GETPORTTYPE                        hal_port_getPortType;
    HAL_PORT_GETSTATUS                          hal_port_getStatus;
    HAL_DUMP_DB_FUNC_T                          hal_port_dumpDb;
    HAL_PORT_GETPORT                            hal_port_getPort;
    HAL_PORT_ADDSEGSERVICEGROUP                 hal_port_addSegServiceGroup;
    HAL_PORT_DELSEGSERVICEGROUP                 hal_port_delSegServiceGroup;
    HAL_PORT_GETSEGSERVICEGROUP                 hal_port_getSegServiceGroup;
    HAL_PORT_TRAVERSESEGSERVICEGROUP            hal_port_traverseSegServiceGroup;
    HAL_PORT_SETTXCOEF                          hal_port_setTxCoef;
    HAL_PORT_GETTXCOEF                          hal_port_getTxCoef;
    HAL_PORT_GETANEN                            hal_port_getAnEn;
    HAL_PORT_SETANEN                            hal_port_setAnEn;
    HAL_PORT_GETLINKTRNGEN                      hal_port_getLinkTrainingEn;
    HAL_PORT_SETLINKTRNGEN                      hal_port_setLinkTrainingEn;
    HAL_PORT_GETLINKTRAININGRESULT              hal_port_getLinkTrainingResult;
    HAL_PORT_SETADVERTISEDINTFTYPE              hal_port_setAdvIntfType;
    HAL_PORT_GETPORTFROMCLXPORT                 hal_port_getPortFromClxPort;

} HAL_PORT_FUNC_VEC_T;

typedef struct
{
    HAL_IFMON_INIT_FUNC_T                       hal_ifmon_init;
    HAL_IFMON_DEINIT_FUNC_T                     hal_ifmon_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_ifmon_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_ifmon_resetPortDefault;
    HAL_IFMON_REGISTER_FUNC_T                   hal_ifmon_register;
    HAL_IFMON_DEREGISTER_FUNC_T                 hal_ifmon_deregister;
    HAL_IFMON_GETMODE_FUNC_T                    hal_ifmon_getMode;
    HAL_IFMON_SETMODE_FUNC_T                    hal_ifmon_setMode;
    HAL_IFMON_SETMONITORSTATE_FUNC_T            hal_ifmon_setMonitorState;
    HAL_IFMON_GETMONITORSTATE_FUNC_T            hal_ifmon_getMonitorState;
    HAL_DUMP_DB_FUNC_T                          hal_ifmon_dumpDb;
    HAL_IFMON_GETCALLBACKCNT_FUNC_T             hal_ifmon_getCallbackCnt;
} HAL_IFMON_FUNC_VEC_T;

typedef struct
{
    HAL_L2_INIT_FUNC_T                          hal_l2_init;
    HAL_L2_DEINIT_FUNC_T                        hal_l2_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_l2_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_l2_resetPortDefault;
    HAL_L2_ADDADDR_FUNC_T                       hal_l2_addAddr;
    HAL_L2_DELADDR_FUNC_T                       hal_l2_delAddr;
    HAL_L2_GETADDR_FUNC_T                       hal_l2_getAddr;
    HAL_L2_REPLACEADDR_FUNC_T                   hal_l2_replaceAddr;
    HAL_L2_TRAVERSEADDR_FUNC_T                  hal_l2_traverseAddr;
    HAL_L2_REGISTERADDRNOTIFYCALLBACK_FUNC_T    hal_l2_registerAddrNotifyCallback;
    HAL_L2_DEREGISTERADDRNOTIFYCALLBACK_FUNC_T  hal_l2_deregisterAddrNotifyCallback;
    HAL_L2_ADDMCASTID_FUNC_T                    hal_l2_addMcastId;
    HAL_L2_DELMCASTID_FUNC_T                    hal_l2_delMcastId;
    HAL_L2_GETMCASTID_FUNC_T                    hal_l2_getMcastId;
    HAL_L2_ADDMCASTEGRINTF_FUNC_T               hal_l2_addMcastEgrIntf;
    HAL_L2_DELMCASTEGRINTF_FUNC_T               hal_l2_delMcastEgrIntf;
    HAL_L2_GETMCASTEGRINTFCNT_FUNC_T            hal_l2_getMcastEgrIntfCnt;
    HAL_L2_GETMCASTEGRINTF_FUNC_T               hal_l2_getMcastEgrIntf;
    HAL_L2_ADDMCASTADDR_FUNC_T                  hal_l2_addMcastAddr;
    HAL_L2_DELMCASTADDR_FUNC_T                  hal_l2_delMcastAddr;
    HAL_L2_GETMCASTADDR_FUNC_T                  hal_l2_getMcastAddr;
    HAL_L2_ADDIPMCASTGROUP_FUNC_T               hal_l2_addIpMcastGroup;
    HAL_L2_DELIPMCASTGROUP_FUNC_T               hal_l2_delIpMcastGroup;
    HAL_L2_GETIPMCASTGROUP_FUNC_T               hal_l2_getIpMcastGroup;
    HAL_L2_TRAVERSEMCASTADDR_FUNC_T             hal_l2_traverseMcastAddr;
    HAL_DUMP_DB_FUNC_T                          hal_l2_dumpDb;
} HAL_L2_FUNC_VEC_T;

typedef struct
{
    HAL_MIR_INIT_FUNC_T                         hal_mir_init;
    HAL_MIR_DEINIT_FUNC_T                       hal_mir_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_mir_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_mir_resetPortDefault;
    HAL_MIR_ADDSESSION_FUNC_T                   hal_mir_addSession;
    HAL_MIR_DELSESSION_FUNC_T                   hal_mir_delSession;
    HAL_MIR_GETSESSION_FUNC_T                   hal_mir_getSession;
    HAL_MIR_ADDERSPANTERM_FUNC_T                hal_mir_addErspanTerm;
    HAL_MIR_DELERSPANTERM_FUNC_T                hal_mir_delErspanTerm;
    HAL_MIR_GETERSPANTERM_FUNC_T                hal_mir_getErspanTerm;
} HAL_MIR_FUNC_VEC_T;

typedef struct
{
    HAL_L3_INIT_FUNC_T                          hal_l3_init ;
    HAL_L3_DEINIT_FUNC_T                        hal_l3_deinit ;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_l3_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_l3_resetPortDefault;
    HAL_L3_ADDINTF_FUNC_T                       hal_l3_addIntf;
    HAL_L3_DELINTF_FUNC_T                       hal_l3_delIntf;
    HAL_L3_GETINTF_FUNC_T                       hal_l3_getIntf;
    HAL_L3_TRAVERSEINTF_FUNC_T                  hal_l3_traverseIntf;
    HAL_L3_ADDMYROUTERMAC_FUNC_T                hal_l3_addMyRouterMac;
    HAL_L3_DELMYROUTERMAC_FUNC_T                hal_l3_delMyRouterMac;
    HAL_L3_GETMYROUTERMAC_FUNC_T                hal_l3_getMyRouterMac;
    HAL_L3_ADDADJ_FUNC_T                        hal_l3_addAdj;
    HAL_L3_DELADJ_FUNC_T                        hal_l3_delAdj;
    HAL_L3_GETADJ_FUNC_T                        hal_l3_getAdj;
    HAL_L3_TRAVERSEADJ_FUNC_T                   hal_l3_traverseAdj;
    HAL_L3_ADDHOST_FUNC_T                       hal_l3_addHost;
    HAL_L3_DELHOST_FUNC_T                       hal_l3_delHost;
    HAL_L3_GETHOST_FUNC_T                       hal_l3_getHost;
    HAL_L3_TRAVERSEHOST_FUNC_T                  hal_l3_traverseHost;
    HAL_L3_ADDSUBNETBCAST_FUNC_T                hal_l3_addSubnetBcast;
    HAL_L3_DELSUBNETBCAST_FUNC_T                hal_l3_delSubnetBcast;
    HAL_L3_GETSUBNETBCAST_FUNC_T                hal_l3_getSubnetBcast;
    HAL_L3_TRAVERSESUBNETBCAST_FUNC_T           hal_l3_traverseSubnetBcast;
    HAL_L3_ADDROUTE_FUNC_T                      hal_l3_addRoute;
    HAL_L3_DELROUTE_FUNC_T                      hal_l3_delRoute;
    HAL_L3_DELROUTEALL_FUNC_T                   hal_l3_delRouteAll;
    HAL_L3_GETROUTE_FUNC_T                      hal_l3_getRoute;
    HAL_L3_TRAVERSEROUTE_FUNC_T                 hal_l3_traverseRoute;
    HAL_L3_CREATEECMPGRP_FUNC_T                 hal_l3_createEcmpGrp;
    HAL_L3_SETECMPGRP_FUNC_T                    hal_l3_setEcmpGrp;
    HAL_L3_DELECMPGRP_FUNC_T                    hal_l3_delEcmpGrp;
    HAL_L3_GETECMPGRP_FUNC_T                    hal_l3_getEcmpGrp;
    HAL_L3_TRAVERSEECMPGRP_FUNC_T               hal_l3_traverseEcmpGrp;
    HAL_L3_SYNCECMPGRP_FUNC_T                   hal_l3_syncEcmpGrp;
    HAL_L3_ADDECMPGRPPATH_FUNC_T                hal_l3_addEcmpGrpPath;
    HAL_L3_DELECMPGRPPATH_FUNC_T                hal_l3_delEcmpGrpPath;
    HAL_L3_GETECMPGRPPATHBYIDX_FUNC_T           hal_l3_getEcmpGrpPathByIdx;
    HAL_L3_SETECMPGRPHASHPATH_FUNC_T            hal_l3_setEcmpGrpHashPath ;
    HAL_L3_GETECMPGRPHASHPATH_FUNC_T            hal_l3_getEcmpGrpHashPath ;
    HAL_L3_SETPKTHANDLINGPERVRF_FUNC_T          hal_l3_setPktHandlingPerVrf;
    HAL_L3_GETPKTHANDLINGPERVRF_FUNC_T          hal_l3_getPktHandlingPerVrf;
    HAL_L3_GETBDBYINTFID_FUNC_T                 hal_l3_getBdByIntfId;
    HAL_L3_MCAST_ADDID_FUNC_T                   hal_l3_mcast_addId;
    HAL_L3_MCAST_DELID_FUNC_T                   hal_l3_mcast_delId;
    HAL_L3_MCAST_GETID_FUNC_T                   hal_l3_mcast_getId;
    HAL_L3_MCAST_ADDGROUP_FUNC_T                hal_l3_mcast_addGroup;
    HAL_L3_MCAST_DELGROUP_FUNC_T                hal_l3_mcast_delGroup;
    HAL_L3_MCAST_GETGROUP_FUNC_T                hal_l3_mcast_getGroup;
    HAL_L3_MCAST_ADDEGRINTFBYPORT_FUNC_T        hal_l3_mcast_addEgrIntfByPort;
    HAL_L3_MCAST_DELEGRINTFBYPORT_FUNC_T        hal_l3_mcast_delEgrIntfByPort;
    HAL_L3_MCAST_SETEGRINTFBYPORT_FUNC_T        hal_l3_mcast_setEgrIntfByPort;
    HAL_L3_MCAST_GETEGRINTFCNTBYPORT_FUNC_T     hal_l3_mcast_getEgrIntfCntByPort;
    HAL_L3_MCAST_GETEGRINTFBYPORT_FUNC_T        hal_l3_mcast_getEgrIntfByPort;
    HAL_L3_MCAST_ADDDFINTF_FUNC_T               hal_l3_mcast_addDfIntf;
    HAL_L3_MCAST_DELDFINTF_FUNC_T               hal_l3_mcast_delDfIntf;
    HAL_L3_MCAST_GETDFINTF_FUNC_T               hal_l3_mcast_getDfIntf;
    HAL_L3_MCAST_TRAVERSEGROUP_FUNC_T           hal_l3_traverseMcastGroup;
    HAL_L3_SETBFDINFO_FUNC_T                    hal_l3_setBfdInfo;
    HAL_L3_GETBFDINFO_FUNC_T                    hal_l3_getBfdInfo;
    HAL_L3_SETBFDCHECKFAILACTION_FUNC_T         hal_l3_setBfdCheckFailAction;
    HAL_L3_GETBFDCHECKFAILACTION_FUNC_T         hal_l3_getBfdCheckFailAction;
    HAL_L3_SETOPTIONHEADERACTION_FUNC_T         hal_l3_setOptionHeaderAction;
    HAL_L3_GETOPTIONHEADERACTION_FUNC_T         hal_l3_getOptionHeaderAction;
    HAL_L3_CREATEFRRSTATEID_FUNC_T              hal_l3_createFrrStateId;
    HAL_L3_DESTROYFRRSTATEID_FUNC_T             hal_l3_destroyFrrStateId;
    HAL_L3_SETFRRSTATE_FUNC_T                   hal_l3_setFrrState;
    HAL_L3_GETFRRSTATE_FUNC_T                   hal_l3_getFrrState;
    HAL_L3_ADDSRCFORPIMREG_FUNC_T               hal_l3_addSrcForPimReg;
    HAL_L3_DELSRCFORPIMREG_FUNC_T               hal_l3_delSrcForPimReg;
    HAL_L3_GETSRCFORPIMREG_FUNC_T               hal_l3_getSrcForPimReg;
    HAL_L3_ADDVRRP_FUNC_T                       hal_l3_addVrrp;
    HAL_L3_DELVRRP_FUNC_T                       hal_l3_delVrrp;
    HAL_L3_GETVRRP_FUNC_T                       hal_l3_getVrrp;
    HAL_DUMP_DB_FUNC_T                          hal_l3_dumpDb;
    HAL_L3_ADDFDLECMPGROUP_FUNC_T               hal_l3_addFdlEcmpGroup;
    HAL_L3_DELFDLECMPGROUP_FUNC_T               hal_l3_delFdlEcmpGroup;
    HAL_L3_GETFDLECMPGROUP_FUNC_T               hal_l3_getFdlEcmpGroup;
    HAL_L3_DUMPECMPMBRLIST_FUNC_T               hal_l3_dumpEcmpMbrList;
} HAL_L3_FUNC_VEC_T;

typedef struct
{
    HAL_L3T_INIT_FUNC_T                         hal_l3t_init;
    HAL_L3T_DEINIT_FUNC_T                       hal_l3t_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_l3t_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_l3t_resetPortDefault;
    HAL_L3T_ADDTUNNELMAC_FUNC_T                 hal_l3t_addTunnelMac;
    HAL_L3T_DELTUNNELMAC_FUNC_T                 hal_l3t_delTunnelMac;
    HAL_L3T_GETTUNNELMAC_FUNC_T                 hal_l3t_getTunnelMac;
    HAL_L3T_TRAVERSETUNNELMAC_FUNC_T            hal_l3t_traverseTunnelMac;
    HAL_L3T_ADDINIT_FUNC_T                      hal_l3t_addInit;
    HAL_L3T_DELINIT_FUNC_T                      hal_l3t_delInit;
    HAL_L3T_GETINIT_FUNC_T                      hal_l3t_getInit;
    HAL_L3T_TRAVERSEINIT_FUNC_T                 hal_l3t_traverseInit;
    HAL_L3T_ADDTERM_FUNC_T                      hal_l3t_addTerm;
    HAL_L3T_DELTERM_FUNC_T                      hal_l3t_delTerm;
    HAL_L3T_GETTERM_FUNC_T                      hal_l3t_getTerm;
    HAL_L3T_TRAVERSETERM_FUNC_T                 hal_l3t_traverseTerm;
    HAL_L3T_ADDNVO3ROUTE_FUNC_T                 hal_l3t_addNvo3Route;
    HAL_L3T_DELNVO3ROUTE_FUNC_T                 hal_l3t_delNvo3Route;
    HAL_L3T_GETNVO3ROUTE_FUNC_T                 hal_l3t_getNvo3Route;
    HAL_L3T_TRAVERSENVO3ROUTE_FUNC_T            hal_l3t_traverseNvo3Route;
    HAL_L3T_SETUNUSEDECNACTION_FUNC_T           hal_l3t_setUnusedEcnAction;
    HAL_L3T_GETUNUSEDECNACTION_FUNC_T           hal_l3t_getUnusedEcnAction;
    HAL_L3T_CREATEPORT_FUNC_T                   hal_l3t_createPort;
    HAL_L3T_DESTROYPORT_FUNC_T                  hal_l3t_destroyPort;
    HAL_L3T_GETPORT_FUNC_T                      hal_l3t_getPort;
    HAL_L3T_GETKEY_FUNC_T                       hal_l3t_getKey;
    HAL_L3T_TRAVERSEPORT_FUNC_T                 hal_l3t_traversePort;
    HAL_L3T_ADDFLEXTUNNEL_FUNC_T                hal_l3t_addFlexTunnel;
    HAL_L3T_DELFLEXTUNNEL_FUNC_T                hal_l3t_delFlexTunnel;
    HAL_L3T_GETFLEXTUNNEL_FUNC_T                hal_l3t_getFlexTunnel;
    HAL_L3T_SETFLEXTUNNELUDFPROFILE_FUNC_T      hal_l3t_setFlexTunnelUdfProfile;
    HAL_L3T_GETFLEXTUNNELUDFPROFILE_FUNC_T      hal_l3t_getFlexTunnelUdfProfile;
} HAL_L3T_FUNC_VEC_T;

typedef struct
{
    HAL_PKT_INIT_FUNC_T                         hal_pkt_init;
    HAL_PKT_DEINIT_FUNC_T                       hal_pkt_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_pkt_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_pkt_resetPortDefault;
    HAL_PKT_SETRXCONFIG_FUNC_T                  hal_pkt_setRxConfig;
    HAL_PKT_GETRXCONFIG_FUNC_T                  hal_pkt_getRxConfig;
    HAL_PKT_SETPDMALOOPBACK_FUNC_T              hal_pkt_setPdmaLoopback;
    HAL_PKT_SENDPACKET_FUNC_T                   hal_pkt_sendPacket;
    HAL_PKT_SETCTRLTOCPUENTRY_FUNC_T            hal_pkt_setCtrlToCpuEntry;
    HAL_PKT_GETCTRLTOCPUENTRY_FUNC_T            hal_pkt_getCtrlToCpuEntry;
    HAL_PKT_SETRXDEFAULTQUEUE_FUNC_T            hal_pkt_setRxDefaultQueue;
    HAL_PKT_GETRXDEFAULTQUEUED_FUNC_T           hal_pkt_getRxDefaultQueue;
    HAL_PKT_SETRXQUEUEMAPPING_FUNC_T            hal_pkt_setRxQueueMapping;
    HAL_PKT_GETRXQUEUEMAPPING_FUNC_T            hal_pkt_getRxQueueMapping;
    HAL_PKT_SETRXTOCPUPRI_FUNC_T                hal_pkt_setRxToCpuPri;
    HAL_PKT_GETRXTOCPUPRI_FUNC_T                hal_pkt_getRxToCpuPri;
    HAL_PKT_SETRXREDIRECTTOCPU_FUNC_T           hal_pkt_setRxRedirectToCpu;
    HAL_PKT_GETRXREDIRECTTOCPU_FUNC_T           hal_pkt_getRxRedirectToCpu;
    HAL_PKT_SETQUEUETORXCHANNEL_FUNC_T          hal_pkt_setQueueToRxChannel;
    HAL_PKT_GETQUEUETORXCHANNEL_FUNC_T          hal_pkt_getQueueToRxChannel;
    HAL_PKT_SETQUEUETRUNCATESIZE_FUNC_T         hal_pkt_setRxQueueTruncateSize;
    HAL_PKT_GETQUEUETRUNCATESIZE_FUNC_T         hal_pkt_getRxQueueTruncateSize;
    HAL_PKT_SETTXCHANNELCOSBITMAP_FUNC_T        hal_pkt_setTxChannelCosBitmap;
    HAL_PKT_GETTXCHANNELCOSBITMAP_FUNC_T        hal_pkt_getTxChannelCosBitmap;
    HAL_PKT_GETTXCNT_FUNC_T                     hal_pkt_getTxCnt;
    HAL_PKT_GETRXCNT_FUNC_T                     hal_pkt_getRxCnt;
    HAL_PKT_CLEARTXCNT_FUNC_T                   hal_pkt_clearTxCnt;
    HAL_PKT_CLEARRXCNT_FUNC_T                   hal_pkt_clearRxCnt;
    HAL_PKT_CREATEINTF_FUNC_T                   hal_pkt_createIntf;
    HAL_PKT_DESTROYINTF_FUNC_T                  hal_pkt_destroyIntf;
    HAL_PKT_GETINTF_FUNC_T                      hal_pkt_getIntf;
    HAL_PKT_SETINTF_FUNC_T                      hal_pkt_setIntf;
    HAL_PKT_CREATEPROFILE_FUNC_T                hal_pkt_createProfile;
    HAL_PKT_DESTROYPROFILE_FUNC_T               hal_pkt_destroyProfile;
    HAL_PKT_GETPROFILE_FUNC_T                   hal_pkt_getProfile;
    HAL_PKT_GETINTFCNT_FUNC_T                   hal_pkt_getIntfCnt;
    HAL_PKT_CLEARINTFCNT_FUNC_T                 hal_pkt_clearIntfCnt;
    HAL_PKT_SHOWTXDBGCNT_FUNC_T                 hal_pkt_showTxDbgCnt;
    HAL_PKT_SHOWRXDBGCNT_FUNC_T                 hal_pkt_showRxDbgCnt;
    HAL_PKT_DELCTRLTOCPUENTRYALL_FUNC_T         hal_pkt_delCtrlToCpuEntryAll;
    HAL_DUMP_DB_FUNC_T                          hal_pkt_dumpDb;
    HAL_PKT_SETRXMAPPING_FUNC_T                 hal_pkt_setRxMapping;
    HAL_PKT_GETRXMAPPING_FUNC_T                 hal_pkt_getRxMapping;
    HAL_DUMP_REG_FUNC_T                         hal_pkt_dumpReg;
    HAL_PKT_GETPPREASON_FUNC_T                  hal_pkt_getPpReason;
    HAL_PKT_SETINTFPROPERTY_FUNC_T              hal_pkt_setIntfProperty;
    HAL_PKT_GETINTFPROPERTY_FUNC_T              hal_pkt_getIntfProperty;
#if defined(NETIF_EN_NETLINK)
    HAL_PKT_CREATENETLINK_FUNC_T                hal_pkt_createNetlink;
    HAL_PKT_DESTROYNETLINK_FUNC_T               hal_pkt_destroyNetlink;
    HAL_PKT_GETNETLINK_FUNC_T                   hal_pkt_getNetlink;
#endif
    HAL_PKT_SETSWITCHID_FUNC_T                  hal_pkt_setSwitchId;
} HAL_PKT_FUNC_VEC_T;

typedef struct
{
    HAL_STAT_INIT_FUNC_T                        hal_stat_init;
    HAL_STAT_DEINIT_FUNC_T                      hal_stat_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_stat_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_stat_resetPortDefault;
    HAL_STAT_GETPORTCNT_FUNC_T                  hal_stat_getPortCnt;
    HAL_STAT_CLEARPORTCNT_FUNC_T                hal_stat_clearPortCnt;
    HAL_STAT_GETTMCNT_FUNC_T                    hal_stat_getTmCnt;
    HAL_STAT_CLEARTMCNT_FUNC_T                  hal_stat_clearTmCnt;
    HAL_STAT_SETTMQUEUECNTFORPORT_FUNC_T        hal_stat_setTmQueueCntForPort;
    HAL_STAT_GETTMQUEUECNTFORPORT_FUNC_T        hal_stat_getTmQueueCntForPort;
    HAL_STAT_SETTMQUEUECNTFORCPU_FUNC_T         hal_stat_setTmQueueCntForCpu;
    HAL_STAT_GETTMQUEUECNTFORCPU_FUNC_T         hal_stat_getTmQueueCntForCpu;
    HAL_STAT_GETTMQUEUECNT_FUNC_T               hal_stat_getTmQueueCnt;
    HAL_STAT_CLEARTMQUEUECNT_FUNC_T             hal_stat_clearTmQueueCnt;
    HAL_STAT_CREATEDISTCNT_FUNC_T               hal_stat_createDistCnt;
    HAL_STAT_DESTROYDISTCNT_FUNC_T              hal_stat_destroyDistCnt;
    HAL_STAT_GETDISTCNT_FUNC_T                  hal_stat_getDistCnt;
    HAL_STAT_CLEARDISTCNT_FUNC_T                hal_stat_clearDistCnt;
    HAL_STAT_CREATECNT_FUNC_T                   hal_stat_createCnt;
    HAL_STAT_DESTROYCNT_FUNC_T                  hal_stat_destroyCnt;
    HAL_STAT_GETCNT_FUNC_T                      hal_stat_getCnt;
    HAL_STAT_CLEARCNT_FUNC_T                    hal_stat_clearCnt;
    HAL_STAT_GETCNTCFG_FUCT_T                   hal_stat_getCntCfg;
    HAL_STAT_GETPORTRATE_FUNC_T                 hal_stat_getPortRate;
    HAL_STAT_GETPORTRATETYPE_FUNC_T             hal_stat_getPortRateType;
    HAL_STAT_REFRESHCNT_FUCT_T                  hal_stat_refreshCnt;
    HAL_STAT_SETFLOWGROUPMODE_FUNC_T            hal_stat_setFlowGroupMode;
    HAL_STAT_GETFLOWGROUPMODE_FUNC_T            hal_stat_getFlowGroupMode;
    HAL_STAT_GETFLOWGROUPCAPACITY_FUNC_T        hal_stat_getFlowGroupCapacity;
    HAL_STAT_GETCNTIDBYFLOWGROUP_FUNC_T         hal_stat_getCntIdByFlowGroup;
    HAL_STAT_SHOWDBGCNT_FUNC_T                  hal_stat_showDbgCnt;
    HAL_STAT_CLEARDBGCNT_FUNC_T                 hal_stat_clearDbgCnt;
    HAL_STAT_GETRSERRDISTCNT                    hal_stat_getRsErrDistCnt;
    HAL_STAT_CLEARRSERRDISTCNT                  hal_stat_clearRsErrDistCnt;
    HAL_STAT_SETRSERRDISTCNTINTERVAL            hal_stat_setRsErrDistCntInterval;
    HAL_STAT_ANALYZEDBG_FUNC_T                  hal_stat_analyzeDbg;
    HAL_STAT_ANALYZESNAKEDBG_FUNC_T             hal_stat_analyzeSnakeDbg;
} HAL_STAT_FUNC_VEC_T;

typedef struct
{
    HAL_SEC_INIT_FUNC_T                         hal_sec_init;
    HAL_SEC_DEINIT_FUNC_T                       hal_sec_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_sec_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_sec_resetPortDefault;
    HAL_SEC_SETDOSPORTCONFIG_FUNC_T             hal_sec_setDosPortConfig;
    HAL_SEC_GETDOSPORTCONFIG_FUNC_T             hal_sec_getDosPortConfig;
    HAL_SEC_SETDOSCONFIG_FUNC_T                 hal_sec_setDosConfig;
    HAL_SEC_GETDOSCONFIG_FUNC_T                 hal_sec_getDosConfig;
    HAL_SEC_SETSTORMCTRLPROPERTY_FUNC_T         hal_sec_setStormCtrlProperty;
    HAL_SEC_GETSTORMCTRLPROPERTY_FUNC_T         hal_sec_getStormCtrlProperty;
    HAL_SEC_GETSTORMCTRLCNT_FUNC_T              hal_sec_getStormCtrlCnt;
    HAL_SEC_SETSOURCEGUARDPROPERTY_FUNC_T       hal_sec_setSourceGuardProperty;
    HAL_SEC_GETSOURCEGUARDPROPERTY_FUNC_T       hal_sec_getSourceGuardProperty;
    HAL_SEC_ADDSOURCEGUARDENTRY_FUNC_T          hal_sec_addSourceGuardEntry;
    HAL_SEC_DELSOURCEGUARDENTRY_FUNC_T          hal_sec_delSourceGuardEntry;
    HAL_SEC_GETSOURCEGUARDENTRY_FUNC_T          hal_sec_getSourceGuardEntry;
    HAL_SEC_SETEGRESSPORT_FUNC_T                hal_sec_setEgressPort;
    HAL_SEC_GETEGRESSPORT_FUNC_T                hal_sec_getEgressPort;
} HAL_SEC_FUNC_VEC_T;

typedef struct
{
    HAL_SFLOW_INIT_FUNC_T                       hal_sflow_init;
    HAL_SFLOW_DEINIT_FUNC_T                     hal_sflow_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_sflow_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_sflow_resetPortDefault;
} HAL_SFLOW_FUNC_VEC_T;

typedef struct
{
    HAL_QOS_INIT_FUNC_T                         hal_qos_init;
    HAL_QOS_DEINIT_FUNC_T                       hal_qos_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_qos_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_qos_resetPortDefault;
    HAL_QOS_CREATEPROFILE_FUNC_T                hal_qos_createProfile;
    HAL_QOS_DELPROFILE_FUNC_T                   hal_qos_delProfile;
    HAL_QOS_SETPROFILEENTRY_FUNC_T              hal_qos_setProfileEntry;
    HAL_QOS_GETPROFILEENTRY_FUNC_T              hal_qos_getProfileEntry;
    HAL_QOS_SETCOSQMAPPING_FUNC_T               hal_qos_setCosqMapping;
    HAL_QOS_GETCOSQMAPPING_FUNC_T               hal_qos_getCosqMapping;
} HAL_QOS_FUNC_VEC_T;

typedef struct
{
    HAL_STP_INIT_FUNC_T                         hal_stp_init;
    HAL_STP_DEINIT_FUNC_T                       hal_stp_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_stp_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_stp_resetPortDefault;
    HAL_STP_CREATESTG_FUNC_T                    hal_stp_createStg;
    HAL_STP_DESTROYSTG_FUNC_T                   hal_stp_destroyStg;
    HAL_STP_SETBRIDGEDOMAINSTG_FUNC_T           hal_stp_setBridgeDomainStg;
    HAL_STP_GETBRIDGEDOMAINSTG_FUNC_T           hal_stp_getBridgeDomainStg;
    HAL_STP_SETPORTSTATE_FUNC_T                 hal_stp_setPortstate;
    HAL_STP_GETPORTSTATE_FUNC_T                 hal_stp_getPortstate;
    HAL_STP_ISSTGVALID_FUNC_T                   hal_stp_isStgValid;
} HAL_STP_FUNC_VEC_T;

typedef struct
{
    HAL_SWC_INIT_FUNC_T                         hal_swc_init;
    HAL_SWC_DEINIT_FUNC_T                       hal_swc_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_swc_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_swc_resetPortDefault;
    HAL_SWC_SETPROPERTY                         hal_swc_setProperty;
    HAL_SWC_GETPROPERTY                         hal_swc_getProperty;
    HAL_SWC_GETCHIPTEMPERATURE                  hal_swc_getChipTemperature;
    HAL_SWC_SETHASHKEY                          hal_swc_setHashKey;
    HAL_SWC_GETHASHKEY                          hal_swc_getHashKey;
    HAL_SWC_SETTSVALUE                          hal_swc_setTsValue;
    HAL_SWC_GETTSVALUE                          hal_swc_getTsValue;
    HAL_SWC_SETTSOFFSET                         hal_swc_setTsOffset;
    HAL_SWC_SETSTEERING                         hal_swc_setSteering;
    HAL_SWC_GETSTEERING                         hal_swc_getSteering;
    HAL_SWC_SETHASHCONSTANT                     hal_swc_setHashConstant;
    HAL_SWC_GETHASHCONSTANT                     hal_swc_getHashConstant;
    HAL_SWC_SETHASHCONSTANTBYKEY                hal_swc_setHashConstantByKey;
    HAL_SWC_GETHASHCONSTANTBYKEY                hal_swc_getHashConstantByKey;
    HAL_SWC_REGISTERERRORCALLBACK               hal_swc_registerErrorCallback;
    HAL_SWC_DEREGISTERERRORCALLBACK             hal_swc_deregisterErrorCallback;
    HAL_SWC_GETDEVICEINFO_FUNC_T                hal_swc_getDeviceInfo;
    HAL_SWC_GETPORTCONFIG_FUNC_T                hal_swc_getPortConfig;
    HAL_SWC_GETCAPACITY_FUNC_T                  hal_swc_getCapacity;
    HAL_SWC_GETUSAGE_FUNC_T                     hal_swc_getUsage;
    HAL_SWC_SETCSOMODE_FUNC_T                   hal_swc_setCsoMode;
    HAL_SWC_GETCSOMODE_FUNC_T                   hal_swc_getCsoMode;
    HAL_SWC_SETCPIENCAP_FUNC_T                  hal_swc_setCpiEncap;
    HAL_SWC_GETCPIENCAP_FUNC_T                  hal_swc_getCpiEncap;
    HAL_SWC_SETEXCEPTION_FUNC_T                 hal_swc_setException;
    HAL_SWC_SETTRAPALL_FUNC_T                   hal_swc_setTrapAll;
    HAL_SWC_SETEPGMACHW_FUNC_T                  hal_swc_setEpgMacHw;
    HAL_SWC_SENDEPGMACPKT_FUNC_T                hal_swc_sendEpgMacPkt;
    HAL_SWC_CHKEPGMACDONE_FUNC_T                hal_swc_chkEpgMacDone;
    HAL_SWC_STOPEPGMACPKT_FUNC_T                hal_swc_stopEpgMacPkt;
    HAL_SWC_GETCHIPCFGINFO_T                    hal_swc_getChipCfgInfo;
    HAL_SWC_GETTBLNAME_T                        hal_swc_getTblName;
    HAL_SWC_GETSTRINGNAMEBYID_T                 hal_swc_getStringNameById;
} HAL_SWC_FUNC_VEC_T;

typedef struct
{
    HAL_METER_INIT_FUNC_T                       hal_meter_init;
    HAL_METER_DEINIT_FUNC_T                     hal_meter_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_meter_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_meter_resetPortDefault;
    HAL_METER_CREATEMETER_FUNC_T                hal_meter_createMeter;
    HAL_METER_DESTROYMETER_FUNC_T               hal_meter_destroyMeter;
    HAL_METER_GETMETER_FUNC_T                   hal_meter_getMeter;
    HAL_METER_SETMETERPARAM_FUNC_T              hal_meter_setMeterParam;
    HAL_METER_SETIGRPORTMETER_FUNC_T            hal_meter_setIgrPortMeter;
    HAL_METER_GETIGRPORTMETER_FUNC_T            hal_meter_getIgrPortMeter;
} HAL_METER_FUNC_VEC_T;

typedef struct
{
    HAL_TM_INIT_FUNC_T                          hal_tm_init;
    HAL_TM_DEINIT_FUNC_T                        hal_tm_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_tm_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_tm_resetPortDefault;
    HAL_TM_CREATEHANDLER_FUNC_T                 hal_tm_createHandler;
    HAL_TM_DELETEHANDLER_FUNC_T                 hal_tm_deleteHandler;
    HAL_TM_SETSCHEDULETOPOLOGY_FUNC_T           hal_tm_setScheduleTopology;
    HAL_TM_GETSCHEDULETOPOLOGY_FUNC_T           hal_tm_getScheduleTopology;
    HAL_TM_SCH_SETBANDWIDTH_FUNC_T              hal_tm_setBandwidth;
    HAL_TM_SCH_GETBANDWIDTH_FUNC_T              hal_tm_getBandwidth;
    HAL_TM_SCH_SETSCHEDULEMODE_FUNC_T           hal_tm_setScheduleMode;
    HAL_TM_SCH_GETSCHEDULEMODE_FUNC_T           hal_tm_getScheduleMode;
    HAL_TM_SETTCQUEUEMAPPING_FUNC_T             hal_tm_setTcQueueMapping;
    HAL_TM_GETTCQUEUEMAPPING_FUNC_T             hal_tm_getTcQueueMapping;

    HAL_TM_SETIGRBUFPCPREMAP_FUNC_T             hal_tm_setIgrBufPcpRemap;
    HAL_TM_GETIGRBUFPCPREMAP_FUNC_T             hal_tm_getIgrBufPcpRemap;
    HAL_TM_SETEGRBUFPFCPCPREMAPQUEUE_FUNC_T     hal_tm_setEgrBufPfcPcpRemapQueue;
    HAL_TM_GETEGRBUFPFCPCPREMAPQUEUE_FUNC_T     hal_tm_getEgrBufPfcPcpRemapQueue;
    HAL_TM_SETPROPERTY_FUNC_T                   hal_tm_setProperty;
    HAL_TM_GETPROPERTY_FUNC_T                   hal_tm_getProperty;
    HAL_TM_SETCNGCTRL_FUNC_T                    hal_tm_setCngCtrl;
    HAL_TM_GETCNGCTRL_FUNC_T                    hal_tm_getCngCtrl;
    HAL_TM_CREATEWREDPROFILE_FUNC_T             hal_tm_createWredProfile;
    HAL_TM_DELWREDPROFILE_FUNC_T                hal_tm_delWredProfile;
    HAL_TM_SETWREDPROFILE_FUNC_T                hal_tm_setWredProfile;
    HAL_TM_GETWREDPROFILE_FUNC_T                hal_tm_getWredProfile;
    HAL_TM_SETWREDQUEUECONFIG_FUNC_T            hal_tm_setWredQueueConfig;
    HAL_TM_GETWREDQUEUECONFIG_FUNC_T            hal_tm_getWredQueueConfig;
    HAL_TM_CREATEDCTCPPROFILE_FUNC_T            hal_tm_createDctcpProfile;
    HAL_TM_DELDCTCPPROFILE_FUNC_T               hal_tm_delDctcpProfile;
    HAL_TM_SETDCTCPPROFILE_FUNC_T               hal_tm_setDctcpProfile;
    HAL_TM_GETDCTCPPROFILE_FUNC_T               hal_tm_getDctcpProfile;
    HAL_TM_SETDCTCPQUEUECONFIG_FUNC_T           hal_tm_setDctcpQueueConfig;
    HAL_TM_GETDCTCPQUEUECONFIG_FUNC_T           hal_tm_getDctcpQueueConfig;
    HAL_TM_SETPFCMAPPING_FUNC_T                 hal_tm_setPfcMapping;
    HAL_TM_GETPFCMAPPING_FUNC_T                 hal_tm_getPfcMapping;
    HAL_TM_SETBUFTHRESHOLD_FUNC_T               hal_tm_setBufThreshold;
    HAL_TM_GETBUFTHRESHOLD_FUNC_T               hal_tm_getBufThreshold;
    HAL_TM_GETBUFOCCUPANCY_FUNC_T               hal_tm_getBufOccupancy;
    HAL_TM_GETBUFWATERMARK_FUNC_T               hal_tm_getBufWatermark;
    HAL_TM_CLEARBUFWATERMARK_FUNC_T             hal_tm_clearBufWatermark;
    HAL_TM_GETBUFWATERMARKLIST_FUNC_T           hal_tm_getBufWatermarkList;
    HAL_TM_CLEARBUFWATERMARKLIST_FUNC_T         hal_tm_clearBufWatermarkList;
    HAL_DUMP_DB_FUNC_T                          hal_tm_dumpDb;
    HAL_TM_REGISTERBUFSNAPSHOTCALLBACK_FUNC_T   hal_tm_registerBufSnapshotCallback;
    HAL_TM_DEREGISTERBUFSNAPSHOTCALLBACK_FUNC_T hal_tm_deregisterBufSnapshotCallback;
    HAL_TM_GETPAUSESTATUS_FUNC_T                hal_tm_getPauseStatus;
    HAL_TM_DUMPREG_FUNC_T                       hal_tm_dumpReg;
    HAL_TM_SETQUEUEENABLE_FUNC_T                hal_tm_setQueueEnable;
    HAL_TM_GETQUEUEENABLE_FUNC_T                hal_tm_getQueueEnable;
    HAL_TM_SETPCPPFCMAPPING_FUNC_T              hal_tm_setPcpPfcMapping;
    HAL_TM_GETPCPPFCMAPPING_FUNC_T              hal_tm_getPcpPfcMapping;
    HAL_TM_SETDSCPPFCMAPPING_FUNC_T             hal_tm_setDscpPfcMapping;
    HAL_TM_GETDSCPPFCMAPPING_FUNC_T             hal_tm_getDscpPfcMapping;
    HAL_TM_SETQUEUEPFCPRIMAPPING_FUNC_T         hal_tm_setQueuePfcPriMapping;
    HAL_TM_GETQUEUEPFCPRIMAPPING_FUNC_T         hal_tm_getQueuePfcPriMapping;
    HAL_TM_SETPFCPRIQUEUEMAPPING_FUNC_T         hal_tm_setPfcPriQueueMapping;
    HAL_TM_GETPFCPRIQUEUEMAPPING_FUNC_T         hal_tm_getPfcPriQueueMapping;
    HAL_TM_REGISTERPFCWDCALLBACK_FUNC_T         hal_tm_registerPfcWdCallback;
    HAL_TM_DEREGISTERPFCWDCALLBACK_FUNC_T       hal_tm_deregisterPfcWdCallback;
    HAL_TM_SETPFCWD_FUNC_T                      hal_tm_setPfcWd;
    HAL_TM_GETPFCWD_FUNC_T                      hal_tm_getPfcWd;
    HAL_TM_GETPFCWDSTATE_FUNC_T                 hal_tm_getPfcWdState;
} HAL_TM_FUNC_VEC_T;

typedef struct
{
    HAL_VM_INIT_FUNC_T                          hal_vm_init;
    HAL_VM_DEINIT_FUNC_T                        hal_vm_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_vm_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_vm_resetPortDefault;
    HAL_VM_SETVMMODE_FUNC_T                     hal_vm_setVmMode;
    HAL_VM_GETVMMODE_FUNC_T                     hal_vm_getVmMode;
    HAL_VM_SETUPSTREAMPORT_FUNC_T               hal_vm_setUpstreamPort;
    HAL_VM_GETUPSTREAMPORT_FUNC_T               hal_vm_getUpstreamPort;
    HAL_VM_SETPORTPROPERTY_FUNC_T               hal_vm_setPortProperty;
    HAL_VM_GETPORTPROPERTY_FUNC_T               hal_vm_getPortProperty;
    HAL_VM_PE_ADDUCASTADDR_FUNC_T               hal_vm_pe_addUcastAddr;
    HAL_VM_PE_DELUCASTADDR_FUNC_T               hal_vm_pe_delUcastAddr;
    HAL_VM_PE_GETUCASTADDR_FUNC_T               hal_vm_pe_getUcastAddr;
    HAL_VM_PE_ADDMCASTADDR_FUNC_T               hal_vm_pe_addMcastAddr;
    HAL_VM_PE_DELMCASTADDR_FUNC_T               hal_vm_pe_delMcastAddr;
    HAL_VM_PE_GETMCASTADDR_FUNC_T               hal_vm_pe_getMcastAddr;
    HAL_VM_PE_ADDMCASTMEMBERPORT_FUNC_T         hal_vm_pe_addMcastMemberPort;
    HAL_VM_PE_DELMCASTMEMBERPORT_FUNC_T         hal_vm_pe_delMcastMemberPort;
    HAL_VM_CREATEPORT_FUNC_T                    hal_vm_createPort;
    HAL_VM_DESTROYPORT_FUNC_T                   hal_vm_destroyPort;
    HAL_VM_GETPORT_FUNC_T                       hal_vm_getPort;
    HAL_VM_GETKEY_FUNC_T                        hal_vm_getKey;
    HAL_VM_ADDMCASTINTFPROPERTY_FUNC_T          hal_vm_addMcastIntfProperty;
    HAL_VM_DELMCASTINTFPROPERTY_FUNC_T          hal_vm_delMcastIntfProperty;
    HAL_VM_GETMCASTINTFPROPERTY_FUNC_T          hal_vm_getMcastIntfProperty;
    HAL_VM_ADDMCASTSEGSERVICE_FUNC_T            hal_vm_addMcastSegService;
    HAL_VM_DELMCASTSEGSERVICE_FUNC_T            hal_vm_delMcastSegService;
    HAL_VM_GETMCASTSEGSERVICE_FUNC_T            hal_vm_getMcastSegService;
    HAL_VM_RESETUPSTREAMPORT_FUNC_T             hal_vm_resetUpstreamPort;
    HAL_DUMP_DB_FUNC_T                          hal_vm_dumpDb;
    HAL_DUMP_REG_FUNC_T                         hal_vm_dumpReg;
} HAL_VM_FUNC_VEC_T;

typedef struct
{
    HAL_FCOE_INIT_FUNC_T                        hal_fcoe_init;
    HAL_FCOE_DEINIT_FUNC_T                      hal_fcoe_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_fcoe_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_fcoe_resetPortDefault;
    HAL_FCOE_ADDINTF_FUNC_T                     hal_fcoe_addIntf;
    HAL_FCOE_DELINTF_FUNC_T                     hal_fcoe_delIntf;
    HAL_FCOE_GETINTF_FUNC_T                     hal_fcoe_getIntf;
    HAL_FCOE_ADDHOST_FUNC_T                     hal_fcoe_addHost;
    HAL_FCOE_DELHOST_FUNC_T                     hal_fcoe_delHost;
    HAL_FCOE_GETHOST_FUNC_T                     hal_fcoe_getHost;
    HAL_FCOE_ADDROUTE_FUNC_T                    hal_fcoe_addRoute;
    HAL_FCOE_DELROUTE_FUNC_T                    hal_fcoe_delRoute;
    HAL_FCOE_GETROUTE_FUNC_T                    hal_fcoe_getRoute;
    HAL_FCOE_SETVNTOVNENABLE_FUNC_T             hal_fcoe_setVntovnEnable;
    HAL_FCOE_GETVNTOVNENABLE_FUNC_T             hal_fcoe_getVntovnEnable;
    HAL_FCOE_SETZONECHECK_FUNC_T                hal_fcoe_setZoneCheck;
    HAL_FCOE_GETZONECHECK_FUNC_T                hal_fcoe_getZoneCheck;
    HAL_FCOE_ADDZONE_FUNC_T                     hal_fcoe_addZone;
    HAL_FCOE_DELZONE_FUNC_T                     hal_fcoe_delZone;
    HAL_FCOE_GETZONE_FUNC_T                     hal_fcoe_getZone;
    HAL_FCOE_SETPORTCLVCONFIG_FUNC_T            hal_fcoe_setPortNpvConfig;
    HAL_FCOE_GETPORTCLVCONFIG_FUNC_T            hal_fcoe_getPortNpvConfig;
    HAL_FCOE_SETFRAMETYPEACTION_FUNC_T          hal_fcoe_setFrameTypeAction;
    HAL_FCOE_GETFRAMETYPEACTION_FUNC_T          hal_fcoe_getFrameTypeAction;
    HAL_FCOE_CREATEPORT_FUNC_T                  hal_fcoe_createPort;
    HAL_FCOE_DESTROYPORT_FUNC_T                 hal_fcoe_destroyPort;
    HAL_FCOE_SETPACKETPASER_FUNC_T              hal_fcoe_setPacketParser;
    HAL_FCOE_GETPACKETPASER_FUNC_T              hal_fcoe_getPacketParser;
} HAL_FCOE_FUNC_VEC_T;


typedef struct
{
    HAL_NV_INIT_FUNC_T                          hal_nv_init;
    HAL_NV_DEINIT_FUNC_T                        hal_nv_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_nv_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_nv_resetPortDefault;
    HAL_NV_SETP2PPRUNECONTROL_FUNC_T            hal_nv_setP2pPruneControl;
    HAL_NV_GETP2PPRUNECONTROL_FUNC_T            hal_nv_getP2pPruneControl;
    HAL_NV_SETPAYLAODTYPE_FUNC_T                hal_nv_setPayloadType;
    HAL_NV_GETPAYLAODTYPE_FUNC_T                hal_nv_getPayloadType;
    HAL_NV_SETSPLITHORIZONCHECK_FUNC_T          hal_nv_setSplitHorizonCheck;
    HAL_NV_GETSPLITHORIZONCHECK_FUNC_T          hal_nv_getSplitHorizonCheck;
    HAL_NV_SETP2PSPLITHORIZONCHECK_FUNC_T       hal_nv_setP2pSplitHorizonCheck;
    HAL_NV_GETP2PSPLITHORIZONCHECK_FUNC_T       hal_nv_getP2pSplitHorizonCheck;
    HAL_NV_SETP2PUCASTTUNNELADJ_FUNC_T          hal_nv_setP2pUcastTunnelAdj;
    HAL_NV_DELP2PUCASTTUNNELADJ_FUNC_T          hal_nv_delP2pUcastTunnelAdj;
    HAL_NV_GETP2PUCASTTUNNELADJ_FUNC_T          hal_nv_getP2pUcastTunnelAdj;
    HAL_NV_BINDMCASTTUNNEL_FUNC_T               hal_nv_bindMcastTunnel;
    HAL_NV_UNBINDMCASTTUNNEL_FUNC_T             hal_nv_unbindMcastTunnel;
    HAL_NV_GETMCASTTUNNELBINDING_FUNC_T         hal_nv_getMcastTunnelBinding;
    HAL_NV_ADDNVO3GROUP_FUNC_T                  hal_nv_addNvo3Group;
    HAL_NV_DELNVO3GROUP_FUNC_T                  hal_nv_delNvo3Group;
    HAL_NV_ADDNVO3GROUPEGRINTF_FUNC_T           hal_nv_addNvo3GroupEgrPort;
    HAL_NV_DELNVO3GROUPEGRPORT_FUNC_T           hal_nv_delNvo3GroupEgrPort;
    HAL_NV_GETNVO3GROUPEGRPORTLIST_FUNC_T       hal_nv_getNvo3GroupEgrPortList;
    HAL_NV_GETNVO3GROUPEGRINFO_FUNC_T           hal_nv_getNvo3GroupEgrInfo;
    HAL_NV_VXLAN_ADDVNI_FUNC_T                  hal_nv_vxlan_addVni;
    HAL_NV_VXLAN_DELVNI_FUNC_T                  hal_nv_vxlan_delVni;
    HAL_NV_VXLAN_GETVNI_FUNC_T                  hal_nv_vxlan_getVni;
    HAL_NV_NVGRE_ADDVSID_FUNC_T                 hal_nv_nvgre_addVsid;
    HAL_NV_NVGRE_DELVSID_FUNC_T                 hal_nv_nvgre_delVsid;
    HAL_NV_NVGRE_GETVSID_FUNC_T                 hal_nv_nvgre_getVsid;
    HAL_NV_ADDSEGSERVICE_FUNC_T                 hal_nv_addSegService;
    HAL_NV_DELSEGSERVICE_FUNC_T                 hal_nv_delSegService;
    HAL_NV_GETSEGSERVICE_FUNC_T                 hal_nv_getSegService;
} HAL_NV_FUNC_VEC_T;

typedef struct
{
    HAL_LAG_INIT_FUNC_T                         hal_lag_init;
    HAL_LAG_DEINIT_FUNC_T                       hal_lag_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_lag_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_lag_resetPortDefault;
    HAL_LAG_CREATEPORT_FUNC_T                   hal_lag_createPort;
    HAL_LAG_DESTROYPORT_FUNC_T                  hal_lag_destroyPort;
    HAL_LAG_SETMEMBER_FUNC_T                    hal_lag_setMember;
    HAL_LAG_GETMEMBER_FUNC_T                    hal_lag_getMember;
    HAL_LAG_GETMEMBERCNT_FUNC_T                 hal_lag_getMemberCnt;
    HAL_LAG_TRAVERSEPORT_FUNC_T                 hal_lag_traversePort;
    HAL_LAG_GETRANGE_FUNC_T                     hal_lag_getRange;
    HAL_LAG_GETPORT_FUNC_T                      hal_lag_getPort;
    HAL_LAG_GETKEY_FUNC_T                       hal_lag_getKey;
    HAL_LAG_ADDFDLGROUP_FUNC_T                  hal_lag_addFdlGroup;
    HAL_LAG_GETFDLGROUP_FUNC_T                  hal_lag_getFdlGroup;
    HAL_LAG_DELFDLGROUP_FUNC_T                  hal_lag_delFdlGroup;
    HAL_LAG_SET_ATTR_FUNC_T                     hal_lag_setAttr; 
    HAL_LAG_GET_ATTR_FUNC_T                     hal_lag_getAttr; 
    HAL_LAG_CREATEMGLAG_FUNC_T                  hal_lag_createMglag;
    HAL_LAG_DESTROYMGLAG_FUNC_T                 hal_lag_destroyMglag;
    HAL_LAG_SETMGLAGMBR_FUNC_T                  hal_lag_setMglagMbr;
    HAL_LAG_GETMGLAGMBR_FUNC_T                  hal_lag_getMglagMbr;
    HAL_LAG_GETMGLAGMBRCNT_FUNC_T               hal_lag_getMglagMbrCnt;
    HAL_LAG_SET_WEIGHTMEMBER_FUNC_T             hal_lag_setWeightMember;
    HAL_LAG_GET_WEIGHTMEMBER_FUNC_T             hal_lag_getWeightMember; 
} HAL_LAG_FUNC_VEC_T;

typedef struct
{
    HAL_ACL_INIT_FUNC_T                         hal_acl_init;
    HAL_ACL_DEINIT_FUNC_T                       hal_acl_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_acl_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_acl_resetPortDefault;
    HAL_ACL_ADDGROUP_FUNC_T                     hal_acl_addGroup;
    HAL_ACL_DELGROUP_FUNC_T                     hal_acl_delGroup;
    HAL_ACL_GETGROUP_FUNC_T                     hal_acl_getGroup;
    HAL_ACL_ADDUDFKEYPROFILE_FUNC_T             hal_acl_addUdfKeyProfile;
    HAL_ACL_DELUDFKEYPROFILE_FUNC_T             hal_acl_delUdfKeyProfile;
    HAL_ACL_GETUDFKEYPROFILE_FUNC_T             hal_acl_getUdfKeyProfile;
    HAL_ACL_ADDLOU_FUNC_T                       hal_acl_addLou;
    HAL_ACL_DELLOU_FUNC_T                       hal_acl_delLou;
    HAL_ACL_GETLOU_FUNC_T                       hal_acl_getLou;
    HAL_ACL_ALLOCENTRYID_FUNC_T                 hal_acl_allocEntryId;
    HAL_ACL_FREEENTRYID_FUNC_T                  hal_acl_freeEntryId;
    HAL_ACL_GETENTRYIDINFO_FUNC_T               hal_acl_getEntryIdInfo;
    HAL_ACL_ADDENTRY_FUNC_T                     hal_acl_addEntry;
    HAL_ACL_DELENTRY_FUNC_T                     hal_acl_delEntry;
    HAL_ACL_GETENTRY_FUNC_T                     hal_acl_getEntry;
    HAL_ACL_ADDFLOWENTRY_FUNC_T                 hal_acl_addFlowEntry;
    HAL_ACL_DELFLOWENTRY_FUNC_T                 hal_acl_delFlowEntry;
    HAL_ACL_GETFLOWENTRY_FUNC_T                 hal_acl_getFlowEntry;
    HAL_ACL_TRAVERSEGROUP_FUNC_T                hal_acl_traverseGroup;
    HAL_ACL_TRAVERSEENTRY_FUNC_T                hal_acl_traverseEntry;
    HAL_ACL_TRAVERSEUDFKEYPROFILE_FUNC_T        hal_acl_traverseUdfKeyProfile;
    HAL_ACL_TRAVERSELOU_FUNC_T                  hal_acl_traverseLou;
    HAL_ACL_RIM_ALLOC_FUNC_T                    hal_acl_rim_alloc;
    HAL_ACL_RIM_FREE_FUNC_T                     hal_acl_rim_free;
    HAL_ACL_RIM_SETACTION_FUNC_T                hal_acl_rim_setAction;
    HAL_ACL_RIM_GETACTION_FUNC_T                hal_acl_rim_getAction;
    HAL_ACL_RIM_TRAVERSEACTION_FUNC_T           hal_acl_rim_traverseAction;
}HAL_ACL_FUNC_VEC_T;

/* MPLS multiplexing functions */
typedef struct
{
    HAL_MPLS_INIT_FUNC_T                        hal_mpls_init;
    HAL_MPLS_DEINIT_FUNC_T                      hal_mpls_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_mpls_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_mpls_resetPortDefault;
    HAL_MPLS_CREATEPORT_FUNC_T                  hal_mpls_createPort;
    HAL_MPLS_DESTROYPORT_FUNC_T                 hal_mpls_destroyPort;
    HAL_MPLS_GETPORT_FUNC_T                     hal_mpls_getPort;
    HAL_MPLS_GETKEY_FUNC_T                      hal_mpls_getKey;
    HAL_MPLS_ADDINIT_FUNC_T                     hal_mpls_addInit;
    HAL_MPLS_DELINIT_FUNC_T                     hal_mpls_delInit;
    HAL_MPLS_GETINIT_FUNC_T                     hal_mpls_getInit;
    HAL_MPLS_ADDTERM_FUNC_T                     hal_mpls_addTerm;
    HAL_MPLS_DELTERM_FUNC_T                     hal_mpls_delTerm;
    HAL_MPLS_GETTERM_FUNC_T                     hal_mpls_getTerm;
    HAL_MPLS_ADDTRANSIT_FUNC_T                  hal_mpls_addTransit;
    HAL_MPLS_DELTRANSIT_FUNC_T                  hal_mpls_delTransit;
    HAL_MPLS_GETTRANSIT_FUNC_T                  hal_mpls_getTransit;
    HAL_MPLS_CREATEPWPORT_FUNC_T                hal_mpls_createPwPort;
    HAL_MPLS_DESTROYPWPORT_FUNC_T               hal_mpls_destroyPwPort;
    HAL_MPLS_GETPWPORT_FUNC_T                   hal_mpls_getPwPort;
    HAL_MPLS_GETPWKEY_FUNC_T                    hal_mpls_getPwKey;
    HAL_MPLS_ADDPW_FUNC_T                       hal_mpls_addPw;
    HAL_MPLS_DELPW_FUNC_T                       hal_mpls_delPw;
    HAL_MPLS_GETPW_FUNC_T                       hal_mpls_getPw;
    HAL_MPLS_ADDVPWS_FUNC_T                     hal_mpls_addVpws;
    HAL_MPLS_DELVPWS_FUNC_T                     hal_mpls_delVpws;
    HAL_MPLS_GETVPWS_FUNC_T                     hal_mpls_getVpws;
    HAL_MPLS_SETLABELRANGE_FUNC_T               hal_mpls_setLabelRange;
    HAL_MPLS_GETLABELRANGE_FUNC_T               hal_mpls_getLabelRange;
    HAL_MPLS_TRAVERSEINIT_FUNC_T                hal_mpls_traverseInit;
    HAL_MPLS_TRAVERSETRANSIT_FUNC_T             hal_mpls_traverseTransit;
    HAL_MPLS_TRAVERSETERM_FUNC_T                hal_mpls_traverseTerm;
    HAL_MPLS_TRAVERSEPW_FUNC_T                  hal_mpls_traversePw;
    HAL_DUMP_DB_FUNC_T                          hal_mpls_dumpDb;
} HAL_MPLS_FUNC_VEC_T;

typedef struct
{
    HAL_TRILL_INIT_FUNC_T                       hal_trill_init;
    HAL_TRILL_DEINIT_FUNC_T                     hal_trill_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_trill_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_trill_resetPortDefault;
    HAL_TRILL_SETMYNICKNAME_FUNC_T              hal_trill_setMyNickname;
    HAL_TRILL_GETMYNICKNAME_FUNC_T              hal_trill_getMyNickname;
    HAL_TRILL_SETPKTHANDLING_FUNC_T             hal_trill_setPktHandling;
    HAL_TRILL_GETPKTHANDLING_FUNC_T             hal_trill_getPktHandling;
    HAL_TRILL_CREATEPORT_FUNC_T                 hal_trill_createPort;
    HAL_TRILL_DESTROYPORT_FUNC_T                hal_trill_destroyPort;
    HAL_TRILL_ADDINIT_FUNC_T                    hal_trill_addInit;
    HAL_TRILL_DELINIT_FUNC_T                    hal_trill_delInit;
    HAL_TRILL_GETINIT_FUNC_T                    hal_trill_getInit;
    HAL_TRILL_ADDTERM_FUNC_T                    hal_trill_addTerm;
    HAL_TRILL_DELTERM_FUNC_T                    hal_trill_delTerm;
    HAL_TRILL_GETTERM_FUNC_T                    hal_trill_getTerm;
    HAL_TRILL_ADDSEGSERVICE_FUNC_T              hal_trill_addSegService;
    HAL_TRILL_DELSEGSERVICE_FUNC_T              hal_trill_delSegService;
    HAL_TRILL_GETSEGSERVICE_FUNC_T              hal_trill_getSegService;
    HAL_TRILL_ADDROUTE_FUNC_T                   hal_trill_addRoute;
    HAL_TRILL_DELROUTE_FUNC_T                   hal_trill_delRoute;
    HAL_TRILL_GETROUTE_FUNC_T                   hal_trill_getRoute;
    HAL_TRILL_ADDTREE_FUNC_T                    hal_trill_addTree;
    HAL_TRILL_DELTREE_FUNC_T                    hal_trill_delTree;
    HAL_TRILL_GETTREE_FUNC_T                    hal_trill_getTree;
    HAL_TRILL_ADDADJCHECKENTRY_FUNC_T           hal_trill_addAdjCheckEntry;
    HAL_TRILL_DELADJCHECKENTRY_FUNC_T           hal_trill_delAdjCheckEntry;
    HAL_TRILL_GETADJCHECKENTRY_FUNC_T           hal_trill_getAdjCheckEntry;
    HAL_TRILL_ADDRPFCHECKENTRY_FUNC_T           hal_trill_addRpfCheckEntry;
    HAL_TRILL_DELRPFCHECKENTRY_FUNC_T           hal_trill_delRpfCheckEntry;
    HAL_TRILL_GETRPFCHECKENTRY_FUNC_T           hal_trill_getRpfCheckEntry;
    HAL_TRILL_ADDVIRTUALRB_FUNC_T               hal_trill_addVirtualRb;
    HAL_TRILL_DELVIRTUALRB_FUNC_T               hal_trill_delVirtualRb;
    HAL_TRILL_GETVIRTUALRB_FUNC_T               hal_trill_getVirtualRb;
    HAL_TRILL_SETPORTPROPERTY_FUNC_T            hal_trill_setPortProperty;
    HAL_TRILL_GETPORTPROPERTY_FUNC_T            hal_trill_getPortProperty;
} HAL_TRILL_FUNC_VEC_T;

typedef struct
{
    HAL_SFC_INIT_FUNC_T                         hal_sfc_init;
    HAL_SFC_DEINIT_FUNC_T                       hal_sfc_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_sfc_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_sfc_resetPortDefault;
    HAL_SFC_CREATEPORT_FUNC_T                   hal_sfc_createPort;
    HAL_SFC_DESTROY_FUNC_T                      hal_sfc_destroyPort;
    HAL_SFC_GETPORT_FUNC_T                      hal_sfc_getPort;
    HAL_SFC_GETKEY_FUNC_T                       hal_sfc_getKey;
    HAL_SFC_ADDFORWARDER_FUNC_T                 hal_sfc_addForwarder;
    HAL_SFC_DELFORWARDER_FUNC_T                 hal_sfc_delForwarder;
    HAL_SFC_GETFORWARDER_FUNC_T                 hal_sfc_getForwarder;
} HAL_SFC_FUNC_VEC_T;

typedef struct
{
    HAL_DTEL_INIT_FUNC_T                        hal_dtel_init;
    HAL_DTEL_DEINIT_FUNC_T                      hal_dtel_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_dtel_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_dtel_resetPortDefault;
    HAL_DTEL_SETDPPLOOPBACK_FUNC_T              hal_dtel_setDppLoopback;
    HAL_DTEL_GETDPPLOOPBACK_FUNC_T              hal_dtel_getDppLoopback;
    HAL_DTEL_SETPROFILE_FUNC_T                  hal_dtel_setProfile;
    HAL_DTEL_GETPROFILE_FUNC_T                  hal_dtel_getProfile;
} HAL_DTEL_FUNC_VEC_T;

typedef struct {
    HAL_TELM_INIT_FUNC_T                        hal_telm_init;
    HAL_TELM_DEINIT_FUNC_T                      hal_telm_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_telm_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_telm_resetPortDefault;
    HAL_TELM_SETIFACFG_FUNC_T                   hal_telm_setIfaCfg;
    HAL_TELM_GETIFACFG_FUNC_T                   hal_telm_getIfaCfg;

    HAL_TELM_PREPAREIFATXPKT_FUNC_T             hal_telm_prepareIfaTxPkt;
    HAL_TELM_IFA_DMA_ALLOCRXPKT_FUNC_T          hal_telm_dmaAllocRxPkt;
    HAL_TELM_IFA_DMA_FREEPKT_FUNC_T             hal_telm_dmaFreePkt;
    HAL_TELM_IFA_SENDTASKINIT                   hal_telm_ifaSendTaskInit;
    HAL_TELM_IFA_SENDTASKDEINIT                 hal_telm_ifaSendTaskDeinit;
    HAL_TELM_CFGPKT                             hal_telm_cfgPkt;
    HAL_TELM_DECFGPKT                           hal_telm_deCfgPkt;
} HAL_TELM_FUNC_VEC_T;


typedef struct
{
    HAL_STK_INIT_FUNC_T                         hal_stk_init;
    HAL_STK_DEINIT_FUNC_T                       hal_stk_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_stk_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_stk_resetPortDefault;
    HAL_STK_SETMYCHIPID_FUNC_T                  hal_stk_setMyChipId;
    HAL_STK_GETMYCHIPID_FUNC_T                  hal_stk_getMyChipId;
    HAL_STK_SETNEIGHBORCHIPID_FUNC_T            hal_stk_setNeighborChipId;
    HAL_STK_GETNEIGHBORCHIPID_FUNC_T            hal_stk_getNeighborChipId;
    HAL_STK_SETCUTOFFCHIPID_FUNC_T              hal_stk_setCutOffChipId;
    HAL_STK_GETCUTOFFCHIPID_FUNC_T              hal_stk_getCutOffChipId;
    HAL_STK_ADDSTACKINGPORT_FUNC_T              hal_stk_addStackingPort;
    HAL_STK_DELSTACKINGPORT_FUNC_T              hal_stk_delStackingPort;
    HAL_STK_GETSTACKINGPORT_FUNC_T              hal_stk_getStackingPort;
    HAL_STK_SETPATHTOREMOTECHIP_FUNC_T          hal_stk_setPathToRemoteChip;
    HAL_STK_SETREASONMAPPING_FUNC_T             hal_stk_setReasonMapping;
    HAL_STK_GETREASONMAPPING_FUNC_T             hal_stk_getReasonMapping;
    HAL_STK_ADDSTACKINGPORTTOCPU_FUNC_T         hal_stk_addStackingPortToCpu;
    HAL_STK_DELSTACKINGPORTTOCPU_FUNC_T         hal_stk_delStackingPortToCpu;
    HAL_STK_GETSTACKINGPORTTOCPU_FUNC_T         hal_stk_getStackingPortToCpu;
    HAL_STK_SETCPUPATHTOREMOTECHIP_FUNC_T       hal_stk_setCpuPathToRemoteChip;
    HAL_STK_SETSTACKINGPORTQUEUEMAPPING_FUNC_T  hal_stk_setStackingPortQueueMapping;
    HAL_STK_GETSTACKINGPORTQUEUEMAPPING_FUNC_T  hal_stk_getStackingPortQueueMapping;
    HAL_STK_SETDILENTRY_FUNC_T                  hal_stk_setDilEntry;
    HAL_STK_RESETDILENTRY_FUNC_T                hal_stk_resetDilEntry;
    HAL_STK_GETDILENTRY_FUNC_T                  hal_stk_getDilEntry;
    HAL_STK_GETEXTCHIPDIINFO_FUNC_T             hal_stk_getExtChipDiInfo;
    HAL_STK_GETCHIPMODE_FUNC_T                  hal_stk_getChipMode;
} HAL_STK_FUNC_VEC_T;

typedef struct
{
    HAL_PPPOE_INIT_FUNC_T                       hal_pppoe_init;
    HAL_PPPOE_DEINIT_FUNC_T                     hal_pppoe_deinit;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_pppoe_setPortDefault;
    HAL_DFLT_SETPORTPROPERTY_FUNC_T             hal_pppoe_resetPortDefault;
    HAL_PPPOE_SETSERVERMAC_FUNC_T               hal_pppoe_setServerMac;
    HAL_PPPOE_GETSERVERMAC_FUNC_T               hal_pppoe_getServerMac;
    HAL_PPPOE_ADDSEGSERVICE_FUNC_T              hal_pppoe_addSegService;
    HAL_PPPOE_DELSEGSERVICE_FUNC_T              hal_pppoe_delSegService;
    HAL_PPPOE_GETSEGSERVICE_FUNC_T              hal_pppoe_getSegService;
} HAL_PPPOE_FUNC_VEC_T;

typedef struct
{
    /* MicroP multiplexing functions */
    HAL_UP_FUNC_VEC_T *const                    up_func_vec;

    /* chip multiplexing functions */
    HAL_CHIP_FUNC_VEC_T *const                  chip_func_vec;

    /* ifmap multiplexing functions */

    /* vlan multiplexing functions */
    HAL_VLAN_FUNC_VEC_T *const                  vlan_func_vec;

    /* port multiplexing functions */
    HAL_PORT_FUNC_VEC_T *const                  port_func_vec;

    /* ifmon multiplexing functions */
    HAL_IFMON_FUNC_VEC_T *const                 ifmon_func_vec;

    /* l2 multiplexing functions */
    HAL_L2_FUNC_VEC_T *const                    l2_func_vec;

    /* stp multiplexing functions */
    HAL_STP_FUNC_VEC_T *const                   stp_func_vec;

    /* lag multiplexing functions */
    HAL_LAG_FUNC_VEC_T *const                   lag_func_vec;

    /* mirr multiplexing functions */
    HAL_MIR_FUNC_VEC_T *const                   mir_func_vec;

    /* l3 multiplexing functions */
    HAL_L3_FUNC_VEC_T  *const                   l3_func_vec;

    /* iptun multiplexing functions */
    HAL_L3T_FUNC_VEC_T *const                   l3t_func_vec;

    /* swc multiplexing functions */

    /* qos multiplexing functions */
    HAL_QOS_FUNC_VEC_T *const                   qos_func_vec;
    /* rate multiplexing functions */

    /* meter multiplexing functions */
    HAL_METER_FUNC_VEC_T *const                 meter_func_vec;

    /* pkt multiplexing functions */
    HAL_PKT_FUNC_VEC_T *const                   pkt_func_vec;

    /* acl multiplexing functions */
    HAL_ACL_FUNC_VEC_T *const                   acl_func_vec;

    /* stat multiplexing functions */
    HAL_STAT_FUNC_VEC_T *const                  stat_func_vec;

    /* sec multiplexing functions */
    HAL_SEC_FUNC_VEC_T *const                   sec_func_vec;

    /* sflow multiplexing functions */
    HAL_SFLOW_FUNC_VEC_T *const                 sflow_func_vec;

    /* tm multiplexing functions */
    HAL_TM_FUNC_VEC_T *const                    tm_func_vec;

    /* vm multiplexing functions */
    HAL_VM_FUNC_VEC_T *const                    vm_func_vec;

    /* fcoe multiplexing functions */
    HAL_FCOE_FUNC_VEC_T *const                  fcoe_func_vec;

    /* nv multiplexing functions */
    HAL_NV_FUNC_VEC_T *const                    nv_func_vec;

    /* swtich control multiplexing functions */
    HAL_SWC_FUNC_VEC_T *const                   swc_func_vec;

    /* MPLS multiplexing functions */
    HAL_MPLS_FUNC_VEC_T *const                  mpls_func_vec;

    /* TRILL multiplexing functions */
    HAL_TRILL_FUNC_VEC_T *const                 trill_func_vec;

    /* TRILL multiplexing functions */
    HAL_SFC_FUNC_VEC_T *const                   sfc_func_vec;

    /* Stacking multiplexing functions */
    HAL_STK_FUNC_VEC_T *const                   stk_func_vec;

    /* PPPoE multiplexing functions */
    HAL_PPPOE_FUNC_VEC_T *const                 pppoe_func_vec;

    /* DTEL multiplexing functions */
    HAL_DTEL_FUNC_VEC_T *const                  dtel_func_vec;

    /* TELM multiplexing functions */
    HAL_TELM_FUNC_VEC_T *const                  telm_func_vec;

    /* diag multiplexing functions */

#ifdef CLX_EXTENSION
    /* extension multiplexing functions */
    HAL_EXT_FUNC_VEC_T *const                   ext_func_vec;
#endif

} HAL_FUNC_VEC_T;

typedef enum
{
    HAL_TYPE_INDEX_ALLOC = 0,
    HAL_TYPE_INDEX_SET,
    HAL_TYPE_INDEX_PROFILE,
    HAL_TYPE_INDEX_LAST
} HAL_TYPE_INDEX_T;

typedef enum
{
    HAL_SW_IFP_MULTI_DEST_0_ID = HAL_CIM_SW_TBL_BASE_ID,
    HAL_SW_IFP_MULTI_DEST_1_ID,
    HAL_SW_EFP_NVO3_L3IF_0_ID,
    HAL_SW_EFP_NVO3_L3IF_1_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_0_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_0_NON_PRUNE_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_1_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_1_NON_PRUNE_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_0_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_1_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_2_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_3_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_4_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_5_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_6_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_7_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_8_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_9_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_10_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_11_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_12_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_13_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_14_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_15_ID,
    HAL_SW_TBL_EMI_RSLT_0_ID,
    HAL_SW_TBL_EMI_RSLT_1_ID,
    HAL_SW_TBL_EMI_RSLT_2_ID,
    HAL_SW_TBL_EMI_RSLT_3_ID,
    HAL_SW_TBL_EMI_RSLT_4_ID,
    HAL_SW_TBL_EMI_RSLT_5_ID,
    HAL_SW_TBL_EMI_RSLT_6_ID,
    HAL_SW_TBL_EMI_RSLT_7_ID,
    HAL_SW_TBL_EMI_RSLT_8_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_0_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_1_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_2_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_3_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_4_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_5_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_6_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_7_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_8_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_9_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_10_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_11_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_12_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_13_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_14_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_15_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_16_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_17_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_18_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_19_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_20_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_21_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_22_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_23_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_24_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_25_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_26_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_27_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_28_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_29_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_30_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_31_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_32_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_33_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_34_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_35_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_36_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_37_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_38_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_39_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_40_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_41_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_42_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_43_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_44_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_45_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_46_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_47_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_48_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_49_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_50_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_51_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_52_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_53_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_54_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_55_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_56_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_57_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_58_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_59_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_60_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_61_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_62_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_63_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_64_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_65_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_66_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_67_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_68_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_69_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_70_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_71_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_72_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_73_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_74_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_75_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_76_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_77_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_78_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_79_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_80_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_81_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_82_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_83_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_84_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_85_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_86_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_87_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_88_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_89_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_90_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_91_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_92_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_93_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_94_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_95_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_96_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_97_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_98_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_99_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_100_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_101_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_102_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_103_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_104_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_105_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_106_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_107_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_108_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_109_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_110_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_111_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_112_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_113_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_114_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_115_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_116_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_117_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_118_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_119_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_120_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_121_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_122_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_123_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_124_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_125_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_126_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_127_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_128_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_129_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_130_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_131_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_132_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_133_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_134_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_135_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_136_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_137_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_138_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_139_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_140_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_141_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_142_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_143_ID,
    HAL_SW_TBL_EMI_RSLT_L2_LCL_INTF_ID,
    HAL_SW_TBL_EMI_RSLT_L2_LCL_INTF_DFLT_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_0_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_1_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_2_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_3_ID,
    HAL_SW_TBL_IDS_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_IDS_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_EME_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_EME_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_IEV_FDL_HSH_U_DBL_0_ID,
    HAL_SW_TBL_IEV_FDL_HSH_U_DBL_1_ID,
    HAL_SW_TBL_LAST
} HAL_SW_TBL_T;

typedef struct
{
    HAL_TYPE_INDEX_T    index_type;
    HAL_SW_TBL_T        sw_tbl_id;
    UI32_T              hw_tbl_id;
    UI32_T              base_index;
    UI32_T              length;
    UI32_T              plane_cfg;
    union
    {
        UI32_T          *ptr_bitmap[HAL_MAX_NUM_OF_PLANE];
        UI32_T          *ptr_refcnt[HAL_MAX_NUM_OF_PLANE];
    };
} HAL_ALLOC_ENTRY_T;

typedef struct
{
    HAL_ALLOC_ENTRY_T    *ptr_alloc_tbl;
    UI32_T               entry_num;
} HAL_ALLOC_INFO_T;

typedef struct
{
    I32_T die;
    I32_T bin;
    I32_T plane;
    I32_T hw_mac_macro;
    I32_T tm_mac_macro;
} HAL_ETH_MACRO_MAP_T;

typedef struct
{
    UI32_T              device_id;
    UI32_T              macro_num;
    HAL_ETH_MACRO_MAP_T *ptr_macro_map;
} HAL_ETH_MACRO_INFO_T;

typedef struct
{
    const C8_T              *const driver_desc;         /* driver description */
    HAL_FUNC_VEC_T          *const ptr_func_vector;     /* function vector pointer */
    HAL_INTR_INFO_T         *const ptr_intr_info;       /* INTR information pointer */
    TABLE_INFO_T            **const pptr_tbl_info;      /* chip register/table information */
    PACKING_INFO_T          **const pptr_tbl_key_info;  /* chip table key information for hash */
    TCAM_TBL_META_T         *const ptr_tbl_tcam_info;
    HASH_TBL_META_T         *const ptr_tbl_hash_info;
    HAL_ALLOC_INFO_T        *const ptr_alloc_info;
    HAL_ETH_MACRO_INFO_T    *const ptr_eth_macro_info;  /* all mac macro information of this chip family */
    HAL_ECC_INFO_T          *const ptr_ecc_info;
    HAL_CONST_INFO_T        *const ptr_const_info;
    HAL_CMN_FUNC_VEC_T      *const ptr_cmn_func_vector; /* function vector pointer for HAL common */
    HAL_PKJ_INFO_T          *const ptr_pkj_info;
} HAL_DRIVER_T;

typedef CLX_ERROR_NO_T \
(*HAL_DRIVER_INIT_FUNC_T) (
    const UI32_T revision_id,
    HAL_DRIVER_T **pptr_hal_driver);

typedef struct
{
    UI32_T                 device_id;     /* device ID */
    HAL_DRIVER_INIT_FUNC_T hal_initDriver;/* driver handler function pointer */
} HAL_DEVICE_DRIVER_MAP_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   hal_drv_initDeviceDriver
 * PURPOSE:
 *      hal_drv_initDeviceDriver() is an API that will use device ID and
 *      revision ID to find correct device driver.
 *
 * INPUT:
 *      device_id       -- The device ID of this device. Currently, it will be
 *                         PCIe's device ID.
 *      revision_id     -- The revision ID of this device. Currently, it will
 *                         be PCIe's revision ID.
 * OUTPUT:
 *      pptr_hal_driver -- The pointer (address) of the HAL device driver
 *                         that used for this device with the device_id and
 *                         revision_id.
 * RETURN:
 *      CLX_E_OK        -- Initialize the device driver successfully .
 *      CLX_E_OTHERS    -- Fail to initialize the device driver.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_drv_initDeviceDriver(
    const UI32_T   device_id,
    const UI32_T   revision_id,
    HAL_DRIVER_T   **pptr_hal_driver);

#endif  /* #ifndef HAL_DRV_H */
