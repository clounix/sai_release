/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:   hal_tm_pol.h
 * PURPOSE:
 *      It provide HAL API of PM, IOS and LBM module.
 * NOTES:
 */

#ifndef HAL_TM_POL_H
#define HAL_TM_POL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>


/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_IOS_BUF_TOTAL_SZ                    (8188)
#define HAL_IOS_REQ_UN_ALLOC                    (109)
#define HAL_IOS_OPT_REQ_UN_ALLOC                (1)
#define HAL_IOS_TOTAL_UN_ALLOC                  (HAL_IOS_REQ_UN_ALLOC + HAL_IOS_OPT_REQ_UN_ALLOC)
#define HAL_IOS_ALLOC                           (HAL_IOS_BUF_TOTAL_SZ - HAL_IOS_TOTAL_UN_ALLOC)

#define HAL_IOS_SHARE_TRUNC_HRM                 (136)
#define HAL_IOS_CREDIT_TRUNC_HRM                (34)
#define HAL_IOS_RCP_CREDIT_MAX                  (32)
#define HAL_IOS_LB_CREDIT_MAX                   (128)
#define HAL_IOS_PCIE_CREDIT_MAX                 (32)
#define HAL_IOS_CP_HRM_MAX                      (1416)
#define HAL_IOS_PFC_HRM_MAX                     (3072)
#define HAL_IOS_FP_MIN_THR                      (16)

#define HAL_IOS_LOSSY_TRUNC_ON_THR              (HAL_IOS_ALLOC - \
                                                        HAL_IOS_SHARE_TRUNC_HRM  - \
                                                        HAL_IOS_CREDIT_TRUNC_HRM - \
                                                        HAL_IOS_RCP_CREDIT_MAX - \
                                                        HAL_IOS_LB_CREDIT_MAX - \
                                                        HAL_IOS_PCIE_CREDIT_MAX - \
                                                        HAL_IOS_CP_HRM_MAX - \
                                                        HAL_IOS_PFC_HRM_MAX - \
                                                        HAL_IOS_FP_MIN_THR)

#define HAL_IOS_LOSSY_TRUNC_GAP                 (157)
#define HAL_IOS_LOSSY_DROP_ON_THR               (HAL_IOS_LOSSY_TRUNC_ON_THR - HAL_IOS_LOSSY_TRUNC_GAP)
#define HAL_IOS_LOSSY_DROP_GAP                  (317)
#define HAL_IOS_LOSSY_DROP_OFF_THR              (HAL_IOS_LOSSY_DROP_ON_THR - HAL_IOS_LOSSY_DROP_GAP)

#define HAL_IOS_FCOS_TRUNC_ON_THR               (8191)
#define HAL_IOS_FCOS_DROP_ON_THR                (8191)
#define HAL_IOS_FCOS_DROP_OFF_THR               (8191)

#define HAL_IOS_FP_DROP_ON_THR                  (1478)
#define HAL_IOS_FP_DROP_GAP                     (97)
#define HAL_IOS_FP_DROP_OFF_THR                 (HAL_IOS_FP_DROP_ON_THR - HAL_IOS_FP_DROP_GAP)

#define HAL_IOS_GB_HI_GAP                       (337)
#define HAL_IOS_FP_HI_GAP                       (227)
#define HAL_IOS_FP_COS_GAP                      (127)


#define HAL_IOS_GB_HI2_XOFF_THR                 (2915)
#define HAL_IOS_GB_HI2_XON_THR                  (HAL_IOS_GB_HI2_XOFF_THR - HAL_IOS_GB_HI_GAP)
#define HAL_IOS_FP_HI2_XOFF_THR                 (1536)
#define HAL_IOS_FP_HI2_XON_THR                  (HAL_IOS_FP_HI2_XOFF_THR - HAL_IOS_FP_HI_GAP)
#define HAL_IOS_FP_COS_HI2_XOFF_THR             (512)
#define HAL_IOS_FP_COS_HI2_XON_THR              (HAL_IOS_FP_COS_HI2_XOFF_THR - HAL_IOS_FP_COS_GAP)

#define HAL_IOS_GB_HI1_XOFF_THR                 (2403)
#define HAL_IOS_GB_HI1_XON_THR                  (HAL_IOS_GB_HI1_XOFF_THR - HAL_IOS_GB_HI_GAP)
#define HAL_IOS_FP_HI1_XOFF_THR                 (1024)
#define HAL_IOS_FP_HI1_XON_THR                  (HAL_IOS_FP_HI1_XOFF_THR - HAL_IOS_FP_HI_GAP)
#define HAL_IOS_FP_COS_HI1_XOFF_THR             (512)
#define HAL_IOS_FP_COS_HI1_XON_THR              (HAL_IOS_FP_COS_HI1_XOFF_THR - HAL_IOS_FP_COS_GAP)

#define HAL_IOS_FP_EN                           (0x1ffff)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TM_POL_LOCK(unit)           hal_tm_pol_lockResource(unit)
#define HAL_TM_POL_UNLOCK(unit)         hal_tm_pol_unlockResource(unit)
#define HAL_TM_POL_CTL                  (0x3)
#define HAL_TM_POL_HI_2                 (0x2)
#define HAL_TM_POL_HI_1                 (0x1)
#define HAL_TM_POL_LOW                  (0x0)


/* DATA TYPE DECLARATIONS
 */
/*control block for pol module*/
typedef struct HAL_TM_POL_CB_S
{
    CLX_SEMAPHORE_ID_T    pol_sema; /*semaphore for pol module*/
}HAL_TM_POL_CB_T;

typedef enum
{
    HAL_TM_IOS_COS_MAP_PCP_ACTION_ADD,
    HAL_TM_IOS_COS_MAP_PCP_ACTION_UPDATE,
    HAL_TM_IOS_COS_MAP_PCP_ACTION_DELETE,
    HAL_TM_IOS_COS_MAP_PCP_ACTION_CLEAR_ALL,
    HAL_TM_IOS_COS_MAP_PCP_ACTION_LAST
}HAL_TM_IOS_COS_MAP_PCP_ACTION_T;

typedef enum
{
    HAL_TM_EPM_PROPERTY_FLUSH,
    HAL_TM_EPM_PROPERTY_CREDIT_RST,
    HAL_TM_EPM_PROPERTY_LAST
}HAL_TM_EPM_PROPERTY_T;

CLX_ERROR_NO_T
hal_tm_pol_lockResource (
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_tm_pol_unlockResource (
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_tm_pol_initRsrc(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_pol_deinitRsrc(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_pol_deinitCfg(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_getPolCtrlBlock(
    const UI32_T                    unit,
    HAL_TM_POL_CB_T                 **pptr_cb);

#endif  /* #ifndef HAL_TM_POL_H */

