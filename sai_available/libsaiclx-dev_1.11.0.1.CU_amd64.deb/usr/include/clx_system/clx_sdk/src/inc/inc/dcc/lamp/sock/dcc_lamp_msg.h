/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME: dcc_lamp_msg.h
 * PURPOSE:
 *  1. Provide the interface for socket communication
 *
 * NOTES:
 *
 */
#ifndef DCC_LAMP_MSG_H
#define DCC_LAMP_MSG_H

/* INCLUDE DECLARATIONS
*/
#include <clx_types.h>
#include <clx_error.h>
#include <semaphore.h>
#if !defined (DCC_LAMP_SVR)
#include <api/diag.h>
#include <dcc/dcc.h>
#include <hal/common/hal_dbg.h>
#endif

/* NAMING CONSTANT DECLARATIONS
*/
#define DCC_LAMP_MSG_HDR_SIZE   (sizeof(DCC_LAMP_MSG_HDR_T))

/* MACRO FUNCTION DECLARATIONS
 */
#if defined (DCC_LAMP_SVR)
#define DCC_LAMP_MSG_DBG(__ptr_fmt__, __args__...) \
    fprintf(stderr, "[%s:%d] "__ptr_fmt__, __FILE__, __LINE__, ##__args__)

#define DCC_LAMP_MSG_MALLOC(__data_len__) \
    malloc((__data_len__))

#define DCC_LAMP_MSG_MEMSET(__ptr_data__, __init_val__, __data_len__) \
    memset((__ptr_data__), (__init_val__), (__data_len__))

#define DCC_LAMP_MSG_MEMCPY(__ptr_dst_buf__, __ptr_src_buf__, __data_len__) \
    memcpy((__ptr_dst_buf__), (__ptr_src_buf__), (__data_len__))

#define DCC_LAMP_MSG_FREE(__ptr_data__) \
    free((__ptr_data__))
#else
#define DCC_LAMP_MSG_DBG(__ptr_fmt__, __args__...) \
    DIAG_PRINT(\
               HAL_DBG_DCC_IO | HAL_DBG_DCC_DMA | HAL_DBG_DCC_CLD, \
               __ptr_fmt__, ##__args__)

#define DCC_LAMP_MSG_MALLOC(__data_len__) \
    osal_alloc((__data_len__))

#define DCC_LAMP_MSG_MEMSET(__ptr_data__, __init_val__, __data_len__) \
    osal_memset((__ptr_data__), (__init_val__), (__data_len__))

#define DCC_LAMP_MSG_MEMCPY(__ptr_dst_buf__, __ptr_src_buf__, __data_len__) \
    osal_memcpy((__ptr_dst_buf__), (__ptr_src_buf__), (__data_len__))

#define DCC_LAMP_MSG_FREE(__ptr_data__) \
    osal_free((__ptr_data__))
#endif

#define DCC_LAMP_MSG_PACK_MSG(__ptr_msg__, \
                              __unit__, \
                              __chn_type__, \
                              __msg_type__, \
                              __msg_len__, \
                              __msg_sn__, \
                              __src_dev_addr__,\
                              __dst_dev_addr__, \
                              __plane__, \
                              __direct__, \
                              __dbeat__, \
                              __doffs__, \
                              __data_len__, \
                              __ptr_data__) \
    do { \
        (__ptr_msg__) = DCC_LAMP_MSG_MALLOC(DCC_LAMP_MSG_HDR_SIZE + (__msg_len__)); \
        if ((__ptr_msg__) != NULL) { \
            const void  *__ptr_buf__ = (__ptr_data__); \
            DCC_LAMP_MSG_MEMSET((__ptr_msg__), 0x0, DCC_LAMP_MSG_HDR_SIZE + (__msg_len__)); \
            (__ptr_msg__)->unit = (__unit__); \
            (__ptr_msg__)->chn_type = (__chn_type__); \
            (__ptr_msg__)->msg_type = (__msg_type__); \
            (__ptr_msg__)->msg_len = (__msg_len__); \
            (__ptr_msg__)->msg_sn = (__msg_sn__); \
            (__ptr_msg__)->src_dev_addr = (__src_dev_addr__); \
            (__ptr_msg__)->dst_dev_addr = (__dst_dev_addr__); \
            (__ptr_msg__)->plane = (__plane__); \
            (__ptr_msg__)->direct = (__direct__); \
            (__ptr_msg__)->dbeat = (__dbeat__); \
            (__ptr_msg__)->doffs = (__doffs__); \
            (__ptr_msg__)->data_len = (__data_len__); \
            if ((__msg_len__) > 0) { \
                DCC_LAMP_MSG_MEMCPY((__ptr_msg__)->ptr_data, (__ptr_buf__), (__msg_len__)); \
            } \
        } \
    } while (0)

#define DCC_LAMP_MSG_IS_RB_FULL(__ptr_rb__) \
    ((((__ptr_rb__)->end + 1) % (__ptr_rb__)->size) == (__ptr_rb__)->start)

#define DCC_LAMP_MSG_IS_RB_EMPTY(__ptr_rb__) \
    ((__ptr_rb__)->end == (__ptr_rb__)->start)

/* DATA TYPE DECLARATIONS
 */
typedef struct
{
    UI32_T      unit        : 16;
    UI32_T      chn_type    :  8;
    UI32_T      msg_type    :  8;
    UI32_T      msg_len;
    UI32_T      msg_sn;
    UI32_T      src_dev_addr;
    UI32_T      dst_dev_addr;
    UI32_T      dbeat       : 16;
    UI32_T      doffs       : 16;
    UI32_T      plane       : 16;
    UI32_T      direct      : 16;
    UI32_T      data_len;
    UI8_T       ptr_data[];
} DCC_LAMP_MSG_HDR_T;

typedef enum
{
    DCC_LAMP_MSG_CHN_TYPE_IO = 0,
    DCC_LAMP_MSG_CHN_TYPE_TDMA_H2D,
    DCC_LAMP_MSG_CHN_TYPE_TDMA_D2H,
    DCC_LAMP_MSG_CHN_TYPE_TDMA_D2D,
    DCC_LAMP_MSG_CHN_TYPE_SDMA,
    DCC_LAMP_MSG_CHN_TYPE_PDMA,
    DCC_LAMP_MSG_CHN_TYPE_L2FIFO,
    DCC_LAMP_MSG_CHN_TYPE_TSFIFO,
    DCC_LAMP_MSG_CHN_TYPE_CTL,
    DCC_LAMP_MSG_CHN_TYPE_LAST
} DCC_LAMP_MSG_CHN_TYPE_T;

typedef enum
{
    DCC_LAMP_MSG_MSG_TYPE_REG = 0,
    DCC_LAMP_MSG_MSG_TYPE_READ,
    DCC_LAMP_MSG_MSG_TYPE_WRITE,
    DCC_LAMP_MSG_MSG_TYPE_HASH,
    DCC_LAMP_MSG_MSG_TYPE_COPY,
    DCC_LAMP_MSG_MSG_TYPE_PKTIN,
    DCC_LAMP_MSG_MSG_TYPE_PKTOUT,
    DCC_LAMP_MSG_MSG_TYPE_L2IN,
    DCC_LAMP_MSG_MSG_TYPE_TSIN,
    DCC_LAMP_MSG_MSG_TYPE_RST,
    DCC_LAMP_MSG_MSG_TYPE_RUN,
    DCC_LAMP_MSG_MSG_TYPE_ERR,
    DCC_LAMP_MSG_MSG_TYPE_LAST
} DCC_LAMP_MSG_MSG_TYPE_T;

typedef struct
{
    DCC_LAMP_MSG_HDR_T      *ptr_msg;
} DCC_LAMP_MSG_RB_ENTRY_T;

typedef struct
{
    UI32_T                      size;
    UI32_T                      start;
    UI32_T                      end;
    sem_t                       sema;
    DCC_LAMP_MSG_RB_ENTRY_T     *ptr_elem_list;
} DCC_LAMP_MSG_RING_BUFFER_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: dcc_lamp_msg_readMsg
 * PURPOSE:
 *  1. Receive the message from the socket
 *
 * INPUT:
 *  sock                    -- the socket to read
 *
 * OUTPUT:
 *  pptr_msg                -- the pointer to read message
 *
 * RETURN:
 *  CLX_E_OK                -- operate successfully
 *  CLX_E_BAD_PARAMETER     -- fail due to bad parameter
 *  CLX_E_NO_MEMORY         -- fail due to no memory
 *  CLX_E_OTHERS            -- fail due to internal error
 *
 * NOTES:
 *  None
 */
CLX_ERROR_NO_T
dcc_lamp_msg_readMsg(
    const UI32_T        sock,
    DCC_LAMP_MSG_HDR_T  **pptr_msg);

/* FUNCTION NAME: dcc_lamp_msg_writeMsg
 * PURPOSE:
 *  1. Send the message to the socket
 *
 * INPUT:
 *  sock                    -- the socket to write
 *  pptr_msg                -- the pointer to written message
 *
 * OUTPUT:
 *  None
 *
 * RETURN:
 *  CLX_E_OK                -- operate successfully
 *  CLX_E_BAD_PARAMETER     -- fail due to bad parameter
 *  CLX_E_OTHERS            -- fail due to internal error
 *
 * NOTES:
 *  None
 */
CLX_ERROR_NO_T
dcc_lamp_msg_writeMsg(
    const UI32_T                sock,
    const DCC_LAMP_MSG_HDR_T    *ptr_msg);

/* FUNCTION NAME: dcc_lamp_msg_initRb
 * PURPOSE:
 *  1. Init the ring buffer
 *
 * INPUT:
 *  size                    -- the size of the ring buffer
 *
 * OUTPUT:
 *  ptr_rb                  -- the pointer to the ring buffer
 *
 * RETURN:
 *  CLX_E_OK                -- operate successfully
 *  CLX_E_BAD_PARAMETER     -- fail due to bad parameter
 *  CLX_E_NO_MEMORY         -- fail due to no memory
 *
 * NOTES:
 *  None
 */
CLX_ERROR_NO_T
dcc_lamp_msg_initRb(
    DCC_LAMP_MSG_RING_BUFFER_T  *ptr_rb,
    const UI32_T                size);

/* FUNCTION NAME: dcc_lamp_deinitRb
 * PURPOSE:
 *  1. Deinit the ring buffer
 *
 * INPUT:
 *  ptr_rb                  -- the pointer to the ring buffer
 *
 * OUTPUT:
 *  None
 *
 * RETURN:
 *  CLX_E_OK                -- operate successfully
 *  CLX_E_BAD_PARAMETER     -- fail due to bad parameter
 *
 * NOTES:
 *  None
 */
CLX_ERROR_NO_T
dcc_lamp_msg_deinitRb(
    DCC_LAMP_MSG_RING_BUFFER_T  *ptr_rb);

/* FUNCTION NAME: dcc_lamp_msg_writeRb
 * PURPOSE:
 *  1. Write the message into the ring buffer
 *
 * INPUT:
 *  ptr_rb                  -- the pointer to the ring buffer
 *  ptr_elem                -- the pointer to the element to be written
 *
 * OUTPUT:
 *  None
 *
 * RETURN:
 *  CLX_E_OK                -- operate successfully
 *  CLX_E_BAD_PARAMETER     -- fail due to bad parameter
 *  CLX_E_OTHERS            -- fail due to internal error
 *
 * NOTES:
 *  None
 */
CLX_ERROR_NO_T
dcc_lamp_msg_writeRb(
    DCC_LAMP_MSG_RING_BUFFER_T      *ptr_rb,
    const DCC_LAMP_MSG_RB_ENTRY_T   *ptr_elem);

/* FUNCTION NAME: dcc_lamp_msg_readRb
 * PURPOSE:
 *  1. Read the message from the ring buffer
 *
 * INPUT:
 *  ptr_rb                  -- the pointer to the ring buffer
 *
 * OUTPUT:
 *  ptr_elem                -- the pointer to the element to be written
 *
 * RETURN:
 *  CLX_E_OK                -- operate successfully
 *  CLX_E_BAD_PARAMETER     -- fail due to bad parameter
 *  CLX_E_OTHERS            -- fail due to internal error
 *
 * NOTES:
 *  None
 */
CLX_ERROR_NO_T
dcc_lamp_msg_readRb(
    DCC_LAMP_MSG_RING_BUFFER_T  *ptr_rb,
    DCC_LAMP_MSG_RB_ENTRY_T     *ptr_elem);

/* FUNCTION NAME: dcc_lamp_msg_clearRb
 * PURPOSE:
 *  1. Clear the messages from the ring buffer
 *
 * INPUT:
 *  ptr_rb                  -- the pointer to the ring buffer
 *
 * OUTPUT:
 *  None
 *
 * RETURN:
 *  CLX_E_OK                -- operate successfully
 *  CLX_E_BAD_PARAMETER     -- fail due to bad parameter
 *  CLX_E_OTHERS            -- fail due to internal error
 *
 * NOTES:
 *  None
 */
CLX_ERROR_NO_T
dcc_lamp_msg_clearRb(
    DCC_LAMP_MSG_RING_BUFFER_T  *ptr_rb);

#endif
