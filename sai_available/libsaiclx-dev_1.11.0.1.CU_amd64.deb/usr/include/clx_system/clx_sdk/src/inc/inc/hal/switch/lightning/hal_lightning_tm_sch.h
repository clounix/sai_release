/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_tm_sch.h
 * PURPOSE:
 *      It provides hal tm SCH module schedule block API.
 * NOTES:
 *
 *
 */

#ifndef HAL_LIGHTNING_TM_SCH_H
#define HAL_LIGHTNING_TM_SCH_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_tm.h>
#include <hal/switch/lightning/hal_lightning_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_LIGHTNING_TM_SCH_LEVEL_MAX         (2)
#define HAL_LIGHTNING_TM_SCH_NODE_NUM_OF_LVL0  (1)
#define HAL_LIGHTNING_TM_SCH_NODE_NUM_OF_LVL1  (8)

#define HAL_LIGHTNING_TM_SCH_NODE_NUM          (9)

/*chip support 9 schedule node and lv0 node is reserve by sdk but not
directly operato by user*/
#define HAL_LIGHTNING_TM_SCH_NODE_RESERVE_NUM  (1)

#define HAL_LIGHTNING_TM_SCH_LV1_NODE_BITMAP_SIZE \
        (((HAL_LIGHTNING_TM_SCH_NODE_NUM - 1) / 8) + 1)

/*each lvl0 node has at most 9 childrens*/
#define HAL_LIGHTNING_TM_SCH_CHILD_NUM_PER_LV0     (9)
/*each lvl1 node has at most 8 lvl1 childrens*/
#define HAL_LIGHTNING_TM_SCH_CHILD_NUM_PER_LV1     (8)
/*each lvl2 node has at most 2 lvl2 childrens*/
#define HAL_LIGHTNING_TM_SCH_CHILD_NUM_PER_LV2     (2)

/*dwrr weight max*/
#define HAL_LIGHTNING_TM_DWRR_WEIGHT_MAX   (127)

/*bandwidth rate in user-view is kbps unit*/
#define HAL_LIGHTNING_TM_FRONT_PORT_BUCKET_RATE_USER_UNIT (1000)

/*1 byte is 8 bit*/
#define HAL_LIGHTNING_TM_ONE_BYTE_BIT_LENGTH   (8)

/*port max speed 400G that is 402653184(kbps) in shapers*/
#define HAL_LIGHTNING_TM_PORT_SPEED_MAX   (402653184)

/*front port's bucket rate's granularity 256kbps*/
#define HAL_LIGHTNING_TM_FRONT_PORT_BUCKET_RATE_GRANULARITY    (256)

/*front port's bucket size's granularity 64byte*/
#define HAL_LIGHTNING_TM_FRONT_PORT_BUCKET_SIZE_GRANULARITY    (64)

/*front port's min shaping rate 256k bps*/
#define HAL_LIGHTNING_TM_SCH_FRONT_PORT_SHAPE_MIN              (256)

/*max bucket size, 64M bytes*/
#define HAL_LIGHTNING_TM_SCH_BURST_SIZE_LIMIT           (64000000)

/*front port's bucket rate bitwidth in hardware*/
#define HAL_LIGHTNING_TM_FRONT_PORT_BUCKET_RATE_MANTISSA_WIDTH (4)
#define HAL_LIGHTNING_TM_FRONT_PORT_BUCKET_RATE_EXPONENT_WIDTH (11)

/*front port's bucket size bitwidth in hardware*/
#define HAL_LIGHTNING_TM_FRONT_PORT_BUCKET_SIZE_MANTISSA_WIDTH (4)
#define HAL_LIGHTNING_TM_FRONT_PORT_BUCKET_SIZE_EXPONENT_WIDTH (11)

/*cpu port's bucket rate's granularity 64pps*/
#define HAL_LIGHTNING_TM_CPU_PORT_BUCKET_RATE_GRANULARITY  (64)

/*cpu port's min shaping rate 64 pps*/
#define HAL_LIGHTNING_TM_SCH_CPU_PORT_SHAPE_MIN         (64)

/*cpu port's bucket size's granularity packet*/
#define HAL_LIGHTNING_TM_CPU_PORT_BUCKET_SIZE_GRANULARITY  (1)

/*cpu port's bucket rate bitwidth in hardware*/
#define HAL_LIGHTNING_TM_CPU_PORT_BUCKET_RATE_WIDTH    (21)

/*cpu port's bucket size bitwidth in hardware*/
#define HAL_LIGHTNING_TM_CPU_PORT_BUCKET_SIZE_WIDTH    (13)


/*cpi port's bucket rate's granularity 64pps*/
#define HAL_LIGHTNING_TM_CPI_PORT_BUCKET_RATE_GRANULARITY  (64)

/*cpi port's bucket size's granularity packet*/
#define HAL_LIGHTNING_TM_CPI_PORT_BUCKET_SIZE_GRANULARITY  (1)

/*cpi port's bucket rate bitwidth in hardware*/
#define HAL_LIGHTNING_TM_CPI_PORT_BUCKET_RATE_WIDTH    (21)

/*cpi port's bucket size bitwidth in hardware*/
#define HAL_LIGHTNING_TM_CPI_PORT_BUCKET_SIZE_WIDTH    (13)

#define HAL_LIGHTNING_TM_SCH_HW_MAX_RATE                  (0x7fff)
#define HAL_LIGHTNING_TM_SCH_HW_MAX_BUCKET_SIZE           (0x7a29)

/*default value of register FP_DWRR_EN. Notice its 4 bits which represent
 *the bit value of {SP_MIN_LIST, MIN_LIST, SP_MAX_LIST, MAX_LIST}
 */
#define HAL_LIGHTNING_TM_SCH_FP_DWRR_EN_DEF (0x5)

#define HAL_LIGHTNING_TM_SCH_BANDWIDTH_FIELD_VALID    (1U << 0)
#define HAL_LIGHTNING_TM_SCH_WEIGHT_FIELD_VALID       (1U << 1)

#define HAL_LIGHTNING_TM_SCH_TOPOLOTY_FIELD_VALID     (1U << 0)
#define HAL_LIGHTNING_TM_SCH_SP_FIELD_VALID           (1U << 1)
#define HAL_LIGHTNING_TM_SCH_DWRR_EN_FIELD_VALID      (1U << 2)
#define HAL_LIGHTNING_TM_SCH_DWRR_INTR_EN_FIELD_VALID (1U << 3)
#define HAL_LIGHTNING_TM_SCH_SP_SEQ_FIELD_VALID       (1U << 4)

#define HAL_LIGHTNING_TM_SCH_N0 (0)
#define HAL_LIGHTNING_TM_SCH_N1 (1)
#define HAL_LIGHTNING_TM_SCH_N2 (2)
#define HAL_LIGHTNING_TM_SCH_N3 (3)
#define HAL_LIGHTNING_TM_SCH_N4 (4)
#define HAL_LIGHTNING_TM_SCH_N5 (5)
#define HAL_LIGHTNING_TM_SCH_N6 (6)
#define HAL_LIGHTNING_TM_SCH_N7 (7)
#define HAL_LIGHTNING_TM_SCH_N8 (8)

#define HAL_LIGHTNING_TM_SCH_MC0 (0)
#define HAL_LIGHTNING_TM_SCH_MC1 (1)
#define HAL_LIGHTNING_TM_SCH_MC2 (2)
#define HAL_LIGHTNING_TM_SCH_MC3 (3)
#define HAL_LIGHTNING_TM_SCH_MC4 (4)
#define HAL_LIGHTNING_TM_SCH_MC5 (5)
#define HAL_LIGHTNING_TM_SCH_MC6 (6)
#define HAL_LIGHTNING_TM_SCH_MC7 (7)

#define HAL_LIGHTNING_TM_SCH_UC0 (0)
#define HAL_LIGHTNING_TM_SCH_UC1 (1)
#define HAL_LIGHTNING_TM_SCH_UC2 (2)
#define HAL_LIGHTNING_TM_SCH_UC3 (3)
#define HAL_LIGHTNING_TM_SCH_UC4 (4)
#define HAL_LIGHTNING_TM_SCH_UC5 (5)
#define HAL_LIGHTNING_TM_SCH_UC6 (6)
#define HAL_LIGHTNING_TM_SCH_UC7 (7)

#define HAL_LIGHTNING_TM_SCH_N_ROOT (HAL_LIGHTNING_TM_SCH_N8)

#define HAL_LIGHTNING_TM_SCH_LV0 (0)
#define HAL_LIGHTNING_TM_SCH_LV1 (1)
#define HAL_LIGHTNING_TM_SCH_LV2 (2)

#define HAL_LIGHTNING_TM_SCH_LEAF0 (0)
#define HAL_LIGHTNING_TM_SCH_LEAF1 (1)
#define HAL_LIGHTNING_TM_SCH_LEAF2 (2)
#define HAL_LIGHTNING_TM_SCH_LEAF3 (3)
#define HAL_LIGHTNING_TM_SCH_LEAF4 (4)
#define HAL_LIGHTNING_TM_SCH_LEAF5 (5)
#define HAL_LIGHTNING_TM_SCH_LEAF6 (6)
#define HAL_LIGHTNING_TM_SCH_LEAF7 (7)
#define HAL_LIGHTNING_TM_SCH_LEAF8 (8)


/* MACRO FUNCTION DECLARATIONS
 */
/* DATA TYPE DECLARATIONS
 */

typedef enum
{
    HAL_LIGHTNING_TM_SCH_MINBW_DWRR_COMBINE_MODE_SEPARATE = 0,/*minBW is not counted by dwrr weight*/
    HAL_LIGHTNING_TM_SCH_MINBW_DWRR_COMBINE_MODE_SHARE,/*minBW is counted by dwrr*/
    HAL_LIGHTNING_TM_SCH_MINBW_DWRR_COMBINE_MODE_LAST
}HAL_LIGHTNING_TM_SCH_MINBW_DWRR_COMBINE_MODE_T;

typedef struct HAL_LIGHTNING_TM_FP_TPLGY_CONFIG_ENTRY_S
{
    /*tplgy bitmap for node 0*/
    UI32_T fp_tplgy_lv1_n0   ;
    /*tplgy bitmap for node 1*/
    UI32_T fp_tplgy_lv1_n1   ;
    /*tplgy bitmap for node 2*/
    UI32_T fp_tplgy_lv1_n2   ;
    /*tplgy bitmap for node 3*/
    UI32_T fp_tplgy_lv1_n3   ;
    /*tplgy bitmap for node 4*/
    UI32_T fp_tplgy_lv1_n4   ;
    /*tplgy bitmap for node 5*/
    UI32_T fp_tplgy_lv1_n5   ;
    /*tplgy bitmap for node 6*/
    UI32_T fp_tplgy_lv1_n6   ;
    /*tplgy bitmap for node 7*/
    UI32_T fp_tplgy_lv1_n7   ;
    /*tplgy bitmap for node 8*/
    UI32_T fp_tplgy_lv0_n8   ;
}HAL_LIGHTNING_TM_FP_TPLGY_CONFIG_ENTRY_T;

typedef struct HAL_LIGHTNING_TM_SP_SEQUENCE_CONFIG_ENTRY_S
{
    UI32_T sp_sequence[18][2]       ;
}HAL_LIGHTNING_TM_SP_SEQUENCE_CONFIG_ENTRY_T;


/*table lv1_config*/
typedef struct HAL_LIGHTNING_TM_SCH_LV1_CONFIG_ENTRY_S
{
    UI32_T  mcq0_dwrr_weight   ;
    UI32_T  mcq0_bsize_max     ;
    UI32_T  mcq0_shape_max     ;
    UI32_T  mcq0_shape_min     ;

    UI32_T  mcq1_dwrr_weight   ;
    UI32_T  mcq1_bsize_max     ;
    UI32_T  mcq1_shape_max     ;
    UI32_T  mcq1_shape_min     ;

    UI32_T  mcq2_dwrr_weight   ;
    UI32_T  mcq2_bsize_max     ;
    UI32_T  mcq2_shape_max     ;
    UI32_T  mcq2_shape_min     ;

    UI32_T  mcq3_dwrr_weight   ;
    UI32_T  mcq3_bsize_max     ;
    UI32_T  mcq3_shape_max     ;
    UI32_T  mcq3_shape_min     ;

    UI32_T  mcq4_dwrr_weight   ;
    UI32_T  mcq4_bsize_max     ;
    UI32_T  mcq4_shape_max     ;
    UI32_T  mcq4_shape_min     ;

    UI32_T  mcq5_dwrr_weight   ;
    UI32_T  mcq5_bsize_max     ;
    UI32_T  mcq5_shape_max     ;
    UI32_T  mcq5_shape_min     ;

    UI32_T  mcq6_dwrr_weight   ;
    UI32_T  mcq6_bsize_max     ;
    UI32_T  mcq6_shape_max     ;
    UI32_T  mcq6_shape_min     ;

    UI32_T  mcq7_dwrr_weight   ;
    UI32_T  mcq7_bsize_max     ;
    UI32_T  mcq7_shape_max     ;
    UI32_T  mcq7_shape_min     ;

    UI32_T  ucq0_dwrr_weight   ;
    UI32_T  ucq0_bsize_max     ;
    UI32_T  ucq0_shape_max     ;
    UI32_T  ucq0_shape_min     ;

    UI32_T  ucq1_dwrr_weight   ;
    UI32_T  ucq1_bsize_max     ;
    UI32_T  ucq1_shape_max     ;
    UI32_T  ucq1_shape_min     ;

    UI32_T  ucq2_dwrr_weight   ;
    UI32_T  ucq2_bsize_max     ;
    UI32_T  ucq2_shape_max     ;
    UI32_T  ucq2_shape_min     ;

    UI32_T  ucq3_dwrr_weight   ;
    UI32_T  ucq3_bsize_max     ;
    UI32_T  ucq3_shape_max     ;
    UI32_T  ucq3_shape_min     ;

    UI32_T  ucq4_dwrr_weight   ;
    UI32_T  ucq4_bsize_max     ;
    UI32_T  ucq4_shape_max     ;
    UI32_T  ucq4_shape_min     ;

    UI32_T  ucq5_dwrr_weight   ;
    UI32_T  ucq5_bsize_max     ;
    UI32_T  ucq5_shape_max     ;
    UI32_T  ucq5_shape_min     ;

    UI32_T  ucq6_dwrr_weight   ;
    UI32_T  ucq6_bsize_max     ;
    UI32_T  ucq6_shape_max     ;
    UI32_T  ucq6_shape_min     ;

    UI32_T  ucq7_dwrr_weight   ;
    UI32_T  ucq7_bsize_max     ;
    UI32_T  ucq7_shape_max     ;
    UI32_T  ucq7_shape_min     ;
}HAL_LIGHTNING_TM_SCH_LV1_CONFIG_ENTRY_T;

typedef struct HAL_LIGHTNING_TM_SCH_LV1_CONFIG_FIELD_S
{
    UI32_T  mcq0_dwrr_weight        :1;
    UI32_T  mcq0_bsize_max          :1;
    UI32_T  mcq0_shape_max          :1;
    UI32_T  mcq0_shape_min          :1;

    UI32_T  mcq1_dwrr_weight        :1;
    UI32_T  mcq1_bsize_max          :1;
    UI32_T  mcq1_shape_max          :1;
    UI32_T  mcq1_shape_min          :1;

    UI32_T  mcq2_dwrr_weight        :1;
    UI32_T  mcq2_bsize_max          :1;
    UI32_T  mcq2_shape_max          :1;
    UI32_T  mcq2_shape_min          :1;

    UI32_T  mcq3_dwrr_weight        :1;
    UI32_T  mcq3_bsize_max          :1;
    UI32_T  mcq3_shape_max          :1;
    UI32_T  mcq3_shape_min          :1;

    UI32_T  mcq4_dwrr_weight        :1;
    UI32_T  mcq4_bsize_max          :1;
    UI32_T  mcq4_shape_max          :1;
    UI32_T  mcq4_shape_min          :1;

    UI32_T  mcq5_dwrr_weight        :1;
    UI32_T  mcq5_bsize_max          :1;
    UI32_T  mcq5_shape_max          :1;
    UI32_T  mcq5_shape_min          :1;

    UI32_T  mcq6_dwrr_weight        :1;
    UI32_T  mcq6_bsize_max          :1;
    UI32_T  mcq6_shape_max          :1;
    UI32_T  mcq6_shape_min          :1;

    UI32_T  mcq7_dwrr_weight        :1;
    UI32_T  mcq7_bsize_max          :1;
    UI32_T  mcq7_shape_max          :1;
    UI32_T  mcq7_shape_min          :1;

    UI32_T  ucq0_dwrr_weight        :1;
    UI32_T  ucq0_bsize_max          :1;
    UI32_T  ucq0_shape_max          :1;
    UI32_T  ucq0_shape_min          :1;

    UI32_T  ucq1_dwrr_weight        :1;
    UI32_T  ucq1_bsize_max          :1;
    UI32_T  ucq1_shape_max          :1;
    UI32_T  ucq1_shape_min          :1;

    UI32_T  ucq2_dwrr_weight        :1;
    UI32_T  ucq2_bsize_max          :1;
    UI32_T  ucq2_shape_max          :1;
    UI32_T  ucq2_shape_min          :1;

    UI32_T  ucq3_dwrr_weight        :1;
    UI32_T  ucq3_bsize_max          :1;
    UI32_T  ucq3_shape_max          :1;
    UI32_T  ucq3_shape_min          :1;

    UI32_T  ucq4_dwrr_weight        :1;
    UI32_T  ucq4_bsize_max          :1;
    UI32_T  ucq4_shape_max          :1;
    UI32_T  ucq4_shape_min          :1;

    UI32_T  ucq5_dwrr_weight        :1;
    UI32_T  ucq5_bsize_max          :1;
    UI32_T  ucq5_shape_max          :1;
    UI32_T  ucq5_shape_min          :1;

    UI32_T  ucq6_dwrr_weight        :1;
    UI32_T  ucq6_bsize_max          :1;
    UI32_T  ucq6_shape_max          :1;
    UI32_T  ucq6_shape_min          :1;

    UI32_T  ucq7_dwrr_weight        :1;
    UI32_T  ucq7_bsize_max          :1;
    UI32_T  ucq7_shape_max          :1;
    UI32_T  ucq7_shape_min          :1;

}HAL_LIGHTNING_TM_SCH_LV1_CONFIG_FIELD_T;

/*table lv0_configg*/
typedef struct HAL_LIGHTNING_TM_SCH_LV0_CONFIG_ENTRY_S
{
    UI32_T  node0_dwrr_weight ;
    UI32_T  node0_bsize_max   ;
    UI32_T  node0_shape_max   ;
    UI32_T  node0_shape_min   ;

    UI32_T  node1_dwrr_weight ;
    UI32_T  node1_bsize_max   ;
    UI32_T  node1_shape_max   ;
    UI32_T  node1_shape_min   ;

    UI32_T  node2_dwrr_weight ;
    UI32_T  node2_bsize_max   ;
    UI32_T  node2_shape_max   ;
    UI32_T  node2_shape_min   ;

    UI32_T  node3_dwrr_weight ;
    UI32_T  node3_bsize_max   ;
    UI32_T  node3_shape_max   ;
    UI32_T  node3_shape_min   ;

    UI32_T  node4_dwrr_weight ;
    UI32_T  node4_bsize_max   ;
    UI32_T  node4_shape_max   ;
    UI32_T  node4_shape_min   ;

    UI32_T  node5_dwrr_weight ;
    UI32_T  node5_bsize_max   ;
    UI32_T  node5_shape_max   ;
    UI32_T  node5_shape_min   ;

    UI32_T  node6_dwrr_weight ;
    UI32_T  node6_bsize_max   ;
    UI32_T  node6_shape_max   ;
    UI32_T  node6_shape_min   ;

    UI32_T  node7_dwrr_weight ;
    UI32_T  node7_bsize_max   ;
    UI32_T  node7_shape_max   ;
    UI32_T  node7_shape_min   ;
}HAL_LIGHTNING_TM_SCH_LV0_CONFIG_ENTRY_T;

typedef struct HAL_LIGHTNING_TM_SCH_LV0_CONFIG_FIELD_S
{
    UI32_T  node0_dwrr_weight        :1;
    UI32_T  node0_bsize_max          :1;
    UI32_T  node0_shape_max          :1;
    UI32_T  node0_shape_min          :1;

    UI32_T  node1_dwrr_weight        :1;
    UI32_T  node1_bsize_max          :1;
    UI32_T  node1_shape_max          :1;
    UI32_T  node1_shape_min          :1;

    UI32_T  node2_dwrr_weight        :1;
    UI32_T  node2_bsize_max          :1;
    UI32_T  node2_shape_max          :1;
    UI32_T  node2_shape_min          :1;

    UI32_T  node3_dwrr_weight        :1;
    UI32_T  node3_bsize_max          :1;
    UI32_T  node3_shape_max          :1;
    UI32_T  node3_shape_min          :1;

    UI32_T  node4_dwrr_weight        :1;
    UI32_T  node4_bsize_max          :1;
    UI32_T  node4_shape_max          :1;
    UI32_T  node4_shape_min          :1;

    UI32_T  node5_dwrr_weight        :1;
    UI32_T  node5_bsize_max          :1;
    UI32_T  node5_shape_max          :1;
    UI32_T  node5_shape_min          :1;

    UI32_T  node6_dwrr_weight        :1;
    UI32_T  node6_bsize_max          :1;
    UI32_T  node6_shape_max          :1;
    UI32_T  node6_shape_min          :1;

    UI32_T  node7_dwrr_weight        :1;
    UI32_T  node7_bsize_max          :1;
    UI32_T  node7_shape_max          :1;
    UI32_T  node7_shape_min          :1;
}HAL_LIGHTNING_TM_SCH_LV0_CONFIG_FIELD_T;


typedef struct HAL_LIGHTNING_TM_FP_SP_CONFIG_ENTRY_S
{
    /*sp bitmap of node 0*/
    UI32_T fp_sp_lv1_n0        ;
    /*sp bitmap of node 1*/
    UI32_T fp_sp_lv1_n1        ;
    /*sp bitmap of node 2*/
    UI32_T fp_sp_lv1_n2        ;
    /*sp bitmap of node 3*/
    UI32_T fp_sp_lv1_n3        ;
    /*sp bitmap of node 4*/
    UI32_T fp_sp_lv1_n4        ;
    /*sp bitmap of node 5*/
    UI32_T fp_sp_lv1_n5        ;
    /*sp bitmap of node 6*/
    UI32_T fp_sp_lv1_n6        ;
    /*sp bitmap of node 7*/
    UI32_T fp_sp_lv1_n7        ;

    /*sp bitmap of node 8*/
    UI32_T fp_sp_lv0_n8        ;
}HAL_LIGHTNING_TM_FP_SP_CONFIG_ENTRY_T;

typedef struct HAL_LIGHTNING_TM_FP_SP_CONFIG_FIELD_S
{
    UI32_T fp_sp_lv1_n0             :1;
    UI32_T fp_sp_lv1_n1             :1;
    UI32_T fp_sp_lv1_n2             :1;
    UI32_T fp_sp_lv1_n3             :1;
    UI32_T fp_sp_lv1_n4             :1;
    UI32_T fp_sp_lv1_n5             :1;
    UI32_T fp_sp_lv1_n6             :1;
    UI32_T fp_sp_lv1_n7             :1;

    UI32_T fp_sp_lv0_n8             :1;
}HAL_LIGHTNING_TM_FP_SP_CONFIG_FIELD_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_initRsrc(
    const UI32_T                unit);

CLX_ERROR_NO_T
hal_lightning_tm_sch_deinitRsrc(
    const UI32_T                unit);

/* FUNCTION NAME:   hal_lightning_tm_sch_initCfg
 * PURPOSE:
 *     Init tm module sch configuration.
 *
 * INPUT:
 *     unit        --  Device unit number.
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK    --  Operate success.
 *     CLX_E_OTHER --  Init fail.
 *
 * NOTES:
 *     This function will configure all front-plane-ports to be default
 *     topology.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_initCfg(
    const UI32_T                unit);

/* FUNCTION NAME:   hal_lightning_tm_sch_setPortState
 * PURPOSE:
 *      Update register when port link status.
 *
 * INPUT:
 *      unit         -- Device unit number.
 *      port         -- Physical port id.
 *      link         -- TRUE: link up; FALSE: link down.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_setPortState(
    const UI32_T            unit,
    const UI32_T            port,
    const UI32_T            link);

/* FUNCTION NAME:   hal_lightning_tm_sch_setBandwidth
 * PURPOSE:
 *      Configure min/max bandwidth for a handler.
 *
 * INPUT:
 *      unit          -- Device unit number.
 *      port          -- Egress physical port id which to be written.
 *      handler       -- The handler which the bandwidth written on.
 *      ptr_bandwidth -- Bandwidth informations.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK      -- Success.
 *      CLX_E_OTHERS  -- Failed.
 *
 * NOTES:
 *      If maxbandwidth is 0, sdk will configure port speed to hardware.
 *      If burst size is 0, sdk will calculate burst size itself.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_setBandwidth(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_BANDWIDTH_T    *ptr_bandwidth);

/* FUNCTION NAME:   hal_lightning_tm_sch_getBandwidth
 * PURPOSE:
 *      Get min/max bandwidth of a handler.
 *
 * INPUT:
 *      unit          -- Device unit number.
 *      port          -- Egress physical port id which to be written.
 *      handler       -- The handler which the bandwidth to be got.
 * OUTPUT:
 *      ptr_bandwidth -- The bandwidth of the handler.
 * RETURN:
 *      CLX_E_OK      -- Success.
 *      CLX_E_OTHERS  -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_getBandwidth(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    CLX_TM_BANDWIDTH_T          *ptr_bandwidth);

/* FUNCTION NAME:   hal_lightning_tm_sch_setScheduleTopology
 * PURPOSE:
 *      Configure schedule topology of a egress port.
 *
 * INPUT:
 *      unit               -- Device unit number.
 *      port               -- Egress physical port id.
 *      ptr_topology_entry -- Array which has many topology entries.
 *      entry_count        -- Entry count of the array ptr_topology_entry
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_NOT_SUPPORT
 *
 * NOTES:
 *      When topology changed successfully, all the schedule property such as
 *      algorithm and dwrr weight and min/max bandwidth will all be rewrite
 *      to hardware.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_setScheduleTopology(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_SCH_TOPOLOGY_ENTRY_T   *ptr_topology_entry,
    const UI32_T                        entry_count);

/* FUNCTION NAME:   hal_lightning_tm_sch_getScheduleTopology
 * PURPOSE:
 *      Get schedule topology of a egress port.
 *
 * INPUT:
 *      unit                   -- Device unit number.
 *      port                   -- Egress physical port id.
 *      entry_count            -- Entry count of the array ptr_topology_entry.
 * OUTPUT:
 *      ptr_topology_entry     -- Array which has many topology entries return
 *                                by SDK.
 *      ptr_actual_entry_count -- Entry count of SDK return.
 * RETURN:
 *      CLX_E_NOT_SUPPORT
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_getScheduleTopology(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_TM_SCH_TOPOLOGY_ENTRY_T         *ptr_topology_entry,
    UI32_T                              entry_count,
    UI32_T                              *ptr_actual_entry_count);

/* FUNCTION NAME:   hal_lightning_tm_sch_setScheduleMode
 * PURPOSE:
 *      Configure sp/dwrr weight for a handler.
 *
 * INPUT:
 *      unit         -- Device unit number.
 *      port         -- Egress physical port id which to be written.
 *      handler      -- The handler which the bandwidth written on.
 *      mode         -- Schedule algorithm. sp or dwrr.
 *      weight       -- Weight of dwrr, valid only when mode parameter is dwrr.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_setScheduleMode(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_SCH_MODE_T     mode,
    const UI32_T                weight);

/* FUNCTION NAME:   hal_lightning_tm_sch_getScheduleMode
 * PURPOSE:
 *      Gget sp/dwrr weight of a handler.
 *
 * INPUT:
 *      unit         -- Device unit number.
 *      port         -- Egress physical port id which to be got.
 *      handler      -- The handler which to be got.
 * OUTPUT:
 *      ptr_mode     -- Schedule algorithm. sp or dwrr.
 *      ptr_weight   -- Weight of dwrr, valid only when mode parameter is dwrr.
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_getScheduleMode(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_SCH_MODE_T                   *ptr_mode,
    UI32_T                              *ptr_weight);

/* FUNCTION NAME:   hal_lightning_tm_sch_setDwrrMinBwCombineMode
 * PURPOSE:
 *      Per port configure the relationship between dwrr and min bandwidth.
 *
 * INPUT:
 *      unit         -- Device unit number.
 *      port         -- Egress port id.
 *      mode         -- Share mode or Separate mode.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_setDwrrMinBwCombineMode(
    const UI32_T                                    unit,
    const UI32_T                                    port,
    const CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_T mode);

/* FUNCTION NAME:   hal_lightning_tm_sch_getDwrrMinBwCombineMode
 * PURPOSE:
 *      Get per port configure the relationship between dwrr and min bandwidth.
 *
 * INPUT:
 *      unit         --  Device unit number.
 *      port         -- Egress port id.
 * OUTPUT:
 *      ptr_mode     -- Share mode or Separate mode.
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_getDwrrMinBwCombineMode(
    const UI32_T                                    unit,
    const UI32_T                                    port,
    CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_T       *ptr_mode);

/* FUNCTION NAME:   hal_lightning_tm_sch_setSchedulePacketLength
 * PURPOSE:
 *      Configure the packet length whether include SFG(8byte)+IFG(12byte).
 *
 * INPUT:
 *      unit         -- Device unit number.
 *      layer        -- Physical layer means include SFG+IFG.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_setSchedulePacketLength(
    const UI32_T                                unit,
    const UI32_T                                layer);

/* FUNCTION NAME:   hal_lightning_tm_sch_getSchedulePacketLength
 * PURPOSE:
 *      Get configure the packet length whether include SFG(8byte)+IFG(12byte).
 *
 * INPUT:
 *      unit         -- Device unit number.
 * OUTPUT:
 *      ptr_layer    -- Physical layer means include SFG+IFG.
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_getSchedulePacketLength(
    const UI32_T                                    unit,
    UI32_T                                          *ptr_layer);

/* FUNCTION NAME: hal_lightning_tm_setPortEee
 * PURPOSE:
 *      The function is used to set port EEE mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      mode             -- EEE mode which is the same as the definition of port module.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_setPortEee(
    const UI32_T                            unit,
    const UI32_T                            port,
    const HAL_TM_EEE_MODE_T                 mode);

/* FUNCTION NAME: hal_lightning_tm_sch_getPortEee
 * PURPOSE:
 *      The function is used to get port EEE mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 * OUTPUT:
 *      ptr_mode         -- EEE mode which is the same as the definition of port module.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_sch_getPortEee(
    const UI32_T                            unit,
    const UI32_T                            port,
    HAL_TM_EEE_MODE_T                       *ptr_mode);

CLX_ERROR_NO_T
hal_lightning_tm_sch_flushQueue(
    const UI32_T            unit,
    const UI32_T            port,
    const UI32_T            flush_all,
    const CLX_TM_HANDLER_T  handler,
    const UI32_T            enable);

CLX_ERROR_NO_T
hal_lightning_tm_sch_initWarm(
    const UI32_T unit,
    HAL_IO_WB_DB_T *ptr_db);


CLX_ERROR_NO_T
hal_lightning_tm_sch_deinitWarm(
    const UI32_T unit,
    HAL_IO_WB_DB_T *ptr_db);

CLX_ERROR_NO_T
hal_lightning_tm_sch_setPortDefault(
    const UI32_T                            unit,
    const UI32_T                            port);

CLX_ERROR_NO_T
hal_lightning_tm_sch_setPortShaping(
    const UI32_T unit,
    const UI32_T port,
    const UI32_T max_bandwidth_rate,
    const UI32_T max_burst_size);

#endif /* End of HAL_LIGHTNING_TM_SCH_H */

