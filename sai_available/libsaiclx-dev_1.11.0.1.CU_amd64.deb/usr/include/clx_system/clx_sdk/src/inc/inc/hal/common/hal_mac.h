/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:   hal_mac.h
 * PURPOSE:
 *      It provide MAC APIs.
 * NOTES:
 */

#ifndef HAL_MAC_H
#define HAL_MAC_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MAC_IPG_BIAS_DFLT       (4)
#define HAL_MAC_IPG_BIAS_DISABLE    (0)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef enum
{
    HAL_MAC_PROPERTY_MAC_ADDR_0 = 0,
    HAL_MAC_PROPERTY_MAC_ADDR_1,
    HAL_MAC_PROPERTY_VLAN_TAG_0,
    HAL_MAC_PROPERTY_VLAN_TAG_1,
    HAL_MAC_PROPERTY_LPK_T2R_ENA,
    HAL_MAC_PROPERTY_LPK_T2R_DATA_ENA,
    HAL_MAC_PROPERTY_TX_REM_FAULT,
    HAL_MAC_PROPERTY_LPI_CAPABILITY,
    HAL_MAC_PROPERTY_PFC_TX_EN,
    HAL_MAC_PROPERTY_PFC_RX_EN,
    HAL_MAC_PROPERTY_LFC_TX_EN,
    HAL_MAC_PROPERTY_LFC_RX_EN,
    HAL_MAC_PROPERTY_RX_RS_ENA,
    HAL_MAC_PROPERTY_TX_PKT_ENA,
    HAL_MAC_PROPERTY_EGR_LATENCY,
    HAL_MAC_PROPERTY_PTP_EN,
    HAL_MAC_PROPERTY_EGRTS_FIFO_DEPTH,
    HAL_MAC_PROPERTY_EGRTS_FIFO_START,
    HAL_MAC_PROPERTY_IPG_BIAS,
    HAL_MAC_PROPERTY_HAS_MXHDR_EN,
    HAL_MAC_PROPERTY_FRM_LENGTH,
    HAL_MAC_PROPERTY_FLT_HDL_DIS,
    HAL_MAC_PROPERTY_MIB_MAX_LENGTH,
    HAL_MAC_PROPERTY_NO_LGTH_CHECK,
    HAL_MAC_PROPERTY_TX_HAS_MXHDR_EN,
    HAL_MAC_PROPERTY_RX_HAS_MXHDR_EN,
    HAL_MAC_PROPERTY_RX_ERR_MASK_OS_TRUNC,
    HAL_MAC_PROPERTY_RX_ERR_MASK_CRC,
    HAL_MAC_PROPERTY_CRC_RP,
    HAL_MAC_PROPERTY_MAC_TX_ENA,
    HAL_MAC_PROPERTY_MAC_RX_ENA,
    HAL_MAC_PROPERTY_TX_MIB_EN,
    HAL_MAC_PROPERTY_RX_MIB_EN,
    HAL_MAC_PROPERTY_LFC_TX_SEL,
    HAL_MAC_PROPERTY_IGR_LATENCY,
    HAL_MAC_PROPERTY_CPI_MODE,
    HAL_MAC_PROPERTY_PAUSE_THRESH,
    HAL_MAC_PROPERTY_LAST
} HAL_MAC_PROPERTY_T;

typedef enum
{
    HAL_MAC_TX_PAUSE_STATE_XOFF = 0x1,
    HAL_MAC_TX_PAUSE_STATE_XON,
    HAL_MAC_TX_PAUSE_STATE_LAST
} HAL_MAC_TX_PAUSE_STATE_T;

typedef enum
{
    HAL_MAC_TX_CTRL_STATE_IDLE = 0,
    HAL_MAC_TX_CTRL_STATE_PKT,
    HAL_MAC_TX_CTRL_STATE_PAUSE,
    HAL_MAC_TX_CTRL_STATE_FAULT = 5,
    HAL_MAC_TX_CTRL_STATE_LPI = 6,
    HAL_MAC_TX_CTRL_STATE_LAST
} HAL_MAC_TX_CTRL_STATE_T;

typedef enum
{
    HAL_MAC_STATUS_TX_FIFO_EMPTY = 0,
    HAL_MAC_STATUS_RX_LOC_FAULT,
    HAL_MAC_STATUS_RX_REM_FAULT,
    HAL_MAC_STATUS_RX_LFC_STS,
    HAL_MAC_STATUS_RX_PFC_STS,
    HAL_MAC_STATUS_TX_PAUSE_STATE,
    HAL_MAC_STATUS_TX_PFC_STATE,
    HAL_MAC_STATUS_TX_CTRL_STATE,
    HAL_MAC_STATUS_LAST
} HAL_MAC_STATUS_T;

typedef enum
{
    HAL_MAC_SYNCE_MODE_0 = 0,
    HAL_MAC_SYNCE_MODE_1,
    HAL_MAC_SYNCE_MODE_LAST

} HAL_MAC_SYNCE_MODE_T;

typedef enum
{
    HAL_MAC_PORT_CTRL_TX_CG_EN = 0,
    HAL_MAC_PORT_CTRL_RX_CG_EN,
    HAL_MAC_PORT_CTRL_PKTGEN_CG_EN,
    HAL_MAC_PORT_CTRL_PTP_CG_EN,
    HAL_MAC_PORT_CTRL_TX_RST_B,
    HAL_MAC_PORT_CTRL_RX_RST_B,
    HAL_MAC_PORT_CTRL_PKTGEN_RST_B,
    HAL_MAC_PORT_CTRL_PTP_RST_B,
    HAL_MAC_PORT_CTRL_LAST
} HAL_MAC_PORT_CTRL_T;

typedef enum
{
    HAL_MAC_CHANNEL_CTRL_TXFIFO_CG_EN = 0,
    HAL_MAC_CHANNEL_CTRL_RX_CG_EN,
    HAL_MAC_CHANNEL_CTRL_TXFIFO_RST_B,
    HAL_MAC_CHANNEL_CTRL_RX_RST_B,
    HAL_MAC_CHANNEL_CTRL_LAST
} HAL_MAC_CHANNEL_CTRL_T;

typedef enum
{
    /** No Error detected */
    HAL_MAC_LINK_TRAINING_RESULT_NO_ERROR,

    /** Failure detected */
    HAL_MAC_LINK_TRAINING_RESULT_FRAME_LOCK_ERROR,

    /** SNR lower than threshold */
    HAL_MAC_LINK_TRAINING_RESULT_SNR_LOWER_THRESHOLD,

    /** Link training timeout */
    HAL_MAC_LINK_TRAINING_RESULT_TIME_OUT,
    HAL_MAC_LINK_TRAINING_RESULT_LAST
} HAL_MAC_LINK_TRAINING_RESULT_T;
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_mac_init
 * PURPOSE:
 *      Initialize MAC function of all ports
 * INPUT:
 *      unit                --  Chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_init(
    const UI32_T                unit);

/* FUNCTION NAME: hal_mac_deinit
 *
 * PURPOSE:
 *      Deinitialize MAC function of all ports
 * INPUT:
 *      unit                --  Chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_deinit(
    const UI32_T                unit);

/* FUNCTION NAME: hal_mac_initPort
 *
 * PURPOSE:
 *      Initialize MAC function of one port.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_initPort(
    const UI32_T                unit,
    const UI32_T                port);

/* FUNCTION NAME: hal_mac_deinitPort
 *
 * PURPOSE:
 *      Deinitialize MAC function of one port.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_deinitPort(
    const UI32_T                unit,
    const UI32_T                port);

/* FUNCTION NAME:  hal_mac_setProperty
 * PURPOSE:
 *      To set mac control property
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      property            --  Property type
 *      param0              --  First parameter
 *      param1              --  Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_setProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const HAL_MAC_PROPERTY_T    property,
    const UI32_T                param0,
    const UI32_T                param1);

/* FUNCTION NAME:  hal_mac_getProperty
 * PURPOSE:
 *      To get mac control property
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      property            --  Property type
 * OUTPUT:
 *      *ptr_param0         --  First parameter
 *      *ptr_param1         --  Second parameter
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_getProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const HAL_MAC_PROPERTY_T    property,
    UI32_T                      *ptr_param0,
    UI32_T                      *ptr_param1);

/* FUNCTION NAME:  hal_mac_setFlowCtrl
 * PURPOSE:
 *      To set port link flow control
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      flow_ctrl           --  Flow control type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_setFlowCtrl(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_PORT_FC_T         flow_ctrl);

/* FUNCTION NAME:  hal_mac_getFlowCtrl
 * PURPOSE:
 *      To get port link flow control
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      ptr_flow_ctrl       --  Flow control type
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_getFlowCtrl(
    const UI32_T                unit,
    const UI32_T                port,
    CLX_PORT_FC_T               *ptr_flow_ctrl);

/* FUNCTION NAME:   hal_mac_setPriFlowCtrl
 * PURPOSE:
 *      To set the PFC configuration for a specific port.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      pri                 --  Priority number 0~7
 *      flow_ctrl           --  Flow control type
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_setPriFlowCtrl(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI8_T               pri,
    const   CLX_PORT_FC_T       flow_ctrl);

/* FUNCTION NAME:   hal_mac_getPriFlowCtrl
 * PURPOSE:
 *      To get the PFC configuration for a specific port.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      pri                 --  Priority number 0~7
 * OUTPUT:
 *      ptr_flow_ctrl       --  Flow control type
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_getPriFlowCtrl(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI8_T               pri,
    CLX_PORT_FC_T               *ptr_flow_ctrl);

/* FUNCTION NAME:   hal_mac_getAbility
 * PURPOSE:
 *      Get port ability
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      ptr_ability         --  Port ability
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_getAbility(
    const   UI32_T              unit,
    const   UI32_T              port,
    CLX_PORT_ABILITY_T          *ptr_ability);

/* FUNCTION NAME:   hal_mac_initTsFifo
 * PURPOSE:
 *      Initialize time stamp fifo information by speed.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      speed                -- Port speed
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_mac_initTsFifo(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_PORT_SPEED_T      speed);

/* FUNCTION NAME:   hal_mac_getTsEntryCount
 * PURPOSE:
 *      Get port tx time stamp entry count.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      ptr_ts_entry        --  Time stamp entry information
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_getTsEntryCount(
    const UI32_T                unit,
    const UI32_T                port,
    UI32_T                      *ptr_count);

/* FUNCTION NAME:   hal_mac_getTsEntry
 * PURPOSE:
 *      Get mac time stamp entry information.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      ptr_ts_entry        --  Time stamp entry information
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_getTsEntry(
    const UI32_T                unit,
    const UI32_T                port,
    CLX_PORT_TS_ENTRY_T         *ptr_ts_entry);

/* FUNCTION NAME:   hal_mac_updateTsTxLatency
 * PURPOSE:
 *      Update mac egress TS latency.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      latency             --  Latency of egress
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_updateTsTxLatency(
    const UI32_T                unit,
    const UI32_T                port,
    const UI32_T                latency);

/* FUNCTION NAME:   hal_mac_getTxFifoEmpty
 * PURPOSE:
 *      Check if tx fifo is empty.
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_getTxFifoEmpty(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_mac_setSyncE
 * PURPOSE:
 *      Set SyncE state per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      mode        -- SyncE mode
 *      enable      -- SyncE state
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_mac_setSyncE(
    const UI32_T                  unit,
    const UI32_T                  port,
    const HAL_MAC_SYNCE_MODE_T    mode,
    const UI32_T                  enable);

/* FUNCTION NAME:   hal_mac_getSyncE
 * PURPOSE:
 *      Get SyncE state per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      mode        -- SyncE mode
 * OUTPUT:
 *      ptr_enable  -- SyncE state
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_mac_getSyncE(
    const UI32_T                  unit,
    const UI32_T                  port,
    const HAL_MAC_SYNCE_MODE_T    mode,
    UI32_T                        *ptr_enable);

/* FUNCTION NAME:  hal_mac_setTxFlush
 * PURPOSE:
 *      To set mac tx flush state
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      enable              --  Mac tx flush state
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      Tx flush is write only feature.
 */
CLX_ERROR_NO_T
hal_mac_setTxFlush(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

/* FUNCTION NAME:  hal_mac_getStatus
 * PURPOSE:
 *      To get mac status
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      status              --  Status type
 * OUTPUT:
 *      *ptr_param0         --  First parameter
 *      *ptr_param1         --  Second parameter
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_mac_getStatus(
    const UI32_T              unit,
    const UI32_T              port,
    const HAL_MAC_STATUS_T    status,
    UI32_T                    *ptr_param0,
    UI32_T                    *ptr_param1);

/* FUNCTION NAME:  hal_mac_getPropertyStr
 * PURPOSE:
 *      To get property string
 * INPUT:
 *      property            --  Property type
 * OUTPUT:
 *      None
 * RETURN:
 *      Property string
 * NOTES:
 *      None
 */
const C8_T *
hal_mac_getPropertyStr(
    const HAL_MAC_PROPERTY_T    property);

/* FUNCTION NAME:  hal_mac_getStatusStr
 * PURPOSE:
 *      To get status string
 * INPUT:
 *      property            --  Status type
 * OUTPUT:
 *      None
 * RETURN:
 *      Status string
 * NOTES:
 *      None
 */
const C8_T *
hal_mac_getStatusStr(
    const HAL_MAC_STATUS_T    status);

/* FUNCTION NAME:   hal_mac_setAdminState
 * PURPOSE:
 *      To set the admin state for a specific port.
 * INPUT:
 *      unit        --  Device unit number
 *      port        --  Physical port id
 *      lane_cnt    --  Lane count
 *      enable      --  1 for enable admin state, and
 *                      0 for disable admin state.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_BAD_PARAMETER --  Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_setAdminState(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    lane_cnt,
    const UI32_T    enable);

/* FUNCTION NAME:  hal_mac_checkStatus
 * PURPOSE:
 *      To check if mac status is right
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 *      status              --  Status type
 * OUTPUT:
 *      *ptr_param0         --  First parameter
 *      *ptr_param1         --  Second parameter
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_checkStatus(
    const UI32_T              unit,
    const UI32_T              port,
    const HAL_MAC_STATUS_T    sts_type,
    const UI32_T              sts_value);

/* FUNCTION NAME:  hal_mac_checkTxCtrlState
 * PURPOSE:
 *      To check if mac tx control state is right
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_checkTxCtrlState(
    const UI32_T              unit,
    const UI32_T              port);

/* FUNCTION NAME:  hal_mac_checkFaultState
 * PURPOSE:
 *      To check if mac tx control stat is fault state
 * INPUT:
 *      unit                --  Chip id
 *      port                --  Port id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success
 *      CLX_E_OTHERS        --  Error occurs
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_checkFaultState(
    const UI32_T              unit,
    const UI32_T              port);

/* FUNCTION NAME:   hal_mac_setPmdTxState
 * PURPOSE:
 *      To set the PMD state for a specific port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port id.
 *      enable      --  To enable/disable the port.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            --  The operation is success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_mac_setPmdTxState(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

CLX_ERROR_NO_T
hal_mac_getLinkTrainingResult(
    const UI32_T                        unit,
    const UI32_T                        port,
    HAL_MAC_LINK_TRAINING_RESULT_T      *type);

#endif /* End of HAL_MAC_H */
