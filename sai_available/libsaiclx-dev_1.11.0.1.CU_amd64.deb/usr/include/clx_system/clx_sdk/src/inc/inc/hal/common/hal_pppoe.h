/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_pppoe.h
 * PURPOSE:
 *      It provide pppoe hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_PPPOE_H
#define HAL_PPPOE_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_pppoe.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_pppoe_init(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_pppoe_deinit(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_pppoe_setPortDefault(
    const UI32_T unit,
    const UI32_T port);

CLX_ERROR_NO_T
hal_pppoe_resetPortDefault(
    const UI32_T unit,
    const UI32_T port);

CLX_ERROR_NO_T
hal_pppoe_setServerMac(
    const UI32_T    unit,
    const CLX_MAC_T mac);

CLX_ERROR_NO_T
hal_pppoe_getServerMac(
    const UI32_T    unit,
    CLX_MAC_T       *ptr_mac);

CLX_ERROR_NO_T
hal_pppoe_addSegService(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const UI32_T                sess_id,
    const UI32_T                seg0,
    const UI32_T                seg1,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

CLX_ERROR_NO_T
hal_pppoe_delSegService(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        sess_id,
    const UI32_T        seg0,
    const UI32_T        seg1);

CLX_ERROR_NO_T
hal_pppoe_getSegService(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        sess_id,
    const UI32_T        seg0,
    const UI32_T        seg1,
    CLX_PORT_SEG_SRV_T  *ptr_seg_srv);


/* FUNCTION NAME: hal_pppoe_setPort
 * PURPOSE:
 *      This API is used to enable/disable pppoe port.
 * INPUT:
 *      unit   -- Device unit number
 *      port   -- Physical port
 *      enable -- 1: enable, 0: disable
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pppoe_setPort(
    const UI32_T unit,
    const UI32_T port,
    const UI32_T enable);

/* FUNCTION NAME: hal_pppoe_getPort
 * PURPOSE:
 *      This API is used to get if port is pppoe enabled.
 * INPUT:
 *      unit   -- Device unit number
 *      port   -- Physical port
 * OUTPUT:
 *      ptr_enable -- 1: enable, 0: disable
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pppoe_getPort(
    const UI32_T unit,
    const UI32_T port,
    UI32_T *ptr_enable);

/* FUNCTION NAME: hal_pppoe_setPortVlan
 * PURPOSE:
 *      This API is used to set per port vlan search number.
 * INPUT:
 *      unit    -- Device unit number
 *      port    -- Physical port
 *      vid_num -- 1: use 1 vlan, 2: use 2 vlan
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pppoe_setPortVlan(
    const UI32_T unit,
    const UI32_T port,
    const UI32_T vid_num);

/* FUNCTION NAME: hal_pppoe_getPortVlan
 * PURPOSE:
 *      This API is used to get per port vlan search number.
 * INPUT:
 *      unit    -- Device unit number
 *      port    -- Physical port
 * OUTPUT:
 *      ptr_vid_num -- 1: use 1 vlan, 2: use 2 vlan
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pppoe_getPortVlan(
    const UI32_T unit,
    const UI32_T port,
    UI32_T *ptr_vid_num);

/* FUNCTION NAME: hal_pppoe_getSeg
 * PURPOSE:
 *      This API is used to compose egress seg_vmid for L3.
 * INPUT:
 *      unit     -- Device unit number
 *      sess_id  -- PPPoE session_id
 * OUTPUT:
 *      *ptr_seg -- Egress seg_vmid in IEV_L3
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pppoe_getSeg(
    const UI32_T unit,
    const UI32_T sess_id,
    UI32_T *ptr_seg);

/* FUNCTION NAME: hal_pppoe_getSess
 * PURPOSE:
 *      This API is used to get session_id from hardware.
 * INPUT:
 *      unit      -- Device unit number
 *      di        -- Destination Index
 *      seg       -- Egress seg_vmid in IEV_L3
 * OUTPUT:
 *      *ptr_sess -- PPPoE session_id
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pppoe_getSess(
    const UI32_T unit,
    const UI32_T di,
    const UI32_T seg,
    UI32_T *ptr_sess);

#endif