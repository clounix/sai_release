/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_io.h
 * PURPOSE:
 *      1. hal_io.h provides HAL IO manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_IO_H
#define HAL_IO_H

#include <clx_module.h>
#include <cmlib/cmlib_avl.h>
#include <cmlib/cmlib_list.h>


typedef struct HAL_IO_SUB_HDR_S{
    UI32_T cnt;      /* meta unit count */
    UI32_T unit_len; /* the length of one meta unit */
} HAL_IO_SUB_HDR_T;

typedef struct HAL_IO_SWDB_AVL_COOKIE_S
{
    HAL_IO_SUB_HDR_T header;
    C8_T *ptr_data;
} HAL_IO_SWDB_AVL_COOKIE_T;

typedef struct HAL_IO_OBJ_META_S{
    UI32_T obj_id;
    UI32_T obj_ver;
    UI32_T data_size;
    C8_T   *ptr_data;
} HAL_IO_OBJ_META_T;

typedef struct HAL_IO_WB_DB_S{
    UI32_T              max_cnt;        /* used when closeNonVolatile */
    UI32_T              cur_idx;        /* used when addWbObj         */
    UI32_T              total_obj_size; /* used when closeNonVolatile */
    HAL_IO_OBJ_META_T   *ptr_objs;
} HAL_IO_WB_DB_T;



CLX_ERROR_NO_T
hal_io_openNonvolatile(
    const UI32_T unit,
    const UI32_T write_mode);

CLX_ERROR_NO_T
hal_io_closeNonvolatile(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_io_getNonvolatile(
    const UI32_T unit,
    const CLX_MODULE_T module,
    C8_T **pptr_buf,
    UI32_T *ptr_num_bytes);

/* FUNCTION NAME: hal_io_saveAvlTree
* PURPOSE:
*      The function is used to save AVL tree to buffer. Please note that
*      1. avl node should not have pointer field.
* INPUT:
*      length         -- Node size
*      *ptr_avl       -- Pointer of the avl tree head
*      *ptr_obj_meta  -- Object Meta for the avl storage
* OUTPUT:
*      *ptr_obj_meta  -- Object Meta for the avl storage
* RETURN:
*      CLX_E_OK       -- Operate success.
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_io_saveAvlTree(
    const UI32_T           length,
    const CMLIB_AVL_HEAD_T *ptr_avl,
    HAL_IO_OBJ_META_T      *ptr_obj_meta);

/* FUNCTION NAME: hal_io_restoreAvlTree
* PURPOSE:
*      The function is used to restore AVL tree from buffer
* INPUT:
*      length         -- Node size
*      *ptr_avl       -- Pointer of the avl tree head
*      *ptr_obj_meta  -- Object Meta for the avl storage
* OUTPUT:
*      NONE.
* RETURN:
*      CLX_E_OK       -- Operate success.
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_io_restoreAvlTree(
    const UI32_T            length,
    const CMLIB_AVL_HEAD_T  *ptr_avl,
    const HAL_IO_OBJ_META_T *ptr_obj_meta);

/* FUNCTION NAME: hal_io_saveList
* PURPOSE:
*      The function is used to save List to buffer. Please note that
*      1. list node should not have pointer field.
* INPUT:
*      length         -- Node size
*      *ptr_list      -- Pointer of the list head
*      *ptr_obj_meta  -- Object Meta for the list storage
* OUTPUT:
*      *ptr_obj_meta  -- Object Meta for the list storage
* RETURN:
*      CLX_E_OK       -- Operate success.
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_io_saveList(
    const UI32_T       length,
    const CMLIB_LIST_T *ptr_list,
    HAL_IO_OBJ_META_T  *ptr_obj_meta);

/* FUNCTION NAME: hal_io_restoreList
*      The function is used to restore List from buffer
* INPUT:
*      length         -- Node size
*      *ptr_list      -- Pointer of the List head
*      *ptr_obj_meta  -- Object Meta for the list storage
* OUTPUT:
*      NONE.
* RETURN:
*      CLX_E_OK       -- Operate success.
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_io_restoreList(
    const UI32_T             length,
    const CMLIB_LIST_T       *ptr_list,
    const HAL_IO_OBJ_META_T  *ptr_obj_meta);

/* FUNCTION NAME: hal_io_saveArray
* PURPOSE:
*      The function is used to save Array to buffer. Please note that
*      1. array node should not have pointer field.
* INPUT:
*      length         -- Node size
*      count          -- Node count
*      *ptr_array     -- Pointer of the array head
*      *ptr_obj_meta  -- Object Meta for the array storage
* OUTPUT:
*      *ptr_obj_meta  -- Object Meta for the array storage
* RETURN:
*      CLX_E_OK       -- Operate success.
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_io_saveArray(
    const UI32_T       length,
    const UI32_T       count,
    const void         *ptr_array,
    HAL_IO_OBJ_META_T  *ptr_obj_meta);

/* FUNCTION NAME: hal_io_restoreArray
*      The function is used to restore Array from buffer
* INPUT:
*      *ptr_array     -- Pointer of the Array head
*      *ptr_obj_meta  -- Object Meta for the array storage
* OUTPUT:
*      NONE.
* RETURN:
*      CLX_E_OK       -- Operate success.
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_io_restoreArray(
    void                    *ptr_array,
    const HAL_IO_OBJ_META_T *ptr_obj_meta);

/* FUNCTION NAME: hal_io_createWbDb
*      The function is used to create a warmboot database.
* INPUT:
*      obj_count      -- Total object count
* OUTPUT:
*      pptr_db        -- Pointer to the warmboot database
* RETURN:
*      CLX_ERROR_NO_T
* NOTES:
*      NONE
*/
CLX_ERROR_NO_T
hal_io_createWbDb(
    UI32_T          obj_count,
    HAL_IO_WB_DB_T  **pptr_db);

/* FUNCTION NAME: hal_io_addWbObj
*      The function is used to add object(s) to warmboot database.
* INPUT:
*      ptr_db       -- Pointer to the warmboot database
* OUTPUT:
*      obj_count    -- Object count to be added
*      ptr_objs     -- Objects to be added
* RETURN:
*      CLX_ERROR_NO_T
* NOTES:
*      NONE
*/
CLX_ERROR_NO_T
hal_io_addWbObj(
    HAL_IO_WB_DB_T      *ptr_db,
    UI32_T              obj_count,
    HAL_IO_OBJ_META_T   *ptr_objs);

/* FUNCTION NAME: hal_io_writeWbDb
*      The function is used to dump warmboot database to nonvolatile storage
* INPUT:
*      unit         -- Device unit
*      module       -- Module id
*      ptr_db       -- Pointer to the warmboot database
* OUTPUT:
*      NONE
* RETURN:
*      CLX_ERROR_NO_T
* NOTES:
*      NONE
*/
CLX_ERROR_NO_T
hal_io_writeWbDb(
    UI32_T          unit,
    CLX_MODULE_T    module,
    HAL_IO_WB_DB_T  *ptr_db);

/* FUNCTION NAME: hal_io_destroyWbDb
*      The function is used to destroy warmboot database
*      after dumping to nonvolatile storage
* INPUT:
*      ptr_db       -- Pointer to the warmboot database
* OUTPUT:
*      NONE
* RETURN:
*      NONE
* NOTES:
*      NONE
*/
void
hal_io_destroyWbDb(
    HAL_IO_WB_DB_T *ptr_db);

/* FUNCTION NAME: hal_io_readWbDb
*      The function is used to read warmboot database from nonvolatile storage
* INPUT:
*      unit         -- Device unit
*      module       -- Module id
* OUTPUT:
*      pptr_db      -- Pointer to the warmboot database
* RETURN:
*      CLX_ERROR_NO_T
* NOTES:
*      NONE
*/
CLX_ERROR_NO_T
hal_io_readWbDb(
    UI32_T          unit,
    CLX_MODULE_T    module,
    HAL_IO_WB_DB_T  **pptr_db);

/* FUNCTION NAME: hal_io_getWbObj
*      The function is used to get object from warmboot database
* INPUT:
*      ptr_db       -- Pointer to the warmboot database
*      obj_id       -- Object id
* OUTPUT:
*      ptr_obj      -- Object
* RETURN:
*      CLX_ERROR_NO_T
* NOTES:
*      It would try to find the best-matched object by obj_ver from wbdb.
*      If possible, it returns the object with obj_ver = CLX_WB_VER_RELEASE;
*      if not found, it returns the last object found with the same obj_id.
*/
CLX_ERROR_NO_T
hal_io_getWbObj(
    const HAL_IO_WB_DB_T *ptr_db,
    UI32_T               obj_id,
    HAL_IO_OBJ_META_T    *ptr_obj);

/* FUNCTION NAME: hal_io_getDbVer
*      The function is used to get currently loaded nonvolitile version
* INPUT:
*      unit         -- Device unit
* OUTPUT:
*      NONE
* RETURN:
*      db_ver       -- Currently loaded nonvolitile version
* NOTES:
*      NONE
*/
UI32_T
hal_io_getDbVer(
    UI32_T unit);

#endif  /* #ifndef HAL_IO_H */