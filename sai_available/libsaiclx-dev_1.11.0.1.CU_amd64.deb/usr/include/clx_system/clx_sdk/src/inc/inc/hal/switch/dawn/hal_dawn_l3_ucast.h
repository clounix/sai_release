/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_l3_ucast.h
* PURPOSE:
*      It provides hal l3 module API.
* NOTES:
*
*
*/

#ifndef HAL_DAWN_L3_UCAST_H
#define HAL_DAWN_L3_UCAST_H

/* INCLUDE FILE DECLARATIONS
*/
#include <clx_types.h>
#include <clx_error.h>
#include <clx_init.h>
#include <clx_l3.h>
#include <cdb/cdb.h>
#include <hal/common/hal.h>
#include <cmlib/cmlib_list.h>

/* NAMING CONSTANT DECLARATIONS
*/
/*****************************************************************************
 * IDS_RSLT_SRV_L3_INTF
 *****************************************************************************/
#define HAL_DAWN_L3_IDS_RSLT_SRV_L3_INTF_SIZE        (1U << 14)
#define HAL_DAWN_L3_IDS_RSLT_SRV_L3_INTF_ENTRY_NUM   (HAL_DAWN_L3_IDS_RSLT_SRV_L3_INTF_SIZE)

/*****************************************************************************
 * ILE_RSLT_VRF
 *****************************************************************************/
#define HAL_DAWN_L3_ILE_RSLT_VRF_SIZE                (1U << 13)
#define HAL_DAWN_L3_ILE_RSLT_VRF_ENTRY_NUM           (HAL_DAWN_L3_ILE_RSLT_VRF_SIZE)

/*****************************************************************************
 * IEV_RSLT_FRR_*
 *****************************************************************************/
#define HAL_DAWN_L3_FRR_INVALID_GRP_ID               (0xFFFF)

/*****************************************************************************
 * IEV_RSLT_ECMP_*
 *****************************************************************************/
#define HAL_DAWN_L3_IEV_RSLT_ECMP_PATH_ENCAP_IDX_MIN          (8192)

#define HAL_DAWN_L3_ECMP_PATH_MAX_TOT                         (1U << 13) /* act_tot = MAX      */
#define HAL_DAWN_L3_ECMP_PATH_MAX_TOT_IN_CHIP                 (0)        /* act_tot = 0        */
#define HAL_DAWN_L3_ECMP_HSH_MAX_TOT                          (1U << 15) /* sw_spray_tot = MAX */
#define HAL_DAWN_L3_ECMP_HSH_MAX_TOT_IN_CHIP                  (0)        /* sw_spray_tot = 0   */

#define HAL_DAWN_L3_ECMP_PATH_DFLT_BASE_IDX                   (16383)    /* default act_base or orig_base */
#define HAL_DAWN_L3_ECMP_PATH_DFLT_TOT                        (0)        /* default act_tot or orig_tot   */
#define HAL_DAWN_L3_ECMP_HSH_DFLT_BASE_IDX                    (32767)    /* default sw_spray_base         */
#define HAL_DAWN_L3_ECMP_HSH_DFLT_TOT                         (0)        /* default sw_spray_tot          */
#define HAL_DAWN_L3_ECMP_HSH_DFLT_OFFSET                      (8191)     /* default offset                */

#define HAL_DAWN_L3_ECMP_ET_ID_MAX                            (16384)
#define HAL_DAWN_L3_URPF_NUM                                  (16384)

/* Capacity and Usage */
#define HAL_DAWN_L3_PARAM_V4_V6                               (0)
#define HAL_DAWN_L3_PARAM_V4                                  (1)
#define HAL_DAWN_L3_PARAM_V6                                  (2)

typedef enum {
    HAL_DAWN_L3_ECMP_GRP_HW  = 0,
    HAL_DAWN_L3_ECMP_GRP_SW  = 1
} HAL_DAWN_L3_ECMP_GRP_ENUM_T;

/* MACRO FUNCTION DECLARATIONS
*/
#define HAL_DAWN_L3_GET_BIT(flags, bit)   ((((flags) & (bit)) > 0) ? 1 : 0)
#define HAL_DAWN_L3_SET_BIT(flags, bit)   ((flags) |= (bit))

/* VRF */
#define HAL_DAWN_L3_VRF_NUM(unit) \
    ((HAL_TBL_INFO(unit, TBL_ILE_RSLT_VRF_ID)->entry_max_number / 2)) /* ipv4 and ipv6 */
#define HAL_DAWN_L3_RSV_VRF_ID(unit) \
    ((HAL_TBL_INFO(unit, TBL_ILE_RSLT_VRF_ID)->entry_max_number / 2) - 1) /* {all 1}: HW defined for (*,IP) */
#define HAL_DAWN_L3_MAX_VRF_ID(unit) \
    ((HAL_TBL_INFO(unit, TBL_ILE_RSLT_VRF_ID)->entry_max_number / 2) - 2) /* {all 1} - 1 */

/* MyRouterMac */
#define HAL_DAWN_L3_MAX_MYROUTEMAC_IDX(unit) \
    ((HAL_TBL_INFO(unit, TBL_IDS_KEY_TCAM_MY_RTE_MAC_ID)->entry_max_number) - 1)

/* MTU */
#define HAL_DAWN_L3_MAX_MTU_SIZE(unit) \
    ((1U << ((HAL_TBL_INFO(unit, TBL_IDS_RSLT_L3_MTU_ID)->ptr_table_entry + IDS_RSLT_L3_MTU_MTU_FIELD_ID)->length)) - 1)

/* Interface */
#define HAL_DAWN_L3_INTF_ID_NUM(unit) \
    (HAL_TBL_INFO(unit, TBL_IDS_RSLT_SRV_L3_INTF_ID)->entry_max_number)
#define HAL_DAWN_L3_MIN_INTF_ID(unit) (1)
#define HAL_DAWN_L3_MAX_INTF_ID(unit) \
    (HAL_TBL_INFO(unit, TBL_IDS_RSLT_SRV_L3_INTF_ID)->entry_max_number - 2) /* {all 1}: HW defined for invalid */

/* ECMP */
#define HAL_DAWN_L3_ECMP_GRP_HW_MODE_FIELD_NUM                               10
#define HAL_DAWN_L3_GET_ECMP_GRP_HW_MODE_TBL_INFO(field)                     \
    do {                                                                    \
        field[0].field_id  = IEV_RSLT_ECMP_U_HW_TYP_FIELD_ID;               \
        field[0].value     = HAL_DAWN_L3_ECMP_GRP_HW;                        \
        field[1].field_id  = IEV_RSLT_ECMP_U_HW_DLB_EN_FIELD_ID;            \
        field[2].field_id  = IEV_RSLT_ECMP_U_HW_ET_EN_FIELD_ID;             \
        field[3].field_id  = IEV_RSLT_ECMP_U_HW_ET_IDX_FIELD_ID;            \
        field[4].field_id  = IEV_RSLT_ECMP_U_HW_ORIG_TOT_FIELD_ID;          \
        field[5].field_id  = IEV_RSLT_ECMP_U_HW_ORIG_LST_BASE_IDX_FIELD_ID; \
        field[6].field_id  = IEV_RSLT_ECMP_U_HW_ACT_TOT_FIELD_ID;           \
        field[7].field_id  = IEV_RSLT_ECMP_U_HW_ACT_LST_BASE_IDX_FIELD_ID;  \
        field[8].field_id  = IEV_RSLT_ECMP_U_HW_USE_ACT_ONLY_FIELD_ID;      \
        field[8].value     = 0;                                             \
        field[9].field_id  = IEV_RSLT_ECMP_U_HW_HSH_SEL_FIELD_ID;           \
    } while (0)

#define HAL_DAWN_L3_ECMP_GRP_SW_MODE_FIELD_NUM                               9
#define HAL_DAWN_L3_GET_ECMP_GRP_SW_MODE_TBL_INFO(field)                     \
    do {                                                                    \
        field[0].field_id  = IEV_RSLT_ECMP_U_SW_TYP_FIELD_ID;               \
        field[0].value     = HAL_DAWN_L3_ECMP_GRP_SW;                        \
        field[1].field_id  = IEV_RSLT_ECMP_U_SW_DLB_EN_FIELD_ID;            \
        field[2].field_id  = IEV_RSLT_ECMP_U_SW_ET_EN_FIELD_ID;             \
        field[3].field_id  = IEV_RSLT_ECMP_U_SW_ET_IDX_FIELD_ID;            \
        field[4].field_id  = IEV_RSLT_ECMP_U_SW_SW_SPRAY_TOT_FIELD_ID;      \
        field[5].field_id  = IEV_RSLT_ECMP_U_SW_SW_SPRAY_BASE_IDX_FIELD_ID; \
        field[6].field_id  = IEV_RSLT_ECMP_U_SW_ACT_TOT_FIELD_ID;           \
        field[7].field_id  = IEV_RSLT_ECMP_U_SW_ACT_LST_BASE_IDX_FIELD_ID;  \
        field[8].field_id  = IEV_RSLT_ECMP_U_SW_HSH_SEL_FIELD_ID;           \
    } while (0)

#define HAL_DAWN_L3_ECMP_PATH_EP_FIELD_NUM                                       7
#define HAL_DAWN_L3_GET_ECMP_PATH_EP_TBL_INFO(field)                             \
    do {                                                                        \
        field[0].field_id  = IEV_RSLT_ECMP_PATH_U_EP_L3_TYP_FIELD_ID;           \
        field[0].value     = HAL_ECMP_PATH_U_EP_L3;                             \
        field[1].field_id  = IEV_RSLT_ECMP_PATH_U_EP_L3_ADJ_IDX_FIELD_ID;       \
        field[2].field_id  = IEV_RSLT_ECMP_PATH_U_EP_L3_L3_INTF_ID_FIELD_ID;    \
        field[3].field_id  = IEV_RSLT_ECMP_PATH_U_EP_L3_SEG_VMID_VLD_FIELD_ID;  \
        field[4].field_id  = IEV_RSLT_ECMP_PATH_U_EP_L3_SEG_VMID_FIELD_ID;      \
        field[5].field_id  = IEV_RSLT_ECMP_PATH_U_EP_L3_EGID_MGID_FIELD_ID;     \
        field[6].field_id  = IEV_RSLT_ECMP_PATH_U_EP_L3_RATE_CNT_IDX_FIELD_ID;  \
    } while (0)

#define HAL_DAWN_L3_ECMP_PATH_UL_FIELD_NUM                                       7
#define HAL_DAWN_L3_GET_ECMP_PATH_UL_L3_TBL_INFO(field)                          \
    do {                                                                        \
        field[0].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L3_TYP_FIELD_ID;           \
        field[0].value     = HAL_ECMP_PATH_U_UL_L3;                             \
        field[1].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L3_ADJ_IDX_FIELD_ID;       \
        field[2].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L3_L3_INTF_ID_FIELD_ID;    \
        field[3].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L3_SEG_VLD_FIELD_ID;       \
        field[4].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L3_SEG_FIELD_ID;           \
        field[5].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L3_NVO3_ENCAP_IDX_FIELD_ID;\
        field[6].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L3_RATE_CNT_IDX_FIELD_ID;  \
    } while (0)

#define HAL_DAWN_L3_GET_ECMP_PATH_UL_L2_TBL_INFO(field)                          \
    do {                                                                        \
        field[0].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_TYP_FIELD_ID;           \
        field[0].value     = HAL_ECMP_PATH_U_UL_L2;                             \
        field[1].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_VID_CTL_VLD_FIELD_ID;   \
        field[2].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_VID_CTL_FIELD_ID;       \
        field[3].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_VID_1ST_FIELD_ID;       \
        field[4].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_VID_2ND_FIELD_ID;       \
        field[5].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_SEG_VLD_FIELD_ID;       \
        field[6].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_SEG_FIELD_ID;           \
        field[7].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_NVO3_ENCAP_IDX_FIELD_ID;\
        field[8].field_id  = IEV_RSLT_ECMP_PATH_U_UL_L2_RATE_CNT_IDX_FIELD_ID;  \
    } while (0)

#define HAL_DAWN_L3_ECMP_PATH_ENCAP_FIELD_NUM                                    2
#define HAL_DAWN_L3_GET_ECMP_PATH_ENCAP_TBL_INFO(field)                          \
    do {                                                                        \
        field[0].field_id  = IEV_RSLT_ECMP_PATH_ENCAP_NVO3_ENCAP_IDX_FIELD_ID;  \
        field[1].field_id  = IEV_RSLT_ECMP_PATH_ENCAP_RATE_CNT_IDX_FIELD_ID;    \
    } while (0)

/* Checker */
#define HAL_DAWN_L3_IS_DROP(ueid_mgid) \
    ((HAL_DROP_MIN <= ueid_mgid) && (ueid_mgid <= HAL_DROP_MAX))

#define HAL_DAWN_L3_IS_MCAST_ID(ueid_mgid) \
    ((HAL_MGID_MIN <= ueid_mgid) && (ueid_mgid <= HAL_MGID_MAX))

#define HAL_DAWN_L3_IS_ECMP_GRP(ueid_mgid) \
    ((HAL_ECMP_MIN <= ueid_mgid) && (ueid_mgid <= HAL_ECMP_MAX))

#define HAL_DAWN_L3_IS_FRR_GRP(ueid_mgid) \
    ((HAL_FRR_MIN <= ueid_mgid) && (ueid_mgid <= HAL_FRR_MAX))

#define HAL_DAWN_L3_IS_INVALID(ueid_mgid) \
    ((HAL_INVALID_MIN <= ueid_mgid) && (ueid_mgid <= HAL_INVALID_MAX))

#define HAL_DAWN_L3_IP_IS_MULTICAST(ptr_ip)                   \
    ((TRUE == (ptr_ip)->ipv4) ?                              \
        CLX_IPV4_IS_MULTICAST((ptr_ip)->ip_addr.ipv4_addr) : \
        CLX_IPV6_IS_MULTICAST((ptr_ip)->ip_addr.ipv6_addr))

#define HAL_DAWN_L3_IP_IS_ZERO(ptr_ip)               \
    ((TRUE == (ptr_ip)->ipv4) ?                     \
        (0x0 == (ptr_ip)->ip_addr.ipv4_addr) :      \
        (0x0 == (ptr_ip)->ip_addr.ipv6_addr[0] &&   \
         0 == osal_memcmp((ptr_ip)->ip_addr.ipv6_addr, (ptr_ip)->ip_addr.ipv6_addr + 1, 15)))

#define HAL_DAWN_L3_CHK_IP_VER_MATCH(ip1,ip2)        \
    do {                                            \
        if((ip1).ipv4 != (ip2).ipv4)                \
        {                                           \
            HAL_CHECK_ERROR(CLX_E_BAD_PARAMETER);   \
        }                                           \
    } while(0)

/* DATA TYPE DECLARATIONS
*/
typedef enum
{
    /* INTF */
    HAL_DAWN_L3_WBDB_ARRAY_INTF2FDID = 0,
    HAL_DAWN_L3_WBDB_ARRAY_FDID2INTF,
    /* VRF */
    HAL_DAWN_L3_WBDB_ARRAY_VRF_CP2CPU,
    HAL_DAWN_L3_WBDB_ARRAY_VRF_GROUP_LABEL,
    HAL_DAWN_L3_WBDB_ARRAY_GLOBAL_CP2CPU,
    /* ROUTE */
    HAL_DAWN_L3_WBDB_ARRAY_S_TCAM_BLOCK_INFO_FCOE_4X,
    HAL_DAWN_L3_WBDB_ARRAY_D_TCAM_BLOCK_INFO_FCOE_4X,
    HAL_DAWN_L3_WBDB_ARRAY_S_TCAM_BLOCK_INFO_IPV4_2X,
    HAL_DAWN_L3_WBDB_ARRAY_D_TCAM_BLOCK_INFO_IPV4_2X,
    HAL_DAWN_L3_WBDB_ARRAY_S_TCAM_INDIR,
    HAL_DAWN_L3_WBDB_ARRAY_D_TCAM_INDIR,
    HAL_DAWN_L3_WBDB_ARRAY_IPV4_HOST_CNT,
    HAL_DAWN_L3_WBDB_ARRAY_IPV6_HOST_CNT,
    HAL_DAWN_L3_WBDB_ARRAY_IPV4_ROUTE_CNT,
    HAL_DAWN_L3_WBDB_ARRAY_IPV6_ROUTE_CNT,
    HAL_DAWN_L3_WBDB_ARRAY_EXM_VRF_VLD,
    HAL_DAWN_L3_WBDB_ARRAY_EXM_V4_MSK_BTOT,
    HAL_DAWN_L3_WBDB_ARRAY_EXM_V6_MSK_BTOT,
    /* ADJ */
    HAL_DAWN_L3_WBDB_ARRAY_IEV_L3UC_DROP_IDX,
    HAL_DAWN_L3_WBDB_ARRAY_IEV_L3UC_TOCPU_IDX,
    HAL_DAWN_L3_WBDB_ARRAY_IEV_L2UC_DROP_IDX,
    /* ECMP */
    HAL_DAWN_L3_WBDB_ARRAY_ECMP_GRP_TYPE,
    HAL_DAWN_L3_WBDB_ARRAY_ECMP_GRP_USE_NUM,
    /* SW-ECMP */
    HAL_DAWN_L3_WBDB_ARRAY_SW_ECMP_PATH_BASE,
    HAL_DAWN_L3_WBDB_ARRAY_SW_ECMP_PATH_TOT,
    HAL_DAWN_L3_WBDB_ARRAY_SW_ECMP_PATH_USE_NUM,
    HAL_DAWN_L3_WBDB_ARRAY_SW_ECMP_PATH_BLOCK_SZ,
    HAL_DAWN_L3_WBDB_ARRAY_LAST

} HAL_DAWN_L3_WBDB_ARRAY_T;

typedef enum
{
    /* ROUTE */
    HAL_DAWN_L3_WBDB_AVL_FCOE = 0,
    HAL_DAWN_L3_WBDB_AVL_IPV4,
    HAL_DAWN_L3_WBDB_AVL_IPV6_2X,
    HAL_DAWN_L3_WBDB_AVL_IPV6_4X,
    /* ADJ */
    HAL_DAWN_L3_WBDB_AVL_ADJ,
    /* ECMP */
    HAL_DAWN_L3_WBDB_AVL_ECMP,
    HAL_DAWN_L3_WBDB_AVL_LAST

} HAL_DAWN_L3_WBDB_AVL_T;

typedef enum
{
    HAL_DAWN_L3_WBDB_MCAST_RPA_NODE = 0,
    HAL_DAWN_L3_WBDB_MCAST_URPF_USE_NUM,
    HAL_DAWN_L3_WBDB_MCAST_MET_BLOCK,
    HAL_DAWN_L3_WBDB_MCAST_MET_TYPE_NONE,
    HAL_DAWN_L3_WBDB_MCAST_MET_TYPE_LIST6,
    HAL_DAWN_L3_WBDB_MCAST_MET_TYPE_LIST12,
    HAL_DAWN_L3_WBDB_MCAST_LAST

} HAL_DAWN_L3_WBDB_MCAST_T;

#define HAL_DAWN_L3_WBDB_ARRAY_BASE  (0)
#define HAL_DAWN_L3_WBDB_AVL_BASE    (HAL_DAWN_L3_WBDB_ARRAY_LAST)
#define HAL_DAWN_L3_WBDB_MCAST_BASE  (HAL_DAWN_L3_WBDB_ARRAY_LAST + HAL_DAWN_L3_WBDB_AVL_LAST)
#define HAL_DAWN_L3_WBDB_NUM         (HAL_DAWN_L3_WBDB_ARRAY_LAST + HAL_DAWN_L3_WBDB_AVL_LAST + HAL_DAWN_L3_WBDB_MCAST_LAST)

/*****************************************************************************
 * SWDB of ADJ and ECMP Group
 *****************************************************************************/
typedef struct
{
    UI32_T              adj_id;         /* hw adjacency index */
    CLX_PORT_T          port;           /* interface object */
    UI32_T              iev_idx;
    CMLIB_LIST_T        *ptr_ecmp_list; /* ecmp group-id list */
    CMLIB_LIST_T        *ptr_frr_list;  /* frr group-id list of this backup adj */
    UI32_T              use_num;        /* reference count of host, route, ecmp, and frr */

} HAL_DAWN_L3_ADJ_NODE_T;

typedef struct
{
    UI32_T              grp_id;         /* hw ecmp group index */
    UI32_T              iev_idx;
    UI32_T              path_cnt;
    UI32_T              weight_cnt;
    UI32_T              weight_vld;     /* only update weight_cnt when this field is 1 */

} HAL_DAWN_L3_ECMP_NODE_T;

/*****************************************************************************
 * Function
 *****************************************************************************/
typedef CLX_ERROR_NO_T
(*HAL_DAWN_L3_ECMP_CALLBACK_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        adj_id,
    const UI32_T        ecmp_grp_id,
    const void          *ptr_cookie);

typedef CLX_ERROR_NO_T
(*HAL_DAWN_L3_FRR_CALLBACK_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        backup_adj_id,
    const UI32_T        frr_grp_id,
    const void          *ptr_cookie);

/*******************************************************************************/
/*  resource management api                                                    */
/*******************************************************************************/
/* FUNCTION NAME: hal_dawn_l3_fdid2intf
* PURPOSE:
*      The function is used to get the l3_intf by fdid
* INPUT:
*      unit           -- Device unit number
*      bdid           -- bd id.
* OUTPUT:
*      *ptr_intf_id   -- l3 interface id.
* RETURN:
*      CLX_E_OK            --  Operate success.
*      CLX_E_BAD_PARAMETER --  Bad parameter. The input sema_type is bad parameter.
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_dawn_l3_fdid2intf(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    UI32_T                          *ptr_intf_id);

/* FUNCTION NAME: hal_dawn_l3_intf2fdid
* PURPOSE:
*      The function is used to get the fdid by l3_intf
* INPUT:
*      unit           -- Device unit number
*      intf_id        -- l3 interface id.
* OUTPUT:
*      *ptr_bdid   -- vid/bd id.
* RETURN:
*      CLX_E_OK            --  Operate success.
*      CLX_E_BAD_PARAMETER --  Bad parameter. The input sema_type is bad parameter.
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_dawn_l3_intf2fdid(
    const UI32_T              unit,
    const UI32_T              intf_id,
    CLX_BRIDGE_DOMAIN_T       *ptr_bdid);

/* FUNCTION NAME:   hal_dawn_l3_getAdjInfo
 * PURPOSE:
 *   This API is used to get the adjacency SW information.
 * INPUT:
 *   unit       -- Device unit number.
 *   adj_id     -- Adjacency id.
 * OUTPUT:
 *   *ptr_adj_info   -- Adjacency SW information.
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_l3_getAdjInfo(
    const UI32_T            unit,
    const UI32_T            adj_id,
    HAL_L3_ADJ_INFO_T       *ptr_adj_info);

/* FUNCTION NAME:   hal_dawn_l3_getEcmpInfo
 * PURPOSE:
 *   This API is used to get IEV information for ECMP group.
 * INPUT:
 *   unit            -- Device unit number.
 *   ecmp_grp_id     -- Adjacency id.
 * OUTPUT:
 *   *ptr_ecmp_info  -- IEV information
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_l3_getEcmpInfo(
    const UI32_T            unit,
    const UI32_T            ecmp_grp_id,
    HAL_L3_ECMP_INFO_T      *ptr_ecmp_info);

/* FUNCTION NAME:   hal_dawn_l3_addFcoeTcamEntry
 * PURPOSE:
 *   This API is used to add fcoe tcam entry
 * INPUT:
 *   unit           -- Device unit number.
 *   is_vrf         -- Is intf_id or vrf_id
 *   intf_vrf_id    -- intf_id or vrf_id
 *   *ptr_fcid_addr -- Pointer of fcid_addr
 *   group_label    -- group label
 *   iev_rslt_idx   -- allocated iev_rslt_idx
 * OUTPUT:
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_l3_addFcoeTcamEntry(
    const UI32_T                    unit,
    const UI32_T                    is_vrf,
    const UI32_T                    intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T      *ptr_fcid_addr,
    const UI32_T                    group_label,
    const UI32_T                    iev_rslt_idx);

/* FUNCTION NAME:   hal_dawn_l3_delFcoeTcamEntry
 * PURPOSE:
 *   This API is used to delete fcoe tcam entry
 * INPUT:
 *   unit           -- Device unit number.
 *   is_vrf         -- Is intf_id or vrf_id
 *   intf_vrf_id    -- intf_id or vrf_id
 *   *ptr_fcid_addr -- Pointer of fcid_addr
 * OUTPUT:
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_l3_delFcoeTcamEntry(
    const UI32_T                    unit,
    const UI32_T                    is_vrf,
    const UI32_T                    intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T      *ptr_fcid_addr);

/* FUNCTION NAME:   hal_dawn_l3_getFcoeTcamEntry
 * PURPOSE:
 *   This API is used to get fcoe tcam entry
 * INPUT:
 *   unit           -- Device unit number.
 *   is_vrf         -- Is intf_id or vrf_id
 *   intf_vrf_id    -- intf_id or vrf_id
 *   *ptr_fcid_addr -- Pointer of fcid_addr
 * OUTPUT:
 *   *ptr_group_label   -- Group_label for CIA
 *   *ptr_iev_rslt_idx  -- The allocated iev rslt idx, should set in tcam entry as result
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_l3_getFcoeTcamEntry(
    const UI32_T                    unit,
    const UI32_T                    is_vrf,
    const UI32_T                    intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T      *ptr_fcid_addr,
    UI32_T                          *ptr_group_label,
    UI32_T                          *ptr_iev_rslt_idx);

/* FUNCTION NAME:   hal_dawn_l3_addIpMcTcamEntry
 * PURPOSE:
 *   This API is used to add IP MC tcam entry
 * INPUT:
 *   unit           -- Device unit number.
 *   vrf_id         -- Virtual Routing Forwarding ID
 *   *ptr_ip_addr     -- IP address, the key of IP tcam entry
 *   iev_rslt_idx   -- The allocated iev rslt idx, should set in tcam entry as result
 * OUTPUT:
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_l3_addIpMcTcamEntry(
    const UI32_T                    unit,
    const UI32_T                    vrf_id,
    const CLX_L3_IP_NETWORK_ADDR_T  *ptr_ip_addr,
    const UI32_T                    iev_rslt_idx);

/* FUNCTION NAME:   hal_dawn_l3_delIpMcTcamEntry
 * PURPOSE:
 *   This API is used to del IP tcam entry
 * INPUT:
 *   unit           -- Device unit number.
 *   vrf_id         -- Virtual Routing Forwarding ID
 *   *ptr_ip_addr   -- IP address, the key of IP tcam entry
 * OUTPUT:
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_l3_delIpMcTcamEntry(
    const UI32_T                    unit,
    const UI32_T                    vrf_id,
    const CLX_L3_IP_NETWORK_ADDR_T  *ptr_ip_addr);

/* FUNCTION NAME:   hal_dawn_l3_getIpMcTcamEntry
 * PURPOSE:
 *   This API is used to get IP tcam entry
 * INPUT:
 *   unit           -- Device unit number.
 *   vrf_id         -- Virtual Routing Forwarding ID
 *   *ptr_ip_addr   -- IP address, the key of IP tcam entry
 * OUTPUT:
 *   *ptr_iev_rslt_idx   -- The allocated iev rslt idx, should set in tcam entry as result
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_dawn_l3_getIpMcTcamEntry(
    const UI32_T                    unit,
    const UI32_T                    vrf_id,
    const CLX_L3_IP_NETWORK_ADDR_T  *ptr_ip_addr,
    UI32_T                          *ptr_iev_rslt_idx);

/********************************************************
*  multiplex API
********************************************************/

/* FUNCTION NAME: hal_dawn_l3_init
* PURPOSE:
*      The function is used to init L3 module
* INPUT:
*      unit           -- Device unit number
* OUTPUT:
*      None
* RETURN:
*      CLX_E_OK            --  Operate success.
*      CLX_E_BAD_PARAMETER --  Bad parameter.
*      CLX_E_OTHERS        --  Other error
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_dawn_l3_init(
    const UI32_T         unit);

/* FUNCTION NAME: hal_dawn_l3_deinit
* PURPOSE:
*      The function is used to de init L3 module.
* INPUT:
*      unit           -- Device unit number
* OUTPUT:
*      None
* RETURN:
*      CLX_E_OK            --  Operate success.
*      CLX_E_BAD_PARAMETER --  Bad parameter.
*      CLX_E_OTHERS        --  Other error
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_dawn_l3_deinit(
    const UI32_T         unit);

/* FUNCTION NAME:     hal_dawn_l3_addIntf
* PURPOSE:
*        Create interface based on VLAN or Bridge Domain.
* INPUT:
*        unit              --  Device unit number
*        bdid              --  Bridge Domain ID
*        ptr_l3_intf       -- The Interface information
* OUTPUT:
*        ptr_l3_intf->intf_id
* RETURN:
*        CLX_E_OK               --  Operate success.
*        CLX_E_BAD_PARAMETER    --  Bad parameter.
*        CLX_E_TABLE_FULL       --  Hardware table is full, entry can't be added.
*        CLX_E_NO_MEMORY        --  No available memory
* NOTES:
*  User needs to create bridge domain by this BD ID firstly,
*  otherwise, interface cannot work correctly.
*/
CLX_ERROR_NO_T
hal_dawn_l3_addIntf(
    const UI32_T                     unit,
    const CLX_BRIDGE_DOMAIN_T        bdid,
    CLX_L3_INTF_INFO_T               *ptr_l3_intf);

/* FUNCTION NAME:     hhal_dawn_l3_delIntf
* PURPOSE:
*        Delete interface based on VLAN or Bridge Domain.
* INPUT:
*        unit                 --   Device unit number
*        bdid                 --   Bridge Domain ID
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK               --  Operate success.
*        CLX_E_BAD_PARAMETER    --  Bad parameter.
*        CLX_E_NO_MEMORY        --  No available memory
*        CLX_E_ENTRY_NOT_FOUND  --  The specified interface has not been created
* NOTES:
*        NONE.
*/
CLX_ERROR_NO_T
hal_dawn_l3_delIntf(
    const UI32_T                      unit,
    const CLX_BRIDGE_DOMAIN_T         bdid);

/* FUNCTION NAME:     hal_dawn_l3_getIntf
* PURPOSE:
*        Get interface information according to specified VLAN ID or BD ID.
* INPUT:
*        unit               --  Device unit number
*        bdid               --  Bridge Domain ID
* OUTPUT:
*        ptr_l3_intf        --  Interface property, including Interface ID, MAC, VRF ID, MTU, URPF check mode and etc
* RETURN:
*        CLX_E_OK                --  Operate success.
*        CLX_E_BAD_PARAMETER     --  Bad parameter.
*        CLX_E_NO_MEMORY         --  No available memory
*        CLX_E_ENTRY_NOT_FOUND   --  The specified interface has not been created
* NOTES:
*   This API is used get the interface property according to the specified interface ID.
*   User must create interface first.
*   If the IP network address bound to this interface cannot be obtained, user needs
*   to use clx_l3_getHost and clx_l3_getRoute to get the host and route entry added.
*/
CLX_ERROR_NO_T
hal_dawn_l3_getIntf(
    const UI32_T                     unit,
    const CLX_BRIDGE_DOMAIN_T        bdid,
    CLX_L3_INTF_INFO_T               *ptr_l3_intf);

/* FUNCTION NAME:     hal_dawn_l3_traverseIntf
 * PURPOSE:
 *        get all Adjaciences.
 * INPUT:
 *        unit                 -- Device unit number
 *        callback             -- Callback function provided by user, user can do self
 *                                action to every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_traverseIntf(
    const UI32_T                        unit,
    const CLX_L3_INTF_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);

/* FUNCTION NAME: hal_dawn_l3_setOptionHeaderAction
 * PURPOSE:
 *      This API is used to set the action for the packet with option header.
 * INPUT:
 *      unit  -- Device unit number.
 *      action  -- Refer to CLX_FWD_ACTION_T.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  operate success.
 *      CLX_E_BAD_PARAMETER --  bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_setOptionHeaderAction(
    const UI32_T                        unit,
    const CLX_L3_OPTION_HEADER_INFO_T   action);

/* FUNCTION NAME: hal_dawn_l3_getOptionHeaderAction
 * PURPOSE:
 *      This API is used to get the action for the packet with option header.
 * INPUT:
 *      unit  -- Device unit number.
 *      port_id  -- Port ID.
 * OUTPUT:
 *      ptr_action  -- Refer to CLX_FWD_ACTION_T.
 * RETURN:
 *      CLX_E_OK --  operate success.
 *      CLX_E_BAD_PARAMETER --  bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_getOptionHeaderAction(
    const UI32_T                    unit,
    CLX_L3_OPTION_HEADER_INFO_T     *ptr_action);

/* FUNCTION NAME:   hal_dawn_l3_addAdj
 * PURPOSE:
 *   This API is used to add/set an adjacency.
 * INPUT:
 *   unit           --  Device unit number.
 *   *ptr_adj_info  --  Adjacency information.
 * OUTPUT:
 *   *ptr_adj_id    -- Adjacency id.
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *  This API is used to add/set an adjacency for a host, route or ecmp group.
 *  If the ptr_adj_info->flags & CLX_L3_ADJ_FLAGS_WITH_ID is 0, means add a new adjacency,
 *  and the *ptr_adj_id will be the returned value. Otherwise, set an existing adjacency,
 *  and the *ptr_adj_id will be the inputted value.
 *  Only support set frr_backup_path and frr_state_id.
 */
CLX_ERROR_NO_T
hal_dawn_l3_addAdj(
    const UI32_T                unit,
    const CLX_L3_ADJ_INFO_T     *ptr_adj_info,
    UI32_T                      *ptr_adj_id);

/* FUNCTION NAME:   hal_dawn_l3_delAdj
 * PURPOSE:
 *   This API is used to delete an adjacency.
 * INPUT:
 *   unit       -- Device unit number.
 *   adj_type   -- Adjacency type.
 *   adj_id     -- Adjacency id.
 * OUTPUT:
 *   None
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_dawn_l3_delAdj(
    const UI32_T            unit,
    const CLX_L3_ADJ_TYPE_T adj_type,
    const UI32_T            adj_id);

/* FUNCTION NAME:   hal_dawn_l3_getAdj
 * PURPOSE:
 *   This API is used to get the adjacency information.
 * INPUT:
 *   unit       -- Device unit number.
 *   adj_id     -- Adjacency id.
 * OUTPUT:
 *   *ptr_adj_info   -- Adjacency information.
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *   None.
 */
CLX_ERROR_NO_T
hal_dawn_l3_getAdj(
    const UI32_T        unit,
    const UI32_T        adj_id,
    CLX_L3_ADJ_INFO_T   *ptr_adj_info);

/* FUNCTION NAME:     hal_dawn_l3_traverseAdj
 * PURPOSE:
 *        get all Adjacencies.
 * INPUT:
 *        unit                 -- Device unit number
 *        adj_type             -- Adjacency type.
 *        callback             -- Callback function provided by user, user can do self
 *                                action to every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_traverseAdj(
    const UI32_T                        unit,
    const CLX_L3_ADJ_TYPE_T             adj_type,
    const CLX_L3_ADJ_TRAVERSE_FUNC_T    callback,
    void                                *ptr_cookie);

/* FUNCTION NAME: hal_dawn_l3_createFrrStateId
 * PURPOSE:
 *       This API is used to
 * INPUT:
 *       unit           -- Device unit number
 *       type           --
 *       state_id       --
 *
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_createFrrStateId(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    UI32_T                              *ptr_state_id);

/* FUNCTION NAME:   hal_dawn_l3_destroyFrrStateId
 * PURPOSE:
 *       This API is used to get "for PIM register IP subnet" by specified VRF.
 * INPUT:
 *       unit           -- Device unit number
 *       type           --
 *       state_id       --
 *
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_destroyFrrStateId(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id);

/* FUNCTION NAME:  hal_dawn_l3_setFrrState
 * PURPOSE:
 *       This API is used to
 * INPUT:
 *       unit           -- Device unit number
 *       type           --
 *       state_id       --
 *       link_up        --
 *
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_setFrrState(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id,
    const BOOL_T                        link_up);


/* FUNCTION NAME:   hal_dawn_l3_getFrrState
 * PURPOSE:
 *       This API is used to
 * INPUT:
 *       unit           -- Device unit number
 *       type           --
 *       state_id       --
 *       ptr_link_up    --
 *
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_getFrrState(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id,
    BOOL_T                              *ptr_link_up);

/* FUNCTION NAME:     hal_dawn_l3_addHost
* PURPOSE:
*        add an l3_host entry for uc ipv4/ipv6 local route
* INPUT:
*        unit            -- Device unit number
*        ptr_host_info   --  l3_host info, include ip addr, vrf-id, adj, etc.
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_addHost(
    const UI32_T                    unit,
    const CLX_L3_HOST_INFO_T        *ptr_host_info);


/* FUNCTION NAME:     hal_dawn_l3_delHost
* PURPOSE:
*        delete an l3_host entry for uc ipv4/ipv6 local route
* INPUT:
*        unit                  -- Device unit number
*        ptr_host_info      --  include l3_host's key
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_delHost(
    const UI32_T                   unit,
    const CLX_L3_HOST_INFO_T       *ptr_host_info);


/* FUNCTION NAME:     hal_dawn_l3_getHost
* PURPOSE:
*        get an l3_host entry for uc ipv4/ipv6 local route
* INPUT:
*        unit           -- Device unit number
*        ptr_host_info  -- include l3_host's key
* OUTPUT:
*        ptr_host_info  -- l3_host info, include ip addr, vrf-id, adj, etc.
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getHost(
    const UI32_T                   unit,
    CLX_L3_HOST_INFO_T             *ptr_host_info);


/* FUNCTION NAME:     hal_dawn_l3_traverseHost
* PURPOSE:
*        This API used for get all host entry
* INPUT:
*        unit                 -- Device unit number
*        callback             -- Callback function user provided by user, user can do self
*                                action for every node data in this callback function.
*        ptr_cookie           -- User cookie data as input parameter of callback function
* OUTPUT:
*        ptr_cookie           -- User cookie data as output parameter of callback function.
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_traverseHost(
    const UI32_T                        unit,
    const CLX_L3_HOST_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);

/* FUNCTION NAME:     hal_dawn_l3_addSubnetBcast
* PURPOSE:
*        add an subnet broadcast entry for uc route
* INPUT:
*        unit             -- Device unit number
*        ptr_subnet_info  -- Subnet Broadcast information
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_addSubnetBcast(
    const UI32_T                        unit,
    const CLX_L3_SUBNET_BCAST_INFO_T    *ptr_subnet_info);

/* FUNCTION NAME:     hal_dawn_l3_delSubnetBcast
* PURPOSE:
*        delete an subnet broadcast entry for uc route
* INPUT:
*        unit             -- Device unit number
*        ptr_subnet_info  -- Subnet Broadcast information
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_delSubnetBcast(
    const UI32_T                        unit,
    const CLX_L3_SUBNET_BCAST_INFO_T    *ptr_subnet_info);

/* FUNCTION NAME:     hal_dawn_l3_getSubnetBcast
* PURPOSE:
*        get an subnet broadcast entry for uc route
* INPUT:
*        unit             -- Device unit number
*        ptr_subnet_info  -- Subnet Broadcast information
* OUTPUT:
*        ptr_subnet_info  -- Subnet Broadcast information
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getSubnetBcast(
    const UI32_T                        unit,
    CLX_L3_SUBNET_BCAST_INFO_T          *ptr_subnet_info);

/* FUNCTION NAME:     hal_dawn_l3_addMyRouterMac
* PURPOSE:
*        add my router mac, need specify l3_interface_id and mac address and mask
* INPUT:
*        unit           --    Device unit number
*        index          --     hardware access index
*        router_mac_info--     myRouterMAC information,mac/mac mask/ifidx/ifidx mask
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_addMyRouterMac(
    const UI32_T                      unit,
    const UI32_T                      index,
    const CLX_L3_ROUTER_MAC_INFO_T    *ptr_router_mac_info);

/* FUNCTION NAME:     hal_dawn_l3_delMyRouterMac
* PURPOSE:
*        set my router mac, need specify l3_interface_id and mac address and mask
* INPUT:
*        unit           --    Device unit number
*        index          --     hardware   access index
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_delMyRouterMac(
    const UI32_T               unit,
    const UI32_T               index);

/* FUNCTION NAME:     hal_dawn_l3_getMytRouterMac
* PURPOSE:
*        test whether the router mac has exist in myroutermac table
* INPUT:
*        unit       --    Device unit number
*        index      --     hardware TCAM  access index
* OUTPUT:
*        router_mac_info--     myRouterMAC information,mac/mac mask/ifidx/ifidx mask
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getMyRouterMac(
    const UI32_T               unit,
    const UI32_T               index,
    CLX_L3_ROUTER_MAC_INFO_T   *ptr_router_mac_info);

/* FUNCTION NAME:     hal_dawn_l3_setPktHandlingPerVrf
* PURPOSE:
*        set the per vrf packet handling action; including l3 lookup miss action,
*        ttl=0, ttl=1, meter, counter, group_label and fall_back_en.
* INPUT:
*        unit              -- Device unit number
*        vrf_id           -- vrf-id
*        pkt_handling  --packet handling configuration
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_setPktHandlingPerVrf(
    const UI32_T                       unit,
    const UI32_T                       vrf_id,
    const CLX_L3_VRF_INFO_T            *ptr_pkt_handling);

/* FUNCTION NAME:     hal_dawn_l3_getPktHandlingPerVrf
* PURPOSE:
*        get the per vrf packet handling action; including l3 lookup miss action,
*        ttl=0, ttl=1, meter, counter, group_label and fall_back_en.
* INPUT:
*        unit          -- Device unit number
*        vrf_id       -- vrf-id
* OUTPUT:
*        pkt_handling  --packet handling configuration
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getPktHandlingPerVrf(
    const UI32_T                       unit,
    const UI32_T                       vrf_id,
    CLX_L3_VRF_INFO_T                  *ptr_pkt_handling);

/* FUNCTION NAME:     hal_dawn_l3_updateAdjUseNum
* PURPOSE:
*        increase/decrease the adj user
* INPUT:
*        unit                  -- Device unit number
*        adj_id                -- Adjacency id.
*        increase              -- The adj user increase/decrease
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_updateAdjUseNum(
    const UI32_T                  unit,
    const UI32_T                  adj_id,
    const BOOL_T                  increase);

/* FUNCTION NAME:     hal_dawn_l3_updateEcmpGrpUseNum
* PURPOSE:
*        increase/decrease the ecmp group user
* INPUT:
*        unit                  -- Device unit number
*        ecmp_grp_id           -- specify group id to set
*        increase              -- The ecmp group user increase/decrease
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_updateEcmpGrpUseNum(
    const UI32_T                  unit,
    const UI32_T                  ecmp_grp_id,
    const BOOL_T                  increase);

/* FUNCTION NAME:     hal_dawn_l3_createEcmpGrp
* PURPOSE:
*        create ecmp route group
* INPUT:
*        unit                              -- Device unit number
*        ptr_ecmp_grp_info.hash_mode       -- specify hw mode or sw mode, optional, default is hw mode
*        ptr_ecmp_grp_info.sw_hash_val_cnt -- sw mode val cnt, optional, default 0
*        ptr_ecmp_grp_info.dlb             -- optional, default dlb disabled
*
* OUTPUT:
*        ptr_ecmp_grp_id   -- ecmp group tbl index allocated
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_createEcmpGrp(
    const UI32_T                   unit,
    const CLX_L3_ECMP_GRP_INFO_T   *ptr_ecmp_grp_info,
    UI32_T                         *ptr_ecmp_grp_id);


/* FUNCTION NAME:     hal_dawn_l3_setEcmpGrp
* PURPOSE:
*        set ecmp group
* INPUT:
*        unit                  -- Device unit number
*        ecmp_grp_id           -- specify group id to set
*        ptr_route_info        -- l3_ecmp_grp information, include key of route
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_setEcmpGrp(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_GRP_INFO_T    *ptr_ecmp_grp_info);

/* FUNCTION NAME:     hal_dawn_l3_delEcmpGrp
* PURPOSE:
*        del ecmp group, will delete all path
* INPUT:
*        unit                  -- Device unit number
*        ecmp_grp_id           -- specify group id to delete
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_delEcmpGrp(
    const UI32_T                    unit,
    const CLX_L3_OUTPUT_TYPE_T      type,
    const UI32_T                    ecmp_grp_id);

/* FUNCTION NAME:     hal_dawn_l3_getEcmpGrp
* PURPOSE:
*        get an ecmp route's adjacency
* INPUT:
*        unit               -- Device unit number
*        ecmp_grp_id        -- specify group id to get
*        ptr_ecmp_grp_info  -- specify ecmp group id
* OUTPUT:
*        ptr_ecmp_grp_info  --  ecmp gourp information
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getEcmpGrp(
    const UI32_T                   unit,
    const UI32_T                   ecmp_grp_id,
    CLX_L3_ECMP_GRP_INFO_T         *ptr_ecmp_grp_info);

/* FUNCTION NAME:     hal_dawn_l3_traverseEcmpGrp
 * PURPOSE:
 *        get all ECMP groups.
 * INPUT:
 *        unit                 -- Device unit number
 *        type                 -- ECMP group type.
 *        callback             -- Callback function provided by user, user can do self
 *                                action to every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_traverseEcmpGrp(
    const UI32_T                            unit,
    const CLX_L3_OUTPUT_TYPE_T              type,
    const CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T   callback,
    void                                    *ptr_cookie);

/* FUNCTION NAME:     hal_dawn_l3_addEcmpGrpPath
* PURPOSE:
*        add a path to specify ecmp group
* INPUT:
*        unit                 -- Device unit number
*        ecmp_grp_id          -- specify group id
*        ptr_ecmp_path_info   -- ECMP path information
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_addEcmpGrpPath(
    const UI32_T                   unit,
    const UI32_T                   ecmp_grp_id,
    const CLX_L3_ECMP_PATH_INFO_T  *ptr_ecmp_path_info);

/* FUNCTION NAME:     hal_dawn_l3_delEcmpGrpPath
* PURPOSE:
*        delete an specify nexthop of  ecmp route
* INPUT:
*        unit                    -- Device unit number
*        ptr_ecmp_grp_info       -- ECMP group information
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_delEcmpGrpPath(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info) ;

/* FUNCTION NAME:     hal_dawn_l3_getEcmpGrpPathByIdx
* PURPOSE:
*        get an ecmp route's adjacency
* INPUT:
*        unit               -- Device unit number
*        path_idx           -- path index
*        ptr_ecmp_grp_info  -- specify ecmp grp id
* OUTPUT:
*        ptr_ecmp_grp_info  -- return the ECMP group information
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getEcmpGrpPathByIdx(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const UI32_T                    path_idx,
    CLX_L3_ECMP_PATH_INFO_T         *ptr_ecmp_path_info);

/* FUNCTION NAME:     hal_dawn_l3_setEcmpGrpHashPath
* PURPOSE:
*        set the specify entry :  hash_val_list (per entry)
* INPUT:
*        unit            -- Device unit number
*        hash_val_list  -- hash_val need to config
*        ptr_ecmp_hash_info  --  next hop address  and group-id
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_setEcmpGrpHashPath(
    const UI32_T                     unit,
    const UI32_T                     ecmp_grp_id,
    const UI32_T                     *ptr_hash_val_list,
    const UI32_T                     hash_val_cnt,
    const CLX_L3_ECMP_PATH_INFO_T    *ptr_ecmp_path_info);

/* FUNCTION NAME:     hal_dawn_l3_getEcmpGrpHashPath
* PURPOSE:
*        get the specify entry :  hash_val (per entry)
* INPUT:
*        unit            -- Device unit number
*        hash_val     -- specify hash_val
*        ptr_ecmp_hash_info    --  specify the group-id
* OUTPUT:
*        ptr_ecmp_hash_info    --  ip_nexthop_addr
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getEcmpGrpHashPath(
    const UI32_T                     unit,
    const UI32_T                     ecmp_grp_id,
    const UI32_T                     hash_val_cnt,
    const CLX_L3_ECMP_PATH_INFO_T    *ptr_ecmp_path_info,
    UI32_T                           *ptr_actual_hash_val_cnt,
    UI32_T                           *ptr_hash_val_list);

/* FUNCTION NAME:     hal_dawn_l3_setIcmpRedirect
* PURPOSE:
*        set ICMP redirect enable or disable (global)
*        if enabled, a copy of packet will send to cpu
* INPUT:
*        unit               -- Device unit number
*        is_enable          -- TRUE: icmp redirect enable, FALSE: icmp redirect disable
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_setIcmpRedirect(
    const UI32_T                       unit,
    const UI32_T                       is_enable);

/* FUNCTION NAME:     hal_dawn_l3_getIcmpRedirect
* PURPOSE:
*        get ICMP redirect enable or disable (global)
*        if enabled, a copy of packet will send to cpu
* INPUT:
*        unit              -- Device unit number
* OUTPUT:
*        ptr_is_enable     -- TRUE: icmp redirect enable, FALSE: icmp redirect disable
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getIcmpRedirect(
    const UI32_T                 unit,
    UI32_T                       *ptr_is_enable);

/* FUNCTION NAME:     hal_dawn_l3_setSelfForward
* PURPOSE:
*        set allow_self_forward enable or disable (global)
*       (when egress intf==ingress intf, the original packet will forward)
* INPUT:
*        unit            -- Device unit number
*        is_enable       -- TRUE: allow self_forward, FALSE: not allow self_forward
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_setSelfForward(
    const UI32_T                    unit,
    const UI32_T                    is_enable);

/* FUNCTION NAME:     hal_dawn_l3_getSelfForward
* PURPOSE:
*        get allow_self_forward enable or disable (global)
*       (when egress intf==ingress intf, the original packet will forward)
* INPUT:
*        unit              -- Device unit number
* OUTPUT:
*        ptr_is_enable     -- TRUE: allow self_forward, FALSE: not allow self_forward
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getSelfForward(
    const UI32_T                 unit,
    UI32_T                       *ptr_is_enable);

/* FUNCTION NAME: hal_dawn_l3_setBfdInfo
* PURPOSE:
*      The function is used to config bfd system config info.
* INPUT:
*      unit           -- Device unit number
*      ptr_bfd_info   -- bfd system config, refer to CLX_L3_BFD_INFO_T
* OUTPUT:
*      None
* RETURN:
*      CLX_E_OK            --  Operate success.
*      CLX_E_BAD_PARAMETER --  Bad parameter.
*      CLX_E_OTHERS        --  Other error
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_dawn_l3_setBfdInfo(
    const UI32_T                unit,
    const CLX_L3_BFD_INFO_T     *ptr_bfd_info);

/* FUNCTION NAME: hal_dawn_l3_getBfdInfo
* PURPOSE:
*      The function is used to get bfd system config info
* INPUT:
*      unit           -- Device unit number
* OUTPUT:
*      ptr_bfd_info   -- bfd system config info, refer to CLX_L3_BFD_INFO_T.
* RETURN:
*      CLX_E_OK            --  Operate success.
*      CLX_E_BAD_PARAMETER --  Bad parameter.
*      CLX_E_OTHERS        --  Other error
* NOTES:
*      NONE.
*/
CLX_ERROR_NO_T
hal_dawn_l3_getBfdInfo(
    const UI32_T        unit,
    CLX_L3_BFD_INFO_T   *ptr_bfd_info);

/* FUNCTION NAME:     hal_dawn_l3_addRoute
* PURPOSE:
*        add an route entry for uc route
* INPUT:
*        unit           -- Device unit number
*        ptr_route_info -- Route information
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_addRoute(
    const UI32_T                       unit,
    const CLX_L3_ROUTE_INFO_T          *ptr_route_info);

/* FUNCTION NAME:     hal_dawn_l3_delRoute
* PURPOSE:
*        delete an route entry for uc route
* INPUT:
*        unit           -- Device unit number
*        ptr_route_info -- Route information
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_delRoute(
    const UI32_T                    unit,
    const CLX_L3_ROUTE_INFO_T       *ptr_route_info);

/* FUNCTION NAME:     hal_dawn_l3_getRoute
* PURPOSE:
*        get an route entry for uc route
* INPUT:
*        unit           -- Device unit number
*        ptr_route_info -- Route information
* OUTPUT:
*        ptr_route_info -- Route information
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getRoute(
    const UI32_T            unit,
    CLX_L3_ROUTE_INFO_T     *ptr_route_info);

/* FUNCTION NAME:     hal_dawn_l3_traverseRoute
* PURPOSE:
*        This API is used to get all Route entries.
* INPUT:
*        unit                 -- Device unit number
*        callback             -- Callback function provided by user, user can do self
*                                action to every node data in this callback function.
*        ptr_cookie           -- User cookie data as input parameter of callback function
* OUTPUT:
*        ptr_cookie           -- User cookie data as output parameter of callback function
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_traverseRoute(
    const UI32_T                        unit,
    const CLX_L3_ROUTE_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

/* FUNCTION NAME:     hal_dawn_l3_setGlobalRouteMissAction
* PURPOSE:
*        set global_route miss action
* INPUT:
*        unit         -- Device unit number
*        action       -- Refer to CLX_FWD_ACTION_T.
*                     -- For this case, only support CLX_FWD_ACTION_DROP and CLX_FWD_ACTION_REDIRECT_TO_CPU
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_setGlobalRouteMissAction(
    const UI32_T unit,
    const UI32_T action);

/* FUNCTION NAME:     hal_dawn_l3_getGlobalRouteMissAction
* PURPOSE:
*        get global_route miss action
* INPUT:
*        unit         -- Device unit number
* OUTPUT:
*        *ptr_action  -- Refer to CLX_FWD_ACTION_T.
*                     -- For this case, only support CLX_FWD_ACTION_DROP and CLX_FWD_ACTION_REDIRECT_TO_CPU
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_OTHERS --  Get action error.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getGlobalRouteMissAction(
    const UI32_T    unit,
    UI32_T          *ptr_action);

/* FUNCTION NAME:     hal_dawn_l3_setUrpfCheck
* PURPOSE:
*        set global urpf check enable or disable (global)
* INPUT:
*        unit            -- Device unit number
*        is_enable       -- 1: urpf check enabled, 0: urpf check disabled
* OUTPUT:
*        None
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_setUrpfCheck(
    const UI32_T                    unit,
    const UI32_T                    is_enable);

/* FUNCTION NAME:     hal_dawn_l3_getUrpfCheck
* PURPOSE:
*        get global urpf check enable or disable (global)
* INPUT:
*        unit            -- Device unit number
* OUTPUT:
*        ptr_is_enable   -- 1: urpf check enabled, 0: urpf check disabled
* RETURN:
*        CLX_E_OK --  Operate success.
*        CLX_E_BAD_PARAMETER --  Bad parameter.
* NOTES:
*
*/
CLX_ERROR_NO_T
hal_dawn_l3_getUrpfCheck(
    const UI32_T                 unit,
    UI32_T                       *ptr_is_enable);

/* FUNCTION NAME:   hal_dawn_l3_addVrrp
 * PURPOSE:
 *       This API is used to add a VRRP entry.
 * INPUT:
 *       unit           -- Device unit number
 *       vrid           -- Vritual router identifier (VRID)
 *       bdid           -- Bridge Domain ID
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 *       CLX_E_TABLE_FULL    --  Table full.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_addVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

/* FUNCTION NAME:   hal_dawn_l3_delVrrp
 * PURPOSE:
 *       This API is used to delete a VRRP entry.
 * INPUT:
 *       unit           -- Device unit number
 *       vrid           -- Vritual router identifier (VRID)
 *       bdid           -- Bridge Domain ID
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_delVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

/* FUNCTION NAME:   hal_dawn_l3_getVrrp
 * PURPOSE:
 *       This API is used to check VRRP entry exist or not.
 * INPUT:
 *       unit           -- Device unit number
 *       vrid           -- Vritual router identifier (VRID)
 *       bdid           -- Bridge Domain ID
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_getVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

/* FUNCTION NAME:   hal_dawn_l3_addEcmpList
 * PURPOSE:
 *       This API is used to add ecmp_grp_id to adj_node's ecmp_grp_list.
 * INPUT:
 *       grp_id         -- ecmp group id
 *       ptr_ecmp_list  -- adj_node's ecmp_grp_list
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_addEcmpList(
    const UI32_T grp_id,
    CMLIB_LIST_T *ptr_ecmp_list);

/* FUNCTION NAME:   hal_dawn_l3_delEcmpList
 * PURPOSE:
 *       This API is used to delete ecmp_grp_id from adj_node's ecmp_grp_list.
 * INPUT:
 *       grp_id         -- ecmp group id
 *       ptr_ecmp_list  -- adj_node's ecmp_grp_list
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_delEcmpList(
    const UI32_T grp_id,
    CMLIB_LIST_T *ptr_ecmp_list);

/* FUNCTION NAME:   hal_dawn_l3_addFrrList
 * PURPOSE:
 *       This API is used to add adj_id to adj_node's frr_adj_list.
 * INPUT:
 *       adj_id         -- adj id
 *       ptr_frr_list   -- adj_node's frr_adj_list
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_addFrrList(
    const UI32_T        adj_id,
    CMLIB_LIST_T        *ptr_frr_list);

/* FUNCTION NAME:   hal_dawn_l3_delFrrList
 * PURPOSE:
 *       This API is used to delete adj_id from adj_node's frr_adj_list.
 * INPUT:
 *       adj_id         -- adj id
 *       ptr_frr_list   -- adj_node's frr_adj_list
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_delFrrList(
    const UI32_T        adj_id,
    CMLIB_LIST_T        *ptr_frr_list);

/* FUNCTION NAME:   hal_dawn_l3_getPathIdxByGrpAdjId
 * PURPOSE:
 *       This API is used to get iev_ecmp_path_idx by ecmp_grp_id and adj_id.
 * INPUT:
 *       unit           -- Device unit number
 *       ecmp_grp_id    -- ecmp group id
 *       output_type    -- l3_adj or nvo3_adj
 *       adj_id         -- adj id
 * OUTPUT:
 *       ptr_act_idx    -- act-list index to IEV_RSLT_ECMP_PATH_U_EP_L3
 *       ptr_act_cnt    -- act-list index count
 *       ptr_orig_idx   -- orig-list index to IEV_RSLT_ECMP_PATH_U_EP_L3
 *       ptr_orig_cnt   -- orig-list index count
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_getPathIdxByGrpAdjId(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_OUTPUT_TYPE_T      output_type,
    const UI32_T                    adj_id,
    UI32_T                          *ptr_act_idx,
    UI32_T                          *ptr_act_cnt,
    UI32_T                          *ptr_orig_idx,
    UI32_T                          *ptr_orig_cnt);

/* FUNCTION NAME:   hal_dawn_l3_updateAdjToEcmp
 * PURPOSE:
 *       This API is used to update all related ecmp_path in ecmp_grp when adj is updated.
 * INPUT:
 *       unit           -- Device unit number
 *       ptr_ecmp_list  -- adj_node's ecmp_grp_list
 *       adj_id         -- adj_id which is updated
 *       ptr_cookie     -- cookie needed when update
 *       callback       -- callback function to be applied to all nodes in the list
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_updateAdjToEcmp(
    const UI32_T                    unit,
    CMLIB_LIST_T                    *ptr_ecmp_list,
    const UI32_T                    adj_id,
    void                            *ptr_cookie,
    HAL_DAWN_L3_ECMP_CALLBACK_FUNC_T callback);

/* FUNCTION NAME:   hal_dawn_l3_updateAdjToFrr
 * PURPOSE:
 *       This API is used to update all related backup adj in frr_adj_list when adj is updated.
 * INPUT:
 *       unit           -- Device unit number
 *       ptr_frr_list   -- adj_node's frr_adj_list
 *       adj_id         -- adj_id which is updated
 *       ptr_cookie     -- cookie needed when update
 *       callback       -- callback function to be applied to all nodes in the list
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
hal_dawn_l3_updateAdjToFrr(
    const UI32_T                    unit,
    CMLIB_LIST_T                    *ptr_frr_list,
    const UI32_T                    adj_id,
    void                            *ptr_cookie,
    HAL_DAWN_L3_FRR_CALLBACK_FUNC_T  callback);

/* FUNCTION NAME:   hal_dawn_l3_getCapacity
 * PURPOSE:
 *      Get resource capacity
 * INPUT:
 *      unit            -- Device unit number
 *      type            -- Resource type
 *      param           -- Parameter if necessary
 * OUTPUT:
 *      ptr_size        -- Size of capacity
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_getCapacity(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_size);

/* FUNCTION NAME:   hal_dawn_l3_getUsage
 * PURPOSE:
 *     Get resource usage.
 * INPUT:
 *      unit            -- Device unit number
 *      type            -- Resource type
 *      param           -- Parameter if necessary
 * OUTPUT:
 *      ptr_cnt         -- Count of usage
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_getUsage(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_l3_setL3ExcptAct
 * PURPOSE:
 *     Set L3 exceptions.
 * INPUT:
 *      unit            -- Device unit number
 *      property        -- Property type
 *      action          -- Action
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      Apply to the following exceptions:
 *      - EXCPT_IEV_L3_IPV4_MC_MISS
 *      - EXCPT_IEV_L3_IPV6_MC_MISS
 *      - EXCPT_IEV_L3_SW_FWD_IPV4 (l3_excpt_sw_fwd)
 *      - EXCPT_IEV_L3_SW_FWD_IPV6 (l3_excpt_sw_fwd)
 *      - EXCPT_IDS_L3_MTU
 *      - EXCPT_IEV_L3_MTU (l3_excpt_mtu)
 *      - EXCPT_EMI_L3_MTU
 *      - EXCPT_IEV_L3_IPV4_TTL_0 (l3_excpt_ttl)
 *      - EXCPT_IEV_L3_IPV6_TTL_0 (l3_excpt_ttl)
 *      - EXCPT_IEV_L3_IPV4_MC_BRIDGED_CP_TTL_0
 *      - EXCPT_IEV_L3_IPV6_MC_BRIDGED_CP_TTL_0
 *      - EXCPT_IEV_L3_IPV4_TTL_1 (l3_excpt_ttl)
 *      - EXCPT_IEV_L3_IPV6_TTL_1 (l3_excpt_ttl)
 *      - EXCPT_EMI_L3_IPV4_TTL_1
 *      - EXCPT_EMI_L3_IPV6_TTL_1
 */
CLX_ERROR_NO_T
hal_dawn_l3_setL3ExcptAct(
    const UI32_T                unit,
    const CLX_SWC_PROPERTY_T    property,
    const CLX_FWD_ACTION_T      action);

/* FUNCTION NAME:   hal_dawn_l3_getL3ExcptAct
 * PURPOSE:
 *     Get L3 exceptions.
 * INPUT:
 *      unit            -- Device unit number
 *      property        -- Property type
 * OUTPUT:
 *      *ptr_action     -- Pointer of action
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      Apply to the following exceptions:
 *      - EXCPT_IEV_L3_IPV4_MC_MISS
 *      - EXCPT_IEV_L3_IPV6_MC_MISS
 *      - EXCPT_IEV_L3_SW_FWD_IPV4 (l3_excpt_sw_fwd)
 *      - EXCPT_IEV_L3_SW_FWD_IPV6 (l3_excpt_sw_fwd)
 *      - EXCPT_IDS_L3_MTU
 *      - EXCPT_IEV_L3_MTU (l3_excpt_mtu)
 *      - EXCPT_EMI_L3_MTU
 *      - EXCPT_IEV_L3_IPV4_TTL_0 (l3_excpt_ttl)
 *      - EXCPT_IEV_L3_IPV6_TTL_0 (l3_excpt_ttl)
 *      - EXCPT_IEV_L3_IPV4_MC_BRIDGED_CP_TTL_0
 *      - EXCPT_IEV_L3_IPV6_MC_BRIDGED_CP_TTL_0
 *      - EXCPT_IEV_L3_IPV4_TTL_1 (l3_excpt_ttl)
 *      - EXCPT_IEV_L3_IPV6_TTL_1 (l3_excpt_ttl)
 *      - EXCPT_EMI_L3_IPV4_TTL_1
 *      - EXCPT_EMI_L3_IPV6_TTL_1
 */
CLX_ERROR_NO_T
hal_dawn_l3_getL3ExcptAct(
    const UI32_T                unit,
    const CLX_SWC_PROPERTY_T    property,
    CLX_FWD_ACTION_T            *ptr_action);

/* FUNCTION NAME:   hal_dawn_l3_setEcmpBlockSize
 * PURPOSE:
 *      Set Ecmp block size.
 * INPUT:
 *      unit        -- Device unit number
 *      size        -- Ecmp block size
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_setEcmpBlockSize(
    const UI32_T    unit,
    const UI32_T    size);

/* FUNCTION NAME:   hal_dawn_l3_getEcmpBlockSize
 * PURPOSE:
 *      Get Ecmp block size.
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      *ptr_size       -- Pointer of block size
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_getEcmpBlockSize(
    const UI32_T    unit,
    UI32_T          *ptr_size);

/* FUNCTION NAME: hal_dawn_l3_dumpSwdb
 * PURPOSE:
 *      Dump L3 software DB
 * INPUT:
 *      unit            -- Device unit number.
 *      flags           -- Dump flags.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_OTHERS            -- Operation fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_l3_dumpSwdb(
    const UI32_T    unit,
    const UI32_T    flags);

#endif  /* End of HAL_DAWN_L3_UCAST_H */
