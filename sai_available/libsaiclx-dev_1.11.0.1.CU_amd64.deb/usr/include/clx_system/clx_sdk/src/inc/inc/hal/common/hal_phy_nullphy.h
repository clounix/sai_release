/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_phy_nullphy.h
 * PURPOSE:
 *      It provide NULLPHY API.
 * NOTES:
 *
 */
#ifndef HAL_PHY_NULLPHY_H
#define HAL_PHY_NULLPHY_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <hal/common/hal_phy.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct
{
    HAL_PHY_ADMIN_STATE_TYPE_T  admin_state;
    HAL_PHY_SPEED_TYPE_T        speed;
    HAL_PHY_EEE_TYPE_T          eee;
    HAL_PHY_EEE_MODE_TYPE_T     eee_mode;
    HAL_PHY_FEC_TYPE_T          fec;
    HAL_PHY_LOOPBACK_TYPE_T     loopback;
    HAL_PHY_PMA_INTF_TYPE_T     pma_intf;
    HAL_PHY_PMD_INTF_TYPE_T     pmd_intf;
    HAL_PHY_ANLT_TYPE_T         anlt;
    HAL_PHY_AN_RE_AN_TYPE_T     an_re_an;
    HAL_PHY_AN_SPEED_TYPE_T     an_speed;
    HAL_PHY_AN_EEE_TYPE_T       an_eee;
    HAL_PHY_AN_FEC_TYPE_T       an_fec;
    HAL_PHY_AN_FC_TYPE_T        an_fc;
    HAL_PHY_AN_DUPLEX_TYPE_T    an_duplex;
    HAL_PHY_AN_RF_TYPE_T        an_rf;
    I32_T                       temperature;
    HAL_PHY_PRBS_PATTERN_TYPE_T prbs_pattern;
    HAL_PHY_PRBS_CHECKER_TYPE_T prbs_checker;
} HAL_PHY_NULLPHY_SW_DB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* FUNCTION NAME:   hal_phy_nullphy_init
 * PURPOSE:
 *      Init the null PHY drive per unit
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_nullphy_init(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_phy_nullphy_deinit
 * PURPOSE:
 *      Deinit the null PHY drive per unit
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_nullphy_deinit(
    const UI32_T    unit);

#endif /* End of HAL_PHY_NULLPHY_H */
