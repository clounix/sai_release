/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_telm.h
 * PURPOSE:
 *      It provides hal Dataplane telemetry module module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_LIGHTNING_TELM_H
#define HAL_LIGHTNING_TELM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_telm.h>
#include <clx_port.h>
#include <clx_swc.h>
#include <clx_tm.h>
#include <hal/common/hal_tbl.h>
#include <hal/common/hal.h>
#include <hal/common/hal_const_cmn.h>
#include <osal/osal_dma.h>
#include <cmlib/cmlib_queue.h>
#include <hal/common/hal_phy.h>
#include <hal/switch/lightning/hal_lightning_tm.h>
#include <hal/switch/lightning/hal_lightning_tm_buf.h>
#include <sys/time.h>
/* NAMING CONSTANT DECLARATIONS
 */


/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* port hash index */
#define HAL_TELM_IFA_CHECK_PORT_INVALID(port_id)        (((port_id) & 0x80000000) != 0)
#define HAL_TELM_IFA_SET_PORT_INVALID(port_id)          ((port_id) |= 0x80000000)
#define HAL_TELM_IFA_CLEAR_PORT_INVALID(port_id)        ((port_id) & 0x7FFFFFFF)
#define HAL_TELM_IFA_GET_PORT_ID(port_id)               ((port_id) & 0xFFF)
#define HAL_TELM_IFA_SET_PORT_ID(port_id, value)        ((port_id) = (((port_id) & 0xFFFFF000) | ((value) & 0xFFF)))

#define HAL_PKT_SKB_RESV_IFA_MD_LEN (32)
#define HAL_TELM_PKT_POOL_BUF_SIZE (4096)
#define DEMO_PKT_POOL_BUF_BLOCKS (256)
#define HAL_PKT_RX_BUF_LEN (HAL_TELM_PKT_POOL_BUF_SIZE - HAL_PKT_SKB_RESV_IFA_MD_LEN)
/* max 8 core in DUT, max 8 threads */
#define IFA_PKT_QUEUE_MAX (8)
#define IFA_PKT_QUEUE_LEN (2048)

#define IFA_SEND_THREAD_PRI                       (80)
#define IFA_SEND_THREAD_STACK                     (64 * 1024)

#define IFA_TC_QUEUE_MAPPING_MAX_NUM              (16)

/* congestion may occur when port's packet sending rate approaches the port's maximum rate */
#define IFA_PORT_RATR_DROP_PROB                   (80)

/* send pkt and then sleep  */
#define IFA_PORT_SEND_PKT_BULK_NUM                (400)
#define IFA_PORT_SEND_PKT_BULK_SLEEP_US           (10)

#define IFA_R2T_LOOPBACK_TX_RETRY_MAX             (3)
#define IFA_R2T_LOOPBACK_TX_RETRY_PERIOD          (10)  /* 10us */

#define IFA_GET_QUEUE_DEF_DELAY_US                (100) /* 100us */

struct pseudo_header_ipv4 {
    UI32_T src_addr;
    UI32_T dest_addr;
    UI8_T zero;
    UI8_T protocol;
    UI16_T length;
};

struct pseudo_header_ipv6 {
    UI8_T src_addr[16];
    UI8_T dest_addr[16];
    UI32_T length;
    UI8_T zero[3];
    UI8_T next_header;
};

typedef enum {
    /* port speed. 0: 10G;  1: 25G; 2: 40G; 3: 50G; 4:100G; 5:200G; 6:400G */
    HAL_LIGHTNING_TELM_IFA_SPEED_10G = 0,
    HAL_LIGHTNING_TELM_IFA_SPEED_25G,
    HAL_LIGHTNING_TELM_IFA_SPEED_40G,
    HAL_LIGHTNING_TELM_IFA_SPEED_50G,
    HAL_LIGHTNING_TELM_IFA_SPEED_100G,
    HAL_LIGHTNING_TELM_IFA_SPEED_200G,
    HAL_LIGHTNING_TELM_IFA_SPEED_400G,
    HAL_LIGHTNING_TELM_IFA_SPEED_800G,
    HAL_LIGHTNING_TELM_IFA_SPEED_LAST
} HAL_LIGHTNING_TELM_IFA_SPEED_T;

typedef enum
{
    HAL_LIGHTNING_TELM_WBDB_IFA_CB,
    HAL_LIGHTNING_TELM_WBDB_LAST,
} HAL_LIGHTNING_TELM_WBDB_T;

typedef struct HAL_LIGHTNING_TELM_IFA_S
{
    UI32_T                          ip_prot;                            /* IFA protocol type in IPv4/v6 header */
    UI32_T                          node_id;                            /* node_id in metadata, set rwi_slv */
    UI32_T                          lcl_namespace;                      /* local namespace in metadata */
    UI32_T                          occupancy_delay_us[CLX_PORT_NUM];   /* support per port get queue depth sleep us */
    UI32_T                          bulk_send_num;                      /* bulk send num */
    UI32_T                          bulk_send_sleep_us;                 /* bulk send sleep us */
    CLX_THREAD_ID_T                 task_id;
    CLX_TM_HANDLER_T                tc_queue_mapping[IFA_TC_QUEUE_MAPPING_MAX_NUM];
    CLX_TM_WRED_QUEUE_CFG_T         port_wred_cfg[CLX_PORT_NUM][HAL_LIGHTNING_TM_LEGACY_QUEUE_NUM];
    CLX_TM_WRED_ENTRY_T             wred_profile[HAL_LIGHTNING_TM_WRED_PROFILE_ID_MAX][CLX_COLOR_LAST];
    HAL_LIGHTNING_TELM_IFA_SPEED_T  ifa_speed[CLX_PORT_NUM];
}HAL_LIGHTNING_TELM_IFA_T;

typedef struct HAL_LIGHTNING_TELM_CB_S
{
    CLX_SEMAPHORE_ID_T  telm_sema;
    /* ifa configuration saved in sw memory */
    HAL_LIGHTNING_TELM_IFA_T telm_ifa_cfg;
} HAL_LIGHTNING_TELM_CB_T;

extern HAL_LIGHTNING_TELM_CB_T _hal_telm_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

// #if defined(CLX_EN_BIG_ENDIAN)
typedef struct HAL_LIGHTNING_TELM_IFA_MD_S
{
    UI32_T      lns:4;
    UI32_T      dev_id:20;
    UI32_T      ip_ttl:8;

    UI32_T      egress_port_speed:4;
    UI32_T      congestion:2;
    UI32_T      queue_id:6;
    UI32_T      rx_timestamp_sec:20;

    UI32_T      egress_port:16;
    UI32_T      ingress_port:16;

    UI32_T      rx_timestamp_ns;

    UI32_T      residence_time_ns;

    UI32_T      queue_tx_byte_count;

    UI32_T      queue_tx_byte_count_h16:16;
    UI32_T      queue_depth:16;

    UI32_T      device_id;
}__attribute__ ((packed)) HAL_LIGHTNING_TELM_IFA_MD_T;

typedef struct HAL_LIGHTNING_TELM_IFA_PKT_QUEUE_S
{
    CMLIB_QUEUE_T                   *ptr_id;
    CLX_SEMAPHORE_ID_T              sema;
    UI32_T                          len;      /* Software CPU queue maximum length.        */
    UI32_T                          weight;   /* The weight for thread de-queue algorithm. */
} HAL_LIGHTNING_TELM_IFA_PKT_QUEUE_T;

typedef struct HAL_LIGHTNING_TELM_IFA_PKT_STAT_S {
    UI64_T input_pkts;
    UI64_T output_pkts;
    UI64_T failed_output_pkts;
    UI64_T failed_enqueue_times;
    UI64_T output_drop_pkts;
}HAL_LIGHTNING_TELM_IFA_PKT_STAT_T;

extern HAL_LIGHTNING_TELM_IFA_PKT_QUEUE_T  hal_lightning_ifa_pkt_queue[];
extern HAL_LIGHTNING_TELM_IFA_PKT_STAT_T hal_lightning_ifa_pkts_stats[];
extern struct timeval g_tm_occupancyDelay[];
extern CLX_TM_BUF_OCCUPANCY_T g_occupancy[CLX_PORT_NUM][HAL_LIGHTNING_TM_LEGACY_QUEUE_NUM];

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */


CLX_ERROR_NO_T
hal_lightning_telm_setIfaCfg(const UI32_T unit, const CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

CLX_ERROR_NO_T
hal_lightning_telm_getIfaCfg(const UI32_T unit, CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

CLX_ERROR_NO_T
hal_lightning_telm_initIfa(const UI32_T unit);

CLX_ERROR_NO_T
hal_lightning_telm_deinitIfa(const UI32_T unit);

CLX_ERROR_NO_T hal_lightning_telm_prepareIfaTxPkt(const UI32_T unit,
                                        const CLX_PKT_RX_PKT_T *ptr_rx_pkt,
                                        void *ptr_cookie);

void *hal_lightning_telm_ifa_dmaAllocRxPkt(void);

CLX_ERROR_NO_T hal_lightning_telm_ifa_dmaFreePkt(const void *ptr_dma_mem);

CLX_ERROR_NO_T
hal_lightning_telm_setPortSpeed(const UI32_T unit, const UI32_T port, const HAL_PHY_SPEED_TYPE_T port_speed);

CLX_ERROR_NO_T
hal_lightning_telm_setTcQueueMapping(const UI32_T unit, const UI32_T tc, CLX_TM_HANDLER_T handler_id);

CLX_ERROR_NO_T
hal_lightning_telm_setWredQueueConfig(const UI32_T unit, const UI32_T port,  UI32_T queue_id, const CLX_TM_WRED_QUEUE_CFG_T *ptr_wred_cfg);

CLX_ERROR_NO_T
hal_lightning_telm_setWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    const CLX_TM_TRAFFIC_TYPE_T             type,
    const CLX_COLOR_T                       color,
    const CLX_TM_WRED_ENTRY_T               *ptr_entry);

CLX_ERROR_NO_T hal_lightning_telm_ifa_sendTaskInit(UI32_T unit, UI32_T port);
CLX_ERROR_NO_T hal_lightning_telm_ifa_sendTaskDeinit(UI32_T unit, UI32_T port);
CLX_ERROR_NO_T hal_lightning_telm_deCfgPkt(UI32_T unit);
CLX_ERROR_NO_T hal_lightning_telm_cfgPkt(UI32_T unit);
void hal_lightning_telm_showIfaStat(UI32_T port, UI32_T clear_en);

void hal_lightning_telm_ifa_txCb(const UI32_T unit, const void *ptr_pkt, void *ptr_cookie);

CLX_ERROR_NO_T
hal_lightning_telm_getPortSpeed(const UI32_T unit, const UI32_T port, HAL_LIGHTNING_TELM_IFA_SPEED_T *ptr_ifa_speed);

CLX_ERROR_NO_T
hal_lightning_telm_getTcQueueMapping(const UI32_T unit, const UI32_T tc, CLX_TM_HANDLER_T *ptr_handler_id);

CLX_ERROR_NO_T
hal_lightning_telm_getWredQueueConfig(const UI32_T unit, const UI32_T port, UI32_T queue_id, CLX_TM_WRED_QUEUE_CFG_T *ptr_wred_cfg);

CLX_ERROR_NO_T
hal_lightning_telm_getWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    const CLX_TM_TRAFFIC_TYPE_T             type,
    const CLX_COLOR_T                       color,
    CLX_TM_WRED_ENTRY_T                     *ptr_entry);

CLX_ERROR_NO_T
hal_lightning_telm_ifa_enQueuePkt(
    HAL_LIGHTNING_TELM_IFA_PKT_QUEUE_T  *ptr_que,
    void                    *ptr_data);

#endif /*end of HAL_LIGHTNING_TELM_H*/
