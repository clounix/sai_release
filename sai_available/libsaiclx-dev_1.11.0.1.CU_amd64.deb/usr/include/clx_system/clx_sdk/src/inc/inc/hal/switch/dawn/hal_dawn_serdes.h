/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_serdes.h
 * PURPOSE:
 *      It provide HAL_DAWN_SERDES module API.
 * NOTES:
 *
 */
#ifndef HAL_DAWN_SERDES_H
#define HAL_DAWN_SERDES_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct
{
    C8_T    *ptr_field_name;
    UI32_T table_id;
    UI32_T filed_id;
    UI32_T lane_offset;
} TECH_DUMP_REG_PHY_ENTRY_T;

typedef struct
{
    C8_T                     *ptr_phy_name;
    UI32_T                   table_total_fields;
    TECH_DUMP_REG_PHY_ENTRY_T *ptr_phy_entry;
} TECH_DUMP_REG_PHY_T;

typedef struct
{
    C8_T    *ptr_field_name;
    UI32_T base_addr;
    UI32_T macro_offset;
    UI32_T lane_offset;
    UI32_T length;
} TECH_DUMP_MEM_PHY_ENTRY_T;

typedef struct
{
    C8_T                     *ptr_phy_name;
    UI32_T                   table_total_fields;
    TECH_DUMP_MEM_PHY_ENTRY_T *ptr_phy_entry;
} TECH_DUMP_MEM_PHY_T;

typedef struct
{
    C8_T                     *ptr_phy_name;
    UI32_T                   table_total_fields;
    TECH_DUMP_REG_PHY_ENTRY_T *ptr_phy_entry;
} TECH_DUMP_COEF_PHY_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEthxMem(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEthcMem(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEthxReg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEthcReg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEthxCoef(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEthcCoef(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEthxMsgq(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEthcMsgq(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_dawn_serdes_dumpEyeBER(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_cnt);

CLX_ERROR_NO_T
hal_dawn_serdes_drawEyeScan(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_cnt);

#endif   /* End of HAL_DAWN_SERDES_H */