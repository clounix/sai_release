/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_cmn_drv.h
 * PURPOSE:
 *  Provide HAL common driver structure and API for HAL exported API.
 *
 * NOTES:
 */

#ifndef HAL_CMN_DRV_H
#define HAL_CMN_DRV_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_stat.h>
#include <clx_dtel.h>
#include <hal/common/hal_ifmon.h>
#include <hal/common/hal_tm.h>
#include <hal/common/hal_tm_pol.h>
#include <hal/common/hal_tm_buf.h>
#include <hal/common/hal_tm_sch.h>
#include <hal/common/hal_l3.h>
#include <hal/common/hal_cmn.h>
#include <hal/common/hal_pkt_rsrc.h>
#include <hal/common/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* vlan multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_VLAN_SETKEEPDEI_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_VLAN_GETKEEPDEI_FUNC_T) (
    const UI32_T    unit,
    UI32_T          *ptr_enable);

/* ifmon multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_LOCKDATA_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_UNLOCKDATA_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_LOCKFLOW_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_UNLOCKFLOW_FUNC_T) (
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_GETLINK_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_link);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_GETFAULT_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_fault);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_GETSPEED_FUNC_T) (
    const UI32_T        unit,
    const UI32_T        port,
    CLX_PORT_SPEED_T    *ptr_speed);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_ADDMOCLORT_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_DELMOCLORT_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_RECORDTIME_FUNC_T) (
    const UI32_T              unit,
    const HAL_IFMON_TIME_T    time_type);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_UPDATESWSTATE_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_updated);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_IFMON_DUMPLINKSTATE_FUNC_T) (
    const UI32_T    unit);

/* tm multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETPMSTATE_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_DIR_T           dir,
    const   UI32_T              enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETPMSPEED_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_PORT_SPEED_T    speed);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_POL_SETPROPERTY_FUNC_T) (
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   HAL_TM_EPM_PROPERTY_T       property,
    const   UI32_T                      data);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_POL_GETEPMBUFFEREMPTY_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_GETTSRXENTRY_FUNC_T) (
    const UI32_T                unit,
    const UI32_T                port,
    CLX_PORT_TS_ENTRY_T         *ptr_ts_entry);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETTSRXSTATE_FUNC_T) (
    const UI32_T                unit,
    const UI32_T                port,
    const UI32_T                enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_UPDATETSRXLATENCY_FUNC_T) (
    const UI32_T                unit,
    const UI32_T                port,
    const UI32_T                latency);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_RESETEPMBUFFER_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              lane_num);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_GETLANENUM_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_lane_num);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETSTATE_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_DIR_T           dir,
    const   UI32_T              all_queue,
    const   CLX_TM_HANDLER_T    handler,
    const   UI32_T              enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETSPEED_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_PORT_SPEED_T    speed);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETSTEERING_ENABLE_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_GETSTEERING_ENABLE_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETSTEERING_FUNC_T) (
    const UI32_T                    unit,
    const CLX_SWC_STEERING_ENTRY_T  *ptr_str_entry);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_GETSTEERING_FUNC_T) (
    const UI32_T                    unit,
    CLX_SWC_STEERING_ENTRY_T        *ptr_str_entry);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_CONFIGTDM_FUNC_T) (
    const   UI32_T              unit);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_UPDATEPORTTDM_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              lane_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETSTACKINGPORT_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_UPDATEPORTSTATUS_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const HAL_TM_SC_T                   status);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETFLOWCTRLMODE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const HAL_TM_FC_T                   mode);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_GETFLOWCTRLMODE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    HAL_TM_FC_T                         *mode);

typedef CLX_ERROR_NO_T \

(*HAL_CMN_TM_GETIOSPAUSEMODE_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    HAL_TM_FC_T                         *mode);

typedef CLX_ERROR_NO_T \

(*HAL_CMN_TM_GETAOPEMPTY_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SCH_SETPORTEEE_FUNC_T) (
    const UI32_T                            unit,
    const UI32_T                            port,
    const HAL_TM_EEE_MODE_T                 mode);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SCH_GETPORTEEE_FUNC_T) (
    const UI32_T                            unit,
    const UI32_T                            port,
    HAL_TM_EEE_MODE_T                       *ptr_mode);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETCUTTHROUGH_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_GETCUTTHROUGH_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETPORTLANECNT_FUNC_T) (
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              cnt);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_POL_GETLBSEMPTY_FUNC_T) (
    const   UI32_T                  unit,
    const   UI32_T                  port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_DEINITPORTFLOW_FUNC_T) (
    const   UI32_T                  unit,
    const   UI32_T                  port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SCH_FLUSHQUEUE_FUNC_T) (
    const UI32_T            unit,
    const UI32_T            port,
    const UI32_T            flush_all,
    const CLX_TM_HANDLER_T  handler,
    const UI32_T            enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_POL_SETIOSFLUSH_FUNC_T) (
    const   UI32_T                  unit,
    const   UI32_T                  port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_CHECKHEALTHMON_FUNC_T) (
    const   UI32_T                  unit,
    const   UI32_T                  port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_POL_SETDROPERROR_FUNC_T) (
    const UI32_T        unit,
    const UI32_T        port,
    const UI32_T        enable);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_DUMPREGPORTSTATE_FUNC_T) (
    const UI32_T        unit,
    const UI32_T        port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_SETPFCWDINTERVAL_FUNC_T)(
    const UI32_T        unit,
    const UI32_T        interval);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_TM_GETPFCWDINTERVAL_FUNC_T)(
    const UI32_T        unit,
    UI32_T              *ptr_interval);

/* MPLS multiplexing functions */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_MPLS_SETSKIPMPLS_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    value);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_MPLS_GETSKIPMPLS_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_value);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_MPLS_SETDELMPLS_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    value);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_MPLS_GETDELMPLS_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_value);

/* stat multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_STAT_GETTMCNT_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_STAT_TM_CNT_TYPE_T        type,
    CLX_STAT_TM_CNT_T                   *ptr_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_STAT_CLEARTMCNT_FUNC_T) (
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_STAT_TM_CNT_TYPE_T        type);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_STAT_GETRSERRDISTCNT)(
    const UI32_T                            unit,
    const UI32_T                            port,
    HAL_STAT_RSERRDIST_CNT_ENTRY_T          *ptr_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_STAT_CLEARRSERRDISTCNT)(
    const UI32_T                            unit,
    const UI32_T                            port);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_STAT_SETRSERRDISTCNTINTERVAL)(
    const UI32_T                            unit,
    const UI32_T                            interval);

typedef CLX_ERROR_NO_T
(*HAL_CMN_STAT_GETPORTRATETYPE_FUNC_T)(
    const UI32_T                     unit,
    const CLX_STAT_PORT_CNT_TYPE_T   type,
    CLX_STAT_RATE_TYPE_T             *rate_type);

/* l3 multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_FDID2INTF_FUNC_T)(
    const UI32_T                unit,
    const CLX_BRIDGE_DOMAIN_T   bdid,
    UI32_T                      *ptr_intf_id);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_INTF2FDID_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                intf_id,
    CLX_BRIDGE_DOMAIN_T         *ptr_bdid);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_SETGLOBALROUTEMISSACTION_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                action);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETGLOBALROUTEMISSACTION_FUNC_T)(
    const UI32_T                unit,
    UI32_T                      *ptr_action);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETADJINFO_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                adj_id,
    HAL_L3_ADJ_INFO_T           *ptr_adj_info);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETECMPINFO_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    HAL_L3_ECMP_INFO_T          *ptr_ecmp_info);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_UPDATEADJUSENUM_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                adj_id,
    const BOOL_T                inc);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_UPDATEECMPGRPUSENUM_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const BOOL_T                inc);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETPATHIDXBYGRPADJID_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const CLX_L3_OUTPUT_TYPE_T  output_type,
    const UI32_T                adj_id,
    UI32_T                      *ptr_act_idx,
    UI32_T                      *ptr_act_cnt,
    UI32_T                      *ptr_orig_idx,
    UI32_T                      *ptr_orig_cnt);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_SETECMPBLOCKSIZE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                size);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETECMPBLOCKSIZE_FUNC_T)(
    const UI32_T                unit,
    UI32_T                      *ptr_size);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_ADDFCOETCAMENTRY_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr,
    const UI32_T                group_label,
    const UI32_T                iev_rslt_idx);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_DELFCOETCAMENTRY_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETFCOETCAMENTRY_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                is_vrf,
    const UI32_T                intf_vrf_id,
    const CLX_FCOE_FCID_ADDR_T  *ptr_fcid_addr,
    UI32_T                      *ptr_group_label,
    UI32_T                      *ptr_iev_rslt_idx);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_DELMEMBERALL_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_ADDMELSUBENTRYBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T  *ptr_sub_entry);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_DELMELSUBENTRYBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T  *ptr_sub_entry);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETMELSUBENTRYBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    const UI32_T                        entry_num,
    HAL_L3_MCAST_MEL_SUB_ENTRY_T        *ptr_sub_entry,
    UI32_T                              *ptr_actual_num);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETMELSUBENTRYNUMBYPORT_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        mcast_id,
    const UI32_T                        port_id,
    UI32_T                              *ptr_entry_num);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETCAPACITY_FUNC_T)(
    const UI32_T                unit,
    const CLX_SWC_RSRC_T        type,
    const UI32_T                param,
    UI32_T                      *ptr_size);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3_GETUSAGE_FUNC_T)(
    const UI32_T                unit,
    const CLX_SWC_RSRC_T        type,
    const UI32_T                param,
    UI32_T                      *ptr_cnt);

/* l3t multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3T_CFGFLEXTNLGTP_FUNC_T)(
    const UI32_T unit,
    const UI32_T index,
    const UI32_T flags);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3T_CFGFLEXTNLGENEVE_FUNC_T)(
    const UI32_T unit,
    const UI32_T index,
    const UI32_T flags);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_L3T_CFGFLEXTNLUSERDEFINED_FUNC_T)(
    const UI32_T unit,
    const UI32_T index,
    const UI32_T flags);

/* pkt multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPIPPEXCPTCODETOUSER_FUNC_T)(
    const UI32_T                unit,
    UI32_T                      code,
    CLX_PKT_RX_REASON_BITMAP_T  user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPIPPRSNCODETOUSER_FUNC_T)(
    const UI32_T                unit,
    UI32_T                      code,
    CLX_PKT_RX_REASON_BITMAP_T  user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPEPPEXCPTCODETOUSER_FUNC_T)(
    const UI32_T                unit,
    UI32_T                      code,
    CLX_PKT_RX_REASON_BITMAP_T  user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPIPPEXCPTTOUSER_FUNC_T)(
    const UI32_T                        unit,
    const HAL_PKT_RX_REASON_BITMAP_T    *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T          user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPIPPL3EXCPTTOUSER_FUNC_T)(
    const UI32_T                        unit,
    const HAL_PKT_RX_REASON_BITMAP_T    *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T          user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPIPPCOPYTOCPUTOUSER_FUNC_T)(
    const UI32_T                        unit,
    const HAL_PKT_RX_REASON_BITMAP_T    *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T          user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPIPPRSNTOUSER_FUNC_T)(
    const UI32_T                        unit,
    const HAL_PKT_RX_REASON_BITMAP_T    *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T          user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPEPPEXCPTTOUSER_FUNC_T)(
    const UI32_T                        unit,
    const HAL_PKT_RX_REASON_BITMAP_T    *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T          user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPEPPCOPYTOCPUTOUSER_FUNC_T)(
    const UI32_T                        unit,
    const HAL_PKT_RX_REASON_BITMAP_T    *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T          user_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPUSERTOIPPEXCPT_FUNC_T)(
    const UI32_T                        unit,
    const CLX_PKT_RX_REASON_BITMAP_T    user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T          *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPUSERTOIPPL3EXCPT_FUNC_T)(
    const UI32_T                        unit,
    const CLX_PKT_RX_REASON_BITMAP_T    user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T          *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPUSERTOIPPCOPYTOCPU_FUNC_T)(
    const UI32_T                        unit,
    const CLX_PKT_RX_REASON_BITMAP_T    user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T          *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPUSERTOIPPRSN_FUNC_T)(
    const UI32_T                        unit,
    const CLX_PKT_RX_REASON_BITMAP_T    user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T          *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPUSERTOEPPEXCPT_FUNC_T)(
    const UI32_T                        unit,
    const CLX_PKT_RX_REASON_BITMAP_T    user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T          *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_MAPUSERTOEPPCOPYTOCPU_FUNC_T)(
    const UI32_T                        unit,
    const CLX_PKT_RX_REASON_BITMAP_T    user_bitmap,
    HAL_PKT_RX_REASON_BITMAP_T          *ptr_hw_bitmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_TRANSUSERTOHWREASON_FUNC_T)(
    const UI32_T                                unit,
    const CLX_PKT_RX_REASON_T                   user_reason,
    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T     hw_action,
    UI32_T                                      *ptr_hw_reason);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_TRANSHWTOUSERREASON_FUNC_T)(
    const UI32_T                                unit,
    const UI32_T                                hw_reason,
    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T     hw_action,
    CLX_PKT_RX_REASON_T                         *ptr_user_reason);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_PKT_INITREASONMAP_FUNC_T)(
    const UI32_T unit);

/* dtel multiplexing functions start */
typedef CLX_ERROR_NO_T \
(*HAL_CMN_DTEL_GETPORTPROPERTY_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_PROPERTY_T       property,
    UI32_T                          *ptr_param0,
    UI32_T                          *ptr_param1);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_DTEL_SETPORTPROPERTY_FUNC_T) (
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_PROPERTY_T       property,
    const UI32_T                    param0,
    const UI32_T                    param1);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_DTEL_GETPROPERTY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_SWC_PROPERTY_T        property,
    UI32_T                          *ptr_param0,
    UI32_T                          *ptr_param1);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_DTEL_SETPROPERTY_FUNC_T) (
    const UI32_T                    unit,
    const CLX_SWC_PROPERTY_T        property,
    const UI32_T                    param0,
    const UI32_T                    param1);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_INITEGRUCPRSRC_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_INITEGRUCPWARMRSRC_FUNC_T)(
    const UI32_T            unit,
    const HAL_IO_WB_DB_T    *ptr_wbdb);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_DEINITEGRUCPRSRC_FUNC_T)(
    const UI32_T    unit);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_DEINITEGRUCPWARMRSRC_FUNC_T)(
    const UI32_T         unit,
    HAL_IO_OBJ_META_T    *ptr_wbdb_obj);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_SETACTIVEUCP_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             ucp_bmp);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_FLIPEGRUCP_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    enable_ucp,
    const UI32_T    disable_ucp);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_SETUCPCFG_FUNC_T)(
    const UI32_T                    unit,
    const UI32_T                    tbl_id,
    const UI32_T                    ucp_id,
    const HAL_UCP_FRM_TYP_ENUM_T    frame_type,
    const UI32_T                    *ptr_buf);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_SETUCPPBMEN_FUNC_T)(
    const UI32_T    unit,
    const UI32_T    tbl_id,
    const UI32_T    ucp_id,
    const UI32_T    *ptr_buf);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_ADDHWENTRY_FUNC_T)(
    const UI32_T                       unit,
    const CLX_ACL_GROUP_T              type,
    const UI32_T                       entry_1x_id,
    const UI32_T                       norm_width,
    const HAL_ACL_PLANE_BCAST_INFO_T   *bcast_info,
    UI32_T                             (*ptr_entry_2d_buf)[CDB_ICIA_COM_TCAM_4X_WORDS]);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_SETHWENTRYVLD_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             hw_entry_id,
    const UI32_T             norm_width,
    const BOOL_T             entry_valid);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_READHWENTRY_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             entry_1x_id,
    const UI32_T             norm_width,
    UI32_T                   (*ptr_entry_2d_buf)[CDB_ICIA_COM_TCAM_4X_WORDS]);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_DELHWENTRY_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             entry_1x_id,
    const UI32_T             norm_width);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_CLEARCONTHWENTRY_FUNC_T)(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             start_1x_entry,
    const UI32_T             last_1x_entry);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_MOVEHWENTRY_FUNC_T)(
    const UI32_T               unit,
    const CLX_ACL_GROUP_T      type,
    const I32_T                src_1x_entry_id,
    const I32_T                dst_1x_entry_id,
    const UI32_T               tot_1x_move_entry_num,
    const DCC_DMA_D2D_DIR_T    d2d_dir,
    const UI32_T               shift_cnt,
    const UI32_T               cont_move);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_SETLOUORBMAP_FUNC_T)(
    const UI32_T            unit,
    const CLX_ACL_GROUP_T   type,
    const UI32_T            lou_prof_id,
    const UI32_T            lou_id,
    const UI8_T             lou_or_bmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_ACL_GETLOUORBMAP_FUNC_T)(
    const UI32_T            unit,
    const CLX_ACL_GROUP_T   type,
    const UI32_T            lou_prof_id,
    const UI32_T            lou_id,
    UI8_T                   *lou_or_bmap);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_EFUSE_READ_FUNC_T)(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T           die,
    const HAL_EFUSE_GROUP_T        group,
    const UI32_T                   addr,
    UI32_T                         *ptr_val);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_EFUSE_DMAREAD_FUNC_T)(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T           die,
    const HAL_EFUSE_GROUP_T        group,
    const UI32_T                   addr,
    const UI32_T                   words,
    UI32_T                         *ptr_buf);  /* if ptr_buf is NULL, put data to EFS_MIR only */

typedef CLX_ERROR_NO_T \
(*HAL_CMN_EFUSE_READMIR_FUNC_T)(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T           die,
    const HAL_EFUSE_GROUP_T        group,
    const UI32_T                   mir_idx,
    UI32_T                         *ptr_val);

typedef CLX_ERROR_NO_T \
(*HAL_CMN_EFUSE_WRITE_FUNC_T)(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T           die,
    const HAL_EFUSE_GROUP_T        group,
    const UI32_T                   addr,
    const UI32_T                   bit_offset,
    const UI32_T                   bit_len,
    const UI32_T                   value);

typedef struct
{
    HAL_CMN_VLAN_SETKEEPDEI_FUNC_T              hal_vlan_setKeepDei;
    HAL_CMN_VLAN_GETKEEPDEI_FUNC_T              hal_vlan_getKeepDei;
} HAL_CMN_VLAN_FUNC_VEC_T;

typedef struct
{
    HAL_CMN_IFMON_LOCKDATA_FUNC_T               hal_ifmon_lockData;
    HAL_CMN_IFMON_UNLOCKDATA_FUNC_T             hal_ifmon_unlockData;
    HAL_CMN_IFMON_LOCKFLOW_FUNC_T               hal_ifmon_lockFlow;
    HAL_CMN_IFMON_UNLOCKFLOW_FUNC_T             hal_ifmon_unlockFlow;
    HAL_CMN_IFMON_GETLINK_FUNC_T                hal_ifmon_getLink;
    HAL_CMN_IFMON_GETFAULT_FUNC_T               hal_ifmon_getFault;
    HAL_CMN_IFMON_GETSPEED_FUNC_T               hal_ifmon_getSpeed;
    HAL_CMN_IFMON_ADDMOCLORT_FUNC_T             hal_ifmon_addMonPort;
    HAL_CMN_IFMON_DELMOCLORT_FUNC_T             hal_ifmon_delMonPort;
    HAL_CMN_IFMON_RECORDTIME_FUNC_T             hal_ifmon_recordTime;
    HAL_CMN_IFMON_UPDATESWSTATE_FUNC_T          hal_ifmon_updateSwState;
    HAL_CMN_IFMON_DUMPLINKSTATE_FUNC_T          hal_ifmon_dumpLinkState;
} HAL_CMN_IFMON_FUNC_VEC_T;


typedef struct
{
    HAL_CMN_TM_SETPMSTATE_FUNC_T                hal_tm_pol_setPmState;
    HAL_CMN_TM_SETPMSPEED_FUNC_T                hal_tm_setPmSpeed;
    HAL_CMN_TM_POL_SETPROPERTY_FUNC_T           hal_tm_pol_setProperty;
    HAL_CMN_TM_POL_GETEPMBUFFEREMPTY_FUNC_T     hal_tm_pol_getEpmBufferEmpty;
    HAL_CMN_TM_GETTSRXENTRY_FUNC_T              hal_tm_getTsRxEntry;
    HAL_CMN_TM_SETTSRXSTATE_FUNC_T              hal_tm_setTsRxState;
    HAL_CMN_TM_UPDATETSRXLATENCY_FUNC_T         hal_tm_updateTsRxLatency;
    HAL_CMN_TM_RESETEPMBUFFER_FUNC_T            hal_tm_resetEpmBuffer;
    HAL_CMN_TM_GETLANENUM_FUNC_T                hal_tm_pol_getLaneNum;
    HAL_CMN_TM_SETSTATE_FUNC_T                  hal_tm_setState;
    HAL_CMN_TM_SETSPEED_FUNC_T                  hal_tm_setSpeed;
    HAL_CMN_TM_SETSTEERING_ENABLE_FUNC_T        hal_tm_setSteeringEnable;
    HAL_CMN_TM_GETSTEERING_ENABLE_FUNC_T        hal_tm_getSteeringEnable;
    HAL_CMN_TM_SETSTEERING_FUNC_T               hal_tm_setSteering;
    HAL_CMN_TM_GETSTEERING_FUNC_T               hal_tm_getSteering;
    HAL_CMN_TM_CONFIGTDM_FUNC_T                 hal_tm_configTdm;
    HAL_CMN_TM_UPDATEPORTTDM_FUNC_T             hal_tm_updatePortTdm;
    HAL_CMN_TM_SETSTACKINGPORT_FUNC_T           hal_tm_setStackingPort;
    HAL_CMN_TM_UPDATEPORTSTATUS_FUNC_T          hal_tm_updatePortStatus;
    HAL_CMN_TM_SETFLOWCTRLMODE_FUNC_T           hal_tm_setFlowCtrlMode;
    HAL_CMN_TM_GETFLOWCTRLMODE_FUNC_T           hal_tm_getFlowCtrlMode;
    HAL_CMN_TM_GETFLOWCTRLMODE_FUNC_T           hal_tm_getIosPauseMode;
    HAL_CMN_TM_GETAOPEMPTY_FUNC_T               hal_tm_getAopEmpty;
    HAL_CMN_TM_SCH_SETPORTEEE_FUNC_T            hal_tm_sch_setPortEee;
    HAL_CMN_TM_SCH_GETPORTEEE_FUNC_T            hal_tm_sch_getPortEee;
    HAL_CMN_TM_SETCUTTHROUGH_FUNC_T             hal_tm_setCutThrough;
    HAL_CMN_TM_SETPORTLANECNT_FUNC_T            hal_tm_setPortLaneCnt;
    HAL_CMN_TM_POL_GETLBSEMPTY_FUNC_T           hal_tm_pol_getLbsEmpty;
    HAL_CMN_TM_DEINITPORTFLOW_FUNC_T            hal_tm_deinitPortFlow;
    HAL_CMN_TM_SCH_FLUSHQUEUE_FUNC_T            hal_tm_sch_flushQueue;
    HAL_CMN_TM_POL_SETIOSFLUSH_FUNC_T           hal_tm_pol_setIosFlush;
    HAL_CMN_TM_CHECKHEALTHMON_FUNC_T            hal_tm_checkHealthMon;
    HAL_CMN_TM_POL_SETDROPERROR_FUNC_T          hal_tm_pol_setDropError;
    HAL_CMN_TM_DUMPREGPORTSTATE_FUNC_T          hal_tm_dumpRegPortState;
    HAL_CMN_TM_SETPFCWDINTERVAL_FUNC_T          hal_tm_setPfcwdInterval;
    HAL_CMN_TM_GETPFCWDINTERVAL_FUNC_T          hal_tm_getPfcwdInterval;
} HAL_CMN_TM_FUNC_VEC_T;

typedef struct
{
    /* start from dtel.c file */
    HAL_CMN_DTEL_GETPORTPROPERTY_FUNC_T         hal_dtel_getPortProperty;
    HAL_CMN_DTEL_SETPORTPROPERTY_FUNC_T         hal_dtel_setPortProperty;
    HAL_CMN_DTEL_GETPROPERTY_FUNC_T             hal_dtel_getProperty;
    HAL_CMN_DTEL_SETPROPERTY_FUNC_T             hal_dtel_setProperty;
} HAL_CMN_DTEL_FUNC_VEC_T;

typedef struct
{
    HAL_CMN_MPLS_SETSKIPMPLS_FUNC_T             hal_mpls_setSkipMpls;
    HAL_CMN_MPLS_GETSKIPMPLS_FUNC_T             hal_mpls_getSkipMpls;
    HAL_CMN_MPLS_SETDELMPLS_FUNC_T              hal_mpls_setDelMpls;
    HAL_CMN_MPLS_GETDELMPLS_FUNC_T              hal_mpls_getDelMpls;
} HAL_CMN_MPLS_FUNC_VEC_T;

typedef struct
{
    HAL_CMN_STAT_GETTMCNT_FUNC_T                hal_stat_getTmCnt;
    HAL_CMN_STAT_CLEARTMCNT_FUNC_T              hal_stat_clearTmCnt;
    HAL_CMN_STAT_GETRSERRDISTCNT                hal_stat_getRsErrDistCnt;
    HAL_CMN_STAT_CLEARRSERRDISTCNT              hal_stat_clearRsErrDistCnt;
    HAL_CMN_STAT_SETRSERRDISTCNTINTERVAL        hal_stat_setRsErrDistCntInterval;
    HAL_CMN_STAT_GETPORTRATETYPE_FUNC_T         hal_stat_getPortRateType;
} HAL_CMN_STAT_FUNC_VEC_T;

typedef struct
{
    /* HAL INTF dispatcher */
    HAL_CMN_L3_FDID2INTF_FUNC_T                 hal_l3_fdid2intf;
    HAL_CMN_L3_INTF2FDID_FUNC_T                 hal_l3_intf2fdid;
    /* HAL VRF dispatcher */
    HAL_CMN_L3_SETGLOBALROUTEMISSACTION_FUNC_T  hal_l3_setGlobalRouteMissAction;
    HAL_CMN_L3_GETGLOBALROUTEMISSACTION_FUNC_T  hal_l3_getGlobalRouteMissAction;
    /* HAL ADJ and ECMP dispatcher */
    HAL_CMN_L3_GETADJINFO_FUNC_T                hal_l3_getAdjInfo;
    HAL_CMN_L3_GETECMPINFO_FUNC_T               hal_l3_getEcmpInfo;
    HAL_CMN_L3_UPDATEADJUSENUM_FUNC_T           hal_l3_updateAdjUseNum;
    HAL_CMN_L3_UPDATEECMPGRPUSENUM_FUNC_T       hal_l3_updateEcmpGrpUseNum;
    HAL_CMN_L3_GETPATHIDXBYGRPADJID_FUNC_T      hal_l3_getPathIdxByGrpAdjId;
    HAL_CMN_L3_SETECMPBLOCKSIZE_FUNC_T          hal_l3_setEcmpBlockSize;
    HAL_CMN_L3_GETECMPBLOCKSIZE_FUNC_T          hal_l3_getEcmpBlockSize;
    /* HAL ROUTE dispatcher */
    HAL_CMN_L3_ADDFCOETCAMENTRY_FUNC_T          hal_l3_addFcoeTcamEntry;
    HAL_CMN_L3_DELFCOETCAMENTRY_FUNC_T          hal_l3_delFcoeTcamEntry;
    HAL_CMN_L3_GETFCOETCAMENTRY_FUNC_T          hal_l3_getFcoeTcamEntry;
    /* HAL MCAST dispatcher */
    HAL_CMN_L3_DELMEMBERALL_FUNC_T              hal_l3_delMemberAll;
    HAL_CMN_L3_ADDMELSUBENTRYBYPORT_FUNC_T      hal_l3_addMelSubEntryByPort;
    HAL_CMN_L3_DELMELSUBENTRYBYPORT_FUNC_T      hal_l3_delMelSubEntryByPort;
    HAL_CMN_L3_GETMELSUBENTRYBYPORT_FUNC_T      hal_l3_getMelSubEntryByPort;
    HAL_CMN_L3_GETMELSUBENTRYNUMBYPORT_FUNC_T   hal_l3_getMelSubEntryNumByPort;
    /* HAL CAPACITY and USAGE dispatcher */
    HAL_CMN_L3_GETCAPACITY_FUNC_T               hal_l3_getCapacity;
    HAL_CMN_L3_GETUSAGE_FUNC_T                  hal_l3_getUsage;
} HAL_CMN_L3_FUNC_VEC_T;

typedef struct
{
    HAL_CMN_L3T_CFGFLEXTNLGTP_FUNC_T            hal_l3t_cfgFlexTnlGtp;
    HAL_CMN_L3T_CFGFLEXTNLGENEVE_FUNC_T         hal_l3t_cfgFlexTnlGeneve;
    HAL_CMN_L3T_CFGFLEXTNLUSERDEFINED_FUNC_T    hal_l3t_cfgFlexTnlUserDefined;
} HAL_CMN_L3T_FUNC_VEC_T;

typedef struct
{
    HAL_CMN_PKT_MAPIPPEXCPTCODETOUSER_FUNC_T    hal_pkt_mapIppExcptCodeToUser;
    HAL_CMN_PKT_MAPIPPRSNCODETOUSER_FUNC_T      hal_pkt_mapIppRsnCodeToUser;
    HAL_CMN_PKT_MAPEPPEXCPTCODETOUSER_FUNC_T    hal_pkt_mapEppExcptCodeToUser;
    HAL_CMN_PKT_MAPIPPEXCPTTOUSER_FUNC_T        hal_pkt_mapIppExcptToUser;
    HAL_CMN_PKT_MAPIPPL3EXCPTTOUSER_FUNC_T      hal_pkt_mapIppL3ExcptToUser;
    HAL_CMN_PKT_MAPIPPCOPYTOCPUTOUSER_FUNC_T    hal_pkt_mapIppCopyToCpuToUser;
    HAL_CMN_PKT_MAPIPPRSNTOUSER_FUNC_T          hal_pkt_mapIppRsnToUser;
    HAL_CMN_PKT_MAPEPPEXCPTTOUSER_FUNC_T        hal_pkt_mapEppExcptToUser;
    HAL_CMN_PKT_MAPEPPCOPYTOCPUTOUSER_FUNC_T    hal_pkt_mapEppCopyToCpuToUser;
    HAL_CMN_PKT_MAPUSERTOIPPEXCPT_FUNC_T        hal_pkt_mapUserToIppExcpt;
    HAL_CMN_PKT_MAPUSERTOIPPL3EXCPT_FUNC_T      hal_pkt_mapUserToIppL3Excpt;
    HAL_CMN_PKT_MAPUSERTOIPPCOPYTOCPU_FUNC_T    hal_pkt_mapUserToIppCopyToCpu;
    HAL_CMN_PKT_MAPUSERTOIPPRSN_FUNC_T          hal_pkt_mapUserToIppRsn;
    HAL_CMN_PKT_MAPUSERTOEPPEXCPT_FUNC_T        hal_pkt_mapUserToEppExcpt;
    HAL_CMN_PKT_MAPUSERTOEPPCOPYTOCPU_FUNC_T    hal_pkt_mapUserToEppCopyToCpu;
    HAL_CMN_PKT_TRANSUSERTOHWREASON_FUNC_T      hal_pkt_transUserToHwReason;
    HAL_CMN_PKT_TRANSHWTOUSERREASON_FUNC_T      hal_pkt_transHwToUserReason;
    HAL_CMN_PKT_INITREASONMAP_FUNC_T            hal_pkt_initReasonMap;
} HAL_CMN_PKT_FUNC_VEC_T;

typedef struct
{
    HAL_CMN_ACL_INITEGRUCPRSRC_FUNC_T               hal_acl_initEgrUcpRsrc;
    HAL_CMN_ACL_INITEGRUCPWARMRSRC_FUNC_T           hal_acl_initEgrUcpWarmRsrc;
    HAL_CMN_ACL_DEINITEGRUCPRSRC_FUNC_T             hal_acl_deinitEgrUcpRsrc;
    HAL_CMN_ACL_DEINITEGRUCPWARMRSRC_FUNC_T         hal_acl_deinitEgrUcpWarmRsrc;
    HAL_CMN_ACL_SETACTIVEUCP_FUNC_T                 hal_acl_setActiveUcp;
    HAL_CMN_ACL_FLIPEGRUCP_FUNC_T                   hal_acl_flipEgrUcp;
    HAL_CMN_ACL_SETUCPCFG_FUNC_T                    hal_acl_setUcpCfg;
    HAL_CMN_ACL_SETUCPPBMEN_FUNC_T                  hal_acl_setUcpPbmEn;
    HAL_CMN_ACL_ADDHWENTRY_FUNC_T                   hal_acl_addHwEntry;
    HAL_CMN_ACL_SETHWENTRYVLD_FUNC_T                hal_acl_setHwEntryVld;
    HAL_CMN_ACL_READHWENTRY_FUNC_T                  hal_acl_readHwEntry;
    HAL_CMN_ACL_DELHWENTRY_FUNC_T                   hal_acl_delHwEntry;
    HAL_CMN_ACL_CLEARCONTHWENTRY_FUNC_T             hal_acl_clearContHwEntry;
    HAL_CMN_ACL_MOVEHWENTRY_FUNC_T                  hal_acl_moveHwEntry;
    HAL_CMN_ACL_SETLOUORBMAP_FUNC_T                 hal_acl_setLouOrBmp;
    HAL_CMN_ACL_GETLOUORBMAP_FUNC_T                 hal_acl_getLouOrBmp;
} HAL_CMN_ACL_FUNC_VEC_T;

typedef struct
{
    HAL_CMN_EFUSE_READ_FUNC_T                     hal_efuse_read;
    HAL_CMN_EFUSE_DMAREAD_FUNC_T                  hal_efuse_dmaRead;
    HAL_CMN_EFUSE_READMIR_FUNC_T                  hal_efuse_readMir;
    HAL_CMN_EFUSE_WRITE_FUNC_T                    hal_efuse_write;
} HAL_CMN_EFUSE_FUNC_VEC_T;

typedef struct
{
    /* vlan multiplexing functions */
    HAL_CMN_VLAN_FUNC_VEC_T *const  vlan_cmn_func_vec;
    /* ifmon multiplexing functions */
    HAL_CMN_IFMON_FUNC_VEC_T *const ifmon_cmn_func_vec;
    /* tm multiplexing functions */
    HAL_CMN_TM_FUNC_VEC_T *const    tm_cmn_func_vec;
    /* MPLS multiplexing functions */
    HAL_CMN_MPLS_FUNC_VEC_T *const  mpls_cmn_func_vec;
    /* stat multiplexing functions */
    HAL_CMN_STAT_FUNC_VEC_T *const  stat_cmn_func_vec;
    /* l3 multiplexing functions */
    HAL_CMN_L3_FUNC_VEC_T *const    l3_cmn_func_vec;
    /* l3t multiplexing functions */
    HAL_CMN_L3T_FUNC_VEC_T *const   l3t_cmn_func_vec;
    /* pkt multiplexing functions */
    HAL_CMN_PKT_FUNC_VEC_T *const   pkt_cmn_func_vec;
    /* dtel multiplexing functions */
    HAL_CMN_DTEL_FUNC_VEC_T *const  dtel_cmn_func_vec;
    /* acl multiplexing functions */
    HAL_CMN_ACL_FUNC_VEC_T *const  acl_cmn_func_vec;
    /* efuse multiplexing functions */
    HAL_CMN_EFUSE_FUNC_VEC_T *const efuse_cmn_func_vec;
} HAL_CMN_FUNC_VEC_T;
#endif  /* #ifndef HAL_CMN_DRV_H */
