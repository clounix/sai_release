/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  hal_cmn.h
 * PURPOSE:
 *  1. To maintain common internal utility API, such as src_supp_tag management,
 *     or exception code management.
 * NOTES:
 */

#ifndef HAL_CMN_H
#define HAL_CMN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <hal/common/hal_l3.h>
#include <hal/common/hal_pkt_rsrc.h>
#include <hal/common/hal_ecc.h>
#include <dcc/dcc_dma.h>
#include <cdb/cdb.h>

/* NAMING CONSTANT DECLARATIONS
*/
#define HAL_CMN_PVLAN_CVLAN_NUM           (5)
#define HAL_CMN_MCLAG_NUM                 (6)
#define HAL_CMN_MCAST_LAG_EPOCH_MASTER    (0)
#define HAL_CMN_MCAST_LAG_EPOCH_BACKUP    (1)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_CMN_TRANS_TO_LRN_SST(__sst__) do                                        \
    {                                                                                   \
        if (HAL_CMN_SST_ROLE_PVLAN_IT == (__sst__))                                 \
        {                                                                               \
            (__sst__) = HAL_CMN_SST_ROLE_PVLAN_P;                                   \
        }                                                                               \
        else if (((__sst__) >= HAL_CMN_SST_ROLE_MCLAG0_EP_ON) &&                    \
                 ((__sst__) <= HAL_CMN_SST_ROLE_MCLAG5_EP_OFF))                     \
        {                                                                               \
            (__sst__) = HAL_CMN_SST_ROLE_NORMAL;                                    \
        }                                                                               \
        else if (((__sst__) >= HAL_CMN_SST_ROLE_MCLAG0_UP) &&                       \
                 ((__sst__) <= HAL_CMN_SST_ROLE_MCLAG5_UP))                         \
        {                                                                               \
            (__sst__) = HAL_CMN_SST_ROLE_TRILL_UP;                                  \
        }                                                                               \
    } while(0)

/* protect ITM_RSLT_LAG_SEL & IEV_LAG_EPOCH */
#define HAL_CMN_LOCK_MCAST_LAG_SEL(unit)                                            \
        HAL_COMMON_LOCK_RESOURCE(&_ext_hal_cmn_cb[(unit)].lag_mcast_sel_sema_id,    \
                                 CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_CMN_FREE_MCAST_LAG_SEL(unit)                                            \
        HAL_COMMON_FREE_RESOURCE(&_ext_hal_cmn_cb[(unit)].lag_mcast_sel_sema_id)

/* protect L2 mcast lag member */
#define HAL_CMN_LOCK_L2_MCAST_LAG_MBR(unit)                                            \
        HAL_COMMON_LOCK_RESOURCE(&_ext_hal_cmn_cb[(unit)].l2_mcast_lag_mbr_sema_id,    \
                                 CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_CMN_FREE_L2_MCAST_LAG_MBR(unit)                                            \
        HAL_COMMON_FREE_RESOURCE(&_ext_hal_cmn_cb[(unit)].l2_mcast_lag_mbr_sema_id)

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_CMN_CB_S
{
    CLX_SEMAPHORE_ID_T    lag_mcast_sel_sema_id;    /* protect ITM_RSLT_LAG_SEL & IEV_LAG_EPOCH */
    CLX_SEMAPHORE_ID_T    l2_mcast_lag_mbr_sema_id;    /* protect L2 mcast lag member */
} HAL_CMN_CB_T;

typedef struct HAL_ACL_PLANE_BCAST_INFO_S
{
    BOOL_T bcast_flag;
    UI32_T bcast_cont_plane_idx;
    UI32_T non_bcast_plane_bmp;
} HAL_ACL_PLANE_BCAST_INFO_T;

typedef enum
{
    HAL_CMN_ACTION_ADD = 0,
    HAL_CMN_ACTION_DEL,
    HAL_CMN_ACTION_SET,
    HAL_CMN_ACTION_GET,
    HAL_CMN_ACTION_LAST
} HAL_CMN_ACTION_T;

typedef enum
{
    /* ep with port-prune */
    HAL_CMN_SST_ROLE_EP_START               = 0,
    HAL_CMN_SST_ROLE_EP_PORT_PRUNE_START    = HAL_CMN_SST_ROLE_EP_START,
    HAL_CMN_SST_ROLE_NORMAL                 = HAL_CMN_SST_ROLE_EP_PORT_PRUNE_START,
    HAL_CMN_SST_ROLE_PVLAN_START,
    HAL_CMN_SST_ROLE_PVLAN_P                = HAL_CMN_SST_ROLE_PVLAN_START,
    HAL_CMN_SST_ROLE_PVLAN_IT,
    HAL_CMN_SST_ROLE_PVLAN_I,
    HAL_CMN_SST_ROLE_PVLAN_C0,
    HAL_CMN_SST_ROLE_PVLAN_C1,
    HAL_CMN_SST_ROLE_PVLAN_C2,
    HAL_CMN_SST_ROLE_PVLAN_C3,
    HAL_CMN_SST_ROLE_PVLAN_C4,
    HAL_CMN_SST_ROLE_PVLAN_END              = HAL_CMN_SST_ROLE_PVLAN_C4,
    HAL_CMN_SST_ROLE_MCLAGX_EP_ON_START,
    HAL_CMN_SST_ROLE_MCLAG0_EP_ON           = HAL_CMN_SST_ROLE_MCLAGX_EP_ON_START,
    HAL_CMN_SST_ROLE_MCLAG1_EP_ON,
    HAL_CMN_SST_ROLE_MCLAG2_EP_ON,
    HAL_CMN_SST_ROLE_MCLAG3_EP_ON,
    HAL_CMN_SST_ROLE_MCLAG4_EP_ON,
    HAL_CMN_SST_ROLE_MCLAG5_EP_ON,
    HAL_CMN_SST_ROLE_MCLAGX_EP_ON_END       = HAL_CMN_SST_ROLE_MCLAG5_EP_ON,
    HAL_CMN_SST_ROLE_MCLAGX_EP_OFF_START,
    HAL_CMN_SST_ROLE_MCLAG0_EP_OFF          = HAL_CMN_SST_ROLE_MCLAGX_EP_OFF_START,
    HAL_CMN_SST_ROLE_MCLAG1_EP_OFF,
    HAL_CMN_SST_ROLE_MCLAG2_EP_OFF,
    HAL_CMN_SST_ROLE_MCLAG3_EP_OFF,
    HAL_CMN_SST_ROLE_MCLAG4_EP_OFF,
    HAL_CMN_SST_ROLE_MCLAG5_EP_OFF,
    HAL_CMN_SST_ROLE_MCLAGX_EP_OFF_END      = HAL_CMN_SST_ROLE_MCLAG5_EP_OFF,
    HAL_CMN_SST_ROLE_EP_PORT_PRUNE_END      = HAL_CMN_SST_ROLE_MCLAGX_EP_OFF_END,
    HAL_CMN_SST_ROLE_VM,
    HAL_CMN_SST_ROLE_EP_END                 = HAL_CMN_SST_ROLE_VM,
    /* uplink */
    HAL_CMN_SST_ROLE_UP_START,
    HAL_CMN_SST_ROLE_NV_UP                  = HAL_CMN_SST_ROLE_UP_START,
    HAL_CMN_SST_ROLE_TRILL_UP,
    HAL_CMN_SST_ROLE_MPLS_UP,
    HAL_CMN_SST_ROLE_MCLAGX_UP_START,
    HAL_CMN_SST_ROLE_MCLAG0_UP              = HAL_CMN_SST_ROLE_MCLAGX_UP_START,
    HAL_CMN_SST_ROLE_MCLAG1_UP,
    HAL_CMN_SST_ROLE_MCLAG2_UP,
    HAL_CMN_SST_ROLE_MCLAG3_UP,
    HAL_CMN_SST_ROLE_MCLAG4_UP,
    HAL_CMN_SST_ROLE_MCLAG5_UP,
    HAL_CMN_SST_ROLE_MCLAGX_UP_END          = HAL_CMN_SST_ROLE_MCLAG5_UP,
    HAL_CMN_SST_ROLE_UP_END                 = HAL_CMN_SST_ROLE_MCLAGX_UP_END,
    /* last */
    HAL_CMN_SST_ROLE_VALID_LAST             = HAL_CMN_SST_ROLE_UP_END,
    HAL_CMN_SST_ROLE_BYPASS_PRUNE           = 31 /* HW bypass prune when sst all 1 */
} HAL_CMN_SST_ROLE_T;

/* for maintaining IEV_RSLT_U_xxx relation to l3_output (ecmp/adj) */
typedef struct HAL_CMN_RTE_NODE_S
{
    UI32_T iev_idx;                     /* index to union IEV_RSLT or IEV_RSLT_NVO3_ENCAP */
    CLX_L3_OUTPUT_TYPE_T output_type;   /* ecmp, adj, nvo3_adj */
    UI32_T output_id;

    struct HAL_CMN_RTE_NODE_S *ptr_prev_iev;
    struct HAL_CMN_RTE_NODE_S *ptr_next_iev;
}   HAL_CMN_RTE_NODE_T;

typedef CLX_ERROR_NO_T
(*HAL_CMN_ADJ_CALLBACK_FUNC_T)(
    const UI32_T unit,
    const UI32_T iev_idx,
    const HAL_L3_ADJ_INFO_T *ptr_adj_info);

typedef CLX_ERROR_NO_T
(*HAL_CMN_NVO3_ADJ_CALLBACK_FUNC_T)(
    const UI32_T         unit,
    const UI32_T         iev_idx,  /* index to union IEV_RSLT_ECMP_PATH */
    const CLX_PORT_T     port);    /* nvo3_adj_info */

typedef struct
{
    UI32_T is_tbl_id;
    union
    {
        UI32_T tbl_id;
        UI32_T addr;
    };
    union
    {
        UI32_T field_id;
        UI32_T offset;
    };
    UI32_T entry_idx;
    UI32_T data;
} HAL_CMN_LATENCY_TBL_ENTRY_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_cmn_init(
    const UI32_T    unit);

void
hal_cmn_deinit(
    const UI32_T    unit);


/* FUNCTION NAME: hal_cmn_cmpRteIev
 * PURPOSE:
 *      The function is used to compare rte_node iev_idx in rte_avl tree.
 * INPUT:
 *      ptr_user_param -- user parameter
 *      ptr_user_data  -- user data
 *      ptr_node_data  -- node data
 * OUTPUT:
 *      None
 * RETURN:
 *      <0 -- ptr_user_data.iev_idx < ptr_node_data.iev_idx
 *      =0 -- ptr_user_data.iev_idx = ptr_node_data.iev_idx
 *      >0 -- ptr_user_data.iev_idx > ptr_node_data.iev_idx
 * NOTES:
 *      None
 */
I32_T
hal_cmn_cmpRteIev(
    void    *ptr_user_param,
    void    *ptr_user_data,
    void    *ptr_node_data);

/* FUNCTION NAME: hal_cmn_cmpRteAdj
 * PURPOSE:
 *      The function is used to compare rte_node output_id in rte_avl tree (adj only).
 * INPUT:
 *      ptr_user_param -- user parameter
 *      ptr_user_data  -- user data
 *      ptr_node_data  -- node data
 * OUTPUT:
 *      None
 * RETURN:
 *      <0 -- ptr_user_data.output_id < ptr_node_data.output_id
 *      =0 -- ptr_user_data.output_id = ptr_node_data.output_id
 *      >0 -- ptr_user_data.output_id > ptr_node_data.output_id
 * NOTES:
 *      None
 */
I32_T
hal_cmn_cmpRteAdj(
    void    *ptr_user_param,
    void    *ptr_user_data,
    void    *ptr_node_data);

/* FUNCTION NAME: hal_cmn_addIevL3RteNode
 * PURPOSE:
 *    add or set IEV_RSLT_U_xxx's usage of l3_output (ecmp or adj) to swdb
 * INPUT:
 *    unit        --  device unit number
 *    iev_idx     --  index to IEV_RSLT_U_xxx
 *    output_type --  ecmp or adj
 *    output_id   --  ecmp_id or adj_id
 *    ptr_adj_avl --  pointer to adj_avl
 *    ptr_iev_avl --  pointer to iev_avl
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_addIevL3RteNode(
    const UI32_T                  unit,
    const UI32_T                  iev_idx,
    const CLX_L3_OUTPUT_TYPE_T    output_type,
    const UI32_T                  output_id,
    CMLIB_AVL_HEAD_T              *ptr_adj_avl,
    CMLIB_AVL_HEAD_T              *ptr_iev_avl);

/* FUNCTION NAME: hal_cmn_delIevL3RteNode
 * PURPOSE:
 *    remove IEV_RSLT_U_xxx's usage of l3_output (ecmp or adj) to swdb
 * INPUT:
 *    unit        --  device unit number
 *    iev_idx     --  index to IEV_RSLT_U_xxx
 *    ptr_adj_avl --  pointer to adj_avl
 *    ptr_iev_avl --  pointer to iev_avl
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_delIevL3RteNode(
    const UI32_T        unit,
    const UI32_T        iev_idx,
    CMLIB_AVL_HEAD_T    *ptr_adj_avl,
    CMLIB_AVL_HEAD_T    *ptr_iev_avl);

/* FUNCTION NAME: hal_cmn_getIevL3RteNode
 * PURPOSE:
 *    Get rte_node from avl by specified id
 * INPUT:
 *    unit        --  device unit number
 *    id          --  iev_idx or adj_id (depends on which avl is not NULL)
 *    ptr_adj_avl --  pointer to adj_avl
 *    ptr_iev_avl --  pointer to iev_avl
 * OUTPUT:
 *    pptr_node   --  found rte_node
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 *    whether id is iev_idx or adj_id is determined by which input avl is not NULL
 *    (e.g.) if ptr_adj_avl != NULL, id is adj_id
 */
CLX_ERROR_NO_T
hal_cmn_getIevL3RteNode(
    const UI32_T          unit,
    const UI32_T          id,
    CMLIB_AVL_HEAD_T      *ptr_adj_avl,
    CMLIB_AVL_HEAD_T      *ptr_iev_avl,
    HAL_CMN_RTE_NODE_T    **pptr_node);

/* FUNCTION NAME: hal_cmn_saveIevL3RteNodes
 * PURPOSE:
 *    save set-l3-adj-swdb for warm-deinit
 * INPUT:
 *    ptr_adj_avl   --  pointer to adj_avl
 *    ptr_iev_avl   --  pointer to iev_avl
 *    ptr_obj_meta      --  Object Meta for the nonvolatile storage
 * OUTPUT:
 *    ptr_obj_meta      --  Object Meta for the nonvolatile storage
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_saveIevL3RteNodes(
    CMLIB_AVL_HEAD_T     *ptr_adj_avl,
    CMLIB_AVL_HEAD_T     *ptr_iev_avl,
    HAL_IO_OBJ_META_T    *ptr_obj_meta);

/* FUNCTION NAME: hal_cmn_restoreIevL3RteNodes
 * PURPOSE:
 *    restore set-l3-adj-swdb for warm-init
 * INPUT:
 *    unit          --  device unit number
 *    ptr_adj_avl   --  pointer to adj_avl
 *    ptr_iev_avl   --  pointer to iev_avl
 *    ptr_obj_meta  --  Object Meta for the nonvolatile storage
 * OUTPUT:
 *    NONE
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_restoreIevL3RteNodes(
    const UI32_T               unit,
    CMLIB_AVL_HEAD_T           *ptr_adj_avl,
    CMLIB_AVL_HEAD_T           *ptr_iev_avl,
    const HAL_IO_OBJ_META_T    *ptr_obj_meta);

/* FUNCTION NAME:   hal_cmn_addIevNvo3RteNode
 * PURPOSE:
 *      Add node with given path_idx.
 * INPUT:
 *      unit                 -- Device unit number
 *      iev_idx              -- Index to IEV_RSLT_NVO3_ENCAP
 *      output_type          -- L3 output type; CLX_L3_OUTPUT_TYPE_[ECMP|NVO3_ADJ]
 *      output_id            -- L3 output id
 *      pptr_nvo3_adj_arr    -- Array of pointer to first node of each nvo3_adj_id
 *      ptr_path_avl         -- Avl head of path_idx
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             -- Operate success
 *      CLX_E_OTHERS         -- Operate fail
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_addIevNvo3RteNode(
    const UI32_T                  unit,
    const UI32_T                  iev_idx,
    const CLX_L3_OUTPUT_TYPE_T    output_type,
    const UI32_T                  output_id,
    HAL_CMN_RTE_NODE_T            **pptr_nvo3_adj_arr,
    CMLIB_AVL_HEAD_T              *ptr_path_avl);

/* FUNCTION NAME:   hal_cmn_setIevNvo3RteNode
 * PURPOSE:
 *      Set node with given path_idx.
 * INPUT:
 *      unit                 -- Device unit number
 *      iev_idx              -- Index to IEV_RSLT_NVO3_ENCAP
 *      output_type          -- L3 output type; CLX_L3_OUTPUT_TYPE_[ECMP|NVO3_ADJ]
 *      output_id            -- L3 output id
 *      pptr_nvo3_adj_arr    -- Array of pointer to first node of each nvo3_adj_id
 *      ptr_path_avl         -- Avl head of path_idx
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             -- Operate success
 *      CLX_E_OTHERS         -- Operate fail
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_setIevNvo3RteNode(
    const UI32_T                  unit,
    const UI32_T                  iev_idx,
    const CLX_L3_OUTPUT_TYPE_T    output_type,
    const UI32_T                  output_id,
    HAL_CMN_RTE_NODE_T            **pptr_nvo3_adj_arr,
    CMLIB_AVL_HEAD_T              *ptr_path_avl);

/* FUNCTION NAME:   hal_cmn_delIevNvo3RteNode
 * PURPOSE:
 *      Delete node with given path_idx.
 * INPUT:
 *      unit                 -- Device unit number
 *      iev_idx              -- Index to IEV_RSLT_NVO3_ENCAP
 *      pptr_nvo3_adj_arr    -- Array of pointer to first node of each nvo3_adj_id
 *      ptr_path_avl         -- Avl head of path_idx
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             -- Operate success
 *      CLX_E_OTHERS         -- Operate fail
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_delIevNvo3RteNode(
    const UI32_T          unit,
    const UI32_T          iev_idx,
    HAL_CMN_RTE_NODE_T    **pptr_nvo3_adj_arr,
    CMLIB_AVL_HEAD_T      *ptr_path_avl);

/* FUNCTION NAME: hal_cmn_saveIevNvo3RteNodes
 * PURPOSE:
 *    save set-nvo3-adj-swdb for warm-deinit
 * INPUT:
 *    pptr_nvo3_adj_arr --  Array of pointer to first node of each nvo3_adj_id
 *    ptr_path_avl      --  Avl head of path_idx
 *    ptr_obj_meta      --  Object Meta for the nonvolatile storage
 * OUTPUT:
 *    ptr_obj_meta      --  Object Meta for the nonvolatile storage
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_saveIevNvo3RteNodes(
    HAL_CMN_RTE_NODE_T    **pptr_nvo3_adj_arr,
    CMLIB_AVL_HEAD_T      *ptr_path_avl,
    HAL_IO_OBJ_META_T     *ptr_obj_meta);

/* FUNCTION NAME: hal_cmn_restoreIevNvo3RteNodes
 * PURPOSE:
 *    restore set-nvo3-adj-swdb for warm-init
 * INPUT:
 *    unit              --  device unit number
 *    pptr_nvo3_adj_arr --  Array of pointer to first node of each nvo3_adj_id
 *    ptr_path_avl      --  Avl head of path_idx
 *    ptr_obj_meta      --  Object Meta for the nonvolatile storage
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_restoreIevNvo3RteNodes(
    const UI32_T               unit,
    HAL_CMN_RTE_NODE_T         **pptr_nvo3_adj_arr,
    CMLIB_AVL_HEAD_T           *ptr_path_avl,
    const HAL_IO_OBJ_META_T    *ptr_obj_meta);

/* FUNCTION NAME: hal_cmn_updateIevByAdj
 * PURPOSE:
 *    update iev entries related to the input adj_id
 * INPUT:
 *    unit         --  device unit number
 *    adj_id       --  adj_id that is updated
 *    ptr_adj_info --  updated adj_info
 *    ptr_adj_avl  --  pointer to adj_avl
 *    callback     --  callback function handling iev modification
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_updateIevByAdj(
    const UI32_T                   unit,
    const UI32_T                   adj_id,
    const HAL_L3_ADJ_INFO_T        *ptr_adj_info,
    CMLIB_AVL_HEAD_T               *ptr_adj_avl,
    HAL_CMN_ADJ_CALLBACK_FUNC_T    callback);

/* FUNCTION NAME:   hal_cmn_updateIevByNvo3Adj
 * PURPOSE:
 *      Update hw path info by traversing nodes using given nvo3_adj_id.
 * INPUT:
 *      unit                 -- Device unit number
 *      nvo3_adj_id          -- Nvo3 adjacency id
 *      port                 -- Info of nvo3_adj
 *      pptr_nvo3_adj_arr    -- Array of pointer to first node of each nvo3_adj_id
 *      callback             -- Callback function to update path
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             -- Operate success
 *      CLX_E_OTHERS         -- Operate fail
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_updateIevByNvo3Adj(
    const UI32_T                        unit,
    const UI32_T                        nvo3_adj_id,
    const CLX_PORT_T                    port,
    HAL_CMN_RTE_NODE_T                  **pptr_nvo3_adj_arr,
    HAL_CMN_NVO3_ADJ_CALLBACK_FUNC_T    callback);

/* FUNCTION NAME: hal_cmn_addNvo3Route
 * PURPOSE:
 *    configure nvo3_encap_idx's egress path,
 *    including nvo3_adj and nvo3_ecmp
 * INPUT:
 *    unit                  --  device unit number
 *    nvo3_encap_idx        --  index to IEV_RSLT_NVO3_ENCAP
 *    output_type           --  nvo3_ecmp or nvo3_adj
 *    output_id             --  nvo3_ecmp_id or nvo3_adj_id
 *    ptr_buf               --  cdb_buf of IEV_RSLT_ECMP_PATH_U_EP_L3 (nvo3_adj only)
 *    pptr_nvo3_adj_arr     --  Array of pointer to first node of each nvo3_adj_id
 *    ptr_path_avl          --  Avl head of path_idx
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 *    This api configures a tunnel's output to nvo3_adj or nvo3_ecmp.
 *    It handles the following scenarios:
 *    # N/A       -> nvo3_adj/nvo3_ecmp
 *    # nvo3_adj  -> nvo3_adj/nvo3_ecmp
 *    # nvo3_ecmp -> nvo3_adj/nvo3_ecmp
 *
 *    User only needs to input ptr_buf if output_type=nvo3_adj.
 *    Both nvo3_adj/nvo3_ecmp would save into swdb (To sync with L3RteNode)
 */
CLX_ERROR_NO_T
hal_cmn_addNvo3Route(
    const UI32_T                  unit,
    const UI32_T                  nvo3_encap_idx,
    const CLX_L3_OUTPUT_TYPE_T    output_type,
    const UI32_T                  output_id,
    const UI32_T                  *ptr_path_buf,
    HAL_CMN_RTE_NODE_T            **pptr_nvo3_adj_arr,
    CMLIB_AVL_HEAD_T              *ptr_path_avl);

CLX_ERROR_NO_T
hal_cmn_delNvo3Route(
    const UI32_T          unit,
    const UI32_T          nvo3_encap_idx,
    HAL_CMN_RTE_NODE_T    **pptr_nvo3_adj_arr,
    CMLIB_AVL_HEAD_T      *ptr_path_avl);

/* FUNCTION NAME: hal_cmn_getDi
 * PURPOSE:
 *    get di from clx_port/native port
 * INPUT:
 *    unit      --  device unit number
 *    port      --  clx_port or native port
 *    reason    --  cpu reason if to_cpu
 * OUTPUT:
 *    ptr_di    -- di derived from input port
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_getDi(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        reason,
    UI32_T              *ptr_di);

/* FUNCTION NAME: hal_cmn_setLatencyMode
 * PURPOSE:
 *    Set latency normal mode
 * INPUT:
 *    unit      --  device unit number
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_setLatencyMode(
    const UI32_T    unit);

/* FUNCTION NAME: hal_cmn_setChipDfltCfg
 * PURPOSE:
 *    set chip default config value
 * INPUT:
 *    unit  --  device unit number
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_setChipDfltCfg(
    const UI32_T    unit);

/* FUNCTION NAME: hal_cmn_dmaReadTcam
 * PURPOSE:
 *    dma read tcam table from device to host memory
 *    (not transform entry data from cell-c/cell-t to data/mask view)
 * INPUT:
 *    unit          -- Unit number.
 *    inst_idx      -- Instance index.
 *    subinst_idx   -- Sub instance index.
 *    table_id      -- Table ID.
 *    entry_idx     -- Entry index in table.
 *    entry_num     -- Number of entries to read.
 * OUTPUT:
 *    ptr_dst_buf   -- pointer to the entry buffer
 * RETURN:
 *    CLX_E_OK      -- Read success.
 *    Others        -- Read fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_dmaReadTcam(
    const UI32_T    unit,
    void            *ptr_dst_buf,
    const UI32_T    inst_idx,
    const UI32_T    subinst_idx,
    const UI32_T    table_id,
    const UI32_T    entry_idx,
    const UI32_T    entry_num);

/* FUNCTION NAME: hal_cmn_dmaWriteTcam
 * PURPOSE:
 *    dma write tcam table from host memory to device
 *    (not transform entry data from data/mask to cell-c/cell-t view)
 * INPUT:
 *    unit          -- Unit number.
 *    ptr_src_buf   -- pointer to the entry buffer
 *    inst_idx      -- Instance index.
 *    subinst_idx   -- Sub instance index.
 *    table_id      -- Table ID.
 *    entry_idx     -- Entry index in table.
 *    entry_num     -- Number of entries to write.
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK      -- Write success.
 *    Others        -- Write fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_dmaWriteTcam(
    const UI32_T    unit,
    void            *ptr_src_buf,
    const UI32_T    inst_idx,
    const UI32_T    subinst_idx,
    const UI32_T    table_id,
    const UI32_T    entry_idx,
    const UI32_T    entry_num);

/* FUNCTION NAME: hal_cmn_dmaCopyTcam
 * PURPOSE:
 *    dma copy tcam table from device to device
 * INPUT:
 *    unit          -- Unit number.
 *    inst_idx      -- Instance index.
 *    subinst_idx   -- Sub instance index.
 *    table_id      -- Table ID.
 *    src_entry_idx -- Source entry index in table.
 *    dst_entry_idx -- Destination entry index in table.dir
 *    dir           -- Direction of copy tcam table.
 *    entry_num     -- Number of entries to copy.
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK      -- Copy success.
 *    Others        -- Copy fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_cmn_dmaCopyTcam(
    const UI32_T               unit,
    const UI32_T               inst_idx,
    const UI32_T               subinst_idx,
    const UI32_T               table_id,
    const UI32_T               src_entry_idx,
    const UI32_T               dst_entry_idx,
    const DCC_DMA_D2D_DIR_T    dir,
    const UI32_T               entry_num);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
extern HAL_CMN_CB_T    _ext_hal_cmn_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

#endif
