/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

#ifndef HAL_PKJ_DECODER_H
#define HAL_PKJ_DECODER_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_PKJ_TBL_DECODE_VALUE_S {
    UI32_T                              value;
    /* following items are used as union */
    struct HAL_PKJ_TBL_DECODE_INFO_S    *ptr_decode;
    UI32_T                              tbl_id;
} HAL_PKJ_TBL_DECODE_VALUE_T;

typedef struct HAL_PKJ_TBL_DECODE_INFO_S {
    UI32_T                        tbl_id;
    UI32_T                        field_id;
    UI32_T                        value_num;
    HAL_PKJ_TBL_DECODE_VALUE_T    *ptr_value_vec;
} HAL_PKJ_TBL_DECODE_INFO_T;

typedef struct HAL_PKJ_TBL_CB_DECODE_VALUE_S {
    UI32_T                                 value;
    /* following items are used as union */
    struct HAL_PKJ_TBL_CB_DECODE_INFO_S    *ptr_cb_decode;
    HAL_PKJ_TBL_DECODE_INFO_T              *ptr_coda_decode;
    UI32_T                                 tbl_id;
} HAL_PKJ_TBL_CB_DECODE_VALUE_T;

typedef struct HAL_PKJ_TBL_CB_DECODE_INFO_S {
    UI32_T                           cb_id;
    UI32_T                           field_id;
    UI32_T                           value_num;
    HAL_PKJ_TBL_CB_DECODE_VALUE_T    *ptr_value_vec;
} HAL_PKJ_TBL_CB_DECODE_INFO_T;

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif /* end of #ifndef HAL_PKJ_DECODER_H */
