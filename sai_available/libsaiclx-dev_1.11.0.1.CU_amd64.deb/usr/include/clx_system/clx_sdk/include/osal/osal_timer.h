#include <clx_error.h>
typedef int OSAL_TIMER_ID_T;

typedef void (*OSAL_TIMER_HANDLER_T)(void *arg);

/* EXPORTED SUBPROGRAM BODIES
 */

/* FUNCTION NAME:  osal_timer_init
 * PURPOSE:
 *      OS abstration API to init osal timer task and resource.
 *      This function can ignore when init. Because the timer 
 *      start function will also check timer task status. If timer task not start, it will init it.
 * INPUT:
 *      None
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Successfully init.
 *      CLX_E_OTHERS        -- timer init failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
osal_timer_init(void);

/* FUNCTION NAME:  osal_timer_deinit
 * PURPOSE:
 *      OS abstration API to deinit osal timer task and resource.
 * INPUT:
 *      None
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Successfully deinit.
 *      CLX_E_OTHERS        -- Trigger timer task failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
osal_timer_deinit(void);


/* FUNCTION NAME:  osal_timer_start
 * PURPOSE:
 *      OS abstration API to start a timmer.
 * INPUT:
 *      time_value_ms     -- Timer value in ms
 *      func              -- Callback function when timeout
 *      arg               -- Arg for callback function
 * OUTPUT:
 *      timerid           -- timerid
 * RETURN:
 *      CLX_E_OK          -- Successfully get time.
 *      CLX_E_TABLE_FULL  -- No Timer resource
 *      CLX_E_OTHERS      -- Fail to get time.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
osal_timer_start(
    OSAL_TIMER_ID_T               *out_timerid,
    const UI32_T                  time_value_ms,
    const OSAL_TIMER_HANDLER_T    func,
    const void                    *arg);

/* FUNCTION NAME:  osal_timer_stop
 * PURPOSE:
 *      OS abstration API to stop running timer.
 * INPUT:
 *      timerid      -- timerid
 * OUTPUT:
 *      func_arg     -- Output user configure func_arg, if NULL, will ignore it.
 * RETURN:
 *      CLX_E_OK            -- Successfully stop timer.
 *      CLX_E_BAD_PARAMETER -- Wrong timerid.
 *      CLX_E_OTHERS        -- Stop timer failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
osal_timer_stop(
    OSAL_TIMER_ID_T     timerid,
    void                **func_arg);