/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:   clx_ifmap.h
 * PURPOSE:
 *      It provides user port to CLX port translation API.
 * NOTES:
 */

#ifndef CLX_IFMAP_H
#define CLX_IFMAP_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <hal/common/hal.h>
#include <hal/common/hal_obj.h>
#include <cmlib/cmlib_port.h>
#ifdef CLX_EN_IFMAP
#include <ifmap/hal_ifmap.h>
#include <ifmap/ifmap_clx_port.h>
#include <ifmap/ifmap_clx_ifmon.h>
#include <ifmap/ifmap_clx_vlan.h>
#include <ifmap/ifmap_clx_stp.h>
#include <ifmap/ifmap_clx_l3.h>
#include <ifmap/ifmap_clx_vm.h>
#include <ifmap/ifmap_clx_trill.h>
#include <ifmap/ifmap_clx_stk.h>
#include <ifmap/ifmap_clx_meter.h>
#include <ifmap/ifmap_clx_mir.h>
#include <ifmap/ifmap_clx_fcoe.h>
#include <ifmap/ifmap_clx_l2.h>
#include <ifmap/ifmap_clx_acl.h>
#include <ifmap/ifmap_clx_tm.h>
#include <ifmap/ifmap_clx_lag.h>
#include <ifmap/ifmap_clx_sec.h>
#include <ifmap/ifmap_clx_mpls.h>
#include <ifmap/ifmap_hal_dflt.h>
#include <ifmap/ifmap_clx_stat.h>
#include <ifmap/ifmap_clx_l3t.h>
#include <ifmap/ifmap_clx_pppoe.h>
#include <ifmap/ifmap_clx_swc.h>
#include <ifmap/ifmap_hal_phy.h>
#include <ifmap/ifmap_hal_cfg.h>
#endif /* #ifdef CLX_EN_IFMAP */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* macro define for CPU/CPI/RC user port mapping */
#define CLX_IFMAP_PORT_ID_CPU       (CLX_PORT_INVALID-1)
#define CLX_IFMAP_PORT_ID_CPI_0     (CLX_PORT_INVALID-2)
#define CLX_IFMAP_PORT_ID_CPI_1     (CLX_PORT_INVALID-3)
#define CLX_IFMAP_PORT_ID_RC_0      (CLX_PORT_INVALID-4)
#define CLX_IFMAP_PORT_ID_RC_1      (CLX_PORT_INVALID-5)

#ifdef CLX_EN_IFMAP
/* semaphosre macros */
#define CLX_IFMAP_LOCK(__unit__)            (hal_ifmap_lockResource(__unit__))
#define CLX_IFMAP_UNLOCK(__unit__)          (hal_ifmap_unlockResource(__unit__))
#define CLX_IFMAP_L2_LOCK(__unit__)         (hal_ifmap_l2_lockResource(__unit__))
#define CLX_IFMAP_L2_UNLOCK(__unit__)       (hal_ifmap_l2_unlockResource(__unit__))
#define CLX_IFMAP_TM_LOCK(__unit__)         (hal_ifmap_tm_lockResource(__unit__))
#define CLX_IFMAP_TM_UNLOCK(__unit__)       (hal_ifmap_tm_unlockResource(__unit__))
#define CLX_IFMAP_IFMON_LOCK(__unit__)      (hal_ifmap_ifmon_lockResource(__unit__))
#define CLX_IFMAP_IFMON_UNLOCK(__unit__)    (hal_ifmap_ifmon_unlockResource(__unit__))
#define CLX_IFMAP_PKT_LOCK(__unit__)        (hal_ifmap_pkt_lockResource(__unit__))
#define CLX_IFMAP_PKT_UNLOCK(__unit__)      (hal_ifmap_pkt_unlockResource(__unit__))

#define CLX_IFMAP_FUNC_CALL(__unit__, __module__, __func__, __param__)                                              \
({                                                                                                                  \
    CLX_ERROR_NO_T __rc = CLX_E_OK;                                                                                 \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )                           \
    {                                                                                                               \
        DIAG_PRINT(HAL_DBG_INFO,"[N]\n");                                                                           \
       __rc= (ifmap_clx##_##__module__##_##__func__ __param__);                                                     \
    }                                                                                                               \
    else                                                                                                            \
    {                                                                                                               \
        if ((NULL == PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec) ||                                       \
            (NULL == PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec->hal_##__module__##_##__func__))          \
        {                                                                                                           \
            __rc = CLX_E_NOT_SUPPORT;                                                                               \
        }                                                                                                           \
        else                                                                                                        \
        {                                                                                                           \
            DIAG_PRINT(HAL_DBG_INFO,"[N]\n");                                                                       \
            __rc = (PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec->hal_##__module__##_##__func__ __param__); \
        }                                                                                                           \
    }                                                                                                               \
    __rc;                                                                                                           \
})

#define CLX_IFMAP_HAL_API_CALL(__unit__, __module__, __func__, __param__)                                           \
({                                                                                                                  \
    CLX_ERROR_NO_T __rc = CLX_E_OK;                                                                                 \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )                           \
    {                                                                                                               \
       __rc= (ifmap_hal##_##__module__##_##__func__ __param__);                                                     \
    }                                                                                                               \
    else                                                                                                            \
    {                                                                                                               \
       __rc= (hal##_##__module__##_##__func__ __param__);                                                           \
    }                                                                                                               \
    __rc;                                                                                                           \
})

/* macro to translate user-port to cl-port */
#define CLX_IFMAP_PORT_USER_TO_CL(__unit__, __user_port__, __cl_port__) do                  \
{                                                                                           \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        __cl_port__ = HAL_IFMAP_USER_PORT_MAP_INFO(__unit__, __user_port__);                \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        __cl_port__ =  __user_port__;                                                       \
    }                                                                                       \
} while(0)

/* macro to translate cl-port to user-port */
#define CLX_IFMAP_PORT_CL_TO_USER(__unit__, __cl_port__, __user_port__) do                  \
{                                                                                           \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        __user_port__ = HAL_IFMAP_CL_PORT_MAP_INFO(__unit__, __cl_port__);                  \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        __user_port__ = __cl_port__;                                                        \
    }                                                                                       \
} while(0)

/* macro to translate user-port-bitmap to cl-port-bitmap */
#define CLX_IFMAP_PBMP_USER_TO_CL(__unit__, __user_pbmp__, __np_pbmp__) do                  \
{                                                                                           \
    UI32_T    __up, __np;                                                                   \
    CLX_PORT_BITMAP_CLEAR(__np_pbmp__);                                                     \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        CLX_PORT_FOREACH(__user_pbmp__, __up)                                               \
        {                                                                                   \
            __np = HAL_IFMAP_USER_PORT_MAP_INFO(__unit__, __up);                            \
            if (CLX_PORT_INVALID != __np)                                                   \
            {                                                                               \
                CLX_PORT_ADD(__np_pbmp__, __np);                                            \
            }                                                                               \
            else                                                                            \
            {                                                                               \
                DIAG_PRINT(HAL_DBG_ERR,"u=%u, pbmp translation failed, up=%u to cl=%u\n",   \
                __unit__, __up, __np);                                                      \
            }                                                                               \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        CMLIB_PORT_BITMAP_SET(__np_pbmp__, __user_pbmp__);                                  \
    }                                                                                       \
} while (0)

/* macro to translate cl-port-bitmap to user-port-bitmap */
#define CLX_IFMAP_PBMP_CL_TO_USER(__unit__, __np_pbmp__, __user_pbmp__) do                  \
{                                                                                           \
    UI32_T    __up, __np;                                                                   \
    CLX_PORT_BITMAP_CLEAR(__user_pbmp__);                                                   \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        CLX_PORT_FOREACH(__np_pbmp__, __np)                                                 \
        {                                                                                   \
            __up = HAL_IFMAP_CL_PORT_MAP_INFO(__unit__, __np);                              \
            if (CLX_PORT_INVALID != __up)                                                   \
            {                                                                               \
                CLX_PORT_ADD(__user_pbmp__, __up);                                          \
            }                                                                               \
            else                                                                            \
            {                                                                               \
                DIAG_PRINT(HAL_DBG_ERR,"u=%u, pbmp translation failed, cl=%u to cl=%u\n",   \
                __unit__, __np, __up);                                                      \
            }                                                                               \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        CMLIB_PORT_BITMAP_SET(__user_pbmp__, __np_pbmp__);                                  \
    }                                                                                       \
} while (0)

/* macro to translate user-port_t to cl-port_t */
#define CLX_IFMAP_PORT_T_USER_TO_CL(__unit__, __user_port_t__, __clx_port_t__) do           \
{                                                                                           \
    CLX_PORT_TYPE_T __port_type;                                                            \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        HAL_OBJ_TYPE_GET((__user_port_t__), __port_type);                                   \
        if (CLX_PORT_TYPE_NORMAL == __port_type)                                            \
        {                                                                                   \
            CLX_IFMAP_PORT_USER_TO_CL((__unit__), (__user_port_t__), (__clx_port_t__));     \
        }                                                                                   \
        else                                                                                \
        {                                                                                   \
            (__clx_port_t__) = (__user_port_t__);                                           \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        (__clx_port_t__) = (__user_port_t__);                                               \
    }                                                                                       \
} while(0)

/* macro to translate cl-port_t to user-port_t */
#define CLX_IFMAP_PORT_T_CL_TO_USER(__unit__, __clx_port_t__, __user_port_t__) do           \
{                                                                                           \
    CLX_PORT_TYPE_T __port_type;                                                            \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        HAL_OBJ_TYPE_GET((__clx_port_t__), __port_type);                                    \
        if (CLX_PORT_TYPE_NORMAL == __port_type)                                            \
        {                                                                                   \
            CLX_IFMAP_PORT_CL_TO_USER((__unit__), (__clx_port_t__), (__user_port_t__));     \
        }                                                                                   \
        else                                                                                \
        {                                                                                   \
            (__user_port_t__) = (__clx_port_t__);                                           \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        (__user_port_t__) = (__clx_port_t__);                                               \
    }                                                                                       \
} while(0)

/* macro to get user CPU port */
#define CLX_IFMAP_CPU_PORT(__unit__)    (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_CPU_PORT(__unit__)) : (HAL_CPU_PORT(__unit__)))

/* macro to get user CPI ports */
#define CLX_IFMAP_CPI_PORT_0(__unit__)      (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_CPI_PORT(__unit__, 0)) : (HAL_CPI_PORT(__unit__, 0)))

#define CLX_IFMAP_CPI_PORT_1(__unit__)      (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_CPI_PORT(__unit__, 1)) : (HAL_CPI_PORT(__unit__, 1)))


/* macro to get user RC ports */
#define CLX_IFMAP_RC_PORT_0(__unit__)       (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_RC_PORT(__unit__, 0)) : (HAL_RC_PORT(__unit__, 0)))

#define CLX_IFMAP_RC_PORT_1(__unit__)       (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_RC_PORT(__unit__, 1)) : (HAL_RC_PORT(__unit__, 1)))


/* macro to get user-port bitmap */
#define CLX_IFMAP_PBMP(__unit__)        (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_PORT_BMP(__unit__)) : (HAL_PORT_BMP(__unit__)))

#define CLX_IFMAP_PBMP_PP(__unit__)     (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_PORT_BMP_PP(__unit__)) : (HAL_PORT_BMP_PP(__unit__)))

#define CLX_IFMAP_PBMP_ETH(__unit__)    (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_PORT_BMP_ETH(__unit__)) : (HAL_PORT_BMP_ETH(__unit__)))

#define CLX_IFMAP_PBMP_PHY(__unit__)    (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_PORT_BMP_PHY(__unit__)) : (HAL_PORT_BMP_PHY(__unit__)))

#define CLX_IFMAP_PBMP_TOTAL(__unit__)  (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_USER_PORT_BMP_TOTAL(__unit__)) : \
    (HAL_PORT_BMP_TOTAL(__unit__)))

/* macro for coding decision statement */
#define CLX_IFMAP_IS_PORT_VALID(__unit__, __user_port__)    (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) ||       \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_IS_USER_PORT_VALID(__unit__, __user_port__)) :    \
    (HAL_IS_PORT_VALID(__unit__, __user_port__)))

#define CLX_IFMAP_IS_ETH_PORT_VALID(__unit__, __user_port__)    (((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) ||   \
    (HAL_IS_DEVICE_DAWN_FAMILY(__unit__))) ? (HAL_IFMAP_IS_USER_ETH_PORT_VALID(__unit__, __user_port__)) :\
    (HAL_IS_ETH_PORT_VALID(__unit__, __user_port__)))

/* macro to check user-port (check fail will return directly) */
#define CLX_IFMAP_CHECK_PORT(__unit__, __user_port__) do                                    \
{                                                                                           \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        if (!HAL_IFMAP_IS_USER_PORT_VALID((__unit__), (__user_port__)))                     \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user port=%u, rc=%d\n",                 \
            __unit__, __user_port__, CLX_E_BAD_PARAMETER);                                  \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        if (!HAL_IS_PORT_VALID((__unit__), (__user_port__)))                                \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid port=%u, rc=%d\n",                      \
            __unit__, __user_port__, CLX_E_BAD_PARAMETER);                                  \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
} while (0)

#define CLX_IFMAP_CHECK_ETH_PORT(__unit__, __user_port__) do                                \
{                                                                                           \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        if (!HAL_IFMAP_IS_USER_ETH_PORT_VALID((__unit__), (__user_port__)))                 \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user eth port=%u, rc=%d\n",             \
            __unit__, __user_port__, CLX_E_BAD_PARAMETER);                                  \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        if (!HAL_IS_ETH_PORT_VALID((__unit__), (__user_port__)))                            \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid eth port=%u, rc=%d\n",                  \
            __unit__, __user_port__, CLX_E_BAD_PARAMETER);                                  \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
} while (0)

#define CLX_IFMAP_CHECK_PP_PORT(__unit__, __user_port__) do                                 \
{                                                                                           \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        if (!HAL_IFMAP_IS_USER_PP_PORT_VALID((__unit__), (__user_port__)))                  \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user pp port=%u, rc=%d\n",              \
            __unit__, __user_port__, CLX_E_BAD_PARAMETER);                                  \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        if (!HAL_IS_PP_PORT_VALID((__unit__), (__user_port__)))                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid pp port=%u, rc=%d\n",                   \
            __unit__, __user_port__, CLX_E_BAD_PARAMETER);                                  \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
} while (0)

#define CLX_IFMAP_CHECK_PHY_PORT(__unit__, __user_port__) do                                \
{                                                                                           \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        if (!HAL_IFMAP_IS_USER_PHY_PORT_VALID((__unit__), (__user_port__)))                 \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user phy port=%u, rc=%d\n",             \
            __unit__, __user_port__, CLX_E_BAD_PARAMETER);                                  \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        if (!HAL_IS_PHY_PORT_VALID((__unit__), (__user_port__)))                            \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid phy port=%u, rc=%d\n",                  \
            __unit__, __user_port__, CLX_E_BAD_PARAMETER);                                  \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
} while (0)

/* macro to check user-port bitmaps (check faill will return directly) */
#define CLX_IFMAP_CHECK_PORT_BITMAP(__unit__, __user_pbmp__) do                             \
{                                                                                           \
    CLX_PORT_BITMAP_T __bitmap__;                                                           \
                                                                                            \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_IFMAP_USER_PORT_BMP((__unit__)));             \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                                 \
                                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user port bitmap, rc=%d\n",             \
            __unit__, CLX_E_BAD_PARAMETER);                                                 \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP((__unit__)));                        \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                                 \
                                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid port bitmap, rc=%d\n",                  \
            __unit__, CLX_E_BAD_PARAMETER);                                                 \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
} while (0)

#define CLX_IFMAP_CHECK_ETH_PORT_BITMAP(__unit__, __user_pbmp__) do                         \
{                                                                                           \
    CLX_PORT_BITMAP_T __bitmap__;                                                           \
                                                                                            \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_IFMAP_USER_PORT_BMP_ETH((__unit__)));         \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                                 \
                                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user eth port bitmap, rc=%d\n",         \
            __unit__, CLX_E_BAD_PARAMETER);                                                 \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_ETH((__unit__)));                    \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                                 \
                                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid eth port bitmap, rc=%d\n",              \
            __unit__, CLX_E_BAD_PARAMETER);                                                 \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
} while (0)

#define CLX_IFMAP_CHECK_PP_PORT_BITMAP(__unit__, __user_pbmp__) do                          \
{                                                                                           \
    CLX_PORT_BITMAP_T __bitmap__;                                                           \
                                                                                            \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_IFMAP_USER_PORT_BMP_PP((__unit__)));          \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                                 \
                                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user pp port bitmap, rc=%d\n",          \
            __unit__, CLX_E_BAD_PARAMETER);                                                 \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_PP((__unit__)));                     \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                                 \
                                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid pp port bitmap, rc=%d\n",               \
            __unit__, CLX_E_BAD_PARAMETER);                                                 \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
} while (0)

#define CLX_IFMAP_CHECK_PHY_PORT_BITMAP(__unit__, __user_pbmp__) do                         \
{                                                                                           \
    CLX_PORT_BITMAP_T __bitmap__;                                                           \
                                                                                            \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_IFMAP_USER_PORT_BMP_PHY((__unit__)));         \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                                 \
                                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user phy port bitmap, rc=%d\n",         \
            __unit__, CLX_E_BAD_PARAMETER);                                                 \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
    else                                                                                    \
    {                                                                                       \
        CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_PHY((__unit__)));                    \
        CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                                 \
                                                                                            \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                                             \
        {                                                                                   \
            DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid phy port bitmap, rc=%d\n",              \
            __unit__, CLX_E_BAD_PARAMETER);                                                 \
            return  CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                   \
    }                                                                                       \
} while (0)

/* macro to check user-port CLX PORT_T (check faill will return directly) */
#define CLX_IFMAP_CHECK_PORT_T(__unit__, __user_port__) do                                  \
{                                                                                           \
    CLX_PORT_TYPE_T __port_type;                                                            \
    if ((HAL_IS_DEVICE_LIGHTNING_FAMILY(__unit__)) || (HAL_IS_DEVICE_DAWN_FAMILY(__unit__)) )   \
    {                                                                                       \
        HAL_OBJ_TYPE_GET((__user_port__), __port_type);                                     \
        if (CLX_PORT_TYPE_NORMAL == __port_type)                                            \
        {                                                                                   \
            if (!HAL_IFMAP_IS_USER_PORT_VALID((__unit__), (__user_port__)))                 \
            {                                                                               \
                DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid user port=%u, rc=%d\n",             \
                __unit__, __user_port__, CLX_E_BAD_PARAMETER);                              \
                return  CLX_E_BAD_PARAMETER;                                                \
            }                                                                               \
        }                                                                                   \
    }                                                                                       \
} while (0)

#else /* !CLX_EN_IFMAP */
/* semaphosre macros */
#define CLX_IFMAP_LOCK(__unit__)
#define CLX_IFMAP_UNLOCK(__unit__)
#define CLX_IFMAP_L2_LOCK(__unit__)
#define CLX_IFMAP_L2_UNLOCK(__unit__)
#define CLX_IFMAP_TM_LOCK(__unit__)
#define CLX_IFMAP_TM_UNLOCK(__unit__)

#define CLX_IFMAP_FUNC_CALL(__unit__, __module__, __func__, __param__)                                              \
({                                                                                                                  \
    CLX_ERROR_NO_T __rc = CLX_E_OK;                                                                                 \
    if ((NULL == PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec) ||                                           \
    (NULL == PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec->hal_##__module__##_##__func__))                  \
    {                                                                                                               \
        __rc = CLX_E_NOT_SUPPORT;                                                                                   \
    }                                                                                                               \
    else                                                                                                            \
    {                                                                                                               \
        DIAG_PRINT(HAL_DBG_INFO,"[N]\n");                                                                           \
        __rc = (PTR_HAL_FUNC_VECTOR(__unit__)->__module__##_func_vec->hal_##__module__##_##__func__ __param__);     \
    }                                                                                                               \
    __rc;                                                                                                           \
})

#define CLX_IFMAP_HAL_API_CALL(__unit__, __module__, __func__, __param__)                                           \
({                                                                                                                  \
    CLX_ERROR_NO_T __rc = CLX_E_OK;                                                                                 \
    __rc= (hal##_##__module__##_##__func__ __param__);                                                              \
    __rc;                                                                                                           \
})

/* macro to translate user-port to cl-port */
#define CLX_IFMAP_PORT_USER_TO_CL(__unit__, __user_port__, __cl_port__)

/* macro to translate cl-port to user-port */
#define CLX_IFMAP_PORT_CL_TO_USER(__unit__, __cl_port__, __user_port__)

/* macro to translate user-port-bitmap to cl-port-bitmap */
#define CLX_IFMAP_PBMP_USER_TO_CL(__unit__, __user_pbmp__, __np_pbmp__)

/* macro to translate cl-port-bitmap to user-port-bitmap */
#define CLX_IFMAP_PBMP_CL_TO_USER(__unit__, __np_pbmp__, __user_pbmp__)

/* macro to translate user-port_t to cl-port_t */
#define CLX_IFMAP_PORT_T_USER_TO_CL(__unit__, __user_port_t__, __cl_port_t__)

/* macro to translate cl-port_t to user-port_t */
#define CLX_IFMAP_PORT_T_CL_TO_USER(__unit__, __cl_port_t__, __user_port_t__)

/* macro to get user CPU port */
#define CLX_IFMAP_CPU_PORT(__unit__)        (HAL_CPU_PORT(__unit__))

/* macro to get user CPI ports */
#define CLX_IFMAP_CPI_PORT_0(__unit__)      (HAL_CPI_PORT(__unit__, 0))
#define CLX_IFMAP_CPI_PORT_1(__unit__)      (HAL_CPI_PORT(__unit__, 1))

/* macro to get user RC ports */
#define CLX_IFMAP_RC_PORT_0(__unit__)       (HAL_RC_PORT(__unit__, 0))
#define CLX_IFMAP_RC_PORT_1(__unit__)       (HAL_RC_PORT(__unit__, 1))

/* macro to get user-port bitmap */
#define CLX_IFMAP_PBMP(__unit__)        (HAL_PORT_BMP(__unit__))
#define CLX_IFMAP_PBMP_PP(__unit__)     (HAL_PORT_BMP_PP(__unit__))
#define CLX_IFMAP_PBMP_ETH(__unit__)    (HAL_PORT_BMP_ETH(__unit__))
#define CLX_IFMAP_PBMP_PHY(__unit__)    (HAL_PORT_BMP_PHY(__unit__))
#define CLX_IFMAP_PBMP_TOTAL(__unit__)  (HAL_PORT_BMP_TOTAL(__unit__))

/* macro for coding decision statement */
#define CLX_IFMAP_IS_PORT_VALID(__unit__, __user_port__)                \
                    (HAL_IS_PORT_VALID(__unit__, __user_port__))
#define CLX_IFMAP_IS_ETH_PORT_VALID(__unit__, __user_port__)            \
                    (HAL_IS_ETH_PORT_VALID(__unit__, __user_port__))

/* macro to check user-port (check fail will return directly) */
#define CLX_IFMAP_CHECK_PORT(__unit__, __user_port__) do                \
{                                                                       \
    if (!HAL_IS_PORT_VALID((__unit__), (__user_port__)))                \
    {                                                                   \
        DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid port=%u, rc=%d\n",      \
        __unit__, __user_port__, CLX_E_BAD_PARAMETER);                  \
        return  CLX_E_BAD_PARAMETER;                                    \
    }                                                                   \
} while (0)

#define CLX_IFMAP_CHECK_ETH_PORT(__unit__, __user_port__) do            \
{                                                                       \
    if (!HAL_IS_ETH_PORT_VALID((__unit__), (__user_port__)))            \
    {                                                                   \
        DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid eth port=%u, rc=%d\n",  \
        __unit__, __user_port__, CLX_E_BAD_PARAMETER);                  \
        return  CLX_E_BAD_PARAMETER;                                    \
    }                                                                   \
} while (0)

#define CLX_IFMAP_CHECK_PP_PORT(__unit__, __user_port__) do             \
{                                                                       \
    if (!HAL_IS_PP_PORT_VALID((__unit__), (__user_port__)))             \
    {                                                                   \
        DIAG_PRINT(HAL_DBG_ERR, "u=%u, invalid pp port=%u, rc=%d\n",    \
        __unit__, __user_port__, CLX_E_BAD_PARAMETER);                  \
        return  CLX_E_BAD_PARAMETER;                                    \
    }                                                                   \
} while (0)

#define CLX_IFMAP_CHECK_PHY_PORT(__unit__, __user_port__) do            \
{                                                                       \
    if (!HAL_IS_PHY_PORT_VALID((__unit__), (__user_port__)))            \
    {                                                                   \
        DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid phy port=%u, rc=%d\n",  \
        __unit__, __user_port__, CLX_E_BAD_PARAMETER);                  \
        return  CLX_E_BAD_PARAMETER;                                    \
    }                                                                   \
} while (0)

/* macro to check user-port bitmaps (check faill will return directly) */
#define CLX_IFMAP_CHECK_PORT_BITMAP(__unit__, __user_pbmp__) do         \
{                                                                       \
    CLX_PORT_BITMAP_T __bitmap__;                                       \
                                                                        \
    CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP((__unit__)));        \
    CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                 \
                                                                        \
    if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                             \
    {                                                                   \
        DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid port bitmap, rc=%d\n",  \
        __unit__, CLX_E_BAD_PARAMETER);                                 \
        return  CLX_E_BAD_PARAMETER;                                    \
    }                                                                   \
} while (0)

#define CLX_IFMAP_CHECK_ETH_PORT_BITMAP(__unit__, __user_pbmp__) do     \
{                                                                       \
    CLX_PORT_BITMAP_T __bitmap__;                                       \
                                                                        \
    CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_ETH((__unit__)));    \
    CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                 \
                                                                        \
    if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                             \
    {                                                                   \
        DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid eth port bitmap, "      \
        "rc=%d\n", __unit__, CLX_E_BAD_PARAMETER);                      \
        return  CLX_E_BAD_PARAMETER;                                    \
    }                                                                   \
} while (0)

#define CLX_IFMAP_CHECK_PP_PORT_BITMAP(__unit__, __user_pbmp__) do      \
{                                                                       \
    CLX_PORT_BITMAP_T __bitmap__;                                       \
                                                                        \
    CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_PP((__unit__)));     \
    CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                 \
                                                                        \
    if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                             \
    {                                                                   \
        DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid pp port bitmap, "       \
        "rc=%d\n", __unit__, CLX_E_BAD_PARAMETER);                      \
        return  CLX_E_BAD_PARAMETER;                                    \
    }                                                                   \
} while (0)

#define CLX_IFMAP_CHECK_PHY_PORT_BITMAP(__unit__, __user_pbmp__) do     \
{                                                                       \
    CLX_PORT_BITMAP_T __bitmap__;                                       \
                                                                        \
    CMLIB_PORT_BITMAP_INV(__bitmap__, HAL_PORT_BMP_PHY((__unit__)));    \
    CMLIB_PORT_BITMAP_AND(__bitmap__, (__user_pbmp__));                 \
                                                                        \
    if (!CLX_PORT_BITMAP_EMPTY(__bitmap__))                             \
    {                                                                   \
        DIAG_PRINT(HAL_DBG_WARN, "u=%u, invalid phy port bitmap, "      \
        "rc=%d\n", __unit__, CLX_E_BAD_PARAMETER);                      \
        return  CLX_E_BAD_PARAMETER;                                    \
    }                                                                   \
} while (0)

/* macro to check user-port CLX PORT_T (!CLX_EN_IFMAP, it will be empty) */
#define CLX_IFMAP_CHECK_PORT_T(__unit__, __user_port__)

#endif /* CLX_EN_IFMAP */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_ifmap_initUserPortMap
 * PURPOSE:
 *      To initialize the user port to cl port mapping.
 * INPUT:
 *      unit                -- Device unit number
 *      port_cnt            -- Port count
 *      ptr_user_port_list  -- List of user ports want to map
 *      ptr_cl_port_list    -- List of cl port ID that user port map to
 *
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_ifmap_initUserPortMap(
    const UI32_T    unit,
    const UI32_T    port_cnt,
    const UI32_T    *ptr_user_port_list,
    const UI32_T    *ptr_cl_port_list);

/* FUNCTION NAME:   clx_ifmap_setUserPortMap
 * PURPOSE:
 *      To set the user port to cl port mapping.
 * INPUT:
 *      unit                -- Device unit number
 *      port_cnt            -- Port count
 *      ptr_user_port_list  -- List of user ports want to set
 *      ptr_cl_port_list    -- List of cl port ID that user port map to
 *
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_ifmap_setUserPortMap(
    const UI32_T    unit,
    const UI32_T    port_cnt,
    const UI32_T    *ptr_user_port_list,
    const UI32_T    *ptr_cl_port_list);

/* FUNCTION NAME:   clx_ifmap_getUserPortMap
 * PURPOSE:
 *      To get the user port to cl port mapping.
 * INPUT:
 *      unit                -- Device unit number
 *      port_cnt            -- Port count
 *      ptr_user_port_list  -- List of user ports want to get
 *      ptr_cl_port_list    -- List of cl port ID that user port map to
 *
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_ifmap_getUserPortMap(
    const UI32_T    unit,
    const UI32_T    port_cnt,
    const UI32_T    *ptr_user_port_list,
          UI32_T    *ptr_cl_port_list);

#endif /* End of #ifndef CLX_IFMAP_H */

