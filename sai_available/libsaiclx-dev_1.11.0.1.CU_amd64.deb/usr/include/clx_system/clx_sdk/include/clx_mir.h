/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  clx_mir.h
 * PURPOSE:
 *      Define the declaration for mirror module in CLX SDK.
 *
 * NOTES:
 */

#ifndef CLX_MIR_H
#define CLX_MIR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* Mirror direction */
typedef enum
{
    CLX_MIR_DIRECTION_INGRESS = 0,  /* ingress mirror session */
    CLX_MIR_DIRECTION_EGRESS,       /* egress mirror session */
    CLX_MIR_DIRECTION_LAST,
} CLX_MIR_DIRECTION_T;

/* Mirror type */
typedef enum
{
    CLX_MIR_TYPE_LOCALSPAN = 0,     /* mirror session type is local span */
    CLX_MIR_TYPE_RSPAN_SRC,         /* mirror session type is rspan source */
    CLX_MIR_TYPE_RSPAN_DST,         /* mirror session type is rspan termination */
    CLX_MIR_TYPE_ERSPAN_SRC,        /* mirror session type is erspan source */
    CLX_MIR_TYPE_ERSPAN_DST,        /* mirror session type is erspan termination */
    CLX_MIR_TYPE_LAST,
} CLX_MIR_TYPE_T;

/* ERSPAN term information */
typedef struct CLX_MIR_ERSPAN_TERM_S
{
    CLX_IP_ADDR_T   src_ip;         /* Source IP address      */
    CLX_IP_ADDR_T   dst_ip;         /* Destination IP address */
    UI32_T          erspan_id;      /* ERSPAN ID              */
    UI32_T          session_bitmap; /* Mirror session bitmap  */
} CLX_MIR_ERSPAN_TERM_T;

/* ERSPAN header type */
typedef enum
{
    CLX_MIR_ERSPAN_HDR_TYPE_8BYTES = 0, /* ERSPAN type II               */
    CLX_MIR_ERSPAN_HDR_TYPE_12BYTES,    /* ERSPAN type III              */
    CLX_MIR_ERSPAN_HDR_TYPE_20BYTES,    /* ERSPAN type III with option  */
    CLX_MIR_ERSPAN_HDR_TYPE_0BYTES,     /* ERSPAN type I                */
    CLX_MIR_ERSPAN_HDR_TYPE_FLEX_TUNNEL,    /* use flex_tunnel_idx point to flex tunnel */
    CLX_MIR_ERSPAN_HDR_TYPE_LAST,
} CLX_MIR_ERSPAN_HDR_TYPE_T;

/* ERSPAN packet configuration */
typedef struct CLX_MIR_ERSPAN_PKT_S
{
    CLX_MAC_T                    src_mac;           /* L2 source MAC address                 */
    CLX_MAC_T                    dst_mac;           /* L2 destination MAC address            */
    CLX_IP_ADDR_T                src_ip;            /* Source IPv4 address                   */
    CLX_IP_ADDR_T                dst_ip;            /* Destination IPv4 address              */
    UI8_T                        dscp;              /* Differentiated Services Code Point    */
    UI8_T                        ttl;               /* Hop limit                             */
    UI32_T                       init_seq_num;      /* Initial sequence number of GRE header */
    CLX_MIR_ERSPAN_HDR_TYPE_T    erspan_type;       /* Type of ERSPAN header                 */
    UI32_T                       erspan_id;         /* ERSPAN ID in ERSPAN header            */
    UI8_T                        flex_tunnel_idx;   /* point to flex tunnel */
} CLX_MIR_ERSPAN_PKT_T;

/* Mirror session information */
typedef struct CLX_MIR_SESSION_S
{
    UI32_T                  session_id;         /* Session ID                            */
    CLX_MIR_DIRECTION_T     direction;          /* Direction of mirror traffic           */
    CLX_MIR_TYPE_T          mir_type;           /* Mirror type                           */
    UI32_T                  truncate_size;      /* Truncate size                         */
    UI32_T                  meter_rate;         /* Rate limitation (unit: 1kbps or 1pps) */
    UI32_T                  meter_burst_size;   /* Burst size (unit: 1byte or 1pkt)      */
    CLX_PORT_T              port;               /* Destination port/lag                  */
    CLX_VLAN_T              cvid;               /* cvid value for RSPAN/ERSPAN           */
    CLX_VLAN_T              svid;               /* svid value for RSPAN/ERSPAN           */
    UI8_T                   pcp;                /* pcp value for RSPAN/ERSPAN            */
    UI8_T                   dei;                /* dei value for RSPAN/ERSPAN            */
    UI8_T                   tc;                 /* New TC value                          */
    CLX_MIR_ERSPAN_PKT_T    erspan;             /* ERSPAN configuration                  */

#define CLX_MIR_SESSION_FLAGS_METER_EN              (1U << 0)   /* If set, enable rate limitation */
#define CLX_MIR_SESSION_FLAGS_USE_NEW_TC            (1U << 1)   /* If set, use new TC value as queue source.
                                                                 * Otherwise, use TC value in original packet.
                                                                 */
#define CLX_MIR_SESSION_FLAGS_CVID_VALID            (1U << 2)   /* If set, add C-TAG for RSPAN/ERSPAN */
#define CLX_MIR_SESSION_FLAGS_SVID_VALID            (1U << 3)   /* If set, add S-TAG for RSPAN/ERSPAN */
#define CLX_MIR_SESSION_FLAGS_RSPAN_REPLACE_TAG     (1U << 4)   /* Replace or add tag for RSPAN VLAN operation */
#define CLX_MIR_SESSION_FLAGS_RSPAN_DROP_BPDU       (1U << 5)   /* If set, drop BPDU packet control for RSPAN */
#define CLX_MIR_SESSION_FLAGS_RSPAN_DROP_CTRL_PKT   (1U << 6)   /* If set, drop control packet control for RSPAN */
#define CLX_MIR_SESSION_FLAGS_ERSPAN_SEQ_NUM        (1U << 7)   /* If set, GRE header with sequence number */
#define CLX_MIR_SESSION_FLAGS_NO_DECAP              (1U << 8)   /* RSPAN DST: Whether not to decap VLAN TAG
                                                                 * ERSPAN DST: Whether not to decap ERSPAN header
                                                                 */
#define CLX_MIR_SESSION_FLAGS_ERSPAN_TO_RSPAN_TRAN  (1U << 9)   /* ERSPAN DST: If set, translate from ERSPAN to RSPAN format */
#define CLX_MIR_SESSION_FLAGS_RSPAN_TO_ERSPAN_TRAN  (1U << 10)  /* RSPAN DST: If set, translate from RSPAN to ERSPAN format */
#define CLX_MIR_SESSION_FLAGS_METER_PACKET_RATE     (1U << 11)  /* If set, rate limitation uses packet rate */
#define CLX_MIR_SESSION_FLAGS_METER_BURST_SIZE      (1U << 12)  /* If set, use meter_burst_size as meter burst size */

    UI32_T                  flags;      /* Set CLX_MIR_SESSION_FLAGS_xxx flag */
} CLX_MIR_SESSION_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_mir_addSession
 * PURPOSE:
 *      This API is used to add or set a mirror session. Mirror module supports five
 *      mirror session types, including:<CL>
 *      (1). Local SPAN session<CL>
 *      (2). RSPAN source session<CL>
 *      (3). RSPAN destination session<CL>
 *      (4). ERSPAN source session<CL>
 *      (5). ERSPAN destination session<CL>
 *      User should specify the session ID, direction and type when set a existed session.
 * INPUT:
 *      unit        --   Device unit number
 *      ptr_session --   The session information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             --  Operation is success.
 *      CLX_E_BAD_PARAMETER  --  Bad parameter.
 *      CLX_E_ENTRY_EXISTS   --  The session has been created.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_mir_addSession(
    const UI32_T                    unit,
    const CLX_MIR_SESSION_T         *ptr_session);

/* FUNCTION NAME:   clx_mir_delSession
 * PURPOSE:
 *      This API is used to delete a mirror session. <CL>
 *      User should specify the session ID and direction.<CL>
 *      Before deleting a mirror session, all sources binding to the session should be
 *      un-bound first.
 * INPUT:
 *      unit          -- Device unit number
 *      session_id    -- Mirror session ID
 *      direction     -- Mirror session direction
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK               --  Operation is successful.
 *      CLX_E_BAD_PARAMETER    --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND  --  The specified entry has not been created.
 * NOTES:
 *      Before deleting a mirror session, all mirror sources bound to the session
 *      should be removed first.
 */
CLX_ERROR_NO_T
clx_mir_delSession(
    const UI32_T                unit,
    const UI32_T                session_id,
    const CLX_MIR_DIRECTION_T   direction);

/* FUNCTION NAME:   clx_mir_getSession
 * PURPOSE:
 *      This API is used to get mirror session information. <CL>
 *      User should specify the session ID and direction.
 * INPUT:
 *      unit         --  Device unit number
 * OUTPUT:
 *      ptr_session  --  The information of this session to be obtained
 * RETURN:
 *      CLX_E_OK                -- Operation is successful.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   -- The specified entry has not been created.
 * NOTES:
 *      User must specify the session_id, direction in (ptr_session).
 */
CLX_ERROR_NO_T
clx_mir_getSession(
    const UI32_T            unit,
    CLX_MIR_SESSION_T       *ptr_session);

/* FUNCTION NAME:   clx_mir_addErspanTerm
 * PURPOSE:
 *      This API is used to add an ERSPAN tunnel term.
 * INPUT:
 *      unit                      --  Device unit number
 *      ptr_erspan_term           --  The ERSPAN termination information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                  -- Operation is successful.
 *      CLX_E_BAD_PARAMETER       -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND     -- The specified entry has not been created.
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_mir_addErspanTerm(
    const UI32_T                        unit,
    const CLX_MIR_ERSPAN_TERM_T         *ptr_erspan_term);

/* FUNCTION NAME:   clx_mir_delErspanTerm
 * PURPOSE:
 *      This API is used to delete an ERSPAN tunnel term.
 * INPUT:
 *      unit                       --  Device unit number
 *      ptr_erspan_term            --  The ERSPAN termination information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                  -- Operation is successful.
 *      CLX_E_BAD_PARAMETER       -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND     -- The specified entry has not been created.
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_mir_delErspanTerm(
    const UI32_T                        unit,
    const CLX_MIR_ERSPAN_TERM_T         *ptr_erspan_term);

/* FUNCTION NAME:   clx_mir_getErspanTerm
 * PURPOSE:
 *      This API is used to get an ERSPAN tunnel term information.
 * INPUT:
 *      unit                      --  Device unit number
 *      ptr_erspan_term           --  The ERSPAN termination information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                  -- Operation is successful
 *      CLX_E_BAD_PARAMETER       -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND     -- The specified entry has not been created
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_mir_getErspanTerm(
    const UI32_T                unit,
    CLX_MIR_ERSPAN_TERM_T       *ptr_erspan_term);

#endif
