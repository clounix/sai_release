/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  clx_ver.h
 * PURPOSE:
 *      Define the CLX SDK release version.
 *
 * NOTES:
 *
 */

#ifndef CLX_VER_H
#define CLX_VER_H

/* INCLUDE FILE DECLARATIONS
 */


/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_VER_SDK(__major__, __minor__, __rev__)  (((__major__) << 16) + ((__minor__) << 8) + (__rev__))
#define CLX_VER_MAJOR(__ver__)                      (((__ver__) & 0xFFFF0000) >> 16)
#define CLX_VER_MINOR(__ver__)                      (((__ver__) & 0x0000FF00) >> 8)
#define CLX_VER_REVISION(__ver__)                   ((__ver__) & 0x000000FF)
#define CLX_VER_BETA                                ""

#define CLX_WB_VER_SDK(__major__, __minor__, __rev__)  (((__major__) << 16) + ((__minor__) << 8) + (__rev__))
#define CLX_WB_VER_MAJOR(__ver__)                      (((__ver__) & 0xFFFF0000) >> 16)
#define CLX_WB_VER_MINOR(__ver__)                      (((__ver__) & 0x0000FF00) >> 8)
#define CLX_WB_VER_REVISION(__ver__)                   ((__ver__) & 0x000000FF)
#define CLX_WB_VER_RELEASE                             CLX_WB_VER_SDK(1,0,0)
#define CLX_WB_VER_BETA                                ""

#define CLX_VER_COMPILE_TIME CLX_MAKE_COMPILE_TIME
#if defined(CLX_RELEASED)
#include "clx_ver_released.h"
#define CLX_VER_GIT_HASH     CLX_RELEASED_GIT_HASH
#define CLX_VER_RELEASE      CLX_SDK_VERSION
#define CLX_VER_EXT_PATCH    ""
#else
#define CLX_VER_GIT_HASH     CLX_MAKE_GIT_HASH
#define CLX_VER_RELEASE      CLX_VER_SDK(1,4,2)
#define CLX_VER_EXT_PATCH    ""
#endif // CLX_RELEASED


/* MACRO FUNCTION DECLARATIONS
 */


/* DATA TYPE DECLARATIONS
 */


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */


#endif  /* CLX_VER_H */
