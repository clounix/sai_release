/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software and the information contained therein are protected by
*  copyright and other intellectual property laws and terms herein is
*  confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
*
*******************************************************************************/

/* FILE NAME:  clx_qos.h
 * PURPOSE:
 *      It provides qos module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_QOS_H
#define CLX_QOS_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>


/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_QOS_INVALID_PROFILE_ID (0xFFFFFFFF)  /* invalid profile id, to cancel qos profile */


/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/*trust1p or trust dscp*/
typedef enum
{
    CLX_TRUST_MODE_NONE = 0,
    CLX_TRUST_MODE_1P,      /* Trust 8021.p,  whether to use the 1p in packets for qos mapping */              
    CLX_TRUST_MODE_DSCP,    /* Trust dscp,  whether to use the dscp in packets for qos mapping */
    CLX_TRUST_MODE_1P_DSCP, /* Both trust 1p and dscp */
    CLX_TRUST_MODE_LAST
} CLX_TRUST_MODE_T;

/*qos mapping type*/
typedef enum
{
    CLX_QOS_MAPPING_PCP_DEI_TO_PHB = 0, /* Mapping of ingress pcp/dei to phb */
    CLX_QOS_MAPPING_DSCP_TO_PHB,        /* Mapping of ingress dscp to phb */
    CLX_QOS_MAPPING_EXP_TO_PHB,         /* Mapping of ingress exp to phb */
    CLX_QOS_MAPPING_PHB_TO_PCP_DEI,     /* Mapping of egress phb to pcp/dei */
    CLX_QOS_MAPPING_PHB_TO_DSCP,        /* Mapping of egress phb to dscp */
    CLX_QOS_MAPPING_PHB_TO_EXP,         /* Mapping of egress phb to exp */
    CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, /* Default mapping of egress phb to pcp/dei */
    CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP,    /* Default mapping of egress phb to dscp */
    CLX_QOS_MAPPING_DFLT_PHB_TO_EXP,     /* Default mapping of egress phb to exp */
    CLX_QOS_MAPPING_LAST
} CLX_QOS_MAPPING_TYPE_T;

/*qos mapping entry*/
typedef struct CLX_QOS_MAPPING_ENTRY_S
{
    UI8_T           tc;     /*Traffic class*/
    CLX_COLOR_T     color;  /*Traffic color*/
    UI8_T           pcp;    /*Priority code point*/
    UI8_T           dei;    /*Drop eligible indicator*/
    UI8_T           dscp;   /*Differentiated services code point*/
    UI8_T           exp;    /*Experimental Bits*/
    UI8_T           exp_l_lsp;  /* Used as drop precedence in l_lsp */
} CLX_QOS_MAPPING_ENTRY_T;



/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */


/* FUNCTION NAME:   clx_qos_createProfile
 * PURPOSE:
 *      This API is used to create a new QoS profile (also called QoS mapping). QoS
 *      mapping is the mapping between {pcp,dei}, {dscp} or {exp} to {tc,color}. tc(traffic
 *      class) is used by chip to derivate queue by another API clx_tm_setTcQueueMapping.
 * INPUT:
 *      unit          --  Device unit number
 *      mapping_type  --  The type of the mapping profile. <CL>
 *                          CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress pcp/dei to phb. <CL>
 *                          CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb. <CL>
 *                          CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp to phb. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb to dscp. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp.
 *      profileId     --  An assigned number that represents the software profile ID and the index
 *                        of hardware table on this QoS mapping type.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_TABLE_FULL    --  NO more memory for the entry.
 *      CLX_E_ENTRY_EXISTS  --  The mapping proile is alreaded created.
 * NOTES:
 *      Use this API to create a new mapping profile.
 */
CLX_ERROR_NO_T
clx_qos_createProfile (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profileId);

/* FUNCTION NAME:   clx_qos_delProfile
 * PURPOSE:
 *      This API is used to delete a QoS profile.
 * INPUT:
 *      unit          --  Device unit number.
 *      mapping_type  --  The type of the mapping profile. <CL>
 *                          CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress pcp/dei to phb. <CL>
 *                          CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb. <CL>
 *                          CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp to phb. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb to dscp. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp.
 *      profileId     --  An assigned number that represents the software profile ID and the index
 *                        of hardware table on this QoS mapping type.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              --  Operation successful.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  The mapping proile is not exist.
 *      CLX_E_NOT_SUPPORT     --  Not support to delete the mapping profile.
 *                                (eg. the mapping profile has been applied to a port/vm/interface/
 *                                tunnel and so on)
 * NOTES:
 *      Use this API to destroy a mapping profile. The mapping profile can be destroyed
 *      only when the mapping profile is not used by other objects
 *      (such as port/vm/interface/tunnel etc.).
 */
CLX_ERROR_NO_T
clx_qos_delProfile (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profileId);

/* FUNCTION NAME:   clx_qos_setProfileEntry
 * PURPOSE:
 *      This API is used to configure a profile entry.
 * INPUT:
 *      unit          --  Device unit number
 *      mapping_type  --  The type of the mapping profile. <CL>
 *                          CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress pcp/dei to phb. <CL>
 *                          CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb. <CL>
 *                          CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp to phb. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb to dscp. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp.
 *                          CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI means the default mapping 
 * of egress phb to pcp/dei when packets untag in.
 *                          CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP means the mapping of egress phb 
 * to dscp when packets untag in.
 *                          CLX_QOS_MAPPING_DFLT_PHB_TO_EXP means the mapping of egress phb 
 * to exp  when packets untag in.
 *      profileId     --  An assigned number that represents the software profile ID and the index
 *                        of hardware table on this QoS mapping type.
 * For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and 
 * CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profileId should set to 0.
 *      ptr_entry     --  The entry of the priority mapping.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                --  Operate success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   --  The mapping proile is not found.
 * NOTES:
 *      Use this API to configure a mapping entry. User should set all fields needed according to the
 *      "mapping_type" parameter in the entry. <CL>
 *      If "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB, fields "pcp", "dei", "tc", "color",
 *      "sticky" must be input by user, and other fields must be ignored. <CL>
 *      If "mapping_type" is CLX_QOS_MAPPING_DSCP_TO_PHB, fields "dscp", "tc", "color",
 *      "sticky" must be input by user, and other fields must be ignored. <CL>
 *      If "mapping_type" is CLX_QOS_MAPPING_EXP_TO_PHB, fields "exp", "tc", "color". <CL>
 *      If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI or CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, 
 *      fields "pcp", "dei", "tc", "color" must be input by user, and other fields must be ignored. <CL>
 *      If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_DSCP or CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP, 
 *      fields "dscp", "tc", "color" must be input by user, and other fields must be ignored. <CL>
 *      If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_EXP or CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, 
 *      fields "exp", "tc", "color" must be input by user, and other fields must be ignored.
 */
CLX_ERROR_NO_T
clx_qos_setProfileEntry (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profileId,
    const CLX_QOS_MAPPING_ENTRY_T  *ptr_entry);

/* FUNCTION NAME:   clx_qos_getProfileEntry
 * PURPOSE:
 *      This API is used to get the information of a profile entry.
 * INPUT:
 *      unit          --  Device unit number.
 *      mapping_type  --  The type of the mapping profile. <CL>
 *                          CLX_QOS_MAPPING_PCP_DEI_TO_PHB means the mapping of ingress pcp/dei to phb. <CL>
 *                          CLX_QOS_MAPPING_DSCP_TO_PHB means the mapping of ingress dscp to phb. <CL>
 *                          CLX_QOS_MAPPING_EXP_TO_PHB means the mapping of ingress exp to phb. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_PCP_DEI means the mapping of egress phb to pcp/dei. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_DSCP means the mapping of egress phb to dscp. <CL>
 *                          CLX_QOS_MAPPING_PHB_TO_EXP means the mapping of egress phb to exp.
 *                          CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI means the default mapping 
 * of egress phb to pcp/dei when packets untag in.
 *                          CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP means the default mapping of 
 * egress phb to dscp when packets untag in.
 *                          CLX_QOS_MAPPING_DFLT_PHB_TO_EXP means the default mapping of 
 * egress phb to exp  when packets untag in.
 *      profileId     --  An assigned number that represents the software profile ID and the index
 *                        of hardware table on this QoS mapping type.
 * For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and 
 * CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profileId should set to 0.
 *      ptr_entry     --  The entry which to be obtained by user. <CL>
 *                      If "mapping_type" is CLX_QOS_MAPPING_PCP_DEI_TO_PHB, fields "pcp" and "dei" are the input. <CL>
 *                      If "mapping_type" is CLX_QOS_MAPPING_DSCP_TO_PHB, fields "dscp" is the input. <CL>
 *                      If "mapping_type" is CLX_QOS_MAPPING_EXP_TO_PHB, fields "exp" is the input. <CL>
 *                      If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI, CLX_QOS_MAPPING_PHB_TO_DSCP,
 *                      CLX_QOS_MAPPING_PHB_TO_EXP, CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 *                      CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP or CLX_QOS_MAPPING_DFLT_PHB_TO_EXP,
 *                      fields "tc", "color" are the input.
 * OUTPUT:
 *      ptr_entry     --  The entry which to be obtained by user.
 *                          If "mapping_type" is
 *                          CLX_QOS_MAPPING_PCP_DEI_TO_PHB, CLX_QOS_MAPPING_DSCP_TO_PHB
 *                          or CLX_QOS_MAPPING_EXP_TO_PHB,  fields "tc" and "color" and "sticky" are output. <CL>
 *                          If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_PCP_DEI or CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, fields "pcp" and "dei" are output. <CL>
 *                          If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_DSCP or CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP, fields "dscp" is output. <CL>
 *                          If "mapping_type" is CLX_QOS_MAPPING_PHB_TO_EXP or or CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, fields "exp" is output.
 * RETURN:
 *      CLX_E_OK                --  Operation is successful.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   --  The mapping profileId is not exists.
 *      CLX_E_NOT_INITED        --  SDK module has not been initialized.
 * NOTES:
 *      Use this API to get a mapping entry. <CL>
 */
CLX_ERROR_NO_T
clx_qos_getProfileEntry (
    const UI32_T                    unit,
    const CLX_QOS_MAPPING_TYPE_T    mapping_type,
    const UI32_T                    profileId,
    CLX_QOS_MAPPING_ENTRY_T        *ptr_entry);

#endif  /* End of CLX_QOS_H */

