/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_telm.h
 * PURPOSE:
 *      It provides TELM module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_TELM_H
#define CLX_TELM_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>
#include <clx_swc.h>
#include <clx_pkt.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* ifa struct */
typedef struct CLX_TELM_IFA_CFG_S {
    UI32_T ip_prot;       /* IFA protocol type in IPv4/v6 header */
    UI32_T node_id;       /* node_id in metadata, set rwi_slv */
    UI32_T lcl_namespace; /* local namespace in metadata */

} CLX_TELM_IFA_CFG_T;



/* ifa api */

/**
 * @brief Set telemetry IFA config information.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_ifa_cfg    - ifa config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_setIfaCfg(const UI32_T unit, const CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);

/**
 * @brief Get telemetry configuration information for IFA usage.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_ifa_cfg    - TELM IFA config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_getIfaCfg(const UI32_T unit, CLX_TELM_IFA_CFG_T *ptr_ifa_cfg);


/**
 * @brief prepare ifa tx pkt.
 *
 * @param [in]     unit                     - Device unit number.
 * @param [in]     ptr_rx_pkt               - rx pkt from cpu.
 * @param [in]     ptr_cookie               - cookie.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_prepareIfaTxPkt(const UI32_T unit,
                const CLX_PKT_RX_PKT_T *ptr_rx_pkt,
                void *ptr_cookie);

/**
 * @brief alloc rx pkt memory.
 *
 * @return         void *               - address of alloced.
 */
void *clx_telm_dmaAllocRxPkt(void);

/**
 * @brief free rx pkt memory.
 *
 * @param [in]     ptr_dma_mem              - memofy address will be freed.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_dmaFreePkt(const void *ptr_dma_mem);

/**
 * @brief set rx pkt cfg.
 *
 * @param [in]     unit                     - Device unit number.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_cfgPkt(UI32_T unit);

/**
 * @brief destroy rx pkt cfg.
 *
 * @param [in]     unit                     - Device unit number.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
CLX_ERROR_NO_T
clx_telm_deCfgPkt(UI32_T unit);

/**
 * @brief init send tx thread.
 *
 * @param [in]     unit                     - Device unit number.
 * @param [in]     port                     - Tx port.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
CLX_ERROR_NO_T clx_telm_ifaSendTaskInit(UI32_T unit, UI32_T port);

/**
 * @brief Deinit send tx thread.
 *
 * @param [in]     unit                     - Device unit number.
 * @param [in]     port                     - Tx port.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
CLX_ERROR_NO_T clx_telm_ifaSendTaskDeinit(UI32_T unit, UI32_T port);

#endif /* End of CLX_TELM_H */
