/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_SAMPLEPACKET_H__)
#define __CLXS_SAMPLEPACKET_H__

typedef struct clxs_samplepacket_bind_data_s
{
    sai_object_id_t obj;
} clxs_samplepacket_bind_data_t;

typedef struct clxs_samplepacket_entry_s {
    bool valid;
    uint32_t sai_sample_rate;
    sai_samplepacket_type_t sai_type;
    sai_samplepacket_mode_t sai_mode;
    sai_object_id_t sai_curr_mirrorsession_oid;
    uint32_t mirrorsession_count;
    CMLIB_LIST_T *ptr_igr_obj_list;
    CMLIB_LIST_T *ptr_egr_obj_list;
} clxs_samplepacket_entry_t;

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_samplepacket_api_t     samplepacket_api;

/* API DECLARATIONS
 */
sai_status_t clxs_samplepacket_init(
    _In_ uint32_t unit);

sai_status_t clxs_samplepacket_deinit(
    _In_ uint32_t unit);

sai_status_t clxs_samplepacket_getRate(
    _In_ sai_object_id_t samplepacket_id,
    _Out_ uint32_t *ptr_samplepacket_rate);

sai_status_t clxs_samplepacket_getType(
    _In_ sai_object_id_t samplepacket_id,
    _Out_ sai_samplepacket_type_t *ptr_samplepacket_type);

sai_status_t clxs_samplepacket_applySetting(
    _In_ sai_object_id_t obj_id,
    _In_ bool igr,
    _In_ sai_object_id_t cur_samplepacket_id,
    _In_ sai_object_id_t new_samplepacket_id);

sai_status_t clxs_get_samplepacket_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

clxs_samplepacket_entry_t *clxs_samplepacket_getEntry(uint32_t unit, uint32_t samplepkt_entry_idx);

#endif /* __CLXS_SAMPLEPACKET_H__ */
