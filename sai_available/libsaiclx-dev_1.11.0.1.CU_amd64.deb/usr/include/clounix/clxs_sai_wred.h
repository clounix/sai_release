/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_WRED_H__)
#define __CLXS_WRED_H__

#define CLXS_WRED_DEFAULT_PROBABILITY    (100)
#define CLXS_WRED_MAX_WEIGHT             (15)
#define CLXS_WRED_DEFAULT_WEIGHT         (0)
#define CLXS_WRED_MAX_QUEUE_NUM          (8)
#define CLXS_WRED_DEFAULT_ECN_MARK       (false)
#define CLXS_WRED_FLAGS_MAX_THRESHOLD    (1 << 0)
#define CLXS_WRED_FLAGS_MIN_THRESHOLD    (1 << 1)
#define CLXS_WRED_FLAGS_DROP_PROBABILITY (1 << 2)
#define CLXS_WRED_FLAGS_ALL (CLXS_WRED_FLAGS_MAX_THRESHOLD|CLXS_WRED_FLAGS_MIN_THRESHOLD|CLXS_WRED_FLAGS_DROP_PROBABILITY)

typedef struct clxs_wred_entry {
    bool     enabled;
    uint32_t flags;
    uint32_t min_threshold;
    uint32_t max_threshold;
    uint32_t max_drop_rate;
} clxs_wred_entry_t;

typedef struct clxs_wred_profile_entry_s {
    bool     valid;
    bool     ecn_enabled;
    uint32_t weight;
    clxs_wred_entry_t green;
    clxs_wred_entry_t yellow;
    clxs_wred_entry_t red;
    uint32_t queue_bmap[CLXS_MAX_PORT_NUM];
} clxs_wred_profile_entry_t;

extern const sai_wred_api_t             wred_api;

#ifdef CLX_WRED_ECN_MARKED_COUNT_USING_ACL
#define CLXS_WRED_ECN_VALUE_3   (0x3)
#define CLXS_WRED_ECN_MASK      (0x3)

typedef enum
{
    CLXS_WRED_IPTYPE_IPV4,
    CLXS_WRED_IPTYPE_IPV6,
    CLXS_WRED_IPTYPE_MAX
} CLXS_WRED_IPTYPE_T;

typedef struct CLXS_WRED_ECN_MARKED_COUNTER_DB_S
{
    bool        enabled;
    uint32_t    unit;
    UI32_T      port;
    CLX_PORT_T  clx_port;
    UI32_T      ecn_marked_entry_id[CLXS_WRED_IPTYPE_MAX];   /*egress 2 acl(0-ipv4, 1-ipv6) mactch ecn = 0x3 and group-lable = 0 */
    UI32_T      ecn_marked_counter_id[CLXS_WRED_IPTYPE_MAX];	 /*egress 2 2xcounters, 0-ipv4,1-ipv6*/
}CLXS_WRED_ECN_MARKED_COUNTER_DB_T;

typedef struct CLXS_WRED_ECN_MARKED_CB_S
{
    uint32_t        enable_count_num;
    uint32_t        egr_group_id;
    uint32_t        igr_group_id;
    uint32_t        ingress_ecn_entry_id[CLXS_WRED_IPTYPE_MAX];   /*ingress 2 acl(0-ipv4, 1-ipv6) mactch ecn = 0x3, set group-label 0x6e*/
    CLXS_WRED_ECN_MARKED_COUNTER_DB_T   *port_ecn_marked_count_info;
}CLXS_WRED_ECN_MARKED_CB_T;

extern CLXS_WRED_ECN_MARKED_CB_T _clxs_wred_ecn_marked_cb[CLXS_MAX_CHIP_NUM];

#define CLXS_WRED_ECN_MARKED_COUNT_PTR(__unit__, __port__)  ((CLXS_WRED_ECN_MARKED_COUNTER_DB_T *)(_clxs_wred_ecn_marked_cb[unit].port_ecn_marked_count_info + __port__))

sai_status_t clxs_wred_getEcnMarkedCounters(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ bool     is_byte, 
    _Out_ uint64_t *counters);

sai_status_t clxs_wred_clearEcnMarkedCounters(
    _In_ uint32_t unit,
    _In_ uint32_t port);
#endif

/* API DECLARATIONS
 */
sai_status_t clxs_wred_applySetting(
    _In_ sai_object_id_t obj_id,
    _In_ sai_object_id_t wred_id);

sai_status_t clxs_wred_init(
    _In_ uint32_t unit);

sai_status_t clxs_wred_deinit(
    _In_ uint32_t unit);

sai_status_t clxs_get_wred_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

clxs_wred_profile_entry_t *clxs_wred_getProfile(
    uint32_t unit,
	uint32_t wred_profile_id);

/* get ECN enable of wred profile */
bool clxs_wred_getEcnEnable(
    _In_ sai_object_id_t  wred_id);

#endif /* __CLXS_WRED_H__ */
