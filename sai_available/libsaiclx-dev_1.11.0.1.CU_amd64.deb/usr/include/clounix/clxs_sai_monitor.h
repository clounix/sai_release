/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#ifndef CLX_MONITOR_H
#define CLX_MONITOR_H

#define SAI_RX_ERR_CNT_THRESHOLD            1000000
#define SAI_RX_ERR_CNT_ACCUMULATED_CYCLE    5
#define SAI_RX_DMA_BUF_LOW_THRESHOLD_PERCENT    0.02

#ifdef CLX_SWITCH_MONITOR
#define CLXS_SWITCH_MONITOR_STAT_CNT(__unit__)      clxs_switch_monitor[__unit__].dma_info_num
#define CLXS_SWITCH_MONITOR_DMA_INFO_PTR(__unit__, __chn__, __idx__)    \
                                ((CLXS_MONITOR_DMA_INFO_T *)(clxs_switch_monitor[__unit__].ptr_monitor_dma_info + \
                                    (__chn__*CLXS_SWITCH_MONITOR_STAT_CNT(__unit__) +__idx__ )))

typedef struct  CLXS_MONITOR_DMA_INFO_S
{
    UI32_T  rch_avbl_gpd_no;
    UI32_T  rx_done;
} CLXS_MONITOR_DMA_INFO_T;

typedef struct  CLXS_SWITCH_MONITOR_S
{
    uint32_t                interval_us;
    CLX_THREAD_ID_T         thread_id;
    CLX_SEMAPHORE_ID_T      sema;
    CLXS_MONITOR_DMA_INFO_T *ptr_monitor_dma_info;
    uint32_t                dma_info_num;
} CLXS_SWITCH_MONITOR_T;

#endif

typedef struct {
    UI32_T cnt_single;
    UI32_T cnt_double;
} DEMO_SWC_CMD_TRAV_COOKIE_T;

#ifdef CLX_ECC_ERR_LOG
typedef struct SAI_ECC_ERR_CNT_S
{
    uint32_t*    history_single_table_err_cnt;
    uint32_t*    history_double_table_err_cnt;
    uint32_t*    history_single_hub_mem_err_cnt;
    uint32_t*    history_double_hub_mem_err_cnt;
    uint32_t     single_err_total_cnt;
    uint32_t     double_err_total_cnt;
    uint32_t     correct_total_cnt;
} SAI_ECC_ERR_CNT_T;
#endif

#ifdef CLX_SWITCH_MONITOR
extern uint32_t monitor_dma_index;
extern CLXS_SWITCH_MONITOR_T clxs_switch_monitor[CLXS_MAX_CHIP_NUM];
sai_status_t clxs_port_fault_log(
	    _In_ const uint32_t     unit,
	    _In_ const uint32_t     port,
        _In_ const uint32_t     fault);

sai_status_t clxs_switch_monitor_init(
    _In_ const uint32_t unit);

sai_status_t clxs_switch_monitor_deinit(
    _In_ const uint32_t unit);
#endif

#ifdef CLX_ECC_ERR_LOG
sai_status_t clxs_monitor_initEccLog(
    uint32_t unit);

sai_status_t clxs_monitor_deinitEccLog(
    uint32_t unit);
#endif

#endif  /* End of CLX_MONITOR_H */