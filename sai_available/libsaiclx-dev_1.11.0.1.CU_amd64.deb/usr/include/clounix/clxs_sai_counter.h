/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_COUNTER_H__)
#define __CLXS_COUNTER_H__

#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
#define CLXS_COUNTER_GRPLABEL_DST_MIN             (0)
#define CLXS_COUNTER_GRPLABEL_DST_MAX             (0x7ff)

#define CLXS_COUNTER_MAPPED_DST_MASK             (0x7ff)
#define CLXS_COUNTER_MAPPED_NUM           (2047)
#define CLXS_COUNTER_MAPPED_SIZE           (CLX_BITMAP_SIZE(CLXS_COUNTER_MAPPED_NUM))
#define CLXS_META_MAPPED_SIZE               (10)

#define CLXS_COUNTER_TYPE_DIST       1
#define CLXS_COUNTER_TYPE_SRV        2

typedef struct
{
    sai_object_id_t counter_id;
    uint32_t counterid_refcnt;
    uint32_t cnt_group_label;
    uint32_t cnt_acl_entry_id;
} CLXS_COUNTER_INFO_T;

typedef struct
{
    CMLIB_AVL_HEAD_T        *ptr_counter_avl;
    CLX_SEMAPHORE_ID_T      sema;
} CLXS_COUNTER_CB_T;

#define CLXS_COUNTER_CB(unit) (ptr_clxs_counter_cb[unit])

#define CLXS_COUNTER_LOCK(unit) \
    osal_takeSemaphore(&ptr_clxs_counter_cb[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER)

#define CLXS_COUNTER_UNLOCK(unit) \
    osal_giveSemaphore(&ptr_clxs_counter_cb[unit]->sema)


extern const sai_counter_api_t counter_api;
extern CLXS_COUNTER_CB_T    *ptr_clxs_counter_cb[CLXS_MAX_CHIP_NUM];

extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T counter_stats_capability_info;

sai_status_t
clxs_get_CounterInfo(
    _In_ sai_object_id_t counter_id,
    _Out_ uint32_t *cnt_id,
    _Out_ uint32_t *cnt_type);

#define CLXS_COUNTER_L3_OPTFLAGS_REMOVE       (0)
#define CLXS_COUNTER_L3_OPTFLAGS_CREATE        (1)
#define CLXS_COUNTER_GRPLABEL_CREATE        (1)
#define CLXS_COUNTER_GRPLABEL_REMOVE        (0)

#define CLXS_L3_GRPLABEL_FLAGS_META             (1 << 0)
#define CLXS_L3_GRPLABEL_FLAGS_COUNTER         (1 << 1)

#define CLXS_COUNTER_INVALID_ID             (0xffffffff)
sai_status_t
clxs_counter_init(
    _In_ const uint32_t      unit);

sai_status_t
clxs_counter_deinit(
    _In_ const uint32_t      unit);
#ifdef CLX_ROUTE_NEIGHBOR_COUNT
sai_status_t
clxs_counter_operate(
    _In_ uint32_t unit,
    _In_ uint32_t optflags,
    _In_ sai_object_id_t counter_id,
    _In_ sai_ip_addr_family_t addr_family,
    _Out_ uint32_t *ptr_group_label);
#endif
#endif
#endif
