/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_ACL_H__)
#define __CLXS_ACL_H__

extern const sai_acl_api_t              acl_api;

#define CLXS_ACL_USER_META_FDB_DST_MIN                  (0)
#define CLXS_ACL_USER_META_FDB_DST_MAX                  (0xfff)
#define CLXS_ACL_USER_META_ROUTE_DST_MIN                (0)
#define CLXS_ACL_USER_META_ROUTE_DST_MAX                (0x7ff)
#define CLXS_ACL_USER_META_NEIGHBOR_DST_MIN             (0)
#define CLXS_ACL_USER_META_NEIGHBOR_DST_MAX             (0x7ff)
#define CLXS_ACL_USER_META_ROUTE_NEIGHBOR_DST_OFFSET    (1)
#define CLXS_ACL_USER_META_PORT_MIN                     (0)
#define CLXS_ACL_USER_META_PORT_MAX                     (3)
#define CLXS_ACL_USER_META_PORT_OFFSET                  (8)
#define CLXS_ACL_USER_META_ACL_MIN                      (0)
#define CLXS_ACL_USER_META_ACL_MAX                      (0x3f)
#define CLXS_ACL_INTERNAL_META_ACL_MIN               (0x40)
#define CLXS_ACL_INTERNAL_META_ACL_MAX               (0x7f)
#define CLXS_ACL_META_MAX                    (0x7f)
#define CLXS_ACL_META_MASK                    (CLXS_ACL_META_MAX)
#define CLXS_INTERNAL_META_ACL_BITMAP_SIZE       \
            (CLX_BITMAP_SIZE(CLXS_ACL_INTERNAL_META_ACL_MAX-CLXS_ACL_INTERNAL_META_ACL_MIN))

#define CLXS_ACL_GROUP_NUM_IGR                          (256)
#define CLXS_ACL_GROUP_NUM_EGR                          (256)
#define CLXS_ACL_RANGE_NUM                                  (CLX_ACL_LOU_NUM)
/*should be bigger than (CLXS_ACL_TABLE_NUM_IGR +  CLXS_ACL_TABLE_NUM_EGR)*/
#define CLXS_ACL_GROUP_MEMBER_NUM         (16)
#define CLXS_ECN_INGRESS_ACL_GROUP_LABEL      0x6e
#define CLXS_ECN_INGRESS_ACL_GROUP_LABEL_MASK 0xffffffff

#ifndef CLX_ACL_SONIC_BIND
#define CLXS_ACL_SRV_GRP_LBL_MAX		0x3FF
#define CLXS_ACL_SRV_GRP_LBL_INDEX_MIN               (0x1)
#define CLXS_ACL_SRV_GRP_LBL_INDEX_MAX               (0x3FF)
#endif

#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MIN             (200)
#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX             (600)
#else
#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX             (700)
#endif

#define CLXS_ACL_GROUP_MEMBER_PRIO_MIN                  (CLXS_ACL_ACTION_PRIO_USR_DEFINE_MIN)
#define CLXS_ACL_GROUP_MEMBER_PRIO_MAX                  (CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX)
#define CLXS_ACL_ENTRY_PRIO_MIN                         (0)
#define CLXS_ACL_ENTRY_PRIO_MAX                         (0xffffff)

/*the smaller prio value means higher priority */
/*other priority reserved to acl application */
#define CLXS_ACL_GROUP_PRIO_POLICER     (7)
#if defined(CLX_PORT_IP_COUNT_USING_ACL) || defined(CLX_SHOW_ECMP_PATH_EN)
#define CLXS_ACL_GROUP_PRIO_USER_ALLOC_MIN               (2)
#else
#define CLXS_ACL_GROUP_PRIO_USER_ALLOC_MIN               (1)
#endif
#define CLXS_ACL_GROUP_PRIO_USER_ALLOC_MAX               (7)
#define CLXS_ACL_GROUP_PRIO_ICC         (0)
#define CLXS_ACL_GROUP_PRIO_COUNTER     (6)
#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_ACL_GROUP_PRIO_PORT_IP_COUNT     (1)
#endif

#define CLXS_ACL_ACTION_PRIO_POLICER    (15)
#define CLXS_ACL_ACTION_PRIO_USER_ALLOC_MIN              (2)
#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_EGR_ACL_ACTION_PRIO_USER_ALLOC_MAX              (6)
#else
#define CLXS_EGR_ACL_ACTION_PRIO_USER_ALLOC_MAX              (7)
#endif
#define CLXS_IGR_ACL_ACTION_PRIO_USER_ALLOC_MAX              (14)
#define CLXS_ACL_ACTION_PRIO_ICC        (1)

#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_EGR_ACL_ACTION_PRIO_COUNTER	(7)
#define CLXS_ING_ACL_ACTION_PRIO_COUNTER	(15)
#endif

#define CLXS_ACL_GROUP_PRIO_ECN_MARKED_COUNT     (1)

#ifdef CLX_TAM_MOD_ENABLE
#define CLXS_ACL_GROUP_PRIO_TAM_MOD_EGRESS      (1)
#endif

#if SAI_API_VERSION >= SAI_VERSION(1, 4, 0)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_IPV6_AETH_DEFAULT	    (59)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_AETH_DEFAULT            (60)
#endif

#define CLXS_ACL_UDF_PROFILE_ID_FOR_TCP_FLAG_DEFAULT        (61)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_INT_DEFAULT         (62)
#define CLXS_ACL_UDF_PROFILE_ID_DEFAULT                     (63)
#define CLXS_ACL_UDF_PROFILE_NUM                            (64)

#if SAI_API_VERSION >= SAI_VERSION(1, 4, 0)
#define CLXS_ACL_UDF_AETH_OFFSET                        (20)
#define CLXS_ACL_UDF_BTH_OFFSET                         (8)
#define CLXS_ACL_IP_PROTO_UDP                           (0x11)
#endif
#define CLXS_ACL_UDF_TCP_FLAG_OFFSET                    (13)
#define CLXS_ACL_IP_PROTO_TCP                           (0x6)
#define CLXS_ACL_UDF_TCP_PROFILE_PKT_CNT                (14)
#define CLXS_ACL_UDF_PROFILE_PKT_CNT_FOR_INT            (16)
#define CLXS_ACL_IP_PROTO_GRE                           (47)

#define CLXS_ACL_INVALID_GROUP_ID                       (0xffffffff)
#define CLXS_ACL_INVALID_ENTRY_ID                       (0xffffffff)

#define CLXS_ACL_UDF_DEFAULT_ID_OFFSET                  (CLXS_ACL_UDF_TCP_FLAG_OFFSET)
#define CLXS_ROUTE_IP2ME_GROUP_LABEL (1 << 11)
#define CLXS_ACL_INVALID_VALUE                          (0xFFFFFFFF)

#define CLXS_ACL_UDF_PROF_BMP_FOREACH(__udf_prof_bmp__, __prof_idx__)                                              \
    for ((__prof_idx__) = 0; (__prof_idx__) < CLXS_ACL_UDF_PROFILE_NUM; (__prof_idx__)++)                           \
    if (CMLIB_BITMAP_BIT_CHK((__udf_prof_bmp__), (__prof_idx__)))

#define CLXS_ACL_GET_GROUP_BIND_INFO_PTR(__ptr_bind_info__, __unit__, __stage__) \
            do                      \
            {                                                                                                           \
                if (SAI_ACL_STAGE_INGRESS == (__stage__))                                                               \
                {                                                                                                       \
                    (__ptr_bind_info__) = _clxs_acl_cb[(__unit__)]->group_cb.ptr_igr_bind_point_avl;                    \
                }                                                                                                       \
                else                                                                                                    \
                {                                                                                                       \
                    (__ptr_bind_info__) = _clxs_acl_cb[(__unit__)]->group_cb.ptr_egr_bind_point_avl;                    \
                }                                                                                                       \
            } while (0)
        
#define CLXS_ACL_GET_TABLE_INFO_PTR(__ptr_table_info__, __unit__, __stage__, __table_id__) \
            do                      \
            {                                                                                                             \
                if (SAI_ACL_STAGE_INGRESS == (__stage__))                                                                 \
                {                                                                                                         \
                    (__ptr_table_info__) = _clxs_acl_cb[(__unit__)]->table_cb.igr_table_info_arr + (__table_id__);         \
                }                                                                                                         \
                else                                                                                                      \
                {                                                                                                         \
                    (__ptr_table_info__) = _clxs_acl_cb[(__unit__)]->table_cb.egr_table_info_arr + (__table_id__);         \
                }                                                                                                         \
            } while (0)

#define CLXS_ACL_TABLE_ATTR_FIELD_BMP_ADD(__table_attr_field_bmp__, __attr_type__)                                 \
                    (CMLIB_BITMAP_BIT_ADD((__table_attr_field_bmp__), ((__attr_type__) - SAI_ACL_TABLE_ATTR_FIELD_START)))
                
#define CLXS_ACL_TABLE_ATTR_FIELD_BMP_CHK(__table_attr_field_bmp__, __attr_type__)                                 \
                    (CMLIB_BITMAP_BIT_CHK((__table_attr_field_bmp__), ((__attr_type__) - SAI_ACL_TABLE_ATTR_FIELD_START)))

#define CLXS_ACL_ENTRY_ATTR_FIELD_BMP_ADD(__entry_attr_field_bmp__, __attr_type__)                                 \
                    (CMLIB_BITMAP_BIT_ADD((__entry_attr_field_bmp__), ((__attr_type__) - SAI_ACL_ENTRY_ATTR_FIELD_START)))

#define CLXS_ACL_ENTRY_ATTR_FIELD_BMP_CHK(__entry_attr_field_bmp__, __attr_type__)                                 \
                    (CMLIB_BITMAP_BIT_CHK((__entry_attr_field_bmp__), ((__attr_type__) - SAI_ACL_ENTRY_ATTR_FIELD_START)))

/* since bit 0 of table bmp must be zero (table 0 is used for policer, which will not set bind point info),
   we can store is_group info at bit 0 of group_label */
#define CLXS_ACL_SET_GROUP_LABEL_BIND_POINT(__group_label__, __table_bmp__, __is_group__) \
    do                       \
    {                                                                                                             \
        (__group_label__) &= ~(0xff);                                                                             \
        (__group_label__) |= (((__table_bmp__)) | (__is_group__));                                                \
    } while (0)

#define CLXS_ACL_GET_BIND_POINT_INFO(__table_bmp__, __is_group__, __group_label__) \
    do                              \
    {                                                                                                             \
        (__table_bmp__) = (__group_label__) & 0xfe;                                                               \
        (__is_group__) = (__group_label__) & 0x1;                                                                 \
    } while (0)

#define CLXS_ACL_GET_GROUP_INFO_PTR(__ptr_group_info__, __unit__, __stage__, __group_id__) \
            do                      \
            {                                                                                                             \
                if (SAI_ACL_STAGE_INGRESS == (__stage__))                                                                 \
                {                                                                                                         \
                    (__ptr_group_info__) = _clxs_acl_cb[(__unit__)]->group_cb.igr_group_info_arr + (__group_id__);         \
                }                                                                                                         \
                else                                                                                                      \
                {                                                                                                         \
                    (__ptr_group_info__) = _clxs_acl_cb[(__unit__)]->group_cb.egr_group_info_arr + (__group_id__);         \
                }                                                                                                         \
            } while (0)

#define CLXS_ACL_TABLE_ATTR_FIELD_BMP_WORDS                                                                        \
            (((SAI_ACL_TABLE_ATTR_FIELD_END - SAI_ACL_TABLE_ATTR_FIELD_START) >> 5) + 1)

#define CLXS_ACL_TABLE_ATTR_ACTION_TYPE_LIST_NUM  64

#define CLXS_ACL_TABLE_ATTR_ACTION_TYPE_BMP_WORDS                                                               \
            ((CLXS_ACL_TABLE_ATTR_ACTION_TYPE_LIST_NUM >> 5) +1)

#define CLXS_ACL_ENTRY_ATTR_FIELD_BMP_WORDS                                                                        \
            (((SAI_ACL_ENTRY_ATTR_FIELD_END - SAI_ACL_ENTRY_ATTR_FIELD_START) >> 5) + 1)

typedef struct CLXS_ACL_UDF_CB_S
{
    uint32_t    udf_prof_bmp[2];    /* total 64 udf_profile */
} CLXS_ACL_UDF_CB_T;

typedef enum
{
    CLXS_ACL_USER_META_PORT,
    CLXS_ACL_USER_META_FDB_DST,
    CLXS_ACL_USER_META_ROUTE_DST,
    CLXS_ACL_USER_META_NEIGHBOR_DST,
    CLXS_ACL_USER_META_ACL,
    CLXS_ACL_USER_META_ACL_LAST
} CLXS_ACL_USER_META_T;

typedef enum _sai_acl_int_type_t
{
    /** IFA1 UDP */
    SAI_ACL_INT_TYPE_IFA1_UDP,

    /** IFA1 TCP */
    SAI_ACL_INT_TYPE_IFA1_TCP,

    /** IFA1 GRE */
    SAI_ACL_INT_TYPE_IFA1_GRE,

    /** IOAM IPv6 Hop-by-Hop */
    SAI_ACL_INT_TYPE_IOAM_IPV6_HOP_BY_HOP,

    /** IOAM VXLAN Generic Protocol Extension */
    SAI_ACL_INT_TYPE_IOAM_VXLAN_GPE,

    /** IOAM Generic Network Virtualization Encapsulation */
    SAI_ACL_INT_TYPE_IOAM_GENEVE,

    /** IOAM GRE */
    SAI_ACL_INT_TYPE_IOAM_GRE

} sai_acl_int_type_t;

typedef struct CLXS_ACL_TABLE_ATTR_FIELD_INFO_S
{
    sai_acl_table_attr_t    type;

#define CLXS_ACL_TABLE_ATTR_FIELD_FLAGS_IGR    (1 << 0)
#define CLXS_ACL_TABLE_ATTR_FIELD_FLAGS_EGR    (1 << 1)
    uint32_t                 flags;
} CLXS_ACL_TABLE_ATTR_FIELD_INFO_T;

typedef struct CLXS_ACL_BIND_TAM_INT_S
{
    sai_object_id_t acl_table_oid;
    bool            bind;
    bool            enable;
    uint32_t        dtel_profile_id;
    bool            need_internal_entry;
    uint32_t        presence_pb1;
    uint32_t        presence_pb2;
}CLXS_ACL_BIND_TAM_INT_T;

typedef struct CLXS_ACL_RANGE_CB_S
{
    uint32_t    range_bmp;
    uint32_t    rsvd_range_id;    /* all 1: invalid */
} CLXS_ACL_RANGE_CB_T;

typedef struct CLXS_ACL_BIND_POINT_INFO_S
{
    sai_object_id_t    bind_point_obj;
    sai_object_id_t    acl_obj; /*acl table group or acl table*/
} CLXS_ACL_BIND_POINT_INFO_T;

typedef uint32_t CLXS_ACL_TABLE_ATTR_FIELD_BMP_T[CLXS_ACL_TABLE_ATTR_FIELD_BMP_WORDS];

typedef uint32_t CLXS_ACL_TABLE_ATTR_ACTION_TYPE_BMP_T[CLXS_ACL_TABLE_ATTR_ACTION_TYPE_BMP_WORDS];

typedef struct CLXS_ACL_TABLE_INFO_S
{
    uint32_t                          valid;
    uint32_t                          bind_point_type_bmp;
    uint32_t                          attached_bind_type_bmp;      /*record actual bind object type in this table, used when create acl entry*/
    CLXS_ACL_TABLE_ATTR_FIELD_BMP_T    attr_field_bmp;
    CLXS_ACL_TABLE_ATTR_ACTION_TYPE_BMP_T action_type_bmp;
    uint32_t                          clx_group_prio;   /* value of clx_group_prio is allocated by sdk (range: 0-7).*/

    uint32_t                          clx_action_prio;  /* if flags_group_valid is set,
                                                           clx action prioity is group member priority (range: 100/100-700/100).
                                                           if flags_group_valid is not set,
                                                           value of clx action prioity is allocated by sdk (range: 8-15). */
    uint32_t                          entry_width;
    uint32_t                          egr_group_used;
    sai_object_id_t                   egr_group_obj_id;
    uint32_t                          group_profile_flags;
    CLX_ACL_GROUP_PROFILE_T           group_profile;
} CLXS_ACL_TABLE_INFO_T;

typedef uint32_t CLXS_ACL_ENTRY_ATTR_FIELD_BMP_T[CLXS_ACL_ENTRY_ATTR_FIELD_BMP_WORDS];
typedef struct CLXS_ACL_ENTRY_INFO_S CLXS_ACL_ENTRY_INFO_T;

struct CLXS_ACL_ENTRY_INFO_S
{
    uint32_t                table_id;   /* avl key */
    uint32_t                entry_id;   /* avl key */
    uint32_t                prio;
    uint32_t                group_label;
    sai_object_id_t         egr_entry_obj_id;
    sai_object_list_t       egr_port_list;
    sai_object_id_t         samplepacket_obj_id;
    uint32_t                next_entry_id;
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
    sai_acl_int_type_t int_type;
    uint32_t ifa1_probe_marker1;
    uint32_t ifa1_probe_marker2;
#endif
    CLXS_ACL_ENTRY_INFO_T    *ptr_next_entry_info;
    uint32_t    flags;
    BOOL_T      admin_state;
#ifndef CLX_ACL_SONIC_BIND
    uint32_t srv_group_label;
#endif
    CLXS_ACL_ENTRY_ATTR_FIELD_BMP_T field_bmp;
};

typedef struct CLXS_ACL_GROUP_INFO_S
{
    uint32_t                      valid;
    uint32_t                      bind_point_type_bmp;
    sai_acl_table_group_type_t    group_type;
    uint32_t                      member_cnt;
    uint32_t                      member[CLXS_ACL_GROUP_MEMBER_NUM];
    bool                          member_is_bind[CLXS_ACL_GROUP_MEMBER_NUM];
} CLXS_ACL_GROUP_INFO_T;

typedef struct CLXS_ACL_GROUP_CB_S
{
    CLXS_ACL_GROUP_INFO_T    igr_group_info_arr[CLXS_ACL_GROUP_NUM_IGR];
    CLXS_ACL_GROUP_INFO_T    egr_group_info_arr[CLXS_ACL_GROUP_NUM_EGR];
    CMLIB_AVL_HEAD_T        *ptr_igr_bind_point_avl;    /* CLXS_ACL_BIND_POINT_INFO_T */
    CMLIB_AVL_HEAD_T        *ptr_egr_bind_point_avl;    /* CLXS_ACL_BIND_POINT_INFO_T */
} CLXS_ACL_GROUP_CB_T;

typedef struct CLXS_ACL_TABLE_CB_S
{
    CLXS_ACL_TABLE_INFO_T *   igr_table_info_arr;
    CLXS_ACL_TABLE_INFO_T *   egr_table_info_arr;
    uint32_t                igr_clx_group_prio_bmp;
    uint32_t                egr_clx_group_prio_bmp;
    uint32_t                igr_clx_action_prio_bmp;
    uint32_t                egr_clx_action_prio_bmp;
} CLXS_ACL_TABLE_CB_T;

typedef struct CLXS_ACL_ENTRY_CB_S
{
    CLXS_ACL_ENTRY_INFO_T *  acl_entry_info_arr;
//    CLXS_ACL_ENTRY_INFO_T    igr_entry_info_arr[CLXS_ACL_ENTRY_NUM_IGR];
//    CLXS_ACL_ENTRY_INFO_T    egr_entry_info_arr[CLXS_ACL_ENTRY_NUM_EGR];
    CMLIB_AVL_HEAD_T        *ptr_igr_entry_avl;
    CMLIB_AVL_HEAD_T        *ptr_egr_entry_avl;
} CLXS_ACL_ENTRY_CB_T;

#ifndef CLX_ACL_SONIC_BIND
#define CLXS_ACL_VLAN_SRV_GRP_LBL_BMP_SIZE		((CLXS_ACL_SRV_GRP_LBL_MAX >> 5) + 1)
typedef struct CLXS_ACL_VLAN_SRV_GRP_LBL_S
{
    uint32_t service_group_label;
    uint32_t num;
}CLXS_ACL_VLAN_SRV_GRP_LBL_T;
#endif

typedef struct CLXS_ACL_CB_S
{
    CLXS_ACL_RANGE_CB_T    range_cb;
    CLXS_ACL_UDF_CB_T      udf_cb;
    CLXS_ACL_GROUP_CB_T    group_cb;
    CLXS_ACL_TABLE_CB_T    table_cb;
    CLXS_ACL_ENTRY_CB_T    entry_cb;
    uint32_t    igr_acl_group_lable[CLXS_INTERNAL_META_ACL_BITMAP_SIZE];
#ifndef CLX_ACL_SONIC_BIND
    uint32_t    service_group_lable[CLXS_ACL_VLAN_SRV_GRP_LBL_BMP_SIZE];
    CLXS_ACL_VLAN_SRV_GRP_LBL_T vlan_srv_grp_lbl_info[CLXS_MAX_VLAN_NUM];
#endif

} CLXS_ACL_CB_T;

extern CLXS_ACL_CB_T*                      _clxs_acl_cb[CLXS_MAX_CHIP_NUM];
extern const sai_attribute_entry_t         _clxs_acl_table_attr_arr[];
extern CLXS_ACL_TABLE_ATTR_FIELD_INFO_T    _clxs_acl_table_attr_field_list[];
extern uint32_t                            clxs_acl_table_attr_field_list_size;
extern uint32_t                            clxs_acl_table_attr_arr_size;

sai_status_t
clxs_acl_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_acl_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_acl_getSwitchAttr(
    _In_ const sai_object_key_t *ptr_key,
    _Inout_ sai_attribute_value_t *ptr_value,
    void *ptr_arg);

sai_status_t
clxs_get_acl_entry_enum_values_capability(
    _In_ uint32_t unit,
    _In_ sai_attr_id_t attr_id,
    _Inout_ sai_s32_list_t *enum_values_capability);

sai_status_t
clxs_acl_setGrpLblBindInfo(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const sai_object_id_t acl_object_id,
    _In_ const sai_object_id_t bind_point_onject_id,
    _Inout_ uint32_t *ptr_group_label);

sai_status_t
clxs_acl_setGrpLblUserMeta(
    _In_ const CLXS_ACL_USER_META_T user_meta_type,
    _In_ const uint32_t user_meta,
    _Inout_ uint32_t *ptr_group_label);

sai_status_t
clxs_acl_getUserMeta(
    _In_ const CLXS_ACL_USER_META_T user_meta_type,
    _In_ const uint32_t group_label,
    _Out_ uint32_t *ptr_user_meta);

sai_status_t
clxs_acl_addUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const uint32_t prof_id,
    _In_ const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format,
    _In_ const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

sai_status_t
clxs_acl_delUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const uint32_t prof_id);

sai_status_t
clxs_acl_updateUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

sai_status_t
clxs_acl_updateEntrySamplingRate(
    _In_ const sai_object_id_t entry_object_id,
    _In_ const uint32_t sampling_rate);

sai_status_t
clxs_acl_getBindPortList(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id,
    _Out_ sai_object_list_t *ptr_igr_portlist,
    _Out_ sai_object_list_t *ptr_egr_portlist);

sai_status_t clxs_acl_bindTableToTamInt(
    _In_ CLXS_ACL_BIND_TAM_INT_T    *ptr_bind_info);

sai_status_t clxs_get_acl_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_acl_range_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_acl_getBindPointAclbyBindPointobj(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const sai_object_id_t  bind_obj,
    _Out_ sai_object_id_t *ptr_aclobj);

sai_status_t clxs_acl_getUdfInfo(
    _In_ uint32_t unit,
    _Inout_ CLXS_ACL_UDF_CB_T* ptr_udfInfo
);

sai_status_t _clxs_acl_objectTypeToBindType(
    _In_ const sai_object_type_t obj_type,
    _Out_ sai_acl_bind_point_type_t *bind_point_type);

sai_status_t _clxs_acl_getGroupObjInfo(
    _In_ const sai_object_id_t acl_table_group_id,
    _Out_ uint32_t *ptr_unit,
    _Out_ sai_acl_stage_t *ptr_stage,
    _Out_ uint32_t *ptr_group_id);

sai_status_t _clxs_acl_getTableObjInfo(
    _In_ const sai_object_id_t acl_table_id,
    _Out_ uint32_t *ptr_unit,
    _Out_ sai_acl_stage_t *ptr_stage,
    _Out_ uint32_t *ptr_table_id);

sai_status_t _clxs_acl_getEntry(
    _In_ const uint32_t unit,
    _In_ const uint32_t entry_id,
    _Out_ BOOL_T *ptr_entry_valid,
    _Out_ CLX_ACL_CLASSIFY_T *ptr_classify,
    _Out_ CLX_ACL_ACTION_T *ptr_action);

sai_status_t _clxs_acl_allocAddEntry(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const uint32_t table_id,
    _In_ const uint32_t entry_prio,
    _In_ const bool admin_state,
    _In_ const CLX_ACL_CLASSIFY_T *ptr_classify,
    _In_ const CLX_ACL_ACTION_T *ptr_action,
    _In_ const uint32_t is_alloc,
    _Inout_ uint32_t *ptr_entry_id);


#endif
