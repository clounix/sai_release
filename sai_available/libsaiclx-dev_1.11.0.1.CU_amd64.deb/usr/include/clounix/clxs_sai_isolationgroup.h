/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_ISOLATIONGROUP_H__)
#define __CLXS_ISOLATIONGROUP_H__

#if SAI_API_VERSION >= SAI_VERSION(1, 4, 0)

#define MAX_ISOLATION_GROUP_OBJECT_COUNT    (64)
#define MAX_ISOLATION_GROUP_MEMBER_OBJECT_COUNT     (256)
#define CLXS_ISOLATION_GROUP_ID_RANGE_VALID(id)      \
        ((id) < MAX_ISOLATION_GROUP_OBJECT_COUNT)
#define CLXS_ISOLATION_GROUP_MEMBER_ID_RANGE_VALID(id)      \
        ((id) < MAX_ISOLATION_GROUP_MEMBER_OBJECT_COUNT)
typedef struct _CLXS_ISOLATION_GROUP_INFO_S{
    sai_isolation_group_type_t      type;
    sai_object_list_t       memeber_list;
    sai_object_list_t       bind_point_list;
}CLXS_ISOLATION_GROUP_INFO_T;

extern const sai_isolation_group_api_t   isolationgroup_api;
extern CLXS_ISOLATION_GROUP_INFO_T  **isolationgroup_info[CLXS_MAX_CHIP_NUM];

sai_status_t
clxs_isolationgroup_init(
    _In_ const uint32_t    unit);

sai_status_t
clxs_isolationgroup_deinit(
    _In_ const uint32_t    unit);

sai_status_t
clxs_isolation_group_setBindObj(
    _In_ sai_object_id_t    bind_port_oid,
    _In_ sai_object_id_t    isolation_grp_oid,
    _In_ bool   is_add);

sai_status_t
clxs_isolation_group_updateLagMbr(
    _In_ sai_object_id_t    lag_oid,
    _In_ sai_object_id_t    lag_member_oid,
    _In_ bool   is_add);
#endif
#endif