/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_NEXTHOPGROUP_H__)
#define __CLXS_NEXTHOPGROUP_H__
/* capacity */
#define CLXS_NEXTHOPGROUP_PATH_BITMAP_SIZE(unit) (CLX_BITMAP_SIZE(CLXS_MAX_ECMP_PATH_NUM(unit)))
#define CLXS_NEXTHOPGROUP_ECMP_MAX_PATHS         (CLXS_MAX_PORT_NUM)

#define CLXS_NEXTHOPGROUP_LOCK(unit) \
    sai_osal_mutex_lock(_ptr_clxs_nexthopgroup_cb[unit]->sema);

#define CLXS_NEXTHOPGROUP_UNLOCK(unit) \
    sai_osal_mutex_unlock(_ptr_clxs_nexthopgroup_cb[unit]->sema);

#define CLXS_NEXTHOPGROUP_CB(unit)  (_ptr_clxs_nexthopgroup_cb[unit])

/* ------------------------------------------------------------------------ data-type: nexthopgroup_member */
typedef struct
{
    sai_object_id_t             next_hop_grp_id; /* SAI_NEXT_HOP_GROUP_MEMBER_ATTR_NEXT_HOP_GROUP_ID */
    sai_object_id_t             next_hop_id;     /* SAI_NEXT_HOP_GROUP_MEMBER_ATTR_NEXT_HOP_ID       */
    sai_uint32_t                weight;          /* SAI_NEXT_HOP_GROUP_MEMBER_ATTR_WEIGHT            */
    sai_uint32_t                index;          /* SAI_NEXT_HOP_GROUP_MEMBER_ATTR_INDEX            */
    sai_uint32_t                sequence_id;          /* SAI_NEXT_HOP_GROUP_MEMBER_ATTR_SEQUENCE_ID            */
    sai_int32_t                 configured_role;   /*SAI_NEXT_HOP_GROUP_MEMBER_ATTR_CONFIGURED_ROLE*/
    sai_int32_t	                observed_role;      /*SAI_NEXT_HOP_GROUP_MEMBER_ATTR_OBSERVED_ROLE*/
    sai_object_id_t             monitored_object;   /*SAI_NEXT_HOP_GROUP_MEMBER_ATTR_MONITORED_OBJECT*/
    bool                        active;
    bool                        valid;

} CLXS_NEXTHOPGROUP_DB_T;

typedef struct
{
    sai_object_id_t             grp_oid;
    sai_int32_t                 ref_cnt;
    bool                        valid;
} CLXS_NEXTHOPGROUP_INFO_T;

typedef struct
{
    CLX_SEMAPHORE_ID_T          sema;
    sai_uint32_t                *nhp_validmap;
    CLXS_NEXTHOPGROUP_DB_T      *db;
    CLXS_NEXTHOPGROUP_INFO_T    *gp_info;
} CLXS_NEXTHOPGROUP_CB_T;

extern const sai_next_hop_group_api_t   nexthopgroup_api;
extern CLXS_NEXTHOPGROUP_CB_T           *_ptr_clxs_nexthopgroup_cb[CLXS_MAX_CHIP_NUM];


/* API DECLARATIONS
 */
sai_status_t
clxs_nexthopgroup_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthopgroup_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthopgroup_getObj(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         ecmp_grp_id,
    _Out_ sai_object_id_t       *ptr_next_hop_group_id);

sai_status_t
clxs_nexthopgroup_getInfo(
    _In_ const sai_object_id_t  next_hop_group_id,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_ecmp_grp_id);

sai_status_t
clxs_set_next_hop_group_member_attribute(
    _In_ sai_object_id_t        next_hop_group_member_id,
    _In_ const sai_attribute_t  *attr);

sai_status_t
clxs_get_next_hop_group_member_attribute(
    _In_ sai_object_id_t        next_hop_group_member_id,
    _In_ uint32_t               attr_count,
    _Inout_ sai_attribute_t     *attr_list);

sai_status_t
clxs_nexthopgroup_syncRhGroup(
    _In_ const uint32_t         unit,
    _In_ sai_object_id_t        pre_group_oid,
    _In_ sai_object_id_t        cur_group_oid);

#ifdef CLX_NEXTHOPGROUP_AUTO_UPDATE
void
clxs_nexthopgroup_auto_update (
    _In_ sai_object_id_t port_id,
    _In_ sai_port_oper_status_t status);
#endif

sai_status_t
clxs_create_next_hop_group_member(
    _Out_ sai_object_id_t       *next_hop_group_member_id,
    _In_ sai_object_id_t        switch_id,
    _In_ uint32_t               attr_count,
    _In_ const sai_attribute_t  *attr_list);

sai_status_t
clxs_remove_next_hop_group_member(
    _In_ sai_object_id_t        next_hop_group_member_id);

CLXS_NEXTHOPGROUP_DB_T *
_clxs_nexthopgroup_getEntry(
    _In_ uint32_t           unit,
    _In_ uint32_t           entry_id);

sai_status_t
clxs_nexthopgroup_incRefCnt(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  grp_id);

sai_status_t
clxs_nexthopgroup_decRefCnt(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  grp_id);

bool
clxs_nexthopgroup_isReferenced(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  grp_id);

sai_status_t clxs_nexthopgroup_get_enum_values_capability(
    _In_ uint32_t unit,
    _In_ sai_attr_id_t attr_id,
    _Inout_ sai_s32_list_t *enum_values_capability);

#endif /* __CLXS_NEXTHOPGROUP_H__ */
