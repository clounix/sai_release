/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_ROUTERINTERFACE_H__)
#define __CLXS_ROUTERINTERFACE_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define INVALID_INTF_ID 0xffffffff
#define CLXS_RIF_NVO3_RTE_INTF(__unit__)                (CLXS_MIN_NVO3_INTF_ID(__unit__))
#define CLXS_RIF_NVO3_RTE_MASK(__unit__)                (CLXS_NUM_RIF(__unit__) - CLXS_NUM_NVO3_INTF_ID(__unit__))

#define CLXS_RIF_RTE_MASK(__unit__)                     (((CLXS_NUM_RIF(__unit__)+1023)/1024)*1024 - 1)

#define CLXS_MIN_NVO3_INTF_ID(__unit__)             (CLXS_NUM_RIF(__unit__) - CLXS_NUM_NVO3_INTF_ID(__unit__))
#define CLXS_MIN_NVO3_RTE_MAC(__unit__)             (CLXS_NUM_RTE(__unit__) - CLXS_NUM_NVO3_RTE_MAC(__unit__))

#define CLXS_RIF_CB(unit) (ptr_clxs_rif_cb[unit])

#define CLXS_RIF_LOCK(unit) \
    sai_osal_mutex_lock(ptr_clxs_rif_cb[unit]->sema)

#define CLXS_RIF_UNLOCK(unit) \
    sai_osal_mutex_unlock(ptr_clxs_rif_cb[unit]->sema)

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    CLXS_RIF_IDX_TYPE_RTE_MAC = 0,
    CLXS_RIF_IDX_TYPE_TNL_MAC,
    CLXS_RIF_IDX_TYPE_NVO3_MAC,
} CLXS_RIF_IDX_TYPE_T;

typedef struct
{
    bool                valid;
    bool                is_nvo3;
    CLX_BRIDGE_DOMAIN_T bdid;
    sai_int32_t         type;
    uint32_t            rte_mac_idx;
    uint32_t            tnl_mac_idx;
    uint32_t            sub_vid;
    sai_object_id_t     ing_acl_object;
    sai_object_id_t     egr_acl_object;
    union
    {
        sai_object_id_t     obj_id; /* port, lag, or vlan object_id */
        struct
        {
            uint16_t inner_vid, outer_vid;
        } qinq;
    } u;
} CLXS_RIF_ENTRY_T;

typedef struct
{
    bool                valid;
    bool                is_nvo3;
} CLXS_RIF_RTE_MAC_T;

typedef struct
{
    bool                valid;
    uint32_t            ref_cnt;
    CLX_MAC_T           tunnel_mac;
    CLX_MAC_T           tunnel_mac_mask;
} CLXS_RIF_TNL_MAC_T;

typedef struct
{
    CLXS_RIF_ENTRY_T     *ptr_rif_entry;
    /* index is intf_id, not l3_intf_id in sdk, we can not assume that sdk will give us same intf_id as
       we allocate from our bitmap, we can not assume that other module do not create l3_intf locally*/
//    CLX_L3_INTF_INFO_T  *ptr_intf_entry;     /* DB for bridge_intf, index is l3_intf_id */
    uint32_t            *bdid2intfid;
    CLXS_RIF_RTE_MAC_T  *ptr_rte_entry;         /* my_rte_mac */
    uint32_t            *ptr_tnl_bmp;           /* my_tnl_mac */
    CLXS_RIF_TNL_MAC_T  *ptr_tnl_mac;
    CLX_SEMAPHORE_ID_T  sema;

} CLXS_RIF_CB_T;

extern const sai_router_interface_api_t routerinterface_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T router_interface_stats_capability_info;
extern uint32_t         _clxs_rif_max_num[CLXS_MAX_CHIP_NUM];
extern CLXS_RIF_CB_T     *ptr_clxs_rif_cb[CLXS_MAX_CHIP_NUM];

/* API DECLARATIONS
 */
sai_status_t clxs_rif_init(
    _In_ const uint32_t    unit);

sai_status_t clxs_rif_deinit(
    _In_ const uint32_t    unit);

sai_status_t clxs_rif_getsubvid(
    _In_  const sai_object_id_t         rif_id,
    _Out_ uint32_t                      *ptr_subvid);

sai_status_t clxs_rif_getInfo(
    _In_  const sai_object_id_t         rif_id,
    _Out_ uint32_t                      *ptr_unit,
    _Out_ CLX_BRIDGE_DOMAIN_T           *ptr_bdid,
    _Out_ CLX_L3_INTF_INFO_T            *ptr_intf_info,
    _Out_ sai_router_interface_type_t   *ptr_type,
    _Out_ CLX_PORT_T                    *ptr_port);

sai_status_t clxs_rif_updateLagMember(
    _In_ const sai_object_id_t          lag_oid,
    _In_ const sai_object_id_t          member_port_oid,
    _In_ const bool                     is_add);

sai_status_t clxs_rif_get_bdid(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  intf_id,
    _Out_ CLX_BRIDGE_DOMAIN_T* bdid);

sai_status_t clxs_rif_get_type(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  intf_id,
    _Out_ sai_int32_t* type);

sai_status_t
clxs_rif_allocRouterMacIdx(
    const uint32_t              unit,
    const CLXS_RIF_IDX_TYPE_T    type,
    uint32_t                    *ptr_idx);

void
clxs_rif_freeRouterMacIdx(
    const uint32_t              unit,
    const CLXS_RIF_IDX_TYPE_T    type,
    const uint32_t              idx);

sai_status_t clxs_rif_getRouterMacIdx(
    _In_ const uint32_t              unit,
    _In_ const CLXS_RIF_IDX_TYPE_T    type,
    _In_ const uint32_t                 l3_intf_id,
    _In_ const CLX_MAC_T  mac,
    _Out_  uint32_t*              ptr_idx);

sai_status_t clxs_rif_update_router_mac(
    _In_ const uint32_t unit,
    _In_ const sai_mac_t old_mac,
    _In_ const sai_mac_t new_mac);

sai_status_t
clxs_rif_alloc_nvo3_intf(
    const uint32_t  unit,
    uint32_t        *ptr_intf_id);

void
clxs_rif_free_nvo3_intf(
    const uint32_t  unit,
    uint32_t        intf_id);

bool
clxs_rif_intf_is_nvo3(
    const uint32_t  unit,
    const uint32_t  intf_id);

sai_status_t
clxs_rif_update_router_macByVrf(
    _In_ const uint32_t unit,
    _In_ const uint32_t vrf,
    _In_ const sai_mac_t* new_mac);

#endif /* __CLXS_ROUTERINTERFACE_H__ */
