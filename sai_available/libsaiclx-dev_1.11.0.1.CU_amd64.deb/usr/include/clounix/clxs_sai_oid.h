/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_OID_H__)
#define __CLXS_OID_H__

#define SAI_OID_NAME_MAX_LEN            40
#define SAI_OID_FIELD_NUM_MAX           8
#define SAI_OID_FIELDS_STR_MAX          512
#define SAI_OID_FIELD_INVALID_VALUE     0

/*The field type defination sorted by the sequence of sai_object_type_t*/
typedef enum _sai_object_id_field_type_t {
    SAI_OID_FIELD_NULL,
    SAI_OID_FIELD_TYPE,                     //oid type
    SAI_OID_FIELD_UNIT,
    SAI_OID_FIELD_PORT,
    SAI_OID_FIELD_CLX_PORT,                 //SAI_OBJECT_TYPE_PORT
    SAI_OID_FIELD_LAG_ID,
    SAI_OID_FIELD_LAG_PORT,                 //SAI_OBJECT_TYPE_LAG
    SAI_OID_FIELD_VRF_ID,                   //SAI_OBJECT_TYPE_VIRTUAL_ROUTER
    SAI_OID_FIELD_NEXT_HOP_TYPE,
    SAI_OID_FIELD_NEXT_HOP_ID,//10          //SAI_OBJECT_TYPE_NEXT_HOP
    SAI_OID_FIELD_NHOP_GRP_ID,              //SAI_OBJECT_TYPE_NEXT_HOP_GROUP
    SAI_OID_FIELD_INTF_ID,                  //SAI_OBJECT_TYPE_ROUTER_INTERFACE
    SAI_OID_FIELD_ACL_TABLE_ID,
    SAI_OID_FIELD_ACL_STAGE,                //SAI_OBJECT_TYPE_ACL_TABLE
    SAI_OID_FIELD_ACL_ENTRY_ID,
    SAI_OID_FIELD_ACL_ENTRY_TABLE_ID,
    SAI_OID_FIELD_ACL_ENTRY_STAGE,          //SAI_OBJECT_TYPE_ACL_ENTRY
    SAI_OID_FIELD_ACL_COUNTER_ID,           //SAI_OBJECT_TYPE_ACL_COUNTER
    SAI_OID_FIELD_ACL_RANGE_ID,             //SAI_OBJECT_TYPE_ACL_RANGE
    SAI_OID_FIELD_ACL_GRP_ID,//20           //SAI_OBJECT_TYPE_ACL_TABLE_GROUP
    SAI_OID_FIELD_ACL_GRP_MBR_GRP_ID,
    SAI_OID_FIELD_ACL_GRP_MBR_STAGE,        //SAI_OBJECT_TYPE_ACL_TABLE_GROUP_MEMBER
    SAI_OID_FIELD_HOSTIF_ID,                //SAI_OBJECT_TYPE_HOSTIF
    SAI_OID_FIELD_MIR_SESSION_ID,           //SAI_OBJECT_TYPE_MIRROR_SESSION
    SAI_OID_FIELD_SAMPLEPKT_ENTRY_IDX,      //SAI_OBJECT_TYPE_SAMPLEPACKET
    SAI_OID_FIELD_STP_ID,                   //SAI_OBJECT_TYPE_STP
    SAI_OID_FIELD_HOSTIF_TRAP_GRP_ID,       //SAI_OBJECT_TYPE_HOSTIF_TRAP_GROUP
    SAI_OID_FIELD_POLICER_COLOR_ACT,
    SAI_OID_FIELD_POLICER_METER_ID,         //SAI_OBJECT_TYPE_POLICER
    SAI_OID_FIELD_WRED_PROF_ID,//30         //SAI_OBJECT_TYPE_WRED
    SAI_OID_FIELD_QOS_MAP_TYPE,
    SAI_OID_FIELD_QUEUE_PROF_ENTRY_ID,      //SAI_OBJECT_TYPE_QOS_MAP
    SAI_OID_FIELD_QUEUE_TYPE,
    SAI_OID_FIELD_QUEUE_ID,                 //SAI_OBJECT_TYPE_QUEUE
    SAI_OID_FIELD_SCH_PROF_ID,              //SAI_OBJECT_TYPE_SCHEDULER
    SAI_OID_FIELD_SCH_GRP_LEVEL,
    SAI_OID_FIELD_SCH_GRP_FIND_IDX,         //SAI_OBJECT_TYPE_SCHEDULER_GROUP
    SAI_OID_FIELD_NP_POOL_ID,               //SAI_OBJECT_TYPE_BUFFER_POOL
    SAI_OID_FIELD_DB_BUF_PROF_IND,//40      //SAI_OBJECT_TYPE_BUFFER_PROFILE
    SAI_OID_FIELD_PG_ID,                    //SAI_OBJECT_TYPE_INGRESS_PRIORITY_GROUP
    SAI_OID_FIELD_LAG_MBR,                  //SAI_OBJECT_TYPE_LAG_MEMBER
    SAI_OID_FIELD_HASH_IDX,                 //SAI_OBJECT_TYPE_HASH
    SAI_OID_FIELD_UDF_DB_IDX,               //SAI_OBJECT_TYPE_UDF  SAI_OBJECT_TYPE_UDF_MATCH  SAI_OBJECT_TYPE_UDF_GROUP
    SAI_OID_FIELD_HOSTIF_TRAP_TYPE,         //SAI_OBJECT_TYPE_HOSTIF_TRAP
    SAI_OID_FIELD_HOSTIF_TABLE_ID,          //SAI_OBJECT_TYPE_HOSTIF_TABLE_ENTRY
    SAI_OID_FIELD_VLAN_VID,                 //SAI_OBJECT_TYPE_VLAN
    SAI_OID_FIELD_VLAN_MBR_VID,
    SAI_OID_FIELD_BD_PORT_ID,               //SAI_OBJECT_TYPE_VLAN_MEMBER
    SAI_OID_FIELD_TUNNEL_MAP_ID,//50        //SAI_OBJECT_TYPE_TUNNEL_MAP
    SAI_OID_FIELD_TUNNEL_SAI_ID,            //SAI_OBJECT_TYPE_TUNNEL
    SAI_OID_FIELD_TUNNEL_TERM_CLX_ID,
    SAI_OID_FIELD_TUNNEL_TERM_SAI_ID,       //SAI_OBJECT_TYPE_TUNNEL_TERM_TABLE_ENTRY
    SAI_OID_FIELD_NHOP_GRP_TYPE,
    SAI_OID_FIELD_NHOP_GRP_MBR_ID,          //SAI_OBJECT_TYPE_NEXT_HOP_GROUP_MEMBER
    SAI_OID_FIELD_STP_PORT_STP_ID,          //SAI_OBJECT_TYPE_STP_PORT
    SAI_OID_FIELD_RPF_ID,                   //SAI_OBJECT_TYPE_RPF_GROUP
    SAI_OID_FIELD_RPF_MBR_SW_ID,            //SAI_OBJECT_TYPE_RPF_GROUP_MEMBER
    SAI_OID_FIELD_L2MC_MCAST_ID,            //SAI_OBJECT_TYPE_L2MC_GROUP
    SAI_OID_FIELD_L2MC_MBR_MCAST_ID,//60    //SAI_OBJECT_TYPE_L2MC_GROUP_MEMBER
    SAI_OID_FIELD_IPMC_MCAST_ID,            //SAI_OBJECT_TYPE_IPMC_GROUP
    SAI_OID_FIELD_IPMC_MBR_ID,              //SAI_OBJECT_TYPE_IPMC_GROUP_MEMBER
    SAI_OID_FIELD_BD_ID,                    //SAI_OBJECT_TYPE_BRIDGE
    SAI_OID_FIELD_TUNNEL_MAP_ENTRY_ID,
    SAI_OID_FIELD_TUNNEL_MAP_ENTRY_MAP_ID,  //SAI_OBJECT_TYPE_TUNNEL_MAP_ENTRY
    SAI_OID_FIELD_TAM_ENTRY_ID,             //SAI_OBJECT_TYPE_TAM
    SAI_OID_FIELD_PORT_POOL_ID,
    SAI_OID_FIELD_PORT_POOL_TYPE,           //SAI_OBJECT_TYPE_PORT_POOL
    SAI_OID_FIELD_ISOLATION_GRP_ID,         //SAI_OBJECT_TYPE_ISOLATION_GROUP
    SAI_OID_FIELD_ISOLATION_GRP_MBR_ID,//70 //SAI_OBJECT_TYPE_ISOLATION_GROUP_MEMBER
    SAI_OID_FIELD_TAM_MATH_FUNC_ENTRY_ID,   //SAI_OID_FIELD_TAM_MATH_FUNC
    SAI_OID_FIELD_TAM_REPORT_ENTRY_ID,      //SAI_OBJECT_TYPE_TAM_REPORT
    SAI_OID_FIELD_TAM_EVENT_THRESHOLD_ENTRY_ID,   //SAI_OBJECT_TYPE_TAM_EVENT_THRESHOLD
    SAI_OID_FIELD_TAM_TEL_TYPE_ENTRY_ID,    //SAI_OBJECT_TYPE_TAM_TEL_TYPE
    SAI_OID_FIELD_TAM_TRANSPORT_ENTRY_ID,   //SAI_OBJECT_TYPE_TAM_TRANSPORT
    SAI_OID_FIELD_TAM_TELEMETRY_ENTRY_ID,   //SAI_OBJECT_TYPE_TAM_TELEMETRY
    SAI_OID_FIELD_TAM_COLLECTOR_ENTRY_ID,   //SAI_OBJECT_TYPE_TAM_COLLECTOR
    SAI_OID_FIELD_TAM_EVENT_ACTION_ENTRY_ID,//SAI_OBJECT_TYPE_TAM_EVENT_ACTION
    SAI_OID_FIELD_TAM_EVENT_ENTRY_ID,       //SAI_OBJECT_TYPE_TAM_EVENT
    SAI_OID_FIELD_TAM_INT_TYPE,//80
    SAI_OID_FIELD_TAM_INT_PROFILE_ID,       //SAI_OBJECT_TYPE_TAM_INT
    SAI_OID_FIELD_COUNTER_TYPE,
    SAI_OID_FIELD_CNT_ID,                   //SAI_OBJECT_TYPE_COUNTER SAI_OBJECT_TYPE_DEBUG_COUNTER
    SAI_OID_FIELD_SERDES_PORT,              //SAI_OBJECT_TYPE_PORT_SERDES
    SAI_OID_FIELD_TUNNEL_TYPE,              //TUNNEL TYPE
    SAI_OID_FIELD_NAME_MAX
} sai_object_id_field_type_t;

typedef struct _clxs_oid_field_t {
    sai_object_id_field_type_t  field_type;
    uint16_t                    offset;
    uint16_t                    length;
} clxs_oid_field_t;

typedef struct _clxs_meta_oid_t {
    sai_object_type_t   type;
    uint16_t            field_num;
    clxs_oid_field_t    oid_field[SAI_OID_FIELD_NUM_MAX];
} clxs_meta_oid_t;

typedef struct _clxs_oid_field_data_t {
    sai_object_id_field_type_t  type;
    uint32_t                    value;
} clxs_oid_field_data_t;

extern const char *sai_oid_field_to_str_map[SAI_OID_FIELD_NAME_MAX];
 #define SAI_OID_FIELD_NAME_STR(__fname__)     \
    ({int t = (__fname__); t< SAI_OID_FIELD_NAME_MAX ? sai_oid_field_to_str_map[t] : "Unknown oid field name";})

sai_status_t
clxs_oid_init(void);

sai_status_t
clxs_create_oid(
    _In_ sai_object_type_t  oid_type,
    _In_ uint32_t           *ptr_fields,
    _In_ uint32_t           data_len,
    _Out_ sai_object_id_t   *ptr_oid);

sai_object_type_t
clxs_get_oid_type(
    _In_ sai_object_id_t    object_id);

sai_status_t
clxs_parse_oid(
    _In_ sai_object_id_t        object_id,
    _Out_ sai_object_type_t     *type,
    _Out_ clxs_oid_field_data_t *oid_field);

sai_status_t
clxs_get_oid_fields(
    _In_ sai_object_id_t    object_id,
    _In_ sai_object_type_t  oid_type,
    _In_ uint32_t           data_len,
    _Out_ uint32_t          **oid_field);

int32_t
clxs_set_oid_fields_str(
    _In_ sai_object_id_t        object_id,
    _In_ sai_object_type_t      oid_type,
    _In_ int32_t                str_len,
    _Out_ char                  *ptr_str);

sai_status_t
clxs_object_to_pbmp(
    _In_ const uint32_t             unit,
    _In_ const sai_object_id_t      oid,    /* PORT/LAG object */
    _Out_ CLX_PORT_BITMAP_T         bmp);

/*************oid operation definition************/

#define _CLXS_CREATE_OID(_ret, _oid_type, _ptr_oid, ...) \
            do \
            { \
                uint32_t _oid_field_data[] = {__VA_ARGS__}; \
                _ret = clxs_create_oid(_oid_type, _oid_field_data, sizeof(_oid_field_data)/sizeof(uint32_t), _ptr_oid); \
            } while(0)

#define _CLXS_GET_OID_FIELDS(_ret, _oid_type, _oid, ...) \
            do \
            { \
                uint32_t *_oid_field_data[] = {__VA_ARGS__}; \
                _ret = clxs_get_oid_fields(_oid, _oid_type, sizeof(_oid_field_data)/sizeof(uint32_t *), _oid_field_data); \
            } while(0)

#define CLXS_CREATE_PORT_OID(_ret, _unit, _port, _clx_port, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_PORT, _ptr_oid, _port, _unit, _clx_port)

#define CLXS_GET_PORT_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_port, _ptr_clx_port) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_PORT, _oid, _ptr_port, _ptr_unit, _ptr_clx_port)


#define CLXS_CREATE_LAG_OID(_ret, _unit, _lagid, _port, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_LAG, _ptr_oid, _lagid, _unit, _port)

#define CLXS_GET_LAG_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_lagid, _ptr_port) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_LAG, _oid, _ptr_lagid, _ptr_unit, _ptr_port)


#define CLXS_CREATE_VIRTUAL_ROUTER_OID(_ret, _unit, _vrf_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_VIRTUAL_ROUTER, _ptr_oid, _unit, _vrf_id)

#define CLXS_GET_VIRTUAL_ROUTER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_vrf_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_VIRTUAL_ROUTER, _oid, _ptr_unit, _ptr_vrf_id)


#define CLXS_CREATE_NEXT_HOP_OID(_ret, _unit, _nexthop_type, _nexthop_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_NEXT_HOP, _ptr_oid, _unit, _nexthop_type, _nexthop_id)

#define CLXS_GET_NEXT_HOP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_nexthop_type, _ptr_nexthop_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_NEXT_HOP, _oid, _ptr_unit, _ptr_nexthop_type, _ptr_nexthop_id)


#define CLXS_CREATE_NEXT_HOP_GROUP_OID(_ret, _unit, _nhop_grp_type, _ecmp_grp_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_NEXT_HOP_GROUP, _ptr_oid, _unit, _nhop_grp_type, _ecmp_grp_id)

#define CLXS_GET_NEXT_HOP_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_nhop_grp_type, _ptr_ecmp_grp_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_NEXT_HOP_GROUP, _oid, _ptr_unit, _ptr_nhop_grp_type, _ptr_ecmp_grp_id)


#define CLXS_CREATE_ROUTER_INTERFACE_OID(_ret, _unit, _intf_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ROUTER_INTERFACE, _ptr_oid, _unit, _intf_id)

#define CLXS_GET_ROUTER_INTERFACE_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_intf_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ROUTER_INTERFACE, _oid, _ptr_unit, _ptr_intf_id)


#define CLXS_CREATE_ACL_TABLE_OID(_ret, _unit, _acl_table_id, _acl_stage, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ACL_TABLE, _ptr_oid, _unit, _acl_table_id, _acl_stage)

#define CLXS_GET_ACL_TABLE_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_acl_table_id, _ptr_acl_stage) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ACL_TABLE, _oid, _ptr_unit, _ptr_acl_table_id, _ptr_acl_stage)


#define CLXS_CREATE_ACL_ENTRY_OID(_ret, _unit, _acl_entry_id, _acl_entry_table_id, _acl_entry_stage, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ACL_ENTRY, _ptr_oid, _unit, _acl_entry_id, _acl_entry_table_id, _acl_entry_stage)

#define CLXS_GET_ACL_ENTRY_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_acl_entry_id, _ptr_acl_entry_table_id, _ptr_acl_entry_stage) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ACL_ENTRY, _oid, _ptr_unit, _ptr_acl_entry_id, _ptr_acl_entry_table_id, _ptr_acl_entry_stage)


#define CLXS_CREATE_ACL_COUNTER_OID(_ret, _unit, _acl_counter_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ACL_COUNTER, _ptr_oid, _unit, _acl_counter_id)

#define CLXS_GET_ACL_COUNTER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_acl_counter_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ACL_COUNTER, _oid, _ptr_unit, _ptr_acl_counter_id)


#define CLXS_CREATE_ACL_RANGE_OID(_ret, _unit, _acl_range_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ACL_RANGE, _ptr_oid, _unit, _acl_range_id)

#define CLXS_GET_ACL_RANGE_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_acl_range_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ACL_RANGE, _oid, _ptr_unit, _ptr_acl_range_id)


#define CLXS_CREATE_ACL_TABLE_GROUP_OID(_ret, _unit, _acl_grp_id, _acl_stage, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ACL_TABLE_GROUP, _ptr_oid, _unit, _acl_grp_id,_acl_stage)

#define CLXS_GET_ACL_TABLE_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_acl_grp_id,_ptr_acl_stage) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ACL_TABLE_GROUP, _oid, _ptr_unit, _ptr_acl_grp_id, _ptr_acl_stage)


#define CLXS_CREATE_ACL_TABLE_GROUP_MEMBER_OID(_ret, _unit, _acl_table_id, _acl_grp_mbr_grp_id, _acl_grp_mbr_stage, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ACL_TABLE_GROUP_MEMBER, _ptr_oid, _unit, _acl_table_id, _acl_grp_mbr_grp_id, _acl_grp_mbr_stage)

#define CLXS_GET_ACL_TABLE_GROUP_MEMBER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_acl_table_id, _ptr_acl_grp_mbr_grp_id, _ptr_acl_grp_mbr_stage) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ACL_TABLE_GROUP_MEMBER, _oid, _ptr_unit, _ptr_acl_table_id, _ptr_acl_grp_mbr_grp_id, _ptr_acl_grp_mbr_stage)


#define CLXS_CREATE_HOSTIF_OID(_ret, _unit, _hostif_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_HOSTIF, _ptr_oid, _unit, _hostif_id)

#define CLXS_GET_HOSTIF_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_hostif_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_HOSTIF, _oid, _ptr_unit, _ptr_hostif_id)


#define CLXS_CREATE_MIRROR_SESSION_OID(_ret, _unit, _mir_session_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_MIRROR_SESSION, _ptr_oid, _unit, _mir_session_id)

#define CLXS_GET_MIRROR_SESSION_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_mir_session_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_MIRROR_SESSION, _oid, _ptr_unit, _ptr_mir_session_id)


#define CLXS_CREATE_SAMPLEPACKET_OID(_ret, _unit, _samplepacket_entry_idx, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_SAMPLEPACKET, _ptr_oid, _unit, _samplepacket_entry_idx)

#define CLXS_GET_SAMPLEPACKET_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_samplepacket_entry_idx) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_SAMPLEPACKET, _oid, _ptr_unit, _ptr_samplepacket_entry_idx)


#define CLXS_CREATE_STP_OID(_ret, _unit, _stp_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_STP, _ptr_oid, _unit, _stp_id)

#define CLXS_GET_STP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_stp_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_STP, _oid, _ptr_unit, _ptr_stp_id)


#define CLXS_CREATE_HOSTIF_TRAP_GROUP_OID(_ret, _unit, _hostif_trap_grp_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_HOSTIF_TRAP_GROUP, _ptr_oid, _unit, _hostif_trap_grp_id)

#define CLXS_GET_HOSTIF_TRAP_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_hostif_trap_grp_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_HOSTIF_TRAP_GROUP, _oid, _ptr_unit, _ptr_hostif_trap_grp_id)


#define CLXS_CREATE_POLICER_OID(_ret, _unit, _policer_color_act, _policer_meter_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_POLICER, _ptr_oid, _unit, _policer_color_act, _policer_meter_id)

#define CLXS_GET_POLICER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_policer_color_act, _ptr_policer_meter_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_POLICER, _oid, _ptr_unit, _ptr_policer_color_act, _ptr_policer_meter_id)


#define CLXS_CREATE_WRED_OID(_ret, _unit, _wred_prof_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_WRED, _ptr_oid, _unit, _wred_prof_id)

#define CLXS_GET_WRED_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_wred_prof_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_WRED, _oid, _ptr_unit, _ptr_wred_prof_id)


#define CLXS_CREATE_QOS_MAP_OID(_ret, _unit, _qos_map_type, _queue_prof_entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_QOS_MAP, _ptr_oid, _unit, _qos_map_type, _queue_prof_entry_id)

#define CLXS_GET_QOS_MAP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_qos_map_type, _ptr_queue_prof_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_QOS_MAP, _oid, _ptr_unit, _ptr_qos_map_type, _ptr_queue_prof_entry_id)


#define CLXS_CREATE_QUEUE_OID(_ret, _unit, _port, _queue_type, _queue_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_QUEUE, _ptr_oid, _unit, _port, _queue_type, _queue_id)

#define CLXS_GET_QUEUE_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_port, _ptr_queue_type, _ptr_queue_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_QUEUE, _oid, _ptr_unit, _ptr_port, _ptr_queue_type, _ptr_queue_id)


#define CLXS_CREATE_SCHEDULER_OID(_ret, _unit, _sch_prof_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_SCHEDULER, _ptr_oid, _unit, _sch_prof_id)

#define CLXS_GET_SCHEDULER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_sch_prof_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_SCHEDULER, _oid, _ptr_unit, _ptr_sch_prof_id)


#define CLXS_CREATE_SCHEDULER_GROUP_OID(_ret, _unit, _sch_grp_level, _sch_grp_find_idx, _clx_port, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_SCHEDULER_GROUP, _ptr_oid, _unit, _sch_grp_level, _sch_grp_find_idx, _clx_port)

#define CLXS_GET_SCHEDULER_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_sch_grp_level, _ptr_sch_grp_find_idx, _ptr_clx_port) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_SCHEDULER_GROUP, _oid, _ptr_unit, _ptr_sch_grp_level, _ptr_sch_grp_find_idx, _ptr_clx_port)


#define CLXS_CREATE_BUFFER_POOL_OID(_ret, _unit, _np_pool_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_BUFFER_POOL, _ptr_oid, _unit, _np_pool_id)

#define CLXS_GET_BUFFER_POOL_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_np_pool_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_BUFFER_POOL, _oid, _ptr_unit, _ptr_np_pool_id)


#define CLXS_CREATE_BUFFER_PROFILE_OID(_ret, _unit, _db_buf_prof_ind, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_BUFFER_PROFILE, _ptr_oid, _unit, _db_buf_prof_ind)

#define CLXS_GET_BUFFER_PROFILE_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_db_buf_prof_ind) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_BUFFER_PROFILE, _oid, _ptr_unit, _ptr_db_buf_prof_ind)


#define CLXS_CREATE_INGRESS_PRIORITY_GROUP_OID(_ret, _unit, _pg_id, _clx_port, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_INGRESS_PRIORITY_GROUP, _ptr_oid,  _pg_id, _unit, _clx_port)

#define CLXS_GET_INGRESS_PRIORITY_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_pg_id, _ptr_clx_port) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_INGRESS_PRIORITY_GROUP, _oid, _ptr_pg_id, _ptr_unit, _ptr_clx_port)


#define CLXS_CREATE_LAG_MEMBER_OID(_ret, _unit, _lag_id, _lag_mbr, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_LAG_MEMBER, _ptr_oid,  _lag_id, _unit, _lag_mbr)

#define CLXS_GET_LAG_MEMBER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_lag_id, _ptr_lag_mbr) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_LAG_MEMBER, _oid, _ptr_lag_id, _ptr_unit, _ptr_lag_mbr)


#define CLXS_CREATE_HASH_OID(_ret, _unit, _hash_idx, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_HASH, _ptr_oid, _unit, _hash_idx)

#define CLXS_GET_HASH_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_hash_idx) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_HASH, _oid, _ptr_unit, _ptr_hash_idx)


#define CLXS_CREATE_UDF_OID(_ret, _unit, _udf_db_idx, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_UDF, _ptr_oid, _unit, _udf_db_idx)

#define CLXS_GET_UDF_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_udf_db_idx) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_UDF, _oid, _ptr_unit, _ptr_udf_db_idx)


#define CLXS_CREATE_UDF_MATCH_OID(_ret, _unit, _udf_db_idx, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_UDF_MATCH, _ptr_oid, _unit, _udf_db_idx)

#define CLXS_GET_UDF_MATCH_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_udf_db_idx) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_UDF_MATCH, _oid, _ptr_unit, _ptr_udf_db_idx)


#define CLXS_CREATE_UDF_GROUP_OID(_ret, _unit, _udf_db_idx, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_UDF_GROUP, _ptr_oid, _unit, _udf_db_idx)

#define CLXS_GET_UDF_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_udf_db_idx) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_UDF_GROUP, _oid, _ptr_unit, _ptr_udf_db_idx)


#define CLXS_CREATE_SWITCH_OID(_ret, _unit, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_SWITCH, _ptr_oid, _unit)

#define CLXS_GET_SWITCH_OID_FIELDS(_ret, _oid, _ptr_unit) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_SWITCH, _oid, _ptr_unit)


#define CLXS_CREATE_HOSTIF_TRAP_OID(_ret, _unit, _hostif_trap_type, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_HOSTIF_TRAP, _ptr_oid, _unit, _hostif_trap_type)

#define CLXS_GET_HOSTIF_TRAP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_hostif_trap_type) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_HOSTIF_TRAP, _oid, _ptr_unit, _ptr_hostif_trap_type)


#define CLXS_CREATE_HOSTIF_TABLE_ENTRY_OID(_ret, _unit, _hostif_table_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_HOSTIF_TABLE_ENTRY, _ptr_oid, _unit, _hostif_table_id)

#define CLXS_GET_HOSTIF_TRAP_TABLE_ENTRY_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_hostif_table_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_HOSTIF_TABLE_ENTRY, _oid, _ptr_unit, _ptr_hostif_table_id)


#define CLXS_CREATE_VLAN_OID(_ret, _unit, _vlan_vid, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_VLAN, _ptr_oid, _unit, _vlan_vid)

#define CLXS_GET_VLAN_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_vlan_vid) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_VLAN, _oid, _ptr_unit, _ptr_vlan_vid)


#define CLXS_CREATE_VLAN_MEMBER_OID(_ret, _unit, _vlan_member_vid, _bd_port_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_VLAN_MEMBER, _ptr_oid, _unit, _vlan_member_vid, _bd_port_id)

#define CLXS_GET_VLAN_MEMBER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_vlan_member_vid, _ptr_bd_port_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_VLAN_MEMBER, _oid, _ptr_unit, _ptr_vlan_member_vid, _ptr_bd_port_id)


#define CLXS_CREATE_TUNNEL_MAP_OID(_ret, _unit, _tunnel_map_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TUNNEL_MAP, _ptr_oid, _unit, _tunnel_map_id)

#define CLXS_GET_TUNNEL_MAP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_tunnel_map_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TUNNEL_MAP, _oid, _ptr_unit, _ptr_tunnel_map_id)


#define CLXS_CREATE_TUNNEL_OID(_ret, _unit, _tunnel_sai_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TUNNEL, _ptr_oid, _unit, _tunnel_sai_id)

#define CLXS_GET_TUNNEL_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_tunnel_sai_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TUNNEL, _oid, _ptr_unit, _ptr_tunnel_sai_id)


#define CLXS_CREATE_TUNNEL_TERM_TABLE_ENTRYR_OID(_ret, _unit, _tunnel_term_clx_id, _tunnel_term_sai_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TUNNEL_TERM_TABLE_ENTRY, _ptr_oid, _unit, _tunnel_term_clx_id, _tunnel_term_sai_id)

#define CLXS_GET_TUNNEL_TERM_TABLE_ENTRY_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_tunnel_term_clx_id, _ptr_tunnel_term_sai_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TUNNEL_TERM_TABLE_ENTRY, _oid, _ptr_unit, _ptr_tunnel_term_clx_id, _ptr_tunnel_term_sai_id)


#define CLXS_CREATE_NEXT_HOP_GROUP_MEMBER_OID(_ret, _unit, _nhop_grp_type, _nhop_grp_id, _nhop_grp_mbr_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_NEXT_HOP_GROUP_MEMBER, _ptr_oid, _unit, _nhop_grp_type, _nhop_grp_id, _nhop_grp_mbr_id)

#define CLXS_GET_NEXT_HOP_GROUP_MEMBER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_nhop_grp_type, _ptr_nhop_grp_id, _ptr_nhop_grp_mbr_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_NEXT_HOP_GROUP_MEMBER, _oid, _ptr_unit, _ptr_nhop_grp_type, _ptr_nhop_grp_id, _ptr_nhop_grp_mbr_id)


#define CLXS_CREATE_STP_PORT_OID(_ret, _unit, _stp_id, _bd_port_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_STP_PORT, _ptr_oid, _unit, _stp_id, _bd_port_id)

#define CLXS_GET_STP_PORT_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_stp_id, _ptr_bd_port_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_STP_PORT, _oid, _ptr_unit, _ptr_stp_id, _ptr_bd_port_id)


#define CLXS_CREATE_RPF_GROUP_OID(_ret, _unit, _rpf_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_RPF_GROUP, _ptr_oid, _unit, _rpf_id)

#define CLXS_GET_RPF_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_rpf_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_RPF_GROUP, _oid, _ptr_unit, _ptr_rpf_id)


#define CLXS_CREATE_RPF_GROUP_MEMBER_OID(_ret, _unit, _rpf_mbr_sw_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_RPF_GROUP_MEMBER, _ptr_oid, _unit, _rpf_mbr_sw_id)

#define CLXS_GET_RPF_GROUP_MEMBER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_rpf_mbr_sw_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_RPF_GROUP_MEMBER, _oid, _ptr_unit, _ptr_rpf_mbr_sw_id)


#define CLXS_CREATE_L2MC_GROUP_OID(_ret, _unit, _l2mc_mcast_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_L2MC_GROUP, _ptr_oid, _unit, _l2mc_mcast_id)

#define CLXS_GET_L2MC_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_l2mc_mcast_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_L2MC_GROUP, _oid, _ptr_unit, _ptr_l2mc_mcast_id)


#define CLXS_CREATE_L2MC_GROUP_MEMBER_OID(_ret, _unit, _l2mc_mbr_mcast_id, _bd_port_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_L2MC_GROUP_MEMBER, _ptr_oid, _unit, _l2mc_mbr_mcast_id, _bd_port_id)

#define CLXS_GET_L2MC_GROUP_MEMBER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_l2mc_mbr_mcast_id, _ptr_bd_port_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_L2MC_GROUP_MEMBER, _oid, _ptr_unit, _ptr_l2mc_mbr_mcast_id, _ptr_bd_port_id)


#define CLXS_CREATE_IPMC_GROUP_OID(_ret, _unit, _ipmc_mcast_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_IPMC_GROUP, _ptr_oid, _unit, _ipmc_mcast_id)

#define CLXS_GET_IPMC_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_ipmc_mcast_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_IPMC_GROUP, _oid, _ptr_unit, _ptr_ipmc_mcast_id)


#define CLXS_CREATE_IPMC_GROUP_MEMBER_OID(_ret, _unit, _ipmc_mbr_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_IPMC_GROUP_MEMBER, _ptr_oid, _unit, _ipmc_mbr_id)

#define CLXS_GET_IPMC_GROUP_MEMBER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_ipmc_mbr_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_IPMC_GROUP_MEMBER, _oid, _ptr_unit, _ptr_ipmc_mbr_id)


#define CLXS_CREATE_HOSTIF_USER_DEFINED_TRAP_OID(_ret, _unit, _hostif_trap_type, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_HOSTIF_USER_DEFINED_TRAP, _ptr_oid, _unit, _hostif_trap_type)

#define CLXS_GET_HOSTIF_USER_DEFINED_TRAP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_hostif_trap_type) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_HOSTIF_USER_DEFINED_TRAP, _oid, _ptr_unit, _ptr_hostif_trap_type)


#define CLXS_CREATE_BRIDGE_OID(_ret, _unit, _bd_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_BRIDGE, _ptr_oid, _unit, _bd_id)

#define CLXS_GET_BRIDGE_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_bd_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_BRIDGE, _oid, _ptr_unit, _ptr_bd_id)


#define CLXS_CREATE_BRIDGE_PORT_OID(_ret, _unit, _bd_port_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_BRIDGE_PORT, _ptr_oid, _unit, _bd_port_id)

#define CLXS_GET_BRIDGE_PORT_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_bd_port_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_BRIDGE_PORT, _oid, _ptr_unit, _ptr_bd_port_id)


#define CLXS_CREATE_TUNNEL_MAP_ENTRY_OID(_ret, _unit, _tunnel_map_entry_id, _tunnel_map_entry_map_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TUNNEL_MAP_ENTRY, _ptr_oid, _unit, _tunnel_map_entry_id, _tunnel_map_entry_map_id)

#define CLXS_GET_TUNNEL_MAP_ENTRY_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_tunnel_map_entry_id, _ptr_tunnel_map_entry_map_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TUNNEL_MAP_ENTRY, _oid, _ptr_unit, _ptr_tunnel_map_entry_id, _ptr_tunnel_map_entry_map_id)


#define CLXS_CREATE_TAM_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_PORT_POOL_OID(_ret, _unit, _port, _port_pool_type, _port_pool_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_PORT_POOL, _ptr_oid, _unit, _port, _port_pool_type, _port_pool_id)

#define CLXS_GET_PORT_POOL_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_port, _ptr_port_pool_type, _ptr_port_pool_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_PORT_POOL, _oid, _ptr_unit, _ptr_port, _ptr_port_pool_type, _ptr_port_pool_id)


#define CLXS_CREATE_ISOLATION_GROUP_OID(_ret, _unit, _isolation_grp_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ISOLATION_GROUP, _ptr_oid, _unit, _isolation_grp_id)

#define CLXS_GET_ISOLATION_GROUP_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_isolation_grp_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ISOLATION_GROUP, _oid, _ptr_unit, _ptr_isolation_grp_id)


#define CLXS_CREATE_ISOLATION_GROUP_MEMBER_OID(_ret, _unit, _isolation_grp_mbr_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_ISOLATION_GROUP_MEMBER, _ptr_oid, _unit, _isolation_grp_mbr_id)

#define CLXS_GET_ISOLATION_GROUP_MEMBER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_isolation_grp_mbr_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_ISOLATION_GROUP_MEMBER, _oid, _ptr_unit, _ptr_isolation_grp_mbr_id)


#define CLXS_CREATE_TAM_MATH_FUNC_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_MATH_FUNC, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_MATH_FUNC_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_MATH_FUNC, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_REPORT_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_REPORT, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_REPORT_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_REPORT, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_EVENT_THRESHOLD_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_EVENT_THRESHOLD, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_EVENT_THRESHOLD_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_EVENT_THRESHOLD, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_TEL_TYPE_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_TEL_TYPE, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_TEL_TYPE_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_TEL_TYPE, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_TRANSPORT_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_TRANSPORT, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_TRANSPORT_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_TRANSPORT, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_TELEMETRY_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_TELEMETRY, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_TELEMETRY_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_TELEMETRY, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_COLLECTOR_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_COLLECTOR, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_COLLECTOR_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_COLLECTOR, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_EVENT_ACTION_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_EVENT_ACTION, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_EVENT_ACTION_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_EVENT_ACTION, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_EVENT_OID(_ret, _unit, _entry_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_EVENT, _ptr_oid, _unit, _entry_id)

#define CLXS_GET_TAM_EVENT_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_entry_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_EVENT, _oid, _ptr_unit, _ptr_entry_id)


#define CLXS_CREATE_TAM_INT_OID(_ret, _unit, _tam_int_type, _profile_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_TAM_INT, _ptr_oid, _unit, _tam_int_type, _profile_id)

#define CLXS_GET_TAM_INT_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_tam_int_type, _ptr_profile_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_TAM_INT, _oid, _ptr_unit,  _ptr_tam_int_type, _ptr_profile_id)


#define CLXS_CREATE_COUNTER_OID(_ret, _unit, _counter_type, _cnt_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_COUNTER, _ptr_oid, _unit, _counter_type, _cnt_id)

#define CLXS_GET_COUNTER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_counter_type, _ptr_cnt_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_COUNTER, _oid, _ptr_unit,  _ptr_counter_type, _ptr_cnt_id)


#define CLXS_CREATE_DEBUG_COUNTER_OID(_ret, _unit, _counter_type, _cnt_id, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_DEBUG_COUNTER, _ptr_oid, _unit, _counter_type, _cnt_id)

#define CLXS_GET_DEBUG_COUNTER_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_counter_type, _ptr_cnt_id) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_DEBUG_COUNTER, _oid, _ptr_unit,  _ptr_counter_type, _ptr_cnt_id)


#define CLXS_CREATE_PORT_SERDES_OID(_ret, _unit, _serdes_port, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_PORT_SERDES, _ptr_oid, _unit, _serdes_port)

#define CLXS_GET_PORT_SERDES_OID_FIELDS(_ret, _oid, _ptr_unit, _ptr_serdes_port) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_PORT_SERDES, _oid, _ptr_unit,  _ptr_serdes_port)


#define CLXS_CREATE_SWITCH_TUNNEL_OID(_ret, _unit, _tunnel_type, _ptr_oid) \
            _CLXS_CREATE_OID(_ret, SAI_OBJECT_TYPE_SWITCH_TUNNEL, _ptr_oid, _unit, _tunnel_type)

#define CLXS_GET_SWITCH_TUNNEL_OID_FIELDS(_ret, _oid, _ptr_unit, _tunnel_type) \
            _CLXS_GET_OID_FIELDS(_ret, SAI_OBJECT_TYPE_SWITCH_TUNNEL, _oid, _ptr_unit,  _tunnel_type)

#endif /* __CLXS_OID_H__ */