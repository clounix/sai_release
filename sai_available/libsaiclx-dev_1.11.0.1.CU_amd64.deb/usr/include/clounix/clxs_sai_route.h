/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_ROUTE_H__)
#define __CLXS_ROUTE_H__


#define CLXS_ROUTE_CB(unit) (_ptr_clxs_route_cb[unit])

#define CLXS_ROUTE_LOCK(unit) \
    osal_takeSemaphore(&_ptr_clxs_route_cb[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_ROUTE_UNLOCK(unit) \
    osal_giveSemaphore(&_ptr_clxs_route_cb[unit]->sema);

#define CLXS_ROUTE_OPER_RECORD_NUM                  (200*1024)         /* max buffer num */
#define CLXS_ROUTE_LOG_POOL_BLOCK_SIZE              (1024)             /* max route info log block size - num of clx_l3_route_info per block */
#define CLXS_ROUTE_LOG_POOL_BLOCK_CNT               (1024)             /* max route info log block cnt - num of pool block */
#define CLXS_ROUTE_OPER_LOG_FILE                    "/var/log/route_oper_log"
#define CLXS_ROUTE_OPER_LOG_JSON                    "/var/log/route_oper.json"


/* Save all routes datas that we can't get from sdk losslessly.*/
typedef struct
{
    uint32_t                    vrf_id;
    sai_ip_prefix_t             prefix;
    uint32_t                    output_type;
    uint32_t                    output_id;
    uint32_t                    group_label;
    uint32_t                    action;
    sai_object_id_t             counter_id;
} CLXS_ROUTE_DB_T;

typedef struct
{
    CMLIB_AVL_HEAD_T            *db;
    CLX_SEMAPHORE_ID_T          sema;
} CLXS_ROUTE_CB_T;

/* action type */
typedef enum
{
    CLXS_ROUTE_OPER_TYPE_SINGLE_ADD = 0,
    CLXS_ROUTE_OPER_TYPE_SINGLE_REMOVE,
    CLXS_ROUTE_OPER_TYPE_SINGLE_SET,
    CLXS_ROUTE_OPER_TYPE_SINGLE_GET,
    CLXS_ROUTE_OPER_TYPE_BULK_ADD,
    CLXS_ROUTE_OPER_TYPE_BULK_REMOVE,
    CLXS_ROUTE_OPER_TYPE_BULK_SET,
    CLXS_ROUTE_OPER_TYPE_BULK_GET,
    CLXS_ROUTE_OPER_TYPE_MAX_NUM
}CLXS_ROUTE_OPER_TYPE_T;

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_route_api_t            route_api;
extern CLXS_ROUTE_CB_T           *_ptr_clxs_route_cb[CLXS_MAX_CHIP_NUM];
extern bool _clxs_route_raw_bulk;

#define CLXS_REGISTER_ROUTE_LOG_NOTIFY_UPDATE(func)   do { clxs_route_log_notify_update[__MODULE__] = func; } while (0)

typedef sai_status_t (*CLXS_ROUTE_LOG_NOTIFY_UPDATE)(
    _In_ uint32_t                    unit,
    _In_ CLXS_ROUTE_OPER_TYPE_T      oper_type,
    _In_ uint32_t                    object_cnt,
    _In_ uint64_t                    start_time,
    _In_ uint64_t                    end_time,
    _In_ uint64_t                    sdk_time,
    _In_ sai_status_t                ret,
    _In_ CLX_L3_ROUTE_INFO_T         *ptr_route_info);

extern CLXS_ROUTE_LOG_NOTIFY_UPDATE clxs_route_log_notify_update[CLXS_API_MAX];

/* API DECLARATIONS
 */
sai_status_t clxs_route_init(
    const uint32_t    unit);

sai_status_t clxs_route_deinit(
    const uint32_t    unit);

bool is_route_directed(CLX_L3_ROUTE_INFO_T * ptr_route_info);

bool clxs_route_check_interface(UI32_T unit, UI32_T vrf_id, sai_ip_prefix_t* prefix, UI32_T intf_id);

sai_status_t clxs_route_match_get(
    _In_ const UI32_T    unit,
    _In_ const UI32_T    vrf_id,
    _In_ sai_ip_address_t   ip_addr,
    _Out_  CLX_L3_ROUTE_INFO_T* route_info);

sai_status_t clxs_route_get_used_route_num(
    _In_ sai_object_id_t switch_id,
    _Out_ uint32_t *count);

sai_status_t
clxs_route_get_available_route_num(
    _In_ sai_object_id_t   switch_id,
    _In_ BOOL_T            is_ipv6,
    _Out_ uint32_t         *count);
uint64_t calculateTimeInterval(
    uint64_t  start_time,
    uint64_t  end_time);

#endif /* __CLXS_ROUTE_H__ */
