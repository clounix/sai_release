/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_QOSMAP_H__)
#define __CLXS_QOSMAP_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define CLXS_QOSMAP_MAX_TC_COUNT             (16)
#define CLXS_QOSMAP_MAX_USER_TC              (7)
#define CLXS_QOSMAP_MIN_USER_TC              (0)
#define CLXS_QOSMAP_MAX_LOSSLESS_QUEUE_NUM   (2)
#define CLXS_QOSMAP_MAX_PFC_COUNT            (8)
#define CLXS_QOSMAP_MAX_DOT1P_COUNT  (8)
#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
#define CLXS_QOSMAP_MAX_EXP_COUNT    (8)    /* 3 bit EXP in MPLS Lable */
#endif
#define CLXS_QOSMAP_MAX_DSCP_COUNT   (64)
#define CLXS_QOSMAP_MAX_COLOR_COUNT  (3)
#define CLXS_QOSMAP_TYPES_MAX        (SAI_QOS_MAP_TYPE_TC_AND_COLOR_TO_MPLS_EXP+5)
/* 0 reserved by SDK */
#define CLXS_QOSMAP_PROFILE_OFFSET   (1)
#define CLXS_QOSMAP_PROFILE_PHB_TYPE_NUM (CLX_QOS_MAPPING_LAST)
#define CLXS_QOSMAP_TO_TC_TYPE(__type__)    (((__type__ == SAI_QOS_MAP_TYPE_DOT1P_TO_TC ) || (__type__ == SAI_QOS_MAP_TYPE_DSCP_TO_TC) || \
                                             (__type__ == SAI_QOS_MAP_TYPE_MPLS_EXP_TO_TC))?1:0)
#define CLXS_QOSMAP_TO_COLOR_TYPE(__type__)    (((__type__ == SAI_QOS_MAP_TYPE_DOT1P_TO_COLOR ) || (__type__ == SAI_QOS_MAP_TYPE_DSCP_TO_COLOR) || \
                                             (__type__ == SAI_QOS_MAP_TYPE_MPLS_EXP_TO_COLOR))?1:0)

#define CLXS_QOSMAP_PORT_CONFIG_BMP_SIZE (CLX_BITMAP_SIZE(CLXS_MAX_PORT_NUM))

typedef struct CLXS_QOSMAP_PROF_DB_S{
    sai_object_id_t         id;
    sai_qos_map_list_t      qosmap;
} CLXS_QOSMAP_PROF_DB_T;

typedef struct CLXS_QOSMAP_PROF_TYPE_S{
    uint32_t     profileId;
    sai_qos_map_type_t     type;
} CLXS_QOSMAP_PROF_TYPE_T;

typedef struct CLXS_QOSMAP_HW_S{
    bool             valid;
    uint32_t         ref_cnt;
    CLXS_QOSMAP_PROF_TYPE_T         sw_profile_1;/* if igr map,sw_profile_1 is to_tc map;if egr map,sw_profile_1 is tc_and_color map */
    CLXS_QOSMAP_PROF_TYPE_T         sw_profile_2;/* if igr map,sw_profile_2 is to_color map;if egr map,sw_profile_2 is 0 */
} CLXS_QOSMAP_HW_T;

typedef struct CLXS_QOSMAP_PORT_PFC_S{
    sai_port_priority_flow_control_mode_t ctrl_mode;
    uint8_t rx_enable;
    uint8_t tx_enable;
    uint8_t map_enable;
} CLXS_QOSMAP_PORT_PFC_T;

typedef struct CLXS_QOSMAP_S{
    bool                    valid;
    CLXS_QOSMAP_PROF_DB_T   clxs_qosmap_entry;
} CLXS_QOSMAP_T;

typedef struct CLXS_QOSMAP_CB_S{
    CLXS_QOSMAP_T *           clxs_qosmap_prof[CLXS_QOSMAP_TYPES_MAX];
    CLXS_QOSMAP_HW_T *        clxs_qosmap_prof_hw[CLXS_QOSMAP_PROFILE_PHB_TYPE_NUM];
    sai_object_id_t*          clxs_qosmap_port_prof_base; //  base of  sai_object_id_t*          clxs_qosmap_port_prof[CLXS_QOSMAP_TYPES_MAX][port];
    uint32_t                  clxs_qosmap_port_config_bmp[CLXS_QOSMAP_TYPES_MAX][CLXS_QOSMAP_PORT_CONFIG_BMP_SIZE];
    sai_object_id_t           clxs_qosmap_switch_prof[CLXS_QOSMAP_TYPES_MAX];
    CLXS_QOSMAP_PORT_PFC_T    clxs_qosmap_port_pfc[CLXS_MAX_PORT_NUM];
    sai_object_id_t*          clxs_qosmap_port_prof[CLXS_QOSMAP_TYPES_MAX];
} CLXS_QOSMAP_CB_T;

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_qos_map_api_t          qosmap_api;
extern CLXS_QOSMAP_CB_T *_clxs_qosmap_cb[CLXS_MAX_CHIP_NUM];
extern C8_T *p_sw_qosmap_type[CLXS_QOSMAP_TYPES_MAX];
extern C8_T *p_hw_qosmap_type[CLX_QOS_MAPPING_LAST];
/* API DECLARATIONS
 */
sai_status_t clxs_qosmap_getPfcControl(
    sai_object_id_t         port_object_id,
    const sai_port_attr_t   attr_id,
    sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setPfcControl(
    sai_object_id_t         port_object_id,
    const sai_port_attr_t       attr_id,
    _In_ uint8_t            pfc_enable);

sai_status_t clxs_qosmap_getPfcControlMode(
    sai_object_id_t         port_object_id,
    sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setPfcControlMode(
    sai_object_id_t         port_object_id,
    const sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_getProfileFromPort(
    sai_object_id_t         port_object_id,
    uint32_t                type,
    sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setProfileToPort(
    sai_object_id_t         port_object_id,
    uint32_t                type,
    sai_object_id_t         profile_object_id);

sai_status_t clxs_qosmap_getProfileFromTunnel(
    _In_ uint32_t        unit,
    _In_ uint32_t        sai_id,
    _In_ sai_qos_map_type_t      type,
    _Out_ sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setProfileToTunnel(
    _In_ uint32_t        unit,
    _In_ uint32_t        sai_id,
    _In_ sai_qos_map_type_t        type,
    _In_ sai_object_id_t        profile_object_id,
    _In_ uint32_t current_hw_profile,
    _Out_ uint32_t *new_hw_profile);

sai_status_t clxs_qosmap_getProfileFromSwitch(
    sai_object_id_t         switch_id,
    uint32_t                type,
    sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setProfileToSwitch(
    sai_object_id_t         switch_id,
    uint32_t                type,
    sai_object_id_t         profile_object_id);

sai_status_t clxs_qosmap_getPfcRxEnable(
    _In_ uint32_t        unit,
    _In_ uint32_t        port,
    _In_ uint32_t        pg_id,
    _Out_ BOOL_T         *rx_enable);

sai_status_t clxs_qosmap_init(
    uint32_t unit);

sai_status_t clxs_qosmap_deinit(
    uint32_t unit);

sai_status_t clxs_get_qos_map_count(_In_ const uint32_t unit, _Out_ uint32_t *count);

sai_status_t _clxs_check_qos_prof_hw(
    _In_ uint32_t    unit,
    _In_ CLX_QOS_MAPPING_TYPE_T    hw_type,
    _In_ uint32_t    qos_prof_id);

sai_status_t _clxs_check_qos_prof(
    _In_ uint32_t    unit,
    _In_ sai_qos_map_type_t    type,
    _In_ uint32_t    qos_prof_id);

sai_status_t clxs_qosmap_checkPortProfile(
    _In_ sai_object_id_t            port_object_id,
    _In_ sai_qos_map_type_t         type,
    _In_ sai_object_id_t            qos_prof_id);

sai_status_t clxs_qosmap_getEgrHwProfileFromPort(
    _In_ sai_object_id_t         port_object_id,
    _In_ sai_qos_map_type_t      type,
    _Out_ uint32_t   *profileId_hw);
#endif /* __CLXS_QOSMAP_H__ */
