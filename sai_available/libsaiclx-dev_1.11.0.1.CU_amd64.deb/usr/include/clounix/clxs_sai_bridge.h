/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_BRIDGE_H__)
#define __CLXS_BRIDGE_H__

#define CLXS_BRIDGE_FLAGS_CREATE_WITH_ID (1 << 0)
#define CLXS_BRIDGE_FLAGS_IS_1Q_BRIDGE   (1 << 1)
#define CLXS_BRIDGE_FDID_1Q_BASE     (1)
#define CLXS_BRIDGE_FDID_1Q_MIN      (CLXS_BRIDGE_FDID_1Q_BASE)
#define CLXS_BRIDGE_FDID_1Q_MAX      (CLXS_BRIDGE_FDID_1Q_BASE + CLXS_BRIDGE_FDID_1Q_NUM - 1)
#define CLXS_BRIDGE_FDID_1D_BASE     (CLXS_BRIDGE_FDID_1Q_MAX + 1)
#define CLXS_BRIDGE_FDID_1D_MIN      (CLXS_BRIDGE_FDID_1D_BASE)
#define CLXS_BRIDGE_FDID_1D_MAX(unit)      (CLXS_BRIDGE_FDID_1D_BASE + CLXS_BRIDGE_FDID_1D_NUM(unit) - 1)
#define CLXS_BRIDGE_FDID_1D_BMP_SIZE(unit) (CLX_BITMAP_SIZE(CLXS_BRIDGE_FDID_1D_NUM(unit)))

#define CLXS_BRIDGE_PORT_BMP_SIZE(__unit__)    (CLX_BITMAP_SIZE(CLXS_MAX_BRIDGE_PORT_NUM(__unit__)))
#define CLXS_BRIDGE_FDID_1Q_NUM      (4095)
#define CLXS_BRIDGE_FDID_1D_NUM(__unit__)      (CLXS_BRIDGE_FDID_NUM(__unit__) - CLXS_BRIDGE_FDID_1Q_NUM)
#define CLXS_BRIDGE_FDID_1Q_BMP_SIZE (CLX_BITMAP_SIZE(CLXS_BRIDGE_FDID_1Q_NUM))

#define CLXS_BRIDGE_CB(__unit__) ptr_clxs_bridge_cb[(__unit__)]
#define CLXS_BRIDGE_LOCK(__unit__)   \
        sai_osal_mutex_lock(ptr_clxs_bridge_cb[(__unit__)]->bd_sema)
#define CLXS_BRIDGE_UNLOCK(__unit__) \
        sai_osal_mutex_unlock(ptr_clxs_bridge_cb[(__unit__)]->bd_sema)
#define CLXS_BRIDGE_FDID_LOCK(__unit__)   \
        sai_osal_mutex_lock(ptr_clxs_bridge_cb[(__unit__)]->fdid_sema)
#define CLXS_BRIDGE_FDID_UNLOCK(__unit__) \
        sai_osal_mutex_unlock(ptr_clxs_bridge_cb[(__unit__)]->fdid_sema)
#define CLXS_BRIDGE_PORT_LOCK(__unit__)   \
        sai_osal_mutex_lock(ptr_clxs_bridge_cb[(__unit__)]->port_sema)
#define CLXS_BRIDGE_PORT_UNLOCK(__unit__) \
        sai_osal_mutex_unlock(ptr_clxs_bridge_cb[(__unit__)]->port_sema)

#define CLXS_BRIDGE_IS_LEGAL_BDID(__unit__,__bdid__) \
        ((__bdid__) >= CLXS_BRIDGE_FDID_1Q_BASE) && ((__bdid__) <= CLXS_BRIDGE_FDID_NUM(__unit__))
#define CLXS_BRIDGE_IS_LEGAL_BD_PORT_ID(__unit__,__bd_port_id__) \
        ((__bd_port_id__) < CLXS_MAX_BRIDGE_PORT_NUM(__unit__))
#define CLXS_BRIDGE_TO_SW_IDX(__bdid__) \
        (((__bdid__) < CLXS_BRIDGE_FDID_1D_BASE) ? 0 : ((__bdid__) - CLXS_BRIDGE_FDID_1D_BASE + 1))
#define INVALID_VALUE               (0xFFFFFFFF)       
typedef struct CLXS_BRIDGE_PORT_ATTR_S
{
    CLX_BRIDGE_DOMAIN_T     bdid;
    CLXS_SRV_LRN_MODE_T      lrn_mode;
    bool    admin;
    bool    igr_filter;
    int32_t tag_mode;
    CLX_STAT_CNT_T      igr_cnt;
    CLX_STAT_CNT_T      egr_cnt;
#if SAI_API_VERSION >= SAI_VERSION(1,4,0)
    sai_object_id_t     isolation_group_oid;
#endif
} CLXS_BRIDGE_PORT_ATTR_T;


typedef struct CLXS_BRIDGE_PORT_INFO_S
{
    sai_bridge_port_type_t    type;
    sai_object_id_t           oid;  /* PORT/LAG/RIF/TNL object */
    uint16_t                  vid;  /* only SUB_PORT use */
} CLXS_BRIDGE_PORT_INFO_T;

typedef struct CLXS_BRIDGE_PORT_NODE_S
{
    CLXS_BRIDGE_PORT_INFO_T  key;
    CLXS_BRIDGE_PORT_ATTR_T  attr;
    sai_object_id_t oid;
    uint32_t idx;
} CLXS_BRIDGE_PORT_NODE_T;

typedef struct CLXS_BRIDGE_ATTR_S
{
    uint32_t            mbr_cnt;
    int32_t             flood_type[CLXS_SRV_BUM_TYPE_LAST]; /* 0 is for bc, 1 is for unknown mc and  2 is for unknown uc */
    uint32_t            flood_all_mgid;   /* flood all mgid, can be shared by uuc,umc and bc */
    uint32_t            flood_none_mgid;   /* flood none mgid, can be shared by uuc,umc and bc  */
    uint32_t            flood_group_mgid[CLXS_SRV_BUM_TYPE_LAST]; /* 0 is for bc, 1 is for unknown mc and  2 is for unknown uc */
    CLX_STAT_CNT_T      igr_cnt;
    CLX_STAT_CNT_T      egr_cnt;
#define CLXS_BRIDGE_ATTR_FLAGS_LRN_EN (1 << 0)
#define CLXS_BRIDGE_ATTR_FLAGS_RIF_EN (1 << 1)
    uint32_t                flags;
} CLXS_BRIDGE_ATTR_T;

typedef struct CLXS_BRIDGE_CB_S
{
    bool                    miss_excpt_drop;
    /* FDID */
    uint32_t                valid_fdid_1q_bmp[CLXS_BRIDGE_FDID_1Q_BMP_SIZE]; /* 1Q_BRIDGE: vlan = fdid */
    uint32_t  *              valid_fdid_1d_bmp; /* 1D_BRIDGE: bdid = fdid */
    CLX_SEMAPHORE_ID_T      fdid_sema;
    /* BRIDGE */
    CLXS_BRIDGE_ATTR_T *      bd_arr;
    CLX_SEMAPHORE_ID_T      bd_sema;
    /* BRIDGE PORT */
    //CLXS_BRIDGE_PHY_PORT_INFO_T  phy_port_arr[CLXS_MAX_PORT_NUM];
    uint32_t *                  valid_bd_port_id_bmp;
    CLXS_BRIDGE_PORT_NODE_T *    port_arr;
    CMLIB_AVL_HEAD_T            *ptr_port_avl;
    CLX_SEMAPHORE_ID_T          port_sema;
} CLXS_BRIDGE_CB_T;

extern const sai_bridge_api_t           bridge_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T bridge_stats_capability_info ;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T bridge_port_stats_capability_info; 
extern CLXS_BRIDGE_CB_T* ptr_clxs_bridge_cb[CLXS_MAX_CHIP_NUM];
/* API DECLARATIONS
 */
sai_status_t
clxs_bridge_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_bridge_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_bridge_createBridgeDomain(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             flags,      /* reference CLXS_BRIDGE_FLAGS_XXX */
    _Inout_ CLX_BRIDGE_DOMAIN_T     *ptr_bdid);

sai_status_t
clxs_bridge_removeBridgeDomain(
    _In_ const uint32_t             unit,
    _In_ const CLX_BRIDGE_DOMAIN_T  bdid);

sai_status_t
clxs_bridge_getBridgeDomainType_loose(
    _In_ const uint32_t        unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_bridge_type_t         *ptr_type);

sai_status_t
clxs_bridge_getBridgeDomainType(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_bridge_type_t         *ptr_type);

sai_status_t
clxs_bridge_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_bdid);

sai_status_t
clxs_bridge_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_bridge_getBdPortIdByObject(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_bd_port_id);

sai_status_t
clxs_bridge_getBdPortIdByInfo(
    _In_ const uint32_t                 unit,
    _In_ const CLXS_BRIDGE_PORT_INFO_T   *ptr_info,
    _Out_ uint32_t                      *ptr_bd_port_id);

sai_status_t
clxs_bridge_getPortInfo(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ CLXS_BRIDGE_PORT_INFO_T    *ptr_info);

sai_status_t
clxs_bridge_getPortObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_bridge_getBdPortBdid(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ uint32_t                  *ptr_bdid);

sai_status_t
clxs_bridge_setFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLXS_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act);
#if 0
sai_status_t
clxs_bridge_setPortMode(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             port, /* native port id */
    _In_ const sai_bridge_port_type_t mode);

sai_status_t
clxs_bridge_getPortMode(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             port, /* native port id */
    _Out_ sai_bridge_port_type_t      *ptr_mode);
#endif
sai_status_t
clxs_bridge_fillServiceFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLXS_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act,
    _In_ const uint32_t             mcast_id,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clxs_bridge_fillServiceLrn(
    _In_ const uint32_t             unit,
    _In_ const bool                 bd_lrn_en,
    _In_ const CLXS_SRV_LRN_MODE_T   mode,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clxs_bridge_fillTnlService(
    _In_ const uint32_t             unit,
    _In_ const sai_object_id_t      tnl_oid,
    _In_ const uint32_t             bdid,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clxs_bridge_createDfltBdPort(
    _Out_  sai_object_id_t *bd_port_oid,
    _In_ const sai_object_id_t          switch_id,
    _In_ const CLXS_BRIDGE_PORT_INFO_T   *ptr_port_info);

sai_status_t
clxs_bridge_updateLagMbr(
    _In_ const uint32_t                 unit,
    _In_ const uint32_t                 bd_port_id,
    _In_ const CLXS_BRIDGE_PORT_INFO_T   *ptr_port_info,
    _In_ const bool                     is_add);

sai_status_t
clxs_get_1q_fdid_count(
    _In_ uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_bridge_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_bridge_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif /* __CLXS_BRIDGE_H__ */
