/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_HASH_H__)
#define __CLXS_HASH_H__

#define CLXS_HASH_NUM              (CLX_SWC_HASH_TYPE_LAST)
#define CLXS_HASH_INFO(__unit__, __id__)    (_clxs_hash_fn[__unit__][__id__])
#define CLXS_HASH_LOCK(__unit__)           osal_takeSemaphore(&_clxs_hash_sema[__unit__], CLX_SEMAPHORE_WAIT_FOREVER)
#define CLXS_HASH_UNLOCK(__unit__)         osal_giveSemaphore(&_clxs_hash_sema[__unit__])
#define CLXS_HASH_FN_VALID(__unit__, __id__)    (_clxs_hash_fn[__unit__][__id__].valid)

#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
#define MAX_SAI_HASH_FIELD            (SAI_NATIVE_HASH_FIELD_NONE)
#elif SAI_API_VERSION >= SAI_VERSION(1,5,0)
#define MAX_SAI_HASH_FIELD            (18)
#else
#define MAX_SAI_HASH_FIELD            (12)
#endif

typedef enum _clxs_sai_hash_type {
    CLXS_HASH_ECMP,
    CLXS_HASH_ECMP_IP4,
    CLXS_HASH_ECMP_IPINIP,
    CLXS_HASH_ECMP_IP6,
    CLXS_HASH_LAG,
    CLXS_HASH_LAG_IP4,
    CLXS_HASH_LAG_IPINIP,
    CLXS_HASH_LAG_IP6,
    CLXS_HASH_TYPE_LAST
} clxs_sai_hash_type_t;

typedef struct CLXS_HASH_FN_S {
    bool                valid;
    bool                field[MAX_SAI_HASH_FIELD];
    bool                type[CLXS_HASH_TYPE_LAST];
} CLXS_HASH_FN_T;

typedef enum
{
    CLXS_HASH_IP_ALL,
    CLXS_HASH_IP4,
    CLXS_HASH_IP6,
    CLXS_HASH_IP_LAST
} CLXS_HASH_IP_TYPE_T;

typedef struct _clxs_hash_type {
    bool                read_only;
    CLX_SWC_HASH_TYPE_T hash_type;
    CLXS_HASH_IP_TYPE_T ip_type;
} clxs_hash_type_t;

extern const sai_hash_api_t             hash_api;
extern CLX_SEMAPHORE_ID_T _clxs_hash_sema[CLXS_MAX_CHIP_NUM];
extern CLXS_HASH_FN_T _clxs_hash_fn[CLXS_MAX_CHIP_NUM][CLXS_HASH_NUM];
extern clxs_hash_type_t _clxs_hash_type_to_sdk[CLXS_HASH_TYPE_LAST];
extern char *_clxs_hash_type_str[CLXS_HASH_TYPE_LAST];
extern sai_object_id_t   _clxs_hash_type_to_idx_map[CLXS_MAX_CHIP_NUM][CLXS_HASH_TYPE_LAST];

sai_status_t
clxs_hash_init(
    _In_ uint32_t               unit);

sai_status_t
clxs_hash_deinit(
    _In_ uint32_t               unit);

sai_status_t
clxs_hash_id_get(
    _In_  sai_object_id_t       switch_id,
    _In_  sai_switch_attr_t     attr,
    _Out_ sai_object_id_t       *ptr_hash_id);

sai_status_t
clxs_hash_id_set(
    _In_ sai_object_id_t        switch_id,
    _In_  sai_switch_attr_t     attr,
    _In_ sai_object_id_t        hash_id);

sai_status_t clxs_get_hash_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

char * _clxs_swc_hash_type_to_str(
    _In_ CLX_SWC_HASH_TYPE_T hash_type);

sai_status_t clxs_hash_update(
    _In_ uint32_t       unit,
    _In_ CLX_SWC_HASH_TYPE_T hash_type);

#endif
