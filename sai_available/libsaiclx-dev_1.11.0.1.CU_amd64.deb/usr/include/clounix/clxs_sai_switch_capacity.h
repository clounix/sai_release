/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_SWITCH_CAPACITY_H__)
#define __CLXS_SWITCH_CAPACITY_H__

#define CLXS_MAX_PORT_MTU(__unit__)        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->port.max_port_mtu) :0)

//#define CLXS_MAX_PORT_MTU(__unit__)                (if(CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->port.max_port_mtu : 0)
#define CLXS_CPU_PORT(__unit__)                        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->port.cpu_port_num):0)
#define CLXS_MAX_LAG_NUM(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->lag.max_lag_num):0)
#define CLXS_MAX_PORT_NUM_PER_LAG(__unit__)        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->lag.max_port_num_per_lag):0)
#define CLXS_MAX_WRED_PROFILE_NUM(__unit__)        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->wred.max_wred_profile_num):0)
#define CLXS_MAX_STP_NUM(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.max_stp_num):0)
#define CLXS_MAX_BRIDGE_PORT_NUM(__unit__)         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->bridge.max_bridge_port_num):0)
#define CLXS_MAX_NEIGHBOR_NUM(__unit__)            ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->neighbor.max_neighbor_num):0)
#define CLXS_MAX_NEXTHOP_NUM(__unit__)           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->nexthop.max_nexthop_num):0)
#define CLXS_MAX_ROUTE_NUM(__unit__)              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->route.max_route_num):0)
#define CLXS_MAX_ECMP_PATH_NUM(__unit__)           ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->nexthopgroup.max_ecmp_path_num):0)
#define CLXS_MAX_ECMP_GROUP_NUM(__unit__)          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->nexthopgroup.max_ecmp_group_num):0)
#define CLXS_MAX_QOSMAP_PROFILE_NUM(__unit__)      ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->qos.max_profile_num):0)

#define CLXS_MAX_SAMPLEPKT_PROFILE_NUM(__unit__)     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->samplepkt.max_samplepkt_profile_num ):0)
#define CLXS_MAX_RPFGRP_NUM(__unit__)   ( (CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rpfgroup.max_rpfgroup_num):0)
#define CLXS_MAX_RPFGRP_MEMBER(__unit__)   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rpfgroup.max_rpfgroup_member_num):0)

#define CLXS_BRIDGE_FDID_NUM(__unit__)         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->bridge.max_fdid_num):0)
#define SAI_DFLT_CFG_PKT_RX_GPD_NUM(__unit__)        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->hostif.dflt_cfg_pkt_rx_gpd_num):0)
#define SAI_CPU_PORT_RX_CHANNEL_NUM(__unit__)        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->hostif.cpu_port_rx_channel_num):0)

#define CLXS_BUF_CELL_BYTE_SIZE(__unit__)      ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.cell_byte_size):0)
#define CLXS_BUF_IOS_CELL_SIZE(__unit__)       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.ios_cell_size):130)
#define CLXS_BUF_ING_POOL_SIZE(__unit__)        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.ingress_pool_size):0)
#define CLXS_BUF_EGR_POOL_SIZE(__unit__)       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->buffer.egress_pool_size):0)

#define CLXS_MAX_NUM_OF_IGR_MIR_SES(__unit__)  ( (CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->mirror.max_igr_session_num):0)
#define CLXS_MAX_NUM_OF_EGR_MIR_SES(__unit__)  ( (CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->mirror.max_igr_session_num):0)
#define CLXS_MAX_NUM_OF_MIR_SES(__unit__)      (CLXS_MAX_NUM_OF_IGR_MIR_SES(__unit__) + CLXS_MAX_NUM_OF_EGR_MIR_SES(__unit__))

#define CLXS_RSV_STP_ALL_DROP(__unit__)       ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.rsv_stp_drop):0)
#define CLXS_RSV_STP_ALL_FWD(__unit__)         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.rsv_stp_fwd):0)
#define CLXS_RSV_STP_ALL_LRN(__unit__)         ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->stp.rsv_stp_lrn):0)

#define CLXS_ACL_TABLE_NUM_IGR(__unit__)                          ( (CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.igr_acl_table_num):0)
#define CLXS_ACL_TABLE_NUM_EGR(__unit__)                          ( (CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.egr_acl_table_num):0)
#define CLXS_ACL_ENTRY_NUM_IGR(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.igr_acl_entry_num):0)
#define CLXS_ACL_ENTRY_NUM_EGR(__unit__)                          ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->acl.egr_acl_entry_num):0)

#define CLXS_NUM_RIF(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.max_rif_num):0)
#define CLXS_NUM_RTE(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.max_rte_mac_num):0)
#define CLXS_NUM_TNL_RTE(__unit__)                 ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.max_tnl_rte_mac_num):0)

#define CLXS_UDF_MATCH_MAX_NUM(__unit__)      ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->udf.max_udf_match_num):0)
#define CLXS_UDF_GROUP_CAPACITY(__unit__)      ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->udf.udf_group_capacity):0)

#define CLXS_RIF_MODE(__unit__)                     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.resource_mode):0)
#define CLXS_NUM_NVO3_INTF_ID(__unit__)             ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.nvo3_rif_max_num):0)
#define CLXS_NUM_NVO3_RTE_MAC(__unit__)             ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->rif.nvo3_rte_mac_num):0)
#define CLXS_MAX_VRF_NUM(__unit__)    ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->vrf.max_vrf_num):0)

#define CLXS_QUEUE_UC_NUM(__unit__)                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.uc_queue_num):0)
#define CLXS_QUEUE_MC_NUM(__unit__)                ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.mc_queue_num):0)
#define CLXS_QUEUE_LEGACY_NUM(__unit__)            ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.legacy_queue_num):0)
#define CLXS_QUEUE_CPU_NUM(__unit__)              ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->queue.cpu_queue_num):0)

#define CLXS_SCH_GRP_MAX_NUM_LEVEL_0(__unit__)     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_node_num_level0:0)
#define CLXS_SCH_GRP_MAX_NUM_LEVEL_1(__unit__)     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_node_num_level1:0)
#define CLXS_SCH_GRP_MAX_NUM_LEVEL_2(__unit__)     ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_node_num_level2:0)
#define CLXS_SCH_GRP_MAX_CHILD_LEVEL_0(__unit__)   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_child_num_level0:0)
#define CLXS_SCH_GRP_MAX_CHILD_LEVEL_1(__unit__)   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_child_num_level1:0)
#define CLXS_SCH_GRP_MAX_CHILD_LEVEL_2(__unit__)   ((CLXS_CHIP_SPEC(__unit__)!=NULL)?CLXS_CHIP_SPEC(__unit__)->schedulergroup.max_child_num_level2:0)

#define CLXS_MAX_TUNNEL_NUM(__unit__)        ((CLXS_CHIP_SPEC(__unit__)!=NULL)?(CLXS_CHIP_SPEC(__unit__)->tunnel.max_tunnel_num) :0)

typedef struct _CLXS_CHIP_SPEC_ACL_T
{
    uint32_t igr_acl_table_num;
    uint32_t egr_acl_table_num;
    uint32_t igr_acl_entry_num;
    uint32_t egr_acl_entry_num;
    uint32_t udf_profile_num;
    uint32_t acl_range_num;

    uint32_t user_meta_port_min;
    uint32_t user_meta_port_max;
    uint32_t user_meta_port_offset;

    uint32_t acl_internal_meta_min;
    uint32_t acl_internal_meta_max;
    uint32_t user_meta_fdb_min;
    uint32_t user_meta_fdb_max;
    uint32_t user_meta_route_dst_min;
    uint32_t user_meta_route_dst_max;
    uint32_t user_meta_neighbor_dst_min;
    uint32_t user_meta_neighbor_dst_max;

} CLXS_CHIP_SPEC_ACL_T;

typedef struct _CLXS_CHIP_SPEC_UDF_T
{
    uint32_t udf_group_capacity;
    uint32_t max_udf_match_num;
    uint32_t max_udf_offset;
} CLXS_CHIP_SPEC_UDF_T;

typedef struct _CLXS_CHIP_SPEC_BUFFER_T
{
    uint32_t cell_byte_size;
    uint32_t ios_cell_size;

    /*below:suggested default value */
    uint32_t num_ingress_pools;
    uint32_t num_egress_pools;
    uint32_t ingress_pool_size;
    uint32_t egress_pool_size;

    uint32_t ing_max_dynamic_th;
    uint32_t egr_max_dynamic_th;
    uint32_t hys_gap;
    uint32_t min_sys_buffer_headroom;
} CLXS_CHIP_SPEC_BUFFER_T;

typedef struct _CLXS_CHIP_SPEC_QOS_T
{
    uint32_t max_profile_num;
} CLXS_CHIP_SPEC_QOS_T;

typedef struct _CLXS_CHIP_SPEC_QUEUE_T
{
    uint32_t cpu_queue_num;
    uint32_t uc_queue_num;
    uint32_t mc_queue_num;
    uint32_t legacy_queue_num;
} CLXS_CHIP_SPEC_QUEUE_T;

typedef struct _CLXS_CHIP_SPEC_SCHGRP_T
{
    uint32_t max_sch_levels;
    uint32_t max_node_num_level0;
    uint32_t max_node_num_level1;
    uint32_t max_node_num_level2;
    uint32_t max_child_num_level0;
    uint32_t max_child_num_level1;
    uint32_t max_child_num_level2;
    uint32_t max_sch_num;

} CLXS_CHIP_SPEC_SCHGRP_T;

typedef struct _CLXS_CHIP_SPEC_WRED_T
{
    uint32_t max_wred_profile_num;
    uint32_t min_wred_th;
    uint32_t max_wred_th;

    uint32_t min_wred_th_g;
    uint32_t max_wred_th_g;
    uint32_t min_wred_th_y;
    uint32_t max_wred_th_y;
    uint32_t min_wred_th_r;
    uint32_t max_wred_th_r;
} CLXS_CHIP_SPEC_WRED_T;

typedef struct _CLXS_CHIP_SPEC_IPMC_T
{
    uint32_t max_ipmc_num;
} CLXS_CHIP_SPEC_IPMC_T;

typedef struct _CLXS_CHIP_SPEC_LAG_T
{
    uint32_t max_lag_num;
    uint32_t max_port_num_per_lag;
} CLXS_CHIP_SPEC_LAG_T;

typedef struct _CLXS_CHIP_SPEC_PORT_T
{
    uint32_t max_port_lanes_num;
    uint32_t cpu_port_num;
    uint32_t max_port_mtu;

} CLXS_CHIP_SPEC_PORT_T;

typedef struct _CLXS_CHIP_SPEC_TUNNEL_T
{
    uint32_t max_tunnel_num;
} CLXS_CHIP_SPEC_TUNNEL_T;

typedef struct _CLXS_CHIP_SPEC_NEXTHOPGROUP_T
{
    uint32_t max_ecmp_group_num;
    uint32_t max_ecmp_path_num;

} CLXS_CHIP_SPEC_NEXTHOPGROUP_T;

typedef struct _CLXS_CHIP_SPEC_NEIGHBOR_T
{
    uint32_t max_neighbor_num;
} CLXS_CHIP_SPEC_NEIGHBOR_T;

typedef struct _CLXS_CHIP_SPEC_NEXTHOP_T
{
    uint32_t max_nexthop_num;
} CLXS_CHIP_SPEC_NEXTHOP_T;

typedef struct _CLXS_CHIP_SPEC_ROUTE_T
{
    uint32_t max_route_num;
} CLXS_CHIP_SPEC_ROUTE_T;

typedef struct _CLXS_CHIP_SPEC_ROUTEINTERFACE_T
{
    uint32_t resource_mode;
    uint32_t max_rif_num;
    uint32_t max_rte_mac_num;
    uint32_t max_tnl_rte_mac_num;
    uint32_t nvo3_rif_max_num;
    uint32_t nvo3_rte_mac_num;
} CLXS_CHIP_SPEC_ROUTEINTERFACE_T;

typedef struct _CLXS_CHIP_SPEC_VIRTUALROUTER_T
{
    uint32_t max_vrf_num;
} CLXS_CHIP_SPEC_VIRTUALROUTER_T;

typedef struct _CLXS_CHIP_SPEC_BRIDGE_T
{
    uint32_t max_fdid_num;
    uint32_t max_bridge_port_num;
} CLXS_CHIP_SPEC_BRIDGE_T;

typedef struct _CLXS_CHIP_SPEC_FDB_T
{
    uint32_t max_fdb_num;
} CLXS_CHIP_SPEC_FDB_T;

typedef struct _CLXS_CHIP_SPEC_L2MC_T
{
    uint32_t max_l2mc_num;
} CLXS_CHIP_SPEC_L2MC_T;

typedef struct _CLXS_CHIP_SPEC_MIRROR_T
{
    uint32_t max_igr_session_num;
    uint32_t max_egr_session_num;
} CLXS_CHIP_SPEC_MIRROR_T;

typedef struct _CLXS_CHIP_SPEC_STP_T
{
    uint32_t max_stp_num;
    uint32_t rsv_stp_drop;
    uint32_t rsv_stp_fwd;
    uint32_t rsv_stp_lrn;
} CLXS_CHIP_SPEC_STP_T;

typedef struct _CLXS_CHIP_SPEC_ISOLATIONGRP_T
{
    uint32_t max_isolation_group_num;
} CLXS_CHIP_SPEC_ISOLATIONGRP_T;

typedef struct _CLXS_CHIP_SPEC_POLICER_T
{
    uint32_t max_meterid_num;
} CLXS_CHIP_SPEC_POLICER_T;

typedef struct _CLXS_CHIP_SPEC_RPFGROUP_T
{
    uint32_t max_rpfgroup_num;
    uint32_t max_rpfgroup_member_num;
} CLXS_CHIP_SPEC_RPFGROUP_T;

typedef struct _CLXS_CHIP_SPEC_SAMPLEPKT_T
{
    uint32_t max_samplepkt_profile_num;
} CLXS_CHIP_SPEC_SAMPLEPKT_T;


typedef struct _CLXS_CHIP_SPEC_HOSTIF_T
{
    uint32_t dflt_cfg_pkt_rx_gpd_num;
    uint32_t cpu_port_rx_channel_num;
} CLXS_CHIP_SPEC_HOSTIF_T;


typedef struct _CLXS_CHIP_SPEC_T
{
    CLXS_CHIP_SPEC_BUFFER_T               buffer;
    CLXS_CHIP_SPEC_QUEUE_T                 queue;
    CLXS_CHIP_SPEC_ACL_T                      acl;
    CLXS_CHIP_SPEC_UDF_T                      udf;
    CLXS_CHIP_SPEC_QOS_T                      qos;
    CLXS_CHIP_SPEC_SCHGRP_T               schedulergroup;
    CLXS_CHIP_SPEC_WRED_T                   wred;
    CLXS_CHIP_SPEC_POLICER_T           policer;
    CLXS_CHIP_SPEC_IPMC_T                    ipmc;
    CLXS_CHIP_SPEC_LAG_T                      lag;
    CLXS_CHIP_SPEC_PORT_T                   port;
    CLXS_CHIP_SPEC_TUNNEL_T               tunnel;
    CLXS_CHIP_SPEC_NEXTHOPGROUP_T        nexthopgroup;
    CLXS_CHIP_SPEC_NEIGHBOR_T         neighbor;
    CLXS_CHIP_SPEC_NEXTHOP_T           nexthop;
    CLXS_CHIP_SPEC_ROUTE_T                route;
    CLXS_CHIP_SPEC_ROUTEINTERFACE_T      rif;
    CLXS_CHIP_SPEC_VIRTUALROUTER_T        vrf;
    CLXS_CHIP_SPEC_BRIDGE_T                        bridge;
    CLXS_CHIP_SPEC_FDB_T                            fdb;
    CLXS_CHIP_SPEC_L2MC_T                       l2mc;
    CLXS_CHIP_SPEC_MIRROR_T                  mirror;
    CLXS_CHIP_SPEC_STP_T                       stp;
    CLXS_CHIP_SPEC_ISOLATIONGRP_T       isolationgrp;
    CLXS_CHIP_SPEC_RPFGROUP_T           rpfgroup;
    CLXS_CHIP_SPEC_SAMPLEPKT_T        samplepkt;
    CLXS_CHIP_SPEC_HOSTIF_T           hostif;

} CLXS_CHIP_SPEC_T;


extern CLXS_CHIP_SPEC_T * _clxs_chip_spec[CLXS_MAX_CHIP_NUM];

#define CLXS_CHIP_SPEC(__unit__)                (((__unit__< CLXS_MAX_CHIP_NUM)&&(_clxs_chip_spec[__unit__] != NULL))?(CLXS_CHIP_SPEC_T *)(_clxs_chip_spec[__unit__]):NULL)

#endif /* __CLXS_SWITCH_CAPACITY_H__ */