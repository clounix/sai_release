/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_STP_H__)
#define __CLXS_STP_H__
#define CLXS_STP_LOCK(__unit__)   \
        sai_osal_mutex_lock(ptr_clxs_stp_sema[(__unit__)])
#define CLXS_STP_UNLOCK(__unit__) \
        sai_osal_mutex_unlock(ptr_clxs_stp_sema[(__unit__)])
#define CLXS_STP_CB(__unit__) ptr_clxs_stp_cb[(__unit__)]
#define CLXS_STP_BMP_SIZE(__unit__)        (CLX_BITMAP_SIZE(CLXS_MAX_STP_NUM(__unit__)))

typedef struct CLXS_STP_COOKIE_S
{
    uint32_t            unit;
    uint32_t            stpid;
    uint32_t            mbr_cnt;
    uint32_t            *count;
    sai_object_id_t     **pptr_oid;
} CLXS_STP_COOKIE_T;

typedef struct CLXS_STP_PORT_NODE_S
{
    uint32_t            stpid;      /* KEY */
    uint32_t            bd_port_id; /* KEY */
    CLX_STP_PORTSTATE_T state;
} CLXS_STP_PORT_NODE_T;

typedef struct CLXS_STP_INFO_S
{
    uint32_t            vlan_bmp[CLXS_VLAN_BMP_SIZE]; /* 1Q-Domain */
    uint32_t            bdid;                            /* 1D-Domain */
    uint32_t            mbr_cnt;
} CLXS_STP_INFO_T;

typedef struct CLXS_STP_CB_S
{
    /* STP */
    uint32_t  *          valid_stp_bmp;
    CLXS_STP_INFO_T *     stp_arr;
    /* STP_PORT */
    CMLIB_AVL_HEAD_T    *ptr_port_avl;
} CLXS_STP_CB_T;

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_stp_api_t              stp_api;
extern CLX_SEMAPHORE_ID_T ptr_clxs_stp_sema[CLXS_MAX_CHIP_NUM];
extern CLXS_STP_CB_T* ptr_clxs_stp_cb[CLXS_MAX_CHIP_NUM];

/* API DECLARATIONS
 */
sai_status_t
clxs_stp_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_stp_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_stp_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_stpid);

sai_status_t
clxs_stp_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_stp_getPortInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_stpid,
    _Out_ uint32_t                  *ptr_bd_port_id);

sai_status_t
clxs_stp_getPortObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             bd_port_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_stp_updateStpVlan(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             vid,
    _In_ const bool                 is_add);

sai_status_t
clxs_stp_updateStpBdid(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             bd_port_id,
    _In_ const uint32_t             bdid);

sai_status_t
clxs_get_stp_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_stp_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif /* __CLXS_STP_H__ */
