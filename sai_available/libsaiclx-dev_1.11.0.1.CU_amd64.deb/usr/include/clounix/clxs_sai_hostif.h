/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_HOSTIF_H__)
#define __CLXS_HOSTIF_H__
#define CLXS_HOSTIF_MAX_REASON_PER_TRAP                      (10)
#define CLXS_HOSTIF_TRAPS_NUM                                 CLXS_HOSTIF_REGULAR_TRAP_SUPPORTED_NUM  /* hosif_trap */

#define CLXS_HOSTIF_MAX_NUM_OF_HIF  (512)
#define CLXS_HOSTIF_MAX_NUM_OF_HIF_TABLE                     (4096)  /* hostif_table_entry */
#define CLXS_HOSTIF_MAX_TRAP_GROUPS (48)
#define CLXS_HOSTIF_REGULAR_TRAP_SUPPORTED_NUM               (32)    /* hostif_trap */
#define CLXS_HOSTIF_UDF_TRAP_SUPPORTED_NUM       (4)
#define CLXS_HOSTIF_UDF_TRAPS_NUM                   CLXS_HOSTIF_UDF_TRAP_SUPPORTED_NUM    /* hosif_user_defined_trap */

#define CLXS_HOSTIF_TRAPS_SUPPORTED_BY_ACL_NUM          (64)
#define CLXS_HOSTIF_MAX_C2C_ENTRY_PER_TRAP                      (5)

#define CLXS_HOSTIF_LOCK(__unit__) \
    osal_takeSemaphore(&_ptr_clxs_hostif_cb[__unit__]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_HOSTIF_UNLOCK(__unit__) \
    osal_giveSemaphore(&_ptr_clxs_hostif_cb[__unit__]->sema);

#define CLXS_HOSTIF_TABLE_LOCK(__unit__) \
    osal_takeSemaphore(&_ptr_clxs_hostif_table_cb[__unit__]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_HOSTIF_TABLE_UNLOCK(__unit__) \
    osal_giveSemaphore(&_ptr_clxs_hostif_table_cb[__unit__]->sema);

#define CLXS_HOSTIF_TRAP_LOCK(__unit__) \
    osal_takeSemaphore(&_ptr_clxs_hostif_trap_cb[__unit__]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_HOSTIF_TRAP_UNLOCK(__unit__) \
    osal_giveSemaphore(&_ptr_clxs_hostif_trap_cb[__unit__]->sema);

/*
CPU_PORT DEFAULT QUEUE RX rate, current precision is a multiple of 64,
refer to /etc/sonic/copp_cfg.json from customer system, set default queue cir:1000, cbs:1200
*/
#define CLXS_CPU_RX_PACKET_DEFAULT_QUEUE_RATE_SZ        (1024)
#define CLXS_CPU_RX_PACKET_DEFAULT_QUEUE_BURST_SZ       (CLXS_CPU_RX_PACKET_DEFAULT_QUEUE_RATE_SZ * 120 / 100)

/*CPU RX rate*/
#define CLXS_CPU_RX_PACKET_DEFAULT_RATE_SZ        (20000)
#define CLXS_CPU_RX_PACKET_DEFAULT_BURST_SZ       (5000)

typedef enum
{
    CLXS_HOSTIF_TRAP_CPU_QUEUE_DEFAULT,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_0,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_1,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_2,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_3,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_4,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_5,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_6,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_7,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_8,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_9,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_10,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_11,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_12,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_USR_DEFINE_13,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_SAMPLER,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_TTL_ERR,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_FDB,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_0,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_1,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_2,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_3,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_4,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_5,
    CLXS_HOSTIF_USER_DEFINED_TRAP_CPU_QUEUE_L3,
    CLXS_HOSTIF_USER_DEFINED_TRAP_CPU_QUEUE_ACL,
    CLXS_HOSTIF_USER_DEFINED_TRAP_CPU_QUEUE_FDB,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_0,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_1,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_2,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_3,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_4,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_5,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_6,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_7,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_8,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_9,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_10,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_11,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_12,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_13,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_14,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_15,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_TRAP_16,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_LAST
} CLXS_HOSTIF_TRAP_CPU_QUEUE_T;

typedef struct
{
    sai_hostif_type_t           type;                       /* SAI_HOSTIF_ATTR_TYPE         */
    sai_object_id_t             obj_id;                     /* SAI_HOSTIF_ATTR_OBJ_ID       */
    char                        name[SAI_HOSTIF_NAME_SIZE]; /* SAI_HOSTIF_ATTR_NAME         */
    char                        mcgrp_name[SAI_HOSTIF_NAME_SIZE]; /* SAI_HOSTIF_ATTR_GENETLINK_MCGRP_NAME */
    bool                        valid;                      /* interface entry valid or not */
    sai_uint32_t                queue;                      /* SAI_HOSTIF_ATTR_QUEUE        */
    sai_hostif_vlan_tag_t       vlan_tag;                   /* SAI_HOSTIF_ATTR_VLAN_TAG     */
    uint32_t                    vid;                        /* port default vid */
    uint32_t                    netif_id;                   /* clxssai-metadata */
    bool                        status;                     /* SAI_HOSTIF_ATTR_OPER_STATUS  */
    sai_mac_t                   mac;                        /* switch mac */
} CLXS_HOSTIF_DB_T;

typedef struct
{
    sai_hostif_table_entry_type_t         type;         /* SAI_HOSTIF_TABLE_ENTRY_ATTR_TYPE         */
    sai_object_id_t                       obj_id;       /* SAI_HOSTIF_TABLE_ENTRY_ATTR_OBJ_ID       */
    sai_object_id_t                       trap_id;      /* SAI_HOSTIF_TABLE_ENTRY_ATTR_TRAP_ID      */
    sai_hostif_table_entry_channel_type_t channel_type; /* SAI_HOSTIF_TABLE_ENTRY_ATTR_CHANNEL_TYPE */
    sai_object_id_t                       hostif_id;    /* SAI_HOSTIF_TABLE_ENTRY_ATTR_HOST_IF      */
    bool                                  valid;
    uint32_t                              profile_id;   /* clxssai-metadata */

} CLXS_HOSTIF_TABLE_DB_T;

typedef struct
{
    bool                        valid;          /* SAI_HOSTIF_TRAP_GROUP_ATTR_ADMIN_STATE */
    sai_uint32_t                queue;          /* SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE       */
    sai_object_id_t             policer_id;     /* SAI_HOSTIF_TRAP_GROUP_ATTR_POLICER     */
    uint32_t                    priority;
    uint32_t                    trap_group_id;

} CLXS_HOSTIF_TRAP_GROUP_DB_T;

#define CLXS_HOSTIF_TRAP_FLAGS_DEFAULT_TO_CPU           (1 << 0)
#define CLXS_HOSTIF_TRAP_FLAGS_RATELIMIT_BY_QUEUE       (1 << 1)
#define CLXS_HOSTIF_TRAP_FLAGS_TO_CPU_BY_ACL            (1 << 2)
#define CLXS_HOSTIF_TRAP_FLAGS_TO_CPU_BY_CTL2CPU        (1 << 3)
#define CLXS_HOSTIF_TRAP_FLAGS_TO_CPU_BY_OTHERS         (1 << 4)
#define CLXS_HOSTIF_TRAP_FALGS_CTL2CPU_BY_PROXY         (1 << 5)

typedef struct
{
    bool    valid;
    uint32_t            flags;
    sai_hostif_trap_type_t      trap_type;      /* SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE     */
    sai_packet_action_t         action;         /* SAI_HOSTIF_TRAP_ATTR_PACKET_ACTION */
    uint32_t                    trap_group_id;  /* SAI_HOSTIF_TRAP_ATTR_TRAP_GROUP    */
    uint32_t                    priority;
    uint32_t                    cpu_queue;      /* cpu_queue mapping with trap_cpu_reason_code */
    uint32_t                    trap_cpu_reason_code[CLXS_HOSTIF_MAX_REASON_PER_TRAP];
    uint32_t                    copy_cpu_reason_code[CLXS_HOSTIF_MAX_REASON_PER_TRAP];
    sai_object_id_t             counter_id;
} CLXS_HOSTIF_TRAP_DB_T;

typedef struct
{
    sai_hostif_trap_type_t      trap_type;      /* SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE     */
    uint32_t                    trap_group_id;  /* SAI_HOSTIF_TRAP_ATTR_TRAP_GROUP    */
    uint32_t                    cpu_queue;
    uint32_t                    cpu_reason_code[CLXS_HOSTIF_MAX_REASON_PER_TRAP];

} CLXS_HOSTIF_UDF_TRAP_DB_T;

typedef struct
{
    sai_hostif_trap_type_t          trap_type;      /* SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE     */
    CLX_PKT_CTRL_TO_CPU_ENTRY_T     entry;
    bool                    entry_valid;
    uint32_t                        entry_id;
} CLXS_HOSTIF_CTRL2CPU_CFG_T;

typedef enum
{
    CLXS_HOSTIF_TRAP_INT_TRAP_TYPE_IPV4_LOCAL_LINK = SAI_HOSTIF_TRAP_TYPE_LOCAL_IP_CUSTOM_RANGE_BASE,
    CLXS_HOSTIF_TRAP_INT_TRAP_TYPE_IPV6_LOCAL_LINK,
    CLXS_HOSTIF_TRAP_INT_TRAP_TYPE_IPV6_IP2ME,
    CLXS_HOSTIF_TRAP_INT_TRAP_TYPE_LAST

} CLXS_HOSTIF_TRAP_INT_TRAP_TYPE_T;

typedef enum
{
    CLXS_HOSTIF_TRAP_LACP_CTRL2CPU_ENTRY_ID,
    CLXS_HOSTIF_TRAP_ARP_REQUEST_CTRL2CPU_ENTRY_ID,
    CLXS_HOSTIF_TRAP_ARP_RESPONSE_CTRL2CPU_ENTRY_ID,
    CLXS_HOSTIF_TRAP_IPV6_ND_RS_CTRL2CPU_ENTRY_ID,  /*RS 133*/
    CLXS_HOSTIF_TRAP_IPV6_ND_RA_CTRL2CPU_ENTRY_ID,  /*RA 134*/
    CLXS_HOSTIF_TRAP_IPV6_ND_NS_CTRL2CPU_ENTRY_ID,  /*NS 135*/
    CLXS_HOSTIF_TRAP_IPV6_ND_NA_CTRL2CPU_ENTRY_ID,  /*NA 136*/
    CLXS_HOSTIF_TRAP_IPV6_ND_REDIRECT_CTRL2CPU_ENTRY_ID,    /*REDIRECT 137*/
    CLXS_HOSTIF_TRAP_PVRST_CTRL2CPU_ENTRY_ID,
    CLXS_HOSTIF_TRAPS_SUPPORTED_BY_CTRL2CPU_NUM
} CLXS_HOSTIF_TRAP_CTRL2CPU_ENTRY_ID_T;


/* ------------------------------------------------------------------------ data-type: hostif,
                                                                                       hostif_table_entry */
typedef struct
{
    CLXS_HOSTIF_DB_T            db[CLXS_HOSTIF_MAX_NUM_OF_HIF];
    CLX_SEMAPHORE_ID_T          sema;
} CLXS_HOSTIF_CB_T;

typedef struct
{
    CLXS_HOSTIF_TABLE_DB_T       db[CLXS_HOSTIF_MAX_NUM_OF_HIF_TABLE];
    CLX_SEMAPHORE_ID_T          sema;

} CLXS_HOSTIF_TABLE_CB_T;

/* ------------------------------------------------------------------------ data-type: hostif_trap_group,
                                                                                       hostif_trap,
                                                                                       hostif_udf_trap */
typedef struct
{
    sai_hostif_trap_type_t      trap_type;      /* SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE     */

    /* Default value for HW, will be updated later when user set the trap */
    CLX_ACL_CLASSIFY_T          key;
    CLX_ACL_ACTION_T            act;
    UI32_T                      dbg_srv_counter_id; /* for sai hostif debug*/

    /* Assigned after successfully allocating an entry from ACL */
    bool                        entry_valid;
    uint32_t                    entry_id;

} CLXS_HOSTIF_ACL_CFG_T;

typedef struct
{
    CLXS_HOSTIF_TRAP_GROUP_DB_T  group_db[CLXS_HOSTIF_MAX_TRAP_GROUPS];
    CLXS_HOSTIF_TRAP_DB_T        trap_db[CLXS_HOSTIF_TRAPS_NUM];
    CLXS_HOSTIF_UDF_TRAP_DB_T    udf_trap_db[CLXS_HOSTIF_UDF_TRAPS_NUM];
    CLXS_HOSTIF_ACL_CFG_T        acl_trap_cfg[CLXS_HOSTIF_TRAPS_SUPPORTED_BY_ACL_NUM];
    CLXS_HOSTIF_CTRL2CPU_CFG_T   ctrl2cpu_trap_cfg[CLXS_HOSTIF_TRAPS_SUPPORTED_BY_CTRL2CPU_NUM];
    uint32_t                    default_trap_group;
    CLX_SEMAPHORE_ID_T          sema;
    UI32_T                      acl_group_id;
    CLX_ACL_GROUP_PROFILE_T     acl_group_profile;
    uint32_t                    default_meter_id;
} CLXS_HOSTIF_TRAP_CB_T;

typedef struct
{
    UI64_T forward_pkts;
    UI64_T dropped_pkts;
    UI64_T dropped_byts;
}CLXS_HOSTIF_STATS_T;

extern const sai_hostif_api_t           hostif_api;
extern const CLXS_HOSTIF_TRAP_DB_T   _clxs_hostif_traps[CLXS_HOSTIF_TRAPS_NUM];
extern const CLXS_HOSTIF_UDF_TRAP_DB_T   _clxs_hostif_udf_traps[CLXS_HOSTIF_UDF_TRAPS_NUM];
extern CLXS_HOSTIF_CTRL2CPU_CFG_T  _clxs_hostif_ctrl2cpu_cfg[CLXS_HOSTIF_TRAPS_SUPPORTED_BY_CTRL2CPU_NUM];

extern CLXS_HOSTIF_CB_T              *_ptr_clxs_hostif_cb[CLXS_MAX_CHIP_NUM];
extern CLXS_HOSTIF_TABLE_CB_T        *_ptr_clxs_hostif_table_cb[CLXS_MAX_CHIP_NUM];
extern CLXS_HOSTIF_TRAP_CB_T         *_ptr_clxs_hostif_trap_cb[CLXS_MAX_CHIP_NUM];


sai_status_t
clxs_hostif_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_hostif_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_hostif_getDefaultTrapGroupOid(
    _In_ const uint32_t         unit,
    _Out_ sai_object_id_t       *ptr_trap_group_oid);

sai_status_t clxs_get_hostif_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_trap_group_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_trap_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_table_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

void clxs_hostif_arp_nd_action_modify(
    _In_ uint32_t unit,
    _In_ bool modify_en,
    _In_ bool is_arp);

sai_status_t
clxs_hostif_setNetIfSampleRate(
    _In_ const sai_object_id_t      obj_id,
    _In_ const bool                 is_ingress,
    _In_ const uint32_t             sample_rate);

CLXS_HOSTIF_DB_T *
_clxs_hostif_getEntry(
    _In_ uint32_t           unit,
    _In_ uint32_t           clxs_hif_id);

CLXS_HOSTIF_TABLE_DB_T *
_clxs_hostif_table_getEntry(
    _In_ uint32_t           unit,
    _In_ uint32_t           clxs_hif_table_id);

uint32_t
_clxs_hostif_trap_getAclEntryCfg(
    const uint32_t          unit,
    const uint32_t          trap_type,
    CLXS_HOSTIF_ACL_CFG_T    *pptr_acl_cfg[CLXS_HOSTIF_MAX_ACL_ENTRY_PER_TRAP]);

uint32_t
_clxs_hostif_trap_getCtrl2cpuEntryCfg(
    _In_ const uint32_t	        unit,
    _In_ const uint32_t	        trap_type,
    _Out_ CLXS_HOSTIF_CTRL2CPU_CFG_T *pptr_c2c_cfg[CLXS_HOSTIF_MAX_C2C_ENTRY_PER_TRAP]);
uint32_t
clxs_hostif_get_trap_acl_entry(
    _In_  uint32_t              unit,
    _In_  uint32_t              trap_type,
    _Out_ uint32_t              *acl_entry_id
);

sai_status_t
clxs_hostif_collectDropStats(
    _In_  uint32_t                          unit,
    _In_  uint32_t                          queue,
    _Out_ CLXS_HOSTIF_STATS_T               *stats);

sai_status_t
clxs_hostif_clearDropStats(
    _In_  uint32_t                          unit,
    _In_  uint32_t                          queue);

sai_status_t
clxs_hostif_auto_update (
    _In_ sai_object_id_t            port_id,
    _In_ sai_port_oper_status_t     port_state);

sai_status_t
clxs_hostif_set_pvid (
    _In_ uint32_t       unit,
    _In_ uint32_t       port,
    _In_ uint32_t       vid);

sai_status_t
clxs_hostif_updateSrcMac(
    _In_ const uint32_t    unit,
    _In_ const sai_mac_t   mac_addr);

#endif
