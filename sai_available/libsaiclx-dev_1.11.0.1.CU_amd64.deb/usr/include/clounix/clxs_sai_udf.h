/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_UDF_H__)
#define __CLXS_UDF_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define CLXS_UDF_GROUP_MAX_NUM       (1)

/* MACRO FUNCTION DECLARATIONS
 */
#define CLXS_UDF_ENTRY_MAX_NUM(__unit__)       (CLXS_UDF_GROUP_MAX_NUM * CLXS_UDF_GROUP_CAPACITY(__unit__))

#define udf_entry(_unit_,_db_idx_)      _clxs_udf_cb[_unit_]->entry[_db_idx_]
#define udf_group(_unit_,_db_idx_)      _clxs_udf_cb[_unit_]->group[_db_idx_]
#define udf_match(_unit_,_db_idx_)      _clxs_udf_cb[_unit_]->match[_db_idx_]

#define udf_entry_db(_unit_,_db_idx_)      udf_entry(_unit_,_db_idx_).db
#define udf_group_db(_unit_,_db_idx_)      udf_group(_unit_,_db_idx_).db
#define udf_match_db(_unit_,_db_idx_)      udf_match(_unit_,_db_idx_).db

/* DATA TYPE DECLARATIONS
 */
typedef struct _CLXS_UDF_MATCH_L2_T
{
    uint16_t data;
    bool     is_valid;
} CLXS_UDF_MATCH_L2_T;

typedef struct _CLXS_UDF_MATCH_L3_T
{
    uint8_t  data;
    bool     is_valid;
} CLXS_UDF_MATCH_L3_T;

typedef struct _CLXS_UDF_MATCH_DB_T
{
    uint32_t refs;
    CLXS_UDF_MATCH_L2_T l2_type;
    CLXS_UDF_MATCH_L3_T l3_type;
    uint8_t priority;
    sai_object_id_t sai_object;
} CLXS_UDF_MATCH_DB_T;

typedef struct _CLXS_UDF_ENTRY_DB_T {
    uint32_t base;
    uint32_t offset;
    uint32_t match_index;
    uint32_t group_index;
    sai_object_id_t sai_object;
} CLXS_UDF_ENTRY_DB_T;

typedef struct _CLXS_UDF_GROUP_DB_T
{
    uint32_t type;
    uint32_t length;
    uint32_t refs;
    uint32_t count;
    sai_object_id_t sai_object;
    uint32_t udf_indexes[0];
} CLXS_UDF_GROUP_DB_T;

typedef struct _CLXS_UDF_GROUP_CB_T {
    CLXS_UDF_GROUP_DB_T *db;
    bool is_created;
} CLXS_UDF_GROUP_CB_T;

typedef struct _CLXS_UDF_ENTRY_CB_T {
    CLXS_UDF_ENTRY_DB_T *db;
    bool is_created;
} CLXS_UDF_ENTRY_CB_T;

typedef struct _CLXS_UDF_MATCH_CB_T {
    CLXS_UDF_MATCH_DB_T *db;
    bool is_created;
} CLXS_UDF_MATCH_CB_T;


typedef struct _CLXS_UDF_CB_T {

    CLXS_UDF_GROUP_CB_T   group[CLXS_UDF_GROUP_MAX_NUM];
    CLXS_UDF_ENTRY_CB_T *  entry;
    CLXS_UDF_MATCH_CB_T *  match;
} CLXS_UDF_CB_T;

extern const sai_udf_api_t              udf_api;
extern CLXS_UDF_CB_T *_clxs_udf_cb[CLXS_MAX_CHIP_NUM];
/* API DECLARATIONS
 */
sai_status_t clxs_udf_get_match_list_from_group(
    _In_ sai_object_id_t    udf_group_id,
    _Out_ uint32_t          *ptr_count,
    _Out_ CLXS_UDF_MATCH_DB_T *ptr_match_list);

sai_status_t clxs_udf_get_entry_list(
    _In_ sai_object_id_t    udf_group_id,
    _In_ sai_object_id_t    udf_match_id,
    _Out_ uint32_t          *ptr_count,
    _Out_ uint32_t          *ptr_list);

sai_status_t clxs_udf_init(_In_ uint32_t unit);

sai_status_t clxs_udf_deinit(_In_ uint32_t unit);

sai_status_t clxs_udf_get_group_obj(
    _In_ uint32_t         unit,
    _In_ uint32_t         udf_group_id,
    _Out_ sai_object_id_t *ptr_udf_group_id);

sai_status_t clxs_udf_get_match_id(
    _In_ sai_object_id_t    udf_match_obj,
    _Out_ uint32_t          *ptr_match_id);

sai_status_t clxs_udf_get_db_size(
    _In_ uint32_t           unit,
    _In_ sai_object_type_t  udf_type,
    _Out_ uint32_t         *size);

sai_status_t clxs_udf_get_db_count(
    _In_ uint32_t unit, _In_ sai_object_type_t udf_type,
    _Out_ uint32_t *count);

bool clxs_udf_is_db_created(_In_ uint32_t unit, _In_ uint32_t index, _In_ sai_object_type_t udf_type);


#endif /* __CLXS_UDF_H__ */
