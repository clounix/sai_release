/**
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 * File:    clxs_sai_ext_phy.h
 *
 * Brief:   This module defines ext phy interface
 *  
 */


#ifndef __CLXS_EXT_PHY_H__
#define __CLXS_EXT_PHY_H__

#if CLX_PORT_EXT_PHY
#include <ext_phy.h>

/**
 * @brief internal phy
 */
#define EXT_PHY_FEATURE_TYPE_INTERNAL_PHY   0x00000000

/**
 * @brief ext phy type 1
 */
#define EXT_PHY_FEATURE_TYPE_1              0x00000001

typedef struct  CLXS_LINE_CARD_SCAN_S
{
    uint32_t                interval_us;
    CLX_THREAD_ID_T         thread_id;
    CLX_SEMAPHORE_ID_T      sema;
} CLXS_LINE_CARD_SCAN_T;

typedef struct CLXS_EXT_PHY_STATUS_RECORD_S
{ 
    ext_phy_init_status_t    status; 
    struct tm                ts;
    bool                     valid;
} CLXS_EXT_PHY_STATUS_RECORD_T;

typedef struct CLXS_EXT_PHY_SLOT_INFO_S
{ 
    CLXS_EXT_PHY_STATUS_RECORD_T*    history_status; 
    int32_t     current_index;
} CLXS_EXT_PHY_SLOT_INFO_T;

#define CLXS_LINE_CARD_SCAN_THREAD_PRI              (50)
#define CLXS_LINE_CARD_SCAN_THREAD_NAME             "LINE_CARD_SCAN"
#define CLXS_LINE_CARD_TEST_THREAD_NAME             "LINE_CARD_TEST"
#define CLXS_LINE_CARD_SCAN_THREAD_INTERVAL         (1000000)
#define CLXS_LINE_CARD_SCAN_THREAD_STACK_SIZE       (32 * 1024)
#define CLXS_LINE_CARD_SCAN_TAKE_SYNC_SEMA(unit, timeout)         \
    osal_takeSemaphore(&clxs_line_card_scan[unit].sema, timeout)

#define CLXS_LINE_CARD_SCAN_GIVE_SYNC_SEMA(unit)                  \
    osal_giveSemaphore(&clxs_line_card_scan[unit].sema);

#define EXT_PHY_MAX_SLOT_INIT_STATUS_HISTORY      100

typedef int32_t (*ext_phy_api_query_f_p)(EXT_PHY_DRV_T**);

extern EXT_PHY_DRV_T *            clxs_ext_phy_func_vec;

char* _clxs_ext_phy_initStatusToString(
    _In_ const ext_phy_init_status_t status);

extern CLX_SEMAPHORE_ID_T      ext_phy_api_sema;
extern CLXS_EXT_PHY_SLOT_INFO_T*   clxs_ext_phy_slot_status_record;

// Macro for ext phy api call
#define EXT_PHY_API_CALL(type, func_name, ...) \
    ({ \
        sai_status_t ret_val = SAI_STATUS_SUCCESS; \
        osal_takeSemaphore(&ext_phy_api_sema, CLX_SEMAPHORE_WAIT_FOREVER); \
        if (type == EXT_PHY_FEATURE_TYPE_1) { \
            if (clxs_ext_phy_func_vec->func_name) { \
                ret_val = clxs_ext_phy_func_vec->func_name(__VA_ARGS__); \
            } \
        } \
        osal_giveSemaphore(&ext_phy_api_sema); \
        ret_val; \
    })

// Macro for ext phy port api call
#define EXT_PHY_PORT_API_CALL(ext_phy_type, func_name, port, ...) \
    ({ \
        sai_status_t ret_val = SAI_STATUS_SUCCESS; \
        osal_takeSemaphore(&ext_phy_api_sema, CLX_SEMAPHORE_WAIT_FOREVER); \
        if (ext_phy_type == EXT_PHY_FEATURE_TYPE_1) { \
            if (clxs_ext_phy_func_vec->func_name) { \
                ext_phy_init_status_t port_status = EXT_PHY_NOT_PRESENT; \
                ret_val = clxs_ext_phy_func_vec->get_port_init_status(port, &port_status); \
                if (SAI_STATUS_SUCCESS != ret_val) { \
                    CLXS_LOG_ERR(__MODULE__, "port %d ext phy get status failed, ret=%d!", port, ret_val); \
                } \
                else { \
                    if (EXT_PHY_INIT_SUCCESS == port_status) { \
                        ret_val = clxs_ext_phy_func_vec->func_name(port, __VA_ARGS__); \
                    } \
                    else { \
                        CLXS_LOG_INF(__MODULE__, "port %d ext phy get port status %s, ret=%d!", port, _clxs_ext_phy_initStatusToString(port_status), ret); \
                        ret_val = SAI_STATUS_ITEM_NOT_FOUND; \
                    } \
                } \
            } \
        } \
        osal_giveSemaphore(&ext_phy_api_sema); \
        ret_val; \
    })

sai_status_t
clxs_ext_phy_init(
    uint32_t    unit, 
    uint32_t    type, 
    const char*       json_file);

sai_status_t
clxs_ext_phy_deinit(
    uint32_t    unit,
    uint32_t    type);

sai_status_t
clxs_ext_phy_preShutdown(
    const uint32_t     unit,
    uint32_t    type);

sai_status_t
clxs_ext_phy_lineCardScanInit(
    const uint32_t    unit,
    uint32_t          type);

sai_status_t
clxs_ext_phy_lineCardScanDeinit(
    const uint32_t    unit);

uint32_t
clxs_ext_phy_clxFec2ExtPhy(
    const uint32_t    clxs_fec_mode);

uint32_t
clxs_ext_phy_ExtPhyFec2Clx(
    const uint32_t    ext_phy_fec_mode);

#endif
#endif /* End of __CLXS_EXT_PHY_H__ */


