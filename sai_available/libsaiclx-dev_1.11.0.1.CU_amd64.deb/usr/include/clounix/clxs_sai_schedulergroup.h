/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2024
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLXS_SCHDULERGROUP_H__)
#define __CLXS_SCHDULERGROUP_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define CLXS_SCH_GRP_MAX_SCH_NUM         (9)
#define CLXS_SCH_GRP_MAX_SCH_LEVELS      (3)


/* DATA TYPE DECLARATIONS
 */
typedef struct CLXS_SCH_GRP_DB_S
{
    bool                        is_used;
    sai_object_id_t             object_id;
    sai_object_id_t             parent_id;
    uint32_t                    child_count;
    uint32_t                    max_child_count;
    sai_object_id_t             scheduler_id;
    CLX_TM_SCH_TOPOLOGY_ENTRY_T topology_entry;
} CLXS_SCH_GRP_DB_T;

typedef struct CLXS_SCH_GRP_HIERARCHY_S
{
    bool             is_legacy;
    /* queue, lv2, lv1*/
    CLXS_SCH_GRP_DB_T groups[CLXS_SCH_GRP_MAX_SCH_LEVELS][CLXS_SCH_GRP_MAX_SCH_NUM];
} CLXS_SCH_GRP_HIERARCHY_T;

typedef struct CLXS_SCH_GRP_CB_S{
    CLXS_SCH_GRP_HIERARCHY_T         clxs_sch_grp_prof_map[CLXS_MAX_PORT_NUM];
} CLXS_SCH_GRP_CB_T;

extern const sai_scheduler_group_api_t  schedulergroup_api;
extern CLXS_SCH_GRP_CB_T *_clxs_sch_grp_cb[CLXS_MAX_CHIP_NUM];
extern uint32_t _clxs_sch_grp_level_max_node[CLXS_SCH_GRP_MAX_SCH_LEVELS];

/* API DECLARATIONS
 */
sai_status_t
clxs_sch_grp_getPortQueueLegacy(
    uint32_t    unit,
    uint32_t    port,
    bool    *legacy);

sai_status_t clxs_sch_grp_getGroupDb(
    uint32_t            unit,
    uint32_t            port,
    uint32_t            level,
    uint32_t            index,
    CLXS_SCH_GRP_DB_T    *ptr_group_db);

sai_status_t
clxs_sch_grp_removeQueue(
    uint32_t    unit,
    uint32_t    port,
    sai_object_id_t parent_oid);

sai_status_t
clxs_sch_grp_addQueue(
    uint32_t    unit,
    uint32_t    port,
    sai_object_id_t     parent_oid);

sai_status_t clxs_sch_grp_applyTopology(
    uint32_t            unit,
    uint32_t            port);

sai_status_t clxs_sch_grp_checkTopologyComplete(
    uint32_t            unit,
    uint32_t            port,
    bool                *is_complete);

sai_status_t clxs_sch_grp_getHierarchyDb(
    uint32_t                    unit,
    uint32_t                    port,
    CLXS_SCH_GRP_HIERARCHY_T     *ptr_db);

sai_status_t clxs_sch_grp_getGroupNum(
    sai_object_id_t     port_object_id,
    uint32_t            *ptr_num);

sai_status_t clxs_sch_grp_getGroupList(
    sai_object_id_t     port_object_id,
    sai_object_id_t     *ptr_list);

sai_status_t clxs_sch_grp_init(
    uint32_t unit);

sai_status_t clxs_sch_grp_deinit(
    uint32_t unit);

sai_status_t clxs_sch_grp_setGroupDb(
    uint32_t            unit,
    uint32_t            port,
    uint32_t            level,
    uint32_t            index,
    CLXS_SCH_GRP_DB_T    *ptr_group_db);
#endif /* __CLXS_SCHDULERGROUP_H__ */
