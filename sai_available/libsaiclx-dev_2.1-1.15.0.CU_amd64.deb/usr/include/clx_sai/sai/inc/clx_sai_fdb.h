/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_FDB_H__)
#define __CLX_SAI_FDB_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define MAX_MAC_STR_LEN                 20
#define CLXS_FDB_DB(__unit__) (ptr_clxs_fdb_db[(__unit__)])
#define CLXS_FDB_LOCK(__unit__)   \
        osal_semaphore_take(&ptr_clxs_fdb_db[(__unit__)]->semaphore, CLX_SEMAPHORE_WAIT_FOREVER)
#define CLXS_FDB_UNLOCK(__unit__) \
        osal_semaphore_give(&ptr_clxs_fdb_db[(__unit__)]->semaphore)


/*******************************************************************************
 * Data Type Definitions
 *******************************************************************************/
typedef struct clxs_fdb_db_entry_s
{
    clx_bridge_domain_t     bdid; /* key */
    clx_mac_t               mac;  /* key */
    clx_port_t              port;
    clxs_fdb_entry_attrs_t  attr_info;
} clxs_fdb_db_entry_t;

/* module data base */
typedef struct clxs_fdb_db_s
{
    util_lib_avl_head_t     *fdb_entry_avl;
    clx_semaphore_id_t      semaphore;
} clxs_fdb_db_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_fdb_api_t              fdb_api;
extern clxs_fdb_db_t* ptr_clxs_fdb_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_fdb_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_fdb_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_fdb_register_callback(
    _In_ const uint32_t unit,
    _In_ void *ptr_func);

#endif /* __CLX_SAI_FDB_H__ */
