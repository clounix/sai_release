/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_NEIGHBOR_H__)
#define __CLX_SAI_NEIGHBOR_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define MAX_VLAN_ID 4096
#define CLXS_NEIGHBOR_DB(unit) (ptr_clxs_neighbor_db[unit])

#define CLXS_NEIGHBOR_LOCK(unit) \
    osal_semaphore_take(&ptr_clxs_neighbor_db[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER)
#define CLXS_NEIGHBOR_UNLOCK(unit) \
    osal_semaphore_give(&ptr_clxs_neighbor_db[unit]->sema)

#define CLXS_BC_NEIGHBOR_LOCK(unit) \
    osal_semaphore_take(&ptr_clxs_neighbor_db[unit]->bc_sema, CLX_SEMAPHORE_WAIT_FOREVER)
#define CLXS_BC_NEIGHBOR_UNLOCK(unit) \
    osal_semaphore_give(&ptr_clxs_neighbor_db[unit]->bc_sema)

/*******************************************************************************
 * Data Type Definitions
 *******************************************************************************/
typedef struct clxs_neighbor_bc_entry_s
{
    uint32_t intf_id; /* L3 egress interface ID */
    uint32_t mc_id;
    bool enable;
    uint8_t intf_mac[6];
    uint32_t vrf_id;
    util_lib_list_t *ip_list; /*ip list */
    clx_port_bitmap_t port_bitmap;
}clxs_neighbor_bc_entry_t;

typedef struct clxs_neighbor_adj_data_s
{
    uint32_t adj_id; /*next hop id */
    sai_object_id_t rif_id; /*rif */
}clxs_neighbor_adj_data_t;

typedef struct clxs_neighbor_entry_s
{
    uint32_t vrf_id; /* key */
    sai_ip_address_t ip_address; /* key */
    sai_object_id_t switch_id;
    sai_object_id_t counter_id;
    sai_packet_action_t pkt_action;
    bool no_host;
    uint32_t adj_in_use;
    uint32_t user_meta;
    uint32_t flush_label;
    util_lib_list_t *adj_list; /*different rif\adj by each, date type:clxs_neighbor_adj_data_t */
}clxs_neighbor_entry_t;

typedef struct clxs_neighbor_adj_entry_s
{
    uint32_t adj_id; /*key*/ 
    clxs_neighbor_entry_t *ptr_neighbor;
}clxs_neighbor_adj_entry_t;

/* module data base */
typedef struct clxs_neighbor_db_s
{
    util_lib_avl_head_t *ptr_neighbor_avl;
    util_lib_avl_head_t *ptr_adj;
    clx_semaphore_id_t sema;
    clxs_neighbor_bc_entry_t *ptr_bc_neighbor;
    clx_semaphore_id_t bc_sema;
} clxs_neighbor_db_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_neighbor_api_t neighbor_api;
extern clxs_neighbor_db_t *ptr_clxs_neighbor_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_neighbor_init(
    _In_    const uint32_t  unit);

sai_status_t
clxs_neighbor_deinit(
    _In_    const uint32_t  unit);

sai_status_t
clxs_neighbor_get_host_count(
    _In_    uint32_t    unit,
    _Out_   uint32_t    *ptr_count);

sai_status_t
clxs_neighbor_update_bc_vlan_member(
    _In_    bool                add,
    _In_    uint32_t            unit,
    _In_    clx_vlan_t          vlan,
    _In_    clx_port_bitmap_t   port_bitmap);

sai_status_t
clxs_create_neighbor_entry(
    _In_    const sai_neighbor_entry_t  *neighbor_entry,
    _In_    uint32_t                    attr_count,
    _In_    const sai_attribute_t       *attr_list);

sai_status_t
clxs_remove_neighbor_entry(
    _In_    const sai_neighbor_entry_t  *neighbor_entry);

sai_status_t
clxs_set_neighbor_entry_attribute(
    _In_    const sai_neighbor_entry_t  *neighbor_entry,
    _In_    const sai_attribute_t       *attr);

sai_status_t
clxs_get_neighbor_entry_attribute(
    _In_    const sai_neighbor_entry_t  *neighbor_entry,
    _In_    uint32_t                    attr_count,
    _Inout_ sai_attribute_t             *attr_list);

clxs_neighbor_bc_entry_t*
clxs_neighbor_get_bc_db(
    _In_    uint32_t    unit,
    _In_    clx_vlan_t  vlan);

sai_status_t
clxs_neighbor_update_host(
    _In_ const uint32_t         unit,
    _In_ const clx_port_t       port,
    _In_ const uint32_t         adj_id,
    _In_ const uint32_t         reason);

sai_status_t
clxs_neighbor_flush_by_port(
    sai_object_id_t             port_id);

#endif
