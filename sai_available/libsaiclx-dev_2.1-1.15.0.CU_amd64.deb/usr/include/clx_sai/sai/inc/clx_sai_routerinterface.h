/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_ROUTERINTERFACE_H__)
#define __CLX_SAI_ROUTERINTERFACE_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define INVALID_INTF_ID 0xffffffff
#define CLXS_RIF_NVO3_RTE_INTF(__unit__)                (CLXS_MIN_NVO3_INTF_ID(__unit__))
#define CLXS_RIF_NVO3_RTE_MASK(__unit__)                (CLXS_NUM_RIF(__unit__))
#define CLXS_RIF_RTE_MASK(__unit__)                     0xFFFFFFFF
#define CLXS_MIN_NVO3_INTF_ID(__unit__)             (CLXS_NUM_RIF(__unit__) - CLXS_NUM_NVO3_INTF_ID(__unit__))
#define CLXS_RIF_DB(unit) (ptr_clxs_rif_db[unit])

#define CLXS_RIF_LOCK(unit) \
    sai_osal_mutex_lock(ptr_clxs_rif_db[unit]->sema)

#define CLXS_RIF_UNLOCK(unit) \
    sai_osal_mutex_unlock(ptr_clxs_rif_db[unit]->sema)

typedef enum _clxs_rif_rmac_type_t
{
    CLXS_RIF_RMAC_TYPE_SHARED,
    CLXS_RIF_RMAC_TYPE_EXCLUSIVE,
} clxs_rif_rmac_type_t;

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef struct
{
    bool valid;
    uint32_t native_intf_id;        /*for virtual rif*/
    util_lib_list_t *ptr_virtual_intf_list;        /*for native rif*/
    clx_bridge_domain_t bdid;
    uint32_t rmac_idx;
    uint32_t tnl_mac_idx;
    uint32 igr_cnt_id;        /* Ingress counter ID. */
    uint32 egr_cnt_id;        /* Egress counter ID. */
    sai_object_id_t obj_id;        /* port, lag, or vlan object_id */
    uint32_t flags;
    clxs_router_interface_attrs_t attr_info;
} clxs_rif_entry_t;
#define CLXS_RIF_ENTRY_FLAGS_NVO3 (1U << 0)    /*used by tunnel*/

typedef struct
{
    bool valid;
    uint32_t rmac_label;
    clx_mac_t mac;
    clx_mac_t mac_msk;
    uint32_t ref_cnt;
    uint32_t flags;
}clxs_rif_rmac_t;
#define CLXS_RIF_RMAC_FLAGS_SHARED (1U << 0)

typedef struct
{
    uint32_t intf_id;
}clxs_rif_virtual_intf_info_t;

typedef struct
{
    bool valid;
    uint32_t ref_cnt;
    clx_mac_t tunnel_mac;
    clx_mac_t tunnel_mac_mask;
} clxs_rif_tnl_mac_t;

typedef struct
{
    clxs_rif_entry_t *ptr_rif_entry;
    uint32_t *bdid2intfid;
    uint32_t *ptr_rmac_label_bmp;
    clxs_rif_rmac_t *ptr_rmac;
    uint32_t *ptr_tnl_bmp;        /* my_tnl_mac */
    clxs_rif_tnl_mac_t *ptr_tnl_mac;
    clx_semaphore_id_t sema;
    uint32_t rif_counter_number;
} clxs_rif_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_router_interface_api_t routerinterface_api;
extern clxs_object_stats_capability_info_t router_interface_stats_capability_info;
extern uint32_t         _clxs_rif_max_num[CLXS_MAX_CHIP_NUM];
extern clxs_rif_db_t     *ptr_clxs_rif_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t clxs_rif_init(
    _In_ const uint32_t    unit);

sai_status_t clxs_rif_deinit(
    _In_ const uint32_t    unit);

sai_status_t clxs_rif_get_sub_port_vid(
    _In_  const sai_object_id_t         rif_id,
    _Out_ uint32_t                      *ptr_subvid);

sai_status_t clxs_rif_get_info(
    _In_  const sai_object_id_t         rif_id,
    _Out_ uint32_t                      *ptr_unit,
    _Out_ clx_bridge_domain_t           *ptr_bdid,
    _Out_ clx_l3_intf_t            *ptr_intf_info,
    _Out_ sai_router_interface_type_t   *ptr_type,
    _Out_ clx_port_t                    *ptr_port);

sai_status_t clxs_rif_update_lag_member(
    _In_ const sai_object_id_t          lag_oid,
    _In_ const clx_port_t               clx_port,
    _In_ const bool                     is_add);

sai_status_t clxs_rif_get_bdid(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  intf_id,
    _Out_ clx_bridge_domain_t* bdid);

sai_status_t clxs_rif_get_type(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  intf_id,
    _Out_ sai_int32_t* type);

sai_status_t clxs_rif_update_router_mac(
    _In_ const uint32_t unit,
    _In_ const sai_mac_t new_mac);

sai_status_t
clxs_rif_alloc_nvo3_intf(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  bdid,
    _Out_ uint32_t  *ptr_intf_id);

void
clxs_rif_free_nvo3_intf(
    const uint32_t  unit,
    uint32_t        intf_id);

bool
clxs_rif_intf_is_nvo3(
    const uint32_t  unit,
    const uint32_t  intf_id);

sai_status_t
clxs_rif_update_router_mac_by_vrf(
    _In_ const uint32_t unit,
    _In_ const uint32_t vrf,
    _In_ const sai_mac_t  new_mac);

sai_status_t
clxs_rif_get_object_id(
    _In_ const uint32_t      unit,
    _In_ const uint32_t      intf_id,
    _Out_ sai_object_id_t    *router_interface_id);

sai_status_t
clxs_rif_add_nvo3_rmac(
    _In_ const uint32_t unit,
    _In_ const uint32_t l3_intf_id,
    _In_ const clx_mac_t mac);

sai_status_t
clxs_rif_del_nvo3_rmac(
    _In_ const uint32_t unit,
    _In_ const clx_mac_t mac);

sai_status_t
clxs_rif_set_vrf(
    _In_ const uint32_t  unit,
    _In_ uint32_t l3_intf_id,
    _In_ sai_object_id_t vrf_oid);
#endif /* __CLX_SAI_ROUTERINTERFACE_H__ */
