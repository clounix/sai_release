/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_SWITCH_H__)
#define __CLX_SAI_SWITCH_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define SAI_COLD_BOOT               0
#define SAI_WARM_BOOT               1
#define SAI_FAST_BOOT               2

#ifdef CLX_PFC_WD_TIMER_INTERVAL_EN
#define CLX_SWITCH_MAX_PFCWD_POLLING_INTERVAL   (100)
#define CLX_SWITCH_MIN_PFCWD_POLLING_INTERVAL   (1)
#endif
#define SAI_IS_WARM_BOOT(unit)  (clxs_switch_get_boot_type(unit) == SAI_WARM_BOOT)
#define SAI_IS_FAST_BOOT(unit)  (clxs_switch_get_boot_type(unit) == SAI_FAST_BOOT)
#define SAI_IS_WARM_DEINIT(unit)  clxs_switch_get_deinit_type(unit)

#define CLXS_TM_LOCK(unit)          sai_osal_mutex_lock(clxs_tm_mutex[unit])
#define CLXS_TM_UNLOCK(unit)        sai_osal_mutex_unlock(clxs_tm_mutex[unit])
#define CLXS_DB_LOCK(unit)          sai_osal_mutex_lock(clxs_db_mutex[unit])
#define CLXS_DB_UNLOCK(unit)        sai_osal_mutex_unlock(clxs_db_mutex[unit])

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef enum
{
    _CLXS_SWITCH_MAC = 0,
    _CLXS_DEFAULT_VXLAN_ROUTER_MAC
}clxs_switch_mac_type_t;

typedef enum
{
    CLX_CFG_TYPE_EXTEND_DIAG_LOG_SEVERITY = CLX_CFG_TYPE_LAST + 1,
    CLX_CFG_TYPE_PORT_BREAKOUT_LANE_NUM_MAX,
    CLX_CFG_TYPE_EXTEND_SDK_LOG_SEVERITY,
    CLX_CFG_TYPE_EXTEND_ECMP_RH_HASH_SEED,
    CLX_CFG_TYPE_EXTEND_LAG_RH_HASH_SEED,
    CLX_CFG_TYPE_EXTEND_ECMP_FDL_THRESHOLD,
    CLX_CFG_TYPE_EXTEND_ECMP_FDL_PROBABILITY,
    CLX_CFG_TYPE_EXTEND_ECMP_MEMBERS_MAX_COUNT,
#ifdef CLX_TAM_MOD_EXTEND_ENABLE
    CLX_CFG_TYPE_EXTEND_MOD_PP_QUEUE_CIR,
    CLX_CFG_TYPE_EXTEND_MOD_TM_QUEUE_CIR,
#endif
    CLX_CFG_TYPE_EXTEND_LOG_DES_DIR,
    CLX_CFG_TYPE_EXTEND_CPI_ENABLE,
    CLX_CFG_TYPE_EXTEND_LAST
}clxs_cfg_extend_type_t;

typedef enum
{
    V4_V6_HOST_HASH_RSC = 0,        /*V4 HOST HASH & V6 HOST HASH*/
    V4_V6_ROUTE_2X_RSC,             /*V4 ROUTE & V6 ROUTE(MASK <= 64)*/
    V4_V6_ROUTE_4X_RSC,             /*V4 ROUTE & V6 ROUTE(MASK > 64)*/
    AVBL_ROUTE_HW_RSC_LAST
}clxs_switch_avbl_route_hw_rsc_type_t;

typedef struct clxs_switch_entry_s
{
    uint32_t                                        unit_inited;
    bool                                            restart_warm_only;
    uint32_t                                        boot_type;
    char*                                           warm_read_filename;
    char*                                           warm_write_filename;
    char*                                           warm_sdk_filename;
    FILE*                                           warm_sdk_file;
    uint32_t                                        default_hash_seed[CLX_SWC_HSH_PKT_TYPE_LAST];
    clxs_switch_attrs_t                             attr_info;
} clxs_switch_entry_t;

typedef struct clxs_switch_db_s
{
    uint32_t                                        inited_num;
    char                                            sdk_cfg_path[SAI_MAX_FIRMWARE_PATH_NAME_LEN];
    char                                            sdk_led_cfg_path[SAI_MAX_FIRMWARE_PATH_NAME_LEN];
    clxs_switch_entry_t                             switch_entry[CLXS_MAX_CHIP_NUM];
} clxs_switch_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_switch_api_t           switch_api;
extern clx_semaphore_id_t               clxs_tm_mutex[CLXS_MAX_CHIP_NUM];
extern clx_semaphore_id_t               clxs_db_mutex[CLXS_MAX_CHIP_NUM];
extern clxs_object_stats_capability_info_t switch_stats_capability_info;
extern clxs_switch_db_t _clxs_switch_db;


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_switch_get_unit_id(
    _In_ sai_object_id_t        switch_id,
    _Out_ uint32_t              *ptr_unit_id);

sai_status_t
clxs_switch_get_fdb_miss_action(
    _In_ const uint32_t             unit,
    _In_ const clxs_srv_bum_type_t   type,
    _Out_ sai_packet_action_t       *ptr_action);

sai_status_t
clxs_switch_get_cfg_value(
    _In_ const uint32 unit,
    _In_ const clx_cfg_type_t in_cfg_type,
    _Inout_ clx_cfg_value_t * ptr_cfg_value);

bool
clxs_switch_get_restart_warm_only(
    _In_ const uint32_t unit);

const char *
clxs_switch_get_module_name(
    _In_ const uint32_t index);

sai_status_t
clxs_switch_get_src_mac(
    _In_ const uint32_t              unit,
    _In_ const uint32_t              type,
    _Out_ sai_mac_t                 *mac);

uint32_t
clxs_switch_get_unit_inited(
    _In_ const uint32_t unit);

sai_status_t
clxs_get_switch_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_switch_init_module(
    _In_ uint32_t       unit);

clx_error_no_t
_clxs_switch_get_cfg_value(
    _In_  const uint32       unit,
    _In_  const uint32       in_cfg_type,
    _Out_ clx_cfg_value_t    *ptr_in_value);

boolean
clxs_switch_check_default_cfg_enable(
    const uint32            unit,
    const uint32            defalut_config);


bool
clxs_switch_get_deinit_type(
    _In_ const uint32_t    unit);

sai_status_t
clxs_switch_get_ecmp_rh_enable(
    _In_ const uint32_t     unit,
    _In_ bool               *rh_enable);

#ifdef CLX_ECMP_FASTLINK_CONVERGE_EN
bool
clxs_switch_get_ecmp_fast_converge_enable(
    _In_ const uint32_t             unit);
#endif

sai_status_t
clxs_switch_get_enum_values_capability(
    _In_ const uint32_t unit,
    _In_ const sai_attr_id_t attr_id,
    _Inout_ sai_s32_list_t *enum_values_capability);

sai_status_t
clxs_switch_get_hash_symmetric_enable(
    _In_ const uint32_t    unit,
    _In_ const uint32_t    hash_engine,
    _Out_ bool             *enable);

uint32_t
clxs_switch_get_boot_type(
    _In_ const uint32_t  unit);

sai_status_t
clxs_switch_get_ecmp_member_counts(
    _In_   const uint32_t   unit,
    _Out_  uint32_t*  ecmp_count);

sai_status_t
clxs_switch_shutdown_request_notify(
    _In_ const uint32_t    unit);

sai_status_t
clxs_switch_get_qosmap(
    _In_ const uint32_t              unit,
    _In_ const sai_qos_map_type_t    type,
    _Out_   sai_object_id_t          *ptr_qosmap_oid);

sai_status_t
clxs_switch_get_lag_hash_algorithm(
    _In_ const uint32_t    unit,
    _Out_ int32_t          *ptr_hash_algo);

sai_status_t
clxs_switch_get_lag_rh_enable(
    _In_ uint32_t            unit,
    _Out_ bool               *ptr_rh_enable);

sai_status_t
clxs_switch_get_profile_id(
    _In_ const uint32_t    unit,
    _Out_ uint32_t         *profile_id);

sai_packet_action_t clxs_switch_get_pfc_dlr_packet_action(
    _In_ const uint32   unit);

sai_status_t clxs_switch_get_pfc_tc_dld_interval(
    _In_ const uint32   unit,
    _Inout_ sai_map_list_t *ptr_maplist);

sai_status_t clxs_switch_get_pfc_tc_dlr_interval(
    _In_ const uint32   unit,
    _Inout_ sai_map_list_t *ptr_maplist);

#if SAI_API_VERSION >= SAI_VERSION(1,12,0)
sai_status_t
clxs_switch_get_hostif_status_auto_update(
    _In_ const uint32_t    unit,
    _Out_ bool             *enable);
#endif

#endif /* __CLX_SAI_SWITCH_H__ */
