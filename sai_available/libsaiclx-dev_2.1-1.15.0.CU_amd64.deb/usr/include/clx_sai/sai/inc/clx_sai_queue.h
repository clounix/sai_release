/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_QUEUE_H__)
#define __CLX_SAI_QUEUE_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_REGISTER_QUEUE_STATS_NOTIFY_UPDATE(func)   do { clxs_queue_stats_notify_update[__MODULE__] = func; } while (0)

#define CLXS_PORT_QUEUE_PTR(__unit__, __port__, __queue_index__)       \
            ((clxs_queue_t *)(_clxs_queue_db[__unit__]->queue) + __port__*(CLXS_QUEUE_UC_NUM(__unit__) + CLXS_QUEUE_MC_NUM(__unit__)) + __queue_index__)

#define CLXS_CPU_QUEUE_PTR(__unit__, __queue_index__)       \
            ((clxs_queue_t *)(_clxs_queue_db[__unit__]->queue) + CLXS_MAX_PORT_NUM *(CLXS_QUEUE_UC_NUM(__unit__) + CLXS_QUEUE_MC_NUM(__unit__)) + __queue_index__)
/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/

typedef struct clxs_queue_s
{
    clxs_queue_attrs_t    *queue_attrs;
    uint64_t              last_drop_pkts;             /**The previous statistical values of drop pkts*/
    uint64_t              last_drop_bytes;            /**The previous statistical values of drop bytes*/
    uint64_t              historical_wred_drop_pkts;  /**Historical cumulative values of wred drop pkts*/
    uint64_t              historical_wred_drop_bytes; /**Historical cumulative values of wred drop bytes*/
} clxs_queue_t;

typedef struct clxs_queue_db_s{
    void*           pfcdl_callback;
    clxs_queue_t    queue[0]; /* flexible array member ,must be the last member of the structure */
} clxs_queue_db_t;

typedef sai_status_t (*CLXS_QUEUE_STATS_NOTIFY_UPDATE)(
    _In_ const uint32             unit,
    _In_ const uint32             port,
    _In_ clx_tm_handler_type_t    handler_type,
    _In_ const uint32             queue_index,
    _In_ uint64                   pkt_cnt,
    _In_ uint64                   drop_cnt);

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_queue_api_t                  queue_api;
extern clxs_object_stats_capability_info_t    queue_stats_capability_info;
extern clxs_queue_db_t                        *_clxs_queue_db[CLXS_MAX_CHIP_NUM];

extern CLXS_QUEUE_STATS_NOTIFY_UPDATE         clxs_queue_stats_notify_update[CLXS_API_MAX];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_queue_register_callback(
    _In_ const uint32_t    unit,
    _In_ void              *func);

uint32_t
clxs_queue_get_queue_id(
    _In_ uint32_t    unit,
    _In_ uint32_t    port,
    _In_ uint32_t    queue_id);

sai_status_t
clxs_queue_get_queue(
    _In_ uint32_t          unit,
    _In_ uint32_t          port,
    _In_ uint32_t          queue_id,
    _Out_ clxs_queue_t     **ptr_queue);

sai_status_t
clxs_queue_getNum(
    _In_ sai_object_id_t     port_object_id,
    _Out_ uint32_t           *ptr_num);

sai_status_t
clxs_queue_getList(
    _In_ sai_object_id_t     port_object_id,
    _Out_ sai_object_id_t    *ptr_list);

sai_status_t
clxs_queue_init(
    _In_ uint32_t    unit);

sai_status_t
clxs_queue_deinit(
    _In_ uint32_t    unit);

sai_status_t
clxs_queue_apply_port_wred(
    _In_ uint32_t           unit,
    _In_ uint32_t           port,
    _In_ sai_object_id_t    wred_id);

sai_status_t
clxs_get_queue_stats_ext(
    _In_ sai_object_id_t        queue_id,
    _In_ uint32_t               number_of_counters,
    _In_ const sai_stat_id_t    *counter_ids,
    _In_ sai_stats_mode_t       mode,
    _Out_ uint64_t              *counters);

sai_status_t
clxs_clear_queue_stats(
        _In_ sai_object_id_t        queue_id,
        _In_ uint32_t               number_of_counters,
        _In_ const sai_stat_id_t    *counter_ids);

sai_status_t
clxs_queue_get_profile_id(
    _In_ uint32_t            unit,
    _In_ uint32_t            port,
    _In_ uint32_t            queue_idx,
    _In_ sai_queue_attr_t    attr_id,
    _Out_ sai_object_id_t    *attr_oid);

sai_object_id_t
clxs_queue_get_queue_object_id(
    _In_ uint32_t    unit,
    _In_ uint32_t    port,
    _In_ uint32_t    queue_idx);

sai_status_t
clxs_queue_get_buf_drop_stats(
    _In_ const uint32               unit,
    _In_ const uint32               port,
    _In_ const uint32               queue_idx,
    clx_tm_handler_type_t           handler_type,
    clx_stat_tm_cnt_t               *ptr_drop_cnt);

#endif /* __CLX_SAI_QUEUE_H__ */
