/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_PORT_LINK_DELAY_H__)
#define __CLX_SAI_PORT_LINK_DELAY_H__

#ifdef CLX_PORT_LINK_DELAY

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/

#define CLXS_PORT_LINK_DELAY_LOCK(unit) \
    sai_osal_mutex_lock(_clxs_link_delay[unit].data_protect);

#define CLXS_PORT_LINK_DELAY_UNLOCK(unit) \
    sai_osal_mutex_unlock(_clxs_link_delay[unit].data_protect);

#define CLXS_PORT_LINK_DELAY_PTR(__unit__, __port__)        ((clxs_port_link_delay_t *)(_clxs_link_delay[__unit__].port_link_delay_ptr + __port__ ))

#define CLXS_PORT_LINK_DELAY_THREAD_INTERVAL_MIN    (500)

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/

typedef struct  clxs_port_link_delay_s
{
    uint32_t                up_delay;
    uint32_t                down_delay;
    uint64_t                up_time;
    uint64_t                down_time;
    sai_port_oper_status_t  link_status;
    sai_port_oper_status_t  link_status_last_report;
    uint32_t                up_cnt;
    uint32_t                down_cnt;
    bool                    timeout;
} clxs_port_link_delay_t;

typedef struct  clxs_link_delay_s
{
    clx_port_bitmap_t       port_bmp;
    clxs_port_link_delay_t  *port_link_delay_ptr;
    uint32_t                interval_us;
    clx_thread_id_t         thread_id;
    clx_semaphore_id_t      data_protect;
} clxs_link_delay_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/

extern clxs_link_delay_t _clxs_link_delay[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/

sai_status_t clxs_port_linkdelay_update_state(
        _In_ const uint32_t unit,
        _In_ const uint32_t port,
        _In_ const uint32_t link,
        _Out_ bool *ptr_linkdelay_en,
        _Out_ bool *ptr_notify);

sai_status_t clxs_port_linkdelay_set_up_delay_time(
    _In_ uint32_t                unit,
    _In_ uint32_t                port,
    _In_ uint32_t                up_delay_time);

sai_status_t clxs_port_linkdelay_set_down_delay_time(
    _In_ uint32_t                unit,
    _In_ uint32_t                port,
    _In_ uint32_t                down_delay_time);

uint32_t clxs_port_linkdelay_get_up_delay_time(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

uint32_t clxs_port_linkdelay_get_down_delay_time(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

uint32_t clxs_port_linkdelay_get_down_cnt(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

uint32_t clxs_port_linkdelay_get_up_cnt(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

sai_status_t clxs_port_linkdelay_init_resource(
    _In_ const uint32_t unit);

sai_status_t clxs_port_linkdelay_deinit_resource(
    _In_ const uint32_t unit);

sai_status_t clxs_port_linkdelay_init_thread(
    _In_ const uint32_t     unit);

sai_status_t clxs_port_linkdelay_deinit_thread(
    _In_ const uint32_t     unit);

#endif


#endif /* __CLX_SAI_PORT_LINK_DELAY_H__ */