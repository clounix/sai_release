/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_STP_H__)
#define __CLX_SAI_STP_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_STP_LOCK(__unit__)   \
        sai_osal_mutex_lock(ptr_clxs_stp_db[(__unit__)]->sema)
#define CLXS_STP_UNLOCK(__unit__) \
        sai_osal_mutex_unlock(ptr_clxs_stp_db[(__unit__)]->sema)

#define CLXS_STP_DB(__unit__)                (ptr_clxs_stp_db[(__unit__)])
#define CLXS_STP_VALID_STP_BMP(__unit__)     (ptr_clxs_stp_db[(__unit__)]->valid_stp_bmp)
#define CLXS_STP_INFO(__unit__, __stpid__)   (ptr_clxs_stp_db[(__unit__)]->stp_arr[(__stpid__)])
#define CLXS_STP_PORT_AVL(__unit__)          (ptr_clxs_stp_db[(__unit__)]->ptr_port_avl)
#define CLXS_STP_BMP_SIZE(__unit__)          (CLX_BITMAP_SIZE(CLXS_MAX_STP_NUM(__unit__)))

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef struct clxs_stp_cookie_s
{
    uint32_t            unit;
    uint32_t            stpid;
    uint32_t            mbr_cnt;
    uint32_t            *count;
    sai_object_id_t     **pptr_oid;
} clxs_stp_cookie_t;

typedef struct clxs_stp_port_node_s
{
    uint32_t            stpid;      /* KEY */
    clx_gport_t         gport;      /* KEY */
    clx_stp_state_t     state;      /* value */
    sai_object_id_t     bd_port_oid;/* value */
} clxs_stp_port_node_t;

typedef struct clxs_stp_info_s
{
    uint32_t            vlan_bmp[CLXS_VLAN_BMP_SIZE]; /* 1Q-Domain */
    uint32_t            bdid;                         /* 1D-Domain */
    uint32_t            mbr_cnt;
} clxs_stp_info_t;

typedef struct clxs_stp_db_s
{
    uint32_t              *valid_stp_bmp;
    clxs_stp_info_t       *stp_arr;
    util_lib_avl_head_t   *ptr_port_avl;
    clx_semaphore_id_t    sema;
} clxs_stp_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_stp_api_t stp_api;
extern clxs_stp_db_t      *ptr_clxs_stp_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_stp_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_stp_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_stp_get_info(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_stpid);

sai_status_t
clxs_stp_get_object(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_stp_update_stp_vlan(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             vid,
    _In_ const bool                 is_add);

sai_status_t
clxs_stp_updateStpBdid(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             bd_port_id,
    _In_ const uint32_t             bdid);

sai_status_t
clxs_get_stp_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_stp_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_create_stp_port(
    _Out_ sai_object_id_t         *stp_port_id,
    _In_ sai_object_id_t          switch_id,
    _In_ uint32_t                 attr_count,
    _In_ const sai_attribute_t    *attr_list);

sai_status_t
clxs_remove_stp_port(
    _In_ sai_object_id_t     stp_port_id);


#endif /* __CLX_SAI_STP_H__ */
