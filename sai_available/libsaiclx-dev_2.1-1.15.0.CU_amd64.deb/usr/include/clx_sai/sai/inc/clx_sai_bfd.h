/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_BFD_H__)
#define __CLX_SAI_BFD_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_BFD_LOCK(unit)     sai_osal_mutex_lock(g_clxs_bfd_db[unit].mutex)
#define CLXS_BFD_UNLOCK(unit)   sai_osal_mutex_unlock(g_clxs_bfd_db[unit].mutex)
#define CLXS_BFD_DB(__unit__)   (g_clxs_bfd_db[__unit__])


/*******************************************************************************
 * Data Type Declarations 
 *******************************************************************************/
typedef struct clxs_bfd_session_obj_s
{
    sai_object_id_t             session_oid;
    uint32                      hw_session_id;
    clxs_bfd_session_attrs_t    attr_info;
} clxs_bfd_session_obj_t;

typedef struct clxs_bfd_db_s
{
    util_lib_list_t     *ptr_session_list;
    clx_semaphore_id_t  mutex;
} clxs_bfd_db_t;


/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern clxs_bfd_db_t g_clxs_bfd_db[CLXS_MAX_CHIP_NUM];
extern const sai_bfd_api_t  bfd_api;


/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/
/*Public Functions*/
sai_status_t clxs_bfd_deinit(
    _In_ const uint32_t unit);

sai_status_t clxs_bfd_event_register_callback(
    _In_ const uint32_t unit,
    _In_ void           *ptr_func);

sai_status_t clxs_bfd_get_session_count(
    _In_    const uint32_t  unit,
    _Out_   uint32_t        *session_count);

sai_status_t clxs_bfd_init(
    _In_ const uint32_t unit);

sai_status_t clxs_bfd_session_get_obj(
    _In_    const   uint32_t        unit,
    _In_    uint32_t                obj_id,
    _Out_   clxs_bfd_session_obj_t  **pptr_obj);

/*SAI API Functions*/
sai_status_t
clxs_get_bfd_session_stats_ext(
    _In_  sai_object_id_t       bfd_session_id,
    _In_  uint32_t              number_of_counters,
    _In_  const sai_stat_id_t   *ptr_counter_ids,
    _In_  sai_stats_mode_t      mode,
    _Out_ uint64_t              *ptr_counters);

#endif /*__CLX_SAI_BFD_H__*/
