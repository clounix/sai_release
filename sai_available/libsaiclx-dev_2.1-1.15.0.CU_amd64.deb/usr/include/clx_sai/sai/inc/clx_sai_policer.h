/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_POLICER_H__)
#define __CLX_SAI_POLICER_H__
#define CLXS_POLICER_MAX_METER_NUMBER(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_meterid_num):0)

#define CLXS_POLICER_MAX_METER_GLOBAL_BS(unit)        (_ptr_clxs_policer_db[unit]->is_global_bs)
#define CLXS_POLICER_MAX_METER_GLOBAL_IR(unit)        (_ptr_clxs_policer_db[unit]->is_global_ir)

#define CLXS_POLICER_MAX_METER_GLOBAL_PACKET_BS(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_global_packet_bs):0)
#define CLXS_POLICER_MAX_METER_GLOBAL_BYTE_BS(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_global_byte_bs):0)
#define CLXS_POLICER_MAX_METER_PLANE_PACKET_BS(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_plane_packet_bs):0)
#define CLXS_POLICER_MAX_METER_PLANE_BYTE_BS(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_plane_byte_bs):0)

#define CLXS_POLICER_MAX_METER_GLOBAL_PACKET_IR(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_global_packet_ir):0)
#define CLXS_POLICER_MAX_METER_GLOBAL_BYTE_IR(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_global_byte_ir):0)
#define CLXS_POLICER_MAX_METER_PLANE_PACKET_IR(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_plane_packet_ir):0)
#define CLXS_POLICER_MAX_METER_PLANE_BYTE_IR(unit)        ( (CLXS_CHIP_SPEC(unit)!=NULL)?(CLXS_CHIP_SPEC(unit)->policer.max_plane_byte_ir):0)

#define CLXS_POLICER_GN_PKT_ACT_DROP             (0x1 << CLX_COLOR_GREEN)
#define CLXS_POLICER_YL_PKT_ACT_DROP             (0x1 << CLX_COLOR_YELLOW)
#define CLXS_POLICER_RD_PKT_ACT_DROP             (0x1 << CLX_COLOR_RED)

#define CLXS_POLICER_INVALID_METER_ID            (0xFFFFFFFF)

#define CLXS_POLICER_LOCK(unit) \
    osal_semaphore_take(&_ptr_clxs_policer_db[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_POLICER_UNLOCK(unit) \
    osal_semaphore_give(&_ptr_clxs_policer_db[unit]->sema);

typedef struct clxs_meter_counter_pkt_act_s
{
    sai_packet_action_t pkt_act;
    bool                enable_counter;
} clxs_meter_counter_pkt_act_t;

typedef struct clxs_meter_info_s
{
    uint32_t            meter_id;
    uint32_t            srv_cnt_id;
    clxs_policer_attrs_t     *attr_info;
} clxs_meter_info_t;

typedef struct clxs_policer_db_s
{
    clx_semaphore_id_t      sema;
    bool                    is_global_bs;
    bool                    is_global_ir;
    clxs_meter_info_t       meter_cfg_info[0];
} clxs_policer_db_t;

extern const sai_policer_api_t          policer_api;
extern clxs_policer_db_t *_ptr_clxs_policer_db[CLXS_MAX_CHIP_NUM];

#define CLXS_REGISTER_POLICER_CHANGE(func)   do { clxs_policer_notify_update_cb[__MODULE__] = func; } while (0)

typedef sai_status_t (*clxs_policer_notify_update_fn)(
    _In_ const uint32_t      unit,
    _In_ sai_object_id_t     object_id,
    _In_ clx_meter_cfg_t     old_meter_cfg,
    _In_ clx_meter_cfg_t     new_meter_cfg);

extern clxs_policer_notify_update_fn clxs_policer_notify_update_cb[CLXS_API_MAX];


/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/ 
sai_status_t
clxs_policer_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_policer_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_policer_get_meter_cfg(
    _In_ const sai_object_id_t      policer_id,
    _Out_ uint32_t      *ptr_meter_id,
    _Out_ clx_meter_cfg_t   *ptr_meter_cfg);

sai_status_t
clxs_policer_get_meter_cnt_id(
    _In_ const sai_object_id_t  policer_id,
    _Out_ uint32_t              *ptr_cnt_id);

sai_status_t
clxs_policer_get_color_act(
    _In_ uint32_t   unit,
    _In_ uint32_t   meter_id,
    _Out_ uint32_t  *ptr_color_act);
#endif /* __CLX_SAI_POLICER_H__ */
