/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_BUFFER_H__)
#define __CLX_SAI_BUFFER_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_BUF_IGR_POOL_NUM                   (3)
#define CLXS_BUF_EGR_POOL_NUM                   (3)
#define CLXS_BUF_IGR_RESERVED_POOL_NUM          (1)
#define CLXS_BUF_EGR_RESERVED_POOL_NUM          (1)
#define CLXS_BUF_IGR_USER_POOL_NUM              ((CLXS_BUF_IGR_POOL_NUM) - (CLXS_BUF_IGR_RESERVED_POOL_NUM))
#define CLXS_BUF_EGR_USER_POOL_NUM              ((CLXS_BUF_EGR_POOL_NUM) - (CLXS_BUF_EGR_RESERVED_POOL_NUM))
#define CLXS_BUF_POOL_NUM                       ((CLXS_BUF_IGR_POOL_NUM) + (CLXS_BUF_EGR_POOL_NUM))

#define CLXS_BUF_PROFILE_START_INDEX            (0)
#define CLXS_BUF_PROFILE_IGR_DEAULT_INDEX       (0)
#define CLXS_BUF_PROFILE_EGR_DEAULT_INDEX       (2)
#define CLXS_BUF_IGR_RESERVED_PROFILE_NUM       (2)
#define CLXS_BUF_EGR_RESERVED_PROFILE_NUM       (1)
#define CLXS_BUF_PROFILE_MAX_NUM(unit)          ((CLXS_BUF_IGR_PROFILE_NUM(unit)) + (CLXS_BUF_EGR_PROFILE_NUM(unit)))
#define CLXS_BUF_PROFILE_USER_MAX_NUM(unit)     (CLXS_BUF_PROFILE_MAX_NUM(unit) - CLXS_BUF_IGR_RESERVED_PROFILE_NUM - CLXS_BUF_EGR_RESERVED_PROFILE_NUM)

#define CLXS_BUF_IGR_PG_NUM_PER_PORT(unit)      (CLXS_QUEUE_LEGACY_NUM(unit))
#define CLXS_BUF_PORT_QUEUE_NUM(unit, port)     ((CLXS_QUEUE_UC_NUM(unit)) + (CLXS_PORT_MC_QUEUE_NUM(unit, port)))

#define CLXS_BUFFER_DB(_unit_)                  (clxs_buffer_db[_unit_])

#define CLXS_BUFFER_POOL_OBJ_PTR(_unit_, _id_)      \
                    ((clxs_buffer_pool_obj_t *)CLXS_BUFFER_DB(_unit_).pool_table.ptr_obj + (_id_))
#define CLXS_BUFFER_PROFILE_OBJ_PTR(_unit_, _id_)      \
                    ((clxs_buffer_profile_obj_t *)CLXS_BUFFER_DB(_unit_).profile_table.ptr_obj + (_id_))
#define CLXS_BUFFER_IGR_PG_OBJ_PTR(_unit_, _port_, _id_)      \
                    ((clxs_buffer_igr_pg_obj_t *)CLXS_BUFFER_DB(_unit_).igr_pg_table.ptr_obj + \
                    (_port_) * (CLXS_BUF_IGR_PG_NUM_PER_PORT(_unit_)) + (_id_))

#define CLXS_BUFFER_HW_PROFILE_PTR(_unit_, _type_, _id_)    \
                    ((clxs_buffer_hw_profile_t *)(CLXS_BUFFER_DB(_unit_).buffer_hw_profiles + \
                    ((_type_) * (CLXS_BUF_IGR_PROFILE_NUM(_unit_)) + (_id_))))


/*******************************************************************************
 * Data Type Declarations 
 *******************************************************************************/
typedef enum _sai_buffer_alpha_bounds_t {
    SAI_BUFFER_ALPHA_1_128 = -7,
    SAI_BUFFER_ALPHA_1_64  = -6,
    SAI_BUFFER_ALPHA_1_32  = -5,
    SAI_BUFFER_ALPHA_1_16  = -4,
    SAI_BUFFER_ALPHA_1_8   = -3,
    SAI_BUFFER_ALPHA_1_4   = -2,
    SAI_BUFFER_ALPHA_1_2   = -1,

    SAI_BUFFER_ALPHA_1  = 0,
    SAI_BUFFER_ALPHA_2  = 1,
    SAI_BUFFER_ALPHA_4  = 2,
    SAI_BUFFER_ALPHA_8  = 3,
    SAI_BUFFER_ALPHA_16 = 4,
    SAI_BUFFER_ALPHA_32 = 5,
    SAI_BUFFER_ALPHA_64 = 6,
} sai_buffer_alpha_bounds_t;

typedef enum _clxs_buffer_hw_prof_type_t
{
    BUFF_HW_PROF_TYPE_SATRT = 0,
    BUFF_HW_PROF_TYPE_IGR_PG = BUFF_HW_PROF_TYPE_SATRT, //hw_type used as an index in CLXS_BUFFER_HW_PROFILE_PTR,should start from 0.
    BUFF_HW_PROF_TYPE_EGR_QUEUE,
    BUFF_HW_PROF_TYPE_MAX
} clxs_buffer_hw_prof_type_t;

typedef enum _clxs_buffer_target_type_t
{
    BUFF_TARGET_TYPE_START = 0,
    BUFF_TARGET_TYPE_IGR_PG,
    BUFF_TARGET_TYPE_QUEUE,
    BUFF_TARGET_TYPE_END
} clxs_buffer_target_type_t;

typedef struct _clxs_buffer_hw_profile_t {
    bool        is_valid;
    uint32_t    hw_profile_id;
    uint32_t    prof_obj_id;
} clxs_buffer_hw_profile_t;

typedef struct _clxs_buffer_pool_obj_t
{
    sai_object_id_t             pool_oid;
    uint32_t                    hw_type;
    clxs_buffer_pool_attrs_t    attr_info;
} clxs_buffer_pool_obj_t;

typedef struct _clxs_buffer_profile_obj_t
{
    sai_object_id_t             profile_oid;
    uint32_t                    profile_obj_id;
    uint32_t                    profile_hw_id;
    uint32_t                    ref_cnt;
    clxs_buffer_target_type_t   target_type;
    clxs_buffer_profile_attrs_t attr_info;
} clxs_buffer_profile_obj_t;

typedef struct _clxs_buffer_igr_pg_obj_t
{
    sai_object_id_t                     igr_pg_oid;
    clxs_ingress_priority_group_attrs_t *ptr_attr_info;
} clxs_buffer_igr_pg_obj_t;

typedef struct _clxs_buffer_pool_obj_table_t
{
    uint32_t                max_num;
    uint32_t                num_in_use;
    clxs_buffer_pool_obj_t  *ptr_obj;
    uint32_t                *ptr_obj_valid_bmp;
} clxs_buffer_pool_obj_table_t;

typedef struct _clxs_buffer_profile_obj_table_t
{
    uint32_t                    max_num;
    uint32_t                    num_in_use;
    clxs_buffer_profile_obj_t   *ptr_obj;
    uint32_t                    *ptr_obj_valid_bmp;
} clxs_buffer_profile_obj_table_t;

typedef struct _clxs_buffer_igr_pg_obj_table_t
{
    uint32_t                    max_num;
    uint32_t                    num_in_use;
    clxs_buffer_igr_pg_obj_t    *ptr_obj;
    uint32_t                    *ptr_obj_valid_bmp;
} clxs_buffer_igr_pg_obj_table_t;

typedef struct _clxs_buffer_db_t
{
    uint32_t                        default_igr_pool_id;
    uint32_t                        default_egr_pool_id;
    uint32_t                        default_igr_prof_id;
    uint32_t                        default_igr_pfc_prof_id;
    uint32_t                        default_egr_prof_id;
    clxs_buffer_hw_profile_t        *buffer_hw_profiles;
    clxs_buffer_pool_obj_table_t    pool_table;
    clxs_buffer_profile_obj_table_t profile_table;
    clxs_buffer_igr_pg_obj_table_t  igr_pg_table;
} clxs_buffer_db_t;

typedef struct _clxs_buffer_port_pool_oid_fields_t
{
    uint32_t                pool_id;
    sai_buffer_pool_type_t  pool_type;
} clxs_buffer_port_pool_oid_fields_t;


/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern const sai_buffer_api_t               buffer_api;
extern clxs_object_stats_capability_info_t  ing_pg_stats_capability_info;
extern clxs_object_stats_capability_info_t  buffer_pool_stats_capability_info;
extern clxs_buffer_db_t                     clxs_buffer_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/ 
sai_status_t
clxs_buffer_add_default_profile_to_port(
    _In_ uint32_t unit,
    _In_ uint32_t port);

sai_status_t 
clxs_buffer_bind_profile_to_queue(
    _In_ sai_object_id_t queue_oid,
    _In_ sai_object_id_t buf_prof_oid);

uint32_t
clxs_buffer_bytes_to_clxs_cells(
    _In_ uint32_t unit,
    _In_ uint64_t bytes);

uint32_t
clxs_buffer_clxs_cells_to_bytes(
    _In_ uint32_t unit,
    _In_ uint32_t cells);

sai_status_t
clxs_buffer_deinit(
    _In_ uint32_t unit);

sai_status_t
clxs_buffer_del_profile_from_port(
    _In_ uint32_t unit,
    _In_ uint32_t port);

sai_status_t
clxs_buffer_get_bind_profile_id(
    _In_    uint32_t                    unit,
    _In_    uint32_t                    port,
    _In_    clxs_buffer_target_type_t   buf_target_type,
    _In_    uint32_t                    target_id,
    _Out_   uint32_t                    *ptr_prof_idx);

sai_status_t 
clxs_buffer_get_egr_default_buffer_profile(
    _In_ uint32_t           unit,
    _Out_ sai_object_id_t   *ptr_buffer_prof_oid);

sai_status_t 
clxs_buffer_get_igr_pg_obj(
    _In_    const   uint32_t            unit,
    _In_    uint32_t                    port,
    _In_    uint32_t                    pg_id,
    _Out_   clxs_buffer_igr_pg_obj_t    **pptr_obj);

sai_status_t 
clxs_buffer_get_pool_obj(
    _In_    const   uint32_t        unit,
    _In_    uint32_t                obj_id,
    _Out_   clxs_buffer_pool_obj_t  **pptr_obj);

sai_status_t
clxs_buffer_get_port_pool_oid_fields(
    _In_  sai_object_id_t                       buffer_pool_oid,
    _Out_ clxs_buffer_port_pool_oid_fields_t    *ptr_port_pool_oid_fields);

sai_status_t
clxs_buffer_get_port_occupancy(
    _In_    uint32_t                unit,
    _In_    uint32_t                port,
    _In_    sai_buffer_pool_type_t  buf_pool_type,
    _Out_   uint64_t                *ptr_cur_occupy_cell);

sai_status_t
clxs_buffer_get_port_pool_list(
    _In_ sai_object_id_t            object_id,
    _Inout_ sai_attribute_value_t   *ptr_value);

sai_status_t
clxs_buffer_get_priority_group_count(
    sai_object_id_t port_object_id,
    uint32_t        *ptr_count);

sai_status_t
clxs_buffer_get_priority_group_list(
    sai_object_id_t port_object_id,
    sai_object_id_t *ptr_list);

sai_status_t 
clxs_buffer_get_profile_obj(
    _In_    const   uint32_t            unit,
    _In_    uint32_t                    obj_id,
    _Out_   clxs_buffer_profile_obj_t   **pptr_obj);

sai_status_t 
clxs_buffer_get_queue_buffer_profile(
    _In_ uint32_t           unit,
    _In_ uint32_t           port,
    _In_ uint32_t           queue_id,
    _Out_ sai_object_id_t   *ptr_buffer_prof_oid);

sai_status_t
clxs_buffer_init(
    _In_ uint32_t unit);

sai_status_t 
clxs_buffer_pg_set_port_buffer_profile(
    _In_ uint32_t           unit,
    _In_ uint32_t           port,
    _In_ uint32_t           pg_id,
    _In_ sai_object_id_t    buffer_prof_oid);

sai_status_t
clxs_buffer_update_port_pg_buffer(
    _In_ uint32_t   unit,
    _In_ uint32_t   port,
    _In_ uint32_t   pg_id,
    _In_ uint32_t   pfc_enable);

sai_status_t
clxs_get_buffer_pool_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t      *count);

sai_status_t
clxs_get_buffer_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t      *count);

/**************************************************************/
sai_status_t
clxs_clear_buffer_pool_stats(
    _In_ sai_object_id_t        pool_id,
    _In_ uint32_t               number_of_counters,
    _In_ const sai_stat_id_t    *ptr_counter_ids);

sai_status_t
clxs_clear_ingress_priority_group_stats(
    _In_ sai_object_id_t                            ingress_pg_id,
    _In_ uint32_t                                   number_of_counters,
#if SAI_API_VERSION >= SAI_VERSION(1,4,0)
    _In_ const sai_stat_id_t                        *ptr_counter_ids);
#else
    _In_ const sai_ingress_priority_group_stat_t    *ptr_counter_ids);
#endif

sai_status_t
clxs_get_buffer_pool_stats_ext(
    _In_  sai_object_id_t       pool_id,
    _In_  uint32_t              number_of_counters,
    _In_  const sai_stat_id_t   *ptr_counter_ids,
    _In_  sai_stats_mode_t      mode,
    _Out_ uint64_t              *ptr_counters);

sai_status_t
clxs_get_ingress_priority_group_stats_ext(
    _In_ sai_object_id_t                            ingress_pg_id,
    _In_ uint32_t                                   number_of_counters,
#if SAI_API_VERSION >= SAI_VERSION(1,4,0)
    _In_ const sai_stat_id_t                        *ptr_counter_ids,
#else
    _In_ const sai_ingress_priority_group_stat_t    *ptr_counter_ids,
#endif
    _In_ sai_stats_mode_t                           mode,
    _Out_ uint64_t                                  *ptr_counters);

sai_status_t
clxs_buffer_get_default_egress_pool(
    _In_    uint32_t                unit,
    _In_    sai_object_id_t         *pool_id);

sai_status_t
clxs_buffer_update_port_queue(
    _In_ uint32_t               unit,
    _In_ uint32_t               port,
    _In_ uint32_t               queue);

 #endif /*__CLX_SAI_BUFFER_H__*/