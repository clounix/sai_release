/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_TAM_H__)
#define __CLX_SAI_TAM_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_TAM_TAM_MAX_NUM                (32)
#define CLXS_TAM_MATH_FUNC_MAX_NUM          (32)
#define CLXS_TAM_EVENT_THRESHOLD_MAX_NUM    (32)
#define CLXS_TAM_TEL_TYPE_MAX_NUM           (32)
#define CLXS_TAM_REPORT_MAX_NUM             (32)
#define CLXS_TAM_TELEMETRY_MAX_NUM          (32)
#define CLXS_TAM_TRANSPORT_MAX_NUM          (32)
#define CLXS_TAM_COLLECTOR_MAX_NUM          (32)
#define CLXS_TAM_EVENT_ACTION_MAX_NUM       (128)
#define CLXS_TAM_EVENT_MAX_NUM              (128)

#ifdef CLX_TAM_MOD_EXTEND_ENABLE
#define CLXS_TAM_MOD_QUEUE_BINDWIDTH   (2048)
#define CLXS_TAM_MOD_QUEUE_BURST       (8191)
#define CLXS_TAM_MOD_NETIF_TYPE        (1)
#define CLXS_TAM_MOD_NETIF_ID_SET(id)   ((CLXS_TAM_MOD_NETIF_TYPE << 16) + id)
#define CLXS_TAM_MOD_NETIF_ID_GET(id)   (id & 0xffff)
#endif

#define CLXS_TAM_LOCK(unit)                     sai_osal_mutex_lock(g_clxs_tam_db[unit].data_protect)
#define CLXS_TAM_UNLOCK(unit)                   sai_osal_mutex_unlock(g_clxs_tam_db[unit].data_protect)
#define CLXS_TAM_DB(__unit__)                   (g_clxs_tam_db[__unit__])

#define CLXS_TAM_TAM_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_tam_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_TAM].ptr_obj + __id__)
#define CLXS_TAM_MATH_FUNC_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_math_func_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_MATH_FUNC].ptr_obj + __id__)
#define CLXS_TAM_EVENT_THRESHOLD_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_event_threshold_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_EVENT_THRESHOLD].ptr_obj + __id__)
#define CLXS_TAM_TEL_TYPE_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_tel_type_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_TEL_TYPE].ptr_obj + __id__)
#define CLXS_TAM_REPORT_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_report_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_REPORT].ptr_obj + __id__)
#define CLXS_TAM_TELEMETRY_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_telemetry_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_TELEMETRY].ptr_obj + __id__)
#define CLXS_TAM_TRANSPORT_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_transport_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_TRANSPORT].ptr_obj + __id__)
#define CLXS_TAM_COLLECTOR_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_collector_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_COLLECTOR].ptr_obj + __id__)
#define CLXS_TAM_EVENT_ACTION_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_event_action_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_EVENT_ACTION].ptr_obj + __id__)
#define CLXS_TAM_EVENT_OBJ_PTR(__unit__, __id__)    \
                    ((clxs_tam_event_obj_t *)CLXS_TAM_DB(__unit__).tam_obj_table[CLXS_TAM_TYPE_EVENT].ptr_obj + __id__)


/*******************************************************************************
 * Data Type Declarations 
 *******************************************************************************/
typedef enum _clxs_tam_type_t
{
    CLXS_TAM_TYPE_START = 0,
    CLXS_TAM_TYPE_TAM = CLXS_TAM_TYPE_START,
    CLXS_TAM_TYPE_MATH_FUNC,
    CLXS_TAM_TYPE_EVENT_THRESHOLD,
    CLXS_TAM_TYPE_TEL_TYPE,
    CLXS_TAM_TYPE_REPORT,
    CLXS_TAM_TYPE_TELEMETRY,
    CLXS_TAM_TYPE_TRANSPORT,
    CLXS_TAM_TYPE_COLLECTOR,
    CLXS_TAM_TYPE_EVENT_ACTION,
    CLXS_TAM_TYPE_EVENT,
    CLXS_TAM_TYPE_MAX
} clxs_tam_type_t;

typedef enum _clxs_tam_mod_type_t
{
    CLXS_TAM_MOD_TYPE_TM,
    CLXS_TAM_MOD_TYPE_IPP,
    CLXS_TAM_MOD_TYPE_EPP,
    CLXS_TAM_MOD_TYPE_ALL,
    CLXS_TAM_MOD_TYPE_MAX_NUM
}clxs_tam_mod_type_t;

typedef struct _clxs_tam_tam_obj_t
{
    sai_object_id_t     tam_oid;
    clxs_tam_attrs_t    attr_info;
} clxs_tam_tam_obj_t;

typedef struct _clxs_tam_math_func_obj_t
{
    sai_object_id_t             tam_math_func_oid;
    clxs_tam_math_func_attrs_t  attr_info;
} clxs_tam_math_func_obj_t;

typedef struct _clxs_tam_event_threshold_obj_t
{
    sai_object_id_t                     tam_event_threshold_oid;
    clxs_tam_event_threshold_attrs_t    attr_info;
} clxs_tam_event_threshold_obj_t;

typedef struct _clxs_tam_tel_type_obj_t
{
    sai_object_id_t             tam_tel_type_oid;
    clxs_tam_tel_type_attrs_t   attr_info;
} clxs_tam_tel_type_obj_t;

typedef struct _clxs_tam_report_obj_t
{
    sai_object_id_t         tam_report_oid;
    clxs_tam_report_attrs_t attr_info;
} clxs_tam_report_obj_t;

typedef struct _clxs_tam_telemetry_obj_t
{
    sai_object_id_t             tam_telemetry_oid;
    clxs_tam_telemetry_attrs_t  attr_info;
} clxs_tam_telemetry_obj_t;

typedef struct _clxs_tam_transport_obj_t
{
    sai_object_id_t             tam_transport_oid;
    clxs_tam_transport_attrs_t  attr_info;
} clxs_tam_transport_obj_t;

typedef struct _clxs_tam_collector_obj_t
{
    sai_object_id_t         tam_collector_oid;
    clxs_tam_collector_attrs_t attr_info;
} clxs_tam_collector_obj_t;

typedef struct _clxs_tam_event_action_obj_t
{
    sai_object_id_t                 tam_event_action_oid;
    clxs_tam_event_action_attrs_t   attr_info;
} clxs_tam_event_action_obj_t;

typedef struct _clxs_tam_event_obj_t
{
    sai_object_id_t         tam_event_oid;
    clxs_tam_event_attrs_t  attr_info;
#ifdef CLX_TAM_MOD_EXTEND_ENABLE
    uint32_t                netlink_id;
    uint32_t                netlink_profile_id;
    uint32_t                out_port;
#endif
} clxs_tam_event_obj_t;

typedef struct _clxs_tam_type_map_t
{
    clxs_tam_type_t tam_type;
    uint32_t        obj_max_num;
    uint32_t        bytes_per_obj;
} clxs_tam_type_map_t;

typedef struct _clxs_tam_obj_table_t
{
    uint32_t    size;
    uint32_t    count;
    void        *ptr_obj;
    uint32_t    *ptr_obj_valid;
} clxs_tam_obj_table_t;

typedef struct _clxs_tam_db_t
{
    clxs_tam_obj_table_t    tam_obj_table[CLXS_TAM_TYPE_MAX];
    clx_semaphore_id_t      data_protect;
} clxs_tam_db_t;


/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern clxs_tam_db_t g_clxs_tam_db[CLXS_MAX_CHIP_NUM];
extern const sai_tam_api_t  tam_api;


/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/ 
sai_status_t clxs_tam_get_obj(
    _In_    const   uint32_t        unit,
    _In_    const   clxs_tam_type_t tam_type,
    _In_    uint32_t                obj_id,
    _Out_   void                    **pptr_obj);

sai_status_t clxs_tam_init(
    _In_ const uint32_t unit);

sai_status_t clxs_tam_deinit(
    _In_ const uint32_t unit);

#if SAI_API_VERSION >= SAI_VERSION(1,5,0)
sai_status_t clxs_tam_update_tam_obj_list(
    _In_ sai_object_id_t            bind_obj,
    _In_ const sai_object_list_t    *ptr_old_tam_obj_list,
    _In_ const sai_object_list_t    *ptr_new_tam_obj_list);

#endif

sai_status_t clxs_tam_set_collector_cfg_info(
    _In_  sai_object_id_t                   collector_oid,
    _Out_  clx_telm_collector_cfg_info_t    *ptr_clx_collector_cfg);


sai_status_t clxs_tam_get_transport_object_id(
    _In_ const sai_object_id_t              collector_oid,
    _Out_ sai_object_id_t                   *ptr_transport_oid);

#endif /*__CLX_SAI_TAM_H__*/
