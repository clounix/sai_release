/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_SWITCH_FEATURE_H__)
#define __CLX_SAI_SWITCH_FEATURE_H__
/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_FEATURE_NAME_MAX_LEN       (128)
#define CLXS_SHOW_ECMP_PATH_BY_COUNTER     1
#define CLXS_SHOW_ECMP_PATH_BY_ALGO        2
#define CLXS_PORT_LINK_DELAY_DEF_MODE      1
#define CLXS_PORT_LINK_DELAY_EXT_MODE      2

#define CLXS_WRED_ECN_UNMARK_COUNT_ACL     2
#define CLXS_WRED_ECN_COUNT_ACL_IPV6       4

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef enum
{
    CLXS_FEATURE_FIRST = CLX_CFG_TYPE_EXTEND_LAST,
    CLXS_FEATURE_ACL_SONIC_BIND = CLXS_FEATURE_FIRST,
    CLXS_FEATURE_ADJ_DROP_BY_DELETING_FDB,
    CLXS_FEATURE_BRIDGEPORT_ING_FILTER,
    CLXS_FEATURE_ECC_ERR_LOG,
    CLXS_FEATURE_MAC_MOVE_NOTIFY,
    CLXS_FEATURE_PORT_IP_COUNT_USING_ACL,
    CLXS_FEATURE_PORT_LINK_DELAY,
    CLXS_FEATURE_SHOW_ECMP_PATH,
    CLXS_FEATURE_SWITCH_MONITOR,
    CLXS_FEATURE_RIF_RESOURCE_MODE,
    CLXS_FEATURE_TUNNEL_NOV3_RIF_NUM,
    CLXS_FEATURE_TUNNEL_NOV3_RTE_MAC_NUM,
    CLXS_FEATURE_EXT_PHY_TYPE,
    CLXS_FEATURE_EXT_PHY_LINE_CARD_SCAN_INTERVAL,
    CLXS_FEATURE_STORMCONTROL_VALUE0_USE_ACL,
    CLXS_FEATURE_SUPPORT_BULK_GET_STATS,
    CLXS_FEATURE_PORT_FLEX_SPEED_SLOWDOWN,
    CLXS_FEATURE_L3_MTU_FAIL_ACTION,
    CLXS_FEATURE_PORT_SERDES_CONFIG_FROM_FILE,
    CLXS_FEATURE_NETIF_VLAN_TAG_TYPE,
    CLXS_FEATURE_CPU_RX_RATE_LIMIT, /* param0: 0:cpu port rx rate, 1: cpu queue rx rate
                                       param1: when param0 is 0, NA
                                               when param0 is 1, queue id
                                       value : rate pps
                                    */
    CLXS_FEATURE_NEIGHBOR_FLUSH_HOST,
    CLXS_FEATURE_WATERMARK_READ_CLEAR_ENABLE,
    CLXS_FEATURE_LINKDELAY_STATUS_CHANGE_LOG,
    CLXS_FEATURE_TAM_INT_TRUNCATE_SIZE,
    CLXS_FEATURE_MOD_RX_BY_NETIF,
    CLXS_FEATURE_FDB_DEFAULT_AGE_TIME,
    CLXS_FEATURE_LAG_MEMBER_AUTO_UPDATE,
    CLXS_FEATURE_HASH_DEFAULT_L2_FIELD,
    CLXS_FEATURE_HOSTIF_ARP_REPLY_TRAP2CPU,
    CLXS_FEATURE_HOSTIF_DEF_TRAP_GROUP_QUEUE0,  /* default queue id, 0: use cpu_queue in hostif_cpu_reason_map, 1: use queue 0 */
    CLXS_FEATURE_DUPLICATE_CREATE_RETURN_EXISTS,
    CLXS_FEATURE_PORT_OVERSIZE_GREATER_THAN_MTU,
    CLXS_FEATURE_BFD_HW_ENABLE,
    CLXS_FEATURE_ACL_FORWARD_SPECTIAL_IP_PROTOCOL,
    CLXS_FEATURE_PORT_ECN_MARK_COUNT_USING_ACL,
    CLXS_FEATURE_TAM_INT_IFA2_MODIFY_DEVICE_ID,
    CLXS_FEATURE_TAM_INT_IFA2_QUEUE_CIR,
    CLXS_FEATURE_SAMPLEPACKET_GET_OUT_PORT,
    CLXS_FEATURE_LAST
}CLXS_FEATURE_TYPE_T;

typedef struct
{
    CLXS_FEATURE_TYPE_T type;
    char                name[CLXS_FEATURE_NAME_MAX_LEN];
    int32_t             cfg_value;
    int32_t             default_value;
} clxs_switch_feature_info_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern clxs_switch_feature_info_t _clxs_switch_feature_info[];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
int32_t clxs_switch_get_feature(
    _In_ const uint32_t unit,
    _In_ CLXS_FEATURE_TYPE_T feature_type);

clx_error_no_t
clxs_switch_get_feature_type(
    _In_ const char *ptr_feature_name,
    _Out_ uint32    *ptr_feature_type);

clx_error_no_t clxs_switch_feature_dump_cmd(
    _In_ const char                *tokens[]);


#endif /* __CLX_SAI_SWITCH_FEATURE_H__ */
