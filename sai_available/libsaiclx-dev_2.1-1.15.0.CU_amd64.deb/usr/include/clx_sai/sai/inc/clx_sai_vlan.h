/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_VLAN_H__)
#define __CLX_SAI_VLAN_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_VLAN_BC_LABEL  0x1
#define CLXS_VLAN_UMC_LABEL 0x2
#define CLXS_VLAN_UUC_LABEL 0x3
#define CLXS_VLAN_RSV_VID   4095

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef struct clxs_vlan_info_s
{
    uint32_t            flood_all_mgid;   /* flood all mgid, can be shared by uuc,umc and bc */
    uint32_t            flood_none_mgid;   /* flood none mgid, can be shared by uuc,umc and bc */
    uint32_t            flood_type[CLXS_SRV_BUM_TYPE_LAST]; /* 0 is for bc, 1 is for unknown mc and  2 is for unknown uc */
    uint32_t            flood_group_mgid[CLXS_SRV_BUM_TYPE_LAST]; /* 0 is for bc, 1 is for unknown mc and  2 is for unknown uc */
    uint32_t            mbr_cnt;
    sai_object_id_t     stp_oid;
    bool                mac_learn_disable;
    bool                igmp_snooping;
} clxs_vlan_info_t;

typedef struct clxs_vlan_mbr_info_s
{
    uint32_t            vid;        /* KEY */
    clx_gport_t         gport; /* KEY */
    bool                untag;
    sai_object_id_t     bridge_port_oid;
} clxs_vlan_mbr_info_t;

typedef struct clxs_vlan_mbr_cookie_s
{
    uint32_t            unit;
    uint16_t            vid;
    clx_gport_t         gport;
    sai_object_id_t     **pptr_oid;
} clxs_vlan_mbr_cookie_t;

typedef struct clxs_vlan_db_s
{
    clxs_vlan_info_t    vlan_info[CLXS_MAX_VLAN_NUM];
    uint32_t            valid_vlan_bmp[CLXS_VLAN_BMP_SIZE];
    util_lib_avl_head_t    *ptr_mbr_db;
    clx_semaphore_id_t  sema;
} clxs_vlan_db_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_vlan_api_t             vlan_api;


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_vlan_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_vlan_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_vlan_get_info(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint16_t                  *ptr_vid);

sai_status_t
clxs_vlan_set_flood_action(
    _In_ const uint32_t             unit,
    _In_ const clxs_srv_bum_type_t   type,
    _In_ const sai_packet_action_t  act);

sai_status_t
clxs_vlan_update_lag_member(
    _In_ const uint32_t                  unit,
    _In_ const sai_object_id_t           lag_oid,
    _In_ const sai_object_id_t           member_port_oid,
    _In_ const bool                      is_add);

sai_status_t
clxs_get_vlan_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_vlan_member_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_create_vlan_member(
    _Out_ sai_object_id_t         *vlan_member_id,
    _In_ sai_object_id_t          switch_id,
    _In_ uint32_t                 attr_count,
    _In_ const sai_attribute_t    *attr_list);

sai_status_t
clxs_remove_vlan_member(
    _In_ sai_object_id_t     vlan_member_id);

bool
clxs_vlan_is_valid(
    _In_ uint32_t unit,
    _In_ uint16_t vid);

clxs_vlan_db_t *
clxs_vlan_get_db(
    const uint32 unit);

#ifdef CLX_MAC2ME_TRAP_TO_CPU_EN
bool clxs_vlan_get_flood_type_none_status(_In_ uint32_t unit);
#endif
#endif /* __CLX_SAI_VLAN_H__ */
