/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_PORT_H__)
#define __CLX_SAI_PORT_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/

#define CLXS_PORT_MAX_PFC_COUNT        (8)
#define CLXS_PORT_UINT32_INVALID_VALUE (0xFFFFFFFF)
#define CLXS_PORT_SPEED_NAME_SIZE      (32)

#define CLXS_PORT_MC_QUEUE_NUM(__unit__, __port__)      (SHAL_IS_CPI_PORT(__unit__, __port__) ? 0 : CLXS_QUEUE_MC_NUM(__unit__))
#define CLXS_PORT_QUEUE_NUM(__unit__, __port__)         (CLXS_QUEUE_UC_NUM(__unit__) + CLXS_PORT_MC_QUEUE_NUM(__unit__, __port__))

#define CLXS_PORT_FOREACH(__unit__, __port__)                              \
    if ( __unit__ < CLXS_MAX_CHIP_NUM&&NULL != _clxs_port_db[__unit__].port_db_ptr)                 \
    for (__port__ = 0; __port__ < CLX_PORT_NUM; __port__++)    \
    if (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port)

#define CLXS_FRONT_PORT_FOREACH(__unit__, __port__)                              \
    if ( __unit__ < CLXS_MAX_CHIP_NUM&&NULL != _clxs_port_db[__unit__].port_db_ptr)                 \
    for (__port__ = 0; __port__ < CLX_PORT_NUM; __port__++)    \
    if ((CLX_PORT_CPU_PORT(unit) != __port__) && (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port))

#define CLXS_PORT_DB_PTR(__unit__, __port__)        ((clxs_port_property_t *)(_clxs_port_db[__unit__].port_db_ptr + __port__ ))
#define CLXS_PORT_MAP_PTR(__unit__, __port__)       ((clxs_port_map_t *)(_clxs_port_db[__unit__].port_map + __port__))

#define CLXS_PORT_QOSMAP_PTR(__unit__, __port__, __qosmap_type__)   \
                                                    ((clxs_port_qosmap_t *)(_clxs_port_db[__unit__].ptr_qosmap +  \
                                                        __port__*CLXS_QOSMAP_TYPES_MAX + __qosmap_type__))

#define CLXS_PORT_PFC_PTR(__unit__, __port__)       ((clxs_port_pfc_t *)(_clxs_port_db[__unit__].ptr_pfc + __port__))

#define CLXS_IS_PORT_VALID(__unit__, __port__)      ((__port__ < CLXS_MAX_PORT_NUM) && ((NULL == _clxs_port_db[__unit__].port_db_ptr) ? false : (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port)))

#define CHECK_PORT_ERR_RETURN(unit, port)  do {\
    CHECK_UNIT_ERR_RETURN(unit);    \
    if (!CLXS_IS_PORT_VALID(unit, port))\
    {\
        CLXS_LOG_ERR("Invalid port: unit=%d, port=%d", unit, port);\
        return SAI_STATUS_INVALID_PARAMETER;\
    }\
}while (0)

#define CLXS_PORT_LOCK(unit) \
        sai_osal_mutex_lock(_clxs_port_db[unit].sema);

#define CLXS_PORT_UNLOCK(unit) \
        sai_osal_mutex_unlock(_clxs_port_db[unit].sema);


#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_PORT_IP_COUNT_PTR(__unit__, __port__)  ((clxs_port_ip_counter_db_t *)(_clxs_port_db[__unit__].port_ip_count_info + __port__))
#endif

#define CLXS_REGISTER_PORT_STATS_NOTIFY_UPDATE(func)   do { clxs_port_stats_notify_update[__MODULE__] = func; } while (0)

#define CLXS_PORT_SET_INTF_GRP_LBL(__unit__, __intf_grp_lbl__, __meta_data__) \
do  \
{   \
    (__intf_grp_lbl__) &= ~(CLXS_ACL_USER_META_PORT_MAX(__unit__) << CLXS_ACL_USER_META_PORT_OFFSET(__unit__)); \
    (__intf_grp_lbl__) |= ((__meta_data__) << CLXS_ACL_USER_META_PORT_OFFSET(__unit__));                        \
} while (0)

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/

#if SAI_API_VERSION < SAI_VERSION(1,10,0)
/**
 * Before version 1.10, SAI did not support the 400G interface type.
 * However, the SDK does support CR8 and LR8.
 * Therefore, we need to extend the `sai_port_interface_type_t` here.
 */
typedef enum _ext_sai_port_interface_type_t
{
    /** Interface type CR8 */
    SAI_PORT_INTERFACE_TYPE_CR8 = SAI_PORT_INTERFACE_TYPE_XGMII+1,

    /** Interface type SR8 */
    SAI_PORT_INTERFACE_TYPE_SR8,

    /** Interface type KR8 */
    SAI_PORT_INTERFACE_TYPE_KR8,

    /** Interface type LR8 */
    SAI_PORT_INTERFACE_TYPE_LR8
} ext_sai_port_interface_type_t;
#endif

typedef enum
{
    CLXS_PORT_BREAKOUT_CAPABILITY_NONE       = 0,
    CLXS_PORT_BREAKOUT_CAPABILITY_TWO        = 1,
    CLXS_PORT_BREAKOUT_CAPABILITY_FOUR       = 2,
    CLXS_PORT_BREAKOUT_CAPABILITY_TWO_FOUR   = 3     /*TODO: clarify this purpose*/
} clxs_port_breakout_capability_t;

/* Consistent with the order of sec_cmd_showStormControlPortInfo */
typedef enum
{
    CLXS_STORM_CTRL_TYPE_BROADCAST = 0,
    CLXS_STORM_CTRL_TYPE_FLOOD,
    CLXS_STORM_CTRL_TYPE_MULTICAST,
    CLXS_STORM_CTRL_TYPE_RESERVE,
    CLXS_STORM_CTRL_TYPE_LAST
} clx_storm_ctrl_type_t;

typedef enum
{
    CLXS_PORT_POLICER_ACTION_ADD,
    CLXS_PORT_POLICER_ACTION_DELETE,
    CLXS_PORT_POLICER_ACTION_MODIFY,
    CLXS_PORT_POLICER_ACTION_LAST
} clxs_port_policer_action_t;
typedef enum
{
    CLXS_PORT_200G_SLOWDOWN_4x25G           = (1U << 0),//default
    CLXS_PORT_200G_SLOWDOWN_2x50G           = (1U << 1),
    CLXS_PORT_400G_SLOWDOWN_4x25G           = (1U << 2),//default
    CLXS_PORT_400G_SLOWDOWN_2x50G           = (1U << 3),
    CLXS_PORT_400G_SLOWDOWN_4x50G           = (1U << 4),//default
    CLXS_PORT_400G_SLOWDOWN_8x25G           = (1U << 5),
    CLXS_PORT_800G_SLOWDOWN_4x25G           = (1U << 6),
    CLXS_PORT_800G_SLOWDOWN_2x50G           = (1U << 7),
    CLXS_PORT_800G_SLOWDOWN_4x50G           = (1U << 8),
    CLXS_PORT_800G_SLOWDOWN_8x25G           = (1U << 9),
    CLXS_PORT_800G_SLOWDOWN_4x100G          = (1U << 10),
    CLXS_PORT_800G_SLOWDOWN_8x50G           = (1U << 11),
    CLXS_PORT_SPEED_SLOWDOWN_MODE_MAX
} clxs_port_speed_slowdown_mode_t;

typedef enum
{
    CLXS_PORT_PFC_INTERVAL_TYPE_DLD,    /* PFC Deadlock Detection */
    CLXS_PORT_PFC_INTERVAL_TYPE_DLR,    /* PFC Deadlock Recovery */
    CLXS_PORT_PFC_INTERVAL_TYPE_MAX
} clxs_port_pfc_interval_type_t;

#define CLXS_PORT_ATTR_FIELD_NUM        (SAI_PORT_ATTR_END - SAI_PORT_ATTR_START)
#define CLXS_PORT_ATTR_FIELD_BMP_WORDS  CLX_BITMAP_SIZE(CLXS_PORT_ATTR_FIELD_NUM)
typedef uint32_t clxs_port_attr_field_bmp_t[CLXS_PORT_ATTR_FIELD_BMP_WORDS];

typedef struct clxs_port_property_s
{
    uint8_t                    valid;
    clx_port_t                 clx_port;
    uint32_t                   lane_grp;    /* First lane number in the list */
    uint8_t                    lane_num;
    uint8_t                    lane_max_num;
    bool                       is_present;
    sai_object_id_t            wred_id;
    uint32_t                   flags;
    bool                       ext_phy;     /* Indicate that the port has a ext phy */
    uint32_t                   slot;
    uint32_t                   sample_rate;
    clxs_port_attr_field_bmp_t init_bitmap;
    clxs_port_attrs_t          attrs;
}clxs_port_property_t;

#define CLXS_PORT_UNIT_PORT_FLAG_PARENT    (1 << 0)

#ifdef CLX_PORT_IP_COUNT_USING_ACL
/*iptype for ip count*/
typedef enum
{
    CLXS_PORT_IPCOUNT_IPTYPE_IPV4,
    CLXS_PORT_IPCOUNT_IPTYPE_IPV6,
    CLXS_PORT_IPCOUNT_IPTYPE_MAX
} clxs_port_ipcount_iptype_t;

/*ip count db info*/
typedef struct clxs_port_ip_counter_db_s
{
    bool        valid;
    uint32_t    unit;
    uint32_t    port;
    uint32_t    ing_acl_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];	 /*ingress 2 mcast acl, 0-ipv4,1-ipv6*/
    uint32_t    egr_acl_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];	 /*egress 2 mcast acl, 0-ipv4,1-ipv6*/
    uint32_t    ing_counter_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];	 /*ingress 2 mcast counters, 0-ipv4,1-ipv6*/
    uint32_t    egr_counter_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];	 /*egress 2 mcast counters, 0-ipv4,1-ipv6*/
} clxs_port_ip_counter_db_t;
#endif

typedef struct clxs_port_map_s
{
    bool                        valid;
    uint32_t                    unit;
    uint32_t                    port;
    clx_port_t                  clx_port;
    uint32_t                    dst_idx;
    sai_object_id_t             obj;
    char                        hostif_name[SAI_HOSTIF_NAME_SIZE];
    uint32_t                    hostif_id;
    uint32_t                    ifindex;
} clxs_port_map_t;

typedef struct  clxs_port_link_s
{
    sai_pointer_t               callback_func;
    clx_semaphore_id_t          mutex;
    clx_semaphore_id_t          sema;
    clx_thread_id_t             thread_id;
    util_lib_list_t                *event_list;
} clxs_port_link_t;

typedef struct clxs_port_qosmap_s{
    sai_object_id_t qosmap_oid;
    uint32_t        hw_profile_id;
} clxs_port_qosmap_t;

typedef struct clxs_port_pfc_s{
    sai_port_priority_flow_control_mode_t   ctrl_mode;
    uint8_t                                 rx_enable;
    uint8_t                                 tx_enable;
    uint32_t                                queue_bitmap;
    sai_map_list_t                          dld_maplist;
    sai_map_list_t                          dlr_maplist;
} clxs_port_pfc_t;

typedef struct  clxs_port_db_s
{
    clxs_port_property_t       *port_db_ptr;
    clxs_port_link_t            port_link;
    clx_semaphore_id_t          sema;
    clx_semaphore_id_t          thread_sync;
    uint32_t                    port_count;
    clxs_port_map_t            *port_map;
#ifdef CLX_PORT_IP_COUNT_USING_ACL
    clxs_port_ip_counter_db_t  *port_ip_count_info;
    uint32_t                    acl_ing_group_id;
    uint32_t                    acl_egr_group_id;
#endif
    uint32_t                    ext_phy_type;
    clxs_port_qosmap_t         *ptr_qosmap;
    clxs_port_pfc_t            *ptr_pfc;
} clxs_port_db_t;

typedef struct  clxs_port_stat_pfc_db_s
{
    uint64_t                    rx_duration[CLXS_MAX_PORT_NUM][CLXS_PORT_MAX_PFC_COUNT];
    uint32_t                    interval_us;
    uint32                      thread_pri;
    clx_thread_id_t             thread_id;
    clx_semaphore_id_t          sema;
} clxs_port_stat_pfc_db_t;

typedef struct clxs_port_lag_common_attrs_s
{
    uint16_t        pvid;
}clxs_port_lag_common_attrs_t;

typedef struct clxs_port_speed_lane_map_s{
    clx_port_speed_t                   lane_speed;
    uint8_t                            port_lane_num;
    clx_port_speed_t                   target_speed;
    clxs_port_speed_slowdown_mode_t    mode;
    uint8_t                            speed_lane_num;
}clxs_port_speed_lane_map_t;

typedef struct clxs_port_interface_medium_type_table_s{
    int32_t           interface_type;
    clx_port_medium_t medium_type;
} clxs_port_interface_medium_type_table_t;

typedef struct _clxs_port_speed_map_t {
    uint32_t sai_speed;                 // SAI speed
    uint32_t lane_cnt;                  // Lane count
    clx_port_ability_speed_t sdk_speed; // SDK speed ability bitmap
} clxs_port_speed_map_t;

typedef sai_status_t (*clxs_port_stats_notify_update_fn)(
    _In_ const uint32                      unit,
    _In_ const uint32                      port,
    _In_ const clx_stat_port_t            *cnt_type,
    _In_ const uint32                      cnt_num,
    _In_ uint64                            *cnt);

#ifdef CLX_STORMCONTROL_VALUE0_USE_ACL
/**add policer type. If considering other protocol types
 *  in the future, they need to be added in these enumerations*/
typedef enum
{
    CLXS_PORT_BC_STC_PROTOCOL_DROP_ARP = 0,
    CLXS_PORT_BC_STC_PROTOCOL_DROP_DHCP,
    CLXS_PORT_BC_STC_PROTOCOL_DROP_MAX_NUM,
} clxs_port_bc_stc_protocol_drop_t;

typedef enum
{
    CLXS_PORT_UMC_STC_PROTOCOL_DROP_ND = 0,
    CLXS_PORT_UMC_STC_PROTOCOL_DROP_MAX_NUM,
} clxs_port_umc_stc_protocol_drop_t;

typedef enum
{
    CLXS_PORT_STORMCONTROL_TYPE_BC = 0,
    CLXS_PORT_STORMCONTROL_TYPE_UMC,
    CLXS_PORT_STORMCONTROL_TYPE_UUC,
    CLXS_PORT_STORMCONTROL_TYPE_MAX_NUM,
} clxs_port_stormcontrol_type_t;

typedef struct  clxs_port_stormcontrol_by_acl_db_s
{
    uint32_t                        acl_group_id_for_stormcontrol;
    uint32_t                        acl_entry_id_for_bc_stromcontrol[CLXS_ACL_UDF_PROFILE_NUM][CLX_CIA_CLASSIFY_KEY_LAST];
    uint32_t                        acl_entry_id_for_umc_stromcontrol[CLXS_ACL_UDF_PROFILE_NUM][CLX_CIA_CLASSIFY_KEY_LAST];
    uint32_t                        acl_entry_id_for_uuc_stromcontrol[CLXS_ACL_UDF_PROFILE_NUM][CLX_CIA_CLASSIFY_KEY_LAST];
    uint32_t                        acl_entry_id_bc_stc_protocol_drop[CLXS_PORT_BC_STC_PROTOCOL_DROP_MAX_NUM][CLXS_HOSTIF_MAX_ACL_ENTRY_PER_TRAP];
    uint32_t                        acl_entry_id_umc_stc_protocol_drop[CLXS_PORT_UMC_STC_PROTOCOL_DROP_MAX_NUM][CLXS_HOSTIF_MAX_ACL_ENTRY_PER_TRAP];
    uint32_t                        meter_id_for_port_stormcontrol[CLXS_MAX_PORT_NUM][CLXS_PORT_STORMCONTROL_TYPE_MAX_NUM];


} clxs_port_stormcontrol_by_acl_db_t;
extern clxs_port_stormcontrol_by_acl_db_t port_stormcontrol_by_acl[CLXS_MAX_CHIP_NUM];
#endif

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/

extern clxs_port_db_t _clxs_port_db[CLXS_MAX_CHIP_NUM];
extern const sai_port_api_t             port_api;
extern clxs_object_stats_capability_info_t port_stats_capability_info;
extern clxs_object_stats_capability_info_t port_pool_stats_capability_info;
extern clxs_port_stats_notify_update_fn clxs_port_stats_notify_update[CLXS_API_MAX];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/

sai_status_t
clxs_port_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_port_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_port_to_object(
    uint32_t            unit,
    uint32_t            port,
    sai_object_id_t     *ptr_object_id);

sai_status_t
clxs_port_register_callback(
    _In_ const uint32_t         unit,
    _In_ void                   *func);

uint32_t
clxs_port_get_unit_port_num(
    _In_ const uint32_t unit);

sai_status_t
clxs_port_get_port_num(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t
clxs_port_get_max_port_num(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t
clxs_port_get_port_list(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t
clxs_port_get_cpu_port(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t
clxs_port_get_tpid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const sai_switch_attr_t attr,
    _Out_ uint16_t * ptr_tpid);

sai_status_t
clxs_port_set_tpid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const sai_switch_attr_t attr,
    _In_ const uint16_t ptr_tpid);

sai_status_t
clxs_port_set_bind_egr_table(
    sai_object_id_t     port_object,
    uint32_t        intf_group_label,
    bool        is_add);

sai_status_t
clxs_port_get_port_map(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _Out_ clxs_port_map_t *ptr_port_map);

sai_status_t
clxs_port_update_port_map(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const char *port_name,
    _In_ const uint32_t hostif_id);

sai_status_t
clxs_port_update_lag_member(
    _In_ const sai_object_id_t              port_oid,
    _In_ const clxs_port_lag_common_attrs_t *attrs,
    _In_ const bool                         is_add);

sai_status_t
clxs_port_get_mirror_session_oid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ bool igr,
    _Out_ sai_object_id_t *ptr_mirrorsession_oid);

sai_status_t
clxs_get_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_port_pool_get_wred_profile_id(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _Out_ sai_object_id_t* wredId);

void
clxs_port_state_change_notify(
    _In_ uint32_t unit,
    _In_ uint32_t count,
    _In_ const sai_port_oper_status_notification_t *data);

void
clxs_port_fastlink_converge(
    _In_ sai_object_id_t port_id,
    _In_ sai_port_oper_status_t port_state);

clx_error_no_t
clxs_port_link_event_init(
    _In_ const uint32_t     unit);

sai_status_t
clxs_create_port(
    _Out_ sai_object_id_t *port_id,
    _In_ sai_object_id_t switch_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);

sai_status_t
clxs_remove_port(
    _In_ sai_object_id_t port_id);

sai_status_t
clxs_set_port_attribute(
    _In_ sai_object_id_t port_id,
    _In_ const sai_attribute_t *attr);

sai_status_t
clxs_get_port_attribute(
    _In_ sai_object_id_t port_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list);

sai_status_t
clxs_get_port_stats_ext(
    _In_ sai_object_id_t port_id,
    _In_ uint32_t number_of_counters,
    _In_ const sai_stat_id_t *counter_ids,
    _In_ sai_stats_mode_t mode,
    _Out_ uint64_t *counters);

sai_status_t
clxs_clear_port_stats(
    _In_ sai_object_id_t port_id,
    _In_ uint32_t number_of_counters,
    _In_ const sai_stat_id_t *counter_ids);

sai_status_t
clxs_port_get_name(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _Out_ char *ptr_name);

sai_status_t
clxs_port_set_interface_type(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t    interface_type);

sai_status_t
clxs_port_set_link_training(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const bool       link_training);

sai_status_t
clxs_port_set_media_type(
    _In_ const uint32_t    unit,
    _In_ const uint32_t    port,
    _In_ const int32_t     media_type);

sai_status_t
clxs_port_set_auto_neg(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ bool             port_an_status);

sai_status_t
clxs_port_set_speed(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const uint32_t   speed);

sai_status_t
clxs_port_set_loopback(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t    loopback);

sai_status_t
clxs_port_set_fec(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t   fec_mode);

sai_status_t
clxs_port_set_fec_ext(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t   fec_mode);

sai_status_t
clxs_port_set_admin(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const uint32_t   admin);

sai_status_t
clxs_port_get_auto_neg(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ bool          *port_autoneg);

sai_status_t
clxs_port_get_fec(
    _In_ const uint32_t       unit,
    _In_ const uint32_t       port,
    _Inout_ int32_t           *fec_mode);

sai_status_t
clxs_port_get_fec_ext(
    _In_ const uint32_t       unit,
    _In_ const uint32_t       port,
    _Inout_ int32_t           *fec_ext_mode);

sai_status_t
clxs_port_get_link_training(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ bool          *port_link_training);

sai_status_t
clxs_port_set_internal_loopback(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _In_ const int32_t    internal_loopback);

sai_status_t
clxs_port_get_admin(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ bool          *admin_mode);

sai_status_t
clxs_port_get_speed(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ uint32_t      *speed);

sai_status_t
clxs_port_get_interface_type(
    _In_ const uint32_t       unit,
    _In_ const uint32_t       port,
    _Inout_ int32_t           *interface_type);

sai_status_t
clxs_port_get_media_type(
    _In_ const uint32_t   unit,
    _In_ const uint32_t   port,
    _Inout_ int32_t       *media);

sai_status_t
clxs_port_get_def_config_from_hw(
    _In_ const uint32_t unit,
    _In_ const uint32_t port);

sai_status_t
clxs_port_set_pfc_action(
    _In_ uint32_t               unit,
    _In_ uint32_t               port,
    _In_ clx_tm_pfcwd_action_t  action);

sai_status_t
clxs_port_set_pfc_detect_time(
    _In_ uint32_t               unit,
    _In_ uint32_t               port,
    _In_ sai_map_list_t         maplist);

sai_status_t
clxs_port_set_pfc_recovery_time(
    _In_ uint32_t               unit,
    _In_ uint32_t               port,
    _In_ sai_map_list_t         maplist);

sai_status_t
clxs_port_set_switch_qos_map(
    _In_    uint32_t            unit,
    _In_    sai_qos_map_type_t  type,
    _In_    sai_object_id_t     qosmap_oid);

sai_status_t
clxs_port_get_pfc_rx_enable(
    _In_ uint32_t        unit,
    _In_ uint32_t        port,
    _In_ uint32_t        pg_id,
    _Out_ boolean         *rx_enable);

sai_status_t
clxs_port_get_pfc_tx_enable(
    _In_ uint32_t        unit,
    _In_ uint32_t        port,
    _In_ uint32_t        queue_id,
    _Out_ boolean         *tx_enable);

sai_status_t
clxs_port_update_pfc_map(
    _In_    uint32_t            unit,
    _In_    sai_qos_map_type_t  type,
    _In_    sai_object_id_t     qosmap_oid,
    _In_    sai_qos_map_list_t  qosmap_list);

sai_status_t
clxs_port_get_link(
    _In_ uint32_t           unit,
    _In_ uint32_t           port,
    _Out_ uint32_t         *ptr_link_status);

sai_status_t
clxs_port_set_def_vlan_id(
    _In_ uint32_t               unit,
    _In_ clx_port_t             clx_port,
    _In_ uint32_t               vid);

sai_status_t
clxs_port_get_def_vlan_id(
    _In_ uint32_t               unit,
    _In_ clx_port_t             clx_port,
    _Out_ uint32_t              *vid);

sai_status_t clxs_port_get_igr_buffer_profile(
    _In_ uint32_t           unit,
    _In_ uint32_t           port,
    _Out_ sai_object_id_t   *ptr_buf_prof_oid);

sai_status_t clxs_port_get_egr_buffer_profile(
    _In_ uint32_t           unit,
    _In_ uint32_t           port,
    _Out_ sai_object_id_t   *ptr_buf_prof_oid);

sai_status_t
clxs_port_set_pfc_interval(
    _In_ const uint32_t       unit,
    _In_ const uint32_t       port,
    _In_ const clxs_port_pfc_interval_type_t interval_type,
    _In_ const sai_map_list_t *ptr_maplist);

sai_status_t
clxs_port_get_pfc_dld_interval(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _Inout_ sai_map_list_t *ptr_maplist);

sai_status_t
clxs_port_get_pfc_dlr_interval(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _Inout_ sai_map_list_t *ptr_maplist);

sai_status_t
clxs_port_check_link_down(
    uint32_t                unit,
    clx_port_t              clx_port,
    bool                    *ptr_link_down);

sai_status_t
clxs_port_get_samplepacket_enable(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const bool     is_igr,
    _Out_ bool          *ptr_enable);

sai_status_t
clxs_port_get_ifindex(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _Out_ uint32_t *ptr_ifindex);

sai_status_t
clxs_port_get_egr_sample_rate(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _Out_ uint32_t *ptr_sample_rate);

sai_status_t
clxs_port_set_egr_sample_rate(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const uint32_t sample_rate);

uint8_t
clxs_port_get_qosmap_queue_tc(
    uint32_t                unit,
    uint32_t                port,
    uint32_t                queue);

#endif /* __CLX_SAI_PORT_H__ */
