/**
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 * File:    clxs_sai_ext_phy.h
 *
 * Brief:   This module defines ext phy interface
 *
 */


#ifndef __CLX_SAI_EXT_PHY_H__
#define __CLX_SAI_EXT_PHY_H__

#if CLX_PORT_EXT_PHY
#include <ext_phy.h>

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/

/**
 * @brief internal phy
 */
#define EXT_PHY_FEATURE_TYPE_INTERNAL_PHY   0x00000000

/**
 * @brief ext phy type 1
 */
#define EXT_PHY_FEATURE_TYPE_1              0x00000001

#define CLXS_LINE_CARD_SCAN_THREAD_PRI              (50)
#define CLXS_LINE_CARD_SCAN_THREAD_NAME             "LINE_CARD_SCAN"
#define CLXS_LINE_CARD_TEST_THREAD_NAME             "LINE_CARD_TEST"
#define CLXS_LINE_CARD_SCAN_THREAD_INTERVAL         (1000000)
#define CLXS_LINE_CARD_SCAN_THREAD_STACK_SIZE       (32 * 1024)
#define CLXS_LINE_CARD_SCAN_TAKE_SYNC_SEMA(unit, timeout)         \
    osal_semaphore_take(&clxs_line_card_scan[unit].sema, timeout)

#define CLXS_LINE_CARD_SCAN_GIVE_SYNC_SEMA(unit)                  \
    osal_semaphore_give(&clxs_line_card_scan[unit].sema);

#define EXT_PHY_MAX_SLOT_INIT_STATUS_HISTORY      100

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/

typedef struct  clxs_line_card_scan_s
{
    uint32_t                interval_us;
    clx_thread_id_t         thread_id;
    clx_semaphore_id_t      sema;
} clxs_line_card_scan_t;

typedef struct clxs_ext_phy_status_record_s
{
    ext_phy_init_status_t    status;
    struct tm                ts;
    bool                     valid;
} clxs_ext_phy_status_record_t;

typedef struct clxs_ext_phy_slot_info_s
{
    clxs_ext_phy_status_record_t*    history_status;
    int32_t     current_index;
} clxs_ext_phy_slot_info_t;

typedef int32_t (*ext_phy_api_query_f_p)(EXT_PHY_DRV_T**);

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/

extern EXT_PHY_DRV_T *clxs_ext_phy_func_vec;
extern clx_semaphore_id_t ext_phy_api_sema;
extern clxs_ext_phy_slot_info_t *clxs_ext_phy_slot_status_record;

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/

char* clxs_ext_phy_status_to_string(
    _In_ const ext_phy_init_status_t status);

// Macro for ext phy api call
#define EXT_PHY_API_CALL(type, func_name, ...) \
    ({ \
        sai_status_t ret_val = SAI_STATUS_SUCCESS; \
        osal_semaphore_take(&ext_phy_api_sema, CLX_SEMAPHORE_WAIT_FOREVER); \
        if (type == EXT_PHY_FEATURE_TYPE_1) { \
            if (clxs_ext_phy_func_vec->func_name) { \
                ret_val = clxs_ext_phy_func_vec->func_name(__VA_ARGS__); \
            } \
        } \
        osal_semaphore_give(&ext_phy_api_sema); \
        ret_val; \
    })

// Macro for ext phy port api call
#define EXT_PHY_PORT_API_CALL(ext_phy_type, func_name, port, ...) \
    ({ \
        sai_status_t ret_val = SAI_STATUS_SUCCESS; \
        osal_semaphore_take(&ext_phy_api_sema, CLX_SEMAPHORE_WAIT_FOREVER); \
        if (ext_phy_type == EXT_PHY_FEATURE_TYPE_1) { \
            if (clxs_ext_phy_func_vec->func_name) { \
                ext_phy_init_status_t port_status = EXT_PHY_NOT_PRESENT; \
                ret_val = clxs_ext_phy_func_vec->get_port_init_status(port, &port_status); \
                if (SAI_STATUS_SUCCESS != ret_val) { \
                    CLXS_LOG_ERR("Get ext phy port status failed: port=%d ret=%d!", port, ret_val); \
                } \
                else { \
                    if (EXT_PHY_INIT_SUCCESS == port_status) { \
                        ret_val = clxs_ext_phy_func_vec->func_name(port, __VA_ARGS__); \
                    } \
                    else { \
                        ret_val = SAI_STATUS_ITEM_NOT_FOUND; \
                        CLXS_LOG_INF("Invalid ext phy port status: port=%d port_status=%s ret=%d", \
                            port, clxs_ext_phy_status_to_string(port_status), ret_val); \
                    } \
                } \
            } \
        } \
        osal_semaphore_give(&ext_phy_api_sema); \
        ret_val; \
    })

sai_status_t
clxs_ext_phy_init(
    uint32_t    unit,
    uint32_t    type,
    const char*       json_file);

sai_status_t
clxs_ext_phy_deinit(
    uint32_t    unit,
    uint32_t    type);

sai_status_t
clxs_ext_phy_set_pre_shutdown(
    const uint32_t     unit,
    uint32_t    type);

sai_status_t
clxs_ext_phy_init_line_card_scan(
    const uint32_t    unit,
    uint32_t          type);

sai_status_t
clxs_ext_phy_deinit_line_card_scan(
    const uint32_t    unit);

uint32_t
clxs_ext_phy_fec_clx_to_ext_phy(
    const uint32_t    clxs_fec_mode);

uint32_t
clxs_ext_phy_fec_ext_phy_to_clx(
    const uint32_t    ext_phy_fec_mode);

#if SAI_API_VERSION >= SAI_VERSION(1,9,0)
int32_t
clxs_ext_phy_loopback_ext_phy_to_sai(
    const ext_phy_loopback_mode_t    ext_phy_loopback);

ext_phy_loopback_mode_t
clxs_ext_phy_loopback_sai_to_ext_phy(
    const int32_t sai_loopback_mode);
#endif

ext_phy_loopback_mode_t
clxs_ext_phy_internal_loopback_sai_to_ext_phy(
    const int32_t sai_internal_loopback_mode);

int32_t
clxs_ext_phy_internal_loopback_ext_phy_to_sai(
    const ext_phy_loopback_mode_t    ext_phy_loopback);

#endif
#endif /* End of __CLX_SAI_EXT_PHY_H__ */


