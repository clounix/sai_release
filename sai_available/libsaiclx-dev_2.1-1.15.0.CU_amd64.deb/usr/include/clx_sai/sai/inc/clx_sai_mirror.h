/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_MIRROR_H__)
#define __CLX_SAI_MIRROR_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_MIRROR_DB(_unit_) (_clxs_mirror_db[_unit_])

#define CLXS_MIRROR_LOCK(_unit_) \
    osal_semaphore_take(&(_clxs_mirror_db[_unit_]->sema), CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_MIRROR_UNLOCK(_unit_) \
    osal_semaphore_give(&(_clxs_mirror_db[_unit_]->sema));

/*******************************************************************************
 * Data Type Declarations 
 *******************************************************************************/
typedef struct clxs_mir_entry_s
{
    bool                        valid;
    clxs_mirror_session_attrs_t attr_info;
    uint32_t                    igr_session_id;
    uint32_t                    egr_session_id;
    bool                        igr_created;
    bool                        egr_created;
} clxs_mir_entry_t;

typedef struct
{
    uint32_t                igr_session_id_bmp;
    uint32_t                egr_session_id_bmp;
    clx_semaphore_id_t      sema;
    clxs_mir_entry_t        *ptr_mir_entry;
} clxs_mir_db_t;

/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern const sai_mirror_api_t           mirror_api;
extern clxs_mir_db_t *                  _clxs_mirror_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/ 
sai_status_t 
clxs_mirror_sync_session(
    _In_ uint32_t               unit,
    _In_ sai_object_id_t        mir_obj_idx,
    _In_ clx_mir_direct_t       dir,
    _Out_ uint32_t              *ptr_mir_session);

/* Get session id from mirror idx*/
sai_status_t 
clxs_mirror_get_session_id(
    _In_ uint32_t               unit,
    _In_ clx_mir_direct_t       dir,
    _In_ uint32_t               mir_idx,
    _Out_ sai_object_id_t       *ptr_mir_ses_obj_id);

sai_status_t 
clxs_mirror_init(
    uint32_t unit);

sai_status_t 
clxs_mirror_deinit(
    uint32_t unit);

sai_status_t 
clxs_mirror_get_sdk_session_id(
    _In_ sai_object_id_t    session_oid,
    _In_ clx_mir_direct_t   direction,
    _Inout_ uint32_t        *sdk_ses_id);

sai_status_t 
clxs_mirror_get_session_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t      *count);

clxs_mir_entry_t*
_clxs_mirror_get_session_entry(
    uint32_t            unit,
    uint32_t            mir_ses_id);

#endif