/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_HASH_H__)
#define __CLX_SAI_HASH_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_HASH_NUM              ((CLX_SWC_HSH_PKT_TYPE_LAST) * 2)

#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
#define MAX_SAI_HASH_FIELD            (SAI_NATIVE_HASH_FIELD_NONE)
#elif SAI_API_VERSION >= SAI_VERSION(1,5,0)
#define MAX_SAI_HASH_FIELD            (18)
#else
#define MAX_SAI_HASH_FIELD            (12)
#endif

#define CLXS_HASH_DB(__unit__)                  (_clxs_hash_db[__unit__])
#define CLXS_HASH_LOCK(__unit__)                osal_semaphore_take(&(_clxs_hash_db[__unit__].sema), CLX_SEMAPHORE_WAIT_FOREVER)
#define CLXS_HASH_UNLOCK(__unit__)              osal_semaphore_give(&(_clxs_hash_db[__unit__].sema))
#define CLXS_HASH(__unit__, __id__)             (_clxs_hash_db[__unit__].hash_info[__id__])
#define DEFAULT_ECMP_HASH_ID(__unit__)          (_clxs_hash_db[__unit__].default_ecmp_hash_id)
#define DEFAULT_LAG_HASH_ID(__unit__)           (_clxs_hash_db[__unit__].default_lag_hash_id)
#define DEFAULT_NVO3_HASH_ID(__unit__)          (_clxs_hash_db[__unit__].default_nvo3_hash_id)
/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef enum _clxs_sai_hash_type {
    CLXS_HASH_ECMP,
    CLXS_HASH_ECMP_IP4,
    CLXS_HASH_ECMP_IPINIP,
    CLXS_HASH_ECMP_IP6,
    CLXS_HASH_LAG,
    CLXS_HASH_LAG_IP4,
    CLXS_HASH_LAG_IPINIP,
    CLXS_HASH_LAG_IP6,
    CLXS_HASH_TYPE_LAST
} clxs_sai_hash_type_t;

typedef struct clxs_hash_info_s {
    bool                valid;
    bool                field[MAX_SAI_HASH_FIELD];
    bool                type[CLXS_HASH_TYPE_LAST];
}clxs_hash_info_t;

typedef struct clxs_hash_db_s {
    clxs_hash_info_t        hash_info[CLXS_HASH_NUM];
    sai_object_id_t         hash_type_to_idx_map[CLXS_HASH_TYPE_LAST];
    sai_object_id_t         default_ecmp_hash_id;
    sai_object_id_t         default_lag_hash_id;
    sai_object_id_t         default_nvo3_hash_id;
    clx_semaphore_id_t      sema;
}clxs_hash_db_t;

typedef enum
{
    CLXS_HASH_IP_ALL,
    CLXS_HASH_IP4,
    CLXS_HASH_IP6,
    CLXS_HASH_IP_LAST
} clxs_hash_ip_type_t;

typedef struct _clxs_hash_type {
    bool                    read_only;
    clx_swc_hsh_pkt_type_t  hash_type;
    clxs_hash_ip_type_t     ip_type;
} clxs_hash_type_t;

typedef struct _clxs_hash_key_map_t {
    uint32                  count;
    sai_native_hash_field_t sai_key;
    clx_swc_hsh_key_type_t  keys[8];
} clxs_hash_key_map_t;

typedef struct _clxs_hash_symmetric_key_map_t {
    uint32                  count;
    clx_swc_hsh_key_type_t  keys[10];
} clxs_hash_symmetric_key_map_t;
typedef enum
{
    CLXS_HASH_IPV4_HASH_KEY_MAP,
    CLXS_HASH_IPV6_HASH_KEY_MAP,
    CLXS_HASH_ALL_HASH_KEY_MAP
} clxs_hash_key_map_type_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_hash_api_t hash_api;
extern clxs_hash_db_t       _clxs_hash_db[CLXS_MAX_CHIP_NUM];
extern clxs_hash_type_t     _clxs_hash_type_to_sdk[CLXS_HASH_TYPE_LAST];
extern char                 *_clxs_hash_type_str[CLXS_HASH_TYPE_LAST];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t clxs_hash_get_enum_values_capability(
    _In_ uint32_t unit,
    _In_ sai_attr_id_t attr_id,
    _Inout_ sai_s32_list_t *enum_values_capability);

sai_status_t
clxs_get_hash_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_hash_get_id(
    _In_  sai_object_id_t       switch_id,
    _In_  sai_switch_attr_t     attr,
    _Out_ sai_object_id_t       *ptr_hash_id);

sai_status_t
clxs_hash_set_id(
    _In_ sai_object_id_t        switch_id,
    _In_  sai_switch_attr_t     attr,
    _In_ sai_object_id_t        hash_id);

sai_status_t
clxs_hash_get_default_nvo3_hash_id(
    _In_ uint32_t         unit,
    _Out_ sai_object_id_t *ptr_hash_id);

sai_status_t
clxs_hash_update(
    _In_ uint32_t       unit,
    _In_ clx_swc_hsh_pkt_type_t hash_type);

char *
clxs_swc_hash_type_to_str(
    _In_ clx_swc_hsh_pkt_type_t hash_type);

sai_status_t
clxs_hash_init(
    _In_ uint32_t               unit);

sai_status_t
clxs_hash_deinit(
    _In_ uint32_t               unit);

#endif /*__CLX_SAI_HASH_H__*/
