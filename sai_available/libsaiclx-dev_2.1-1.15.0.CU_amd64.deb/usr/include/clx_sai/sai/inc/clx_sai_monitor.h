/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_MONITOR_H__)
#define __CLX_SAI_MONITOR_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define SAI_RX_ERR_CNT_THRESHOLD            1000000
#define SAI_RX_ERR_CNT_ACCUMULATED_CYCLE    5
#define SAI_RX_DMA_BUF_LOW_THRESHOLD_PERCENT    0.02

#ifdef CLX_SWITCH_MONITOR
#define CLXS_SWITCH_MONITOR_STAT_CNT(__unit__)      clxs_switch_monitor[__unit__].dma_info_num
#define CLXS_SWITCH_MONITOR_DMA_INFO_PTR(__unit__, __chn__, __idx__)    \
                                ((clxs_monitor_dma_info_t *)(clxs_switch_monitor[__unit__].ptr_monitor_dma_info + \
                                    (__chn__*CLXS_SWITCH_MONITOR_STAT_CNT(__unit__) +__idx__ )))

/* System MMU buffer monitoring related macros */
#define CLXS_SWITCH_MONITOR_MMU_BLOCKING_THRESHOLD      (10)
#endif

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
#ifdef CLX_SWITCH_MONITOR
typedef struct  clxs_monitor_dma_info_s
{
    uint32  rch_avbl_gpd_no;
    uint32  rx_done;
} clxs_monitor_dma_info_t;

typedef enum {
    CLXS_MMU_STATUS_NORMAL = 0,     /* normal status */
    CLXS_MMU_STATUS_BLOCKING        /* blocking status */
} clxs_mmu_status_t;

typedef struct _clxs_monitor_buffer_usage_s
{
    clxs_mmu_status_t status;                    /* current MMU status */
    uint32_t blocking_cnt;                       /* blocking detection count */
    uint32_t last_usage;                         /* last cycle buffer usage */
    bool port_valid[CLX_PORT_NUM];             /* port valid status */
    uint64_t last_port_tx[CLX_PORT_NUM];         /* last cycle port tx counter */
    uint64_t last_pfc_out_total[CLX_PORT_NUM];   /* last cycle pfc out total counter */
} clxs_monitor_buffer_usage_t;

typedef struct  clxs_switch_monitor_s
{
    uint32_t                interval_us;
    clx_thread_id_t         thread_id;
    clx_semaphore_id_t      sema;
    clxs_monitor_dma_info_t *ptr_monitor_dma_info;
    uint32_t                dma_info_num;
    clxs_monitor_buffer_usage_t system_buf_monitor;  /* System MMU buffer usage monitor */
} clxs_switch_monitor_t;

#endif

typedef struct {
    uint32 cnt_single;
    uint32 cnt_double;
} demo_swc_cmd_trav_cookie_t;

#ifdef CLX_ECC_ERR_LOG
typedef struct clxs_ecc_error_cnt_s
{
    uint32_t        index;
    uint32_t        value;
} clxs_ecc_error_cnt_t;

typedef struct sai_ecc_err_info_s
{
    util_lib_list_t *single_correct_err_cnt_list;
    util_lib_list_t *single_uncorrect_err_cnt_list;
    util_lib_list_t *single_unreachable_err_cnt_list;
    util_lib_list_t *double_correct_err_cnt_list;
    util_lib_list_t *double_uncorrect_err_cnt_list;
    uint32_t     single_correct_err_total_cnt;
    uint32_t     single_uncorrect_err_total_cnt;
    uint32_t     single_unreachable_err_total_cnt;
    uint32_t     double_correct_err_total_cnt;
    uint32_t     double_uncorrect_err_total_cnt;
} sai_ecc_err_info_t;
#endif


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
#ifdef CLX_SWITCH_MONITOR
extern uint32_t monitor_dma_index;
extern clxs_switch_monitor_t clxs_switch_monitor[CLXS_MAX_CHIP_NUM];
#endif

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
#ifdef CLX_SWITCH_MONITOR
sai_status_t clxs_port_fault_log(
	    _In_ const uint32_t     unit,
	    _In_ const uint32_t     port,
        _In_ const uint32_t     fault);

sai_status_t clxs_switch_monitor_init(
    _In_ const uint32_t unit);

sai_status_t clxs_switch_monitor_deinit(
    _In_ const uint32_t unit);
#endif

#ifdef CLX_ECC_ERR_LOG
sai_status_t clxs_monitor_init_ecc_log(
    uint32_t unit);

sai_status_t clxs_monitor_deinit_ecc_log(
    uint32_t unit);
#endif

#if (SAI_API_VERSION >= SAI_VERSION(1,13,0) || defined(CLX_ENABLE_HEALTH_EVENT_EN))
typedef enum clxs_monitor_event_type_e
{
    CLXS_MONITOR_EVENT_PLL_ERR = CLX_SWC_HEALTH_LAST,
    CLXS_MONITOR_EVENT_TEMP_ERR,
    CLXS_MONITOR_EVENT_ECC_ERR,
    CLXS_MONITOR_EVENT_CPU_PORT_BLOCK,
    CLXS_MONITOR_EVENT_FRONT_PORT_BLOCK,
    CLXS_MONITOR_EVENT_MMU_BLOCK,
    CLXS_MONITOR_EVENT_LAST
} clxs_monitor_event_type_t;

/* Monitor callback function type */
typedef void (*clxs_monitor_callback_fn)(
    _In_ const uint32_t unit,
    _In_ const clx_swc_notify_event_t *event,
    _In_ void *cookie);

/* Register a callback function - will receive all event types */
sai_status_t clxs_monitor_register_callback(
    _In_ const uint32_t unit,
    _In_ clxs_monitor_callback_fn callback_fn);

/* Deregister a callback function */
sai_status_t clxs_monitor_deregister_callback(
    _In_ const uint32_t unit,
    _In_ clxs_monitor_callback_fn callback_fn);
#endif
#endif  /* __CLX_SAI_MONITOR_H__ */