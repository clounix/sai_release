/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_TAM_INT_H__)
#define __CLX_SAI_TAM_INT_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_TAM_INT_IFA2_DEFAULT_IP_PROTO  (0x83)
#define CLXS_TAM_INT_IFA2_DEFAULT_LNS       (0x01)
#define CLXS_TAM_INT_DEFAULT_SAMPLE_RATE    (1)
#define CLXS_SAI_TAM_INT_TYPE_START         (SAI_TAM_INT_TYPE_IOAM)
#define CLXS_SAI_TAM_INT_TYPE_MAX           (SAI_TAM_INT_TYPE_IFA1_TAILSTAMP + 1)

#define CLXS_TAM_INT_DB(__unit__)                   (g_clxs_tam_int_db[__unit__])
#define CLXS_SAI_TAM_INT_MAX_OBJ_NUM(__unit__)      (CLXS_TAM_IFA2_PROFILE_NUM(__unit__) + \
                                                        CLXS_TAM_IOAM_PROFILE_NUM(__unit__) + CLXS_TAM_INT2_PROFILE_NUM(__unit__)) 
#define CLXS_TAM_INT_IFA2_RX_QUEUE          (CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_28)


/*******************************************************************************
 * Data Type Declarations 
 *******************************************************************************/
typedef enum _clxs_tam_int_role_t
{
    CLXS_TAM_INT_ROLE_NONE = 0,
    CLXS_TAM_INT_ROLE_SOURCE,
    CLXS_TAM_INT_ROLE_TRANSIT,
    CLXS_TAM_INT_ROLE_SINK
} clxs_tam_int_role_t;

typedef enum _clxs_tam_int_int_mode_t
{
    CLXS_TAM_INT_INT_MODE_NONE = 0,
    CLXS_TAM_INT_INT_MODE_XD, 
    CLXS_TAM_INT_INT_MODE_MX, 
    CLXS_TAM_INT_INT_MODE_MD, 
    CLXS_TAM_INT_INT_MODE_LAST
} clxs_tam_int_int_mode_t;

typedef enum _clxs_tam_int_inline_mode_t
{
    CLXS_TAM_INT_INLINE_MODE_NONE = 0,
    CLXS_TAM_INT_INLINE_MODE_LIVE,  /*SAI_TAM_INT_ATTR_INLINE is true*/
    CLXS_TAM_INT_INLINE_MODE_CLONE, /*SAI_TAM_INT_ATTR_INLINE is false*/
    CLXS_TAM_INT_INLINE_MODE_LAST
} clxs_tam_int_inline_mode_t;

typedef enum _clxs_tam_int_type_t
{
    CLXS_TAM_INT_TYPE_NONE = 0,
    CLXS_TAM_INT_TYPE_IOAM,
    CLXS_TAM_INT_TYPE_IFA1,
    CLXS_TAM_INT_TYPE_IFA2,
    CLXS_TAM_INT_TYPE_INT_1,
    CLXS_TAM_INT_TYPE_INT_2,
    CLXS_TAM_INT_TYPE_DIRECT_EXPORT,
    CLXS_TAM_INT_TYPE_IFA1_TAILSTAMP,
    CLXS_TAM_INT_TYPE_MAX
} clxs_tam_int_type_t;

typedef struct _clxs_tam_int_info_t
{
    clxs_tam_int_int_mode_t     int_mode;           /* INT mode (xd,mx,md)*/
    clxs_tam_int_role_t         role;
    uint32_t                    sampling_rate;  /* get from sai sample rate module,set to sdk */
    clxs_tam_int_inline_mode_t  inline_mode;
} clxs_tam_int_info_t;

typedef struct _clxs_tam_int_obj_t
{
    sai_object_id_t         tam_int_oid;
    clxs_tam_int_attrs_t    attr_info;
    clxs_tam_int_info_t     tam_int_info;
    uint32_t                hw_profile_id;
    sai_object_id_t         binded_switch_oid;
    uint32_t                egress_acl_group_id;
    uint32_t                egress_acl_entry_id;
    uint32_t                egress_acl_cnt_id;
    uint32_t                netlink_profile_id;
} clxs_tam_int_obj_t;

typedef struct _clxs_tam_int_obj_pool_t
{
    uint32_t                size;
    uint32_t                count;
    clxs_tam_int_obj_t      *ptr_obj;
    uint32_t                *ptr_obj_valid;
    uint32_t                *ptr_hw_profile_bmp;
} clxs_tam_int_obj_pool_t;

typedef struct _clxs_tam_int_db_t
{
    clxs_tam_int_int_mode_t     int_mode;               /* INT mode (xd,mx,md)*/
    clxs_tam_int_inline_mode_t  inline_mode;
    uint64_t                    hop_cnt_zero_count;  /* hop_cnt_zero interrupt count for ifa2 */
    uint64_t                    ifa_max_len_exceed_count;  /* ifa_max_len_exceed interrupt count for ifa2 */
    clxs_tam_int_obj_pool_t     obj_pool[CLXS_SAI_TAM_INT_TYPE_MAX]; 
} clxs_tam_int_db_t;


/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern clxs_tam_int_db_t g_clxs_tam_int_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/ 
sai_status_t clxs_tam_int_deinit(
    _In_    const uint32_t  unit);

sai_status_t clxs_tam_int_init(
    _In_    const uint32_t  unit);

sai_status_t clxs_tam_int_set_mirror_session_id(
    _In_ const sai_object_id_t  tam_int_oid,
    _In_ const uint32_t         mir_session_id,
    _In_ const bool             bind);

char * clxs_tam_int_trans_inline_mode_to_str(
    _In_    const clxs_tam_int_inline_mode_t inline_mode);

char * clxs_tam_int_trans_int_mode_to_str(
    _In_    const clxs_tam_int_int_mode_t int_mode);

char * clxs_tam_int_trans_role_to_str(
    _In_    const clxs_tam_int_role_t role);

sai_status_t clxs_tam_int_update_port(
    _In_    const sai_object_id_t   tam_int_oid,
    _In_    const uint32_t          port,
    _In_    const bool              bind);

sai_status_t clxs_tam_int_update_switch(
    _In_    const sai_object_id_t   tam_int_oid,
    _In_    const uint32_t          unit,
    _In_    const bool              bind);

sai_status_t clxs_tam_int_update_sample_rate(
    _In_ const sai_object_id_t  tam_int_oid,
    _In_ uint32_t               sample_rate);

sai_status_t clxs_create_tam_int(
    _Out_   sai_object_id_t         *tam_int_id,
    _In_    sai_object_id_t         switch_id,
    _In_    uint32_t                attr_count,
    _In_    const sai_attribute_t   *attr_list);

sai_status_t clxs_get_tam_int_attribute(
    _In_    sai_object_id_t tam_int_id,
    _In_    uint32_t        attr_count,
    _Inout_ sai_attribute_t *attr_list);

sai_status_t clxs_remove_tam_int(
    _In_    sai_object_id_t tam_int_id);

sai_status_t clxs_set_tam_int_attribute(
    _In_    sai_object_id_t         tam_int_id,
    _In_    const sai_attribute_t   *attr);

sai_status_t clxs_tam_int_update_collector(
    _In_ const uint32_t                 unit,
    _In_ const sai_object_id_t          collector_oid);

sai_status_t clxs_tam_int_update_transport(
    _In_ const uint32_t                 unit,
    _In_ const sai_object_id_t          transport_oid);

sai_status_t clxs_tam_int_update_acl(
    _In_    const uint32_t          unit,
    _In_    const sai_object_id_t   acl_table_id);

sai_status_t clxs_tam_int_set_transport_egress_port(
    _In_ const uint32_t                 unit,
    _In_ const sai_object_id_t          tam_transport_oid,
    _In_ const clx_port_t               egr_port,
    _In_ const bool                     enable);

sai_status_t clxs_tam_int_get_l3_protocol(
    _In_ const sai_object_id_t      tam_int_oid,
    _Out_ uint8_t   *ptr_l3_protocol
);

#endif /*__CLX_SAI_TAM_INT_H__*/