/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_NEXTHOP_H__)
#define __CLX_SAI_NEXTHOP_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
 /* used in adj list, set void* high half 1 to avoid null checks */
#define U32_TO_PVOID(x)             ((void *)((char *)(1L << 32) + (uint32_t)(x)))
#define PVOID_TO_U32(x)             ((uint32_t)((char *)(x) - (char *)(1L << 32)))
#define INVALID_L3_ADJ_ID           (0xffffffff)
#define CLXS_NEXTHOP_ID_BMP_SIZE(__unit__)    (CLX_BITMAP_SIZE(CLXS_MAX_NEXTHOP_NUM(__unit__)))


#define CLXS_NEXTHOP_DB(unit)       (_clxs_nexthop_db[(unit)])
#define CLXS_NEXTHOP_LOCK(unit)     sai_osal_mutex_lock(_clxs_nexthop_db[(unit)]->sema)
#define CLXS_NEXTHOP_UNLOCK(unit)   sai_osal_mutex_unlock(_clxs_nexthop_db[(unit)]->sema)

#define CREATE_NEXTHOP  (1 << 0)
#define REMOVE_NEXTHOP  (1 << 1)
#define ADD_MACADDR     (1 << 2)
#define DEL_MACADDR     (1 << 3)

#define SET_TUNNEL_VNI          (1 << 0)
#define UNSET_TUNNEL_VNI        (1 << 1)
#define SET_TUNNEL_MAC          (1 << 2)
#define UPDATE_VRF_VNI          (1 << 3)
#define ADD_ROUTE               (1 << 4)
#define DELETE_ROUTE            (1 << 5)


/*******************************************************************************
 * Data Type Definitions
 *******************************************************************************/
typedef struct clxs_nexthop_vrf_adj_s
{
    uint32_t     vrf_id;
    uint32_t     vni;
    uint32_t     adj_id;
    uint32_t     refcnt;
} clxs_nexthop_vrf_adj_t;

typedef struct clxs_nexthop_tnl_map_adj_s
{
    uint32_t     adj_id;
    uint32_t     nexthop_id;
} clxs_nexthop_tnl_map_adj_t;

typedef struct clxs_nexthop_l2addr_s
{
    clx_bridge_domain_t     bdid;
    clx_mac_t               mac;
    clx_port_t              port;
    util_lib_list_t         *adj_id_list;
} clxs_nexthop_l2addr_t;

typedef struct clxs_nexthop_entry_s
{
    uint32_t                    nexthop_id;     /* index */
    clxs_next_hop_attrs_t       attr_info;
    uint32_t                    ref_cnt;
    bool                        invalid;
    #define CLXS_NEXTHOP_TUNNEL_VNI_CONFIGURED  (1<<0)
    #define CLXS_NEXTHOP_TUNNEL_MAC_CONFIGURED  (1<<1)
    #define CLXS_NEXTHOP_ARP_MAC_CONFIGURED     (1<<2)
    uint32_t                    flags;
    util_lib_list_t             *vrf_adj_list;   /* adj_id on each vrf, clxs_nexthop_vrf_adj_t */
} clxs_nexthop_entry_t;

/* module data base */
typedef struct clxs_nexthop_db_s
{
    util_lib_avl_head_t     *info_nexthops;             /*nexthop info avl, clxs_nexthop_entry_t*/
    util_lib_avl_head_t     *id_nexthops;               /*nexthop id avl, clxs_nexthop_entry_t*/
    util_lib_avl_head_t     *nh_l2addrs;                /*nexthop l2addr avl, clxs_nexthop_l2addr_t */
    util_lib_avl_head_t     *tnl_map_adjs;              /*nexthop adjid avl, it's only for tunnel encap, clxs_nexthop_tnl_map_adj_t*/
    uint32_t                default_vrf;
    uint32_t                *tnl_id_bmp;
    clx_semaphore_id_t      sema;
} clxs_nexthop_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_next_hop_api_t         nexthop_api;
extern clxs_nexthop_db_t     *_clxs_nexthop_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_nexthop_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthop_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthop_get_object(
    _In_    const uint32_t      unit,
    _In_    const uint32_t      adj_id,
    _Out_   sai_object_id_t     *ptr_next_hop_id);

sai_status_t
clxs_nexthop_get_info(
    _In_    const sai_object_id_t   next_hop_id,
    _In_    const uint32_t          vrf_id,
    _In_    const uint32_t          flags,
    _Out_   uint32_t                *ptr_unit,
    _Out_   uint32_t                *ptr_adj_id);

sai_status_t
clxs_nexthop_create_neighbor_adj(
    _In_ uint32_t unit,
    _In_ sai_object_id_t rif_oid,
    _In_ sai_ip_address_t ip_address,
    _In_ void *mac_addr,
    _Out_ uint32_t *ptr_adj_id);

sai_status_t
clxs_nexthop_remove_neighbor_adj(
    _In_ uint32_t unit,
    _In_ sai_object_id_t rif_oid,
    _In_ sai_ip_address_t ip_address);

sai_status_t
clxs_nexthop_set_neighbor_adj(
    _In_ uint32_t unit,
    _In_ sai_object_id_t rif_oid,
    _In_ sai_ip_address_t ip_address,
    _In_ void *mac_addr);

sai_status_t clxs_nexthop_update_l2_addr(
    _In_ const uint32_t              unit,
    _In_ const clx_l2_addr_t         *ptr_l2_addr,
    _In_ const uint32_t              reason);

void
clxs_nexthop_tunnel_map_encap_update(
    _In_    uint32_t    unit,
    _In_    uint32_t    vrf_id,
    _In_    uint32_t    vni);

void
clxs_nexthop_switch_vxlan_mac_update(
    _In_    uint32_t    unit);

sai_status_t clxs_nexthop_update_by_adj_id(
    _In_  uint32_t              unit,
    _In_  uint32_t              vrf_id,
    _In_  uint32_t              adj_id);

sai_status_t
clxs_nexthop_get_adj_id(
    _In_ uint32_t               unit,
    _In_ sai_object_id_t        rif_id,
    _In_ sai_ip_address_t       ip_address,
    _Out_ uint32_t              *out_adj_id);


#endif /* __CLX_SAI_NEXTHOP_H__ */
