/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_ACL_H__)
#define __CLX_SAI_ACL_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_ACL_USER_META_ROUTE_NEIGHBOR_DST_OFFSET    (1)

#define CLXS_ACL_STAGE_IGR                    (1 << 0)
#define CLXS_ACL_STAGE_EGR                    (1 << 1)

#define CLXS_ACL_GROUP_NUM_IGR                          (256)
#define CLXS_ACL_GROUP_NUM_EGR                          (256)
#define CLXS_ACL_RANGE_NUM                                  (CLX_CIA_RANGE_NUM)
/*should be bigger than (CLXS_ACL_TABLE_NUM_IGR +  CLXS_ACL_TABLE_NUM_EGR)*/
#define CLXS_ACL_GROUP_MEMBER_NUM         (16)

#define CLXS_ECN_INGRESS_ACL_GROUP_LABEL      0x6e
#define CLXS_ECN_INGRESS_ACL_GROUP_LABEL_MASK 0xffff

#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MIN             (200)
#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX             (600)
#else
#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX             (700)
#endif

#define CLXS_ACL_GROUP_MEMBER_PRIO_MIN                  (CLXS_ACL_ACTION_PRIO_USR_DEFINE_MIN)
#define CLXS_ACL_GROUP_MEMBER_PRIO_MAX                  (CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX)
#define CLXS_ACL_ENTRY_PRIO_MIN                         (0)
#define CLXS_ACL_ENTRY_PRIO_MAX                         (SHAL_ACL_ENTRY_MAX_PRIORITY)
#define CLXS_ACL_TABLE_FILED_NUM                        (SAI_ACL_TABLE_ATTR_FIELD_END - SAI_ACL_TABLE_ATTR_START)
#define CLXS_ACL_ENTRY_NUM                              (CLXS_ACL_GROUP_MEMBER_NUM * 1024)


#define CLXS_ACL_GROUP_PRIO_ICC         (0)
#define CLXS_ACL_GROUP_PRIO_COUNTER     (6)
#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_ACL_GROUP_PRIO_PORT_IP_COUNT     (1)
#endif

#define CLXS_ACL_ACTION_PRIO_POLICER    (15)
#define CLXS_ACL_ACTION_PRIO_ICC        (1)

#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_EGR_ACL_ACTION_PRIO_COUNTER	(7)
#define CLXS_ING_ACL_ACTION_PRIO_COUNTER	(15)
#endif

#define CLXS_ACL_GROUP_PRIO_ECN_MARKED_COUNT     (1)


#if SAI_API_VERSION >= SAI_VERSION(1, 4, 0)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_IPV6_AETH_DEFAULT       (56)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_AETH_DEFAULT            (57)
#endif
#define CLXS_ACL_UDF_PROFILE_ID_FOR_IPV6_TUNNEL_VNI         (58)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_IPV4_TUNNEL_VNI         (59)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_IPV6_FLOW_LABEL         (60)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_IPV4_ECN_COUNT          (61)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_IPV6_ECN_COUNT          (62)
#define CLXS_ACL_UDF_PROFILE_ID_DEFAULT                     (63)
#define CLXS_ACL_UDF_PROFILE_NUM                            (64)

#define CLXS_ACL_UDF_ECN_OFFSET                         (1)
#define CLXS_ACL_UDF_ECN_3                              (0x3)
#define CLXS_ACL_UDF_ECN_MASK                           (0x3)

#define CLXS_ACL_UDF_TAM_INT_IFA2_OFFSET                (9)
#define CLXS_ACL_UDF_TAM_INT_IFA2_MASK                  (0xFF)

#define CLXS_ACL_UDF_TUNNEL_VNI_OFFSET                  (8)
#define CLXS_ACL_UDF_IPV6_FLOW_LABEL_OFFSET             (1)
#if SAI_API_VERSION >= SAI_VERSION(1, 4, 0)
#define CLXS_ACL_UDF_AETH_OFFSET                        (12)
#define CLXS_ACL_UDF_BTH_OFFSET                         (0)
#define CLXS_ACL_IP_PROTO_UDP                           (0x11)
#endif
#define CLXS_ACL_UDF_TCP_FLAG_OFFSET                    (13)
#define CLXS_ACL_IP_PROTO_TCP                           (0x6)
#define CLXS_ACL_UDF_TCP_PROFILE_PKT_CNT                (14)
#define CLXS_ACL_UDF_PROFILE_PKT_CNT_FOR_INT            (16)

#define CLXS_ACL_INVALID_GROUP_ID                       (0xffffffff)
#define CLXS_ACL_INVALID_ENTRY_ID                       (0xffffffff)

#define CLXS_ACL_UDF_DEFAULT_ID_OFFSET                  (CLXS_ACL_UDF_TCP_FLAG_OFFSET)
#define CLXS_ACL_L4_HEADER_LEN                          (8)
#define CLXS_ACL_UDF_INFINI_BAND_LEN                    (16)
/*l3_da_grp_lbl value*/
#define CLXS_ROUTE_IP2ME_GROUP_LABEL                (0x800)
#define CLXS_ROUTE_IP2MESUB_GROUP_LABEL             (0x1000)

/*igr_cia_grp_lbl value*/
#define CLXS_ECMP_HASH_INGRESS_ACL_GROUP_LABEL                  (0x6f)
#define CLXS_ECMP_HASH_INGRESS_ACL_GROUP_LABEL_MASK             (0xffffffff)
#define CLXS_HOSTIF_TRAP_TYPE_LOW_PRI_UC_FLOW_LABEL             (0x70)
#define CLXS_HOSTIF_TRAP_TYPE_HIGH_PRI_UC_FLOW_LABEL            (0x71)
#define CLXS_HOSTIF_TRAP_TYPE_UC_FLOW_LABEL_MASK                (0xffffffff)

#define CLXS_ACL_TAM_INT_IFA2_GROUP_LABEL                       (0x72)
#define CLXS_ACL_TAM_INT_IFA2_GROUP_LABEL_MASK                (0xffffffff)

#define CLXS_ACL_INVALID_VALUE                          (0xFFFFFFFF)

#if SAI_API_VERSION >= SAI_VERSION(1, 11, 0)
#ifdef CLX_ECMP_PACKET_SPRAY_FUNC
#define CLXS_ACL_UDF_ROCE_BTH_RESERVED_OFFSET           (8)
#endif
#endif

#if SAI_API_VERSION >= SAI_VERSION(1, 12, 0)
#ifdef CLX_ACL_ACTION_SET_BTH_FIELDS
#define CLXS_ACL_UDF_BTH_OPCODE_IPV4_OFFSET_FROM_L2          (42)    //l2+ipv4+udp:14+20+8
#define CLXS_ACL_UDF_BTH_RESERVED_IPV4_OFFSET_FROM_L2        (46)    //l2+ipv4+udp+l4offset:14+20+8+4
#define CLXS_ACL_UDF_BTH_OPCODE_IPV6_OFFSET_FROM_L2          (62)    //l2+ipv4+udp:14+40+8
#endif
#endif

#define CLXS_ACL_UDF_PROF_BMP_FOREACH(_udf_prof_bmp_, _prof_idx_)                                              \
    for ((_prof_idx_) = 0; (_prof_idx_) < CLXS_ACL_UDF_PROFILE_NUM; (_prof_idx_)++)                           \
    if (UTIL_LIB_BMP_BIT_CHK((_udf_prof_bmp_), (_prof_idx_)))

#define CLXS_ACL_GET_GROUP_BIND_INFO_PTR(_ptr_bind_info_, _unit_, _stage_) \
            do                      \
            {                                                                                                           \
                if (SAI_ACL_STAGE_INGRESS == (_stage_))                                                               \
                {                                                                                                       \
                    (_ptr_bind_info_) = _clxs_acl_db[(_unit_)]->group_db.ptr_igr_bind_point_avl;                    \
                }                                                                                                       \
                else                                                                                                    \
                {                                                                                                       \
                    (_ptr_bind_info_) = _clxs_acl_db[(_unit_)]->group_db.ptr_egr_bind_point_avl;                    \
                }                                                                                                       \
            } while (0)

#define CLXS_ACL_GET_TABLE_INFO_PTR(_ptr_table_info_, _unit_, _stage_, _table_id_) \
            do                      \
            {                                                                                                             \
                if (SAI_ACL_STAGE_INGRESS == (_stage_))                                                                 \
                {                                                                                                         \
                    (_ptr_table_info_) = _clxs_acl_db[(_unit_)]->table_db.igr_table_info_arr + (CLXS_ACL_GET_ID(_table_id_));         \
                }                                                                                                         \
                else                                                                                                      \
                {                                                                                                         \
                    (_ptr_table_info_) = _clxs_acl_db[(_unit_)]->table_db.egr_table_info_arr + (CLXS_ACL_GET_ID(_table_id_));         \
                }                                                                                                         \
            } while (0)

#define CLXS_ACL_SET_PORT_LABEL(group_label, table_bmp) \
    do                       \
    {                                                                                                             \
        (group_label) &= ~(((1U << CLXS_ACL_USER_META_PORT_MAX(0)) - 1));                                                                             \
        (group_label) |= (((table_bmp)));                                                \
    } while (0)

#define CLXS_ACL_GET_GROUP_INFO_PTR(_ptr_group_info_, _unit_, _stage_, _group_id_) \
            do                      \
            {                                                                                                             \
                if (SAI_ACL_STAGE_INGRESS == (_stage_))                                                                 \
                {                                                                                                         \
                    (_ptr_group_info_) = _clxs_acl_db[(_unit_)]->group_db.igr_group_info_arr + (_group_id_);         \
                }                                                                                                         \
                else                                                                                                      \
                {                                                                                                         \
                    (_ptr_group_info_) = _clxs_acl_db[(_unit_)]->group_db.egr_group_info_arr + (_group_id_);         \
                }                                                                                                         \
            } while (0)

#define CLXS_ACL_TABLE_ATTR_FIELD_BMP_WORDS     CLX_BITMAP_SIZE(CLXS_ACL_TABLE_FILED_NUM)
#define CLXS_ACL_UDF_PROFILE_BMP_WORDS     CLX_BITMAP_SIZE(CLXS_ACL_UDF_PROFILE_NUM)

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef struct clxs_acl_udf_db_s
{
    uint32_t    udf_prof_bmp[CLXS_ACL_UDF_PROFILE_BMP_WORDS];
} clxs_acl_udf_db_t;

typedef enum
{
    CLXS_ACL_USER_META_PORT,
    CLXS_ACL_USER_META_FDB_DST,
    CLXS_ACL_USER_META_ROUTE_DST,
    CLXS_ACL_USER_META_NEIGHBOR_DST,
    CLXS_ACL_USER_META_ACL,
    CLXS_ACL_USER_META_ACL_LAST
} clxs_acl_user_meta_t;

typedef struct clxs_acl_table_attr_field_info_s
{
    sai_acl_table_attr_t    attr_id;
    uint32_t                attr_flag;
    uint32_t                attr_capability;//indicates attr_id supports ingress, egress, or both.
} clxs_acl_table_attr_field_info_t;

typedef struct clxs_acl_action_info_s
{
    sai_acl_action_type_t    type;
    uint32_t                 flags;//indicates action type supports ingress, egress, or both.
} clxs_acl_action_info_t;

typedef struct clxs_acl_range_db_s
{
    uint32_t    range_bmp;
    uint32_t    rsvd_range_id;
} clxs_acl_range_db_t;

typedef struct clxs_acl_bind_point_info_s
{
    sai_object_id_t    bind_point_obj;
    sai_object_id_t    acl_obj; /*acl table group obj or acl table obj*/
} clxs_acl_bind_point_info_t;

typedef uint32_t clxs_acl_table_attr_field_bmp_t[CLXS_ACL_TABLE_ATTR_FIELD_BMP_WORDS];

typedef struct clxs_acl_entry_node_s {
    uint32_t            entry_id;
    clxs_acl_entry_attrs_t    entry_attrs;
    uint32_t            table_id;
    uint32_t            prio;
    sai_object_id_t     samplepacket_obj_id;
    uint32_t            flags;
    boolean             admin_state;
    uint32_t            group_label;           // mark as has bind port or lag, if unbind, it is 0
    uint32_t            entry_num;             // the number of frame entries per user entry
    util_lib_list_t    *bindpoint_entry_list;  //clxs_acl_bindpoint_entry_info_t list
} clxs_acl_entry_info_t;

typedef struct clxs_acl_bindpoint_entry_info_s {
    uint32_t           entry_id;  // user entry id
    uint32_t           bp_entry_id;    // the head acl entry id of the different frame type acl entries
    sai_object_type_t  bind_type;
    union {
        uint32_t           unit;             // bind switch
        clx_port_bitmap_t  pbmp;             // bind port
        uint32_t           vlan;             // bind vlan
        uint32_t           rif_bd;           // bind rif
    }value;
    util_lib_list_t    *entry_list;      // clxs_acl_hw_entry_info_t list
} clxs_acl_bindpoint_entry_info_t;

typedef struct clxs_acl_table_info_s {
    uint32_t                          valid;
    uint32_t                          bind_point_type_bmp;
    uint32_t                          attached_bind_type_bmp;
    clxs_acl_table_attr_field_bmp_t   attr_field_bmp;
    sai_s32_list_t                    action_type_list;
    uint32_t                          clx_group_prio;
    uint32_t                          clx_action_prio;
    uint32_t                          entry_width;
    clx_cia_grp_prof_t                group_profile;
    bool                              tam_profile_valid;
    uint32_t                          tam_profile;
    util_lib_list_t                  *entry_list;  // user entry id list;
} clxs_acl_table_info_t;

typedef struct clxs_acl_entry_info_s
{
    uint32_t                table_id;
    uint32_t                entry_id;    // user entry id
    uint32_t                bp_entry_id;  // the head acl entry id of the different frame type acl entries
    uint32_t                hw_entry_id;  // the hw entry id
    boolean                 admin_state;  //the admin state of the entry, the same as the user entry
} clxs_acl_hw_entry_info_t;

typedef struct clxs_acl_group_info_s
{
    uint32_t                      valid;
    uint32_t                      bind_point_type_bmp;
    sai_acl_table_group_type_t    group_type;
    uint32_t                      member_cnt;
    uint32_t                      member[CLXS_ACL_GROUP_MEMBER_NUM];
    bool                          member_is_bind[CLXS_ACL_GROUP_MEMBER_NUM];
} clxs_acl_group_info_t;

typedef struct clxs_acl_group_db_s
{
    clxs_acl_group_info_t    igr_group_info_arr[CLXS_ACL_GROUP_NUM_IGR];
    clxs_acl_group_info_t    egr_group_info_arr[CLXS_ACL_GROUP_NUM_EGR];
    util_lib_avl_head_t      *ptr_igr_bind_point_avl;    /* clxs_acl_bind_point_info_t */
    util_lib_avl_head_t      *ptr_egr_bind_point_avl;    /* clxs_acl_bind_point_info_t */
} clxs_acl_group_db_t;

typedef struct clxs_acl_table_db_s
{
    clxs_acl_table_info_t *   igr_table_info_arr;
    clxs_acl_table_info_t *   egr_table_info_arr;
    uint32_t                igr_clx_group_prio_bmp;
    uint32_t                egr_clx_group_prio_bmp;
    uint32_t                igr_clx_action_prio_bmp;
    uint32_t                egr_clx_action_prio_bmp;
    clxs_acl_table_attr_field_bmp_t     field_capability_igr_bmp;
    clxs_acl_table_attr_field_bmp_t     field_capability_egr_bmp;
} clxs_acl_table_db_t;

#define CLXS_ACL_ENTRY_BMP_WORDS     CLX_BITMAP_SIZE(CLXS_ACL_ENTRY_NUM)
typedef uint32_t clxs_acl_entry_bmp_t[CLXS_ACL_ENTRY_BMP_WORDS];

typedef struct clxs_acl_entry_db_s
{
    clxs_acl_entry_bmp_t entry_bmp;
    clxs_acl_entry_info_t *  entry_info_arr;
    clxs_acl_hw_entry_info_t *  hw_entry_info_arr;
} clxs_acl_entry_db_t;


typedef struct clxs_acl_db_s
{
    clxs_acl_range_db_t    range_db;
    clxs_acl_udf_db_t      udf_db;
    clxs_acl_group_db_t    group_db;
    clxs_acl_table_db_t    table_db;
    clxs_acl_entry_db_t    entry_db;
} clxs_acl_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_acl_api_t              acl_api;
extern clxs_acl_db_t*                      _clxs_acl_db[CLXS_MAX_CHIP_NUM];
extern clxs_acl_table_attr_field_info_t    _clxs_acl_table_attr_field_info[];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_acl_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_acl_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_acl_get_switch_attr(
    _In_ const sai_object_key_t *ptr_key,
    _Inout_ sai_attribute_value_t *ptr_value,
    _In_ const sai_attr_id_t         attr_id);

sai_status_t
clxs_get_acl_entry_enum_values_capability(
    _In_ uint32_t unit,
    _In_ sai_attr_id_t attr_id,
    _Inout_ sai_s32_list_t *enum_values_capability);

sai_status_t
clxs_acl_set_bind_point(
	_In_ const uint32_t 				unit,
	_In_ const sai_acl_stage_t			stage,
	_In_ const sai_object_id_t			acl_object_id,
	_In_ const sai_object_id_t			bind_point_object_id);

sai_status_t
clxs_acl_set_grp_lbl_bind_info(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const sai_object_id_t acl_object_id,
    _In_ const sai_object_id_t bind_point_onject_id,
    _Inout_ uint32_t *ptr_group_label);

sai_status_t
clxs_acl_set_grp_lbl_user_meta(
    _In_ const uint32_t unit,
    _In_ const clxs_acl_user_meta_t user_meta_type,
    _In_ const uint32_t user_meta,
    _Inout_ uint32_t *ptr_group_label);

sai_status_t
clxs_acl_add_udf_key_profile(
    _In_ const uint32_t unit,
    _In_ const uint32_t prof_id,
    _In_ const clx_cia_pkt_format_t *ptr_pkt_format,
    _In_ const clx_cia_udf_prof_t *ptr_profile);

sai_status_t
clxs_acl_del_udf_key_profile(
    _In_ const uint32_t unit,
    _In_ const uint32_t prof_id);

sai_status_t
clxs_acl_update_udf_key_profile(
    _In_ const uint32_t unit,
    _In_ const clx_cia_udf_prof_t *ptr_profile);

sai_status_t
clxs_acl_update_entry_sampling_rate(
    _In_ const sai_object_id_t entry_object_id,
    _In_ const uint32_t sampling_rate);

sai_status_t
clxs_get_acl_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_acl_range_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_acl_get_bind_acl_obj_by_bind_point(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const sai_object_id_t  bind_obj,
    _Out_ sai_object_id_t *ptr_aclobj);

sai_status_t
clxs_acl_get_udf_info(
    _In_ uint32_t unit,
    _Inout_ clxs_acl_udf_db_t* ptr_udfInfo
);

sai_status_t
clxs_acl_object_type_to_bind_type(
    _In_ const sai_object_type_t obj_type,
    _Out_ sai_acl_bind_point_type_t *bind_point_type);

sai_status_t
clxs_acl_table_add_entry(
    _In_ const uint32_t           unit,
    _In_ const uint32_t           table_id,
    _In_ const sai_acl_stage_t   stage,
    _In_ const uint32_t           entry_id);

sai_status_t
clxs_acl_update_table_tam_int(
    _In_ const sai_object_id_t acl_object_id,
    _In_ const uint32_t        profile_id,
    _In_ const bool            enable);

sai_status_t
clxs_acl_talbe_is_group_member(
    _In_ const sai_object_id_t acl_group_id,
    _In_ const sai_object_id_t acl_table_id);

sai_status_t
clxs_acl_get_policer_stats(
    _In_  uint32_t          unit,
    _In_ sai_object_id_t    policer_id,
    _Out_ uint64_t          stat[6]);

sai_status_t
clxs_acl_clear_policer_stats(
    _In_  uint32_t          unit,
    _In_ sai_object_id_t    policer_id);

#endif
