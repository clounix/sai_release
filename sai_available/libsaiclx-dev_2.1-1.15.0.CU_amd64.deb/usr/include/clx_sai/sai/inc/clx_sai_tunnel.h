/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_TUNNEL_H__)
#define __CLX_SAI_TUNNEL_H__


/*******************************************************************************
* Macro Definitions
 *******************************************************************************/
#define CLXS_TNL_DB(__unit__)                ptr_clxs_tnl_db[(__unit__)]

#if SAI_API_VERSION >= SAI_VERSION(1,9,1)
    #define CLXS_MAX_TUNNEL_TYPES_NUM (SAI_TUNNEL_TYPE_NVGRE + 1)
#elif SAI_API_VERSION >= SAI_VERSION(1,7,3)
    #define CLXS_MAX_TUNNEL_TYPES_NUM (SAI_TUNNEL_TYPE_MPLS + 1)
#endif

#define CLXS_MAX_TUNNEL_MAP_NUM (8192)
#define CLXS_MAX_TUNNEL_DECAP_NUM (8192)

#define CLXS_TNL_LOCK(__unit__)                                  \
    sai_osal_mutex_lock(CLXS_TNL_DB(__unit__)->tnl_sema)
#define CLXS_TNL_UNLOCK(__unit__)                                \
    sai_osal_mutex_unlock(CLXS_TNL_DB(__unit__)->tnl_sema)

#define CLXS_TUNNEL_QOSMAP_PROF_INDEX_BASE        (CLXS_MAX_PORT_NUM)
#define CLXS_TNL_ID_BMP_SIZE(__unit__)    (CLX_BITMAP_SIZE(CLXS_MAX_TUNNEL_NUM(__unit__)))
#define CLXS_TNL_MAP_ID_BMP_SIZE    (CLX_BITMAP_SIZE(CLXS_MAX_TUNNEL_MAP_NUM))
#define CLXS_TNL_DECAP_ID_BMP_SIZE    (CLX_BITMAP_SIZE(CLXS_MAX_TUNNEL_DECAP_NUM))
#define CLXS_TNL_FOREACH(__unit__, __tnl_id__) \
        UTIL_LIB_BMP_BIT_FOREACH(CLXS_TNL_DB(__unit__)->ptr_tnl_id_bmp, (__tnl_id__), CLXS_TNL_ID_BMP_SIZE(__unit__))
#define CLXS_TNL_MAP_FOREACH(__unit__, __tnl_map_id__) \
        UTIL_LIB_BMP_BIT_FOREACH(CLXS_TNL_DB(__unit__)->ptr_tnl_map_id_bmp, (__tnl_map_id__), CLXS_TNL_MAP_ID_BMP_SIZE)        

/*******************************************************************************
* Data Type Declarations
 *******************************************************************************/
typedef struct clxs_tnl_map_entry_s
{
    uint32 map_entry_id;/*key*/
    clxs_tunnel_map_entry_attrs_t attr_info;
} clxs_tnl_map_entry_t;

typedef struct clxs_tnl_map_s
{
    uint32 map_id;  /* key*/
    util_lib_list_t  *ptr_map_entry_list;
    uint32 next_map_entry_id;
    clxs_tunnel_map_attrs_t attr_info;
} clxs_tnl_map_t;

typedef struct clxs_tnl_encap_entry_s
{
    clx_tnl_info_t key;/*encap dir*/
    uint32 tnl_gport;
    sai_object_id_t underlay_vrf_oid;
    uint32 ref_cnt;
} clxs_tnl_encap_entry_t;

typedef struct clxs_tnl_decap_entry_s
{
    uint32 decap_id;
    clx_tnl_info_t  key;/*encap dir*/
    uint32 tnl_gport;
    clxs_tunnel_term_table_entry_attrs_t attr_info;
} clxs_tnl_decap_entry_t;

#define VNI_ASSIGNED (1 << 0)
typedef struct clxs_tnl_associated_nexthop_s
{
    uint32_t nexthop_id; /*key*/
    sai_ip_address_t endpoint_ip;
    uint32_t vni;
    clx_port_t tnl_gport;
    uint32_t flags;
} clxs_tnl_associated_nexthop_t;

/*if  added vni assigned nexthop tunnel, and the vni not
   in our maps create it and add segService with invalid
   bdid or rif_id, if map entry added later, cover it. with
   vrf/bdid/rif_id valid. if map entry removed, search from
   vni assigned nexthop_tunnel, if still exist, renew the
   seg, or delete it*/
typedef struct clxs_tnl_nexthop_vni_map_s
{
    clx_port_t tnl_gport;    /*key*/
    uint32_t vni;       /*key*/
    uint32_t vrf_id;
    uint32_t bdid;
    uint32_t l3_intf_id;
    uint32_t vni_assigned_ref_cnt;
} clxs_tnl_nextop_vni_map_t;

typedef struct clxs_tnl_entry_s
{
    uint32 tnl_id;/*key*/
    clxs_tunnel_attrs_t attr_info;

    util_lib_list_t *ptr_associated_nexthop_list;
    util_lib_list_t *ptr_vni_map_list;
    util_lib_list_t *ptr_decap_list;
    util_lib_list_t *ptr_encap_list;
    uint32_t *ptr_decap_id_bmp;

    sai_object_id_t qosmap_oid[CLXS_QOSMAP_TYPES_MAX];
    uint32 hw_profile_id[CLXS_QOSMAP_TYPES_MAX];
    bool learn;
} clxs_tnl_entry_t;

#if (SAI_API_VERSION >= SAI_VERSION(1,7,3))
typedef struct
{
    bool is_valid;
    clxs_switch_tunnel_attrs_t attr_info;
} clxs_switch_tnl_attr_t;
#endif

typedef struct
{
    clxs_tnl_entry_t **ptr_tnl_table;
    uint32_t *ptr_tnl_id_bmp;
    clxs_tnl_map_t **ptr_tnl_map_table; 
    uint32_t *ptr_tnl_map_id_bmp;
    util_lib_avl_head_t *ptr_nvo3_output;
    util_lib_avl_head_t *ptr_tnl_adj_map;
    util_lib_avl_head_t *ptr_dip_map;
    util_lib_avl_head_t *ptr_tnl_gport_map;
    uint32 *ptr_bdid_2_intfid;
#if (SAI_API_VERSION >= SAI_VERSION(1,7,3))
    clxs_switch_tnl_attr_t *ptr_switch_tunnel;
#endif
    clx_semaphore_id_t  tnl_sema;
} clxs_tnl_db_t;

typedef struct clxs_tnl_nvo3_adj_output_s
{
    uint32 l3_adj_id;
    uint32 nvo3_adj_id;
} clxs_tnl_nvo3_adj_output_t;

typedef struct clxs_tnl_nvo3_ecmp_output_s
{
    uint32 grp_id;
    uint32 nvo3_grp_id;
    util_lib_list_t* grp_members;/*clxs_tnl_nvo3_adj_output_t*/
    /*This adj id is selected for l2mc*/
    uint32 selected_nvo3_adj;
} clxs_tnl_nvo3_ecmp_output_t;

typedef struct {
    clx_nhp_type_t type;
    uint32 refcnt;
    union {
        clxs_tnl_nvo3_adj_output_t adj;
        clxs_tnl_nvo3_ecmp_output_t ecmp;
    } output;
} clxs_tnl_nvo3_output_entry_t;

typedef struct clxs_tnl_dip_map_s
{
    uint32 vrf_id;
    sai_ip_address_t addr;
    sai_ip_address_t mask;
    uint32 refcnt;
    clxs_tnl_nvo3_output_entry_t *nvo3_output;
} clxs_tnl_dip_map_t;

typedef struct clxs_tnl_gport_map_s
{
    clx_port_t tnl_gport;/* key*/
    uint32 tnl_id;
    sai_ip_address_t src_ip;/*encap dir*/
    sai_ip_address_t dst_ip;
} clxs_tnl_gport_map_t;
typedef struct clxs_tnl_adj_data_s
{
    uint32 nvo3_adj_id;
} clxs_tnl_adj_data_t;

typedef struct clxs_tnl_adj_map_s
{
    uint32 adj_id; /*key*/
    util_lib_list_t *nvo3_adj_list; /*clxs_tnl_adj_data_t */
} clxs_tnl_adj_map_t;

/*******************************************************************************
* Global Variable Declarations
 *******************************************************************************/
extern const sai_tunnel_api_t tunnel_api;
extern clxs_object_stats_capability_info_t tunnel_stats_capability_info;
extern clxs_tnl_db_t *ptr_clxs_tnl_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
* Function Declarations
 *******************************************************************************/
sai_status_t
clxs_tunnel_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_tunnel_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_tunnel_create_fdb_gport(
    _In_ uint32_t unit,
    _In_ const sai_object_id_t tnl_oid,
    _In_ const sai_ip_address_t *ptr_dip,
    _Out_ clx_port_t *ptr_gport);

sai_status_t
clxs_tunnel_remove_fdb_gport(
    _In_ uint32_t unit,
    _In_ const sai_object_id_t tnl_oid,
    _In_ const sai_ip_address_t *ptr_dip,
    _In_ clx_port_t gport);

sai_status_t
clxs_tunnel_get_tunnel_port_vni(
    _In_ sai_object_id_t tunnel_id,
    _In_ uint32_t vrf_id,
    _In_ sai_ip_address_t ipaddr,
    _Out_ clx_port_t *port,
    _Out_ uint32_t *vni,
    _Out_ uint32_t *l3_intf_id);

sai_status_t
clxs_tunnel_add_nexthop_tunnel(
    uint32 unit,
    uint32 next_hop_id,
    sai_object_id_t  tunnel_oid,
    sai_ip_address_t endpoint_ip,
    uint32 tunnel_vni,
    uint32 vni_configured);

sai_status_t
clxs_tunnel_remove_nexthop_tunnel(
    uint32 unit, uint32 next_hop_id,
    sai_object_id_t tunnel_oid,
    sai_ip_address_t endpoint_ip,
    uint32 tunnel_vni,
    uint32 vni_configured);

sai_status_t
clxs_tunnel_update_nexthop_tunnel_vni(
    uint32 unit,
    sai_object_id_t tnl_oid,
    uint32 next_hop_id,
    uint32 tunnel_vni);

sai_status_t
clxs_get_tunnel_port_list(
    _In_ const sai_object_id_t tunnel_id,
    _Out_ uint32_t *unit,
    _Out_ clx_port_t port_list[CLX_PORT_NUM],
    _Out_ uint32_t *pcount);

bool
clxs_tunnel_is_vxlan(
    _In_ sai_object_id_t tunnel_id);

sai_status_t
clxs_tunnel_get_object(
    _In_ const uint32 unit,
    _In_ const clx_port_t tnl_gport,
    _Out_ sai_object_id_t* ptr_tnl_oid,
    _Out_ sai_ip_address_t* ptr_dip);

sai_status_t 
clxs_tunnel_get_gport(
    _In_ const uint32 unit,
    _In_ uint32 tnl_id,
    _Out_ clx_gport_t *gport);

sai_status_t
clxs_tunnel_update_host(
    uint32 unit,
    clx_l3_host_t* host_info);

sai_status_t
clxs_tunnel_update_by_adj(
    uint32 unit,
    uint32 l3_adj_id);

sai_status_t
clxs_tunnel_update_route(
    uint32 unit,
    clx_l3_route_t* route_info);

sai_status_t
clxs_tunnel_update_by_ecmp_grp(
    uint32 unit,
    uint32 ecmp_grp_id,
    boolean add,
    clx_l3_ecmp_path_t *path_info);

sai_status_t
clxs_set_tunnel_port_lrn(
    _In_ const uint32_t   unit,
    _In_ const sai_object_id_t tunnel_id,
    _In_ const bool  lrn_en,
    _In_ const bool  fwd,
    _In_ const bool  to_cpu);

sai_status_t
clxs_set_tunnel_port_admin(
    _In_ const uint32_t   unit,
    _In_ const sai_object_id_t tunnel_id,
    _In_ const bool  admin);

sai_status_t
clxs_tunnel_update_vlan_bum(
    _In_ uint32_t unit,
    _In_ bool act,
    _In_ uint16_t vid,
    _In_ clx_gport_t gport);

sai_status_t
clxs_get_tunnel_map_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_term_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_p2mp_term_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_map_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#if SAI_API_VERSION >= SAI_VERSION(1,7,3)
sai_status_t
clxs_tunnel_get_switch_tunnel_attr(
    _In_ uint32 unit,
    _In_ sai_tunnel_type_t switch_tnl_type,
    _In_  sai_switch_tunnel_attr_t id,
    _Out_ sai_attribute_value_t *ptr_val);

sai_status_t
 clxs_tunnel_set_switch_tunnel_attr(
    _In_ uint32 unit,
    _In_ sai_tunnel_type_t switch_tnl_type,
    _In_  sai_switch_tunnel_attr_t id,
    _In_  const sai_attribute_value_t *ptr_val);

sai_status_t
clxs_tunnel_create_switch_tunnel(
    _In_ uint32 unit,
    _In_ sai_tunnel_type_t tunnel_type,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);

sai_status_t
clxs_tunnel_remove_switch_tunnel(
    _In_ uint32 unit,
    _In_ sai_tunnel_type_t tunnel_type);

sai_status_t
clxs_tunnel_get_switch_tunnel(
    _In_ uint32 unit,
    _In_ sai_tunnel_type_t tunnel_type,
    _Out_ sai_object_id_t *ptr_switch_tunnel_id);

sai_status_t
clxs_tunnel_set_switch_tunnel(
    _In_ uint32 unit,
    _In_ sai_object_id_t switch_tunnel_id);
#endif

sai_status_t
clxs_create_tunnel(
    _Out_ sai_object_id_t *ptr_tunnel_id,
    _In_ sai_object_id_t switch_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);
sai_status_t 
clxs_remove_tunnel(
    _In_ sai_object_id_t tunnel_id);

sai_status_t
clxs_set_tunnel_attribute(
    _In_ sai_object_id_t tunnel_id,
    _In_ const sai_attribute_t *ptr_attr);

sai_status_t
clxs_get_tunnel_attribute(
    _In_ sai_object_id_t tunnel_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *ptr_attr_list);

#endif /* __CLX_SAI_TUNNEL_H__ */
