/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SDK_H__)
#define __CLX_SDK_H__
#include <saitypes.h>
#ifdef CLX_SDK
#include <clx/clx_types.h>
#include <clx/clx_module.h>
#include <clx/clx_init.h>
#include <clx/clx_error.h>
#include <clx/clx_lag.h>
#include <clx/clx_cia.h>
#include <clx/clx_swc.h>
#include <clx/clx_tnl.h>
#include <clx/clx_netif.h>
#include <clx/clx_pkt.h>
#include <clx/clx_l3.h>
#include <clx/clx_stk.h>
#include <clx/clx_sec.h>
#include <clx/clx_mpls.h>
#include <clx/clx_port.h>
#include <clx/clx_l2.h>
#include <clx/clx_stp.h>
#include <clx/clx_ver.h>
#include <clx/clx_mir.h>
#include <clx/clx_cfg.h>
#include <clx/clx_meter.h>
#include <clx/clx_vlan.h>
#include <clx/clx_tm.h>
#include <clx/clx_stat.h>
#include <clx/clx_qos.h>
#include <clx/clx_telm.h>
#include <tob/tob.h>
#include <hal/hal.h>
#include <hal/hal_io.h>
#include <hal/hal_obj.h>
#include <util/lib/util_lib_list.h>
#include <util/lib/util_lib_avl.h>
#include <util/lib/util_lib_crc.h>
#include <util/lib/util_lib_hsh.h>
#include <util/lib/util_lib_bit.h>
#include <util/lib/util_lib_bmp.h>
#include <osal/osal_types.h>
#include <osal/osal.h>
#include <osal/osal_lib.h>
#include <osal/osal_dma.h>
#endif /*CLX_SDK*/


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_MAX_CHIP_NUM                   (CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM)
#define CLXS_MAX_PORT_NUM                   (CLX_PORT_NUM)
#define CLXS_MAX_VLAN_NUM                   (4096)
#define CLXS_ACL_UDF_PROFILE_NUM            (64)
#define CLXS_HOSTIF_MAX_ACL_ENTRY_PER_TRAP  (12)
#define CLXS_DMA_MEM_SIZE                   (4*1024*1024)
#define CLXS_DFLT_VLAN                      (1)
#define CLXS_DFLT_STP                       (0)
#define CLXS_VLAN_BMP_SIZE                  (CLX_BITMAP_SIZE(CLXS_MAX_VLAN_NUM))

#define UNUSED(x)                           (void)(x)
#define CLXS_IS_UNIT_VALID(__unit__)        ((__unit__ >= CLXS_MAX_CHIP_NUM) ? false : clxs_switch_get_unit_inited(__unit__))
#define CLXS_CHECK_PTR(__ptr__, __msg__) \
    do                         \
    {                                                              \
        if (NULL == __ptr__)                                       \
        {                                                          \
            CLXS_LOG_ERR("%s", __msg__);                \
            return SAI_STATUS_INVALID_PARAMETER;                   \
        }                                                          \
    } while (0)
#define CLXS_UNIT_FOREACH(__unit__)                              \
    for (__unit__ = 0; __unit__ < CLXS_MAX_CHIP_NUM; __unit__++)    \
        if (clxs_switch_get_unit_inited(__unit__))
#define UTIL_LIB_LIST_FOREACH(ptr_list, ptr_data, ptr_node) \
    for ( util_lib_list_head_locate(ptr_list, &ptr_node); \
          ptr_node && CLX_E_OK == util_lib_list_node_data_get(ptr_list, ptr_node, (void**)&ptr_data); \
          util_lib_list_next(ptr_list, ptr_node, &ptr_node))
#define UTIL_LIB_LIST_FOREACH_SAFE(ptr_list, ptr_data, ptr_node, ptr_next_node) \
    for ( util_lib_list_head_locate(ptr_list, &ptr_node); \
          ptr_node && (CLX_E_OK == util_lib_list_node_data_get(ptr_list, ptr_node, (void**)&ptr_data)); \
          (ptr_next_node = NULL,util_lib_list_next(ptr_list, ptr_node, &ptr_next_node),ptr_node = ptr_next_node))


/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef struct avl_cookie_s
{
    uint32 length;
    void* data;
} avl_cookie_t;

typedef struct avl_cookie_box_s
{
    uint32 count;
    avl_cookie_t* cookies;
} avl_cookie_box_t;

typedef enum
{
    CLXS_SRV_BUM_TYPE_BROADCAST = 0,
    CLXS_SRV_BUM_TYPE_UNKNOWN_MULTICAST,
    CLXS_SRV_BUM_TYPE_UNKNOWN_UNICAST,
    CLXS_SRV_BUM_TYPE_LAST
} clxs_srv_bum_type_t;

typedef struct clxs_sch_topology_entry_s {
    clx_tm_handler_t handler;        /* Handler of children */
    clx_tm_handler_t parent_handler; /* Handler of parent */
    uint32_t         schedule_sequence;
} clxs_sch_topology_entry_t;

#endif /* __CLX_SDK_H__ */
