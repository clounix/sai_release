/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_ACL_MGMT_H__)
#define __CLX_SAI_ACL_MGMT_H__
#include "shal_acl_mgmt.h"
/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_ACL_SET_MODULE_TYPE(type, id)    ((type << 16) + id)
#define CLXS_ACL_GET_ID(id)                   (id & 0xffff)
#define CLXS_ACL_GET_MODULE_TYPE(id)          (id >> 16)

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef enum clxs_acl_module_type_s
{
    ACL_TYPE_START,
    ACL_TYPE_COPP = ACL_TYPE_START,
    ACL_TYPE_USER_ACL,
    ACL_TYPE_IP_CNT,
    ACL_TYPE_L3_CNT,
    ACL_TYPE_POLICER,
    ACL_TYPE_IPTUNNEL,
    ACL_TYPE_ECN_MARK,
    ACL_TYPE_TAM_IFA2,
    ACL_TYPE_INVALID,
    ACL_TYPE_MAX = ACL_TYPE_INVALID,
} clxs_acl_module_type_t;

typedef struct clxs_acl_priority_info_s
{
    uint32_t                  group_id;
    bool                      is_created;
    shal_acl_module_type_t    owner[SHAL_ACL_TYPE_MAX]; //shal type
} clxs_acl_priority_info_t;

typedef struct clxs_acl_mgmt_db_s
{
    shal_acl_ucp_group_prio_map_t *group_map;
    clxs_acl_priority_info_t *igr_pri_info;
    clxs_acl_priority_info_t *egr_pri_info;
    shal_acl_module_type_t *igr_module_group;
    shal_acl_module_type_t *egr_module_group;
} clxs_acl_mgmt_db_t;

extern clxs_acl_mgmt_db_t* ptr_clxs_acl_mgmt_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
clx_error_no_t clxs_acl_add_table(
    _In_ const uint32_t                   unit,
    _In_ const clxs_acl_module_type_t     type,
    _In_ const clx_cia_stage_t            stage,
    _In_ clx_cia_grp_prof_t    *ptr_group_profile,
    _Out_ uint32_t                        *ptr_group_id
);

clx_error_no_t clxs_acl_del_table(
    _In_ const uint32_t                  unit,
    _In_ const clx_cia_stage_t           stage,
    _In_ const uint32_t                  group_id
);

clx_error_no_t clxs_acl_alloc_entry_id(
    _In_ const uint32_t                  unit,
    _In_ const clx_cia_stage_t           stage,
    _In_ const uint32_t                  group_id,
    _In_ const uint32_t                  entry_pri,
    _Out_ uint32_t                       *ptr_entry_id);

clx_error_no_t clxs_acl_free_entry_id(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id);

clx_error_no_t clxs_acl_add_entry(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id,
    _In_ const boolean                    entry_valid,
    _In_ const clx_cia_classify_t        *ptr_classify,
    _In_       clx_cia_act_t            *ptr_action);

clx_error_no_t clxs_acl_del_entry(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id);

clx_error_no_t clxs_acl_get_entry(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         id,
    _Out_ boolean                *ptr_entry_valid,
    _Out_ clx_cia_classify_t    *ptr_classify,
    _Out_ clx_cia_act_t         *ptr_action);

clx_error_no_t clxs_acl_free_del_entry(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  entry_id);

clx_error_no_t clxs_acl_update_entry(
    _In_ const uint32_t                 unit,
    _In_ const uint32_t                 entry_id,
    _In_ const clx_cia_classify_t       *ptr_classify,
    _In_       clx_cia_act_t            *ptr_action);

clx_error_no_t clxs_acl_set_entry_valid(
    _In_ const uint32_t    unit,
    _In_ const uint32_t    entry_id,
    _In_ const boolean      entry_valid);

clx_error_no_t clxs_acl_dump_module_stage_info(
    _In_ const uint32_t                  unit,
    _In_ const clxs_acl_module_type_t    module_type,
    _In_ const clx_cia_stage_t           stage);

clx_error_no_t clxs_acl_dump_group_info(
    _In_ const uint32_t           unit,
    _In_ const clx_cia_stage_t    stage,
    _In_ const uint32_t           group_id);

clx_error_no_t clxs_acl_get_module_name(
    _In_ const clxs_acl_module_type_t    module_type,
    _Out_ char                            *module_name);

sai_status_t clxs_acl_mgmt_init(
    _In_ const uint32_t    unit);

sai_status_t clxs_acl_mgmt_deinit(
    _In_ const uint32_t unit);

clx_error_no_t clxs_acl_get_module_table_id(
    _In_ const uint32_t                 unit,           
    _In_ const clxs_acl_module_type_t   module_type,
    _In_ const clx_cia_stage_t          stage,
    _Out_ uint32_t                      *ptr_table_num,
    _Out_ uint32_t                      *ptr_table_id);
#endif /*__CLX_SAI_ACL_MGMT_H__*/
