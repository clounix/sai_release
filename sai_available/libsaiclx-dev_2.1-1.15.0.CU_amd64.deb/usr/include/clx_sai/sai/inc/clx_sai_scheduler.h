/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_SCHEDULER_H__)
#define __CLX_SAI_SCHEDULER_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_MAX_SCHEDULER_PROFILE_NUM(__unit__)   (128)

/*
CPU_PORT DEFAULT QUEUE RX rate, current precision is a multiple of 64,
refer to /etc/sonic/copp_cfg.json from customer system, set default queue pir:1000, pbs:1200
*/
#define CLXS_CPU_RX_PACKET_DEFAULT_QUEUE_RATE_SZ        (1024)
#define CLXS_CPU_RX_PACKET_DEFAULT_QUEUE_BURST_SZ       (CLXS_CPU_RX_PACKET_DEFAULT_QUEUE_RATE_SZ * 120 / 100)

#define CLXS_CPU_RX_PACKET_DEFAULT_RATE_SZ        (20000)
#define CLXS_CPU_RX_PACKET_DEFAULT_BURST_SZ       (8*1024 - 1)

typedef enum _clxs_scheduler_shaper_obj_type_t
{
    CLXS_SCHEDULER_SHAPER_OBJ_CPU_PORT,
    CLXS_SCHEDULER_SHAPER_OBJ_CPU_QUEUE,
    CLXS_SCHEDULER_SHAPER_OBJ_PHY_PORT,
    CLXS_SCHEDULER_SHAPER_OBJ_PHY_PORT_QUEUE,
} clxs_scheduler_shaper_obj_type_t;

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/

typedef struct clxs_scheduler_db_s{
    /* scheduler is applied to port */
    sai_object_id_t             clxs_scheduler_port[CLXS_MAX_PORT_NUM];
    /* scheduler profile */
    clxs_scheduler_attrs_t      *clxs_scheduler_profile;
    bool                        *profile_valid;
} clxs_scheduler_db_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_scheduler_api_t        scheduler_api;
extern clxs_scheduler_db_t *_clxs_scheduler_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_scheduler_get_default_shaper(
        _In_ const uint32_t  unit,
        _In_ clxs_scheduler_shaper_obj_type_t obj_type,
        _In_ uint32_t queue_id,
        _Out_ clx_tm_shaper_t *ptr_shaper);

sai_status_t
clxs_scheduler_check_profile_valid(
    uint32_t    unit,
    uint32_t    prof_id);

sai_status_t
clxs_scheduler_set_to_port(
    sai_object_id_t     object_id,
    sai_object_id_t     scheduler_id);

sai_status_t
clxs_scheduler_get_on_port(
    sai_object_id_t     object_id,
    sai_object_id_t     *ptr_scheduler_id);

sai_status_t
clxs_scheduler_apply_to_object(
    sai_object_id_t     scheduler_id,
    uint32_t            port,
    clx_tm_handler_t    handler);

sai_status_t
clxs_scheduler_init(
    uint32_t unit);

sai_status_t
clxs_scheduler_deinit(
    uint32_t unit);

sai_status_t
clxs_get_scheduler_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_scheduler_get_info(
    sai_object_id_t object_id,
    uint32_t        *ptr_unit,
    uint32_t        *ptr_profile_id);

sai_status_t
clxs_scheduler_apply_to_queue(
    sai_object_id_t     scheduler_id,
    uint32_t            port,
    clx_tm_handler_t    handler);

#endif /* __CLX_SAI_SCHEDULER_H__ */
