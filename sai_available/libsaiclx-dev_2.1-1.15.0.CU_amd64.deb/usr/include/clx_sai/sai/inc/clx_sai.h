/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_H__)
#define __CLX_SAI_H__

#include <clx_sai_version.h>
#ifndef CLXS_SAI_HEAD_VERSION
#define CLXS_SAI_HEAD_VERSION                 "1.7.1"
#endif

#ifndef SAI_VERSION
#define SAI_VERSION(major, minor, revision) (10000 * (major) + 100 * (minor) + (revision))
#endif

#ifndef SAI_API_VERSION
/* SAI_MAJOR, SAI_MINOR, SAI_REVISION is defined in clx_sai_version.h when SAI VERSION < 1.8.0 */
#define SAI_API_VERSION SAI_VERSION(SAI_MAJOR, SAI_MINOR, SAI_REVISION)
#endif

#if defined(CLX_STATIC_EN)
#define STATIC static
#else
#define STATIC
#endif

#include <sai.h>
#include <saiextensions.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>
#include <stdarg.h>
#include <assert.h>
#include <inttypes.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <clx_sdk.h>
#include <clx_sai_dispatch.h>
#include <clx_sai_utils.h>
#include <clx_sai_fmt.h>
#include <clx_sai_time.h>
#include <clx_sai_mutex.h>
#include <clx_sai_log.h>
#include <clx_sai_attr.h>
#include <clx_sai_attr_reflection.h>
#include <clx_sai_oid.h>
#include <clx_sai_object.h>
#include <clx_sai_acl_mgmt.h>
#include <clx_sai_port.h>
#include <clx_sai_port_link_delay.h>
#include <clx_sai_qosmap.h>
#include <clx_sai_switch.h>
#include <clx_sai_switch_feature.h>
#include <clx_sai_bridge.h>
#include <clx_sai_vlan.h>
#include <clx_sai_fdb.h>
#include <clx_sai_lag.h>
#include <clx_sai_l2mc.h>
#include <clx_sai_nexthop.h>
#include <clx_sai_nexthopgroup.h>
#include <clx_sai_policer.h>
#include <clx_sai_queue.h>
#include <clx_sai_route.h>
#include <clx_sai_routerinterface.h>
#include <clx_sai_rpfgroup.h>
#include <clx_sai_samplepacket.h>
#include <clx_sai_scheduler.h>
#include <clx_sai_schedulergroup.h>
#include <clx_sai_stp.h>
#include <clx_sai_tunnel.h>
#include <clx_sai_udf.h>
#include <clx_sai_wred.h>
#include <clx_sai_virtualrouter.h>
#include <clx_sai_acl.h>
#include <clx_sai_pkt_rx.h>
#include <clx_sai_buffer.h>
#include <clx_sai_counter.h>
#include <clx_sai_debugcounter.h>
#include <clx_sai_hash.h>
#include <clx_sai_hostif.h>
#include <clx_sai_ipmc.h>
#include <clx_sai_ipmcgroup.h>
#include <clx_sai_isolationgroup.h>
#include <clx_sai_l2mcgroup.h>
#include <clx_sai_mcastfdb.h>
#include <clx_sai_mirror.h>
#include <clx_sai_neighbor.h>
#include <clx_sai_monitor.h>
#include <clx_sai_tam_int.h>
#include <clx_sai_tam.h>
#include <clx_sai_diag.h>
#include <clx_sai_ext_phy.h>
#include <clx_sai_hotpatch_init.h>
#include <clx_sai_bfd.h>

#include <parser/dsh_parser.h>
#include <parser/dsh_util.h>

#include <execinfo.h>

#include <shal.h>


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define _SHAL_FUNC_CALL(__func_vec__, __func__, __param__, __rc__) ({               \
        clx_error_no_t __rc = CLX_E_OK;                                             \
        if ((NULL == clxs_shal_func_vec)||(NULL == clxs_shal_func_vec->__func_vec__) || (NULL == clxs_shal_func_vec->__func_vec__->__func__))             \
        {                                                                           \
            CLXS_LOG_NTC("not support this function");         \
            __rc = __rc__;                                                          \
        }                                                                           \
        else                                                                        \
        {                                                                           \
            __rc = (clxs_shal_func_vec->__func_vec__->__func__ __param__);               \
        }                                                                           \
        __rc;                                                                       \
    })

#define SHAL_FUNC_CALL(__module__,__func__, __param__) \
        _SHAL_FUNC_CALL(shal_##__module__##_func_vec, __func__, __param__, CLX_E_NOT_SUPPORT)


/*******************************************************************************
 * Data Type Declarations 
 *******************************************************************************/
typedef struct clxs_shal_func_vec_s
{
    shal_port_func_vec_t            *shal_port_func_vec;
    shal_switch_func_vec_t          *shal_switch_func_vec;
    shal_vlan_func_vec_t            *shal_vlan_func_vec;
    shal_vrf_func_vec_t             *shal_vrf_func_vec;
    shal_route_func_vec_t           *shal_route_func_vec;
    shal_nexthop_func_vec_t         *shal_nexthop_func_vec;
    shal_nexthopgroup_func_vec_t    *shal_nexthopgroup_func_vec;
    shal_rif_func_vec_t             *shal_rif_func_vec;
    shal_neighbor_func_vec_t        *shal_neighbor_func_vec;
    shal_mirror_func_vec_t          *shal_mirror_func_vec;
    shal_isolationgroup_func_vec_t  *shal_isolationgroup_func_vec;
    shal_hash_func_vec_t            *shal_hash_func_vec;
    shal_stp_func_vec_t             *shal_stp_func_vec;
    shal_fdb_func_vec_t             *shal_fdb_func_vec;
    shal_lag_func_vec_t             *shal_lag_func_vec;
    shal_bridge_func_vec_t          *shal_bridge_func_vec;
    shal_acl_func_vec_t             *shal_acl_func_vec;
    shal_tunnel_func_vec_t          *shal_tunnel_func_vec;
    shal_schedulergroup_func_vec_t  *shal_schedulergroup_func_vec;
    shal_l2mcgroup_func_vec_t       *shal_l2mcgroup_func_vec;
    shal_qosmap_func_vec_t          *shal_qosmap_func_vec;
    shal_hostif_func_vec_t          *shal_hostif_func_vec;
    shal_samplepacket_func_vec_t    *shal_samplepacket_func_vec;
    shal_udf_func_vec_t             *shal_udf_func_vec;
    shal_buffer_func_vec_t          *shal_buffer_func_vec;
    shal_wred_func_vec_t            *shal_wred_func_vec;
    shal_queue_func_vec_t           *shal_queue_func_vec;
    shal_policer_func_vec_t         *shal_policer_func_vec;
    shal_tam_func_vec_t             *shal_tam_func_vec;
    shal_bfd_func_vec_t             *shal_bfd_func_vec;
}clxs_shal_func_vec_t;

/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern sai_service_method_table_t       g_services;
extern  clxs_shal_func_vec_t  *clxs_shal_func_vec;


#endif /* __CLX_SAI_H__ */
