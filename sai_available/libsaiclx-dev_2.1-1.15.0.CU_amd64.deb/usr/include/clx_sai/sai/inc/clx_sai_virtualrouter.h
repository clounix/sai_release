/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_VIRTUAL_ROUTER_H__)
#define __CLX_SAI_VIRTUAL_ROUTER_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define INVALID_VRF_ID 0xffffffff
#define CLXS_VRF_BITMAP_SIZE(__unit__)   (CLX_BITMAP_SIZE(CLXS_MAX_VRF_NUM(__unit__)))
#define VRF_FOREACH(unit, vrf_id)  UTIL_LIB_BMP_BIT_FOREACH(ptr_clxs_vrf_db[unit]->vrf_bitmap, vrf_id, CLXS_VRF_BITMAP_SIZE(unit))

#define CLXS_VRF_DB(unit)       (CLXS_IS_UNIT_VALID(unit)?(ptr_clxs_vrf_db[unit]):NULL)

#define CLXS_VRF_LOCK(unit)    do {\
        if (CLXS_IS_UNIT_VALID(unit))\
        {\
            osal_semaphore_take(&ptr_clxs_vrf_db[unit]->sema, CLX_SEMAPHORE_WAIT_FOREVER);\
        }\
    }while (0)

#define CLXS_VRF_UNLOCK(unit)   do {\
        if (CLXS_IS_UNIT_VALID(unit))\
        {\
            osal_semaphore_give(&ptr_clxs_vrf_db[unit]->sema);\
        }\
    }while (0)


/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef struct
{
    clxs_virtual_router_attrs_t    vrf_attrs;
} clxs_vrf_entry_t;

typedef struct
{
    clxs_vrf_entry_t               *ptr_vrf_entry;
    clx_semaphore_id_t             sema;
    sai_object_id_t                default_vrf_id;
    uint32_t                       *vrf_bitmap;
} clxs_vrf_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern clxs_vrf_db_t* ptr_clxs_vrf_db[];
extern const sai_virtual_router_api_t   virtualrouter_api;


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t clxs_vrf_init(
    const uint32_t    unit);

sai_status_t clxs_vrf_deinit(
    const uint32_t    unit);

sai_status_t clxs_vrf_get_info(
    _In_ const sai_object_id_t  obj_id,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_vrf_id,
    _Out_ clx_mac_t             *ptr_src_mac,
    _Out_ clx_fwd_action_t      *ptr_fwd_act);

sai_status_t clxs_vrf_get_object(
    _In_ const uint32_t         vrf_id,
    _In_ const uint32_t         unit,
    _Out_ sai_object_id_t       *ptr_obj_id);

sai_status_t clxs_vrf_get_default_vrf(
    _In_ const uint32_t unit,
    _Out_ sai_object_id_t *ptr_obj_id);

sai_status_t
clxs_get_vrf_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

bool _clxs_vrf_check_exist(
    const uint32_t  unit,
    const uint32_t  vrf_id);

sai_status_t
clxs_vrf_get_entry(
    const uint32_t  unit,
    const uint32_t  vrf_id,
    clxs_vrf_entry_t **ppt_vrf_entry);

 bool
clxs_vrf_smac_attr_is_set(
    const uint32_t  unit,
    const uint32_t  vrf_id);

#endif /* __CLX_SAI_VIRTUAL_ROUTER_H__ */
