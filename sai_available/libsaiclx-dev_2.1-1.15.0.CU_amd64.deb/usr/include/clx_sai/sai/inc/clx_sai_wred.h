/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_WRED_H__)
#define __CLX_SAI_WRED_H__


/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_WRED_DEFAULT_PROBABILITY    (100)
#define CLXS_WRED_MAX_WEIGHT             (15)
#define CLXS_WRED_FLAGS_MAX_THRESHOLD    (1 << 0)
#define CLXS_WRED_FLAGS_MIN_THRESHOLD    (1 << 1)
#define CLXS_WRED_FLAGS_DROP_PROBABILITY (1 << 2)
#define CLXS_WRED_FLAGS_ALL (CLXS_WRED_FLAGS_MAX_THRESHOLD|CLXS_WRED_FLAGS_MIN_THRESHOLD|CLXS_WRED_FLAGS_DROP_PROBABILITY)

#ifdef CLX_WRED_ECN_MARKED_COUNT_USING_ACL
#define CLXS_WRED_ECN_VALUE_3   (0x3)
#define CLXS_WRED_ECN_MASK      (0x3)

#define CLXS_WRED_ECN_MARKED_COUNT_PTR(__unit__, __port__, __queue__)       \
            ((clxs_wred_ecn_counter_db_t *)(_clxs_wred_ecn_stats_db[__unit__].ptr_ecnmarked_counter_db + __port__ * CLXS_QUEUE_UC_NUM(__unit__) + __queue__))

#define CLXS_WRED_ECN_UNMARK_COUNT_PTR(__unit__, __port__, __queue__)       \
            ((clxs_wred_ecn_counter_db_t *)(_clxs_wred_ecn_stats_db[__unit__].ptr_ecnunmark_counter_db + __port__ * CLXS_QUEUE_UC_NUM(__unit__) + __queue__))

#endif

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
 typedef struct clxs_wred_profile_db_s {
    clxs_wred_attrs_t wred_attrs;
    bool valid;
} clxs_wred_profile_db_t;

#ifdef CLX_WRED_ECN_MARKED_COUNT_USING_ACL
typedef enum
{
    CLXS_WRED_IPTYPE_IPV4,
    CLXS_WRED_IPTYPE_IPV6,
    CLXS_WRED_IPTYPE_MAX
} clxs_wred_iptype_t;

typedef struct clxs_wred_ecn_counter_db_s
{
    bool            enabled;
    uint8_t         tc;
    uint64_t        pkts_cnt;                /**The historical statistical values of ecn marked pkts*/
    uint64_t        bytes_cnt;               /**The historical statistical values of ecn marked bytes*/
    uint32_t        acl_entry_id[CLXS_WRED_IPTYPE_MAX];     /*egress 2 acl(0-ipv4, 1-ipv6) mactch ecn = 0x3 and group-lable = 0 */
    uint32_t        srv_counter_id[CLXS_WRED_IPTYPE_MAX];	 /*egress 2 2xcounters, 0-ipv4,1-ipv6*/
}clxs_wred_ecn_counter_db_t;

typedef struct clxs_wred_ecn_stats_s
{
    uint32_t        egr_group_id;
    uint32_t        igr_group_id;
    uint32_t        igr_entry_id[CLXS_WRED_IPTYPE_MAX];   /*ingress 2 acl(0-ipv4, 1-ipv6) mactch ecn = 0x3, set group-label 0x6e*/
    clxs_wred_ecn_counter_db_t   *ptr_ecnmarked_counter_db;
    clxs_wred_ecn_counter_db_t   *ptr_ecnunmark_counter_db;
}clxs_wred_ecn_stats_t;

extern clxs_wred_ecn_stats_t _clxs_wred_ecn_stats_db[CLXS_MAX_CHIP_NUM];

#endif

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_wred_api_t             wred_api;


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_wred_apply_on_queue(
    _In_ uint32_t            unit,
    _In_ uint32_t            port,
    _In_ clx_tm_handler_t    handler,
    _In_ sai_object_id_t	 wred_id);

sai_status_t
clxs_wred_init(
    _In_ uint32_t unit);

sai_status_t
clxs_wred_deinit(
    _In_ uint32_t unit);

sai_status_t
clxs_get_wred_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

clxs_wred_profile_db_t *
clxs_wred_get_profile(
    uint32_t unit,
	uint32_t wred_profile_id);

/* get ECN enable of wred profile */
bool
clxs_wred_get_ecn_enable(
    _In_ sai_object_id_t  wred_id);

#ifdef CLX_WRED_ECN_MARKED_COUNT_USING_ACL
sai_status_t
clxs_wred_get_port_ecnmarked_pkts(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _Out_ uint64_t *counters);

sai_status_t
clxs_wred_enable_ecnmarked_cnt(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ uint32_t queue_idx,
    _In_ bool     enable);

sai_status_t
clxs_wred_get_queue_ecnmarked_cnt(
    _In_ uint32_t                   unit,
    _In_ uint32_t                   port,
    _In_ uint32_t                   queue_idx,
    _Out_ clx_stat_tm_cnt_t         *ptr_cnt);

sai_status_t
clxs_wred_clear_ecnmarked_cnt(
    _In_ uint32_t                   unit,
    _In_ uint32_t                   port,
    _In_ uint32_t                   queue_idx);

sai_status_t
clxs_wred_update_port_egress_ecnmarked_acl(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             port);

sai_status_t
clxs_wred_update_egress_ecnmarked_acl(
    _In_ const uint32_t             unit);

sai_status_t
clxs_wred_get_queue_ecnunmark_cnt(
    _In_ uint32_t                   unit,
    _In_ uint32_t                   port,
    _In_ uint32_t                   queue,
    _Out_ clx_stat_tm_cnt_t         *ptr_cnt);

sai_status_t
clxs_wred_get_queue_ecnunmark_cnt(
    _In_ uint32_t                   unit,
    _In_ uint32_t                   port,
    _In_ uint32_t                   queue,
    _Out_ clx_stat_tm_cnt_t         *ptr_cnt);

#endif

clxs_wred_profile_db_t *
clxs_wred_get_profile_db(
    _In_ uint32_t unit);

#endif /* __CLX_SAI_WRED_H__ */
