/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_BRIDGE_H__)
#define __CLX_SAI_BRIDGE_H__


/*******************************************************************************
* Macro Definitions
*******************************************************************************/
#define CLXS_BRIDGE_NUM(__unit__) (1 + CLXS_BRIDGE_BD_1D_NUM(__unit__))
#define CLXS_BRIDGE_FLAGS_CREATE_WITH_ID (1 << 0)
#define CLXS_BRIDGE_BD_1Q_NUM      (4095)
#define CLXS_BRIDGE_BD_1D_NUM(__unit__)      (CLXS_BRIDGE_BD_NUM(__unit__) - CLXS_BRIDGE_BD_1Q_NUM)
#define CLXS_BRIDGE_BD_1D_MIN      (CLXS_BRIDGE_BD_1Q_NUM + 1)
#define CLXS_BRIDGE_BD_1D_MAX(unit)      (CLXS_BRIDGE_BD_1D_MIN + CLXS_BRIDGE_BD_1D_NUM(unit) - 1)
#define CLXS_BRIDGE_BD_1D_BMP_SIZE(unit) (CLX_BITMAP_SIZE(CLXS_BRIDGE_BD_1D_NUM(unit)))
#define CLXS_BRIDGE_PORT_BMP_SIZE(__unit__)    (CLX_BITMAP_SIZE(CLXS_MAX_BRIDGE_PORT_NUM(__unit__)))
#define CLXS_BRIDGE_DFLT_1Q_ID       (1)
#define CLXS_BRIDGE_CB(__unit__) g_clxs_bridge_db[(__unit__)]
#define CLXS_BRIDGE_LOCK(__unit__)   \
        sai_osal_mutex_lock(g_clxs_bridge_db[(__unit__)]->bd_sema)
#define CLXS_BRIDGE_UNLOCK(__unit__) \
        sai_osal_mutex_unlock(g_clxs_bridge_db[(__unit__)]->bd_sema)
#define CLXS_BRIDGE_PORT_LOCK(__unit__)   \
        sai_osal_mutex_lock(g_clxs_bridge_db[(__unit__)]->port_sema)
#define CLXS_BRIDGE_PORT_UNLOCK(__unit__) \
        sai_osal_mutex_unlock(g_clxs_bridge_db[(__unit__)]->port_sema)

#define CLXS_BRIDGE_IS_LEGAL_BD_PORT_ID(__unit__,__bd_port_id__) \
        ((__bd_port_id__) < CLXS_MAX_BRIDGE_PORT_NUM(__unit__))
#define CLXS_BRIDGE_TO_SW_IDX(__bdid__) \
        (((__bdid__) < CLXS_BRIDGE_BD_1D_MIN) ? 0 : ((__bdid__) - CLXS_BRIDGE_BD_1D_MIN + 1))


/*******************************************************************************
* Data Type Declarations
 *******************************************************************************/
typedef enum clxs_lrn_mode_s
{
    CLXS_LRN_MODE_NOT,
    CLXS_LRN_MODE_HW,
    CLXS_LRN_MODE_SW,
    CLXS_LRN_MODE_LAST
} clxs_lrn_mode_t;

typedef struct clxs_bridge_port_vport_type_s
{
    clx_gport_type_t type;
    clx_gport_t gport;
    uint16_t vid;    /*only subport */
}clxs_bridge_port_vport_type_t;

typedef struct clxs_bridge_lrn_info_s
{
    clxs_lrn_mode_t    lrn_mode;
    bool    sa_miss_do_fwd; /*data plane action*/
    bool    sa_miss_to_cpu; /*cpu path action*/
} clxs_bridge_lrn_info_t;

typedef struct clxs_bridge_port_attr_s
{
    clx_bridge_domain_t     bdid;
    clxs_bridge_lrn_info_t    lrn_info;
    bool    admin;
    bool    igr_filter;
    bool    egr_filter;
    int32_t tag_mode;
    clx_stat_srv_cnt_t      igr_cnt;
    clx_stat_srv_cnt_t      egr_cnt;
#if SAI_API_VERSION >= SAI_VERSION(1,4,0)
    sai_object_id_t     isolation_group_oid;
#endif
} clxs_bridge_port_attr_t;

typedef struct clxs_bridge_port_key_s
{
    sai_bridge_port_type_t    type;
    sai_object_id_t           oid;  /* port/lag/tunnel oid */
    uint16_t                  vid;  /* for subport */
} clxs_bridge_port_key_t;

typedef struct clxs_bridge_port_node_s
{
    clxs_bridge_port_key_t  key;
    clxs_bridge_port_attr_t  attr;
    sai_object_id_t oid;
    uint32_t idx;
} clxs_bridge_port_node_t;

typedef struct clxs_bridge_attr_s
{
    uint32_t            mbr_cnt;
} clxs_bridge_attr_t;

typedef struct clxs_bridge_db_s
{
    /* bd */
    uint32_t  *              valid_bd_1d_bmp;
    clx_semaphore_id_t      bd_bmp_sema;
    /* bridge */
    clxs_bridge_attr_t *      bd_arr;
    clx_semaphore_id_t      bd_sema;
    /* bridge port */
    uint32_t *                  valid_bd_port_id_bmp;
    clxs_bridge_port_node_t *    port_arr;
    util_lib_avl_head_t            *ptr_port_avl;
    clx_semaphore_id_t          port_sema;
} clxs_bridge_db_t;


/*******************************************************************************
* Global Variable Declarations
 *******************************************************************************/
extern const sai_bridge_api_t           bridge_api;
extern clxs_object_stats_capability_info_t bridge_stats_capability_info ;
extern clxs_object_stats_capability_info_t bridge_port_stats_capability_info;
extern clxs_bridge_db_t *g_clxs_bridge_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
* Function Declarations
 *******************************************************************************/
sai_status_t
clxs_bridge_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_bridge_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_bridge_create_bd(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             flags,
    _Inout_ clx_bridge_domain_t     *ptr_bdid);

sai_status_t
clxs_bridge_remove_bd(
    _In_ const uint32_t             unit,
    _In_ const clx_bridge_domain_t  bdid);

sai_status_t
clxs_bridge_port_get_vport(
    _In_ const uint32_t    unit,
    _In_ const sai_object_id_t    bridge_port_oid,
    _Out_ clxs_bridge_port_vport_type_t    *vport);

sai_status_t
clxs_bridge_port_get_pbmp(
    _In_ const uint32_t    unit,
    _In_ const sai_object_id_t    bridge_port_oid,
    _Out_ clx_port_bitmap_t    bmp);

sai_status_t
clxs_bridge_get_bridge_type(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_bridge_type_t         *ptr_type);

sai_status_t
clxs_bridge_get_info(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_bdid);

sai_status_t
clxs_bridge_get_obj(
    _In_ const uint32_t      unit,
    _In_ const uint32_t      bdid,
    _Out_ sai_object_id_t    *ptr_oid);

sai_status_t
clxs_bridge_get_1q_obj(
    _In_ const uint32_t             unit,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_bridge_port_get_associated_obj(
    _In_ const sai_object_id_t      bridge_port_oid,
    _Out_ clxs_bridge_port_key_t    *ptr_bridge_port_key);

sai_status_t
clxs_bridge_port_get_obj(
    _In_ const uint32_t unit,
    _In_ const sai_bridge_port_type_t type,
    _In_ const sai_object_id_t port_oid,
    _In_ const uint16_t vid,
    _Out_ sai_object_id_t *ptr_oid);

sai_status_t
clxs_bridge_port_get_obj_by_id(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_bridge_port_get_bdid(
    _In_ const uint32_t unit,
    _In_ const sai_object_id_t bridge_port_obj,
    _Out_ uint32_t *ptr_bdid);

sai_status_t
clxs_bridge_port_update_lag_member(
    _In_ const uint32_t unit,
    _In_ const sai_object_id_t lag_oid,
    _In_ const sai_object_id_t member_port_oid,
    _In_ const bool is_add);

sai_status_t
clxs_get_bridge_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_bridge_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
_clxs_bridge_port_add_db_entry(
    _In_ const uint32 unit,
    _In_ const clxs_bridge_port_node_t *ptr_key);

#endif /* __CLX_SAI_BRIDGE_H__ */
