/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_HOSTIF_H__)
#define __CLX_SAI_HOSTIF_H__

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_HOSTIF_MAX_REASON_PER_TRAP                      (10)
#define CLXS_HOSTIF_TRAPS_NUM                               CLXS_HOSTIF_REGULAR_TRAP_SUPPORTED_NUM

#define CLXS_HOSTIF_MAX_NUM_OF_HIF                          (512)
#define CLXS_HOSTIF_MAX_NUM_OF_HIF_TABLE                    (4096)
#define CLXS_HOSTIF_MAX_TRAP_GROUPS                         (48)
#define CLXS_HOSTIF_REGULAR_TRAP_SUPPORTED_NUM              (48)
#define CLXS_HOSTIF_UDF_TRAP_SUPPORTED_NUM                  (5)
#define CLXS_HOSTIF_UDF_TRAPS_NUM                           (CLXS_HOSTIF_UDF_TRAP_SUPPORTED_NUM)

#define CLXS_HOSTIF_TRAPS_SUPPORTED_BY_ACL_NUM              (96)
#define CLXS_HOSTIF_MAX_C2C_ENTRY_PER_TRAP                  (5)

#define CLXS_HOSTIF_LOCK(__unit__) \
    osal_semaphore_take(&_ptr_clxs_hostif_db[__unit__]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_HOSTIF_UNLOCK(__unit__) \
    osal_semaphore_give(&_ptr_clxs_hostif_db[__unit__]->sema);

#define CLXS_HOSTIF_TABLE_LOCK(__unit__) \
    osal_semaphore_take(&_ptr_clxs_hostif_table_db[__unit__]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_HOSTIF_TABLE_UNLOCK(__unit__) \
    osal_semaphore_give(&_ptr_clxs_hostif_table_db[__unit__]->sema);

#define CLXS_HOSTIF_TRAP_LOCK(__unit__) \
    osal_semaphore_take(&_ptr_clxs_hostif_trap_db[__unit__]->sema, CLX_SEMAPHORE_WAIT_FOREVER);

#define CLXS_HOSTIF_TRAP_UNLOCK(__unit__) \
    osal_semaphore_give(&_ptr_clxs_hostif_trap_db[__unit__]->sema);

#define CLXS_HOSTIF_TRAP_DEFAULT_TO_CPU_FLAGS           (1 << 0)
#define CLXS_HOSTIF_TRAP_FLAGS_RATELIMIT_BY_QUEUE       (1 << 1)
#define CLXS_HOSTIF_TRAP_TO_CPU_BY_ACL_FLAGS            (1 << 2)
#define CLXS_HOSTIF_TRAP_FLAGS_TO_CPU_BY_CTL2CPU        (1 << 3)
#define CLXS_HOSTIF_TRAP_FLAGS_TO_CPU_BY_OTHERS         (1 << 4)
#define CLXS_HOSTIF_TRAP_FALGS_CTL2CPU_BY_PROXY         (1 << 5)
#define CLXS_HOSTIF_TRAP_USE_EGR_ACL_FLAGS              (1 << 6)

/*******************************************************************************
 * Data Type Declarations 
 *******************************************************************************/
typedef struct clxs_hostif_info_s
{
    sai_hostif_type_t           type;                       /* SAI_HOSTIF_ATTR_TYPE         */
    sai_object_id_t             obj_id;                     /* SAI_HOSTIF_ATTR_OBJ_ID       */
    char                        name[SAI_HOSTIF_NAME_SIZE]; /* SAI_HOSTIF_ATTR_NAME         */
    char                        mcgrp_name[SAI_HOSTIF_NAME_SIZE]; /* SAI_HOSTIF_ATTR_GENETLINK_MCGRP_NAME */
    bool                        valid;                      /* interface entry valid or not */
    sai_uint32_t                queue;                      /* SAI_HOSTIF_ATTR_QUEUE        */
    sai_hostif_vlan_tag_t       vlan_tag;                   /* SAI_HOSTIF_ATTR_VLAN_TAG     */
    uint32_t                    netif_id;                   /* clxssai-metadata */
    bool                        status;                     /* SAI_HOSTIF_ATTR_OPER_STATUS  */
    sai_mac_t                   mac;                        /* switch mac */
} clxs_hostif_info_t;

typedef struct clxs_hostif_table_info_s
{
    sai_hostif_table_entry_type_t         type;         /* SAI_HOSTIF_TABLE_ENTRY_ATTR_TYPE         */
    sai_object_id_t                       obj_id;       /* SAI_HOSTIF_TABLE_ENTRY_ATTR_OBJ_ID       */
    sai_object_id_t                       trap_id;      /* SAI_HOSTIF_TABLE_ENTRY_ATTR_TRAP_ID      */
    sai_hostif_table_entry_channel_type_t channel_type; /* SAI_HOSTIF_TABLE_ENTRY_ATTR_CHANNEL_TYPE */
    sai_object_id_t                       hostif_id;    /* SAI_HOSTIF_TABLE_ENTRY_ATTR_HOST_IF      */
    bool                                  valid;
    uint32_t                              profile_id;   /* clxssai-metadata */

} clxs_hostif_table_info_t;

typedef struct clxs_hostif_trap_group_info_s
{
    bool                        valid;
    bool                        admin_state;    /* SAI_HOSTIF_TRAP_GROUP_ATTR_ADMIN_STATE */
    sai_uint32_t                queue;          /* SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE       */
    sai_object_id_t             policer_id;     /* SAI_HOSTIF_TRAP_GROUP_ATTR_POLICER     */
    uint32_t                    priority;
    uint32_t                    trap_group_id;
} clxs_hostif_trap_group_info_t;

typedef struct clxs_hostif_cpu_reason_s
{
    uint32_t    trap_cpu_reason_code[CLXS_HOSTIF_MAX_REASON_PER_TRAP];
    uint32_t    copy_cpu_reason_code[CLXS_HOSTIF_MAX_REASON_PER_TRAP];
}clxs_hostif_cpu_reason_t;
typedef struct clxs_hostif_trap_info_s
{
    bool                        valid;
    uint32_t                    flags;
    sai_hostif_trap_type_t      trap_type;      /* SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE     */
    sai_packet_action_t         action;         /* SAI_HOSTIF_TRAP_ATTR_PACKET_ACTION */
    uint32_t                    trap_group_id;  /* SAI_HOSTIF_TRAP_ATTR_TRAP_GROUP    */
    uint32_t                    priority;
    uint32_t                    cpu_queue;      /* cpu_queue mapping with trap_cpu_reason_code */
    clxs_hostif_cpu_reason_t    cpu_reason_code;
    sai_object_id_t             counter_id;
} clxs_hostif_trap_info_t;

typedef struct clxs_hostif_udf_trap_info_s
{
    bool                        valid;
    sai_hostif_user_defined_trap_type_t      trap_type; /* SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE*/
    uint32_t                    trap_group_id;  /* SAI_HOSTIF_TRAP_ATTR_TRAP_GROUP    */
    uint32_t                    cpu_queue;
    clxs_hostif_cpu_reason_t    cpu_reason_code;
} clxs_hostif_udf_trap_info_t;

typedef struct clxs_hostif_ctrl2cpu_cfg_s
{
    sai_hostif_trap_type_t          trap_type;      /* SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE     */
    clx_pkt_ctrl_to_cpu_entry_t     entry;
    bool                            entry_valid;
    uint32_t                        entry_id;
} clxs_hostif_ctrl2cpu_cfg_t;

typedef enum
{
    CLXS_HOSTIF_TRAP_INTL_TRAP_TYPE_IPV4_LOCAL_LINK = SAI_HOSTIF_TRAP_TYPE_LOCAL_IP_CUSTOM_RANGE_BASE,
    CLXS_HOSTIF_TRAP_INTL_TRAP_TYPE_IPV6_LOCAL_LINK,
    CLXS_HOSTIF_TRAP_INTL_TRAP_TYPE_LAST
} clxs_hostif_trap_intl_trap_type_t;

typedef enum
{
    CLXS_HOSTIF_TRAP_PVRST_CTRL2CPU_ENTRY_ID,
    CLXS_HOSTIF_TRAPS_SUPPORTED_BY_CTRL2CPU_NUM
} clxs_hostif_trap_ctrl2cpu_entry_id_t;

typedef enum
{
    CLXS_HOSTIF_TRAP_CPU_QUEUE_DEFAULT          = 0,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_SAMPLER          = 1,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_TTL_ERR          = 2,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_FDB              = 3,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_0            = 4,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_1            = 5,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_2            = 6,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_3            = 7,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_4            = 8,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_5            = 9,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_6            = 10,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_7            = 11,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_8            = 12,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_9            = 13,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_10           = 14,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_11           = 15,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_12           = 16,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_13           = 17,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_14           = 18,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_15           = 19,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_16           = 20,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_17           = 21,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_18           = 22,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_19           = 23,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_20           = 24,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_21           = 25,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_22           = 26,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_23           = 27,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_24           = 28,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_25           = 29,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_26           = 30,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_27           = 31,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_28           = 32,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_29           = 33,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CIA_30           = 34,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_CTL2CPU_PVRST    = 35,
    CLXS_HOSTIF_USER_DEFINED_TRAP_CPU_QUEUE_L3  = 36,
    CLXS_HOSTIF_USER_DEFINED_TRAP_CPU_QUEUE_ACL = 37,
    CLXS_HOSTIF_USER_DEFINED_TRAP_CPU_QUEUE_FDB = 38,
    CLXS_HOSTIF_USER_DEFINED_TRAP_CPU_QUEUE_TAM = 39,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_ICMP             = 46,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_ICCP             = 47,
    CLXS_HOSTIF_TRAP_CPU_QUEUE_LAST
}clxs_hostif_trap_cpu_queue_t;

typedef enum
{
    CLXS_HOSTIF_TRAP_SPECIAL_QUEUE_TYPE_ICMP,
    CLXS_HOSTIF_TRAP_SPECIAL_QUEUE_TYPE_ICCP,
    CLXS_HOSTIF_TRAP_SPECIAL_QUEUE_TYPE_LAST
} clxs_hostif_trap_special_queue_type_t;
typedef struct clxs_hostif_db_s
{
    clxs_hostif_info_t          db[CLXS_HOSTIF_MAX_NUM_OF_HIF];
    clx_semaphore_id_t          sema;
} clxs_hostif_db_t;

typedef struct clxs_hostif_table_db_s
{
    clxs_hostif_table_info_t    db[CLXS_HOSTIF_MAX_NUM_OF_HIF_TABLE];
    clx_semaphore_id_t          sema;

} clxs_hostif_table_db_t;

typedef struct clxs_hostif_acl_cfs_s
{
    sai_hostif_trap_type_t      trap_type;      /* SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE     */

    /* Default value for HW, will be updated later when user set the trap */
    clx_cia_classify_t          key;
    clx_cia_act_t               act;
    uint32                      dbg_srv_counter_id; /* for sai hostif debug*/
    bool                        entry_valid;
    uint32_t                    entry_id;
#ifdef CLX_MAC2ME_TRAP_TO_CPU_EN
    uint32_t                    ref_cnt;
    struct clxs_hostif_acl_cfs_s       *ptr_next_acl_cfg;
#endif

} clxs_hostif_acl_cfg_t;

typedef struct clxs_hostif_trap_db_s
{
    clxs_hostif_trap_group_info_t  group_db[CLXS_HOSTIF_MAX_TRAP_GROUPS];
    clxs_hostif_trap_info_t        trap_db[CLXS_HOSTIF_TRAPS_NUM];
    clxs_hostif_udf_trap_info_t    udf_trap_db[CLXS_HOSTIF_UDF_TRAPS_NUM];
    clxs_hostif_acl_cfg_t        acl_trap_cfg[CLXS_HOSTIF_TRAPS_SUPPORTED_BY_ACL_NUM];
    clxs_hostif_ctrl2cpu_cfg_t   ctrl2cpu_trap_cfg[CLXS_HOSTIF_TRAPS_SUPPORTED_BY_CTRL2CPU_NUM];
    uint32_t                    default_trap_group;
    clx_semaphore_id_t          sema;
    uint32                      acl_group_id;
    clx_cia_grp_prof_t          acl_group_profile;
    uint32                      acl_egr_group_id;
    clx_cia_grp_prof_t          acl_egr_group_profile;
    uint32_t                    default_meter_id;
    uint32_t                    iccp_meter_id;
} clxs_hostif_trap_db_t;

typedef struct clxs_hostif_stats_s
{
    uint64 forward_pkts;
    uint64 dropped_pkts;
    uint64 dropped_byts;
}clxs_hostif_stats_t;

/*******************************************************************************
 * Global Variable Declarations 
 *******************************************************************************/
extern const sai_hostif_api_t           hostif_api;
extern clxs_hostif_db_t              *_ptr_clxs_hostif_db[CLXS_MAX_CHIP_NUM];
extern clxs_hostif_table_db_t        *_ptr_clxs_hostif_table_db[CLXS_MAX_CHIP_NUM];
extern clxs_hostif_trap_db_t         *_ptr_clxs_hostif_trap_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations 
 *******************************************************************************/
sai_status_t
clxs_hostif_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_hostif_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_hostif_get_default_trap_group_oid(
    _In_ const uint32_t         unit,
    _Out_ sai_object_id_t       *ptr_trap_group_oid);

sai_status_t clxs_get_hostif_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_trap_group_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_trap_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_table_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_hostif_set_netif_sample_rate(
    _In_ const sai_object_id_t      obj_id,
    _In_ const bool                 is_ingress,
    _In_ const uint32_t             sample_rate);

clxs_hostif_info_t *
clxs_hostif_get_entry(
    _In_ uint32_t           unit,
    _In_ uint32_t           clxs_hif_id);

clxs_hostif_table_info_t *
clxs_hostif_table_get_entry(
    _In_ uint32_t           unit,
    _In_ uint32_t           clxs_hif_table_id);

uint32_t
clxs_hostif_trap_get_acl_entry_cfg(
    const uint32_t          unit,
    const uint32_t          trap_type,
    clxs_hostif_acl_cfg_t    *pptr_acl_cfg[CLXS_HOSTIF_MAX_ACL_ENTRY_PER_TRAP]);

uint32_t
clxs_hostif_trap_get_ctrl2cpu_entry_cfg(
    _In_ const uint32_t	        unit,
    _In_ const uint32_t	        trap_type,
    _Out_ clxs_hostif_ctrl2cpu_cfg_t *pptr_c2c_cfg[CLXS_HOSTIF_MAX_C2C_ENTRY_PER_TRAP]);

uint32_t
clxs_hostif_get_trap_acl_entry(
    _In_  uint32_t              unit,
    _In_  uint32_t              trap_type,
    _Out_ uint32_t              *acl_entry_id
);

sai_status_t
clxs_hostif_auto_update (
    _In_ sai_object_id_t            port_id,
    _In_ sai_port_oper_status_t     port_state);

sai_status_t
clxs_hostif_udf_trap_get_cpu_queue(
    _In_ const sai_object_id_t      obj_id,
    _Out_ uint32_t                  *ptr_cpu_queue);

#ifdef CLX_MAC2ME_TRAP_TO_CPU_EN
sai_status_t
clxs_hostif_update_src_mac(
    _In_ const uint32_t    unit,
    _In_ const sai_mac_t   mac_addr);

sai_status_t
clxs_hostif_trap_add_route_mac(
    _In_ const uint32_t     unit,
    _In_ const sai_mac_t    mac_addr);

sai_status_t
clxs_hostif_trap_del_route_mac(
    _In_ const uint32_t     unit,
    _In_ const sai_mac_t    mac_addr);

sai_status_t
clxs_hostif_arp_entry_valid_modify(
    _In_ uint32_t     unit,
    _In_ bool         entry_valid);
#endif

sai_status_t
clxs_hostif_get_policer_stats(
    _In_  uint32_t          unit,
    _In_ sai_object_id_t    policer_id,
    _Out_ uint64_t          stat[6]);

sai_status_t
clxs_hostif_clear_policer_stats(
    _In_  uint32_t          unit,
    _In_ sai_object_id_t    policer_id);

#endif
