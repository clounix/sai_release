/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_PORT_ECMP_MEMBER_TRACER_H__)
#define __CLX_SAI_PORT_ECMP_MEMBER_TRACER_H__

#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
#ifdef CLX_SHOW_ECMP_PATH_EN

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
/* ECMP PATH pkt format TCP/UDP over IPv6/IPv4 */
#define CLXS_PORT_ECMP_PATH_PKT_INFO(unit)           (_clxs_port_ecmp_path_db[unit].pkt_info)
#define CLXS_PORT_ECMP_PATH_NETIF_PROF_ID(unit)      (_clxs_port_ecmp_path_db[unit].res.netif_prof_id)
#define CLXS_PORT_ECMP_PATH_ACL_RES(unit)            (_clxs_port_ecmp_path_db[unit].res.acl_info)
#define CLXS_PORT_ECMP_PATH_ING_ACL_RES(unit)        (_clxs_port_ecmp_path_db[unit].res.acl_info.ing_acl_info)
#define CLXS_PORT_ECMP_PATH_EGR_ACL_RES(unit, port)  (_clxs_port_ecmp_path_db[unit].res.acl_info.egr_acl_info[port])


/*******************************************************************************
 * Data Type Definitions
 *******************************************************************************/
typedef struct clxs_port_ecmp_path_igr_acl_info_s
{
    uint32_t igr_entry_id;          /* Ingress acl entry id    */
    uint32_t igr_counter_id;        /* Ingress acl counter id  */
    uint32_t igr_group_id;          /* Ingress acl table id  */
}clxs_port_ecmp_path_igr_acl_info_t;

typedef struct clxs_port_ecmp_path_egr_acl_info_s
{
    uint32_t egr_ipv4_entry_id;       /* Egress acl entry id     */
    uint32_t egr_ipv4_counter_id;     /* Egress acl counter id   */
    uint32_t egr_ipv6_entry_id;       /* Egress acl entry id     */
    uint32_t egr_ipv6_counter_id;     /* Egress acl counter id   */
}clxs_port_ecmp_path_egr_acl_info_t;

typedef struct clxs_port_ecmp_path_acl_info_s
{
    clxs_port_ecmp_path_igr_acl_info_t   ing_acl_info;
    clxs_port_ecmp_path_egr_acl_info_t   egr_acl_info[CLX_PORT_NUM];
    uint32_t                        egr_global_group_id;          /* Egress acl table id  */
}clxs_port_ecmp_path_acl_info_t;

typedef struct clxs_port_ecmp_path_pkt_info_s
{
    clx_mac_t  src_mac_addr;      /* ipv4/ipv6 Switch src mac addr */
    clx_mac_t  dst_mac_addr;      /* ipv4/ipv6 Switch dst mac addr */
    clx_ip_t   src_ip;             /* ipv4/ipv6 Switch ecmp_path src_ip */
    clx_ip_t   dst_ip;             /* ipv4/ipv6 Switch ecmp_path dst_ip */
    uint8_t    protocol;          /* ipv4/ipv6 Protocol type */
    uint16_t   src_port;           /* ipv4/ipv6 Switch ecmp_path l4 src port */
    uint16_t   dst_port;           /* ipv4/ipv6 Switch ecmp_path l4 dst port */
    uint32_t   igr_phy_port;      /* ipv4/ipv6 Switch ecmp_path ingress physical port */
    uint32_t   egr_port;          /* ipv4/ipv6 Switch ecmp_path egress port */
    bool       is_ipv6;             /* check if run show egress-port ipv4/ipv6 ecmp cli */
}clxs_port_ecmp_path_pkt_info_t;

typedef struct clxs_port_ecmp_path_pkt_res_s
{
    uint32_t                    netif_prof_id;             /*  ecmp path netif profile prof_id */
    clxs_port_ecmp_path_acl_info_t   acl_info; /* Ingress and Egress acl entry info */
}clxs_port_ecmp_path_pkt_res_t;

/* =========ecmp path info structure, include pkt info and res info========= */
typedef struct clxs_port_ecmp_path_s
{
    clxs_port_ecmp_path_pkt_info_t       pkt_info;
    clxs_port_ecmp_path_pkt_res_t        res;
}clxs_port_ecmp_path_t;


/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern clxs_port_ecmp_path_t _clxs_port_ecmp_path_db[CLXS_MAX_CHIP_NUM];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_port_ecmp_path_process_path(
    _In_    const uint32_t          unit,
    _In_    uint32_t                port,
    _In_    uint32_t                attr_count,
    _Inout_ sai_attribute_t         *attr_list);

sai_status_t
clxs_port_ecmp_path_get_attr(
    _In_    uint32_t                unit,
    _In_    sai_attr_id_t           attr_id,
    _Inout_ sai_attribute_value_t   *ptr_value);

#endif /*CLX_SHOW_ECMP_PATH_EN*/
#endif /*SAI_API_VERSION*/

#endif /*__CLX_SAI_PORT_ECMP_MEMBER_TRACER_H__*/