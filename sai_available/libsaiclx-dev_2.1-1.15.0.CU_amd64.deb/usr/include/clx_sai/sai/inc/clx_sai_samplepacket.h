/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_SAMPLEPACKET_H__)
#define __CLX_SAI_SAMPLEPACKET_H__

#define GENL_PSAMPLE_FAMILY_NAME    "psample"
#define CLXS_SAMPLEPACKET_DB(unit) (&_clxs_samplepacket_db[unit])

#define CLXS_SAMPLEPACKET_EGR_DB(unit) (&_clxs_samplepacket_egress_db[unit])

#define CLXS_SFLOW_EGR_INFO_LOCK(unit)          sai_osal_mutex_lock(CLXS_SAMPLEPACKET_EGR_DB(unit)->mutex)
#define CLXS_SFLOW_EGR_INFO_UNLOCK(unit)        sai_osal_mutex_unlock(CLXS_SAMPLEPACKET_EGR_DB(unit)->mutex)

/*******************************************************************************
 * Data Type Declarations
 *******************************************************************************/
typedef struct clxs_samplepacket_bind_data_s
{
    sai_object_id_t obj;
} clxs_samplepacket_bind_data_t;

typedef struct clxs_samplepacket_entry_s {
    bool valid;
    clxs_samplepacket_attrs_t attr_info;
    sai_object_id_t sai_curr_mirrorsession_oid;
    uint32_t mirrorsession_count;
    util_lib_list_t *ptr_igr_obj_list;
    util_lib_list_t *ptr_egr_obj_list;
} clxs_samplepacket_entry_t;

typedef struct clxs_samplepacket_db_s {
    clxs_samplepacket_entry_t *ptr_entry;
} clxs_samplepacket_db_t;

typedef struct clxs_samplepacket_egress_info_s
{
    bool                        active;
    bool                        l3_uc;
    uint16_t                    ifindex;
    uint32_t                    egr_port;
    uint32_t                    sample_rate;
    clx_swc_flow_hsh_key_t      hash_key;
} clxs_samplepacket_egress_entry_t;

typedef struct clxs_samplepacket_egress_db_s
{
    int32_t  netlink_fd;
    int32_t  family_id;
    int32_t  group_id;
    uint32_t netlink_profile_id;
    uint32_t interval_ms;
    uint64_t start_time;
    uint64_t packet_count;
    uint64_t perf_count;
    uint64_t packet_rate;
    bool perf_test;
    osal_timer_id_t timer_id;
    clx_semaphore_id_t mutex;
    util_lib_avl_head_t *sflow_egress_info_avl;
} clxs_samplepacket_egress_db_t;

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_samplepacket_api_t     samplepacket_api;
extern clxs_samplepacket_db_t _clxs_samplepacket_db[CLXS_MAX_CHIP_NUM];

extern clxs_samplepacket_egress_db_t _clxs_samplepacket_egress_db[CLXS_MAX_CHIP_NUM];

/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t
clxs_samplepacket_init(
    _In_ uint32_t unit);

sai_status_t
clxs_samplepacket_deinit(
    _In_ uint32_t unit);

sai_status_t
clxs_samplepacket_get_rate(
    _In_ sai_object_id_t samplepacket_id,
    _Out_ uint32_t *ptr_samplepacket_rate);

sai_status_t
clxs_samplepacket_get_type(
    _In_ sai_object_id_t samplepacket_id,
    _Out_ sai_samplepacket_type_t *ptr_samplepacket_type);

sai_status_t
clxs_samplepacket_apply_setting(
    _In_ uint32_t unit,
    _In_ sai_object_id_t obj_id,
    _In_ bool igr,
    _In_ sai_object_id_t cur_samplepacket_id,
    _In_ sai_object_id_t new_samplepacket_id);

sai_status_t
clxs_get_samplepacket_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

clxs_samplepacket_entry_t *
clxs_samplepacket_get_entry(
    _In_ uint32_t unit,
    _In_ uint32_t samplepkt_entry_idx);

sai_status_t
clxs_samplepacket_update_egress_info(
    _In_ sai_object_id_t port_object);

clx_error_no_t
clxs_samplepacket_netlink_init(
    const uint32_t              unit);

#endif /* __CLX_SAI_SAMPLEPACKET_H__ */
