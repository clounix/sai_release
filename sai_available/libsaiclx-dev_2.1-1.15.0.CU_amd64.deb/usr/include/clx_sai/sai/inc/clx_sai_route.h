/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2025
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/
#if !defined (__CLX_SAI_ROUTE_H__)
#define __CLX_SAI_ROUTE_H__
#include "uthash.h"

/*******************************************************************************
 * Macro Definitions
 *******************************************************************************/
#define CLXS_ROUTE_DB(unit) (_ptr_clxs_route_db[unit])

#define CLXS_ROUTE_READ_LOCK(unit) \
    sai_osal_rwlock_rdlock(&_ptr_clxs_route_db[unit]->route_rwlock);

#define CLXS_ROUTE_WRITE_LOCK(unit) \
    sai_osal_rwlock_wrlock(&_ptr_clxs_route_db[unit]->route_rwlock);

#define CLXS_ROUTE_RW_UNLOCK(unit) \
    sai_osal_rwlock_unlock(&_ptr_clxs_route_db[unit]->route_rwlock);

#define CLXS_ROUTE_POOL_SEM_LOCK(unit) \
    sai_osal_mutex_lock(_ptr_clxs_route_db[unit]->pool_mamger->pool_sem);

#define CLXS_ROUTE_POOL_SEM_UNLOCK(unit) \
    sai_osal_mutex_unlock(_ptr_clxs_route_db[unit]->pool_mamger->pool_sem);

#define CLXS_ROUTE_OPER_RECORD_NUM                  (200*1024)         /* max buffer num */
#define CLXS_ROUTE_LOG_POOL_BLOCK_SIZE              (1024)             /* max route info log block size - num of clx_l3_route_info per block */
#define CLXS_ROUTE_LOG_POOL_BLOCK_CNT               (1024)             /* max route info log block cnt - num of pool block */
#define CLXS_ROUTE_OPER_LOG_FILE                    "/var/log/route_oper_log"
#define CLXS_ROUTE_OPER_LOG_JSON                    "/var/log/route_oper.json"

#if SAI_API_VERSION >= SAI_VERSION(1, 11, 0)
#ifdef CLX_ECMP_PACKET_SPRAY_FUNC
#define CLXS_SAI_ROUTE_LABEL_PACKET_ECMP_SPRAY_START     (0x8000)
#endif
#endif

#define CLXS_REGISTER_ROUTE_LOG_NOTIFY_UPDATE(func)   do { clxs_route_log_notify_func[__MODULE__] = func; } while (0)

#define CLXS_ROUTE_POOL_NUM     (32)
#define CLXS_ROUTE_POOL_SIZE    (100000)          // capacity of each pool
#define CLXS_ROUTE_ACL_IPV4_PROTO_NUM  (3)
#define CLXS_ROUTE_ACL_IPV6_PROTO_NUM  (5)

/*******************************************************************************
 * Data Type Definitions
 *******************************************************************************/

/**
 * @brief Route entry structure
 */
typedef struct clxs_route_entry_s
{
    char                        key[MAX_KEY_STR_LEN];          /** Key string in format "ip_vrf", supports both IPv4 and IPv6 */
    sai_route_entry_t           route_entry;                   /** Route entry information */
    clxs_route_entry_attrs_t    attr_info;                    /** Route entry attributes */
    uint32_t                    output_type;                   /** Output type */
    uint32_t                    output_id;                     /** Output ID */
    uint32_t                    grp_lbl;                       /** Route entry group label */
    uint32_t                    pool_id;                       /** pool ID */
    UT_hash_handle              hh;                           /** Hash handle for uthash */
} clxs_route_entry_t;

typedef struct clxs_route_pool_s
{
    uint32_t                    free_num;          /**free entry in pool*/
    util_lib_mpool_t            *ptr_mpool;        /**memory pool*/
} clxs_route_pool_t;

typedef struct clxs_route_pool_mamager_s
{
    clxs_route_pool_t           pools[CLXS_ROUTE_POOL_NUM];  /**array of pools*/
    uint32_t                    pool_count;                   /** current alloced pool counter*/
    clx_semaphore_id_t          pool_sem;                     /** semaphore for pool*/
} clxs_route_pool_mamager_t;

/* module data base */
typedef struct clxs_route_db_s
{
    clxs_route_entry_t          *route_entry;     /**entry hash table*/
    clxs_route_pool_mamager_t   *pool_mamger;     /**pool mamager*/
    uint32_t                    port_nh_adj;
    uint32_t                    rif_nh_adj;
    uint32_t                    trap_action_adj;
    sai_osal_rwlock             route_rwlock;
} clxs_route_db_t;

/* action type */
typedef enum clxs_route_oper_type_s
{
    CLXS_ROUTE_OPER_TYPE_SINGLE_ADD = 0,
    CLXS_ROUTE_OPER_TYPE_SINGLE_REMOVE,
    CLXS_ROUTE_OPER_TYPE_SINGLE_SET,
    CLXS_ROUTE_OPER_TYPE_SINGLE_GET,
    CLXS_ROUTE_OPER_TYPE_BULK_ADD,
    CLXS_ROUTE_OPER_TYPE_BULK_REMOVE,
    CLXS_ROUTE_OPER_TYPE_BULK_SET,
    CLXS_ROUTE_OPER_TYPE_BULK_GET,
    CLXS_ROUTE_OPER_TYPE_MAX_NUM
}clxs_route_oper_type_t;

typedef sai_status_t (*clxs_route_notify_oper_log_fn) (
    _In_ uint32_t                    unit,
    _In_ clxs_route_oper_type_t      oper_type,
    _In_ uint32_t                    object_cnt,
    _In_ uint64_t                    start_time,
    _In_ uint64_t                    end_time,
    _In_ uint64_t                    sdk_time,
    _In_ sai_status_t                ret,
    _In_ clx_l3_route_t              *ptr_route_info);

/*******************************************************************************
 * Global Variable Declarations
 *******************************************************************************/
extern const sai_route_api_t            route_api;
extern clxs_route_db_t                  *_ptr_clxs_route_db[CLXS_MAX_CHIP_NUM];
extern clxs_route_notify_oper_log_fn    clxs_route_log_notify_func[CLXS_API_MAX];


/*******************************************************************************
 * Function Declarations
 *******************************************************************************/
sai_status_t clxs_route_init(
    _In_    const uint32_t      unit);

sai_status_t clxs_route_deinit(
    _In_    const uint32_t      unit);

sai_status_t clxs_route_get_route_entry(
    _In_    const uint32_t      unit,
    _In_    const uint32_t      vrf_id,
    _In_    sai_ip_address_t    ip_addr,
    _Out_   clx_l3_route_t      *clx_route);

sai_status_t clxs_route_get_available_route_num(
    _In_    sai_object_id_t     switch_id,
    _In_    bool                is_ipv6,
    _Out_   uint32_t            *count);

uint64_t clxs_route_calculate_time_interval(
    _In_    uint64_t    start_time,
    _In_    uint64_t    end_time);

clxs_route_entry_t*
_clxs_route_alloc_db_entry(
    _In_ uint32_t unit);

sai_status_t
_clxs_route_add_db_entry(
    _In_    const sai_route_entry_t     *ptr_route_entry,
    _In_    clxs_route_entry_t          *route_info_db);
#endif /* __CLX_SAI_ROUTE_H__ */
