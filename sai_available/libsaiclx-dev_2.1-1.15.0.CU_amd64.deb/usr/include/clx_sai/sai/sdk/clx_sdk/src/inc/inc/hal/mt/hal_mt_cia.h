/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_cia.h
 * PURPOSE:
 *    Provide HAL driver API functions of CIA module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_CIA_H
#define HAL_MT_CIA_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_cia.h>
#include <hal/hal_l3.h>
#include <hal/hal_cmn.h>
#include <hal/hal_cia.h>
#include <hal/hal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_CIA_PLANE_PORT_BITS                  (32)
#define HAL_MT_CIA_L2_DA_SA_LBL_BITS                (10)
#define HAL_MT_CIA_DA_SA_LBL_BITS                   (16)
#define HAL_MT_CIA_UDF_INT_INTF_LBL_BITS            (16)
#define HAL_MT_CIA_UDF_INT_IGR_CIA_LBL_BITS         (16)
#define HAL_MT_CIA_UDF_INT_TCP_FLAG_BITS            (12)
#define HAL_MT_CIA_UDF_INT_VID_BITS                 (12)
#define HAL_MT_CIA_UDF_INT_PCP_DEI_BITS             (4)
#define HAL_MT_CIA_UDF_INT_PCP_BITS                 (3)
#define HAL_MT_CIA_UDF_INT_DEI_BITS                 (1)
#define HAL_MT_CIA_UDF_KEY_BITS                     (200)
#define HAL_MT_CIA_EXACT_KEY_BITS                   (140)
#define HAL_MT_CIA_UDF_PKG_BITS                     (8)
#define HAL_MT_CIA_UDF_PROF_ID_BITS                 (6)
#define HAL_MT_CIA_EXACT_PKG_PROF_TLV_LST_WORDS_MAX (12)
#define HAL_MT_CIA_PKG_PROF_TLV_LST_WORDS_MAX       (24)
#define HAL_MT_CIA_KEY_1X_WORDS                     (14)
#define HAL_MT_CIA_BASEKEY_L3_WORDS_MAX             (HAL_MT_CIA_KEY_1X_WORDS * 2)
#define HAL_MT_CIA_BASEKEY_WORDS_MAX                (HAL_MT_CIA_KEY_1X_WORDS * 3)
#define HAL_MT_CIA_ACTION_NUM_MAX                   (4)
#define HAL_MT_CIA_KEY_WIDTH_MAX                    (4)
#define HAL_MT_CIA_EXACT_ACTION_NUM_MAX             (2)
#define HAL_MT_CIA_TILE_REGTION_SIZE                (8)
#define HAL_MT_CIA_BASE_LABEL_REPLACE_SA            (1U << 0)
#define HAL_MT_CIA_BASE_LABEL_REPLACE_DA            (1U << 1)
#define HAL_MT_CIA_IGR_CIA_GROUP_LABEL_MAX          (0xF000)
#define HAL_MT_CIA_ACTION_OFFSET                    (HAL_MT_CIA_KEY_WIDTH_MAX * HAL_MT_CIA_KEY_1X_WORDS)
#define HAL_MT_CIA_ACTION_QOS_PROF_PCP_DEI_VLD      (1U << 0)
#define HAL_MT_CIA_ACTION_QOS_PROF_EXP_VLD          (1U << 1)
#define HAL_MT_CIA_ACTION_QOS_PROF_DSCP_VLD         (1U << 2)
#define HAL_MT_CIA_ACTION_FCM_INST_MAX              (6)
#define HAL_MT_CIA_ACTION_FCM_BYTE_CNT_MAX          (4)
#define HAL_MT_CIA_ACTION_FCM_ENABLE                (0xF003)
#define HAL_MT_CIA_ACTION_TEML_IOAM_DELAY_BIT       (2)
#define HAL_MT_CIA_ACTION_TEML_IOAM_ENABLE_BIT      (1)
#define HAL_MT_CIA_ACTION_FWD_MSK_SRC_PRUNE         (0x03)
#define HAL_MT_CIA_ACTION_FWD_MSK_TTL               (0x1C)
#define HAL_MT_CIA_ACTION_FWD_MSK_RPF               (0x3E0)
#define HAL_MT_CIA_PGK_TLV_BYTE_OFF_MAX             (215) /* 0-215 */
#define HAL_MT_CIA_FCM_TLV_BIDX_MAX                 (62)

#define HAL_MT_CIA_SAMPLER_VALUE_DEFAULT_VALUE     (0xDEADBEEF)
#define HAL_MT_CIA_SAMPLER_TAPS_DEFAULT_VALUE      (0x80200003)
#define HAL_MT_CIA_SAMPLER_THRESHOLD_DEFAULT_VALUE (0)
#define HAL_MT_CIA_RESOURCE_ALLOC_MODE_NUM         (5)

#define HAL_MT_CIA_L2_DA_SA_LBL_FLD(__data__) \
    ((__data__) & HAL_CIA_UI32_MSK(HAL_MT_CIA_L2_DA_SA_LBL_BITS))
#define HAL_MT_CIA_UNPACK_ICMP_TYPE(__icmp_type__) ((__icmp_type__) >> 8)
#define HAL_MT_CIA_UNPACK_ICMP_CODE(__icmp_code__) (((__icmp_code__)) & 0xFF)
#define HAL_MT_CIA_UNPACK_IGMP_TYPE(__igmp_type__) ((__igmp_type__) >> 8)
#define HAL_MT_CIA_UCP_CFG_ENTRY_IDX(__frm_typ__)  ((__frm_typ__) * HAL_CIA_PER_UCP_FRM_TYPE_CFG_NUM)

#define HAL_MT_CIA_PACK_ICMP_TYPE_CODE(__icmp_type__, __icmp_code__) \
    (((uint32)((__icmp_type__) & 0xFF) << 8) + (((__icmp_code__) & 0xFF)))
#define HAL_MT_CIA_PACK_IGMP_TYPE(__igmp_type__) ((uint32)((__igmp_type__) & 0xFF) << 8)
#define HAL_MT_CIA_PACK_DA_SA_GRP_LBL(__sa_lbl__, __da_lbl__)                                      \
    ((((__da_lbl__) & HAL_CIA_UI32_MSK(HAL_MT_CIA_DA_SA_LBL_BITS)) << HAL_MT_CIA_DA_SA_LBL_BITS) | \
     ((__sa_lbl__) & HAL_CIA_UI32_MSK(HAL_MT_CIA_DA_SA_LBL_BITS)))

#define HAL_MT_CIA_UNPACK_DA_SA_GRP_LBL(__sa_lbl__, __da_lbl__, __data__)          \
    do {                                                                           \
        (__da_lbl__) = (__data__) >> (HAL_MT_CIA_DA_SA_LBL_BITS) &                 \
            HAL_CIA_UI32_MSK(HAL_MT_CIA_DA_SA_LBL_BITS);                           \
        (__sa_lbl__) = (__data__) & (HAL_CIA_UI32_MSK(HAL_MT_CIA_DA_SA_LBL_BITS)); \
    } while (0)

#define HAL_MT_CIA_PACK_RANGE_KEY(__profile_idx__, __cia_range_en__) \
    ((__profile_idx__) | (__cia_range_en__) << 6)

#define HAL_MT_CIA_UNPACK_RANGE_KEY(__profile_idx__, __cia_range_en__, __data__)        \
    do {                                                                                \
        (__profile_idx__) = (__data__) & HAL_CIA_UI32_MSK(HAL_MT_CIA_UDF_PROF_ID_BITS); \
        (__cia_range_en__) = ((__data__) >> HAL_MT_CIA_UDF_PROF_ID_BITS) &              \
            HAL_CIA_UI32_MSK(HAL_CIA_UDF_INT_RANGE_BITS);                               \
    } while (0)

#define HAL_MT_CIA_GRP_LOGICAL_2_PHYSICAL(__unit__, __stage__, __group__) \
    ((__stage__ == CLX_CIA_STAGE_IGR) ?                                   \
         (__group__) :                                                    \
         (__stage__ == CLX_CIA_STAGE_IGR_POST) ?                          \
         (__group__) :                                                    \
         (__stage__ == CLX_CIA_STAGE_EGR) ?                               \
         ((__group__) + PTR_HAL_CONST_INFO(__unit__, cia)->igr_grp_num) : \
         ((__group__) + PTR_HAL_CONST_INFO(__unit__, cia)->igr_post_grp_num))

#define HAL_MT_CIA_UCP_LOGICAL_2_PHYSICAL(__unit__, __stage__, __ucp_idx__) \
    ((__stage__ == CLX_CIA_STAGE_IGR) ?                                     \
         (__ucp_idx__) :                                                    \
         (__stage__ == CLX_CIA_STAGE_IGR_POST) ?                            \
         (__ucp_idx__) :                                                    \
         (__stage__ == CLX_CIA_STAGE_EGR) ?                                 \
         ((__ucp_idx__) + PTR_HAL_CONST_INFO(__unit__, cia)->igr_ucp_num) : \
         ((__ucp_idx__) + PTR_HAL_CONST_INFO(__unit__, cia)->igr_post_ucp_num))

#define HAL_MT_CIA_GET_PHYSICAL_TILE_REGION_FLD(__base__, __ucp__) (__base__ + (__ucp__) / 8)

#define HAL_MT_CIA_GET_ALLOC_IDX(__unit__, __stage__, __alloc_idx__)                              \
    do {                                                                                          \
        if (HAL_IS_DEV_NB_CIAT_DOUBLE_FAMILY(unit)) {                                             \
            if ((__stage__ == CLX_CIA_STAGE_IGR_POST) || (__stage__ == CLX_CIA_STAGE_EGR_POST)) { \
                __alloc_idx__ = 1;                                                                \
            } else if (((__stage__ == CLX_CIA_STAGE_IGR) || (__stage__ == CLX_CIA_STAGE_EGR))) {  \
                __alloc_idx__ = 0;                                                                \
            }                                                                                     \
        }                                                                                         \
    } while (0)

#define HAL_MT_CIA_GET_BCAST_IDX(__unit__, __bcast_idx__, __stage__, __bcast_idx_by_type__)     \
    do {                                                                                        \
        if (((__stage__ == CLX_CIA_STAGE_IGR_POST) || (__stage__ == CLX_CIA_STAGE_EGR_POST)) && \
            (__bcast_idx__ == TOB_INST_IDX_BCAST)) {                                            \
            __bcast_idx_by_type__ = TOB_SLAVE_INST_IDX_BCAST;                                   \
        } else if (((__stage__ == CLX_CIA_STAGE_IGR) || (__stage__ == CLX_CIA_STAGE_EGR)) &&    \
                   (__bcast_idx__ == TOB_INST_IDX_BCAST) &&                                     \
                   (HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(__unit__))) {                          \
            __bcast_idx_by_type__ = TOB_MASTER_INST_IDX_BCAST;                                  \
        } else {                                                                                \
            __bcast_idx_by_type__ = __bcast_idx__;                                              \
        }                                                                                       \
    } while (0)

#define HAL_MT_CIA_PLANE_BMP(__unit__, __stage__)                             \
    (((__stage__ == CLX_CIA_STAGE_IGR) || (__stage__ == CLX_CIA_STAGE_EGR)) ? \
         HAL_PLANE_BMP((__unit__)) :                                          \
         HAL_SLAVE_PLANE_BMP((__unit__)))

#define HAL_MT_CIA_PLANE_BMP_FOREACH(__unit__, __stage__, __plane_idx__)                    \
    for ((__plane_idx__) = 0; (__plane_idx__) < HAL_PLANE_NUM(__unit__); (__plane_idx__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((HAL_MT_CIA_PLANE_BMP((__unit__), (__stage__))), (__plane_idx__)))

#define HAL_MT_CIA_PLANE_BMP_FIRST_PLANE(__unit__, __stage__, __plane_idx__, __plane_idx_first__) \
    do {                                                                                          \
        HAL_MT_CIA_PLANE_BMP_FOREACH(__unit__, __stage__, __plane_idx__)                          \
        {                                                                                         \
            __plane_idx_first__ = __plane_idx__;                                                  \
            break;                                                                                \
        }                                                                                         \
    } while (0)

#define HAL_MT_CIA_PACK_DA_SA_GRP_LBL(__sa_lbl__, __da_lbl__)                                      \
    ((((__da_lbl__) & HAL_CIA_UI32_MSK(HAL_MT_CIA_DA_SA_LBL_BITS)) << HAL_MT_CIA_DA_SA_LBL_BITS) | \
     ((__sa_lbl__) & HAL_CIA_UI32_MSK(HAL_MT_CIA_DA_SA_LBL_BITS)))

#define HAL_MT_CIA_GET_ENTRY_TBL_ID(__tbl_id__, __norm_width__)   \
    do {                                                          \
        switch ((__norm_width__)) {                               \
            case (1):                                             \
                (__tbl_id__) = MT_NB_TBL_CIAT_CIA_TCAM_UCP_1X_ID; \
                break;                                            \
            case (2):                                             \
                (__tbl_id__) = MT_NB_TBL_CIAT_CIA_TCAM_UCP_2X_ID; \
                break;                                            \
            default: /* 4 */                                      \
                (__tbl_id__) = MT_NB_TBL_CIAT_CIA_TCAM_UCP_4X_ID; \
                break;                                            \
        }                                                         \
    } while (0)

#define HAL_MT_CIA_GET_UCP_VLD_FIELD_ID(__field__, __tbl_id__)            \
    do {                                                                  \
        switch ((__tbl_id__)) {                                           \
            case (MT_NB_TBL_CIAT_CIA_TCAM_UCP_1X_ID):                     \
                (__tbl_id__) = MT_NB_CIAT_CIA_TCAM_UCP_1X_VLD_T_FIELD_ID; \
                break;                                                    \
            case (MT_NB_TBL_CIAT_CIA_TCAM_UCP_2X_ID):                     \
                (__tbl_id__) = MT_NB_CIAT_CIA_TCAM_UCP_2X_VLD_T_FIELD_ID; \
                break;                                                    \
            default: /* MT_NB_TBL_CIAT_CIA_TCAM_UCP_4X_ID */              \
                (__tbl_id__) = MT_NB_CIAT_CIA_TCAM_UCP_4X_VLD_T_FIELD_ID; \
                break;                                                    \
        }                                                                 \
    } while (0)

#define HAL_MT_CIA_ACTION_CHECK_FCM_BYTE_CNT(__unit__, __idx__, __byte_cnt__, __expe_byte_cnt__) \
    do {                                                                                         \
        if ((__byte_cnt__) != (__expe_byte_cnt__)) {                                             \
            UTIL_LOG_PRINT(UTIL_LOG_CIA, UTIL_LOG_WARN,                                          \
                           "u=%u, rewr-cfg %u, invalid byte_cnt=%u, should be byte_cnt=%u\n",    \
                           (__unit__), (__idx__), (__byte_cnt__), __expe_byte_cnt__);            \
            return CLX_E_BAD_PARAMETER;                                                          \
        }                                                                                        \
    } while (0)

#define IPV6_H_BUF_TO_HW_IPV6(__unit__, __tbl_id__, __fld_id__, __key_buf__, __hw_ipv6__) \
    do {                                                                                  \
        uint32 __ipv6_buf__[3];                                                           \
                                                                                          \
        osal_memset(__ipv6_buf__, 0, sizeof(__ipv6_buf__));                               \
        tob_field_unpack(__unit__, __tbl_id__, __fld_id__, __key_buf__, __ipv6_buf__);    \
        hw_ipv6[1] = __ipv6_buf__[0];                                                     \
        hw_ipv6[2] = __ipv6_buf__[1];                                                     \
        hw_ipv6[3] = __ipv6_buf__[2];                                                     \
    } while (0)

#define HAL_MT_CIA_ACT_RIM_SET_IDX(__idx__, __pbr_type__, __alloc_idx__) \
    do {                                                                 \
        __idx__ = ((__pbr_type__) << 16) | (__alloc_idx__);              \
    } while (0)

#define HAL_MT_CIA_ACT_RIM_GET_IDX(__idx__, __pbr_type__, __alloc_idx__) \
    do {                                                                 \
        __alloc_idx__ = (__idx__) & 0xFFFF;                              \
        __pbr_type__ = ((__idx__) >> 16) & 0x3;                          \
    } while (0)

#define HAL_MT_CIA_ACT_RIM_GET_ALLOC_IDX(__idx__, __alloc_idx__) \
    do {                                                         \
        __alloc_idx__ = (__idx__) & 0xFFFF;                      \
    } while (0)

#if defined(CLX_ASICSIM)
#define HAL_MT_CIA_FAKE_VB_OFFSET (182)
#endif

typedef enum hal_mt_cia_typ_e {
    HAL_MT_CIA_KEY_TCAM_L2 = 0,
    HAL_MT_CIA_KEY_TCAM_ARP = 1,
    HAL_MT_CIA_KEY_TCAM_L3_IPV4 = 2,
    HAL_MT_CIA_KEY_TCAM_MPLS = 3,
    HAL_MT_CIA_KEY_TCAM_UDF0 = 4,
    HAL_MT_CIA_KEY_TCAM_UDF1 = 5,
    HAL_MT_CIA_KEY_TCAM_L3_IPV6 = 6
} hal_mt_cia_typ_t;

typedef enum hal_mt_cia_act_pbr_type_e {
    HAL_MT_CIA_ACT_PBR_TYPE_MPATH = 0,
    HAL_MT_CIA_ACT_PBR_TYPE_FRC_L3 = 1,
    HAL_MT_CIA_ACT_PBR_TYPE_BD_DI = 2,
    HAL_MT_CIA_ACT_PBR_TYPE_DI_ONLY = 3,
    HAL_MT_CIA_ACT_PBR_TYPE_LAST
} hal_mt_cia_act_pbr_type_t;

typedef enum hal_mt_cia_act_fcm_op_type_e {
    HAL_MT_CIA_ACT_FCM_OP_TYPE_NONE = 0,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_ADD_2B = 1,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_ADD_4B = 2,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_DEL_2B = 3,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_DEL_4B = 4,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_SET_2B_MSK = 5,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_SET_4B = 6,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_SET_FIX_OFFSET = 7,
    HAL_MT_CIA_ACT_FCM_OP_TYPE_LAST
} hal_mt_cia_act_fcm_op_type_t;

typedef enum hal_mt_cia_act_fcm_op_code_e {
    HAL_MT_CIA_ACT_FCM_OP_CODE_DMAC_HI = 0,
    HAL_MT_CIA_ACT_FCM_OP_CODE_DMAC_LO = 1,
    HAL_MT_CIA_ACT_FCM_OP_CODE_SMAC_HI = 2,
    HAL_MT_CIA_ACT_FCM_OP_CODE_SMAC_LO = 3,
    HAL_MT_CIA_ACT_FCM_OP_CODE_L2_VLAN0 = 4,
    HAL_MT_CIA_ACT_FCM_OP_CODE_L2_VLAN1 = 5,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_DA_3 = 6,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_DA_2 = 7,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_DA_1 = 8,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_DA_0 = 9,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_SA_3 = 10,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_SA_2 = 11,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_SA_1 = 12,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_SA_0 = 13,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv4_DIP = 14,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv4_SIP = 15,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv6_TOS = 16,
    HAL_MT_CIA_ACT_FCM_OP_CODE_IPv4_TOS = 17,
    HAL_MT_CIA_ACT_FCM_OP_CODE_L4_SPORT = 18,
    HAL_MT_CIA_ACT_FCM_OP_CODE_L4_DPORT = 19,
    HAL_MT_CIA_ACT_FCM_OP_CODE_LAST
} hal_mt_cia_act_fcm_op_code_t;

typedef enum hal_mt_cia_rsn_act_e {
    HAL_MT_CIA_RSN_ACT_DISABLE = 0,
    HAL_MT_CIA_RSN_ACT_COPY = 1,
    HAL_MT_CIA_RSN_ACT_REDIR = 2,
    HAL_MT_CIA_RSN_ACT_DROP = 3,
    HAL_MT_CIA_RSN_ACT_LAST = 4
} hal_mt_cia_rsn_act_t;

typedef enum hal_mt_cia_act_fwd_msk_bit_e {
    HAL_MT_CIA_ACT_FWD_MSK_BIT_SRC_PRUNING = (1U << 0),
    HAL_MT_CIA_ACT_FWD_MSK_BIT_TTL = (1U << 1),
    HAL_MT_CIA_ACT_FWD_MSK_BIT_RPF = (1U << 2),
    HAL_MT_CIA_ACT_FWD_MSK_BIT_LAST,
} hal_mt_cia_act_fwd_msk_bit_t;

clx_error_no_t
hal_mt_cia_entry_alloc_rsrc_free(const uint32 unit,
                                 const clx_cia_stage_t type,
                                 const hal_cia_entry_alloc_info_t *ptr_alloc_info);

clx_error_no_t
hal_mt_cia_rim_fcm_idx_alloc(const uint32 unit, const uint32 is_flw, uint32 *ptr_index);

clx_error_no_t
hal_mt_cia_rim_fcm_idx_free(const uint32 unit, const uint32 is_flw, const uint32 index);

clx_error_no_t
hal_mt_cia_rim_redir_idx_alloc(const uint32 unit,
                               const clx_cia_rim_alloc_t type,
                               uint32 *ptr_index);

clx_error_no_t
hal_mt_cia_rim_redir_idx_free(const uint32 unit,
                              const clx_cia_rim_alloc_t type,
                              const uint32 a_index);

clx_error_no_t
hal_mt_cia_rim_redir_idx_set(const uint32 unit,
                             const clx_cia_rim_alloc_t type,
                             const uint32 a_index,
                             const clx_cia_redir_act_t *ptr_redir_act);

clx_error_no_t
hal_mt_cia_rim_redir_idx_get(const uint32 unit,
                             const clx_cia_rim_alloc_t type,
                             const uint32 a_index,
                             clx_cia_redir_act_t *ptr_redir_act);

clx_error_no_t
hal_mt_cia_rim_redir_idx_trav(const uint32 unit,
                              const clx_cia_rim_alloc_t type,
                              const clx_cia_rim_trav_func_t callback,
                              void *ptr_cookie);

clx_error_no_t
hal_mt_cia_rim_fcm_act_set(const uint32 unit,
                           const uint32 is_flw,
                           const uint32 index,
                           const void *ptr_action);

clx_error_no_t
hal_mt_cia_rim_fcm_act_get(const uint32 unit,
                           const uint32 is_flw,
                           const uint32 index,
                           const void *ptr_action);

clx_error_no_t
hal_mt_cia_rim_fcm_act_trav(const uint32 unit,
                            const uint32 is_flw,
                            const clx_cia_rim_trav_func_t callback,
                            void *ptr_cookie);

clx_error_no_t
hal_mt_cia_grp_chk(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const uint32 pri,
                   const clx_cia_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_cia_grp_add(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const uint32 pri,
                   const clx_cia_grp_prof_t *ptr_grp_prof,
                   uint32 *ptr_grp_id);

clx_error_no_t
hal_mt_cia_grp_set(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const uint32 pri,
                   const clx_cia_grp_prof_t *ptr_grp_prof,
                   uint32 grp_id);

clx_error_no_t
hal_mt_cia_pkt_format_get(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const uint32 udf_prof_id,
                          const hal_cia_udf_info_t *ptr_udf_info,
                          clx_cia_pkt_format_t *ptr_pkt_format);

clx_error_no_t
hal_mt_cia_pkg_lou_prof_idx_get(const uint32 unit,
                                const clx_cia_stage_t stage,
                                const uint32 udf_prof_id,
                                uint32 *ptr_exact_pkg_prof_vld,
                                uint32 *ptr_exact_pkg_prof_idx,
                                uint32 *ptr_cia_pkg_prof_vld,
                                uint32 *ptr_cia_pkg_prof_idx,
                                uint32 *ptr_lou_prof_vld,
                                uint32 *ptr_lou_prof_idx);

clx_error_no_t
hal_mt_cia_pkg_prof_get(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 cia_pkg_prof_idx,
                        const uint32 cia_pkg_prof_vld,
                        const hal_cia_udf_info_t *ptr_udf_info,
                        clx_cia_udf_prof_t *ptr_profile);

clx_error_no_t
hal_mt_cia_exact_pkg_prof_get(const uint32 unit,
                              const uint32 exact_pkg_prof_idx,
                              const hal_cia_udf_info_t *ptr_udf_info,
                              clx_cia_udf_prof_t *ptr_profile);
clx_error_no_t
hal_mt_cia_pkg_prof_set(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 udf_prof_id,
                        const clx_cia_udf_prof_t *ptr_profile,
                        uint32 *ptr_cia_pkg_vld,
                        uint32 *ptr_pkg_0_cnt,
                        uint32 *ptr_pkg_1_cnt,
                        uint32 *ptr_pkg_0_consecutive_bmp,
                        uint32 *ptr_pkg_1_consecutive_bmp);
clx_error_no_t
hal_mt_cia_exact_pkg_prof_set(const uint32 unit,
                              const uint32 udf_prof_id,
                              const clx_cia_udf_prof_t *ptr_profile,
                              uint32 *ptr_exact_pkg_vld,
                              uint32 *ptr_consecutive_bmp);

clx_error_no_t
hal_mt_cia_pkg_lou_prof_idx_set(const uint32 unit,
                                const clx_cia_stage_t stage,
                                const uint32 udf_prof_id,
                                const uint32 exact_pkg_vld,
                                const uint32 pkg_vld,
                                const uint32 lou_vld);

clx_error_no_t
hal_mt_cia_tcam_pkg_lou_set(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 udf_key_profile_id,
                            const boolean valid,
                            const clx_cia_pkt_format_t *ptr_pkt_format);

clx_error_no_t
hal_mt_cia_exact_grp_prof_get(const uint32 unit,
                              const clx_cia_stage_t stage,
                              const uint32 grp_id,
                              const uint32 ucp_member_bmp,
                              clx_cia_exact_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_cia_exact_grp_add(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 pri,
                         const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                         uint32 *ptr_grp_id);

clx_error_no_t
hal_mt_cia_exact_grp_set(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 pri,
                         const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                         uint32 grp_id);

clx_error_no_t
hal_mt_cia_exact_grp_chk(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 pri,
                         const clx_cia_exact_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_cia_grp_prof_get(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 group_id,
                        const uint32 ucp_member_bmp,
                        clx_cia_grp_prof_t *ptr_grp_prof);

clx_error_no_t
hal_mt_cia_udf_key_info_get(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 group,
                            const clx_cia_classify_t *ptr_classify,
                            hal_cia_entry_pack_udf_key_t *ptr_udf_key);
/**
 * @brief The API is used to add an exact match entry to HW.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - UCP group stage type.
 * @param [in]     grp_id            - Group id.
 * @param [in]     ptr_entry_info    - The entry information.
 * @param [out]    ptr_entry_id      - The returned entry id from HW.
 * @return         Clx_error_no_t.
 */
clx_error_no_t
hal_mt_cia_exact_entry_add(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 grp_id,
                           const clx_cia_exact_entry_t *ptr_entry_info,
                           uint32 *ptr_entry_id);

/**
 * @brief The API is used to update entry to HW.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     grp_id            - Group id.
 * @param [in]     tile_bmp          - Tile bmp.
 * @param [in]     key_buf           - New key buffer.
 * @param [in]     new_rslt_tbl      -  MT_NB_TBL_CIAT_RSLT_UCP_ACTIONS_ID or
 *                                     MT_NB_TBL_FPU_HSH_POLICY_ID.
 * @param [in]     rslt_buf          - New rslt buffer.
 * @param [in]     ptr_entry_info    - Origin flow entry info.
 * @param [out]    key_idx           - New flow entry index.
 * @param [out]    new_rslt_idx      - For 4 action - CIAT_RLST_UCP_ACTIONS index.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_cia_exact_action_update(const uint32 unit,
                               const uint32 grp_id,
                               const uint32 tile_bmp,
                               uint32 *key_buf,
                               const uint32 new_rslt_tbl,
                               uint32 *rslt_buf,
                               hal_cia_exact_entry_info_t *ptr_entry_info,
                               uint32 *key_idx,
                               uint32 *new_rslt_idx);

clx_error_no_t
hal_mt_cia_exact_entry_get(const uint32 unit,
                           const hal_cia_exact_entry_info_t *ptr_entry_info,
                           clx_cia_exact_classify_t *ptr_classify,
                           clx_cia_act_t *ptr_action);

clx_error_no_t
hal_mt_cia_exact_entry_id_info_get(const uint32 unit,
                                   const uint32 hw_entry_id,
                                   clx_cia_stage_t *ptr_stage,
                                   uint32 *ptr_grp_id);

clx_error_no_t
hal_mt_cia_exact_entry_del(const uint32 unit,
                           const uint32 grp_id,
                           hal_cia_exact_entry_info_t *ptr_entry_info);

clx_error_no_t
hal_mt_cia_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_cia_sw_entry_info_get(const uint32 unit,
                             const uint32 entry_id,
                             clx_cia_stage_t *stage,
                             uint32 *ptr_sw_entry_id);
clx_error_no_t
hal_mt_cia_exact_grp_entry_cap_usage_get(const uint32 unit,
                                         const clx_cia_stage_t stage,
                                         const uint32 group_id,
                                         const uint32 get_capacity,
                                         uint32 *ptr_cnt);
clx_error_no_t
hal_mt_cia_tapping_tpid_set(const uint32 unit, const clx_swc_cfg_t property, const uint32 tpid);

clx_error_no_t
hal_mt_cia_tapping_tpid_get(const uint32 unit, const clx_swc_cfg_t property, uint32 *tpid);

clx_error_no_t
hal_mt_cia_adj_info_update(const uint32 unit,
                           const uint32 adj_id,
                           const hal_l3_adj_info_t *ptr_adj_info);

clx_error_no_t
hal_mt_cia_range_prof_set(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const uint32 udf_prof_id,
                          const uint32 range_id,
                          const clx_cia_range_cfg_t *ptr_range);
clx_error_no_t
hal_mt_cia_range_prof_get(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const uint32 udf_prof_id,
                          const uint32 range_id,
                          const hal_cia_range_info_t *ptr_range_info,
                          clx_cia_range_cfg_t *ptr_range);

clx_error_no_t
hal_mt_cia_range_prof_clear(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 udf_prof_id,
                            const uint32 range_id);

clx_error_no_t
hal_mt_cia_range_union_set(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 union_id,
                           const uint32 range_bmp);

clx_error_no_t
hal_mt_cia_range_union_get(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 union_id,
                           uint32 *ptr_range_bmp);

clx_error_no_t
hal_mt_cia_ucp_num_get(const uint32 unit, clx_cia_stage_t stage, uint32 *ptr_ucp_num);

clx_error_no_t
hal_mt_cia_ucp_to_grp_add(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const uint32 group,
                          const uint32 new_ucp);

clx_error_no_t
hal_mt_cia_ucp_pbm_en_get(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const uint32 group,
                          uint32 *ptr_ucp_pbm_en);

clx_error_no_t
hal_mt_cia_free_ucp_pbm_get(const uint32 unit,
                            const clx_cia_stage_t stage,
                            uint32 *ptr_ucp_num,
                            uint32 *ptr_free_ucp_bmp);

clx_error_no_t
hal_mt_cia_grp_enable(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 group,
                      const uint32 enable);

clx_error_no_t
hal_mt_cia_entry_unpack(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const hal_cia_entry_info_t *ptr_entry_info,
                        boolean *ptr_entry_valid,
                        clx_cia_classify_t *ptr_classify,
                        clx_cia_act_t *ptr_action);

clx_error_no_t
hal_mt_cia_entry_id_alloc(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const uint32 group_id,
                          const uint32 entry_priority,
                          uint32 *ptr_entry_id);
clx_error_no_t
hal_mt_cia_ucp_reset(const uint32 unit, const clx_cia_stage_t stage, uint32 ucp_bmp);

/**
 * @brief The API is used to add/set an UCP entry from HW for mountain series.
 *
 * If both ptr_classify and ptr_action are NULL, the API will only modify valid bit of entry.
 * Support_chip: all.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    entry_id          - Entry id.
 * @param [in]    ptr_entry_info    - The classified and action information of the entry
 *                                    information is matched.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_cia_entry_add(const uint32 unit,
                     const uint32 entry_id,
                     const clx_cia_entry_t *ptr_entry_info);

clx_error_no_t
hal_mt_cia_ecmp_info_update(const uint32 unit,
                            const uint32 ecmp_group_id,
                            const hal_l3_ecmp_t *ptr_ecmp_info);

/**
 * @brief The API is used to get not free flow entry.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     group_id           - Group id.
 * @param [in]     ucp_member_bmp     - Ucp member bmp.
 * @param [out]    ptr_exact_entry    - The 4 action flow entry id.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No flow entry used 4 action in this group.
 * @return         CLX_E_ENTRY_EXISTS       - Has flow entry used 4 action in this group.
 */
clx_error_no_t
hal_mt_cia_exact_preempt_entry_chk(const uint32 unit,
                                   const uint32 group_id,
                                   const uint32 ucp_member_bmp,
                                   uint32 *ptr_exact_entry);

/**
 * @brief The API is used to free free flow action entry.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ucp_member_bmp    - Ucp member bmp.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_cia_exact_preempt_entry_free(const uint32 unit, const uint32 ucp_member_bmp);

/**
 * @brief The API is used to set l3 protocol parser.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    type      - L3 protocol type.
 * @param [in]    enable    - Enable/disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_cia_l3_proto_psr_set(const uint32 unit,
                            const clx_cia_cfg_l3_proto_type_t type,
                            const uint32 enable);

/**
 * @brief The API is used to get l3 protocol parser.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - L3 protocol type.
 * @param [out]    ptr_enable    - Enable/disable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_cia_l3_proto_psr_get(const uint32 unit,
                            const clx_cia_cfg_l3_proto_type_t type,
                            uint32 *ptr_enable);

clx_error_no_t
hal_mt_cia_global_parameter_set(const uint32 unit,
                                const clx_swc_cfg_t type,
                                const uint32 param0,
                                const uint32 param1);

clx_error_no_t
hal_mt_cia_global_parameter_get(const uint32 unit,
                                const clx_swc_cfg_t type,
                                uint32 *ptr_param0,
                                uint32 *ptr_param1);

#endif /* End of HAL_MT_CIA_H */
