/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_MT_PORT_H
#define HAL_MT_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <hal/hal_mac.h>
#include <hal/hal_port.h>
#include <util/lib/util_lib_avl.h>
#include <hal/mt/nb/hal_mt_nb_mac.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_PORT_LCL_MAX_NUM 8192
#define HAL_MT_NB_PTP_MSG_ONE_STEP (0x1)
#define HAL_MT_NB_PTP_MSG_TWO_STEP (0x2)
#define HAL_MT_NB_PTP_MSG_DELAY    (0x1)
#define HAL_MT_NB_PTP_MSG_PDELAY   (0x2)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_PORT_LOCK(unit)   hal_mt_port_rsc_lock(unit)
#define HAL_MT_PORT_UNLOCK(unit) hal_mt_port_rsc_unlock(unit)
/* EXPORTED SUBPROGRAM SPECIFICATIONS */

typedef enum {
    HAL_MT_PORT_TYPE_NOR = 0,
    HAL_MT_PORT_TYPE_REC = 1,
    HAL_MT_PORT_TYPE_CPU = 2,
    HAL_MT_PORT_TYPE_FAB = 3
} HAL_MT_PORT_TYPE_T;

/* Synce mode */
typedef enum {
    HAL_MT_PORT_SYNCE_MODE_DISABLE = 0x0,             /* Synce mode disable */
    HAL_MT_PORT_SYNCE_MODE_0 = CLX_PORT_SYNCE_MODE_0, /* Synce mode 0 */
    HAL_MT_PORT_SYNCE_MODE_1 = CLX_PORT_SYNCE_MODE_1, /* Synce mode 1 */
    HAL_MT_PORT_SYNCE_MODE_LAST
} HAL_MT_PORT_SYNCE_MODE_T;

typedef enum {
    HAL_MT_PORT_SPEED_CODE_DEFAULT = 0x0,
    HAL_MT_PORT_SPEED_CODE_10G = 0x1,
    HAL_MT_PORT_SPEED_CODE_25G = 0x2,
    HAL_MT_PORT_SPEED_CODE_40G = 0x4,
    HAL_MT_PORT_SPEED_CODE_50G = 0x8,
    HAL_MT_PORT_SPEED_CODE_100G = 0x10,
    HAL_MT_PORT_SPEED_CODE_200G = 0x20,
    HAL_MT_PORT_SPEED_CODE_400G = 0x40,
    HAL_MT_PORT_SPEED_CODE_800G = 0x80,
    HAL_MT_PORT_SPEED_CODE_LAST
} HAL_MT_PORT_SPEED_CODE_T;

typedef enum {
    HAL_PORT_PTP_MODE_DISABLE = 0,
    HAL_PORT_PTP_MODE_MASTER,
    HAL_PORT_PTP_MODE_SLAVE,
    HAL_PORT_PTP_MODE_TRANSPARENT,
    HAL_PORT_PTP_MODE_LAST,
} HAL_PORT_PTP_MODE_T;

typedef enum {
    HAL_MT_PORT_WBDB_ID_PBM = 0,
    HAL_MT_PORT_WBDB_ID_TXS,
    HAL_MT_PORT_WBDB_ID_RXS,
    HAL_MT_PORT_WBDB_ID_LANE_CNT,
    HAL_MT_PORT_WBDB_ID_LFC_TX,
    HAL_MT_PORT_WBDB_ID_PFC_TX,
    HAL_MT_PORT_WBDB_ID_PHY_CFG,
    HAL_MT_PORT_WBDB_ID_LAST
} HAL_MT_PORT_WBDB_ID_T;

typedef enum {
    HAL_MT_PORT_TS_REPLACE_TPYE_MAC = 0,
    HAL_MT_PORT_IGR_TS_REPLACE_SRC_MAC,
    HAL_MT_PORT_EGR_TS_REPLACE_DST_MAC,
} HAL_MT_PORT_TS_REPLACE_TYPE_T;

clx_error_no_t
hal_mt_port_default_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *ptr_speed);

clx_error_no_t
hal_mt_port_speed_lane_cnt_trans(const clx_port_speed_t speed,
                                 const uint32 lane_cnt,
                                 HAL_PORT_SPEED_LANT_T *ptr_speed_lane);

clx_error_no_t
hal_mt_port_rsc_lock(const uint32 unit);

clx_error_no_t
hal_mt_port_rsc_unlock(const uint32 unit);

/**
 * @brief To set the speed for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port id.
 * @param [in]    speed    - The speed of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief To get the speed for a specific port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [out]    ptr_speed    - The speed of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *ptr_speed);

/**
 * @brief To get the speed list for a specific port.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Physical port id.
 * @param [in]     max_len           - The max length of speedlist.
 * @param [out]    ptr_speed_list    - Speed list of the port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_speed_list_get(const uint32 unit,
                           const uint32 port,
                           const uint32 max_len,
                           clx_port_speed_t *ptr_speed_list);

/**
 * @brief To get the PFC configuration of mac.
 *
 * @param [in]     unit          - Chip id.
 * @param [in]     port          - Port id.
 * @param [out]    ptr_pfc_tx    - Pfc tx status.
 * @param [out]    ptr_pfc_rx    - Pfc rx status.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_pfc_get(const uint32 unit, const uint32 port, uint32 *ptr_pfc_tx, uint32 *ptr_pfc_rx);

/**
 * @brief To set the flow control configuration for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    fc      - The flow control configuration of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_flow_ctrl_set(const uint32 unit, const uint32 port, const clx_port_fc_dir_t fc);

/**
 * @brief To get the flow control configuration for a specific port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [out]    ptr_fc    - The flow control configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_flow_ctrl_get(const uint32 unit, const uint32 port, clx_port_fc_dir_t *ptr_fc);

/**
 * @brief To set the PFC configuration for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    pri     - The priority number 0~7.
 * @param [in]    pfc     - The PFC configuration of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_pri_flow_ctrl_set(const uint32 unit,
                              const uint32 port,
                              const uint8 pri,
                              const clx_port_fc_dir_t pfc);

/**
 * @brief To get the PFC configuration for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     pri        - The priority number 0~7.
 * @param [out]    ptr_pfc    - The PFC configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_pri_flow_ctrl_get(const uint32 unit,
                              const uint32 port,
                              const uint8 pri,
                              clx_port_fc_dir_t *ptr_pfc);

/**
 * @brief To set pkt drop for tm module.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port id.
 * @param [in]    drop_flg    - Drop flag.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_pkt_drop_set(const uint32 unit, const uint32 port, const uint8 drop_flg);

/**
 * @brief To set the EEE mode for a specific port.
 *
 * NB umac not support eee.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    mode    - The EEE mode of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_eee_mode_set(const uint32 unit, const uint32 port, const CLX_PORT_EEE_MODE_T mode);

/**
 * @brief To get the EEE mode for a specific port.
 *
 * NB umac not support eee.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [out]    ptr_mode    - The EEE mode of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_eee_mode_get(const uint32 unit, const uint32 port, CLX_PORT_EEE_MODE_T *ptr_mode);

/**
 * @brief To set the FEC configuration for a specific port.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port id.
 * @param [in]    clx_fec    - The FEC configuration of the physical port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_fec_set(const uint32 unit, const uint32 port, const uint32 clx_fec);

/**
 * @brief To get the FEC configuration for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [out]    ptr_fec    - The FEC configuration of the physical port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_fec_get(const uint32 unit, const uint32 port, uint32 *ptr_fec);

/**
 * @brief To set the administrative state for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - To enable/disable the port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_admin_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief To get the administrative state for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - To enable/disable the port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_admin_state_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief To set the autonegotiation status for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    anlt    - Toggle status of autonegotiation-linktraining per port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_anlt_status_set(const uint32 unit, const uint32 port, const uint32 anlt);

/**
 * @brief To get the autonegotiation status for a specific port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [out]    ptr_anlt    - Toggle status of autonegotiation per port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_anlt_status_get(const uint32 unit, const uint32 port, uint32 *ptr_anlt);

/**
 * @brief To set the auto-negotiation advertisement for a specific port.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    ptr_ability    - Autonegotiation ability setting per port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_local_adv_ability_set(const uint32 unit,
                                  const uint32 port,
                                  const clx_port_ability_t *ptr_ability);

/**
 * @brief To get the auto-negotiation advertisement for a specific port.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    ptr_ability    - Autonegotiation ability setting per port.
 * @return        CLX_E_OK               - The operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_local_adv_ability_get(const uint32 unit,
                                  const uint32 port,
                                  clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to get the auto-negotiation remote advertisement for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Autonegotiation ability setting per port.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_remote_adv_ability_get(const uint32 unit,
                                   const uint32 port,
                                   clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to set the loopback for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    lbtype    - Loopback type: CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                            CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                             CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL: local PHY parallel loopback.
 *                            CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL: remote serial loopback.
 *                            CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL: remote parallel loopback
 *                            external phy. CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lb_set(const uint32 unit, const uint32 port, const clx_port_loopback_t lbtype);

/**
 * @brief This API is used to get the loopback for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_lbtype    - Loopback type: CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                                 CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                                  CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL: local PHY parallel
 *                                 loopback. CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL: remote serial
 *                                 loopback. CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL: remote
 *                                 parallel loopback external phy. CLX_PORT_LOOPBACK_MAC: local MAC
 *                                 loopback.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lb_get(const uint32 unit, const uint32 port, clx_port_loopback_t *ptr_lbtype);

/**
 * @brief This API is used to set the loopback output for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    enable    - 1 for enable loopback and output, and 0 for disable loopback and
 *                            output.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lb_output_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief This API is used to get the loopback output for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_enable    - 1 for enable loopback and output, and 0 for disable loopback and
 *                                 output.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lb_output_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief This API is used to probe a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_probe(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to initialize a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_create(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to deinitialize a specific port.
 *
 * All ports in the same sub-marco on CL8600 must
 * link/admin down first before deinit a port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_destroy(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to set the lane count for a specific port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    cnt     - Lane count.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lane_cnt_set(const uint32 unit, const uint32 port, const uint32 cnt);

/**
 * @brief This API is used to get the lane count for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_cnt    - Lane count.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lane_cnt_get(const uint32 unit, const uint32 port, uint32 *ptr_cnt);

/**
 * @brief This API is used to get the physical link status for a specific port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_link    - Link status (Reference to CLX_PORT_LINK_XXX).
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_link_get(const uint32 unit, const uint32 port, uint32 *ptr_link);

/**
 * @brief This API is used to get the physical fault status for a specific port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [out]    ptr_fault    - Fault status (Reference to CLX_PORT_FAULT_XXX).
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_fault_get(const uint32 unit, const uint32 port, uint32 *ptr_fault);

/**
 * @brief This API is used to set the medium type for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    medium    - Medium type.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_medium_type_set(const uint32 unit, const uint32 port, const clx_port_medium_t medium);

/**
 * @brief This API is used to get the medium type for a specific port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_medium    - Medium type.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_medium_type_get(const uint32 unit, const uint32 port, clx_port_medium_t *ptr_medium);

/**
 * @brief This API is used to set the PHY configuration for a specific port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    ptr_config    - PHY config.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_cfg_set(const uint32 unit, const uint32 port, const clx_port_phy_cfg_t *ptr_config);

/**
 * @brief This API is used to get the property for a specific port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    ptr_config    - PHY config.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_cfg_get(const uint32 unit, const uint32 port, clx_port_phy_cfg_t *ptr_config);

/**
 * @brief Set all tx coefficients (CN3, CN2, CN1, C0, C1, C2, C3) for a specific lane Note 1:
 *        different switch family supports different coefficient number Note 2: when summation of
 *        coefficient is overflow, C0 got reduction Note 3: partial coefficients configuration is
 *        allowed (flags within struct config is necessary).
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port ID.
 * @param [in]    lane_idx       - Lane offset within th port.
 * @param [in]    location       - PHY location.
 * @param [in]    ptr_tx_coef    - The tx coefficients applied to the specific lane.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_coef_set(const uint32 unit,
                        const uint32 port,
                        const uint32 lane_idx,
                        const clx_port_phy_location_t location,
                        clx_port_tx_coef_t *ptr_tx_coef);

/**
 * @brief Set all tx coefficients (CN3, CN2, CN1, C0, C1, C2, C3) for a specific lane Note 1:
 *        different switch family supports different coefficient number Note 2: flags within the
 *        struct indicates the coefficients supported in this switch family.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [in]     lane_idx       - Lane offset within th port.
 * @param [in]     location       - PHY location.
 * @param [out]    ptr_tx_coef    - The tx coefficients applied to the specific lane.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_coef_get(const uint32 unit,
                        const uint32 port,
                        const uint32 lane_idx,
                        const clx_port_phy_location_t location,
                        clx_port_tx_coef_t *ptr_tx_coef);

/**
 * @brief This API is used to bind port vlan and bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Interface object.
 * @param [in]    svid    - First layer VLAN.
 * @param [in]    cvid    - Second layer VLAN.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_vlan_bd_bind(const uint32 unit,
                         const clx_port_t port,
                         const uint32 svid,
                         const uint32 cvid,
                         const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to unbind port vlan and bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Interface object.
 * @param [in]    svid    - First layer VLAN.
 * @param [in]    cvid    - Second layer VLAN.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_vlan_bd_unbind(const uint32 unit,
                           const clx_port_t port,
                           const uint32 svid,
                           const uint32 cvid,
                           const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to get the bridge domain bound to the port vlan.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: all.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Interface object.
 * @param [in]     svid        - First layer VLAN.
 * @param [in]     cvid        - Second layer VLAN.
 * @param [out]    ptr_bdid    - Bridge domain id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_vlan_bd_get(const uint32 unit,
                        const clx_port_t port,
                        const uint32 svid,
                        const uint32 cvid,
                        clx_bridge_domain_t *ptr_bdid);

/**
 * @brief To apply default properties for the new created port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Set port default fail.
 */
clx_error_no_t
hal_mt_port_default_set(const uint32 unit, const uint32 port);

/**
 * @brief To clear default properties for the destroyed port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Reset port default fail.
 */
clx_error_no_t
hal_mt_port_default_reset(const uint32 unit, const uint32 port);

/**
 * @brief To initialize port module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Operate success.
 * @return        CLX_E_ALREADY_INITED    - Module is reinitialized.
 * @return        CLX_E_OTHER             - Init fail.
 */
clx_error_no_t
hal_mt_port_init(const uint32 unit);

/**
 * @brief To deinitialize the port module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Success.
 * @return        CLX_E_NOT_INITED    - Module is not initialized.
 * @return        CLX_E_OTHERS        - Deinitialization failed for other reasons.
 */
clx_error_no_t
hal_mt_port_deinit(const uint32 unit);

/**
 * @brief Set Port config.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Port ID.
 * @param [in]    ptr_config    - Port config.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_cfg_set(const uint32 unit, const uint32 port, const clx_port_cfg_t *ptr_config);

/**
 * @brief Get port config.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Port ID.
 * @param [out]    ptr_config    - Port config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_cfg_get(const uint32 unit, const uint32 port, clx_port_cfg_t *ptr_config);

/**
 * @brief This API is used to get the mapping between unit/port and mac/lane number.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Physical port ID.
 * @param [out]    ptr_eth_macro    - Physical MAC macro ID (shown in schematic).
 * @param [out]    ptr_lane         - Physical lane ID.
 * @param [out]    ptr_max_speed    - The maximum speed of the physical port.
 * @param [out]    ptr_flags        - Attributes of the physical port.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_lane_map_get(const uint32 unit,
                         const uint32 port,
                         uint32 *ptr_eth_macro,
                         uint32 *ptr_lane,
                         clx_port_speed_t *ptr_max_speed,
                         uint32 *ptr_flags);

/**
 * @brief This API is used to set the configs for a specific interface object.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     intf          - Interface object.
 * @param [out]    ptr_config    - The pointer of the interface configs.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_intf_cfg_set(const uint32 unit,
                         const clx_port_t intf,
                         const clx_port_intf_cfg_t *ptr_config);

/**
 * @brief This API is used to set the configs for a specific interface object.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     intf          - Interface object.
 * @param [out]    ptr_config    - The pointer of the interface configs.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_intf_cfg_get(const uint32 unit, const clx_port_t intf, clx_port_intf_cfg_t *ptr_config);

/**
 * @brief Set port timestamp state.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    enable    - Timestamp state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_ts_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get port timestamp state.
 *
 * @param [in]     unit          - Chip id.
 * @param [in]     port          - Port id.
 * @param [out]    ptr_enable    - Timestamp state.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_ts_state_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Get port tx timestamp entry information.
 *
 * @param [in]     unit            - Chip id.
 * @param [in]     port            - Port id.
 * @param [out]    ptr_ts_entry    - Timestamp entry information.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_ts_tx_entry_get(const uint32 unit,
                            const uint32 port,
                            clx_port_ts_entry_t *ptr_ts_entry);

/**
 * @brief Get port rx timestamp entry information.
 *
 * @param [in]     unit            - Chip id.
 * @param [in]     port            - Port id.
 * @param [out]    ptr_ts_entry    - Timestamp entry information.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_ts_rx_entry_get(const uint32 unit,
                            const uint32 port,
                            clx_port_ts_entry_t *ptr_ts_entry);

/**
 * @brief Set port rx/tx TS latency based on clock, port speed and FEC.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_port_ts_latency_update(const uint32 unit, const uint32 port);

/**
 * @brief Set unidirectional link feature per physical port.
 *
 * The port is always operationally up. The operational status does not
 * depend on local faults and remote faults.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1 for enable unidirectional link, and 0 for disable unidirectional
 *                            link.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_unidirectional_link_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get unidirectional link feature per physical port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port id.
 * @param [in]    ptr_enable    - 1 for enable unidirectional link, and 0 for disable
 *                                unidirectional link.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_unidirectional_link_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set tx state per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable tx state 0: disable tx state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get tx state per physical port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port id.
 * @param [in]    ptr_enable    - 1: tx state is enalbed 0: tx state is disabled.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_state_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set rx state per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable rx state 0: disable rx state.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_rx_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get rx state per physical port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port id.
 * @param [in]    ptr_enable    - 1: rx state is enalbed 0: rx state is disabled.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_rx_state_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set rx idle per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable rx idle 0: disable rx idle.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_rx_idle_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get rx idle per physical port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port id.
 * @param [in]    ptr_enable    - 1: rx idle is enabled 0: rx idle is disabled.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_rx_idle_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set led state for a specific port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    chmode    - Mac chmode.
 * @param [in]    enable    - 1 for enable led, and 0 for disable led.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_led_set(const uint32 unit,
                    const uint32 port,
                    HAL_MT_NB_MAC_CHMODE_E chmode,
                    const uint32 enable);

/**
 * @brief Set MxLink per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable MxLink 0: disable MxLink.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NOT_SUPPORT      - Not support MxLink.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mxlink_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get replace mac Enable per physical port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [in]     type          - Refer to HAL_MT_PORT_TS_REPLACE_TYPE_T.
 * @param [out]    ptr_enable    - 0/1: disable/enable timestamp replace mac,
 *                                 .
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_ts_replace_mac_en_get(const uint32 unit,
                                  const uint32 port,
                                  const HAL_MT_PORT_TS_REPLACE_TYPE_T type,
                                  boolean *ptr_enable);

/**
 * @brief Set replace mac Enable per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    type      - Refer to HAL_MT_PORT_TS_REPLACE_TYPE_T.
 * @param [in]    enable    - 1: enable timestamp replace mac 0: disable timestamp replace mac.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_ts_replace_mac_en_set(const uint32 unit,
                                  const uint32 port,
                                  const HAL_MT_PORT_TS_REPLACE_TYPE_T type,
                                  const boolean enable);

/**
 * @brief Set MxHdr Enable per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable MxHdr 0: disable MxHdr.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NOT_SUPPORT      - Not support MxHdr.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mxhdr_en_set(const uint32 unit, const uint32 port, const boolean enable);

/**
 * @brief Get MxHdr Enable per physical port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - 0/1: disable/enable MxHdr,.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_NOT_SUPPORT      - Not support MxHdr.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mxhdr_en_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Get MxLink per physical port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port id.
 * @param [in]    ptr_enable    - 1: MxLink is enalbed 0: MxLink is disabled.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NOT_SUPPORT      - Not support MxLink.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mxlink_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set max length of mib counter per physical port.
 *
 * When packet length is larger than the max length, it will be counted to
 * over-size counter. For example, if MIB_MAX_LENGTH = 2000,
 * for packet with 1518 < length <= 2000, it will be counted to
 * MIB SRAM register of 1519_2560. And for packet length > 2000,
 * it will be counted to oversize_good or oversize_bad counter.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port id.
 * @param [in]    max_len    - Max length of mib counter.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mib_max_len_set(const uint32 unit, const uint32 port, const uint32 max_len);

/**
 * @brief Get max length of mib counter per physical port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [out]    ptr_max_len    - Max length of mib counter.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mib_max_len_get(const uint32 unit, const uint32 port, uint32 *ptr_max_len);

/**
 * @brief Get the status per physical port.
 *
 * There is 8 bits for 8 RX priority flow control status in rx_pfc.
 * RX flow control status for priority x (x = 0~7) =
 * rx_pfc & (CLX_PORT_FC_STATUS_ON << x).
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_status    - Port status speed - reference to clx_port_speed_t link -
 *                                 reference to CLX_PORT_LINK_XXX fault - reference to
 *                                 CLX_PORT_FAULT_XXX rx_fc - reference to CLX_PORT_FC_STATUS_XXX
 *                                 rx_pfc - reference to CLX_PORT_FC_STATUS_XXX.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_status_get(const uint32 unit, const uint32 port, clx_port_status_t *ptr_status);

/**
 * @brief Force to transmit remote fault out.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: force to transmit remote fault out 0: work as usual.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_remote_fault_set(const uint32 unit, const uint32 port, uint32 enable);

/**
 * @brief Dump the database per physical port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    flags    - Database type.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_db_dump(const uint32 unit, const uint32 flags);

/**
 * @brief To get the autonegotiation status for a specific port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [out]    ptr_anlt    - Toggle status of autonegotiation per port.
 * @return         CLX_E_OK               - The operation is success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_anlt_get(const uint32 unit, const uint32 port, uint32 *ptr_anlt);

/**
 * @brief Set Mac property per physical port.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port id.
 * @param [in]    property    - Mac property type.
 * @param [in]    value       - Mac property value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mac_cfg_set(const uint32 unit,
                        const uint32 port,
                        const HAL_MAC_PROPERTY_T property,
                        const uint32 value);

/**
 * @brief Set SyncE state per physical port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    mode    - SyncE mode.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_synce_mode_set(const uint32 unit, const uint32 port, const clx_port_synce_mode_t mode);

/**
 * @brief Get SyncE mode per physical port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port id.
 * @param [out]    ptr_mode    - SyncE mode.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_synce_mode_get(const uint32 unit, const uint32 port, clx_port_synce_mode_t *ptr_mode);

/**
 * @brief Get MAC property per physical port.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port id.
 * @param [in]     property     - Mac property type.
 * @param [out]    ptr_value    - Mac property value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mac_cfg_get(const uint32 unit,
                        const uint32 port,
                        const HAL_MAC_PROPERTY_T property,
                        uint32 *ptr_value);

/**
 * @brief This API is used to get link database for a specific port.
 *
 * There are 8 bits for 8 priority flow control state in pfc_tx.
 * Tx flow control state for priority x (x = 0~7) = pfc_tx & (1 << x).
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port id.
 * @param [out]    ptr_tx_state    - Tx state.
 * @param [out]    ptr_rx_state    - Rx state.
 * @param [out]    ptr_lfc_tx      - Local flow control state.
 * @param [out]    ptr_pfc_tx      - Priority flow control state.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_mt_port_link_db_get(const uint32 unit,
                        const uint32 port,
                        uint32 *ptr_tx_state,
                        uint32 *ptr_rx_state,
                        uint32 *ptr_lfc_tx,
                        uint32 *ptr_pfc_tx);

/**
 * @brief Set meter per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    dir       - Ingress or egress.
 * @param [in]    enable    - Enable meter or not.
 * @param [in]    mtr_id    - Meter index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NOT_SUPPORT      - Not support meter.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_meter_set(const uint32 unit,
                      const uint32 port,
                      const clx_dir_t dir,
                      const boolean enable,
                      const uint32 mtr_id);

/**
 * @brief Get meter per physical port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [in]     dir           - Ingress or egress.
 * @param [out]    ptr_enable    - Enable meter or not.
 * @param [out]    ptr_mtr_id    - Meter index.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_NOT_SUPPORT      - Not support MxLink.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_meter_get(const uint32 unit,
                      const uint32 port,
                      const clx_dir_t dir,
                      boolean *ptr_enable,
                      uint32 *ptr_mtr_id);

/**
 * @brief Set split horizon per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable split horizon.
 * @return        CLX_E_OK           - Operate success.
 * @return        CLX_E_BAD_PARAM    - Bad parameter.
 * @return        CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
hal_mt_port_split_horizon_set(const uint32 unit, const uint32 port, const boolean enable);

/**
 * @brief Get split horizon per physical port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_enable    - Enable/Disable split horizon.
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter.
 * @return         CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
hal_mt_port_split_horizon_get(const uint32 unit, const uint32 port, boolean *ptr_enable);

/**
 * @brief This API is used to get the ability for a specific port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Port ability.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_ability_get(const uint32 unit, const uint32 port, clx_port_ability_t *ptr_ability);

/**
 * @brief Set egress high latency per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - Enable/Disable high latency.
 * @return        CLX_E_OK           - Operate success.
 * @return        CLX_E_BAD_PARAM    - Bad parameter.
 * @return        CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
hal_mt_port_egr_high_latency_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get high latency per physical port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port id.
 * @param [out]    enable    - Enable/Disable high latency.
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter.
 * @return         CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
hal_mt_port_egr_high_latency_get(const uint32 unit, const uint32 port, boolean *enable);

/**
 * @brief Set high latency threshold.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    threshold    - High latency threshold.
 * @return        CLX_E_OK           - Operate success.
 * @return        CLX_E_BAD_PARAM    - Bad parameter.
 * @return        CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
hal_mt_port_egr_high_latency_thd_set(const uint32 unit, const uint32 threshold);

/**
 * @brief Get high latency threshold.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    threshold    - High latency threshold.
 * @return         CLX_E_OK           - Operate success.
 * @return         CLX_E_BAD_PARAM    - Bad parameter.
 * @return         CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
hal_mt_port_egr_high_latency_thd_get(const uint32 unit, uint32 *threshold);

/**
 * @brief This API is used to update the tad mode for a local interface.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    plane_id    - Plane ID.
 * @param [in]    lcl_intf    - Local interface.
 * @param [in]    tag_mode    - Tag mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_intf_tag_mode_update(const uint32 unit,
                                 const uint32 plane_id,
                                 const uint32 lcl_intf,
                                 const uint32 tag_mode);

/**
 * @brief Set Mburst property.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    property    - Property type.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mburst_cfg_set(const uint32 unit,
                           const uint32 port,
                           const clx_port_mburst_cfg_t *property);

/**
 * @brief Get Mburst property.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    property    - Property type.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mburst_cfg_get(const uint32 unit, const uint32 port, clx_port_mburst_cfg_t *property);

/**
 * @brief Get mburst statistic.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     dir         - Direction.
 * @param [out]    ptr_stat    - Mburst stat.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mburst_stat_get(const uint32 unit,
                            const uint32 port,
                            const clx_dir_t dir,
                            clx_port_mburst_stat_t *ptr_stat);

/**
 * @brief Get Mburst Histogram threshold.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [in]     dir          - IPL or EPL.
 * @param [in]     thrd_num     - Threshold num.
 * @param [out]    ptr_count    - Mburst Histogram count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mburst_hist_cnt_get(const uint32 unit,
                                const uint32 port,
                                const clx_dir_t dir,
                                const uint32 thrd_num,
                                uint32 *ptr_count);

/**
 * @brief Clear Mburst count.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    dir     - IPL or EPL.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_mburst_cnt_clear(const uint32 unit, const uint32 port, const clx_dir_t dir);

/**
 * @brief Get capacity of port-related resource.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Resource type.
 * @param [in]     param       - Parameter if necessary.
 * @param [out]    ptr_size    - Size of capacity.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_capacity_get(const uint32 unit,
                         const clx_swc_rsrc_t type,
                         const uint32 param,
                         uint32 *ptr_size);

/**
 * @brief Get usage of port-related resource.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Resource type.
 * @param [in]     param      - Parameter if necessary.
 * @param [out]    ptr_cnt    - Count of usage.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_usage_get(const uint32 unit,
                      const clx_swc_rsrc_t type,
                      const uint32 param,
                      uint32 *ptr_cnt);

/**
 * @brief Set phy prbs error inject.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    num_err    - Parameter if necessary.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_prbs_err_inject(const uint32 unit, const uint32 port, const uint32 num_err);

/**
 * @brief Set port prbs error bits clear.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_prbs_err_cnt_clear_set(const uint32 unit, const uint32 port, const uint32 lane_bmp);

/**
 * @brief Get phy firmware version.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port ID.
 * @param [out]    ptr_version_eth    - Eth phy firmware version.
 * @param [out]    ptr_version_cpi    - Cpi phy firmware version.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_fw_version_get(const uint32 unit,
                               const uint32 port,
                               uint32 *ptr_version_eth,
                               uint32 *ptr_version_cpi);

/**
 * @brief Get phy rate code.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    pma_rate    - Phy rate code: 0: 10P3125 1: 25P78125 2: 26P5625 3: 53P125_NRZ 4:
 *                               53P125_PAM4 5: 56P25_PAM4 6: 106P25 7: 112P5.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_rate_get(const uint32 unit, const uint32 port, uint32 *pma_rate);

/**
 * @brief Set phy to isolation mode.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    enable      - Enable/disable isolation mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_isola_mode_set(const uint32 unit,
                               const uint32 port,
                               const uint32 lane_bmp,
                               const uint32 enable);

/**
 * @brief Set phy tx or rx powerup.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    lane_bmp      - Lane bitmap.
 * @param [in]    module        - Tx or rx.
 * @param [in]    lane_speed    - Serdes lane speed.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_txrx_powerup_set(const uint32 unit,
                                 const uint32 port,
                                 const uint32 lane_bmp,
                                 const clx_dir_t module,
                                 const clx_port_lane_speed_t lane_speed);

/**
 * @brief Set phy tx elecidle.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    enable    - Enable or disable.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_tx_elecidle_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get phy tx elecidle.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_enable    - Phy tx elecidle.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_tx_elecidle_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Set phy rx termination mode.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    mode        - Termination mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_rx_term_set(const uint32 unit,
                            const uint32 port,
                            const uint32 lane_bmp,
                            const clx_port_acc_term_mode_t mode);

/**
 * @brief Get phy rx termination mode.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_mode    - Phy rx termination mode.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_rx_term_get(const uint32 unit, const uint32 port, uint32 *ptr_mode);

/**
 * @brief Get phy Atest or Pmon data.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    mode        - Atest mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_atest_pmon_get(const uint32 unit,
                               const uint32 port,
                               const uint32 lane_bmp,
                               const uint32 mode);

/**
 * @brief Get phy rx snr.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_snr_int    - Snr calculate integer value.
 * @param [out]    ptr_snr_dec    - Snr calculate decimal value.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_rx_snr_get(const uint32 unit,
                           const uint32 port,
                           uint32 *ptr_snr_int,
                           uint32 *ptr_snr_dec);
/**
 * @brief Set port ptp mode.
 *
 * @param [in]    unit                  - Device unit number.
 * @param [in]    port                  - Physical port ID.
 * @param [in]    ptp_sync_mode_step    - Ptp sync mode and sync step.
 * @param [in]    mode                  - Ptp mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_ptp_mode_set(const uint32 unit,
                         const uint32 port,
                         const uint32 ptp_sync_mode_step,
                         const uint32 mode);

/**
 * @brief This API is used to set the egress TPID0 as TPID1 value for RSPAN port.
 *
 * Called by mirror module.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port             - Port Number.
 * @param [in]    is_rspan_port    - Port is RSPAN port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_egr_port_tpid_for_rspan_set(const uint32 unit,
                                        const uint32 port,
                                        const boolean is_rspan_port);

clx_error_no_t
hal_mt_port_lane_cnt_update(const uint32 unit);

clx_error_no_t
hal_mt_port_mac_config_update(uint32 unit, uint32 port, uint32 an_speed, uint32 an_fec);

/**
 * @brief Get phy tx signal.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_enable    - Phy tx signal.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_tx_signal_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief Get the port origin si.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Physical port ID.
 * @param [out]    ptr_origin_si    - Port origin si.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_origin_si_get(const uint32 unit, const uint32 port, uint32 *ptr_origin_si);
/**
 * @brief Set phy tx signal.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    enable    - Enable or disable.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_phy_tx_signal_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set the port origin si.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Physical port ID.
 * @param [in]    origin_si    - Port origin si.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_origin_si_set(const uint32 unit, const uint32 port, const uint32 origin_si);
/**
 * @brief Register/deregister phy tx signal callback.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    func          - Callback function.
 * @param [in]    ptr_cookie    - Cookie data of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_port_tx_signal_register(const uint32 unit,
                               clx_port_phy_notify_func_t func,
                               void *ptr_cookie);
#endif /* #ifndef HAL_MT_PORT_H */
