/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_lag.h
 * PURPOSE:
 *      It provides LAG module API.
 * NOTES:
 *
 */

#ifndef CLX_LAG_H
#define CLX_LAG_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum clx_lag_type_e {
    CLX_LAG_RH_TYPE = 0,   /* Resilient hash */
    CLX_LAG_RR_TYPE,       /* Round-Robin */
    CLX_LAG_WEIGHT_TYPE,   /* Weighted */
    CLX_LAG_SEL_ALGO_TYPE, /* Member selectable algo */
    CLX_LAG_LAST_TYPE,
} clx_lag_type_t;

/* Lag Algorithm mode */
typedef enum clx_lag_algorithm_mode_e {
    CLX_LAG_ALGORITHM_HI_MODE = 0, /* only use act list */
    CLX_LAG_ALGORITHM_LO_MODE,     /* only use ori list */
    CLX_LAG_ALGORITHM_BOTH_MODE,   /* use ori and act list */
    CLX_LAG_ALGORITHM_MODE_LAST
} clx_lag_algorithm_mode_t;

typedef struct clx_lag_create_info_s {
    uint32 flag; /* CLX_LAG_CREATE_FLAG_XXX */
    clx_lag_type_t lag_type;
} clx_lag_create_info_t;
#define CLX_LAG_CREATE_FLAG_WITH_ID     (1U << 0) /* The lag id is be specified by user */
#define CLX_LAG_CREATE_FLAG_MEMBER_SORT (1U << 1) /* If set, create a lag with sorted members */

typedef struct clx_lag_attr_s {
    uint32 flag; /* CLX_LAG_ATTE_FLAG_XXX */
    clx_lag_type_t lag_type;
    clx_swc_hsh_pkt_type_t uc_hash_type;
    clx_swc_hsh_pkt_type_t mc_hash_type;
    clx_lag_algorithm_mode_t lag_algo_mode;
} clx_lag_attr_t;
#define CLX_LAG_ATTR_FLAGS_LAG_TYPE_VALID         (1U << 0)
#define CLX_LAG_ATTR_FLAGS_UC_LAG_HASH_TYPE_VALID (1U << 1)
#define CLX_LAG_ATTR_FLAGS_LAG_ALGL_MODE_VALID    (1U << 2)

typedef struct clx_lag_traverse_info_s {
    uint32 flag;
    uint32 lag_id;       /* Link aggregation group ID */
    clx_port_t lag_port; /* LAG port*/
} clx_lag_traverse_info_t;

/* lag hash path result info */
typedef struct clx_lag_hashpath_rslt_info_s {
    uint32 hash_value;   /* flow hash value, lag only use 0-9 bit flow hash value */
    uint32 hash_path_di; /* lag hash path di */
} clx_lag_hashpath_rslt_info_t;

typedef struct clx_lag_member_s {
    uint32 flag;       /* CLX_LAG_MEMBER_ATTR_FLAG_XXX */
    clx_port_t member; /* Lag member. */
    uint32 weight;     /* The weight of lag member. */
} clx_lag_member_t;
#define CLX_LAG_MEMBER_ATTR_FLAG_INGRESS_DISABLE (1U << 0)
#define CLX_LAG_MEMBER_ATTR_FLAG_EGRESS_DISABLE  (1U << 1)

/* lag info */
typedef struct clx_lag_chip_info_s {
    uint32 lag_group_max_num;
    uint32 lag_member_max_num;
    uint32 lag_group_min_id;
    uint32 lag_group_max_id;
} clx_lag_chip_info_t;

typedef struct clx_mglag_attr_s {
    uint32 flag;                              /* CLX_MGLAG_ATTR_FLAG_XXX*/
} clx_mglag_attr_t;
#define CLX_MGLAG_ATTR_FLAG_WITH_ID (1U << 0) /* The mglag id is be specified by user */

typedef struct clx_mglag_member_s {
    uint32 member_cnt;
    uint32 *mc_member;
} clx_mglag_member_t;

typedef clx_error_no_t (*clx_lag_trav_func_t)(uint32 unit,
                                              const clx_lag_traverse_info_t *ptr_info,
                                              void *cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Create a new lag.
 *
 * This API is used to create a new lag. The lag_id can be specified
 * by user or automatically assigned by the software.
 * Support_chip: CLX86.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     ptr_lag_create_info    - The pointer to lag create info @param [in,
 *                                          out] ptr_lag_id - The pointer to lag id which will be
 *                                          created.
 * @param [out]    ptr_lag_port           - The pointer to lag port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
clx_error_no_t
clx_lag_create(const uint32 unit,
               const clx_lag_create_info_t *ptr_lag_create_info,
               uint32 *ptr_lag_id,
               clx_port_t *ptr_lag_port);

/**
 * @brief Destroy a lag with user specified lag id.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    lag_id    - Lag id which will be deleted.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
clx_error_no_t
clx_lag_destroy(const uint32 unit, const uint32 lag_id);

/**
 * @brief This API is used to set the lag attr.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    lag_id      - Lag id.
 * @param [in]    ptr_attr    - Pointer of the lag attr.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_lag_attr_set(const uint32 unit, const uint32 lag_id, const clx_lag_attr_t *ptr_attr);

/**
 * @brief This API is used to get the lag attr.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     lag_id      - Lag id.
 * @param [out]    ptr_attr    - Pointer of the lag attr.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_lag_attr_get(const uint32 unit, const uint32 lag_id, clx_lag_attr_t *ptr_attr);

/**
 * @brief Set lag member.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    lag_id        - Lag id.
 * @param [in]    member_cnt    - Set member port count.
 * @param [in]    ptr_member    - The pointer to lag member list.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_lag_member_set(const uint32 unit,
                   const uint32 lag_id,
                   const uint32 member_cnt,
                   const clx_lag_member_t *ptr_member);

/**
 * @brief Get lag member.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                     - Device unit number.
 * @param [in]     lag_id                   - Lag id.
 * @param [in]     member_cnt               - Get member port count.
 * @param [out]    ptr_member               - The pointer to member list.
 * @param [out]    ptr_actual_member_cnt    - The pointer to actual member port count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_lag_member_get(const uint32 unit,
                   const uint32 lag_id,
                   const uint32 member_cnt,
                   clx_lag_member_t *ptr_member,
                   uint32 *ptr_actual_member_cnt);

/**
 * @brief Get LAG member count.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     lag_id            - Lag id.
 * @param [out]    ptr_member_cnt    - The pointer to lag member count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_lag_member_cnt_get(const uint32 unit, const uint32 lag_id, uint32 *ptr_member_cnt);

/**
 * @brief Get lag id from lag port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     lag_port      - Lag port.
 * @param [out]    ptr_lag_id    - The pointer to lag id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_lag_id_get(const uint32 unit, clx_port_t lag_port, uint32 *ptr_lag_id);

/**
 * @brief Get lag port from lag id.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     lag_id          - Lag id.
 * @param [out]    ptr_lag_port    - The pointer to lag gport.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_lag_port_get(const uint32 unit, uint32 lag_id, clx_port_t *ptr_lag_port);

/**
 * @brief Traver all lags.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    callback      - The callback function of type clx_lag_trav_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_lag_trav(const uint32 unit, const clx_lag_trav_func_t callback, void *ptr_cookie);
#endif /* End of CLX_LAG_H */