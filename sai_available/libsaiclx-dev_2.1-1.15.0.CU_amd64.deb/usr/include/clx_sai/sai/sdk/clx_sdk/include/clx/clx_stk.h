/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_stk.h
 * PURPOSE:
 *      It provides stacking module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_STK_H
#define CLX_STK_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <clx/clx_pkt.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum clx_stk_chip_mode_e {
    CLX_STK_CHIP_MODE_SINGLE_CHIP, /* Single chip mode. */
    CLX_STK_CHIP_MODE_FABRIC,      /* Fabric mode. */
    CLX_STK_CHIP_MODE_LINECARD,    /* Linecard mode. */
    CLX_STK_CHIP_MODE_EXTENDED_DI, /* Extended DI mode. Linecard support more path to connect np.
                                    */
    CLX_STK_CHIP_MODE_LAST
} clx_stk_chip_mode_t;

typedef enum clx_stk_chip_cfg_type_e {
    CLX_STK_CHIP_CFG_TYPE_MY_CHIP_ID,       /* device chip id */
    CLX_STK_CHIP_CFG_TYPE_NEIGHBOR_CHIP_ID, /* neighbor chip id. Not supported on CL8600. */
    CLX_STK_CHIP_CFG_TYPE_CUT_OFF_CHIP_ID,  /* cut off chip id. Not supported on CL8600. */
    CLX_STK_CHIP_CFG_TYPE_LAST
} clx_stk_chip_cfg_type_t;

typedef enum clx_stk_port_cfg_type_e {
    CLX_STK_PORT_CFG_TYPE_PORT,
    CLX_STK_PORT_CFG_TYPE_CPU_PORT, /* Not supported on CL8600. */
    CLX_STK_PORT_CFG_TYPE_DPI_PORT, /* enable fabric port function but not join fabric link */
    CLX_STK_PORT_CFG_TYPE_LAST
} clx_stk_port_cfg_type_t;

typedef enum clx_stk_path_cfg_type_e {
    CLX_STK_PATH_CFG_TYPE_PATH,
    CLX_STK_PATH_CFG_TYPE_CPU_PATH, /* Not supported on CL8600. */
    CLX_STK_PATH_CFG_TYPE_LAST
} clx_stk_path_cfg_type_t;

typedef struct clx_stk_chip_cfg_s {
    uint32 chip; /* chip id */
    uint32 path; /* fabric link id */
} clx_stk_chip_cfg_t;

typedef struct clx_stk_port_cfg_s {
    uint32 path;                 /* fabric link id */
    uint32 port;                 /* port number */
    clx_port_bitmap_t port_list; /* port list. only for get operation */
} clx_stk_port_cfg_t;

typedef struct clx_stk_path_cfg_s {
    uint32 chip; /* chip id */
    uint32 path; /* fabric link id */
} clx_stk_path_cfg_t;

typedef struct clx_stk_dil_s {
    /* eth port */
    uint32 plane; /* plane id */
    uint32 port;  /* port id */
    /* fab port */
    uint32 fl_id;  /* fabric link id */
    boolean is_fl; /* 0: eth port; 1: fabric port */
} clx_stk_dil_t;

/**
 * @brief This API is used to set the DIL entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    di               - Destination index.
 * @param [in]    ptr_dil_entry    - DIL entry.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stk_dil_entry_set(const uint32 unit, const uint32 di, const clx_stk_dil_t *ptr_dil_entry);

/**
 * @brief This API is used to get the DIL entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     di               - Destination index.
 * @param [out]    ptr_dil_entry    - DIL entry.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stk_dil_entry_get(const uint32 unit, const uint32 di, clx_stk_dil_t *ptr_dil_entry);

/**
 * @brief This API is used to get chip mode.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [out]    ptr_chip_mode    - Chip mode.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
clx_stk_chip_mode_get(const uint32 unit, uint32 *ptr_chip_mode);

/**
 * @brief This API is used to set chip configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    cfg_type        - Chip configuration type.
 * @param [in]    ptr_chip_cfg    - Chip configuration.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stk_chip_cfg_set(const uint32 unit,
                     const clx_stk_chip_cfg_type_t cfg_type,
                     const clx_stk_chip_cfg_t *ptr_chip_cfg);

/**
 * @brief This API is used to get chip configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     cfg_type        - Chip configuration type.
 * @param [out]    ptr_chip_cfg    - Chip configuration.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stk_chip_cfg_get(const uint32 unit,
                     const clx_stk_chip_cfg_type_t cfg_type,
                     clx_stk_chip_cfg_t *ptr_chip_cfg);

/**
 * @brief This API is used to get port list from fabric path.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     cfg_type        - Port configuration type.
 * @param [out]    ptr_port_cfg    - Port configuration.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */

clx_error_no_t
clx_stk_fab_port_get(const uint32 unit,
                     const clx_stk_port_cfg_type_t cfg_type,
                     clx_stk_port_cfg_t *ptr_port_cfg);

/**
 * @brief This API is used to add port into fabric path.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    cfg_type        - Port configuration type.
 * @param [in]    ptr_port_cfg    - Port configuration.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stk_fab_port_add(const uint32 unit,
                     const clx_stk_port_cfg_type_t cfg_type,
                     const clx_stk_port_cfg_t *ptr_port_cfg);

/**
 * @brief This API is used to delete port from fabric path.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    cfg_type        - Port configuration type.
 * @param [in]    ptr_port_cfg    - Port configuration.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stk_fab_port_del(const uint32 unit,
                     const clx_stk_port_cfg_type_t cfg_type,
                     const clx_stk_port_cfg_t *ptr_port_cfg);

/**
 * @brief This API is used to set the mapping of path and remote chip.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    cfg_type        - Path configuration type.
 * @param [in]    ptr_path_cfg    - Path configuration.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stk_path_remote_map_set(const uint32 unit,
                            const clx_stk_path_cfg_type_t cfg_type,
                            const clx_stk_path_cfg_t *ptr_path_cfg);

/**
 * @brief This API is used to get extended chip di range.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     chip           - Device chip id.
 * @param [out]    ptr_di_base    - DI base.
 * @param [out]    ptr_di_num     - DI number.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stk_ext_chip_di_info_get(const uint32 unit,
                             const uint32 chip,
                             uint32 *ptr_di_base,
                             uint32 *ptr_di_num);

#endif
