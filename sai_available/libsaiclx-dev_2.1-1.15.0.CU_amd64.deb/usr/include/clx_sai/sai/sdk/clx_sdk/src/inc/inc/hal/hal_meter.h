/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_meter.h
 * PURPOSE:
 *    It provides HAL driver API functions for meter module.
 *
 * NOTES:
 *    None
 */
#ifndef HAL_METER_H
#define HAL_METER_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_meter.h>
#include <clx/clx_init.h>
#include <clx/clx_cfg.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_METER_SERVICE_TYPE_NUM (8)  /* interface, phy port, and domain, etc */
#define HAL_METER_CIA_TYPE_NUM     (16) /* total of icia ucp grps and ecia ucp grps */

/* bucket count in one meter */
#define HAL_METER_BUCKET_CNT (2)

/* fixed packet length for packet mode */
#define HAL_METER_PKT_LEN (128)

/* meter register words number */
#define HAL_METER_REG_WORDS (1)

/* meter token variate words number */
#define HAL_METER_TOKEN_VAR_WORDS (2)

/* MACRO FUNCTION DECLARATIONS
 */

/* Meter pool mgmt control block */
#define HAL_METER_POOL_MGMT_CB(unit) (_hal_meter_pool_mgmt_cb[unit])

/* global meter bank capacity, unit: double bucket */
#define HAL_METER_GLOBAL_BANK_CAPACITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->g_bank_capacity)

/* max global meter rate, unit: kbps */
#define HAL_METER_GLOBAL_RATE_MAX(unit) (PTR_HAL_CONST_INFO(unit, meter)->g_rate_max)

/* plane meter bank capacity, unit: double bucket */
#define HAL_METER_PLANE_BANK_CAPACITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->p_bank_capacity)

/* reserved meter bank capacity, unit: double bucket */
#define HAL_METER_RSV_BANK_CAPACITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->rsv_bank_capacity)

/* meter rate granularity, unit: kbps */
#define HAL_METER_RATE_GRANULARITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->rate_gra)

/* max plane meter rate, unit: kbps */
#define HAL_METER_PLANE_RATE_MAX(unit) (PTR_HAL_CONST_INFO(unit, meter)->p_rate_max)

/* meter bucket granularity, unit: byte */
#define HAL_METER_BUCKET_GRANULARITY(unit) (PTR_HAL_CONST_INFO(unit, meter)->bucket_gra)

/* max meter bucket size, unit: byte */
#define HAL_METER_BUCKET_MAX(unit, global)                               \
    ((1 == (global)) ? (PTR_HAL_CONST_INFO(unit, meter)->g_bucket_max) : \
                       (PTR_HAL_CONST_INFO(unit, meter)->p_bucket_max))

/* ucp group number for ingress cia */
#define HAL_METER_INGRESS_UCP_GRP_NUM(unit) (PTR_HAL_CONST_INFO(unit, meter)->igr_grp_num)

/* ucp group number for egress cia */
#define HAL_METER_EGRESS_UCP_GRP_NUM(unit) (PTR_HAL_CONST_INFO(unit, meter)->egr_grp_num)

/* plane meter pool entry number */
#define HAL_METER_POOL_PLANE_ENTRY_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->p_entry_num)

/* global meter pool entry number */
#define HAL_METER_POOL_GLOBAL_ENTRY_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->g_entry_num)

/* reserved meter pool entry number */
#define HAL_METER_POOL_RSV_ENTRY_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->rsv_entry_num)

/* total meter pool entry number */
#define HAL_METER_POOL_ENTRY_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->total_entry_num)

/* plane meter bank number */
#define HAL_METER_BANK_PLANE_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->p_bank_num)

/* global meter bank number */
#define HAL_METER_BANK_GLOBAL_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->g_bank_num)

/* reserved meter bank number */
#define HAL_METER_BANK_RSV_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->rsv_bank_num)

/* total meter bank number */
#define HAL_METER_BANK_NUM(unit) (HAL_METER_POOL_MGMT_CB(unit)->total_bank_num)

/* meter translate packet to rate
 * rate = (((packet) * HAL_METER_PKT_LEN * 8) / 1000)
 */
#define HAL_METER_PKT_TO_RATE(packet, rate)                   \
    do {                                                      \
        uint64 __pkt1__;                                      \
        uint64 __rate1__;                                     \
        osal_memset(&__pkt1__, 0, sizeof(uint64));            \
        osal_memset(&__rate1__, 0, sizeof(uint64));           \
        UI64_ADD_UI32(__pkt1__, packet);                      \
        UI64_MULT_UI32(__pkt1__, (HAL_METER_PKT_LEN * 8));    \
        util_lib_bit_u64_div_u32(__pkt1__, 1000, &__rate1__); \
        rate = UI64_LOW(__rate1__);                           \
    } while (0)

/* meter translate rate to packet
 * packet =  (((rate) * 1000) / (HAL_METER_PKT_LEN * 8))
 */
#define HAL_METER_RATE_TO_PKT(rate, packet)                                      \
    do {                                                                         \
        uint64 __pkt2__;                                                         \
        uint64 __rate2__;                                                        \
        osal_memset(&__pkt2__, 0, sizeof(uint64));                               \
        osal_memset(&__rate2__, 0, sizeof(uint64));                              \
        UI64_ADD_UI32(__rate2__, rate);                                          \
        UI64_MULT_UI32(__rate2__, (1000));                                       \
        util_lib_bit_u64_div_u32(__rate2__, (HAL_METER_PKT_LEN * 8), &__pkt2__); \
        packet = UI64_LOW(__pkt2__);                                             \
    } while (0)

/* meter translate round rate to packet */
#define HAL_METER_ROUND_RATE_TO_PKT(rate, packet)          \
    do {                                                   \
        uint32 __pkt__ = 0;                                \
        uint32 __rate__ = 0;                               \
        HAL_METER_RATE_TO_PKT(rate, __pkt__);              \
        HAL_METER_PKT_TO_RATE(__pkt__, __rate__);          \
        packet = __rate__ != rate ? __pkt__ + 1 : __pkt__; \
    } while (0)

/* meter round rate */
#define HAL_METER_ROUND_RATE(unit, rate)                             \
    ((((rate) < HAL_METER_RATE_GRANULARITY(unit)) && ((rate) > 0)) ? \
         (1) :                                                       \
         ((rate) / HAL_METER_RATE_GRANULARITY(unit)))

/* meter round bucket size */
#define HAL_METER_ROUND_BUCKET_SIZE(unit, size)                        \
    ((((size) < HAL_METER_BUCKET_GRANULARITY(unit)) && ((size) > 0)) ? \
         (1) :                                                         \
         ((size) / HAL_METER_BUCKET_GRANULARITY(unit)))

/* translate packet to bucket */
#define HAL_METER_PKT_TO_BUCKET(packet) ((packet) * HAL_METER_PKT_LEN)

/* translate bucket to packet */
#define HAL_METER_BUCKET_TO_PKT(bucket) ((bucket) / HAL_METER_PKT_LEN)

/* DATA TYPE DECLARATIONS
 */

/* meter type in HAL */
typedef enum hal_meter_type_e {
    HAL_METER_TYPE_IGR_INTF = 0,    /* ingress interface */
    HAL_METER_TYPE_EGR_INTF,        /* egress interface */
    HAL_METER_TYPE_IGR_PORT,        /* ingress physical port */
    HAL_METER_TYPE_EGR_PORT,        /* egress physical port */
    HAL_METER_TYPE_DOMAIN,          /* ingress domain */
    HAL_METER_TYPE_EGR_DOMAIN,      /* egress domain */
    HAL_METER_TYPE_IGR_MIR_POLICER, /* ingress mirror or copp meter */
    HAL_METER_TYPE_EGR_MIR_POLICER, /* egress mirror or copp meter */
    HAL_METER_TYPE_ICIA,            /* ingress cia */
    HAL_METER_TYPE_ECIA,            /* egress cia */
    HAL_METER_TYPE_ICIA_POST,       /* ingress cia post */
    HAL_METER_TYPE_ECIA_POST,       /* egress cia post */
    HAL_METER_TYPE_FLOW,            /* flow-based */
    HAL_METER_TYPE_LAST,
} hal_meter_type_t;

/* meter resource type in HAL */
typedef enum hal_meter_rsrc_type_e {
    HAL_METER_RSRC_TYPE_PLANE = 0, /* plane Meter */
    HAL_METER_RSRC_TYPE_GLB,       /* global Meter */
    HAL_METER_RSRC_TYPE_RSV,       /* reserved Meter */
    HAL_METER_RSRC_TYPE_LAST,
} hal_meter_rsrc_type_t;

/* double bucket hw meter */
typedef struct hal_meter_hw_meter_s {
    uint32 even_sw_id;                     /* even allocated by which sw meter */
    uint32 odd_sw_id;                      /* odd allocated by which sw meter  */
    uint32 bank_idx;                       /* hw meter owned by which bank  */
    struct hal_meter_hw_meter_s *ptr_next; /* next hw meter                    */
    struct hal_meter_hw_meter_s *ptr_prev; /* prev hw meter                    */
} hal_meter_hw_meter_t;

typedef struct hal_meter_index_s {
    uint32 hw_id;   /* hw meter pool entry id   */
    uint16 even_en; /* even bucket enable       */
    uint16 odd_en;  /* odd bucket enable        */
} hal_meter_index_t;

/* Meter TCM Mode */
typedef enum hal_meter_algo_e {
    HAL_METER_ALGO_SRTCM = 0, /* SrTCM                 */
    HAL_METER_ALGO_TRTCM,     /* TrTCM                 */
    HAL_METER_ALGO_MTRTCM,    /* modified TrTCM        */
    HAL_METER_ALGO_1R2CM,     /* single rate two color */
    HAL_METER_ALGO_LAST
} hal_meter_algo_t;

/* Meter Parameter */
typedef struct hal_meter_param_s {
    uint32 cir;     /* cir */
    uint32 cbs;     /* cbs */
    uint32 pir_eir; /* pir or eir */
    uint32 pbs_ebs; /* pbs or ebs */
} hal_meter_param_t;

/* meter configuration*/
typedef struct hal_meter_cfg_s {
    hal_meter_param_t param;         /* bucket cir/cbs/pir/pbs/eir/ebs */
    hal_meter_algo_t algo_mode;      /* meter tcm mode */
    hal_meter_rsrc_type_t rsrc_type; /* resource type */
    uint16 color_aware;              /* 0: color blind; 1: color ware */
    uint16 layer1;                   /* 0: layer2; 1: layer1 */
    uint16 global;                   /* 0: plane; 1: global */
    uint16 packet;                   /* 0: byte; 1: packet */
} hal_meter_cfg_t;

/* meter software config */
typedef struct hal_meter_sw_meter_s {
    uint32 sw_id;               /* meter id */
    hal_meter_cfg_t cfg;        /* tcm mode/color mode/layer mode/port mode */
    hal_meter_index_t hw_index; /* hw meter info when meter allocated       */
    hal_meter_type_t type;      /* sw meter type                            */
    uint32 valid;               /* 0: sw meter not created; 1: created      */
    uint32 ref_cnt;             /* reference count */
} hal_meter_sw_meter_t;

/* meter bank */
typedef struct hal_meter_bank_s {
    struct hal_meter_bank_s *ptr_next;     /* next bank */
    struct hal_meter_bank_s *ptr_prev;     /* prev bank */
    hal_meter_rsrc_type_t rsrc_type;       /* resource type */
    uint16 global;                         /* 0: plane meter; 1: global meter */
    uint16 valid;                          /* 0: not allocated; 1: allocated */
    uint16 ucp_grp_id;                     /* the ucp group id if the bank is used for cia */
    uint16 used_single_num;                /* the number of the used single bucket in bank */
    uint16 used_double_num;                /* the number of the used double bucket in bank */
    hal_meter_type_t type;                 /* the bank type */
    hal_meter_hw_meter_t free_single_list; /* the double list of the free single bucket nodes */
    hal_meter_hw_meter_t free_double_list; /* the double list of the free double bucket nodes */
    hal_meter_hw_meter_t *ptr_hw;          /* hw meters managed by this bank */
} hal_meter_bank_t;

/* meter pool mgmt control block */
typedef struct hal_meter_pool_mgmt_cb_s {
    hal_meter_bank_t *ptr_bank_list; /* the array of meter bank */

    /* allocated bank management */
    hal_meter_bank_t used_p_srv[HAL_METER_SERVICE_TYPE_NUM]; /* manage allocated plane bank for
                                                                service  */
    hal_meter_bank_t used_p_cia[HAL_METER_CIA_TYPE_NUM]; /* manage allocated plane bank for cia */
    hal_meter_bank_t used_p_flow; /* manage allocated plane bank for flow     */
    hal_meter_bank_t used_g_srv[HAL_METER_SERVICE_TYPE_NUM]; /* manage allocated global bank for
                                                                service */
    hal_meter_bank_t used_g_cia[HAL_METER_CIA_TYPE_NUM]; /* manage allocated global bank for cia */
    hal_meter_bank_t used_g_flow;   /* manage allocated global bank for flow    */
    hal_meter_bank_t used_igr_port; /* manage allocated ingress port bank for port rate limit */

    hal_meter_bank_t free_p_list;   /* manage free plane bank list              */
    hal_meter_bank_t free_g_list;   /* manage free global bank list             */
    hal_meter_bank_t free_rsv_list; /* manage free reserved bank list */
    hal_meter_sw_meter_t *ptr_sw;   /* the array of sw meter                    */
    hal_meter_hw_meter_t *ptr_hw;   /* the array of hw meter                    */
    uint32 sw_id_num_words;         /* it is used to manage sw meter ids        */
    uint32 *ptr_sw_id_bmap;         /* it is used to manage sw meter ids        */
    uint32 sw_p_free_cnt;           /* free sw plane meter count                */
    uint32 sw_g_free_cnt;           /* free sw global meter count               */
    uint32 sw_rsv_free_cnt;         /* free reserved meter count */

    uint32 p_bank_num;              /* plane meter bank number */
    uint32 g_bank_num;              /* global meter bank number */
    uint32 rsv_bank_num;            /* reserved meter bank number */
    uint32 total_bank_num;          /* total meter bank number */

    uint32 p_entry_num;             /* plane meter entry number, unit: double bucket */
    uint32 g_entry_num;             /* global meter entry number, unit: double bucket */
    uint32 rsv_entry_num;           /* reserved meter entry number, unit: double bucket */
    uint32 total_entry_num;         /* total meter entry number */

} hal_meter_pool_mgmt_cb_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* meter pool mgmt control block */
extern hal_meter_pool_mgmt_cb_t *_hal_meter_pool_mgmt_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/**
 * @brief Init meter module control blocks.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Init success.
 * @return        CLX_E_NO_MEMORY        - Allocate control block failed.
 * @return        CLX_E_OTHERS           - Init fail.
 * @return        CLX_E_BAD_PARAMETER    - Parameter invalid.
 */
clx_error_no_t
hal_meter_init(const uint32 unit);

/**
 * @brief Deinit meter module control blocks and free resource.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Deinit success.
 * @return        CLX_E_OTHERS           - DeInit fail.
 * @return        CLX_E_BAD_PARAMETER    - Parameter invalid.
 */
clx_error_no_t
hal_meter_deinit(const uint32 unit);

/**
 * @brief Convert the data format: A.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     value       - CL8360 plane meter, data(15 bits), format: A(11 bits)+B(4 bits)
 *                               CL8360 global meter, data(16 bits), format: A(12 bits)+B(4 bits)
 *                               CL8570, data(16 bits), format: A(11 bits)+B(5 bits) CL8600,
 *                               data(15 bits), format: A(11 bits)+B(4 bits).
 * @param [out]    ptr_rate    - Meter rate.
 */
void
hal_meter_data_to_rate_trans(const uint32 unit, const uint32 value, uint32 *ptr_rate);

/**
 * @brief Convert the data format: A.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     value              - Data(15 bits), format: A(11 bits)+B(4 bits).
 * @param [out]    ptr_bucket_size    - Meter bucket size.
 */
void
hal_meter_data_to_bucket_trans(const uint32 unit, const uint32 value, uint32 *ptr_bucket_size);

/**
 * @brief Meter show resource.
 *
 * @param [in]    unit      - The device number.
 * @param [in]    detail    - Detail information.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_meter_resource_show(const uint32 unit, const boolean detail);

/**
 * @brief Alloc hw meter resource.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     meter_id      - Meter id.
 * @param [in]     meter_type    - Meter type.
 * @param [in]     ucp_grp_id    - Ucp group id.
 * @param [out]    ptr_hw_idx    - Hw index.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_meter_hw_meter_rsrc_alloc(const uint32 unit,
                              const uint32 meter_id,
                              const hal_meter_type_t meter_type,
                              const uint32 ucp_grp_id,
                              uint32 *ptr_hw_idx);

/**
 * @brief Create sw meter.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     ptr_cfg            - Meter config.
 * @param [out]    ptr_sw_meter_id    - Sw meter id.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_meter_sw_meter_create(const uint32 unit,
                          const hal_meter_cfg_t *ptr_cfg,
                          uint32 *ptr_sw_meter_id);

/**
 * @brief Set sw meter config.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    sw_meter_id      - Sw meter id.
 * @param [in]    ptr_meter_cfg    - Meter config.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_meter_sw_meter_cfg_set(const uint32 unit,
                           const uint32 sw_meter_id,
                           const hal_meter_cfg_t *ptr_meter_cfg);

/**
 * @brief Meter get property.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    property      - Property.
 * @param [in]    ptr_param0    - Param0.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_meter_property_get(const uint32 unit, const clx_swc_cfg_t property, uint32 *ptr_param0);

/**
 * @brief Create a meter.
 *
 * The rate & burst size should be multiple of 64. if usr provide a number
 * which is not multiple of 64, this function will reset it.
 * eg: rate = 1 kbps, the final rate will be 64 kbps
 * size = 1 byte, the final size will be 64 bytes.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_meter_cfg    - Meter configuration.
 * @param [out]    ptr_meter_id     - Meter id, it presents a logical meter.
 * @return         CLX_E_OK               - Create success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter invalid or null pointer.
 * @return         CLX_E_OTHERS           - Not inited or others.
 * @return         CLX_E_TABLE_FULL       - No more meter can be created.
 */
clx_error_no_t
hal_meter_create(const uint32 unit, const clx_meter_cfg_t *ptr_meter_cfg, uint32 *ptr_meter_id);

/**
 * @brief Delete a meter.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    meter_id    - Service meter logic id.
 * @return        CLX_E_OK                 - Success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The meter does not exist.
 * @return        CLX_E_ENTRY_IN_USE       - The meter is in use.
 */
clx_error_no_t
hal_meter_destroy(const uint32 unit, const uint32 meter_id);

/**
 * @brief Get a meter configuration.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     meter_id         - Meter id, it presents a logical meter.
 * @param [in]     enable           - Enable semaphore lock.
 * @param [out]    ptr_meter_cfg    - The meter configuration.
 * @return         CLX_E_OK                 - Get success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter invalid or null pointer.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The meter does not exist.
 * @return         CLX_E_OTHERS             - Unit is invalid.
 */
clx_error_no_t
hal_meter_with_lock_get(const uint32 unit,
                        const uint32 meter_id,
                        const boolean enable,
                        clx_meter_cfg_t *ptr_meter_cfg);

/**
 * @brief Get a meter configuration.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     meter_id         - Meter id, it presents a logical meter.
 * @param [out]    ptr_meter_cfg    - The meter configuration.
 * @return         CLX_E_OK                 - Get success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter invalid or null pointer.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The meter does not exist.
 * @return         CLX_E_OTHERS             - Unit is invalid.
 */
clx_error_no_t
hal_meter_get(const uint32 unit, const uint32 meter_id, clx_meter_cfg_t *ptr_meter_cfg);

/**
 * @brief Modify meter rate & bucket size.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     meter_id           - Meter id, it presents a logical meter.
 * @param [out]    ptr_meter_param    - The meter rate & bucket size.
 * @return         CLX_E_OK                 - Set success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter invalid or null pointer.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The meter does not exist.
 * @return         CLX_E_OTHERS             - Unit is invalid.
 */
clx_error_no_t
hal_meter_param_set(const uint32 unit,
                    const uint32 meter_id,
                    const clx_meter_param_t *ptr_meter_param);

/**
 * @brief Free meter hw index without lock.
 *
 * @param [in]    unit      - The device number.
 * @param [in]    hw_idx    - Hw index.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_meter_hw_idx_without_lock_free(const uint32 unit, const uint32 hw_idx);

/**
 * @brief Get a hw meter index for meter.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     meter_id      - Sw meter id.
 * @param [in]     meter_type    - Meter type.
 * @param [in]     ucp_grp_id    - Ucp group id for ingress or egress cia.
 * @param [in]     old_hw_idx    - Old hw meter index, old_hw_idx is not free when it's
 *                                 HAL_INVALID_MTR_HW_IDX.
 * @param [out]    ptr_hw_idx    - Hw meter index.
 * @return         CLX_E_OK                 - Alloc success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter invalid or null pointer.
 * @return         CLX_E_OTHERS             - Not inited or others.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No more hw meter.
 */
clx_error_no_t
hal_meter_hw_idx_alloc(const uint32 unit,
                       const uint32 meter_id,
                       const hal_meter_type_t meter_type,
                       const uint32 ucp_grp_id,
                       const uint32 old_hw_idx,
                       uint32 *ptr_hw_idx);

/**
 * @brief Free a hw meter index for meter.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    hw_idx    - Hw meter idx.
 * @return        CLX_E_OK                 - Alloc success.
 * @return        CLX_E_BAD_PARAMETER      - Parameter invalid or null pointer.
 * @return        CLX_E_OTHERS             - Not inited or others.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No more hw meter.
 */
clx_error_no_t
hal_meter_hw_idx_free(const uint32 unit, const uint32 hw_idx);

/**
 * @brief Get a meter id by hw meter index.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     hw_idx          - Meter hw index.
 * @param [in]     enable          - Enable semaphore lock.
 * @param [out]    ptr_meter_id    - Meter id.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mete_id_with_lock_get(const uint32 unit,
                          const uint32 hw_idx,
                          const boolean enable,
                          uint32 *ptr_meter_id);

/**
 * @brief Get a meter id by hw meter index.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     hw_idx          - Meter hw index.
 * @param [out]    ptr_meter_id    - Meter id.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_meter_id_get(const uint32 unit, const uint32 hw_idx, uint32 *ptr_meter_id);

#endif /* end of hal_meter_h */
