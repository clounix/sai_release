/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_rim.h
 * PURPOSE:
 *  1. Provide Resource Index Management API.
 * NOTES:
 */

#ifndef HAL_RIM_H
#define HAL_RIM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_cfg.h>
#include <tob/tob.h>
#include <hal/hal.h>
#include <hal/hal_tbl.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* rim broadcast cfg index */
#define HAL_RIM_ENTRY_BC_IDX (0xFF)

#define HAL_RIM_ENTRY_HW_INFO_SET(__hw_info__, __field_num__, __ptr_field__) \
    do {                                                                     \
        __hw_info__.field_num = __field_num__;                               \
        __hw_info__.ptr_field = __ptr_field__;                               \
    } while (0)

#define HAL_RIM_ENTRY_INFO_SET(__entry_info__, __cfg_idx__, __sw_tbl_id__, __old_entry_idx__, \
                               __flags__, __count__, __entry_idx__, __bank_length__,          \
                               __ptr_mem_service__)                                           \
    do {                                                                                      \
        __entry_info__.cfg_idx = __cfg_idx__;                                                 \
        __entry_info__.sw_tbl_id = __sw_tbl_id__;                                             \
        __entry_info__.old_entry_idx = __old_entry_idx__;                                     \
        __entry_info__.flags = __flags__;                                                     \
        __entry_info__.count = __count__;                                                     \
        __entry_info__.entry_idx = __entry_idx__;                                             \
        __entry_info__.bank_length = __bank_length__;                                         \
        __entry_info__.ptr_mem_service = __ptr_mem_service__;                                 \
    } while (0)

#define HAL_RIM_ERROR_NO_RETURN(rc, fmt, args...)                            \
    {                                                                        \
        if (CLX_E_OK != rc) {                                                \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_ERR, "[error:%s-%d]:" fmt, \
                           clx_error_string_get(rc), rc, ##args);            \
        }                                                                    \
    }

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_rim_tbl_id_info_s {
    uint32 tbl_idx;
    uint32 hw_tbl_id;
    uint32 shared_tbl_id;
} hal_rim_tbl_id_info_t;

typedef struct hal_rim_entry_rsc_info_s {
    uint32 hw_tbl_id;
    uint32 base_index;
    uint32 length;
    uint32 tbl_width;
    uint32 used_cnt;
    uint32 free_cnt;
} hal_rim_entry_rsc_info_t;

typedef struct hal_rim_entry_info_s {
    uint32 cfg_idx;       /* The inst or subinst index，bc use HAL_RIM_ENTRY_BC_IDX */
    uint32 sw_tbl_id;     /* software table id */
    uint32 hw_tbl_id;     /* if HAL_RIM_ENTRY_FLAGS_WITH_HW_TBL_ID set, hw_tbl_id is valid */
    uint32 old_entry_idx; /* old entry index, fields alloc use, if no care, use HAL_INVALID_ID */
    uint32 flags;         /* refer to HAL_RIM_ENTRY_FLAGS_XX. */
    uint32 count;         /* entry count */
    uint32 entry_idx;     /* entry index */
    /* if HAL_RIM_ENTRY_FLAGS_IDX_ALLOC_BANK set, must set and multiples of 32, else no care */
    uint32 bank_length;
    /* if HAL_RIM_ENTRY_FLAGS_PHY_IDX or HAL_RIM_ENTRY_FLAGS_FPU set, must set, else no care */
    tob_entry_index_service_t *ptr_mem_service;
} hal_rim_entry_info_t;

/* operate index is phy, default is local */
#define HAL_RIM_ENTRY_FLAGS_PHY_IDX (1U << 0)
/* when operate index, clear entry hardward */
#define HAL_RIM_ENTRY_FLAGS_HW_CLEAR (1U << 1)
/* when fields operate, set table all fields  */
#define HAL_RIM_ENTRY_FLAGS_TABLE (1U << 2)
/* when fields operate, set table specified field  */
#define HAL_RIM_ENTRY_FLAGS_FIELD (1U << 3)
/* nb fpu hash or tcam, if write hw entry, must set this flag */
#define HAL_RIM_ENTRY_FLAGS_FPU (1U << 4)
/* alloc index base on bank, continuous distribution can only within the bank */
#define HAL_RIM_ENTRY_FLAGS_IDX_ALLOC_BANK (1U << 5)
/* when alloc index, count is 2 or 4, index will be aligning alloc, set the flag will be not */
#define HAL_RIM_ENTRY_FLAGS_IDX_NOT_ALIGN (1U << 6)
/* specify hw_table_id to process */
#define HAL_RIM_ENTRY_FLAGS_WITH_HW_TBL_ID (1U << 7)
/* operation index from back to front */
#define HAL_RIM_ENTRY_FLAGS_IDX_OPER_FROM_BACK (1U << 8)

typedef struct hal_rim_entry_hw_info_s {
    uint32 field_num;
    tob_fvp_t *ptr_field;
} hal_rim_entry_hw_info_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Alloc/reuse table fields index，setting hw table and record reference count.
 *
 * Support_chip: all.
 *
 * @param [in]     unit              - The unit number.
 * @param [in]     ptr_hw_info       - The entry hardward info.
 * @param [in]     ptr_entry_info    - The entry info.
 * @param [out]    ptr_entry_info    - The entry info.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_TABLE_FULL         - Resources is full.
 * @return         CLX_E_OTHERS             - Operation Failed.
 * @return         CLX_E_NOT_SUPPORT        - Operation not support.
 */
clx_error_no_t
hal_rim_fields_alloc(const uint32 unit,
                     const hal_rim_entry_hw_info_t *ptr_hw_info,
                     hal_rim_entry_info_t *ptr_entry_info);

/**
 * @brief Free table fields index，clear hw table, decreasing reference count.
 *
 * Support_chip: all.
 *
 * @param [in]    unit              - The unit number.
 * @param [in]    ptr_hw_info       - The entry hardward info, field type rsc set,
 *                                    else set NULL.
 * @param [in]    ptr_entry_info    - The entry info.
 * @return        CLX_E_OK                 - Operation successful.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Table not found or not used.
 * @return        CLX_E_OTHERS             - Operation Failed.
 */
clx_error_no_t
hal_rim_fields_free(const uint32 unit,
                    const hal_rim_entry_hw_info_t *ptr_hw_info,
                    const hal_rim_entry_info_t *ptr_entry_info);

/**
 * @brief Get fields entry index by table filed info.
 *
 * Support_chip: all.
 *
 * @param [in]     unit              - The unit number.
 * @param [in]     ptr_hw_info       - The entry hardward info.
 * @param [in]     ptr_entry_info    - The entry info.
 * @param [out]    ptr_entry_info    - The entry info.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_OTHERS             - Operation Failed.
 * @return         CLX_E_NOT_SUPPORT        - Operation not support.
 */
clx_error_no_t
hal_rim_fields_get(const uint32 unit,
                   const hal_rim_entry_hw_info_t *ptr_hw_info,
                   hal_rim_entry_info_t *ptr_entry_info);

/**
 * @brief Getting reference count.
 *
 * Support_chip: all.
 *
 * @param [in]     unit              - The unit number.
 * @param [in]     ptr_hw_info       - The entry hardward info, field type rsc set,
 *                                     else set NULL.
 * @param [in]     ptr_entry_info    - The entry info.
 * @param [out]    ptr_refcnt        - Reference count.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
clx_error_no_t
hal_rim_fields_refcnt_get(const uint32 unit,
                          const hal_rim_entry_hw_info_t *ptr_hw_info,
                          const hal_rim_entry_info_t *ptr_entry_info,
                          uint32 *ptr_refcnt);

/**
 * @brief Modify reference count.
 *
 * Support_chip: all.
 *
 * @param [in]    unit              - The unit number.
 * @param [in]    ptr_hw_info       - The entry hardward info, field type rsc set,
 *                                    else set NULL.
 * @param [in]    ptr_entry_info    - The entry info.
 * @param [in]    cnt               - Count to be increase or decrease.
 * @return        CLX_E_OK                 - Operation successful.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return        CLX_E_OTHERS             - Operation Failed.
 * @return        CLX_E_NOT_SUPPORT        - Operation not support.
 */
clx_error_no_t
hal_rim_fields_refcnt_modify(const uint32 unit,
                             const hal_rim_entry_hw_info_t *ptr_hw_info,
                             const hal_rim_entry_info_t *ptr_entry_info,
                             const int32 cnt);

/**
 * @brief Allocating free index and setting hw table fields same info by sw table index.
 *
 * Support_chip: all.
 *
 * @param [in]     unit              - The unit number.
 * @param [in]     ptr_hw_info       - The entry hardward info, if not set hardware,
 *                                     set NULL.
 * @param [in]     ptr_entry_info    - The entry info.
 * @param [out]    ptr_entry_info    - The entry info.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return         CLX_E_TABLE_FULL         - Resources is full.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
clx_error_no_t
hal_rim_index_alloc(const uint32 unit,
                    const hal_rim_entry_hw_info_t *ptr_hw_info,
                    hal_rim_entry_info_t *ptr_entry_info);

/**
 * @brief Setting index and hw table.
 *
 * Support_chip: all.
 *
 * @param [in]    unit              - The unit number.
 * @param [in]    ptr_hw_info       - The entry hardward info, if not set hardware,
 *                                    set NULL.
 * @param [in]    ptr_entry_info    - The entry info.
 * @return        CLX_E_OK                 - Operation successful.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return        CLX_E_ENTRY_IN_USE       - Entry index is used.
 * @return        CLX_E_OTHERS             - Operation Failed.
 */
clx_error_no_t
hal_rim_index_set(const uint32 unit,
                  const hal_rim_entry_hw_info_t *ptr_hw_info,
                  const hal_rim_entry_info_t *ptr_entry_info);

/**
 * @brief Free entry index.
 *
 * Support_chip: all.
 *
 * @param [in]    unit              - The unit number.
 * @param [in]    ptr_entry_info    - The entry info.
 * @return        CLX_E_OK                 - Operation successful.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Table not found.
 * @return        CLX_E_OTHERS             - Operation Failed.
 */
clx_error_no_t
hal_rim_index_free(const uint32 unit, const hal_rim_entry_info_t *ptr_entry_info);

/**
 * @brief Getting index resourece info.
 *
 * Support_chip: all.
 *
 * @param [in]     unit            - The unit number.
 * @param [in]     cfg_idx         - The inst or subinst index，bc use HAL_RIM_ENTRY_BC_IDX.
 * @param [in]     sw_tbl_id       - The software table id.
 * @param [out]    ptr_rsc_info    - Resource info.
 * @return         CLX_E_OK                 - Successfully get sw table info.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Not found entry.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
clx_error_no_t
hal_rim_index_rsc_info_get(const uint32 unit,
                           const uint32 cfg_idx,
                           const uint32 sw_tbl_id,
                           hal_rim_entry_rsc_info_t *ptr_rsc_info);

/**
 * @brief Checking entry index is used or not.
 *
 * Support_chip: all.
 *
 * @param [in]     unit              - The unit number.
 * @param [out]    ptr_entry_info    - Entry info.
 * @return         CLX_E_OK                 - Entry is found.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation Failed.
 */
clx_error_no_t
hal_rim_index_entry_idx_is_used(const uint32 unit, const hal_rim_entry_info_t *ptr_entry_info);

/**
 * @brief Reseting allocated bmp size.
 *
 * Support_chip: all.
 *
 * @param [in]    unit            - The unit number.
 * @param [in]    sw_tbl_id       - The software table id.
 * @param [in]    ptr_rsc_info    - The sw entry resource info.
 * @return        CLX_E_OK                 - Operation successful.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation Failed.
 */
clx_error_no_t
hal_rim_index_entry_cfg_reset(const uint32 unit,
                              const uint32 sw_tbl_id,
                              const hal_rim_entry_rsc_info_t *ptr_rsc_info);

/**
 * @brief Hal_rim_init() is responsible for rim init.
 *
 * Support_chip: all.
 *
 * @param [in]    unit    - The unit number.
 * @return        CLX_E_OK        - Successfully init.
 * @return        CLX_E_OTHERS    - Error index.
 */
clx_error_no_t
hal_rim_init(const uint32 unit);

/**
 * @brief Hal_rim_deinit() is responsible for rim deinit.
 *
 * Support_chip: all.
 *
 * @param [in]    unit    - The unit number.
 * @return        CLX_E_OK        - Successfully init.
 * @return        CLX_E_OTHERS    - Free rim sem failed.
 */
clx_error_no_t
hal_rim_deinit(const uint32 unit);

#endif /* #ifndef HAL_RIM_H */
