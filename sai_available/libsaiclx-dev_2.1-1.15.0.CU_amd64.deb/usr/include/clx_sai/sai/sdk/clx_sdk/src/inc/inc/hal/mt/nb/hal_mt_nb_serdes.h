/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_serdes.h
 * PURPOSE:
 *      It provide HAL_MT_NB_SERDES module API.
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_SERDES_H
#define HAL_MT_NB_SERDES_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_cfg.h>
#include <hal/mt/nb/hal_mt_nb_pma.h>
#include <hal/hal_phy.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define ANGROUP_MAXSIZE (4)

#define HAL_MT_NB_SERDES_MAX_MACRO           (33)
#define HAL_MT_NB_SERDES_MAX_LANES_PER_MACRO (8)

#define HAL_MT_NB_SERDES_MACRO_0_BASE_ADDR   (0x2ED4400)
#define HAL_MT_NB_SERDES_MACRO_OFFSET        (0x114400)
#define HAL_MT_NB_SERDES_SLICE_ODD_ENEN_GAP  (0x1180000)
#define HAL_MT_NB_SERDES_SLICE_GAP           (0x451000)
#define HAL_MT_NB_MACRO_MAX_NUM_PER_SLICE    (4)
#define HAL_MT_NB_SERDES_CPI_MACRO_BASE_ADDR (0x5E8F800)

#define HAL_MT_NB_GET_SLICE_SERDES_ADDR(slice)                                                \
    (HAL_MT_NB_SERDES_MACRO_0_BASE_ADDR + (slice % 2) * HAL_MT_NB_SERDES_SLICE_ODD_ENEN_GAP + \
     (slice / 2) * HAL_MT_NB_SERDES_SLICE_GAP)
#define HAL_MT_NB_GET_MACRO_SERDES_ADDR(macro_id)                                       \
    (((macro_id % HAL_MT_NB_MACRO_MAX_NUM_PER_SLICE) * HAL_MT_NB_SERDES_MACRO_OFFSET) + \
     HAL_MT_NB_GET_SLICE_SERDES_ADDR(macro_id / HAL_MT_NB_MACRO_MAX_NUM_PER_SLICE))
#define HAL_MT_NB_GET_SLICE_MACRO_SERDES_ADDR(slc, slc_macro) \
    ((slc_macro * HAL_MT_NB_SERDES_MACRO_OFFSET) + HAL_MT_NB_GET_SLICE_SERDES_ADDR(slc))

#define HAL_MT_NB_SERDES_LANE_OFFSET(__lane__) ((__lane__) * ETH_LANE_OFFSET)

#define HAL_CHECK_SERDES_ERROR(__pass__)                                              \
    do {                                                                              \
        clx_error_no_t __rc = CLX_E_OTHERS;                                           \
        if (__pass__ != HAL_MT_NB_PMA_ERR_CODE_NONE) {                                \
            UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_WARN, #__pass__ "=%d\n", __pass__); \
            return __rc;                                                              \
        }                                                                             \
    } while (0)

/* DATA TYPE DECLARATIONS
 */

typedef struct {
    uint32 flags;
    uint32 group[ANGROUP_MAXSIZE];
} HAL_MT_NB_AN_GROUP;

typedef enum { INIT_QUEUE, EN_QUEUE, DE_QUEUE, OP_QUEUE_LAST } OP_QUEUE_T;

typedef struct hal_mt_nb_phy_cfg_s {
    HAL_PHY_PMD_INTF_TYPE_T pmd_intf_type[CLX_PORT_NUM];
    mss_access_t phy_mss[CLX_PORT_NUM];         /* Multi-Standard SerDes access */
    HAL_PHY_FEC_TYPE_T phy_fec[CLX_PORT_NUM];   /* fec mode */
    uint32 consortium_next_page[CLX_PORT_NUM];  /* an np */
    uint32 an_consortium_ability[CLX_PORT_NUM]; /* an consortium ability
                                                   bit0:50GBASE-KR2,
                                                   bit1:50GBASE-CR2,
                                                   bit2:400GBASE-CR8,
                                                   bit10:requests Clause 91 FEC,
                                                   bit11:requests Clause 74 FEC*/
    uint32 tx_lane_swap[HAL_MT_NB_SERDES_MAX_MACRO][HAL_MT_NB_SERDES_MAX_LANES_PER_MACRO]; /* tx
                                                                                              lane
                                                                                              swap
                                                                                            */
    uint32 rx_lane_swap[HAL_MT_NB_SERDES_MAX_MACRO][HAL_MT_NB_SERDES_MAX_LANES_PER_MACRO]; /* rx
                                                                                              lane
                                                                                              swap
                                                                                            */
    uint32 tx_polarity[HAL_MT_NB_SERDES_MAX_MACRO][HAL_MT_NB_SERDES_MAX_LANES_PER_MACRO];  /* phy tx
                                                                                              polarity
                                                                                            */
    uint32 rx_polarity[HAL_MT_NB_SERDES_MAX_MACRO][HAL_MT_NB_SERDES_MAX_LANES_PER_MACRO];  /* phy rx
                                                                                              polarity
                                                                                            */
    hal_mt_nb_pma_txfir_config_t phy_txfir[HAL_MT_NB_SERDES_MAX_MACRO]
                                          [HAL_MT_NB_SERDES_MAX_LANES_PER_MACRO];
    /* tx-coef */
    HAL_MT_NB_AN_GROUP anlt_group[HAL_MT_NB_SERDES_MAX_MACRO]; /* anlt group */
} hal_mt_nb_phy_cfg_t;

extern hal_mt_nb_phy_cfg_t _phy_cfg[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/*serdes speed*/
typedef enum {
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_56P25_PAM4 = 0x0,
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_10P3125,
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_25P78125,
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_26P5625,
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_53P125_NRZ,
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_53P125_PAM4,
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_106P25,
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_112P5,
    HAL_MT_NB_PMA_PHY_SPEED_TYPE_LAST
} HAL_MT_NB_PMA_PHY_SPEED_TYPE_T;

extern const char *pma_rate_list[];

/*serdes tx block width*/
typedef enum {
    HAL_MT_NB_PMA_PHY_WIDTH_TYPE_16 = 0x2,
    HAL_MT_NB_PMA_PHY_WIDTH_TYPE_20,
    HAL_MT_NB_PMA_PHY_WIDTH_TYPE_32,
    HAL_MT_NB_PMA_PHY_WIDTH_TYPE_40,
    HAL_MT_NB_PMA_PHY_WIDTH_TYPE_64,
    HAL_MT_NB_PMA_PHY_WIDTH_TYPE_128,
    HAL_MT_NB_PMA_PHY_WIDTH_TYPE_LAST
} HAL_MT_NB_PMA_PHY_WIDTH_TYPE_T;

typedef struct {
    /**
     * Lane number, set lane number between 0 and 3
     **/
    uint8 lane_num;

    /**
     * Set to 1 to enable rxeq_prbs mode. Set to 0 to use LT mode
     **/
    uint32 prbs_en;

    /**
     * Set to 1 to enable anlt. Set to 0 to disable anlt
     **/
    uint32 anlt_en;

    /**
     * Set to 1 for testing between lanes on the same PHY
     **/
    uint32 an_no_nonce_check;

    /**
     * Set this to 1 for x1 configuration
     * Set this to 0 for running in multi-lane configurations
     **/
    uint32 an_no_attached;

    /**
     * Disables link training status check
     * In silicon set this to 0
     **/
    uint32 status_check_disable;

    /**
     * Enables next page support for consortium technologies
     * Not supported in this example sequence
     **/
    uint32 next_page_en;

    /**
     * Width corresponding to line rate
     **/
    uint32 ltcs_width;

    /**
     * ANLT clause as per IEEE-802 specification
     * ANLT cluase mapping is as follows
     * 106G  - 4
     * 53PAM - 3
     * 53NRZ - 2
     * 10G   - 1
     **/
    uint32 ltcs_clause;

    /**
     * Preset check enable
     * Set to 0 in sim
     * To be set by FW in silicon
     **/
    uint32 ltcs_preset_check;

    /**
     * Set to 1 if enabling precoding, applicable only for PAM
     * Set to 0 for this example
     **/
    uint32 ltcs_mod;

    /**
     * Mode EQ run in
     * HAL_MT_NB_PMA_ANLT_MODE, HAL_MT_NB_PMA_LT_MODE,
     *HAL_MT_NB_PMA_MANUAL mode
     **/
    uint32 eq_select;

    /**
     * Set to either HAL_MT_NB_PMA_ANLT_MODE, HAL_MT_NB_PMA_LT_MODE,
     *HAL_MT_NB_PMA_MANUAL_EQ HAL_MT_NB_PMA_ANLT_MODE - brings up lane in ANLT
     *configuration HAL_MT_NB_PMA_LT_MODE - brings up lane with link training, no AN
     * HAL_MT_NB_PMA_MANUAL_EQ - brings up lane with manual EQ
     **/
    hal_mt_nb_pma_eq_type_t s_eq_type;
} HAL_MT_NB_PMA_ANLT_CONFIG_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

clx_error_no_t
hal_mt_nb_serdes_ethx_mem_dump(const uint32 unit,
                               const uint32 port_id,
                               const uint32 lane_bmp,
                               const uint32 more);

clx_error_no_t
hal_mt_nb_serdes_ethl_mem_dump(const uint32 unit,
                               const uint32 port_id,
                               const uint32 lane_bmp,
                               const uint32 more);

clx_error_no_t
hal_mt_nb_serdes_ethx_reg_dump(const uint32 unit,
                               const uint32 port_id,
                               const uint32 lane_bmp,
                               const uint32 more);

clx_error_no_t
hal_mt_nb_serdes_ethl_reg_dump(const uint32 unit,
                               const uint32 port_id,
                               const uint32 lane_bmp,
                               const uint32 more);

clx_error_no_t
hal_mt_nb_serdes_ethx_coef_dump(const uint32 unit,
                                const uint32 port_id,
                                const uint32 lane_bmp,
                                const uint32 more);

clx_error_no_t
hal_mt_nb_serdes_ethl_coef_dump(const uint32 unit,
                                const uint32 port_id,
                                const uint32 lane_bmp,
                                const uint32 more);

clx_error_no_t
hal_mt_nb_serdes_ethx_msgq_dump(const uint32 unit,
                                const uint32 port_id,
                                const uint32 lane_bmp,
                                const uint32 more);

clx_error_no_t
hal_mt_nb_serdes_ethl_msgq_dump(const uint32 unit,
                                const uint32 port_id,
                                const uint32 lane_bmp,
                                const uint32 more);

clx_error_no_t
hal_mt_nb_serdes_eyeber_dump(const uint32 unit, const uint32 port_id, const uint32 lane_cnt);

clx_error_no_t
hal_mt_nb_serdes_eye_scan_print(const uint32 unit,
                                const uint32 port_id,
                                const uint32 lane_id,
                                const uint32 sample_deep);

clx_error_no_t
hal_mt_nb_serdes_eye_scan_rowdata_get(const uint32 unit,
                                      const uint32 port_id,
                                      const uint32 lane_id);

clx_error_no_t
hal_mt_nb_serdes_snr_calc_get(const uint32 unit,
                              const uint32 port_id,
                              const uint32 lane_id,
                              uint32 *ptr_snr_int,
                              uint32 *ptr_snr_dec);

clx_error_no_t
hal_mt_nb_serdes_fw_download(const uint32 unit);

clx_error_no_t
hal_mt_nb_serdes_fw_reload(const uint32 unit, const uint32 port_id);

clx_error_no_t
hal_mt_nb_serdes_refclock_check(const uint32 unit);

clx_error_no_t
hal_mt_nb_serdes_refclock_route_set(const uint32 unit);

clx_error_no_t
hal_mt_nb_serdes_lcpll_lock_range_set(const uint32 unit,
                                      const uint32 port_id,
                                      const uint32 max_val,
                                      const uint32 min_val,
                                      const uint32 lock_cycle);

clx_error_no_t
hal_mt_nb_serdes_lcpll_lock_get(const uint32 unit,
                                const uint32 port_id,
                                const uint32 check_en,
                                const uint32 expected_val,
                                uint32 *pll_lock);

clx_error_no_t
hal_mt_nb_serdes_tx_power_state_set(const uint32 unit,
                                    const uint32 port_id,
                                    const uint32 tx_pstate);

clx_error_no_t
hal_mt_nb_serdes_tx_power_state_get(const uint32 unit, const uint32 port_id, uint32 *tx_pstate);

clx_error_no_t
hal_mt_nb_serdes_rx_power_state_set(const uint32 unit,
                                    const uint32 port_id,
                                    const uint32 rx_pstate);

clx_error_no_t
hal_mt_nb_serdes_rx_power_state_get(const uint32 unit, const uint32 port_id, uint32 *rx_pstate);

clx_error_no_t
hal_mt_nb_serdes_rxcdr_lock_get(const uint32 unit, const uint32 port_id, const uint32 timeout_us);

clx_error_no_t
hal_mt_nb_serdes_lane_speed_get(const uint32 unit,
                                const uint32 port_id,
                                HAL_MT_NB_PMA_PHY_SPEED_TYPE_T *hal_mt_nb_pma_speed);

clx_error_no_t
hal_mt_nb_serdes_anlt_group_oper_set(const uint32 unit,
                                     const uint32 port_id,
                                     const OP_QUEUE_T operation,
                                     uint32 *anlt_group);

clx_error_no_t
hal_mt_nb_serdes_anlt_intr_enable(uint32 unit, uint32 port, uint32 enable);
clx_error_no_t
hal_mt_nb_serdes_an_intr_sta_get(uint32 unit, uint32 port, uint32 *status);
clx_error_no_t
hal_mt_nb_serdes_anlt_status_complete_get(const uint32 unit,
                                          const uint32 port_id,
                                          uint32 *an_status);

clx_error_no_t
hal_mt_nb_serdes_lt_state_get(const uint32 unit,
                              const uint32 port_id,
                              const uint32 lane_id,
                              uint32 *lt_done,
                              HAL_PMA_LT_T *lt_stat);

clx_error_no_t
hal_mt_nb_phy_an_speed_consortium_set(const uint32 unit, const uint32 port_id);
clx_error_no_t
hal_mt_nb_phy_port_anlt_result_get(const uint32 unit,
                                   const uint32 port,
                                   HAL_PHY_AN_SPEED_TYPE_T *ptr_result,
                                   uint32 *ptr_fec);
clx_error_no_t
hal_mt_nb_phy_eqbk_hold_req_enable(const uint32 unit, const uint32 port, uint32 enable);

clx_error_no_t
hal_mt_nb_phy_an_link_stat_cfg(const uint32 unit, const uint32 port, uint32 stat);

clx_error_no_t
hal_mt_nb_phy_anlt_status_get(const uint32 unit,
                              const uint32 port_id,
                              const uint32 lane_id,
                              uint32 *ptr_anlt_status);

clx_error_no_t
hal_mt_nb_serdes_tx_lane_reset(const uint32 unit, const uint32 port_id);

clx_error_no_t
hal_mt_nb_phy_prbs_pattern_get(const uint32 unit,
                               const uint32 port_id,
                               HAL_PHY_PRBS_PATTERN_TYPE_T *ptr_prbs_pattern);

clx_error_no_t
hal_mt_nb_serdes_port_anlt_map_en_get(const uint32 unit, const uint32 port_id, uint32 *ptr_map_en);
#endif /* End of HAL_MT_NB_SERDES_H */
