/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_tm_sched.h
 * PURPOSE:
 *      It provides hal tm SCH module schedule block API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NB_TM_SCHED_H
#define HAL_MT_NB_TM_SCHED_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_tm.h>
#include <hal/mt/nb/hal_mt_nb_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */

/*dwrr weight max*/
#define HAL_MT_NB_TM_DWRR_WEIGHT_MAX (255)

#define HAL_MT_NB_TM_DWRR_WEIGHT_BIT_NUM (3)
/*bandwidth rate in user-view is kbps unit*/
#define HAL_MT_NB_TM_FRONT_PORT_BUCKET_RATE_USER_UNIT (1000)

/*port max speed 800G that is 800000000(kbps) in shapers*/
#define HAL_MT_NB_TM_PORT_SPEED_MAX (800000000)

#define HAL_MT_NB_TM_PORT_PPS_SPEED_MAX (50000000)

#define HAL_MT_NB_TM_SAPER_STEP_RATE_128K              (128)
#define HAL_MT_NB_TM_SAPER_STEP_RATE_5M                (5000)
#define HAL_MT_NB_TM_PORT_SPEED_TO_PORT_BANDWIDTH(val) val * 1000

#define HAL_MT_NB_TM_SHAPER_PPS_PKT_SIZE_BYTES (8 * 1024)
#define HAL_MT_NB_TM_SHAPER_PPS_PKT_SIZE       (HAL_MT_NB_TM_SHAPER_PPS_PKT_SIZE_BYTES * 8)
#define HAL_MT_NB_TM_SHAPER_CFG_RATE_128K      (172800000)
#define HAL_MT_NB_TM_SHAPER_CFG_RATE_5M        (4423680)

#define HAL_MT_NB_TM_SHAPER_DFLT_RATE          (4)
#define HAL_MT_NB_TM_SHAPER_DFLT_MAX_BUCKET    (8)
#define HAL_MT_NB_TM_SHAPER_DFLT_ADD_TOKEN_VAL (1)
#define HAL_MT_NB_TM_SHAPER_DFLT_FRACTION      (1)
#define HAL_MT_NB_TM_SHAPER_DFLT_CREDIT_VAL    (2048 * 8)

#define HAL_MT_NB_TM_SHAPER_BANDWIDTH_MIN  (HAL_MT_NB_TM_SAPER_STEP_RATE_128K)
#define HAL_MT_NB_TM_SHAPER_BURST_SIZE_MIN (2048)
#define HAL_RC_MAX_BANDWIDTH               (400000000) // 400Gb
#define HAL_MT_NB_TM_BANDWIDTH_RESET_VAL \
    (0xFFFFFFFE) // When the max bandwidth is asic initial value

#define HAL_MT_NB_TM_SCHED_MAX_BUCKET_BPS \
    (0x7FFF * HAL_MT_NB_TM_SHAPER_DFLT_CREDIT_VAL / 8)                           // 67106816
#define HAL_MT_NB_TM_SCH_MAX_BUCKET_PPS \
    (HAL_MT_NB_TM_SCHED_MAX_BUCKET_BPS / HAL_MT_NB_TM_SHAPER_PPS_PKT_SIZE_BYTES) // 8191
/* MACRO FUNCTION DECLARATIONS
 */
/*dwrr weight valid*/
#define HAL_MT_NB_TM_SCHED_DWRR_WEIGHT_VLD(weight) \
    (((weight) > 0) && ((weight) <= HAL_MT_NB_TM_DWRR_WEIGHT_MAX))

#define HAL_MT_NB_TM_SCHED_SET_BURST(curr_burst_size, max_bucket)            \
    do {                                                                     \
        uint32 burst_size = 0;                                               \
        if (curr_burst_size < HAL_MT_NB_TM_SHAPER_BURST_SIZE_MIN) {          \
            burst_size = HAL_MT_NB_TM_SHAPER_BURST_SIZE_MIN;                 \
        } else {                                                             \
            burst_size = curr_burst_size;                                    \
        }                                                                    \
        max_bucket = (burst_size * 8) / HAL_MT_NB_TM_SHAPER_DFLT_CREDIT_VAL; \
    } while (0)
/* DATA TYPE DECLARATIONS
 */

typedef struct hal_mt_nb_tm_shaper_reg_s {
    uint32 cir_rate_table_id;
    uint32 cir_max_bucket_table_id;
    uint32 cir_add_token_value_table_id;
    uint32 cir_fraction_table_id;
    uint32 pir_rate_table_id;
    uint32 pir_max_bucket_table_id;
    uint32 pir_add_token_value_table_id;
    uint32 pir_fraction_table_id;
} hal_mt_nb_tm_shaper_reg_t;

typedef struct hal_mt_nb_tm_shaper_cfg_s {
    uint32 cfg_cir_shaper_rate;
    uint32 cfg_cir_shaper_max_bucket;
    uint32 cfg_cir_add_token_value;
    uint32 cfg_cir_fraction;
    uint32 cfg_pir_shaper_rate;
    uint32 cfg_pir_shaper_max_bucket;
    uint32 cfg_pir_add_token_value;
    uint32 cfg_pir_fraction;
} hal_mt_nb_tm_shaper_cfg_t;

typedef struct hal_mt_nb_tm_sched_hw_idx_s {
    uint32 inst_idx;
    uint32 sub_idx;
    uint32 entry_idx;
} hal_mt_nb_tm_sched_hw_idx_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init tm module sch configuration.
 *
 * This function will configure all front-plane-ports to be default
 * topology.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_mt_nb_tm_sched_cfg_init(const uint32 unit);

/**
 * @brief Init tm module sch warmboot.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    ptr_db    - Warmboot database.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_mt_nb_tm_sched_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_sched_wb_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

/**
 * @brief Configure min/max bandwidth for a handler.
 *
 * If maxbandwidth is 0, sdk will configure port speed to hardware.
 * If burst size is 0, sdk will calculate burst size itself.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port             - Egress physical port id which to be written.
 * @param [in]    handler          - The handler which the bandwidth written on.
 * @param [in]    ptr_bandwidth    - Bandwidth informations.
 * @return        CLX_E_OK        - Success.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_tm_sched_shaper_set(const uint32 unit,
                              const uint32 port,
                              const clx_tm_handler_t handler,
                              const clx_tm_shaper_t *ptr_bandwidth);

/**
 * @brief Get min/max bandwidth of a handler.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Egress physical port id which to be written.
 * @param [in]     handler          - The handler which the bandwidth to be got.
 * @param [out]    ptr_bandwidth    - The bandwidth of the handler.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_tm_sched_shaper_get(const uint32 unit,
                              const uint32 port,
                              const clx_tm_handler_t handler,
                              clx_tm_shaper_t *ptr_bandwidth);

/**
 * @brief Configure sp/dwrr weight for a handler.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Egress physical port id which to be written.
 * @param [in]     handler      - The handler which the bandwidth written on.
 * @param [out]    sched_cfg    - Parameters of scheduler.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_tm_sched_mode_set(const uint32 unit,
                            const uint32 port,
                            const clx_tm_handler_t handler,
                            clx_tm_sched_cfg_t sched_cfg);

/**
 * @brief Get sp/dwrr weight of a handler.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Egress physical port id which to be got.
 * @param [in]     handler          - The handler which to be got.
 * @param [out]    ptr_sched_cfg    - Parameters of scheduler.
 * @return         CLX_E_OK        - Success.
 * @return         CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_tm_sched_mode_get(const uint32 unit,
                            const uint32 port,
                            const clx_tm_handler_t handler,
                            clx_tm_sched_cfg_t *ptr_sched_cfg);

/**
 * @brief Enable/disable cpu shaping.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Egress physical port id which to be written.
 * @param [in]    enable    - True or false.
 * @return        CLX_E_OK        - Success.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_tm_sched_cpu_shaping_pps_en_set(const uint32 unit,
                                          const uint32 port,
                                          const boolean enable);
/**
 * @brief Get cpu shaping status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Egress physical port id which to be written.
 * @param [in]    enable    - True or false.
 * @return        CLX_E_OK        - Success.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_tm_sched_cpu_shaping_pps_mode_get(const uint32 unit, const uint32 port, boolean *enable);

clx_error_no_t
hal_mt_nb_tm_sched_port_dflt_set(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_tm_sched_speed_set(const uint32 unit, const uint32 port, const hal_tm_port_speed_t speed);

#endif /* End of HAL_MT_NB_TM_SCHED_H */
