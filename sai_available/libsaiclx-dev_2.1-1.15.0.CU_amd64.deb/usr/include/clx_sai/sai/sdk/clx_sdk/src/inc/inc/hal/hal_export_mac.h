/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_export_mac.h
 * PURPOSE:
 *      It provide MAC export module api.
 * NOTES:
 *
 */

#ifndef __HAL_EXPORT_MAC_H__
#define __HAL_EXPORT_MAC_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <util/lib/util_lib_hsh.h>
#include <util/lib/util_lib_list.h>
#include <hal/hal_eparser.h>

#ifdef __cplusplus
extern "C" {
#endif

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* MAC export type definitions */
typedef enum hal_export_mac_type_e {
    HAL_EXPORT_MAC_TYPE_FDB = 0, /* Export FDB MAC entries from L2UC tiles */
    HAL_EXPORT_MAC_TYPE_ARP = 1, /* Export ARP MAC entries from ARP tiles */
    HAL_EXPORT_MAC_TYPE_MAX
} hal_export_mac_type_t;

/* MAC message type definitions */
typedef enum hal_export_mac_msg_type_e {
    HAL_EXPORT_MAC_MSG_INVALID = 0,
    HAL_EXPORT_MAC_MSG_START = 1,
    HAL_EXPORT_MAC_MSG_DONE = 2,
    HAL_EXPORT_MAC_MSG_ERROR = 3,
} hal_export_mac_msg_type_t;

/* MAC TLV type definitions */
#define TLV_TYPE_MAC_COUNT     (0x21) /* MAC entry count */
#define TLV_TYPE_MAC_ENTRY_LEN (0x22) /* MAC entry length */
#define TLV_TYPE_MAC_ENTRIES   (0x23) /* MAC entry data */

/* MAC entry structure - updated to match hardware format */
typedef struct hal_export_mac_entry_s {
    uint8_t mac_addr[6]; /* MAC address (48 bits) */
    uint16_t bd;         /* Bridge Domain (14 bits, corresponds to VLAN) */
    uint16_t dst_idx;    /* Destination index (16 bits, corresponds to port) */
    uint8_t is_secure;   /* Security flag (1 bit) */
    uint8_t is_static;   /* Static/Dynamic flag (1 bit): 1=static, 0=dynamic */
    uint16_t acl_label;  /* ACL label (10 bits) */
    uint8_t reserved[2]; /* Reserved fields for alignment */
} hal_export_mac_entry_t;

/* MAC entry type definitions */
#define MAC_ENTRY_TYPE_STATIC  (0x01) /* Static MAC entry */
#define MAC_ENTRY_TYPE_DYNAMIC (0x02) /* Dynamic MAC entry */

/* Simplified MAC entry for sending */
typedef struct hal_export_mac_simple_entry_s {
    uint8_t mac_addr[6]; /* MAC address (6 bytes) */
    uint16_t bd;         /* Bridge Domain (14 bits, corresponds to VLAN) */
    uint32_t port_id;    /* Port ID converted from destination index */
    uint8_t mac_type;    /* MAC entry type (static or dynamic) */
    uint8_t reserved[3]; /* Reserved fields for alignment */
} hal_export_mac_simple_entry_t;

/* MAC list structure for storing exported MAC entries using linked list */
typedef struct hal_export_mac_list_s {
    util_lib_list_t *mac_list; /* MAC linked list for storage */
    uint32_t mac_count;        /* MAC entry count */
} hal_export_mac_list_t;

/* Message header structure with fragment flags */
typedef struct hal_export_mac_msg_header_s {
    hal_export_mac_msg_type_t msg_type; /* Message type */
    uint8_t fragment_index;             /* Current fragment index, 0-based */
    uint8_t total_fragments;            /* Total number of fragments */
    uint16_t reserved;                  /* Reserved for future use */
} hal_export_mac_msg_header_t;

typedef struct hal_export_mac_export_context_s {
    uint8_t *hsh_dma_buffer;        /* HSH DMA buffer pointer */
    uint32_t hsh_size;              /* HSH buffer size in bytes */
    uint8_t *tcam_dma_buffer;       /* TCAM DMA buffer pointer */
    uint32_t tcam_size;             /* TCAM buffer size in bytes */
    uint8_t *rslt_dma_buffer;       /* RSLT DMA buffer pointer */
    uint32_t rslt_size;             /* RSLT buffer size in bytes */
    hal_export_mac_type_t mac_type; /* MAC export type (FDB or ARP) */
} hal_export_mac_export_context_t;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

clx_error_no_t
hal_export_mac_init(uint32 unit);

clx_error_no_t
hal_export_mac_deinit(uint32 unit);

clx_error_no_t
hal_export_mac_handle_start(uint32 unit, eparse_msg_type_t msg_type, void *msg, uint32_t length);

clx_error_no_t
hal_export_mac_data_parse_mt(uint32_t unit,
                             hal_export_mac_export_context_t *ctx,
                             hal_export_mac_list_t *main_list);

clx_error_no_t
hal_export_mac_data_parse(uint32 unit,
                          hal_export_mac_export_context_t *context,
                          hal_export_mac_list_t *mac_list);
clx_error_no_t
hal_export_mac_data_export(uint32 unit,
                           uint8_t *dma_buffer,
                           uint32_t buffer_size,
                           hal_export_mac_type_t mac_type);

clx_error_no_t
hal_export_mac_calc_arp_hsh_size(uint32 unit, uint32_t *hsh_size);

#ifdef __cplusplus
}
#endif
#endif /* __HAL_EXPORT_MAC_H__ */