/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_bfd.h
 *
 * PURPOSE:
 *      It provides bfd module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_BFD_H
#define CLX_BFD_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_BFD_SESSION_MAX_MEP_ID_LENGTH 32

/* SHA1 authentication data. */
#define CLX_BFD_AUTH_SHA1_KEY_LENGTH 64

/* Simple Password authentication data. */
#define CLX_BFD_SIMPLE_PASSWORD_KEY_LENGTH_MAX 64

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/*  BFD admin status. */
typedef enum {
    CLX_BFD_ADMIN_STATUS_UP = 0,
    CLX_BFD_ADMIN_STATUS_DOWN = 1,
    CLX_BFD_ADMIN_STATUS_COUNT
} clx_bfd_admin_status_t;

/* BFD session direction. */
typedef enum {
    CLX_BFD_SESSION_DIRECTION_LOCAL = 0,
    CLX_BFD_SESSION_DIRECTION_REMOTE = 1,
    CLX_BFD_SESSION_DIRECTION_COUNT
} clx_bfd_session_direction_t;

/* BFD Session State. */
typedef enum {
    CLX_BFD_STATE_ADMIN_DOWN = 0,
    CLX_BFD_STATE_DOWN = 1,
    CLX_BFD_STATE_INIT = 2,
    CLX_BFD_STATE_UP = 3,
    CLX_BFD_STATE_COUNT
} clx_bfd_state_e_t;

/* BFD Diagnostic Codes. */
typedef enum {
    CLX_BFD_DIAG_CODE_NONE = 0,
    CLX_BFD_DIAG_CODE_CTRL_DETECT_TIME_EXPIRED = 1,
    CLX_BFD_DIAG_CODE_ECHO_FAILED = 2,
    CLX_BFD_DIAG_CODE_NEIGHBOUR_SIGNALLED_DOWN = 3,
    CLX_BFD_DIAG_CODE_FOWARDING_PLANE_RESET = 4,
    CLX_BFD_DIAG_CODE_PATH_DOWN = 5,
    CLX_BFD_DIAG_CODE_CONCAT_PATH_DOWN = 6,
    CLX_BFD_DIAG_CODE_ADMIN_DOWN = 7,
    CLX_BFD_DIAG_CODE_REV_CONCAT_PATH_DOWN = 8,
    CLX_BFD_DIAG_CODE_MISCONNECTIVITY_DEFECT = 9,
    CLX_BFD_DIAG_CODE_COUNT,
} clx_bfd_diag_code_t;

/* BFD tunnel types. */
typedef enum {                                             // TODO: 确认哪些tunnel需要支持
    CLX_BFD_TUNNEL_TYPE_UDP = 0,                           /* BFD over IPv4/v6. */
    CLX_BFD_TUNNEL_TYPE_IP4IN4 = 1,                        /* BFD over IPv4-in-IPv4 tunnel. */
    CLX_BFD_TUNNEL_TYPE_IP6IN4 = 2,                        /* BFD over IPv6-in-IPv4 tunnel. */
    CLX_BFD_TUNNEL_TYPE_IP4IN6 = 3,                        /* BFD over IPv4-in-IPv6 tunnel. */
    CLX_BFD_TUNNEL_TYPE_IP6IN6 = 4,                        /* BFD over IPv6-in-IPv6 tunnel. */
    CLX_BFD_TUNNEL_TYPE_GRE = 5,                           /* BFD over GRE IPv4-in-IPv4 tunnel. */
    CLX_BFD_TUNNEL_TYPE_GRE4IN4 = CLX_BFD_TUNNEL_TYPE_GRE, /* BFD over GRE IPv4-in-IPv4 tunnel. */
    CLX_BFD_TUNNEL_TYPE_MPLS = 6,                          /* BFD over MPLS LSP. */
    CLX_BFD_TUNNEL_TYPE_PWE_CONTROL_WORD = 7,              /* BFD over PW with CW. */
    CLX_BFD_TUNNEL_TYPE_PWE_ROUTER_ALERT = 8,              /* BFD over PW with Router Alert. */
    CLX_BFD_TUNNEL_TYPE_PWE_TTL = 9,                       /* BFD over PW with TTL=1. */
    CLX_BFD_TUNNEL_TYPE_MPLS_TP_CC = 10,                   /* BFD for MPLS-TP proactive CC. */
    CLX_BFD_TUNNEL_TYPE_MPLS_TP_CC_CV = 11,                /* BFD for MPLS-TP proactive CC&CV. */
    CLX_BFD_TUNNEL_TYPE_GRE6IN4 = 12,                      /* BFD over GRE IPv6-in-IPv4 tunnel. */
    CLX_BFD_TUNNEL_TYPE_GRE4IN6 = 13,                      /* BFD over GRE IPv4-in-IPv6 tunnel. */
    CLX_BFD_TUNNEL_TYPE_GRE6IN6 = 14,                      /* BFD over GRE IPv6-in-IPv6 tunnel. */
    CLX_BFD_TUNNEL_TYPE_PWE_GAL = 15,                      /* BFD over PW with GAL, GACH. */
    CLX_BFD_TUNNEL_TYPE_MPLS_PHP = 16,                     /* BFD over MPLS LSP and PHP. */
    CLX_BFD_TUNNEL_TYPE_VXLAN_IPV4_IN_IPV4 = 17,           /* BFD over VxLAN IPv4-in-IPv4 tunnel. */
    CLX_BFD_TUNNEL_TYPE_VXLAN_IPV4_IN_IPV6 = 18,           /* BFD over VxLAN IPv4-in-IPv6 tunnel. */
    CLX_BFD_TUNNEL_TYPE_VXLAN_IPV6_IN_IPV4 = 19,           /* BFD over VxLAN IPv6-in-IPv4 tunnel. */
    CLX_BFD_TUNNEL_TYPE_VXLAN_IPV6_IN_IPV6 = 20,           /* BFD over VxLAN IPv6-in-IPv6 tunnel. */
    CLX_BFD_TUNNEL_TYPE_SRV6 = 21,                         /* BFD over SRv6 tunnel. */
    CLX_BFD_TUNNEL_TYPE_COUNT = 22
} clx_bfd_tunnel_type_t;

/* BFD Authentication Types. */
typedef enum {
    CLX_BFD_AUTH_TYPE_NONE = 0,
    CLX_BFD_AUTH_TYPE_SIMPLE_PASSWORD = 1,
    CLX_BFD_AUTH_TYPE_KEYED_MD5 = 2,
    CLX_BFD_AUTH_TYPE_METICULOUS_KEYED_MD5 = 3,
    CLX_BFD_AUTH_TYPE_KEYED_SHA1 = 4,
    CLX_BFD_AUTH_TYPE_METICULOUS_KEYED_SHA1 = 5,
    CLX_BFD_AUTH_TYPE_COUNT,
} clx_bfd_auth_type_t;

/* BFD session flags. */
#define CLX_BFD_SESSION_UPDATE                                    \
    0x00000001                          /* Update an existing BFD \
                                            session ID. */
#define CLX_BFD_SESSION_PASSIVE                              \
    0x00000002                          /* Specifies session \
                                              takes passive role. */
#define CLX_BFD_SESSION_DEMAND                                     \
    0x00000004                          /* Specifies local         \
                                              session is in demand \
                                              mode. */
#define CLX_BFD_SESSION_ENCAP_SET                               \
    0x00000008                          /* Update encapsulation \
                                              on existing BFD   \
                                              session. */
#define CLX_BFD_SESSION_PWE_RAW                                   \
    0x00000010                          /* Use MPLS PWE RAW mode. \
                                              Valid only for PWE  \
                                              Tunnel types. */
#define CLX_BFD_SESSION_PWE_ACH                                      \
    0x00000020                          /* Use MPLS Associated       \
                                              Channel Header.  Valid \
                                              only for PWE Tunnel    \
                                              types. */
#define CLX_BFD_SESSION_IPV6 0x00000040 /* Use IPv6 encapsulation. */
#define CLX_BFD_SESSION_MULTIHOP                               \
    0x00000080                          /* BFD IP/UDP multihop \
                                              session. */
#define CLX_BFD_SESSION_MPLS_TP_AIS_LDI                              \
    0x00000100                          /* Set MPLS-TP AIS LDI.      \
                                              Valid only for MPLS-TP \
                                              Tunnel types. */
#define CLX_BFD_SESSION_MPLS_TP_LKR                                 \
    0x00000200                          /* MPLS-TP Locked Report    \
                                              (LKR). Valid only for \
                                              MPLS-TP Tunnel types. */
#define CLX_BFD_SESSION_KEY_TYPE_USE_YOUR_DISC                       \
    0x00000400                          /* Resolve BFD session ID    \
                                              from your              \
                                              discriminator.(Instead \
                                              of MPLS label) */
#define CLX_BFD_SESSION_MPLS_IP_DEST_RANDOM                         \
    0x00000800                          /* Randomize outgoing IP    \
                                              dest addr. Valid only \
                                              for MPLS/PWE Tunnel   \
                                              types. */
#define CLX_BFD_SESSION_MPLS_TP_POLL_SEQUENCE_ENABLE                 \
    0x00001000                          /* Enable poll sequence      \
                                              for MPLS-TP            \
                                              encapsulations.  Valid \
                                              only for MPLS-TP       \
                                              Tunnel types. */
#define CLX_BFD_SESSION_SHA1_SEQUENCE_INCR                          \
    0x00002000                          /* Increment sequence       \
                                                number.  Valid for  \
                                                SHA1 authentication \
                                                only. */
#define CLX_BFD_SESSION_IN_HW                                     \
    0x00004000                          /* Process the endpint in \
                                                HW. */
#define CLX_BFD_SESSION_STACK                                    \
    0x00008000                          /* session is managed by \
                                            other unit in the    \
                                            stack. */
#define CLX_BFD_SESSION_REMOTE_EVENT_DISABLE               \
    0x00010000                          /* Do not generate \
                                               events. */
#define CLX_BFD_SESSION_RDI_AUTO_UPDATE                       \
    0x00020000                          /* Auto update defect \
                                               state on timeout event */
#define CLX_BFD_SESSION_RX_REMOTE_EVENT_DISABLE                   \
    0x00040000                          /* Do not generate events \
                                                for RX packets. */
#define CLX_BFD_SESSION_RX_RDI_AUTO_UPDATE                    \
    0x00080000                          /* Auto update defect \
                                              DB. */
#define CLX_BFD_SESSION_HW_ACCELERATION_SET                  \
    0x00100000                          /* Configure only HW \
                                                accelerator  \
                                                properties. */
#define CLX_BFD_SESSION_USE_PKT_VLAN_ID                         \
    0x00200000                          /* Use to configure the \
                                              User provided Vlan ID. */
#define CLX_BFD_SESSION_MICRO_BFD                                 \
    0x00400000                          /* Use to configure micro \
                                              BFD session. */
#define CLX_BFD_SESSION_ADMIN_DOWN_PKT_ON_SESSION_DEL           \
    0x00800000                          /* Trasmit ADMIN_DOWN   \
                                              packet on session \
                                              deletion. */

/* Additional BFD session flags, only for update session */
#define CLX_BFD_SESSION_FLAGS2_VIRTUAL_ROUTER  0x000001 /* Set virtual router */
#define CLX_BFD_SESSION_FLAGS2_PORT            0x000002 /* Set egress port */
#define CLX_BFD_SESSION_FLAGS2_TC              0x000004 /* Set traffic class */
#define CLX_BFD_SESSION_FLAGS2_VLAN_TPID       0x000008 /* Set vlan tpid */
#define CLX_BFD_SESSION_FLAGS2_VLAN_PRIO       0x000010 /* Set vlan priority */
#define CLX_BFD_SESSION_FLAGS2_VLAN_CFI        0x000020 /* Set vlan cfi */
#define CLX_BFD_SESSION_FLAGS2_VLAN_ID         0x000040 /* Set vlan id */
#define CLX_BFD_SESSION_FLAGS2_TOS             0x000080 /* Set IP header TOS */
#define CLX_BFD_SESSION_FLAGS2_TTL             0x000100 /* Set IP header TTL */
#define CLX_BFD_SESSION_FLAGS2_TUNNEL_TOS      0x000200 /* Set tunnel IP header TOS */
#define CLX_BFD_SESSION_FLAGS2_TUNNEL_TTL      0x000400 /* Set tunnel IP header TTL */
#define CLX_BFD_SESSION_FLAGS2_SRC_MAC_ADDRESS 0x000800 /* Set source MAC address */
#define CLX_BFD_SESSION_FLAGS2_DST_MAC_ADDRESS 0x001000 /* Set destination MAC address */
#define CLX_BFD_SESSION_FLAGS2_SRC_IP          0x002000 /* Set source IP address */
#define CLX_BFD_SESSION_FLAGS2_DST_IP          0x004000 /* Set destination IP address */
#define CLX_BFD_SESSION_FLAGS2_SRC_UDP_PORT    0x008000 /* Set source udp port */
#define CLX_BFD_SESSION_FLAGS2_ECHO            0x010000 /* Set enable/disable echo */
#define CLX_BFD_SESSION_FLAGS2_MIN_TX          0x020000 /* Set min tx interval */
#define CLX_BFD_SESSION_FLAGS2_MIN_RX          0x040000 /* Set min rx interval */
#define CLX_BFD_SESSION_FLAGS2_MULTIPLIER      0x080000 /* Set multiplier */
#define CLX_BFD_SESSION_FLAGS2_MIN_ECHO_RX     0x100000 /* Set min echo rx interval */

/* BFD session object. */
typedef struct clx_bfd_session_cfg_info_s {
    uint32 flags;                  /* Control flags. */
    uint32 flags2;                 /* Second set of control flags. */
    uint32 session_id;             /* Session ID. */
    uint32 tunnel_type;            /* Type of BFD encapsulation. */
    uint32 tx_port;                /* TX port associated with this
                                     session. */
    uint16 vlan_tpid;              /* Vlan Tag Protocol Identifier. In case
                                       of VxLAN, Inner/Overlay Vlan Tag
                                       Protocol Identifier. */
    uint8 vlan_pri;                /* VLAN tag priority. */
    uint8 vlan_cfi;                /* VLAN CFI. */
    uint8 inner_vlan_pri;          /* Inner VLAN tag priority. */
    uint8 inner_vlan_cfi;          /* Inner VLAN CFI. */
    uint16 inner_vlan_tpid;        /* Inner Vlan Tag Protocol Identifier.
                                       In case of VxLAN, Inner/Overlay inner
                                       Vlan Tag Protocol Identifier. */
    uint32 vrf_id;                 /* Vrf identifier. */
    clx_mac_t dst_mac;             /* Destination MAC. In case of VxLAN,
                                         Inner/Overlay Destination MAC. */
    clx_mac_t src_mac;             /* Source MAC. In case of VxLAN,
                                         Inner/Overlay Source MAC. */
    clx_ipv4_t src_ip_addr;        /* Source IPv4 address. In case of
                                  VxLAN, Inner/Overlay Source IPv4
                                  address. */
    clx_ipv4_t dst_ip_addr;        /* Destination IPv4 address. In case of
                                  VxLAN, Inner/Overlay Destination IPv4
                                  address. */
    clx_ipv6_t src_ip6_addr;       /* Source IPv6 address. In case of
                                    VxLAN, Inner/Overlay Source IPv6
                                    address. */
    clx_ipv6_t dst_ip6_addr;       /* Destination IPv6 address. In case of
                                    VxLAN, Inner/Overlay Destination IPv6
                                    address. */
    uint8 ip_tos;                  /* IPv4 Tos / IPv6 Traffic Class. In
                                      case of VxLAN, Inner/Overlay IPv4 Tos
                                      / IPv6 Traffic Class. */
    uint8 ip_ttl;                  /* IPv4 TTL / IPv6 Hop Count. In case of
                                      VxLAN, Inner/Overlay IPv4 TTL / IPv6
                                      Hop Count. */
    uint16 pkt_inner_vlan_id;      /* TX Packet inner Vlan Id. In case of
                                      VxLAN, Inner/Overlay Inner VLAN Id
                                      and priority. */
    clx_ipv4_t inner_src_ip_addr;  /* Inner source IPv4 address. */
    clx_ipv4_t inner_dst_ip_addr;  /* Inner destination IPv4 address. */
    clx_ipv6_t inner_dst_ip6_addr; /* Inner destination IPv6 address. */
    clx_ipv6_t inner_src_ip6_addr; /* Inner source IPv6 address. */
    uint8 inner_ip_tos;            /* Inner IPv4 Tos / IPv6 Traffic Class. */
    uint8 inner_ip_ttl;            /* Inner IPv4 TTL / IPv6 Hop Count. */
    uint16 udp_src_port;           /* UDP source port for Ipv4, Ipv6. */
    uint32 local_discr;            /* Local discriminator. */
    uint32 local_min_tx;           /* Desired local min tx interval (us). */
    uint32 local_min_rx;           /* Required local rx interval (us). */
    uint32 local_min_echo;         /* Local minimum echo interval (us). */
    uint32 local_detect_mult;      /* Local detection interval multiplier. */
    uint32 auth_type;              /* Authentication type. */
    uint32 auth_index;             /* Authentication index. */
    uint32 tx_auth_seq;            /* Tx authentication sequence id. */
    uint32 rx_auth_seq;            /* Rx authentication sequence id. */
    uint32 remote_discr;           /* Remote discriminator. */
    uint32 bfd_detection_time;     /* Optional: BFD Detection Time, in
                                      microseconds. */
    uint16 pkt_vlan_id;            /* TX Packet Vlan Id. In case of VxLAN,
                                      Inner/Overlay VLAN Id and priority. */
    uint16 inner_pkt_vlan_id;      /* Inner Packet Vlan Id. */
    uint8 tc;                      /* Traffic class. */
} clx_bfd_session_cfg_info_t;

/* BFD session mpls info object. */
typedef struct clx_bfd_session_mpls_cfg_info_s {
    uint32 label;    /* Incoming inner label. */
    uint32 mpls_hdr; /* MPLS Header. */
    // bcm_mpls_egress_label_t egress_label; /* The MPLS outgoing label information. */
    int32 egress_if;                                 /* Egress interface. */
    uint8 mep_id[CLX_BFD_SESSION_MAX_MEP_ID_LENGTH]; /* MPLS-TP CC/CV TLV and Source MEP ID. */
    uint8 mep_id_length;                             /* Length of MPLS-TP CC/CV TLV and
                                                        MEP-ID. */
    uint8 remote_mep_id[CLX_BFD_SESSION_MAX_MEP_ID_LENGTH]; /* MPLS-TP CC/CV TLV and Remote MEP ID.
                                                             */
    uint8 remote_mep_id_length;                             /* Length of MPLS-TP CC/CV TLV and
                                                               REMOTE MEP-ID. */
    uint8 mis_conn_mep_id[CLX_BFD_SESSION_MAX_MEP_ID_LENGTH]; /* MPLS-TP CC/CV TLV and Mis
                                           connectivity MEP ID. */
    uint8 mis_conn_mep_id_length;                             /* Length of MPLS-TP CC/CV TLV and Mis
                                                                 connectivity MEP-ID. */
    uint32 gal_label;                                         /* MPLS GAL label. */
    uint8 bfd_period_cluster; /* Tx period group. All MEPs in a group
                                 must be created with the same Tx
                                 period. Modifying the Tx period in
                                 one MEP affects the others. */
} clx_bfd_session_mpls_cfg_info_t;

typedef struct clx_bfd_session_vxlan_cfg_info_s {
    int32 gport;       /* Gport identifier. In case of VxLAN,
                          Tunnel ID */
    uint32 vxlan_vnid; /* VxLAN Network Identifier. */
} clx_bfd_session_vxlan_cfg_info_t;

#define CLX_BFD_SESSION_STATS_PACKETS_IN         0x01
#define CLX_BFD_SESSION_STATS_PACKETS_OUT        0x02
#define CLX_BFD_SESSION_STATS_PACKETS_DROP       0x04
#define CLX_BFD_SESSION_STATS_PACKETS_AUTH_DROP  0x08
#define CLX_BFD_SESSION_STATS_PACKETS_ECHO_REPLY 0x10
#define CLX_BFD_SESSION_STATS_PACKETS_ALL        0x1f

/* BFD session statistics. */
typedef struct clx_bfd_session_stats_s {
    uint64 packets_in;         /* Total packets in 64bit count. */
    uint64 packets_out;        /* Total packets out 64bit count. */
    uint64 packets_drop;       /* Total packets drop 64bit count. */
    uint64 packets_auth_drop;  /* Packets drop due to authentication
                                     failure 64bit count. */
    uint64 packets_echo_reply; /* Total number of echo reply packets
                                  processed. */
} clx_bfd_session_stats_t;

/* Incoming bfd packets dropped statistics. */
typedef struct clx_bfd_drop_stats_s {
    uint32 bfd_ver_err;                    /* Invalid BFD Version. */
    uint32 bfd_len_err;                    /* BFD Length Error. */
    uint32 bfd_detect_mult;                /* BFD detect multiplier Zero. */
    uint32 bfd_my_disc;                    /* BFD My discriminator Zero. */
    uint32 bfd_p_f_bit;                    /* BFD poll and final bits set. */
    uint32 bfd_m_bit;                      /* BFD M bit not equal to zero. */
    uint32 bfd_auth_type_mismatch;         /* BFD auth type mismatch. */
    uint32 bfd_auth_simple_err;            /* BFD auth simple password Error. */
    uint32 bfd_auth_m_sha1_err;            /* BFD auth SHA1 error. */
    uint32 bfd_sess_mismatch;              /* BFD Session mismatch. */
    uint32 bfd_mpls_fm_len_err;            /* BFD MPLS FM Packet received smaller
                                              than expected. */
    uint32 bfd_mpls_fm_type_err;           /* BFD MPLS FM type received
                                              unsupported. */
    uint32 bfd_echo_ipv4_mismatch;         /* BFD IPv4 echo pkt received with
                                              src/dst ip not equal. */
    uint32 bfd_echo_ipv6_mismatch;         /* BFD IPv6 echo pkt received with
                                              src/dst ip not equal. */
    uint32 bfd_ip_hdr_ver_err;             /* BFD IP packet received with invalid
                                              version. */
    uint32 bfd_mpls_no_label;              /* BFD MPLS packet received with no
                                              labels. */
    uint32 bfd_gal_additional_label_miss;  /* BFD MPLS packet received with only
                                            one label and BOS as GAL. */
    uint32 bfd_unknown_ach_type;           /* BFD MPLS pkt received with unknown
                                              ACH type. */
    uint32 bfd_vxlan_i_flag_err;           /* BFD VXLAN pkt received with I flag
                                              not set. */
    uint32 bfd_ip_ttl_err;                 /* BFD VXLAN pkt received with wrong TTL
                                              value. */
    uint32 bfd_unsupported_echo_encap_err; /* BFD VXLAN echo packet received which
                                           is not supported. */
    uint32 bfd_unsupported_ethertype_err;  /* BFD packet received with unsupported
                                            ether type. */
    uint32 bfd_ether_type_len_err;         /* BFD pkt received with insufficient L2
                                              header length. */
    uint32 bfd_offset_err;                 /* BFD packet received with unsupported
                                              offset type. */
    uint32 bfd_malformed_pkt_err;          /* BFD special type pkt received with
                                              nonzero discriminator for other than
                                              MPLS TP CC & CV type. */
    uint32 bfd_malformed_ipv4_pkt_err;     /* BFD pkt received with IPv4 ether
                                              type, but invalid
                                              TTL/Protocol/Src/Dst IP address. */
    uint32 bfd_malformed_ipv6_pkt_err;     /* BFD pkt received with IPv6 ether
                                              type, but invalid
                                              HopLimit/Protocol/Src/Dst IP address. */
    uint32 bfd_malformed_mpls_pkt_err;     /* BFD pkt received with MPLS ether
                                              type, but invalid TTL/Label. */
    uint32 bfd_sess_id_config_err;         /* BFD packet received with session id
                                              wrongly configured. */
    uint32 bfd_session_not_enabled;        /* BFD packet received with session no
                                              longer enabled. */
    uint32 bfd_your_disc_zero;             /* BFD Packet received with your
                                              discrimnator zero for session states
                                              INIT or UP. */
    uint32 bfd_your_disc_mismatch;         /* BFD packet received for a session
                                              with your discriminator mismatch with
                                              local discriminator. */
    uint32 bfd_my_disc_mismatch;           /* BFD packet received for a session
                                              with my discriminator mismatch with
                                              remote discriminator. */
    uint32 bfd_pkts_discarded_admin_down;  /* BFD packet received for a session in
                                            ADMIN DOWN state. */
    uint32 bfd_echo_your_disc_zero;        /* BFD Echo packet received with zero
                                              your discriminator. */
    uint32 bfd_echo_your_disc_err;         /* BFD Echo packet received for a
                                              session with your discriminator
                                              mismatch with local discriminator. */
    uint32 bfd_mpls_fm_sess_mismatch;      /* BFD MPLS FM pkt received for non
                                              CC/CC_CV session. */
    uint32 bfd_non_cc_cv_err;              /* BFD packet received for a CC_CV
                                              session, but its not of MPLS TP CC/CV
                                              type. */
} clx_bfd_drop_stats_t;

typedef struct clx_bfd_auth_sha1_s {
    uint8 enable;
    uint32 sequence;
    uint8 key[CLX_BFD_AUTH_SHA1_KEY_LENGTH];
} clx_bfd_auth_sha1_t;

typedef struct clx_bfd_auth_simple_password_s {
    uint8 length;
    uint8 password[CLX_BFD_SIMPLE_PASSWORD_KEY_LENGTH_MAX];
} clx_bfd_auth_simple_password_t;

/* BFD session status. */
typedef struct clx_bfd_session_status_s {
    /* Local session info */
    uint32 local_session_id;
    uint32 local_diag;
    uint32 local_state;
    uint32 selected_tx;
    uint32 selected_rx;
    uint32 selected_echo;
    uint32 selected_detect_mult;
    uint32 demand_active_status;

    /* Remote session info */
    uint32 remote_session_id;
    uint32 remote_state;
    uint32 remote_min_tx;
    uint32 remote_min_rx;
    uint32 remote_min_echo;
    uint32 remote_detect_mult;
    uint32 remote_diag;
    uint32 remote_demand_status;
} clx_bfd_session_status_t;

typedef struct clx_bfd_event_msg_s {
    uint32 session_id;
    uint32 status; /* BFD session status, refer to clx_bfd_state_e_t. */
} clx_bfd_event_msg_t;

/* BFD event callback. */
typedef void (*clx_bfd_event_cb_t)(const uint32 unit,
                                   const clx_bfd_event_msg_t *msg,
                                   void *ptr_cookie);

/**
 * @brief This API is used to create a bfd session.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number @param [inout] ptr_cfg - BFD session configuration.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_create(const uint32 unit, clx_bfd_session_cfg_info_t *ptr_cfg);

/**
 * @brief This API is used to delete a bfd session.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - BFD session id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_delete(const uint32 unit, const uint32 session_id);

/**
 * @brief This API is used to delete all bfd sessions.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_all_session_delete(const uint32 unit);

/**
 * @brief This API is used to update the bfd session configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_cfg    - BFD session configuration .
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_update(const uint32 unit, clx_bfd_session_cfg_info_t *ptr_cfg);

/**
 * @brief This API is used to get the bfd session configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     session_id    - BFD session id.
 * @param [out]    ptr_cfg       - BFD session configuration .
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_cfg_info_get(const uint32 unit,
                             const uint32 session_id,
                             clx_bfd_session_cfg_info_t *ptr_cfg);

/**
 * @brief This API is used to get the next bfd session configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     session_id    - BFD session id.
 * @param [out]    ptr_cfg       - BFD session configuration.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_next_cfg_info_get(const uint32 unit,
                                  const uint32 session_id,
                                  clx_bfd_session_cfg_info_t *ptr_cfg);

/**
 * @brief This API is used to get the bfd session packet statistics.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     session_id    - BFD session id.
 * @param [out]    ptr_stats     - BFD session statistics.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_pkt_stats_get(const uint32 unit,
                              const uint32 session_id,
                              clx_bfd_session_stats_t *ptr_stats);

/**
 * @brief This API is used to get the bfd drop packet statistics.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_stats    - BFD drop packet statistics.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_bfd_global_drop_pkt_stats_get(const uint32 unit, clx_bfd_drop_stats_t *ptr_stats);

/**
 * @brief This API is used to clear the bfd session packet statistics.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - BFD session id.
 * @param [in]    flags         - Flags to clear.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_bfd_session_pkt_stats_clear(const uint32 unit, const uint32 session_id, const uint32 flags);

/**
 * @brief This API is used to clear the bfd session drop packet statistics.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_bfd_global_drop_pkt_stats_clear(const uint32 unit);

/**
 * @brief This API is used to get the bfd session status.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     session_id    - BFD session id.
 * @param [out]    ptr_status    - BFD session status.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_status_get(const uint32 unit,
                           const uint32 session_id,
                           clx_bfd_session_status_t *ptr_status);

/**
 * @brief This API is used to trigger the bfd session poll.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - BFD session id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_poll_trigger(const uint32 unit, const uint32 session_id);

/**
 * @brief This API is used to set the bfd session admin status.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - BFD session id.
 * @param [in]    status        - BFD session admin status.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_bfd_session_admin_set(const uint32 unit,
                          const uint32 session_id,
                          const clx_bfd_admin_status_t status);

/**
 * @brief This API is used to register the bfd event callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cb            - BFD event callback.
 * @param [in]    ptr_cookie    - Pointer to cookie.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_bfd_event_cb_register(const uint32 unit, clx_bfd_event_cb_t cb, void *ptr_cookie);

/**
 * @brief This API is used to unregister the bfd event callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_bfd_event_cb_unregister(const uint32 unit);

#endif /* CLX_BFD_H */
