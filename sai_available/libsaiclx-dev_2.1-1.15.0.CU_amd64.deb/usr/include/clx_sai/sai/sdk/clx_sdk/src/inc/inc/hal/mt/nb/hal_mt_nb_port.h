/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_MT_NB_PORT_H
#define HAL_MT_NB_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <hal/mt/hal_mt_mac.h>
#include <hal/mt/nb/hal_mt_nb_serdes.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_ETH_SLICE_MAX_NUM                  (8)
#define HAL_MT_NB_ETH_MACRO_MAX_NUM_PER_SLICE        (4)
#define HAL_MT_NB_L256_ETH_MACRO_MAX_NUM_PER_SLICE   (8)
#define HAL_MT_NB_PORT_DROP_PKT_DISABLE              (0)
#define HAL_MT_NB_PORT_DROP_PKT_UNTAGGED             (1)
#define HAL_MT_NB_PORT_DROP_PKT_TAGGED               (2)
#define HAL_MT_NB_PORT_DROP_PKT_TAGGED_EXPT_DFLT_VID (3)
#define HAL_MT_NB_PORT_MACRO_INVALID                 (0xFFFFFFFF)

#define HAL_MT_NB_PORT_DERICTION_INGRESS (0)
#define HAL_MT_NB_PORT_DERICTION_EGRESS  (1)

#define HAL_MT_NB_PORT_MBURST_CNT_TX_BYTE       (0)
#define HAL_MT_NB_PORT_MBURST_CNT_TX_PKT        (1)
#define HAL_MT_NB_PORT_MBURST_CNT_TX_MATCH_BYTE (2)
#define HAL_MT_NB_PORT_MBURST_CNT_TX_MATCH_PKT  (3)

typedef enum {
    HAL_MT_NB_PORT_FC_DISABLE,
    HAL_MT_NB_PORT_FC_PAUSE,
    HAL_MT_NB_PORT_FC_PFC,
    HAL_MT_NB_PORT_FC_LAST
} HAL_MT_NB_PORT_FC_T;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS */
/**
 * @brief This API is used to set the mapping between unit/port and mac/lane number.
 *
 * This API is suggested to be used during SDK initialization.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Physical port ID.
 * @param [in]    ptr_lane_map    - Lane map info pointer.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_lane_map_set(const uint32 unit,
                            const uint32 port,
                            const clx_port_lane_map_info_t *ptr_lane_map);

/**
 * @brief This API is used to get the mapping between unit/port and mac/lane number.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port ID.
 * @param [out]    ptr_lane_map    - Lane map info pointer.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_lane_map_get(const uint32 unit,
                            const uint32 port,
                            clx_port_lane_map_info_t *ptr_lane_map);

/**
 * @brief This API is used to set port egress vlan tag control. number.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    intf            - Logical port ID.
 * @param [in]    bdid            - Bridge Doamin ID.
 * @param [in]    ptr_port_tag    - Egress vlan tag control.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_vlan_tag_ctrl_set(const uint32 unit,
                                 const clx_port_t intf,
                                 const clx_bridge_domain_t bdid,
                                 const clx_port_vlan_tag_ctrl_t *ptr_port_tag);

/**
 * @brief This API is used to get port egress vlan tag control. number.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     intf            - Logical port ID.
 * @param [in]     bdid            - Bridge Doamin ID.
 * @param [out]    ptr_port_tag    - Egress vlan tag control.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_vlan_tag_ctrl_get(const uint32 unit,
                                 const clx_port_t intf,
                                 const clx_bridge_domain_t bdid,
                                 clx_port_vlan_tag_ctrl_t *ptr_port_tag);

/**
 * @brief To get register and filed of mac status for a specific port.
 *
 * @param [in]     unit          - Chip id.
 * @param [in]     port          - Physical Port id.
 * @param [in]     status        - Status type.
 * @param [out]    ptr_param0    - Value.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_mac_status_get(const uint32 unit,
                              const uint32 port,
                              const uint32 status,
                              uint32 *ptr_param0);

/**
 * @brief To set umac channel mode.
 *
 * @param [in]    unit        - Chip id.
 * @param [in]    port        - Port id.
 * @param [in]    lane_cnt    - Lane cnt.
 * @param [in]    fec         - Fec mode.
 * @param [in]    speed       - Set speed.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_chmode_set(const uint32 unit,
                          const uint32 port,
                          const uint32 lane_cnt,
                          const uint32 fec,
                          const uint32 speed);

/**
 * @brief To get fec from umac channel mode.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @param [in]    fec     - Fec mode.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_fec_get(const uint32 unit, const uint32 port, uint32 *fec);

/**
 * @brief To set umac and pl speed for a specific port.
 *
 * @param [in]    unit        - Chip id.
 * @param [in]    port        - Port id.
 * @param [in]    lane_cnt    - Lane cnt.
 * @param [in]    fec         - Fec mode.
 * @param [in]    speed       - Set speed.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_speed_set(const uint32 unit,
                         const uint32 port,
                         const uint32 lane_cnt,
                         const uint32 fec,
                         const uint32 speed);

/**
 * @brief To set mac control property.
 *
 * @param [in]    unit        - Chip id.
 * @param [in]    port        - Port id.
 * @param [in]    property    - Property type.
 * @param [in]    param0      - First parameter.
 * @param [in]    param1      - Second parameter.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_mac_cfg_set(const uint32 unit,
                           const uint32 port,
                           const HAL_MAC_PROPERTY_T property,
                           uint32 param0,
                           const uint32 param1);

/**
 * @brief To get mac control property.
 *
 * @param [in]     unit          - Chip id.
 * @param [in]     port          - Port id.
 * @param [in]     property      - Property type.
 * @param [out]    ptr_param0    - Property value.
 * @param [out]    ptr_param1    - Reserved.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_mac_cfg_get(const uint32 unit,
                           const uint32 port,
                           const HAL_MAC_PROPERTY_T property,
                           uint32 *ptr_param0,
                           uint32 *ptr_param1);

/**
 * @brief To set eth port dead lock.
 *
 * @param [in]    unit     - Chip id.
 * @param [in]    port     - Port id.
 * @param [in]    queue    - Queue id.
 * @param [in]    mode     - Dead lock state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_dead_lock_set(const uint32 unit,
                             const uint32 port,
                             const uint32 queue,
                             const uint32 mode);

/**
 * @brief To set eth port dead lock.
 *
 * Set  based on 0.74ns unit. For example 100ms 1.35*10^8 (80B EFCO);.
 *
 * @param [in]    unit         - Chip id.
 * @param [in]    port         - Port id.
 * @param [in]    threshold    - Dead lock threshold.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_dead_lock_th_set(const uint32 unit, const uint32 port, const uint32 threshold);

/**
 * @brief To set tx flush state.
 *
 * Tx flush is write only feature.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    enable    - Flush state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_tx_flush_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief To set tx queue flush state.
 *
 * Tx que flush is write only feature.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    queue     - Flush queue.
 * @param [in]    enable    - Mac tx flush enable/disable.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_tx_que_flush_set(const uint32 unit,
                                const uint32 port,
                                const uint32 queue,
                                const uint32 enable);

/**
 * @brief To set per queue Flow Control ignore.
 *
 * @param [in]    unit      - Chip id.
 * @param [in]    port      - Port id.
 * @param [in]    queue     - Queue id.
 * @param [in]    enable    - Fc ignore state.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_port_flow_ctrl_ignore_set(const uint32 unit,
                                    const uint32 port,
                                    const uint32 queue,
                                    const uint32 enable);

/**
 * @brief Set epl xoff mask.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable epl xoff mask 0: disable epl xoff mask.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_tx_xoff_mask_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Check buffer empty.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_buf_empty_check(const uint32 unit, const uint32 port);

/**
 * @brief Set rx port status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable 0: disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_rx_admin_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Set tx port status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable 0: disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_tx_admin_state_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Config cpx port pl.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Cpx port id(256,257,259).
 * @param [in]    speed    - Cpi speed,max 100g.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_cpx_pl_cfg(const uint32 unit, const uint32 port, clx_port_speed_t speed);

/**
 * @brief This API is used to set the cut through state for a specific port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    speed    - Physical port speed.
 * @param [in]    ct_en    - Cut throught state 1 for cut through state 0 for store and forward
 *                           state.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_cut_through_set(const uint32 unit,
                               const uint32 port,
                               const uint32 speed,
                               const uint32 ct_en);

/**
 * @brief To set the flow control configuration for a specific port.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    channel_num    - Port buffer num.
 * @param [in]    speed          - Physical port speed.
 * @param [in]    fc_mode        - HAL_MT_NB_PORT_FC_T.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_flow_control_set(const uint32 unit,
                                const uint32 port,
                                const uint32 channel_num,
                                const uint32 speed,
                                const uint32 fc_mode);

/**
 * @brief To set pkt drop for tm module.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    channel_num    - Port buffer num.
 * @param [in]    speed          - Physical port speed.
 * @param [in]    drop_flg       - Drop flag.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_pkt_drop_set(const uint32 unit,
                            const uint32 port,
                            const uint32 channel_num,
                            const uint32 speed,
                            const uint32 drop_flg);

clx_error_no_t
hal_mt_nb_port_fabric_set(const uint32 unit, const uint32 port, const uint32 fabric_en);

clx_error_no_t
hal_mt_nb_port_fabric_get(const uint32 unit, const uint32 port, uint32 *fabric_en);

/**
 * @brief Config mburst property.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Physical port ID.
 * @param [in]    ptr_property    - Property type.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_cfg_set(const uint32 unit,
                              const uint32 port,
                              const clx_port_mburst_cfg_t *ptr_property);

/**
 * @brief Get mburst property.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Physical port ID.
 * @param [in]    ptr_property    - Property type.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_cfg_get(const uint32 unit,
                              const uint32 port,
                              clx_port_mburst_cfg_t *ptr_property);

/**
 * @brief Get mburst histogram statistic.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Port.
 * @param [in]    dir       - IPL or EPL.
 * @param [in]    p_stat    - Statistic.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_stat_get(const uint32 unit,
                               const uint32 port,
                               const clx_dir_t dir,
                               clx_port_mburst_stat_t *p_stat);

/**
 * @brief Get mburst histogram count.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical Port ID.
 * @param [in]     dir          - IPL or EPL.
 * @param [in]     thrd_num     - Threshold num.
 * @param [out]    ptr_count    - Mburst Histogram count.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_hist_cnt_get(const uint32 unit,
                                   const uint32 port,
                                   const clx_dir_t dir,
                                   const uint32 thrd_num,
                                   uint32 *ptr_count);

/**
 * @brief Clear mburst count.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port.
 * @param [in]    dir     - IPL or EPL.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_mburst_clear_set(const uint32 unit, const uint32 port, const clx_dir_t dir);

/**
 * @brief This API is used to set counter clear.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - This API is not support in this chip.
 */
clx_error_no_t
hal_mt_nb_port_fec_clear(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get buffer count.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @return        CLX_E_OK             - Success.
 * @return        CLX_E_NOT_SUPPORT    - This API is not support in this chip.
 */
clx_error_no_t
hal_mt_nb_port_buff_cnt_show(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get buffer config.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @return        CLX_E_OK             - Success.
 * @return        CLX_E_NOT_SUPPORT    - This API is not support in this chip.
 */
clx_error_no_t
hal_mt_nb_port_buff_cfg_show(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get xoff status.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port               - Physical port.
 * @param [out]    ptr_xoff_status    - Xoff status.
 * @return         CLX_E_OK             - Success.
 * @return         CLX_E_NOT_SUPPORT    - This API is not support in this chip.
 */
clx_error_no_t
hal_mt_nb_port_xoff_status_get(const uint32 unit,
                               const uint32 port,
                               clx_port_xoff_status_t *ptr_xoff_status);

/**
 * @brief This API is used to set destination index.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @param [in]    di      - Destination index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_port_di_set(const uint32 unit, const uint32 port, const uint32 di);

#endif /* #ifndef HAL_MT_NB_PORT_H */
