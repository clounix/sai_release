/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_intr.h
 * PURPOSE:
 *      1. hal_mt_intr.h provides HAL ISR manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_INTR_H
#define HAL_MT_INTR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_intr.h>
#include <drv/drv.h>

#include <hal/hal.h>
#include <util/lib/util_lib_queue.h>

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_INTR_GET_INTR_FUNC_PTR(unit) (hal_mt_intr_func[unit])

#define HAL_MT_INTR_VEC_CHAIN24      (24)
#define HAL_MT_INTR_VEC_CHAIN25      (25)
#define HAL_MT_INTR_VEC_CHAIN29      (29)
#define HAL_MT_INTR_VEC_CHAIN31      (31)
#define HAL_MT_INTR_MASK_UMAC0       (0)
#define HAL_MT_INTR_MASK_UMAC1       (1)
#define HAL_MT_INTR_MAX_CAHIN_SIZE   (32)
#define HAL_MT_INTR_MAX_SLAVE_SIZE   (32)
#define HAL_MT_INTR_CHAIN29_CMAC_SLV (16)

typedef struct hal_mt_intr_reg_node_s {
    clx_intr_type_t intr_type;

    uint32 inst_idx;
    uint32 subinst_idx;

    uint32 stat_reg; /* intr reg id, such as MT_NB_REG_TDS_SLV_TDS_TIMEOUT_IRQ_ID */
    uint32 mask_reg;
    uint32 clr_reg;
    uint32 test_reg;
} hal_mt_intr_reg_node_t;

typedef clx_error_no_t (*hal_mt_intr_isr_handle_func_t)(const uint32 unit, void *ptr_cookie);

typedef struct hal_mt_intr_node_s {
    hal_mt_intr_reg_node_t reg_info;
    hal_mt_intr_isr_handle_func_t intr_handle_func;
    const struct hal_mt_intr_node_s *next;
} hal_mt_intr_node_t;

/* Callback Functions for IRQ related registers R/W */
typedef clx_error_no_t (*hal_mt_intr_read_func_t)(const uint32 unit,
                                                  uint32 *ptr_reg_val,
                                                  uint32 *word_size,
                                                  const hal_mt_intr_reg_node_t intr_node);

typedef clx_error_no_t (*hal_mt_intr_read_mask_func_t)(const uint32 unit,
                                                       uint32 *ptr_reg_val,
                                                       const hal_mt_intr_reg_node_t intr_node);

typedef clx_error_no_t (*hal_mt_intr_write_func_t)(const uint32 unit,
                                                   uint32 *reg_val,
                                                   hal_mt_intr_reg_node_t intr_node);

typedef clx_error_no_t (*hal_mt_intr_type_write_func_t)(const uint32 unit,
                                                        const clx_intr_type_t intr_type);

typedef clx_error_no_t (*hal_mt_intr_chain_unmask_func_t)(const uint32 unit, const uint32 reg_val);

typedef clx_error_no_t (*hal_mt_intr_dump_func_t)(const uint32 unit);

typedef struct hal_mt_intr_vec_s {
    uint32 slave;
    uint32 inst_idx;
    uint32 subinst_idx;
    const hal_mt_intr_node_t *slave_head;
} hal_mt_intr_vec_t;

typedef struct hal_mt_intr_func_s {
    hal_mt_intr_read_func_t intr_read_stat;
    hal_mt_intr_write_func_t intr_set;
    hal_mt_intr_write_func_t intr_clear;
    hal_mt_intr_read_mask_func_t intr_read_mask;
    hal_mt_intr_write_func_t intr_mask;
    hal_mt_intr_write_func_t intr_unmask;
    hal_mt_intr_type_write_func_t intr_type_unmask;
    hal_mt_intr_type_write_func_t intr_type_mask;
    hal_mt_intr_chain_unmask_func_t intr_umac_unmask;
    hal_mt_intr_dump_func_t intr_dump;
} hal_mt_intr_func_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* -------------------------------------- Init and deinit */
clx_error_no_t
hal_mt_intr_init(const uint32 unit);

clx_error_no_t
hal_mt_intr_deinit(const uint32 unit);

clx_error_no_t
hal_mt_intr_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_intr_cfg_deinit(const uint32 unit);

/* -------------------------------------- Reg operation */
clx_error_no_t
hal_mt_intr_read(const uint32 unit,
                 uint32 *reg_val,
                 uint32 *word_size,
                 const hal_mt_intr_reg_node_t intr_node);

clx_error_no_t
hal_mt_intr_mask(const uint32 unit, uint32 *reg_val, const hal_mt_intr_reg_node_t intr_node);

clx_error_no_t
hal_mt_intr_clear(const uint32 unit, uint32 *reg_val, const hal_mt_intr_reg_node_t intr_node);

clx_error_no_t
hal_mt_intr_unmask(const uint32 unit, uint32 *reg_val, const hal_mt_intr_reg_node_t intr_node);

clx_error_no_t
hal_mt_intr_type_unmask(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_umac_unmask(const uint32 unit, const uint32 reg_val);

clx_error_no_t
hal_mt_intr_type_mask(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_dump(const uint32 unit);

/* -------------------------------------- API and callbacks */
clx_error_no_t
hal_mt_intr_irq_request(const uint32 unit,
                        clx_intr_type_t intr_type,
                        hal_mt_intr_isr_handle_func_t handler);

clx_error_no_t
hal_mt_intr_event_trigger(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_event_reg_trigger(const uint32 unit, void *ptr_cookie);

clx_error_no_t
hal_mt_intr_common_event_trigger(const uint32 unit, void *ptr_cookie);

clx_error_no_t
hal_mt_intr_event_wait(const uint32 unit, const clx_intr_type_t intr_type, const uint32 timeout);

clx_error_no_t
hal_mt_intr_spinlock_take(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_spinlock_give(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_ifmon_event_wait(const uint32 unit, const uint32 timeout);

clx_error_no_t
hal_mt_telm_hdr_event_trigger(const uint32 unit, void *ptr_cookie);

clx_error_no_t
hal_mt_intr_l2_fifo_event_trigger(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_event_cnt_get(const uint32 unit, const clx_intr_type_t intr_type, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_intr_event_cnt_incr(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_event_cnt_clear(const uint32 unit, const clx_intr_type_t intr_type);

const char *
hal_mt_intr_event_string_get(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_disable(const uint32 unit, const clx_intr_type_t intr_type);

clx_error_no_t
hal_mt_intr_enable(const uint32 unit, const clx_intr_type_t intr_type);

#endif /* #ifndef HAL_MT_INTR_H */
