/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_netif.h
 * PURPOSE:
 *      Define the NET interface APIs in CLX SDK.
 * NOTES:
 */
#ifndef CLX_NETIF_H
#define CLX_NETIF_H

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_pkt.h>

#define CLX_NETIF_NAME_LEN               (16)
#define CLX_NETLINK_NAME_LEN             (16)
#define CLX_NETIF_PROFILE_NUM_MAX        (258)
#define CLX_NETIF_PROFILE_PATTERN_NUM    (4)
#define CLX_NETIF_PROFILE_PATTERN_LEN    (8)
#define CLX_NETIF_NETLINK_NUM_MAX        (258)
#define CLX_NETIF_NETLINK_MC_GRP_NUM_MAX (32)

/* ----------------------------------------------------------------------------------- struct */
typedef struct clx_netif_intf_cnt_s {
    uint32 tx_pkt;
    uint32 tx_queue_full;
    uint32 tx_err;
    uint32 rx_pkt;
} clx_netif_intf_cnt_t;

typedef struct clx_netif_rx_reason_cnt_s {
    uint64 pkt_cnts;
    uint64 byte_cnts;
} clx_netif_rx_reason_cnt_t;

typedef struct clx_netif_intf_s {
    /* unique key */
    uint32 id;
    char name[CLX_NETIF_NAME_LEN];
    clx_port_t port; /* only support unit port and local port */

    clx_mac_t mac;
    uint8 skip_port_state_event;
    uint8 vlan_tag_type; /* used by CLX_NETIF_VLAN_TAG_* */
    uint32 igr_sampling_rate;
    uint32 egr_sampling_rate;
    uint32 oper_state;
    uint32 flags; /* used by CLX_NETIF_INTF_FLAGS_* */
    uint32 tc;
} clx_netif_intf_t;

#define CLX_NETIF_INTF_FLAGS_NAME                  (1UL << 0)
#define CLX_NETIF_INTF_FLAGS_PORT                  (1UL << 1)
#define CLX_NETIF_INTF_FLAGS_MAC                   (1UL << 2)
#define CLX_NETIF_INTF_FLAGS_VLAN_TAG_TYPE         (1UL << 3)
#define CLX_NETIF_INTF_FLAGS_IGR_SAMPLING_RATE     (1UL << 4)
#define CLX_NETIF_INTF_FLAGS_EGR_SAMPLING_RATE     (1UL << 5)
#define CLX_NETIF_INTF_FLAGS_SKIP_PORT_STATE_EVENT (1UL << 6)
#define CLX_NETIF_INTF_FLAGS_OPER_STATE            (1UL << 7)
#define CLX_NETIF_INTF_FLAGS_TC                    (1UL << 8)

#define CLX_NETIF_VLAN_TAG_STRIP    (0)
#define CLX_NETIF_VLAN_TAG_KEEP     (1)
#define CLX_NETIF_VLAN_TAG_ORIGINAL (2)

typedef struct clx_netif_netlink_mc_grp_s {
    char name[CLX_NETLINK_NAME_LEN];

} clx_netif_netlink_mc_grp_t;

typedef struct clx_netif_netlink_s {
    uint32 id;
    char name[CLX_NETLINK_NAME_LEN];
    clx_netif_netlink_mc_grp_t mc_grp[CLX_NETIF_NETLINK_MC_GRP_NUM_MAX];
    uint32 mc_grp_num;

} clx_netif_netlink_t;

typedef struct clx_netif_rx_dst_netlink_s {
    char name[CLX_NETLINK_NAME_LEN];
    char mc_grp_name[CLX_NETLINK_NAME_LEN];
} clx_netif_rx_dst_netlink_t;

typedef enum clx_netif_rx_dst_type_e {
    CLX_NETIF_RX_DST_SDK = 0,
    CLX_NETIF_RX_DST_NETLINK,
    CLX_NETIF_RX_DST_FAST_FWD,
    CLX_NETIF_RX_DST_LAST
} clx_netif_rx_dst_type_t;

typedef struct clx_netif_prof_s {
    /* unique key */
    uint32 id;

    char name[CLX_NETIF_NAME_LEN];
    uint32 priority;
    clx_netif_rx_dst_type_t dst_type;

    /* match fields */
    clx_port_t port; /* only support unit port and local port */
    clx_pkt_rx_rsn_bmp_t rsn_bmp;
    uint8 pattern[CLX_NETIF_PROFILE_PATTERN_NUM][CLX_NETIF_PROFILE_PATTERN_LEN];
    uint32 offset[CLX_NETIF_PROFILE_PATTERN_NUM];
    uint8 mask[CLX_NETIF_PROFILE_PATTERN_NUM][CLX_NETIF_PROFILE_PATTERN_LEN];

    uint32 flags; /* used by CLX_NETIF_PROF_FLAGS_* */

    /* when prof hist, destination of netlink */
    clx_netif_rx_dst_netlink_t netlink;

} clx_netif_prof_t;
#define CLX_NETIF_PROF_FLAGS_PORT      (1UL << 0)
#define CLX_NETIF_PROF_FLAGS_REASON    (1UL << 1)
#define CLX_NETIF_PROF_FLAGS_PATTERN_0 (1UL << 2)
#define CLX_NETIF_PROF_FLAGS_PATTERN_1 (1UL << 3)
#define CLX_NETIF_PROF_FLAGS_PATTERN_2 (1UL << 4)
#define CLX_NETIF_PROF_FLAGS_PATTERN_3 (1UL << 5)

typedef struct clx_netif_ifa_cfg_s {
    uint32 ip_prot; /* ifa protocol type in ipv4/v6 header */
    uint32 node_id; /* node_id in metadata */
} clx_netif_ifa_cfg_t;

/* ----------------------------------------------------------------------------------- APIs */
/**
 * @brief To create Netlink.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_netlink       - Pointer of the Netlink.
 * @param [out]    ptr_netlink_id    - Pointer of the Netlink ID.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_netif_netlink_create(const uint32 unit,
                         const clx_netif_netlink_t *ptr_netlink,
                         uint32 *ptr_netlink_id);

/**
 * @brief To destroy Netlink.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    netlink_id    - The Netlink ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_netif_netlink_destroy(const uint32 unit, const uint32 netlink_id);

/**
 * @brief To get the Netlink.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     netlink_id     - The Netlink ID.
 * @param [out]    ptr_netlink    - Pointer of the Netlink.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_netif_netlink_get(const uint32 unit, const uint32 netlink_id, clx_netif_netlink_t *ptr_netlink);

/**
 * @brief To create the Network Interface for Linux TCP/IP stack.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_net_intf    - Pointer of the Network Interface.
 * @param [out]    ptr_intf_id     - Pointer of the Network Interface ID.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_intf_create(const uint32 unit, const clx_netif_intf_t *ptr_net_intf, uint32 *ptr_intf_id);

/**
 * @brief To destroy the Network Interface for Linux TCP/IP stack.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    intf_id    - The Network Interface ID.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_intf_destroy(const uint32 unit, const uint32 intf_id);

/**
 * @brief To get the Network Interface for Linux TCP/IP stack.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     intf_id         - The Network Interface ID.
 * @param [out]    ptr_net_intf    - Pointer of the Network Interface.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_intf_get(const uint32 unit, const uint32 intf_id, clx_netif_intf_t *ptr_net_intf);

/**
 * @brief To set the Network Interface for Linux TCP/IP stack.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    intf_id         - The Network Interface ID.
 * @param [in]    ptr_net_intf    - Pointer of the Network Interface.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_intf_set(const uint32 unit, const uint32 intf_id, const clx_netif_intf_t *ptr_net_intf);

/**
 * @brief To get the Network Profile counter for Linux TCP/IP stack.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     intf_id          - The Network Interface ID.
 * @param [out]    ptr_netif_cnt    - Pointer of the Network Interface counter.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_intf_cnt_get(const uint32 unit,
                       const uint32 intf_id,
                       clx_netif_intf_cnt_t *ptr_netif_cnt);

/**
 * @brief To clear the Network Profile counter for Linux TCP/IP stack.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    intf_id    - The Network Interface ID.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_intf_cnt_clear(const uint32 unit, const uint32 intf_id);

/**
 * @brief To create the Network Profile for Rx packets to User Process.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_net_prof    - Pointer of the Network Profile.
 * @param [out]    ptr_prof_id     - Pointer of the Network Profile ID.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_prof_create(const uint32 unit, const clx_netif_prof_t *ptr_net_prof, uint32 *ptr_prof_id);

/**
 * @brief To destroy the Network Profile for Rx packets to User Process.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    prof_id    - The Network Profile ID.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_prof_destroy(const uint32 unit, const uint32 prof_id);

/**
 * @brief To get the Network Profile for Rx packets to User Process.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     prof_id         - The Network Profile ID.
 * @param [out]    ptr_net_prof    - Pointer of the Network Interface prof.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_netif_prof_get(const uint32 unit, const uint32 prof_id, clx_netif_prof_t *ptr_net_prof);

/**
 * @brief To get the cpu reason counter based on port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     intf_id              - The Network Interface ID.
 * @param [in]     cpu_reason           - The CPU reason.
 * @param [out]    ptr_rx_reason_cnt    - Pointer of the counter based on CPU reason.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_netif_cpu_reason_cnt_get(const uint32 unit,
                             const uint32 intf_id,
                             const clx_pkt_rx_reason_t cpu_reason,
                             clx_netif_rx_reason_cnt_t *ptr_rx_reason_cnt);

/**
 * @brief To clear the cpu reason counter based on port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    intf_id       - The Network Interface ID.
 * @param [in]    cpu_reason    - The CPU reason.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_netif_cpu_reason_cnt_clear(const uint32 unit,
                               const uint32 intf_id,
                               const clx_pkt_rx_reason_t cpu_reason);

/**
 * @brief To get the ifa-cfg from the device.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_ifa_cfg    - Pointer to store the retrieved ifa-cfg.
 * @return         CLX_E_OK        - Successfully get the ifa-cfg.
 * @return         CLX_E_OTHERS    - Failed to get the ifa-cfg.
 */
clx_error_no_t
clx_netif_ifa_cfg_get(const uint32 unit, clx_netif_ifa_cfg_t *ptr_ifa_cfg);

/**
 * @brief To set the ifa-cfg for the device.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_ifa_cfg    - The ifa-cfg to be set.
 * @return        CLX_E_OK        - Successfully set the ifa-cfg.
 * @return        CLX_E_OTHERS    - Failed to set the ifa-cfg.
 */
clx_error_no_t
clx_netif_ifa_cfg_set(const uint32 unit, const clx_netif_ifa_cfg_t *ptr_ifa_cfg);

#endif /* end of CLX_NETIF_H */
