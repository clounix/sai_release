/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_tm_rep.h
 * PURPOSE:
 * NOTES:
 *
 */

#ifndef HAL_MT_TM_REP_H
#define HAL_MT_TM_REP_H

#include <hal/hal.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
/* Murmur Hash */
#define HAL_MT_TM_REP_IR_POLY                             (0x8bb7)
#define HAL_MT_TM_REP_GF16_FAC                            (0x569a)
#define HAL_MT_TM_REP_GF16_SEED                           (0)
#define HAL_MT_TM_REP_GF16_MASK                           (0xFFFF)
#define HAL_MT_TM_REP_EMDB_MAX                            (8)
#define HAL_MT_TM_REP_MCDB_KEY_SIZE                       (27)
#define HAL_MT_TM_REP_GET_HASH_KEY(__mg_id__, __sn_num__) (((__mg_id__) << 12) | (__sn_num__))

#define HAL_MT_TM_REP_EMDB_INSERT      (0)
#define HAL_MT_TM_REP_EMDB_SEARCH      (1)
#define HAL_MT_TM_REP_EMDB_SEARCH_FREE (2)
#define HAL_MT_TM_REP_EMDB_WRITE       (3)
#define HAL_MT_TM_REP_EMDB_READ        (4)
#define HAL_MT_TM_REP_EMDB_DELETE      (5)

#define HAL_MT_TM_REP_EMDB_WAIT_TIMES (1000)

uint32
gf16_mul_calc(uint32 a, uint32 b);

uint32
murmur_hash(uint32 key);

uint32
gf16_mul(uint32 *ptr_lst, uint32 fac, uint32 seed_16_bits, uint32 key_byte_size);

/**
 * @brief To insert emdb and return emdb idx.
 *
 * @param [in]     unit            - Chip unit id.
 * @param [in]     mg_id           - Mcast grp id.
 * @param [in]     sn_num          - Mcast member sn id.
 * @param [in]     mcdb_ptr        - Mcdb hw id.
 * @param [out]    ptr_emdb_idx    - Return emdb idx.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return         CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_insert_emdb(const uint32 unit,
                          const uint32 mg_id,
                          const uint32 sn_num,
                          const uint32 mcdb_ptr,
                          uint32 *ptr_emdb_idx);

/**
 * @brief To insert emdb and return emdb idx.
 *
 * @param [in]     unit            - Chip unit id.
 * @param [in]     mg_id           - Mcast grp id.
 * @param [in]     sn_num          - Mcast member sn id.
 * @param [out]    ptr_mcdb_ptr    - Return mcdb idx.
 * @param [out]    ptr_emdb_id     - Return emdb id.
 * @param [out]    ptr_emdb_idx    - Return emdb idx.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return         CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_search_emdb(const uint32 unit,
                          const uint32 mg_id,
                          const uint32 sn_num,
                          uint32 *ptr_mcdb_ptr,
                          uint32 *ptr_emdb_id,
                          uint32 *ptr_emdb_idx);

/**
 * @brief To delete emdb idx.
 *
 * @param [in]    unit        - Chip unit id.
 * @param [in]    mg_id       - Mcast grp id.
 * @param [in]    sn_num      - Mcast member sn id.
 * @param [in]    cp_index    - Mcast member need swap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return        CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_delete_emdb(const uint32 unit,
                          const uint32 mg_id,
                          const uint32 sn_num,
                          const uint32 cp_index);

/**
 * @brief Get emdb id from sn.
 *
 * @param [in]     unit           - Chip unit id.
 * @param [in]     mg_id          - Mcast grp id.
 * @param [in]     sn_num         - Mcast member sn id.
 * @param [out]    ptr_emdb_id    - Emdb id.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
hal_mt_tm_rep_get_emdb(const uint32 unit,
                       const uint32 mg_id,
                       const uint32 sn_num,
                       uint32 *ptr_emdb_id);

/**
 * @brief Alloc mcdb idx.
 *
 * @param [in]     unit            - Chip unit id.
 * @param [in]     emdb_id         - Emdb id.
 * @param [out]    ptr_mcdb_idx    - Return idx.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return         CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_alloc_mcdb(const uint32 unit, const uint32 emdb_id, uint32 *ptr_mcdb_idx);

/**
 * @brief Add mcdb info.
 *
 * @param [in]    unit       - Chip unit id.
 * @param [in]    emdb_id    - Emdb id.
 * @param [in]    mcdb_id    - Mcdb id.
 * @param [in]    is_even    - Even or Odd.
 * @param [in]    is_fl      - Fabric link or non fabric link.
 * @param [in]    di         - Dst idx or fabric link id.
 * @param [in]    cud        - Mel idx.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return        CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_add_mcdb(const uint32 unit,
                       const uint32 emdb_id,
                       const uint32 mcdb_id,
                       const uint32 is_even,
                       const uint32 is_fl,
                       const uint32 di,
                       const uint32 cud);

/**
 * @brief Delete mcdb info.
 *
 * @param [in]    unit       - Chip unit id.
 * @param [in]    emdb_id    - Emdb id.
 * @param [in]    mcdb_id    - Mcdb id.
 * @param [in]    is_even    - Even or Odd.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return        CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_delete_mcdb(const uint32 unit,
                          const uint32 emdb_id,
                          const uint32 mcdb_id,
                          const uint32 is_even);

/**
 * @brief Get mcdb info.
 *
 * @param [in]     unit         - Chip unit id.
 * @param [in]     emdb_id      - Emdb id.
 * @param [in]     mcdb_id      - Mcdb id.
 * @param [in]     is_even      - Even or Odd.
 * @param [out]    ptr_is_fl    - Fabric link or non fabric link.
 * @param [out]    ptr_di       - Dst idx.
 * @param [out]    ptr_cud      - Cud idx.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return         CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_get_mcdb(const uint32 unit,
                       const uint32 emdb_id,
                       const uint32 mcdb_id,
                       const uint32 is_even,
                       uint32 *ptr_is_fl,
                       uint32 *ptr_di,
                       uint32 *ptr_cud);

/**
 * @brief Free mcdb idx.
 *
 * @param [in]    unit       - Chip unit id.
 * @param [in]    emdb_id    - Emdb id.
 * @param [in]    mcdb_id    - Mcdb id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return        CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_free_mcdb(const uint32 unit, const uint32 emdb_id, const uint32 mcdb_id);

/**
 * @brief Free mcdb idx.
 *
 * @param [in]    unit             - Chip unit id.
 * @param [in]    mg_id            - Mcast grp id.
 * @param [in]    mg_size          - Mcast grp size.
 * @param [in]    leave_sn         - Leave member sn.
 * @param [in]    swap_sn          - Swap member sn.
 * @param [in]    leave_mcdb_id    - Leave member mcdb idx.
 * @param [in]    swap_mcdb_id     - Swap member mcdb idx.
 * @param [in]    swap_emdb_idx    - Swap member emdb hw idx.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return        CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_delete_mg_member(const uint32 unit,
                               const uint32 mg_id,
                               const uint32 mg_size,
                               const uint32 leave_sn,
                               const uint32 swap_sn,
                               const uint32 leave_mcdb_id,
                               const uint32 swap_mcdb_id,
                               const uint32 swap_emdb_idx);

/**
 * @brief Delete all mc member in mc group.
 *
 * @param [in]    unit       - Chip unit id.
 * @param [in]    mg_id      - Mcast grp id.
 * @param [in]    mg_size    - Mcast grp size.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return        CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_delete_all_mg_member(const uint32 unit, const uint32 mg_id, const uint32 mg_size);

/**
 * @brief Update mcdb idx.
 *
 * @param [in]    unit        - Chip unit id.
 * @param [in]    mg_id       - Mcast grp id.
 * @param [in]    mg_size     - Mcast grp size.
 * @param [in]    sn          - Member sn.
 * @param [in]    mcdb_idx    - Member mcdb idx.
 * @param [in]    cud         - Member cud idx.
 * @param [in]    di          - Member dst idx.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return        CLX_E_OTHERS           - HW operation error.
 */
clx_error_no_t
hal_mt_tm_rep_update_mg_member(const uint32 unit,
                               const uint32 mg_id,
                               const uint32 mg_size,
                               const uint32 sn,
                               const uint32 mcdb_idx,
                               const uint32 cud,
                               const uint32 di);

#endif /* End of HAL_MT_TELM_H */
