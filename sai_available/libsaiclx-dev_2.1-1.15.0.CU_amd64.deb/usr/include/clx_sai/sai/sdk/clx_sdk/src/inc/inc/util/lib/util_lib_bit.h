/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_bit.h
 * PURPOSE:
 *  this file is used to provide bitwise operations to other users.
 * NOTES:
 *  it contains operations as below:
 *      1. and
 *      2. or
 *      3. xor
 *      4. compare
 *      5. invert
 *      6. rotate
 *      7. reverse
 *      8. get index of set-bit
 *      9. check bit
 *      10. set
 *      11. clear
 *
 *
 *
 */
#ifndef UTIL_LIB_BIT_H
#define UTIL_LIB_BIT_H
/* INCLUDE FILE DECLARATIONS
 */

#include <util/lib/util_lib.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* MACRO FUNCTION DECLARATIONS
 */

/**
 * @brief This macro is used to do bit operation for bit-8/16/32 operands.
 *
 * @param [in]    data     - The operand.
 * @param [in]    op       - Operation.
 * @param [in]    bit_n    - The operation bit no, 0~data bit width.
 * @return        The operation result.
 */
#define UTIL_LIB_BIT_OP(data, op, bit_n) ((data)op(1U << (bit_n)))

/**
 * @brief This macro is used to do bit operation for bit-64 operands.
 *
 * @param [in]    data     - The operand.
 * @param [in]    op       - Operation.
 * @param [in]    bit_n    - The operation bit no, 0~63.
 * @return        The operation result.
 */
#define UTIL_LIB_BIT_U64_OP(data, op, bit_n) ((data)op(1ULL << (bit_n)))

/**
 * @brief "and" two data of 8/16/32-bit and save the result in dest of 8/16/32-bit.
 *
 * @param [in]     data1    - The first operand of 8/16/32-bit.
 * @param [in]     data2    - The second operand of 8/16/32-bit.
 * @param [out]    dest     - The result will be saved in this data of 8/16/32-bit.
 */
#define UTIL_LIB_BIT_AND(data1, data2, dest) ((dest) = (data1) & (data2))

/**
 * @brief "or" two data of 8/16/32-bit and save the result in dest of 8/16/32-bit.
 *
 * @param [in]     data1    - The first operand of 8/16/32-bit.
 * @param [in]     data2    - The second operand of 8/16/32-bit.
 * @param [out]    dest     - The result will be saved in this data of 8/16/32-bit.
 */
#define UTIL_LIB_BIT_OR(data1, data2, dest) ((dest) = (data1) | (data2))

/**
 * @brief "xor" two data of 8/16/32-bit and save the result in dest of 8/16/32-bit.
 *
 * @param [in]     data1    - The first operand of 8/16/32-bit.
 * @param [in]     data2    - The second operand of 8/16/32-bit.
 * @param [out]    dest     - The result will be saved in this data of 8/16/32-bit.
 */
#define UTIL_LIB_BIT_XOR(data1, data2, dest) ((dest) = (data1) ^ (data2))

/**
 * @brief Compare two data of 8/16/32-bit if they are the same and save the result in dest of
 *        32-bit.
 *
 * @param [in]     data1    - The first operand of 8/16/32-bit.
 * @param [in]     data2    - The second operand of 8/16/32-bit.
 * @param [out]    dest     - The result will be saved in this data of 32-bit 0 : two operands are
 *                            the same 1 : two operands are not the same.
 */
#define UTIL_LIB_BIT_CMP(data1, data2, dest) ((dest) = ((data1) - (data2)) ? 1 : 0)

/**
 * @brief Compare two data of 64-bit if they are the same and save the result in dest of 32-bit.
 *
 * @param [in]     data1    - The first operand of 64-bit.
 * @param [in]     data2    - The second operand of 64-bit.
 * @param [out]    dest     - The result will be saved in this data of 32-bit 0 : two operands are
 *                            the same 1 : two operands are not the same.
 */
#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UTIL_LIB_BIT_U64_CMP(data1, data2, dest) ((dest) = ((data1) - (data2)) ? 1 : 0)
#else
#define UTIL_LIB_BIT_U64_CMP(data1, data2, dest)                   \
    do {                                                           \
        (dest) = (data1).ui64[UI64_LSW] - (data2).ui64[UI64_LSW];  \
        (dest) |= (data1).ui64[UI64_MSW] - (data2).ui64[UI64_MSW]; \
        (dest) = (dest) ? 1 : 0;                                   \
    } while (0)
#endif

/* shift */

/**
 * @brief It is used to shift left data with digit and save the result in dest.
 *
 * The operand should be unsigned 8-bit.
 *
 * @param [in]     data     - The data of 8-bit.
 * @param [in]     digit    - Shift digit, it is 0~7.
 * @param [out]    dest     - The shift result.
 */
#define UTIL_LIB_BIT_U8_SHF_L(data, digit, dest) (dest) = (data) << ((digit) & 7)

/**
 * @brief It is used to shift left data with digit and save the result in dest.
 *
 * The operand should be unsigned 16-bit.
 *
 * @param [in]     data     - The data of 16-bit.
 * @param [in]     digit    - Shift digit, it is 0~15.
 * @param [out]    dest     - The shift result.
 */
#define UTIL_LIB_BIT_U16_SHF_L(data, digit, dest) (dest) = (data) << ((digit) & 15)

/**
 * @brief It is used to shift left data with digit and save the result in dest.
 *
 * The operand should be unsigned 32-bit.
 *
 * @param [in]     data     - The data of 32-bit.
 * @param [in]     digit    - Shift digit, it is 0~31.
 * @param [out]    dest     - The shift result.
 */
#define UTIL_LIB_BIT_U32_SHF_L(data, digit, dest) (dest) = (data) << ((digit) & 31)

/**
 * @brief It is used to shift left data with digit and save the result in dest.
 *
 * The operand should be unsigned 64-bit.
 *
 * @param [in]     data     - The data of 64-bit.
 * @param [in]     digit    - Shift digit, it is 0~63.
 * @param [out]    dest     - The shift result.
 */
#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UTIL_LIB_BIT_U64_SHF_L(data, digit, dest) (dest) = (data) << ((digit) & 63)
#else
#define UTIL_LIB_BIT_U64_SHF_L(data, digit, dest)                       \
    do {                                                                \
        uint32 _digit = (digit) & 63;                                   \
        if (_digit > 32) {                                              \
            _digit &= 31;                                               \
            (dest).ui64[UI64_MSW] = ((data).ui64[UI64_LSW] << _digit);  \
            (dest).ui64[UI64_LSW] = 0;                                  \
        } else if (_digit == 32) {                                      \
            (dest).ui64[UI64_MSW] = (data).ui64[UI64_LSW];              \
            (dest).ui64[UI64_LSW] = 0;                                  \
        } else if (0 != _digit) {                                       \
            (dest).ui64[UI64_MSW] = ((data).ui64[UI64_MSW] << _digit) | \
                ((data).ui64[UI64_LSW] >> (32 - _digit));               \
            (dest).ui64[UI64_LSW] = ((data).ui64[UI64_LSW] << _digit);  \
        } else {                                                        \
            (dest).ui64[UI64_LSW] = (data).ui64[UI64_LSW];              \
            (dest).ui64[UI64_MSW] = (data).ui64[UI64_MSW];              \
        }                                                               \
    } while (0)
#endif

/**
 * @brief It is used to shift right data with digit and save the result in dest.
 *
 * The operand should be unsigned 8-bit.
 *
 * @param [in]     data     - The data of 8-bit.
 * @param [in]     digit    - Shift digit, it is 0~7.
 * @param [out]    dest     - The shift result.
 */
#define UTIL_LIB_BIT_U8_SHF_R(data, digit, dest) (dest) = (data) >> ((digit) & 7)

/**
 * @brief It is used to shift right data with digit and save the result in dest.
 *
 * The operand should be unsigned 16-bit.
 *
 * @param [in]     data     - The data of 16-bit.
 * @param [in]     digit    - Shift digit, it is 0~15.
 * @param [out]    dest     - The shift result.
 */
#define UTIL_LIB_BIT_U16_SHF_R(data, digit, dest) (dest) = (data) >> ((digit) & 15)

/**
 * @brief It is used to shift right data with digit and save the result in dest.
 *
 * The operand should be unsigned 32-bit.
 *
 * @param [in]     data     - The data of 32-bit.
 * @param [in]     digit    - Shift digit, it is 0~31.
 * @param [out]    dest     - The shift result.
 */
#define UTIL_LIB_BIT_U32_SHF_R(data, digit, dest) (dest) = (data) >> ((digit) & 31)

/**
 * @brief It is used to shift right data with digit and save the result in dest.
 *
 * The operand should be unsigned 64-bit.
 *
 * @param [in]     data     - The data of 64-bit.
 * @param [in]     digit    - Shift digit, it is 0~63.
 * @param [out]    dest     - The shift result.
 */
#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UTIL_LIB_BIT_U64_SHF_R(data, digit, dest) (dest) = (data) >> ((digit) & 63)
#else
#define UTIL_LIB_BIT_U64_SHF_R(data, digit, dest)                       \
    do {                                                                \
        uint32 _digit = (digit) & 63;                                   \
        if (_digit > 32) {                                              \
            _digit &= 31;                                               \
            (dest).ui64[UI64_LSW] = ((data).ui64[UI64_MSW] >> _digit);  \
            (dest).ui64[UI64_MSW] = 0;                                  \
        } else if (_digit == 32) {                                      \
            (dest).ui64[UI64_LSW] = (data).ui64[UI64_MSW];              \
            (dest).ui64[UI64_MSW] = 0;                                  \
        } else if (0 != _digit) {                                       \
            (dest).ui64[UI64_LSW] = ((data).ui64[UI64_LSW] >> _digit) | \
                ((data).ui64[UI64_MSW] << (32 - _digit));               \
            (dest).ui64[UI64_MSW] = ((data).ui64[UI64_MSW] >> _digit);  \
        } else {                                                        \
            (dest).ui64[UI64_LSW] = (data).ui64[UI64_LSW];              \
            (dest).ui64[UI64_MSW] = (data).ui64[UI64_MSW];              \
        }                                                               \
    } while (0)
#endif

/* rotate */

#define UTIL_LIB_BIT_N_ROT_L(data, digit, bit_width, dest) \
    ((dest) = (((data) << ((digit) & ((bit_width) - 1))) | \
               ((data) >> (((bit_width) - ((digit) & ((bit_width) - 1))) & ((bit_width) - 1)))))

#define UTIL_LIB_BIT_N_ROT_R(data, digit, bit_width, dest) \
    ((dest) = (((data) >> ((digit) & ((bit_width) - 1))) | \
               ((data) << (((bit_width) - ((digit) & ((bit_width) - 1))) & ((bit_width) - 1)))))

/**
 * @brief Rotate left a data of 8-bit.
 *
 * The operand should be unsigned 8-bit.
 *
 * @param [in]     data     - The data of 8-bit.
 * @param [in]     digit    - Rotate digit, it is 0~7.
 * @param [out]    dest     - The rotate result.
 * @return         The rotated data of 8.
 */
#define UTIL_LIB_BIT_U8_ROT_L(data, digit, dest) UTIL_LIB_BIT_N_ROT_L(data, digit, 8, dest)

/**
 * @brief Rotate left a data of 16-bit.
 *
 * The operand should be unsigned 16-bit.
 *
 * @param [in]     data     - The data of 16-bit.
 * @param [in]     digit    - Rotate digit, it is 0~15.
 * @param [out]    dest     - The rotate result.
 * @return         The rotated data of 16.
 */
#define UTIL_LIB_BIT_U16_ROT_L(data, digit, dest) UTIL_LIB_BIT_N_ROT_L(data, digit, 16, dest)

/**
 * @brief Rotate left a data of 32-bit.
 *
 * The operand should be unsigned 32-bit.
 *
 * @param [in]     data     - The data of 32-bit.
 * @param [in]     digit    - Rotate digit, it is 0~31.
 * @param [out]    dest     - The rotate result.
 * @return         The rotated data of 32.
 */
#define UTIL_LIB_BIT_U32_ROT_L(data, digit, dest) UTIL_LIB_BIT_N_ROT_L(data, digit, 32, dest)

/**
 * @brief Rotate right a data of 8-bit.
 *
 * @param [in]     data     - The data of 8-bit.
 * @param [in]     digit    - Rotate digit, it is 0~7.
 * @param [out]    dest     - The rotate result.
 * @return         The rotated data of 8.
 */
#define UTIL_LIB_BIT_U8_ROT_R(data, digit, dest) UTIL_LIB_BIT_N_ROT_R(data, digit, 8, dest)

/**
 * @brief Rotate right a data of 16-bit.
 *
 * @param [in]     data     - The data of 16-bit.
 * @param [in]     digit    - Rotate digit, it is 0~15.
 * @param [out]    dest     - The rotate result.
 * @return         The rotated data of 16.
 */
#define UTIL_LIB_BIT_U16_ROT_R(data, digit, dest) UTIL_LIB_BIT_N_ROT_R(data, digit, 16, dest)

/**
 * @brief Rotate right a data of 32-bit.
 *
 * @param [in]     data     - The data of 32-bit.
 * @param [in]     digit    - Rotate digit, it is 0~31.
 * @param [out]    dest     - The rotate result.
 * @return         The rotated data of 32.
 */
#define UTIL_LIB_BIT_U32_ROT_R(data, digit, dest) UTIL_LIB_BIT_N_ROT_R(data, digit, 32, dest)

/**
 * @brief Invert a data of 8/16/32-bit and save the result in dest of 8/16/32-bit.
 *
 * @param [in]     data    - The data of 8/16/32-bit.
 * @param [out]    dest    - The result will be saved in the dest data of 8/16/32-bit.
 */
#define UTIL_LIB_BIT_INVERT(data, dest) ((dest) = ~(data))

/**
 * @brief Check the (bit_n)th bit if is set.
 *
 * @param [in]    data     - 8/16/32-bit data.
 * @param [in]    bit_n    - The (bit_n)th bit will be check, 0~7/15/31.
 * @return        0    - The (bit_n)th bit is 0.
 * @return        1    - The (bit_n)th bit is 1.
 */
#define UTIL_LIB_BIT_CHK(data, bit_n) (UTIL_LIB_BIT_OP(data, &, bit_n) ? 1 : 0)

/**
 * @brief Set the (bit_n)th bit to 1.
 *
 * @param [in]    data     - 8/16/32-bit data.
 * @param [in]    bit_n    - The (bit_n)th bit will be set, 0~7/15/31.
 */
#define UTIL_LIB_BIT_SET(data, bit_n) UTIL_LIB_BIT_OP(data, |=, bit_n)

/**
 * @brief Set the (bit_n)th bit to 0.
 *
 * @param [in]    data     - 8/16/32-bit data.
 * @param [in]    bit_n    - The (bit_n)th bit will be set, 0~7/15/31.
 */
#define UTIL_LIB_BIT_CLR(data, bit_n) UTIL_LIB_BIT_OP(data, &= ~, bit_n)

/**
 * @brief Check the (bit_n)th bit if is set.
 *
 * @param [in]    data     - 64-bit data.
 * @param [in]    bit_n    - The (bit_n)th bit will be check, 0~63.
 */
#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UTIL_LIB_BIT_U64_CHK(data, bit_n) (UTIL_LIB_BIT_U64_OP(data, &, bit_n) ? 1 : 0)
#else
#define UTIL_LIB_BIT_U64_CHK(data, bit_n)                                                         \
    (UTIL_LIB_BIT_OP((data).ui64[(((bit_n) / 32) == 0) ? UI64_LSW : UI64_MSW], &, (bit_n) % 32) ? \
         1 :                                                                                      \
         0)
#endif

/**
 * @brief Set the (bit_n)th bit to 1.
 *
 * @param [in]    data     - 64-bit data.
 * @param [in]    bit_n    - The (bit_n)th bit will be set, 0~63.
 */
#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UTIL_LIB_BIT_U64_SET(data, bit_n) UTIL_LIB_BIT_U64_OP(data, |=, bit_n)
#else
#define UTIL_LIB_BIT_U64_SET(data, bit_n) \
    UTIL_LIB_BIT_OP((data).ui64[(((bit_n) / 32) == 0) ? UI64_LSW : UI64_MSW], |=, (bit_n) % 32)
#endif

/**
 * @brief Set the (bit_n)th bit to 0.
 *
 * @param [in]    data     - 64-bit data.
 * @param [in]    bit_n    - The (bit_n)th bit will be set, 0~63.
 */
#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UTIL_LIB_BIT_U64_CLR(data, bit_n) UTIL_LIB_BIT_U64_OP(data, &= ~, bit_n)
#else
#define UTIL_LIB_BIT_U64_CLR(data, bit_n) \
    UTIL_LIB_BIT_OP((data).ui64[(((bit_n) / 32) == 0) ? UI64_LSW : UI64_MSW], &= ~, (bit_n) % 32)
#endif

/**
 * @brief Get each set-bit index of 8/16/32-bitdata. the result will be return in ptr_index.
 *
 * This macro will not check ptr_index if it null pointer.
 * please make sure ptr_index is not null pointer.
 * The ptr_index should be a int32 pointer, please notice.
 * eg:
 * uint32 data = 0x7;
 * int32 i = 0;
 * UTIL_LIB_BIT_FOREACH_SETBIT(data, &i)
 * {
 * osal_printf("i=%d\n", i);
 * }
 * output:
 * i=0
 * i=1
 * i=2.
 *
 * @param [in]     data         - 8/16/32-bit data to get set-bit index.
 * @param [out]    ptr_index    - Int32 pointer, the index of set-bit. 0~31.
 */
#define UTIL_LIB_BIT_FOREACH_SETBIT(data, ptr_index) \
    *(ptr_index) = -1;                               \
    while (CLX_E_OK == util_lib_bit_u32_first_bit_get((uint32)(data), (ptr_index)))

/**
 * @brief Get each set-bit index of 64-bit data. the result will be return in ptr_index.
 *
 * This macro will not check ptr_index if it null pointer.
 * please make sure ptr_index is not null pointer.
 * The ptr_index should be a int32 pointer, please notice.
 * eg:
 * uint64 data = 0x7;
 * int32 i = 0;
 * UTIL_LIB_BIT_U64_FOREACH_SETBIT(data, &i)
 * {
 * osal_printf("i=%d\n", i);
 * }
 * output:
 * i=0
 * i=1
 * i=2.
 *
 * @param [in]     data         - 64-bit data to get set-bit index.
 * @param [out]    ptr_index    - Int32 pointer, the index of set-bit. 0~63.
 */
#define UTIL_LIB_BIT_U64_FOREACH_SETBIT(data, ptr_index) \
    *(ptr_index) = -1;                                   \
    while (CLX_E_OK == util_lib_bit_u64_first_bit_get((uint64)(data), (ptr_index)))

/**
 * @brief Get each set-bit index of 8-bit data array. the result will be return in ptr_index.
 *
 * This macro will not check ptr_index if it null pointer.
 * please make sure ptr_index is not null pointer.
 * The ptr_index should be a int32 pointer, please notice.
 * eg:
 * uint8 data[2] = {0x7, 0x7};
 * int32 i = 0;
 * UTIL_LIB_BIT_U8_ARRAY_FOREACH_SETBIT(data, 2, &i)
 * {
 * osal_printf("i=%d\n", i);
 * }
 * output:
 * i=0
 * i=1
 * i=2
 * i=8
 * i=9
 * i=10.
 *
 * @param [in]     ptr_data     - 8-bit data array start address.
 * @param [in]     size         - Array size.
 * @param [out]    ptr_index    - Int32 pointer, the index of set-bit.
 */
#define UTIL_LIB_BIT_U8_ARRAY_FOREACH_SETBIT(ptr_data, size, ptr_index) \
    *(ptr_index) = -1;                                                  \
    while (CLX_E_OK == util_lib_bit_u8_array_first_bit_get((ptr_data), (size), (ptr_index)))

/**
 * @brief Get the first byte from UI32 data.
 *
 * @param [in]    ui32_data    - Ui32 data.
 * @return        The first LSB byte.
 */
#define UTIL_LIB_BIT_U32_BYTE0(ui32_data) ((ui32_data) & 0x000000FF)

/**
 * @brief Get the second byte from UI32 data.
 *
 * @param [in]    ui32_data    - Ui32 data.
 * @return        The second LSB byte.
 */
#define UTIL_LIB_BIT_U32_BYTE1(ui32_data) (((ui32_data) >> 8) & 0x000000FF)

/**
 * @brief Get the third byte from UI32 data.
 *
 * @param [in]    ui32_data    - Ui32 data.
 * @return        The third LSB byte.
 */
#define UTIL_LIB_BIT_U32_BYTE2(ui32_data) (((ui32_data) >> 16) & 0x000000FF)

/**
 * @brief Get the fourth byte from UI32 data.
 *
 * @param [in]    ui32_data    - Ui32 data.
 * @return        The fourth LSB byte.
 */
#define UTIL_LIB_BIT_U32_BYTE3(ui32_data) (((ui32_data) >> 24) & 0x000000FF)

/**
 * @brief Get the lower two bytes from UI32 data.
 *
 * @param [in]    ui32_data    - Ui32 data.
 * @return        The two LSB bytes.
 */
#define UTIL_LIB_BIT_U32_LOW(ui32_data) ((ui32_data) & 0x0000FFFF)

/**
 * @brief Get the higher two bytes from UI32 data.
 *
 * @param [in]    ui32_data    - Ui32 data.
 * @return        The two MSB bytes.
 */
#define UTIL_LIB_BIT_U32_HIGH(ui32_data) (((ui32_data) >> 16) & 0x0000FFFF)

/**
 * @brief Get the lower byte from UI16 data.
 *
 * @param [in]    ui16_data    - Ui16 data.
 * @return        The LSB byte.
 */
#define UTIL_LIB_BIT_UI16_LOW(ui16_data) ((ui16_data) & 0x00FF)

/**
 * @brief Get the higher byte from UI16 data.
 *
 * @param [in]    ui16_data    - Ui16 data.
 * @return        The MSB byte.
 */
#define UTIL_LIB_BIT_UI16_HIGH(ui16_data) (((ui16_data) >> 8) & 0x00FF)

/* DATA TYPE DECLARATIONS
 */
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Get the first set-bit index of an 32-bit data starting from (.
 *
 * @param [in]     data         - The data of 8/16/32-bit.
 * @param [in]     ptr_index    - The previous bit postion of start check bit.
 *                                -1~30.
 * @param [out]    ptr_index    - The index of first set-bit. 0~31.
 * @return         CLX_E_OK                 - Check success.
 * @return         CLX_E_BAD_PARAMETER      - The parameter is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - There is not set-bit from start_bit to MSB.
 */
clx_error_no_t
util_lib_bit_u32_first_bit_get(uint32 data, int32 *ptr_index);

/**
 * @brief Get the first set-bit index of 64-bit data starting from (*ptr_index + 1) bit(include) to
 *        MSB.
 *
 * @param [in]     data         - The data of 64-bit.
 * @param [out]    ptr_index    - The index of first set-bit. 0~63.
 * @return         CLX_E_OK                 - Check success.
 * @return         CLX_E_BAD_PARAMETER      - The parameter is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Not set-bit from (*ptr_index + 1) bit to MSB.
 */
clx_error_no_t
util_lib_bit_u64_first_bit_get(uint64 data, int32 *ptr_index);

/**
 * @brief "and" two 8-bit arrays and save the result in dest array.
 *
 * @param [in]     ptr_data1    - The first array of 8-bit.
 * @param [in]     ptr_data2    - The second array of 8-bit.
 * @param [in]     length       - Array length.
 * @param [out]    ptr_dest     - The dest array which is used to save the "and" result.
 * @return         CLX_E_OK               - Check success.
 * @return         CLX_E_BAD_PARAMETER    - The parameter is invalid.
 */
clx_error_no_t
util_lib_bit_u8_array_and(uint8 *ptr_data1, uint8 *ptr_data2, uint32 length, uint8 *ptr_dest);

/**
 * @brief "or" two 8-bit arrays and save the result in dest array.
 *
 * @param [in]     ptr_data1    - The first array of 8-bit.
 * @param [in]     ptr_data2    - The second array of 8-bit.
 * @param [in]     length       - Array length.
 * @param [out]    ptr_dest     - The dest array which is used to save the "or" result.
 * @return         CLX_E_OK               - Check success.
 * @return         CLX_E_BAD_PARAMETER    - The parameter is invalid.
 */
clx_error_no_t
util_lib_bit_u8_array_or(uint8 *ptr_data1, uint8 *ptr_data2, uint32 length, uint8 *ptr_dest);

/**
 * @brief "xor" two 8-bit arrays and save the result in dest array.
 *
 * @param [in]     ptr_data1    - The first array of 8-bit.
 * @param [in]     ptr_data2    - The second array of 8-bit.
 * @param [in]     length       - Array length.
 * @param [out]    ptr_dest     - The dest array which is used to save the "xor" result.
 * @return         CLX_E_OK               - Check success.
 * @return         CLX_E_BAD_PARAMETER    - The parameter is invalid.
 */
clx_error_no_t
util_lib_bit_u8_array_xor(uint8 *ptr_data1, uint8 *ptr_data2, uint32 length, uint8 *ptr_dest);

/**
 * @brief Cmpare two 8-bit arrays if they are the same and save the result in dest.
 *
 * @param [in]     ptr_data1      - The first array of 8-bit.
 * @param [in]     ptr_data2      - The second array of 8-bit.
 * @param [in]     length         - Array length.
 * @param [out]    ptr_cmp_ret    - The compare result 0: two arrays of 8-bit are the same 1: two
 *                                  arrays of 8-bit are not the same.
 * @return         CLX_E_OK               - Check success.
 * @return         CLX_E_BAD_PARAMETER    - The parameter is invalid.
 */
clx_error_no_t
util_lib_bit_u8_array_cmp(uint8 *ptr_data1, uint8 *ptr_data2, uint32 length, int32 *ptr_cmp_ret);

/**
 * @brief Invert an array of 8-bit and save the result in dest array.
 *
 * @param [in]     ptr_data    - The array of 8-bit.
 * @param [in]     length      - Array length.
 * @param [out]    ptr_dest    - The dest array is used to save inverted data.
 * @return         CLX_E_OK               - Check success.
 * @return         CLX_E_BAD_PARAMETER    - The parameter is invalid.
 */
clx_error_no_t
util_lib_bit_u8_array_invert(uint8 *ptr_data, uint32 length, uint8 *ptr_dest);

/**
 * @brief Get the first set-bit index of an array of 8-bit starting from start_bit.
 *
 * @param [in]     ptr_data     - The 8-bit array.
 * @param [in]     length       - Array length.
 * @param [in]     ptr_index    - The previous bit postion of start check bit,
 *                                (0~(length.
 * @param [out]    ptr_index    - The index of first set-bit. >=0: the index.
 * @return         CLX_E_OK                 - Check success.
 * @return         CLX_E_BAD_PARAMETER      - The parameter is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No set-bit from start bit to the last bit.
 */
clx_error_no_t
util_lib_bit_u8_array_first_bit_get(const uint8 *ptr_data, uint32 length, int32 *ptr_index);

/**
 * @brief Check one bit of an array of 8-bit if it is set.
 *
 * @param [in]     ptr_data    - The array of 8-bit.
 * @param [in]     length      - The array length.
 * @param [in]     bit_n       - The checked bit, 0~(length*8-1).
 * @param [out]    ptr_ret     - The check result 0: the bit is not set 1: the bit is set.
 * @return         CLX_E_OK               - Check success.
 * @return         CLX_E_BAD_PARAMETER    - The parameter is invalid.
 */
clx_error_no_t
util_lib_bit_u8_array_bit_chk(uint8 *ptr_data, uint32 length, uint32 bit_n, int32 *ptr_ret);

/**
 * @brief Set a range of bit of an array of 8-bit to 1.
 *
 * @param [in]    ptr_data     - The array of 8-bit.
 * @param [in]    length       - The array length.
 * @param [in]    start_bit    - The start bit of the array to set, 0~(length*8-1).
 * @param [in]    bit_cnt      - The count of bit will be set, start_bit+bit_cnt <= length*8.
 * @return        CLX_E_OK               - Check success.
 * @return        CLX_E_BAD_PARAMETER    - Ptr_data is NULL or length == 0 or start_bit >= length
 *                                         >= length.
 */
clx_error_no_t
util_lib_bit_u8_array_range_set(uint8 *ptr_data, uint32 length, uint32 start_bit, uint32 bit_cnt);

/**
 * @brief Set a range of bit of an array of 8-bit to 0.
 *
 * @param [in]    ptr_data     - The array of 8-bit.
 * @param [in]    length       - The array length.
 * @param [in]    start_bit    - The start bit of the array to clear, 0~(length*8-1).
 * @param [in]    bit_cnt      - The count of bit will be cleared, start_bit+bit_cnt<=ength*8.
 * @return        CLX_E_OK               - Check success.
 * @return        CLX_E_BAD_PARAMETER    - Ptr_data is NULL or length == 0 or start_bit >=length
 *                                         >=length.
 */
clx_error_no_t
util_lib_bit_u8_array_range_clr(uint8 *ptr_data, uint32 length, uint32 start_bit, uint32 bit_cnt);

/**
 * @brief It is used to reverse bit8 operand.
 *
 * @param [in]    bit8_data    - The data will be reverse.
 * @return        0    - 0xFF -- the reverse data.
 */
uint8
util_lib_bit_u8_rev(uint8 bit8_data);

/**
 * @brief It is used to reverse bit16 operand.
 *
 * @param [in]    bit16_data    - The data will be reverse.
 * @return        0    - 0xFFFF -- the reverse data.
 */
uint16
util_lib_bit_u16_rev(uint16 bit16_data);

/**
 * @brief It is used to reverse bit32 operand.
 *
 * @param [in]    bit32_data    - The data will be reverse.
 * @return        0    - 0xFFFFFFFF -- the reverse data.
 */
uint32
util_lib_bit_u32_rev(uint32 bit32_data);

/**
 * @brief It is used to reverse bit64 operand.
 *
 * @param [in]    bit64_data    - The data will be reverse.
 * @return        0    - 0xFFFFFFFFFFFFFFFF -- the reverse data.
 */
uint64
util_lib_bit_u64_rev(uint64 bit64_data);

/**
 * @brief It is used to do 64 bits division by 32 bits.
 *
 * @param [in]     dividend      - Dividend operator.
 * @param [in]     divisor       - Divisor operator.
 * @param [out]    ptr_result    - Save the devision result.
 * @return         0    - 0xFFFFFFFFFFFFFFFF -- the reverse data.
 */
clx_error_no_t
util_lib_bit_u64_div_u32(uint64 dividend, uint32 divisor, uint64 *ptr_result);

/**
 * @brief It is used to do 64 bits division by 64 bits.
 *
 * @param [in]     dividend      - Dividend operator.
 * @param [in]     divisor       - Divisor operator.
 * @param [out]    ptr_result    - Save the devision result.
 * @return         0    - 0xFFFFFFFFFFFFFFFF -- the reverse data.
 */
clx_error_no_t
util_lib_bit_u64_div_u64(uint64 dividend, uint64 divisor, uint64 *ptr_result);

#endif /* End of UTIL_LIB_BIT_H */
