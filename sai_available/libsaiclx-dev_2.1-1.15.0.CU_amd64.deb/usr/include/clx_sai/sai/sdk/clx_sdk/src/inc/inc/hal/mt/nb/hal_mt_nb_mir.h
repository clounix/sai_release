/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_mir.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8600.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_MIR_H
#define HAL_MT_NB_MIR_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_mir.h>
#include <hal/hal_mir.h>

clx_error_no_t
hal_mt_nb_mir_local_span_session_add(const uint32 unit,
                                     const uint32 entry_id,
                                     const clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_rspan_encap_session_add(const uint32 unit,
                                      const uint32 entry_id,
                                      const clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_rspan_decap_session_add(const uint32 unit,
                                      const uint32 entry_id,
                                      const clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_rspan_decap_session_set(const uint32 unit,
                                      const uint32 entry_id,
                                      const clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_erspan_encap_session_add(const uint32 unit,
                                       const uint32 entry_id,
                                       const clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_erspan_encap_session_set(const uint32 unit,
                                       const uint32 entry_id,
                                       const clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_erspan_decap_session_add(const uint32 unit,
                                       const uint32 entry_id,
                                       const clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_local_sapn_session_del(const uint32 unit, const uint32 entry_id);

clx_error_no_t
hal_mt_nb_mir_rspan_encap_session_del(const uint32 unit, const uint32 entry_id);

clx_error_no_t
hal_mt_nb_mir_rspan_decap_session_del(const uint32 unit, const uint32 entry_id);

clx_error_no_t
hal_mt_nb_mir_erspan_encap_session_del(const uint32 unit, const uint32 entry_id);

clx_error_no_t
hal_mt_nb_mir_erspan_decap_session_del(const uint32 unit, const uint32 entry_id);

clx_error_no_t
hal_mt_nb_mir_local_span_session_get(const uint32 unit,
                                     const uint32 entry_id,
                                     clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_rspan_encap_session_get(const uint32 unit,
                                      const uint32 entry_id,
                                      clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_rspan_decap_session_get(const uint32 unit,
                                      const uint32 entry_id,
                                      clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_erspan_encap_session_get(const uint32 unit,
                                       const uint32 entry_id,
                                       clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_erspan_decap_session_get(const uint32 unit,
                                       const uint32 entry_id,
                                       clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_hw_mir_src_port_set(const uint32 unit,
                                  const uint32 port,
                                  const clx_dir_t dir,
                                  const uint32 mir_session_bitmap);

clx_error_no_t
hal_mt_nb_mir_hw_mir_src_port_get(const uint32 unit,
                                  const uint32 port,
                                  const clx_dir_t dir,
                                  uint32 *ptr_mir_session_bitmap);

clx_error_no_t
hal_mt_nb_mir_ersapn_decap_add(const uint32 unit,
                               const clx_mir_erspan_decap_key_t *ptr_decap_key,
                               const uint32 mir_id);

clx_error_no_t
hal_mt_nb_mir_erspan_decap_del(const uint32 unit,
                               const clx_mir_erspan_decap_key_t *ptr_erspan_term_cfg);

clx_error_no_t
hal_mt_nb_mir_ersapn_decap_find(const uint32 unit,
                                const clx_mir_erspan_decap_key_t *ptr_erspan_term_search,
                                hal_mir_erspan_term_t **ptr_erspan_term);

clx_error_no_t
hal_mt_nb_mir_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_mir_destination_set(const uint32 unit, const uint32 entry_id, const clx_port_t port);

clx_error_no_t
hal_mt_nb_mir_parameter_check(const uint32 unit, const clx_mir_session_cfg_t *ptr_session);

clx_error_no_t
hal_mt_nb_mir_hw_erspan_decap_miss_action_set(const uint32 unit, const uint32 miss_action);

clx_error_no_t
hal_mt_nb_mir_hw_erspan_decap_miss_action_get(const uint32 unit, uint32 *ptr_miss_action);

clx_error_no_t
hal_mt_nb_mir_rspan_port_check(const uint32 unit, const uint32 port, uint32 *ptr_is_rspan);

clx_error_no_t
hal_mt_nb_mir_hw_lag_port_event_update(const uint32 unit,
                                       const uint32 event,
                                       const clx_port_t lag_port);

/**
 * @brief To set selective flow config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ptr_select_cfg    - Selective flow config.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_mir_selective_flow_mir_set(const uint32 unit,
                                     const clx_swc_selective_flow_cfg_t *ptr_select_cfg);

/**
 * @brief To get selective flow config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_select_cfg    - Selective flow config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_mir_selective_flow_mir_get(const uint32 unit,
                                     clx_swc_selective_flow_cfg_t *ptr_select_cfg);
#endif /* End of HAL_MT_NB_MIR_H */
