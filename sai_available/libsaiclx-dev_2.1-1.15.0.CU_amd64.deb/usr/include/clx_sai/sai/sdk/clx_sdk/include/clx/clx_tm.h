/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_tm.h
 * PURPOSE:
 *      It provides tm module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_TM_H
#define CLX_TM_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
/*port level node handler*/
#define CLX_TM_HANDLER_PORT (0xFFFFFFFF)
#define CLX_TM_HANDLER_NONE (CLX_INVALID_ID)

/*value 0 means no configure for bandwidth*/
#define CLX_TM_BANDWIDTH_NONE (0)

/* Current max num is based on the DSCP value */
#define CLX_TM_PFC_VALUE_MAX_NUM (64)

#define CLX_PFCWD_MAX_DETECTION_TIME     (5000)  /* ms */
#define CLX_PFCWD_MAX_RECOVERY_TIME      (60000) /* ms */
#define CLX_PFCWD_DEFAULT_DETECTION_TIME (100)   /* ms */
#define CLX_PFCWD_DEFAULT_RECOVERY_TIME  (1000)  /* ms */

#define CLX_TM_HISTOGRAM_SECTIOIN_NUM 8          /* The number of queue histogram section */
#define CLX_TM_HISTOGRAM_THD_NUM      7

/* The index is used to unbind wred profile for oq*/
#define CLX_TM_WRED_PROFILE_INVALID_INDEX (0xFFFFFFFF)

#define CLX_TM_MBURST_PROFILE_INVALID_INDEX (0xFFFFFFFF)

/* MACRO FUNCTION DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef uint32 clx_tm_handler_t;
typedef enum clx_tm_handler_type_e {
    CLX_TM_HANDLER_TYPE_QP = 0,
    CLX_TM_HANDLER_TYPE_UNICAST,
    CLX_TM_HANDLER_TYPE_MULTICAST,
    CLX_TM_HANDLER_TYPE_SCHED_NODE,
    CLX_TM_HANDLER_TYPE_INGRESS,
    CLX_TM_HANDLER_TYPE_LAST
} clx_tm_handler_type_t;

typedef enum clx_tm_sched_mode_e {
    CLX_TM_SCH_MODE_SP = 0, /* Strict Priority mode*/
    CLX_TM_SCH_MODE_DWRR,   /* Weighted Round Robin mode*/
    CLX_TM_SCH_MODE_LAST
} clx_tm_sched_mode_t;

typedef enum clx_tm_shaper_mode_e {
    CLX_TM_SHAPER_MODE_BYTE = 0, /* byte unit */
    CLX_TM_SHAPER_MODE_PACKET,   /* packet unit */
    CLX_TM_SHAPER_MODE_LAST
} clx_tm_shaper_mode_t;

/* TM Global control type */
typedef enum clx_tm_cfg_type_e {
    CLX_TM_CFG_SYSTEM_ECN,              /* Configure the global ECN enable/disable and free thd
                                         * settings. Enabling this option will result in ECN marking when
                                         * the free buffer less than the configured global free thd.
                                         * (This is working on global share buffer, not releated to queue
                                         * ECN mechenism) Param0: Enable/Disable (0 for disable) Param1:
                                         * Free thd (granularity : 2 cells) */
    CLX_TM_CFG_SNAPSHOT_THD_EGR_GLOBAL, /* Use egress global thd to trigger
                                         * snapshot. Param0 will be buffer thd to
                                         * trigger snapshot and 0 is to disable.*/
    CLX_TM_CFG_CPI_QUEUE_TRUNCATE_SIZE, /* Set truncate packet size of one queue of CPI port.
                                         * Param0 will be CPI port 0/1, param1 is handler of
                                         * queue and value is truncate packet size.*/

    CLX_TM_CFG_TC_CUT_THROUGH,          /* NB new add, only NB support, set/get tc cut through */
    CLX_TM_CFG_PORT_TC_PROF_INDEX,      /* NB new add, only NB support, set/get port's tc prof
                                                   index */
    CLX_TM_CFG_STACKING_TC_PROF_INDEX,  /* NB new add, only NB support, set/get Fabric link tc
                                           profile index */
    CLX_TM_CFG_INGRESS_DYNAMIC_THD,     /* NB new add, set/get ingress global dynamic
                                         * thd configure param0:   enable/disable
                                         * param1:   dynamic factor value,0~13
                                         *           the max thd is equal (free
                                         * buffer)*(percentage), the relationship between
                                         * factor and percentage(alpha) as flow: 0:1/128
                                         * 1:2/128     2:4/18   3:8/128  4:13/128    5:26/128
                                         *              6:38/128    7:50/128    8:64/18
                                         * 9:76/128 10:88/128   11:104/128 12:116/128
                                         * 13:128/128 dynanic thd = pool_size * (
                                         * alpha/(1+alpha) ) */
    CLX_TM_CFG_EGRESS_DYNAMIC_THD,      /* NB new add, set/get egress global dynamic thd
                                         * configure param0: to see
                                         * CLX_TM_CFG_INGRESS_DYNAMIC_THRESHOLD comment
                                         * param1: to see
                                         * CLX_TM_CFG_INGRESS_DYNAMIC_THRESHOLD comment
                                         */
    CLX_TM_CFG_INGRESS_SHARE_POOL_SIZE, /* NB new add, set/get ingress buffer share pool size
                                         * param0: share lossy pool size
                                         * param1: share lossless pool size*/
    CLX_TM_CFG_EGRESS_SHARE_POOL_SIZE,  /* NB new add, set/get egress buffer share pool size
                                         * param0: share lossy pool size
                                         * param1: share lossless pool size*/
    CLX_TM_CFG_WRED_RED_BASE_YELLOW_ENABLE, /* NB new add,
                                             * param0: 0 - red packet always drop,
                                             *         1 - red packet probability the same with
                                             * yellow param1: not used */
    CLX_TM_CFG_LOSSLESS_TC,                 /* NB new add, enable global lossless TC
                                             * input is the bit map, example: enable TC 6 and 7 is 0x60  */
    CLX_TM_CFG_BUFFER_LEVEL_SEL,    /* Select egress queue buffer level, param0:0 is pool level,1
                                       is pdb level*/
    CLX_TM_CFG_DYNAMIC_BUFFER_POOL, /* NB new add, Set handler dynmaic buffer pool, */
                                    /* param0: 0 ingress dynamic pool, 1 egress dynamic pool */
    /* param1: 0: dynamic share lossy pool, 1: dynamic share lossless pool */
    CLX_TM_CFG_MBURST_ENABLE,
    CLX_TM_CFG_IGR_HEADROOM_SIZE, /* Set/get ingress headroom size */
    CLX_TM_CFG_LAST
} clx_tm_cfg_type_t;

/* PFCWD State */
typedef enum clx_tm_pfcwd_state_e {
    CLX_TM_PFCWD_STATE_DISABLED,    /* The PFC WatchDog state -- disabled */
    CLX_TM_PFCWD_STATE_CFG_NOT_RDY, /* The PFC WatchDog state -- enable but config not ready (pfc
                                          map not configure)*/
    CLX_TM_PFCWD_STATE_OPERATIONAL, /* The PFC WatchDog state -- operational */
    CLX_TM_PFCWD_STATE_STORMED,     /* The PFC WatchDog state -- stormed */
    CLX_TM_PFCWD_STATE_LAST
} clx_tm_pfcwd_state_t;

typedef enum clx_tm_pfcwd_event_e {
    CLX_TM_PFCWD_EVENT_DETECTED = 0, /* The PFC WatchDog PFC storm detected event */
    CLX_TM_PFCWD_EVENT_RECOVERED,    /* The PFC WatchDog recovered event */
    CLX_TM_PFCWD_EVENT_LAST
} clx_tm_pfcwd_event_t;

typedef enum clx_tm_pfcwd_action_e {
    CLX_TM_PFCWD_ACTION_DROP = 0, /* The PFC WatchDog DROP action */
    CLX_TM_PFCWD_ACTION_FORWARD,  /* The PFC WatchDog forward packets action */
    CLX_TM_PFCWD_ACTION_DONTCARE, /* The PFC WatchDog don't care action and just notify uplayer */
    CLX_TM_PFCWD_ACTION_LAST
} clx_tm_pfcwd_action_t;
typedef enum clx_tm_buf_stat_type_e {
    CLX_TM_BUF_STAT_IGR_PORT,           // NB Not Support
    CLX_TM_BUF_STAT_IGR_PORT_HEADROOM,  // NB Not Support
    CLX_TM_BUF_STAT_IGR_QUEUE,
    CLX_TM_BUF_STAT_IGR_QUEUE_HEADROOM, /* The buffer type is ingress headroom and occupancy */
    CLX_TM_BUF_STAT_EGR_PORT,           // NB Not Support
    CLX_TM_BUF_STAT_EGR_QUEUE,
    CLX_TM_BUF_STAT_IGR_SYSTEM_LOSSY,
    CLX_TM_BUF_STAT_IGR_SYSTEM_LOSSLESS,
    CLX_TM_BUF_STAT_EGR_SYSTEM_LOSSY,
    CLX_TM_BUF_STAT_EGR_SYSTEM_LOSSLESS,
    CLX_TM_BUF_STAT_IGR_SYSTEM, /* IGR_SYSTEM_LOSSY + IGR_SYSTEM_LOSSLESS (ASIC clear w) */
    CLX_TM_BUF_STAT_EGR_SYSTEM, /* EGR_SYSTEM_LOSSY + EGR_SYSTEM_LOSSLESS (ASIC clear w) */
    CLX_TM_BUF_STAT_SYSTEM,
    CLX_TM_BUF_STAT_TYPE_LAST
} clx_tm_buf_stat_type_t;
typedef enum clx_tm_buf_dynamic_type_e {
    CLX_TM_BUF_DYN_TYPE_IGR = 0,
    CLX_TM_BUF_DYN_TYPE_EGR,
} clx_tm_buf_dynamic_type_t;
typedef enum clx_tm_buf_prof_type_e {
    CLX_TM_BUF_PROF_TYPE_IGR_QUEUE = 0,
    CLX_TM_BUF_PROF_TYPE_EGR_QUEUE,
    CLX_TM_BUF_PROF_TYPE_MAX,
} clx_tm_buf_prof_type_t;

typedef enum clx_tm_buf_wred_mode_e {
    CLX_TM_BUF_WRED_MODE_DROP,
    CLX_TM_BUF_WRED_MODE_ECN,
    CLX_TM_BUF_WRED_MODE_LAST
} clx_tm_buf_wred_mode_t;

typedef struct clx_tm_wred_cfg_s {
    uint32 prof_id;  /* Wred prof index */
} clx_tm_wred_cfg_t; /* only NB support */

/* TM PFC mapping type */
typedef enum clx_tm_pfc_map_type_e {
    CLX_TM_PFC_MAP_TYPE_PRI_TO_QUE = 0, /* PFC Rx priority to queue Map */
    /* Queue to PFC Tx priority Map (NB support single tc to single queue) */
    CLX_TM_PFC_MAP_TYPE_QUE_TO_PRI = 1,
    /* Both PFC Rx priority to queue and queue to PFC Tx priority Map */
    CLX_TM_PFC_MAP_TYPE_PRI_QUE_BOTH = 2,
    CLX_TM_PFC_MAP_TYPE_DATA_PCP = 3,      /* Oversubscribe class map for PCP */
    CLX_TM_PFC_MAP_TYPE_DATA_DSCP = 4,     /* Oversubscribe class map for DSCP */
    CLX_TM_PFC_MAP_TYPE_DATA_MPLS_EXP = 5, /* Oversubscribe class map for EXP (Only NB)*/
    CLX_TM_PFC_MAP_TYPE_LAST
} clx_tm_pfc_map_type_t;

typedef enum clx_tm_tcb_buf_drop_type_e {
    CLX_TM_TCB_BUF_DROP_TYPE_IGR_QUEUE,
    CLX_TM_TCB_BUF_DROP_TYPE_EGR_GREEN,
    CLX_TM_TCB_BUF_DROP_TYPE_EGR_YELLOW,
    CLX_TM_TCB_BUF_DROP_TYPE_EGR_RED,
    CLX_TM_TCB_BUF_DROP_TYPE_LAST
} clx_tm_tcb_buf_drop_type_t;

typedef enum clx_tm_tcb_match_type_e {
    CLX_TM_TCB_MATCH_TYPE_CAPTURE, /* capture key */
    CLX_TM_TCB_MATCH_TYPE_TRIGGER, /* trigger key */
    CLX_TM_TCB_MATCH_TYPE_LAST
} clx_tm_tcb_match_type_t;

typedef enum clx_tm_tcb_op_type_e {
    CLX_TM_TCB_OP_TYPE_NONE,
    CLX_TM_TCB_OP_TYPE_START,
    CLX_TM_TCB_OP_TYPE_STOP,
    CLX_TM_TCB_OP_TYPE_CLEAR,
    CLX_TM_TCB_OP_TYPE_LAST
} clx_tm_tcb_op_type_t;

typedef enum {
    CLX_TM_TCB_TRIG_TYPE_KEY,      /* trigger source is key */
    CLX_TM_TCB_TRIG_TYPE_BUF_DROP, /* trigger source is buffer drop */
    CLX_TM_TCB_TRIG_TYPE_LAST
} clx_tm_tcb_trig_type_t;

typedef enum clx_tm_tcb_cfg_type_e {
    CLX_TM_TCB_CFG_TYPE_TRIG_POS, /* trigger position */
    CLX_TM_TCB_CFG_TYPE_OP,       /* operation */
    CLX_TM_TCB_CFG_TYPE_LAST
} clx_tm_tcb_cfg_type_t;

typedef uint32_t clx_queue_t;
typedef struct clx_tm_cfg_s {
    clx_tm_cfg_type_t cfg_type;
    uint32 value0;
    uint32 value1;
} clx_tm_cfg_t;

typedef struct clx_tm_sched_cfg_s {
    /* data */
    clx_tm_sched_mode_t sched_mode;
    uint32 weight;
} clx_tm_sched_cfg_t;

typedef struct clx_tm_buf_egr_prof_s {
    uint32 min;
    uint32 max; /* Maximum threshold of tail drop */
} clx_tm_buf_egr_prof_t;

typedef struct clx_tm_buf_igr_prof_cfg_s {
    uint32 min;          /* Minimum guarantee thd */
    uint32 xon;          /* Middle thd of lossly mode, or xon of lossless mode */
    uint32 xoff;         /* Maximum thd of lossly mode, or xoff of lossless mode */
    uint32 headroom;     /* Headroom is work when set CLX_CFG_TYPE_TM_IGR_DYNAMIC_NO_SUPPORT */
} clx_tm_buf_igr_prof_t; /* Only NB support */
typedef struct clx_tm_buf_prof_s {
    clx_tm_buf_prof_type_t type;
    union {
        clx_tm_buf_igr_prof_t igr_prof;
        clx_tm_buf_egr_prof_t egr_prof;
    };
} clx_tm_buf_prof_t;

typedef struct clx_tm_buf_wred_prof_s {
    uint32 wred_min;
    uint32 wred_max;
    uint32 green_probability;         /* NB ECN need same configuration on all color */
    uint32 yellow_probability;        /* NB ECN need same configuration on all color */
    clx_tm_buf_wred_mode_t wred_mode; /* On port or profile ecn or drop */
} clx_tm_wred_prof_t;

typedef struct clx_tm_shaper_s {
    uint32 cir;                            /* Minimum rate */
    uint32 cbs;                            /* Burst size of minimum bucket */
    uint32 pir;                            /* Maximum rate */
    uint32 pbs;                            /* Burst size of maximum bucket */
    clx_tm_shaper_mode_t shaper_mode;      /* Byte-based or packet-based. */
} clx_tm_shaper_t;
#define CLX_TM_DEFAULT_SHAPER (0)          // PIR or CIR is 0
#define CLX_TM_SHAPER_ZERO    (0xFFFFFFFF) // PIR or CIR is 0

typedef struct clx_tm_tc_prof_s {
    uint32 tc;     /* Traffic class, nb max 8*/
    uint32 uc_qid; /* Uc queue id for traffic class mapping */
    uint32 mc_qid; /* Mc queue id for traffic class mapping */
} clx_tm_tc_prof_t;

typedef struct clx_tm_pfcwd_cfg_s {
    boolean enable;               /* enable PFCWD */
    uint32 detection_time;        /* detection time in ms */
    uint32 recovery_time;         /* recovery time in ms */
    clx_tm_pfcwd_action_t action; /* Take what action when detect PFC storm */
} clx_tm_pfcwd_cfg_t;

typedef struct clx_tm_pfc_s {
    clx_tm_pfc_map_type_t map_type;              /* The pfc map type */
    uint32 value_list[CLX_TM_PFC_VALUE_MAX_NUM]; /* The array of pfc priority, pcp priority, dscp or
                                                    mpls exp list */
    uint32 value_cnt;                            /* The effective count of the array*/
} clx_tm_pfc_mapping_cfg_t;

typedef void (*clx_tm_pfcwd_handle_func_t)(const uint32 unit,
                                           const uint32 port,
                                           const clx_tm_handler_t handler, /*Queue*/
                                           const clx_tm_pfcwd_event_t event_type,
                                           void *ptr_cookie);

typedef struct clx_tm_buf_cfg_s {
    clx_tm_buf_prof_type_t type; /* Buffer type */
    uint32 prof_id;              /* Buffer prof index */
} clx_tm_buf_cfg_t;              /* only NB support */

typedef struct clx_tm_histogram_info_s {
    uint32 port; /* Egress port ID */
    clx_tm_handler_type_t handler_type;
    uint32 queue_id;
    uint32 watermark;
    uint64 section_cnt[CLX_TM_HISTOGRAM_SECTIOIN_NUM]; /* The counters of  queue histogram section
                                                        */
} clx_tm_histogram_info_t;                             /* only NB support */

typedef struct clx_tm_histogram_cfg_s {
    boolean enable;                       /* Enable or disable histogram function*/
    uint32 thd_type;                      /* Histogram thd is packet or buffer cell*/
    uint32 thd[CLX_TM_HISTOGRAM_THD_NUM]; /* Threshold value of histogram sections */
} clx_tm_histogram_cfg_t;                 /* Only NB support */
#define CLX_TM_HISTOGRAM_THD_TYPE_PKTS 0
#define CLX_TM_HISTOGRAM_THD_TYPE_CELL 1

typedef struct clx_tm_tcb_match_igr_s {
    uint32 di;                    /* di, 16 bits */
    uint32 int_role;              /* INT role, 2 bits */
    uint32 int_mode;              /* IMT mode, 2 bit */
    uint32 int_clone;             /* IMT clone, 1 bit */
    uint32 tc;                    /* tc, 3 bits */
    uint32 cpu_valid;             /* cpu valid, 1 bit */
    uint32 cpu_redir;             /* cpu redirect, 1 bit */
    uint32 cpu_dest;              /* cpu dest, 2 bit */
    uint32 cpu_queue;             /* cpu queue id, 6 bit */
    uint32 ct_mode;               /* cut through mode, 1 bit */
    uint32 pkt_size;              /* packet size, 14 bits */
    uint32 mirror_session;        /* mirror session id, 8 bits */
    uint32 mod_en;                /* Mod enable, 1 bit */
    uint32 acl_redirect_trunc_en; /* Acl redirect truncation enable, 1 bit */
    uint32 cpa_en;                /* CPU enable, 1 bit */
    uint32 flow_hash;             /* flow hash, 10 bit */
    uint32 meter_color;           /* meter color, 2 bit */
    uint32 pkj;                   /* pkj, 1 bit */
    uint32 sop;                   /* sop, 1 bit */
    uint32 eop;                   /* eop, 1 bit */
    uint32 frag_size;             /* frag size, 8 bit */
    uint32 rec_vld;               /* recive valid, 1 bit */
    uint32 sport;                 /* source port, cl port */
    uint32 drop_reason_code;      /* drop reason code, 6 bit*/
} clx_tm_tcb_igr_key_t;

typedef struct clx_tm_tcb_match_egr_s {
    uint32 pkt_size;    /* packet size, 14 bits*/
    uint32 oq;          /* out queue, 12 bits */
    uint32 cud_type;    /* cud type, 5 bits */
    uint32 cud_value;   /* cud value, 16 bits */
    uint32 ecn_mark;    /* ecn mark, 1 bit */
    uint32 cpa_mark;    /* cpa mark, 1 bit */
    uint32 trunc;       /* truncation, 1 bit */
    uint32 sop;         /* sop, 1 bit */
    uint32 eop;         /* eop, 1 bit */
    uint32 frag_size;   /* frag size, 8 bit */
    uint32 error;       /* error flag, 1 bit */
    uint32 dport;       /* dest port, cl port */
    uint32 pd_fifo_num; /* pd fifo num, 2 bit */
} clx_tm_tcb_egr_key_t;

typedef struct clx_tm_tcb_key_s {
    clx_dir_t dir;                      /* TCB match dir */
    union {
        clx_tm_tcb_igr_key_t igr_match; /* ingress match key */
        clx_tm_tcb_egr_key_t egr_match; /* egress match key */
    };
    union {
        clx_tm_tcb_igr_key_t igr_mask; /* ingress match mask */
        clx_tm_tcb_egr_key_t egr_mask; /* egress match mask */
    };
} clx_tm_tcb_key_t;

typedef struct clx_tm_tcb_buf_drop_s {
    clx_tm_tcb_buf_drop_type_t type;
    uint32 port;
    clx_tm_handler_t handler;
} clx_tm_tcb_buf_drop_t;

typedef struct clx_tm_tcb_match_s {
    clx_tm_tcb_trig_type_t trig_type;
    union {
        clx_tm_tcb_key_t trig_key;
        clx_tm_tcb_buf_drop_t buf_drop;
    };
    clx_tm_tcb_key_t cap_key;
} clx_tm_tcb_match_t;

#define CLX_TM_TCB_DATA_LEN (256)
typedef struct clx_tm_tcb_data_s {
    uint8_t data[CLX_TM_TCB_DATA_LEN];
    uint64_t timestamp; /* capture packet timestamp */
    clx_tm_tcb_key_t trigger_data;
} clx_tm_tcb_cap_data_t;

typedef struct clx_tm_mburst_prof_s {
    uint32 high_th; /* High threshold */
    uint32 low_th;  /* Low threshold */
} clx_tm_mburst_prof_t;

typedef struct clx_tm_mburst_cfg_s {
    uint32 prof_id; /* Mburst profile ID */
} clx_tm_mburst_cfg_t;

typedef enum clx_tm_mburst_event_type_s {
    CLX_TM_MBURST_EVENT_TYPE_START,
    CLX_TM_MBURST_EVENT_TYPE_END,
    CLX_TM_MBURST_EVENT_TYPE_LAST,
} clx_tm_mburst_event_type_e;

typedef struct clx_tm_mburst_info_s {
    clx_tm_mburst_event_type_e event_type; /* Event type */
    uint32 port;                           /* Egress port ID */
    clx_tm_handler_t handler;              /* Handler ID */
    uint32 watermark;                      /* Watermark */
    uint64 watermark_time;                 /* Watermark time */
    uint64 event_time;                     /* Event time */
} clx_tm_mburst_info_t;

// Callback Function Prototype
typedef void (*clx_tm_histogram_cb_t)(const uint32 unit,
                                      const clx_tm_histogram_info_t *ptr_histogram_info,
                                      void *ptr_cookie);

typedef void (*clx_tm_tcb_func_t)(const uint32 unit,
                                  const uint32 count,
                                  clx_tm_tcb_cap_data_t *data,
                                  void *ptr_cookie);

typedef void (*clx_tm_mburst_func_t)(const uint32 unit,
                                     const clx_tm_mburst_info_t *ptr_mburst_info,
                                     void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIßONS
 */

/**
 * @brief The function is used to configure buffer profile index for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - The ID number of port.
 * @param [in]    handler    - The ID number of TM handler.
 * @param [in]    ptr_cfg    - Buffer configuration struct pointer.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_buf_cfg_set(const uint32 unit,
                   const uint32 port,
                   const clx_tm_handler_t handler,
                   const clx_tm_buf_cfg_t *ptr_cfg);

/**
 * @brief The function is used to get buffer profile index for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - The ID number of port.
 * @param [in]     handler    - The ID number of TM handler.
 * @param [out]    ptr_cfg    - Buffer configuration struct pointer.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_buf_cfg_get(const uint32 unit,
                   const uint32 port,
                   const clx_tm_handler_t handler,
                   clx_tm_buf_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get the buffer usage amount.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - The ID number of a port.
 * @param [in]     handler           - The ID number of a TM handler.
 * @param [in]     buf_usage_type    - The type of buffer usage.
 * @param [out]    ptr_usage         - The return value of buffer usage.
 * @return         CLX_E_OK            - Operation success.
 * @return         CLX_E_OTHERS        - Other errors.
 * @return         CLX_E_OP_INVALID    - Invalid operation. mapping.
 */
clx_error_no_t
clx_tm_buf_usage_get(const uint32 unit,
                     const uint32 port,
                     const clx_tm_handler_t handler,
                     const clx_tm_buf_stat_type_t buf_usage_type,
                     uint32 *ptr_usage);

/**
 * @brief The function is used to create buffer prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    buf_prof_type    - To set the thd of port/queue in ingress/egress type.
 * @param [in]    prof_id          - Buffer prof id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_buf_prof_create(const uint32 unit,
                       const clx_tm_buf_prof_type_t buf_prof_type,
                       const uint32 prof_id);

/**
 * @brief The function is used to destroy buffer prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    buf_prof_type    - To set the thd of port/queue in ingress/egress type.
 * @param [in]    prof_id          - Buffer prof id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_buf_prof_destroy(const uint32 unit,
                        const clx_tm_buf_prof_type_t buf_prof_type,
                        const uint32 prof_id);

/**
 * @brief The function is used to set buffer prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    prof_id     - Buffer prof index.
 * @param [in]    ptr_prof    - Buffer prof struct pointer.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_buf_prof_set(const uint32 unit, const uint32 prof_id, const clx_tm_buf_prof_t *ptr_prof);

/**
 * @brief The function is used to get buffer prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     prof_id     - Buffer prof index.
 * @param [out]    ptr_prof    - Buffer prof struct pointer.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_buf_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_buf_prof_t *ptr_prof);

/**
 * @brief The function is used to create wred prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    prof_id    - Buffer prof id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_wred_prof_create(const uint32 unit, const uint32 prof_id);

/**
 * @brief The function is used to destroy wred prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    prof_id    - Buffer prof id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_wred_prof_destroy(const uint32 unit, const uint32 prof_id);

/**
 * @brief The function is used to set wred buffer prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    prof_id          - Buffer prof index.
 * @param [in]    ptr_wred_prof    - Wred buffer prof struct pointer.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_wred_prof_set(const uint32 unit,
                     const uint32 prof_id,
                     const clx_tm_wred_prof_t *ptr_wred_prof);

/**
 * @brief The function is used to get wred buffer prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     prof_id          - Buffer prof index.
 * @param [out]    ptr_wred_prof    - Wred buffer prof struct pointer.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_wred_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_wred_prof_t *ptr_wred_prof);

/**
 * @brief The function is used to configure wred prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - The ID number of port.
 * @param [in]    handler         - The ID number of TM handler.
 * @param [in]    ptr_wred_cfg    - Wred profile configure pointer.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_wred_cfg_set(const uint32 unit,
                    const uint32 port,
                    const clx_tm_handler_t handler,
                    const clx_tm_wred_cfg_t *ptr_wred_cfg);

/**
 * @brief The function is used to configure wred prof for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - The ID number of port.
 * @param [in]     handler         - The ID number of TM handler.
 * @param [out]    ptr_wred_cfg    - Wred profile configure pointer.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_wred_cfg_get(const uint32 unit,
                    const uint32 port,
                    const clx_tm_handler_t handler,
                    clx_tm_wred_cfg_t *ptr_wred_cfg);

/**
 * @brief This API is used to get the buffer Watermark.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     port                  - The ID number of a port.
 * @param [in]     handler               - The ID number of TM handler.
 * @param [in]     buf_watermark_type    - The type of buffer watermark.
 * @param [out]    ptr_watermark         - The return value of buffer watermark.
 * @return         CLX_E_OK            - Operation success.
 * @return         CLX_E_OTHERS        - Other errors.
 * @return         CLX_E_OP_INVALID    - Invalid operation.
 */
clx_error_no_t
clx_tm_buf_watermark_get(const uint32 unit,
                         const uint32 port,
                         const clx_tm_handler_t handler,
                         const clx_tm_buf_stat_type_t buf_watermark_type,
                         uint32 *ptr_watermark);

/**
 * @brief This API is used to clear buffer Watermark.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit                  - Device unit number.
 * @param [in]    port                  - The ID number of egress port.
 * @param [in]    handler               - The ID number of TM handler.
 * @param [in]    buf_watermark_type    - The type of buffer watermark.
 * @return        CLX_E_OK            - Operation success.
 * @return        CLX_E_OTHERS        - Other errors.
 * @return        CLX_E_OP_INVALID    - Invalid operation.
 */
clx_error_no_t
clx_tm_buf_watermark_clear(const uint32 unit,
                           const uint32 port,
                           const clx_tm_handler_t handler,
                           const clx_tm_buf_stat_type_t buf_watermark_type);

/**
 * @brief The function is used to configure some special properties for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - (Optional) If the property is Port or Queue setting,
 *                             the port ID needs to be specified.
 * @param [in]    handler    - (Optional) If the property is Queue setting,
 *                             the queue handler needs to be specified.
 * @param [in]    ptr_cfg    - The configure cfg with type and value to assign.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_cfg_set(const uint32 unit,
               const uint32 port,
               const clx_tm_handler_t handler,
               const clx_tm_cfg_t *ptr_cfg);

/**
 * @brief The function is used to get the special property for TM module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - (Optional) If the property is Port or Queue setting,
 *                              the port ID needs to be specified.
 * @param [in]     handler    - (Optional) If the property is Queue setting,
 *                              the queue handler needs to be specified.
 * @param [out]    ptr_cfg    - The configure with type and value to assign.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_cfg_get(const uint32 unit,
               const uint32 port,
               const clx_tm_handler_t handler,
               clx_tm_cfg_t *ptr_cfg);

/**
 * @brief The function is used to create a TM handler for the designated egress port.
 *        A TM handler can be a node consisting of multiple queues, a multicast queue or or a
 *        unicast queue.
 *
 * If a user decides to use a custom schedule policy, this API should be invoked first.
 * After invoking this API, the user should use the {handler_type, handler_id} key pair
 * to uniquely identify a tm handler.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - The ID number of egress port.
 * @param [in]     handler_type    - Type of TM handler.
 * @param [in]     queue_id        - The ID number of queue. Only take effect when TM handler is
 *                                   CLX_TM_HANDLER_TYPE_UNICAST or CLX_TM_HANDLER_TYPE_MULTICAST.
 * @param [out]    ptr_handler     - The ID number of the TM handler assigned by the SDK.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_TABLE_FULL       - Cannot create any additional handlers.
 * @return         CLX_E_NOT_INITED       - The SDK module has not been initialized yet.
 * @return         CLX_E_BAD_PARAMETER    - API input parameter is not reasonalbe.
 */
clx_error_no_t
clx_tm_handler_create(const uint32 unit,
                      const uint32 port,
                      const clx_tm_handler_type_t handler_type,
                      const clx_queue_t queue_id,
                      clx_tm_handler_t *ptr_handler);

/**
 * @brief The function is used to remove a TM handler for a particular egress port.
 *        The TM handler can be a unicast queue, a multicast queue, or a queue group made up of
 *        multiple queues.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - The ID number of egress port.
 * @param [in]    handler    - The ID number of the TM handler.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The TM handler does not exist.
 * @return        CLX_E_NOT_INITED         - The SDK module has not been initialized yet.
 * @return        CLX_E_BAD_PARAMETER      - API input parameter is not reasonalbe.
 */
clx_error_no_t
clx_tm_handler_destroy(const uint32 unit, const uint32 port, const clx_tm_handler_t handler);

/**
 * @brief The function is used to register histogram function callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    cb            - The callback function of type clx_tm_histogram_cb_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_histogram_cb_register(const uint32 unit,
                             const uint32 port,
                             const clx_tm_histogram_cb_t cb,
                             void *ptr_cookie);

/**
 * @brief The function is used to deregister histogram function callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    cb            - The callback function of type clx_tm_histogram_cb_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_histogram_cb_unregister(const uint32 unit,
                               const uint32 port,
                               const clx_tm_histogram_cb_t cb,
                               void *ptr_cookie);

/**
 * @brief The function is used to set egress queue histogram function configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_cfg    - Egress queue histogram configuration struct pointer.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_histogram_cfg_set(const uint32 unit, const clx_tm_histogram_cfg_t *ptr_cfg);

/**
 * @brief The function is used to get egress queue histogram function configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cfg    - Egress queue histogram configuration struct pointer.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_histogram_cfg_get(const uint32 unit, clx_tm_histogram_cfg_t *ptr_cfg);

/**
 * @brief The function is used to clear egress queue histogram count.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    handler    - Queue handler.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_histogram_count_clear(const uint32 unit, const uint32 port, const clx_tm_handler_t handler);

/**
 * @brief The function is create mburst profile.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    prof_id    - Profile ID of mburst profile.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_mburst_prof_create(const uint32 unit, const uint32 prof_id);

/**
 * @brief The function is destroy mburst profile.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    prof_id    - Profile ID of mburst profile.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_mburst_prof_destroy(const uint32 unit, const uint32 prof_id);

/**
 * @brief The function is set mburst profile.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    prof_id     - Profile ID of mburst profile.
 * @param [in]    ptr_prof    - Pointer of mburst profile struct.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_mburst_prof_set(const uint32 unit,
                       const uint32 prof_id,
                       const clx_tm_mburst_prof_t *ptr_prof);

/**
 * @brief The function is get mburst profile.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     prof_id     - Profile ID of mburst profile.
 * @param [out]    ptr_prof    - Pointer of mburst profile struct.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_mburst_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_mburst_prof_t *ptr_prof);

/**
 * @brief The function is set microburst configure.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    handler    - Queue handler.
 * @param [in]    ptr_cfg    - Pointer of microburst configure struct.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_mburst_cfg_set(const uint32 unit,
                      const uint32 port,
                      const clx_tm_handler_t handler,
                      const clx_tm_mburst_cfg_t *ptr_cfg);

/**
 * @brief The function is used to get microburst configure.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [in]     handler    - Queue handler.
 * @param [out]    ptr_cfg    - Pointer of microburst configure struct.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_mburst_cfg_get(const uint32 unit,
                      const uint32 port,
                      const clx_tm_handler_t handler,
                      clx_tm_mburst_cfg_t *ptr_cfg);

/**
 * @brief The function is used to register microburst function callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_func      - User callback function.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_mburst_callback_register(const uint32 unit,
                                const clx_tm_mburst_func_t ptr_func,
                                void *ptr_cookie);
/**
 * @brief The function is used to deregister microburst function callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_func      - User callback function.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_mburst_callback_deregister(const uint32 unit,
                                  const clx_tm_mburst_func_t ptr_func,
                                  void *ptr_cookie);

/**
 * @brief The function is used to set the pcp remapped to ingress or egress queue.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port id.
 * @param [in]    queue          - Queue id.
 * @param [in]    ptr_pfc_cfg    - PFC mapping struct.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Table is full.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 * @return        CLX_E_OP_INVALID       - Operate invalid.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_tm_pfc_mapping_set(const uint32 unit,
                       const uint32 port,
                       const uint32 queue,
                       const clx_tm_pfc_mapping_cfg_t *ptr_pfc_cfg);

/**
 * @brief The function is used to get the mapping of the PCP and the queue group.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port id.
 * @param [in]     queue          - Queue id.
 * @param [out]    ptr_pfc_cfg    - PFC mapping struct.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_tm_pfc_mapping_get(const uint32 unit,
                       const uint32 port,
                       const uint32 queue,
                       clx_tm_pfc_mapping_cfg_t *ptr_pfc_cfg);

/**
 * @brief This API is used to register a callback function that will be called whenever the PFCWD
 *        event occur.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cb            - The callback function of type clx_tm_pfcwd_handle_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_pfcwd_cb_register(const uint32 unit, const clx_tm_pfcwd_handle_func_t cb, void *ptr_cookie);

/**
 * @brief This API is used to deregister a callback function that will be called whenever the PFCWD
 *        event occur.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cb            - The callback function of type clx_tm_pfcwd_handle_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_pfcwd_cb_deregister(const uint32 unit,
                           const clx_tm_pfcwd_handle_func_t cb,
                           void *ptr_cookie);

/**
 * @brief This API is used to configure PFCWD on queue.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    queue      - Queue id.
 * @param [in]    ptr_cfg    - PFCWD Configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_pfcwd_set(const uint32 unit,
                 const clx_port_t port,
                 const uint32 queue,
                 const clx_tm_pfcwd_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get PFCWD on queue.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [in]     queue      - Queue id.
 * @param [out]    ptr_cfg    - PFCWD Configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_pfcwd_get(const uint32 unit,
                 const clx_port_t port,
                 const uint32 queue,
                 clx_tm_pfcwd_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get current state of PFCWD.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [in]     queue        - Queue id.
 * @param [out]    ptr_state    - PFCWD Current State.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_pfcwd_state_get(const uint32 unit,
                       const clx_port_t port,
                       const uint32 queue,
                       clx_tm_pfcwd_state_t *ptr_state);

/**
 * @brief This API is used to assign schedule mode as DWRR or SP of the TM handler.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - The ID number of egress port.
 * @param [in]    handler      - The ID number of the TM handler.
 * @param [in]    sched_cfg    - Parameters of scheduler.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_sched_set(const uint32 unit,
                 const uint32 port,
                 const clx_tm_handler_t handler,
                 const clx_tm_sched_cfg_t sched_cfg);

/**
 * @brief This API is used to get schedule mode (DWRR/SP) of a TM handler.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - The ID number of egress port.
 * @param [in]     handler          - The ID number of the TM handler.
 * @param [out]    ptr_sched_cfg    - Parameters of scheduler.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_sched_get(const uint32 unit,
                 const uint32 port,
                 const clx_tm_handler_t handler,
                 clx_tm_sched_cfg_t *ptr_sched_cfg);

/**
 * @brief This API is used to setup shaper configuration of a TM handler.
 *
 * Assign CIR, cir bucket, PIR and PIR bucket of a TM handler.
 * If "0" is set to CIR/PIR or  CIR/PIR bucket,
 * SDK will provide a set of SDK default settings.
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - The ID number of egress port.
 * @param [in]    handler       - The ID number of the TM handler.
 * @param [in]    ptr_shaper    - Shaper parameters.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_shaper_set(const uint32 unit,
                  const uint32 port,
                  const clx_tm_handler_t handler,
                  const clx_tm_shaper_t *ptr_shaper);

/**
 * @brief This API is used to get shaper configuration of a TM handler.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - The ID number of egress port.
 * @param [in]     handler       - The ID number of the TM handler.
 * @param [out]    ptr_shaper    - Shaper parameters.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_tm_shaper_get(const uint32 unit,
                  const uint32 port,
                  const clx_tm_handler_t handler,
                  clx_tm_shaper_t *ptr_shaper);

/**
 * @brief The function is used to set the tc to queue mapping.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    prof_id     - Tc prof id.
 * @param [in]    ptr_prof    - Tc prof info pointer.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tm_tc_prof_set(const uint32 unit, const uint32 prof_id, const clx_tm_tc_prof_t *ptr_prof);

/**
 * @brief The function is used to get tc to queue mapping.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    prof_id     - Tc prof id.
 * @param [in]    ptr_prof    - Tc prof info pointer.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tm_tc_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_tc_prof_t *ptr_prof);

/**
 * @brief The function is used to set tcb match key.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    type         - Match type, capture or trigger.
 * @param [in]    ptr_match    - Match key.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_tcb_match_set(const uint32 unit,
                     const clx_tm_tcb_match_type_t type,
                     const clx_tm_tcb_match_t *ptr_match);

/**
 * @brief The function is used to get tcb match key.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - Match type, capture or trigger.
 * @param [out]    ptr_match    - Match key.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_tcb_match_get(const uint32 unit,
                     const clx_tm_tcb_match_type_t type,
                     clx_tm_tcb_match_t *ptr_match);

/**
 * @brief The function is used to set tcb configure.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    type     - Configure type.
 * @param [in]    value    - Configure valiue.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_tcb_cfg_set(const uint32 unit, const clx_tm_tcb_cfg_type_t type, const uint32 value);

/**
 * @brief The function is used to get tcb configure.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - Configure type.
 * @param [out]    ptr_value    - Configure valiue pointer.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_tcb_cfg_get(const uint32 unit, const clx_tm_tcb_cfg_type_t type, uint32 *ptr_value);

/**
 * @brief The function is used to register tcb callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    func          - Callback function.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_tcb_callback_register(const uint32 unit, const clx_tm_tcb_func_t func, void *ptr_cookie);

/**
 * @brief The function is used to unregister tcb callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     func          - Callback function.
 * @param [out]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
clx_tm_tcb_callback_deregister(const uint32 unit, const clx_tm_tcb_func_t func, void *ptr_cookie);

#endif /* End of CLX_TM_H */
