/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_cmn_drv.h
 * PURPOSE:
 *  Provide HAL common driver structure and API for HAL exported API.
 *
 * NOTES:
 */

#ifndef HAL_CMN_DRV_H
#define HAL_CMN_DRV_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_stat.h>
#include <clx/clx_telm.h>
#include <hal/hal_cia.h>
#include <hal/hal_cia.h>
#include <hal/hal_ifmon.h>
#include <hal/hal_tm.h>
#include <hal/hal_tm_buf.h>
#include <hal/hal_tm_sched.h>
#include <hal/hal_l2.h>
#include <hal/hal_l3.h>
#include <hal/hal_tnl.h>
#include <hal/hal_mpls.h>
#include <hal/hal_pkt_rsrc.h>
#include <hal/hal_meter.h>
#include <hal/hal_sflow.h>
#include <hal/hal_mir.h>
#include <hal/hal_lag.h>
#include <hal/hal_qos.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef clx_error_no_t (*hal_cmn_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_nvo3_route_add_func_t)(const uint32 unit,
                                                        const uint32 nvo3_encap_idx,
                                                        const clx_nhp_type_t output_type,
                                                        const uint32 output_id,
                                                        uint32 *ptr_path_buf,
                                                        hal_cmn_rte_node_t **pptr_nvo3_adj_arr,
                                                        util_lib_avl_head_t *ptr_path_avl);

typedef clx_error_no_t (*hal_cmn_nvo3_route_del_func_t)(const uint32 unit,
                                                        const uint32 nvo3_encap_idx,
                                                        hal_cmn_rte_node_t **pptr_nvo3_adj_arr,
                                                        util_lib_avl_head_t *ptr_path_avl);

typedef clx_error_no_t (*hal_cmn_addievl3rtenode_func_t)(const uint32 unit,
                                                         const uint32 iev_idx,
                                                         const clx_nhp_type_t output_type,
                                                         const uint32 output_id,
                                                         util_lib_avl_head_t *ptr_adj_avl,
                                                         util_lib_avl_head_t *ptr_iev_avl);
typedef clx_error_no_t (*hal_cmn_delievl3rtenode_func_t)(const uint32 unit,
                                                         const uint32 iev_idx,
                                                         util_lib_avl_head_t *ptr_adj_avl,
                                                         util_lib_avl_head_t *ptr_iev_avl);

typedef clx_error_no_t (*hal_cmn_getievl3rtenode_func_t)(const uint32 unit,
                                                         const uint32 id,
                                                         util_lib_avl_head_t *ptr_adj_avl,
                                                         util_lib_avl_head_t *ptr_iev_avl,
                                                         hal_cmn_rte_node_t **pptr_node);

typedef clx_error_no_t (*hal_cmn_saveievl3rtenodes_func_t)(util_lib_avl_head_t *ptr_adj_avl,
                                                           util_lib_avl_head_t *ptr_iev_avl,
                                                           hal_io_obj_meta_t *ptr_obj_meta);

typedef clx_error_no_t (*hal_cmn_restoreievl3rtenodes_func_t)(const uint32 unit,
                                                              util_lib_avl_head_t *ptr_adj_avl,
                                                              util_lib_avl_head_t *ptr_iev_avl,
                                                              const hal_io_obj_meta_t *ptr_obj_meta);

typedef clx_error_no_t (*hal_cmn_getencapidxfromport_func_t)(const uint32 unit,
                                                             const clx_port_t port,
                                                             const clx_tnl_info_t *ptr_key,
                                                             uint32 *ptr_nvo3_encap_idx);

typedef clx_error_no_t (*hal_cmn_getportfromencapidx_func_t)(const uint32 unit,
                                                             const uint32 nvo3_encap_idx,
                                                             clx_port_t *ptr_port,
                                                             clx_tnl_info_t *ptr_key,
                                                             boolean *ptr_use_port);

/* l2 multiplexing functions start */
typedef clx_error_no_t (*hal_cmn_L2_addr_di_replace_func_t)(const uint32 unit,
                                                            const uint32 match_ueid_mgid,
                                                            const uint32 replace_ueid_mgid);

typedef clx_error_no_t (*hal_cmn_l2_phy_mc_id_get_func_t)(const uint32 unit,
                                                          const uint32 phy_mc_id,
                                                          uint32 *ptr_flags,
                                                          clx_port_bitmap_t port_bitmap);
typedef clx_error_no_t (*hal_cmn_l2_uncompress_phy_mc_id_get_func_t)(const uint32 unit,
                                                                     const uint32 logical_mc_id,
                                                                     uint32 *ptr_phy_mc_id);
typedef clx_error_no_t (*hal_cmn_l2_bum_logical_mc_id_to_phy_id_trans_func_t)(
    const uint32 unit,
    const uint32 logical_mc_id,
    uint32 *ptr_phy_mc_id,
    boolean *ptr_no_compress);
typedef clx_error_no_t (*hal_cmn_l2_bum_uncompress_phy_mc_id_get_func_t)(
    const uint32 unit,
    const hal_l2_bum_mc_id_t logical_mc_id,
    hal_l2_bum_mc_id_t *ptr_phy_mc_id);
typedef clx_error_no_t (*hal_cmn_l2_bum_entry_logical_mc_id_set_func_t)(const uint32 unit,
                                                                        const uint32 bum_entry_idx,
                                                                        const uint32 logical_mc_id);
typedef clx_error_no_t (*hal_cmn_l2_bum_entry_logical_mc_id_get_func_t)(const uint32 unit,
                                                                        const uint32 bum_entry_idx,
                                                                        uint32 *ptr_logical_mc_id);
typedef clx_error_no_t (*hal_cmn_l2_bum_entry_idx_to_avl_add_func_t)(const uint32 unit,
                                                                     const uint32 logical_mc_id,
                                                                     const uint32 bum_entry_idx);
typedef clx_error_no_t (*hal_cmn_l2_bum_entry_idx_to_avl_del_func_t)(const uint32 unit,
                                                                     const uint32 logical_mc_id,
                                                                     const uint32 bum_entry_idx);
typedef clx_error_no_t (*hal_cmn_l2_uncompress_phy_mc_id_to_logical_id_trans_func_t)(
    const uint32 unit,
    const uint32 phy_mc_id,
    const boolean lock,
    uint32 *ptr_logical_mc_id);
/* ifmon multiplexing functions start */
typedef clx_error_no_t (*hal_cmn_ifmon_lockdata_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_ifmon_unlockdata_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_ifmon_lockflow_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_ifmon_unlockflow_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_ifmon_getlink_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       uint32 *ptr_link);

typedef clx_error_no_t (*hal_cmn_ifmon_getfault_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        uint32 *ptr_fault);

typedef clx_error_no_t (*hal_cmn_ifmon_getspeed_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        clx_port_speed_t *ptr_speed);

typedef clx_error_no_t (*hal_cmn_ifmon_addmoclort_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_cmn_ifmon_delmoclort_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_cmn_ifmon_addanltbitmap_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_cmn_ifmon_delanltbitmap_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_cmn_ifmon_recordtime_func_t)(const uint32 unit,
                                                          const HAL_IFMON_TIME_T time_type);

typedef clx_error_no_t (*hal_cmn_ifmon_updateswstate_func_t)(const uint32 unit,
                                                             const uint32 port,
                                                             uint32 *ptr_updated);

typedef clx_error_no_t (*hal_cmn_ifmon_dumplinkstate_func_t)(const uint32 unit);

/* tm multiplexing functions start */

typedef clx_error_no_t (*hal_cmn_tm_speed_set_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const clx_port_speed_t speed);
typedef clx_error_no_t (*hal_cmn_tm_flow_ctrl_mode_set_func_t)(const uint32 unit,
                                                               const uint32 port,
                                                               const hal_tm_fc_t mode);
typedef clx_error_no_t (*hal_cmn_tm_port_flush_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const uint32 enable);

typedef clx_error_no_t (*hal_cmn_tm_trunc_prof_set_func_t)(const uint32 unit,
                                                           const hal_tm_trunc_prof_t *profile);

typedef clx_error_no_t (*hal_cmn_tm_trunc_prof_get_func_t)(const uint32 unit,
                                                           hal_tm_trunc_prof_t *profile);

typedef clx_error_no_t (*hal_cmn_tm_trunc_set_func_t)(const uint32 unit,
                                                      const hal_tm_trunc_cfg_t *config);

typedef clx_error_no_t (*hal_cmn_tm_trunc_get_func_t)(const uint32 unit,
                                                      hal_tm_trunc_cfg_t *config);

typedef clx_error_no_t (*hal_cmn_tm_cpa_get_func_t)(const uint32 unit,
                                                    const clx_swc_cfg_cpa_type_t type,
                                                    const uint32 value);

typedef clx_error_no_t (*hal_cmn_tm_getcpa_func_t)(const uint32 unit,
                                                   const clx_swc_cfg_cpa_type_t type,
                                                   uint32 *ptr_value);

typedef clx_error_no_t (*hal_cmn_tm_xoff_msk_set_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_cmn_tm_buf_dflt_set_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_tm_pfcwd_state_disable_event_handler_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const uint8 queue_id,
    const hal_tm_pfcwd_event_t event,
    hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

typedef clx_error_no_t (*hal_cmn_tm_pfcwd_state_cfg_not_ready_event_handler_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const uint8 queue_id,
    const hal_tm_pfcwd_event_t event,
    hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

typedef clx_error_no_t (*hal_cmn_tm_pfcwd_state_oper_event_handler_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const uint8 queue_id,
    const hal_tm_pfcwd_event_t event,
    hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

typedef clx_error_no_t (*hal_cmn_tm_pfcwd_state_stormed_event_handler_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const uint8 queue_id,
    const hal_tm_pfcwd_event_t event,
    hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

typedef clx_error_no_t (*hal_cmn_tm_fc_show_func_t)(const uint32 unit);

/* MPLS multiplexing functions */
typedef clx_error_no_t (*hal_cmn_mpls_initcfg_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_mpls_initwarm_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_mpls_deinitwarm_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_mpls_deinitcfg_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_mpls_pathinfo_get_func_t)(const uint32 unit,
                                                           const clx_port_t port,
                                                           hal_mpls_path_t *ptr_path);

typedef clx_error_no_t (*hal_cmn_mpls_getportbypathinfo_func_t)(const uint32 unit,
                                                                const hal_mpls_path_t *ptr_path,
                                                                clx_port_t *ptr_port);

typedef clx_error_no_t (*hal_cmn_mpls_vpwslagmember_update_func_t)(const uint32 unit,
                                                                   const uint32 lag_id,
                                                                   const uint32 add_member_cnt,
                                                                   const uint32 *ptr_add_member_di,
                                                                   const uint32 del_member_cnt,
                                                                   const uint32 *ptr_del_member_di);

/* stat multiplexing functions start */
typedef clx_error_no_t (*hal_cmn_stat_tm_cnt_get_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const clx_tm_handler_t handler,
                                                         const clx_stat_tm_t type,
                                                         clx_stat_tm_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_cmn_stat_tm_cnt_clear_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           const clx_tm_handler_t handler,
                                                           const clx_stat_tm_t type);

typedef clx_error_no_t (*hal_cmn_stat_queue_cnt_idx_get_func_t)(const uint32 unit,
                                                                const clx_tm_handler_t handler,
                                                                uint32 *ptr_idx);

/* l3 multiplexing functions start */
typedef clx_error_no_t (*hal_cnm_l3_fdid2intf_func_t)(const uint32 unit,
                                                      const clx_bridge_domain_t bdid,
                                                      uint32 *ptr_intf_id);

typedef clx_error_no_t (*hal_cnm_l3_intf2fdid_func_t)(const uint32 unit,
                                                      const uint32 intf_id,
                                                      clx_bridge_domain_t *ptr_bdid);

typedef clx_error_no_t (*hal_cnm_l3_glb_route_miss_act_set_fun_t)(const uint32 unit,
                                                                  const uint32 action);

typedef clx_error_no_t (*hal_cnm_l3_glb_route_miss_act_get_fun_t)(const uint32 unit,
                                                                  uint32 *ptr_action);

typedef clx_error_no_t (*hal_cmn_l3_adj_info_get_func_t)(const uint32 unit,
                                                         const uint32 adj_id,
                                                         hal_l3_adj_info_t *ptr_adj_info);

typedef clx_error_no_t (*hal_cmn_l3_host_idx_get_func_t)(const uint32 unit,
                                                         const clx_l3_host_t *ptr_host,
                                                         uint32 *is_tcam,
                                                         uint32 *ptr_host_idx);

typedef clx_error_no_t (*hal_cmn_l3_adj_reference_update_func_t)(const uint32 unit,
                                                                 const uint32 adj_id,
                                                                 const boolean inc);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_reference_update_func_t)(const uint32 unit,
                                                                  const uint32 ecmp_grp_id,
                                                                  const boolean inc);
typedef clx_error_no_t (*hal_cmn_l3_reference_update_func_t)(const uint32 unit,
                                                             const clx_nhp_t nhp,
                                                             const boolean inc);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_pathidx_get_by_adjid_func_t)(
    const uint32 unit,
    const uint32 ecmp_grp_id,
    const clx_nhp_type_t output_type,
    const uint32 adj_id,
    uint32 *ptr_act_idx,
    uint32 *ptr_act_cnt,
    uint32 *ptr_orig_idx,
    uint32 *ptr_orig_cnt);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_resilient_set_func_t)(const uint32 unit,
                                                               const uint32 is_enable);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_resilient_get_func_t)(const uint32 unit,
                                                               uint32 *is_enable);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_algomode_set_func_t)(const uint32 unit,
                                                              const clx_l3_ecmp_algo_mode_t mode);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_algomode_get_func_t)(const uint32 unit,
                                                              clx_l3_ecmp_algo_mode_t *mode);

typedef clx_error_no_t (
    *hal_cmn_l3_ecmp_hsh_eng_algomode_set_func_t)(const uint32 unit, const clx_swc_hsh_algo_t mode);
typedef clx_error_no_t (*hal_cmn_l3_ecmp_hsh_eng_algomode_get_func_t)(const uint32 unit,
                                                                      clx_swc_hsh_algo_t *mode);
typedef clx_error_no_t (*hal_cmn_l3_mc_lcl_set_func_t)(const uint32 unit,
                                                       const clx_swc_cfg_t property,
                                                       const uint32 addr,
                                                       const uint32 mask);
typedef clx_error_no_t (*hal_cmn_l3_mc_lcl_get_func_t)(const uint32 unit,
                                                       const clx_swc_cfg_t property,
                                                       uint32 *addr,
                                                       uint32 *mask);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_grp_max_path_set_func_t)(const uint32 unit,
                                                                  const uint32 num);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_grp_max_path_get_func_t)(const uint32 unit, uint32 *num);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_grp_acl_bind_func_t)(const uint32 unit,
                                                              const uint32 old_ecmp_grp_id,
                                                              uint32 *new_ecmp_grp_id,
                                                              const boolean need_alloc);

typedef clx_error_no_t (*hal_cmn_l3_ecmp_grp_acl_unbind_func_t)(const uint32 unit,
                                                                const uint32 old_ecmp_grp_id,
                                                                const uint32 new_ecmp_grp_id,
                                                                const boolean need_free);

typedef clx_error_no_t (*hal_cmn_l3_mcast_all_mbr_del_func_t)(const uint32 unit,
                                                              const uint32 mcast_id);

typedef clx_error_no_t (*hal_cmn_l3_capacity_get_func_t)(const uint32 unit,
                                                         const clx_swc_rsrc_t type,
                                                         const uint32 param,
                                                         uint32 *ptr_size);

typedef clx_error_no_t (*hal_cmn_l3_usage_get_func_t)(const uint32 unit,
                                                      const clx_swc_rsrc_t type,
                                                      const uint32 param,
                                                      uint32 *ptr_cnt);

typedef clx_error_no_t (*hal_cmn_l3_icmp_redirect_get_func_t)(const uint32 unit,
                                                              uint32 *ptr_is_enable);

typedef clx_error_no_t (*hal_cmn_l3_icmp_redirect_set_func_t)(const uint32 unit,
                                                              const uint32 is_enable);

typedef clx_error_no_t (*hal_cmn_l3_urpf_check_get_func_t)(const uint32 unit,
                                                           uint32 *ptr_is_enable);

typedef clx_error_no_t (*hal_cmn_l3_urpf_check_set_func_t)(const uint32 unit,
                                                           const uint32 is_enable);

typedef clx_error_no_t (*hal_cmn_l3_vld_ip_get_func_t)(const uint32 unit,
                                                       uint32 *ptr_enable,
                                                       uint32 *ptr_fail_act);

typedef clx_error_no_t (*hal_cmn_l3_vld_ip_set_func_t)(const uint32 unit,
                                                       const uint32 enable,
                                                       const uint32 fail_act);

typedef clx_error_no_t (*hal_cmn_l3_excpt_act_get_func_t)(const uint32 unit,
                                                          const clx_swc_cfg_t property,
                                                          clx_fwd_action_t *ptr_action);

typedef clx_error_no_t (*hal_cmn_l3_excpt_act_set_func_t)(const uint32 unit,
                                                          const clx_swc_cfg_t property,
                                                          const clx_fwd_action_t action);

typedef clx_error_no_t (*hal_cmn_l3_hdr_err_act_get_func_t)(const uint32 unit,
                                                            const clx_swc_cfg_t property,
                                                            clx_fwd_action_t *ptr_action);

typedef clx_error_no_t (*hal_cmn_l3_hdr_err_act_set_func_t)(const uint32 unit,
                                                            const clx_swc_cfg_t property,
                                                            const clx_fwd_action_t action);

typedef clx_error_no_t (*hal_cmn_l3_fwd_get_func_t)(const uint32 unit,
                                                    const clx_nhp_t nhp,
                                                    const uint32 subnet_bc_id,
                                                    uint32 *ptr_fwd_ptr);

typedef clx_error_no_t (*hal_cmn_l3_nhp_get_func_t)(const uint32 unit,
                                                    const uint32 hw_addr,
                                                    clx_nhp_t *ptr_nhp,
                                                    uint32 *ptr_subnet_bc_id);

/* Ecmp Internal for L2 */
/* Create Group */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_add_func_t)(const uint32 unit,
                                                        clx_l2_ecmp_grp_t *ptr_ecmp_info,
                                                        clx_port_t *ptr_ecmp_port);

/* Del Group */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_del_func_t)(const uint32 unit,
                                                        const clx_port_t ecmp_port);

/* Get Group */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_get_func_t)(const uint32 unit,
                                                        const clx_port_t ecmp_port,
                                                        clx_l2_ecmp_grp_t *ptr_ecmp_info);

/* Add path */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_path_add_func_t)(
    const uint32 unit,
    const clx_port_t ecmp_port,
    const clx_l2_ecmp_path_t *ptr_path_info);

/* Del path */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_path_del_func_t)(
    const uint32 unit,
    const clx_port_t ecmp_port,
    const clx_l2_ecmp_path_t *ptr_path_info);

/* Get path by idx */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_path_get_func_t)(const uint32 unit,
                                                             const clx_port_t ecmp_port,
                                                             const uint32 path_idx,
                                                             clx_l2_ecmp_path_t *ptr_path_info);

/* Set grp hsh */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_path_hsh_set_func_t)(
    const uint32 unit,
    const clx_l3_ecmp_path_hsh_t *ptr_hsh_set);

/* Get grp hsh */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_path_hsh_get_func_t)(
    const uint32 unit,
    clx_l3_ecmp_path_hsh_t *ptr_hsh_get);

/* Dump Group Path List */
typedef clx_error_no_t (*hal_cmn_l3_l2_ecmp_path_dump_func_t)(const uint32 unit,
                                                              const clx_port_t ecmp_port);

/* Set cpu di */
typedef clx_error_no_t (*hal_cmn_l3_cpu_di_set_func_t)(const uint32 unit,
                                                       const uint32 cpu_id,
                                                       const uint32 cpu_queue);

typedef clx_error_no_t (*hal_cmn_l3_mcast_lag_bmp_get_func_t)(const uint32 unit,
                                                              const uint32 mcast_id,
                                                              HAL_LAGID_BITMAP_T lagid_bitmap);
typedef clx_error_no_t (*hal_cmn_l3_frr_get_func_t)(const uint32 unit,
                                                    const uint32 frr_id,
                                                    hal_l3_frr_t *frr);
/* tunnel multiplexing functions start */

typedef clx_error_no_t (*hal_cmn_tnl_flex_tnl_udf_cfg_func_t)(const uint32 unit,
                                                              const uint32 index,
                                                              const uint32 flags);

typedef clx_error_no_t (*hal_cmn_tnl_cfg_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_tnl_excpt_act_set_func_t)(const uint32 unit,
                                                           const clx_swc_cfg_t property,
                                                           clx_fwd_action_t action);

typedef clx_error_no_t (*hal_cmn_tnl_excpt_act_get_func_t)(const uint32 unit,
                                                           const clx_swc_cfg_t property,
                                                           clx_fwd_action_t *ptr_action);

typedef clx_error_no_t (*hal_cmn_tnl_tnl_to_list_trav_func_t)(const uint32 unit,
                                                              const hal_tnl_trav_type_t type,
                                                              util_lib_list_t *ptr_list);

typedef clx_error_no_t (*hal_cmn_tnl_cfg_ecmp_path_by_nvo3_adj_info_func_t)(
    const uint32 unit,
    const uint32 ecmp_path_idx,
    const clx_port_t port);

typedef clx_error_no_t (*hal_cmn_tnl_trans_nvo3_adj_to_ecmp_path_func_t)(const uint32 unit,
                                                                         const uint32 nvo3_adj_id,
                                                                         tob_fvp_t *ptr_path_info,
                                                                         uint32 *ptr_buf);

typedef clx_error_no_t (*hal_cmn_tnl_ip_sa_idx_alloc_func_t)(const uint32 unit,
                                                             const boolean is_ipv4,
                                                             const clx_ip_addr_t *ptr_src_ip,
                                                             uint32 *ptr_idx);

typedef clx_error_no_t (*hal_cmn_tnl_ip_sa_idx_free_func_t)(const uint32 unit,
                                                            const boolean is_ipv4,
                                                            const uint32 idx);
typedef clx_error_no_t (*hal_cmn_tnl_ip_da_idx_alloc_func_t)(
    const uint32 unit,
    const boolean is_ipv4,
    const clx_ip_addr_t *ptr_dst_ip,
    const boolean is_seglist,
    const clx_srv6_sidlist_t *ptr_segment_list,
    uint32 *ptr_idx);

typedef clx_error_no_t (*hal_cmn_tnl_ip_da_idx_free_func_t)(const uint32 unit,
                                                            const boolean is_ipv4,
                                                            const boolean is_seglist,
                                                            const uint32 segments_left,
                                                            const uint32 idx);

typedef clx_error_no_t (*hal_cmn_tnl_dst_tep_idx_alloc_func_t)(const uint32 unit,
                                                               const boolean is_ipv4,
                                                               uint32 *ptr_idx);

typedef clx_error_no_t (*hal_cmn_tnl_dst_tep_idx_free_func_t)(const uint32 unit,
                                                              const boolean is_ipv4,
                                                              const uint32 idx);

typedef clx_error_no_t (*hal_cmn_tnl_psr_en_set_func_t)(const uint32 unit,
                                                        const clx_tnl_psr_type_t type,
                                                        const uint32 slice_bmp_en);

typedef clx_error_no_t (*hal_cmn_tnl_psr_en_get_func_t)(const uint32 unit,
                                                        const clx_tnl_psr_type_t type,
                                                        uint32 *slice_bmp_en);

typedef clx_error_no_t (*hal_cmn_tnl_ipv6_ext_set_func_t)(const uint32 unit,
                                                          const clx_tnl_ipv6_ext_type_t type,
                                                          const uint32 optValue);
typedef clx_error_no_t (*hal_cmn_tnl_ipv6_ext_get_func_t)(const uint32 unit,
                                                          const clx_tnl_ipv6_ext_type_t type,
                                                          uint32 *ptr_optValue);

typedef clx_error_no_t (*hal_cmn_tnl_vxlan_ra_chk_set_func_t)(const uint32 unit,
                                                              const uint32 enable);

typedef clx_error_no_t (*hal_cmn_tnl_vxlan_ra_chk_get_func_t)(const uint32 unit,
                                                              uint32 *ptr_enable);

typedef clx_error_no_t (*hal_cmn_tnl_nvgre_ra_chk_set_func_t)(const uint32 unit,
                                                              const uint32 enable);

typedef clx_error_no_t (*hal_cmn_tnl_nvgre_ra_chk_get_func_t)(const uint32 unit,
                                                              uint32 *ptr_enable);

typedef clx_error_no_t (*hal_cmn_tnl_vxlan_udp_port_set_func_t)(const uint32 unit,
                                                                const uint32 dport);

typedef clx_error_no_t (*hal_cmn_tnl_vxlan_udp_port_get_func_t)(const uint32 unit,
                                                                uint32 *ptr_dport);

/* srv6 multiplexing functions start */
typedef clx_error_no_t (*hal_cmn_srv6_cfg_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_srv6_warm_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_srv6_warm_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_srv6_egr_lcl_intf_cfg_func_t)(
    const uint32 unit,
    const hal_cmn_action_t hwdb_action,
    const clx_srv6_encap_cfg_t *ptr_encap_info,
    const uint32 rwi_rslt_lcl_idx);

typedef clx_error_no_t (*hal_cmn_srv6_igr_lcl_intf_cfg_func_t)(
    const uint32 unit,
    const hal_cmn_action_t hwdb_action,
    const clx_srv6_local_cfg_t *ptr_local_info,
    const uint32 dis_rslt_lcl_idx);

typedef clx_error_no_t (*hal_cmn_pkt_initreasonmap_func_t)(const uint32 unit);

/* telm multiplexing functions start */
typedef clx_error_no_t (*hal_cmn_telm_getswccfg_func_t)(const uint32 unit,
                                                        const clx_swc_cfg_t property,
                                                        uint32 *ptr_param0,
                                                        uint32 *ptr_param1);

typedef clx_error_no_t (*hal_cmn_telm_setswccfg_func_t)(const uint32 unit,
                                                        const clx_swc_cfg_t property,
                                                        const uint32 param0,
                                                        const uint32 param1);

typedef clx_error_no_t (*hal_cmn_cia_ucp_cfg_set_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t type,
                                                         const uint32 tbl_id,
                                                         const uint32 ucp_id,
                                                         const hal_ucp_frm_type_t frame_type,
                                                         uint32 *ptr_buf);

typedef clx_error_no_t (*hal_cmn_cia_hw_entry_read_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 entry_1x_id,
    const uint32 norm_width,
    uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

typedef clx_error_no_t (*hal_cmn_cia_hw_entry_del_func_t)(const uint32 unit,
                                                          const clx_cia_stage_t stage,
                                                          const uint32 entry_1x_id,
                                                          const uint32 norm_width);

typedef clx_error_no_t (*hal_cmn_cia_hw_entry_move_func_t)(const uint32 unit,
                                                           const clx_cia_stage_t stage,
                                                           const uint32 tbl_id,
                                                           const int32 src_1x_entry_id,
                                                           const int32 dst_1x_entry_id,
                                                           const uint32 tot_1x_move_entry_num,
                                                           const drv_dma_d2d_dir_t d2d_dir,
                                                           const uint32 shift_cnt,
                                                           const uint32 cont_move);

typedef clx_error_no_t (*hal_cmn_cia_move_tbl_id_get_func_t)(const uint32 unit,
                                                             const clx_cia_stage_t stage,
                                                             const uint32 norm_width,
                                                             uint32 *ptr_tbl_id);

typedef clx_error_no_t (*hal_cmn_cia_grp_chk_func_t)(const uint32 unit,
                                                     const clx_cia_stage_t stage,
                                                     const uint32 pri,
                                                     const clx_cia_grp_prof_t *ptr_grp_prof);

typedef clx_error_no_t (*hal_cmn_cia_grp_add_func_t)(const uint32 unit,
                                                     const clx_cia_stage_t stage,
                                                     const uint32 pri,
                                                     const clx_cia_grp_prof_t *ptr_grp_prof,
                                                     uint32 *ptr_grp_id);

typedef clx_error_no_t (*hal_cmn_cia_grp_set_func_t)(const uint32 unit,
                                                     const clx_cia_stage_t stage,
                                                     const uint32 pri,
                                                     const clx_cia_grp_prof_t *ptr_grp_prof,
                                                     uint32 grp_id);

typedef clx_error_no_t (*hal_cmn_cia_exact_grp_chk_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 pri,
    const clx_cia_exact_grp_prof_t *ptr_grp_prof);

typedef clx_error_no_t (*hal_cmn_cia_exact_grp_add_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 pri,
    const clx_cia_exact_grp_prof_t *ptr_grp_prof,
    uint32 *ptr_grp_id);

typedef clx_error_no_t (*hal_cmn_cia_exact_grp_set_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 pri,
    const clx_cia_exact_grp_prof_t *ptr_grp_prof,
    uint32 grp_id);

typedef clx_error_no_t (*hal_cmn_cia_ucp_reset_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       uint32 ucp_bmp);

typedef clx_error_no_t (*hal_cmn_cia_exact_preempt_entry_chk_func_t)(const uint32 unit,
                                                                     const uint32 grp_id,
                                                                     const uint32 ucp_member_bmp,
                                                                     uint32 *ptr_exact_entry);

typedef clx_error_no_t (*hal_cmn_cia_exact_preempt_entry_free_func_t)(const uint32 unit,
                                                                      const uint32 ucp_member_bmp);

typedef clx_error_no_t (*hal_cmn_cia_grp_enable_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t stage,
                                                        const uint32 grp,
                                                        const uint32 enable);

typedef clx_error_no_t (*hal_cmn_cia_grp_prof_get_func_t)(const uint32 unit,
                                                          const clx_cia_stage_t stage,
                                                          const uint32 grp_id,
                                                          const uint32 ucp_member_bmp,
                                                          clx_cia_grp_prof_t *ptr_grp_prof);

typedef clx_error_no_t (*hal_cmn_cia_exact_grp_prof_get_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 grp_id,
    const uint32 ucp_member_bmp,
    clx_cia_exact_grp_prof_t *ptr_grp_prof);

typedef clx_error_no_t (*hal_cmn_cia_exact_entry_del_func_t)(
    const uint32 unit,
    const uint32 grp_id,
    hal_cia_exact_entry_info_t *ptr_entry_info);

typedef clx_error_no_t (*hal_cmn_cia_sw_entry_info_get_func_t)(const uint32 unit,
                                                               const uint32 entry_id,
                                                               clx_cia_stage_t *ptr_stage,
                                                               uint32 *ptr_sw_entry_id);

typedef clx_error_no_t (*hal_cmn_cia_entry_id_alloc_func_t)(const uint32 unit,
                                                            const clx_cia_stage_t stage,
                                                            const uint32 group_id,
                                                            const uint32 entry_pri,
                                                            uint32 *ptr_enrty_id);
typedef clx_error_no_t (*hal_cmn_cia_ucp_num_get_func_t)(const uint32 unit,
                                                         clx_cia_stage_t stage,
                                                         uint32 *ptr_ucp_num);

typedef clx_error_no_t (*hal_cmn_cia_l3_proto_psr_set_func_t)(const uint32 unit,
                                                              const clx_cia_cfg_l3_proto_type_t type,
                                                              const uint32 enable);
typedef clx_error_no_t (*hal_cmn_cia_l3_proto_psr_get_func_t)(const uint32 unit,
                                                              const clx_cia_cfg_l3_proto_type_t type,
                                                              uint32 *ptr_enable);
typedef clx_error_no_t (*hal_cmn_cia_global_parameter_set_func_t)(const uint32 unit,
                                                                  const clx_swc_cfg_t type,
                                                                  const uint32 param0,
                                                                  const uint32 param1);
typedef clx_error_no_t (*hal_cmn_cia_global_parameter_get_func_t)(const uint32 unit,
                                                                  const clx_swc_cfg_t type,
                                                                  uint32 *ptr_param0,
                                                                  uint32 *ptr_param1);

typedef clx_error_no_t (*hal_cmn_cia_entry_alloc_rsrc_free_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const hal_cia_entry_alloc_info_t *ptr_alloc_info);

typedef clx_error_no_t (*hal_cmn_cia_ucp_pbm_en_get_func_t)(const uint32 unit,
                                                            const clx_cia_stage_t stage,
                                                            const uint32 group,
                                                            uint32 *ptr_ucp_pbm_en);

typedef clx_error_no_t (*hal_cmn_cia_pkg_prof_set_func_t)(const uint32 unit,
                                                          const clx_cia_stage_t stage,
                                                          const uint32 udf_prof_id,
                                                          const clx_cia_udf_prof_t *ptr_profile,
                                                          uint32 *ptr_cia_pkg_vld,
                                                          uint32 *ptr_pkg_0_cnt,
                                                          uint32 *ptr_pkg_1_cnt,
                                                          uint32 *ptr_pkg_0_consecutive_bmp,
                                                          uint32 *ptr_pkg_1_consecutive_bmp);

typedef clx_error_no_t (*hal_cmn_cia_exact_pkg_prof_set_func_t)(
    const uint32 unit,
    const uint32 udf_prof_id,
    const clx_cia_udf_prof_t *ptr_profile,
    uint32 *ptr_exact_pkg_vld,
    uint32 *ptr_consecutive_bmp);

typedef clx_error_no_t (*hal_cmn_cia_pkg_lou_prof_idx_set_func_t)(const uint32 unit,
                                                                  const clx_cia_stage_t stage,
                                                                  const uint32 udf_prof_id,
                                                                  const uint32 exact_pkg_vld,
                                                                  const uint32 pkg_vld,
                                                                  const uint32 lou_vld);

typedef clx_error_no_t (*hal_cmn_cia_tcam_pkg_lou_set_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 udf_key_profile_id,
    const boolean valid,
    const clx_cia_pkt_format_t *ptr_pkt_format);

typedef clx_error_no_t (*hal_cmn_cia_pkt_format_get_func_t)(const uint32 unit,
                                                            const clx_cia_stage_t stage,
                                                            const uint32 udf_prof_id,
                                                            const hal_cia_udf_info_t *ptr_udf_info,
                                                            clx_cia_pkt_format_t *ptr_pkt_format);

typedef clx_error_no_t (*hal_cmn_cia_pkg_prof_get_func_t)(const uint32 unit,
                                                          const clx_cia_stage_t stage,
                                                          const uint32 cia_pkg_prof_idx,
                                                          const uint32 cia_pkg_prof_vld,
                                                          const hal_cia_udf_info_t *ptr_udf_info,
                                                          clx_cia_udf_prof_t *ptr_profile);

typedef clx_error_no_t (*hal_cmn_cia_exact_pkg_prof_get_func_t)(
    const uint32 unit,
    const uint32 exact_pkg_prof_idx,
    const hal_cia_udf_info_t *ptr_udf_info,
    clx_cia_udf_prof_t *ptr_profile);

typedef clx_error_no_t (*hal_cmn_cia_pkg_lou_prof_idx_get_func_t)(const uint32 unit,
                                                                  const clx_cia_stage_t stage,
                                                                  const uint32 udf_prof_id,
                                                                  uint32 *ptr_exact_pkg_prof_vld,
                                                                  uint32 *ptr_exact_pkg_prof_idx,
                                                                  uint32 *ptr_cia_pkg_prof_vld,
                                                                  uint32 *ptr_cia_pkg_prof_idx,
                                                                  uint32 *ptr_lou_prof_vld,
                                                                  uint32 *ptr_lou_prof_idx);

typedef clx_error_no_t (*hal_cmn_cia_hw_entry_vld_set_func_t)(const uint32 unit,
                                                              const clx_cia_stage_t stage,
                                                              const uint32 hw_entry_id,
                                                              const uint32 norm_width,
                                                              const boolean entry_vld);

typedef clx_error_no_t (*hal_cmn_cia_cont_hw_entry_clear_func_t)(const uint32 unit,
                                                                 const clx_cia_stage_t stage,
                                                                 const uint32 start_1x_entry,
                                                                 const uint32 last_1x_entry);

typedef clx_error_no_t (*hal_cmn_cia_grp_enable_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t type,
                                                        const uint32 group,
                                                        const uint32 enable);

typedef clx_error_no_t (*hal_cmn_cia_udf_key_info_get_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 group,
    const clx_cia_classify_t *ptr_classify,
    hal_cia_entry_pack_udf_key_t *ptr_udf_key);

typedef clx_error_no_t (*hal_cmn_cia_hw_entry_add_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 entry_1x_id,
    const uint32 norm_width,
    const hal_cia_plane_bcast_info_t *ptr_bcast_info,
    uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

typedef clx_error_no_t (*hal_cmn_cia_range_prof_get_func_t)(
    const uint32 unit,
    const clx_cia_stage_t type,
    const uint32 udf_prof_id,
    const uint32 range_id,
    const hal_cia_range_info_t *ptr_range_info,
    clx_cia_range_cfg_t *ptr_range);

typedef clx_error_no_t (*hal_cmn_cia_range_prof_set_func_t)(const uint32 unit,
                                                            const clx_cia_stage_t type,
                                                            const uint32 udf_prof_id,
                                                            const uint32 range_id,
                                                            const clx_cia_range_cfg_t *ptr_range);

typedef clx_error_no_t (*hal_cmn_cia_range_prof_clear_func_t)(const uint32 unit,
                                                              const clx_cia_stage_t type,
                                                              const uint32 udf_prof_id,
                                                              const uint32 range_id);

typedef clx_error_no_t (*hal_cmn_cia_cia_pkg_prof_range_info_get_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 cia_pkg_prof_idx,
    uint32 *ptr_cia_int_lou_vld,
    uint32 *ptr_cia_lou_en);

typedef clx_error_no_t (*hal_cmn_cia_exact_pkg_prof_range_info_get_func_t)(
    const uint32 unit,
    const uint32 exact_pkg_prof_idx,
    uint32 *ptr_exact_int_lou_vld,
    uint32 *ptr_exact_lou_en);

typedef clx_error_no_t (*hal_cmn_cia_free_ucp_pbm_get_func_t)(const uint32 unit,
                                                              const clx_cia_stage_t stage,
                                                              uint32 *ucp_num,
                                                              uint32 *free_ucp_bmp);

typedef clx_error_no_t (*hal_cmn_cia_ucp_to_grp_add_func_t)(const uint32 unit,
                                                            const clx_cia_stage_t stage,
                                                            const uint32 group,
                                                            const uint32 new_ucp);

typedef clx_error_no_t (*hal_cmn_cia_grp_enable_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t stage,
                                                        const uint32 group,
                                                        const uint32 enable);

typedef clx_error_no_t (*hal_cmn_cia_exact_entry_get_func_t)(
    const uint32 unit,
    const hal_cia_exact_entry_info_t *ptr_entry_info,
    clx_cia_exact_classify_t *ptr_classify,
    clx_cia_act_t *ptr_act);

typedef clx_error_no_t (*hal_cmn_cia_ecmp_info_update_func_t)(const uint32 unit,
                                                              const uint32 ecmp_group_id,
                                                              const hal_l3_ecmp_t *ptr_ecmp_info);

typedef clx_error_no_t (*hal_cmn_cia_adj_info_update_func_t)(const uint32 unit,
                                                             const uint32 adj_id,
                                                             const hal_l3_adj_info_t *ptr_adj_info);

typedef clx_error_no_t (*hal_cmn_cia_cfg_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_cia_exact_entry_id_info_get_func_t)(const uint32 unit,
                                                                     const uint32 hw_entry_id,
                                                                     clx_cia_stage_t *ptr_type,
                                                                     uint32 *ptr_group_id);

typedef clx_error_no_t (*hal_cmn_cia_exact_grp_entry_cap_usage_get_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 group_id,
    const uint32 get_capacity,
    uint32 *ptr_cnt);
typedef clx_error_no_t (*hal_cmn_cia_tapping_tpid_set_func_t)(const uint32 unit,
                                                              const clx_swc_cfg_t property,
                                                              const uint32 tpid);
typedef clx_error_no_t (*hal_cmn_cia_tapping_tpid_get_func_t)(const uint32 unit,
                                                              const clx_swc_cfg_t property,
                                                              uint32 *tpid);
typedef clx_error_no_t (*hal_cmn_cia_rim_fcm_idx_alloc_func_t)(const uint32 unit,
                                                               const uint32 is_flw,
                                                               uint32 *ptr_index);
typedef clx_error_no_t (*hal_cmn_cia_rim_fcm_idx_free_func_t)(const uint32 unit,
                                                              const uint32 is_flw,
                                                              const uint32 index);
typedef clx_error_no_t (*hal_cmn_cia_rim_fcm_act_set_func_t)(const uint32 unit,
                                                             const uint32 is_flw,
                                                             const uint32 index,
                                                             const void *ptr_action);
typedef clx_error_no_t (*hal_cmn_cia_rim_fcm_act_get_func_t)(const uint32 unit,
                                                             const uint32 is_flw,
                                                             const uint32 index,
                                                             const void *ptr_action);
typedef clx_error_no_t (*hal_cmn_cia_rim_fcm_act_trav_func_t)(const uint32 unit,
                                                              const uint32 is_flw,
                                                              const clx_cia_rim_trav_func_t callback,
                                                              void *ptr_cookie);

typedef clx_error_no_t (*hal_cmn_cia_rim_redir_idx_alloc_func_t)(const uint32 unit,
                                                                 const clx_cia_rim_alloc_t type,
                                                                 uint32 *ptr_index);

typedef clx_error_no_t (*hal_cmn_cia_rim_redir_idx_free_func_t)(const uint32 unit,
                                                                const clx_cia_rim_alloc_t type,
                                                                const uint32 index);

typedef clx_error_no_t (*hal_cmn_cia_rim_redir_idx_set_func_t)(
    const uint32 unit,
    const clx_cia_rim_alloc_t type,
    const uint32 index,
    const clx_cia_redir_act_t *ptr_redir_act);

typedef clx_error_no_t (*hal_cmn_cia_rim_redir_idx_get_func_t)(const uint32 unit,
                                                               const clx_cia_rim_alloc_t type,
                                                               const uint32 index,
                                                               clx_cia_redir_act_t *ptr_redir_act);

typedef clx_error_no_t (*hal_cmn_cia_rim_redir_idx_trav_func_t)(
    const uint32 unit,
    const clx_cia_rim_alloc_t type,
    const clx_cia_rim_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_cmn_cia_entry_unpack_func_t)(const uint32 unit,
                                                          const clx_cia_stage_t stage,
                                                          const hal_cia_entry_info_t *ptr_entry_info,
                                                          boolean *ptr_entry_valid,
                                                          clx_cia_classify_t *ptr_classify,
                                                          clx_cia_act_t *ptr_action);

typedef clx_error_no_t (*hal_cmn_meter_cfg_init_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_meter_cfg_reg_set_t)(const uint32 unit,
                                                      const hal_meter_type_t type,
                                                      const uint32 bank_idx,
                                                      const boolean enable);

typedef clx_error_no_t (*hal_cmn_meter_hwidx_trans_t)(const uint32 unit,
                                                      const hal_meter_index_t *ptr_hw_index,
                                                      uint32 *ptr_hw_idx);

typedef clx_error_no_t (*hal_cmn_meter_index_trans_t)(const uint32 unit,
                                                      const uint32 hw_idx,
                                                      hal_meter_index_t *ptr_hw_index);

typedef clx_error_no_t (*hal_cmn_meter_pool_set_t)(const uint32 unit,
                                                   const hal_meter_sw_meter_t *ptr_sw_meter);

typedef clx_error_no_t (*hal_cmn_meter_port_cfg_set_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const uint32 layer1_len);

typedef clx_error_no_t (*hal_cmn_meter_port_cfg_get_t)(const uint32 unit,
                                                       const uint32 port,
                                                       uint32 *layer1_len);

typedef clx_error_no_t (*hal_cmn_sflow_set_igr_cfg_sflw_mir_func_t)(const uint32 unit,
                                                                    const uint32 profile_id,
                                                                    const uint32 sflw_mir_en,
                                                                    const uint32 sflw_mir_bidx);

typedef clx_error_no_t (*hal_cmn_sflow_get_igr_cfg_sflw_mir_func_t)(const uint32 unit,
                                                                    const uint32 profile_id,
                                                                    uint32 *ptr_sflw_mir_en,
                                                                    uint32 *ptr_sflw_mir_bidx);

typedef clx_error_no_t (*hal_cmn_sflow_set_egr_cfg_sflw_mir_func_t)(const uint32 unit,
                                                                    const uint32 profile_id,
                                                                    const uint32 sflw_mir_en,
                                                                    const uint32 sflw_mir_bidx);

typedef clx_error_no_t (*hal_cmn_sflow_get_egr_cfg_sflw_mir_func_t)(const uint32 unit,
                                                                    const uint32 profile_id,
                                                                    uint32 *ptr_sflw_mir_en,
                                                                    uint32 *ptr_sflw_mir_bidx);

typedef clx_error_no_t (*hal_cmn_sflow_set_igr_cfg_sflw_func_t)(const uint32 unit,
                                                                const uint32 profile_id,
                                                                const uint32 sflw_splr_threshold);

typedef clx_error_no_t (*hal_cmn_sflow_set_egr_cfg_sflw_func_t)(const uint32 unit,
                                                                const uint32 profile_id,
                                                                const uint32 sflw_splr_threshold);

typedef clx_error_no_t (*hal_cmn_sflow_set_high_latency_cfg_func_t)(const uint32 unit,
                                                                    const uint32 threshold,
                                                                    const uint32 sflw_lat_en);

typedef clx_error_no_t (*hal_cmn_sflow_init_cfg_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_lag_init_cfg_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_swc_cfg_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_swc_hsh_tile_bmp_get_func_t)(
    const uint32 unit,
    const clx_swc_hsh_tile_type_t hash_tile_type,
    hal_swc_hsh_tile_bmp_t ptr_bitmap);

typedef clx_error_no_t (*hal_cmn_swc_tcam_bmp_get_func_t)(const uint32 unit,
                                                          const clx_swc_tcam_type_t tcam_type,
                                                          hal_swc_tcam_bmp_t ptr_bitmap);

typedef clx_error_no_t (*hal_cmn_swc_rsn_bloom_filter_set_func_t)(
    const uint32 unit,
    const clx_swc_cfg_rsn_bloom_filter_type_t bloom_filter_type,
    const uint32 bloom_filter_value);

typedef clx_error_no_t (*hal_cmn_swc_rsn_bloom_filter_get_func_t)(
    const uint32 unit,
    const clx_swc_cfg_rsn_bloom_filter_type_t bloom_filter_type,
    uint32 *bloom_filter_value);

typedef clx_error_no_t (*hal_cmn_swc_mod_epp_rsn_set_func_t)(const uint32 unit, boolean enable);

typedef clx_error_no_t (*hal_cmn_swc_mod_drop_rsn_set_func_t)(const uint32 unit, boolean enable);

typedef clx_error_no_t (*hal_cmn_qos_wb_init_func_t)(const uint32 unit, hal_io_wb_db_t *ptr_db);

typedef clx_error_no_t (*hal_cmn_qos_wb_deinit_func_t)(const uint32 unit,
                                                       hal_io_obj_meta_t *ptr_wbdb_obj,
                                                       uint32 *ptr_obj_count);

typedef clx_error_no_t (*hal_cmn_qos_cfg_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_qos_rsrc_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_qos_mapping_prof_cfg_alloc_func_t)(
    const uint32 unit,
    const clx_dir_t direction,
    const clx_qos_mapping_type_t mapping_type,
    const uint32 profile_id);

typedef clx_error_no_t (*hal_cmn_qos_mapping_prof_cfg_free_func_t)(
    const uint32 unit,
    const clx_dir_t direction,
    const clx_qos_mapping_type_t mapping_type,
    const uint32 profile_id);

typedef clx_error_no_t (*hal_cmn_qos_user_prof_cfg_set_func_t)(
    const uint32 unit,
    const clx_dir_t direction,
    const clx_qos_mapping_type_t mapping_type,
    const uint32 profile_id,
    const clx_qos_mapping_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_cmn_qos_prof_apply_func_t)(const uint32 unit,
                                                        const clx_dir_t direction,
                                                        const hal_qos_intf_type_t intf_type,
                                                        const clx_qos_mapping_type_t mapping_type,
                                                        const uint32 profile_id,
                                                        uint32 *ptr_phb_prof_idx);

typedef clx_error_no_t (*hal_cmn_qos_user_prof_idx_get_func_t)(
    const uint32 unit,
    const clx_dir_t direction,
    const clx_qos_mapping_type_t mapping_type,
    const uint32 qos_prof_id,
    uint32 *ptr_profile_id);

typedef clx_error_no_t (*hal_cmn_qos_acl_qos_prof_alloc_func_t)(
    const uint32 unit,
    const clx_cia_qos_act_t acl_qos_action,
    uint32 *ptr_profile_idx);

typedef clx_error_no_t (*hal_cmn_qos_acl_qos_prof_free_func_t)(const uint32 unit,
                                                               const uint32 profile_id);

typedef clx_error_no_t (*hal_cmn_qos_acl_qos_prof_get_func_t)(const uint32 unit,
                                                              const uint32 profile_id,
                                                              clx_cia_qos_act_t *ptr_qos_action);
typedef clx_error_no_t (*hal_cmn_qos_getaclqosprofile_func_t)(const uint32 unit,
                                                              const uint32 profile_id,
                                                              clx_cia_qos_act_t *ptr_qos_action);
typedef clx_error_no_t (*hal_cmn_qos_cpy_to_2nd_set_func_t)(const uint32 unit, const uint32 to_2nd);

typedef clx_error_no_t (*hal_cmn_qos_cpy_to_2nd_get_func_t)(const uint32 unit, uint32 *ptr_to_2nd);

typedef clx_error_no_t (*hal_cmn_efuse_read_func_t)(const uint32 unit,
                                                    const hal_efuse_page_t page,
                                                    const uint32 addr,
                                                    uint32 *ptr_val);

typedef clx_error_no_t (*hal_cmn_efuse_write_func_t)(const uint32 unit,
                                                     const hal_efuse_page_t page,
                                                     const uint32 addr,
                                                     const uint32 bit_offset,
                                                     const uint32 bit_len,
                                                     const uint32 value);

typedef clx_error_no_t (*hal_cmn_efuse_dump_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_sflow_alloc_profile_func_t)(const uint32 unit,
                                                             const hal_sflow_src_type_t src_type,
                                                             const hal_sflow_dst_type_t dst_type,
                                                             const uint32 mir_session_id,
                                                             const uint32 profile_id,
                                                             const uint32 sampling_rate,
                                                             const boolean sample_high_latency);

typedef clx_error_no_t (*hal_lag_free_oriact_list_t)(const uint32 unit,
                                                     const uint32 lag_id,
                                                     HAL_LAG_INFO_T *ptr_lag_info);

typedef clx_error_no_t (*hal_lag_alloc_oriact_list_t)(const uint32 unit,
                                                      const uint32 lagid,
                                                      HAL_LAG_INFO_T *ptr_lag_info);

typedef clx_error_no_t (*hal_lag_set_memberportsi_t)(
    const uint32 unit,
    const uint32 lag_di,
    const uint32 add_member_cnt,
    const HAL_LAG_MEMBER_DI_INFO_T *ptr_add_member_di,
    const uint32 del_member_cnt,
    const uint32 *ptr_del_member_di);

typedef clx_error_no_t (*hal_lag_get_info_t)(const uint32 unit,
                                             const uint32 lag_id,
                                             uint32 *ptr_member_cnt,
                                             uint32 *ptr_member_di,
                                             HAL_LAG_INFO_T *ptr_lag_info);

typedef clx_error_no_t (*hal_lag_set_info_t)(const uint32 unit,
                                             const uint32 lag_id,
                                             const HAL_LAG_INFO_T *ptr_lag_info);

typedef clx_error_no_t (*hal_lag_hsh_path_get_func_t)(const uint32 unit,
                                                      const clx_swc_hsh_pkt_type_t hash_type,
                                                      const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                                      const uint32 lag_id,
                                                      clx_lag_hashpath_rslt_info_t *ptr_rslt);

typedef clx_error_no_t (*hal_lag_hsh_path_by_hsh_get_func_t)(const uint32 unit,
                                                             const clx_swc_hsh_pkt_type_t hash_type,
                                                             const uint32 lag_id,
                                                             clx_lag_hashpath_rslt_info_t *ptr_rslt);

typedef clx_error_no_t (*hal_lag_mc_hash_engine_set_t)(const uint32 unit,
                                                       const clx_swc_hsh_pkt_type_t hash_engine);

typedef clx_error_no_t (*hal_lag_mc_hash_engine_get_t)(const uint32 unit,
                                                       clx_swc_hsh_pkt_type_t *ptr_hash_engine);

typedef clx_error_no_t (*hal_cmn_mir_add_local_span_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    const clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_add_rspan_src_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    const clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_add_rspan_dst_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    const clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_add_erspan_src_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    const clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_add_erspan_dst_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    const clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_del_local_span_session_func_t)(const uint32 unit,
                                                                    const uint32 entry_id);

typedef clx_error_no_t (*hal_cmn_mir_del_rspan_src_session_func_t)(const uint32 unit,
                                                                   const uint32 entry_id);

typedef clx_error_no_t (*hal_cmn_mir_del_rspan_dst_session_func_t)(const uint32 unit,
                                                                   const uint32 entry_id);

typedef clx_error_no_t (*hal_cmn_mir_del_erspan_src_session_func_t)(const uint32 unit,
                                                                    const uint32 entry_id);

typedef clx_error_no_t (*hal_cmn_mir_del_erspan_dst_session_func_t)(const uint32 unit,
                                                                    const uint32 entry_id);

typedef clx_error_no_t (*hal_cmn_mir_set_rspan_dst_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    const clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_set_erspan_src_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    const clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_get_local_span_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_get_rspan_src_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_get_rspan_dst_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_get_erspan_src_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_get_erspan_dst_session_func_t)(
    const uint32 unit,
    const uint32 entry_id,
    clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_add_erspan_term_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_key,
    const uint32 mir_id);

typedef clx_error_no_t (*hal_cmn_mir_del_erspan_term_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_key);

typedef clx_error_no_t (*hal_cmn_mir_find_erspan_term_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_erspan_term_search,
    hal_mir_erspan_term_t **ptr_erspan_term);

typedef clx_error_no_t (*hal_cmn_mir_update_hw_lag_member_func_t)(const uint32 unit,
                                                                  const uint32 port,
                                                                  const uint32 link,
                                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_cmn_mir_init_cfg_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_mir_set_hw_mir_src_port_func_t)(const uint32 unit,
                                                                 const uint32 port,
                                                                 const clx_dir_t dir,
                                                                 const uint32 mir_session_bitmap);

typedef clx_error_no_t (*hal_cmn_mir_get_hw_mir_src_port_func_t)(const uint32 unit,
                                                                 const uint32 port,
                                                                 const clx_dir_t dir,
                                                                 uint32 *ptr_mir_session_bitmap);

typedef clx_error_no_t (*hal_cmn_mir_set_hw_erspan_term_miss_action_func_t)(
    const uint32 unit,
    const uint32 miss_action);

typedef clx_error_no_t (
    *hal_cmn_mir_get_hw_erspan_term_miss_action_func_t)(const uint32 unit, uint32 *ptr_miss_action);

typedef clx_error_no_t (*hal_cmn_mir_update_hw_lag_port_event_func_t)(const uint32 unit,
                                                                      const uint32 event,
                                                                      const clx_port_t lag_port);

typedef clx_error_no_t (*hal_cmn_mir_set_destination_func_t)(const uint32 unit,
                                                             const uint32 entry_id,
                                                             const clx_port_t port);

typedef clx_error_no_t (*hal_cmn_mir_check_parameter_func_t)(
    const uint32 unit,
    const clx_mir_session_cfg_t *ptr_session);

typedef clx_error_no_t (*hal_cmn_mir_set_selective_flow_mir_func_t)(
    const uint32 unit,
    const clx_swc_selective_flow_cfg_t *ptr_select_cfg);

typedef clx_error_no_t (*hal_cmn_mir_get_selective_flow_mir_func_t)(
    const uint32 unit,
    clx_swc_selective_flow_cfg_t *ptr_select_cfg);

typedef clx_error_no_t (*hal_cmn_sec_cfg_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_sec_dos_port_prof_info_get_func_t)(const uint32 unit,
                                                                    const uint32 port,
                                                                    uint32 *ptr_profile_id,
                                                                    uint32 *ptr_ref_cnt);

typedef clx_error_no_t (*hal_cmn_sec_isolation_grp_max_get_func_t)(const uint32 unit,
                                                                   uint32 *ptr_grp_max);

typedef clx_error_no_t (*hal_cmn_stk_rsrc_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_stk_fab_port_bmp_get_func_t)(const uint32 unit,
                                                              uint32 *ptr_pp_pbmp,
                                                              clx_port_bitmap_t cl_pbmp);

typedef clx_error_no_t (*hal_cmn_stk_fab_port_check_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            boolean *ptr_is_fab);
typedef clx_error_no_t (*hal_cmn_stk_cpu_di_property_set_func_t)(
    const uint32 unit,
    const clx_swc_cpu_di_property_t property,
    const uint32 value);
typedef clx_error_no_t (*hal_cmn_stk_cpu_di_property_get_func_t)(
    const uint32 unit,
    const clx_swc_cpu_di_property_t property,
    uint32 *ptr_value);
typedef clx_error_no_t (*hal_cmn_stk_update_by_link_change_func_t)(const uint32 unit,
                                                                   const uint32 port,
                                                                   const boolean enable);

typedef clx_error_no_t (*hal_cmn_stk_fl_hash_sel_set_func_t)(const uint32 unit, const uint32 value);

typedef clx_error_no_t (*hal_cmn_stk_fl_hash_sel_get_func_t)(const uint32 unit, uint32 *ptr_value);

typedef clx_error_no_t (*hal_cmn_stk_cfg_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_port_setmxlink_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const uint32 enable);

typedef clx_error_no_t (*hal_cmn_port_getmxlink_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        uint32 *ptr_enable);
typedef clx_error_no_t (*hal_cmn_port_getinitportbitmap_func_t)(const uint32 unit,
                                                                clx_port_bitmap_t *ptr_bitmap);

typedef clx_error_no_t (*hal_cmn_port_updateportbitmap_func_t)(const uint32 unit,
                                                               clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (*hal_cmn_port_updateintftagmode_func_t)(const uint32 unit,
                                                                const uint32 plane_id,
                                                                const uint32 lcl_intf,
                                                                const uint32 tag_mode);

typedef clx_error_no_t (*hal_cmn_port_getcapacity_func_t)(const uint32 unit,
                                                          const clx_swc_rsrc_t type,
                                                          const uint32 param,
                                                          uint32 *ptr_size);

typedef clx_error_no_t (*hal_cmn_port_getusage_func_t)(const uint32 unit,
                                                       const clx_swc_rsrc_t type,
                                                       const uint32 param,
                                                       uint32 *ptr_cnt);

typedef clx_error_no_t (*hal_cmn_cpu2jtag_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_cpu2jtag_toggle_trst_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cmn_cpu2jtag_check_ir_func_t)(const uint32 unit,
                                                           const char *ir_val,
                                                           const uint32 ir_len);

typedef clx_error_no_t (*hal_cmn_cpu2jtag_check_dr_func_t)(const uint32 unit,
                                                           const char *dr_val,
                                                           const uint32 dr_len,
                                                           const char *exp_dr_val,
                                                           const uint32 exp_dr_len);

typedef clx_error_no_t (*hal_cmn_drv_init_rsrc_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_cmn_drv_init_dma_thread_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_cmn_drv_deinit_dma_thread_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_cmn_drv_init_dma_rsrc_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_cmn_drv_deinit_dma_rsrc_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_cmn_drv_init_dma_intr_func_t)(const uint32 unit);

typedef struct {
    hal_cmn_L2_addr_di_replace_func_t hal_l2_addr_di_replace;
    hal_cmn_l2_phy_mc_id_get_func_t hal_l2_phy_mc_id_get;
    hal_cmn_l2_uncompress_phy_mc_id_get_func_t hal_l2_uncompress_phy_mc_id_get;
    hal_cmn_l2_bum_logical_mc_id_to_phy_id_trans_func_t hal_l2_bum_logical_mc_id_to_phy_id_trans;
    hal_cmn_l2_bum_uncompress_phy_mc_id_get_func_t hal_l2_bum_uncompress_phy_mc_id_get;
    hal_cmn_l2_bum_entry_logical_mc_id_set_func_t hal_l2_bum_entry_logical_mc_id_set;
    hal_cmn_l2_bum_entry_logical_mc_id_get_func_t hal_l2_bum_entry_logical_mc_id_get;
    hal_cmn_l2_bum_entry_idx_to_avl_add_func_t hal_l2_bum_entry_idx_to_avl_add;
    hal_cmn_l2_bum_entry_idx_to_avl_del_func_t hal_l2_bum_entry_idx_from_avl_del;
    hal_cmn_l2_uncompress_phy_mc_id_to_logical_id_trans_func_t
        hal_l2_uncompress_phy_mc_id_to_logical_id_trans;
} hal_cmn_l2_func_vec_t;

typedef struct {
    hal_cmn_ifmon_lockdata_func_t hal_ifmon_data_lock;
    hal_cmn_ifmon_unlockdata_func_t hal_ifmon_data_unlock;
    hal_cmn_ifmon_lockflow_func_t hal_ifmon_flow_lock;
    hal_cmn_ifmon_unlockflow_func_t hal_ifmon_flow_unlock;
    hal_cmn_ifmon_getlink_func_t hal_ifmon_link_get;
    hal_cmn_ifmon_getfault_func_t hal_ifmon_fault_get;
    hal_cmn_ifmon_getspeed_func_t hal_ifmon_speed_get;
    hal_cmn_ifmon_addmoclort_func_t hal_ifmon_mon_port_add;
    hal_cmn_ifmon_delmoclort_func_t hal_ifmon_mon_port_del;
    hal_cmn_ifmon_addmoclort_func_t hal_ifmon_mon_anlt_add;
    hal_cmn_ifmon_delmoclort_func_t hal_ifmon_mon_anlt_del;
    hal_cmn_ifmon_recordtime_func_t hal_ifmon_time_record;
    hal_cmn_ifmon_updateswstate_func_t hal_ifmon_sw_state_update;
    hal_cmn_ifmon_dumplinkstate_func_t hal_ifmon_link_state_dump;
} hal_cmn_ifmon_func_vec_t;

typedef struct {
    hal_cmn_tm_speed_set_func_t hal_tm_speed_set;
    hal_cmn_tm_flow_ctrl_mode_set_func_t hal_tm_flow_ctrl_mode_set;
    hal_cmn_tm_port_flush_func_t hal_tm_port_flush;
    hal_cmn_tm_trunc_prof_set_func_t hal_tm_trunc_prof_set;
    hal_cmn_tm_trunc_prof_get_func_t hal_tm_trunc_prof_get;
    hal_cmn_tm_trunc_set_func_t hal_tm_trunc_set;
    hal_cmn_tm_trunc_get_func_t hal_tm_trunc_get;
    hal_cmn_tm_cpa_get_func_t hal_tm_cpa_set;
    hal_cmn_tm_getcpa_func_t hal_tm_cpa_get;
    hal_cmn_tm_xoff_msk_set_func_t hal_tm_xoff_msk_set;
    hal_cmn_tm_buf_dflt_set_func_t hal_tm_buf_dflt_set;
    hal_cmn_tm_pfcwd_state_disable_event_handler_func_t hal_tm_pfcwd_state_disable_event_handler;
    hal_cmn_tm_pfcwd_state_cfg_not_ready_event_handler_func_t
        hal_tm_pfcwd_state_cfg_not_ready_event_handler;
    hal_cmn_tm_pfcwd_state_oper_event_handler_func_t hal_tm_pfcwd_state_oper_event_handler;
    hal_cmn_tm_pfcwd_state_stormed_event_handler_func_t hal_tm_pfcwd_state_stormed_event_handler;
    hal_cmn_tm_fc_show_func_t hal_tm_fc_show;
} hal_cmn_tm_func_vec_t;

typedef struct {
    hal_cmn_telm_getswccfg_func_t hal_telm_getSwcCfg;
    hal_cmn_telm_setswccfg_func_t hal_telm_setSwcCfg;
} hal_cmn_telm_func_vec_t;

typedef struct {
    hal_cmn_mpls_initcfg_func_t hal_mpls_initcfg;
    hal_cmn_mpls_deinitcfg_func_t hal_mpls_deinitcfg;
    hal_cmn_mpls_initwarm_func_t hal_mpls_initwarm;
    hal_cmn_mpls_deinitwarm_func_t hal_mpls_deinitwarm;
    hal_cmn_mpls_pathinfo_get_func_t hal_mpls_pathinfo_get;
    hal_cmn_mpls_getportbypathinfo_func_t hal_mpls_getportbypathinfo;
    hal_cmn_mpls_vpwslagmember_update_func_t hal_mpls_vpwslagmember_update;
} hal_cmn_mpls_func_vet_t;

typedef struct {
    hal_cmn_stat_tm_cnt_get_func_t hal_stat_tm_cnt_get;
    hal_cmn_stat_tm_cnt_clear_func_t hal_stat_tm_cnt_clear;
    hal_cmn_stat_queue_cnt_idx_get_func_t hal_stat_queue_cnt_idx_get;
} hal_cmn_stat_func_vec_t;

typedef struct {
    /* HAL INTF dispatcher */
    hal_cnm_l3_fdid2intf_func_t hal_l3_fdid2intf;
    hal_cnm_l3_intf2fdid_func_t hal_l3_intf2fdid;
    /* HAL VRF dispatcher */
    hal_cnm_l3_glb_route_miss_act_set_fun_t hal_l3_glb_route_miss_act_set;
    hal_cnm_l3_glb_route_miss_act_get_fun_t hal_l3_glb_route_miss_act_get;
    /* HAL HOST dispatcher */
    hal_cmn_l3_host_idx_get_func_t hal_l3_host_idx_get;
    /* HAL ADJ and ECMP dispatcher */
    hal_cmn_l3_adj_info_get_func_t hal_l3_adj_info_get;
    hal_cmn_l3_adj_reference_update_func_t hal_l3_adj_reference_update;
    hal_cmn_l3_ecmp_reference_update_func_t hal_l3_ecmp_reference_update;
    hal_cmn_l3_reference_update_func_t hal_l3_reference_update;
    hal_cmn_l3_ecmp_pathidx_get_by_adjid_func_t hal_l3_ecmp_pathidx_get_by_adjid;
    hal_cmn_l3_ecmp_resilient_set_func_t hal_l3_ecmp_resilient_set;
    hal_cmn_l3_ecmp_resilient_get_func_t hal_l3_ecmp_resilient_get;
    hal_cmn_l3_ecmp_algomode_set_func_t hal_l3_ecmp_algomode_set;
    hal_cmn_l3_ecmp_algomode_get_func_t hal_l3_ecmp_algomode_get;
    hal_cmn_l3_ecmp_hsh_eng_algomode_set_func_t hal_l3_ecmp_hsh_eng_algomode_set;
    hal_cmn_l3_ecmp_hsh_eng_algomode_get_func_t hal_l3_ecmp_hsh_eng_algomode_get;
    hal_cmn_l3_ecmp_grp_max_path_set_func_t hal_l3_ecmp_grp_max_path_set;
    hal_cmn_l3_ecmp_grp_max_path_get_func_t hal_l3_ecmp_grp_max_path_get;
    hal_cmn_l3_ecmp_grp_acl_bind_func_t hal_l3_ecmp_grp_acl_bind;
    hal_cmn_l3_ecmp_grp_acl_unbind_func_t hal_l3_ecmp_grp_acl_unbind;
    /* HAL MCAST dispatcher */
    hal_cmn_l3_mcast_all_mbr_del_func_t hal_l3_mcast_all_mbr_del;
    /* HAL CAPACITY and USAGE dispatcher */
    hal_cmn_l3_capacity_get_func_t hal_l3_capacity_get;
    hal_cmn_l3_usage_get_func_t hal_l3_usage_get;
    hal_cmn_l3_icmp_redirect_get_func_t hal_l3_icmp_redirect_get;
    hal_cmn_l3_icmp_redirect_set_func_t hal_l3_icmp_redirect_set;
    hal_cmn_l3_urpf_check_get_func_t hal_l3_urpf_check_get;
    hal_cmn_l3_urpf_check_set_func_t hal_l3_urpf_check_set;
    hal_cmn_l3_vld_ip_get_func_t hal_l3_vld_ip_get;
    hal_cmn_l3_vld_ip_set_func_t hal_l3_vld_ip_set;
    hal_cmn_l3_excpt_act_get_func_t hal_l3_excpt_act_get;
    hal_cmn_l3_excpt_act_set_func_t hal_l3_excpt_act_set;
    hal_cmn_l3_hdr_err_act_get_func_t hal_l3_hdr_err_act_get;
    hal_cmn_l3_hdr_err_act_set_func_t hal_l3_hdr_err_act_set;
    hal_cmn_l3_fwd_get_func_t hal_l3_fwd_get;
    hal_cmn_l3_nhp_get_func_t hal_l3_nhp_get;
    /* L2 ECMP dispatcher */
    hal_cmn_l3_l2_ecmp_add_func_t hal_l3_l2_ecmp_add;
    hal_cmn_l3_l2_ecmp_del_func_t hal_l3_l2_ecmp_del;
    hal_cmn_l3_l2_ecmp_get_func_t hal_l3_l2_ecmp_get;
    hal_cmn_l3_l2_ecmp_path_add_func_t hal_l3_l2_ecmp_path_add;
    hal_cmn_l3_l2_ecmp_path_del_func_t hal_l3_l2_ecmp_path_del;
    hal_cmn_l3_l2_ecmp_path_get_func_t hal_l3_l2_ecmp_path_get;
    hal_cmn_l3_l2_ecmp_path_hsh_set_func_t hal_l3_l2_ecmp_path_hsh_set;
    hal_cmn_l3_l2_ecmp_path_hsh_get_func_t hal_l3_l2_ecmp_path_hsh_get;
    hal_cmn_l3_l2_ecmp_path_dump_func_t hal_l3_l2_ecmp_path_dump;
    hal_cmn_l3_cpu_di_set_func_t hal_l3_cpu_di_set;
    hal_cmn_l3_mcast_lag_bmp_get_func_t hal_l3_mcast_lag_bmp_get;
    hal_cmn_l3_frr_get_func_t hal_l3_frr_get;
    hal_cmn_l3_mc_lcl_set_func_t hal_l3_mc_lcl_set;
    hal_cmn_l3_mc_lcl_get_func_t hal_l3_mc_lcl_get;
} hal_cmn_l3_func_vec_t;

typedef struct {
    hal_cmn_tnl_flex_tnl_udf_cfg_func_t hal_tnl_flex_tnl_udf_cfg;
    hal_cmn_tnl_cfg_init_func_t hal_tnl_cfg_init;
    hal_cmn_tnl_excpt_act_set_func_t hal_tnl_excpt_act_set;
    hal_cmn_tnl_excpt_act_get_func_t hal_tnl_excpt_act_get;
    hal_cmn_tnl_tnl_to_list_trav_func_t hal_tnl_tnl_to_list_trav;
    hal_cmn_tnl_cfg_ecmp_path_by_nvo3_adj_info_func_t hal_tnl_cfg_ecmp_path_by_nvo3_adj_info;
    hal_cmn_tnl_trans_nvo3_adj_to_ecmp_path_func_t hal_tnl_trans_nvo3_adj_to_ecmp_path;
    hal_cmn_tnl_ip_sa_idx_alloc_func_t hal_tnl_ip_sa_idx_alloc;
    hal_cmn_tnl_ip_sa_idx_free_func_t hal_tnl_ip_sa_idx_free;
    hal_cmn_tnl_ip_da_idx_alloc_func_t hal_tnl_ip_da_idx_alloc;
    hal_cmn_tnl_ip_da_idx_free_func_t hal_tnl_ip_da_idx_free;
    hal_cmn_tnl_dst_tep_idx_alloc_func_t hal_tnl_dst_tep_idx_alloc;
    hal_cmn_tnl_dst_tep_idx_free_func_t hal_tnl_dst_tep_idx_free;
    hal_cmn_tnl_psr_en_set_func_t hal_tnl_psr_en_set;
    hal_cmn_tnl_psr_en_get_func_t hal_tnl_psr_en_get;
    hal_cmn_tnl_ipv6_ext_set_func_t hal_tnl_ipv6_ext_set;
    hal_cmn_tnl_ipv6_ext_get_func_t hal_tnl_ipv6_ext_get;
    hal_cmn_tnl_vxlan_ra_chk_set_func_t hal_tnl_vxlan_ra_chk_set;
    hal_cmn_tnl_vxlan_ra_chk_get_func_t hal_tnl_vxlan_ra_chk_get;
    hal_cmn_tnl_nvgre_ra_chk_set_func_t hal_tnl_nvgre_ra_chk_set;
    hal_cmn_tnl_nvgre_ra_chk_get_func_t hal_tnl_nvgre_ra_chk_get;
    hal_cmn_tnl_vxlan_udp_port_set_func_t hal_tnl_vxlan_udp_port_set;
    hal_cmn_tnl_vxlan_udp_port_get_func_t hal_tnl_vxlan_udp_port_get;
} hal_cmn_tnl_func_vec_t;

typedef struct hal_cmn_srv6_func_vec_s {
    hal_cmn_srv6_cfg_init_func_t hal_srv6_cfg_init;
    hal_cmn_srv6_warm_init_func_t hal_srv6_warm_init;
    hal_cmn_srv6_warm_deinit_func_t hal_srv6_warm_deinit;
    hal_cmn_srv6_egr_lcl_intf_cfg_func_t hal_srv6_egr_lcl_intf_cfg;
    hal_cmn_srv6_igr_lcl_intf_cfg_func_t hal_srv6_igr_lcl_intf_cfg;
} hal_cmn_srv6_func_vec_t;

typedef struct hal_cmn_cia_func_vec_s {
    hal_cmn_cia_rim_fcm_idx_alloc_func_t hal_cia_rim_fcm_idx_alloc;
    hal_cmn_cia_rim_fcm_idx_free_func_t hal_cia_rim_fcm_idx_free;
    hal_cmn_cia_rim_fcm_act_set_func_t hal_cia_rim_fcm_act_set;
    hal_cmn_cia_rim_fcm_act_get_func_t hal_cia_rim_fcm_act_get;
    hal_cmn_cia_rim_fcm_act_trav_func_t hal_cia_rim_fcm_act_trav;
    hal_cmn_cia_rim_redir_idx_alloc_func_t hal_cia_rim_redir_idx_alloc;
    hal_cmn_cia_rim_redir_idx_free_func_t hal_cia_rim_redir_idx_free;
    hal_cmn_cia_rim_redir_idx_set_func_t hal_cia_rim_redir_idx_set;
    hal_cmn_cia_rim_redir_idx_get_func_t hal_cia_rim_redir_idx_get;
    hal_cmn_cia_rim_redir_idx_trav_func_t hal_cia_rim_redir_idx_trav;
    hal_cmn_cia_grp_chk_func_t hal_cia_grp_chk;
    hal_cmn_cia_grp_add_func_t hal_cia_grp_add;
    hal_cmn_cia_grp_set_func_t hal_cia_grp_set;
    hal_cmn_cia_grp_prof_get_func_t hal_cia_grp_prof_get;
    hal_cmn_cia_exact_grp_chk_func_t hal_cia_exact_grp_chk;
    hal_cmn_cia_exact_grp_add_func_t hal_cia_exact_grp_add;
    hal_cmn_cia_exact_grp_set_func_t hal_cia_exact_grp_set;
    hal_cmn_cia_exact_grp_prof_get_func_t hal_cia_exact_grp_prof_get;
    hal_cmn_cia_ucp_reset_func_t hal_cia_ucp_reset;
    hal_cmn_cia_exact_preempt_entry_chk_func_t hal_cia_exact_preempt_entry_chk;
    hal_cmn_cia_exact_preempt_entry_free_func_t hal_cia_exact_preempt_entry_free;
    hal_cmn_cia_grp_enable_func_t hal_cia_grp_enable;
    hal_cmn_cia_exact_entry_del_func_t hal_cia_exact_entry_del;
    hal_cmn_cia_sw_entry_info_get_func_t hal_cia_sw_entry_info_get;
    hal_cmn_cia_entry_id_alloc_func_t hal_cia_entry_id_alloc;
    hal_cmn_cia_pkt_format_get_func_t hal_cia_pkt_format_get;
    hal_cmn_cia_pkg_lou_prof_idx_get_func_t hal_cia_pkg_lou_prof_idx_get;
    hal_cmn_cia_pkg_prof_get_func_t hal_cia_pkg_prof_get;
    hal_cmn_cia_exact_pkg_prof_get_func_t hal_cia_exact_pkg_prof_get;
    hal_cmn_cia_pkg_prof_set_func_t hal_cia_pkg_prof_set;
    hal_cmn_cia_exact_pkg_prof_set_func_t hal_cia_exact_pkg_prof_set;
    hal_cmn_cia_pkg_lou_prof_idx_set_func_t hal_cia_pkg_lou_prof_idx_set;
    hal_cmn_cia_tcam_pkg_lou_set_func_t hal_cia_tcam_pkg_lou_set;
    hal_cmn_cia_hw_entry_vld_set_func_t hal_cia_hw_entry_vld_set;
    hal_cmn_cia_hw_entry_del_func_t hal_cia_hw_entry_del;
    hal_cmn_cia_entry_alloc_rsrc_free_func_t hal_cia_entry_alloc_rsrc_free;
    hal_cmn_cia_entry_unpack_func_t hal_cia_entry_unpack;
    hal_cmn_cia_exact_entry_id_info_get_func_t hal_cia_exact_entry_id_info_get;
    hal_cmn_cia_exact_entry_get_func_t hal_cia_exact_entry_get;
    hal_cmn_cia_cfg_init_func_t hal_cia_cfg_init;
    hal_cmn_cia_cont_hw_entry_clear_func_t hal_cia_cont_hw_entry_clear;
    hal_cmn_cia_hw_entry_add_func_t hal_cia_hw_entry_add;
    hal_cmn_cia_udf_key_info_get_func_t hal_cia_udf_key_info_get;
    hal_cmn_cia_ucp_cfg_set_func_t hal_cia_ucp_cfg_set;
    hal_cmn_cia_hw_entry_read_func_t hal_cia_hw_entry_read;
    hal_cmn_cia_hw_entry_move_func_t hal_cia_hw_entry_move;
    hal_cmn_cia_ucp_pbm_en_get_func_t hal_cia_ucp_pbm_en_get;
    hal_cmn_cia_range_prof_get_func_t hal_cia_range_prof_get;
    hal_cmn_cia_range_prof_set_func_t hal_cia_range_prof_set;
    hal_cmn_cia_range_prof_clear_func_t hal_cia_range_prof_clear;
    hal_cmn_cia_cia_pkg_prof_range_info_get_func_t hal_cia_cia_pkg_prof_range_info_get;
    hal_cmn_cia_exact_pkg_prof_range_info_get_func_t hal_cia_exact_pkg_prof_range_info_get;
    hal_cmn_cia_free_ucp_pbm_get_func_t hal_cia_free_ucp_pbm_get;
    hal_cmn_cia_ucp_to_grp_add_func_t hal_cia_ucp_to_grp_add;
    hal_cmn_cia_ecmp_info_update_func_t hal_cia_ecmp_info_update;
    hal_cmn_cia_adj_info_update_func_t hal_cia_adj_info_update;
    hal_cmn_cia_exact_grp_entry_cap_usage_get_func_t hal_cia_exact_grp_entry_cap_usage_get;
    hal_cmn_cia_tapping_tpid_set_func_t hal_cia_tapping_tpid_set;
    hal_cmn_cia_tapping_tpid_get_func_t hal_cia_tapping_tpid_get;
    hal_cmn_cia_ucp_num_get_func_t hal_cia_ucp_num_get;
    hal_cmn_cia_l3_proto_psr_set_func_t hal_cia_l3_proto_psr_set;
    hal_cmn_cia_l3_proto_psr_get_func_t hal_cia_l3_proto_psr_get;
    hal_cmn_cia_global_parameter_set_func_t hal_cia_global_parameter_set;
    hal_cmn_cia_global_parameter_get_func_t hal_cia_global_parameter_get;
    hal_cmn_cia_move_tbl_id_get_func_t hal_cia_move_tbl_id_get;
} hal_cmn_cia_func_vec_t;

typedef struct {
    hal_cmn_meter_cfg_init_t hal_meter_cfg_init;
    hal_cmn_meter_cfg_reg_set_t hal_meter_cfg_reg_set;
    hal_cmn_meter_hwidx_trans_t hal_meter_hw_idx_trans;
    hal_cmn_meter_index_trans_t hal_meter_index_trans;
    hal_cmn_meter_pool_set_t hal_meter_pool_set;
    hal_cmn_meter_port_cfg_set_t hal_meter_port_cfg_set;
    hal_cmn_meter_port_cfg_get_t hal_meter_port_cfg_get;
} hal_cmn_meter_func_vec_t;

typedef struct hal_cmn_sflow_func_vec_s {
    hal_cmn_sflow_set_igr_cfg_sflw_mir_func_t hal_sflow_igr_cfg_sflow_mir_set;
    hal_cmn_sflow_get_igr_cfg_sflw_mir_func_t hal_sflow_igr_cfg_sflow_mir_get;
    hal_cmn_sflow_set_egr_cfg_sflw_mir_func_t hal_sflow_egr_cfg_sflow_mir_set;
    hal_cmn_sflow_get_egr_cfg_sflw_mir_func_t hal_sflow_egr_cfg_sflow_mir_get;
    hal_cmn_sflow_set_igr_cfg_sflw_func_t hal_sflow_igr_cfg_sflow_set;
    hal_cmn_sflow_set_egr_cfg_sflw_func_t hal_sflow_egr_cfg_sflow_set;
    hal_cmn_sflow_set_high_latency_cfg_func_t hal_sflow_high_latency_cfg_set;
    hal_cmn_sflow_init_cfg_func_t hal_sflow_cfg_init;
    hal_cmn_sflow_alloc_profile_func_t hal_sflow_profile_alloc;
} hal_cmn_sflow_func_vec_t;

typedef struct hal_cmn_mir_func_vec_s {
    hal_cmn_mir_add_local_span_session_func_t hal_mir_local_span_session_add;
    hal_cmn_mir_add_rspan_src_session_func_t hal_mir_rspan_encap_session_add;
    hal_cmn_mir_add_rspan_dst_session_func_t hal_mir_rspan_decap_session_add;
    hal_cmn_mir_add_erspan_src_session_func_t hal_mir_erspan_encap_session_add;
    hal_cmn_mir_add_erspan_dst_session_func_t hal_mir_erspan_decap_session_add;
    hal_cmn_mir_del_local_span_session_func_t hal_mir_local_sapn_session_del;
    hal_cmn_mir_del_rspan_src_session_func_t hal_mir_rspan_encap_session_del;
    hal_cmn_mir_del_rspan_dst_session_func_t hal_mir_rspan_decap_session_del;
    hal_cmn_mir_del_erspan_src_session_func_t hal_mir_erspan_encap_session_del;
    hal_cmn_mir_del_erspan_dst_session_func_t hal_mir_erspan_decap_session_del;
    hal_cmn_mir_set_rspan_dst_session_func_t hal_mir_rspan_decap_session_set;
    hal_cmn_mir_set_erspan_src_session_func_t hal_mir_erspan_encap_session_set;
    hal_cmn_mir_get_local_span_session_func_t hal_mir_local_span_session_get;
    hal_cmn_mir_get_rspan_src_session_func_t hal_mir_rspan_encap_session_get;
    hal_cmn_mir_get_rspan_dst_session_func_t hal_mir_rspan_decap_session_get;
    hal_cmn_mir_get_erspan_src_session_func_t hal_mir_erspan_encap_session_get;
    hal_cmn_mir_get_erspan_dst_session_func_t hal_mir_erspan_decap_session_get;
    hal_cmn_mir_add_erspan_term_func_t hal_mir_ersapn_decap_add;
    hal_cmn_mir_del_erspan_term_func_t hal_mir_erspan_decap_del;
    hal_cmn_mir_find_erspan_term_func_t hal_mir_ersapn_decap_find;
    hal_cmn_mir_update_hw_lag_member_func_t hal_mir_hw_lag_member_update;
    hal_cmn_mir_init_cfg_func_t hal_mir_cfg_init;
    hal_cmn_mir_set_hw_mir_src_port_func_t hal_mir_hw_mir_src_port_set;
    hal_cmn_mir_get_hw_mir_src_port_func_t hal_mir_hw_mir_src_port_get;
    hal_cmn_mir_set_hw_erspan_term_miss_action_func_t hal_mir_hw_erspan_decap_miss_action_set;
    hal_cmn_mir_get_hw_erspan_term_miss_action_func_t hal_mir_hw_erspan_decap_miss_action_get;
    hal_cmn_mir_update_hw_lag_port_event_func_t hal_mir_hw_lag_port_event_update;
    hal_cmn_mir_set_destination_func_t hal_mir_destination_set;
    hal_cmn_mir_check_parameter_func_t hal_mir_parameter_check;
    hal_cmn_mir_set_selective_flow_mir_func_t hal_mir_selective_flow_mir_set;
    hal_cmn_mir_get_selective_flow_mir_func_t hal_mir_selective_flow_mir_get;
} hal_cmn_mir_func_vec_t;

typedef struct {
    hal_cmn_lag_init_cfg_func_t hal_lag_initCfg;
    hal_lag_free_oriact_list_t hal_lag_freeOriActList;
    hal_lag_alloc_oriact_list_t hal_lag_allocOriActList;
    hal_lag_set_memberportsi_t hal_lag_setMemberPortSi;
    hal_lag_get_info_t hal_lag_getInfo;
    hal_lag_set_info_t hal_lag_setInfo;
    hal_lag_mc_hash_engine_set_t hal_lag_mc_hash_engine_set;
    hal_lag_mc_hash_engine_get_t hal_lag_mc_hash_engine_get;
    hal_lag_hsh_path_get_func_t hal_lag_hsh_path_get;
    hal_lag_hsh_path_by_hsh_get_func_t hal_lag_hsh_path_by_hsh_get;
} hal_cmn_lag_func_vec_t;

typedef struct {
    hal_cmn_swc_cfg_init_func_t hal_swc_cfg_init;
    hal_cmn_swc_hsh_tile_bmp_get_func_t hal_swc_hsh_tile_bmp_get;
    hal_cmn_swc_tcam_bmp_get_func_t hal_swc_tcam_bmp_get;
    hal_cmn_swc_rsn_bloom_filter_set_func_t hal_swc_rsn_bloom_filter_set;
    hal_cmn_swc_rsn_bloom_filter_get_func_t hal_swc_rsn_bloom_filter_get;
    hal_cmn_swc_mod_epp_rsn_set_func_t hal_swc_mod_epp_rsn_set;
    hal_cmn_swc_mod_drop_rsn_set_func_t hal_swc_mod_drop_rsn_set;
} hal_cmn_swc_func_vec_t;

typedef struct {
    hal_cmn_sec_cfg_init_func_t hal_sec_cfg_init;
    hal_cmn_sec_dos_port_prof_info_get_func_t hal_sec_dos_port_prof_info_get;
    hal_cmn_sec_isolation_grp_max_get_func_t hal_sec_isolation_grp_max_get;
} hal_cmn_sec_func_vec_t;

typedef struct hal_cmn_qos_func_vec_s {
    hal_cmn_qos_wb_init_func_t hal_qos_wb_init;
    hal_cmn_qos_wb_deinit_func_t hal_qos_wb_deinit;
    hal_cmn_qos_cfg_init_func_t hal_qos_cfg_init;
    hal_cmn_qos_rsrc_init_func_t hal_qos_rsrc_init;
    hal_cmn_qos_mapping_prof_cfg_alloc_func_t hal_qos_mapping_prof_cfg_alloc;
    hal_cmn_qos_mapping_prof_cfg_free_func_t hal_qos_mapping_prof_cfg_free;
    hal_cmn_qos_user_prof_cfg_set_func_t hal_qos_user_prof_cfg_set;
    hal_cmn_qos_prof_apply_func_t hal_qos_prof_apply;
    hal_cmn_qos_user_prof_idx_get_func_t hal_qos_user_prof_idx_get;
    hal_cmn_qos_acl_qos_prof_alloc_func_t hal_qos_acl_qos_prof_alloc;
    hal_cmn_qos_acl_qos_prof_free_func_t hal_qos_acl_qos_prof_free;
    hal_cmn_qos_acl_qos_prof_get_func_t hal_qos_acl_qos_prof_get;
    hal_cmn_qos_cpy_to_2nd_set_func_t hal_qos_cpy_to_2nd_set;
    hal_cmn_qos_cpy_to_2nd_get_func_t hal_qos_cpy_to_2nd_get;
} hal_cmn_qos_func_vec_t;

typedef struct {
    hal_cmn_efuse_read_func_t hal_efuse_read;
    hal_cmn_efuse_write_func_t hal_efuse_write;
    hal_cmn_efuse_dump_func_t hal_efuse_dump;
} hal_cmn_efuse_func_vec_t;

typedef struct {
    hal_cmn_stk_rsrc_init_func_t hal_stk_rsrc_init;
    hal_cmn_stk_cfg_init_func_t hal_stk_cfg_init;
    hal_cmn_stk_fab_port_bmp_get_func_t hal_stk_fab_port_bmp_get;
    hal_cmn_stk_fab_port_check_func_t hal_stk_fab_port_check;
    hal_cmn_stk_cpu_di_property_set_func_t hal_stk_cpu_di_property_set;
    hal_cmn_stk_cpu_di_property_get_func_t hal_stk_cpu_di_property_get;
    hal_cmn_stk_update_by_link_change_func_t hal_stk_update_by_link_change;
    hal_cmn_stk_fl_hash_sel_set_func_t hal_stk_fl_hash_sel_set;
    hal_cmn_stk_fl_hash_sel_get_func_t hal_stk_fl_hash_sel_get;
} hal_cmn_stk_func_vec_t;

typedef struct {
    hal_cmn_port_setmxlink_func_t hal_port_mxlink_set;
    hal_cmn_port_getmxlink_func_t hal_port_mxlink_get;
    hal_cmn_port_getinitportbitmap_func_t hal_port_init_port_bitmap_get;
    hal_cmn_port_updateportbitmap_func_t hal_port_port_bitmap_update;
    hal_cmn_port_updateintftagmode_func_t hal_port_intf_tag_mode_update;
    hal_cmn_port_getcapacity_func_t hal_port_capacity_get;
    hal_cmn_port_getusage_func_t hal_port_usage_get;
} hal_cmn_port_func_vec_t;
typedef struct {
    hal_cmn_init_func_t hal_cmn_init;
    hal_cmn_deinit_func_t hal_cmn_deinit;

    hal_cmn_nvo3_route_add_func_t hal_cmn_nvo3_route_add;
    hal_cmn_nvo3_route_del_func_t hal_cmn_nvo3_route_del;

    hal_cmn_addievl3rtenode_func_t hal_cmn_add_iev_l3_rte_node;
    hal_cmn_delievl3rtenode_func_t hal_cmn_del_iev_l3_rte_node;
    hal_cmn_getievl3rtenode_func_t hal_cmn_get_iev_l3_rte_node;

    hal_cmn_saveievl3rtenodes_func_t hal_cmn_save_iev_l3_rte_nodes;
    hal_cmn_restoreievl3rtenodes_func_t hal_cmn_restore_iev_l3_rte_nodes;

    hal_cmn_getencapidxfromport_func_t hal_cmn_get_encap_idx_from_port;
    hal_cmn_getportfromencapidx_func_t hal_cmn_get_port_from_encap_idx;
} hal_cmn_cmn_func_vec_t;

typedef struct {
    hal_cmn_cpu2jtag_init_func_t hal_cpu2jtag_init;
    hal_cmn_cpu2jtag_toggle_trst_func_t hal_cpu2jtag_toggleTrst;
    hal_cmn_cpu2jtag_check_ir_func_t hal_cpu2jtag_checkIr;
    hal_cmn_cpu2jtag_check_dr_func_t hal_cpu2jtag_checkDr;
} hal_cmn_cpu2jtag_func_vec_t;

typedef struct {
    /* l2 multiplexing functions */
    hal_cmn_l2_func_vec_t *const l2_cmn_func_vec;
    /* ifmon multiplexing functions */
    hal_cmn_ifmon_func_vec_t *const ifmon_cmn_func_vec;
    /* tm multiplexing functions */
    hal_cmn_tm_func_vec_t *const tm_cmn_func_vec;
    /* MPLS multiplexing functions */
    hal_cmn_mpls_func_vet_t *const mpls_cmn_func_vec;
    /* stat multiplexing functions */
    hal_cmn_stat_func_vec_t *const stat_cmn_func_vec;
    /* l3 multiplexing functions */
    hal_cmn_l3_func_vec_t *const l3_cmn_func_vec;
    /* l3t multiplexing functions */
    hal_cmn_tnl_func_vec_t *const tnl_cmn_func_vec;
    /* srv6 multiplexing functions */
    hal_cmn_srv6_func_vec_t *const srv6_cmn_func_vec;
    /* telm multiplexing functions */
    hal_cmn_telm_func_vec_t *const telm_cmn_func_vec;
    /* acl multiplexing functions */
    hal_cmn_cia_func_vec_t *const cia_cmn_func_vec;
    /* meter multiplexing functions */
    hal_cmn_meter_func_vec_t *const meter_cmn_func_vec;
    /* sflow multiplexing functions */
    hal_cmn_sflow_func_vec_t *const sflow_cmn_func_vec;
    /* mir multiplexing functions */
    hal_cmn_mir_func_vec_t *const mir_cmn_func_vec;
    /* lag multiplexing functions */
    hal_cmn_lag_func_vec_t *const lag_cmn_func_vec;
    /* swc multiplexing functions */
    hal_cmn_swc_func_vec_t *const swc_cmn_func_vec;
    /* sec multiplexing functions */
    hal_cmn_sec_func_vec_t *const sec_cmn_func_vec;
    /* qos multiplexing functions*/
    hal_cmn_qos_func_vec_t *const qos_cmn_func_vec;
    /* stk multiplexing functions*/
    hal_cmn_stk_func_vec_t *const stk_cmn_func_vec;
    /* efuse multiplexing functions */
    hal_cmn_efuse_func_vec_t *const efuse_cmn_func_vec;
    /* port multiplexing functions*/
    hal_cmn_port_func_vec_t *const port_cmn_func_vec;
    /* common functions */
    hal_cmn_cmn_func_vec_t *const cmn_cmn_func_vec;
    /* cpu2jtag multiplexing functions */
    hal_cmn_cpu2jtag_func_vec_t *const cpu2jtag_cmn_func_vec;
} hal_cmn_func_vec_t;
#endif /* #ifndef HAL_CMN_DRV_H */
