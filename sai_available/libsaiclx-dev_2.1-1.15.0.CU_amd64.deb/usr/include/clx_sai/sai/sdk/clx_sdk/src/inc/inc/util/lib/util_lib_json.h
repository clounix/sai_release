/**
 * @brief A lightweight JSON parser implementation.
 *
 */

#ifndef _UTIL_LIB_JSON_H_
#define _UTIL_LIB_JSON_H_

#include <clx/clx_types.h>

/* JSON value types */
typedef enum {
    JSON_TYPE_NULL,
    JSON_TYPE_BOOLEAN,
    JSON_TYPE_NUMBER,
    JSON_TYPE_STRING,
    JSON_TYPE_ARRAY,
    JSON_TYPE_OBJECT
} json_value_type_t;

/* JSON value structure */
typedef struct json_value {
    json_value_type_t type;
    union {
        boolean bool_val;
        int64 int_val;
        char *str_val;
        struct {
            struct json_value **items;
            uint32 length;
            uint32 capacity;
        } array;
        struct {
            char **keys;
            struct json_value **values;
            uint32 length;
            uint32 capacity;
        } object;
    } u;
} json_value_t;

/* JSON parsing context */
typedef struct {
    const char *data;
    uint32 pos;
    uint32 len;
} json_parse_ctx_t;

/* Basic parsing functions */
/**
 * @brief Parse a JSON file into a value.
 *
 * @param [in]     filename      - The JSON file to parse.
 * @return         json_value_t* - Newly allocated JSON value or NULL on failure.
 */
json_value_t *
util_lib_json_parse_from_file(const char *filename);

/**
 * @brief Parse a JSON string into a value.
 *
 * @param [in]    str    - The JSON string to parse.
 * @return        json_value_t*    - Newly allocated JSON value or NULL on failure.
 */
json_value_t *
util_lib_json_parse_string(const char *str);

/**
 * @brief Free a JSON value and all its children.
 *
 * @param [in]    value    - The JSON value to free.
 */
void
util_lib_json_value_free(json_value_t *value);

/* Value access functions */
/**
 * @brief Get a value from a JSON object with the specified key.
 *
 * @param [in]    obj    - The JSON object.
 * @param [in]    key    - The key to look up.
 * @return        json_value_t*    - The value associated with the key or NULL if not found.
 */
json_value_t *
util_lib_json_object_get(json_value_t *obj, const char *key);

/**
 * @brief Get a value from a JSON array at the specified index.
 *
 * @param [in]    arr      - The JSON array.
 * @param [in]    index    - The index to get.
 * @return        json_value_t*    - The value at the index or NULL if invalid.
 */
json_value_t *
util_lib_json_array_get(json_value_t *arr, uint32 index);

/**
 * @brief Get the length of a JSON array.
 *
 * @param [in]    arr    - The JSON array.
 * @return        uint32    - The length of the array or 0 if not an array.
 */
uint32
util_lib_json_array_length(json_value_t *arr);

/**
 * @brief Get the type of a JSON value.
 *
 * @param [in]    value    - The JSON value.
 * @return        json_value_type_t    - The type of the value.
 */
json_value_type_t
util_lib_json_get_type(json_value_t *value);

/**
 * @brief Get a value from a JSON object and return success status.
 *
 * @param [in]     obj      - The JSON object.
 * @param [in]     key      - The key to look up.
 * @param [out]    value    - Pointer to store the retrieved value.
 * @return         TRUE     - If the key was found.
 * @return         FALSE    - Otherwise.
 */
boolean
util_lib_json_object_get_ex(json_value_t *obj, const char *key, json_value_t **value);

/* Value conversion functions */
/**
 * @brief Get an integer value from a JSON value.
 *
 * @param [in]     value    - The JSON value.
 * @param [out]    out      - Pointer to store the integer value.
 * @return         TRUE     - If successful.
 * @return         FALSE    - Otherwise.
 */
boolean
util_lib_json_get_int(json_value_t *value, int64 *out);

/**
 * @brief Get a string value from a JSON value.
 *
 * @param [in]    value    - The JSON value.
 * @return        const char*    - The string value or NULL if not a string.
 */
const char *
util_lib_json_get_string(json_value_t *value);

/**
 * @brief Get a boolean value from a JSON value.
 *
 * @param [in]     value    - The JSON value.
 * @param [out]    out      - Pointer to store the boolean value.
 * @return         TRUE     - If successful.
 * @return         FALSE    - Otherwise.
 */
boolean
util_lib_json_get_boolean(json_value_t *value, boolean *out);

/* Value modification functions */
/**
 * @brief Set a value in a JSON array.
 *
 * @param [in]    arr      - The JSON array.
 * @param [in]    index    - The index to set.
 * @param [in]    value    - The value to set.
 * @return        TRUE     - If successful.
 * @return        FALSE    - Otherwise.
 */
boolean
util_lib_json_array_set(json_value_t *arr, uint32 index, json_value_t *value);

/**
 * @brief Set a value in a JSON object.
 *
 * @param [in]    obj      - The JSON object.
 * @param [in]    key      - The key to set.
 * @param [in]    value    - The value to set.
 * @return        TRUE     - If successful.
 * @return        FALSE    - Otherwise.
 */
boolean
util_lib_json_object_set(json_value_t *obj, const char *key, json_value_t *value);

/**
 * @brief Add a value to a JSON array.
 *
 * @param [in]    arr      - The JSON array.
 * @param [in]    value    - The value to add.
 * @return        TRUE     - If successful.
 * @return        FALSE    - Otherwise.
 */
boolean
util_lib_json_array_add(json_value_t *arr, json_value_t *value);

/* String utility functions */
/**
 * @brief Duplicate a string using osal memory functions.
 *
 * @param [in]    str    - The string to duplicate.
 * @return        char*    - A newly allocated copy of the string, or NULL on failure.
 */
char *
util_lib_json_strdup(const char *str);

/* Copy functions */
/**
 * @brief Copy a JSON value.
 *
 * @param [in]    value    - The JSON value to copy.
 * @return        json_value_t*    - A newly allocated copy of the JSON value or NULL on failure.
 */
json_value_t *
util_lib_json_value_copy(json_value_t *value);

/* Serialization functions */
/**
 * @brief Convert a JSON value to a string.
 *
 * @param [in]    value     - The JSON value to convert.
 * @param [in]    pretty    - Whether to format the output.
 * @return        char*    - A newly allocated string representation or NULL on failure.
 */
char *
util_lib_json_stringify(json_value_t *value, boolean pretty);

/**
 * @brief Write a JSON value to a file.
 *
 * @param [in]    value       - The JSON value to write.
 * @param [in]    filename    - The file to write to.
 * @param [in]    pretty      - Whether to format the output.
 * @return        TRUE     - If successful.
 * @return        FALSE    - Otherwise.
 */
boolean
util_lib_json_write_to_file(json_value_t *value, const char *filename, boolean pretty);

/* Helper functions */
/**
 * @brief Create a new JSON value.
 *
 * @param [in]    type    - The type of JSON value to create.
 * @return        json_value_t*    - Newly allocated JSON value or NULL on failure.
 */
json_value_t *
util_lib_json_value_new(json_value_type_t type);

#endif /* _UTIL_LIB_JSON_H_ */
