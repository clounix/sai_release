/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_qos.h
 * PURPOSE:
 *      It provides qos module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_QOS_H
#define CLX_QOS_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_QOS_INVALID_PROFILE_ID (0xFFFFFFFF) /* invalid profile id, to cancel qos profile */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/*trust1p or trust dscp*/
typedef enum clx_qos_trust_mode_e {
    CLX_TRUST_MODE_NONE = 0,
    CLX_TRUST_MODE_1P, /* Trust 8021.p,  whether to use the 1p in packets for qos mapping */
    CLX_TRUST_MODE_LAST,
} clx_qos_trust_mode_t;

/*qos mapping type*/
typedef enum clx_qos_mapping_type_e {
    CLX_QOS_MAPPING_TYPE_DOT1P = 0,  /* including pcp-dei-to-phb, phb-to-pcp-dei */
    CLX_QOS_MAPPING_TYPE_DSCP,       /* including dscp-to-phb, phb-to-dscp */
    CLX_QOS_MAPPING_TYPE_EXP,        /* including exp-to-phb, phb-to-exp */
    CLX_QOS_MAPPING_TYPE_DFLT_DOT1P, /* default phb-to-pcp-dei, used for untag */
    CLX_QOS_MAPPING_TYPE_DFLT_DSCP,  /* default phb-to-dscp, used for untag */
    CLX_QOS_MAPPING_TYPE_DFLT_EXP,   /* default phb-to-exp, used for untag */
    CLX_QOS_MAPPING_TYPE_LAST,
} clx_qos_mapping_type_t;

/*qos mapping entry*/
typedef struct clx_qos_mapping_cfg_s {
    uint8 priority;    /*Traffic class*/
    clx_color_t color; /*Traffic color: green,yellow,red*/
    uint8 dot1p;       /*(pcp(3bit),dei(1bit))*/
    uint8 dscp;        /*Differentiated services code point*/
    uint8 exp;         /*Experimental Bits*/
    uint8 exp_l_lsp;   /*Drop precedence in l_lsp */
} clx_qos_mapping_cfg_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to create a new QoS profile (also called QoS mapping).
 *
 * QoS mapping is the mapping between {pcp,dei}, {dscp} or {exp} to {priority,color}.
 * priority(traffic class) is used by chip to derivate queue by another API
 * clx_tm_tc_queue_mapping_set.
 * Use this API to create a new mapping profile.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     direction       - Mapping direction, including CLX_DIR_INGRESS and
 * CLX_DIR_EGRESS.
 * @param [in]     mapping_type    - The type of the mapping profile.
 * CLX_QOS_MAPPING_TYPE_DOT1P means the mapping of ingress pcp/dei to phb or egress phb to pcp/dei.
 * CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress dscp to phb or egress phb to dscp.
 * CLX_QOS_MAPPING_TYPE_EXP means the mapping of ingress exp to phb or egress phb to exp.
 * CLX_QOS_MAPPING_TYPE_DFLT_DOT1P, CLX_QOS_MAPPING_TYPE_DFLT_DSCP, CLX_QOS_MAPPING_TYPE_DFLT_EXP
 *                                   donot support.
 * @param [in]     profile_id      - An assigned number that represents the software profile ID and
 *                                   the index of hardware table on this QoS mapping type.
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - NO more memory for the entry.
 * @return         CLX_E_ENTRY_EXISTS     - The mapping profile is already created.
 */
clx_error_no_t
clx_qos_prof_create(const uint32 unit,
                    const clx_dir_t direction,
                    const clx_qos_mapping_type_t mapping_type,
                    const uint32 profile_id);

/**
 * @brief This API is used to delete a QoS profile.
 *
 * Use this API to destroy a mapping profile. The mapping profile can be destroyed
 * only when the mapping profile is not used by other objects
 * (such as port/vm/interface/tunnel etc.).
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     direction       - Mapping direction, including CLX_DIR_INGRESS and
 * CLX_DIR_EGRESS.
 * @param [in]     mapping_type    - The type of the mapping profile.
 * CLX_QOS_MAPPING_TYPE_DOT1P means the mapping of ingress pcp/dei to phb or egress phb to pcp/dei.
 * CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress dscp to phb or egress phb to dscp.
 * CLX_QOS_MAPPING_TYPE_EXP means the mapping of ingress exp to phb or egress phb to exp.
 * CLX_QOS_MAPPING_TYPE_DFLT_DOT1P, CLX_QOS_MAPPING_TYPE_DFLT_DSCP, CLX_QOS_MAPPING_TYPE_DFLT_EXP
 * donot support.
 * @param [in]     profile_id      - An assigned number that represents the software profile ID and
 *                                   the index of hardware table on this QoS mapping type.
 * @return         CLX_E_OK                 - Operation successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping profile is not exist.
 * @return         CLX_E_NOT_SUPPORT        - Not support to delete the mapping profile.
 *                                            (eg. the mapping profile has been applied to a
 *                                            port/vm/interface/ tunnel and so on)
 */
clx_error_no_t
clx_qos_prof_destroy(const uint32 unit,
                     const clx_dir_t direction,
                     const clx_qos_mapping_type_t mapping_type,
                     const uint32 profile_id);

/**
 * @brief This API is used to configure a profile entry.
 *
 * Use this API to configure a mapping entry. User should be set all fields needed according to the
 * "mapping_type" parameter in the entry.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DOT1P or CLX_QOS_MAPPING_TYPE_DFLT_DOT1P,
 * fields "pcp", "dei", "priority", "color" must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DSCP or CLX_QOS_MAPPING_TYPE_DFLT_DSCP,
 * fields "dscp", "priority", "color" must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_EXP or CLX_QOS_MAPPING_TYPE_DFLT_EXP,
 * fields "exp", "priority", "color" must be input by user, and other fields must be ignored.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     direction       - Mapping direction, including CLX_DIR_INGRESS and
 * CLX_DIR_EGRESS.
 * @param [in]     mapping_type    - The type of the mapping profile.
 * CLX_QOS_MAPPING_TYPE_DOT1P means the mapping of ingress pcp/dei to phb or egress phb to pcp/dei.
 * CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress dscp to phb or egress phb to dscp.
 * CLX_QOS_MAPPING_TYPE_EXP means the mapping of ingress exp to phb or egress phb to exp.
 * CLX_QOS_MAPPING_TYPE_DFLT_DOT1P means the default mapping of egress phb to
 * pcp/dei when packets untag in.
 * CLX_QOS_MAPPING_TYPE_DFLT_DSCP means the default mapping of egress phb to
 * dscp when packets untag in.
 * CLX_QOS_MAPPING_TYPE_DFLT_EXP means the default mapping of egress phb to
 * exp when packets untag in.
 * @param [in]     profile_id      - An assigned number that represents the software profile ID and
 * the index of hardware table on this QoS mapping type.
 * For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and
 * CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profile_id should be set to 0.
 * @param [in]     ptr_cfg         - The config of the priority mapping.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping profile is not found.
 */
clx_error_no_t
clx_qos_prof_set(const uint32 unit,
                 const clx_dir_t direction,
                 const clx_qos_mapping_type_t mapping_type,
                 const uint32 profile_id,
                 const clx_qos_mapping_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get the information of a profile entry.
 *
 * Use this API to get a mapping entry.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     direction       - Mapping direction, including CLX_DIR_INGRESS and
 * CLX_DIR_EGRESS.
 * @param [in]     mapping_type    - The type of the mapping profile.
 * CLX_QOS_MAPPING_TYPE_DOT1P means the mapping of ingress pcp/dei to phb or egress phb to pcp/dei.
 * CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress dscp to phb or egress phb to dscp.
 * CLX_QOS_MAPPING_TYPE_EXP means the mapping of ingress exp to phb or egress phb to exp.
 * CLX_QOS_MAPPING_TYPE_DFLT_DOT1P means the default mapping of egress phb to
 * pcp/dei when packets untag in.
 * CLX_QOS_MAPPING_TYPE_DFLT_DSCP means the default mapping of egress phb to
 * dscp when packets untag in.
 * CLX_QOS_MAPPING_TYPE_DFLT_EXP means the default mapping of egress phb to
 * exp when packets untag in.
 * @param [in]     profile_id      - An assigned number that represents the software profile ID and
 * the index of hardware table on this QoS mapping type.
 * For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI, CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and
 * CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profile_id should be set to 0.
 * @param [in]     ptr_cfg         - The config which to be obtained by user.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DOT1P:
 *    if "direction" is CLX_DIR_INGRESS, fields "pcp" and "dei" are the input.
 *    if "direction" is CLX_DIR_EGRESS, fields "priority" and "color" are the input.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DSCP:
 *    if "direction" is CLX_DIR_INGRESS, field "dscp" is the input.
 *    if "direction" is CLX_DIR_EGRESS, fields "priority" and "color" are the input.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_EXP:
 *    if "direction" is CLX_DIR_INGRESS, field "exp" is the input.
 *    if "direction" is CLX_DIR_EGRESS, fields "priority" and "color" are the input.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DFLT_DOT1P, CLX_QOS_MAPPING_TYPE_DFLT_DSCP or
 * CLX_QOS_MAPPING_TYPE_DFLT_EXP, fields "priority", "color" are the input.
 * @param [out]    ptr_cfg         - The config which to be obtained by user.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DOT1P:
 *    if "direction" is CLX_DIR_INGRESS, fields "priority" and "color" are the output.
 *    if "direction" is CLX_DIR_EGRESS, fields "pcp" and "dei" are the output.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DSCP:
 *    if "direction" is CLX_DIR_INGRESS, fields "priority" and "color" are the output.
 *    if "direction" is CLX_DIR_EGRESS, field "dscp" is the output.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_EXP:
 *    if "direction" is CLX_DIR_INGRESS, field "priority" and "color" are the output.
 *    if "direction" is CLX_DIR_EGRESS, fields "exp" is the output.
 * If "mapping_type" is CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 * fields "pcp" and "dei" are the output.
 * If "mapping_type" is CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP,
 * fields "dscp" is the output.
 * If "mapping_type" is CLX_QOS_MAPPING_DFLT_PHB_TO_EXP,
 * fields "exp" is the output.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The mapping profile_id is not found.
 * @return         CLX_E_NOT_INITED         - SDK module has not been initialized.
 */
clx_error_no_t
clx_qos_prof_get(const uint32 unit,
                 const clx_dir_t direction,
                 const clx_qos_mapping_type_t mapping_type,
                 const uint32 profile_id,
                 clx_qos_mapping_cfg_t *ptr_cfg);

#endif /* End of CLX_QOS_H */
