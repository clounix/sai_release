/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_ecc.h
 * PURPOSE:
 *  Provide HAL ECC manipulation APIs for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NAMCHABARWA_ECC_H
#define HAL_MT_NAMCHABARWA_ECC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_ecc.h>
#include <clx/clx_swc.h>
#include <hal/hal_ecc.h>
#include <hal/mt/hal_mt_intr.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_MT_NB_ECC_FPUHSH_SLV_HASH_TILE_MAX          (24)  /* max tile num */
#define HAL_MT_NB_ECC_FPUHSH_SLV_HASH_MEM_MAX           (25)  /* memory max num per tile */
#define HAL_MT_NB_ECC_FPUHSH_SLV_HASH_MEM_LINE_NUM_MAX  (128) /* line max num per memory */
#define HAL_MT_NB_ECC_FPUHSH_SLV_HASH_MEM_ENTRY_NUM_MAX (8)   /* entry max num per line(ipv4) */
#define HAL_MT_NB_ECC_SERR_TYPE                         (0)
#define HAL_MT_NB_ECC_DERR_TYPE                         (1)
#define HAL_MT_NB_ECC_INVALID_TYPE                      (0xFF)

#define HAL_MT_NB_ECC_HANDLE_THREAD_PRI   (50)
#define HAL_MT_NB_ECC_HANDLE_THREAD_STACK (32 * 1024)

/* in 4 FPU entry is same for 25.6T, \
 * 12.8T: FPU0 and FPU2 entry is same FPU1 and FPU3 is same */
#define HAL_MT_NB_ECC_FPU_NUM         (2)
#define HAL_MT_NB_ECC_BIT_NUM_IN_WORD (32)
/* ECC IRQ max bit num is MCDB	mem_serr_irq[303] */
#define HAL_MT_NB_ECC_IRQ_BIT_NUM_MAX (303)
#define HAL_MT_NB_ECC_IRQ_BMP_SIZE    (((HAL_MT_NB_ECC_IRQ_BIT_NUM_MAX - 1) / 32) + 1)

#define HAL_MT_NB_ECC_GET_PTR_CNT(_array_)                  \
    if (HAL_MT_NB_ECC_ARRAY_SIZE(_array_)) {                \
        *pptr_irq_bmp = &_array_[0];                        \
        *ptr_array_cnt = HAL_MT_NB_ECC_ARRAY_SIZE(_array_); \
    }

typedef enum hal_mt_nb_ecc_tbl_id_e {
    HAL_MT_NB_ECC_TBL_ID_START = HAL_NAMCHABARWA_LAST_TBL_ID + 1,
    HAL_MT_NB_ECC_TBL_ASM_SUB0_FD_FIFO_MEM_ID,
    HAL_MT_NB_ECC_TBL_ASM_SUB0_PD_FIFO_MEM_ID,
    HAL_MT_NB_ECC_TBL_ASM_SUB1_FD_FIFO_MEM_ID,
    HAL_MT_NB_ECC_TBL_ASM_SUB1_PD_FIFO_MEM_ID,
    HAL_MT_NB_ECC_TBL_DQC_ENQ_CB_PSZ_MEM_ID,
    HAL_MT_NB_ECC_TBL_DQC_GNT_CB_PSZ_MEM_ID,
    HAL_MT_NB_ECC_TBL_DQC_READ_CB_PSZ_MEM_ID,
    HAL_MT_NB_ECC_TBL_DQC_READ_RPT_FIFO_MEM_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM0_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM1_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM2_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM3_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM4_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM5_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM6_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM7_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM8_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM9_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM10_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM11_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM12_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM13_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM14_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM15_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM16_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM17_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM18_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM19_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM20_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM21_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM22_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM23_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM24_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM25_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM26_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM27_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM28_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM29_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM30_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM31_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM32_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM33_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM34_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM35_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM36_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM37_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM38_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM39_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM40_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM41_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM42_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM43_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM44_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM45_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM46_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM47_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM48_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM49_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM50_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM51_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM52_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM53_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM54_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM55_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM56_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM57_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM58_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM59_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM60_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM61_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM62_ID,
    HAL_MT_NB_ECC_TBL_DQC_TOP_PD_XBAR_NORMAL_FIFO_BACKUP_MEM63_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_PD_SHARE_1R1W0_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_PD_SHARE_1R1W1_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_PD_SHARE_1R1W2_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_PD_SHARE_1R1W3_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_PD_SHARE_1R1W4_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_PD_SHARE_1R1W0_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_PD_SHARE_1R1W1_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_PD_SHARE_1R1W2_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_PD_SHARE_1R1W3_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_PD_SHARE_1R1W4_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_PPL_WF_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_PPL_WF_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_ASM_DROP_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_ASM_DROP_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_PD_OQC_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_SEARCH_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_SEARCH_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_RESULT_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_RESULT_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_RELOOK_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_RELOOK_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB0_PD_DEL_1R1W_ID,
    HAL_MT_NB_ECC_TBL_FRG_FRG_SUB1_PD_DEL_1R1W_ID,
    HAL_MT_NB_ECC_TBL_MCDB_MCDB_DAT_FIFO_MEM0_ID,
    HAL_MT_NB_ECC_TBL_MCDB_MCDB_DAT_FIFO_MEM1_ID,
    HAL_MT_NB_ECC_TBL_MCDB_MCDB_DAT_FIFO_MEM2_ID,
    HAL_MT_NB_ECC_TBL_MCDB_MCDB_DAT_FIFO_MEM3_ID,
    HAL_MT_NB_ECC_TBL_MCDB_MCDB_DAT_FIFO_MEM4_ID,
    HAL_MT_NB_ECC_TBL_MCDB_MCDB_DAT_FIFO_MEM5_ID,
    HAL_MT_NB_ECC_TBL_MCDB_MCDB_DAT_FIFO_MEM6_ID,
    HAL_MT_NB_ECC_TBL_MCDB_MCDB_DAT_FIFO_MEM7_ID,
    HAL_MT_NB_ECC_TBL_OQC_OQC_INC_EVENT_MEM_ID,
    HAL_MT_NB_ECC_TBL_OQC_OQC_DEC_EVENT_MEM_ID,
    HAL_MT_NB_ECC_TBL_OQC_OQC_DEQ_REQ_MEM_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM8_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM9_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM10_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM11_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM12_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM13_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM14_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_0_MEM15_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM8_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM9_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM10_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM11_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM12_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM13_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM14_ID,
    HAL_MT_NB_ECC_TBL_PDB_CENTER_FBM_REL_REQ_1_MEM15_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM8_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM9_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM10_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM11_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM12_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM13_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM14_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_RD_DATA_SMALL_MEM15_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_HOLD_FIFO_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_HOLD_FIFO_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_HOLD_FIFO_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_HOLD_FIFO_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM8_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM9_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM10_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM11_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM12_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM13_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM14_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_EPP_HOLD_FIFO_SMALL_MEM15_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_SUBSLICE0_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_SUBSLICE1_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_SUBSLICE2_ID,
    HAL_MT_NB_ECC_TBL_PDB_QUAD_SUBSLICE3_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WREQ_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WREQ_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WREQ_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WREQ_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WREQ_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WREQ_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WREQ_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WREQ_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RREQ_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RREQ_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RREQ_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RREQ_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RREQ_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RREQ_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RREQ_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RREQ_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RDAT_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RDAT_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RDAT_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RDAT_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RDAT_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RDAT_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RDAT_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_RDAT_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WF_REQ_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WF_REQ_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WF_REQ_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WF_REQ_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WF_REQ_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WF_REQ_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WF_REQ_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WF_REQ_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_REORDER_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_REORDER_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_REORDER_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_REORDER_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_REORDER_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_REORDER_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_REORDER_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_REORDER_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WR_CMD_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WR_CMD_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WR_CMD_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WR_CMD_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WR_CMD_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WR_CMD_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WR_CMD_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDM_PDM_WR_CMD_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_PAYLOAD_MEM_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_FBM_MEM_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM0_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM1_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM2_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM3_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM4_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM5_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM6_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM7_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM8_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM9_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM10_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM11_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM12_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM13_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM14_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM15_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM16_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM17_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM18_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM19_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM20_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM21_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM22_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM23_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM24_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM25_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM26_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM27_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM28_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM29_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM30_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM31_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM32_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM33_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM34_ID,
    HAL_MT_NB_ECC_TBL_PDM_EME_PDM_EME_VRF_MEM35_ID,
    HAL_MT_NB_ECC_TBL_PPL_WR_REQ_MEM_ID,
    HAL_MT_NB_ECC_TBL_PPL_RD_REQ_MEM_ID,
    HAL_MT_NB_ECC_TBL_PPL_RD_RSLT_MEM_ID,
    HAL_MT_NB_ECC_TBL_PPL_WRREQ_CBR_MEM_ID,
    HAL_MT_NB_ECC_TBL_PPL_RDREQ_CBR_MEM_ID,
    HAL_MT_NB_ECC_TBL_PPL_EME_VRF_MEM_ID,
    HAL_MT_NB_ECC_TBL_PPL_EME_PAYLOAD_MEM_ID,
    HAL_MT_NB_ECC_TBL_PPL_EME_UCNT_MEM_ID,
    HAL_MT_NB_ECC_TBL_PPL_EME_FBM_MEM_ID,
    HAL_MT_NB_ECC_TBL_REP_MC_PD_FIFO_MEM_ID,
    HAL_MT_NB_ECC_TBL_REP_MIR_PD_FIFO_MEM_ID,
    HAL_MT_NB_ECC_TBL_REP_MC_IN_DATA_FIFO_MEM_ID,
    HAL_MT_NB_ECC_TBL_EPL_APP_PTP_REFL_MEM_ETH_GRP0_ID,
    HAL_MT_NB_ECC_TBL_EPL_APP_PTP_REFL_MEM_ETH_GRP1_ID,
    HAL_MT_NB_ECC_TBL_EPL_APP_PTP_REFL_MEM_ETH_GRP2_ID,
    HAL_MT_NB_ECC_TBL_EPL_APP_PTP_REFL_MEM_ETH_GRP3_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_FCFEC_FTYPE_0_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_FCFEC_STYPE_0_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_FCFEC_STYPE_1_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_FCFEC_STYPE_2_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_FCFEC_FTYPE_1_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_FCFEC_STYPE_3_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_FCFEC_STYPE_4_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_FCFEC_STYPE_5_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_RSFEC_0_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_RSFEC_1_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_RSFEC_2_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_RSFEC_3_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_DESKEW_0_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_DESKEW_1_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_DESKEW_2_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_DESKEW_3_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_DESKEW_4_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_DESKEW_5_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_DESKEW_6_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_DESKEW_7_ID,
    HAL_MT_NB_ECC_TBL_UMAC_WRAP_STATUS_ID,
    HAL_MT_NB_ECC_TBL_RWI_HSH_VLAN_MEM_ID,
    HAL_MT_NB_ECC_TBL_RWO_HSH_BDO_VLAN_MEM_ID,
    HAL_MT_NB_ECC_TBL_ID_LAST,
} hal_mt_nb_ecc_tbl_id_t;

typedef uint32 hal_mt_nb_ecc_bmp_t[HAL_MT_NB_ECC_IRQ_BMP_SIZE];

/* ecc irq info struct, Each bit position corresponds to a table */
typedef struct hal_mt_nb_ecc_sram_irq_bmp_s {
    uint32 table_id;
    uint32 serr_reg_id;
    uint32 derr_reg_id;
    uint32 err_info_id;
    uint32 bit_index_start; /* irq bit index start */
    uint32 bit_index_end;   /* irq bit index end */
    /* hash table maybe have many mem, line cnt is diff in per table_id */
    uint32 line_cnt_per_mem;
} hal_mt_nb_ecc_sram_irq_bmp_t;

/* table id type for malloc cache */
typedef enum hal_mt_nb_ecc_cache_table_type_e {
    /* TDS table id */
    HAL_MT_NB_ECC_TDS_HSH_BDO = 0,
    HAL_MT_NB_ECC_TDS_DIR_POC,

    /* DIS table id */
    HAL_MT_NB_ECC_DIS_HSH_BDI_MEM,
    HAL_MT_NB_ECC_DIS_DIR_LCL,

    /* FPU table id */
    HAL_MT_NB_ECC_FPU_L2,
    HAL_MT_NB_ECC_FPU_L3,
    HAL_MT_NB_ECC_FPU_MPLS,
    HAL_MT_NB_ECC_FPU_SRV6,

    HAL_MT_NB_ECC_CACHED_LAST, /* cache array max num */
} hal_mt_nb_ecc_cache_table_type_t;

typedef struct hal_mt_nb_ecc_cache_memory_table_info_s {
    /* define table data and valid */
    uint32 table_id;   /* cached table id */
    uint32 valid;      /* table valid if enable ecc */
    uint32 table_size; /* all entry size for the table_id */

    /* 25.6T: 4 fpu in NB, and table entry content is same in every fpu */
    uint8 *ptr_data; /* point to data memory. malloc data memory, if enable ecc recovery. per slc
                        per pointer?? */
} hal_mt_nb_ecc_cache_memory_table_info_t;

typedef struct hal_mt_nb_ecc_cache_memory_all_table_s { /* for sram table in tds/dis/rwi/rwo */
    hal_mt_nb_ecc_cache_memory_table_info_t cache_tab_info;
    clx_semaphore_id_t mutex_sema_id;
} hal_mt_nb_ecc_cache_memory_all_table_t;

typedef struct hal_mt_nb_ecc_cache_memory_fpu_table_s { /* for sram table in fpu */
    hal_mt_nb_ecc_cache_memory_table_info_t cache_tab_info;
    /* fpu has 24 tile, lock cache table per tile */
    clx_semaphore_id_t mutex_sema_id[HAL_MT_NB_ECC_FPUHSH_SLV_HASH_TILE_MAX];
} hal_mt_nb_ecc_cache_memory_fpu_table_t;

extern hal_mt_nb_ecc_cache_memory_fpu_table_t
    _hal_mt_nb_ecc_fpu_cache_table[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_MT_NB_ECC_FPU_NUM];

/* MACRO  DECLARATIONS
 */

#define HAL_MT_NB_ECC_ARRAY_SIZE(__array__) (sizeof(__array__) / sizeof(__array__[0]))

#define HAL_MT_NB_ECC_CB_LOCK(_unit_) \
    HAL_COMMON_LOCK_RESOURCE(&_hal_mt_nb_ecc_cb[(_unit_)].mutex_sema_id, CLX_SEMAPHORE_WAIT_FOREVER)

#define HAL_MT_NB_ECC_CB_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_mt_nb_ecc_cb[(_unit_)].mutex_sema_id)

/* lock is added to each cache table, and when a specific table is distinguished, the lock is
 applied. This prevents L2 from getting locked when it writes to the cache table while L3 is being
 processed
 */
#define HAL_MT_NB_ECC_CACHE_LOCK(_unit_, _inst_, _table_id_, _bank_bmp_)                           \
    do {                                                                                           \
        uint32 _inst_idx_ = 0;                                                                     \
        if (TOB_TABLE(_unit_, _table_id_)->duplicate_type == HAL_HW_DUP_TYPE_FPU) {                \
            if (HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(_unit_)) {                                    \
                if (_inst_ == TOB_ODD_INST_IDX_BCAST || _inst_ == 1 || _inst_ == 3) {              \
                    _inst_idx_ = 1;                                                                \
                }                                                                                  \
            }                                                                                      \
            for (int _tile_idx_ = 0; _tile_idx_ < HAL_MT_NB_ECC_FPUHSH_SLV_HASH_TILE_MAX;          \
                 _tile_idx_++) {                                                                   \
                if ((_bank_bmp_) & (1 << _tile_idx_)) {                                            \
                    HAL_COMMON_LOCK_RESOURCE(&_hal_mt_nb_ecc_fpu_cache_table[(_unit_)][_inst_idx_] \
                                                  .mutex_sema_id[_tile_idx_],                      \
                                             CLX_SEMAPHORE_WAIT_FOREVER);                          \
                }                                                                                  \
            }                                                                                      \
        }                                                                                          \
    } while (0);

#define HAL_MT_NB_ECC_CACHE_UNLOCK(_unit_, _inst_, _table_id_, _bank_bmp_)                         \
    do {                                                                                           \
        uint32 _inst_idx_ = 0;                                                                     \
        if (TOB_TABLE(_unit_, _table_id_)->duplicate_type == HAL_HW_DUP_TYPE_FPU) {                \
            if (HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(_unit_)) {                                    \
                if (_inst_ == TOB_ODD_INST_IDX_BCAST || _inst_ == 1 || _inst_ == 3) {              \
                    _inst_idx_ = 1;                                                                \
                }                                                                                  \
            }                                                                                      \
            for (int _tile_idx_ = 0; _tile_idx_ < HAL_MT_NB_ECC_FPUHSH_SLV_HASH_TILE_MAX;          \
                 _tile_idx_++) {                                                                   \
                if ((_bank_bmp_) & (1 << _tile_idx_)) {                                            \
                    HAL_COMMON_FREE_RESOURCE(&_hal_mt_nb_ecc_fpu_cache_table[(_unit_)][_inst_idx_] \
                                                  .mutex_sema_id[_tile_idx_]);                     \
                }                                                                                  \
            }                                                                                      \
        }                                                                                          \
    } while (0);

#define HAL_MT_NB_ECC_CHECK_RC_RETURN(_rc_, _module_, _level_, format, arg...) \
    do {                                                                       \
        if (_rc_ != CLX_E_OK) {                                                \
            UTIL_LOG_PRINT(_module_, _level_, "rc:%u, " format, _rc_, ##arg);  \
            return _rc_;                                                       \
        }                                                                      \
    } while (0);

#define HAL_MT_NB_ECC_CHECK_RC_NOT_RETURN(_rc_, _module_, _level_, format, arg...) \
    do {                                                                           \
        if (_rc_ != CLX_E_OK) {                                                    \
            UTIL_LOG_PRINT(_module_, _level_, "rc:%u, " format, _rc_, ##arg);      \
        }                                                                          \
    } while (0);

#define HAL_MT_NB_ECC_CHECK_RC_GOTO(_rc_, _module_, _level_, _goto_, format, arg...) \
    do {                                                                             \
        if (_rc_ != CLX_E_OK) {                                                      \
            UTIL_LOG_PRINT(_module_, _level_, "rc:%u, " format, _rc_, ##arg);        \
            goto _goto_;                                                             \
        }                                                                            \
    } while (0);

/* DATA TYPE DECLARATIONS
 */

/* register for recover double ecc error */
typedef void (*hal_mt_nb_ecc_recovery_notify_func_t)(const uint32 unit,
                                                     const uint32 inst_idx,
                                                     const uint32 subinst_idx,
                                                     const uint32 table_id,
                                                     const uint32 entry_idx,
                                                     const uint32 data_size,
                                                     const uint32 *ptr_data);

typedef void (*hal_mt_nb_ecc_entry_blocked_notify_func_t)(const uint32 unit,
                                                          const uint32 inst_idx,
                                                          const uint32 subinst_idx,
                                                          const uint32 table_id,
                                                          const uint32 entry_idx,
                                                          const uint32 entry_cnt,
                                                          void *ptr_data);

typedef struct hal_mt_nb_ecc_serr_derr_reg_id_s {
    uint32 serr_irq_id; /* SLV single error irq register id, such as
                           MT_NB_REG_FPUHSH_SLV_IRQS_HASH_IRQS_MEM_0_SERR_IRQ_ID */
    uint32 derr_irq_id; /* SLV double error irq register id, such as
                           MT_NB_REG_FPUHSH_SLV_IRQS_HASH_IRQS_MEM_0_DERR_IRQ_ID */
} hal_mt_nb_ecc_serr_derr_reg_id_t;

typedef struct hal_mt_nb_ecc_cb_s {
    clx_semaphore_id_t mutex_sema_id;
    hal_ecc_log_info_t log_arr[HAL_ECC_LOG_NUM];
    uint32 next_log_entry_id;

    /* add callback register for recovery or notify ecc always happend */
    hal_mt_nb_ecc_recovery_notify_func_t recovery_cb; /* recover ecc table by each service */
    /* notify L2/L3 after rewrite table entry by dirty data */
    hal_mt_nb_ecc_entry_blocked_notify_func_t entry_blocked_ntf_cb;
} hal_mt_nb_ecc_cb_t;

typedef enum hal_mt_nb_ecc_cfg_reg_type_e {
    HAL_MT_NB_ECC_CFG_REG_TYPE_GEN_EN = 0,
    HAL_MT_NB_ECC_CFG_REG_TYPE_DETECT_EN,
    HAL_MT_NB_ECC_CFG_REG_TYPE_CORRECT_EN,
    HAL_MT_NB_ECC_CFG_REG_TYPE_CAPTURE_EN,
    HAL_MT_NB_ECC_CFG_REG_TYPE_CAPTURE_DERR_ONLY,
} hal_mt_nb_ecc_cfg_reg_type_t;
typedef struct hal_mt_nb_ecc_cfg_reg_s {
    hal_mt_nb_ecc_cfg_reg_type_t reg_type; /* register type: gen_en/detect_en */
    uint32 table_id;                       /* cfg regist table id */
    uint32 table_words;                    /* number of words occupied by this table id */
} hal_mt_nb_ecc_cfg_reg_t;

/* FUNCTION MACRO DECLARATIONS
 */

/**
 * @brief This API is used to write cache table when L2/L3 addHash or write entry in FPU.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    inst_idx       - Inst index.
 * @param [in]    subinst_idx    - Subinst index.
 * @param [in]    tab_id         - Table id.
 * @param [in]    entry_index    - Entry index in table.
 * @param [in]    entry_size     - Entry size.
 * @param [in]    ptr_entry      - Pointer to the entry buffer.
 * @return        CLX_E_OK        - Write success.
 * @return        CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
hal_mt_nb_ecc_cache_table_write(const uint32 unit,
                                const uint32 inst_idx,
                                const uint32 subinst_idx,
                                const uint32 tab_id,
                                const uint32 entry_index,
                                const uint32 entry_size,
                                uint32 *ptr_entry);

/**
 * @brief This API is used to delete cache table when L2/L3 addHash or write entry in FPU.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    inst_idx       - Inst index.
 * @param [in]    subinst_idx    - Subinst index.
 * @param [in]    tab_id         - Table id.
 * @param [in]    entry_index    - Entry index in table.
 * @param [in]    entry_size     - Entry size.
 * @param [in]    ptr_entry      - Pointer to the entry buffer.
 * @return        CLX_E_OK        - Write success.
 * @return        CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
hal_mt_nb_ecc_cache_table_del(const uint32 unit,
                              const uint32 inst_idx,
                              const uint32 subinst_idx,
                              const uint32 tab_id,
                              const uint32 entry_index,
                              const uint32 entry_size,
                              uint32 *ptr_entry);

/**
 * @brief This API is used to get table id by tile index for FPU.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     tile_index      - Tile index, max is HAL_MT_NAMCHABARWA_SWC_HASH_TILE_NUM.
 * @param [out]    ptr_table_id    - Output table id if the tile index.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
hal_mt_nb_ecc_table_id_get(const uint32 unit, const uint32 tile_index, uint32 *ptr_table_id);

/**
 * @brief This API is used to get cached hash table entry by one line(8 entry).
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     inst          - Inst index.
 * @param [in]     table_id      - Table id.
 * @param [in]     tile_index    - Tile index, max is HAL_MT_NAMCHABARWA_SWC_HASH_TILE_NUM.
 * @param [in]     mem_idx       - Memory index of each tile.
 * @param [in]     line_idx      - Line index of each memofy.
 * @param [out]    ptr_data      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
hal_mt_nb_ecc_hash_cached_line_entry_get(const uint32 unit,
                                         const uint32 inst,
                                         const uint32 table_id,
                                         const uint32 tile_index,
                                         const uint32 mem_idx,
                                         const uint32 line_idx,
                                         uint32 *ptr_data);

/**
 * @brief This API is used to get cached direct entry.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     inst           - Inst index.
 * @param [in]     table_id       - Table id.
 * @param [in]     entry_index    - Entry index in table.
 * @param [out]    ptr_entry      - Pointer to the entry buffer.
 * @return         CLX_E_OK        - Write success.
 * @return         CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
hal_mt_nb_ecc_direct_cache_get(const uint32 unit,
                               const uint32 inst,
                               const uint32 table_id,
                               const uint32 entry_index,
                               uint32 *ptr_entry);

/**
 * @brief This API is used to handle interrupt.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    ptr_cookie    - Interrupt hal_mt_intr_reg_node_t info.
 * @return        CLX_E_OK        - Write success.
 * @return        CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
hal_mt_nb_ecc_intr_handle(const uint32 unit, void *ptr_cookie);

/**
 * @brief This API is used to recover HW entry from cached entry data.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    inst_idx           - Inst index.
 * @param [in]    subinst_idx        - Subinst index.
 * @param [in]    table_id           - Table id.
 * @param [in]    entry_index        - Entry index in table.
 * @param [in]    ptr_cached_data    - Pointer to the cached entry buffer.
 * @return        CLX_E_OK        - Write success.
 * @return        CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
hal_mt_nb_ecc_cache_recover(const uint32 unit,
                            const uint32 inst_idx,
                            const uint32 subinst_idx,
                            const uint32 table_id,
                            const uint32 entry_index,
                            uint32 *ptr_cached_data);

/**
 * @brief This API is used to record ecc error log.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_intr_reg    - Interrupt hal_mt_intr_reg_node_t info.
 * @return        CLX_E_OK        - Write success.
 * @return        CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
hal_mt_nb_ecc_log_record(const uint32 unit, hal_mt_intr_reg_node_t *ptr_intr_reg);

/**
 * @brief This API is used to register a callback function that notify module when ecc error occurs
 *        too many times.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cb      - The callback function of type hal_mt_nb_ecc_recovery_notify_func_t.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_ecc_recover_cb_register(const uint32 unit, const hal_mt_nb_ecc_recovery_notify_func_t cb);

/**
 * @brief This API is used to register a callback function that notify module when ecc error occurs
 *        too many times.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cb      - The callback function of type hal_mt_nb_ecc_recovery_notify_func_t.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_ecc_recover_cb_deregister(const uint32 unit,
                                    const hal_mt_nb_ecc_recovery_notify_func_t cb);

/**
 * @brief This API is used to register a callback function that notify module when ecc error occurs
 *        too many times.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cb      - The callback function of type hal_mt_nb_ecc_entry_blocked_notify_func_t.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_ecc_entry_blocked_cb_register(const uint32 unit,
                                        const hal_mt_nb_ecc_entry_blocked_notify_func_t cb);

/**
 * @brief This API is used to register a callback function that notify module when ecc error occurs
 *        too many times.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cb      - The callback function of type hal_mt_nb_ecc_entry_blocked_notify_func_t.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_ecc_entry_blocked_cb_deregister(const uint32 unit,
                                          const hal_mt_nb_ecc_entry_blocked_notify_func_t cb);

/**
 * @brief This API is used to get table name.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    table_id    - Table name.
 * @return        ASM_SUB0_FD_FIFO_MEM    - Table name.
 */
const char *
hal_mt_nb_ecc_tbl_name_get(const uint32 unit, const uint32 table_id);

/**
 * @brief This API is used to get table id by table name.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_name      - Table name.
 * @param [out]    ptr_tbl_id    - Table id.
 * @return         HAL_MT_NB_ECC_TBL_ASM_SUB0_FD_FIFO_MEM_ID    - Table id.
 */
clx_error_no_t
hal_mt_nb_ecc_tbl_id_get(const uint32 unit, char *ptr_name, uint32 *ptr_tbl_id);
#endif /* #ifndef HAL_MT_NAMCHABARWA_ECC_H */
