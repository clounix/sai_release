/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecpu_elink.h
 * PURPOSE:
 *  1. Provide elink module macros and data structures.
 */

#ifndef HAL_ECPU_ELINK_H
#define HAL_ECPU_ELINK_H

/* INCLUDE FILE DECLARATIONS
 */
#include "hal/hal_ecpu_ringbuffer.h"
/* NAMING CONSTANT DECLARATIONS
 */
typedef clx_error_no_t (*hal_elink_app_deinit_func_t)(uint32 unit);

#define HAL_ELINK_LOG_INFO(...) UTIL_LOG_PRINT(UTIL_LOG_ECPU_ELINK, UTIL_LOG_INFO, __VA_ARGS__)
#define HAL_ELINK_LOG_WRN(...)  UTIL_LOG_PRINT(UTIL_LOG_ECPU_ELINK, UTIL_LOG_WARN, __VA_ARGS__)
#define HAL_ELINK_LOG_ERR(...)  UTIL_LOG_PRINT(UTIL_LOG_ECPU_ELINK, UTIL_LOG_ERR, __VA_ARGS__)

#define HAL_ELINK_MSG_DATA_START (1 << 0)
#define HAL_ELINK_MSG_DATA_END   (1 << 1)
#define HAL_ELINK_MSG_DATA_WHOLE (HAL_ELINK_MSG_DATA_START | HAL_ELINK_MSG_DATA_END)
#define HAL_ELINK_KA_TIMEOUT     (1000)        /*ms*/
#define HAL_ELINK_WAIT_UP_PERIOD (2000)        /*2ms*/
#define HAL_ELINK_WAIT_UP_MAX    (3000)
#define HAL_ELINK_RSP_TIMEOUT    (1000 * 1000) /* 1S */

#define HAL_ELINK_MAX_APP                  (32)
#define HAL_ELINK_APP_QUE_SEM_TAKE_TIMEOUT (1000)       /*1ms*/
#define HAL_ELINK_NOTIFY_SEM_TAKE_TIMEOUT  (1000 * 100) /*100ms*/
#define HAL_ELINK_NOTIFY_QUEUE_CAPACITY    64
#define HAL_ELINK_NOTIFY_THREAD_STACK_SIZE 16 * 1024

clx_error_no_t
hal_elink_rx_irq_handler(uint32 unit);

#define HAL_ELINK_KA_MAXCNT       (3)
#define HAL_ELINK_WAITACK_TIMEOUT (5)
#define HAL_ELINK_SENDTYPE_CTRL   (1 << 0)
#define HAL_ELINK_SENDTYPE_KA     (1 << 1)
#define HAL_ELINK_SENDTYPE_DATA   (1 << 2)
#define HAL_ELINK_CFG_QUE_LEN     (128)

#define HAL_ELINK_RX_CNT_INCR(unit)         (hal_elink_stat[(unit)].rx_cnt++)
#define HAL_ELINK_RX_KEEP_INCR(unit)        (hal_elink_stat[(unit)].rx_keep++)
#define HAL_ELINK_RX_ACK_INCR(unit)         (hal_elink_stat[(unit)].rx_ack++)
#define HAL_ELINK_RX_DISCNT_INCR(unit)      (hal_elink_stat[(unit)].rx_discnt++)
#define HAL_ELINK_RX_PKT_INCR(unit)         (hal_elink_stat[(unit)].rx_pkt++)
#define HAL_ELINK_RX_DROP_CNT_INCR(unit)    (hal_elink_stat[(unit)].rx_drop_cnt++)
#define HAL_ELINK_RX_DROP_KEEP_INCR(unit)   (hal_elink_stat[(unit)].rx_drop_keep++)
#define HAL_ELINK_RX_DROP_ACK_INCR(unit)    (hal_elink_stat[(unit)].rx_drop_ack++)
#define HAL_ELINK_RX_DROP_DISCNT_INCR(unit) (hal_elink_stat[(unit)].rx_drop_discnt++)
#define HAL_ELINK_RX_DROP_PKT_INCR(unit)    (hal_elink_stat[(unit)].rx_drop_pkt++)

#define HAL_ELINK_TX_CNT_INCR(unit)         (hal_elink_stat[(unit)].tx_cnt++)
#define HAL_ELINK_TX_KEEP_INCR(unit)        (hal_elink_stat[(unit)].tx_keep++)
#define HAL_ELINK_TX_ACK_INCR(unit)         (hal_elink_stat[(unit)].tx_ack++)
#define HAL_ELINK_TX_DISCNT_INCR(unit)      (hal_elink_stat[(unit)].tx_discnt++)
#define HAL_ELINK_TX_PKT_INCR(unit)         (hal_elink_stat[(unit)].tx_pkt++)
#define HAL_ELINK_TX_DROP_CNT_INCR(unit)    (hal_elink_stat[(unit)].tx_drop_cnt++)
#define HAL_ELINK_TX_DROP_KEEP_INCR(unit)   (hal_elink_stat[(unit)].tx_drop_keep++)
#define HAL_ELINK_TX_DROP_ACK_INCR(unit)    (hal_elink_stat[(unit)].tx_drop_ack++)
#define HAL_ELINK_TX_DROP_DISCNT_INCR(unit) (hal_elink_stat[(unit)].tx_drop_discnt++)
#define HAL_ELINK_TX_DROP_PKT_INCR(unit)    (hal_elink_stat[(unit)].tx_drop_pkt++)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
#pragma pack(1)
/*
 *   ---------------------------------------------------
 *  | ELINK_MSG_HDR | ELINK_MSG_DATA_HDR | APP_DATA_HDR |
 *   ---------------------------------------------------
 */
typedef struct hal_elink_msg_hdr_s {
    uint8 machine_id; /*0: host CPU， 1 - eCPU1， 2-eCPU2... */
    uint8 msg_type;   /*connect,disconnect,keepalive,data,ack,connectack...*/
    uint16 seq_id;
    uint16 len;       /*load length*/
    uint8 data[0];
} hal_elink_msg_hdr_t;

typedef struct hal_elink_msg_data_hdr_s {
    uint8 data_type : 6; /*hal_elink_data_msg_type_t:0:req, 1:rsp, 2:noitfy */
    uint8 flags : 2;     /*bit0:start of the msg  bit1:end of the msg*/
    uint8 app_id;        /*Data message sub-type: cfg,ptp,port-map,couter...*/
    uint8 data[0];       /*APP message header*/
} hal_elink_msg_data_hdr_t;

typedef struct hal_elink_hdr_s {
    hal_elink_msg_hdr_t mhdr;
    hal_elink_msg_data_hdr_t dhdr;
} hal_elink_hdr_t;

#pragma pack()

typedef struct hal_elink_queue_info_s {
    uint32 unit;
    hal_elink_msg_hdr_t *pmsg;
} hal_elink_queue_info_t;

typedef enum hal_elink_data_msg_type_e {
    HAL_ELINK_DATA_MSG_TYPE_REQ,
    HAL_ELINK_DATA_MSG_TYPE_RSP,
    HAL_ELINK_DATA_MSG_TYPE_NTF,
} hal_elink_data_msg_type_t;

typedef clx_error_no_t (*hal_elink_app_notify_func_t)(uint32 unit, hal_elink_msg_data_hdr_t *dmsg);

typedef enum hal_elink_app_id_e {
    HAL_ELINK_APP_TYPE_MISC,
    HAL_ELINK_APP_TYPE_PTP,
    HAL_ELINK_APP_TYPE_DIAG,
    HAL_ELINK_APP_TYPE_BFD,
    HAL_ELINK_APP_TYPE_LAST
} hal_elink_app_id_t;

typedef struct hal_elink_queue_s {
    util_lib_queue_t *pfifo;
    clx_semaphore_id_t sem;
    clx_semaphore_id_t sync; /*Used to notify threads to dequeue */
} hal_elink_queue_t;

typedef enum hal_elink_machine_id_e {
    HAL_ELINK_MACHINE_ID_HOSTCPU,
    HAL_ELINK_MACHINE_ID_ECPU1,
    HAL_ELINK_MACHINE_ID_ECPU2,
    HAL_ELINK_MACHINE_ID_LAST
} hal_elink_machine_id_t;

typedef enum hal_elink_fsm_status_e {
    HAL_ELINK_FSM_INIT,
    HAL_ELINK_FSM_WAIT_ACK,
    HAL_ELINK_FSM_WAIT_CONNECT,
    HAL_ELINK_FSM_ESTABLISHED,
    HAL_ELINK_FSM_DISCONNECTED,
    HAL_ELINK_FSM_LAST
} hal_elink_fsm_status_t;

typedef enum hal_elink_event_e {
    HAL_ELINK_EVENT_START,
    HAL_ELINK_EVENT_CNT_SEND,
    HAL_ELINK_EVENT_CNT_RCV,
    HAL_ELINK_EVENT_ACK,
    HAL_ELINK_EVENT_DISCNT,
    HAL_ELINK_EVENT_LAST
} hal_elink_event_t;

typedef struct hal_elink_fsm_s {
    hal_elink_fsm_status_t fsm;
    uint16 seq_id; /*sequence*/
} hal_elink_fsm_t;

typedef enum hal_elink_msg_type_e {
    HAL_ELINK_MSG_TYPE_CONNECT,    /*connect message*/
    HAL_ELINK_MSG_TYPE_DISCONNECT, /*disconnect message*/
    HAL_ELINK_MSG_TYPE_KA,         /*keep alive message*/
    HAL_ELINK_MSG_TYPE_DATA,       /*data message*/
    HAL_ELINK_MSG_TYPE_ACK,
    HAL_ELINK_MSG_TYPE_LAST
} hal_elink_msg_type_t;

typedef enum hal_elink_media_type_e {
    HAL_ELINK_MEDIA_TYPE_REGISTER,
    HAL_ELINK_MEDIA_TYPE_DTCM,
    HAL_ELINK_MEDIA_TYPE_ITCM
} hal_elink_media_type_t;

typedef struct hal_elink_ka_s {
    uint16 timeout_cnt;
    uint16 time; /*Wait for ack time*/
    osal_timer_id_t timer;
    uint16 seq_id;
} hal_elink_ka_t;

typedef struct hal_elink_cache_s {
    hal_elink_msg_hdr_t *pmsg;
    uint32 offset;
    uint32 len;
} hal_elink_cache_t;

typedef struct hal_elink_ctrl_s {
    uint8 local_id;
    uint8 remote_id;
    uint16 seq_id;
    hal_elink_fsm_t elink_fsm;
    hal_elink_ka_t ka; /*keep alive*/
    hal_elink_cache_t cache;
    hal_ecpu_ring_buffer_control_t rxbuf;
    hal_ecpu_ring_buffer_control_t txbuf;
    uint32 unit;
    uint8 sendtype;
    uint8 init;
} hal_elink_ctrl_t;

typedef struct hal_elink_app_entry_s {
    uint8 app_id;
    uint16 valid;
    hal_elink_queue_t *pqueue;
    hal_elink_app_deinit_func_t deinit;
} hal_elink_app_entry_t;

typedef struct hal_elink_app_ctrl_s {
    hal_elink_app_entry_t app_vec[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_ELINK_MAX_APP];
    clx_semaphore_id_t sem;
    uint32 init_done;
    int32 num[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
    uint32 map[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM][HAL_ELINK_MAX_APP];
} hal_elink_app_ctrl_t;

typedef struct hal_elink_statistic_s {
    uint64 rx_cnt;
    uint64 rx_keep;
    uint64 rx_ack;
    uint64 rx_discnt;
    uint64 rx_pkt; /*data*/
    uint64 rx_drop_cnt;
    uint64 rx_drop_keep;
    uint64 rx_drop_ack;
    uint64 rx_drop_discnt;
    uint64 rx_drop_pkt;

    uint64 tx_cnt;
    uint64 tx_keep;
    uint64 tx_ack;
    uint64 tx_discnt;
    uint64 tx_pkt; /*data*/
    uint64 tx_drop_cnt;
    uint64 tx_drop_keep;
    uint64 tx_drop_ack;
    uint64 tx_drop_discnt;
    uint64 tx_drop_pkt;
} hal_elink_statistic_t;

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */
extern hal_elink_statistic_t hal_elink_stat[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to create application queue.
 *
 * @param [in]     pname     - Application register name pointer.
 * @param [in]     len       - Application register name length.
 * @param [out]    pqueue    - Queue handler.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_app_queue_create(const char *pname, const uint32 len, hal_elink_queue_t *pqueue);

/**
 * @brief This API is used to destroy application queue.
 *
 * @param [in]    pqueue    - Queue handler.
 * @return        CLX_E_OTHERS           - Operate failed.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_app_queue_destroy(hal_elink_queue_t *pqueue);

/**
 * @brief This API is used to get application queue.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     app_id     - Application id.
 * @param [out]    ppqueue    - Queue handler.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_app_queue_get(const uint32 unit, const uint8 app_id, hal_elink_queue_t **ppqueue);

/**
 * @brief This API is used to clear application queue message buffer.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    app_id    - Application id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_app_queue_clr(const uint32 unit, const uint8 app_id);

/**
 * @brief This API is used to register application queue to elink.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    app_id    - Application id.
 * @param [in]    pqueue    - Queue handler.
 * @param [in]    deinit    - Deinit handler.
 * @return        CLX_E_OK              - Operate success.
 * @return        CLX_E_OTHERS          - Operate failed.
 * @return        CLX_E_TABLE_FULL      - Table is full.
 * @return        CLX_E_ENTRY_EXISTS    - Application is already registered.
 */
clx_error_no_t
hal_elink_app_register(const uint32 unit,
                       const uint8 app_id,
                       hal_elink_queue_t *pqueue,
                       const hal_elink_app_deinit_func_t deinit);

/**
 * @brief This API is used to deregister application queue to elink.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    app_id    - Application id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_OTHERS           - Operate failed.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_app_deregister(const uint32 unit, const uint8 app_id);

/**
 * @brief This API is used to get elink control block.
 *
 * @param [in]    unit    - Device unit number.
 * @return        hal_elink_ctrl_t *    - Elink control block.
 */
hal_elink_ctrl_t *
hal_elink_elink_cb_get(const uint32 unit);

/**
 * @brief This API is used to register notify callback function.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    app_id    - Application id.
 * @param [in]    func      - Callback function.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_notify_register(const uint32 unit,
                          const uint8 app_id,
                          const hal_elink_app_notify_func_t func);

/**
 * @brief This API is used to unregister notify callback function.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    app_id    - Application id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_notify_unregister(const uint32 unit, const uint8 app_id);

/**
 * @brief This API is used to start notify thread.
 *
 * @param  [in]    void      - void.
 *
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_notify_start(void);

/**
 * @brief This API is used to stop notify thread.
 *
 * @param    [in]    void      - void.
 *
 * @return        Void.
 */
void
hal_elnk_notify_stop(void);

/**
 * @brief This API is used to encapsulate the data into an elink request message and send it.
 *
 * The memory pointed to by pdata is managed by APP, and elink does not release it.
 * pdata on the SDK side must use the memory requested by osal_alloc.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    app_id    - Application id.
 * @param [in]    pdata     - Message pointer.
 * @param [in]    len       - Message length.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_OTHERS           - Operate failed.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_msg_req_tx(const uint32 unit, const uint8 app_id, const uint8 *pdata, const uint16 len);

/**
 * @brief This API is used to encapsulate the data into an elink response message and send it.
 *
 * The memory pointed to by pdata is managed by APP, and elink does not release it.
 * pdata on the SDK side must use the memory requested by osal_alloc.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    app_id    - Application id.
 * @param [in]    pdata     - Message pointer.
 * @param [in]    len       - Message length.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_OTHERS           - Operate failed.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_msg_rsp_tx(const uint32 unit, const uint8 app_id, const uint8 *pdata, const uint16 len);

/**
 * @brief This API is used to encapsulate the data into an elink notify message and send it.
 *
 * The memory pointed to by pdata is managed by APP, and elink does not release it.
 * pdata on the SDK side must use the memory requested by osal_alloc.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    app_id    - Application id.
 * @param [in]    pdata     - Message pointer.
 * @param [in]    len       - Message length.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_OTHERS           - Operate failed.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_msg_notify_tx(const uint32 unit, const uint8 app_id, const uint8 *pdata, const uint16 len);

/**
 * @brief This API is used to receive response message from elink.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     app_id    - Application id.
 * @param [out]    ppmsg     - Received message pointer.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_msg_rsp_rx(const uint32 unit, uint8 app_id, void **ppmsg);

/**
 * @brief This API is used to get elink statistics.
 *
 * @param [in]    unit    - Device unit number.
 * @return        hal_elink_statistic_t *    - Elink statistics control block.
 */
hal_elink_statistic_t *
hal_elink_stat_get(const uint32 unit);

/**
 * @brief This API is used to clear elink statistics.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Operate success.
 * @return        CLX_E_OTHERS        - Operate failed.
 * @return        CLX_E_NOT_INITED    - Not initialized.
 */
clx_error_no_t
hal_elink_stat_clr(uint32 unit);

/**
 * @brief This API is used to get receive message channel data pointer index.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    prindex    - Read point index.
 * @param [out]    pwindex    - Write point index.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_rx_rw_idx_get(const uint32 unit, uint32 *prindex, uint32 *pwindex);

/**
 * @brief This API is used to get send message channel data pointer index.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    prindex    - Read point index.
 * @param [out]    pwindex    - Write point index.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_tx_rw_idx_get(const uint32 unit, uint32 *prindex, uint32 *pwindex);

/**
 * @brief This API is used to reset elink module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        Void.
 */
void
hal_elink_reset(const uint32 unit);

/**
 * @brief This API is used to wait elink up.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_OTHERS           - Operate failed.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_elink_wait_up(const uint32 unit);

/**
 * @brief This API is used to Check whether elink is up.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Elink is up.
 * @return        CLX_E_OTHERS    - Elink is down.
 */
clx_error_no_t
hal_elink_is_up(const uint32 unit);

/**
 * @brief This API is used to init elink module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_init(const uint32 unit);

/**
 * @brief This API is used to deinit elink module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_deinit(const uint32 unit);

/**
 * @brief This API is used to dequeue the message from elink queue.
 *
 * @param [in]     pqueue    - Queue handler.
 * @param [out]    ppmsg     - Message pointer.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_dequeue(hal_elink_queue_t *pqueue, void **ppmsg);

/**
 * @brief This API is used to dequeue the message from elink queue.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     pqueue    - Queue handler.
 * @param [out]    ppmsg     - Message pointer.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_with_unit_dequeue(uint32 *unit, hal_elink_queue_t *pqueue, void **ppmsg);

/**
 * @brief This API is used to enqueue the message from elink queue.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    pqueue    - Queue handler.
 * @param [in]    pmsg      - Message pointer.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_elink_with_unit_enqueue(const uint32 unit, hal_elink_queue_t *pqueue, void *pmsg);

#endif
