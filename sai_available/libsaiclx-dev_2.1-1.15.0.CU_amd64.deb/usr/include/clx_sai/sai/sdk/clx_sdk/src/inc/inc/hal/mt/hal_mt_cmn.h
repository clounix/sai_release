/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_cmn.h
 * PURPOSE:
 *  1. To maintain common internal utility API, such as src_supp_tag management,
 *     or exception code management.
 * NOTES:
 */

#ifndef HAL_MT_CMN_H
#define HAL_MT_CMN_H

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_RSV_NVO3_ENCAP_INVALID_IDX  (0)
#define HAL_MT_RSV_NVO3_ENCAP_INVALID2_IDX (1024)
#define HAL_MT_RSV_EVPN_PBM_ENTRY          (0)

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Common Hw resource table/lock init.
 *
 * For cl8600.
 *
 * @param [in]     unit    - device unit number
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_mt_cmn_init(const uint32 unit);

/**
 * @brief Common Hw resource table/lock deinit.
 *
 * For cl8600.
 *
 * @param [in]     unit    - device unit number
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_mt_cmn_deinit(const uint32 unit);

/**
 * @brief Get nvo3_encap_idx from l3t_port/lsp_port/srv6_port
 *
 * For cl8600.
 *
 * @param [in]     unit                  - device unit number
 * @param [in]     port                  - l3t_port/lsp_port/srv6_port
 * @param [in]     ptr_key               - tunnel key for mc tunnel
 * @param [out]    ptr_nvo3_encap_idx    - index to RWO_SRAM_NVO3_ENCAP (all planes equal value)
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_mt_cmn_encap_idx_get_from_port(const uint32 unit,
                                   const clx_port_t port,
                                   const clx_tnl_info_t *ptr_key,
                                   uint32 *ptr_nvo3_encap_idx);

/**
 * @brief Get l3t_port/lsp_port/srv6_port from nvo3_encap_idx
 *
 * For cl8600.
 *
 * @param [in]     unit              - device unit number
 * @param [in]     nvo3_encap_idx    - index of RWO_SRAM_NVO3_ENCAP
 * @param [out]    ptr_port          - l3t_port/lsp_port/srv6_port
 * @param [out]    ptr_key           - tunnel key for mc tunnel
 * @param [out]    ptr_use_port      - indicate output ptr_port or ptr_key
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_mt_cmn_port_get_from_encap_idx(const uint32 unit,
                                   const uint32 nvo3_encap_idx,
                                   clx_port_t *ptr_port,
                                   clx_tnl_info_t *ptr_key,
                                   boolean *ptr_use_port);

#endif
