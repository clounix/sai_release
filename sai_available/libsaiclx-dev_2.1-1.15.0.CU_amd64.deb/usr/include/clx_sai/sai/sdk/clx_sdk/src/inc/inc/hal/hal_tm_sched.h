/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_tm_sched.h
 * PURPOSE:
 *      It provides hal tm SCHED module schedule block API.
 * NOTES:
 *
 *
 */

#ifndef HAL_TM_SCHED_H
#define HAL_TM_SCHED_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_tm.h>
#include <hal/hal_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TM_SCHED_LOCK(unit)   (hal_tm_sched_rsrc_lock(unit))
#define HAL_TM_SCHED_UNLOCK(unit) (hal_tm_sched_rsrc_unlock(unit))

/* DATA TYPE DECLARATIONS
 */

/*control block for sch module*/
typedef struct hal_tm_sched_cb_s {
    /*semaphore for schedule block*/
    clx_semaphore_id_t sch_sema;
} hal_tm_sched_cb_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

extern clx_error_no_t
hal_tm_sched_ctrl_block_get(const uint32 unit, hal_tm_sched_cb_t **pptr_cb);

/**
 * @brief Init tm module sch software shadow and hardware shadow.
 *
 * This function will allocate memory.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_tm_sched_rsrc_init(const uint32 unit);

/**
 * @brief Deinit tm module sch software shadow and hardware shadow.
 *
 * This function will free memory.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_tm_sched_rsrc_deinit(const uint32 unit);

/**
 * @brief Lock semaphore of tm schedule block.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Success.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_tm_sched_rsrc_lock(const uint32 unit);

/**
 * @brief Unlock semaphore of tm schedule block.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Success.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_tm_sched_rsrc_unlock(const uint32 unit);

clx_error_no_t
hal_tm_sched_db_dump(const uint32 unit);

#endif /* End of HAL_TM_SCHED_H */
