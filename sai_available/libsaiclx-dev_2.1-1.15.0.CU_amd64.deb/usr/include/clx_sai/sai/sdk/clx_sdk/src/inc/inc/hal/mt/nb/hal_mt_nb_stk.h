/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_stk.h
 * PURPOSE:
 *      It provides hal stacking module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NB_STK_H
#define HAL_MT_NB_STK_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_stk.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum { HAL_CHIP_TYP_LC = 0, HAL_CHIP_TYP_FAB = 1 } HAL_CHIP_TYP_ENUM_T;

typedef enum { HAL_FL_TYP_ETH = 0, HAL_FL_TYP_FAB = 1 } HAL_FL_TYP_ENUM_T;

typedef enum { HAL_CHASSIS_MODE_DISABLE = 0, HAL_CHASSIS_MODE_ENABLE = 1 } HAL_CHASSIS_MODE_T;

typedef enum { HAL_ASIC_DEF_LINECARD = 0, HAL_ASIC_DEF_FABRIC = 1 } HAL_ASIC_DEF_T;
typedef enum hal_mt_nb_stk_fl_hash_sel_e {
    HAL_MT_NB_STK_FL_HASH_SEL_MODULO = 0,
    HAL_MT_NB_STK_FL_HASH_SEL_MULTIPLY_SHIFT = 1
} hal_mt_nb_stk_fl_hash_sel_t;

typedef enum hal_mt_nb_stk_rep_sch_e {
    HAL_MT_NB_STK_REP_SCH_WITHOUT_LOCAL_MC_REP = 0,
    HAL_MT_NB_STK_REP_SCH_LOCAL_MC_REP = 1
} hal_mt_nb_stk_rep_sch_t;

typedef enum hal_mt_nb_stk_cpu_di_src_e {
    HAL_MT_NB_STK_REDIRECT_TO_CPU_L2UC,
    HAL_MT_NB_STK_REDIRECT_TO_CPU_L3UC,
} hal_mt_nb_stk_cpu_di_src_t;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */

/**
 * @brief Initiate the stk software resource, such as software database and semaphore.
 *
 * @param [in]    unit    - Device unit number.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_stk_rsrc_init(const uint32 unit);

/**
 * @brief Initiate the stk hardware configuration.
 *
 * @param [in]    unit    - Device unit number.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_stk_cfg_init(const uint32 unit);

/**
 * @brief Set chip id.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    chip    - Device chip id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_my_chip_id_set(const uint32 unit, const uint32 chip);

/**
 * @brief Add stacking port to a stacking group path.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    path    - Path id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_stacking_port_add(const uint32 unit, const uint32 path, const uint32 port);

/**
 * @brief Delete stacking port from a stacking group path.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    path    - Path id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_stacking_port_del(const uint32 unit, const uint32 path, const uint32 port);

/**
 * @brief Get stacking port list from a stacking group path.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     path             - Path id.
 * @param [out]    ptr_port_list    - Port list.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_stacking_port_get(const uint32 unit,
                                const uint32 path,
                                clx_port_bitmap_t *ptr_port_list);

/**
 * @brief Get dpi port list.
 *
 * @param [in]     unit             - Device unit number.
 * @param [out]    ptr_port_list    - Port list.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */

clx_error_no_t
hal_mt_nb_stk_dpi_port_get(const uint32 unit, clx_port_bitmap_t *ptr_port_list);

/**
 * @brief Add dpi port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_dpi_port_add(const uint32 unit, const uint32 port);

/**
 * @brief Delete dpi port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_dpi_port_del(const uint32 unit, const uint32 port);

/**
 * @brief Set a path to the remote chip.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    path    - Path id.
 * @param [in]    chip    - Device chip id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_path_to_remote_chip_set(const uint32 unit, const uint32 path, const uint32 chip);

/**
 * @brief Set the DIL entry.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    di               - Destination index.
 * @param [in]    ptr_dil_entry    - DIL entry.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_dil_entry_set(const uint32 unit, const uint32 di, const clx_stk_dil_t *ptr_dil_entry);

/**
 * @brief Get the DIL entry.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     di               - Destination index.
 * @param [out]    ptr_dil_entry    - DIL entry.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_dil_entry_get(const uint32 unit, const uint32 di, clx_stk_dil_t *ptr_dil_entry);

/* EXPORTED HAL PROGRAMS
 */
/**
 * @brief Set the lag as fabric path.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    lag_id    - Lag id.
 * @param [in]    is_fl     - Lag members with remote di or not.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_dst_lag_set(const uint32 unit, const uint32 lag_id, const uint32 is_fl);

/**
 * @brief Get fabric port bitmap in hw plane port view.
 *
 * 1. For pp_pbmp size, please reference HAL_ITM_PBM_WORDS.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_pp_pbmp    - Mgid port bitmap (optional).
 * @param [out]    cl_pbmp        - Clx_port_bitmap_t (optional).
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_fab_port_bmp_get(const uint32 unit, uint32 *ptr_pp_pbmp, clx_port_bitmap_t cl_pbmp);

/**
 * @brief Check given port is used as fabric port or not.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port 0 : used as front port.
 * @param [out]    ptr_is_fab    - Status.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_fab_port_check(const uint32 unit, const uint32 port, boolean *ptr_is_fab);

/**
 * @brief Set CPU DI priority and CPU queue ID.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    property    - Property type.
 * @param [in]    value       - DI priority or queue ID value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_cpu_di_property_set(const uint32 unit,
                                  const clx_swc_cpu_di_property_t property,
                                  const uint32 value);

/**
 * @brief Get CPU DI priority and CPU queue ID.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     property     - Property type.
 * @param [out]    ptr_value    - DI priority or queue ID value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stk_cpu_di_property_get(const uint32 unit,
                                  const clx_swc_cpu_di_property_t property,
                                  uint32 *ptr_value);

/**
 * @brief Get CPU DI.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     src           - CPU DI user.
 * @param [out]    ptr_cpu_di    - CPU DI.
 * @return         CLX_E_OK    - Operate success.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stk_cpu_di_get(const uint32 unit,
                         const hal_mt_nb_stk_cpu_di_src_t src,
                         uint32 *ptr_cpu_di);

/**
 * @brief Update stacking configuration once link change.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Cl port.
 * @param [in]    enable    - Link status.
 * @return        CLX_E_OK    - Operate success.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stk_update_by_link_change(const uint32 unit, const uint32 port, const boolean enable);

/**
 * @brief Set stacking fl hash select configuration.
 *
 * Support_chip: all.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    value    - Config value.
 * @return        CLX_E_OK    - Operate success.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stk_fl_hash_sel_set(const uint32 unit, const uint32 value);

/**
 * @brief Get stacking fl hash select configuration.
 *
 * Support_chip: all.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_value    - Config value.
 * @return         CLX_E_OK    - Operate success.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stk_fl_hash_sel_get(const uint32 unit, uint32 *ptr_value);

/**
 * @brief Set the destination ucdi.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    di       - Destination index.
 * @param [in]    is_fl    - Is fabric port or not.
 * @return        CLX_E_OK    - Operate success.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stk_dst_ucdi_set(const uint32 unit, const uint32 di, const uint32 is_fl);
/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif
