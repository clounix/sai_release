/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_pkt.h
 * PURPOSE:
 *      Provide the interface for packet TX/RX configuration.
 *
 * NOTES:
 *
 */

#ifndef CLX_PKT_H
#define CLX_PKT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>

/* NAMING DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* The reason defined for the packets which are copied/redirected to CPU. */

/* RX Packet Reasons */
typedef enum {
    CLX_PKT_RX_REASON_ECIA_SFLOW = 0,     /* Egress flow-based sflow hit. */
    CLX_PKT_RX_REASON_VLAN_MISS_VLAN_CHK, /* VLAN lookup miss or not accepted. */
    CLX_PKT_RX_REASON_PAR_ERR,            /* Parser error to CPU. */
    CLX_PKT_RX_REASON_DOS_CHK,            /* DoS checking fail to CPU. */
    CLX_PKT_RX_REASON_URPF_CHECK_FAIL,    /* L3 URPF check fail to CPU. */
    CLX_PKT_RX_REASON_L3_LKP_MISS,        /* L3 lookup miss to CPU. */
    CLX_PKT_RX_REASON_ICMP_REDIRECT,      /* The same L3 interface for ingress and egress to CPU. */
    CLX_PKT_RX_REASON_IPV4_HDR_OPTION,    /* IPv4 header with option to CPU. */
    CLX_PKT_RX_REASON_IGR_PORT_SFLOW,     /* Ingress port-based sflow hit. */
    CLX_PKT_RX_REASON_EGR_PORT_SFLOW,     /* Egress port-based sflow hit. */
    CLX_PKT_RX_REASON_IPSG_CHK,           /* IPSG check fail to CPU. */
    CLX_PKT_RX_REASON_L3MC_RPF_CHECK,     /* L3MC RPF check fail to CPU */
    CLX_PKT_RX_REASON_IPV6_HOP_BY_HOP_EXT_HDR, /* IPv6 with hop by hop extension header to CPU. */
    CLX_PKT_RX_REASON_PIM_REGISTER,            /* For source hit and group miss, send to CPU for
                                                  PIM-registration. */
    CLX_PKT_RX_REASON_L3MC_SPT_READY_UNSET,    /* L3MC to CPU to trigger setting Shortest Path Tree
                                                  ready bit. */
    CLX_PKT_RX_REASON_IGR_MTU_FAIL,            /* Ingress MTU check fail to CPU. */
    CLX_PKT_RX_REASON_EGR_MTU_FAIL,            /* Egress MTU check fail to CPU. */
    /* 16 */
    CLX_PKT_RX_REASON_REDIRECT_TO_CPU_L3MC, /* L3MC Redirect to CPU. */
    CLX_PKT_RX_REASON_L2_LKP_MISS,       /* L2 lookup failed with the bank error or entry miss. */
    CLX_PKT_RX_REASON_L2_SA_MISS,        /* L2 lookup SA miss. */
    CLX_PKT_RX_REASON_L2_SA_MOVE,        /* L2 lookup SA hit but interface move. */
    CLX_PKT_RX_REASON_IPV4_MC_MALFORMED, /* IPv4 multicast packet is malformed from RFC. */
    CLX_PKT_RX_REASON_IPV4_MC_LKP_MISS,  /* IPv4 multicast packet lookup miss. */
    CLX_PKT_RX_REASON_IPV6_MC_MALFORMED, /* IPv6 multicast packet is malformed from RFC. */
    CLX_PKT_RX_REASON_IPV6_MC_LKP_MISS,  /* IPv6 multicast packet lookup miss. */
    CLX_PKT_RX_REASON_IP_TUNNEL_INNER_VER_ERR, /* IP tunnel packet inner is not IPv4 and IPv6. */

    CLX_PKT_RX_REASON_GRE_VER_ERR,             /* GRE tunnel version is illegal from RFC 2784. */
    CLX_PKT_RX_REASON_GRE_CTRL_FLAG_ERR, /* GRE tunnel control flag is illegal from RFC 2784. */

    CLX_PKT_RX_REASON_GRE_ERSPAN_TERM_LKP_MISS, /* GRE ERSPAN tunnel term lookup miss. */
    CLX_PKT_RX_REASON_VXLAN_BAS_CTRL_FLAG_ERR,  /* VXLAN Basic header control flag is illegal from
                                                   RFC. */
    CLX_PKT_RX_REASON_VXLAN_BAS_UDP_CHKSM_ERR,  /* VXLAN Basic header UDP checksum is abnormal. */

    CLX_PKT_RX_REASON_VXLAN_GPE_CTRL_FLAG_ERR, /* VXLAN GPE header control flag is illegal from RFC.
                                                */
    /* 32 */
    CLX_PKT_RX_REASON_ECMP_LKP_MISS,   /* ECMP lookup failed with the bank error or entry miss. */
    CLX_PKT_RX_REASON_IGR_L3_MTU_FAIL, /* Ingress L3 MTU check fail to CPU. */
    CLX_PKT_RX_REASON_EGR_L3_MTU_FAIL, /* Egress L3 MTU check fail to CPU. */
    CLX_PKT_RX_REASON_IGR_TUNNEL_MTU_FAIL, /* Ingress Tunnel MTU check fail to CPU. */
    CLX_PKT_RX_REASON_EGR_TUNNEL_MTU_FAIL, /* Egress Tunnel MTU check fail to CPU. */
    CLX_PKT_RX_REASON_PORT_MTR_DROP,       /* Meter over rate drop, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_MGO_HIT,  /* IP tunnel (*, G) lookup hit copy to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_MSGO_HIT, /* IP tunnel (S, G) lookup hit copy to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_SPT_RDY_UNSET,  /* IP tunnel (S, G) ready, notify to update spt ready
                                                bit, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_INVALID_SA,     /* Tunnel header SMAC invalid to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_TTL_0, /* IP tunnel packet outer TTL is 0 to CPU, CL8600 only.
                                              */
    CLX_PKT_RX_REASON_IP_TUNNEL_OUTER_TTL_1, /* IP tunnel packet outer TTL is 1 to CPU, CL8600 only.
                                              */
    CLX_PKT_RX_REASON_IP_TUNNEL_IP_HDR_ERR,  /* IP tunnel pacet IP invalid to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_UNK_PLD,        /* IP tunnel unknown payload to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_SPTO_BLOCK,     /* Underlay STP block packets to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_RMAC_MISS,        /* MPLS packtes DMAC not match to CPU, CL8600 only. */
    /* 48 */
    CLX_PKT_RX_REASON_TUNNEL_MGO_MISS,  /* IP tunnel (*, G) lookup miss to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_MSGO_MISS, /* IP tunnel (S, G) lookup miss to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_LSP_MISS, /* MPLS packets LSP label lookup miss to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_SA_DA_BIND,  /* IP tunnel SIP and DIP bind check fail to CPU, CL8600
                                             only. */
    CLX_PKT_RX_REASON_TUNNEL_RPF_CHECK,   /* IP tunnel multicast RPF check fail to CPU, CL8600 only.
                                           */
    CLX_PKT_RX_REASON_GENEVE_VER_ERR,     /* GENEVE packets version is illegal from RFC8926, CL8600
                                             only. */
    CLX_PKT_RX_REASON_GENEVE_CTRL_FLAG_O, /* GENEVE packets O-bit is illegal form RFC8926, CL8600
                                             only. */
    CLX_PKT_RX_REASON_GENEVE_CTRL_FLAG_C, /* GENEVE packets C-bit is illegal form RFC8926, CL8600
                                             only. */
    CLX_PKT_RX_REASON_MPLS_LSP_RSVD,      /* Select RSVD or RSVD1 via the register MPLS_rsvd_excpt,
                                             CL8600 only.*/
    CLX_PKT_RX_REASON_MPLS_LSP_RSVD1,     /* Select RSVD or RSVD1 via the register MPLS_rsvd_excpt,
                                             CL8600 only.*/
    CLX_PKT_RX_REASON_MPLS_ELI_BOS,       /* ELI label is at the bottom, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_NULL_TOP,      /* NULL label not at the top, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_EXPOSE_TTL0,   /* VPN or Transit label ttl id 0, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_EXPOSE_TTL1,   /* VPN or Transit label ttl id 1, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_NULL_IP, /* No VPN labe and have NULL label, the inner layer is not the
                                       IP but the Ether, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_EL_IP, /* Only have LSP and have entroy label, the inner layer is not the
                                     IP but the Ether, CL8600 only. */
    /* 64 */
    CLX_PKT_RX_REASON_MPLS_LSP_IP,    /* Only have LSP, the inner is not Ether, CL8600 only. */
    CLX_PKT_RX_REASON_SRV6_FUNC_MISS, /* SRv6 packets function lookup miss to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_SRH_ERR,        /* SRH is illegal from RFC, CL8600 only. */
    CLX_PKT_RX_REASON_SRV6_FUNC_REDIRECT_TO_CPU, /* SRv6 packets function match to CPU, CL8600 only.
                                                  */
    CLX_PKT_RX_REASON_SRV6_FLAVOR_ERR,    /* SRv6 packets flavor invalid to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_SRH_SL0_USP,        /* SRv6 USP flavor and SL is 0 to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_SRH_SL0_USP_NO_SRH, /* SRv6 USP flavor and packets has no SRH, CL8600 only. */
    CLX_PKT_RX_REASON_SRH_SL0_USP_TWO_SRH, /* SRv6 USP flavor and packets has two SRH, CL8600 only.
                                            */
    CLX_PKT_RX_REASON_SRH_SL0_NO_POP_SRH, /* SRv6 packet SL is 0 and no USP/USD flavor, CL8600 only.
                                           */
    CLX_PKT_RX_REASON_SRH_SL_NO_ZERO_DECAP, /* SRv6 decapsulatin when SL is not 0, CL8600 only. */
    CLX_PKT_RX_REASON_SRV6_UNK_PLD_DECAP,   /* SRv6 decapsulation when payload invalid, CL8600 only.
                                             */
    CLX_PKT_RX_REASON_B6_INSERT_RCV_REDUCED,     /* SRv6 packets B6.Insert when DIP is not in SRH,
                                                    CL8600 only. */
    CLX_PKT_RX_REASON_B6_INSERT_RCV_DIP_UNMATCH, /* SRv6 packets B6.Insert when DIP not match SRH
                                                    current SID, CL8600 only. */
    CLX_PKT_RX_REASON_SRV6_UNK_BEHAVIOR,   /* SRv6 endpoint behavior invalid to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_AUTO_TUNNEL_IP_MISS, /* 6to4 tunnel outer IPv4 and inner IPv6 are unmatched,
                                              CL8600 only. */
    CLX_PKT_RX_REASON_ISATAP_TUNNEL_IP_MISS, /* ISATAP tunnel outer IPv4 and inner IPv6 are
                                                unmatched, CL8600 only.*/
    /* 80 */
    CLX_PKT_RX_REASON_MPLS_DECAP_BOS, /* No bottom of the labels stack, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_PW_CW,     /* Common PWCW packets, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_PW_ACH,    /* ACH packets, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_PW_UNK,    /* PWCW parsing error, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_L3VPN_IP,  /* L3VPN scenario, the inner is ether, CL8600 only. */
    CLX_PKT_RX_REASON_BDI_HSH_MISS,   /* Hash search for inner bridge domain failed, CL8600 only. */
    CLX_PKT_RX_REASON_IGMP_SNOOPING,  /* IGMP snooping packets, CL8600 only. */
    CLX_PKT_RX_REASON_MLD_SNOOPING,   /* MLD snooping packets, CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_ECN,     /* Used Ecn map of tunnel decap: ECT(1) (!), CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_ECN_2, /* Used Ecn map of tunnel decap: Not-ECT (!!!), CL8600 only. */
    CLX_PKT_RX_REASON_TUNNEL_ECN_3, /* Used Ecn map of tunnel decap: drop (!!!), CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_TRANSIT_LBL_MISS, /* MPLS transit label not hit, CL8600 only. */
    CLX_PKT_RX_REASON_L2_SA_MISS_1,          /* L2 source address miss, CL8600 only. */
    CLX_PKT_RX_REASON_INT_SRC_RCV_INT_ENCAP, /* INT sourrc receive igr with INT encap, CL8600 only.
                                              */
    CLX_PKT_RX_REASON_UC_SOURCE_PRUNING,     /* Unicast source prune, CL8600 only. */
    CLX_PKT_RX_REASON_UC_SPLITHORIZON_CHECK, /* Tunnel farward to tunnel by L2UC, CL8600 only. */
    /* 96 */
    CLX_PKT_RX_REASON_IP_TTL_0,                   /* Ip header TTL is 0, CL8600 only. */
    CLX_PKT_RX_REASON_IP_TTL_1,                   /* Ip header TTL is 0, CL8600 only. */
    CLX_PKT_RX_REASON_TELM_OVER_UNSUPPORTED_TYPE, /* Source role ingress is not valid L4
                                                     type(TCP/UDP/GRE), and tnl_idx is 0, CL8600
                                                     only. */
    CLX_PKT_RX_REASON_EVPN_ESI_FILTER,            /* EVPN esi filter to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_EVPN_DF_FILTER,             /* EVPN DF filter to CPU, CL8600 only. */
    CLX_PKT_RX_REASON_VLAN_HSH_MISS, /* Hash search for VLAN editing failed, CL8600 only. */
    CLX_PKT_RX_REASON_IGR_NOT_PVLAN_PORT_PORT, /* Inbound port is a non PVLAN port, CL8600 only. */
    CLX_PKT_RX_REASON_EGR_PVLAN_PORT_TYPE_CHECK, /* Check PVLAN role on outbound port, CL8600 only.
                                                  */
    CLX_PKT_RX_REASON_INT_OVER_UNSUPPORTED_TYPE, /* INT source ingress is not valid L4
                                                    type(TCP/UDP/GRE), and tnl_idx is 0, CL8600
                                                    only. */
    CLX_PKT_RX_REASON_MC_SOURCE_PRUNING,         /* Multicast source prune, CL8600 only. */
    CLX_PKT_RX_REASON_MC_SPLITHORIZON_CHECK, /* Tunnel farward to tunnel by L2UC, CL8600 only. */
    CLX_PKT_RX_REASON_MC_L3VPN_PRUNING,      /* L3 VPN source pruning with same l3 interface, CL8600
                                                only. */
    CLX_PKT_RX_REASON_L3VPN_BUT_NO_L3_SERVICE, /* Get L3 VPN packet but L3 service is not enabled,
                                                  CL8600 only. */
    CLX_PKT_RX_REASON_IOAM_OVER_UNSUPPORTED_TYPE, /* IOAM source ingress is not IPv4/IPv6 and
                                                     tnl_idx is 0, CL8600 only.*/
    CLX_PKT_RX_REASON_INT_MTU_EXCEED,             /* INT MTU exceed, CL8600 only. */
    CLX_PKT_RX_REASON_INT_META_INCOMP, /* Ingress packet header is oversize, making it impossible to
                                          fully decap INT, CL8600 only. */
    /* 112 */
    CLX_PKT_RX_REASON_TELM_NONEXIST_DECAP, /* CUD type is decap action, but ingress packet has no
                                              TELM header, CL8600 only. */
    CLX_PKT_RX_REASON_INT_OVER_UNSUPPORTED_TNL,  /* INT source role cfg encap TNL type is
                                                     Non-VxlanGpe/Geneve/GRE, CL8600 only. */
    CLX_PKT_RX_REASON_IOAM_OVER_UNSUPPORTED_TNL, /* IOAM source role cfg encap tnl type is
                                                    Non-Vxlan, CL8600 only. */
    CLX_PKT_RX_REASON_MPLS_PHP_BOS_ETH, /* PHP have no mpls label stack, but inner is not IP, CL8600
                                           only. */
    CLX_PKT_RX_REASON_EGR_INC_OVERFLOW, /* Egress packet size overflow, CL8600 only. */
    CLX_PKT_RX_REASON_URPF_CHECK_FAIL_DROP, /* L3 URPF check fail drop, CL8600 only. */
    CLX_PKT_RX_REASON_L3MC_RPF_CHECK_DROP,  /* L3 RPF check fail drop, CL8600 only. */
    CLX_PKT_RX_REASON_PORT_HIGH_LATENCY,    /* Port high latency packet, CL8600 only. */
    CLX_PKT_RX_REASON_ACL_DROP,             /* ACL drop, CL8600 only. */
    CLX_PKT_RX_REASON_IGR_BDI_SPT,          /* Ingress bridge domain spanning tree, CL8600 only. */
    CLX_PKT_RX_REASON_EGR_BDI_SPT,          /* Egress bridge domain spanning tree, CL8600 only. */
    CLX_PKT_RX_REASON_PSR_PKT_INC,          /* Parse packet incompatible. */
    CLX_PKT_RX_REASON_IP_MC_LCL,            /* IP multicast to local. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_0,  /* ctrl2cpu reason for entry 0, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_1,  /* ctrl2cpu reason for entry 1, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_2,  /* ctrl2cpu reason for entry 2, CL8600 only. */
    /* 128 */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_3,  /* ctrl2cpu reason for entry 3, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_4,  /* ctrl2cpu reason for entry 4, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_5,  /* ctrl2cpu reason for entry 5, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_6,  /* ctrl2cpu reason for entry 6, CL8600 only */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_7,  /* ctrl2cpu reason for entry 7, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_8,  /* ctrl2cpu reason for entry 8, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_9,  /* ctrl2cpu reason for entry 9, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_10, /* ctrl2cpu reason for entry 10, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_11, /* ctrl2cpu reason for entry 11, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_12, /* ctrl2cpu reason for entry 12, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_13, /* ctrl2cpu reason for entry 13, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_14, /* ctrl2cpu reason for entry 14, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_15, /* ctrl2cpu reason for entry 15, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_16, /* ctrl2cpu reason for entry 16, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_17, /* ctrl2cpu reason for entry 17, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_18, /* ctrl2cpu reason for entry 18, CL8600 only. */
    /* 144 */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_19, /* ctrl2cpu reason for entry 19, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_20, /* ctrl2cpu reason for entry 20, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_21, /* ctrl2cpu reason for entry 21, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_22, /* ctrl2cpu reason for entry 22, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_23, /* ctrl2cpu reason for entry 23, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_24, /* ctrl2cpu reason for entry 24, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_25, /* ctrl2cpu reason for entry 25, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_26, /* ctrl2cpu reason for entry 26, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_27, /* ctrl2cpu reason for entry 27, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_28, /* ctrl2cpu reason for entry 28, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_29, /* ctrl2cpu reason for entry 29, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_30, /* ctrl2cpu reason for entry 30, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_31, /* ctrl2cpu reason for entry 31, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_32, /* ctrl2cpu reason for entry 32, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_33, /* ctrl2cpu reason for entry 33, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_34, /* ctrl2cpu reason for entry 34, CL8600 only. */
    /* 160 */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_35, /* ctrl2cpu reason for entry 35, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_36, /* ctrl2cpu reason for entry 36, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_37, /* ctrl2cpu reason for entry 37, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_38, /* ctrl2cpu reason for entry 38, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_39, /* ctrl2cpu reason for entry 39, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_40, /* ctrl2cpu reason for entry 40, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_41, /* ctrl2cpu reason for entry 41, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_42, /* ctrl2cpu reason for entry 42, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_43, /* ctrl2cpu reason for entry 43, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_44, /* ctrl2cpu reason for entry 44, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_45, /* ctrl2cpu reason for entry 45, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_46, /* ctrl2cpu reason for entry 46, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_47, /* ctrl2cpu reason for entry 47, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_48, /* ctrl2cpu reason for entry 48, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_49, /* ctrl2cpu reason for entry 49, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_50, /* ctrl2cpu reason for entry 50, CL8600 only. */
    /* 176 */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_51, /* ctrl2cpu reason for entry 51, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_52, /* ctrl2cpu reason for entry 52, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_53, /* ctrl2cpu reason for entry 53, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_54, /* ctrl2cpu reason for entry 54, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_55, /* ctrl2cpu reason for entry 55, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_56, /* ctrl2cpu reason for entry 56, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_57, /* ctrl2cpu reason for entry 57, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_58, /* ctrl2cpu reason for entry 58, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_59, /* ctrl2cpu reason for entry 59, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_60, /* ctrl2cpu reason for entry 60, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_61, /* ctrl2cpu reason for entry 61, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_62, /* ctrl2cpu reason for entry 62, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_63, /* ctrl2cpu reason for entry 63, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_64, /* ctrl2cpu reason for entry 64, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_65, /* ctrl2cpu reason for entry 65, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_66, /* ctrl2cpu reason for entry 66, CL8600 only. */
    /* 192 */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_67, /* ctrl2cpu reason for entry 67, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_68, /* ctrl2cpu reason for entry 68, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_69, /* ctrl2cpu reason for entry 69, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_70, /* ctrl2cpu reason for entry 70, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_71, /* ctrl2cpu reason for entry 71, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_72, /* ctrl2cpu reason for entry 72, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_73, /* ctrl2cpu reason for entry 73, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_74, /* ctrl2cpu reason for entry 74, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_75, /* ctrl2cpu reason for entry 75, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_76, /* ctrl2cpu reason for entry 76, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_77, /* ctrl2cpu reason for entry 77, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_78, /* ctrl2cpu reason for entry 78, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_79, /* ctrl2cpu reason for entry 79, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_80, /* ctrl2cpu reason for entry 80, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_81, /* ctrl2cpu reason for entry 81, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_82, /* ctrl2cpu reason for entry 82, CL8600 only. */
    /* 208 */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_83, /* ctrl2cpu reason for entry 83, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_84, /* ctrl2cpu reason for entry 84, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_85, /* ctrl2cpu reason for entry 85, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_86, /* ctrl2cpu reason for entry 86, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_87, /* ctrl2cpu reason for entry 87, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_88, /* ctrl2cpu reason for entry 88, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_89, /* ctrl2cpu reason for entry 89, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_90, /* ctrl2cpu reason for entry 90, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_91, /* ctrl2cpu reason for entry 91, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_92, /* ctrl2cpu reason for entry 92, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_93, /* ctrl2cpu reason for entry 93, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_94, /* ctrl2cpu reason for entry 94, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_95, /* ctrl2cpu reason for entry 95, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_96, /* ctrl2cpu reason for entry 96, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_97, /* ctrl2cpu reason for entry 97, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_98, /* ctrl2cpu reason for entry 98, CL8600 only. */
    /* 224 */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_99,  /* ctrl2cpu reason for entry 99, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_100, /* ctrl2cpu reason for entry 100, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_101, /* ctrl2cpu reason for entry 101, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_102, /* ctrl2cpu reason for entry 102, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_103, /* ctrl2cpu reason for entry 103, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_104, /* ctrl2cpu reason for entry 104, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_105, /* ctrl2cpu reason for entry 105, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_106, /* ctrl2cpu reason for entry 106, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_107, /* ctrl2cpu reason for entry 107, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_108, /* ctrl2cpu reason for entry 108, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_109, /* ctrl2cpu reason for entry 109, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_110, /* ctrl2cpu reason for entry 110, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_111, /* ctrl2cpu reason for entry 111, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_112, /* ctrl2cpu reason for entry 112, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_113, /* ctrl2cpu reason for entry 113, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_114, /* ctrl2cpu reason for entry 114, CL8600 only. */
    /* 240 */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_115, /* ctrl2cpu reason for entry 115, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_116, /* ctrl2cpu reason for entry 116, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_117, /* ctrl2cpu reason for entry 117, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_118, /* ctrl2cpu reason for entry 118, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_119, /* ctrl2cpu reason for entry 119, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_120, /* ctrl2cpu reason for entry 120, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_121, /* ctrl2cpu reason for entry 121, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_122, /* ctrl2cpu reason for entry 122, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_123, /* ctrl2cpu reason for entry 123, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_124, /* ctrl2cpu reason for entry 124, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_125, /* ctrl2cpu reason for entry 125, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_126, /* ctrl2cpu reason for entry 126, CL8600 only. */
    CLX_PKT_RX_REASON_CTRL_TO_CPU_ENTRY_127, /* ctrl2cpu reason for entry 127, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_0,            /* cia copy reason 0, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_1,            /* cia copy reason 1, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_2,            /* cia copy reason 2, CL8600 only. */
    /* 256 */
    CLX_PKT_RX_REASON_CIA_COPY_3,  /* cia copy reason 3, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_4,  /* cia copy reason 4, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_5,  /* cia copy reason 5, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_6,  /* cia copy reason 6, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_7,  /* cia copy reason 7, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_8,  /* cia copy reason 8, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_9,  /* cia copy reason 9, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_10, /* cia copy reason 10, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_11, /* cia copy reason 11, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_12, /* cia copy reason 12, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_13, /* cia copy reason 13, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_14, /* cia copy reason 14, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_15, /* cia copy reason 15, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_16, /* cia copy reason 16, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_17, /* cia copy reason 17, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_18, /* cia copy reason 18, CL8600 only. */
    /* 272 */
    CLX_PKT_RX_REASON_CIA_COPY_19, /* cia copy reason 19, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_20, /* cia copy reason 20, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_21, /* cia copy reason 21, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_22, /* cia copy reason 22, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_23, /* cia copy reason 23, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_24, /* cia copy reason 24, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_25, /* cia copy reason 25, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_26, /* cia copy reason 26, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_27, /* cia copy reason 27, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_28, /* cia copy reason 28, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_29, /* cia copy reason 29, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_30, /* cia copy reason 30, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_31, /* cia copy reason 31, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_32, /* cia copy reason 32, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_33, /* cia copy reason 33, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_34, /* cia copy reason 34, CL8600 only. */
    /* 288 */
    CLX_PKT_RX_REASON_CIA_COPY_35, /* cia copy reason 35, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_36, /* cia copy reason 36, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_37, /* cia copy reason 37, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_38, /* cia copy reason 38, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_39, /* cia copy reason 39, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_40, /* cia copy reason 40, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_41, /* cia copy reason 41, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_42, /* cia copy reason 42, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_43, /* cia copy reason 43, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_44, /* cia copy reason 44, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_45, /* cia copy reason 45, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_46, /* cia copy reason 46, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_COPY_47, /* cia copy reason 47, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_0,  /* cia trap reason 0. */
    CLX_PKT_RX_REASON_CIA_TRAP_1,  /* cia trap reason 1. */
    CLX_PKT_RX_REASON_CIA_TRAP_2,  /* cia trap reason 2. */
    /* 304 */
    CLX_PKT_RX_REASON_CIA_TRAP_3,  /* cia trap reason 3. */
    CLX_PKT_RX_REASON_CIA_TRAP_4,  /* cia trap reason 4. */
    CLX_PKT_RX_REASON_CIA_TRAP_5,  /* cia trap reason 5. */
    CLX_PKT_RX_REASON_CIA_TRAP_6,  /* cia trap reason 6. */
    CLX_PKT_RX_REASON_CIA_TRAP_7,  /* cia trap reason 7. */
    CLX_PKT_RX_REASON_CIA_TRAP_8,  /* cia trap reason 8. */
    CLX_PKT_RX_REASON_CIA_TRAP_9,  /* cia trap reason 9. */
    CLX_PKT_RX_REASON_CIA_TRAP_10, /* cia trap reason 10. */
    CLX_PKT_RX_REASON_CIA_TRAP_11, /* cia trap reason 11. */
    CLX_PKT_RX_REASON_CIA_TRAP_12, /* cia trap reason 12. */
    CLX_PKT_RX_REASON_CIA_TRAP_13, /* cia trap reason 13. */
    CLX_PKT_RX_REASON_CIA_TRAP_14, /* cia trap reason 14. */
    CLX_PKT_RX_REASON_CIA_TRAP_15, /* cia trap reason 15. */
    CLX_PKT_RX_REASON_CIA_TRAP_16, /* cia trap reason 16. */
    CLX_PKT_RX_REASON_CIA_TRAP_17, /* cia trap reason 17. */
    CLX_PKT_RX_REASON_CIA_TRAP_18, /* cia trap reason 18. */
    /* 320 */
    CLX_PKT_RX_REASON_CIA_TRAP_19, /* cia trap reason 19. */
    CLX_PKT_RX_REASON_CIA_TRAP_20, /* cia trap reason 20. */
    CLX_PKT_RX_REASON_CIA_TRAP_21, /* cia trap reason 21. */
    CLX_PKT_RX_REASON_CIA_TRAP_22, /* cia trap reason 22. */
    CLX_PKT_RX_REASON_CIA_TRAP_23, /* cia trap reason 23. */
    CLX_PKT_RX_REASON_CIA_TRAP_24, /* cia trap reason 24, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_25, /* cia trap reason 25, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_26, /* cia trap reason 26, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_27, /* cia trap reason 27, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_28, /* cia trap reason 28, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_29, /* cia trap reason 29, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_30, /* cia trap reason 30, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_31, /* cia trap reason 31, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_32, /* cia trap reason 32, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_33, /* cia trap reason 33, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_34, /* cia trap reason 34, CL8600 only. */
    /* 336 */
    CLX_PKT_RX_REASON_CIA_TRAP_35,    /* cia trap reason 35, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_36,    /* cia trap reason 36, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_37,    /* cia trap reason 37, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_38,    /* cia trap reason 38, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_39,    /* cia trap reason 39, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_40,    /* cia trap reason 40, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_41,    /* cia trap reason 41, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_42,    /* cia trap reason 42, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_43,    /* cia trap reason 43, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_44,    /* cia trap reason 44, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_45,    /* cia trap reason 45, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_46,    /* cia trap reason 46, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_TRAP_47,    /* cia trap reason 47, CL8600 only. */
    CLX_PKT_RX_REASON_CIA_UDF,        /* cia udf reason */
    CLX_PKT_RX_REASON_MOD,            /* mod reason */
    CLX_PKT_RX_REASON_POST_SMALL_PKT, /* post small pkt reason */
    CLX_PKT_RX_REASON_OTHERS,         /* None of the above reasons */
    CLX_PKT_RX_REASON_LAST
} clx_pkt_rx_reason_t;

#define CLX_PKT_RX_RSN_BMP_SIZE (CLX_BITMAP_SIZE(CLX_PKT_RX_REASON_LAST))
/* The data structure is the reason bitmap for "to CPU" reason codes. */
typedef uint32 clx_pkt_rx_rsn_bmp_t[CLX_PKT_RX_RSN_BMP_SIZE];

#define INDEX_OF_BMP(rsn)  ((rsn) / 32)
#define OFFSET_OF_BMP(rsn) (1UL << ((rsn) % 32))

#define CLX_PKT_RSN_BMP_SET(rsn_bmp, rsn) \
    (((uint32 *)(rsn_bmp))[INDEX_OF_BMP(rsn)] |= OFFSET_OF_BMP(rsn))
#define CLX_PKT_RSN_BMP_CLR(rsn_bmp, rsn) \
    (((uint32 *)(rsn_bmp))[INDEX_OF_BMP(rsn)] &= ~OFFSET_OF_BMP(rsn))
#define CLX_PKT_RSN_BMP_CHK(rsn_bmp, rsn) \
    (((uint32 *)(rsn_bmp))[INDEX_OF_BMP(rsn)] & OFFSET_OF_BMP(rsn))

#define CLX_PKT_RSN_BMP_FOREACH(clx_rsn_bmp, rsn)      \
    for (rsn = 0; rsn < CLX_PKT_RX_REASON_LAST; rsn++) \
        if (CLX_PKT_RSN_BMP_CHK(clx_rsn_bmp, rsn))

/* Packet Drop Reasons */
typedef enum {
    CLX_PKT_DROP_REASON_NONE = 0,
    CLX_PKT_DROP_REASON_ECC_ERR,         /* ECC error. */
    CLX_PKT_DROP_REASON_IPL_ERR_FRM,     /* Error frame from UMAC. */
    CLX_PKT_DROP_REASON_IPL_CRC_ERR,     /* CRC error. */
    CLX_PKT_DROP_REASON_IPL_MAX_LEN_VLT, /* Maximum frame length violation from UMAC. */
    CLX_PKT_DROP_REASON_IPL_JABBER_FRM,  /* Jabber frame from UMAC. */
    CLX_PKT_DROP_REASON_IPL_LEN_ERR,     /* IEEE 802.3 frame with a length error from UMAC. */
    CLX_PKT_DROP_REASON_IPL_CONST_SOP,   /* Packet encountered an error pattern (SOP-SOP-EOP).. */
    CLX_PKT_DROP_REASON_IPL_OVER_MTU, /* Packet truncated when the packet size exceeds the MTU. */
    CLX_PKT_DROP_REASON_IPL_EOP_TIME_OUT, /* Packet truncated when the SFD (umac2ipl_vld) time out.
                                           */
    CLX_PKT_DROP_REASON_IPL_BUF_OVF,      /* Packet truncated when buffer usage overflow. */
    CLX_PKT_DROP_REASON_LBM_FRG_DROP, /* Packet truncated when reaching the truncation threshold. */
    CLX_PKT_DROP_REASON_LBM_TRUN_ERR, /* Packet size is larger than the MTU. */
    CLX_PKT_DROP_REASON_LBM_RECVD_ERR, /* Packet received from EPP/EPL/TM with error status. */
    CLX_PKT_DROP_REASON_L2_IGR_MTU_ERR = 16,  /* Ingress L2 MTU check failed. */
    CLX_PKT_DROP_REASON_L2_EGR_MTU_ERR,       /* Egress L2 MTU check failed. */
    CLX_PKT_DROP_REASON_L2_MC_SOURCE_PRUNING, /* L2 MC packet egress port is the same as the ingress
                                                 port. */
    CLX_PKT_DROP_REASON_L2_UC_SOURCE_PRUNING, /* L2 UC packet egress port is the same as the ingress
                                                 port. */
    CLX_PKT_DROP_REASON_L2_BDI_SPT_DROP,      /* Bridge domain spanning tree drop. */
    CLX_PKT_DROP_REASON_L3_LKUP_TYPE_ERR_DROP,  /* L3 lookup type error drop. */
    CLX_PKT_DROP_REASON_L3_MTU_ERR,             /* L3 MTU check failed. */
    CLX_PKT_DROP_REASON_IP_SG_DROP,             /* IP source guard check failed. */
    CLX_PKT_DROP_REASON_MC_L3VPN_PRUNING_DROP,  /* L3 VPN source BDID equals destination BDID. */
    CLX_PKT_DROP_REASON_L3_DIP_MISS_DROP,       /* L3 DIP lookup miss. */
    CLX_PKT_DROP_REASON_L3_RPF_CHECK_FAIL_DROP, /* L3 packet RPF check failed. */
    CLX_PKT_DROP_REASON_L3UC_FWD_PTR_DROP,      /* L3 UC no forwarding pointer. */
    CLX_PKT_DROP_REASON_ECMP_ERR_DROP,          /* L3 ECMP group member error. */
    CLX_PKT_DROP_REASON_IP_TTL0_DROP,           /* IP TTL is 0. */
    CLX_PKT_DROP_REASON_VLAN_PKT_TAG_FMT_ERR,   /* Packet VLAN tag format error. */
    CLX_PKT_DROP_REASON_VLAN_HSH_MISS_DROP,     /* VLAN hash miss. */
    CLX_PKT_DROP_REASON_TUNNEL_OUTER_HDR_ERR,   /* Tunnel outer header error. */
    CLX_PKT_DROP_REASON_EVPN_ESI_FILTER,        /* EVPN ESI hit. */
    CLX_PKT_DROP_REASON_EVPN_DF_FILTER,         /* EVPN DF hit. */
    CLX_PKT_DROP_REASON_SRV6_HDR_ERR,           /* SRv6 header error. */
    CLX_PKT_DROP_REASON_MPLS_TTL_DROP,          /* MPLS TTL is 0 or 1. */
    CLX_PKT_DROP_REASON_MPLS_RSVD1_DROP,        /* MPLS reserved label check failed. */
    CLX_PKT_DROP_REASON_MPLS_LKP_MISS_DROP,     /* MLSP lable lookup failed. */
    CLX_PKT_DROP_REASON_METER_DROP,             /* Meter drop. */
    CLX_PKT_DROP_REASON_STORM_DROP,             /* Storm control drop. */
    CLX_PKT_DROP_REASON_DOS_CHK_ERR,            /* DoS check failed. */
    CLX_PKT_DROP_REASON_SEC_DROP,               /* Security check failed. */
    CLX_PKT_DROP_REASON_ACL_DROP,               /* ACL drop. */
    CLX_PKT_DROP_REASON_PSR_PKT_ERR,            /* Packet header parsing error. */
    CLX_PKT_DROP_REASON_PDB_WR_ERR = 47,        /* PDB write error. */
    CLX_PKT_DROP_REASON_ASM_PKTSZ_ERR,          /* Assembled packet size error. */
    CLX_PKT_DROP_REASON_REP_MC_CONGEST,         /* MC packet congestion. */
    CLX_PKT_DROP_REASON_REP_MC_MBR_DROP,        /* MC member drop. */
    CLX_PKT_DROP_REASON_REP_DELETE_PORT,        /* Egress port deleted. */
    CLX_PKT_DROP_REASON_REP_CHASSIS_PRUN,       /* Chassis pruning. */
    CLX_PKT_DROP_REASON_REP_INT_PRUN,           /* INT pruning. */
    CLX_PKT_DROP_REASON_REP_BLACKHOLE_DI,       /* Blackhole DI. */
    CLX_PKT_DROP_REASON_REP_OUTRANGE_DI,        /* DI out of range. */
    CLX_PKT_DROP_REASON_REP_LAG_SIZE_ERR,       /* LAG group size is 0. */
    CLX_PKT_DROP_REASON_REP_FL_SIZE_ERR,        /* FL group size is 0. */
    CLX_PKT_DROP_REASON_REP_BYPASS_DI,          /* Bypass DI. */
    CLX_PKT_DROP_REASON_REP_CODE_ERR,           /* Drop code error. */
    CLX_PKT_DROP_REASON_REP_OQ_OUT_RANGE_ERR,   /* OQ out of range. */
    CLX_PKT_DROP_REASON_BAC_SRC_CONGEST,        /* Source congestion. */
    CLX_PKT_DROP_REASON_BAC_DST_CONGEST,        /* Destination congestion. */
    CLX_PKT_DROP_REASON_OQ_ENQ_FAIL,            /* OQ enqueue error. */
    CLX_PKT_DROP_REASON_LAST = 64,
} clx_pkt_drop_reason_t;

/* -----------------------------------------------------------------------------------
 * Control-to-CPU */
/* Control-to-CPU Key Types */
typedef enum clx_pkt_key_type_e {
    CLX_PKT_KEY_TYPE_IPV6 = 0, /* Key type IPv6    */
    CLX_PKT_KEY_TYPE_IPV4,     /* Key type IPv4    */
    CLX_PKT_KEY_TYPE_ARP,      /* Key type ARP     */
    CLX_PKT_KEY_TYPE_L2,       /* Key type L2      */
    CLX_PKT_KEY_TYPE_LAST
} clx_pkt_key_type_t;

/* Tunnel Types */
typedef enum clx_pkt_tunnel_type_e {
    CLX_PKT_TUNNEL_TYPE_NONE = 0,        /* tunnel type is none                    */
    CLX_PKT_TUNNEL_TYPE_MPLS_PW,         /* tunnel type is mpls pw                 */
    CLX_PKT_TUNNEL_TYPE_IP,              /* tunnel type is ip                      */
    CLX_PKT_TUNNEL_TYPE_IP_L2,           /* tunnel type is ip l2                   */
    CLX_PKT_TUNNEL_TYPE_ERSPAN,          /* tunnel type is erspan                  */
    CLX_PKT_TUNNEL_TYPE_SRV6_POP_SRH,    /* tunnel type is srv6 pop srh            */
    CLX_PKT_TUNNEL_TYPE_SRV6_POP_IP_SRH, /* tunnel type is srv6 pop ip srh         */
    CLX_PKT_TUNNEL_TYPE_LAST
} clx_pkt_tunnel_type_t;

/* IPv4 Key */
typedef struct clx_pkt_ctrl_to_cpu_key_ipv4_s {
    clx_ipv4_t dip;                  /* 32-bit IPv4 destination IP Address                   */
    clx_ipv4_t dip_msk;              /* Hit if packet.dip equals to (dip & dip_mask).        */
    clx_ipv4_t dip_max;              /* Hit if packet.dip within [dip, dip_max].             */

    uint8 proto;                     /* Protocol ID                                          */
    uint8 proto_msk;                 /* It is used to mask the protocol ID.                  */

    uint16 l4_dport;                 /* ipv4 l4 dst port                                     */
    uint16 l4_dport_msk;             /* used to mask ipv4 l4 dst port                        */
    uint16 l4_sport;                 /* ipv4 l4 src port                                     */
    uint16 l4_sport_msk;             /* used to mask ipv4 l4 src port                        */
    uint8 icmp_type;                 /* ipv4 icmp type                                       */
    uint8 icmp_type_msk;             /* used to mask ipv4 icmp type                          */
    uint8 icmp_code;                 /* ipv4 icmp code                                       */
    uint8 icmp_code_msk;             /* used to mask ipv4 icmp code                          */

    uint8 hdr_len;                   /* ipv4 header length                                   */
    uint8 hdr_len_msk;               /* used to mask ipv4 header length                      */
    clx_pkt_tunnel_type_t term_type; /* ipv4 tunnel type                                     */
    clx_bridge_domain_t bdid;        /* bridge domain id                                     */
    clx_bridge_domain_t bdid_msk;    /* used to mask bridge domain id                        */
    uint32 flags;                    /* used to set flag                                     */
} clx_pkt_ctrl_to_cpu_key_ipv4_t;

/* The Mac of IPv4 Packet is My Router Mac.               */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_MY_ROUTER_MAC (1 << 0)
/* Check the Mac of IPv4 Packet is My Router Mac or not.  */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_MY_ROUTER_MAC_MSK (1 << 1)
/* The IPv4 route is enable.                              */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_ROUTE (1 << 2)
/* Check the IPv4 route is enable or not.                 */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_ROUTE_MSK (1 << 3)
/* IPv4 Packet with Header Option is allowed.             */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_HDR_OPTION (1 << 4)
/* Check IPv4 Packet with Header Option or not.           */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_HDR_OPTION_MSK (1 << 5)
/* IPv4 Packet with Header Fragment is allowed.           */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_HDR_FRAG (1 << 6)
/* Check IPv4 Packet with Header Fragment or not.         */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_HDR_FRAG_MSK (1 << 7)
/* If true: icmp type/code, Else: TCP/UDP/SCTP dport.     */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_ICMP (1 << 8)
/* If true: key is dip-to-dip_max, Else: dip & dip_mask   */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV4_FLAGS_DIP_RANGE_EN (1 << 9)

/* IPv6 Key */
typedef struct clx_pkt_ctrl_to_cpu_key_ipv6_s {
    clx_ipv6_t dip;                  /* 128-bit IPv6 destination IP Address                  */
    clx_ipv6_t dip_msk;              /* Hit if packet.dip equals to (dip & dip_mask).        */
    clx_ipv6_t dip_max;              /* Hit if packet.dip within [dip, dip_max].             */
    uint8 next_hdr;                  /* IPv6 next header                                     */
    uint8 next_hdr_msk;              /* It is used to mask IPv6 next header.                 */
    uint16 l4_dport;                 /* ipv6 l4 dst port                                     */
    uint16 l4_dport_msk;             /* used to mask ipv6 l4 dst port                        */
    uint16 l4_sport;                 /* ipv6 l4 src port                                     */
    uint16 l4_sport_msk;             /* used to mask ipv6 l4 src port                        */
    uint8 icmp_type;                 /* ipv6 icmp type                                       */
    uint8 icmp_type_msk;             /* used to mask ipv6 icmp type                          */
    uint8 icmp_code;                 /* ipv6 icmp code                                       */
    uint8 icmp_code_msk;             /* used to mask ipv6 icmp code                          */
    clx_pkt_tunnel_type_t term_type; /* ipv6 tunnel type                                     */
    clx_bridge_domain_t bdid;        /* bridge domain id                                     */
    clx_bridge_domain_t bdid_msk;    /* used to mask bridge domain id                        */
    uint32 flags;                    /* used to set ipv6 flag                                */
} clx_pkt_ctrl_to_cpu_key_ipv6_t;

/* The Mac of IPv6 Packet is My Router Mac.                 */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV6_FLAGS_MY_ROUTER_MAC (1 << 0)
/* Check the Mac of IPv6 Packet is My Router Mac or not.    */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV6_FLAGS_MY_ROUTER_MAC_MSK (1 << 1)
/* The IPv6 route is enable.                                */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV6_FLAGS_ROUTE (1 << 2)
/* Check the IPv6 route is enable or not.                   */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV6_FLAGS_ROUTE_MSK (1 << 3)
/* If true: icmp type/code, Else: TCP/UDP/SCTP dport.       */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV6_FLAGS_ICMP (1 << 4)
/* If true: key is dip-to-dip_max, Else: dip & dip_mask     */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV6_FLAGS_DIP_RANGE_EN (1 << 5)
/* IPv6 Packet with Header Option is allowed.   */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV6_FLAGS_HDR_OPTION (1 << 6)
/* Check IPv6 Packet with Header Option or not. */
#define CLX_PKT_CTRL_TO_CPU_KEY_IPV6_FLAGS_HDR_OPTION_MSK (1 << 7)

/* ARP Key */
typedef struct clx_pkt_ctrl_to_cpu_key_arp_s {
    clx_mac_t dmac;                  /* 48-bit DA                              */
    clx_mac_t dmac_msk;              /* It is used to mask the DA.             */
    clx_mac_t smac;                  /* 48-bit SA                              */
    clx_mac_t smac_msk;              /* It is used to mask the SA.             */
    uint16 eth_type;                 /* Ethernet type                          */
    uint16 eth_type_msk;             /* It is used to make the Ethernet type.  */
    uint16 oper;                     /* ARP/RARP operation                     */
    uint16 oper_msk;                 /* ARP/RARP operation                     */
    clx_ipv4_t sender_ip;            /* Sender IP address                      */
    clx_ipv4_t sender_ip_msk;        /* It is used to mask the sender IP address.*/
    clx_ipv4_t target_ip;            /* Target IP address                      */
    clx_ipv4_t target_ip_msk;        /* It is used to mask the target IP address.*/
    clx_pkt_tunnel_type_t term_type; /* tunnel type                            */
    clx_bridge_domain_t bdid;        /* bridge domain id                       */
    clx_bridge_domain_t bdid_msk;    /* used to mask bridge domain id          */
    uint32 flags;                    /* used to set flag                       */
} clx_pkt_ctrl_to_cpu_key_arp_t;

/* The Mac of ARP Packet is My Router Mac.                  */
#define CLX_PKT_CTRL_TO_CPU_KEY_ARP_FLAGS_MY_ROUTER_MAC (1 << 0)
/* Ignore the Mac of ARP Packet is My Router Mac or not.    */
#define CLX_PKT_CTRL_TO_CPU_KEY_ARP_FLAGS_MY_ROUTER_MAC_MSK (1 << 1)
/* [CL8600 only] The L2 mac da is broadcast                 */
#define CLX_PKT_CTRL_TO_CPU_KEY_ARP_FLAGS_DMAC_BC (1 << 2)
/* [CL8600 only] Ignore the l2 mac da is broadcast or not.  */
#define CLX_PKT_CTRL_TO_CPU_KEY_ARP_FLAGS_DMAC_BC_MSK (1 << 3)
/* [CL8600 only] The l2 mac da is equal to target hard address.               */
#define CLX_PKT_CTRL_TO_CPU_KEY_ARP_FLAGS_DMAC_EQ_THA (1 << 4)
/* [CL8600 only] Ignore the l2 mac da is equal to target hard address or not. */
#define CLX_PKT_CTRL_TO_CPU_KEY_ARP_FLAGS_DMAC_EQ_THA_MSK (1 << 5)
/* [CL8600 only] The l2 mac sa is equal to sender hard address.               */
#define CLX_PKT_CTRL_TO_CPU_KEY_ARP_FLAGS_SMAC_EQ_SHA (1 << 6)
/* [CL8600 only] Ignore l2 mac sa is equal to sender hard address not.        */
#define CLX_PKT_CTRL_TO_CPU_KEY_ARP_FLAGS_SMAC_EQ_SHA_MSK (1 << 7)

/* Key Value, L2 */
typedef struct clx_pkt_ctrl_to_cpu_key_l2_s {
    clx_mac_t dmac;                  /* 48-bit DA                                            */
    clx_mac_t dmac_msk;              /* It is used to mask the DA.                           */
    uint16 eth_type;                 /* Ethernet type                                        */
    uint16 eth_type_msk;             /* It is used to make the Ethernet type.                */
    uint16 sub_type;                 /* Sub type                                             */
    uint16 sub_type_msk;             /* It is used to mask the sub type.                     */
    clx_pkt_tunnel_type_t term_type; /* tunnel type                                          */
    clx_bridge_domain_t bdid;        /* bridge domain id                       */
    clx_bridge_domain_t bdid_msk;    /* used to mask bridge domain id          */
    uint32 flags;                    /* used to set flag                                     */
} clx_pkt_ctrl_to_cpu_key_l2_t;

/* The Mac of L2 Packet is My Router Mac.                   */
#define CLX_PKT_CTRL_TO_CPU_KEY_L2_FLAGS_MY_ROUTER_MAC (1 << 0)
/* Ignore the Mac of L2 Packet is My Router Mac or not.     */
#define CLX_PKT_CTRL_TO_CPU_KEY_L2_FLAGS_MY_ROUTER_MAC_MSK (1 << 1)
/* The eth-type is < 1500 or Jumbo LLC.                     */
#define CLX_PKT_CTRL_TO_CPU_KEY_L2_FLAGS_LLC (1 << 2)
/* Ignore the eth-type check.                               */
#define CLX_PKT_CTRL_TO_CPU_KEY_L2_FLAGS_LLC_MSK (1 << 3)

/* Key Value */
typedef union clx_pkt_ctrl_to_cpu_key_u {
    clx_pkt_ctrl_to_cpu_key_ipv6_t ipv6; /* when the key_type is CLX_PKT_KEY_TYPE_IPV6.   */
    clx_pkt_ctrl_to_cpu_key_ipv4_t ipv4; /* when the key_type is CLX_PKT_KEY_TYPE_IPV4.   */
    clx_pkt_ctrl_to_cpu_key_arp_t arp;   /* when the key_type is CLX_PKT_KEY_TYPE_ARP.    */
    clx_pkt_ctrl_to_cpu_key_l2_t l2;     /* when the key_type is CLX_PKT_KEY_TYPE_L2.     */
} clx_pkt_ctrl_to_cpu_key_t;

/* Entry of Control-to-CPU Table */
typedef struct clx_pkt_ctrl_to_cpu_entry_s {
    clx_pkt_key_type_t key_type;   /* Key for IPv6, IPv4, ARP and L2          */
    clx_pkt_ctrl_to_cpu_key_t key; /* CLX_PKT_KEY_TYPE_IPV6   needs to use
                                    * clx_pkt_ctrl_to_cpu_key_ipv6_t.
                                    * CLX_PKT_KEY_TYPE_IPV4   needs to use
                                    * clx_pkt_ctrl_to_cpu_key_ipv4_t.
                                    * CLX_PKT_KEY_TYPE_ARP    needs to use
                                    * clx_pkt_ctrl_to_cpu_key_arp_t.
                                    * CLX_PKT_KEY_TYPE_L2
                                    * needs to use clx_pkt_ctrl_to_cpu_key_l2_t.
                                    */
    clx_fwd_action_t action;       /* It can be forwarded, drop, redirect, copy to cpu */
    boolean valid; /* TRUE: It indicates the entry is valid.                          */
    uint32 flags;  /* flags, refer to CLX_PKT_CTRL_TO_CPU_ENTRY_FLAGS_XXX */
} clx_pkt_ctrl_to_cpu_entry_t;

#define CLX_PKT_CTRL_TO_CPU_ENTRY_FLAGS_BYPASS_BPDU (1 << 0) /* bypass bpdu packet */
#define CLX_PKT_CTRL_TO_CPU_ENTRY_FLAGS_L2_SA_LEARN (1 << 1) /* L2 smac learn */

/* ----------------------------------------------------------------------------------- Queuing */
typedef struct clx_pkt_rx_queue_cfg_s {
    uint32 queue; /* key: rx queue */
    uint32 port;  /* key: CPU port or CPI port */

    /* queue to channel mapping */
    uint32 channel; /* rx dma channel */

    /* queue truncate_size */
    uint32 trunc_size; /* truncate size */

    /* queue reason mapping */
    clx_pkt_rx_rsn_bmp_t rsn_bmp; /* queue reason bmp*/

    uint32 flags;                 /* used by CLX_PKT_QUEUE_FLAGS_* */
} clx_pkt_rx_queue_cfg_t;

#define CLX_PKT_QUEUE_FLAGS_MAP_CHANNEL (1 << 0)
#define CLX_PKT_QUEUE_FLAGS_TRUNC_SIZE  (1 << 1)
#define CLX_PKT_QUEUE_FLAGS_RSN_MAPPING (1 << 2)

/* ----------------------------------------------------------------------------------- CLX PKT */

#define CLX_PKT_RX_BUF_LEN (1024)

typedef enum clx_pkt_flags_e {
    /* rx start */
    CLX_PKT_FLAGS_ROUTE = 1 << 0,       /* The packet is an L3 routed packet.          */
    CLX_PKT_FLAGS_BPDU = 1 << 1,        /* The packet is a bpdu packet.                */
    CLX_PKT_FLAGS_TUNNEL_TERM = 1 << 2, /* The tunnel header should be removed.        */
    CLX_PKT_FLAGS_SPAN_TERM = 1 << 3,   /* The packet is either ERSPAN or RSPAN mirror packet. */
    CLX_PKT_FLAGS_TRUNC = 1 << 4,       /* The packet has been truncated.              */
    CLX_PKT_FLAGS_DROP = 1 << 5,        /* The packet is dropped.                      */
    /* rx end */
    /* tx start */
    CLX_PKT_FLAGS_PTP_EN = 1 << 11,                 /* The Precision Time Protocol is enable.     */
    CLX_PKT_FLAGS_PTP_2STEP_SYNC_MSG = 1 << 12,     /* The 2-step Master Sync message.            */
    CLX_PKT_FLAGS_PTP_1STEP_SYNC_MSG = 1 << 13,     /* The 1-step Master Sync message.            */
    CLX_PKT_FLAGS_PTP_DELAY_REQUEST = 1 << 14,      /* The Slave Delay Request message.           */
    CLX_PKT_FLAGS_PTP_TC_EN = 1 << 15,              /* The Transparent clock is enable.           */
    CLX_PKT_FLAGS_PTP_PEER_DELAY_REQUEST = 1 << 16, /* The Slave Peer Delay Request message.      */
    CLX_PKT_FLAGS_PTP_PEER_DELAY_RESPONSE = 1 << 17, /* The Slave Peer Delay Response message. */
    /* tx end */
} clx_pkt_flags_t;

/* Segment ID Type */
typedef enum clx_pkt_seg_type_e {
    CLX_PKT_SEG_TYPE_VLAN_DOUBLE = 0, /* The egress segment tag type double vlan              */
    CLX_PKT_SEG_TYPE_VLAN_SINGLE = 1, /* The egress segment tag type single vlan              */
    CLX_PKT_SEG_TYPE_VXLAN = 2,       /* The egress segment tag type vxlan                    */
    CLX_PKT_SEG_TYPE_NVGRE = 3,       /* The egress segment tag type nvgre                    */
    CLX_PKT_SEG_TYPE_LAST
} clx_pkt_seg_type_t;

/* Packet Buffer Block */
typedef struct clx_pkt_blk_s {
    uint8 *ptr_buf;                 /* The data buffer pointer                              */
    uint8 *ptr_dma_addr;            /* used for free dma mem when pph in dma mem */
    uint32 len;                     /* The length of this block                             */
    struct clx_pkt_blk_s *ptr_next; /* The pointer for the next buffer block                */
} clx_pkt_blk_t;

/* RX Packet Structure */
typedef struct clx_pkt_info_s {
    uint32 tc;         /* Traffic class        */
    clx_color_t color; /* Color                */

    /* Port */
    clx_port_t igr_phy_port; /* The ingress physical port                            */
    clx_port_t egr_phy_port; /* The egress physical port                             */

    /* VLAN and Bridge Domain */
    clx_bridge_domain_t bdid;    /* The bridge domain ID                                 */
    clx_vlan_tag_t igr_tag_type; /* The ingress VLAN tag type                            */
    clx_vlan_t src_vlan;         /* src vlan */
    uint8 pcp;                   /* Priority Code Point  */
    uint8 dei;                   /* vlan cfi/dei  */

    /* ACL */
    uint32 grp_lbl; /* ACL ingress group label                              */

    /* L3 interface */
    uint32 igr_intf_id; /* The ingress logical interface                        */
    uint32 egr_intf_id; /* The egress logical interface                         */

    /* Port, LAG, VM or Tunnels */
    clx_port_t igr_port; /* The ingress port                                     */
    clx_port_t egr_port; /* The egress port                                      */

    uint32 hdc_latency;  /* high latency */
} clx_pkt_info_t;

/* RX Packet Structure */
typedef struct clx_pkt_rx_pkt_s {
    clx_pkt_info_t info;
    uint32 channel;               /* The dma channel */
    clx_pkt_rx_rsn_bmp_t rsn_bmp; /* The rsn bits of the packet */

    /* timestamp */
    uint32 ts_sec;  /* The timestamp in seconds                             */
    uint32 ts_nsec; /* The timestamp in nano seconds                        */

    /* Flags */
    clx_pkt_flags_t flags; /* used by CLX_PKT_PKT_FLAGS_* */

    /* Payload */
    clx_pkt_blk_t *ptr_data; /* The packet payload saved block                       */
    uint32 total_len;        /* Total length of the payload                          */
} clx_pkt_rx_pkt_t;

/* ----------------------------------------------------------------------------------- RX */
/* Callback func for recv packets  */
typedef clx_error_no_t (*clx_pkt_rx_func_t)(const uint32 unit,
                                            const clx_pkt_rx_pkt_t *ptr_pkt, /* Packet to be
                                                                                processed   */
                                            void *ptr_cookie); /* Private data of user     */

typedef void *(*clx_pkt_rx_alloc_func_t)(void);

typedef clx_error_no_t (*clx_pkt_rx_free_func_t)(const void *ptr_pkt_buf);

typedef enum clx_pkt_cb_op_e {
    CLX_PKT_CB_OP_REGISTER = 0,        /* regisert cb   */
    CLX_PKT_CB_OP_DEREGISTER = 1,      /* deregister cb */
    CLX_PKT_CB_OP_REPLACE = 2,         /* replace register cb */
    CLX_PKT_CB_OP_REPLACE_RECOVER = 3, /* recover register cb before */
    CLX_PKT_CB_OP_LAST
} clx_pkt_cb_op_t;

/* ----------------------------------------------------------------------------------- TX */
/* Callback function type for applications to transmit a packet */
typedef void (*clx_pkt_tx_func_t)(const uint32 unit,
                                  void *ptr_pkt,     /* Packet to be processed  */
                                  void *ptr_cookie); /* Private data            */

/*  Tx mode */
typedef enum clx_pkt_tx_mode_e {
    CLX_PKT_TX_MODE_ETH = 1,      /* Normal packet processing mode */
    CLX_PKT_TX_MODE_RAW = 2,      /* Bypass the IPP and EPP logic  */
    CLX_PKT_TX_MODE_SKIP_IPP = 3, /* Bypass the IPP logic  */
    CLX_PKT_TX_MODE_LAST
} clx_pkt_tx_mode_t;

/* Tx raw mode */
typedef enum clx_pkt_tx_raw_mode_e {
    CLX_PKT_TX_RAW_MODE_PORT = 0, /* To local port or remote port  */
    CLX_PKT_TX_RAW_MODE_CPU,      /* To Remote CPU  */
    CLX_PKT_TX_RAW_MODE_MCAST,    /* To multiple local ports in the mcast group  */
    CLX_PKT_TX_RAW_MODE_LAST
} clx_pkt_tx_raw_mode_t;

/* TX Packet Structure */
typedef struct clx_pkt_tx_pkt_s {
    clx_pkt_tx_mode_t tx_mode;  /* The Tx mode of the packet sent     */
    clx_pkt_tx_raw_mode_t type; /* Tx raw mode */
    clx_pkt_info_t info;

    uint32 channel;       /* The dma channel */
    uint32 cpu_id;        /* Remote CPU ID, used by CLX_PKT_CPU_ID_* */
    uint32 rmt_cpu_queue; /* Remote CPU queue     */

    uint32 mcast_id;      /* Multicast ID         */
    uint16 seq_num;       /* ptp info */

    uint32 pkj_journal;

    clx_pkt_blk_t *ptr_data;              /* The packet payload saved block             */
    clx_pkt_tx_func_t cb;                 /* Callback function for this packet buffer   */
    void *ptr_cookie;                     /* User data for packet cb              */

    clx_pkt_flags_t flags;                /* used by CLX_PKT_PKT_FLAGS_* */
} clx_pkt_tx_pkt_t;
#define CLX_PKT_CPU_ID_NBR   (0xfffffffe) /* Neighbor Discovery   */
#define CLX_PKT_CPU_ID_BCAST (0xffffffff) /* Broadcast            */

/* ----------------------------------------------------------------------------------- cnt */
/* RX Cnt */
typedef struct clx_pkt_rx_cnt_s {
    uint32 pkt;              /* normal packet */
    uint32 rch_avbl_gpd_num; /* RX channel available GPD number */
    uint32 rx_done;          /* RX done interrupt */
} clx_pkt_rx_cnt_t;

typedef struct clx_pkt_rx_reason_cnt_s {
    uint64 pkt_cnts;
    uint64 byte_cnts;
} clx_pkt_rx_reason_cnt_t;

/* TX Cnt */
typedef struct clx_pkt_tx_cnt_s {
    uint32 pkt; /* normal packet */
    uint32 under_size_err;
    uint32 over_size_err;
} clx_pkt_tx_cnt_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief To init the RX subsystem configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_rx_init(const uint32 unit);

/**
 * @brief To deinit the RX subsystem configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_rx_deinit(const uint32 unit);

/**
 * @brief To register the RX pkt cb.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cb            - RX packet callback.
 * @param [in]    ptr_cookie    - Private data of user.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_rx_cb_register(const uint32 unit, const clx_pkt_rx_func_t cb, void *ptr_cookie);

/**
 * @brief To deregister the RX pkt cb.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_rx_cb_deregister(const uint32 unit);

/**
 * @brief To register the user defined RX alloc/free packet callback if needed by user.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    alloc_cb    - Rx alloc mem cb.
 * @param [in]    free_cb     - Rx free mem cb.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_rx_udf_mem_cb_register(const uint32 unit,
                               const clx_pkt_rx_alloc_func_t alloc_cb,
                               const clx_pkt_rx_free_func_t free_cb);

/**
 * @brief To deregister the user defined RX alloc/free pkt cb, use sdk default.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_rx_udf_mem_cb_deregister(const uint32 unit);

/**
 * @brief To transmit the specified packet from CPU port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_pkt    - The packet structure of the TX packet.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_pkt_send(const uint32 unit, const clx_pkt_tx_pkt_t *ptr_pkt);

/**
 * @brief To prepare tx packet.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_pkt         - The packet structure of the TX packet.
 * @param [in]    ptr_data_buf    - The buffer payload.
 * @param [in]    len             - The packet length.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_pkt_prepare(const uint32 unit,
                    clx_pkt_tx_pkt_t *ptr_pkt,
                    const uint8 *ptr_data_buf,
                    uint32 len);

/**
 * @brief To get the queue info by RX queue, flags should be specified.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [out]    ptr_queue_cfg    - The pointer of the specified queue config.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_rx_queue_cfg_get(const uint32 unit, clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

/**
 * @brief To set the queue info by RX queue, flags should be specified.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_queue_cfg    - The pointer of the specified queue config.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_rx_queue_cfg_set(const uint32 unit, const clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

/**
 * @brief To set a specific rule applied to the packet.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    index        - The specified entry index for the rule.
 * @param [in]    ptr_entry    - The value which will be set to the target entry.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_ctrl_to_cpu_entry_set(const uint32 unit,
                              const uint32 index,
                              clx_pkt_ctrl_to_cpu_entry_t *ptr_entry);

/**
 * @brief To get a specified ctrl-to-CPU entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     index        - The specified entry index.
 * @param [out]    ptr_entry    - The value obtained from the entry.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_ctrl_to_cpu_entry_get(const uint32 unit,
                              const uint32 index,
                              clx_pkt_ctrl_to_cpu_entry_t *ptr_entry);

/**
 * @brief Clear all configured ctrl-to-CPU entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_pkt_ctrl_to_cpu_entry_all_clear(const uint32 unit);

/**
 * @brief To get the PDMA RX counters of the target channel.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     channel       - The target channel.
 * @param [out]    ptr_rx_cnt    - Pointer for the Rx counter.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The channel is invalid.
 */
clx_error_no_t
clx_pkt_rx_cnt_get(const uint32 unit, const uint32 channel, clx_pkt_rx_cnt_t *ptr_rx_cnt);

/**
 * @brief To clear the PDMA RX counters of the target channel.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    channel    - The target channel.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
clx_pkt_rx_cnt_clear(const uint32 unit, const uint32 channel);

/**
 * @brief To clear the PDMA TX counters of the target channel.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    channel    - The target channel.
 * @return        CLX_E_OK    - Operation success.
 */
clx_error_no_t
clx_pkt_tx_cnt_clear(const uint32 unit, const uint32 channel);

/**
 * @brief To get the PDMA TX counters of the target channel.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     channel       - The target channel.
 * @param [out]    ptr_tx_cnt    - Pointer for the Tx counter.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The channel is invalid.
 */
clx_error_no_t
clx_pkt_tx_cnt_get(const uint32 unit, const uint32 channel, clx_pkt_tx_cnt_t *ptr_tx_cnt);

/**
 * @brief To get the cpu reason counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     cpu_reason           - The CPU reason.
 * @param [out]    ptr_rx_reason_cnt    - Pointer of the counter based on CPU reason.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_pkt_cpu_reason_cnt_get(const uint32 unit,
                           const clx_pkt_rx_reason_t cpu_reason,
                           clx_pkt_rx_reason_cnt_t *ptr_rx_reason_cnt);

/**
 * @brief To clear the cpu reason counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cpu_reason    - Clx_pkt_rx_reason_t.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_pkt_cpu_reason_cnt_clear(const uint32 unit, const clx_pkt_rx_reason_t cpu_reason);

#endif /* End of CLX_PKT_H */
