/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_cfg.h
 * PURPOSE:
 *      Customer configuration on CLX SDK.
 * NOTES:
 */

#ifndef CLX_CFG_H
#define CLX_CFG_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_types.h>
#include <clx/clx_error.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM (16)

/* DATA TYPE DECLARATIONS
 */
typedef enum clx_cfg_type_e {
    CLX_CFG_TYPE_CHIP_MODE,            /* chip operating mode. 0: legacy mode, 1:hybrid mode */

    CLX_CFG_TYPE_PORT_MAX_SPEED,       /* please refer to CLX_PORT_SPEED_XXX */
    CLX_CFG_TYPE_PORT_LANE_NUM,        /* Port lane mumber */
    CLX_CFG_TYPE_PORT_TX_LANE,         /* Port tx lane */
    CLX_CFG_TYPE_PORT_RX_LANE,         /* Port rx lane */
    CLX_CFG_TYPE_PORT_TX_POLARITY_REV, /* Port tx polarity reserve */
    CLX_CFG_TYPE_PORT_RX_POLARITY_REV, /* Port rx polarity reserve */
    CLX_CFG_TYPE_PORT_EXT_LANE,        /* Port extencd lane */
    CLX_CFG_TYPE_PORT_VALID,           /* Port valid */

    /* l2 module related configuration */
    CLX_CFG_TYPE_L2_THREAD_PRI,      /* L2 thread priority */
    CLX_CFG_TYPE_L2_THREAD_STACK,    /* customize L2 thread stack size in bytes */
    CLX_CFG_TYPE_L2_ADDR_MODE,       /* L2 address operation mode. 0: Polling mode, 1: FIFO mode */
    CLX_CFG_TYPE_L2_TRAV_THREAD_PRI, /* L2 traverse thread priority for non blocking mode */
    CLX_CFG_TYPE_L2_TRAV_THREAD_STACK,         /* customize L2 thread stack size in bytes for non
                                                      blocking mode */
    CLX_CFG_TYPE_L2_DISABLE_MC_ID_COMPRESSION, /* L2 disable mc id compression. Only supported on
                                                  CL8600. */

    /* PKT module related configuration */
    CLX_CFG_TYPE_PKT_TX_GPD_NUM,             /* Tx GPD (General Packet Descriptor) number */
    CLX_CFG_TYPE_PKT_RX_GPD_NUM,             /* Rx GPD (General Packet Descriptor) number */
    CLX_CFG_TYPE_PKT_RX_SCHED_MODE,          /* 0: RR mode, 1: WRR mode                   */
    CLX_CFG_TYPE_PKT_TX_QUEUE_LEN,           /* Initialize Tx GPD-queue (of first SW-GPD) length */
    CLX_CFG_TYPE_PKT_RX_QUEUE_LEN,           /* Initialize Rx GPD-queue (of first SW-GPD) length */
    CLX_CFG_TYPE_PKT_RX_QUEUE_WEIGHT,        /* valid while CLX_CFG_TYPE_PKT_RX_SCHED_MODE is 1
                                              * param0: queue
                                              * param1: NA
                                              * value : weight
                                              */
    CLX_CFG_TYPE_PKT_RX_ISR_THREAD_PRI,      /* Packet receive thread priority */
    CLX_CFG_TYPE_PKT_RX_ISR_THREAD_STACK,    /* customize PKT RX ISR thread stack size in bytes */
    CLX_CFG_TYPE_PKT_RX_FREE_THREAD_PRI,     /* Packet receive free thread priority */
    CLX_CFG_TYPE_PKT_RX_FREE_THREAD_STACK,   /* customize PKT RX free thread stack size in bytes */
    CLX_CFG_TYPE_PKT_TX_ISR_THREAD_PRI,      /* Packet transmit thread priority */
    CLX_CFG_TYPE_PKT_TX_ISR_THREAD_STACK,    /* customize PKT TX ISR thread stack size in bytes */
    CLX_CFG_TYPE_PKT_TX_FREE_THREAD_PRI,     /* Packet transmit free thread priority */
    CLX_CFG_TYPE_PKT_TX_FREE_THREAD_STACK,   /* customize PKT TX free thread stack size in bytes */
    CLX_CFG_TYPE_PKT_ERROR_ISR_THREAD_PRI,   /* Pakcet error thread priority */
    CLX_CFG_TYPE_PKT_ERROR_ISR_THREAD_STACK, /* customize PKT ERROR ISR thread stack size in bytes
                                              */

    /* STAT module related configuration */
    CLX_CFG_TYPE_CNT_THREAD_PRI,       /* Counter thread priority */
    CLX_CFG_TYPE_CNT_THREAD_STACK,     /* customize CNT thread stack size in bytes */
    CLX_CFG_TYPE_CNT_POLLING_INTERVAL, /* STAT polling interval */
    CLX_CFG_TYPE_CNT_TX_DROP_FILTER,   /* Filter tx drop cnt */

    /* IFMON module related configuration */
    CLX_CFG_TYPE_IFMON_THREAD_PRI,   /* Interface monitor thread priority */
    CLX_CFG_TYPE_IFMON_THREAD_STACK, /* customize IFMON thread stack size in bytes */

    /* share memory related configuration */
    CLX_CFG_TYPE_SHARE_MEM_SDN_ENTRY_NUM, /* SDN flow table entry number from share memory */
    CLX_CFG_TYPE_SHARE_MEM_L3_ENTRY_NUM,  /* L3 entry number from share memory */
    CLX_CFG_TYPE_SHARE_MEM_L2_ENTRY_NUM,  /* L2 entry number from share memory */

    /* DLB related configuration */
    CLX_CFG_TYPE_DLB_MONITOR_MODE,                   /* DLB monitor mode. 1: async, 0: sync */
    CLX_CFG_TYPE_DLB_LAG_MONITOR_THREAD_PRI,         /* dlb lag monitor thread pri         */
    CLX_CFG_TYPE_DLB_LAG_MONITOR_THREAD_SLEEP_TIME,  /* dlb lag monitor thread sleep time  */
    CLX_CFG_TYPE_DLB_L3_MONITOR_THREAD_PRI,          /* dlb l3 monitor thread pri          */
    CLX_CFG_TYPE_DLB_L3_MONITOR_THREAD_SLEEP_TIME,   /* dlb l3 monitor thread sleep time   */
    CLX_CFG_TYPE_DLB_L3_INTR_THREAD_PRI,             /* dlb l3 intr thread pri             */
    CLX_CFG_TYPE_DLB_NVO3_MONITOR_THREAD_PRI,        /* dlb nvo3 monitor thread pri        */
    CLX_CFG_TYPE_DLB_NVO3_MONITOR_THREAD_SLEEP_TIME, /* dlb nvo3 monitor thread sleep time */
    CLX_CFG_TYPE_DLB_NVO3_INTR_THREAD_PRI,           /* dlb nvo3 intr thread pri           */

    /* l3 related configuration */
    CLX_CFG_TYPE_L3_ECMP_MIN_BLOCK_SIZE, /* config each ecmp group member min number, not use */
    CLX_CFG_TYPE_L3_ECMP_BLOCK_SIZE,     /* config each ecmp group member max number     */
    CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM, /* Tcam ipv6 4x resource, ipv4 1x
                                                                   can use this resource         */
    CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM, /* Tcam ipv6 2x resource, ipv4 1x can
                                                                  use this resource         */

    /* share memory related configuration */
    CLX_CFG_TYPE_HASH_L2_FDB_REGION_ENTRY_NUM,   /* l2 fdb share memory resource   */
    CLX_CFG_TYPE_HASH_L2_GROUP_REGION_ENTRY_NUM, /* l2 group share memory resource */
    CLX_CFG_TYPE_TCAM_L2_FDB_REGION_ENTRY_NUM, /* l2 fdb share tcam memory resource. Only support on
                                                  CL8600    */
    CLX_CFG_TYPE_TCAM_L2_GROUP_REGION_ENTRY_NUM, /* l2 group share tcam memory resource. Only
                                                    support on CL8600  */
    CLX_CFG_TYPE_HASH_SECURITY_REGION_ENTRY_NUM, /* security share memory resource. Not support on
                                                    CL8600        */
    CLX_CFG_TYPE_HASH_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM, /* hash ipv6 4x route resource, ipv4
                                                                   1x can use this resource   */
    CLX_CFG_TYPE_HASH_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM,  /* hash ipv6 2x route resource, ipv4
                                                                   1x can use this resource   */
    CLX_CFG_TYPE_HASH_L3_WITHOUT_PREFIX_REGION_ENTRY_NUM, /* hash 1x resource, ipv6 use 4x, ipv4 use
                                                             1x                   */
    CLX_CFG_TYPE_HASH_FLOW_REGION_ENTRY_NUM,    /* flow share memory resource              */

    CLX_CFG_TYPE_PORT_FC_MODE,                  /* only use to init port TM
                                                 * buffer   configuration for specific FC mode,   which not
                                                 * enable/disable FC/PFC   for the port/pcp.   param0: port.                  param1:
                                                 * Invalid.   value : 0, FC disable;   1, 802.3x FC;   2, PFC.
                                                 */
    CLX_CFG_TYPE_PORT_PFC_STATE,                /* valid while CLX_CFG_TYPE_PORT_TYPE_FC_MODE
                                                 * of the port is PFC.
                                                 * param0: port.
                                                 * param1: pcp.
                                                 * value : 0, PFC disable;
                                                 *         1, PFC enable.
                                                 */
    CLX_CFG_TYPE_PORT_PFC_QUEUE_STATE,          /* valid while CLX_CFG_TYPE_PORT_TYPE_FC_MODE
                                                 * of the port is PFC.
                                                 * param0: port.
                                                 * param1: queue.
                                                 * value : 0, PFC disable;
                                                 *         1, PFC enable;
                                                 */
    CLX_CFG_TYPE_PORT_PFC_MAPPING,              /* valid while CLX_CFG_TYPE_PORT_FC_MODE
                                                 * of the port is PFC.
                                                 * param0: port.
                                                 * param1: queue.
                                                 * value : PCP bitmap;
                                                 *
                                                 */
    CLX_CFG_TYPE_USE_UNIT_PORT,                 /* use UNIT_PORT or native port of clx_port_t
                                                 * 1 : UNIT_PORT, 0 : native port
                                                 */
    CLX_CFG_TYPE_MAC_VLAN_ENABLE,               /* use dadicate mac vlan table */
    CLX_CFG_TYPE_CPI_PORT_MODE,                 /* use to init CPI port working mode.
                                                 * param0: CPI port number.
                                                 *         257, CPI port 0.
                                                 *         258, CPI port 1.
                                                 * param1: NA.
                                                 * value : 0, CPI mode.
                                                 *         1, Ether mode. (default)
                                                 */
    CLX_CFG_TYPE_PHY_ADDR,                      /* to assign external phy address if it exists. */
    CLX_CFG_TYPE_LED_CFG,                       /* User config decides to load the desired led */
    CLX_CFG_TYPE_FABRIC_MODE_ENABLE,            /* please refer to clx_stk_chip_mode_t
                                                 * set value 0: Single chip mode(single Box). (default)
                                                 *           1: Fabric chip mode.
                                                 *           2: Linecard chip mode.
                                                 */
    CLX_CFG_TYPE_TCAM_ECC_SCAN_ENABLE,          /* set value 0: Disable ECC TCAM scanning. (default)
                                                 * set value 1: Enable  ECC TCAM scanning.
                                                 */
    CLX_CFG_TYPE_MPLS_SR_NUM,                   /* MPLS Segment Routing
                                                 * value: encapsulation number
                                                 */
    CLX_CFG_TYPE_L2_BYPASS_LAG_PRUNE_GROUP_NUM, /* default value: 0 */
    CLX_CFG_TYPE_L3_BYPASS_LAG_PRUNE_GROUP_NUM, /* default value: 0 */

    /* l3 related configuration */
    CLX_CFG_TYPE_TCAM_L3_SIP_ENABLE, /* default value: 0, to expand TCAM capacity */
    CLX_CFG_TYPE_L3_ECMP_FDL_ENABLE, /* default value: 0, to reserve adj for FDL */

    CLX_CFG_TYPE_HASH_L3_IPV4_PREFIX_LENGTH_ENTRY_NUM, /* param0: prefix-length (1~32) */
                                                       /* param1: 1: vrf, 0: global */
                                                       /* value: entry number */

    CLX_CFG_TYPE_HASH_L3_IPV6_PREFIX_LENGTH_ENTRY_NUM, /* param0: prefix-length (1~128) */
                                                       /* param1: 1: vrf, 0: global */
                                                       /* value: entry number */

    CLX_CFG_TYPE_ACL_DROP_REDIRECT_CPU_PKT, /* set value 0: acl drop_cpu action would not drop
                                             * redirect to cpu pkt. (default) set value 1: acl
                                             * drop_cpu action would drop redirect to cpu pkt.
                                             */
    CLX_CFG_TYPE_STACKING_CHIP_PORT_NUM,    /* In stacking/chassis system, max used port num per
                                             * device.    default value: hw default max port
                                             */
    CLX_CFG_TYPE_LAG_MEMBER_AUTO_UPDATE, /* use to configure LAG member add/remove automatically by
                                          * SDK if link status has been changed. param0: NA. param1:
                                          * NA. value : 0, disable (default). 1, enable.
                                          */
    CLX_CFG_TYPE_PKT_DMA_ENHANCE_ENABLE, /* used to turn on the enhancement in DMA address cnversion
                                          * param0: NA
                                          * param1: NA
                                          * value : 0, disable (default)
                                          *         1, enable
                                          */
    CLX_CFG_TYPE_L2_POLLING_INTERVAL,    /* Times (msec) to poll all L2 FDB entries.
                                          * Need to sleep at least 50ms whenever poll 8k fdb entries.
                                          * Ex. if fdb entries is 64k, minimum polling interval would
                                          * be (64k/8k)*50ms
                                          */
    CLX_CFG_TYPE_L2_SKIP_SIZE_BEFORE_VLAN,      /* range: 1-8 Size of 2B to skip, size not including
                                                   Etype, min: 2 Bytes, max: 16 Bytes */
    CLX_CFG_TYPE_L2_SKIP_ETHERTYPE_BEFORE_VLAN, /* Ethertype to skip. */
    CLX_CFG_TYPE_L2_SKIP_SIZE_AFTER_VLAN,       /* range: 1-8 Size of 2B to skip, size not including
                                                   Etype, min: 2 Bytes, max: 16 Bytes */
    CLX_CFG_TYPE_L2_SKIP_ETHERTYPE_AFTER_VLAN,  /* Ethertype to skip. */
    CLX_CFG_TYPE_PFCWD_POLLING_INTERVAL,        /* Polling Interval for pfcwd task in ms */
    CLX_CFG_TYPE_LAG_MEMBER_SKIP_PORT_CHECK, /* Skip port validity check, when adding port members
                                                to LAG group */
    CLX_CFG_TYPE_ACL_HW_INSERT_DESCENDING,   /* used to config insert hw entry order.
                                              * param0: NA
                                              * param1: NA
                                              * value : 0, insert from first entry (default)
                                              *         1, insert from last entry
                                              */
    CLX_CFG_TYPE_CHIP_HASH_STAGE_TYPE,       /* set hash stage type
                                              * param0: hash_stage_0-2
                                              * value : 0: HASH_STAGE_OFF
                                              *         1: HASH_STAGE_8_PARALLEL
                                              *         2: HASH_STAGE_4_BY_4
                                              *         3: HASH_STAGE_2_BY_2_BY_4
                                              *         4: HASH_STAGE_4_BY_2_BY_2
                                              *         5: HASH_STAGE_2_BY_2_BY_2_BY_2
                                              */
    CLX_CFG_TYPE_CHIP_HASH_TILE_TYPE,        /* set hash tile type
                                              * param0: hash_stage_0-2
                                              * param1: hash_tile_0-7
                                              * value : 0: HASH_TILE_OFF
                                              *         1: HASH_TILE_MGI
                                              *         2: HASH_TILE_MSGI
                                              *         3: HASH_TILE_POLICY
                                              *         4: HASH_TILE_L3
                                              *         5: HASH_TILE_AFIB
                                              *         6: HASH_TILE_L2UC
                                              *         7: HASH_TILE_RPFC
                                              *         8: HASH_TILE_ECMP_GRP
                                              *         9: HASH_TILE_ECMP_MBR
                                              *         10: HASH_TILE_L2_ECMP_GRP
                                              *         11: HASH_TILE_L2_ECMP_MBR
                                              *         12: HASH_TILE_MPLS
                                              *         13: HASH_TILE_ARP
                                              *         14: HASH_TILE_L2MC
                                              *         15: HASH_TILE_SRV6
                                              */
    CLX_CFG_TYPE_CHIP_TCAM_TYPE,             /* set tcam type
                                              * param0: tcam_0-31
                                              * value : 0: TCAM_OFF
                                              *         1: TCAM_L3_SA
                                              *         2: TCAM_L3_DA
                                              *         3: TCAM_L3_SA_4X
                                              *         4: TCAM_L3_DA_4X
                                              *         5: TCAM_L2_SA
                                              *         6: TCAM_L2_DA
                                              */
    CLX_CFG_TYPE_SEC_DOS_CHECK_ENABLE,       /* enable all dos check
                                              * param0: NA.
                                              * param1: NA.
                                              * value : 0, disable
                                              *         1, enable.(default)
                                              */
    /* TELM related configuration */
    CLX_CFG_TYPE_TELM_TYPE,       /* Telemetry type, CL8600 only,
                                   * set value 0: TELM is INT type.(default)
                                   * set value 1: TELM is IOAM type.
                                   * set value 2: TELM is IFA type.
                                   */
    CLX_CFG_TYPE_TELM_PROFILE_ID, /* Telemetry profile id for force-on ports, CL8600 only. (default
                                     : 0)*/
    CLX_CFG_TYPE_TELM_IOAM_THREAD_PRI,            /* telemetry ioam fifo read thread priority */
    CLX_CFG_TYPE_TELM_IOAM_THREAD_STACK_SIZE,     /* customize telemetry ioam fifo read thread stack
                                                     size in bytes */
    CLX_CFG_TYPE_STACKING_EXTENDED_CHIP_NUM,      /* In stacking/chassis system, max used chip num
                                                   * per device for special occasions.
                                                   */
    CLX_CFG_TYPE_STACKING_EXTENDED_CHIP_PORT_NUM, /* In stacking/chassis system, max used port num
                                                   * per device for special occasions.
                                                   */
    CLX_CFG_TYPE_L3_ROUTE_LABEL_ENABLE,           /* enable acl label on L3 routing entry
                                                   * param0: NA.
                                                   * param1: NA.
                                                   * value : 0, disable (default)
                                                   *         1, enable.
                                                   */
    CLX_CFG_TYPE_SRV6_MODE,                       /* NB Only, SRV6 Mode:
                                                   * 0 Disable SRv6
                                                   * 1 SRv6 normal mode
                                                   * 2 uSID mode
                                                   * 3 G-SRv6 mode
                                                   */
    CLX_CFG_TYPE_SRV6_LOCATOR_LEN,                /* locator size in SRv6 in octets. 1 = 1 byte */
    CLX_CFG_TYPE_SRV6_FUNC_LEN, /* function size in SRv6 in octets, up to 4 byte. 1 = 1 byte */
    CLX_CFG_TYPE_SRV6_ARG_LEN,  /* argument size in SRv6, up to 2 byte, 1 = 1 byte */
    CLX_CFG_TYPE_SRV6_USID_BLOCK_LEN,   /* uSID block size in octets, up to 7 byte. 1 = 1 byte,
                                           loc=blk+id */
    CLX_CFG_TYPE_SRV6_USID_NODE_LEN,    /* uSID ID size in octets. 1 = 1 byte, loc=blk+id */
    CLX_CFG_TYPE_SRV6_GSRV6_PREFIX_LEN, /* gsrv6 prefix length in otects, up to 12 byte. 1 = 1 byte,
                                           value should less than loc */
    CLX_CFG_TYPE_SRV6_GSRV6_SI_OFFSET_LEN, /* gsrv6 si offset, value=loc+func+arg:1~16, si would be
                                              IPv6 DIP "si_offset"th bytes */
    CLX_CFG_TYPE_SWC_REASON_ACTION,
    CLX_CFG_TYPE_SWC_REASON_PRIORITY,
    CLX_CFG_TYPE_SWITCH_MODE, /* default value: 0, Legacy Ethernet switch mode; 1, experimental
                                 mode(Tapping)  */
    CLX_CFG_TYPE_VLAN_TPID_INIT_VALUE,      /* param0: NA
                                             * param1: NA
                                             * value : 1st tpid init value (default is 0x8100)
                                             */
    CLX_CFG_TYPE_L3_BULK_ROUTE_ENABLE,      /* default value: 0, disable bulk route     */
    CLX_CFG_TYPE_L3_BULK_ROUTE_V4_LOW_MASK, /* default value: 0, do not care mask; user can config
                                               mask 5.9.13.17...29      */
    CLX_CFG_TYPE_L3_BULK_ROUTE_V6_LOW_MASK, /* default value: 0, do not care mask; user can config
                                               mask 5.10.15.20.25...60  */
    CLX_CFG_TYPE_L3_BULK_PRE_ALLOC_EN, /* default value: 0, do not pre alloc; user can config 0/1 */
    CLX_CFG_TYPE_L3_BULK_PRE_ALLOC_V4_NUM, /* default value: 0, do not pre alloc; user can config
                                              mask 1,2,4,8     */
    CLX_CFG_TYPE_L3_BULK_PRE_ALLOC_V6_NUM, /* default value: 0, do not pre alloc; user can config
                                              mask 1,2,4,8,16  */
    CLX_CFG_TYPE_L3_ROUTE_DYNAMIC_ALLOC_EXM_EN, /* default value: 0, do not dynamic alloc exm */

    CLX_CFG_TYPE_MERGE_BD_HSH_ENTRY, /* NB Only, default value: 0, disable merge bd hash entry; 1 is
                                        enable merge bd hash entry */

    CLX_CFG_TYPE_DEFAULT_CONFIG, /* default value: 0xff, enable sdk default init, detailed reference
                                    CLX_CFG_TYPE_DEFAULT_CONFIG_XXX */

    CLX_CFG_TYPE_L3_ADJ_CALC_HW_ADD_ENABLE, /* NB Only, l3 arp entry need different with hash
                                               calculate addr, default 0 */

    CLX_CFG_TYPE_CHIP_LATENCY_MODE_ENABLE,  /* NB Only, chip enables latency mode */

    CLX_CFG_TYPE_TM_QUEUE_CIR_CFG_ENABLE,   /* NB Only, allow API to config CIR value */

    CLX_CFG_TYPE_TM_IGR_DYNAMIC_NO_SUPPORT, /* NB Only, ingress queue support buffer dynamic mode.
                                            If no support, user can config headroom */
    CLX_CFG_TYPE_TM_EGR_DYNAMIC_SUPPORT,    /* NB Only, egress queue support buffer dynamic mode */
    CLX_CFG_TYPE_HEADROOM_IN_IPL, /* NB Only, headroom use ipl buffer,default use tm buffer */
    CLX_CFG_TYPE_TM_CFG_IGR_DYNAMIC_POOL, /* NB Only, ingress queue support buffer dynamic mode */
    CLX_CFG_TYPE_TM_CFG_EGR_DYNAMIC_POOL, /* NB Only, egress queue support buffer dynamic mode */
    CLX_CFG_TYPE_TM_CFG_LOSSY_LOSSLESS_POOL_SEPARATE, /* NB Only, dual pool: lossy/lossless pool */
    CLX_CFG_TYPE_CIA_RESOURCE_ALLOC_MODE,             /* NB Only,
                                                       0: ingress 16k entries, egress 0k entries
                                                       1: ingress 12k entries, egress 4k entries (default)
                                                       2: ingress 8k entries, egress 8k entries
                                                       3: ingress 4k entries, egress 12k entries
                                                       4: ingress 0k entries, egress 16k entries */
    CLX_CFG_TYPE_CIA_EXACT_ACT_PRI,            /* NB Only, exact entry action priority, defalut 0
                                                  range: 0x0 (high) - 0xF(low) */
    CLX_CFG_TYPE_L3_ROUTE_V6_RSRC_MAXIMIZE,    /* grouping five IPv6 route prefixes to
                                                   maximize IPv6 route resources. Default 0, grouping
                                                   IPv6 route prefixes by four for common usage */
    CLX_CFG_TYPE_L3_LPM_DISABLE_AFIB,          /* disable afib when add lpm, default 0 */
    CLX_CFG_TYPE_L3_ROUTE_DISABLE_COVER_CHECK, /* default value: 0, enabel cover check;
                                                  user can config 0/1 */
    CLX_CFG_TYPE_TCAM_L3_WITH_IPV6_PREFIX_128_REGION_RSVD, /* default: 1, reserve dedicated IPv6 4x
                                                              region */
    CLX_CFG_TYPE_LAG_DI_OFFSET,                            /* LAG DI offset, default 0 */
    CLX_CFG_TYPE_PORT_DI_MODE, /* This flag sets the port destination index mode,
                                * allowing for either dynamic or static assignment of the
                                * destination index for the port. value:
                                * 0, Static port DI (default).
                                * 1, Flexiable port DI. */
    CLX_CFG_TYPE_CIAT_MODE, /* NB M256 Only, Ciat mode, default 0, 0: single mode, 1: double mode */
    CLX_CFG_TYPE_M256_CHIP_MODE, /* to be deleted */
    CLX_CFG_TYPE_LAST
} clx_cfg_type_t;

/* Adjust this bit to include ports in the default VLAN1; \
 * otherwise, no port will be added. */
#define CLX_CFG_TYPE_DEFAULT_CONFIG_ADD_PORT_TO_VLAN1 (1 << 0)

typedef struct clx_cfg_value_s {
    uint32 param0; /*(Optional) The optional parameter which is available
                    * when the clx_cfg_type_t needs the first arguments*/
    uint32 param1; /*(Optional) The optional parameter which is available
                    * when the clx_cfg_type_t needs the second arguments*/
    int32 value;   /* Configuration value */

} clx_cfg_value_t;

typedef clx_error_no_t (*clx_cfg_get_func_t)(const uint32 unit,
                                             const clx_cfg_type_t cfg_type,
                                             clx_cfg_value_t *ptr_cfg_value);

typedef clx_error_no_t (*clx_cfg_get_led_func_t)(const uint32 unit,
                                                 uint32 **pptr_led_cfg,
                                                 uint32 *ptr_cfg_size);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The function is to register clx_cfg_get_func_t to SDK.
 *
 * 1.  During SDK initializtion, it will call registered clx_cfg_get_func_t to get configuration
 * and apply them.
 * If no registered clx_cfg_get_func_t or can not get specified clx_cfg_type_t
 * configuration, SDK will apply default setting.
 * 2.  This function should be called before calling clx_init.
 * Support_chip: CLX86.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    ptr_cfg_callback    - Function to get the configuration value.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_cfg_register(const uint32 unit, clx_cfg_get_func_t ptr_cfg_callback);

/**
 * @brief The function is to register clx_cfg_get_led_func_t to SDK.
 *
 * 1.  During SDK initializtion, it will call registered clx_cfg_get_led_func_t to get LED
 * configuration and apply them. If no registered clx_cfg_get_led_func_t or can not get specified
 * external LED cfg configuration, SDK will apply default setting.
 * 2.  This function should be called before calling clx_init.
 * Support_chip: CLX86.
 *
 * @param [in]    unit                    - Device unit number.
 * @param [in]    ptr_led_cfg_callback    - Function to get LED configuration array.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_cfg_led_register(const uint32 unit, clx_cfg_get_led_func_t ptr_led_cfg_callback);

#endif /* CLX_CFG_H */
