/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_meter.h
 * PURPOSE:
 *    Provide HAL driver API functions for namchabarwa.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_METER_H
#define HAL_MT_NB_METER_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_meter.h>
#include <hal/hal_meter.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* plane meter bank capacity, unit: double bucket */
#define HAL_MT_NB_METER_PLANE_BANK_CAPACITY (1024)
/* global meter bank capacity, unit: double bucket */
#define HAL_MT_NB_METER_GLOBAL_BANK_CAPACITY (128)

/* max plane meter rate, unit: kbps */
#define HAL_MT_NB_METER_PLANE_RATE_MAX (4294967295UL) /* 4.2T */
/* max global meter rate, unit: kbps */
#define HAL_MT_NB_METER_GLOBAL_RATE_MAX (4294967295UL) /* 4.2T */

/* max plane meter bucket size, unit: byte */
#define HAL_MT_NB_METER_PLANE_BUCKET_MAX (1024 * 1000 * 1000) /* 1GB */
/* max global meter bucket size, unit: byte */
#define HAL_MT_NB_METER_GLOBAL_BUCKET_MAX (1024 * 1000 * 1000) /* 1GB */

/* meter rate granularity, unit: kbps */
#define HAL_MT_NB_METER_RATE_GRANULARITY (64)
/* meter bucket granularity, unit: byte */
#define HAL_MT_NB_METER_BUCKET_GRANULARITY (8)

/* ucp group number for ingress cia */
#define HAL_MT_NB_METER_INGRESS_UCP_GRP_NUM (12)
/* ucp group number for egress cia */
#define HAL_MT_NB_METER_EGRESS_UCP_GRP_NUM (4)

/* global meter config  delay */
#define HAL_MT_NB_METER_GLOBAL_METER_DELAY (2000) /* fixed time 2ms */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Meter default config initialize
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_cfg_init(const uint32 unit);

/**
 * @brief Set meter bank config register
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     type        - Resource type
 * @param [in]     bank_idx    - Bank id
 * @param [in]     enable      - Enable or disable
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_cfg_reg_set(const uint32 unit,
                            const hal_meter_type_t type,
                            const uint32 bank_idx,
                            const boolean enable);

/**
 * @brief Translate meter hw index
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_hw_index    - meter hw index
 * @param [out]    ptr_hw_idx      - hw index
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_hw_idx_trans(const uint32 unit,
                             const hal_meter_index_t *ptr_hw_index,
                             uint32 *ptr_hw_idx);

/**
 * @brief Translate meter hw index
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     hw_idx          - Hw index
 * @param [out]    ptr_hw_index    - Meter hw index
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_index_trans(const uint32 unit,
                            const uint32 hw_idx,
                            hal_meter_index_t *ptr_hw_index);

/**
 * @brief Set meter pool
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     ptr_sw_meter    - Sw meter
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_pool_set(const uint32 unit, const hal_meter_sw_meter_t *ptr_sw_meter);

/**
 * @brief Set ingress port meter hw index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [in]     hw_idx     - hw index
 * @param [in]     idx_vld    - hw index valid
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_igr_port_meter_hw_idx_set(const uint32 unit,
                                          const uint32 port,
                                          const uint32 *hw_idx,
                                          const uint32 *idx_vld);

/**
 * @brief Get ingress port meter hw index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [out]    hw_idx     - hw index
 * @param [out]    idx_vld    - hw index valid
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_igr_port_meter_hw_idx_get(const uint32 unit,
                                          const uint32 port,
                                          uint32 *hw_idx,
                                          uint32 *idx_vld);

/**
 * @brief Set ingress port meter hw index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [in]     hw_idx     - hw index
 * @param [in]     idx_vld    - hw index valid
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_egr_port_meter_hw_idx_set(const uint32 unit,
                                          const uint32 port,
                                          const uint32 *hw_idx,
                                          const uint32 *idx_vld);

/**
 * @brief Get egress port meter hw index
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     port       - Physical port id
 * @param [out]    hw_idx     - hw index
 * @param [out]    idx_vld    - hw index valid
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_egr_port_meter_hw_idx_get(const uint32 unit,
                                          const uint32 port,
                                          uint32 *hw_idx,
                                          uint32 *idx_vld);

/**
 * @brief set meter port config
 *
 * @param [in]     unit        - device unit number.
 * @param [in]     port        - port id.
 * @param [in]     layer1_len  - layer1 length.
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_port_cfg_set(const uint32 unit, const uint32 port, const uint32 layer1_len);

/**
 * @brief get meter port config
 *
 * @param [in]     unit        - device unit number.
 * @param [in]     port        - port id.
 * @param [out]    layer1_len  - layer1 length.
 * @return         CLX_E_OK    - Operation succeeded
 * @return         Others      - Operation failed
 */
clx_error_no_t
hal_mt_nb_meter_port_cfg_get(const uint32 unit, const uint32 port, uint32 *layer1_len);

#endif /* End of HAL_MT_NB_METER_H */
