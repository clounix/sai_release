/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_cia.h
 * PURPOSE:
 *    Provide HAL driver API functions of CIA module.
 *
 * NOTES:
 *
 */

#ifndef HAL_CIA_H
#define HAL_CIA_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_cia.h>
#include <hal/hal_cmn.h>
#include <hal/hal_sflow.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_CIA_UCP_ENTRY_NUM_MAX            (512)
#define HAL_CIA_EXACT_GRP_NUM_MAX            (24)
#define HAL_CIA_IGR_GRP_NUM_MAX              (12)
#define HAL_CIA_EGR_GRP_NUM_MAX              (4)
#define HAL_CIA_IGR_POST_GRP_NUM_MAX         (12)
#define HAL_CIA_EGR_POST_GRP_NUM_MAX         (4)
#define HAL_CIA_IGR_UCP_NUM_MAX              (32)
#define HAL_CIA_EGR_UCP_NUM_MAX              (32)
#define HAL_CIA_IGR_POST_UCP_NUM_MAX         (32)
#define HAL_CIA_EGR_POST_UCP_NUM_MAX         (32)
#define HAL_CIA_UCP_NUM_MAX                  (32)
#define HAL_CIA_IGR_ENTRY_NUM_MAX            (HAL_CIA_UCP_ENTRY_NUM_MAX * HAL_CIA_IGR_UCP_NUM_MAX)
#define HAL_CIA_EGR_ENTRY_NUM_MAX            (HAL_CIA_UCP_ENTRY_NUM_MAX * HAL_CIA_EGR_UCP_NUM_MAX)
#define HAL_CIA_IGR_POST_ENTRY_NUM_MAX       (HAL_CIA_UCP_ENTRY_NUM_MAX * HAL_CIA_IGR_POST_UCP_NUM_MAX)
#define HAL_CIA_EGR_POST_ENTRY_NUM_MAX       (HAL_CIA_UCP_ENTRY_NUM_MAX * HAL_CIA_EGR_POST_UCP_NUM_MAX)
#define HAL_CIA_ENTRY_INVALID_INT_ID         (0xFFFFFFFF)
#define HAL_CIA_PER_UCP_CFG_NUM              (320)
#define HAL_CIA_UCP_CFG_FRM_TYP_NUM          (5)
#define HAL_CIA_UCP_ENTRY_NUM_WORDS_MAX      (HAL_CIA_UCP_ENTRY_NUM_MAX / 32)
#define HAL_CIA_IGR_ENTRY_NUM_WORDS_MAX      (HAL_CIA_IGR_ENTRY_NUM_MAX / 32)
#define HAL_CIA_EGR_ENTRY_NUM_WORDS_MAX      (HAL_CIA_EGR_ENTRY_NUM_MAX / 32)
#define HAL_CIA_IGR_POST_ENTRY_NUM_WORDS_MAX (HAL_CIA_IGR_POST_ENTRY_NUM_MAX / 32)
#define HAL_CIA_EGR_POST_ENTRY_NUM_WORDS_MAX (HAL_CIA_EGR_POST_ENTRY_NUM_MAX / 32)
#define HAL_CIA_PER_UCP_FRM_TYPE_CFG_NUM     (HAL_CIA_PER_UCP_CFG_NUM / HAL_CIA_UCP_CFG_FRM_TYP_NUM)

#define HAL_CIA_UDF_PROF_NUM               (64)
#define HAL_CIA_UDF_PKG_DATA_BITS          (8)
#define HAL_CIA_UDF_INT_RANGE_BITS         (16)
#define HAL_CIA_UDF_INT_SRV_LBL_BITS       (12)
#define HAL_CIA_UDF_INT_VRF_BITS           (13)
#define HAL_CIA_UDF_INT_BDID_BITS          (14)
#define HAL_CIA_UDF_INT_L3_INTF_ID_BITS    (14)
#define HAL_CIA_UDF_INT_IS_ROUTER_MAC_BITS (1)
#define HAL_CIA_UDF_INT_PBM_BITS           (32)
#define HAL_CIA_RANGE_PROF_ID_DFLT         (0)

#define HAL_CIA_KEY_WIDTH_MAX           (4)
#define HAL_CIA_UDF_PROFILE_NUM         (64)
#define HAL_CIA_RANGE_OR_BITMAP_NUM     (8)
#define HAL_CIA_ITM_PER_PLANE_BMP_WORDS (HAL_ITM_PBM_WORDS / HAL_PLANE_NUM_MAX)

#define HAL_CIA_PROTO_IPV6_RTE 43
#define HAL_CIA_PROTO_IPV6_FRG 44
#define HAL_CIA_PROTO_AH       51
#define HAL_CIA_PROTO_IFA      131
#define HAL_CIA_PROTO_IOAM     186

/* check flags of CLX_CIA_GROUP_CLASSIFY_T */
#define HAL_CIA_BASE_KEY_NONE_FLAGS                                      \
    (CLX_CIA_CLASSIFY_FLAGS_PKG_KEY | CLX_CIA_CLASSIFY_FLAGS_RANGE_KEY | \
     CLX_CIA_CLASSIFY_FLAGS_UDF_VLD | CLX_CIA_CLASSIFY_FLAGS_PORT_BMP_VLD)
#define HAL_CIA_BASE_KEY_COMMON_FLAGS                                      \
    (CLX_CIA_CLASSIFY_FLAGS_QOS_KEY | CLX_CIA_CLASSIFY_FLAGS_PP_INFO_KEY | \
     CLX_CIA_CLASSIFY_FLAGS_PKG_KEY | CLX_CIA_CLASSIFY_FLAGS_RANGE_KEY |   \
     CLX_CIA_CLASSIFY_FLAGS_UDF_VLD | CLX_CIA_CLASSIFY_FLAGS_PORT_BMP_VLD)
#define HAL_CIA_BASE_KEY_L2_FLAGS (CLX_CIA_CLASSIFY_FLAGS_MAC_KEY | HAL_CIA_BASE_KEY_COMMON_FLAGS)
#define HAL_CIA_BASE_KEY_L3_ARP_FLAGS \
    (CLX_CIA_CLASSIFY_FLAGS_ARP_KEY | HAL_CIA_BASE_KEY_COMMON_FLAGS)
#define HAL_CIA_BASE_KEY_L3_IPV4_FLAGS \
    (CLX_CIA_CLASSIFY_FLAGS_IPV4_KEY | HAL_CIA_BASE_KEY_COMMON_FLAGS)
#define HAL_CIA_BASE_KEY_L3_IPV6_FLAGS \
    (CLX_CIA_CLASSIFY_FLAGS_IPV6_KEY | HAL_CIA_BASE_KEY_COMMON_FLAGS)
#define HAL_CIA_BASE_KEY_L3_MPLS_FLAGS \
    (CLX_CIA_CLASSIFY_FLAGS_MPLS_KEY | HAL_CIA_BASE_KEY_COMMON_FLAGS)

/* check flags of clx_cia_ipv4_key_t */
#define HAL_CIA_IPV4_KEY_FLAGS                                                   \
    (CLX_CIA_IPV4_KEY_FLAGS_FRG_TYPE_VLD | CLX_CIA_IPV4_KEY_FLAGS_TTL_TYPE_VLD | \
     CLX_CIA_IPV4_KEY_FLAGS_AUTH_HDR_EXIST | CLX_CIA_IPV4_KEY_FLAGS_OPT_HDR_EXIST)
#define HAL_CIA_IPV4_KEY_FLAGS_MASK \
    (CLX_CIA_IPV4_KEY_FLAGS_AUTH_HDR_EXIST | CLX_CIA_IPV4_KEY_FLAGS_OPT_HDR_EXIST)
/* check flags of clx_cia_ipv6_key_t */
#define HAL_CIA_IPV6_KEY_FLAGS                                                   \
    (CLX_CIA_IPV6_KEY_FLAGS_FRG_TYPE_VLD | CLX_CIA_IPV6_KEY_FLAGS_TTL_TYPE_VLD | \
     CLX_CIA_IPV6_KEY_FLAGS_AUTH_HDR_EXIST)
#define HAL_CIA_IPV6_KEY_FLAGS_MASK (CLX_CIA_IPV6_KEY_FLAGS_AUTH_HDR_EXIST)

#define HAL_CIA_MAC_PKT_GRP_FORMAT                                        \
    (CLX_CIA_GRP_FORMAT_TC_COLOR | CLX_CIA_GRP_FORMAT_UDF_KEY_SINGLE |    \
     CLX_CIA_GRP_FORMAT_UDF_KEY_DOUBLE | CLX_CIA_GRP_FORMAT_BASE_KEY_L2 | \
     CLX_CIA_GRP_FORMAT_L2_SWAP)
#define HAL_CIA_ARP_PKT_GRP_FORMAT (CLX_CIA_GRP_FORMAT_BASE_KEY_L3 | (HAL_CIA_MAC_PKT_GRP_FORMAT))

/* check flags of clx_cia_qos_key_t */
#define HAL_CIA_NON_IP_QOS_KEY_FLAGS                                  \
    (CLX_CIA_QOS_KEY_FLAGS_PCP_DEI | CLX_CIA_QOS_KEY_FLAGS_TC_COLOR | \
     CLX_CIA_QOS_KEY_FLAGS_COLOR_VLD | CLX_CIA_QOS_KEY_FLAGS_EXP)
#define HAL_CIA_IP_QOS_KEY_FLAGS                                       \
    (CLX_CIA_QOS_KEY_FLAGS_DSCP_ECN | CLX_CIA_QOS_KEY_FLAGS_TC_COLOR | \
     CLX_CIA_QOS_KEY_FLAGS_COLOR_VLD)
#define HAL_CIA_IP_W_L2_QOS_KEY_FLAGS (CLX_CIA_QOS_KEY_FLAGS_PCP_DEI | HAL_CIA_IP_QOS_KEY_FLAGS)

/* check flags of clx_cia_pp_info_key_t */
#define HAL_CIA_IGR_L2_PP_KEY_FLAGS                                                     \
    (CLX_CIA_PP_INFO_KEY_FLAGS_L2_FRAME_TYPE_VLD | CLX_CIA_PP_INFO_KEY_FLAGS_L3_ROUTE | \
     CLX_CIA_PP_INFO_KEY_FLAGS_STAG_VLD | CLX_CIA_PP_INFO_KEY_FLAGS_CTAG_VLD |          \
     CLX_CIA_PP_INFO_KEY_FLAGS_TNL_TERM | CLX_CIA_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_CIA_IGR_L3_NON_ARP_PP_KEY_FLAGS                                    \
    (CLX_CIA_PP_INFO_KEY_FLAGS_L3_ROUTE | CLX_CIA_PP_INFO_KEY_FLAGS_TNL_TERM | \
     CLX_CIA_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_CIA_IGR_L3_NON_ARP_W_L2_PP_KEY_FLAGS                               \
    (CLX_CIA_PP_INFO_KEY_FLAGS_L3_ROUTE | CLX_CIA_PP_INFO_KEY_FLAGS_STAG_VLD | \
     CLX_CIA_PP_INFO_KEY_FLAGS_CTAG_VLD | CLX_CIA_PP_INFO_KEY_FLAGS_TNL_TERM | \
     CLX_CIA_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_CIA_IGR_L3_ARP_PP_KEY_FLAGS (CLX_CIA_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_CIA_IGR_L3_ARP_W_L2_PP_KEY_FLAGS                                   \
    (CLX_CIA_PP_INFO_KEY_FLAGS_STAG_VLD | CLX_CIA_PP_INFO_KEY_FLAGS_CTAG_VLD | \
     CLX_CIA_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q)
#define HAL_CIA_EGR_PP_KEY_FLAGS (CLX_CIA_PP_INFO_KEY_FLAGS_L3_ROUTE)
#define HAL_CIA_PP_KEY_FLAGS_MASKABLE                                          \
    (CLX_CIA_PP_INFO_KEY_FLAGS_L3_ROUTE | CLX_CIA_PP_INFO_KEY_FLAGS_STAG_VLD | \
     CLX_CIA_PP_INFO_KEY_FLAGS_CTAG_VLD | CLX_CIA_PP_INFO_KEY_FLAGS_TNL_TERM)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_CIA_LOCK(_unit_) \
    HAL_COMMON_LOCK_RESOURCE(&_hal_cia_cb[(_unit_)].mutex_sema_id, CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_CIA_UNLOCK(_unit_) HAL_COMMON_FREE_RESOURCE(&_hal_cia_cb[(_unit_)].mutex_sema_id)

#define HAL_CIA_CHECK_STAGE(__unit__, __stage__)                                                  \
    do {                                                                                          \
        if ((CLX_CIA_STAGE_IGR != (__stage__)) && (CLX_CIA_STAGE_EGR != (__stage__)) &&           \
            (CLX_CIA_STAGE_IGR_POST != (__stage__)) && (CLX_CIA_STAGE_EGR_POST != (__stage__)) && \
            (CLX_CIA_STAGE_IGR_EXACT != (__stage__))) {                                           \
            return CLX_E_BAD_PARAMETER;                                                           \
        }                                                                                         \
        if (!HAL_IS_DEV_NB_CIAT_DOUBLE_FAMILY(__unit__)) {                                        \
            if (CLX_CIA_STAGE_IGR_POST == __stage__ || CLX_CIA_STAGE_EGR_POST == __stage__) {     \
                return CLX_E_BAD_PARAMETER;                                                       \
            }                                                                                     \
        }                                                                                         \
    } while (0)

#define HAL_CIA_INTERNAL_ID_GET(__unit__, __stage__, __ptr_internal_id__)                 \
    do {                                                                                  \
        if (CLX_CIA_STAGE_IGR == __stage__) {                                             \
            __ptr_internal_id__ = &(_hal_cia_cb[__unit__].entry_cb.igr_internal_id);      \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                      \
            __ptr_internal_id__ = &(_hal_cia_cb[__unit__].entry_cb.egr_internal_id);      \
        } else if (CLX_CIA_STAGE_IGR_POST == __stage__) {                                 \
            __ptr_internal_id__ = &(_hal_cia_cb[__unit__].entry_cb.igr_post_internal_id); \
        } else if (CLX_CIA_STAGE_EGR_POST == __stage__) {                                 \
            __ptr_internal_id__ = &(_hal_cia_cb[__unit__].entry_cb.egr_post_internal_id); \
        } else {                                                                          \
            __ptr_internal_id__ = NULL;                                                   \
        }                                                                                 \
    } while (0)

#define HAL_CIA_GET_GRP_NUM(__ptr_cia_const__, __stage__, __grp_num__) \
    do {                                                               \
        if (CLX_CIA_STAGE_IGR == __stage__) {                          \
            __grp_num__ = __ptr_cia_const__->igr_grp_num;              \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                   \
            __grp_num__ = __ptr_cia_const__->egr_grp_num;              \
        } else if (CLX_CIA_STAGE_IGR_POST == __stage__) {              \
            __grp_num__ = __ptr_cia_const__->igr_post_grp_num;         \
        } else {                                                       \
            __grp_num__ = __ptr_cia_const__->egr_post_grp_num;         \
        }                                                              \
    } while (0)

#define HAL_CIA_GET_EXACT_GRP_NUM(__ptr_cia_const__, __stage__, __grp_num__) \
    do {                                                                     \
        if (CLX_CIA_STAGE_IGR_EXACT == __stage__) {                          \
            __grp_num__ = __ptr_cia_const__->exact_grp_num;                  \
        } else {                                                             \
            __grp_num__ = __ptr_cia_const__->egr_grp_num;                    \
        }                                                                    \
    } while (0)

#define HAL_CIA_ENTRY_NUM_MAX(__stage__)                                          \
    ((CLX_CIA_STAGE_IGR == __stage__)          ? HAL_CIA_IGR_ENTRY_NUM_MAX :      \
         (CLX_CIA_STAGE_EGR == __stage__)      ? HAL_CIA_EGR_ENTRY_NUM_MAX :      \
         (CLX_CIA_STAGE_IGR_POST == __stage__) ? HAL_CIA_IGR_POST_ENTRY_NUM_MAX : \
                                                 HAL_CIA_EGR_POST_ENTRY_NUM_MAX)

#define HAL_CIA_SW_ENTRY_INFO_ARR_GET(__unit__, __stage__, __ptr_sw_entry_info_arr__)              \
    do {                                                                                           \
        if (CLX_CIA_STAGE_IGR == __stage__) {                                                      \
            __ptr_sw_entry_info_arr__ = _hal_cia_cb[__unit__].entry_cb.igr_sw_entry_info_arr;      \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                               \
            __ptr_sw_entry_info_arr__ = _hal_cia_cb[__unit__].entry_cb.egr_sw_entry_info_arr;      \
        } else if (CLX_CIA_STAGE_IGR_POST == __stage__) {                                          \
            __ptr_sw_entry_info_arr__ = _hal_cia_cb[__unit__].entry_cb.igr_post_sw_entry_info_arr; \
        } else {                                                                                   \
            __ptr_sw_entry_info_arr__ = _hal_cia_cb[__unit__].entry_cb.egr_post_sw_entry_info_arr; \
        }                                                                                          \
    } while (0)

#define HAL_CIA_SW_ENTRY_BMP_WORDS_GET(__unit__, __stage__, __sw_entry_bmp_words__) \
    do {                                                                            \
        if (CLX_CIA_STAGE_IGR == __stage__) {                                       \
            __sw_entry_bmp_words__ = HAL_CIA_IGR_ENTRY_NUM_WORDS_MAX;               \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                \
            __sw_entry_bmp_words__ = HAL_CIA_EGR_ENTRY_NUM_WORDS_MAX;               \
        } else if (CLX_CIA_STAGE_IGR_POST == __stage__) {                           \
            __sw_entry_bmp_words__ = HAL_CIA_IGR_POST_ENTRY_NUM_WORDS_MAX;          \
        } else if (CLX_CIA_STAGE_EGR_POST == __stage__) {                           \
            __sw_entry_bmp_words__ = HAL_CIA_EGR_POST_ENTRY_NUM_WORDS_MAX;          \
        }                                                                           \
    } while (0)

#define HAL_CIA_GRP_BMP_GET(__unit__, __stage__, __grp_bmp__)            \
    do {                                                                 \
        if (CLX_CIA_STAGE_IGR == __stage__) {                            \
            __grp_bmp__ = _hal_cia_cb[__unit__].grp_cb.igr_grp_bmp;      \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                     \
            __grp_bmp__ = _hal_cia_cb[__unit__].grp_cb.egr_grp_bmp;      \
        } else if (CLX_CIA_STAGE_IGR_POST == __stage__) {                \
            __grp_bmp__ = _hal_cia_cb[__unit__].grp_cb.igr_post_grp_bmp; \
        } else if (CLX_CIA_STAGE_EGR_POST == __stage__) {                \
            __grp_bmp__ = _hal_cia_cb[__unit__].grp_cb.egr_post_grp_bmp; \
        }                                                                \
    } while (0)

#define HAL_CIA_SW_ENTRY_BMP_GET(__unit__, __stage__, __ptr_sw_entry_bmp__)              \
    do {                                                                                 \
        if (CLX_CIA_STAGE_IGR == __stage__) {                                            \
            __ptr_sw_entry_bmp__ = _hal_cia_cb[__unit__].entry_cb.igr_sw_entry_bmp;      \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                     \
            __ptr_sw_entry_bmp__ = _hal_cia_cb[__unit__].entry_cb.egr_sw_entry_bmp;      \
        } else if (CLX_CIA_STAGE_IGR_POST == __stage__) {                                \
            __ptr_sw_entry_bmp__ = _hal_cia_cb[__unit__].entry_cb.igr_post_sw_entry_bmp; \
        } else {                                                                         \
            __ptr_sw_entry_bmp__ = _hal_cia_cb[__unit__].entry_cb.egr_post_sw_entry_bmp; \
        }                                                                                \
    } while (0)

#define HAL_CIA_HW_ENTRY_BMP_GET(__unit__, __stage__, __ptr_sw_entry_bmp__)              \
    do {                                                                                 \
        if (CLX_CIA_STAGE_IGR == __stage__) {                                            \
            __ptr_sw_entry_bmp__ = _hal_cia_cb[__unit__].entry_cb.igr_hw_entry_bmp;      \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                     \
            __ptr_sw_entry_bmp__ = _hal_cia_cb[__unit__].entry_cb.egr_hw_entry_bmp;      \
        } else if (CLX_CIA_STAGE_IGR_POST == __stage__) {                                \
            __ptr_sw_entry_bmp__ = _hal_cia_cb[__unit__].entry_cb.igr_post_hw_entry_bmp; \
        } else {                                                                         \
            __ptr_sw_entry_bmp__ = _hal_cia_cb[__unit__].entry_cb.egr_post_hw_entry_bmp; \
        }                                                                                \
    } while (0)

#define HAL_CIA_AVL_HEAD_GET(__unit__, __stage__, __ptr_avl_head__)                  \
    do {                                                                             \
        if (CLX_CIA_STAGE_IGR == __stage__) {                                        \
            __ptr_avl_head__ = _hal_cia_cb[__unit__].entry_cb.ptr_igr_avl_head;      \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                 \
            __ptr_avl_head__ = _hal_cia_cb[__unit__].entry_cb.ptr_egr_avl_head;      \
        } else if (CLX_CIA_STAGE_IGR_POST == __stage__) {                            \
            __ptr_avl_head__ = _hal_cia_cb[__unit__].entry_cb.ptr_igr_post_avl_head; \
        } else {                                                                     \
            __ptr_avl_head__ = _hal_cia_cb[__unit__].entry_cb.ptr_egr_post_avl_head; \
        }                                                                            \
    } while (0)

#define HAL_CIA_ADD_HW_ENTRY_BITMAP(__entry_bmp__, __entry_idx__, __entry_width__) \
    do {                                                                           \
        uint32 __idx__ = (__entry_idx__);                                          \
        for (; __idx__ < (__entry_idx__) + (__entry_width__); __idx__++) {         \
            UTIL_LIB_BMP_BIT_ADD((__entry_bmp__), (__idx__));                      \
        }                                                                          \
    } while (0)

#define HAL_CIA_DEL_HW_ENTRY_BITMAP(__entry_bmp__, __entry_idx__, __entry_width__) \
    do {                                                                           \
        uint32 __idx__ = (__entry_idx__);                                          \
        for (; __idx__ < (__entry_idx__) + (__entry_width__); __idx__++) {         \
            UTIL_LIB_BMP_BIT_DEL((__entry_bmp__), (__idx__));                      \
        }                                                                          \
    } while (0)
#define HAL_CIA_PACK_QOS_TC_COLOR(_tc_, _color_) ((((_tc_) & 0xf) << 2) + ((_color_) & 0x3))
#define HAL_CIA_PACK_DSCP_ECN(_dscp_, _ecn_)     ((((_dscp_) & 0x3f) << 2) + ((_ecn_) & 0x3))
#define HAL_CIA_UNPACK_TC(__tc_color__)          (((__tc_color__) >> 2))
#define HAL_CIA_UNPACK_COLOR(__tc_color__)       (((__tc_color__) & 0x3))
#define HAL_CIA_UNPACK_ECN(__dscp_ecn__)         (((__dscp_ecn__) & 0x3))
#define HAL_CIA_PACK_PCP_DEI(_pcp_, _dei_)       ((((_pcp_) & 0x7) << 1) + ((_dei_) & 0x1))
#define HAL_CIA_UNPACK_PCP(__pcp_dei__)          (((__pcp_dei__) >> 1))
#define HAL_CIA_UNPACK_DEI(__pcp_dei__)          (((__pcp_dei__) & 0x1))

#define HAL_CIA_PACK_SRC_DST_PORT(__src_port__, __dst_port__) \
    (((uint32)((__src_port__) & 0xffff) << 16) + ((__dst_port__) & 0xffff))
#define HAL_CIA_UNPACK_SRC_PORT(__src_dst_port__) ((__src_dst_port__) >> 16)
#define HAL_CIA_UNPACK_DST_PORT(__src_dst_port__) ((__src_dst_port__) & 0xFFFF)
#define HAL_CIA_UI32_MSK(__bits__)                (0xFFFFFFFF >> (32 - (__bits__)))
#define HAL_CIA_UI32_FLD_MSK(__unit__, __tbl_id__, __fld_id__) \
    (HAL_CIA_UI32_MSK(TOB_TABLE((__unit__), (__tbl_id__))->ptr_table_entry[(__fld_id__)].length))
#define HAL_CIA_HW_ENTRY_UCP(__unit__, __entry_1x_idx__) \
    ((__entry_1x_idx__) >> PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_bits)
#define HAL_CIA_UCP_ENTRY_NUM(__unit__)       (PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_num)
#define HAL_CIA_UCP_ENTRY_NUM_WORDS(__unit__) (HAL_CIA_UCP_ENTRY_NUM(__unit__) / 32)
#define HAL_CIA_UCP_FIRST_HW_ENTRY(__unit__, __ucp_idx__) \
    ((__ucp_idx__) << PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_bits)
#define HAL_CIA_UCP_LAST_HW_ENTRY(__unit__, __ucp_idx__) \
    ((((__ucp_idx__) + 1) << PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_bits) - 1)

#define HAL_CIA_UDF_CHECK_STAGE(_unit_, _stage_)                                    \
    do {                                                                            \
        if ((CLX_CIA_STAGE_IGR != (_stage_)) && (CLX_CIA_STAGE_EGR != (_stage_))) { \
            return CLX_E_BAD_PARAMETER;                                             \
        }                                                                           \
    } while (0)

#define HAL_CIA_RANGE_CHECK_STAGE(_unit_, _stage_)                                  \
    do {                                                                            \
        if ((CLX_CIA_STAGE_IGR != (_stage_)) && (CLX_CIA_STAGE_EGR != (_stage_))) { \
            return CLX_E_BAD_PARAMETER;                                             \
        }                                                                           \
    } while (0)

#define HAL_CIA_CHECK_UDF_PROFILE_RANGE(__unit__, __udf_prof_id__)                    \
    do {                                                                              \
        if (HAL_IS_DEVICE_NAMCHABARWA_FAMILY(unit)) {                                 \
            /* NB udf_profile_id 0 for internal used */                               \
            HAL_CHECK_MIN_MAX_RANGE(__udf_prof_id__, 1, HAL_CIA_UDF_PROFILE_NUM - 1); \
        } else if ((__udf_prof_id__) >= HAL_CIA_UDF_PROFILE_NUM) {                    \
            UTIL_LOG_PRINT(UTIL_LOG_CIA, UTIL_LOG_WARN,                               \
                           "u=%u, invalid udf-prof-id=%u, range=0-%u\n", (__unit__),  \
                           (__udf_prof_id__), HAL_CIA_UDF_PROF_NUM - 1);              \
            return CLX_E_BAD_PARAMETER;                                               \
        }                                                                             \
    } while (0)
#define HAL_CIA_UI32_FLD_MSK(__unit__, __tbl_id__, __fld_id__) \
    (HAL_CIA_UI32_MSK(TOB_TABLE((__unit__), (__tbl_id__))->ptr_table_entry[(__fld_id__)].length))

typedef enum hal_cia_igr_alloc_e {
    HAL_CIA_IGR_ALLOC_16K = 0,
    HAL_CIA_IGR_ALLOC_12K,
    HAL_CIA_IGR_ALLOC_8K,
    HAL_CIA_IGR_ALLOC_4K,
    HAL_CIA_IGR_ALLOC_0K,
} hal_cia_igr_alloc_t;

typedef enum hal_cia_wbdb_e {
    HAL_CIA_WBDB_GROUP_CB_IGR_GROUP_INFO_ARR = 0,
    HAL_CIA_WBDB_GROUP_CB_EXACT_GROUP_INFO_ARR,
    HAL_CIA_WBDB_GROUP_CB_EGR_GROUP_INFO_ARR,
    HAL_CIA_WBDB_GROUP_CB_GROUP_BMP,
    HAL_CIA_WBDB_UDF_CB_IGR_UDF_INFO_ARR,
    HAL_CIA_WBDB_UDF_CB_EGR_UDF_INFO_ARR,
    HAL_CIA_WBDB_ENTRY_CB_IGR_ENTRY_INFO_ARR,
    HAL_CIA_WBDB_ENTRY_CB_EGR_ENTRY_INFO_ARR,
    HAL_CIA_WBDB_ENTRY_CB_IGR_ENTRY_BMP,
    HAL_CIA_WBDB_ENTRY_CB_EGR_ENTRY_BMP,
    HAL_CIA_WBDB_ENTRY_CB_ENTRY_INTERNAL_ID,
    HAL_CIA_WBDB_EXACT_CB_ENTRY_INFO,
    HAL_CIA_WBDB_ADJ_ECMP_AVL,
    HAL_CIA_WBDB_GROUP_CB_IGR_POST_GROUP_INFO_ARR,
    HAL_CIA_WBDB_GROUP_CB_EGR_POST_GROUP_INFO_ARR,
    HAL_CIA_WBDB_ENTRY_CB_IGR_POST_ENTRY_BMP,
    HAL_CIA_WBDB_ENTRY_CB_EGR_POST_ENTRY_BMP,
    HAL_CIA_WBDB_ENTRY_CB_IGR_POST_ENTRY_INFO_ARR,
    HAL_CIA_WBDB_ENTRY_CB_EGR_POST_ENTRY_INFO_ARR,
    HAL_CIA_WBDB_RIM_CB_FCM_ENTRY,
    HAL_CIA_WBDB_RIM_CB_REDIR_ENTRY,
    HAL_CIA_WBDB_ACT_QOS_PROF_IDX_AVL,
    HAL_CIA_WBDB_UDF_CB_IGR_RANGE_ARR,
    HAL_CIA_WBDB_UDF_CB_EGR_RANGE_ARR,
    HAL_CIA_WBDB_LAST
} hal_cia_wbdb_t;

typedef struct hal_cia_avl_fcm_info_s {
    uint32 fcm_tbl_id; /* avl key */
    uint32 fcm_idx;    /* avl key */
    clx_cia_fcm_act_t fcm_type[CLX_CIA_FCM_NUM];
    uint32 flags;
} hal_cia_avl_fcm_info_t;

typedef struct hal_cia_avl_redir_info_s {
    clx_cia_rim_alloc_t pbr_type; /* avl key */
    uint32 pbr_rslt_idx;          /* avl key */
    uint32 pbr_adj_ecmp_id;       /* avl key adj_id or ecmp_id */
    uint32 l2_mc_id;
    uint32 flags;                 /* HAL_CIA_AVL_REDIR_INFO_FLAGS_XXX */
} hal_cia_avl_redir_info_t;

#define HAL_CIA_AVL_REDIR_INFO_FLAGS_REDIR_WITH_BDID (1U << 0) /* 0: no bdid, 1: with bdid */

typedef struct hal_cia_rim_cb_s {
    util_lib_avl_head_t *ptr_fcm_avl_head;
    util_lib_avl_head_t *ptr_redir_avl_head;
} hal_cia_rim_cb_t;

typedef struct hal_cia_adj_ecmp_pbr_info_s {
    uint32 is_ecmp;     /* avl key */
    uint32 adj_ecmp_id; /* avl key : "adj id" or "ecmp group id" */
    uint32 pbr_idx;     /* avl key : idx */
} hal_cia_adj_ecmp_pbr_info_t;

typedef struct hal_cia_qos_prof_idx_info_s {
    uint32 qos_vld;  /* avl key: qos_vld */
    uint32 dscp;     /* avl key: dscp */
    uint32 exp;      /* avl key: exp */
    uint32 pcp;      /* avl key: pcp */
    uint32 dei;      /* avl key: dei */
    uint32 cnt;      /* reference count */
    uint32 prof_idx; /* profile index */
} hal_cia_qos_prof_idx_info_t;

typedef struct hal_cia_grp_info_s {
    uint32 pri;
    uint32 ucp_member_bmp; /* NB: exact group is fpu bmp */
    uint32 pbm_type;
#define HAL_CIA_GRP_INFO_FLAGS_ACTIVE                     (1U << 0)
#define HAL_CIA_GRP_INFO_FLAGS_PREEMPT_BY_EXACT           (1U << 1)
#define HAL_CIA_GRP_INFO_FLAGS_EXACT_IGNORE_MSK_WITH_TILE (1U << 2)
    uint32 flags;
} hal_cia_grp_info_t;

typedef struct hal_cia_grp_cb_s {
    hal_cia_grp_info_t igr_grp_info_arr[HAL_CIA_IGR_GRP_NUM_MAX];
    hal_cia_grp_info_t exact_grp_info_arr[HAL_CIA_EXACT_GRP_NUM_MAX];
    hal_cia_grp_info_t egr_grp_info_arr[HAL_CIA_EGR_GRP_NUM_MAX];
    hal_cia_grp_info_t igr_post_grp_info_arr[HAL_CIA_IGR_POST_GRP_NUM_MAX];
    hal_cia_grp_info_t egr_post_grp_info_arr[HAL_CIA_EGR_POST_GRP_NUM_MAX];
    uint32 exact_grp_id[HAL_CIA_EXACT_GRP_NUM_MAX];
    uint32 igr_grp_bmp;
    uint32 egr_grp_bmp;
    uint32 igr_post_grp_bmp;
    uint32 egr_post_grp_bmp;
    uint32 exact_grp_bmp;
} hal_cia_grp_cb_t;

typedef struct hal_cia_pkg_int_key_vld_fld_s {
    uint32 tbl_id;
    uint32 lou_fld;
    uint32 flw_lbl_lcl_intf_fld;
    uint32 fdid_fld;
    uint32 vrf_fld;
    uint32 vlan_1st_vid_fld, vlan_1st_pcp_dei_fld;
    uint32 vlan_2nd_vid_fld, vlan_2nd_pcp_dei_fld;
    uint32 is_router_mac_fld;
    uint32 tcp_flags_fld;
    uint32 igr_cia_lbl_fld;
    uint32 pbm_fld;
} hal_cia_pkg_int_key_vld_fld_t;

typedef enum hal_cia_pkg_tlv_fld_idx_e {
    HAL_CIA_PKG_TLV_FLD_IGR = 0,
    HAL_CIA_PKG_TLV_FLD_EGR,
    HAL_CIA_PKG_TLV_FLD_EXACT,
    HAL_CIA_PKG_TLV_FLD_LAST
} hal_cia_pkg_tlv_fld_idx_t;

typedef struct hal_cia_pkg_tlv_s {
    hal_ikg_byte_offset_typ_enum_t type;
    uint32 byte_offset;
    uint32 byte_msk;
    uint32 byte_sel;
} hal_cia_pkg_tlv_t;

typedef struct hal_cia_pkg_tlv_fld_s {
    uint32 tbl_id;
    uint32 typ_fld;
    uint32 byte_offset_fld, byte_msk_fld;
    uint32 byte_sel_fld;
} hal_cia_pkg_tlv_fld_t;

typedef struct hal_cia_udf_int_key_cfg_s {
#define HAL_CIA_PKG_PROF_EXACT_LBL_VLD_L2_SA_OFFSET (0)
#define HAL_CIA_PKG_PROF_EXACT_LBL_VLD_L2_DA_OFFSET (1)
#define HAL_CIA_PKG_PROF_EXACT_LBL_VLD_L3_SA_OFFSET (2)
#define HAL_CIA_PKG_PROF_EXACT_LBL_VLD_L3_DA_OFFSET (3)
    uint32 exact_lbl_vld;
    uint32 int_key_vld; /* MT: DIS/RWI_RSLT_PKG_INT_KEY_VLD */
    uint32 phy_port_vld;
} hal_cia_udf_int_key_cfg_t;

typedef struct hal_cia_exact_entry_pack_udf_key_s {
    uint32 udf_prof_id;
    uint32 exact_prof_id;                  /* derived from udf prof */
    hal_cia_udf_int_key_cfg_t int_key_cfg; /* derived from udf prof */
    uint32 pkg_cnt;                        /* derived from udf prof */
    uint32 flags;                          /* HAL_CIA_EXACT_ENTRY_XXX */
} hal_cia_exact_entry_pack_udf_key_t;

#define HAL_CIA_EXACT_ENTRY_PACK_UDF_KEY_FLAGS_UDF_1Q (1U << 0) /* derived from udf prof */

typedef struct hal_cia_entry_pack_act_s {
    clx_cia_telm_type_t telm_type;
    clx_cia_redir_t redir_type;
    clx_cia_fcm_act_t fcm_type[CLX_CIA_FCM_NUM];
    uint32 l2_mc_id;
    uint32 flags;
} hal_cia_entry_pack_act_t;

#define HAL_CIA_ENTRY_PACK_ACT_MISC             (1U << 0)
#define HAL_CIA_ENTRY_PACK_ACT_LOG              (1U << 1)
#define HAL_CIA_ENTRY_PACK_ACT_RSN              (1U << 2)
#define HAL_CIA_ENTRY_PACK_ACT_MIR              (1U << 3)
#define HAL_CIA_ENTRY_PACK_ACT_SFLW             (1U << 4)
#define HAL_CIA_ENTRY_PACK_ACT_DST_CNT          (1U << 5)
#define HAL_CIA_ENTRY_PACK_ACT_SRV_CNT          (1U << 6)
#define HAL_CIA_ENTRY_PACK_ACT_SRV_CNT2         (1U << 7)
#define HAL_CIA_ENTRY_PACK_ACT_MARK             (1U << 8)
#define HAL_CIA_ENTRY_PACK_ACT_POLICER          (1U << 9)
#define HAL_CIA_ENTRY_PACK_ACT_QOS              (1U << 10)
#define HAL_CIA_ENTRY_PACK_ACT_PBR              (1U << 11)
#define HAL_CIA_ENTRY_PACK_ACT_QOS2             (1U << 12)
#define HAL_CIA_ENTRY_PACK_ACT_TELM             (1U << 13)
#define HAL_CIA_ENTRY_PACK_ACT_LABEL            (1U << 14)
#define HAL_CIA_ENTRY_PACK_ACT_REDIR_INDEX_MODE (1U << 15)
#define HAL_CIA_ENTRY_PACK_ACT_VID_VLD          (1U << 16)

typedef struct hal_cia_exact_entry_pack_info_s {
    uint32 classify_flags;
    hal_cia_exact_entry_pack_udf_key_t udf_key;
    hal_cia_entry_pack_act_t act;
    uint32 tile_idx;
} hal_cia_exact_entry_pack_info_t;

typedef struct hal_cia_entry_allc_info_s {
    uint32 pbr_tbl_id;
    uint32 pbr_rslt_idx;
    uint32 pbr_to_ecmp;
    uint32 pbr_adj_ecmp_id; /* adj id or ecmp group id*/
    uint32 pbr_sw_adj_idx;
    hal_sflow_src_type_t sflw_src_type;
    uint32 sflw_prof_idx;
    uint32 fcm_tbl_id;
    uint32 fcm_idx; /* 1x/2x/4x view idx */
    uint32 meter_hw_idx;
    uint32 policer_meter_hw_idx;
    uint32 srv_cnt_hw_idx;
    uint32 dst_cnt_hw_idx;
    hal_cia_qos_prof_idx_info_t qos_prof;
    uint32 flags; /* HAL_CIA_ENTRY_ALLOC_FLAGS_XXX */
} hal_cia_entry_alloc_info_t;

#define HAL_CIA_ENTRY_ALLOC_FLAGS_PBR_RSLT_IDX_VLD         (1U << 1)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_PBR_ADJ_ECMP_ID_VLD      (1U << 2)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_SFLW_PROF_IDX_VLD        (1U << 3)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_FCM_IDX_VLD              (1U << 4)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_FCM_IDX_IS_FLOW          (1U << 5)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_QOS_PROF_VLD             (1U << 6)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_METER_HW_IDX_VLD         (1U << 7)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_POLICER_METER_HW_IDX_VLD (1U << 8)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_SRV_CNT_HW_IDX_VLD       (1U << 9)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_DST_CNT_HW_IDX_VLD       (1U << 10)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_FCM_IDX_MODE             (1U << 11)
#define HAL_CIA_ENTRY_ALLOC_FLAGS_FCM_NOP                  (1U << 12)

typedef struct hal_cia_exact_entry_info_s {
    uint32 key_tbl;  /* 0 : invalid */
    uint32 key_idx;  /* key idx */
    uint32 rslt_tbl;
    uint32 rslt_idx; /* rslt idx */

    hal_cia_exact_entry_pack_info_t pack_info;
    hal_cia_entry_alloc_info_t alloc_info;
} hal_cia_exact_entry_info_t;

typedef enum hal_cia_qos_rslt_fld_pack_off_idx_e {
    HAL_CIA_QOS_RSLT_FLD_PACK_OFF_IGR = 0,
    HAL_CIA_QOS_RSLT_FLD_PACK_OFF_EGR,
    HAL_CIA_QOS_RSLT_FLD_PACK_OFF_LAST
} hal_cia_qos_rslt_fld_pack_off_idx_t;

typedef enum hal_cia_key_igr_qos_fld_idx_e {
    HAL_CIA_KEY_IGR_QOS_FLD_1X = 0,
    HAL_CIA_KEY_IGR_QOS_FLD_2X_WO_L2,
    HAL_CIA_KEY_IGR_QOS_FLD_2X_W_L2,
    HAL_CIA_KEY_IGR_QOS_FLD_3X,
    HAL_CIA_KEY_IGR_QOS_FLD_LAST
} hal_cia_key_igr_qos_fld_idx_t;

typedef enum hal_cia_key_egr_qos_fld_idx_e {
    HAL_CIA_KEY_EGR_QOS_FLD_1X_L2_FCOE = 0,
    HAL_CIA_KEY_EGR_QOS_FLD_1X_ARP,
    HAL_CIA_KEY_EGR_QOS_FLD_1X_IPV4,
    HAL_CIA_KEY_EGR_QOS_FLD_2X_V6,
    HAL_CIA_KEY_EGR_QOS_FLD_2X_FCOE_W_L2,
    HAL_CIA_KEY_EGR_QOS_FLD_2X_ARP_W_L2,
    HAL_CIA_KEY_EGR_QOS_FLD_2X_IPV4_W_L2,
    HAL_CIA_KEY_EGR_QOS_FLD_3X_IPV6_W_L2,
    HAL_CIA_KEY_EGR_QOS_FLD_LAST
} hal_cia_key_egr_qos_fld_idx_t;

typedef enum hal_cia_key_mac_fld_idx_e {
    HAL_CIA_KEY_MAC_FLD_1X_L2_IGR = 0,
    HAL_CIA_KEY_MAC_FLD_2X_W_L2_IGR,
    HAL_CIA_KEY_MAC_FLD_3X_W_L2_IGR,
    HAL_CIA_KEY_MAC_FLD_1X_L2_EGR,
    HAL_CIA_KEY_MAC_FLD_2X_W_L2_EGR,
    HAL_CIA_KEY_MAC_FLD_3X_W_L2_EGR,
    HAL_CIA_KEY_MAC_FLD_LAST
} hal_cia_key_mac_fld_idx_t;

typedef enum hal_cia_key_arp_fld_idx_e {
    HAL_CIA_KEY_ARP_FLD_1X_ARP_IGR = 0,
    HAL_CIA_KEY_ARP_FLD_2X_ARP_W_L2_IGR,
    HAL_CIA_KEY_ARP_FLD_1X_ARP_EGR,
    HAL_CIA_KEY_ARP_FLD_2X_ARP_W_L2_EGR,
    HAL_CIA_KEY_ARP_FLD_LAST
} hal_cia_key_arp_fld_idx_t;

typedef enum hal_cia_key_ipv4_fld_idx_e {
    HAL_CIA_KEY_IPV4_FLD_1X_IPV4_IGR = 0,
    HAL_CIA_KEY_IPV4_FLD_2X_IPV4_W_L2_IGR,
    HAL_CIA_KEY_IPV4_FLD_1X_IPV4_EGR,
    HAL_CIA_KEY_IPV4_FLD_2X_IPV4_W_L2_EGR,
    HAL_CIA_KEY_IPV4_FLD_LAST
} hal_cia_key_ipv4_fld_idx_t;

typedef enum hal_cia_key_ipv6_fld_idx_e {
    HAL_CIA_KEY_IPV6_FLD_2X_IPV6_IGR = 0,
    HAL_CIA_KEY_IPV6_FLD_3X_IPV6_W_L2_IGR,
    HAL_CIA_KEY_IPV6_FLD_2X_IPV6_EGR,
    HAL_CIA_KEY_IPV6_FLD_3X_IPV6_W_L2_EGR,
    HAL_CIA_KEY_IPV6_FLD_LAST
} hal_cia_key_ipv6_fld_idx_t;

typedef enum hal_cia_key_mpls_fld_idx_e {
    HAL_CIA_KEY_MPLS_FLD_1X_MPLS_IGR = 0,
    HAL_CIA_KEY_MPLS_FLD_1X_MPLS_EGR,
    HAL_CIA_KEY_MPLS_FLD_LAST
} hal_cia_key_mpls_fld_idx_t;

typedef enum hal_cia_key_udf_fld_idx_e {
    HAL_CIA_KEY_UDF_FLD_IGR = 0,
    HAL_CIA_KEY_UDF_FLD_EGR,
    HAL_CIA_KEY_UDF_FLD_LAST
} hal_cia_key_udf_fld_idx_t;

typedef enum hal_cia_key_igr_pp_fld_idx_e {
    HAL_CIA_KEY_IGR_PP_FLD_1X_L2 = 0,
    HAL_CIA_KEY_IGR_PP_FLD_1X_ARP,
    HAL_CIA_KEY_IGR_PP_FLD_1X_IPV4_FCOE,
    HAL_CIA_KEY_IGR_PP_FLD_2X_IPV6,
    HAL_CIA_KEY_IGR_PP_FLD_2X_ARP_W_L2,
    HAL_CIA_KEY_IGR_PP_FLD_2X_IPV4_FCOE_W_L2,
    HAL_CIA_KEY_IGR_PP_FLD_3X_IPV6_W_L2,
    HAL_CIA_KEY_IGR_PP_FLD_LAST
} hal_cia_key_igr_pp_fld_idx_t;

typedef enum hal_cia_key_egr_pp_fld_idx_e {
    HAL_CIA_KEY_EGR_PP_FLD_1X_L2 = 0,
    HAL_CIA_KEY_EGR_PP_FLD_1X_ARP,
    HAL_CIA_KEY_EGR_PP_FLD_1X_IPV4_FCOE,
    HAL_CIA_KEY_EGR_PP_FLD_2X_IPV6,
    HAL_CIA_KEY_EGR_PP_FLD_2X_ARP_W_L2,
    HAL_CIA_KEY_EGR_PP_FLD_2X_IPV4_FCOE_W_L2,
    HAL_CIA_KEY_EGR_PP_FLD_3X_IPV6_W_L2,
    HAL_CIA_KEY_EGR_PP_FLD_LAST
} hal_cia_key_egr_pp_fld_idx_t;

typedef enum hal_cia_key_base_cmn_fld_idx_e {
    HAL_CIA_KEY_BASE_CMN_FLD_1X_IGR = 0,
    HAL_CIA_KEY_BASE_CMN_FLD_2X_IGR,
    HAL_CIA_KEY_BASE_CMN_FLD_3X_IGR,
    HAL_CIA_KEY_BASE_CMN_FLD_1X_EGR,
    HAL_CIA_KEY_BASE_CMN_FLD_2X_EGR,
    HAL_CIA_KEY_BASE_CMN_FLD_3X_EGR,
    HAL_CIA_KEY_BASE_CMN_FLD_LAST
} hal_cia_key_base_cmn_fld_idx_t;

typedef struct hal_cia_key_fld_info_s {
    hal_cia_key_base_cmn_fld_idx_t key_base_cmn_fld_idx;
    hal_cia_key_mac_fld_idx_t key_mac_fld_idx;
    hal_cia_key_arp_fld_idx_t key_arp_fld_idx;
    hal_cia_key_ipv4_fld_idx_t key_ipv4_fld_idx;
    hal_cia_key_ipv6_fld_idx_t key_ipv6_fld_idx;
    hal_cia_key_mpls_fld_idx_t key_mpls_fld_idx;
    hal_cia_key_igr_qos_fld_idx_t key_igr_qos_fld_idx;
    hal_cia_key_egr_qos_fld_idx_t key_egr_qos_fld_idx;
    hal_cia_key_igr_pp_fld_idx_t key_igr_pp_fld_idx;
    hal_cia_key_egr_pp_fld_idx_t key_egr_pp_fld_idx;
    hal_cia_key_udf_fld_idx_t key_udf_fld_idx;
} hal_cia_key_fld_info_t;

typedef enum hal_cia_base_key_e {
    HAL_CIA_BASE_KEY_NONE,
    HAL_CIA_BASE_KEY_1X_L2,
    HAL_CIA_BASE_KEY_1X_ARP,
    HAL_CIA_BASE_KEY_2X_ARP_W_L2,
    HAL_CIA_BASE_KEY_1X_IPV4,
    HAL_CIA_BASE_KEY_2X_IPV4_W_L2,
    HAL_CIA_BASE_KEY_2X_IPV6,
    HAL_CIA_BASE_KEY_3X_IPV6_W_L2,
    HAL_CIA_BASE_KEY_1X_MPLS,
    HAL_CIA_BASE_KEY_2X_MPLS_W_L2
} hal_cia_base_key_t;

typedef enum hal_cia_ip_key_l4_w0_e {
    HAL_CIA_IP_KEY_L4_W0_TCP_UDP,
    HAL_CIA_IP_KEY_L4_W0_ICMP,
    HAL_CIA_IP_KEY_L4_W0_IGMP,
} hal_cia_ip_key_l4_w0_t;

typedef struct hal_cia_entry_pack_base_key_s {
    hal_cia_base_key_t type;
    uint32 width;

    hal_cia_ip_key_l4_w0_t ip_key_l4_w0_type;            /* derived from classify.ipv4/ipv6_key */

#define HAL_CIA_ENTRY_PACK_BASE_PP_KEY_1Q      (1U << 0) /* derived from classify.pp_info_key */
#define HAL_CIA_ENTRY_PACK_BASE_PP_KEY_VID_VLD (1U << 1) /* derived from classify.pp_info_key */
#define HAL_CIA_ENTRY_PACK_BASE_PP_KEY_L2_LBL  (1U << 2) /* derived from classify.pp_info_key */
#define HAL_CIA_ENTRY_PACK_BASE_PP_KEY_L3_LBL  (1U << 3) /* derived from classify.pp_info_key */
    uint32 pp_key_info;

#define HAL_CIA_ENTRY_PACK_BASE_MAC_KEY_1Q (1U << 0) /* derived from classify.mac_key */
    uint32 mac_key_info;

#define HAL_CIA_ENTRY_PACK_REPLACE_SA (1U << 0)
#define HAL_CIA_ENTRY_PACK_REPLACE_DA (1U << 1)
    uint32 ip_key_info;
} hal_cia_entry_pack_base_key_t;

typedef struct hal_cia_entry_pack_udf_key_s {
    uint32 udf_prof_id;
    uint32 width;
    uint32 exact_prof_id;                  /* derived from udf prof */
    hal_cia_udf_int_key_cfg_t int_key_cfg; /* derived from udf prof */
    uint32 pkg_0_cnt;                      /* derived from udf prof */
    uint32 pkg_1_cnt;                      /* derived from udf prof */
    uint32 pbm_msb;                        /* derived from udf prof */
    uint32 flags;                          /* HAL_CIA_ENTRY_XXX */
} hal_cia_entry_pack_udf_key_t;

#define HAL_CIA_ENTRY_PACK_UDF_KEY_FLAGS_UDF_1Q (1U << 0) /* derived from udf prof */

typedef struct hal_cia_entry_pack_info_s {
    uint32 classify_flags;
    uint32 ucp_pbm_en;
    clx_port_bitmap_t port_bitmap;
    hal_cia_entry_pack_base_key_t base_key;
    hal_cia_entry_pack_udf_key_t udf_key;
    hal_cia_entry_pack_act_t act;
} hal_cia_entry_pack_info_t;

typedef struct hal_cia_entry_info_s {
    uint32 group;          /* avl key */
    uint32 pri;            /* avl key */
    uint32 internal_id;    /* avl key */
    uint32 sw_entry_id;    /* all one means the entry is not allocated yet */

    uint32 hw_entry_id;    /* all one means the entry is not added yet */
    uint32 alloc_entry_id; /* allocate id by hal_cia_entry_id_alloc */
    uint32 norm_width;
    clx_cia_stage_t stage;
    hal_cia_entry_pack_info_t pack_info;
    hal_cia_entry_alloc_info_t alloc_info;
} hal_cia_entry_info_t;

typedef enum hal_cia_key_tcam_pkg_lou_fld_idx_e {
    HAL_CIA_KEY_TCAM_PKG_LOU_FLD_IGR = 0,
    HAL_CIA_KEY_TCAM_PKG_LOU_FLD_EGR,
    HAL_CIA_KEY_TCAM_PKG_LOU_FLD_LAST
} hal_cia_key_tcam_pkg_lou_fld_idx_t;

typedef enum hal_cia_pkg_int_key_vld_fld_idx_e {
    HAL_CIA_PKG_INT_KEY_VLD_FLD_IGR = 0,
    HAL_CIA_PKG_INT_KEY_VLD_FLD_EGR,
    HAL_CIA_PKG_INT_KEY_VLD_FLD_LAST
} hal_cia_pkg_int_key_vld_fld_idx_t;

typedef struct hal_cia_exact_cb_s {
    uint32 entry_num;
    hal_cia_exact_entry_info_t *ptr_entry_info;
} hal_cia_exact_cb_t;

typedef struct hal_cia_entry_cb_s {
    hal_cia_entry_info_t igr_sw_entry_info_arr[HAL_CIA_IGR_ENTRY_NUM_MAX];           /* index by
                                                                                        logic_entry_id */
    hal_cia_entry_info_t egr_sw_entry_info_arr[HAL_CIA_EGR_ENTRY_NUM_MAX];           /* index by
                                                                                        logic_entry_id -
                                                                                        egr_entry_id           offset,
                                                                                        mt: 12k */

    hal_cia_entry_info_t igr_post_sw_entry_info_arr[HAL_CIA_IGR_POST_ENTRY_NUM_MAX]; /* index by
                                                                                        logic_entry_id
                                                                                      */
    hal_cia_entry_info_t egr_post_sw_entry_info_arr[HAL_CIA_EGR_POST_ENTRY_NUM_MAX]; /* index by
                                                                              logic_entry_id -
                                                                              egr_entry_id offset,
                                                                              mt:  12k*/

    util_lib_avl_head_t *ptr_igr_avl_head;      /* node : HAL_CIA_ENTRY_INFO_T */
    util_lib_avl_head_t *ptr_egr_avl_head;      /* node : HAL_CIA_ENTRY_INFO_T */
    util_lib_avl_head_t *ptr_igr_post_avl_head; /* node : HAL_CIA_ENTRY_INFO_T */
    util_lib_avl_head_t *ptr_egr_post_avl_head; /* node : HAL_CIA_ENTRY_INFO_T */

    uint32 igr_sw_entry_bmp[HAL_CIA_IGR_ENTRY_NUM_WORDS_MAX];
    uint32 egr_sw_entry_bmp[HAL_CIA_EGR_ENTRY_NUM_WORDS_MAX];
    uint32 igr_post_sw_entry_bmp[HAL_CIA_IGR_POST_ENTRY_NUM_WORDS_MAX];
    uint32 egr_post_sw_entry_bmp[HAL_CIA_EGR_POST_ENTRY_NUM_WORDS_MAX];

    uint32 igr_hw_entry_bmp[HAL_CIA_IGR_ENTRY_NUM_WORDS_MAX];
    uint32 egr_hw_entry_bmp[HAL_CIA_EGR_ENTRY_NUM_WORDS_MAX];
    uint32 igr_post_hw_entry_bmp[HAL_CIA_IGR_POST_ENTRY_NUM_WORDS_MAX];
    uint32 egr_post_hw_entry_bmp[HAL_CIA_EGR_POST_ENTRY_NUM_WORDS_MAX];

    uint32 igr_internal_id;
    uint32 egr_internal_id;
    uint32 igr_post_internal_id;
    uint32 egr_post_internal_id;
    boolean insert_order_descending;
} hal_cia_entry_cb_t;

typedef struct hal_cia_key_tcam_pkg_lou_fld_s {
    uint32 tbl_id;
    uint32 vld_fld_t;
    uint32 l2_etyp_fld_t, l2_etyp_fld_c;
    uint32 l3_proto_fld_t, l3_proto_fld_c;
    uint32 l4_w0_fld_t, l4_w0_fld_c;

    uint32 l2_has_non_snap_llc_fld_t, l2_has_non_snap_llc_fld_c;
    uint32 l2_snap_present_fld_t, l2_snap_present_fld_c;

    uint32 l2_vlan_1st_vld_fld_t, l2_vlan_1st_vld_fld_c;
    uint32 l2_vlan_2nd_vld_fld_t, l2_vlan_2nd_vld_fld_c;

    uint32 lcl_intf_vld_fld_t, lcl_intf_vld_fld_c;
    uint32 lcl_intf_typ_fld_t, lcl_intf_typ_fld_c;
    uint32 lcl_intf_is_vntag_fld_t, lcl_intf_is_vntag_fld_c;

    uint32 lcl_intf_ip_tnl_is_ipv6_fld_t, lcl_intf_ip_tnl_is_ipv6_fld_c;
    uint32 lcl_intf_ip_tnl_typ_fld_t, lcl_intf_ip_tnl_typ_fld_c;
    uint32 llc_type_fld_t, llc_type_fld_c;
    uint32 tnl_is_mpls_fld_t, tnl_is_mpls_fld_c;
    uint32 lcl_is_tnl_fld_t, lcl_is_tnl_fld_c;
} hal_cia_key_tcam_pkg_lou_fld_t;

typedef struct hal_cia_udf_info_s {
    uint32 vld;
    uint32 pkg_0_cnt;
    uint32 pkg_0_consecutive_bmp;
    uint32 pkg_1_cnt;
    uint32 pkg_1_consecutive_bmp;

    uint32 exact_pkg_cnt;
    uint32 exact_pkg_consecutive_bmp;

    uint32 flags;
} hal_cia_udf_info_t;

#define HAL_CIA_UDF_INFO_FLAGS_PKT_FORMAT_1Q    (1U << 0)
#define HAL_CIA_UDF_INFO_FLAGS_PKG_INT_1Q       (1U << 1)
#define HAL_CIA_UDF_INFO_FLAGS_EXACT_PKG_INT_1Q (1U << 2)
#define HAL_CIA_UDF_INFO_FLAGS_L2_SA_LBL        (1U << 6)
#define HAL_CIA_UDF_INFO_FLAGS_L2_DA_LBL        (1U << 7)
#define HAL_CIA_UDF_INFO_FLAGS_L3_SA_LBL        (1U << 8)
#define HAL_CIA_UDF_INFO_FLAGS_L3_DA_LBL        (1U << 9)

typedef struct hal_cia_range_prof_fld_s {
    uint32 tbl_id;
    uint32 typ_fld;
    uint32 sel_fld;
    uint32 byte_offset_typ_fld, byte_offset_fld;
    uint32 val_min_fld, val_max_fld;
    uint32 val_msk_fld, inv_fld;
} hal_cia_range_prof_fld_t;

typedef struct hal_cia_range_info_s {
    uint32 vld;
    uint32 flags;
} hal_cia_range_info_t;

#define HAL_CIA_RANGE_INFO_FLAGS_1Q (1U << 0)

typedef struct hal_cia_udf_cb_s {
    hal_cia_udf_info_t igr_udf_info_arr[HAL_CIA_UDF_PROF_NUM];
    hal_cia_udf_info_t egr_udf_info_arr[HAL_CIA_UDF_PROF_NUM];
    hal_cia_range_info_t igr_range_info_arr[CLX_CIA_RANGE_NUM];
    hal_cia_range_info_t egr_range_info_arr[CLX_CIA_RANGE_NUM];
} hal_cia_udf_cb_t;

typedef struct hal_cia_cb_s {
    hal_cia_rim_cb_t rim_cb;
    hal_cia_grp_cb_t grp_cb;
    hal_cia_exact_cb_t exact_cb;
    hal_cia_entry_cb_t entry_cb;
    hal_cia_udf_cb_t udf_cb;
    util_lib_avl_head_t *ptr_adj_ecmp_pbr_avl_head; /* node : hal_cia_adj_ecmp_pbr_info_t */
    util_lib_avl_head_t *ptr_qos_prof_idx_avl_head; /* node: hal_cia_qos_prof_idx_info_t */
    clx_semaphore_id_t mutex_sema_id;
    uint32 switch_mode;
    uint32 resource_alloc_mode;
} hal_cia_cb_t;

extern hal_cia_cb_t _hal_cia_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
#define HAL_CIA_IS_EXACT_GRP(__unit__, __stage__, __grp_id__) \
    ((CLX_CIA_STAGE_IGR_EXACT == stage) &&                    \
     (UTIL_LIB_BMP_BIT_CHK(&(_hal_cia_cb[__unit__].grp_cb.exact_grp_bmp), __grp_id__)))

#define HAL_CIA_EXACT_SEARCH_VLD(_unit_) (_hal_cia_cb[(_unit_)].exact_cb.entry_num)

#define HAL_CIA_IS_CIA_GRP(__unit__, __group_id__, __stage__)                  \
    (((__stage__ == CLX_CIA_STAGE_IGR) &&                                      \
      (__group_id__ < PTR_HAL_CONST_INFO(__unit__, cia)->igr_grp_num)) ||      \
     ((__stage__ == CLX_CIA_STAGE_EGR) &&                                      \
      (__group_id__ < PTR_HAL_CONST_INFO(__unit__, cia)->egr_grp_num)) ||      \
     ((__stage__ == CLX_CIA_STAGE_IGR_POST) &&                                 \
      (__group_id__ < PTR_HAL_CONST_INFO(__unit__, cia)->igr_post_grp_num)) || \
     ((__stage__ == CLX_CIA_STAGE_EGR_POST) &&                                 \
      (__group_id__ < PTR_HAL_CONST_INFO(__unit__, cia)->egr_post_grp_num)))

#define HAL_CIA_IS_IGR_GRP(__unit__, __stage__)                            \
    ((CLX_CIA_STAGE_IGR_EXACT == stage) || (CLX_CIA_STAGE_IGR == stage) || \
     (CLX_CIA_STAGE_IGR_POST == stage))

#define HAL_CIA_IS_EGR_GRP(__unit__, __stage__) \
    ((CLX_CIA_STAGE_EGR == stage) || (CLX_CIA_STAGE_EGR_POST == stage))

#define HAL_CIA_GET_CANDI_UDF_PROF_ID(__candi_prof_id__, __prof_id__, __prof_id_mask__,  \
                                      __udf_prof_id_arr__)                               \
    do {                                                                                 \
        if ((0 == (__prof_id_mask__)) && ((__udf_prof_id_arr__)[(__prof_id__)].vld)) {   \
            (__candi_prof_id__) = (__prof_id__);                                         \
        } else {                                                                         \
            for ((__candi_prof_id__) = 0; (__candi_prof_id__) < HAL_CIA_UDF_PROFILE_NUM; \
                 (__candi_prof_id__)++) {                                                \
                if ((((__candi_prof_id__) & (__prof_id_mask__)) ==                       \
                     ((__prof_id__) & (__prof_id_mask__))) &&                            \
                    ((__udf_prof_id_arr__)[(__candi_prof_id__)].vld)) {                  \
                    break;                                                               \
                }                                                                        \
            }                                                                            \
            if (HAL_CIA_UDF_PROFILE_NUM == (__candi_prof_id__)) {                        \
                (__candi_prof_id__) = HAL_INVALID_ID;                                    \
            }                                                                            \
        }                                                                                \
    } while (0)

#define HAL_CIA_COPY_TBL(__rc__, __unit__, __bcast_id__, __tbl_id__, __src_entry__, __dst_entry__, \
                         __num__)                                                                  \
    do {                                                                                           \
        TOB_CHIP_INFO_SET(chip_info, (__unit__), (__bcast_id__), 0);                               \
        TOB_TBL_COPY_SET(copy_info, (__tbl_id__), 0, (__src_entry__), (__dst_entry__), (__num__)); \
        (__rc__) = tob_table_copy(chip_info, &copy_info);                                          \
        if (CLX_E_OK != (__rc__)) {                                                                \
            break;                                                                                 \
        }                                                                                          \
    } while (0)
#if defined(CLX_ASICSIM)
#define HAL_CIA_COPY_ACTION_TBL(__rc__, __unit__, __tbl_id__, __sub_inst__, __src_entry__,         \
                                __dst_entry__, __num__)                                            \
    do {                                                                                           \
        TOB_CHIP_INFO_SET(chip_info, (__unit__), (TOB_INST_IDX_BCAST), (__sub_inst__));            \
        TOB_TBL_COPY_SET(copy_info, (__tbl_id__), 0, (__src_entry__), (__dst_entry__), (__num__)); \
        (__rc__) = tob_table_copy(chip_info, &copy_info);                                          \
        if (CLX_E_OK != (__rc__)) {                                                                \
            break;                                                                                 \
        }                                                                                          \
    } while (0)
#endif
#define HAL_CIA_PER_UCP_HW_ENTRY_IDX(__unit__, __entry_1x_idx__) \
    ((__entry_1x_idx__) & HAL_CIA_UI32_MSK(PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_bits))
/**
 * @brief Init CIA module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Init success.
 * @return        CLX_E_NO_MEMORY        - Allocate control block failed.
 * @return        CLX_E_OTHERS           - Init fail.
 * @return        CLX_E_BAD_PARAMETER    - Parameter invalid.
 */
clx_error_no_t
hal_cia_init(const uint32 unit);

/**
 * @brief Deinit CIA module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Deinit success.
 * @return        CLX_E_OTHERS           - DeInit fail.
 * @return        CLX_E_BAD_PARAMETER    - Parameter invalid.
 */
clx_error_no_t
hal_cia_deinit(const uint32 unit);

/**
 * @brief The API is used to get the configuration information of UCP group.
 *
 * Support_chip: all.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     grp_id          - The UCP group id to be deleted.
 * @param [out]    ptr_grp_prof    - UCP group profile to be returned.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_grp_get(const uint32 unit,
                const clx_cia_stage_t stage,
                const uint32 grp_id,
                clx_cia_grp_prof_t *ptr_grp_prof);

/**
 * @brief The API is used to add a UCP group.
 *
 * Support_chip: all.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     ptr_grp_prof    - UCP group profile.
 * @param [out]    ptr_grp_id      - UCP group id.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_grp_add(const uint32 unit,
                const clx_cia_stage_t stage,
                const clx_cia_grp_prof_t *ptr_grp_prof,
                uint32 *ptr_grp_id);

/**
 * @brief The API is used to delete a UCP group.
 *
 * Support_chip: all.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    stage     - UCP group stage type.
 * @param [in]    grp_id    - The UCP group id to be deleted.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_grp_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 grp_id);

/**
 * @brief The API is used to traverse UCP groups.
 *
 * Support_chip: all.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     callback      - The callback function of type clx_cia_grp_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_grp_trav(const uint32 unit,
                 const clx_cia_stage_t stage,
                 const clx_cia_grp_trav_func_t callback,
                 void *ptr_cookie);

/**
 * @brief The API is used to get the configuration information of exact UCP group.
 *
 * Support_chip: all.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     grp_id          - The UCP group id to be deleted.
 * @param [out]    ptr_grp_prof    - UCP group profile to be returned.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_exact_grp_get(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 grp_id,
                      clx_cia_exact_grp_prof_t *ptr_grp_prof);

/**
 * @brief The API is used to add a exact UCP group.
 *
 * Support_chip: all.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     ptr_grp_prof    - UCP group profile.
 * @param [out]    ptr_grp_id      - UCP group id.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_exact_grp_add(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                      uint32 *ptr_grp_id);

/**
 * @brief The API is used to delete a exact UCP group.
 *
 * Support_chip: all.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    stage     - UCP group stage type.
 * @param [in]    grp_id    - The UCP group id to be deleted.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_exact_grp_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 grp_id);

/**
 * @brief The API is used to traverse exact UCP groups.
 *
 * Support_chip: all.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     callback      - The callback function of type CLX_CIA_GRP_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_exact_grp_trav(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const clx_cia_exact_grp_trav_func_t callback,
                       void *ptr_cookie);

/**
 * @brief The API is used to get the configuration information of udf key profile.
 *
 * Support_chip: all.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - Udf key profile stage type.
 * @param [in]     udf_entry_id      - The udf key profile id to be get.
 * @param [out]    ptr_entry_info    - The Udf info return.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_udf_entry_get(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 udf_entry_id,
                      clx_cia_udf_entry_t *ptr_entry_info);

/**
 * @brief The API is used to add a udf key profile.
 *
 * Support_chip: all.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    stage             - Udf key profile stage type.
 * @param [in]    udf_entry_id      - The udf key profile id to be added.
 * @param [in]    ptr_entry_info    - The UDF info.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_udf_entry_add(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 udf_entry_id,
                      const clx_cia_udf_entry_t *ptr_entry_info);

/**
 * @brief The API is used to delete a udf key profile.
 *
 * Support_chip: all.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    stage           - Udf key profile stage type.
 * @param [in]    udf_entry_id    - Udf key profile id to be deleted.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_udf_entry_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 udf_entry_id);

/**
 * @brief The API is used to traverse udf key profile.
 *
 * Support_chip: all.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - Udf key profile stage type.
 * @param [in]     callback      - The callback function of type clx_cia_udf_entry_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_udf_entry_trav(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const clx_cia_udf_entry_trav_func_t callback,
                       void *ptr_cookie);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * Support_chip: all.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     entry_id         - Entry id.
 * @param [out]    ptr_stage        - The UCP group type of the entry id to be returned.
 * @param [out]    ptr_grp_id       - The group id of the entry id to be returned.
 * @param [out]    ptr_entry_pri    - The entry priority of the entry id to be returned.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_entry_id_info_get(const uint32 unit,
                          const uint32 entry_id,
                          clx_cia_stage_t *ptr_stage,
                          uint32 *ptr_grp_id,
                          uint32 *ptr_entry_pri);

/**
 * @brief The API is used to allocate a logic id for UCP entry.
 *
 * Support_chip: all.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group type.
 * @param [in]     grp_id          - Allocate a entry id from UCP group.
 * @param [in]     entry_pri       - Entry priority.
 * @param [out]    ptr_entry_id    - The entry id to be returned.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_entry_id_alloc(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const uint32 grp_id,
                       const uint32 entry_pri,
                       uint32 *ptr_entry_id);

/**
 * @brief The API is used to free the logic id for UCP entry.
 *
 * Support_chip: all.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_entry_id_free(const uint32 unit, const uint32 entry_id);

/**
 * @brief The API is used to get an UCP entry from HW.
 *
 * Support_chip: all.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     entry_id          - Entry id.
 * @param [out]    ptr_entry_info    - The entry information returned.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_entry_get(const uint32 unit, const uint32 entry_id, clx_cia_entry_t *ptr_entry_info);

/**
 * @brief The API is used to set valid bit of Tcam entry to HW.
 *
 * Support_chip: all.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    entry_id     - Entry id.
 * @param [in]    entry_vld    - The valid bit of entry.
 * @return        CLX_E_OK    - Operate success.
 */

clx_error_no_t
hal_cia_entry_vld_set(const uint32 unit, const uint32 entry_id, const boolean entry_vld);

/**
 * @brief The API is used to delete an Tcam entry from HW.
 *
 * Support_chip: all.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_entry_del(const uint32 unit, const uint32 entry_id);

/**
 * @brief The API is used to traverse UCP entries.
 *
 * Support_chip: all.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage.
 * @param [in]     grp_id        - Group id.
 * @param [in]     callback      - The callback function of type CLX_CIA_ENTRY_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_entry_trav(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const uint32 grp_id,
                   const clx_cia_entry_trav_func_t callback,
                   void *ptr_cookie);

/**
 * @brief The API is used to get an exact match entry from HW.
 *
 * Support_chip: all.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - UCP group stage type.
 * @param [in]     grp_id            - Group id.
 * @param [in]     entry_id          - Entry id.
 * @param [out]    ptr_entry_info    - The entry information.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_exact_entry_get(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        const uint32 entry_id,
                        clx_cia_exact_entry_t *ptr_entry_info);

/**
 * @brief The API is used to delete an exact match entry from HW.
 *
 * Support_chip: all.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    stage       - UCP group stage type.
 * @param [in]    grp_id      - Group id.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_exact_entry_del(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        const uint32 entry_id);

/**
 * @brief The API is used to traverse UCP entries.
 *
 * Support_chip: all.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     grp_id        - Group id.
 * @param [in]     callback      - The callback function of type CLX_CIA_ENTRY_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_exact_entry_trav(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 grp_id,
                         const clx_cia_exact_entry_trav_func_t callback,
                         void *ptr_cookie);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * Support_chip: all.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     entry_id      - Flow entry id.
 * @param [out]    ptr_stage     - The UCP group stage type of the entry id to be returned.
 * @param [out]    ptr_grp_id    - The group id of the entry id to be returned.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_exact_entry_id_info_get(const uint32 unit,
                                const uint32 entry_id,
                                clx_cia_stage_t *ptr_stage,
                                uint32 *ptr_grp_id);

/**
 * @brief The API is used to alloc resource index.
 *
 * Support_chip: all.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - Resouce index type.
 * @param [out]    ptr_index    - Alloc index.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_rim_alloc(const uint32 unit, const clx_cia_rim_alloc_t type, uint32 *ptr_index);

/**
 * @brief The API is used to free resource index.
 *
 * Support_chip: all.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    type     - Resouce index type.
 * @param [in]    index    - Free index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_rim_free(const uint32 unit, const clx_cia_rim_alloc_t type, const uint32 index);

/**
 * @brief The API is used to set index action.
 *
 * Support_chip: all.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    type       - Resouce index type.
 * @param [in]    index      - Set index.
 * @param [in]    ptr_act    - Set index action.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_rim_act_set(const uint32 unit,
                    const clx_cia_rim_alloc_t type,
                    const uint32 index,
                    const void *ptr_act);

/**
 * @brief The API is used to get index action.
 *
 * Support_chip: all.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Resouce index type.
 * @param [in]     index      - Get index.
 * @param [out]    ptr_act    - Get index action.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_rim_act_get(const uint32 unit,
                    const clx_cia_rim_alloc_t type,
                    const uint32 index,
                    void *ptr_act);

/**
 * @brief The API is used to traverse rim resouce.
 *
 * Support_chip: all.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - Resouce index type.
 * @param [in]     callback      - The callback function of type CLX_CIA_RIM_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_rim_act_trav(const uint32 unit,
                     const clx_cia_rim_alloc_t type,
                     const clx_cia_rim_trav_func_t callback,
                     void *ptr_cookie);

/**
 * @brief The API is used to add/set the range configuration information.
 *
 * Support_chip: all.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    stage        - UCP group type: Ingress/Egress.
 * @param [in]    range_id     - The range id to be added/set.
 * @param [in]    ptr_range    - The range configuration information.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_range_add(const uint32 unit,
                  const clx_cia_stage_t stage,
                  const uint32 range_id,
                  const clx_cia_range_cfg_t *ptr_range);

/**
 * @brief The API is used to delete the range configuration information.
 *
 * Support_chip: all.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    stage       - UCP group type: Ingress/Egress.
 * @param [in]    range_id    - The range id to be deleted.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_range_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 range_id);

/**
 * @brief The API is used to get the range configuration information.
 *
 * Support_chip: all.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     stage        - UCP group type: Ingress/Egress.
 * @param [in]     range_id     - The range id to be get.
 * @param [out]    ptr_range    - The range configuration information to be returned.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_range_get(const uint32 unit,
                  const clx_cia_stage_t stage,
                  const uint32 range_id,
                  clx_cia_range_cfg_t *ptr_range);

/**
 * @brief The API is used to traverse range.
 *
 * Support_chip: all.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group type: Ingress/Egress.
 * @param [in]     callback      - The callback function of type clx_cia_range_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_cia_range_trav(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const clx_cia_range_trav_func_t callback,
                   void *ptr_cookie);

clx_error_no_t
hal_cia_grp_cb_get(const uint32 unit,
                   const clx_cia_stage_t stage,
                   hal_cia_grp_info_t **ptr_grp_info_arr,
                   uint32 **ptr_grp_bmp,
                   uint32 **ptr_flow_grp_id);

clx_error_no_t
hal_cia_hw_entry_id_alloc(const uint32 unit,
                          const clx_cia_stage_t stage,
                          const hal_cia_entry_info_t *ptr_entry,
                          const uint32 norm_width,
                          uint32 *ptr_alloc_hw_entry_id);
clx_error_no_t
hal_cia_capacity_get(const uint32 unit,
                     const clx_swc_rsrc_t type,
                     const uint32 param,
                     uint32 *ptr_size);
clx_error_no_t
hal_cia_usage_get(const uint32 unit, const clx_swc_rsrc_t type, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_cia_adj_info_update(const uint32 unit,
                        const uint32 adj_id,
                        const hal_l3_adj_info_t *ptr_adj_info);

clx_error_no_t
hal_cia_ecmp_info_update(const uint32 unit,
                         const uint32 ecmp_group_id,
                         const hal_l3_ecmp_t *ptr_ecmp_info);

#endif
