/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_l3.h
 * PURPOSE:
 *      Provide HAL driver API functions for CL8570.
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_NB_L3_H
#define HAL_MT_NB_L3_H

/*****************************************************************************
 * INCLUDE FILE DECLARATIONS
 *****************************************************************************
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_l3.h>
#include <clx/clx_l2.h>
#include <util/util.h>
#include <util/lib/util_lib_avl.h>
#include <util/lib/util_lib_list.h>
#include <util/lib/util_lib_bit.h>
#include <util/lib/util_lib_bmp.h>
#include <hal/hal_l3.h>
#include <hal/hal_tbl.h>
#include <hal/hal_io.h>
#include <hal/hal_swc.h>
#include <hal/hal_lag.h>
#include <tob/mountain/tob_mt.h>
#include <hal/mt/nb/hal_mt_nb_swc.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
/* HITBIT */
#define HAL_MT_NB_L3_HITBIT_SLICE (32) /* 32 FPU share one MT_NB_TBL_FPU_RSLT_HSH_HIT_ID */
#define HAL_MT_NB_L3_HITBIT_BITS  (1)  /* 1 bits for each FPU entry */

#define HAL_MT_NB_L3_MGI_V4_HASH_ENTRY_NUM_PER_BANK (20 * 1024)
#define HAL_MT_NB_L3_MGI_V6_HASH_ENTRY_NUM_PER_BANK (10 * 1024)
#define HAL_MT_NB_L3_MSGI_HASH_ENTRY_NUM_PER_BANK   (20 * 1024)

#define HAL_MT_NB_L3_TCAM_IND_NORMAL_BUF_WORDS (MT_NB_CDB_FPUTCAM_SLV_SLC0_TILE_TCAM_IND_DATA_WORDS)
#define HAL_MT_NB_L3_TCAM_IND_LONG_BUF_WORDS \
    (MT_NB_CDB_FPUTCAM_SLV_SLC0_TILE_TCAM_IND_DATA_WORDS * 2)
#define HAL_MT_NB_L3_HASH_IND_BUF_WORDS (MT_NB_CDB_FPUHSH_SLV_TILE_HSH_IND_DATA_WORDS)

/* INTF */
#define HAL_MT_NB_L3_INTF_NUM(unit) \
    (HAL_TBL_INFO(unit, MT_NB_TBL_DIS_RSLT_BDI_ID)->entry_max_number)
#define HAL_MT_NB_L3_INTF_MIN(unit) (1) /* SW-reserved 0 */
#define HAL_MT_NB_L3_INTF_MAX(unit) (HAL_MT_NB_L3_INTF_NUM(unit) - 1)

/* MTU */
#define HAL_MT_NB_L3_MTU_SIZE_MIN  (0)
#define HAL_MT_NB_L3_MTU_SIZE_MAX  HAL_L3_MTU_SIZE
#define HAL_MT_NB_L3_MTU_SIZE_DFLT (0)

/* VRF */
#define HAL_MT_NB_L3_VRF_ENTRY_NUM  (8192)
#define HAL_MT_NB_L3_VRF_ENTRY_MIN  (0)
#define HAL_MT_NB_L3_VRF_ENTRY_MAX  (HAL_MT_NB_L3_VRF_ENTRY_NUM - 1)
#define HAL_MT_NB_L3_VRF_ENTRY_MASK (HAL_MT_NB_L3_VRF_ENTRY_NUM - 1)

/* Router-MAC */
#define HAL_MT_NB_L3_RMAC_NUM(unit) \
    (HAL_TBL_INFO(unit, MT_NB_TBL_DIS_TCAM_RMACI_ID)->entry_max_number)
#define HAL_MT_NB_L3_RMAC_MIN(unit) (0)
#define HAL_MT_NB_L3_RMAC_MAX(unit) (HAL_MT_NB_L3_RMAC_NUM(unit) - 1) /* reserve 1 for invalid */
#define HAL_MT_NB_L3_RMAC_INVLD     (4095)

/* reserved drop adj */
#define HAL_MT_NB_L3_ADJ_HW_RESERVE_NUM (8)
#define HAL_MT_NB_L3_DROP_ADJ_ID        CLX_L3_ID_CREATE(CLX_L3_ADJ_TYPE_L3, 0)

/* ROUTE */
#define HAL_MT_NB_L3_ROUTE_AFIB_DFLT_NUM (32768)

/* ECMP */
#define HAL_MT_L3_ECMP_PATH_MAX_TOT (1U << 10) /* act_tot = MAX      */
#define HAL_MT_L3_ECMP_HSH_MAX_TOT  (1U << 15) /* sw_spray_tot = MAX */

/* default act_base or orig_base CLX_NHP_TYPE_ADJ/CLX_NHP_TYPE_L2_ECMP */
#define HAL_MT_L3_ADJ_L2_ECMP_PATH_DFLT_BASE_IDX (65535)
/* default act_base or orig_base CLX_NHP_TYPE_MPLS_TRANS */
#define HAL_MT_L3_MPLS_ECMP_PATH_DFLT_BASE_IDX (16384)
/* default act_base or orig_base CLX_NHP_TYPE_TNL */
#define HAL_MT_L3_NVO3_ECMP_PATH_DFLT_BASE_IDX (4095)

/* MCAST */
#define HAL_L3_RPF_TCAM_MAX_NUM              (1024)
#define HAL_L3_MCAST_SG_TCAM_MAX_NUM         (1024)
#define HAL_MT_NB_L3_MCAST_L3MC_ID(mcast_id) (mcast_id - HAL_L2_MGID_NUM)

#define HAL_MT_L3_MPLS_LABEL_BITMASK    (0xFFFFF)
#define HAL_MT_L3_VALN_BITMASK          (0xFFF)
#define HAL_MT_L3_VALN_VID_BITLENGTH    (12)
#define HAL_MT_L3_SVALN_LABEL_BITLENGTH (8)

#define HAL_MT_NB_L3_MCAST_FPU_KRN_OFFSET (20)
#define HAL_MT_NB_L3_MCAST_FPU_KRN_LEN    (1)

/* ECMP */
#define HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT (4)
#define HAL_MT_L3_ECMP_MBR_TABLE_CNT(tot) \
    ((tot > 0) ? ((tot) - 1) / HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT + 1 : 0)
#define HAL_MT_L3_ECMP_MBR_HW_CNT(tot) \
    ((HAL_MT_L3_ECMP_MBR_TABLE_CNT(tot)) * HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT)
#define HAL_MT_L3_ECMP_MBR_TABLE_IDX(offset)    ((offset) / HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT)
#define HAL_MT_L3_ECMP_MBR_TABLE_OFFSET(offset) ((offset) * HAL_MT_L3_ECMP_PER_TABLE_MBR_CNT)

#define HAL_MT_L3_ECMP_NVO3_PER_TABLE_MBR_CNT (1)
#define HAL_MT_L3_ECMP_NVO3_MBR_TABLE_CNT(tot) \
    ((tot > 0) ? ((tot) - 1) / HAL_MT_L3_ECMP_NVO3_PER_TABLE_MBR_CNT + 1 : 0)

#define HAL_MT_L3_ECMP_MBR_PHY2LOGIC_BASE(base) ((base) & 0xffff)

#define HAL_MT_ADJ_L2_ECMP_GRP_MAX_NUM (16 * 1024)
#define HAL_MT_NVO3_ECMP_GRP_MAX_NUM   (64)
#define HAL_MT_MPLS_ECMP_GRP_MAX_NUM   (1024)
#define HAL_MT_ADJ_L2_ECMP_MBR_MAX_NUM (16 * 1024)
#define HAL_MT_NVO3_ECMP_MBR_MAX_NUM   (4 * 1024)
#define HAL_MT_MPLS_ECMP_MBR_MAX_NUM   (4 * 1024)

#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_SLICE_LEN    (1)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_STAGE_LEN    (2)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_TILE_LEN     (3)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_INDEX_LEN    (16)
#define HAL_MT_L3_ECMP_FPU_GRP_BASE_INDEX_LEN        (15)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_SLICE_OFFSET (21)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_STAGE_OFFSET (19)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_TILE_OFFSET  (16)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_BASE_INDEX_OFFSET (0)
#define HAL_MT_L3_ECMP_FPU_GRP_MBR_INVALID_FWD_PTR   (0x7FFFF) /* 2b'Stage,3b'tile,14b'index */
#define HAL_MT_L3_ECMP_ICIA_GRP_MBR_IVALID_FWD_PTR   (0x3FFFF)
#define HAL_MT_L3_FAST_CMD_DONE_POLLING_USEC         (1000)
#define HAL_MT_L3_FAST_CMD_HSH_ENTRY_WORDS           (6)
#define HAL_MT_L3_FAST_CMD_TCAM_ENTRY_WORDS          (8)

#define HAL_MT_L3_FAST_CMD_AGE    (0)
#define HAL_MT_L3_FAST_CMD_SEARCH (1)

#define HAL_MT_L3_FAST_CMD_UNEQUAL (0)
#define HAL_MT_L3_FAST_CMD_EQUAL   (1)
#define HAL_MT_L3_FAST_CMD_BOTH    (2)

#define HAL_MT_L3_FAST_CMD_MODIFY (1)
#define HAL_MT_L3_FAST_CMD_REMOVE (2)

#if defined(NB_EMU_DEV) || defined(CLX_MOCK)
#define HAL_MT_L3_HW_FPU_NUM (1) /* TODO: tmp, maybe cdb will have this macro later */
#else
#define HAL_MT_L3_HW_FPU_NUM (4) /* TODO: tmp, maybe cdb will have this macro later */
#endif

#define HAL_MT_L3_FAST_CMD_DONE_POLLING_NUM_MAX (10000)

/* drop base id */
#define HAL_MT_NB_L3_DROP_ID(unit) (HAL_DROP_BASE_ID(unit))

/*****************************************************************************
 * MACRO FUNCTION DECLARATIONS
 *****************************************************************************
 */
/* hw_addr is 20bit format, 2bit stage + 3bit tile + 15bit entry_idx, entry_width is means how many
 * 1x used per entry */
#define HAL_MT_NB_L3_HIT_ADDR_GET(__hw_addr__, __hit_addr__) \
    do {                                                     \
        TOB_MT_NB_FPU_GET_IDX(__hw_addr__, __hit_addr__);    \
        __hit_addr__ >>= 5;                                  \
    } while (0)

#define HAL_MT_NB_L3_GET_PHY_FPU_ADDR(__slice_idx__, __stage_idx__, __tile_idx__, __entry_idx__, \
                                      __phy_fpu_idx__)                                           \
    (__phy_fpu_idx__ =                                                                           \
         (((__entry_idx__) & ((1 << TOB_MT_HASH_INDEX_LEN) - 1)) |                               \
          (((__tile_idx__) & ((1 << TOB_MT_HASH_TILE_LEN) - 1)) << TOB_MT_HASH_TILE_OFFSET) |    \
          (((__stage_idx__) & ((1 << TOB_MT_HASH_STAGE_LEN) - 1)) << TOB_MT_HASH_STAGE_OFFSET) | \
          (((__slice_idx__) & ((1 << TOB_MT_HASH_INST_LEN) - 1)) << TOB_MT_HASH_INST_OFFSET)))

#define HAL_MT_NB_L3_GET_12_8T_FPU_ADDR(__slice_idx__, __entry_idx__, __phy_fpu_idx__)              \
    (__phy_fpu_idx__ =                                                                              \
         (((__entry_idx__) &                                                                        \
           (((1 << (TOB_MT_HASH_INDEX_LEN + TOB_MT_HASH_TILE_LEN + TOB_MT_HASH_STAGE_LEN)) - 1))) | \
          (((__slice_idx__) & ((1 << TOB_MT_HASH_INST_LEN) - 1)) << TOB_MT_HASH_INST_OFFSET)))

/* ADJ */
#define HAL_MT_NB_L3_ADJ_FPU_SIZE(__bitmap__, __bitmap_size__, __fpu_size__, __size__) \
    do {                                                                               \
        uint32 bit;                                                                    \
        __size__ = 0;                                                                  \
        UTIL_LIB_BMP_BIT_FOREACH(__bitmap__, bit, __bitmap_size__)                     \
        {                                                                              \
            __size__ = __size__ + __fpu_size__;                                        \
        }                                                                              \
    } while (0)

#define HAL_MT_NB_L3_ADJ_HW_TO_SW_INDEX(hw_index, sw_index)                                       \
    ((sw_index) =                                                                                 \
         ((hw_index) / HAL_SWC_HASH_ENTRY_NUM_PER_BANK *                                          \
              (HAL_SWC_HASH_ENTRY_NUM_PER_BANK - HAL_MT_NB_L3_ADJ_HW_RESERVE_NUM) +               \
          ((hw_index) % HAL_SWC_HASH_ENTRY_NUM_PER_BANK >= HAL_MT_NB_L3_ADJ_HW_RESERVE_NUM ?      \
               ((hw_index) % HAL_SWC_HASH_ENTRY_NUM_PER_BANK - HAL_MT_NB_L3_ADJ_HW_RESERVE_NUM) : \
               0)))

#define HAL_MT_NB_L3_ADJ_SW_TO_HW_INDEX(sw_index, hw_index)                                  \
    ((hw_index) =                                                                            \
         ((sw_index) / (HAL_SWC_HASH_ENTRY_NUM_PER_BANK - HAL_MT_NB_L3_ADJ_HW_RESERVE_NUM) * \
              HAL_SWC_HASH_ENTRY_NUM_PER_BANK +                                              \
          (sw_index) % (HAL_SWC_HASH_ENTRY_NUM_PER_BANK - HAL_MT_NB_L3_ADJ_HW_RESERVE_NUM) + \
          HAL_MT_NB_L3_ADJ_HW_RESERVE_NUM))

/* utility */
#define HAL_MT_NB_L3_PLANE_BMP_FOREACH(__unit__, __plane__)                     \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

/* hw addr and fpu addr */
#define HAL_MT_NB_L3_FWD_GET(__fpu__, __fwd__)                                           \
    (__fwd__ = ((__fpu__) & (HAL_SWC_HASH_ENTRY_NUM_PER_BANK - 1)) |                     \
         ((((__fpu__) >> TOB_MT_HASH_TILE_OFFSET) & ((1 << TOB_MT_HASH_TILE_LEN) - 1))   \
          << (TOB_MT_HASH_TILE_OFFSET - 1)) |                                            \
         ((((__fpu__) >> TOB_MT_HASH_STAGE_OFFSET) & ((1 << TOB_MT_HASH_STAGE_LEN) - 1)) \
          << (TOB_MT_HASH_STAGE_OFFSET - 1)))

#define HAL_MT_NB_L3_FPU_GET(__fwd__, __fpu__)                                                 \
    (__fpu__ = ((__fwd__) & (HAL_SWC_HASH_ENTRY_NUM_PER_BANK - 1)) |                           \
         ((((__fwd__) >> (TOB_MT_HASH_TILE_OFFSET - 1)) & ((1 << TOB_MT_HASH_TILE_LEN) - 1))   \
          << TOB_MT_HASH_TILE_OFFSET) |                                                        \
         ((((__fwd__) >> (TOB_MT_HASH_STAGE_OFFSET - 1)) & ((1 << TOB_MT_HASH_STAGE_LEN) - 1)) \
          << TOB_MT_HASH_STAGE_OFFSET))

#define HAL_MT_NB_L3_FPU_SLICE_SET(__old_fpu__, __new_fpu__) \
    (__new_fpu__ = ((__old_fpu__) | (1 << TOB_MT_HASH_INST_OFFSET)))

/* VLAN and MPLS LABEL */
#define HAL_MT_NB_L3_GET_VLAN_BY_LBL(__s_vlan__, __c_vlan__, __mpls_en__, __mpls_label__) \
    do {                                                                                  \
        (__s_vlan__) = (__mpls_label__ & HAL_MT_L3_MPLS_LABEL_BITMASK) >>                 \
            HAL_MT_L3_VALN_VID_BITLENGTH;                                                 \
        if (__mpls_en__) {                                                                \
            (__s_vlan__) |= (1 << HAL_MT_L3_SVALN_LABEL_BITLENGTH);                       \
        }                                                                                 \
        (__c_vlan__) = (__mpls_label__) & HAL_MT_L3_VALN_BITMASK;                         \
    } while (0)

#define HAL_MT_NB_L3_GET_LBL_BY_VLAN(__mpls_en__, __mpls_label__, __s_vlan__, __c_vlan__) \
    do {                                                                                  \
        (__mpls_en__) = (((__s_vlan__) >> HAL_MT_L3_SVALN_LABEL_BITLENGTH) & 0x1);        \
        (__mpls_label__) = ((__s_vlan__ & ((1 << HAL_MT_L3_SVALN_LABEL_BITLENGTH) - 1))   \
                            << HAL_MT_L3_VALN_VID_BITLENGTH) |                            \
            (__c_vlan__ & HAL_MT_L3_VALN_BITMASK);                                        \
    } while (0)

/* Mcast */
#define HAL_MT_NB_L3_MCAST_HSH_PSR_TAGS(tags, inst_id, idx)              \
    do {                                                                 \
        (inst_id = ((tags >> HAL_MT_NB_L3_MCAST_FPU_KRN_OFFSET) &        \
                    ((1 << HAL_MT_NB_L3_MCAST_FPU_KRN_LEN) - 1)));       \
        (idx = (tags & ((1 << HAL_MT_NB_L3_MCAST_FPU_KRN_OFFSET) - 1))); \
    } while (0)

#define HAL_MT_NB_L3_MCAST_TRANS_1X_TO_2X(hw_addr_1x, hw_addr_2x)                                  \
    do {                                                                                           \
        hw_addr_2x = (hw_addr_1x & ((1 << TOB_MT_HASH_INDEX_LEN) - 1));                            \
        hw_addr_2x = (((hw_addr_1x) & (~((1 << TOB_MT_HASH_INDEX_LEN) - 1))) | (hw_addr_2x >> 1)); \
    } while (0)

/* ECMP */

/* Mcast */
#define HAL_MT_NB_L3_MAC_IS_BCAST(mac) ((mac[0] == 0xFFFFFFFF) && (mac[1] == 0xFFFF))

/* Cpu id and queue info */
#define HAL_MT_NB_L3_SET_CPU_ID(__cpu_id__, __cpu_id_queue__) \
    do {                                                      \
        (__cpu_id_queue__) &= 0x3F;                           \
        (__cpu_id_queue__) |= (((__cpu_id__) & 0x3) << 6);    \
    } while (0)

/* Cpu id and queue info */
#define HAL_MT_NB_L3_SET_CPU_QUEUE(__cpu_queue__, __cpu_id_queue__) \
    do {                                                            \
        (__cpu_id_queue__) &= 0xC0;                                 \
        (__cpu_id_queue__) |= ((__cpu_queue__) & 0x3F);             \
    } while (0)

#define HAL_L3_UI32_MSK(__bits__) (0xFFFFFFFF >> (32 - (__bits__)))
#define HAL_SCAN_HSH_GET_START_IDX(endidx, stageid, tileid) \
    (endidx = ((tileid & 0x7) << 15) | ((stageid & 0x3) << 18))

#define HAL_SCAN_HSH_GET_END_IDX(endidx, stageid, tileid) \
    (endidx = ((0x3FFF) | ((tileid & 0x7) << 15) | ((stageid & 0x3) << 18)))

#define HAL_SCAN_TCAM_GET_START_IDX(endidx, tcamid) (endidx = (tcamid * 1024))

#define HAL_SCAN_TCAM_GET_END_IDX(endidx, tcamid) (endidx = (((tcamid + 1) * 1024) - 1))
/*****************************************************************************
 * DATA TYPE DECLARATIONS
 *****************************************************************************
 */
typedef uint32 hal_mt_nb_l3_fast_cmd_hsh_entry_t[HAL_MT_L3_FAST_CMD_HSH_ENTRY_WORDS];
typedef uint32 hal_mt_nb_l3_fast_cmd_tcam_entry_t[HAL_MT_L3_FAST_CMD_TCAM_ENTRY_WORDS];
typedef uint32 hal_mt_nb_l3_tcam_scan_status_t[MT_NB_CDB_FPUTCAM_SLV_TCAM_SCAN_STATUS_WORDS];

typedef enum hal_mt_l3_rmac_type_e {
    HAL_MT_L3_RMAC_TYPE_NONE = 0,
    HAL_MT_L3_RMAC_TYPE_FLEX,
    HAL_MT_L3_RMAC_TYPE_FIXED,
    HAL_MT_L3_RMAC_TYPE_LAST
} hal_mt_l3_rmac_type_t;

typedef struct hal_mt_nb_l3_rmac_intf_s {
    hal_mt_l3_rmac_type_t type;
    uint32 intf_id;
    uint32 intf_mask;
} hal_mt_nb_l3_rmac_intf_t;

typedef struct hal_mt_nb_l3_cb_s {
    clx_semaphore_id_t sema;
    hal_mt_nb_l3_rmac_intf_t *idx2intf; /* Array of rmac index */
    uint32 *intf2idx;                   /* Array of l3 interface */
    uint32 cpu_id_queue;                /* cpu id and queue */
} hal_mt_nb_l3_cb_t;

/* MCAST */
typedef struct hal_mt_nb_l3_rpf_tcam_s {
    uint32 entry_idx;
    uint32 bdid;
    uint32 grp_mtree_id;
    uint32 grp_mtree_type;
} hal_mt_nb_l3_rpf_tcam_t;

/* MGI KEY LEN */
typedef enum {
    HAL_L3_MCAST_MGI_V4_KEY_TYPE = 0,   /* 0:v4 key         */
    HAL_L3_MCAST_MGI_MPLS_KEY_TYPE = 1, /* 1:mpls key       */
    HAL_L3_MCAST_MGI_V4_KEY_TYPE_LAST

} hal_l3_mcast_mgi_key_type_t;

typedef enum {
    HAL_L3_MCAST_RPFC_SINGLE_INTF_MODE = 0, /* single intf mode */
    HAL_L3_MCAST_RPFC_ECMP_MODE = 1,        /* ecmp mode */
    HAL_L3_MCAST_RPFC_PIM_BIDIR_MODE = 2,   /* bidir-pim mode */
    HAL_L3_MCAST_RPFC_MODE_TYPE_LAST
} hal_l3_mcast_rpfc_mode_type_t;

typedef enum {
    HAL_L3_RPFC_RP_TYPE = 0,   /* MTREE-ID */
    HAL_L3_RPFC_ECMP_TYPE = 1, /* ECMP-BASE */
    HAL_L3_RPFC_TYPE_LAST
} hal_l3_rpfc_type_t;

/* emdb_id and hash_id is calculate by grp_id and sn */
typedef struct hal_mt_nb_l3_mcast_mbr_s {
    struct {
        clx_l3_mcast_egr_intf_type_t intf_type; /* set when add member and used for get */
        uint32 port_id;                         /* ipmc group member port       */
        uint32 intf_id;                         /* ipmc group member interface  */
    } key;
    uint32 sn;                                  /* ipmc group member sn         */
    uint32 tbl;                                 /* tbl id                       */
    boolean is_fl;
    uint32 di;
    uint32 emdb_id;  /* ipmc group member emdb id    */
    uint32 mcdb_idx; /* ipmc group member mcdb idx   */
    uint32 emdb_idx; /* ipmc group member emdb idx   */
    uint32 mel_idx;  /* mel idx                      */
} hal_mt_nb_l3_mcast_mbr_t;

typedef struct hal_mt_nb_l3_mcast_grp_s {
    /* AVL key */
    uint32 mcast_id; /* ipmc group index         */

    /* AVL data */
    uint32 mbr_num;                                               /* ipmc group member count  */
    clx_port_bitmap_t port_bmp[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM]; /* ipmc group pbm */
    util_lib_avl_head_t *ptr_mbr_avl;                             /* ipmc group member avl tree */
    HAL_LAGID_BITMAP_T lag_bmp;                                   /* ipmc group lagid bitmap  */
} hal_mt_nb_l3_mcast_grp_t;

typedef struct hal_mt_nb_l3_mcast_mel_key_s {
    uint32 bd_id;
    uint32 tnl_bd;
    uint32 tnl_idx;
    uint32 mpls_ctl;
    uint32 swap_en;
    uint32 swap_lbl;
} hal_mt_nb_l3_mcast_mel_key_t;

typedef struct hal_mt_nb_l3_mcast_mel_node_s {
    /* AVL key */
    hal_mt_nb_l3_mcast_mel_key_t key;

    /* AVL data */
    uint32 cud_idx; /* resource index   */
    uint32 use_num; /* reference count  */
} hal_mt_nb_l3_mcast_mel_node_t;

typedef struct hal_mt_nb_l3_mcast_cb_s {
    /* RPF */
    uint32 rp_id_bmp[CLX_BITMAP_SIZE(HAL_L3_RPF_NUM)];
    util_lib_avl_head_t *ptr_rpa_avl;

    /* Usage */
    uint32 hash_1x_cnt;
    uint32 hash_2x_cnt;
    uint32 sg_tcam_cnt;

    /* Count */
    uint32 ipv4_xg_cnt;
    uint32 ipv4_sg_cnt;
    uint32 ipv6_xg_cnt;
    uint32 ipv6_sg_cnt;

    clx_semaphore_id_t sema;
    clx_semaphore_id_t df_sema;

    /* Swdb */
    util_lib_avl_head_t *ptr_grp_avl; /* save group and member        */
    util_lib_avl_head_t *ptr_sg_avl;  /* save (s,g) entry             */
    util_lib_avl_head_t *ptr_s_g_avl; /* save src or grp reference    */
    util_lib_avl_head_t *ptr_mel_avl; /* save mc intf cud             */

    /* Tile BMP */
    hal_swc_hsh_tile_bmp_t mgi_tile_bmp;
    hal_swc_hsh_tile_bmp_t msgi_tile_bmp;
    hal_swc_hsh_tile_bmp_t rpfc_tile_bmp;

    hal_mt_nb_l3_rpf_tcam_t rpfc_tcam_info[HAL_L3_RPF_TCAM_MAX_NUM];

} hal_mt_nb_l3_mcast_cb_t;

/* sw mcast ip node */
typedef struct hal_mt_nb_l3_mcast_sg_node_s {
    /* AVL key */
    uint32 ipv4;
    uint32 vrf_id;

    union {
        uint32 hw_ipv4;
        uint32 hw_ipv6[4];
    } grp_addr;

    union {
        uint32 hw_ipv4;
        uint32 hw_ipv6[4];
    } src_addr;

    /* AVL data */
    uint32 insert_tcam; /* sg hw addr info */
    uint32 hw_idx;

    uint32 da_tag; /* sg hw search key */
    uint32 da_tcam_hit;
    uint32 sa_tag;
    uint32 sa_tcam_hit;
    uint32 sa_afib_hit;

} hal_mt_nb_l3_mcast_sg_node_t;

/* sw mcast ip node */
typedef struct hal_mt_nb_l3_mcast_s_g_node_s {
    /* AVL key */
    uint32 ipv4;
    uint32 vrf_id;

    union {
        uint32 hw_ipv4;
        uint32 hw_ipv6[4];
    } ip_addr;

    uint32 tag; /* hw info */
    uint32 tcam_hit;
    uint32 afib_hit;

    /* reference info */
    uint32 src_add_by_mcast; /* used by src */
    uint32 src_used_num;     /* used by src */
    uint32 sg_only;          /* used by xg */
    uint32 xg_used_num;      /* used by xg */

} hal_mt_nb_l3_mcast_s_g_node_t;

typedef struct hal_mt_nb_l3_mcast_route_rsrc_s {
    uint32 ipv4;
    uint32 tbl_id;                   /* table ID           */
    hal_swc_hsh_tile_bmp_t bank_bmp; /* bank bitmap        */
    union {
        uint32 ipv4_xg_buf[MT_NB_CDB_FPU_HSH_MGI_V4_WORDS];
        uint32 ipv6_xg_buf[MT_NB_CDB_FPU_HSH_MGI_V6_WORDS];
        uint32 ip_sg_buf[MT_NB_CDB_FPU_HSH_MSGI_WORDS];
    } buf;
    char ip_str[UTIL_IP_ADDR_STR_SIZE];

    /* user data */
    uint32 grp_hit;
    uint32 mcast_id;
    uint32 mcast_en;
    uint32 mc_drop;
    uint32 c2c_en;
    uint32 pim_sm_spt_rdy;
    uint32 keep_ttl;
    uint32 bd_mode;
    uint32 l3_intf_id;
    uint32 mrpf_fail_act;
    uint32 sg_only;
    uint32 sa_dc;

    /* hw info */
    uint32 valid; /* only for sg */
    uint32 da_tag;
    uint32 da_tcam_hit;
    uint32 sa_tag;
    uint32 sa_tcam_hit;
    uint32 sa_afib_hit;

    uint32 insert_tcam; /* sg hw addr info */
    uint32 hw_idx;

} hal_mt_nb_l3_mcast_route_rsrc_t;

typedef struct hal_mt_nb_l3_mcast_mel_info_s {
    uint32 bd_id;
    uint32 decr_ttl;
    uint32 src_supp_ck_vid;
    uint32 src_supp_tag;
    uint32 nvo3_adj_idx;
    uint32 nvo3_encap_idx;
    uint32 seg_vmid;
    uint32 mpls_ctl;
    uint32 swap_lbl;
    uint32 da_mod;
    uint32 sa_mod;
    clx_mac_t dmac;
    HAL_VLAN_VID_CTL_T vid_info;

} hal_mt_nb_l3_mcast_mel_info_t;

/* ROUTE */
typedef struct hal_mt_nb_l3_fib_rsrc_s {
    /* HW data */
    uint32 is_default;
    uint32 fwd_ptr;
    uint32 sa_dc;
    uint32 decr_ttl;
    uint32 acl_lbl;

    /* User data */
    clx_nhp_t nhp;       /* Host|Route nhp               */
    uint32 subnet_bc_id; /* SubnetBcast                  */
    uint32 subnet_bc_en; /* SubnetBcast                  */
    uint32 mpls_lbl;     /* Host|Route                   */
    uint32 mpls_en;      /* Host|Route                   */
    uint32 uc_drop;      /* Host|Route                   */

} hal_mt_nb_l3_fib_rsrc_t;

typedef struct hal_mt_nb_l3_route_rsrc_s {
    uint32 tbl_id;                    /* ILE table ID             */
    uint32 bank_bmp;                  /* ILE bank bitmap [HASH]   */
    uint32 free_exm;                  /* ILE free EXM id [HASH]   */
    uint32 flw_lbl;                   /* IEV_INDIR result         */
    uint32 iev_idx;                   /* IEV index (getFcoe)      */
    hal_mt_nb_l3_fib_rsrc_t fib_rsrc; /* FIB result               */
    union {
        uint32 ipv4_tcam_1x_buf[HAL_MT_NB_L3_TCAM_IND_NORMAL_BUF_WORDS];
        uint32 ipv6_tcam_2x_buf[HAL_MT_NB_L3_TCAM_IND_NORMAL_BUF_WORDS];
        uint32 ipv6_tcam_4x_buf[HAL_MT_NB_L3_TCAM_IND_LONG_BUF_WORDS];
    } buf;
    union {
        uint32 fib_ptr_buf[MT_NB_CDB_FPU_RSLT_FIB_WORDS];
        uint32 afib_ptr_buf[MT_NB_CDB_FPU_RSLT_AFIB_PTR_WORDS];
        uint32 mgi_buf[MT_NB_CDB_FPU_RSLT_MGI_WORDS];
    } rslt_buf;
    char ip_str[UTIL_IP_NETWORK_STR_SIZE];

    /* e.g.
     * ip=192.168.0.4/31, root-ip=192.168.0.0/29 (buf)
     * found root ile_idx=8192, iev_indir_idx=327680, trie_bmp=0x111, iev_idx=81920 (read from ADJ)
     *
     * - vrf_vld            is 1      (calculated from flag)
     * - msk_btot           is 3      (calculated from prefix)
     * - real_prefix        is 31
     * - root_prefix        is 29
     * - root_key           is 15
     *
     * - trie_bit           is 5      (0 or calculated from trie-bmp)
     * - rslt_shift         is 1      (0 or calculated from trie-bmp)
     *
     * - root_vld           is 1
     * - root_d_fpu_idx     is 8192   (read from AVL)
     * - root_s_fpu_idx     is 12288  (read from AVL)
     * - root_rslt_idx      is 327680 (read from HW)
     * - root_rslt_cnt      is 3      (read from HW)
     * - real_vld           is 1
     */
    uint32 is_1x;            /* FPU is_1x                                */
    uint32 vrf_vld;          /* FPU vrf_vld                              */
    uint32 vrf_id;           /* FPU vrf_id                               */
    uint32 option_exist_vld; /* option_exist_vld                         */
    uint32 option_exist;     /* option_exist                             */
    uint32 msk_btot;         /* FPU msk_btot                             */
    uint32 real_prefix;
    uint32 root_prefix;
    uint32 root_key;       /* calculated block key [TCAM]              */

    uint32 trie_bit;       /* based on root IP                         */
    uint32 rslt_shift;     /* based on IEV_INDIR index                 */

    uint32 root_vld;       /* root IP exists in HW                     */
    uint32 root_d_fpu_idx; /* root FPU DIP 1x      (only for root_vld) */
    uint32 root_s_fpu_idx; /* root FPU SIP 1x      (only for root_vld) */
    uint32 root_rslt_idx;  /* root indir index (only for root_vld) */
    uint32 root_rslt_cnt;  /* root indir count (only for root_vld) */
    uint32 real_vld;       /* real IP exists in HW                     */

} hal_mt_nb_l3_route_rsrc_t;

/* Add For Bulk Route */
typedef struct hal_mt_nb_l3_route_ext_rsrc_s {
    hal_mt_nb_l3_route_rsrc_t route_rsrc;
    uint32 route_id; /* ip add order */
    uint32 attrbmp;
    uint32 root_ip[HAL_L3_ROUTE_ROOT_WORD_NUM];
    uint32 root_mask[HAL_L3_ROUTE_ROOT_WORD_NUM];
} hal_mt_nb_l3_route_ext_rsrc_t;

typedef struct hal_mt_nb_l3_route_trav_cookie_s {
    uint32 unit;

    /* [In] for traverseRoute() API, directly callback */
    uint32 tbl_id;
    util_lib_list_t *ptr_list;
    uint32 cnt;

    uint32 is_dip;
    uint32 entry_num;
    uint32 old_idx;
    uint32 new_idx;

} hal_mt_nb_l3_route_trav_cookie_t;

/* Add for get l3 actual route count */
typedef struct hal_mt_nb_l3_route_num_s {
    uint32 ipv4_num;
    uint32 ipv6_num;
    /*  uint32                  ipv6_short_num; */
    /*  uint32                  ipv6_long_num;  */
    /*  uint32                  def_global_num; */
} hal_mt_nb_l3_route_num_t;

/* HOST */
typedef struct hal_mt_nb_l3_host_rsrc_s {
    uint32 ipv4;
    uint32 hash_tbl;                 /* FPU hsh table ID       */
    uint32 tcam_tbl;                 /* FPU tcam table ID      */
    uint32 rslt_tbl;                 /* FPU rslt table ID      */
    hal_swc_hsh_tile_bmp_t bank_bmp; /* FPU hsh bank bitmap    */
    uint32 is_tcam;                  /* FPU tcam bank bitmap   */
    uint32 grp_lbl;                  /* FPU in-band CIA result */
    uint32 decr_ttl;                 /* FPU decr_ttl           */
    uint32 sa_dc;                    /* FPU sa_dc              */
    uint32 fwd_ptr;                  /* FPU fwd_ptr            */
    union {
        uint32 ipv4_buf[MT_NB_CDB_FPU_HSH_L3_V4_WORDS];
        uint32 ipv6_buf[MT_NB_CDB_FPU_HSH_L3_V6_WORDS];
    } buf;
    union {
        uint32 ipv4_buf[MT_NB_CDB_FPU_TCAM_FIB_V4_WORDS];
        uint32 ipv6_buf[MT_NB_CDB_FPU_TCAM_FIB_V6_4X_WORDS];
    } tcam_buf;
    union {
        uint32 ip_buf[MT_NB_CDB_FPU_RSLT_FIB_WORDS];
    } rslt_buf;
    uint32 d_ile_idx;   /* TCAM DIP IDX         */
    uint32 s_ile_idx;   /* TCAM SIP IDX         */
    uint32 phy_fpu_idx; /* HASH IDX             */
    char ip_str[UTIL_IP_ADDR_STR_SIZE];

    /* hitbit */
    uint32 sip_hit;
    /* swdb */
    uint32 vrf_id;
    clx_nhp_t nhp;
    uint32 subnet_bc_id;
    uint32 mpls_lbl;
    uint32 mpls_en;
    uint32 uc_drop;
} hal_mt_nb_l3_host_rsrc_t;

/* ADJ */
typedef struct hal_mt_nb_l3_adj_cb_s {
    util_lib_avl_head_t *ptr_avl; /* util_lib_avl_insert(hal_l3_adj_node_t) when addAdj()
                                   * util_lib_avl_delete(hal_l3_adj_node_t) when delAdj()
                                   * util_lib_list_insert_to_tail(uint32) when addGrpList() of ECMP
                                   * and FRR util_lib_list_node_delete_by_data(uint32) when
                                   * delGrpList() of ECMP and FRR
                                   */
    clx_semaphore_id_t sema;

    uint32 *ptr_adj_alloc_bmp;
    uint32 adj_max_count;
    hal_swc_hsh_tile_bmp_t adj_arp_bmp;
    hal_swc_hsh_tile_bmp_t adj_rpfc_bmp;
    hal_mt_nb_l3_rpf_tcam_t rpfc_tcam_info[HAL_L3_RPF_TCAM_MAX_NUM];

} hal_mt_nb_l3_adj_cb_t;

typedef struct hal_mt_l3_ecmp_node_s {
    /* AVL key */
    uint32 grp_type; /* ecmp group type     */
    uint32 grp_idx;  /* ecmp group idx     */

    /* AVL data */
    boolean algo_ctrl;
    clx_l3_ecmp_algo_mode_t algo_mode; /* ecmp group mode     */
    uint32 grp_tbl;
    uint32 path_tbl;
    uint32 hal_sel;
    uint32 act_cnt;
    uint32 org_cnt;
    uint32 path_cnt;
    uint32 weight_vld; /* only update weight_cnt when this field is 1 */
    uint32 use_num;    /* reference count of host, route, fdl */
    uint32 real_size;  /* real hash buckets for fine grain ECMP */
    uint32 order_mode; /* order ecmp */
    uint32 fine_grain; /* fine grain ecmp */
    uint32 flex_mode;  /* flex ecmp */
} hal_mt_l3_ecmp_node_t;

typedef struct hal_mt_l3_ecmp_grp_s {
    uint32 grp_id; /* ecmp group index    */
    uint32 grp_tbl;
    uint32 path_tbl;
    boolean algo_ctrl;
    clx_l3_ecmp_algo_mode_t algo_mode; /* ecmp group mode     */
    clx_nhp_type_t grp_type;           /* ecmp group type     */
    uint32 hal_sel;                    /* flag for hal sel    */
    uint32 act_cnt;
    uint32 org_cnt;
    uint32 path_cnt;
    uint32 weight_vld; /* only update weight_cnt when this field is 1 */
    uint32 use_num;    /* reference count of host, route */
    uint32 real_size;  /* real hash buckets for fine grain ECMP */
    uint32 order_mode; /* order ecmp */
    uint32 fine_grain; /* fine grain ecmp */
    uint32 flex_mode;  /* flex ecmp */
} hal_mt_l3_ecmp_grp_t;

typedef struct hal_mt_l3_ecmp_path_s {
    /* group */
    hal_mt_l3_ecmp_grp_t ecmp_info; /* SWDB info */
    uint32 grp_tbl_id;              /* ECMP_U */
    union {
        uint32 adj_buf[MT_NB_FPU_RSLT_ECMP_GRP_LAST_FIELD_ID];
        uint32 nvo3_buf[MT_NB_FWR_RSLT_TNL_ECMP_GRP_LAST_FIELD_ID];
        uint32 l2_buf[MT_NB_FPU_RSLT_L2_ECMP_GRP_LAST_FIELD_ID];
        uint32 mpls_buf[MT_NB_ICIA_RSLT_PBR_GRP_LAST_FIELD_ID];
    } grp_buf;

    /* [add/del] path from user
     * [get] path from hw
     */
    uint32 path_weight; /* weight or 1 */
    uint32 path_tbl_id; /* ECMP_PATH_U */
    union {
        uint32 adj_buf[MT_NB_FPU_RSLT_ECMP_MBR_LAST_FIELD_ID];
        uint32 nvo3_buf[MT_NB_FWR_RSLT_TNL_ECMP_MBR_LAST_FIELD_ID];
        uint32 l2_buf[MT_NB_FPU_RSLT_L2_ECMP_MBR_LAST_KEY_ID];
        uint32 mpls_buf[MT_NB_ICIA_RSLT_PBR_MPATH_LAST_FIELD_ID];
    } path_buf;

    /* [add/del] state from user
     * [get] state from hw
     */
    uint32 fwd_ptr;
    uint32 dst_idx;
    uint32 tnl_bd;
    uint32 state;

    uint32 mpls_ctl;
    uint32 mpls_lbl;

    /* metas from HW act */
    uint32 act_offset; /* path offset */
    uint32 act_weight; /* path count for hw, or sw_spray count for sw */
    uint32 act_vld;
    uint32 *act_list;  /* path list */

    /* metas from HW orig */
    uint32 orig_offset;   /* path offset */
    uint32 orig_weight;   /* path count */
    uint32 orig_vld;      /* this path may be out of orig, but in act */
    uint32 *org_list;     /* path list */
    uint32 reserved_path; /* path is reserved */

} hal_mt_l3_ecmp_path_t;

/* Warmboot */
typedef enum {
    HAL_MT_L3_WBDB_INTF_IEV_L2UC_DROP_IDX = 0, /* iev_l2uc_drop_idx     */
    HAL_MT_L3_WBDB_INTF_INTF2FDID,             /* ptr_intf2fdid         */
    HAL_MT_L3_WBDB_INTF_FDID2INTF,             /* ptr_fdid2intf         */
    HAL_MT_L3_WBDB_INTF_INTF2VRF,              /* ptr_intf2vrf          */
    HAL_MT_L3_WBDB_INTF_LAST

} hal_mt_l3_wbdb_intf_t;

typedef enum {
    HAL_MT_L3_WBDB_VRF_IPV4_STATE_BMP = 0, /* ptr_ipv4_state_bmp    */
    HAL_MT_L3_WBDB_VRF_IPV6_STATE_BMP,     /* ptr_ipv4_state_bmp    */
    HAL_MT_L3_WBDB_VRF_LAST

} hal_mt_l3_wbdb_vrf_t;

typedef enum {
    HAL_MT_L3_WBDB_ADJ_AVL = 0,        /* ptr_avl               */
    HAL_MT_L3_WBDB_ADJ_ALLOC_BMP,      /* alloc idx bmp         */
    HAL_MT_L3_WBDB_ADJ_MAX_NUM,        /* total adj idx         */
    HAL_MT_L3_WBDB_ADJ_ARP_BANK_BMP,   /* arp bank bmp          */
    HAL_MT_L3_WBDB_ADJ_RPFC_BANK_BMP,  /* rpfc bank bmp         */
    HAL_MT_L3_WBDB_ADJ_RPFC_TCAM_INFO, /* rpfc_tcam_info        */
    HAL_MT_L3_WBDB_ADJ_LAST

} hal_mt_l3_wbdb_adj_t;

typedef enum {
    HAL_MT_L3_WBDB_ECMP_AVL = 0,               /* ptr_avl               */
    HAL_MT_L3_WBDB_ECMP_SW_ECMP_PATH_BLOCK_SZ, /* sw_ecmp_path_block_sz */
    HAL_MT_L3_WBDB_ECMP_ALGO_MODE,             /* algo_mode            */
    HAL_MT_L3_WBDB_ECMP_RESILIENT_EN,          /* resilient_en          */
    HAL_MT_L3_WBDB_ECMP_GRP_NUM,               /* ecmp grp num          */
    HAL_MT_L3_WBDB_ECMP_PATH_NUM,              /* add path num          */
    HAL_MT_L3_WBDB_ECMP_ALLOC_PATH_NUM,        /* alloc path num        */
    HAL_MT_L3_WBDB_ECMP_LAST

} hal_mt_l3_wbdb_ecmp_t;

typedef enum {
    HAL_MT_L3_WBDB_HOST_IPV4_HASH_1X_CNT = 0, /* ipv4_hash_1x_cnt   */
    HAL_MT_L3_WBDB_HOST_IPV6_HASH_2X_CNT,     /* ipv6_hash_2x_cnt   */
    HAL_MT_L3_WBDB_HOST_IPV4_TCAM_1X_CNT,     /* ipv4_tcam_1x_cnt   */
    HAL_MT_L3_WBDB_HOST_IPV6_TCAM_4X_CNT,     /* ipv6_tcam_4x_cnt   */
    HAL_MT_L3_WBDB_HOST_HASH_V4_CNT,          /* per tile ipv4_hash_1x_cnt   */
    HAL_MT_L3_WBDB_HOST_HASH_V6_CNT,          /* per tile ipv6_hash_2x_cnt   */
    HAL_MT_L3_WBDB_HOST_TCAM_V4_CNT,          /* per bank ipv4_tcam_1x_cnt   */
    HAL_MT_L3_WBDB_HOST_TCAM_V6_CNT,          /* per bankipv6_tcam_4x_cnt   */
    HAL_MT_L3_WBDB_HOST_TCAM_SIP_EN,          /* host_tcam_sip_en   */
    HAL_MT_L3_WBDB_HOST_AVL,                  /* host_avl           */
    HAL_MT_L3_WBDB_HOST_LAST

} hal_mt_l3_wbdb_host_t;

typedef enum {
    HAL_MT_L3_WBDB_ROUTE_TCAM_SIP_EN = 0,         /* tcam_sip_en           */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_2X_CNT,        /* tcam_bank_2x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_4X_CNT,        /* tcam_bank_4x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK,               /* tcam_bank             */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_1X,           /* tcam_block_1x         */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_2X,           /* tcam_block_2x         */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BLOCK_4X,           /* tcam_block_4x         */
    HAL_MT_L3_WBDB_ROUTE_IPV4_TCAM_1X_CNT,        /* ipv4_tcam_1x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_TCAM_2X_CNT,        /* ipv6_tcam_2x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_TCAM_4X_CNT,        /* ipv6_tcam_4x_cnt      */
    HAL_MT_L3_WBDB_ROUTE_USED_V4_CNT,             /* used_v4_cnt           */
    HAL_MT_L3_WBDB_ROUTE_USED_V6_CNT,             /* used_v6_cnt           */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_GLB_CNT,       /* tcam_bank_glb_cnt     */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_ENTRY_CNT,     /* tcam_bank_entry_cnt   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_GLB_ENTRY_CNT, /* tcam_bank_entry_cnt   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BMP,                /* tcam_route_bmp        */
    HAL_MT_L3_WBDB_ROUTE_HASH_BMP,                /* hash_route_bmp        */
    HAL_MT_L3_WBDB_ROUTE_ACL_LABEL_EN,            /* acl_label_en          */
    HAL_MT_L3_WBDB_ROUTE_BULK_EN,                 /* bulk_route_en         */
    HAL_MT_L3_WBDB_ROUTE_FLUSH_EN,                /* bulk_flush_en         */
    HAL_MT_L3_WBDB_ROUTE_V6_RSRC_MAXIMIZE,        /* v6_rsrc_maxmize       */
    HAL_MT_L3_WBDB_ROUTE_IPV4_1X_ROOT_NUM,        /* ipv4_1x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_2X_ROOT_NUM,        /* ipv6_2x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_IPV6_4X_ROOT_NUM,        /* ipv6_4x_root_num      */
    HAL_MT_L3_WBDB_ROUTE_AFIB_ENABLE,             /* lpm afib enable       */
    HAL_MT_L3_WBDB_ROUTE_BULK_V4_AVL,             /* lpm bulk avl swdb     */
    HAL_MT_L3_WBDB_ROUTE_BULK_V6_AVL,             /* lpm bulk avl swdb     */
    HAL_MT_L3_WBDB_ROUTE_DROP_FPU_IDX,            /* fpu drop adj hw addr  */
    HAL_MT_L3_WBDB_ROUTE_PRE_ALLOC_EN,            /* lpm pre alloc enabel  */
    HAL_MT_L3_WBDB_ROUTE_COVER_CHECK_EN,          /* lpm cover check enabel*/
    HAL_MT_L3_WBDB_ROUTE_V4_ALLOC_NUM,            /* lpm v4 alloc count    */
    HAL_MT_L3_WBDB_ROUTE_V6_ALLOC_NUM,            /* lpm v4 alloc count    */
    HAL_MT_L3_WBDB_ROUTE_V4_TRIE,                 /* lpm v4 trie           */
    HAL_MT_L3_WBDB_ROUTE_V6_TRIE,                 /* lpm v6 trie           */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_DA_4X,     /* tcam_bank_bmp_da_4x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_SA_4X,     /* tcam_bank_bmp_sa_4x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_DA_2X,     /* tcam_bank_bmp_da_2x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_SA_2X,     /* tcam_bank_bmp_sa_2x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_DA_4X_GLB, /* tcam_bank_bmp_da_4x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_SA_4X_GLB, /* tcam_bank_bmp_sa_4x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_DA_2X_GLB, /* tcam_bank_bmp_da_2x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_BANK_BMP_SA_2X_GLB, /* tcam_bank_bmp_sa_2x   */
    HAL_MT_L3_WBDB_ROUTE_TCAM_4X_RSVD,            /* tcam_4x_rsvd          */
    HAL_MT_L3_WBDB_ROUTE_LAST

} hal_mt_l3_wbdb_route_t;

typedef enum {
    HAL_MT_L3_WBDB_MCAST_RP_ID_BMP = 0,    /* rp_id_bmp             */
    HAL_MT_L3_WBDB_MCAST_MGI_BANK_BMP,     /* mgi_bank_bmp          */
    HAL_MT_L3_WBDB_MCAST_MSGI_BANK_BMP,    /* mgi_bank_bmp          */
    HAL_MT_L3_WBDB_MCAST_RPFC_BANK_BMP,    /* rpfc_bank_bmp         */
    HAL_MT_L3_WBDB_MCAST_RPA_AVL,          /* ptr_rpa_avl           */
    HAL_MT_L3_WBDB_MCAST_GRP_AVL,          /* ptr_grp_avl           */
    HAL_MT_L3_WBDB_MCAST_SG_AVL,           /* ptr_sg_node_avl       */
    HAL_MT_L3_WBDB_MCAST_S_G_AVL,          /* ptr_s_or_g_node_avl   */
    HAL_MT_L3_WBDB_MCAST_MEL_AVL,          /* ptr_intf_node_avl     */
    HAL_MT_L3_WBDB_MCAST_IPV4_HASH_1X_CNT, /* ipv4_hash_1x_cnt      */
    HAL_MT_L3_WBDB_MCAST_IPV6_HASH_2X_CNT, /* ipv6_hash_2x_cnt      */
    HAL_MT_L3_WBDB_MCAST_SG_TCAM_CNT,      /* sg_hash_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV4_XG_CNT,      /* ipv4_xg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV6_XG_CNT,      /* ipv6_xg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV4_SG_CNT,      /* ipv4_sg_cnt           */
    HAL_MT_L3_WBDB_MCAST_IPV6_SG_CNT,      /* ipv6_sg_cnt           */
    HAL_MT_L3_WBDB_MCAST_RPFC_TCAM_INFO,   /* rpfc_tcam_info        */
    HAL_MT_L3_WBDB_MCAST_LAST

} hal_mt_l3_wbdb_mcast_t;

typedef enum {
    HAL_MT_L3_WBDB_RMAC_IDX_INTF = 0, /* rmac idx to inff         */
    HAL_MT_L3_WBDB_RMAC_INTF_IDX,     /* intf to rmac             */
    HAL_MT_L3_WBDB_CPU_DI,            /* cpu di                   */
    HAL_MT_L3_WBDB_RMAC_LAST

} hal_mt_l3_wbdb_rmac_t;

#define HAL_MT_L3_WBDB_INTF_BASE  (0)
#define HAL_MT_L3_WBDB_VRF_BASE   (HAL_MT_L3_WBDB_INTF_BASE + HAL_MT_L3_WBDB_INTF_LAST)
#define HAL_MT_L3_WBDB_ADJ_BASE   (HAL_MT_L3_WBDB_VRF_BASE + HAL_MT_L3_WBDB_VRF_LAST)
#define HAL_MT_L3_WBDB_ECMP_BASE  (HAL_MT_L3_WBDB_ADJ_BASE + HAL_MT_L3_WBDB_ADJ_LAST)
#define HAL_MT_L3_WBDB_HOST_BASE  (HAL_MT_L3_WBDB_ECMP_BASE + HAL_MT_L3_WBDB_ECMP_LAST)
#define HAL_MT_L3_WBDB_ROUTE_BASE (HAL_MT_L3_WBDB_HOST_BASE + HAL_MT_L3_WBDB_HOST_LAST)
#define HAL_MT_L3_WBDB_MCAST_BASE (HAL_MT_L3_WBDB_ROUTE_BASE + HAL_MT_L3_WBDB_ROUTE_LAST)
#define HAL_MT_L3_WBDB_RMAC_BASE  (HAL_MT_L3_WBDB_MCAST_BASE + HAL_MT_L3_WBDB_MCAST_LAST)
#define HAL_MT_L3_WBDB_NUM        (HAL_MT_L3_WBDB_RMAC_BASE + HAL_MT_L3_WBDB_RMAC_LAST)
/*****************************************************************************
 * LOCAL SUBPROGRAM BODIES
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- MAIN */
/* Resource */
clx_error_no_t
hal_mt_nb_l3_capacity_get(const uint32 unit,
                          const clx_swc_rsrc_t type,
                          const uint32 param,
                          uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_l3_usage_get(const uint32 unit,
                       const clx_swc_rsrc_t type,
                       const uint32 param,
                       uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_dst_idx_get(const uint32 unit, const clx_port_t port, uint32 *ptr_ueid_mgid);

clx_error_no_t
hal_mt_nb_l3_fwd_get(const uint32 unit,
                     const clx_nhp_t nhp,
                     const uint32 subnet_bc_id,
                     uint32 *ptr_fwd_ptr);

clx_error_no_t
hal_mt_nb_l3_fwd_free(const uint32 unit,
                      const clx_nhp_t nhp,
                      const uint32 subnet_bc_id,
                      const uint32 fwd_ptr);

clx_error_no_t
hal_mt_nb_l3_nhp_get(const uint32 unit,
                     const uint32 hw_addr,
                     clx_nhp_t *ptr_nhp,
                     uint32 *ptr_subnet_bc_id);

/* RPFC */
void
hal_mt_nb_l3_urpf_hash_trans(const uint32 unit,
                             const hal_l3_rpfc_type_t type,
                             const uint32 ecmp_grp_id,
                             const uint32 intf_id,
                             uint32 *ptr_buf);

void
hal_mt_nb_l3_urpf_tcam_trans(const uint32 unit,
                             const hal_l3_rpfc_type_t type,
                             const boolean vld,
                             const uint32 ecmp_grp_id,
                             const uint32 intf_id,
                             uint32 *ptr_buf);

/* Init and Deinit */
clx_error_no_t
hal_mt_nb_l3_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_l3_deinit(const uint32 unit);

clx_error_no_t
hal_mt_nb_l3_tbl_dma_move(const uint32 unit,
                          const uint32 tbl_id,
                          const boolean delete_offset,
                          const uint32 offset,
                          const uint32 base_old,
                          const uint32 num_old,
                          const uint32 base_new);

clx_error_no_t
hal_mt_nb_l3_emi_hsh_vlan_add(const uint32 unit,
                              const uint32 lcl_intf,
                              const uint32 bdi,
                              const uint32 s_vlan,
                              const uint32 c_vlan);

clx_error_no_t
hal_mt_nb_l3_mpls_lbl_add(const uint32 unit,
                          const clx_nhp_t nhp,
                          const uint32 mpls_en,
                          const uint32 label);

clx_error_no_t
hal_mt_nb_l3_mpls_lbl_read(const uint32 unit, const clx_nhp_t nhp, uint32 *mpls_en, uint32 *label);

clx_error_no_t
hal_mt_nb_l3_mpls_lbl_del(const uint32 unit, const clx_nhp_t nhp);

/* Dump SWDB */
clx_error_no_t
hal_mt_nb_l3_swdb_dump(const uint32 unit, const uint32 flags);

/* Properties */
clx_error_no_t
hal_mt_nb_l3_reference_update(const uint32 unit, const clx_nhp_t nhp, const boolean inc);

clx_error_no_t
hal_mt_nb_l3_urpf_check_set(const uint32 unit, const uint32 is_enable);

clx_error_no_t
hal_mt_nb_l3_urpf_check_get(const uint32 unit, uint32 *ptr_is_enable);

clx_error_no_t
hal_mt_nb_l3_icmp_redirect_set(const uint32 unit, const uint32 is_enable);

clx_error_no_t
hal_mt_nb_l3_icmp_redirect_get(const uint32 unit, uint32 *ptr_is_enable);

clx_error_no_t
hal_mt_nb_l3_validate_ip_set(const uint32 unit, const uint32 enable, const uint32 fail_act);

clx_error_no_t
hal_mt_nb_l3_validate_ip_get(const uint32 unit, uint32 *ptr_enable, uint32 *ptr_fail_act);

clx_error_no_t
hal_mt_nb_l3_excpt_act_set(const uint32 unit,
                           const clx_swc_cfg_t property,
                           const clx_fwd_action_t action);
/**
 * @brief Get L3 exceptions.
 *
 * Apply to the following reason:
 * - CLX_PKT_RX_REASON_IPV4_MC_LKP_MISS
 * - CLX_PKT_RX_REASON_IPV6_MC_LKP_MISS
 * - CLX_PKT_RX_REASON_IPV4_HDR_OPTION
 * - CLX_PKT_RX_REASON_IPV6_HOP_BY_HOP_EXT_HDR
 * - CLX_PKT_RX_REASON_IGR_L3_MTU_FAIL
 * - CLX_PKT_RX_REASON_EGR_L3_MTU_FAIL
 * - CLX_PKT_RX_REASON_IP_TTL_0
 * - CLX_PKT_RX_REASON_IP_TTL_1.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     property      - Property type.
 * @param [out]    ptr_action    - Action.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_l3_excpt_act_get(const uint32 unit,
                           const clx_swc_cfg_t property,
                           clx_fwd_action_t *ptr_action);
/**
 * @brief Set L3 Header error actions.
 *
 * Apply to the following reason:
 * - CLX_SWC_CFG_IPV4_VER_ERR
 * - CLX_SWC_CFG_IPV4_CHKSM_ERR
 * - CLX_SWC_CFG_IPV4_OPT
 * - CLX_SWC_CFG_IPV6_VER_ERR
 * CLX8600 not support len err.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    property    - Property type.
 * @param [in]    action      - Action.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_l3_hdr_err_act_set(const uint32 unit,
                             const clx_swc_cfg_t property,
                             const clx_fwd_action_t action);
/**
 * @brief Get L3 Header error actions.
 *
 * Apply to the following reason:
 * - CLX_SWC_CFG_IPV4_VER_ERR
 * - CLX_SWC_CFG_IPV4_CHKSM_ERR
 * - CLX_SWC_CFG_IPV4_OPT
 * - CLX_SWC_CFG_IPV4_LEN_ERR
 * CLX8600 not support len err.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     property      - Property type.
 * @param [out]    ptr_action    - Action.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_l3_hdr_err_act_get(const uint32 unit,
                             const clx_swc_cfg_t property,
                             clx_fwd_action_t *ptr_action);

/* ----------------------------------------------------------------------------------- RMAC  */
clx_error_no_t
hal_mt_nb_l3_rmac_idx_get(const uint32 unit, const uint32 intf, uint32 *ptr_index);
clx_error_no_t
hal_mt_nb_l3_rmac_idx_set(const uint32 unit, const uint32 intf_id, const uint32 rmac_idx);
clx_error_no_t
hal_mt_nb_l3_rmac_add(const uint32 unit, const clx_l3_rmac_t *ptr_rmac);
clx_error_no_t
hal_mt_nb_l3_rmac_del(const uint32 unit, const uint32 index);
clx_error_no_t
hal_mt_nb_l3_rmac_get(const uint32 unit, clx_l3_rmac_t *ptr_rmac);

clx_error_no_t
hal_mt_nb_l3_rmac_trav(const uint32 unit, const clx_l3_rmac_trav_func_t callback, void *ptr_cookie);
/* ----------------------------------------------------------------------------------- INTF */
clx_error_no_t
hal_mt_nb_l3_intf_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_intf_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_intf_rsrc_get(const uint32 unit,
                           const uint32 intf_id,
                           hal_l3_intf_rsrc_t *ptr_intf_rsrc);

clx_error_no_t
hal_mt_nb_l3_intf_id_get(const uint32 unit, const clx_bridge_domain_t bdid, uint32 *ptr_intf_id);

clx_error_no_t
hal_mt_nb_l3_intf_fdid_get(const uint32 unit, const uint32 intf_id, clx_bridge_domain_t *ptr_bdid);

clx_error_no_t
hal_mt_nb_l3_intf_set(const uint32 unit, clx_l3_intf_t *ptr_l3_intf);

clx_error_no_t
hal_mt_nb_l3_intf_cb_get(const uint32 unit, hal_l3_intf_cb_t **ptr_intf_cb);

/* CLX API */
clx_error_no_t
hal_mt_nb_l3_intf_add(const uint32 unit, clx_l3_intf_t *ptr_l3_intf);

clx_error_no_t
hal_mt_nb_l3_intf_del(const uint32 unit, const uint32 intf_id);

clx_error_no_t
hal_mt_nb_l3_intf_get(const uint32 unit, clx_l3_intf_t *ptr_l3_intf);

clx_error_no_t
hal_mt_nb_l3_intf_trav(const uint32 unit, const clx_l3_intf_trav_func_t callback, void *ptr_cookie);

clx_error_no_t
hal_mt_nb_l3_intf_rmac_set(const uint32 unit, const uint32 intf_id, const uint32 rmac_idx);

clx_error_no_t
hal_mt_nb_l3_intf_usage_get(const uint32 unit, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_intf_swdb_dump(const uint32 unit);

/* ----------------------------------------------------------------------------------- VRF */
clx_error_no_t
hal_mt_nb_l3_vrf_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_vrf_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_vrf_cb_get(const uint32 unit, hal_l3_vrf_cb_t **ptr_vrf_cb);

/* CLX API */
clx_error_no_t
hal_mt_nb_l3_vrf_set(const uint32 unit, const clx_l3_vrf_t *ptr_vrf);

clx_error_no_t
hal_mt_nb_l3_vrf_get(const uint32 unit, clx_l3_vrf_t *ptr_vrf);

clx_error_no_t
hal_mt_nb_l3_vrf_swdb_dump(const uint32 unit);

/* ----------------------------------------------------------------------------------- ADJ */
clx_error_no_t
hal_mt_nb_l3_adj_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_adj_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_adj_info_get(const uint32 unit, const uint32 adj_id, hal_l3_adj_info_t *ptr_adj_info);

clx_error_no_t
hal_mt_nb_l3_adj_reference_update(const uint32 unit, const uint32 adj_id, const boolean inc);

/* handle URPF */
clx_error_no_t
hal_mt_nb_l3_adj_ecmp_urpf_add(/* for addEcmpPath */
                               const uint32 unit,
                               const uint32 ecmp_grp_id,
                               const uint32 intf_id);

clx_error_no_t
hal_mt_nb_l3_adj_ecmp_urpf_del(/* for delEcmp, delEcmpPath */
                               const uint32 unit,
                               const uint32 ecmp_grp_id,
                               const uint32 intf_id);

clx_error_no_t
hal_mt_nb_l3_adj_ecmp_urpf_update(/* for setIntf, delIntf */
                                  const uint32 unit,
                                  const uint32 is_add,
                                  const uint32 bdid);

clx_error_no_t
hal_mt_nb_l3_adj_ecmp_refer_add(/* for addEcmpPath */
                                const uint32 unit,
                                const uint32 ecmp_grp_id,
                                const uint32 adj_id);

clx_error_no_t
hal_mt_nb_l3_adj_ecmp_refer_del(/* for delEcmp, delEcmpPath */
                                const uint32 unit,
                                const uint32 ecmp_grp_id,
                                const uint32 adj_id);

/* set Cpu di */
clx_error_no_t
hal_mt_nb_l3_adj_cpu_di_update(const uint32 unit, const uint32 cpu_di);

/* CLX API */
clx_error_no_t
hal_mt_nb_l3_adj_add(const uint32 unit, clx_l3_adj_t *ptr_adj_info);

clx_error_no_t
hal_mt_nb_l3_adj_del(const uint32 unit, const uint32 adj_id);

clx_error_no_t
hal_mt_nb_l3_adj_get(const uint32 unit, clx_l3_adj_t *ptr_adj_info);

clx_error_no_t
hal_mt_nb_l3_adj_trav(const uint32 unit,
                      const clx_l3_adj_type_t adj_type,
                      const clx_l3_adj_trav_func_t callback,
                      void *ptr_cookie);

clx_error_no_t
hal_mt_nb_l3_adj_usage_get(const uint32 unit, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_adj_swdb_dump(const uint32 unit);

clx_error_no_t
hal_mt_nb_l3_adj_fpu_get(const uint32 unit, const uint32 adj_id, uint32 *ptr_fwd_ptr);

clx_error_no_t
hal_mt_nb_l3_adj_nhp_fpu_get(const uint32 unit, const uint32 adj_id, uint32 *ptr_hw_addr);

clx_error_no_t
hal_mt_nb_l3_adj_id_get_by_fpu(const uint32 unit, const uint32 fwr_ptr, uint32 *ptr_adj_idx);

clx_error_no_t
hal_mt_nb_l3_adj_capacity_get(const uint32 unit, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_adj_usage_get(const uint32 unit, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_adj_sub_bc_fdb_add(const uint32 unit, const uint32 subnet_bc_id, uint32 *ptr_hw_idx);
clx_error_no_t
hal_mt_nb_l3_adj_mpls_valid_set(const uint32 unit, const uint32 adj_id, const uint32 valid);

clx_error_no_t
hal_mt_nb_l3_adj_sub_bc_fdb_del(const uint32 unit, const uint32 hw_idx);
/* ----------------------------------------------------------------------------------- ECMP */
clx_error_no_t
hal_mt_nb_l3_ecmp_resilient_set(const uint32 unit, const uint32 is_enable);

clx_error_no_t
hal_mt_nb_l3_ecmp_resilient_get(const uint32 unit, uint32 *is_enable);

clx_error_no_t
hal_mt_nb_l3_ecmp_algomode_set(const uint32 unit, const clx_l3_ecmp_algo_mode_t mode);

clx_error_no_t
hal_mt_nb_l3_ecmp_algomode_get(const uint32 unit, clx_l3_ecmp_algo_mode_t *mode);

clx_error_no_t
hal_mt_nb_l3_ecmp_hsh_eng_algomode_set(const uint32 unit, const clx_swc_hsh_algo_t mode);

clx_error_no_t
hal_mt_nb_l3_ecmp_hsh_eng_algomode_get(const uint32 unit, clx_swc_hsh_algo_t *mode);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_max_path_set(const uint32 unit, const uint32 num);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_max_path_get(const uint32 unit, uint32 *num);

clx_error_no_t
hal_mt_nb_l3_ecmp_per_grp_capacity_get(const uint32 unit, uint32 *num);

clx_error_no_t
hal_mt_nb_l3_mcast_lcl_set(const uint32 unit,
                           const clx_swc_cfg_t type,
                           const uint32 addr,
                           const uint32 mask);
clx_error_no_t
hal_mt_nb_l3_mcast_lcl_get(const uint32 unit, const clx_swc_cfg_t type, uint32 *addr, uint32 *mask);

clx_error_no_t
hal_mt_nb_l3_ecmp_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_ecmp_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_info_get(const uint32 unit,
                               const uint32 ecmp_grp_id,
                               hal_mt_l3_ecmp_grp_t *ptr_ecmp_info);

clx_error_no_t
hal_mt_nb_l3_ecmp_ref_update(const uint32 unit, const uint32 ecmp_grp_id, const boolean inc);

clx_error_no_t
hal_mt_nb_l3_ecmp_pathidx_get_by_grpadj(const uint32 unit,
                                        const uint32 ecmp_grp_id,
                                        const uint32 adj_id,
                                        uint32 *ptr_act_list,
                                        uint32 *ptr_act_cnt,
                                        uint32 *ptr_orig_list,
                                        uint32 *ptr_orig_cnt);

/* CLX API */
clx_error_no_t
hal_mt_nb_l3_ecmp_grp_acl_bind(const uint32 unit,
                               const uint32 old_ecmp_id,
                               uint32 *new_ecmp_id,
                               const boolean need_alloc);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_acl_unbind(const uint32 unit,
                                 const uint32 old_ecmp_id,
                                 const uint32 new_ecmp_id,
                                 const boolean need_free);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_add(const uint32 unit, clx_l3_ecmp_grp_t *ptr_ecmp);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_del(const uint32 unit, const uint32 ecmp_id);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_get(const uint32 unit, clx_l3_ecmp_grp_t *ptr_ecmp);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_trav(const uint32 unit,
                           const clx_nhp_type_t type,
                           const clx_l3_ecmp_grp_trav_func_t cb,
                           void *ptr_cookie);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_sync(const uint32 unit, const uint32 ori_ecmp_id, const uint32 cur_ecmp_id);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_add(const uint32 unit, const clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_del(const uint32 unit, const clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_get_by_idx(const uint32 unit,
                                  const uint32 path_idx,
                                  clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_hsh_set(const uint32 unit, const clx_l3_ecmp_path_hsh_t *ptr_hsh_set);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_hsh_get(const uint32 unit, clx_l3_ecmp_path_hsh_t *ptr_hsh_get);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_list_set(const uint32 unit,
                                const boolean is_org,
                                const uint32 idx,
                                const clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_list_get(const uint32 unit,
                                const boolean is_org,
                                const uint32 idx,
                                clx_l3_ecmp_path_t *ptr_path);

clx_error_no_t
hal_mt_nb_l3_ecmp_all_path_list_get(const uint32 unit, clx_l3_ecmp_all_path_t *allPatchInfo);

clx_error_no_t
hal_mt_nb_l3_ecmp_hw_to_fwd_trans(const uint32 unit, const uint32 ecmp_grp_id, uint32 *ptr_fwd_ptr);

clx_error_no_t
hal_mt_nb_l3_ecmp_hwidx_from_fwd(const uint32 unit, const uint32 ptr_fwd_ptr, uint32 *ecmp_grp_id);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_ecmp_grp_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_l3_ecmp_swdb_dump(const uint32 unit);

#if defined(CLX_HSH_LIB)
clx_error_no_t
hal_mt_nb_l3_ecmp_path_hsh_calc(const uint32 unit,
                                const clx_swc_hsh_pkt_type_t hash_type,
                                const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                const uint32 ecmp_grp_id,
                                clx_l3_ecmp_path_hsh_rslt_t *ptr_rslt);
#endif

clx_error_no_t
hal_mt_nb_l3_ecmp_l2_path_dump(const uint32 unit, const clx_port_t ecmp_port);

clx_error_no_t
hal_mt_nb_l3_ecmp_path_list_dump(const uint32 unit, const uint32 ecmp_grp_id);

/* Internal API */
/* Create Group */
clx_error_no_t
hal_mt_nb_l3_ecmp_l2_grp_add(const uint32 unit,
                             clx_l2_ecmp_grp_t *ptr_ecmp,
                             clx_port_t *ptr_ecmp_port);

/* Del Group */
clx_error_no_t
hal_mt_nb_l3_ecmp_l2_grp_del(const uint32 unit, const clx_port_t ecmp_port);

/* Get Group */
clx_error_no_t
hal_mt_nb_l3_ecmp_l2_grp_get(const uint32 unit,
                             const clx_port_t ecmp_port,
                             clx_l2_ecmp_grp_t *ptr_ecmp);

/* Add path */
clx_error_no_t
hal_mt_nb_l3_ecmp_l2_path_add(const uint32 unit,
                              const clx_port_t ecmp_port,
                              const clx_l2_ecmp_path_t *ptr_ecmp_path);

/* Del path */
clx_error_no_t
hal_mt_nb_l3_ecmp_l2_path_del(const uint32 unit,
                              const clx_port_t ecmp_port,
                              const clx_l2_ecmp_path_t *ptr_ecmp_path);

/* Get path by idx */
clx_error_no_t
hal_mt_nb_l3_ecmp_l2_path_get(const uint32 unit,
                              const clx_port_t ecmp_port,
                              const uint32 path_idx,
                              clx_l2_ecmp_path_t *ptr_path);

/* Set grp hsh */
clx_error_no_t
hal_mt_nb_l3_ecmp_l2_path_hsh_set(const uint32 unit, const clx_l3_ecmp_path_hsh_t *ptr_hsh_set);

/* Get grp hsh */
clx_error_no_t
hal_mt_nb_l3_ecmp_l2_path_hsh_get(const uint32 unit, clx_l3_ecmp_path_hsh_t *ptr_hsh_get);

/* set l3 cpu di */
clx_error_no_t
hal_mt_nb_l3_cpu_di_set(const uint32 unit, const uint32 cpu_id, const uint32 cpu_queue);
/* ----------------------------------------------------------------------------------- HOST */

clx_error_no_t
hal_mt_nb_l3_host_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_host_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_host_idx_get(const uint32 unit,
                          const clx_l3_host_t *ptr_host,
                          uint32 *is_tcam,
                          uint32 *ptr_host_idx);

/* CLX API */
clx_error_no_t
hal_mt_nb_l3_host_add(const uint32 unit, const clx_l3_host_t *ptr_host);

clx_error_no_t
hal_mt_nb_l3_host_del(const uint32 unit, const clx_l3_addr_t *ptr_host_addr);

clx_error_no_t
hal_mt_nb_l3_host_get(const uint32 unit, clx_l3_host_t *ptr_host);

clx_error_no_t
hal_mt_nb_l3_host_trav(const uint32 unit, const clx_l3_host_trav_func_t callback, void *ptr_cookie);

clx_error_no_t
hal_mt_nb_l3_host_subnet_bcast_add(const uint32 unit, const clx_l3_subnet_bcast_t *ptr_subnet_info);

clx_error_no_t
hal_mt_nb_l3_host_subnet_bcast_del(const uint32 unit, const clx_l3_addr_t *ptr_subnet_addr);

clx_error_no_t
hal_mt_nb_l3_host_subnet_bcast_get(const uint32 unit, clx_l3_subnet_bcast_t *ptr_subnet_info);

clx_error_no_t
hal_mt_nb_l3_host_subnet_bcast_trav(const uint32 unit,
                                    const clx_l3_bcast_trav_func_t cb,
                                    void *ptr_cookie);

clx_error_no_t
hal_mt_nb_l3_host_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_l3_host_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_host_swdb_dump(const uint32 unit);
/* ----------------------------------------------------------------------------------- ROUTE */
clx_error_no_t
hal_mt_nb_l3_route_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_route_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

/* CLX API */
clx_error_no_t
hal_mt_nb_l3_route_add(const uint32 unit, const clx_l3_route_t *ptr_route);

clx_error_no_t
hal_mt_nb_l3_route_del(const uint32 unit, const clx_l3_addr_t *ptr_route_addr);

clx_error_no_t
hal_mt_nb_l3_route_get(const uint32 unit, clx_l3_route_t *ptr_route);

clx_error_no_t
hal_mt_nb_l3_route_trav(const uint32 unit, const clx_l3_route_trav_func_t cb, void *ptr_cookie);

clx_error_no_t
hal_mt_nb_l3_route_bulk_route_add(const uint32 unit,
                                  const clx_bulk_op_mode_t mode,
                                  clx_l3_bulk_route_t *ptr_bulk_route);

clx_error_no_t
hal_mt_nb_l3_route_bulk_route_del(const uint32 unit,
                                  const clx_bulk_op_mode_t mode,
                                  clx_l3_bulk_route_t *ptr_bulk_route);

clx_error_no_t
hal_mt_nb_l3_route_bulk_route_get(const uint32 unit, clx_l3_route_t *ptr_route);

clx_error_no_t
hal_mt_nb_l3_route_bulk_route_dump(const uint32 unit,
                                   const uint32 count_only,
                                   const uint32 ip_type_v4);

clx_error_no_t
hal_mt_nb_l3_route_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_l3_route_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_route_swdb_dump(const uint32 unit);

/* ----------------------------------------------------------------------------------- MCAST */
clx_error_no_t
hal_mt_nb_l3_mcast_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_l3_mcast_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

/* MEL for VEPA */
clx_error_no_t
hal_mt_nb_l3_mcast_all_mbr_del(const uint32 unit, const uint32 mcast_id);

/* CLX API */
clx_error_no_t
hal_mt_nb_l3_mcast_grp_create(const uint32 unit, const uint32 flags, uint32 *ptr_mcast_id);

clx_error_no_t
hal_mt_nb_l3_mcast_grp_destroy(const uint32 unit, const uint32 mcast_id);

clx_error_no_t
hal_mt_nb_l3_mcast_port_bmp_get(const uint32 unit,
                                const uint32 mcast_id,
                                clx_port_bitmap_t port_bitmap);

clx_error_no_t
hal_mt_nb_l3_mcast_egr_intf_add(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

clx_error_no_t
hal_mt_nb_l3_mcast_egr_intf_del(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

clx_error_no_t
hal_mt_nb_l3_mcast_egr_intf_set(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

clx_error_no_t
hal_mt_nb_l3_mcast_egr_intf_get(const uint32 unit,
                                const uint32 mcast_id,
                                const clx_port_t port_id,
                                uint32 *ptr_cnt,
                                clx_l3_mcast_egr_intf_t *ptr_intf);

clx_error_no_t
hal_mt_nb_l3_mcast_egr_intf_cnt_get(const uint32 unit,
                                    const uint32 mcast_id,
                                    const uint32 port_id,
                                    uint32 *ptr_intf_cnt);

clx_error_no_t
hal_mt_nb_l3_mcast_route_add(const uint32 unit, const clx_l3_mcast_route_t *ptr_group_info);

clx_error_no_t
hal_mt_nb_l3_mcast_route_del(const uint32 unit, const clx_l3_mcast_addr_t *ptr_mcast_addr);

clx_error_no_t
hal_mt_nb_l3_mcast_route_get(const uint32 unit, clx_l3_mcast_route_t *ptr_group_info);

clx_error_no_t
hal_mt_nb_l3_mcast_route_trav(const uint32 unit,
                              const clx_l3_mcast_route_trav_func_t callback,
                              void *ptr_cookie);

clx_error_no_t
hal_mt_nb_l3_mcast_df_intf_add(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_df_intf);

clx_error_no_t
hal_mt_nb_l3_mcast_df_intf_del(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_df_intf);

clx_error_no_t
hal_mt_nb_l3_mcast_df_intf_get(const uint32 unit, clx_l3_mcast_df_intf_t *ptr_df_intf);

clx_error_no_t
hal_mt_nb_l3_mcast_swdb_dump(const uint32 unit);

clx_error_no_t
hal_mt_nb_l3_mcast_capacity_get(const uint32 unit, const uint32 param, uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_l3_mcast_usage_get(const uint32 unit, const uint32 param, uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l3_mcast_sw_entry_oper(const uint32 unit,
                                 const hal_cmn_action_t type,
                                 hal_mt_nb_l3_mcast_s_g_node_t *ptr_node_info);

clx_error_no_t
hal_mt_nb_l3_mcast_lag_bmp_get(const uint32 unit,
                               const uint32 mcast_id,
                               HAL_LAGID_BITMAP_T lagid_bitmap);
/* ----------------------------------------------------------------------------------- FRR */
clx_error_no_t
hal_mt_nb_l3_frr_create(const uint32 unit, clx_l3_frr_t *ptr_frr);

clx_error_no_t
hal_mt_nb_l3_frr_destroy(const uint32 unit, const uint32 frr_id);

clx_error_no_t
hal_mt_nb_l3_frr_path_add(const uint32 unit, const clx_l3_frr_path_t *ptr_path);

clx_error_no_t
hal_mt_nb_l3_frr_path_del(const uint32 unit, const clx_l3_frr_path_t *ptr_path);

clx_error_no_t
hal_mt_nb_l3_frr_state_set(const uint32 unit, const uint32 frr_id, const boolean state);

clx_error_no_t
hal_mt_nb_l3_frr_state_get(const uint32 unit, const uint32 frr_id, boolean *ptr_state);

clx_error_no_t
hal_mt_nb_l3_frr_get(const uint32 unit, const uint32 frr_id, hal_l3_frr_t *ptr_frr);

clx_error_no_t
hal_mt_nb_l3_hsh_startendix_get(const uint32 unit,
                                const clx_swc_hsh_tile_type_t hsh_type,
                                uint32 *hsh_slc0_start_idx,
                                uint32 *hsh_slc0_end_idx,
                                uint32 *hsh_slc1_start_idx,
                                uint32 *hsh_slc1_end_idx);

clx_error_no_t
hal_mt_nb_l3_tcam_startendix_get(const uint32 unit,
                                 const clx_swc_tcam_type_t tcam_type,
                                 uint32 *tcam_slc0_start_idx,
                                 uint32 *tcam_slc0_end_idx,
                                 uint32 *tcam_slc1_start_idx,
                                 uint32 *tcam_slc1_end_idx);

clx_error_no_t
hal_mt_nb_l3_hsh_scan_engine_write(const uint32 unit,
                                   const hal_mt_nb_l3_fast_cmd_hsh_entry_t fast_find_hsh_bit_entry,
                                   const hal_mt_nb_l3_fast_cmd_hsh_entry_t fast_find_hsh_mask_entry);

clx_error_no_t
hal_mt_nb_l3_tcam_scan_engine_write(
    const uint32 unit,
    const hal_mt_nb_l3_fast_cmd_tcam_entry_t fast_find_tcam_bit_entry,
    const hal_mt_nb_l3_fast_cmd_tcam_entry_t fast_find_tcam_mask_entry);

clx_error_no_t
hal_mt_nb_l3_scan_engine_action_set(const uint32 unit,
                                    const clx_swc_hsh_tile_type_t type,
                                    const uint32 param0);

clx_error_no_t
hal_mt_nb_l3_hsh_scan_engine_range_set(const uint32 unit,
                                       const uint32 slc0_start_idx,
                                       const uint32 slc0_end_idx,
                                       const uint32 slc1_start_idx,
                                       const uint32 slc1_end_idx);

clx_error_no_t
hal_mt_nb_l3_tcam_scan_engine_range_set(const uint32 unit,
                                        const uint32 slc0_start_idx,
                                        const uint32 slc0_end_idx,
                                        const uint32 slc1_start_idx,
                                        const uint32 slc1_end_idx);

clx_error_no_t
hal_mt_nb_l3_hsh_scan_engine_trigger(const uint32 unit);

clx_error_no_t
hal_mt_nb_l3_tcam_scan_engine_trigger(const uint32 unit);

clx_error_no_t
hal_mt_nb_l3_host_flush(const uint32 unit, const clx_l3_host_t *ptr_host);

#endif /* End of HAL_L3_H */
