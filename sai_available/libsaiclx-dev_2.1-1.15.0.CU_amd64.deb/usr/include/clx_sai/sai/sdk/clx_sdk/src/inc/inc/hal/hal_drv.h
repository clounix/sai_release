/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_drv.h
 * PURPOSE:
 *  Provide HAL driver structure and driver help APIs.
 *
 * NOTES:
 */

#ifndef HAL_DRV_H
#define HAL_DRV_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <clx/clx_bd.h>
#include <clx/clx_vlan.h>
#include <clx/clx_netif.h>
#include <clx/clx_pkt.h>
#include <clx/clx_cia.h>
#include <clx/clx_sec.h>
#include <clx/clx_l2.h>
#include <clx/clx_stp.h>
#include <clx/clx_lag.h>
#include <clx/clx_mir.h>
#include <clx/clx_l3.h>
#include <clx/clx_tnl.h>
#include <clx/clx_srv6.h>
#include <clx/clx_qos.h>
#include <clx/clx_swc.h>
#include <clx/clx_meter.h>
#include <clx/clx_stat.h>
#include <clx/clx_mpls.h>
#include <clx/clx_tm.h>
#include <clx/clx_init.h>
#include <clx/clx_stk.h>
#include <clx/clx_telm.h>
#include <clx/clx_ecc.h>
#include <clx/clx_ecpu.h>
#include <clx/clx_bfd.h>
#include <clx/clx_ptp.h>
#include <drv/drv.h>
#include <hal/hal_intr.h>
#include <hal/hal_ecc.h>
#include <hal/hal_tbl.h>
#include <hal/hal_const.h>
#include <hal/hal_cmn_drv.h>
#include <hal/hal_pkt_rsrc.h>
#include <hal/hal_dflt.h>
#include <hal/hal_pkj.h>
#include <hal/hal_mac.h>
#include <hal/hal_phy.h>
#include <hal/hal_ecpu_ringbuffer.h>
#include <hal/hal_ecpu.h>
#include <hal/mt/ecpu/hal_mt_ecpu_bfd.h>
#include <hal/mt/ecpu/hal_mt_ecpu_ptp.h>
/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MAX_NUM_OF_PLANE   (8)
#define HAL_RIM_SW_TBL_BASE_ID (1U << 31)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef clx_error_no_t (*HAL_CHIP_MMIO_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_CHIP_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_CHIP_DEINIT_FUNC_T)(const uint32 unit);

/* bd multiplexing functions */

typedef clx_error_no_t (*HAL_BD_INIT)(const uint32 unit);

typedef clx_error_no_t (*HAL_BD_DEINIT)(const uint32 unit);

typedef clx_error_no_t (*HAL_BD_CREATE)(const uint32 unit, const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*HAL_BD_DESTROY)(const uint32 unit, const clx_bridge_domain_t bdid);
typedef clx_error_no_t (*HAL_BD_CFG_SET)(const uint32 unit,
                                         const clx_bridge_domain_t bdid,
                                         const clx_bd_cfg_t *ptr_bd_cfg);

typedef clx_error_no_t (*HAL_BD_CFG_GET)(const uint32 unit,
                                         const clx_bridge_domain_t bdid,
                                         clx_bd_cfg_t *ptr_bd_cfg);

typedef clx_error_no_t (*HAL_BD_CREATED_PRINT)(const uint32 unit);

typedef clx_error_no_t (*HAL_BD_CAPACITY_GET)(const uint32 unit,
                                              const clx_swc_rsrc_t type,
                                              const uint32 param,
                                              uint32 *ptr_size);

typedef clx_error_no_t (*HAL_BD_USAGE_GET)(const uint32 unit,
                                           const clx_swc_rsrc_t type,
                                           const uint32 param,
                                           uint32 *ptr_cnt);

/* vlan multiplexing functions */

typedef clx_error_no_t (*HAL_VLAN_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_VLAN_DEINIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_VLAN_CREATE_FUNC_T)(const uint32 unit, const uint32 vid);

typedef clx_error_no_t (*HAL_VLAN_DESTROY_FUNC_T)(const uint32 unit, const uint32 vid);

typedef clx_error_no_t (*HAL_VLAN_IGR_HSH_PRINT_FUNC_T)(const uint32 unit,
                                                        const uint32 lcl_intf,
                                                        const clx_vlan_t s_vlan,
                                                        const clx_vlan_t c_vlan);

typedef clx_error_no_t (*HAL_VLAN_EGR_HSH_PRINT_FUNC_T)(const uint32 unit,
                                                        const uint32 lcl_intf,
                                                        const clx_bridge_domain_t bdi);

typedef clx_error_no_t (*HAL_VLAN_TRAV_FUNC_T)(const uint32 unit,
                                               const CLX_VLAN_TRAV_FUNC_T callback,
                                               void *ptr_cookie);

typedef clx_error_no_t (*HAL_VLAN_BD_BIND_FUNC_T)(const uint32 unit,
                                                  const clx_vlan_t vid,
                                                  const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*HAL_VLAN_BD_UNBIND_FUNC_T)(const uint32 unit,
                                                    const clx_vlan_t vid,
                                                    const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*HAL_VLAN_BD_GET_FUNC_T)(const uint32 unit,
                                                 const clx_vlan_t vid,
                                                 clx_bridge_domain_t *bdid);

typedef clx_error_no_t (*HAL_VLAN_PORT_GET_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   clx_port_bitmap_t port_bmp,
                                                   clx_port_bitmap_t ut_port_bmp);
typedef clx_error_no_t (*HAL_VLAN_TYPE_SET_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   const clx_vlan_type_t type);

typedef clx_error_no_t (*HAL_VLAN_TYPE_GET_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   clx_vlan_type_t *type);

typedef clx_error_no_t (*HAL_VLAN_PRIVATE_TPORT_ADD)(const uint32 unit,
                                                     const clx_vlan_t vid,
                                                     const clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*HAL_VLAN_PRIVATE_TPORT_DEL)(const uint32 unit,
                                                     const clx_vlan_t vid,
                                                     const clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*HAL_VLAN_PRIVATE_TPORT_GET)(const uint32 unit,
                                                     const clx_vlan_t vid,
                                                     clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*hal_chip_cfg_info_get_func_t)(const uint32 unit,
                                                       const clx_swc_chip_cfg_info_type_t type,
                                                       const uint32 para0,
                                                       const uint32 para1,
                                                       uint32 *ptr_value);

typedef clx_error_no_t (*HAL_VLAN_PORT_ADD_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   const clx_port_bitmap_t port_bmp,
                                                   const clx_port_bitmap_t ut_port_bmp);

typedef clx_error_no_t (*HAL_VLAN_PORT_DEL_FUNC_T)(const uint32 unit,
                                                   const clx_vlan_t vid,
                                                   const clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*HAL_VLAN_TAG_MODE_SET_FUNC_T)(const uint32 unit,
                                                       const clx_vlan_t vid,
                                                       const clx_port_bitmap_t port_bmp,
                                                       const clx_vlan_tag_mode_t mode);

typedef clx_error_no_t (*HAL_VLAN_EXT_TPID_ADD_FUNC_T)(const uint32 unit,
                                                       const clx_vlan_ext_tpid_type_t type,
                                                       const clx_vlan_ext_tpid_grp_t tpid_grp);

typedef clx_error_no_t (*HAL_VLAN_EXT_TPID_DEL_FUNC_T)(const uint32 unit,
                                                       const clx_vlan_ext_tpid_type_t type,
                                                       const clx_vlan_ext_tpid_grp_t tpid_grp);

typedef clx_error_no_t (*HAL_VLAN_EXT_TPID_GET_FUNC_T)(const uint32 unit,
                                                       const clx_vlan_ext_tpid_type_t type,
                                                       clx_vlan_ext_tpid_grp_t tpid_grp);

/* Port multiplexing functions */
typedef clx_error_no_t (*hal_port_cfg_set_func_t)(const uint32 unit,
                                                  const uint32 port,
                                                  const clx_port_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_port_cfg_get_func_t)(const uint32 unit,
                                                  const uint32 port,
                                                  clx_port_cfg_t *ptr_config);

typedef clx_error_no_t (*HAL_PORT_SETSPEED_FUNC_T)(const uint32 unit,
                                                   const uint32 port,
                                                   const clx_port_speed_t speed);

typedef clx_error_no_t (*HAL_PORT_GETSPEED_FUNC_T)(const uint32 unit,
                                                   const uint32 port,
                                                   clx_port_speed_t *ptr_speed);

typedef clx_error_no_t (*HAL_PORT_GETSPEEDLIST_FUNC_T)(const uint32 unit,
                                                       const uint32 port,
                                                       const uint32 max_len,
                                                       clx_port_speed_t *ptr_speed_list);

typedef clx_error_no_t (*HAL_PORT_SETFLOWCTRL_FUNC_T)(const uint32 unit,
                                                      const uint32 port,
                                                      const clx_port_fc_dir_t fc);

typedef clx_error_no_t (*HAL_PORT_GETFLOWCTRL_FUNC_T)(const uint32 unit,
                                                      const uint32 port,
                                                      clx_port_fc_dir_t *ptr_fc);

typedef clx_error_no_t (*HAL_PORT_SETPRIFLOWCTRL_FUNC_T)(const uint32 unit,
                                                         const uint32 port,
                                                         const uint8 pri,
                                                         const clx_port_fc_dir_t pfc);

typedef clx_error_no_t (*HAL_PORT_GETPRIFLOWCTRL_FUNC_T)(const uint32 unit,
                                                         const uint32 port,
                                                         const uint8 pri,
                                                         clx_port_fc_dir_t *ptr_pfc);

typedef clx_error_no_t (*HAL_PORT_SETEEEMODE_FUNC_T)(const uint32 unit,
                                                     const uint32 port,
                                                     const CLX_PORT_EEE_MODE_T mode);

typedef clx_error_no_t (*HAL_PORT_GETEEEMODE_FUNC_T)(const uint32 unit,
                                                     const uint32 port,
                                                     CLX_PORT_EEE_MODE_T *ptr_mode);

typedef clx_error_no_t (*HAL_PORT_SETLOCALADVABILITY_FUNC_T)(const uint32 unit,
                                                             const uint32 port,
                                                             const clx_port_ability_t *ptr_ability);

typedef clx_error_no_t (*HAL_PORT_GETLOCALADVABILITY_FUNC_T)(const uint32 unit,
                                                             const uint32 port,
                                                             clx_port_ability_t *ptr_ability);

typedef clx_error_no_t (*HAL_PORT_GETREMOTEADVABILITY_FUNC_T)(const uint32 unit,
                                                              const uint32 port,
                                                              clx_port_ability_t *ptr_ability);

typedef clx_error_no_t (*HAL_PORT_GETABILITY_FUNC_T)(const uint32 unit,
                                                     const uint32 port,
                                                     clx_port_ability_t *ptr_ability);

typedef clx_error_no_t (*HAL_PORT_SETLOOPBACK)(const uint32 unit,
                                               const uint32 port,
                                               const clx_port_loopback_t lbtype);

typedef clx_error_no_t (*HAL_PORT_GETLOOPBACK)(const uint32 unit,
                                               const uint32 port,
                                               clx_port_loopback_t *ptr_lbtype);

typedef clx_error_no_t (*HAL_PORT_PROBE)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*HAL_PORT_INITPORT)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*HAL_PORT_DEINITPORT)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*HAL_PORT_SETMACADDR)(const uint32 unit,
                                              const uint32 port,
                                              const clx_mac_t mac);

typedef clx_error_no_t (*HAL_PORT_GETMACADDR)(const uint32 unit,
                                              const uint32 port,
                                              clx_mac_t *ptr_mac);

typedef clx_error_no_t (*HAL_PORT_GETLINK)(const uint32 unit, const uint32 port, uint32 *ptr_link);

typedef clx_error_no_t (*HAL_PORT_GETFAULT)(const uint32 unit,
                                            const uint32 port,
                                            uint32 *ptr_fault);

typedef clx_error_no_t (*HAL_PORT_GETTEMPERATURE)(const uint32 unit,
                                                  const uint32 port,
                                                  int32 *ptr_temp);

typedef clx_error_no_t (*HAL_PORT_SETMEDIUCLYPE)(const uint32 unit,
                                                 const uint32 port,
                                                 const clx_port_medium_t medium);

typedef clx_error_no_t (*HAL_PORT_GETMEDIUCLYPE)(const uint32 unit,
                                                 const uint32 port,
                                                 clx_port_medium_t *ptr_medium);

typedef clx_error_no_t (*HAL_PORT_SETPHYPROPERTY)(const uint32 unit,
                                                  const uint32 port,
                                                  const clx_port_phy_cfg_t *ptr_config);

typedef clx_error_no_t (*HAL_PORT_GETPHYPROPERTY)(const uint32 unit,
                                                  const uint32 port,
                                                  clx_port_phy_cfg_t *ptr_config);

typedef clx_error_no_t (*HAL_MT_PORT_VLAN_BD_BIND)(const uint32 unit,
                                                   const clx_port_t port,
                                                   const uint32 svid,
                                                   const uint32 cvid,
                                                   const clx_bridge_domain_t bdid);

typedef clx_error_no_t (*HAL_MT_PORT_VLAN_BD_UNBIND)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const uint32 svid,
                                                     const uint32 cvid,
                                                     const clx_bridge_domain_t bdid);
typedef clx_error_no_t (*HAL_MT_PORT_VLAN_BD_GET)(const uint32 unit,
                                                  const clx_port_t port,
                                                  const uint32 svid,
                                                  const uint32 cvid,
                                                  clx_bridge_domain_t *ptr_bdid);

typedef clx_error_no_t (*HAL_PORT_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_PORT_DEINIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_PORT_SETLANEMAP)(const uint32 unit,
                                              const uint32 port,
                                              const clx_port_lane_map_info_t *ptr_lane_map);

typedef clx_error_no_t (*HAL_PORT_GETLANEMAP)(const uint32 unit,
                                              const uint32 port,
                                              clx_port_lane_map_info_t *ptr_lane_map);

typedef clx_error_no_t (*HAL_PORT_GPORT_CREATE)(const uint32 unit,
                                                const uint32 port,
                                                clx_port_t *ptr_intf);

typedef clx_error_no_t (*HAL_PORT_GPORT_DESTROY)(const uint32 unit, clx_port_t intf);

typedef clx_error_no_t (*HAL_PORT_SETINTFPROPERTY)(const uint32 unit,
                                                   const clx_port_t intf,
                                                   const clx_port_intf_cfg_t *ptr_property);

typedef clx_error_no_t (*HAL_PORT_GETINTFPROPERTY)(const uint32 unit,
                                                   const clx_port_t intf,
                                                   clx_port_intf_cfg_t *ptr_property);

typedef clx_error_no_t (*HAL_PORT_GETTSTXENTRY)(const uint32 unit,
                                                const uint32 port,
                                                clx_port_ts_entry_t *ptr_ts_entry);

typedef clx_error_no_t (*HAL_PORT_GETTSRXENTRY)(const uint32 unit,
                                                const uint32 port,
                                                clx_port_ts_entry_t *ptr_ts_entry);

typedef clx_error_no_t (*HAL_PORT_GETPORTTYPE)(const uint32 unit,
                                               const clx_port_t port,
                                               clx_gport_type_t *ptr_type);

typedef clx_error_no_t (*HAL_PORT_GETSTATUS)(const uint32 unit,
                                             const clx_port_t port,
                                             clx_port_status_t *ptr_status);

typedef clx_error_no_t (*HAL_PORT_PORT_TO_GPORT_TRANS)(const uint32 unit,
                                                       const uint32 port,
                                                       clx_port_t *ptr_port);

typedef clx_error_no_t (*HAL_PORT_GPORT_TO_PORT_TRANS)(const uint32 unit,
                                                       const clx_port_t clx_port,
                                                       uint32 *ptr_port);

typedef clx_error_no_t (*HAL_PORT_SETMACPROPERTY)(const uint32 unit,
                                                  const uint32 port,
                                                  const HAL_MAC_PROPERTY_T property,
                                                  const uint32 param0,
                                                  const uint32 param1);

typedef clx_error_no_t (*HAL_PORT_GETMACPROPERTY)(const uint32 unit,
                                                  const uint32 port,
                                                  const HAL_MAC_PROPERTY_T property,
                                                  uint32 *ptr_param0,
                                                  uint32 *ptr_param1);

typedef clx_error_no_t (*HAL_PORT_SETTXCOEF)(const uint32 unit,
                                             const uint32 port,
                                             const uint32 lane_idx,
                                             const clx_port_phy_location_t location,
                                             clx_port_tx_coef_t *ptr_tx_coef);

typedef clx_error_no_t (*HAL_PORT_GETTXCOEF)(const uint32 unit,
                                             const uint32 port,
                                             const uint32 lane_idx,
                                             const clx_port_phy_location_t location,
                                             clx_port_tx_coef_t *ptr_tx_coef);

typedef clx_error_no_t (*HAL_PORT_SETADVERTISEDINTFTYPE)(const uint32 unit,
                                                         const uint32 port,
                                                         const uint32 intf_type);

typedef clx_error_no_t (*HAL_PORT_VLAN_TAG_CTRL_GET)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const clx_bridge_domain_t bdid,
                                                     clx_port_vlan_tag_ctrl_t *ptr_port_tag);

typedef clx_error_no_t (*HAL_PORT_VLAN_TAG_CTRL_SET)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const clx_bridge_domain_t bdid,
                                                     const clx_port_vlan_tag_ctrl_t *ptr_port_tag);

typedef clx_error_no_t (*HAL_PORT_CREATEINTFGROUP)(const uint32 unit,
                                                   const clx_dir_t dir,
                                                   const uint32 *group_id);

typedef clx_error_no_t (*HAL_PORT_ADDINTFGROUPMEMBER)(const uint32 unit,
                                                      const clx_dir_t dir,
                                                      const uint32 group_id,
                                                      const clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (*HAL_PORT_DELINTFGROUPMEMBER)(const uint32 unit,
                                                      const clx_dir_t dir,
                                                      const uint32 group_id,
                                                      const clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (*HAL_PORT_GETINTFGROUPMEMBER)(const uint32 unit,
                                                      const clx_dir_t dir,
                                                      const uint32 group_id,
                                                      clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (*HAL_PORT_GETPORTINTFGROUPID)(const uint32 unit,
                                                      const clx_dir_t dir,
                                                      const clx_port_t port,
                                                      uint32 *group_id);

typedef clx_error_no_t (*HAL_PORT_DESTROYINTFGROUP)(const uint32 unit,
                                                    const clx_dir_t dir,
                                                    const uint32 group_id);

typedef clx_error_no_t (*HAL_PORT_SETEGRHIGHLATENCYTHRESHOLD)(const uint32 unit,
                                                              const uint32 threshold);

typedef clx_error_no_t (*HAL_PORT_GETEGRHIGHLATENCYTHRESHOLD)(const uint32 unit, uint32 *threshold);

typedef clx_error_no_t (*HAL_PORT_GETPORTINTFGROUP)(const uint32 unit,
                                                    const clx_dir_t dir,
                                                    const clx_port_t port);

typedef clx_error_no_t (*HAL_PORT_SETMBURSTPROPERTY)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const clx_port_mburst_cfg_t *ptr_property);

typedef clx_error_no_t (*HAL_PORT_GETMBURSTPROPERTY)(const uint32 unit,
                                                     const clx_port_t port,
                                                     clx_port_mburst_cfg_t *ptr_property);

typedef clx_error_no_t (*HAL_PORT_GETMBURSTSTAT)(const uint32 unit,
                                                 const clx_port_t port,
                                                 const clx_dir_t dir,
                                                 clx_port_mburst_stat_t *p_stat);

typedef clx_error_no_t (*HAL_PORT_GETMBURSTHISTCNT)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_dir_t dir,
                                                    const clx_port_t thrd_num,
                                                    uint32 *p_count);

typedef clx_error_no_t (*HAL_PORT_CLEARMBURSTCNT)(const uint32 unit,
                                                  const clx_port_t port,
                                                  const clx_dir_t dir);

typedef clx_error_no_t (*HAL_PORT_SETFECCLEAR_FUNC_T)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*HAL_PORT_SHOWBUFFCNT_FUNC_T)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*HAL_PORT_SHOWBUFFCFG_FUNC_T)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*HAL_PORT_GETXOFFSTATUS_FUNC_T)(const uint32 unit,
                                                        const uint32 port,
                                                        clx_port_xoff_status_t *ptr_xoff_status);

typedef clx_error_no_t (*HAL_PORT_REGISTERTXSIGNAL_FUNC_T)(const uint32 unit,
                                                           clx_port_phy_notify_func_t func,
                                                           void *ptr_cookie);

typedef clx_error_no_t (*HAL_PORT_DI_SET_FUNC_T)(const uint32 unit,
                                                 const uint32 port,
                                                 const uint32 di);

/* lag multiplexing functions */
typedef clx_error_no_t (*HAL_LAG_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_LAG_DEINIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_LAG_CREATE_FUNC_T)(const uint32 unit,
                                                const clx_lag_create_info_t *ptr_lag_create_info,
                                                uint32 *ptr_lag_id,
                                                clx_port_t *ptr_lag_port);

typedef clx_error_no_t (*HAL_LAG_DESTROY_FUNC_T)(const uint32 unit, const uint32 lag_id);

typedef clx_error_no_t (*HAL_LAG_MEMBER_SET_FUNC_T)(const uint32 unit,
                                                    const uint32 lag_id,
                                                    const uint32 member_cnt,
                                                    const clx_lag_member_t *ptr_member);

typedef clx_error_no_t (*HAL_LAG_MEMBER_GET_FUNC_T)(const uint32 unit,
                                                    const uint32 lag_id,
                                                    const uint32 member_cnt,
                                                    clx_lag_member_t *ptr_member_info,
                                                    uint32 *ptr_actual_member_cnt);

typedef clx_error_no_t (*HAL_LAG_MEMBER_CNT_GET_FUNC_T)(const uint32 unit,
                                                        const uint32 lag_id,
                                                        uint32 *ptr_member_cnt);

typedef clx_error_no_t (*HAL_LAG_TRAV_FUNC_T)(const uint32 unit,
                                              const clx_lag_trav_func_t callback,
                                              void *ptr_cookie);

typedef clx_error_no_t (*HAL_LAG_PORT_GET_FUNC_T)(const uint32 unit,
                                                  uint32 lag_id,
                                                  clx_port_t *ptr_lag_port);

typedef clx_error_no_t (*HAL_LAG_ID_GET_FUNC_T)(const uint32 unit,
                                                clx_port_t lag_port,
                                                uint32 *ptr_lag_id);

typedef clx_error_no_t (*HAL_LAG_ATTR_SET_FUNC_T)(const uint32 unit,
                                                  const clx_port_t lag_id,
                                                  const clx_lag_attr_t *ptr_attr);

typedef clx_error_no_t (*HAL_LAG_ATTR_GET_FUNC_T)(const uint32 unit,
                                                  const clx_port_t lag_id,
                                                  clx_lag_attr_t *ptr_attr);
/*mirror multiplexing functions */
typedef clx_error_no_t (*hal_mir_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_mir_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_mir_session_add_func_t)(const uint32 unit,
                                                     const clx_mir_direct_t direction,
                                                     const uint32 mir_id,
                                                     const clx_mir_session_cfg_t *ptr_session_cfg);

typedef clx_error_no_t (*hal_mir_session_del_func_t)(const uint32 unit,
                                                     const clx_mir_direct_t direction,
                                                     const uint32 mir_id);

typedef clx_error_no_t (*hal_mir_session_get_func_t)(const uint32 unit,
                                                     const clx_mir_direct_t direction,
                                                     const uint32 mir_id,
                                                     clx_mir_session_cfg_t *ptr_session_cfg);

typedef clx_error_no_t (*hal_mir_erspan_decap_add_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_key,
    const uint32 mir_id);

typedef clx_error_no_t (*hal_mir_erspan_decap_del_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_key);

typedef clx_error_no_t (*hal_mir_erspan_decap_get_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_key_t *ptr_decap_key,
    uint32 *ptr_mir_id);
typedef clx_error_no_t (*hal_mir_erspan_decap_trav_func_t)(
    const uint32 unit,
    const clx_mir_erspan_decap_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_mir_selective_flow_mir_set_func_t)(
    const uint32 unit,
    const clx_swc_selective_flow_cfg_t *ptr_select_cfg);

typedef clx_error_no_t (*hal_mir_selective_flow_mir_get_func_t)(
    const uint32 unit,
    clx_swc_selective_flow_cfg_t *ptr_select_cfg);

/*l3 multiplexing functions */
typedef clx_error_no_t (*hal_l3_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_l3_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_l3_intf_add_func_t)(const uint32 unit, clx_l3_intf_t *ptr_l3_intf);

typedef clx_error_no_t (*hal_l3_intf_del_func_t)(const uint32 unit, const uint32 intf_id);

typedef clx_error_no_t (*hal_l3_intf_get_func_t)(const uint32 unit, clx_l3_intf_t *ptr_l3_intf);

typedef clx_error_no_t (*hal_l3_intf_trav_func_t)(const uint32 unit,
                                                  const clx_l3_intf_trav_func_t cb,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_rmac_add_func_t)(const uint32 unit, const clx_l3_rmac_t *ptr_rmac);

typedef clx_error_no_t (*hal_l3_rmac_del_func_t)(const uint32 unit, const uint32 index);

typedef clx_error_no_t (*hal_l3_rmac_get_func_t)(const uint32 unit, clx_l3_rmac_t *ptr_rmac);

typedef clx_error_no_t (*hal_l3_rmac_trav_func_t)(const uint32 unit,
                                                  const clx_l3_rmac_trav_func_t cb,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_adj_add_func_t)(const uint32 unit, clx_l3_adj_t *ptr_adj_info);

typedef clx_error_no_t (*hal_l3_adj_del_func_t)(const uint32 unit, const uint32 adj_id);

typedef clx_error_no_t (*hal_l3_adj_get_func_t)(const uint32 unit, clx_l3_adj_t *ptr_adj_info);

typedef clx_error_no_t (*hal_l3_adj_trav_func_t)(const uint32 unit,
                                                 const clx_l3_adj_type_t type,
                                                 const clx_l3_adj_trav_func_t callback,
                                                 void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_host_add_func_t)(const uint32 unit, const clx_l3_host_t *ptr_host);

typedef clx_error_no_t (*hal_l3_host_del_func_t)(const uint32 unit,
                                                 const clx_l3_addr_t *ptr_host_addr);

typedef clx_error_no_t (*hal_l3_host_get_func_t)(const uint32 unit, clx_l3_host_t *ptr_host);

typedef clx_error_no_t (*hal_l3_host_trav_func_t)(const uint32 unit,
                                                  const clx_l3_host_trav_func_t callback,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_host_flush_func_t)(const uint32 unit,
                                                   const clx_l3_host_t *ptr_host);

typedef clx_error_no_t (*hal_l3_subnet_bcast_add_func_t)(const uint32 unit,
                                                         const clx_l3_subnet_bcast_t *ptr_subnet);

typedef clx_error_no_t (*hal_l3_subnet_bcast_del_func_t)(const uint32 unit,
                                                         const clx_l3_addr_t *ptr_subnet_addr);

typedef clx_error_no_t (*hal_l3_subnet_bcast_get_func_t)(const uint32 unit,
                                                         clx_l3_subnet_bcast_t *ptr_subnet);

typedef clx_error_no_t (*hal_l3_subnet_bcast_trav_func_t)(const uint32 unit,
                                                          const clx_l3_bcast_trav_func_t cb,
                                                          void *ptr_subnet);

typedef clx_error_no_t (*hal_l3_route_add_func_t)(const uint32 unit,
                                                  const clx_l3_route_t *ptr_route);
typedef clx_error_no_t (*hal_l3_route_del_func_t)(const uint32 unit,
                                                  const clx_l3_addr_t *ptr_route_addr);

typedef clx_error_no_t (*hal_l3_route_get_func_t)(const uint32 unit, clx_l3_route_t *ptr_route);

typedef clx_error_no_t (*hal_l3_route_trav_func_t)(const uint32 unit,
                                                   const clx_l3_route_trav_func_t cb,
                                                   void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_bulk_route_add_func_t)(const uint32 unit,
                                                       const clx_bulk_op_mode_t mode,
                                                       clx_l3_bulk_route_t *ptr_bulk_route);

typedef clx_error_no_t (*hal_l3_bulk_route_del_func_t)(const uint32 unit,
                                                       const clx_bulk_op_mode_t mode,
                                                       clx_l3_bulk_route_t *ptr_bulk_route);

typedef clx_error_no_t (*hal_l3_bulk_route_get_func_t)(const uint32 unit,
                                                       clx_l3_route_t *ptr_route);

typedef clx_error_no_t (*hal_l3_route_usage_get_func_t)(const uint32 unit,
                                                        const uint32 param,
                                                        uint32 *ptr_cnt);

typedef clx_error_no_t (*hal_l3_bulk_route_dump_func_t)(const uint32 unit,
                                                        const uint32 v4_low_mask,
                                                        const uint32 v6_low_mask);

typedef clx_error_no_t (*hal_l3_ecmp_grp_add_func_t)(const uint32 unit,
                                                     clx_l3_ecmp_grp_t *ptr_ecmp);

typedef clx_error_no_t (*hal_l3_ecmp_grp_del_func_t)(const uint32 unit, uint32 ecmp_id);

typedef clx_error_no_t (*hal_l3_ecmp_grp_get_func_t)(const uint32 unit,
                                                     clx_l3_ecmp_grp_t *ptr_ecmp);

typedef clx_error_no_t (*hal_l3_ecmp_grp_trav_func_t)(const uint32 unit,
                                                      const clx_nhp_type_t type,
                                                      const clx_l3_ecmp_grp_trav_func_t cb,
                                                      void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_ecmp_grp_sync_func_t)(const uint32 unit,
                                                      const uint32 ori_ecmp_id,
                                                      const uint32 cur_ecmp_id);

typedef clx_error_no_t (*hal_l3_ecmp_path_add_func_t)(const uint32 unit,
                                                      const clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_ecmp_path_del_func_t)(const uint32 unit,
                                                      const clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_ecmp_path_get_by_idx_func_t)(const uint32 unit,
                                                             const uint32 path_idx,
                                                             clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (
    *hal_l3_ecmp_path_hsh_set_func_t)(const uint32 unit, const clx_l3_ecmp_path_hsh_t *ptr_hsh_set);

typedef clx_error_no_t (*hal_l3_ecmp_path_hsh_get_func_t)(const uint32 unit,
                                                          clx_l3_ecmp_path_hsh_t *ptr_hsh_get);

typedef clx_error_no_t (*hal_l3_ecmp_path_list_set_func_t)(const uint32 unit,
                                                           const boolean is_org,
                                                           const uint32 idx,
                                                           const clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_ecmp_path_list_get_func_t)(const uint32 unit,
                                                           const boolean is_org,
                                                           const uint32 idx,
                                                           clx_l3_ecmp_path_t *ptr_path);

typedef clx_error_no_t (
    *hal_l3_ecmp_all_path_list_get_func_t)(const uint32 unit, clx_l3_ecmp_all_path_t *allPatchInfo);

typedef clx_error_no_t (*hal_l3_vrf_set_func_t)(const uint32 unit, const clx_l3_vrf_t *ptr_vrf);

typedef clx_error_no_t (*hal_l3_vrf_get_func_t)(const uint32 unit, clx_l3_vrf_t *ptr_vrf);

#if 0
typedef clx_error_no_t (*HAL_L3_ADDFDLECMPGROUP_FUNC_T)(const uint32 unit,
                                                        const uint32 ecmp_grp_id,
                                                        const clx_fdl_info_t *ptr_fdl_info);

typedef clx_error_no_t (*HAL_L3_DELFDLECMPGROUP_FUNC_T)(const uint32 unit,
                                                        const uint32 ecmp_grp_id);

typedef clx_error_no_t (*HAL_L3_GETFDLECMPGROUP_FUNC_T)(const uint32 unit,
                                                        const uint32 ecmp_grp_id,
                                                        clx_fdl_info_t *ptr_fdl_info);
#endif
typedef clx_error_no_t (*hal_l3_ecmp_path_hsh_calc_func_t)(
    const uint32 unit,
    const clx_swc_hsh_pkt_type_t hash_type,
    const clx_swc_flow_hsh_key_t *ptr_hash_key,
    const uint32 ecmp_grp_id,
    clx_l3_ecmp_path_hsh_rslt_t *ptr_rslt);

typedef clx_error_no_t (*hal_l3_ecmp_path_list_dump_func_t)(const uint32 unit,
                                                            const uint32 ecmp_grp_id);

/*l3 multicast multiplexing functions */
typedef clx_error_no_t (*hal_l3_mcast_grp_create_func_t)(const uint32 unit,
                                                         const uint32 flags,
                                                         uint32 *ptr_mcast_id);

typedef clx_error_no_t (*hal_l3_mcast_grp_destroy_func_t)(const uint32 unit, const uint32 mcast_id);

typedef clx_error_no_t (*hal_l3_mcast_port_bmp_get_func_t)(const uint32 unit,
                                                           const uint32 mcast_id,
                                                           clx_port_bitmap_t port_bitmap);

typedef clx_error_no_t (
    *hal_l3_mcast_route_add_func_t)(const uint32 unit, const clx_l3_mcast_route_t *ptr_mcast_route);

typedef clx_error_no_t (*hal_l3_mcast_route_del_func_t)(const uint32 unit,
                                                        const clx_l3_mcast_addr_t *ptr_mcast_addr);

typedef clx_error_no_t (*hal_l3_mcast_route_get_func_t)(const uint32 unit,
                                                        clx_l3_mcast_route_t *ptr_mcast_route);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_add_func_t)(const uint32 unit,
                                                           const clx_l3_mcast_egr_t *ptr_egr);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_del_func_t)(const uint32 unit,
                                                           const clx_l3_mcast_egr_t *ptr_egr);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_set_func_t)(const uint32 unit,
                                                           const clx_l3_mcast_egr_t *ptr_egr);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_cnt_get_func_t)(const uint32 unit,
                                                               const uint32 mcast_id,
                                                               const clx_port_t port_id,
                                                               uint32 *ptr_intf_cnt);

typedef clx_error_no_t (*hal_l3_mcast_egr_intf_get_func_t)(const uint32 unit,
                                                           const uint32 mcast_id,
                                                           const clx_port_t port_id,
                                                           uint32 *ptr_cnt,
                                                           clx_l3_mcast_egr_intf_t *ptr_intf);

typedef clx_error_no_t (
    *hal_l3_mcast_df_intf_add_func_t)(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_df_intf);

typedef clx_error_no_t (
    *hal_l3_mcast_df_intf_del_func_t)(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_df_intf);

typedef clx_error_no_t (*hal_l3_mcast_df_intf_get_func_t)(const uint32 unit,
                                                          clx_l3_mcast_df_intf_t *ptr_rslt);

typedef clx_error_no_t (*hal_l3_mcast_route_trav_func_t)(const uint32 unit,
                                                         const clx_l3_mcast_route_trav_func_t cb,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_frr_create_func_t)(const uint32 unit, clx_l3_frr_t *ptr_frr);

typedef clx_error_no_t (*hal_l3_frr_destroy_func_t)(const uint32 unit, const uint32 frr_id);

typedef clx_error_no_t (*hal_l3_frr_path_add_func_t)(const uint32 unit,
                                                     const clx_l3_frr_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_frr_path_del_func_t)(const uint32 unit,
                                                     const clx_l3_frr_path_t *ptr_path);

typedef clx_error_no_t (*hal_l3_frr_state_set_func_t)(const uint32 unit,
                                                      const uint32 frr_id,
                                                      const boolean state);

typedef clx_error_no_t (*hal_l3_frr_state_get_func_t)(const uint32 unit,
                                                      const uint32 frr_id,
                                                      boolean *ptr_state);

/* tunnel multiplexing functions */
typedef clx_error_no_t (*hal_tnl_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_tnl_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_tnl_mac_add_func_t)(const uint32 unit,
                                                 const uint32 index,
                                                 const clx_tnl_mac_info_t *ptr_mac_info);

typedef clx_error_no_t (*hal_tnl_mac_del_func_t)(const uint32 unit, const uint32 index);

typedef clx_error_no_t (*hal_tnl_mac_get_func_t)(const uint32 unit,
                                                 const uint32 index,
                                                 clx_tnl_mac_info_t *ptr_mac_info);

typedef clx_error_no_t (*hal_tnl_mac_trav_func_t)(const uint32 unit,
                                                  const clx_tnl_mac_trav_t callback,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_entry_encap_add_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info,
                                                         const clx_tnl_encap_info_t *ptr_encap_info);

typedef clx_error_no_t (*hal_tnl_entry_encap_del_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info);

typedef clx_error_no_t (*hal_tnl_entry_encap_get_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info,
                                                         clx_tnl_encap_info_t *ptr_encap_info);

typedef clx_error_no_t (*hal_tnl_entry_encap_trav_func_t)(const uint32 unit,
                                                          const clx_tnl_encap_trav_func_t cb,
                                                          void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_entry_decap_add_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info,
                                                         const clx_tnl_decap_info_t *ptr_decap_info);

typedef clx_error_no_t (*hal_tnl_entry_decap_del_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info);

typedef clx_error_no_t (*hal_tnl_entry_decap_get_func_t)(const uint32 unit,
                                                         const clx_tnl_info_t *ptr_tnl_info,
                                                         clx_tnl_decap_info_t *ptr_decap_info);

typedef clx_error_no_t (*hal_tnl_entry_decap_trav_func_t)(const uint32 unit,
                                                          const clx_tnl_decap_trav_func_t cb,
                                                          void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_nvo3_route_add_func_t)(
    const uint32 unit,
    const clx_tnl_info_t *ptr_tnl_info,
    const clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_tnl_nvo3_route_del_func_t)(const uint32 unit,
                                                        const clx_tnl_info_t *ptr_tnl_info);

typedef clx_error_no_t (*hal_tnl_nvo3_route_get_func_t)(
    const uint32 unit,
    const clx_tnl_info_t *ptr_tnl_info,
    clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_tnl_nvo3_route_trav_func_t)(const uint32 unit,
                                                         const clx_tnl_nvo3_route_trav_func_t cb,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_port_create_func_t)(const uint32 unit,
                                                     const uint32 flag,
                                                     const clx_tnl_info_t *ptr_tnl_info,
                                                     clx_port_t *ptr_port);

typedef clx_error_no_t (*hal_tnl_port_destroy_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_tnl_port_get_func_t)(const uint32 unit,
                                                  const clx_tnl_info_t *ptr_tnl_info,
                                                  clx_port_t *ptr_tnl_port);

typedef clx_error_no_t (*hal_tnl_info_get_func_t)(const uint32 unit,
                                                  const clx_port_t tnl_port,
                                                  clx_tnl_info_t *ptr_tnl_info);

typedef clx_error_no_t (*hal_tnl_entry_trav_func_t)(const uint32 unit,
                                                    const clx_tnl_port_trav_func_t cb,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_tnl_flex_tnl_add_func_t)(
    const uint32 unit,
    const uint32 index,
    const clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

typedef clx_error_no_t (*hal_tnl_flex_tnl_del_func_t)(const uint32 unit, const uint32 index);

typedef clx_error_no_t (*hal_tnl_flex_tnl_get_func_t)(const uint32 unit,
                                                      const uint32 index,
                                                      clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

typedef clx_error_no_t (*hal_tnl_flex_tnl_udf_set_func_t)(const uint32 unit,
                                                          const uint32 index,
                                                          clx_tnl_flex_tnl_udf_prof_t *ptr_prof);

typedef clx_error_no_t (*hal_tnl_flex_tnl_udf_get_func_t)(const uint32 unit,
                                                          const uint32 index,
                                                          clx_tnl_flex_tnl_udf_prof_t *ptr_prof);

typedef clx_error_no_t (*hal_tnl_phy_port_set_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const clx_tnl_port_info_t *ptr_port_info);

typedef clx_error_no_t (*hal_tnl_phy_port_get_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      clx_tnl_port_info_t *ptr_port_info);

typedef clx_error_no_t (*hal_tnl_es_grp_create_func_t)(const uint32 unit,
                                                       const uint32 flags,
                                                       uint32 *ptr_es_grp);

typedef clx_error_no_t (*hal_tnl_es_grp_destroy_func_t)(const uint32 unit, const uint32 es_grp);

typedef clx_error_no_t (*hal_tnl_es_grp_mbr_add_func_t)(const uint32 unit,
                                                        const uint32 es_grp,
                                                        const clx_port_t *ptr_port_mbr,
                                                        const uint32 port_num);

typedef clx_error_no_t (*hal_tnl_es_grp_mbr_del_func_t)(const uint32 unit,
                                                        const uint32 es_grp,
                                                        const clx_port_t *ptr_port_mbr,
                                                        const uint32 port_num);

typedef clx_error_no_t (*hal_tnl_es_grp_mbr_get_func_t)(const uint32 unit,
                                                        const uint32 es_grp,
                                                        clx_port_t *ptr_port_mbr,
                                                        uint32 *ptr_port_num);

typedef clx_error_no_t (*hal_tnl_seg_srv_add_func_t)(const uint32 unit,
                                                     const clx_tnl_info_t *ptr_tnl_info,
                                                     const clx_tnl_seg_key_t *ptr_segment,
                                                     const uint32 bdid);

typedef clx_error_no_t (*hal_tnl_seg_srv_del_func_t)(const uint32 unit,
                                                     const clx_tnl_info_t *ptr_tnl_info,
                                                     const clx_tnl_seg_key_t *ptr_segment);

typedef clx_error_no_t (*hal_tnl_seg_srv_get_func_t)(const uint32 unit,
                                                     const clx_tnl_info_t *ptr_tnl_info,
                                                     const clx_tnl_seg_key_t *ptr_segment,
                                                     uint32 *ptr_bdid);

/* srv6 tunnel multiplexing functions */
typedef clx_error_no_t (*hal_srv6_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_srv6_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_srv6_port_create_func_t)(const uint32 unit,
                                                      const uint32 flag,
                                                      clx_port_t *ptr_port);

typedef clx_error_no_t (*hal_srv6_port_destroy_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_srv6_port_trav_func_t)(const uint32 unit,
                                                    const clx_srv6_port_trav_func_t callback,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_local_add_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_srv6_local_cfg_t *ptr_local_info);

typedef clx_error_no_t (*hal_srv6_local_del_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_srv6_local_set_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_srv6_local_cfg_t *ptr_srv6_local);

typedef clx_error_no_t (*hal_srv6_local_get_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    clx_srv6_local_cfg_t *ptr_srv6_local);

typedef clx_error_no_t (*hal_srv6_local_trav_func_t)(const uint32 unit,
                                                     const clx_srv6_local_trav_func_t callback,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_encap_add_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_srv6_encap_cfg_t *ptr_encap_info);

typedef clx_error_no_t (*hal_srv6_encap_del_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_srv6_encap_set_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    const clx_srv6_encap_cfg_t *ptr_encap_info);

typedef clx_error_no_t (*hal_srv6_encap_get_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    clx_srv6_encap_cfg_t *ptr_encap_info);

typedef clx_error_no_t (*hal_srv6_encap_trav_func_t)(const uint32 unit,
                                                     const clx_srv6_encap_trav_func_t callback,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_mysid_entry_add_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry,
    const clx_srv6_mysid_cfg_t *ptr_mysid_info);

typedef clx_error_no_t (*hal_srv6_mysid_entry_del_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry);

typedef clx_error_no_t (*hal_srv6_mysid_entry_set_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry,
    const clx_srv6_mysid_cfg_t *ptr_mysid_info);

typedef clx_error_no_t (*hal_srv6_mysid_entry_get_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry,
    clx_srv6_mysid_cfg_t *ptr_mysid_info);

typedef clx_error_no_t (*hal_srv6_mysid_entry_trav_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_property_set_func_t)(const uint32 unit,
                                                       const clx_srv6_property_t *ptr_property);

typedef clx_error_no_t (*hal_srv6_property_get_func_t)(const uint32 unit,
                                                       clx_srv6_property_t *ptr_property);

typedef clx_error_no_t (*hal_srv6_nvo3_route_add_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const clx_srv6_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_srv6_nvo3_route_set_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const clx_srv6_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_srv6_nvo3_route_del_func_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_srv6_nvo3_route_get_func_t)(
    const uint32 unit,
    const clx_port_t port,
    clx_srv6_nvo3_route_info_t *ptr_nvo3_route_info);

typedef clx_error_no_t (*hal_srv6_nvo3_route_trav_func_t)(
    const uint32 unit,
    const clx_srv6_nvo3_route_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_add_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_del_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_set_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_get_func_t)(
    const uint32 unit,
    clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

typedef clx_error_no_t (*hal_srv6_endpoint_policy_trav_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_srv6_seg_srv_add_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 service_id,
                                                      const uint32 bdid);

typedef clx_error_no_t (*hal_srv6_seg_srv_del_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 service_id);

typedef clx_error_no_t (*hal_srv6_seg_srv_set_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 service_id,
                                                      const uint32 bdid);

typedef clx_error_no_t (*hal_srv6_seg_srv_get_func_t)(const uint32 unit,
                                                      const clx_port_t port,
                                                      const uint32 service_id,
                                                      uint32 *ptr_bdid);

typedef clx_error_no_t (*hal_srv6_hash_action_set_func_t)(
    const uint32 unit,
    const clx_srv6_hash_type_t hash_type,
    const clx_srv6_hash_action_t *ptr_hash_action);

typedef clx_error_no_t (*hal_srv6_hash_action_get_func_t)(const uint32 unit,
                                                          const clx_srv6_hash_type_t hash_type,
                                                          clx_srv6_hash_action_t *ptr_hash_action);

/* ifmon multiplexing functions */
typedef clx_error_no_t (*HAL_IFMON_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_IFMON_DEINIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_IFMON_REGISTER_FUNC_T)(const uint32 unit,
                                                    const clx_port_ifmon_notify_func_t notify_func,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*HAL_IFMON_DEREGISTER_FUNC_T)(const uint32 unit,
                                                      const clx_port_ifmon_notify_func_t notify_func,
                                                      void *ptr_cookie);

typedef clx_error_no_t (*HAL_IFMON_GETMODE_FUNC_T)(const uint32 unit,
                                                   clx_port_ifmon_mode_t *ptr_mode,
                                                   clx_port_bitmap_t *ptr_port_bitmap,
                                                   uint32 *ptr_interval);

typedef clx_error_no_t (*HAL_IFMON_SETMODE_FUNC_T)(const uint32 unit,
                                                   const clx_port_ifmon_mode_t mode,
                                                   const clx_port_bitmap_t port_bitmap,
                                                   const uint32 interval);

typedef clx_error_no_t (*HAL_IFMON_GETMONITORSTATE_FUNC_T)(const uint32 unit, boolean *ptr_enable);

typedef clx_error_no_t (*HAL_IFMON_SETMONITORSTATE_FUNC_T)(const uint32 unit, const boolean enable);

typedef clx_error_no_t (*HAL_IFMON_GETCALLBACKCNT_FUNC_T)(const uint32 unit,
                                                          uint32 *ptr_callback_cnt);

/*l2 multiplexing functions */
typedef clx_error_no_t (*hal_l2_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_l2_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_l2_addr_add_func_t)(const uint32 unit, const clx_l2_addr_t *ptr_addr);

typedef clx_error_no_t (*hal_l2_addr_del_func_t)(const uint32 unit,
                                                 const clx_bridge_domain_t bdid,
                                                 const clx_mac_t mac,
                                                 const uint32 flags);

typedef clx_error_no_t (*hal_l2_addr_get_func_t)(const uint32 unit, clx_l2_addr_t *ptr_addr);

typedef clx_error_no_t (*hal_l2_addr_flush_func_t)(const uint32 unit,
                                                   const uint32 flags,
                                                   const clx_l2_addr_flush_op_type_t flush_type,
                                                   const clx_l2_addr_flush_t *ptr_match_addr);

typedef clx_error_no_t (*hal_l2_addr_replace_func_t)(const uint32 unit,
                                                     const uint32 match_flags,
                                                     const clx_l2_addr_t *ptr_match_addr,
                                                     const uint32 replace_flags,
                                                     const clx_l2_addr_t *ptr_replace_addr);

typedef clx_error_no_t (*hal_l2_addr_trav_func_t)(const uint32 unit,
                                                  const clx_l2_entry_trav_mode_t mode,
                                                  const clx_l2_addr_trav_match_t *ptr_match_addr,
                                                  const clx_l2_addr_trav_func_t callback,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_notify_cb_register_func_t)(
    const uint32 unit,
    const clx_l2_addr_notify_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_notify_cb_deregister_func_t)(
    const uint32 unit,
    const clx_l2_addr_notify_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_sw_learn_cb_register_func_t)(
    const uint32 unit,
    const clx_l2_addr_sw_learn_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_addr_sw_learn_cb_deregister_func_t)(
    const uint32 unit,
    const clx_l2_addr_sw_learn_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_age_status_get_func_t)(const uint32 unit,
                                                       const clx_bridge_domain_t bdid,
                                                       const clx_mac_t mac,
                                                       uint32 *ptr_age_status);

typedef clx_error_no_t (*hal_l2_mcast_grp_create_func_t)(const uint32 unit,
                                                         const uint32 flags,
                                                         uint32 *ptr_mcast_id);

typedef clx_error_no_t (*hal_l2_mcast_grp_destroy_func_t)(const uint32 unit, const uint32 mcast_id);

typedef clx_error_no_t (*hal_l2_mcast_intf_pbmp_get_func_t)(const uint32 unit,
                                                            const uint32 mcast_id,
                                                            uint32 *ptr_flags,
                                                            clx_port_bitmap_t port_bmp);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_add_func_t)(
    const uint32 unit,
    const uint32 mcast_id,
    const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_del_func_t)(
    const uint32 unit,
    const uint32 mcast_id,
    const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_cnt_get_func_t)(const uint32 unit,
                                                               const uint32 mcast_id,
                                                               uint32 *ptr_egr_intf_cnt);

typedef clx_error_no_t (*hal_l2_mcast_egr_intf_get_func_t)(const uint32 unit,
                                                           const uint32 mcast_id,
                                                           clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);
typedef clx_error_no_t (*hal_l2_mcast_egr_intf_check_func_t)(const uint32 unit,
                                                             const uint32 mcast_id,
                                                             const clx_l2_mcast_egr_intf_t egr_intf,
                                                             boolean *ptr_is_exist);
typedef clx_error_no_t (*hal_l2_mcast_addr_add_func_t)(const uint32 unit,
                                                       const clx_l2_mcast_addr_t *ptr_addr);

typedef clx_error_no_t (*hal_l2_mcast_addr_del_func_t)(const uint32 unit,
                                                       const clx_bridge_domain_t bdid,
                                                       const clx_mac_t mac);

typedef clx_error_no_t (*hal_l2_mcast_addr_get_func_t)(const uint32 unit,
                                                       clx_l2_mcast_addr_t *ptr_addr);

typedef clx_error_no_t (*hal_l2_mcast_addr_trav_func_t)(
    const uint32 unit,
    const clx_l2_entry_trav_mode_t mode,
    const clx_l2_mcast_addr_trav_match_t *ptr_match_addr,
    const clx_l2_mcast_addr_trav_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_l2_capacity_get_func_t)(const uint32 unit,
                                                     const clx_swc_rsrc_t type,
                                                     const uint32 param,
                                                     uint32 *ptr_size);
typedef clx_error_no_t (*hal_l2_usage_get_func_t)(const uint32 unit,
                                                  const clx_swc_rsrc_t type,
                                                  const uint32 param,
                                                  uint32 *ptr_cnt);
typedef clx_error_no_t (*hal_l2_aging_time_set_func_t)(const uint32 unit, const uint32 aging_time);
typedef clx_error_no_t (*hal_l2_aging_time_get_func_t)(const uint32 unit, uint32 *ptr_aging_time);
typedef clx_error_no_t (*hal_l2_sa_move_action_set_func_t)(const uint32 unit,
                                                           const clx_fwd_action_t action);
typedef clx_error_no_t (*hal_l2_sa_move_action_get_func_t)(const uint32 unit, uint32 *ptr_action);
typedef clx_error_no_t (*hal_l2_sa_miss_action_set_func_t)(const uint32 unit,
                                                           const clx_swc_cfg_t reason,
                                                           const clx_fwd_action_t action);
typedef clx_error_no_t (*hal_l2_sa_miss_action_get_func_t)(const uint32 unit,
                                                           const clx_swc_cfg_t reason,
                                                           uint32 *ptr_action);
typedef clx_error_no_t (*hal_l2_mcast_id_print_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_l2_mcast_grp_info_print_func_t)(const uint32 unit,
                                                             const uint32 logical_mc_id,
                                                             const uint32 phy_mc_id);
typedef clx_error_no_t (*hal_l2_mcast_lag_mbr_update_func_t)(const uint32 unit,
                                                             const uint32 lag_id,
                                                             const uint32 add_member_cnt,
                                                             const uint32 *ptr_add_member_di,
                                                             const uint32 del_member_cnt,
                                                             const uint32 *ptr_del_member_di);

typedef clx_error_no_t (*hal_l2_mcast_lag_del_func_t)(const uint32 unit, const uint32 lag_id);

/* L2 ECMP */
typedef clx_error_no_t (*hal_l2_ecmp_grp_add_func_t)(const uint32 unit,
                                                     clx_l2_ecmp_grp_t *ptr_ecmp_info,
                                                     clx_port_t *ptr_ecmp_port);

typedef clx_error_no_t (*hal_l2_ecmp_grp_del_func_t)(const uint32 unit, const clx_port_t ecmp_port);

typedef clx_error_no_t (*hal_l2_ecmp_grp_get_func_t)(const uint32 unit,
                                                     const clx_port_t ecmp_port,
                                                     clx_l2_ecmp_grp_t *ptr_ecmp_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_add_func_t)(const uint32 unit,
                                                      const clx_port_t ecmp_port,
                                                      const clx_l2_ecmp_path_t *ptr_path_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_del_func_t)(const uint32 unit,
                                                      const clx_port_t ecmp_port,
                                                      const clx_l2_ecmp_path_t *ptr_path_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_get_by_idx_func_t)(const uint32 unit,
                                                             const clx_port_t ecmp_port,
                                                             const uint32 path_idx,
                                                             clx_l2_ecmp_path_t *ptr_path_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_hsh_set_func_t)(const uint32 unit,
                                                          const clx_port_t ecmp_port,
                                                          uint32 *ptr_hash_val_list,
                                                          const uint32 hash_val_cnt,
                                                          const clx_l2_ecmp_path_t *ptr_path_info);

typedef clx_error_no_t (*hal_l2_ecmp_path_hsh_get_func_t)(const uint32 unit,
                                                          const clx_port_t ecmp_port,
                                                          const uint32 hash_val_cnt,
                                                          const clx_l2_ecmp_path_t *ptr_path_info,
                                                          uint32 *ptr_hash_val_list,
                                                          uint32 *ptr_actual_hash_val_cnt);

typedef clx_error_no_t (*hal_l2_grp_path_list_dump_func_t)(const uint32 unit,
                                                           const clx_port_t ecmp_port);

typedef clx_error_no_t (*hal_l2_multi_mcast_grp_create_func_t)(const uint32 unit,
                                                               const uint32 flags,
                                                               const uint32 mcast_id_cnt,
                                                               uint32 *ptr_mcast_id);
/* stp multiplexing functions */

typedef clx_error_no_t (*HAL_STP_INIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_STP_DEINIT_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_STP_CREATE_FUNC_T)(const uint32 unit,
                                                const uint32 flag,
                                                uint32 *ptr_stgid);

typedef clx_error_no_t (*HAL_STP_DESTROY_FUNC_T)(const uint32 unit, const uint32 stgid);

typedef clx_error_no_t (*HAL_STP_PORTSTATE_SET_FUNC_T)(const uint32 unit,
                                                       const uint32 stg,
                                                       const uint32 port,
                                                       const clx_stp_state_t stp_state);

typedef clx_error_no_t (*HAL_STP_PORTSTATE_GET_FUNC_T)(const uint32 unit,
                                                       const uint32 stg,
                                                       const uint32 port,
                                                       clx_stp_state_t *ptr_stp_state);

typedef clx_error_no_t (*HAL_STP_IS_VALID_FUNC_T)(const uint32 unit, const uint32 stg_id);

/* Pkt multiplexing functions */

typedef clx_error_no_t (*hal_pkt_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_rx_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_rx_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_rx_cb_func_t)(const uint32 unit,
                                               const clx_pkt_rx_func_t cb,
                                               void *ptr_cookie,
                                               const clx_pkt_cb_op_t op_mode);

typedef clx_error_no_t (*HAL_PKT_RXMONITORENABLE_FUNC_T)(const uint32 unit,
                                                         const clx_pkt_rx_func_t cb,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*HAL_PKT_RXMONITORDISABLE_FUNC_T)(const uint32 unit);

typedef clx_error_no_t (*HAL_PKT_SETPDMALOOPBACK_FUNC_T)(const uint32 unit, const boolean enabled);

typedef clx_error_no_t (*hal_pkt_tx_send_func_t)(const uint32 unit,
                                                 const clx_pkt_tx_pkt_t *ptr_pkt);

typedef clx_error_no_t (*hal_pkt_tx_prepare_func_t)(const uint32 unit,
                                                    clx_pkt_tx_pkt_t *ptr_pkt,
                                                    const uint8 *ptr_data_buf,
                                                    uint32 len);

typedef clx_error_no_t (*hal_pkt_queue_cfg_get_func_t)(const uint32 unit,
                                                       clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

typedef clx_error_no_t (*hal_pkt_queue_cfg_set_func_t)(const uint32 unit,
                                                       const clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

typedef clx_error_no_t (*hal_pkt_rx_udf_mem_cb_set_func_t)(const uint32 unit,
                                                           const clx_pkt_rx_alloc_func_t alloc_cb,
                                                           const clx_pkt_rx_free_func_t free_cb);

typedef clx_error_no_t (*hal_pkt_cpu_reason_cnt_get_func_t)(
    const uint32 unit,
    const clx_pkt_rx_reason_t cpu_reason,
    clx_pkt_rx_reason_cnt_t *ptr_rx_reason_cnt);

typedef clx_error_no_t (*hal_pkt_cpu_reason_cnt_clear_func_t)(const uint32 unit,
                                                              const clx_pkt_rx_reason_t cpu_reason);

typedef clx_error_no_t (*hal_pkt_intf_rx_reason_cnt_get_func_t)(
    const uint32 unit,
    const uint32 intf_id,
    const clx_pkt_rx_reason_t cpu_reason,
    clx_netif_rx_reason_cnt_t *ptr_rx_reason_cnt);

typedef clx_error_no_t (*hal_pkt_intf_rx_reason_cnt_clear_func_t)(
    const uint32 unit,
    const uint32 intf_id,
    const clx_pkt_rx_reason_t cpu_reason);

typedef clx_error_no_t (*hal_pkt_ifa_cfg_set_func_t)(const uint32 unit,
                                                     const clx_netif_ifa_cfg_t *ptr_ifa_cfg);

typedef clx_error_no_t (*hal_pkt_ifa_cfg_get_func_t)(const uint32 unit,
                                                     clx_netif_ifa_cfg_t *ptr_ifa_cfg);

typedef clx_error_no_t (*hal_pkt_ctrl_to_cpu_entry_set_func_t)(
    const uint32 unit,
    const uint32 index,
    const clx_pkt_ctrl_to_cpu_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_pkt_ctrl_to_cpu_entry_get_func_t)(
    const uint32 unit,
    const uint32 index,
    clx_pkt_ctrl_to_cpu_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_pkt_ctrl_to_cpu_entry_all_clear_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_pkt_tx_cnt_get_func_t)(const uint32 unit,
                                                    const uint32 channel,
                                                    clx_pkt_tx_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_pkt_rx_cnt_get_func_t)(const uint32 unit,
                                                    const uint32 channel,
                                                    clx_pkt_rx_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_pkt_tx_cnt_clear_func_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*hal_pkt_rx_cnt_clear_func_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*hal_pkt_intf_create_func_t)(const uint32 unit,
                                                     const clx_netif_intf_t *ptr_net_intf,
                                                     uint32 *ptr_intf_id);

typedef clx_error_no_t (*hal_pkt_intf_destroy_func_t)(const uint32 unit, const uint32 id);

typedef clx_error_no_t (*hal_pkt_intf_get_func_t)(const uint32 unit,
                                                  const uint32 intf_id,
                                                  clx_netif_intf_t *ptr_net_intf);

typedef clx_error_no_t (*hal_pkt_intf_set_func_t)(const uint32 unit,
                                                  const uint32 intf_id,
                                                  const clx_netif_intf_t *ptr_net_intf);

typedef clx_error_no_t (*hal_pkt_prof_create_func_t)(const uint32 unit,
                                                     const clx_netif_prof_t *ptr_net_profile,
                                                     uint32 *ptr_profile_id);

typedef clx_error_no_t (*hal_pkt_prof_destroy_func_t)(const uint32 unit, const uint32 id);

typedef clx_error_no_t (*hal_pkt_prof_get_func_t)(const uint32 unit,
                                                  const uint32 profile_id,
                                                  clx_netif_prof_t *ptr_net_profile);

typedef clx_error_no_t (*hal_pkt_intf_cnt_get_func_t)(const uint32 unit,
                                                      const uint32 id,
                                                      clx_netif_intf_cnt_t *ptr_intf_cnt);

typedef clx_error_no_t (*hal_pkt_intf_cnt_clear_func_t)(const uint32 unit, const uint32 id);

typedef clx_error_no_t (*hal_pkt_tx_dbg_cnt_show_func_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*hal_pkt_rx_dbg_cnt_show_func_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*hal_pkt_pp_rsn_get_func_t)(const uint32 unit,
                                                    const uint32 pp_reason,
                                                    const uint32 str_len,
                                                    char *str_pp_reason);

typedef clx_error_no_t (*hal_pkt_pp_rsn_code_get_func_t)(const uint32 unit,
                                                         const char *str_pp_reason,
                                                         uint32 *pp_reason_code);

typedef clx_error_no_t (*hal_pkt_rsn_get_func_t)(const uint32 unit,
                                                 const clx_pkt_rx_reason_t rx_reason_code,
                                                 const uint32 str_len,
                                                 char *str_rx_reason);

typedef clx_error_no_t (*hal_pkt_rsn_code_get_func_t)(const uint32 unit,
                                                      const char *str_rx_reason,
                                                      clx_pkt_rx_reason_t *rx_reason_code);

typedef clx_error_no_t (*hal_pkt_drop_rsn_get_func_t)(const uint32 unit,
                                                      const clx_pkt_drop_reason_t drop_reason,
                                                      const uint32 str_len,
                                                      char *str_drop_reason);

typedef clx_error_no_t (*hal_pkt_pp_to_drop_rsn_func_t)(const uint32 unit,
                                                        const clx_pkt_drop_reason_t drop_reason,
                                                        uint32 *ptr_pp_reason_cnt,
                                                        uint32 *ptr_pp_reason_list);

typedef clx_error_no_t (*hal_pkt_rx_cblist_set_func_t)(const uint32 unit,
                                                       const uint32 flags,
                                                       HAL_PKT_RX_CALLBACK_ACTION_T action,
                                                       void *cookies);

typedef clx_error_no_t (*hal_pkt_netlink_create_func_t)(const uint32 unit,
                                                        const clx_netif_netlink_t *ptr_netlink,
                                                        uint32 *ptr_netlink_id);

typedef clx_error_no_t (*hal_pkt_netlink_destroy_func_t)(const uint32 unit,
                                                         const uint32 netlink_id);

typedef clx_error_no_t (*hal_pkt_netlink_get_func_t)(const uint32 unit,
                                                     const uint32 netlink_id,
                                                     clx_netif_netlink_t *ptr_netlink);

typedef clx_error_no_t (*hal_pkt_queue_cfg_get_func_t)(const uint32 unit,
                                                       clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

typedef clx_error_no_t (*hal_pkt_queue_cfg_set_func_t)(const uint32 unit,
                                                       const clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

/*cia multiplexing functions start*/

typedef clx_error_no_t (*hal_cia_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_cia_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_cia_grp_get_func_t)(const uint32 unit,
                                                 const clx_cia_stage_t stage,
                                                 const uint32 grp_id,
                                                 clx_cia_grp_prof_t *ptr_grp_prof);

typedef clx_error_no_t (*hal_cia_grp_add_func_t)(const uint32 unit,
                                                 const clx_cia_stage_t stage,
                                                 const clx_cia_grp_prof_t *ptr_grp_prof,
                                                 uint32 *ptr_grp_id);
typedef clx_error_no_t (*hal_cia_grp_del_func_t)(const uint32 unit,
                                                 const clx_cia_stage_t stage,
                                                 const uint32 grp_id);
typedef clx_error_no_t (*hal_cia_grp_trav_func_t)(const uint32 unit,
                                                  const clx_cia_stage_t stage,
                                                  const clx_cia_grp_trav_func_t callback,
                                                  void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_exact_grp_get_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 grp_id,
                                                       clx_cia_exact_grp_prof_t *ptr_grp_prof);
typedef clx_error_no_t (*hal_cia_exact_grp_add_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                                                       uint32 *ptr_grp_id);
typedef clx_error_no_t (*hal_cia_exact_grp_del_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 grp_id);
typedef clx_error_no_t (*hal_cia_exact_grp_trav_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t stage,
                                                        const clx_cia_exact_grp_trav_func_t callback,
                                                        void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_udf_entry_get_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 udf_entry_id,
                                                       clx_cia_udf_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_udf_entry_add_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 udf_entry_id,
                                                       const clx_cia_udf_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_udf_entry_del_func_t)(const uint32 unit,
                                                       const clx_cia_stage_t stage,
                                                       const uint32 udf_entry_id);
typedef clx_error_no_t (*hal_cia_udf_entry_trav_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t stage,
                                                        const clx_cia_udf_entry_trav_func_t callback,
                                                        void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_entry_id_info_get_func_t)(const uint32 unit,
                                                           const uint32 entry_id,
                                                           clx_cia_stage_t *ptr_stage,
                                                           uint32 *ptr_grp_id,
                                                           uint32 *ptr_entry_pri);
typedef clx_error_no_t (*hal_cia_entry_id_alloc_func_t)(const uint32 unit,
                                                        const clx_cia_stage_t stage,
                                                        const uint32 grp_id,
                                                        const uint32 entry_pri,
                                                        uint32 *ptr_entry_id);
typedef clx_error_no_t (*hal_cia_entry_id_free_func_t)(const uint32 unit, const uint32 entry_id);
typedef clx_error_no_t (*hal_cia_entry_get_func_t)(const uint32 unit,
                                                   const uint32 entry_id,
                                                   clx_cia_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_entry_add_func_t)(const uint32 unit,
                                                   const uint32 entry_id,
                                                   const clx_cia_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_entry_vld_set_func_t)(const uint32 unit,
                                                       const uint32 entry_id,
                                                       const boolean entry_vld);
typedef clx_error_no_t (*hal_cia_entry_del_func_t)(const uint32 unit, const uint32 entry_id);
typedef clx_error_no_t (*hal_cia_entry_trav_func_t)(const uint32 unit,
                                                    const clx_cia_stage_t stage,
                                                    const uint32 grp_id,
                                                    const clx_cia_entry_trav_func_t callback,
                                                    void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_exact_entry_get_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 grp_id,
                                                         const uint32 entry_id,
                                                         clx_cia_exact_entry_t *ptr_entry_info);
typedef clx_error_no_t (*hal_cia_exact_entry_add_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 grp_id,
                                                         const clx_cia_exact_entry_t *ptr_entry_info,
                                                         uint32 *ptr_entry_id);
typedef clx_error_no_t (*hal_cia_exact_entry_del_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 grp_id,
                                                         const uint32 entry_id);
typedef clx_error_no_t (*hal_cia_exact_entry_trav_func_t)(
    const uint32 unit,
    const clx_cia_stage_t stage,
    const uint32 grp_id,
    const clx_cia_exact_entry_trav_func_t callback,
    void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_exact_entry_id_info_get_func_t)(const uint32 unit,
                                                                 const uint32 entry_id,
                                                                 clx_cia_stage_t *ptr_stage,
                                                                 uint32 *ptr_grp_id);
typedef clx_error_no_t (*hal_cia_rim_alloc_func_t)(const uint32 unit,
                                                   const clx_cia_rim_alloc_t type,
                                                   uint32 *ptr_index);
typedef clx_error_no_t (*hal_cia_rim_free_func_t)(const uint32 unit,
                                                  const clx_cia_rim_alloc_t type,
                                                  const uint32 index);
typedef clx_error_no_t (*hal_cia_rim_act_set_func_t)(const uint32 unit,
                                                     const clx_cia_rim_alloc_t type,
                                                     const uint32 index,
                                                     const void *ptr_action);
typedef clx_error_no_t (*hal_cia_rim_act_get_func_t)(const uint32 unit,
                                                     const clx_cia_rim_alloc_t type,
                                                     const uint32 index,
                                                     void *ptr_action);
typedef clx_error_no_t (*hal_cia_rim_act_trav_func_t)(const uint32 unit,
                                                      const clx_cia_rim_alloc_t type,
                                                      const clx_cia_rim_trav_func_t callback,
                                                      void *ptr_cookie);
typedef clx_error_no_t (*hal_cia_range_add_func_t)(const uint32 unit,
                                                   const clx_cia_stage_t stage,
                                                   const uint32 range_id,
                                                   const clx_cia_range_cfg_t *ptr_range);
typedef clx_error_no_t (*hal_cia_range_del_func_t)(const uint32 unit,
                                                   const clx_cia_stage_t stage,
                                                   const uint32 range_id);
typedef clx_error_no_t (*hal_cia_range_get_func_t)(const uint32 unit,
                                                   const clx_cia_stage_t stage,
                                                   const uint32 range_id,
                                                   clx_cia_range_cfg_t *ptr_range);
typedef clx_error_no_t (*hal_cia_range_trav_func_t)(const uint32 unit,
                                                    const clx_cia_stage_t stage,
                                                    const clx_cia_range_trav_func_t callback,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_cia_range_union_set_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 union_id,
                                                         const uint32 range_bmp);

typedef clx_error_no_t (*hal_cia_range_union_get_func_t)(const uint32 unit,
                                                         const clx_cia_stage_t stage,
                                                         const uint32 union_id,
                                                         uint32 *ptr_range_bmp);

/*cia multiplexing functions end*/

/* security multiplexing functions end */

typedef clx_error_no_t (*hal_sec_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sec_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sec_dos_port_cfg_set_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          const clx_sec_dos_port_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_dos_port_cfg_get_func_t)(const uint32 unit,
                                                          const uint32 port,
                                                          clx_sec_dos_port_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_dos_cfg_set_func_t)(const uint32 unit,
                                                     const clx_sec_dos_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_dos_cfg_get_func_t)(const uint32 unit, clx_sec_dos_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_dos_status_get_func_t)(const uint32 unit,
                                                        clx_sec_dos_status_t *ptr_status);

typedef clx_error_no_t (*hal_sec_dos_status_clear_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sec_dos_cnt_get_func_t)(const uint32 unit, clx_sec_dos_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_sec_dos_cnt_clear_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sec_storm_ctrl_cfg_set_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const clx_sec_storm_ctrl_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_storm_ctrl_cfg_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            clx_sec_storm_ctrl_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_storm_ctrl_stats_get_func_t)(const uint32 unit,
                                                              const uint32 port,
                                                              clx_sec_storm_ctrl_stats_t *ptr_stats);

typedef clx_error_no_t (*hal_sec_storm_ctrl_stats_clear_func_t)(const uint32 unit,
                                                                const uint32 port);

typedef clx_error_no_t (*hal_sec_src_guard_cfg_set_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           const clx_sec_src_guard_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_src_guard_cfg_get_func_t)(const uint32 unit,
                                                           const uint32 port,
                                                           clx_sec_src_guard_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_src_guard_bd_cfg_set_func_t)(
    const uint32 unit,
    const clx_bridge_domain_t bdid,
    const clx_sec_src_guard_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_src_guard_bd_cfg_get_func_t)(const uint32 unit,
                                                              const clx_bridge_domain_t bdid,
                                                              clx_sec_src_guard_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_sec_src_guard_entry_add_func_t)(
    const uint32 unit,
    const clx_sec_src_guard_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_sec_src_guard_entry_del_func_t)(
    const uint32 unit,
    const clx_sec_src_guard_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_sec_src_guard_entry_get_func_t)(const uint32 unit,
                                                             clx_sec_src_guard_entry_t *ptr_entry);

typedef clx_error_no_t (*hal_sec_isolation_grp_cfg_set_func_t)(
    const uint32 unit,
    const uint32 grp_id,
    const clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

typedef clx_error_no_t (*hal_sec_isolation_grp_cfg_get_func_t)(
    const uint32 unit,
    const uint32 grp_id,
    clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

typedef clx_error_no_t (*hal_sec_isolation_port_cfg_set_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const clx_sec_isolation_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_sec_isolation_port_cfg_get_func_t)(
    const uint32 unit,
    const clx_port_t port,
    clx_sec_isolation_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_sec_property_set_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const uint32 type,
                                                      const uint32 param0,
                                                      const uint32 param1);

typedef clx_error_no_t (*hal_sec_property_get_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const uint32 type,
                                                      const uint32 *ptr_param0,
                                                      const uint32 *ptr_param1);

/* security multiplexing functions end */

/* sflow multiplexing functions start */

typedef clx_error_no_t (*hal_sflow_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_sflow_deinit_func_t)(const uint32 unit);

/* sflow multiplexing functions end */

/*switch control multiplexing functions start*/

typedef clx_error_no_t (*hal_swc_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_swc_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_swc_cfg_set_func_t)(const uint32 unit,
                                                 const clx_swc_cfg_t property,
                                                 const uint32 param0,
                                                 const uint32 param1);

typedef clx_error_no_t (*hal_swc_cfg_get_func_t)(const uint32 unit,
                                                 const clx_swc_cfg_t property,
                                                 uint32 *ptr_param0,
                                                 uint32 *ptr_param1);

typedef clx_error_no_t (*hal_swc_chip_temp_get_func_t)(const uint32 unit,
                                                       int32 *ptr_chip_temperature);

typedef clx_error_no_t (*hal_swc_chip_temp_list_get_func_t)(
    const uint32 unit,
    clx_swc_thermal_list_t *ptr_chip_temperature_list);

typedef clx_error_no_t (*hal_swc_pvt_calib_info_get_func_t)(
    const uint32 unit,
    const uint32 inst,
    clx_swc_pvt_calib_info_t *ptr_calib_info);

typedef clx_error_no_t (*hal_swc_hsh_key_set_func_t)(const uint32 unit,
                                                     const clx_swc_hsh_pkt_type_t hash_type,
                                                     const clx_swc_hsh_key_bmp_t key_bitmap);

typedef clx_error_no_t (*hal_swc_hsh_key_get_func_t)(const uint32 unit,
                                                     const clx_swc_hsh_pkt_type_t hash_type,
                                                     clx_swc_hsh_key_bmp_t *ptr_key_bitmap);

typedef clx_error_no_t (*hal_swc_hsh_eng_set_func_t)(const uint32 unit,
                                                     const clx_swc_hsh_pkt_type_t hash_type,
                                                     const clx_swc_hsh_eng_t *hash_engine);

typedef clx_error_no_t (*hal_swc_hsh_eng_get_func_t)(const uint32 unit,
                                                     const clx_swc_hsh_pkt_type_t hash_type,
                                                     clx_swc_hsh_eng_t *hash_engine);

typedef clx_error_no_t (*hal_swc_ts_set_func_t)(const uint32 unit, const clx_swc_ts_t ts_val);

typedef clx_error_no_t (*hal_swc_ts_get_func_t)(const uint32 unit, clx_swc_ts_t *ptr_ts_val);

typedef clx_error_no_t (*hal_swc_ts_offset_set_func_t)(const uint32 unit, const int32 nsec);

typedef clx_error_no_t (*hal_swc_hsh_const_set_func_t)(const uint32 unit,
                                                       const clx_swc_hsh_pkt_type_t hash_type,
                                                       const uint32 hash_const);

typedef clx_error_no_t (*hal_swc_hsh_const_get_func_t)(const uint32 unit,
                                                       const clx_swc_hsh_pkt_type_t hash_type,
                                                       uint32 *ptr_hash_const);

typedef clx_error_no_t (*hal_swc_err_cb_register_func_t)(const uint32 unit,
                                                         const clx_swc_err_type_t error,
                                                         const clx_swc_err_func_t callback,
                                                         void *ptr_cookie);

typedef clx_error_no_t (*hal_swc_err_cb_deregister_func_t)(const uint32 unit,
                                                           const clx_swc_err_type_t error,
                                                           const clx_swc_err_func_t callback,
                                                           void *ptr_cookie);

typedef clx_error_no_t (*hal_swc_notify_cb_register_func_t)(const uint32 unit,
                                                            const clx_swc_notify_category_t category,
                                                            const clx_swc_notify_func_t callback,
                                                            void *ptr_cookie);

typedef clx_error_no_t (*hal_swc_notify_cb_deregister_func_t)(
    const uint32 unit,
    const clx_swc_notify_category_t category,
    const clx_swc_notify_func_t callback,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_swc_dev_info_get_func_t)(const uint32 unit,
                                                      clx_swc_device_info_t *ptr_device_info);

typedef clx_error_no_t (*hal_swc_port_cfg_get_func_t)(const uint32 unit,
                                                      clx_swc_port_cfg_t *ptr_port_config);

typedef clx_error_no_t (*hal_swc_capacity_get_func_t)(const uint32 unit,
                                                      const clx_swc_rsrc_t type,
                                                      const uint32 param,
                                                      uint32 *ptr_size);

typedef clx_error_no_t (*hal_swc_usage_get_func_t)(const uint32 unit,
                                                   const clx_swc_rsrc_t type,
                                                   const uint32 param,
                                                   uint32 *ptr_cnt);

typedef clx_error_no_t (*hal_swc_cso_mode_set_func_t)(const uint32 unit,
                                                      const clx_swc_cso_mode_t mode);

typedef clx_error_no_t (*hal_swc_cso_mode_get_func_t)(const uint32 unit,
                                                      clx_swc_cso_mode_t *ptr_mode);

typedef clx_error_no_t (*hal_swc_excpt_set_func_t)(const uint32 unit,
                                                   const uint32 enable,
                                                   const clx_fwd_action_t action);

typedef clx_error_no_t (*hal_swc_trap_all_set_func_t)(const uint32 unit, const uint32 enable);

typedef clx_error_no_t (*hal_swc_epg_pkt_init_func_t)(hal_swc_epg_pkt_t *ptr_pkt);

typedef clx_error_no_t (*hal_swc_epg_mac_hw_set_func_t)(const uint32 unit,
                                                        const hal_swc_epg_pkt_t *ptr_pkt);

typedef clx_error_no_t (*hal_swc_epg_mac_done_check_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_swc_epg_mac_pkt_stop_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_swc_rsn_act_set_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rx_reason_code,
                                                     const clx_swc_rsn_act_t *rx_reason_action);

typedef clx_error_no_t (*hal_swc_rsn_act_get_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rx_reason_code,
                                                     clx_swc_rsn_act_t *rx_reason_action);

typedef clx_error_no_t (*hal_swc_rsn_pri_set_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rx_reason_code,
                                                     const uint32 priority);

typedef clx_error_no_t (*hal_swc_rsn_pri_get_func_t)(const uint32 unit,
                                                     const clx_pkt_rx_reason_t rx_reason_code,
                                                     uint32 *priority);

typedef clx_error_no_t (*hal_swc_pp_rsn_pri_set_func_t)(const uint32 unit,
                                                        const uint32 pp_reason_code,
                                                        const uint32 priority);

typedef clx_error_no_t (*hal_swc_pp_rsn_pri_get_func_t)(const uint32 unit,
                                                        const uint32 pp_reason_code,
                                                        uint32 *priority);

typedef clx_error_no_t (*hal_swc_max_ts_sec_get_func_t)(const uint32 unit, uint32 *max_ts_sec);

typedef clx_error_no_t (*hal_swc_tod_info_get_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_swc_tbl_name_get_func_t)(const uint32 unit,
                                                      const uint32 tbl_id,
                                                      const uint32 tbl_name_len,
                                                      char *ptr_tbl_name);

typedef clx_error_no_t (*hal_swc_str_name_get_func_t)(const uint32 unit,
                                                      const clx_swc_data_type_t data_type,
                                                      const uint32 index,
                                                      const uint32 str_len,
                                                      char *str_name);

typedef clx_error_no_t (*hal_swc_chip_pll_status_get_func_t)(
    const uint32 unit,
    clx_swc_chip_pll_status_t *ptr_pll_status);

typedef clx_error_no_t (*hal_swc_reg_tbl_info_get_func_t)(const uint32 unit,
                                                          hal_swc_tbl_type_t tbl_type,
                                                          uint32 *ptr_tbl_list);

typedef clx_error_no_t (*hal_swc_skip_rx_crc_check_set_func_t)(const uint32 unit,
                                                               const uint32 enable);

typedef clx_error_no_t (*hal_swc_skip_rx_crc_check_get_func_t)(const uint32 unit,
                                                               uint32 *ptr_enable);

typedef clx_error_no_t (*hal_swc_runt_pkt_fwd_set_func_t)(const uint32 unit, const uint32 enable);

typedef clx_error_no_t (*hal_swc_runt_pkt_fwd_get_func_t)(const uint32 unit, uint32 *ptr_enable);
typedef clx_error_no_t (*hal_swc_hsh_path_get_func_t)(const uint32 unit,
                                                      const clx_swc_hsh_pkt_type_t hash_type,
                                                      const clx_swc_flow_hsh_key_t *ptr_hash_key,
                                                      const uint32 id,
                                                      clx_swc_hsh_path_rslt_info_t *ptr_rslt);

typedef clx_error_no_t (*hal_swc_hsh_path_key_get_func_t)(const uint32 unit,
                                                          const clx_swc_hsh_pkt_type_t hash_type,
                                                          const clx_swc_hsh_path_pkt_info_t pkt_info,
                                                          clx_swc_hsh_key_bmp_t *key_bitmap);
/*switch control multiplexing functions end*/

/* qos multiplexing functions start */

typedef clx_error_no_t (*hal_qos_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_qos_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_qos_prof_create_func_t)(const uint32 unit,
                                                     const clx_dir_t direction,
                                                     const clx_qos_mapping_type_t mapping_type,
                                                     const uint32 profileId);

typedef clx_error_no_t (*hal_qos_prof_destroy_func_t)(const uint32 unit,
                                                      const clx_dir_t direction,
                                                      const clx_qos_mapping_type_t mapping_type,
                                                      const uint32 profileId);

typedef clx_error_no_t (*hal_qos_prof_set_func_t)(const uint32 unit,
                                                  const clx_dir_t direction,
                                                  const clx_qos_mapping_type_t mapping_type,
                                                  const uint32 profileId,
                                                  const clx_qos_mapping_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_qos_prof_get_func_t)(const uint32 unit,
                                                  const clx_dir_t direction,
                                                  const clx_qos_mapping_type_t mapping_type,
                                                  const uint32 profileId,
                                                  clx_qos_mapping_cfg_t *ptr_cfg);

/* qos multiplexing functions end */

/* meter multiplexing functions start */
typedef clx_error_no_t (*hal_meter_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_meter_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_meter_create_func_t)(const uint32 unit,
                                                  const clx_meter_cfg_t *ptr_cfg,
                                                  uint32 *ptr_meter_id);

typedef clx_error_no_t (*hal_meter_destroy_func_t)(const uint32 unit, const uint32 meter_id);

typedef clx_error_no_t (*hal_meter_get_func_t)(const uint32 unit,
                                               const uint32 meter_id,
                                               clx_meter_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_meter_param_set_func_t)(const uint32 unit,
                                                     const uint32 meter_id,
                                                     const clx_meter_param_t *ptr_param);

/* meter multiplexing functions end */

/* stat multiplexing functions start */
typedef clx_error_no_t (*hal_stat_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_port_cnt_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_stat_port_t type,
                                                       uint64 *ptr_cnt);

typedef clx_error_no_t (*hal_stat_port_cnt_clear_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const clx_stat_port_t type);

typedef clx_error_no_t (*hal_stat_tm_cnt_get_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     const clx_tm_handler_t handler,
                                                     const clx_stat_tm_t type,
                                                     clx_stat_tm_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_stat_tm_cnt_clear_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       const clx_stat_tm_t type);

typedef clx_error_no_t (*hal_stat_queue_cnt_get_func_t)(const uint32 unit,
                                                        const clx_tm_handler_t handler,
                                                        clx_stat_tm_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_stat_queue_cnt_clear_func_t)(const uint32 unit,
                                                          const clx_tm_handler_t handler);

typedef clx_error_no_t (*hal_stat_dist_cnt_create_func_t)(const uint32 unit, uint32 *ptr_cnt_id);

typedef clx_error_no_t (*hal_stat_dist_cnt_destroy_func_t)(const uint32 unit, const uint32 cnt_id);

typedef clx_error_no_t (*hal_stat_dist_cnt_get_func_t)(const uint32 unit,
                                                       const uint32 cnt_id,
                                                       clx_stat_dist_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_stat_dist_cnt_clear_func_t)(const uint32 unit, const uint32 cnt_id);

typedef clx_error_no_t (*hal_stat_srv_cnt_create_func_t)(const uint32 unit,
                                                         const clx_stat_srv_cnt_cfg_t *ptr_cfg,
                                                         uint32 *ptr_cnt_id);

typedef clx_error_no_t (*hal_stat_srv_cnt_destroy_func_t)(const uint32 unit, uint32 cnt_id);

typedef clx_error_no_t (*hal_stat_srv_cnt_get_func_t)(const uint32 unit,
                                                      const uint32 cnt_id,
                                                      clx_stat_srv_cnt_t *ptr_cnt);

typedef clx_error_no_t (*hal_stat_srv_cnt_clear_func_t)(const uint32 unit, const uint32 cnt_id);

typedef clx_error_no_t (*hal_stat_srv_cnt_cfg_get_func_t)(const uint32 unit,
                                                          const uint32 cnt_id,
                                                          clx_stat_srv_cnt_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_stat_port_rate_get_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const clx_stat_rate_type_t type,
                                                        uint64 *ptr_rate);

typedef clx_error_no_t (*hal_stat_port_rate_type_get_func_t)(const uint32 unit,
                                                             const clx_stat_port_t type,
                                                             clx_stat_rate_type_t *rate_type);

typedef clx_error_no_t (*hal_stat_cnt_refresh_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_dbg_cnt_show_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const uint32 stage_bmp,
                                                       const uint32 flags);

typedef clx_error_no_t (*hal_stat_dbg_cnt_clear_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_cnt_hw_idx_get_func_t)(const uint32 unit,
                                                         const uint32 sw_cnt_id,
                                                         const hal_stat_hw_type_t cnt_type,
                                                         const hal_stat_pp_obj_type_t pp_obj_type,
                                                         uint32 *ptr_hw_cnt_idx);

typedef clx_error_no_t (*hal_stat_pp_bank_id_get_func_t)(const uint32 unit,
                                                         const uint32 hw_cnt_id,
                                                         const clx_stat_srv_cnt_mode_t mode,
                                                         uint32 *ptr_bank_id,
                                                         uint32 *ptr_sw_bmap_idx_of_bank);

typedef clx_error_no_t (*hal_stat_reason_cnt_get_func_t)(const uint32 unit,
                                                         const clx_pkt_rx_reason_t rx_reason_code,
                                                         uint64 *ptr_cnt);

typedef clx_error_no_t (
    *hal_stat_reason_cnt_clear_func_t)(const uint32 unit, const clx_pkt_rx_reason_t rx_reason_code);

typedef clx_error_no_t (*hal_stat_hw_reason_cnt_get_func_t)(const uint32 unit,
                                                            const clx_pkt_hw_reason_t rsn_code,
                                                            uint64 *ptr_cnt);

typedef clx_error_no_t (*hal_stat_hw_reason_cnt_clear_func_t)(const uint32 unit,
                                                              const clx_pkt_hw_reason_t rsn_code);

#ifdef CLX_STAT_EN_HPC_CNT
typedef clx_error_no_t (*hal_stat_hpc_create_func_t)(const uint32 unit,
                                                     const clx_stat_hpc_cfg_t cfg);

typedef clx_error_no_t (*hal_stat_hpc_destroy_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stat_hpc_dequeue_func_t)(const uint32 unit,
                                                      clx_stat_hpc_cnt_t *ptr_hpc_cnt_node);
#endif /* End of CLX_STAT_EN_HPC_CNT */

typedef clx_error_no_t (*hal_stat_hrm_watermark_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const clx_tm_handler_t handler,
                                                            uint32 *ptr_cnt);

typedef clx_error_no_t (*hal_stat_hrm_watermark_clear_func_t)(const uint32 unit,
                                                              const uint32 port,
                                                              const clx_tm_handler_t handler);

typedef clx_error_no_t (*hal_stat_hrm_occupancy_get_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const clx_tm_handler_t handler,
                                                            uint32 *ptr_occupancy);
/* stat multiplexing functions end */

/* tm multiplexing functions start */
typedef clx_error_no_t (*hal_tm_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_tm_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_tm_handler_create_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_type_t handler_type,
                                                       const uint32 queue_id,
                                                       clx_tm_handler_t *ptr_handler);

typedef clx_error_no_t (*hal_tm_handler_destroy_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const clx_tm_handler_t handler);

typedef clx_error_no_t (*hal_tm_sched_shaper_set_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const clx_tm_handler_t handler,
                                                         const clx_tm_shaper_t *ptr_bandwidth);

typedef clx_error_no_t (*hal_tm_sched_shaper_get_func_t)(const uint32 unit,
                                                         const uint32 port,
                                                         const clx_tm_handler_t handler,
                                                         clx_tm_shaper_t *ptr_bandwidth);

typedef clx_error_no_t (*hal_tm_sched_mode_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       const clx_tm_sched_cfg_t sched_cfg);

typedef clx_error_no_t (*hal_tm_sched_mode_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       clx_tm_sched_cfg_t *ptr_sched_cfg);

typedef clx_error_no_t (*hal_tm_cfg_set_func_t)(const uint32 unit,
                                                const uint32 port,
                                                const clx_tm_handler_t handler,
                                                const clx_tm_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_tm_cfg_get_func_t)(const uint32 unit,
                                                const uint32 port,
                                                const clx_tm_handler_t handler,
                                                clx_tm_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_tm_pfc_mapping_set_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const uint32 queue,
                                                        const clx_tm_pfc_mapping_cfg_t *ptr_pfc);

typedef clx_error_no_t (*hal_tm_pfc_mapping_get_func_t)(const uint32 unit,
                                                        const uint32 port,
                                                        const uint32 queue,
                                                        clx_tm_pfc_mapping_cfg_t *ptr_pfc);

typedef clx_error_no_t (*hal_tm_buf_usage_get_func_t)(const uint32 unit,
                                                      const uint32 port,
                                                      const clx_tm_handler_t handler,
                                                      const clx_tm_buf_stat_type_t buf_usage_type,
                                                      uint32 *ptr_usage);

typedef clx_error_no_t (*hal_tm_buf_watermark_get_func_t)(
    const uint32 unit,
    const uint32 port,
    const clx_tm_handler_t handler,
    const clx_tm_buf_stat_type_t buf_watermark_type,
    uint32 *ptr_watermark);

typedef clx_error_no_t (*hal_tm_buf_watermark_clear_func_t)(
    const uint32 unit,
    const uint32 port,
    const clx_tm_handler_t handler,
    const clx_tm_buf_stat_type_t buf_watermark_type);

typedef clx_error_no_t (*hal_tm_reg_dump_func_t)(const uint32 unit, const uint32 flags);

typedef clx_error_no_t (*hal_pkt_reg_show_func_t)(const uint32 unit,
                                                  const uint32 flags,
                                                  const void *cookies);

typedef clx_error_no_t (*hal_tm_pfcwd_cb_register_func_t)(
    const uint32 unit,
    const clx_tm_pfcwd_handle_func_t notify_function,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_pfcwd_cb_deregister_func_t)(
    const uint32 unit,
    const clx_tm_pfcwd_handle_func_t notify_function,
    void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_pfcwd_set_func_t)(const uint32 unit,
                                                  const clx_port_t port,
                                                  const uint32 queue,
                                                  const clx_tm_pfcwd_cfg_t *ptr_entry);

typedef clx_error_no_t (*hal_tm_pfcwd_get_func_t)(const uint32 unit,
                                                  const clx_port_t port,
                                                  const uint32 queue,
                                                  clx_tm_pfcwd_cfg_t *ptr_entry);

typedef clx_error_no_t (*hal_tm_pfcwd_state_get_func_t)(const uint32 unit,
                                                        const clx_port_t port,
                                                        const uint32 queue,
                                                        clx_tm_pfcwd_state_t *ptr_state);

typedef clx_error_no_t (*hal_tm_tc_prof_set_func_t)(const uint32 unit,
                                                    const uint32 profile_id,
                                                    const clx_tm_tc_prof_t *profile);

typedef clx_error_no_t (*hal_tm_tc_prof_get_func_t)(const uint32 unit,
                                                    const uint32 profile_id,
                                                    clx_tm_tc_prof_t *profile);

typedef clx_error_no_t (*HAL_TM_SETTCCUTTHROUGH_FUNC_T)(const uint32 unit,
                                                        const uint32 tc,
                                                        const boolean enable);

typedef clx_error_no_t (*HAL_TM_GETTCCUTTHROUGH_FUNC_T)(const uint32 unit,
                                                        const uint32 tc,
                                                        boolean *enable);

typedef clx_error_no_t (*hal_tm_buf_prof_create_func_t)(const uint32 unit,
                                                        const clx_tm_buf_prof_type_t buf_prof_type,
                                                        const uint32 profile_id);

typedef clx_error_no_t (*hal_tm_buf_prof_destroy_func_t)(const uint32 unit,
                                                         const clx_tm_buf_prof_type_t buf_prof_type,
                                                         const uint32 profile_id);

typedef clx_error_no_t (*hal_tm_buf_prof_set_func_t)(const uint32 unit,
                                                     const uint32 profile_id,
                                                     const clx_tm_buf_prof_t *profile);

typedef clx_error_no_t (*hal_tm_buf_prof_get_func_t)(const uint32 unit,
                                                     const uint32 profile_id,
                                                     clx_tm_buf_prof_t *profile);

typedef clx_error_no_t (*hal_tm_buf_cfg_set_func_t)(const uint32 unit,
                                                    const uint32 port,
                                                    const clx_tm_handler_t handler,
                                                    const clx_tm_buf_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_tm_buf_cfg_get_func_t)(const uint32 unit,
                                                    const uint32 port,
                                                    const clx_tm_handler_t handler,
                                                    clx_tm_buf_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_tm_wred_prof_create_func_t)(const uint32 unit,
                                                         const uint32 profile_id);

typedef clx_error_no_t (*hal_tm_wred_prof_destroy_func_t)(const uint32 unit,
                                                          const uint32 profile_id);
typedef clx_error_no_t (*hal_tm_wred_prof_set_func_t)(const uint32 unit,
                                                      const uint32 profile_id,
                                                      const clx_tm_wred_prof_t *ptr_wred_profile);

typedef clx_error_no_t (*hal_tm_wred_prof_get_func_t)(const uint32 unit,
                                                      const uint32 profile_id,
                                                      clx_tm_wred_prof_t *ptr_wred_profile);

typedef clx_error_no_t (*hal_tm_wred_cfg_set_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     const clx_tm_handler_t handler,
                                                     const clx_tm_wred_cfg_t *ptr_wred_cfg);

typedef clx_error_no_t (*hal_tm_wred_cfg_get_func_t)(const uint32 unit,
                                                     const uint32 port,
                                                     const clx_tm_handler_t handler,
                                                     clx_tm_wred_cfg_t *ptr_wred_cfg);

typedef clx_error_no_t (*hal_tm_histogram_cfg_set_func_t)(const uint32 unit,
                                                          const clx_tm_histogram_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_tm_histogram_cfg_get_func_t)(const uint32 unit,
                                                          clx_tm_histogram_cfg_t *ptr_config);

typedef clx_error_no_t (*hal_tm_histogram_cb_register_func_t)(const uint32 unit,
                                                              const uint32 port,
                                                              const clx_tm_histogram_cb_t func,
                                                              void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_histogram_cb_deregister_func_t)(const uint32 unit,
                                                                const uint32 port,
                                                                const clx_tm_histogram_cb_t func,
                                                                void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_histogram_cnt_clear_func_t)(const uint32 unit,
                                                            const uint32 port,
                                                            const clx_tm_handler_t handler);

typedef clx_error_no_t (*hal_tm_tcb_match_set_func_t)(const uint32 unit,
                                                      const clx_tm_tcb_match_type_t type,
                                                      const clx_tm_tcb_match_t *ptr_match);

typedef clx_error_no_t (*hal_tm_tcb_match_get_func_t)(const uint32 unit,
                                                      const clx_tm_tcb_match_type_t type,
                                                      clx_tm_tcb_match_t *ptr_match);

typedef clx_error_no_t (*hal_tm_tcb_cfg_set_func_t)(const uint32 unit,
                                                    const clx_tm_tcb_cfg_type_t type,
                                                    const uint32 value);

typedef clx_error_no_t (*hal_tm_tcb_cfg_get_func_t)(const uint32 unit,
                                                    const clx_tm_tcb_cfg_type_t type,
                                                    uint32 *ptr_value);

typedef clx_error_no_t (*hal_tm_tcb_cb_register_func_t)(const uint32 unit,
                                                        const clx_tm_tcb_func_t func,
                                                        void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_tcb_cb_deregister_func_t)(const uint32 unit,
                                                          const clx_tm_tcb_func_t func,
                                                          void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_mburst_prof_create_func_t)(const uint32 unit, const uint32 prof_id);

typedef clx_error_no_t (*hal_tm_mburst_prof_destroy_func_t)(const uint32 unit,
                                                            const uint32 prof_id);

typedef clx_error_no_t (*hal_tm_mburst_prof_set_func_t)(const uint32 unit,
                                                        const uint32 prof_id,
                                                        const clx_tm_mburst_prof_t *ptr_prof);

typedef clx_error_no_t (*hal_tm_mburst_prof_get_func_t)(const uint32 unit,
                                                        const uint32 prof_id,
                                                        clx_tm_mburst_prof_t *ptr_prof);

typedef clx_error_no_t (*hal_tm_mburst_cfg_set_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       const clx_tm_mburst_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_tm_mburst_cfg_get_func_t)(const uint32 unit,
                                                       const uint32 port,
                                                       const clx_tm_handler_t handler,
                                                       clx_tm_mburst_cfg_t *ptr_cfg);

typedef clx_error_no_t (*hal_tm_mburst_callback_register_func_t)(const uint32 unit,
                                                                 const clx_tm_mburst_func_t func,
                                                                 void *ptr_cookie);

typedef clx_error_no_t (*hal_tm_mburst_callback_deregister_func_t)(const uint32 unit,
                                                                   const clx_tm_mburst_func_t func,
                                                                   void *ptr_cookie);

/* tm multiplexing functions end */

/* MPLS multiplexing functions */
typedef clx_error_no_t (*hal_mpls_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_mpls_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_mpls_vpn_id_create_fun_t)(const uint32 unit,
                                                       const clx_mpls_vpn_info_t *vpn_info,
                                                       uint32 *vpn_id);

typedef clx_error_no_t (*hal_mpls_vpn_id_destroy_fun_t)(const uint32 unit, const clx_port_t port);
typedef clx_error_no_t (*hal_mpls_vpn_id_get_fun_t)(const uint32 unit,
                                                    const clx_mpls_get_type_t type,
                                                    clx_mpls_vpn_info_t *ptr_key);
typedef clx_error_no_t (*hal_mpls_lsp_port_create_fun_t)(const uint32 unit,
                                                         clx_mpls_lsp_info_t *ptr_lsp_port);

typedef clx_error_no_t (*hal_mpls_lsp_port_destroy_fun_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_mpls_lsp_port_get_fun_t)(const uint32 unit,
                                                      const clx_mpls_get_type_t type,
                                                      clx_mpls_lsp_info_t *ptr_lsp_port);

typedef clx_error_no_t (*hal_mpls_encap_add_fun_t)(const uint32 unit,
                                                   const clx_mpls_encap_info_t *ptr_init);

typedef clx_error_no_t (*hal_mpls_encap_del_fun_t)(const uint32 unit, const clx_port_t port);

typedef clx_error_no_t (*hal_mpls_encap_get_fun_t)(const uint32 unit,
                                                   clx_mpls_encap_info_t *ptr_init);

typedef clx_error_no_t (*hal_mpls_decap_add_fun_t)(const uint32 unit,
                                                   const clx_mpls_decap_info_t *ptr_term);

typedef clx_error_no_t (*hal_mpls_decap_del_fun_t)(const uint32 unit,
                                                   const clx_mpls_match_info_t *ptr_key);

typedef clx_error_no_t (*hal_mpls_decap_get_fun_t)(const uint32 unit,
                                                   clx_mpls_decap_info_t *ptr_term);

typedef clx_error_no_t (*hal_mpls_transit_add_fun_t)(const uint32 unit,
                                                     const clx_mpls_switch_info_t *ptr_nhlfe);

typedef clx_error_no_t (*hal_mpls_transit_del_fun_t)(const uint32 unit,
                                                     const clx_mpls_match_info_t *ptr_key);

typedef clx_error_no_t (*hal_mpls_transit_get_fun_t)(const uint32 unit,
                                                     clx_mpls_switch_info_t *ptr_nh_info);

typedef clx_error_no_t (*hal_mpls_pw_port_create_fun_t)(const uint32 unit,
                                                        clx_mpls_pw_port_t *ptr_pw_port);

typedef clx_error_no_t (*hal_mpls_pw_port_destroy_fun_t)(const uint32 unit,
                                                         const clx_port_t pw_port);

typedef clx_error_no_t (*hal_mpls_pw_port_get_fun_t)(const uint32 unit,
                                                     const clx_mpls_get_type_t type,
                                                     clx_mpls_pw_port_t *ptr_pw);

typedef clx_error_no_t (*hal_mpls_pw_add_fun_t)(const uint32 unit,
                                                const clx_mpls_pw_info_t *ptr_pw);

typedef clx_error_no_t (*hal_mpls_pw_del_fun_t)(const uint32 unit, const clx_port_t pw_port);

typedef clx_error_no_t (*hal_mpls_pw_get_fun_t)(const uint32 unit, clx_mpls_pw_info_t *ptr_pw);

typedef clx_error_no_t (*hal_mpls_vpws_add_fun_t)(const uint32 unit,
                                                  const clx_mpls_vpws_t *ptr_vpws);

typedef clx_error_no_t (*hal_mpls_vpws_del_fun_t)(const uint32 unit, const clx_port_t pw_port);

typedef clx_error_no_t (*hal_mpls_vpws_get_fun_t)(const uint32 unit, clx_mpls_vpws_t *ptr_vpws);

typedef clx_error_no_t (*hal_mpls_lbl_range_set_fun_t)(const uint32 unit,
                                                       const clx_mpls_lbl_range_t lbl_range);

typedef clx_error_no_t (*hal_mpls_lbl_range_get_fun_t)(const uint32 unit,
                                                       clx_mpls_lbl_range_t *lbl_range);

typedef clx_error_no_t (*hal_mpls_encap_trav_fun_t)(const uint32 unit,
                                                    const clx_mpls_encap_trav_fun_t cb,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_mpls_transit_trav_fun_t)(const uint32 unit,
                                                      const clx_mpls_transit_trav_func_t cb,
                                                      void *ptr_cookie);

typedef clx_error_no_t (*hal_mpls_decap_trav_fun_t)(const uint32 unit,
                                                    const clx_mpls_decap_trav_func_t cb,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*hal_mpls_pw_trav_fun_t)(const uint32 unit,
                                                 const clx_mpls_pw_trav_func_t cb,
                                                 void *ptr_cookie);
/* MPLS multiplexing functions end */

/* Stacking multiplexing functions */
typedef clx_error_no_t (*hal_stk_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stk_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_stk_my_chip_id_set_func_t)(const uint32 unit, const uint32 chip);

typedef clx_error_no_t (*hal_stk_my_chip_id_get_func_t)(const uint32 unit, uint32 *ptr_chip);

typedef clx_error_no_t (*hal_stk_neighbor_chip_id_set_func_t)(const uint32 unit,
                                                              const uint32 path,
                                                              const uint32 chip);

typedef clx_error_no_t (*hal_stk_neighbor_chip_id_get_func_t)(const uint32 unit,
                                                              const uint32 path,
                                                              uint32 *ptr_chip);

typedef clx_error_no_t (*hal_stk_cutoff_chip_id_set_func_t)(const uint32 unit,
                                                            const uint32 path,
                                                            const uint32 chip);

typedef clx_error_no_t (*hal_stk_cutoff_chip_id_get_func_t)(const uint32 unit,
                                                            const uint32 path,
                                                            uint32 *ptr_chip);

typedef clx_error_no_t (*hal_stk_stacking_port_add_func_t)(const uint32 unit,
                                                           const uint32 path,
                                                           const uint32 port);

typedef clx_error_no_t (*hal_stk_stacking_port_del_func_t)(const uint32 unit,
                                                           const uint32 path,
                                                           const uint32 port);

typedef clx_error_no_t (*hal_stk_stacking_port_get_func_t)(const uint32 unit,
                                                           const uint32 path,
                                                           clx_port_bitmap_t *ptr_port_list);

typedef clx_error_no_t (*hal_stk_path_to_remote_chip_set_func_t)(const uint32 unit,
                                                                 const uint32 path,
                                                                 const uint32 chip);
typedef clx_error_no_t (*hal_stk_stacking_port_to_cpu_add_func_t)(const uint32 unit,
                                                                  const uint32 cpu_path,
                                                                  const uint32 port);

typedef clx_error_no_t (*hal_stk_stacking_port_to_cpu_del_func_t)(const uint32 unit,
                                                                  const uint32 cpu_path,
                                                                  const uint32 port);

typedef clx_error_no_t (*hal_stk_stacking_port_to_cpu_get_func_t)(const uint32 unit,
                                                                  const uint32 cpu_path,
                                                                  clx_port_bitmap_t *ptr_port_list);

typedef clx_error_no_t (*hal_stk_cpu_path_to_remote_chip_set_func_t)(const uint32 unit,
                                                                     const uint32 cpu_path,
                                                                     const uint32 chip);

typedef clx_error_no_t (*hal_stk_dpi_port_get_func_t)(const uint32 unit,
                                                      clx_port_bitmap_t *ptr_port_list);

typedef clx_error_no_t (*hal_stk_dpi_port_add_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_stk_dpi_port_del_func_t)(const uint32 unit, const uint32 port);

typedef clx_error_no_t (*hal_stk_dil_entry_set_func_t)(const uint32 unit,
                                                       const uint32 di,
                                                       const clx_stk_dil_t *ptr_dil_entry);

typedef clx_error_no_t (*hal_stk_dil_entry_get_func_t)(const uint32 unit,
                                                       const uint32 di,
                                                       clx_stk_dil_t *ptr_dil_entry);

typedef clx_error_no_t (*hal_stk_ext_chip_di_info_get_func_t)(const uint32 unit,
                                                              const uint32 chip,
                                                              uint32 *ptr_di_base,
                                                              uint32 *ptr_di_num);

typedef clx_error_no_t (*hal_stk_chip_mode_get_func_t)(const uint32 unit, uint32 *ptr_chip_mode);

typedef clx_error_no_t (*hal_stk_chip_cfg_set_func_t)(const uint32 unit,
                                                      const clx_stk_chip_cfg_type_t cfg_type,
                                                      const clx_stk_chip_cfg_t *ptr_chip_cfg);

typedef clx_error_no_t (*hal_stk_chip_cfg_get_func_t)(const uint32 unit,
                                                      const clx_stk_chip_cfg_type_t cfg_type,
                                                      clx_stk_chip_cfg_t *ptr_chip_cfg);

typedef clx_error_no_t (*hal_stk_fab_port_add_func_t)(const uint32 unit,
                                                      const clx_stk_port_cfg_type_t cfg_type,
                                                      const clx_stk_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_stk_fab_port_del_func_t)(const uint32 unit,
                                                      const clx_stk_port_cfg_type_t cfg_type,
                                                      const clx_stk_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_stk_fab_port_get_func_t)(const uint32 unit,
                                                      const clx_stk_port_cfg_type_t cfg_type,
                                                      clx_stk_port_cfg_t *ptr_port_cfg);

typedef clx_error_no_t (*hal_stk_path_remote_map_set_func_t)(const uint32 unit,
                                                             const clx_stk_path_cfg_type_t cfg_type,
                                                             const clx_stk_path_cfg_t *ptr_path_cfg);
/* Stacking multiplexing functions end */

/* TELM multiplexing functions */
typedef clx_error_no_t (*hal_telm_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_telm_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_telm_notify_cb_register_func_t)(const uint32 unit,
                                                             const clx_telm_irq_type_t irq_type,
                                                             const void *callback,
                                                             void *ptr_cookie);

typedef clx_error_no_t (*hal_telm_notify_cb_deregister_func_t)(const uint32 unit,
                                                               const clx_telm_irq_type_t irq_type,
                                                               const void *callback,
                                                               void *ptr_cookie);

typedef clx_error_no_t (*hal_telm_cfg_get_func_t)(const uint32 unit,
                                                  const clx_telm_cfg_t cfg,
                                                  clx_telm_cfg_param_t *ptr_param);

typedef clx_error_no_t (*hal_telm_cfg_set_func_t)(const uint32 unit,
                                                  const clx_telm_cfg_t cfg,
                                                  const clx_telm_cfg_param_t *ptr_param);

typedef clx_error_no_t (*hal_telm_int_prof_get_func_t)(const uint32 unit,
                                                       const uint32 profile_id,
                                                       clx_telm_int_prof_t *ptr_cfg);

typedef clx_error_no_t (*hal_telm_int_prof_set_func_t)(const uint32 unit,
                                                       const uint32 profile_id,
                                                       const clx_telm_int_prof_t *ptr_cfg);

typedef clx_error_no_t (*hal_telm_int_glb_get_func_t)(const uint32 unit,
                                                      clx_telm_int_domain_t *ptr_domain_cfg,
                                                      clx_telm_int_device_t *ptr_device_cfg);

typedef clx_error_no_t (*hal_telm_int_glb_set_func_t)(const uint32 unit,
                                                      const clx_telm_int_domain_t *ptr_domain_cfg,
                                                      const clx_telm_int_device_t *ptr_device_cfg);

typedef clx_error_no_t (*hal_telm_ioam_cfg_get_func_t)(const uint32 unit,
                                                       clx_telm_ioam_cfg_t *ptr_ioam_cfg);

typedef clx_error_no_t (*hal_telm_ioam_cfg_set_func_t)(const uint32 unit,
                                                       const clx_telm_ioam_cfg_t *ptr_ioam_cfg);

typedef clx_error_no_t (*hal_telm_mod_cfg_get_func_t)(const uint32 unit,
                                                      clx_telm_mod_cfg_t *ptr_mod_cfg);

typedef clx_error_no_t (*hal_telm_mod_cfg_set_func_t)(const uint32 unit,
                                                      const clx_telm_mod_cfg_t *ptr_mod_cfg);

typedef clx_error_no_t (*hal_telm_ifa_cfg_get_func_t)(const uint32 unit,
                                                      clx_telm_ifa_cfg_t *ptr_ifa_cfg);

typedef clx_error_no_t (*hal_telm_ifa_cfg_set_func_t)(const uint32 unit,
                                                      const clx_telm_ifa_cfg_t *ptr_ifa_cfg);

/* TELM multiplexing functions end */

/* ECC multiplexing functions start */

typedef clx_error_no_t (*hal_ecc_set_cfg_func_t)(const uint32 unit,
                                                 const clx_ecc_module_type_t module_type,
                                                 const uint32 tbl_type,
                                                 const clx_ecc_cfg_t *ptr_ecc_cfg);

typedef clx_error_no_t (*hal_ecc_get_cfg_func_t)(const uint32 unit,
                                                 const clx_ecc_module_type_t module_type,
                                                 const uint32 tbl_type,
                                                 clx_ecc_cfg_t *ptr_ecc_cfg);

/* Debug dump multiplexing functions */
typedef clx_error_no_t (*hal_db_dump_func_t)(const uint32 unit, const uint32 flags);  /* flags is
                                                                                         used to
                                                                                         indicate
                                                                                         which db */

typedef clx_error_no_t (*hal_reg_dump_func_t)(const uint32 unit, const uint32 flags); /* flags
                                                                                         is used to
                                                                                         indicate
                                                                                         which
                                                                                         reg/table
                                                                                       */

/* ECPU multiplexing functions */
typedef clx_error_no_t (*hal_ecpu_init_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_deinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_hwinit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_reboot_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_stop_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_force_stop_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_start_func_t)(const uint32 unit, const uint32 index);

typedef clx_error_no_t (*hal_ecpu_readmem_func_t)(const uint32 unit,
                                                  const uint32 addr,
                                                  const uint32 len,
                                                  uint32 *pbuf);

typedef clx_error_no_t (*hal_ecpu_diag_log_read_func_t)(const uint32 unit, char **ppbuf);

typedef clx_error_no_t (*hal_ecpu_fw_flash_update_func_t)(const uint32 unit,
                                                          const char *path,
                                                          const hal_ecpu_flash_update_type_t type);

typedef clx_error_no_t (*hal_ecpu_fw_path_set_func_t)(const uint32 unit, const char *path);

typedef clx_error_no_t (*hal_ecpu_updatesramfw_func_t)(const uint32 unit, char *path);

typedef clx_error_no_t (*hal_ecpu_updatesramrawfw_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_headroom_watermark_clr_func_t)(const uint32 unit,
                                                                 const uint32 port,
                                                                 const uint32 queue);

typedef boolean (*hal_ecpu_headroom_is_running_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_intr_register_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_intr_unregister_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_intr_to_ecpu_trigger_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_from_ecpu_intr_clr_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_from_ecpu_intr_enable_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_diag_log_buf_info_get_func_t)(hal_ecpu_diag_buf_info_t *buf_info);

typedef clx_error_no_t (*hal_ecpu_dtcm_addr_get_func_t)(uint64 *addr);

typedef clx_error_no_t (*hal_ecpu_dtcm_on_chain_addr_get_func_t)(uint64 *addr);

typedef clx_error_no_t (*hal_ecpu_itcm_addr_get_func_t)(uint64 *addr);

typedef clx_error_no_t (*hal_ecpu_itcm_on_chain_addr_get_func_t)(uint64 *addr);

typedef clx_error_no_t (*hal_ecpu_fw_feature_is_supported_func_t)(
    const uint32 unit,
    const clx_ecpu_fw_feature_type_t feature_type);

typedef clx_error_no_t (*hal_ecpu_fw_dflt_set_func_t)(const uint32 index);

typedef clx_error_no_t (*hal_ecpu_fw_dflt_get_func_t)(uint32 *index);

typedef clx_error_no_t (*hal_ecpu_fw_running_get_func_t)(uint32 *index);

typedef clx_error_no_t (*hal_ecpu_fw_info_trav_func_t)(const clx_ecpu_fw_trav_func_t callback,
                                                       void *ptr_cookie);

typedef clx_error_no_t (*hal_ecpu_port_limit_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecpu_ring_buf_handler_init_func_t)(
    const uint32 unit,
    hal_ecpu_ring_buffer_control_t *pring);

/* TOD multiplexing functions */
typedef clx_error_no_t (*hal_tod_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_hw_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_interrupt_register_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_interrupt_unregister_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_tod_pps_interrupt_restart_func_t)(const uint32 unit, void *ptr);
typedef clx_error_no_t (*hal_tod_current_value_get_func_t)(const uint32 unit, uint32 *buf);

/* BFD multiplexing functions */
typedef clx_error_no_t (*hal_bfd_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_bfd_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_bfd_session_create_func_t)(const uint32 unit,
                                                        clx_bfd_session_cfg_info_t *cfg_session);
typedef clx_error_no_t (*hal_bfd_session_delete_func_t)(const uint32 unit, const uint32 session_id);
typedef clx_error_no_t (*hal_bfd_session_update_func_t)(const uint32 unit,
                                                        clx_bfd_session_cfg_info_t *cfg_session);
typedef clx_error_no_t (*hal_bfd_all_session_delete_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_bfd_session_cfg_info_get_func_t)(
    const uint32 unit,
    const uint32 session_id,
    clx_bfd_session_cfg_info_t *cfg_session);
typedef clx_error_no_t (*hal_bfd_session_next_cfg_get_func_t)(
    const uint32 unit,
    const uint32 session_id,
    clx_bfd_session_cfg_info_t *cfg_session);
typedef clx_error_no_t (*hal_bfd_session_pkt_stats_get_func_t)(const uint32 unit,
                                                               const uint32 session_id,
                                                               clx_bfd_session_stats_t *stats);
typedef clx_error_no_t (*hal_bfd_session_drop_pkt_stats_get_func_t)(const uint32 unit,
                                                                    clx_bfd_drop_stats_t *stats);
typedef clx_error_no_t (*hal_bfd_session_pkt_stats_clear_func_t)(const uint32 unit,
                                                                 const uint32 session_id,
                                                                 const uint32 flags);
typedef clx_error_no_t (*hal_bfd_session_drop_pkt_stats_clear_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_bfd_session_status_get_func_t)(const uint32 unit,
                                                            const uint32 session_id,
                                                            clx_bfd_session_status_t *status);
typedef clx_error_no_t (*hal_bfd_session_poll_trigger_func_t)(const uint32 unit,
                                                              const uint32 session_id);
typedef clx_error_no_t (*hal_bfd_session_admin_set_func_t)(const uint32 unit,
                                                           const uint32 session_id,
                                                           const clx_bfd_admin_status_t status);
typedef clx_error_no_t (*hal_bfd_session_event_cb_register_func_t)(const uint32 unit,
                                                                   const clx_bfd_event_cb_t cb,
                                                                   void *ptr_cookie);
typedef clx_error_no_t (*hal_bfd_session_event_cb_unregister_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_intr_enable_func_t)(const uint32 unit,
                                                 const clx_intr_type_t intr_type);

typedef clx_error_no_t (*hal_intr_disable_func_t)(const uint32 unit,
                                                  const clx_intr_type_t intr_type);

/* PTP multiplexing functions */
typedef clx_error_no_t (*hal_ptp_init_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_deinit_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_clk_create_func_t)(const uint32 unit,
                                                    const clx_ptp_clk_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_clk_destroy_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_clk_cfg_set_func_t)(const uint32 unit,
                                                     const clx_ptp_clk_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_clk_cfg_get_func_t)(const uint32 unit, clx_ptp_clk_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_port_add_func_t)(const uint32 unit,
                                                  const uint32 port_id,
                                                  const clx_ptp_port_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_port_del_func_t)(const uint32 unit, const uint32 port_id);
typedef clx_error_no_t (*hal_ptp_port_cfg_set_func_t)(const uint32 unit,
                                                      const uint32 port_id,
                                                      const clx_ptp_port_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_port_cfg_get_func_t)(const uint32 unit,
                                                      const uint32 port_id,
                                                      clx_ptp_port_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_port_cnt_get_func_t)(const uint32 unit,
                                                      const uint32 port_id,
                                                      clx_ptp_port_cnt_t *cnt);
typedef clx_error_no_t (*hal_ptp_port_cnt_clr_func_t)(const uint32 unit, const uint32 port_id);
typedef clx_error_no_t (*hal_ptp_clk_rslt_get_func_t)(const uint32 unit, clx_ptp_clk_rslt_t *rslt);
typedef clx_error_no_t (*hal_ptp_port_wire_delay_get_func_t)(const uint32 unit,
                                                             const uint32 port_id,
                                                             clx_ptp_port_wire_delay_t *delay);
typedef clx_error_no_t (*hal_ptp_mon_enable_func_t)(const uint32 unit,
                                                    const clx_ptp_mon_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_mon_disable_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_mon_cfg_set_func_t)(const uint32 unit,
                                                     const clx_ptp_mon_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_mon_cfg_get_func_t)(const uint32 unit, clx_ptp_mon_cfg_t *cfg);
typedef clx_error_no_t (*hal_ptp_mon_stat_get_func_t)(const uint32 unit, clx_ptp_mon_stat_t *stats);
typedef clx_error_no_t (*hal_ptp_mon_stat_clr_func_t)(const uint32 unit);
typedef clx_error_no_t (*hal_ptp_masters_get_func_t)(const uint32 unit,
                                                     clx_ptp_masters_info_t *masters);
typedef clx_error_no_t (*hal_ptp_port_state_get_func_t)(const uint32 unit,
                                                        const uint32 port_id,
                                                        clx_ptp_port_state_t *state);

typedef struct {
    HAL_CHIP_MMIO_INIT_FUNC_T hal_chip_mmio_init;
    HAL_CHIP_INIT_FUNC_T hal_chip_init;
    HAL_CHIP_DEINIT_FUNC_T hal_chip_deinit;
} HAL_CHIP_FUNC_VEC_T;

typedef struct {
    HAL_BD_INIT hal_bd_init;
    HAL_BD_DEINIT hal_bd_deinit;
    HAL_BD_CREATE hal_bd_create;
    HAL_BD_DESTROY hal_bd_destroy;
    HAL_BD_CFG_SET hal_bd_cfg_set;
    HAL_BD_CFG_GET hal_bd_cfg_get;
    HAL_BD_CREATED_PRINT hal_bd_created_bd_print;
    HAL_BD_CAPACITY_GET hal_bd_capacity_get;
    HAL_BD_USAGE_GET hal_bd_usage_get;
    hal_chip_cfg_info_get_func_t hal_bd_chip_cfg_info_get;
} HAL_BD_FUNC_VEC_T;

typedef struct {
    HAL_VLAN_INIT_FUNC_T hal_vlan_init;
    HAL_VLAN_DEINIT_FUNC_T hal_vlan_deinit;
    hal_dflt_port_default_set_func_t hal_vlan_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_vlan_port_dflt_reset;
    HAL_VLAN_CREATE_FUNC_T hal_vlan_create;
    HAL_VLAN_DESTROY_FUNC_T hal_vlan_destroy;
    HAL_VLAN_PORT_GET_FUNC_T hal_vlan_port_get;
    HAL_VLAN_PORT_ADD_FUNC_T hal_vlan_port_add;
    HAL_VLAN_PORT_DEL_FUNC_T hal_vlan_port_del;
    HAL_VLAN_TAG_MODE_SET_FUNC_T hal_vlan_tag_mode_set;
    HAL_VLAN_TYPE_SET_FUNC_T hal_vlan_type_set;
    HAL_VLAN_TYPE_GET_FUNC_T hal_vlan_type_get;
    HAL_VLAN_PRIVATE_TPORT_ADD hal_vlan_private_tport_add;
    HAL_VLAN_PRIVATE_TPORT_DEL hal_vlan_private_tport_del;
    HAL_VLAN_PRIVATE_TPORT_GET hal_vlan_private_tport_get;
    HAL_VLAN_BD_BIND_FUNC_T hal_vlan_bd_bind;
    HAL_VLAN_BD_UNBIND_FUNC_T hal_vlan_bd_unbind;
    HAL_VLAN_BD_GET_FUNC_T hal_vlan_bd_get;
    HAL_VLAN_TRAV_FUNC_T hal_vlan_trav;
    HAL_VLAN_IGR_HSH_PRINT_FUNC_T hal_vlan_igr_hsh_print;
    HAL_VLAN_EGR_HSH_PRINT_FUNC_T hal_vlan_egr_hsh_print;
    hal_chip_cfg_info_get_func_t hal_vlan_chip_cfg_info_get;
    HAL_VLAN_EXT_TPID_ADD_FUNC_T hal_vlan_ext_tpid_add;
    HAL_VLAN_EXT_TPID_DEL_FUNC_T hal_vlan_ext_tpid_del;
    HAL_VLAN_EXT_TPID_GET_FUNC_T hal_vlan_ext_tpid_get;
} HAL_VLAN_FUNC_VEC_T;

typedef struct {
    HAL_PORT_INIT_FUNC_T hal_port_init;
    HAL_PORT_DEINIT_FUNC_T hal_port_deinit;
    hal_dflt_port_default_set_func_t hal_port_port_default_set;
    hal_dflt_port_default_set_func_t hal_port_port_default_reset;
    hal_port_cfg_set_func_t hal_port_cfg_set;
    hal_port_cfg_get_func_t hal_port_cfg_get;
    HAL_PORT_SETSPEED_FUNC_T hal_port_speed_set;
    HAL_PORT_GETSPEED_FUNC_T hal_port_speed_get;
    HAL_PORT_GETSPEEDLIST_FUNC_T hal_port_speed_list_get;
    HAL_PORT_SETFLOWCTRL_FUNC_T hal_port_flow_ctrl_set;
    HAL_PORT_GETFLOWCTRL_FUNC_T hal_port_flow_ctrl_get;
    HAL_PORT_SETPRIFLOWCTRL_FUNC_T hal_port_pri_flow_ctrl_set;
    HAL_PORT_GETPRIFLOWCTRL_FUNC_T hal_port_pri_flow_ctrl_get;
    HAL_PORT_SETEEEMODE_FUNC_T hal_port_eee_mode_set;
    HAL_PORT_GETEEEMODE_FUNC_T hal_port_eee_mode_get;
    HAL_PORT_SETLOCALADVABILITY_FUNC_T hal_port_local_adv_ability_set;
    HAL_PORT_GETLOCALADVABILITY_FUNC_T hal_port_local_adv_ability_get;
    HAL_PORT_GETREMOTEADVABILITY_FUNC_T hal_port_remote_adv_ability_get;
    HAL_PORT_GETABILITY_FUNC_T hal_port_ability_get;
    HAL_PORT_SETLOOPBACK hal_port_loopback_set;
    HAL_PORT_GETLOOPBACK hal_port_loopback_get;
    HAL_PORT_PROBE hal_port_probe;
    HAL_PORT_INITPORT hal_port_create;
    HAL_PORT_DEINITPORT hal_port_destroy;
    HAL_PORT_SETMACADDR hal_port_mac_addr_set;
    HAL_PORT_GETMACADDR hal_port_mac_addr_get;
    HAL_PORT_GETLINK hal_port_link_get;
    HAL_PORT_GETFAULT hal_port_fault_get;
    HAL_PORT_SETMEDIUCLYPE hal_port_medium_type_set;
    HAL_PORT_GETMEDIUCLYPE hal_port_medium_type_get;
    HAL_PORT_SETPHYPROPERTY hal_port_phy_cfg_set;
    HAL_PORT_GETPHYPROPERTY hal_port_phy_cfg_get;
    HAL_PORT_SETLANEMAP hal_port_lane_map_set;
    HAL_PORT_GETLANEMAP hal_port_lane_map_get;
    HAL_MT_PORT_VLAN_BD_BIND hal_port_vlan_bd_bind;
    HAL_MT_PORT_VLAN_BD_UNBIND hal_port_vlan_bd_unbind;
    HAL_MT_PORT_VLAN_BD_GET hal_port_vlan_bd_get;
    HAL_PORT_GPORT_CREATE hal_port_gport_create;
    HAL_PORT_GPORT_DESTROY hal_port_gport_destroy;
    HAL_PORT_SETINTFPROPERTY hal_port_intf_cfg_set;
    HAL_PORT_GETINTFPROPERTY hal_port_intf_cfg_get;
    HAL_PORT_GETTSTXENTRY hal_port_ts_tx_entry_get;
    HAL_PORT_GETTSRXENTRY hal_port_ts_rx_entry_get;
    HAL_PORT_GETPORTTYPE hal_port_port_type_get;
    HAL_PORT_GETSTATUS hal_port_status_get;
    hal_db_dump_func_t hal_port_db_dump;
    HAL_PORT_PORT_TO_GPORT_TRANS hal_port_port_to_gport_trans;
    HAL_PORT_SETTXCOEF hal_port_tx_coef_set;
    HAL_PORT_GETTXCOEF hal_port_tx_coef_get;
    HAL_PORT_VLAN_TAG_CTRL_GET hal_port_vlan_tag_ctrl_get;
    HAL_PORT_VLAN_TAG_CTRL_SET hal_port_vlan_tag_ctrl_set;
    HAL_PORT_GPORT_TO_PORT_TRANS hal_port_gport_to_port_trans;
    HAL_PORT_SETMACPROPERTY hal_port_mac_cfg_set;
    HAL_PORT_GETMACPROPERTY hal_port_mac_cfg_get;
    HAL_PORT_SETEGRHIGHLATENCYTHRESHOLD hal_port_egr_high_latency_threshold_set;
    HAL_PORT_GETEGRHIGHLATENCYTHRESHOLD hal_port_egr_high_latency_threshold_get;
    HAL_PORT_SETMBURSTPROPERTY hal_port_mburst_cfg_set;
    HAL_PORT_GETMBURSTPROPERTY hal_port_mburst_cfg_get;
    HAL_PORT_GETMBURSTSTAT hal_port_mburst_stat_get;
    HAL_PORT_GETMBURSTHISTCNT hal_port_mburst_hist_cnt_get;
    HAL_PORT_CLEARMBURSTCNT hal_port_mburst_cnt_clear;
    HAL_PORT_SETFECCLEAR_FUNC_T hal_port_fec_clear;
    HAL_PORT_SHOWBUFFCNT_FUNC_T hal_port_buff_cnt_show;
    HAL_PORT_SHOWBUFFCFG_FUNC_T hal_port_buff_cfg_show;
    HAL_PORT_GETXOFFSTATUS_FUNC_T hal_port_xoff_status_get;
    HAL_PORT_REGISTERTXSIGNAL_FUNC_T hal_port_tx_signal_register;
    HAL_PORT_DI_SET_FUNC_T hal_port_di_set;
} HAL_PORT_FUNC_VEC_T;

typedef struct {
    HAL_IFMON_INIT_FUNC_T hal_ifmon_init;
    HAL_IFMON_DEINIT_FUNC_T hal_ifmon_deinit;
    hal_dflt_port_default_set_func_t hal_ifmon_port_default_set;
    hal_dflt_port_default_set_func_t hal_ifmon_port_default_reset;
    HAL_IFMON_REGISTER_FUNC_T hal_ifmon_register;
    HAL_IFMON_DEREGISTER_FUNC_T hal_ifmon_deregister;
    HAL_IFMON_GETMODE_FUNC_T hal_ifmon_mode_get;
    HAL_IFMON_SETMODE_FUNC_T hal_ifmon_mode_set;
    HAL_IFMON_SETMONITORSTATE_FUNC_T hal_ifmon_monitor_state_set;
    HAL_IFMON_GETMONITORSTATE_FUNC_T hal_ifmon_monitor_state_get;
    hal_db_dump_func_t hal_ifmon_db_dump;
    HAL_IFMON_GETCALLBACKCNT_FUNC_T hal_ifmon_callback_cnt_get;
} HAL_IFMON_FUNC_VEC_T;

typedef struct hal_l2_func_vec_s {
    hal_l2_init_func_t hal_l2_init;
    hal_l2_deinit_func_t hal_l2_deinit;
    hal_dflt_port_default_set_func_t hal_l2_setPortDefault;
    hal_dflt_port_default_set_func_t hal_l2_resetPortDefault;
    hal_l2_addr_add_func_t hal_l2_addr_add;
    hal_l2_addr_del_func_t hal_l2_addr_del;
    hal_l2_addr_get_func_t hal_l2_addr_get;
    hal_l2_addr_flush_func_t hal_l2_addr_flush;
    hal_l2_addr_replace_func_t hal_l2_addr_replace;
    hal_l2_addr_trav_func_t hal_l2_addr_trav;
    hal_l2_addr_notify_cb_register_func_t hal_l2_addr_notify_cb_register;
    hal_l2_addr_notify_cb_deregister_func_t hal_l2_addr_notify_cb_deregister;
    hal_l2_addr_sw_learn_cb_register_func_t hal_l2_addr_sw_learn_cb_register;
    hal_l2_addr_sw_learn_cb_deregister_func_t hal_l2_addr_sw_learn_cb_deregister;
    hal_l2_age_status_get_func_t hal_l2_age_status_get;
    hal_l2_mcast_grp_create_func_t hal_l2_mcast_grp_create;
    hal_l2_mcast_grp_destroy_func_t hal_l2_mcast_grp_destroy;
    hal_l2_mcast_intf_pbmp_get_func_t hal_l2_mcast_intf_pbmp_get;
    hal_l2_mcast_egr_intf_add_func_t hal_l2_mcast_egr_intf_add;
    hal_l2_mcast_egr_intf_del_func_t hal_l2_mcast_egr_intf_del;
    hal_l2_mcast_egr_intf_cnt_get_func_t hal_l2_mcast_egr_intf_cnt_get;
    hal_l2_mcast_egr_intf_get_func_t hal_l2_mcast_egr_intf_get;
    hal_l2_mcast_egr_intf_check_func_t hal_l2_mcast_egr_intf_check;
    hal_l2_mcast_addr_add_func_t hal_l2_mcast_addr_add;
    hal_l2_mcast_addr_del_func_t hal_l2_mcast_addr_del;
    hal_l2_mcast_addr_get_func_t hal_l2_mcast_addr_get;
    hal_l2_mcast_addr_trav_func_t hal_l2_mcast_addr_trav;
    hal_l2_capacity_get_func_t hal_l2_capacity_get;
    hal_l2_usage_get_func_t hal_l2_usage_get;
    hal_l2_aging_time_set_func_t hal_l2_aging_time_set;
    hal_l2_aging_time_get_func_t hal_l2_aging_time_get;
    hal_l2_sa_move_action_set_func_t hal_l2_sa_move_action_set;
    hal_l2_sa_move_action_get_func_t hal_l2_sa_move_action_get;
    hal_l2_sa_miss_action_set_func_t hal_l2_sa_miss_action_set;
    hal_l2_sa_miss_action_get_func_t hal_l2_sa_miss_action_get;
    hal_db_dump_func_t hal_l2_db_dump;
    hal_l2_mcast_id_print_func_t hal_l2_mcast_id_print;
    hal_l2_mcast_grp_info_print_func_t hal_l2_mcast_grp_info_print;
    hal_l2_mcast_lag_mbr_update_func_t hal_l2_mcast_lag_mbr_update;
    hal_l2_mcast_lag_del_func_t hal_l2_mcast_lag_del;
    hal_l2_ecmp_grp_add_func_t hal_l2_ecmp_grp_add;
    hal_l2_ecmp_grp_del_func_t hal_l2_ecmp_grp_del;
    hal_l2_ecmp_grp_get_func_t hal_l2_ecmp_grp_get;
    hal_l2_ecmp_path_add_func_t hal_l2_ecmp_path_add;
    hal_l2_ecmp_path_del_func_t hal_l2_ecmp_path_del;
    hal_l2_ecmp_path_get_by_idx_func_t hal_l2_ecmp_path_get_by_idx;
    hal_l2_ecmp_path_hsh_set_func_t hal_l2_ecmp_path_hsh_set;
    hal_l2_ecmp_path_hsh_get_func_t hal_l2_ecmp_path_hsh_get;
    hal_l2_grp_path_list_dump_func_t hal_l2_grp_path_list_dump;
    hal_l2_multi_mcast_grp_create_func_t hal_l2_multi_mcast_grp_create;
    hal_chip_cfg_info_get_func_t hal_l2_chip_cfg_info_get;
} hal_l2_func_vec_t;

typedef struct hal_mir_func_vec_s {
    hal_mir_init_func_t hal_mir_init;
    hal_mir_deinit_func_t hal_mir_deinit;
    hal_mir_session_add_func_t hal_mir_session_add;
    hal_mir_session_del_func_t hal_mir_session_del;
    hal_mir_session_get_func_t hal_mir_session_get;
    hal_mir_erspan_decap_add_func_t hal_mir_erspan_decap_add;
    hal_mir_erspan_decap_del_func_t hal_mir_erspan_decap_del;
    hal_mir_erspan_decap_get_func_t hal_mir_erspan_decap_get;
    hal_mir_erspan_decap_trav_func_t hal_mir_erspan_decap_trav;
    hal_mir_selective_flow_mir_set_func_t hal_mir_selective_flow_mir_set;
    hal_mir_selective_flow_mir_get_func_t hal_mir_selective_flow_mir_get;
} hal_mir_func_vec_t;

typedef struct {
    hal_l3_init_func_t hal_l3_init;
    hal_l3_deinit_func_t hal_l3_deinit;
    hal_l3_intf_add_func_t hal_l3_intf_add;
    hal_l3_intf_del_func_t hal_l3_intf_del;
    hal_l3_intf_get_func_t hal_l3_intf_get;
    hal_l3_intf_trav_func_t hal_l3_intf_trav;
    hal_l3_rmac_add_func_t hal_l3_rmac_add;
    hal_l3_rmac_del_func_t hal_l3_rmac_del;
    hal_l3_rmac_get_func_t hal_l3_rmac_get;
    hal_l3_rmac_trav_func_t hal_l3_rmac_trav;
    hal_l3_adj_add_func_t hal_l3_adj_add;
    hal_l3_adj_del_func_t hal_l3_adj_del;
    hal_l3_adj_get_func_t hal_l3_adj_get;
    hal_l3_adj_trav_func_t hal_l3_adj_trav;
    hal_l3_host_add_func_t hal_l3_host_add;
    hal_l3_host_del_func_t hal_l3_host_del;
    hal_l3_host_get_func_t hal_l3_host_get;
    hal_l3_host_trav_func_t hal_l3_host_trav;
    hal_l3_host_flush_func_t hal_l3_host_flush;
    hal_l3_subnet_bcast_add_func_t hal_l3_subnet_bcast_add;
    hal_l3_subnet_bcast_del_func_t hal_l3_subnet_bcast_del;
    hal_l3_subnet_bcast_get_func_t hal_l3_subnet_bcast_get;
    hal_l3_subnet_bcast_trav_func_t hal_l3_subnet_bcast_trav;
    hal_l3_route_add_func_t hal_l3_route_add;
    hal_l3_route_del_func_t hal_l3_route_del;
    hal_l3_route_get_func_t hal_l3_route_get;
    hal_l3_route_trav_func_t hal_l3_route_trav;
    hal_l3_bulk_route_add_func_t hal_l3_bulk_route_add;
    hal_l3_bulk_route_del_func_t hal_l3_bulk_route_del;
    hal_l3_bulk_route_get_func_t hal_l3_bulk_route_get;
    hal_l3_route_usage_get_func_t hal_l3_route_usage_get;
    hal_l3_bulk_route_dump_func_t hal_l3_bulk_route_dump;
    hal_l3_ecmp_grp_add_func_t hal_l3_ecmp_grp_add;
    hal_l3_ecmp_grp_del_func_t hal_l3_ecmp_grp_del;
    hal_l3_ecmp_grp_get_func_t hal_l3_ecmp_grp_get;
    hal_l3_ecmp_grp_trav_func_t hal_l3_ecmp_grp_trav;
    hal_l3_ecmp_grp_sync_func_t hal_l3_ecmp_grp_sync;
    hal_l3_ecmp_path_add_func_t hal_l3_ecmp_path_add;
    hal_l3_ecmp_path_del_func_t hal_l3_ecmp_path_del;
    hal_l3_ecmp_path_get_by_idx_func_t hal_l3_ecmp_path_get_by_idx;
    hal_l3_ecmp_path_hsh_set_func_t hal_l3_ecmp_path_hsh_set;
    hal_l3_ecmp_path_hsh_get_func_t hal_l3_ecmp_path_hsh_get;
    hal_l3_ecmp_path_list_set_func_t hal_l3_ecmp_path_list_set;
    hal_l3_ecmp_path_list_get_func_t hal_l3_ecmp_path_list_get;
    hal_l3_ecmp_all_path_list_get_func_t hal_l3_ecmp_all_path_list_get;
    hal_l3_vrf_set_func_t hal_l3_vrf_set;
    hal_l3_vrf_get_func_t hal_l3_vrf_get;
    hal_l3_mcast_grp_create_func_t hal_l3_mcast_grp_create;
    hal_l3_mcast_grp_destroy_func_t hal_l3_mcast_grp_destroy;
    hal_l3_mcast_port_bmp_get_func_t hal_l3_mcast_port_bmp_get;
    hal_l3_mcast_route_add_func_t hal_l3_mcast_route_add;
    hal_l3_mcast_route_del_func_t hal_l3_mcast_route_del;
    hal_l3_mcast_route_get_func_t hal_l3_mcast_route_get;
    hal_l3_mcast_egr_intf_add_func_t hal_l3_mcast_egr_intf_add;
    hal_l3_mcast_egr_intf_del_func_t hal_l3_mcast_egr_intf_del;
    hal_l3_mcast_egr_intf_set_func_t hal_l3_mcast_egr_intf_set;
    hal_l3_mcast_egr_intf_cnt_get_func_t hal_l3_mcast_egr_intf_cnt_get;
    hal_l3_mcast_egr_intf_get_func_t hal_l3_mcast_egr_intf_get;
    hal_l3_mcast_df_intf_add_func_t hal_l3_mcast_df_intf_add;
    hal_l3_mcast_df_intf_del_func_t hal_l3_mcast_df_intf_del;
    hal_l3_mcast_df_intf_get_func_t hal_l3_mcast_df_intf_get;
    hal_l3_mcast_route_trav_func_t hal_l3_mcast_route_trav;
    hal_l3_frr_create_func_t hal_l3_frr_create;
    hal_l3_frr_destroy_func_t hal_l3_frr_destroy;
    hal_l3_frr_path_add_func_t hal_l3_frr_path_add;
    hal_l3_frr_path_del_func_t hal_l3_frr_path_del;
    hal_l3_frr_state_set_func_t hal_l3_frr_state_set;
    hal_l3_frr_state_get_func_t hal_l3_frr_state_get;
    hal_db_dump_func_t hal_l3_db_dump;
#if 0
    HAL_L3_ADDFDLECMPGROUP_FUNC_T hal_l3_addFdlEcmpGroup;
    HAL_L3_DELFDLECMPGROUP_FUNC_T hal_l3_delFdlEcmpGroup;
    HAL_L3_GETFDLECMPGROUP_FUNC_T hal_l3_getFdlEcmpGroup;
#endif
    hal_l3_ecmp_path_hsh_calc_func_t hal_l3_ecmp_path_hsh_calc;
    hal_l3_ecmp_path_list_dump_func_t hal_l3_ecmp_path_list_dump;
} hal_l3_func_vec_t;

typedef struct {
    hal_tnl_init_func_t hal_tnl_init;
    hal_tnl_deinit_func_t hal_tnl_deinit;
    hal_dflt_port_default_set_func_t hal_tnl_setPortDefault;
    hal_dflt_port_default_set_func_t hal_tnl_resetPortDefault;
    hal_tnl_mac_add_func_t hal_tnl_mac_add;
    hal_tnl_mac_del_func_t hal_tnl_mac_del;
    hal_tnl_mac_get_func_t hal_tnl_mac_get;
    hal_tnl_mac_trav_func_t hal_tnl_mac_trav;
    hal_tnl_entry_encap_add_func_t hal_tnl_entry_encap_add;
    hal_tnl_entry_encap_del_func_t hal_tnl_entry_encap_del;
    hal_tnl_entry_encap_get_func_t hal_tnl_entry_encap_get;
    hal_tnl_entry_encap_trav_func_t hal_tnl_entry_encap_trav;
    hal_tnl_entry_decap_add_func_t hal_tnl_entry_decap_add;
    hal_tnl_entry_decap_del_func_t hal_tnl_entry_decap_del;
    hal_tnl_entry_decap_get_func_t hal_tnl_entry_decap_get;
    hal_tnl_entry_decap_trav_func_t hal_tnl_entry_decap_trav;
    hal_tnl_nvo3_route_add_func_t hal_tnl_nvo3_route_add;
    hal_tnl_nvo3_route_del_func_t hal_tnl_nvo3_route_del;
    hal_tnl_nvo3_route_get_func_t hal_tnl_nvo3_route_get;
    hal_tnl_nvo3_route_trav_func_t hal_tnl_nvo3_route_trav;
    hal_tnl_port_create_func_t hal_tnl_port_create;
    hal_tnl_port_destroy_func_t hal_tnl_port_destroy;
    hal_tnl_port_get_func_t hal_tnl_port_get;
    hal_tnl_info_get_func_t hal_tnl_info_get;
    hal_tnl_entry_trav_func_t hal_tnl_entry_trav;
    hal_tnl_flex_tnl_add_func_t hal_tnl_flex_tnl_add;
    hal_tnl_flex_tnl_del_func_t hal_tnl_flex_tnl_del;
    hal_tnl_flex_tnl_get_func_t hal_tnl_flex_tnl_get;
    hal_tnl_flex_tnl_udf_set_func_t hal_tnl_flex_tnl_udf_set;
    hal_tnl_flex_tnl_udf_get_func_t hal_tnl_flex_tnl_udf_get;
    hal_tnl_phy_port_set_func_t hal_tnl_phy_port_set;
    hal_tnl_phy_port_get_func_t hal_tnl_phy_port_get;
    hal_tnl_es_grp_create_func_t hal_tnl_es_grp_create;
    hal_tnl_es_grp_destroy_func_t hal_tnl_es_grp_destroy;
    hal_tnl_es_grp_mbr_add_func_t hal_tnl_es_grp_mbr_add;
    hal_tnl_es_grp_mbr_del_func_t hal_tnl_es_grp_mbr_del;
    hal_tnl_es_grp_mbr_get_func_t hal_tnl_es_grp_mbr_get;
    hal_tnl_seg_srv_add_func_t hal_tnl_seg_srv_add;
    hal_tnl_seg_srv_del_func_t hal_tnl_seg_srv_del;
    hal_tnl_seg_srv_get_func_t hal_tnl_seg_srv_get;
    hal_db_dump_func_t hal_tnl_db_dump;
} hal_tnl_func_vec_t;

typedef struct hal_srv6_func_vec_s {
    hal_srv6_init_func_t hal_srv6_init;
    hal_srv6_deinit_func_t hal_srv6_deinit;
    hal_dflt_port_default_set_func_t hal_srv6_setPortDefault;
    hal_dflt_port_default_set_func_t hal_srv6_resetPortDefault;
    hal_srv6_port_create_func_t hal_srv6_port_create;
    hal_srv6_port_destroy_func_t hal_srv6_port_destroy;
    hal_srv6_port_trav_func_t hal_srv6_port_trav;
    hal_srv6_local_add_func_t hal_srv6_local_add;
    hal_srv6_local_del_func_t hal_srv6_local_del;
    hal_srv6_local_set_func_t hal_srv6_local_set;
    hal_srv6_local_get_func_t hal_srv6_local_get;
    hal_srv6_local_trav_func_t hal_srv6_local_trav;
    hal_srv6_encap_add_func_t hal_srv6_encap_add;
    hal_srv6_encap_del_func_t hal_srv6_encap_del;
    hal_srv6_encap_set_func_t hal_srv6_encap_set;
    hal_srv6_encap_get_func_t hal_srv6_encap_get;
    hal_srv6_encap_trav_func_t hal_srv6_encap_trav;
    hal_srv6_mysid_entry_add_func_t hal_srv6_mysid_entry_add;
    hal_srv6_mysid_entry_del_func_t hal_srv6_mysid_entry_del;
    hal_srv6_mysid_entry_set_func_t hal_srv6_mysid_entry_set;
    hal_srv6_mysid_entry_get_func_t hal_srv6_mysid_entry_get;
    hal_srv6_mysid_entry_trav_func_t hal_srv6_mysid_entry_trav;
    hal_srv6_nvo3_route_add_func_t hal_srv6_nvo3_route_add;
    hal_srv6_nvo3_route_set_func_t hal_srv6_nvo3_route_set;
    hal_srv6_nvo3_route_del_func_t hal_srv6_nvo3_route_del;
    hal_srv6_nvo3_route_get_func_t hal_srv6_nvo3_route_get;
    hal_srv6_nvo3_route_trav_func_t hal_srv6_nvo3_route_trav;
    hal_srv6_endpoint_policy_add_func_t hal_srv6_endpoint_policy_add;
    hal_srv6_endpoint_policy_del_func_t hal_srv6_endpoint_policy_del;
    hal_srv6_endpoint_policy_set_func_t hal_srv6_endpoint_policy_set;
    hal_srv6_endpoint_policy_get_func_t hal_srv6_endpoint_policy_get;
    hal_srv6_endpoint_policy_trav_func_t hal_srv6_endpoint_policy_trav;
    hal_srv6_property_set_func_t hal_srv6_property_set;
    hal_srv6_property_get_func_t hal_srv6_property_get;
    hal_srv6_seg_srv_add_func_t hal_srv6_seg_srv_add;
    hal_srv6_seg_srv_del_func_t hal_srv6_seg_srv_del;
    hal_srv6_seg_srv_set_func_t hal_srv6_seg_srv_set;
    hal_srv6_seg_srv_get_func_t hal_srv6_seg_srv_get;
    hal_srv6_hash_action_set_func_t hal_srv6_hash_action_set;
    hal_srv6_hash_action_get_func_t hal_srv6_hash_action_get;
    hal_db_dump_func_t hal_srv6_db_dump;
} hal_srv6_func_vec_t;

typedef struct {
    hal_pkt_init_func_t hal_pkt_init;
    hal_pkt_deinit_func_t hal_pkt_deinit;
    hal_dflt_port_default_set_func_t hal_pkt_port_default_set;
    hal_dflt_port_default_set_func_t hal_pkt_port_default_reset;
    hal_pkt_rx_init_func_t hal_pkt_rx_init;
    hal_pkt_rx_deinit_func_t hal_pkt_rx_deinit;
    hal_pkt_rx_cb_func_t hal_pkt_rx_cb;
    hal_pkt_tx_send_func_t hal_pkt_tx_send;
    hal_pkt_tx_prepare_func_t hal_pkt_tx_prepare;
    hal_pkt_ctrl_to_cpu_entry_set_func_t hal_pkt_ctrl_to_cpu_entry_set;
    hal_pkt_ctrl_to_cpu_entry_get_func_t hal_pkt_ctrl_to_cpu_entry_get;
    hal_pkt_ctrl_to_cpu_entry_all_clear_func_t hal_pkt_ctrl_to_cpu_entry_all_clear;
    hal_pkt_tx_cnt_get_func_t hal_pkt_tx_cnt_get;
    hal_pkt_rx_cnt_get_func_t hal_pkt_rx_cnt_get;
    hal_pkt_tx_cnt_clear_func_t hal_pkt_tx_cnt_clear;
    hal_pkt_rx_cnt_clear_func_t hal_pkt_rx_cnt_clear;
    hal_pkt_intf_create_func_t hal_pkt_intf_create;
    hal_pkt_intf_destroy_func_t hal_pkt_intf_destroy;
    hal_pkt_intf_get_func_t hal_pkt_intf_get;
    hal_pkt_intf_set_func_t hal_pkt_intf_set;
    hal_pkt_prof_create_func_t hal_pkt_prof_create;
    hal_pkt_prof_destroy_func_t hal_pkt_prof_destroy;
    hal_pkt_prof_get_func_t hal_pkt_prof_get;
    hal_pkt_intf_cnt_get_func_t hal_pkt_intf_cnt_get;
    hal_pkt_intf_cnt_clear_func_t hal_pkt_intf_cnt_clear;
    hal_pkt_tx_dbg_cnt_show_func_t hal_pkt_tx_dbg_cnt_show;
    hal_pkt_rx_dbg_cnt_show_func_t hal_pkt_rx_dbg_cnt_show;
    hal_db_dump_func_t hal_pkt_db_dump;
    hal_reg_dump_func_t hal_pkt_reg_dump;
    hal_pkt_reg_show_func_t hal_pkt_reg_show;
    hal_pkt_pp_rsn_get_func_t hal_pkt_pp_rsn_get;
    hal_pkt_pp_to_drop_rsn_func_t hal_pkt_pp_to_drop_rsn;
    hal_pkt_pp_rsn_code_get_func_t hal_pkt_pp_rsn_code_get;
    hal_pkt_rsn_get_func_t hal_pkt_rsn_get;
    hal_pkt_rsn_code_get_func_t hal_pkt_rsn_code_get;
    hal_pkt_drop_rsn_get_func_t hal_pkt_drop_rsn_get;
    hal_pkt_rx_cblist_set_func_t hal_pkt_rx_cblist_set;
    hal_pkt_netlink_create_func_t hal_pkt_netlink_create;
    hal_pkt_netlink_destroy_func_t hal_pkt_netlink_destroy;
    hal_pkt_netlink_get_func_t hal_pkt_netlink_get;
    hal_pkt_queue_cfg_get_func_t hal_pkt_queue_cfg_get;
    hal_pkt_queue_cfg_set_func_t hal_pkt_queue_cfg_set;
    hal_pkt_rx_udf_mem_cb_set_func_t hal_pkt_rx_udf_mem_cb_set;
    hal_pkt_cpu_reason_cnt_get_func_t hal_pkt_rx_reason_cnt_get;
    hal_pkt_cpu_reason_cnt_clear_func_t hal_pkt_rx_reason_cnt_clear;
    hal_pkt_intf_rx_reason_cnt_get_func_t hal_pkt_intf_rx_reason_cnt_get;
    hal_pkt_intf_rx_reason_cnt_clear_func_t hal_pkt_intf_rx_reason_cnt_clear;
    hal_pkt_ifa_cfg_set_func_t hal_pkt_ifa_cfg_set;
    hal_pkt_ifa_cfg_get_func_t hal_pkt_ifa_cfg_get;
} HAL_PKT_FUNC_VEC_T;

typedef struct {
    hal_stat_init_func_t hal_stat_init;
    hal_stat_deinit_func_t hal_stat_deinit;
    hal_dflt_port_default_set_func_t hal_stat_port_default_set;
    hal_dflt_port_default_set_func_t hal_stat_port_default_reset;
    hal_stat_port_cnt_get_func_t hal_stat_port_cnt_get;
    hal_stat_port_cnt_clear_func_t hal_stat_port_cnt_clear;
    hal_stat_tm_cnt_get_func_t hal_stat_tm_cnt_get;
    hal_stat_tm_cnt_clear_func_t hal_stat_tm_cnt_clear;
    hal_stat_queue_cnt_get_func_t hal_stat_queue_cnt_get;
    hal_stat_queue_cnt_clear_func_t hal_stat_queue_cnt_clear;
    hal_stat_dist_cnt_create_func_t hal_stat_dist_cnt_create;
    hal_stat_dist_cnt_destroy_func_t hal_stat_dist_cnt_destroy;
    hal_stat_dist_cnt_get_func_t hal_stat_dist_cnt_get;
    hal_stat_dist_cnt_clear_func_t hal_stat_dist_cnt_clear;
    hal_stat_srv_cnt_create_func_t hal_stat_srv_cnt_create;
    hal_stat_srv_cnt_destroy_func_t hal_stat_srv_cnt_destroy;
    hal_stat_srv_cnt_get_func_t hal_stat_srv_cnt_get;
    hal_stat_srv_cnt_clear_func_t hal_stat_srv_cnt_clear;
    hal_stat_srv_cnt_cfg_get_func_t hal_stat_srv_cnt_cfg_get;
    hal_stat_port_rate_get_func_t hal_stat_port_rate_get;
    hal_stat_port_rate_type_get_func_t hal_stat_port_rate_type_get;
    hal_stat_cnt_refresh_func_t hal_stat_cnt_refresh;
    hal_stat_dbg_cnt_show_func_t hal_stat_dbg_cnt_show;
    hal_stat_dbg_cnt_clear_func_t hal_stat_dbg_cnt_clear;
    hal_stat_cnt_hw_idx_get_func_t hal_stat_cnt_hw_idx_get;
    hal_stat_pp_bank_id_get_func_t hal_stat_pp_bank_id_get;
    hal_stat_reason_cnt_get_func_t hal_stat_reason_cnt_get;
    hal_stat_reason_cnt_clear_func_t hal_stat_reason_cnt_clear;
    hal_stat_hw_reason_cnt_get_func_t hal_stat_hw_reason_cnt_get;
    hal_stat_hw_reason_cnt_clear_func_t hal_stat_hw_reason_cnt_clear;
#ifdef CLX_STAT_EN_HPC_CNT
    hal_stat_hpc_create_func_t hal_stat_hpc_create;
    hal_stat_hpc_destroy_func_t hal_stat_hpc_destroy;
    hal_stat_hpc_dequeue_func_t hal_stat_hpc_dequeue;
#endif /* End of CLX_STAT_EN_HPC_CNT */
    hal_stat_hrm_watermark_get_func_t hal_stat_hrm_watermark_get;
    hal_stat_hrm_watermark_clear_func_t hal_stat_hrm_watermark_clear;
    hal_stat_hrm_occupancy_get_func_t hal_stat_hrm_occupancy_get;
} hal_stat_func_vec_t;

typedef struct {
    hal_sec_init_func_t hal_sec_init;
    hal_sec_deinit_func_t hal_sec_deinit;
    hal_dflt_port_default_set_func_t hal_sec_setPortDefault;
    hal_dflt_port_default_set_func_t hal_sec_resetPortDefault;
    hal_sec_dos_port_cfg_set_func_t hal_sec_dos_port_cfg_set;
    hal_sec_dos_port_cfg_get_func_t hal_sec_dos_port_cfg_get;
    hal_sec_dos_cfg_set_func_t hal_sec_dos_cfg_set;
    hal_sec_dos_cfg_get_func_t hal_sec_dos_cfg_get;
    hal_sec_dos_status_get_func_t hal_sec_dos_status_get;
    hal_sec_dos_status_clear_func_t hal_sec_dos_status_clear;
    hal_sec_dos_cnt_get_func_t hal_sec_dos_cnt_get;
    hal_sec_dos_cnt_clear_func_t hal_sec_dos_cnt_clear;
    hal_sec_storm_ctrl_cfg_set_func_t hal_sec_storm_ctrl_cfg_set;
    hal_sec_storm_ctrl_cfg_get_func_t hal_sec_storm_ctrl_cfg_get;
    hal_sec_storm_ctrl_stats_get_func_t hal_sec_storm_ctrl_stats_get;
    hal_sec_storm_ctrl_stats_clear_func_t hal_sec_storm_ctrl_stats_clear;
    hal_sec_src_guard_cfg_set_func_t hal_sec_src_guard_cfg_set;
    hal_sec_src_guard_cfg_get_func_t hal_sec_src_guard_cfg_get;
    hal_sec_src_guard_bd_cfg_set_func_t hal_sec_src_guard_bd_cfg_set;
    hal_sec_src_guard_bd_cfg_get_func_t hal_sec_src_guard_bd_cfg_get;
    hal_sec_src_guard_entry_add_func_t hal_sec_src_guard_entry_add;
    hal_sec_src_guard_entry_del_func_t hal_sec_src_guard_entry_del;
    hal_sec_src_guard_entry_get_func_t hal_sec_src_guard_entry_get;
    hal_sec_isolation_grp_cfg_set_func_t hal_sec_isolation_grp_cfg_set;
    hal_sec_isolation_grp_cfg_get_func_t hal_sec_isolation_grp_cfg_get;
    hal_sec_isolation_port_cfg_set_func_t hal_sec_isolation_port_cfg_set;
    hal_sec_isolation_port_cfg_get_func_t hal_sec_isolation_port_cfg_get;
} hal_sec_func_vec_t;

typedef struct hal_sflow_func_vec_s {
    hal_sflow_init_func_t hal_sflow_init;
    hal_sflow_deinit_func_t hal_sflow_deinit;
} hal_sflow_func_vec_t;

typedef struct hal_qos_func_vec_s {
    hal_qos_init_func_t hal_qos_init;
    hal_qos_deinit_func_t hal_qos_deinit;
    hal_dflt_port_default_set_func_t hal_qos_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_qos_port_dflt_reset;
    hal_qos_prof_create_func_t hal_qos_prof_create;
    hal_qos_prof_destroy_func_t hal_qos_prof_destroy;
    hal_qos_prof_set_func_t hal_qos_prof_set;
    hal_qos_prof_get_func_t hal_qos_prof_get;
} hal_qos_func_vec_t;

typedef struct {
    HAL_STP_INIT_FUNC_T hal_stp_init;
    HAL_STP_DEINIT_FUNC_T hal_stp_deinit;
    hal_dflt_port_default_set_func_t hal_stp_setPortDefault;
    hal_dflt_port_default_set_func_t hal_stp_resetPortDefault;
    HAL_STP_CREATE_FUNC_T hal_stp_create;
    HAL_STP_DESTROY_FUNC_T hal_stp_destroy;
    HAL_STP_PORTSTATE_SET_FUNC_T hal_stp_portstate_set;
    HAL_STP_PORTSTATE_GET_FUNC_T hal_stp_portstate_get;
    HAL_STP_IS_VALID_FUNC_T hal_stp_is_valid;
} HAL_STP_FUNC_VEC_T;

typedef struct {
    hal_swc_init_func_t hal_swc_init;
    hal_swc_deinit_func_t hal_swc_deinit;
    hal_dflt_port_default_set_func_t hal_swc_setPortDefault;
    hal_dflt_port_default_set_func_t hal_swc_resetPortDefault;
    hal_swc_cfg_set_func_t hal_swc_cfg_set;
    hal_swc_cfg_get_func_t hal_swc_cfg_get;
    hal_swc_chip_temp_get_func_t hal_swc_chip_temp_get;
    hal_swc_chip_temp_list_get_func_t hal_swc_chip_temp_list_get;
    hal_swc_pvt_calib_info_get_func_t hal_swc_pvt_calib_info_get;
    hal_swc_hsh_key_set_func_t hal_swc_hsh_key_set;
    hal_swc_hsh_key_get_func_t hal_swc_hsh_key_get;
    hal_swc_hsh_eng_set_func_t hal_swc_hsh_eng_set;
    hal_swc_hsh_eng_get_func_t hal_swc_hsh_eng_get;
    hal_swc_ts_set_func_t hal_swc_ts_set;
    hal_swc_ts_get_func_t hal_swc_ts_get;
    hal_swc_ts_offset_set_func_t hal_swc_ts_offset_set;
    hal_swc_hsh_const_set_func_t hal_swc_hsh_const_set;
    hal_swc_hsh_const_get_func_t hal_swc_hsh_const_get;
    hal_swc_err_cb_register_func_t hal_swc_err_cb_register;
    hal_swc_err_cb_deregister_func_t hal_swc_err_cb_deregister;
    hal_swc_dev_info_get_func_t hal_swc_dev_info_get;
    hal_swc_port_cfg_get_func_t hal_swc_port_cfg_get;
    hal_swc_capacity_get_func_t hal_swc_capacity_get;
    hal_swc_usage_get_func_t hal_swc_usage_get;
    hal_swc_cso_mode_set_func_t hal_swc_cso_mode_set;
    hal_swc_cso_mode_get_func_t hal_swc_cso_mode_get;
    hal_swc_excpt_set_func_t hal_swc_excpt_set;
    hal_swc_trap_all_set_func_t hal_swc_trap_all_set;
    hal_swc_epg_pkt_init_func_t hal_swc_epg_pkt_init;
    hal_swc_epg_mac_hw_set_func_t hal_swc_epg_mac_hw_set;
    hal_swc_epg_mac_done_check_func_t hal_swc_epg_mac_done_chk;
    hal_swc_epg_mac_pkt_stop_func_t hal_swc_epg_mac_pkt_stop;
    hal_swc_rsn_act_set_func_t hal_swc_rsn_act_set;
    hal_swc_rsn_act_get_func_t hal_swc_rsn_act_get;
    hal_swc_rsn_pri_set_func_t hal_swc_rsn_pri_set;
    hal_swc_rsn_pri_get_func_t hal_swc_rsn_pri_get;
    hal_swc_pp_rsn_pri_set_func_t hal_swc_pp_rsn_pri_set;
    hal_swc_pp_rsn_pri_get_func_t hal_swc_pp_rsn_pri_get;
    hal_swc_max_ts_sec_get_func_t hal_swc_max_ts_sec_get;
    hal_swc_tod_info_get_func_t hal_swc_tod_info_get;
    hal_chip_cfg_info_get_func_t hal_swc_chip_cfg_info_get;
    hal_swc_tbl_name_get_func_t hal_swc_tbl_name_get;
    hal_swc_str_name_get_func_t hal_swc_str_name_get;
    hal_swc_chip_pll_status_get_func_t hal_swc_chip_pll_status_get;
    hal_swc_hsh_path_get_func_t hal_swc_hsh_path_get;
    hal_swc_hsh_path_key_get_func_t hal_swc_hsh_path_key_get;
    hal_swc_reg_tbl_info_get_func_t hal_swc_reg_tbl_info_get;
    hal_swc_skip_rx_crc_check_set_func_t hal_swc_skip_rx_crc_check_set;
    hal_swc_skip_rx_crc_check_get_func_t hal_swc_skip_rx_crc_check_get;
    hal_swc_runt_pkt_fwd_set_func_t hal_swc_runt_pkt_fwd_set;
    hal_swc_runt_pkt_fwd_get_func_t hal_swc_runt_pkt_fwd_get;
    hal_swc_notify_cb_register_func_t hal_swc_notify_cb_register;
    hal_swc_notify_cb_deregister_func_t hal_swc_notify_cb_deregister;
} hal_swc_func_vec_t;

typedef struct {
    hal_meter_init_func_t hal_meter_init;
    hal_meter_deinit_func_t hal_meter_deinit;
    hal_dflt_port_default_set_func_t hal_meter_setPortDefault;
    hal_dflt_port_default_set_func_t hal_meter_resetPortDefault;
    hal_meter_create_func_t hal_meter_create;
    hal_meter_destroy_func_t hal_meter_destroy;
    hal_meter_get_func_t hal_meter_get;
    hal_meter_param_set_func_t hal_meter_param_set;
} HAL_METER_FUNC_VEC_T;

typedef struct {
    hal_tm_init_func_t hal_tm_init;
    hal_tm_deinit_func_t hal_tm_deinit;
    hal_dflt_port_default_set_func_t hal_tm_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_tm_port_dflt_reset;
    hal_tm_handler_create_func_t hal_tm_handler_create;
    hal_tm_handler_destroy_func_t hal_tm_handler_destroy;
    hal_tm_sched_shaper_set_func_t hal_tm_shaper_set;
    hal_tm_sched_shaper_get_func_t hal_tm_shaper_get;
    hal_tm_sched_mode_set_func_t hal_tm_sched_mode_set;
    hal_tm_sched_mode_get_func_t hal_tm_sched_mode_get;
    hal_tm_cfg_set_func_t hal_tm_cfg_set;
    hal_tm_cfg_get_func_t hal_tm_cfg_get;
    hal_tm_pfc_mapping_set_func_t hal_tm_pfc_mapping_set;
    hal_tm_pfc_mapping_get_func_t hal_tm_pfc_mapping_get;
    hal_tm_buf_usage_get_func_t hal_tm_buf_usage_get;
    hal_tm_buf_watermark_get_func_t hal_tm_buf_watermark_get;
    hal_tm_buf_watermark_clear_func_t hal_tm_buf_watermark_clear;
    hal_db_dump_func_t hal_tm_db_dump;
    hal_tm_reg_dump_func_t hal_tm_reg_dump;
    hal_tm_pfcwd_cb_register_func_t hal_tm_pfcwd_cb_register;
    hal_tm_pfcwd_cb_deregister_func_t hal_tm_pfcwd_cb_deregister;
    hal_tm_pfcwd_set_func_t hal_tm_pfcwd_set;
    hal_tm_pfcwd_get_func_t hal_tm_pfcwd_get;
    hal_tm_pfcwd_state_get_func_t hal_tm_pfcwd_state_get;
    hal_tm_tc_prof_set_func_t hal_tm_tc_prof_set;
    hal_tm_tc_prof_get_func_t hal_tm_tc_prof_get;
    hal_tm_buf_prof_create_func_t hal_tm_buf_prof_create;
    hal_tm_buf_prof_destroy_func_t hal_tm_buf_prof_destroy;
    hal_tm_buf_prof_set_func_t hal_tm_buf_prof_set;
    hal_tm_buf_prof_get_func_t hal_tm_buf_prof_get;
    hal_tm_buf_cfg_set_func_t hal_tm_buf_cfg_set;
    hal_tm_buf_cfg_get_func_t hal_tm_buf_cfg_get;
    hal_tm_wred_prof_create_func_t hal_tm_wred_prof_create;
    hal_tm_wred_prof_destroy_func_t hal_tm_wred_prof_destroy;
    hal_tm_wred_prof_set_func_t hal_tm_wred_prof_set;
    hal_tm_wred_prof_get_func_t hal_tm_wred_prof_get;
    hal_tm_wred_cfg_set_func_t hal_tm_wred_cfg_set;
    hal_tm_wred_cfg_get_func_t hal_tm_wred_cfg_get;
    hal_tm_histogram_cfg_set_func_t hal_tm_histogram_cfg_set;
    hal_tm_histogram_cfg_get_func_t hal_tm_histogram_cfg_get;
    hal_tm_histogram_cb_register_func_t hal_tm_histogram_cb_register;
    hal_tm_histogram_cb_deregister_func_t hal_tm_histogram_cb_deregister;
    hal_tm_histogram_cnt_clear_func_t hal_tm_histogram_cnt_clear;
    hal_tm_tcb_match_set_func_t hal_tm_tcb_match_set;
    hal_tm_tcb_match_get_func_t hal_tm_tcb_match_get;
    hal_tm_tcb_cfg_set_func_t hal_tm_tcb_cfg_set;
    hal_tm_tcb_cfg_get_func_t hal_tm_tcb_cfg_get;
    hal_tm_tcb_cb_register_func_t hal_tm_tcb_cb_register;
    hal_tm_tcb_cb_deregister_func_t hal_tm_tcb_cb_deregister;
    hal_tm_mburst_prof_create_func_t hal_tm_mburst_prof_create;
    hal_tm_mburst_prof_destroy_func_t hal_tm_mburst_prof_destroy;
    hal_tm_mburst_prof_set_func_t hal_tm_mburst_prof_set;
    hal_tm_mburst_prof_get_func_t hal_tm_mburst_prof_get;
    hal_tm_mburst_cfg_set_func_t hal_tm_mburst_cfg_set;
    hal_tm_mburst_cfg_get_func_t hal_tm_mburst_cfg_get;
    hal_tm_mburst_callback_register_func_t hal_tm_mburst_cb_register;
    hal_tm_mburst_callback_deregister_func_t hal_tm_mburst_cb_deregister;
} HAL_TM_FUNC_VEC_T;

typedef struct {
    HAL_LAG_INIT_FUNC_T hal_lag_init;
    HAL_LAG_DEINIT_FUNC_T hal_lag_deinit;
    hal_dflt_port_default_set_func_t hal_lag_setPortDefault;
    hal_dflt_port_default_set_func_t hal_lag_resetPortDefault;
    HAL_LAG_CREATE_FUNC_T hal_lag_create;
    HAL_LAG_DESTROY_FUNC_T hal_lag_destroy;
    HAL_LAG_MEMBER_SET_FUNC_T hal_lag_member_set;
    HAL_LAG_MEMBER_GET_FUNC_T hal_lag_member_get;
    HAL_LAG_MEMBER_CNT_GET_FUNC_T hal_lag_member_cnt_get;
    HAL_LAG_TRAV_FUNC_T hal_lag_trav;
    HAL_LAG_ID_GET_FUNC_T hal_lag_id_get;
    HAL_LAG_PORT_GET_FUNC_T hal_lag_port_get;
    HAL_LAG_ATTR_SET_FUNC_T hal_lag_attr_set;
    HAL_LAG_ATTR_GET_FUNC_T hal_lag_attr_get;
    hal_chip_cfg_info_get_func_t hal_lag_chip_cfg_info_get;
} HAL_LAG_FUNC_VEC_T;

typedef struct {
    hal_cia_init_func_t hal_cia_init;
    hal_cia_deinit_func_t hal_cia_deinit;
    hal_dflt_port_default_set_func_t hal_cia_setPortDefault;
    hal_dflt_port_default_set_func_t hal_cia_resetPortDefault;
    hal_cia_grp_get_func_t hal_cia_grp_get;
    hal_cia_grp_add_func_t hal_cia_grp_add;
    hal_cia_grp_del_func_t hal_cia_grp_del;
    hal_cia_grp_trav_func_t hal_cia_grp_trav;
    hal_cia_exact_grp_get_func_t hal_cia_exact_grp_get;
    hal_cia_exact_grp_add_func_t hal_cia_exact_grp_add;
    hal_cia_exact_grp_del_func_t hal_cia_exact_grp_del;
    hal_cia_exact_grp_trav_func_t hal_cia_exact_grp_trav;
    hal_cia_udf_entry_get_func_t hal_cia_udf_entry_get;
    hal_cia_udf_entry_add_func_t hal_cia_udf_entry_add;
    hal_cia_udf_entry_del_func_t hal_cia_udf_entry_del;
    hal_cia_udf_entry_trav_func_t hal_cia_udf_entry_trav;
    hal_cia_entry_id_info_get_func_t hal_cia_entry_id_info_get;
    hal_cia_entry_id_alloc_func_t hal_cia_entry_id_alloc;
    hal_cia_entry_id_free_func_t hal_cia_entry_id_free;
    hal_cia_entry_get_func_t hal_cia_entry_get;
    hal_cia_entry_add_func_t hal_cia_entry_add;
    hal_cia_entry_vld_set_func_t hal_cia_entry_vld_set;
    hal_cia_entry_del_func_t hal_cia_entry_del;
    hal_cia_entry_trav_func_t hal_cia_entry_trav;
    hal_cia_exact_entry_get_func_t hal_cia_exact_entry_get;
    hal_cia_exact_entry_add_func_t hal_cia_exact_entry_add;
    hal_cia_exact_entry_del_func_t hal_cia_exact_entry_del;
    hal_cia_exact_entry_trav_func_t hal_cia_exact_entry_trav;
    hal_cia_exact_entry_id_info_get_func_t hal_cia_exact_entry_id_info_get;
    hal_cia_rim_alloc_func_t hal_cia_rim_alloc;
    hal_cia_rim_free_func_t hal_cia_rim_free;
    hal_cia_rim_act_set_func_t hal_cia_rim_act_set;
    hal_cia_rim_act_get_func_t hal_cia_rim_act_get;
    hal_cia_rim_act_trav_func_t hal_cia_rim_act_trav;
    hal_cia_range_add_func_t hal_cia_range_add;
    hal_cia_range_del_func_t hal_cia_range_del;
    hal_cia_range_get_func_t hal_cia_range_get;
    hal_cia_range_trav_func_t hal_cia_range_trav;
    hal_cia_range_union_set_func_t hal_cia_range_union_set;
    hal_cia_range_union_get_func_t hal_cia_range_union_get;
} hal_cia_func_vec_t;

/* MPLS multiplexing functions */
typedef struct {
    hal_mpls_init_func_t hal_mpls_init;
    hal_mpls_deinit_func_t hal_mpls_deinit;
    hal_dflt_port_default_set_func_t hal_mpls_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_mpls_port_dflt_reset;
    hal_mpls_vpn_id_create_fun_t hal_mpls_vpn_id_create;
    hal_mpls_vpn_id_destroy_fun_t hal_mpls_vpn_id_destroy;
    hal_mpls_vpn_id_get_fun_t hal_mpls_vpn_id_get;
    hal_mpls_lsp_port_create_fun_t hal_mpls_lsp_port_create;
    hal_mpls_lsp_port_destroy_fun_t hal_mpls_lsp_port_destroy;
    hal_mpls_lsp_port_get_fun_t hal_mpls_lsp_port_get;
    hal_mpls_encap_add_fun_t hal_mpls_encap_add;
    hal_mpls_encap_del_fun_t hal_mpls_encap_del;
    hal_mpls_encap_get_fun_t hal_mpls_encap_get;
    hal_mpls_decap_add_fun_t hal_mpls_decap_add;
    hal_mpls_decap_del_fun_t hal_mpls_decap_del;
    hal_mpls_decap_get_fun_t hal_mpls_decap_get;
    hal_mpls_transit_add_fun_t hal_mpls_transit_add;
    hal_mpls_transit_del_fun_t hal_mpls_transit_del;
    hal_mpls_transit_get_fun_t hal_mpls_transit_get;
    hal_mpls_pw_port_create_fun_t hal_mpls_pw_port_create;
    hal_mpls_pw_port_destroy_fun_t hal_mpls_pw_port_destroy;
    hal_mpls_pw_port_get_fun_t hal_mpls_pw_port_get;
    hal_mpls_pw_add_fun_t hal_mpls_pw_add;
    hal_mpls_pw_del_fun_t hal_mpls_pw_del;
    hal_mpls_pw_get_fun_t hal_mpls_pw_get;
    hal_mpls_vpws_add_fun_t hal_mpls_vpws_add;
    hal_mpls_vpws_del_fun_t hal_mpls_vpws_del;
    hal_mpls_vpws_get_fun_t hal_mpls_vpws_get;
    hal_mpls_lbl_range_set_fun_t hal_mpls_lbl_range_set;
    hal_mpls_lbl_range_get_fun_t hal_mpls_lbl_range_get;
    hal_mpls_encap_trav_fun_t hal_mpls_encap_trav;
    hal_mpls_transit_trav_fun_t hal_mpls_transit_trav;
    hal_mpls_decap_trav_fun_t hal_mpls_decap_trav;
    hal_mpls_pw_trav_fun_t hal_mpls_pw_trav;
    hal_db_dump_func_t hal_mpls_db_dump;
} hal_mpls_func_vec_t;

typedef struct {
    hal_telm_init_func_t hal_telm_init;
    hal_telm_deinit_func_t hal_telm_deinit;
    hal_dflt_port_default_set_func_t hal_telm_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_telm_port_dflt_reset;
    hal_telm_notify_cb_register_func_t hal_telm_notify_cb_register;
    hal_telm_notify_cb_deregister_func_t hal_telm_notify_cb_deregister;
    hal_telm_cfg_set_func_t hal_telm_cfg_set;
    hal_telm_cfg_get_func_t hal_telm_cfg_get;

    /* int api */
    hal_telm_int_prof_set_func_t hal_telm_int_prof_set;
    hal_telm_int_prof_get_func_t hal_telm_int_prof_get;
    hal_telm_int_glb_set_func_t hal_telm_int_glb_set;
    hal_telm_int_glb_get_func_t hal_telm_int_glb_get;

    /* ioam api */
    hal_telm_ioam_cfg_set_func_t hal_telm_ioam_cfg_set;
    hal_telm_ioam_cfg_get_func_t hal_telm_ioam_cfg_get;

    /* ifa api */
    hal_telm_ifa_cfg_set_func_t hal_telm_ifa_cfg_set;
    hal_telm_ifa_cfg_get_func_t hal_telm_ifa_cfg_get;

    /* mod api */
    hal_telm_mod_cfg_set_func_t hal_telm_mod_cfg_set;
    hal_telm_mod_cfg_get_func_t hal_telm_mod_cfg_get;

} hal_telm_func_vec_t;

typedef struct {
    hal_ecc_set_cfg_func_t hal_ecc_cfg_set;
    hal_ecc_get_cfg_func_t hal_ecc_cfg_get;
    hal_ecc_err_cnt_get_func_t hal_ecc_err_cnt_get;
    hal_ecc_err_cnt_clear_func_t hal_ecc_err_cnt_clear;
} hal_ecc_func_vec_t;

typedef struct {
    hal_stk_init_func_t hal_stk_init;
    hal_stk_deinit_func_t hal_stk_deinit;
    hal_dflt_port_default_set_func_t hal_stk_setPortDefault;
    hal_dflt_port_default_set_func_t hal_stk_resetPortDefault;
    hal_stk_my_chip_id_set_func_t hal_stk_my_chip_id_set;
    hal_stk_my_chip_id_get_func_t hal_stk_my_chip_id_get;
    hal_stk_neighbor_chip_id_set_func_t hal_stk_neighbor_chip_id_set;
    hal_stk_neighbor_chip_id_get_func_t hal_stk_neighbor_chip_id_get;
    hal_stk_cutoff_chip_id_set_func_t hal_stk_cutoff_chip_id_set;
    hal_stk_cutoff_chip_id_get_func_t hal_stk_cutoff_chip_id_get;
    hal_stk_stacking_port_add_func_t hal_stk_stacking_port_add;
    hal_stk_stacking_port_del_func_t hal_stk_stacking_port_del;
    hal_stk_stacking_port_get_func_t hal_stk_stacking_port_get;
    hal_stk_path_to_remote_chip_set_func_t hal_stk_path_to_remote_chip_set;
    hal_stk_stacking_port_to_cpu_add_func_t hal_stk_stacking_port_to_cpu_add;
    hal_stk_stacking_port_to_cpu_del_func_t hal_stk_stacking_port_to_cpu_del;
    hal_stk_stacking_port_to_cpu_get_func_t hal_stk_stacking_port_to_cpu_get;
    hal_stk_cpu_path_to_remote_chip_set_func_t hal_stk_cpu_path_to_remote_chip_set;
    hal_stk_dpi_port_get_func_t hal_stk_dpi_port_get;
    hal_stk_dpi_port_add_func_t hal_stk_dpi_port_add;
    hal_stk_dpi_port_del_func_t hal_stk_dpi_port_del;
    hal_stk_dil_entry_set_func_t hal_stk_dil_entry_set;
    hal_stk_dil_entry_get_func_t hal_stk_dil_entry_get;
    hal_stk_ext_chip_di_info_get_func_t hal_stk_ext_chip_di_info_get;
    hal_stk_chip_mode_get_func_t hal_stk_chip_mode_get;
    hal_stk_chip_cfg_set_func_t hal_stk_chip_cfg_set;
    hal_stk_chip_cfg_get_func_t hal_stk_chip_cfg_get;
    hal_stk_fab_port_add_func_t hal_stk_fab_port_add;
    hal_stk_fab_port_del_func_t hal_stk_fab_port_del;
    hal_stk_fab_port_get_func_t hal_stk_fab_port_get;
    hal_stk_path_remote_map_set_func_t hal_stk_path_remote_map_set;
} hal_stk_func_vec_t;

typedef struct {
    hal_intr_enable_func_t hal_intr_enable;
    hal_intr_disable_func_t hal_intr_disable;
} hal_intr_func_vec_t;

typedef struct {
    hal_ecpu_init_func_t hal_ecpu_init;
    hal_ecpu_deinit_func_t hal_ecpu_deinit;
    hal_ecpu_hwinit_func_t hal_ecpu_hw_init;
    hal_dflt_port_default_set_func_t hal_ecpu_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_ecpu_port_dflt_reset;
    hal_ecpu_reboot_func_t hal_ecpu_reboot;
    hal_ecpu_start_func_t hal_ecpu_start;
    hal_ecpu_stop_func_t hal_ecpu_stop;
    hal_ecpu_force_stop_func_t hal_ecpu_force_stop;
    hal_ecpu_readmem_func_t hal_ecpu_memory_read;
    hal_ecpu_diag_log_read_func_t hal_ecpu_diag_log_read;
    hal_ecpu_fw_flash_update_func_t hal_ecpu_flash_fw_update;
    hal_ecpu_fw_path_set_func_t hal_ecpu_fw_path_set;
    hal_ecpu_updatesramfw_func_t hal_ecpu_sram_fw_update;
    hal_ecpu_updatesramrawfw_func_t hal_ecpu_sram_raw_fw_update;
    hal_ecpu_headroom_watermark_clr_func_t hal_ecpu_headroom_watermark_clr;
    hal_ecpu_headroom_is_running_func_t hal_ecpu_headroom_is_running;
    hal_ecpu_intr_register_func_t hal_ecpu_intr_register;
    hal_ecpu_intr_unregister_func_t hal_ecpu_intr_unregister;
    hal_ecpu_intr_to_ecpu_trigger_func_t hal_ecpu_intr_to_ecpu_trigger;
    hal_ecpu_from_ecpu_intr_clr_func_t hal_ecpu_from_ecpu_intr_clr;
    hal_ecpu_from_ecpu_intr_enable_func_t hal_ecpu_from_ecpu_intr_enable;
    hal_ecpu_diag_log_buf_info_get_func_t hal_ecpu_diag_log_buf_info_get;
    hal_ecpu_dtcm_addr_get_func_t hal_ecpu_dtcm_addr_get;
    hal_ecpu_dtcm_on_chain_addr_get_func_t hal_ecpu_dtcm_on_chain_addr_get;
    hal_ecpu_itcm_addr_get_func_t hal_ecpu_itcm_addr_get;
    hal_ecpu_itcm_on_chain_addr_get_func_t hal_ecpu_itcm_on_chain_addr_get;
    hal_ecpu_fw_feature_is_supported_func_t hal_ecpu_fw_feature_is_supported;
    hal_ecpu_fw_dflt_set_func_t hal_ecpu_fw_dflt_set;
    hal_ecpu_fw_dflt_get_func_t hal_ecpu_fw_dflt_get;
    hal_ecpu_fw_running_get_func_t hal_ecpu_fw_running_get;
    hal_ecpu_fw_info_trav_func_t hal_ecpu_fw_info_trav;
    hal_ecpu_port_limit_func_t hal_ecpu_port_limit;
    hal_ecpu_ring_buf_handler_init_func_t hal_ecpu_ring_buf_tx_init;
    hal_ecpu_ring_buf_handler_init_func_t hal_ecpu_ring_buf_rx_init;
} hal_ecpu_func_vec_t;

typedef struct {
    hal_tod_init_func_t hal_tod_init;
    hal_tod_deinit_func_t hal_tod_deinit;
    hal_tod_hw_init_func_t hal_tod_hw_init;
    hal_tod_interrupt_register_func_t hal_tod_interrupt_register;
    hal_tod_interrupt_unregister_func_t hal_tod_interrupt_unregister;
    hal_tod_pps_interrupt_restart_func_t hal_tod_pps_interrupt_restart;
    hal_tod_current_value_get_func_t hal_tod_curent_value_get;
    hal_dflt_port_default_set_func_t hal_tod_port_dflt_set;
    hal_dflt_port_default_set_func_t hal_tod_port_dflt_reset;
} hal_tod_func_vec_t;

typedef struct {
    hal_bfd_init_func_t hal_bfd_init;
    hal_bfd_deinit_func_t hal_bfd_deinit;
    hal_bfd_session_create_func_t hal_bfd_session_create;
    hal_bfd_session_delete_func_t hal_bfd_session_delete;
    hal_bfd_all_session_delete_func_t hal_bfd_all_session_delete;
    hal_bfd_session_update_func_t hal_bfd_session_update;
    hal_bfd_session_cfg_info_get_func_t hal_bfd_session_cfg_info_get;
    hal_bfd_session_next_cfg_get_func_t hal_bfd_session_next_cfg_get;
    hal_bfd_session_pkt_stats_get_func_t hal_bfd_session_pkt_stats_get;
    hal_bfd_session_drop_pkt_stats_get_func_t hal_bfd_session_drop_pkt_stats_get;
    hal_bfd_session_pkt_stats_clear_func_t hal_bfd_session_pkt_stats_clear;
    hal_bfd_session_drop_pkt_stats_clear_func_t hal_bfd_session_drop_pkt_stats_clear;
    hal_bfd_session_status_get_func_t hal_bfd_session_status_get;
    hal_bfd_session_poll_trigger_func_t hal_bfd_session_poll_trigger;
    hal_bfd_session_admin_set_func_t hal_bfd_session_admin_set;
    hal_bfd_session_event_cb_register_func_t hal_bfd_session_event_cb_register;
    hal_bfd_session_event_cb_unregister_func_t hal_bfd_session_event_cb_unregister;
} hal_bfd_func_vec_t;

typedef struct {
    hal_ptp_init_func_t hal_ptp_init;
    hal_ptp_deinit_func_t hal_ptp_deinit;
    hal_ptp_clk_create_func_t hal_ptp_clk_create;
    hal_ptp_clk_destroy_func_t hal_ptp_clk_destroy;
    hal_ptp_clk_cfg_set_func_t hal_ptp_clk_cfg_set;
    hal_ptp_clk_cfg_get_func_t hal_ptp_clk_cfg_get;
    hal_ptp_port_add_func_t hal_ptp_port_add;
    hal_ptp_port_del_func_t hal_ptp_port_del;
    hal_ptp_port_cfg_set_func_t hal_ptp_port_cfg_set;
    hal_ptp_port_cfg_get_func_t hal_ptp_port_cfg_get;
    hal_ptp_port_cnt_get_func_t hal_ptp_port_cnt_get;
    hal_ptp_port_cnt_clr_func_t hal_ptp_port_cnt_clr;
    hal_ptp_clk_rslt_get_func_t hal_ptp_clk_rslt_get;
    hal_ptp_port_wire_delay_get_func_t hal_ptp_port_wire_delay_get;
    hal_ptp_mon_enable_func_t hal_ptp_mon_enable;
    hal_ptp_mon_disable_func_t hal_ptp_mon_disable;
    hal_ptp_mon_cfg_set_func_t hal_ptp_mon_cfg_set;
    hal_ptp_mon_cfg_get_func_t hal_ptp_mon_cfg_get;
    hal_ptp_mon_stat_get_func_t hal_ptp_mon_stat_get;
    hal_ptp_mon_stat_clr_func_t hal_ptp_mon_stat_clr;
    hal_ptp_masters_get_func_t hal_ptp_masters_get;
    hal_ptp_port_state_get_func_t hal_ptp_port_state_get;
} hal_ptp_func_vec_t;

typedef struct {
    /* chip multiplexing functions */
    HAL_CHIP_FUNC_VEC_T *const chip_func_vec;

    /* bd multiplexing functions */
    HAL_BD_FUNC_VEC_T *const bd_func_vec;

    /* vlan multiplexing functions */
    HAL_VLAN_FUNC_VEC_T *const vlan_func_vec;

    /* port multiplexing functions */
    HAL_PORT_FUNC_VEC_T *const port_func_vec;

    /* ifmon multiplexing functions */
    HAL_IFMON_FUNC_VEC_T *const ifmon_func_vec;

    /* l2 multiplexing functions */
    hal_l2_func_vec_t *const l2_func_vec;

    /* stp multiplexing functions */
    HAL_STP_FUNC_VEC_T *const stp_func_vec;

    /* lag multiplexing functions */
    HAL_LAG_FUNC_VEC_T *const lag_func_vec;

    /* mirr multiplexing functions */
    hal_mir_func_vec_t *const mir_func_vec;

    /* l3 multiplexing functions */
    hal_l3_func_vec_t *const l3_func_vec;

    /* iptun multiplexing functions */
    hal_tnl_func_vec_t *const tnl_func_vec;

    /* srv6 multiplexing functions */
    hal_srv6_func_vec_t *const srv6_func_vec;

    /* swc multiplexing functions */

    /* qos multiplexing functions */
    hal_qos_func_vec_t *const qos_func_vec;
    /* rate multiplexing functions */

    /* meter multiplexing functions */
    HAL_METER_FUNC_VEC_T *const meter_func_vec;

    /* pkt multiplexing functions */
    HAL_PKT_FUNC_VEC_T *const pkt_func_vec;

    /* acl multiplexing functions */
    hal_cia_func_vec_t *const cia_func_vec;

    /* stat multiplexing functions */
    hal_stat_func_vec_t *const stat_func_vec;

    /* sec multiplexing functions */
    hal_sec_func_vec_t *const sec_func_vec;

    /* sflow multiplexing functions */
    hal_sflow_func_vec_t *const sflow_func_vec;

    /* tm multiplexing functions */
    HAL_TM_FUNC_VEC_T *const tm_func_vec;

    /* swtich control multiplexing functions */
    hal_swc_func_vec_t *const swc_func_vec;

    /* MPLS multiplexing functions */
    hal_mpls_func_vec_t *const mpls_func_vec;

    /* Stacking multiplexing functions */
    hal_stk_func_vec_t *const stk_func_vec;

    /* TELM multiplexing functions */
    hal_telm_func_vec_t *const telm_func_vec;

    /* ECC multiplexing functions */
    hal_ecc_func_vec_t *const ecc_func_vec;

    /* intr multiplexing functions */
    hal_intr_func_vec_t *const intr_func_vec;

    /* eCPU multiplexing functions */
    hal_ecpu_func_vec_t *const ecpu_func_vec;

    /* eCPU multiplexing functions */
    hal_tod_func_vec_t *const tod_func_vec;

    /* BFD multiplexing functions */
    hal_bfd_func_vec_t *const bfd_func_vec;

    /* PTP multiplexing functions */
    hal_ptp_func_vec_t *const ptp_func_vec;

    /* PHY multiplexing functions */
    HAL_PHY_FUNC_VEC_T *const phy_func_vec;
    HAL_PHY_FUNC_VEC_T *const internal_phy_func_vec;

    /* diag multiplexing functions */
} hal_func_vec_t;

typedef enum hal_alloc_type_e {
    HAL_ALLOC_TYPE_INDEX = 0,
    HAL_ALLOC_TYPE_PROFILE,
    HAL_ALLOC_TYPE_FIELD,
    HAL_ALLOC_TYPE_LAST
} hal_alloc_type_t;

typedef enum hal_sw_tbl_e {
    HAL_SW_IFP_MULTI_DEST_0_ID = HAL_RIM_SW_TBL_BASE_ID,
    HAL_SW_IFP_MULTI_DEST_1_ID,
    HAL_SW_EFP_NVO3_L3IF_0_ID,
    HAL_SW_EFP_NVO3_L3IF_1_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_0_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_0_NON_PRUNE_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_1_ID,
    HAL_SW_TBL_ITM_RSLT_MGID_1_NON_PRUNE_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_0_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_1_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_2_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_3_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_4_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_5_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_6_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_7_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_8_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_9_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_10_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_11_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_12_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_13_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_14_ID,
    HAL_SW_TBL_IEV_RSLT_BNK_15_ID,
    HAL_SW_TBL_EMI_RSLT_0_ID,
    HAL_SW_TBL_EMI_RSLT_1_ID,
    HAL_SW_TBL_EMI_RSLT_2_ID,
    HAL_SW_TBL_EMI_RSLT_3_ID,
    HAL_SW_TBL_EMI_RSLT_4_ID,
    HAL_SW_TBL_EMI_RSLT_5_ID,
    HAL_SW_TBL_EMI_RSLT_6_ID,
    HAL_SW_TBL_EMI_RSLT_7_ID,
    HAL_SW_TBL_EMI_RSLT_8_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_0_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_1_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_2_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_3_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_4_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_5_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_6_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_7_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_8_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_9_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_10_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_11_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_12_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_13_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_14_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_15_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_16_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_17_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_18_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_19_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_20_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_21_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_22_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_23_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_24_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_25_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_26_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_27_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_28_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_29_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_30_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_31_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_32_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_33_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_34_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_35_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_36_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_37_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_38_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_39_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_40_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_41_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_42_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_43_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_44_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_45_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_46_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_47_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_48_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_49_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_50_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_51_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_52_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_53_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_54_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_55_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_56_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_57_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_58_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_59_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_60_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_61_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_62_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_63_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_64_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_65_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_66_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_67_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_68_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_69_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_70_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_71_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_72_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_73_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_74_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_75_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_76_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_77_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_78_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_79_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_80_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_81_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_82_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_83_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_84_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_85_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_86_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_87_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_88_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_89_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_90_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_91_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_92_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_93_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_94_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_95_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_96_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_97_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_98_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_99_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_100_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_101_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_102_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_103_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_104_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_105_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_106_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_107_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_108_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_109_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_110_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_111_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_112_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_113_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_114_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_115_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_116_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_117_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_118_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_119_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_120_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_121_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_122_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_123_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_124_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_125_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_126_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_127_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_128_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_129_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_130_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_131_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_132_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_133_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_134_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_135_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_136_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_137_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_138_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_139_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_140_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_141_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_142_ID,
    HAL_SW_TBL_EMI_RSLT_PAGE_143_ID,
    HAL_SW_TBL_EMI_RSLT_L2_LCL_INTF_ID,
    HAL_SW_TBL_EMI_RSLT_L2_LCL_INTF_DFLT_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_0_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_1_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_2_ID,
    HAL_SW_TBL_EME_RSLT_ENCAP_IP_3_ID,
    HAL_SW_TBL_IDS_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_IDS_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_EME_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_EME_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_IEV_FDL_HSH_U_DBL_0_ID,
    HAL_SW_TBL_IEV_FDL_HSH_U_DBL_1_ID,
    HAL_SW_TBL_FPU_TCAM_L2_UC_ID,
    HAL_SW_TBL_FPU_TCAM_L2_MC_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_0_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_1_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_2_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_3_ID,
    HAL_SW_TBL_RWO_SRAM_NVO3_ENCAP_4_ID,
    HAL_SW_TBL_DIS_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_DIS_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_ECIA_RSLT_PHB_PROF_0_ID,
    HAL_SW_TBL_ECIA_RSLT_PHB_PROF_1_ID,
    HAL_SW_TBL_REP_RSLT_MC_GRP_SZ_L2_ID,
    HAL_SW_TBL_REP_RSLT_MC_GRP_SZ_L3_ID,
    HAL_SW_TBL_REP_RSLT_MC_DB_ID,
    HAL_SW_TBL_FWR_RSLT_TNL_ECMP_MBR_0_ID,
    HAL_SW_TBL_FWR_RSLT_TNL_ECMP_MBR_1_ID,
    MT_NB_TBL_FPU_TCAM_FIB_V4_DIP_ID,
    MT_NB_TBL_FPU_TCAM_FIB_V4_SIP_ID,
    MT_NB_TBL_FPU_TCAM_FIB_V6_DIP_ID,
    MT_NB_TBL_FPU_TCAM_FIB_V6_SIP_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_0_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_1_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_2_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_3_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_4_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_5_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_6_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_7_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_8_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_9_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_10_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_11_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_12_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_13_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_14_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_15_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_16_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_17_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_18_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_19_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_20_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_21_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_22_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_23_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_24_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_25_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_26_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_27_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_28_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_29_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_30_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_31_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_32_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_33_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_34_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_35_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_36_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_37_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_38_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_39_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_40_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_41_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_42_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_43_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_44_ID,
    MT_SW_TBL_FPU_RSLT_AFIB_W_ACL_LBL_45_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_16K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_12K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_8K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_4K_ID,
    MT_SW_REG_CIAT_SLV_TILE_IGR_REGION_0K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_0K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_4K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_8K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_12K_ID,
    MT_SW_REG_CIAT_SLV_TILE_EGR_REGION_16K_ID,
    HAL_SW_TBL_LAST
} hal_sw_tbl_t;

typedef struct hal_alloc_entry_s {
    hal_alloc_type_t type;
    uint32 sw_tbl_id;
    uint32 hw_tbl_id;
    uint32 base_index;
    uint32 length;
    uint32 bc_type;
    union {
        uint32 *ptr_bitmap[HAL_MAX_NUM_OF_PLANE + 1];
        uint32 *ptr_refcnt[HAL_MAX_NUM_OF_PLANE + 1];
    };
} hal_alloc_entry_t;

typedef struct hal_alloc_info_s {
    hal_alloc_entry_t *ptr_alloc_tbl;
    uint32 entry_num;
} hal_alloc_info_t;

typedef struct {
    int32 die;
    int32 bin;
    int32 plane;
    int32 hw_mac_macro;
    int32 tm_mac_macro;
} hal_eth_macro_map_t;

typedef struct {
    uint32 device_id;
    uint32 macro_num;
    hal_eth_macro_map_t *ptr_macro_map;
} hal_eth_macro_info_t;

typedef struct {
    const char *const driver_desc;            /* driver description */
    hal_func_vec_t *const ptr_func_vector;    /* function vector pointer */
    hal_intr_info_t *const ptr_intr_info;     /* INTR information pointer */
    table_info_t **const pptr_tbl_info;       /* chip register/table information */
    packing_info_t **const pptr_tbl_key_info; /* chip table key information for hash */
    tcam_tbl_meta_t *const ptr_tbl_tcam_info;
    hash_tbl_meta_t *const ptr_tbl_hash_info;
    hal_alloc_info_t *const ptr_alloc_info;
    hal_eth_macro_info_t *const ptr_eth_macro_info; /* all mac macro information of this chip family
                                                     */
    hal_ecc_info_t *const ptr_ecc_info;
    hal_const_info_t *ptr_const_info;
    hal_cmn_func_vec_t *const ptr_cmn_func_vector; /* function vector pointer for HAL common */
    hal_pkj_info_t *const ptr_pkj_info;
} hal_driver_t;

typedef clx_error_no_t (*hal_driver_init_func_t)(const uint32 device_id,
                                                 const uint32 revision_id,
                                                 hal_driver_t **pptr_hal_driver);

typedef struct {
    uint32 device_id;                      /* device ID */
    hal_driver_init_func_t hal_initDriver; /* driver handler function pointer */
} hal_device_driver_map_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Hal_drv_device_drv_init() is an API that will use device ID and revision ID to find
 *        correct device driver.
 *
 * @param [in]     device_id          - The device ID of this device. Currently,
 *                                      it will be PCIe's device ID.
 * @param [in]     revision_id        - The revision ID of this device.
 *                                      Currently, it will be PCIe's revision ID.
 * @param [out]    pptr_hal_driver    - The pointer (address) of the HAL device driver that used
 *                                      for this device with the device_id and revision_id.
 * @return         CLX_E_OK        - Initialize the device driver successfully .
 * @return         CLX_E_OTHERS    - Fail to initialize the device driver.
 */
clx_error_no_t
hal_drv_device_drv_init(const uint32 device_id,
                        const uint32 revision_id,
                        hal_driver_t **pptr_hal_driver);

#endif /* #ifndef HAL_DRV_H */
