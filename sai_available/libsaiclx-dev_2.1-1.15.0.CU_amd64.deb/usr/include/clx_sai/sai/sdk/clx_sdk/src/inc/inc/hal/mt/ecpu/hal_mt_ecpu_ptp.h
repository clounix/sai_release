/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_ecpu_ptp.h
 * PURPOSE:
 *  1. To maintain eCPU PTP related API.
 * NOTES:
 */

#ifndef HAL_MT_ECPU_PTP_H
#define HAL_MT_ECPU_PTP_H

#include <clx/clx_ptp.h>

/* ECPU PTP error code */
typedef enum hal_mt_ecpu_ptp_error_e {
    HAL_MT_ECPU_PTP_E_OK = 0,
    HAL_MT_ECPU_PTP_E_MSG_LEN,
    HAL_MT_ECPU_PTP_E_NO_MEM,
    HAL_MT_ECPU_PTP_E_CREATE_CLK,
    HAL_MT_ECPU_PTP_E_DESTROY_CLK,
    HAL_MT_ECPU_PTP_E_HAS_ENABLED,
    HAL_MT_ECPU_PTP_E_NOT_ENABLE,
    HAL_MT_ECPU_PTP_E_ADD_PORT,
    HAL_MT_ECPU_PTP_E_FIND_PORT,
    HAL_MT_ECPU_PTP_E_NOT_FIND_PORT,
    HAL_MT_ECPU_PTP_E_BAD_PARAMETER,
    HAL_MT_ECPU_PTP_E_ONLY_SUPPORT_ONE_PORT,
    HAL_MT_ECPU_PTP_E_REMOVE_PORT,
    HAL_MT_ECPU_PTP_E_SET_TX_ANNOUNCE_INTERVAL,
    HAL_MT_ECPU_PTP_E_SET_RX_ANNOUNCE_TIMEOUT,
    HAL_MT_ECPU_PTP_E_SET_TX_SYNC_INTERVAL,
    HAL_MT_ECPU_PTP_E_SET_RX_SYNC_TIMEOUT,
    HAL_MT_ECPU_PTP_E_SET_TX_DELAY_REQ_INTERVAL,
    HAL_MT_ECPU_PTP_E_SET_TX_PDELAY_REQ_INTERVAL,
    HAL_MT_ECPU_PTP_E_MAX,
} hal_mt_ecpu_ptp_error_t;

/* ECPU PTP host to ecpu request message type */
typedef enum hal_mt_ecpu_ptp_host2ecpu_req_msg_type_e {
    HAL_MT_ECPU_PTP_SET_CLK_ENABLE,
    HAL_MT_ECPU_PTP_SET_CLK_DISABLE,
    HAL_MT_ECPU_PTP_SET_CLK_ATTR,
    HAL_MT_ECPU_PTP_SET_ADD_PORT,
    HAL_MT_ECPU_PTP_SET_DEL_PORT,
    HAL_MT_ECPU_PTP_SET_PORT_ATTR,
    HAL_MT_ECPU_PTP_GET_CLK_ATTR,
    HAL_MT_ECPU_PTP_GET_PORT_ATTR,
    HAL_MT_ECPU_PTP_GET_CLK,
    HAL_MT_ECPU_PTP_GET_PORT_WIRE_DELAY,
    HAL_MT_ECPU_PTP_GET_PORT_STATISTIC,
    HAL_MT_ECPU_PTP_CLR_PORT_STATISTIC,
    HAL_MT_ECPU_PTP_SET_MON_ENABLE,
    HAL_MT_ECPU_PTP_SET_MON_DISABLE,
    HAL_MT_ECPU_PTP_SET_MON_CFG,
    HAL_MT_ECPU_PTP_GET_MON_STATISTIC,
    HAL_MT_ECPU_PTP_CLR_MON_STATISTIC,
    HAL_MT_ECPU_PTP_GET_MASTERS,
    HAL_MT_ECPU_PTP_GET_PORT_STATE,
    HAL_MT_ECPU_PTP_GET_MON_CFG,
} hal_mt_ecpu_ptp_host2ecpu_req_msg_type_t;

/* ECPU PTP host to ecpu notify message type */
typedef enum hal_mt_ecpu_ptp_host2ecpu_notify_msg_type_e {
    HAL_MT_ECPU_PTP_SET_1PPS,
} hal_mt_ecpu_ptp_host2ecpu_notify_msg_type_t;

/* ECPU PTP ecpu to host notify message type */
typedef enum hal_mt_ecpu_ptp_ecpu2host_notify_msg_type_e {
    HAL_MT_ECPU_PTP_LOAD_TOD,
    HAL_MT_ECPU_PTP_LOAD_OFFSET,
} hal_mt_ecpu_ptp_ecpu2host_notify_msg_type_t;

/* ECPU PTP request message header */
typedef struct hal_mt_ecpu_ptp_req_msg_hdr_s {
    uint8 msg_type;
    uint8 seq;
    uint16 len;
    uint32 flag;
    uint8 data[0];
} hal_mt_ecpu_ptp_req_msg_hdr_t;

/* ECPU PTP response message header */
typedef struct hal_mt_ecpu_ptp_resp_msg_hdr_s {
    uint8 msg_type;
    uint8 code;
    uint8 seq;
    uint8 resv[1];
    uint16 len;
    uint8 data[0];
} hal_mt_ecpu_ptp_resp_msg_hdr_t;

/* ECPU PTP notify message header */
typedef struct hal_mt_ecpu_ptp_notify_msg_hdr_s {
    uint8 msg_type;
    uint8 resv[1];
    uint16 len;
    uint8 data[0];
} hal_mt_ecpu_ptp_notify_msg_hdr_t;

typedef struct hal_mt_ecpu_ptp_clk_cfg_s {
    uint64 leap_date;                  /* Leap date */
    uint32 clk_type;                   /* PTP clock type, refer to CLX_PTP_CLK_TYPE_XXX */
    uint32 role;                       /* PTP clock role, refer to CLX_PTP_ROLE_XXX */
    uint32 step_mode;                  /* PTP clock step mode, refer to CLX_PTP_STEP_MODE_XXX */
    uint32 leap_mode;                  /* PTP clock leap mode, refer to CLX_PTP_LEAP_MODE_XXX */
    uint32 utc_offset;                 /* UTC offset */
    uint16 offset_scaled_log_variance; /* Offset scaled log variance, clock quality parameter */
    uint8 domain_number;               /* Domain number */
    uint8 clk_accuracy;                /* Clock accuracy, clock quality parameter */
    uint8 clk_class;                   /* Clock class, clock quality parameter */
    uint8 resv[7];                     /* Reserved */
    uint8 priority1;                   /* Priority1, clock quality parameter */
    uint8 priority2;                   /* Priority2, clock quality parameter */
    clx_clk_id_t clk_id;               /* Clock ID */
    clx_mac_t dst_mac;                 /* Destination MAC address */
} hal_mt_ecpu_ptp_clk_cfg_t;

typedef struct hal_mt_ecpu_ptp_port_cfg_s {
    uint32 port_id;                  /* Port ID */
    uint32 plane_id;                 /* Plane ID */
    uint32 plane_port_id;            /* Plane port ID */
    uint32 macro_id;                 /* Macro ID */
    uint32 role;                     /* Role */
    uint32 network_trans;            /* Network transport */
    uint32 bmca_mode;                /* BMCA mode */
    uint32 delay_mechanism;          /* Delay mechanism */
    uint32 bdid;                     /* BDID */
    int32 delay_asymmetry;           /* Delay asymmetry */
    int32 log_announce_interval;     /* Log announce interval */
    uint32 announce_timeout;         /* Announce timeout */
    int32 log_sync_interval;         /* Log sync interval */
    uint32 sync_timeout;             /* Sync timeout */
    int32 log_min_delayreq_interval; /* Log min delayreq interval */
    int32 log_pdelay_interval;       /* Log pdelay interval */
    clx_ipv4_t src_ip;               /* Source IP */
    uint32 link_status;              /* Link status */
    uint32 inhibit_announce;         /* Inhibit announce */
    clx_ipv6_t src_ip6;              /* Source IP6 */
    clx_mac_t dst_mac;               /* Destination MAC address */
    clx_mac_t src_mac;               /* Source MAC address */
} hal_mt_ecpu_ptp_port_cfg_t;

typedef struct hal_mt_ecpu_ptp_port_wire_delay_s {
    uint32 port_id;
    int64 wire_delay; /* calculated wire delay between local port and peer port */
} hal_mt_ecpu_ptp_port_wire_delay_t;

typedef struct hal_mt_ecpu_ptp_port_cnt_s {
    uint32 port_id;
    clx_ptp_port_msg_cnt_t tx;         /* The counter of transmit messages */
    clx_ptp_port_msg_cnt_t rx;         /* The counter of receive messages */
    clx_ptp_port_msg_cnt_t tx_discard; /* The counter of transmit discard messages */
    clx_ptp_port_msg_cnt_t rx_discard; /* The counter of receive discard messages */
    clx_ptp_port_rx_err_t rx_err;      /* The error information of receive messages */
} hal_mt_ecpu_ptp_port_cnt_t;

typedef struct hal_mt_ecpu_ptp_port_state_s {
    uint32 port_id;
    clx_ptp_state_type_t state; /* The state of the port */
} hal_mt_ecpu_ptp_port_state_t;

/**
 * @brief This API is used to initialize the eCPU PTP module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize the eCPU PTP module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_deinit(const uint32 unit);

/**
 * @brief This API is used to create a clock.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cfg     - Clock configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_clk_create(const uint32 unit, const clx_ptp_clk_cfg_t *cfg);

/**
 * @brief This API is used to destroy a clock.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_clk_destroy(const uint32 unit);

/**
 * @brief This API is used to set the clock attribute.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cfg     - Clock configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_clk_cfg_set(const uint32 unit, const clx_ptp_clk_cfg_t *cfg);

/**
 * @brief This API is used to get the clock attribute.
 *
 * @param [in]     unit    - Device unit number.
 * @param [out]    cfg     - Clock configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_clk_cfg_get(const uint32 unit, clx_ptp_clk_cfg_t *cfg);

/**
 * @brief This API is used to add a port to start ptp.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Port id.
 * @param [in]    cfg        - Port configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_port_add(const uint32 unit, const uint32 port_id, const clx_ptp_port_cfg_t *cfg);

/**
 * @brief This API is used to delete a port from start ptp.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_port_del(const uint32 unit, const uint32 port_id);

/**
 * @brief This API is used to set the port attribute.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Port id.
 * @param [in]    cfg        - Port configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_port_cfg_set(const uint32 unit,
                             const uint32 port_id,
                             const clx_ptp_port_cfg_t *cfg);

/**
 * @brief This API is used to get the port attribute.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port_id    - Port id.
 * @param [out]    cfg        - Port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_port_cfg_get(const uint32 unit, const uint32 port_id, clx_ptp_port_cfg_t *cfg);

/**
 * @brief This API is used to get the clock result.
 *
 * @param [in]     unit     - Device unit number.
 * @param [out]    clock    - Clock result.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_clk_rslt_get(const uint32 unit, clx_ptp_clk_rslt_t *clock);

/**
 * @brief This API is used to get the port wiredelay.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port_id       - Port id.
 * @param [out]    wire_delay    - Port wiredelay.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_port_wire_delay_get(const uint32 unit,
                                    const uint32 port_id,
                                    clx_ptp_port_wire_delay_t *wire_delay);

/**
 * @brief This API is used to get the port statistic.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port_id    - Port id.
 * @param [out]    cnt        - Port pkt tx/rx/discard cnt.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_port_cnt_get(const uint32 unit, const uint32 port_id, clx_ptp_port_cnt_t *cnt);

/**
 * @brief This API is used to clear the port statistic.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_port_cnt_clr(const uint32 unit, const uint32 port_id);

/**
 * @brief This API is used to get the port state.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port_id    - Port id.
 * @param [out]    state      - Port state.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_port_state_get(const uint32 unit,
                               const uint32 port_id,
                               clx_ptp_port_state_t *state);

/**
 * @brief This API is used to enable the monitor.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cfg     - Monitor configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_mon_enable(const uint32 unit, const clx_ptp_mon_cfg_t *cfg);

/**
 * @brief This API is used to disable the monitor.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_mon_disable(const uint32 unit);

/**
 * @brief This API is used to get the monitor statistic.
 *
 * @param [in]     unit    - Device unit number.
 * @param [out]    cfg     - Monitor statistic.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_mon_cfg_get(const uint32 unit, clx_ptp_mon_cfg_t *cfg);

/**
 * @brief This API is used to set the monitor configuration.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cfg     - Monitor configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_mon_cfg_set(const uint32 unit, const clx_ptp_mon_cfg_t *cfg);

/**
 * @brief This API is used to get the monitor statistic.
 *
 * @param [in]     unit    - Device unit number.
 * @param [out]    stat    - Monitor statistic.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_mon_stat_get(const uint32 unit, clx_ptp_mon_stat_t *stat);

/**
 * @brief This API is used to clear the monitor statistic.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_mon_stat_clr(const uint32 unit);

/**
 * @brief This API is used to get the masters.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    masters    - Masters.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_ptp_masters_get(const uint32 unit, clx_ptp_masters_info_t *masters);

#endif /* HAL_MT_ECPU_PTP_H */
