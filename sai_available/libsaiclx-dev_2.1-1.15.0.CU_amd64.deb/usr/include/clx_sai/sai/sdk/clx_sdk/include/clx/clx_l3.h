/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_l3.h
 * PURPOSE:
 *      It provide L3 module API.
 * NOTES:
 *
 */
#ifndef CLX_L3_H
#define CLX_L3_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_vlan.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
#define CLX_L3_MCAST_FLAGS_WITH_ID (1U << 1) /* Use the specified multicast ID while creating */

/* Create l3 index with specified type and resource index */
#define CLX_L3_ID_CREATE(type, idx) ((((type) & 0xFF) << 24) | ((idx) & 0xFFFFFF))
#define CLX_L3_ECMP_RESERVE_PATH_ID (CLX_L3_ID_CREATE(CLX_L3_ADJ_TYPE_L3, 0))

typedef struct clx_l3_addr_s {
    uint32 vrf_id;         /* virtual routing forwarding ID */
    clx_ip_addr_t ip_addr; /* ip address */
    uint32 opt_exist;      /* v4 or v6 option hdr exist, only l3 route needed */
    uint32 flags;          /* for detailed info, refer to CLX_L3_ADDR_FLAGS_XX */
} clx_l3_addr_t;
/* global route or not, only l3 route needed, the vrf_id field is wildcard */
#define CLX_L3_ADDR_FLAGS_GLB_ROUTE (1U << 0)
/* the opt_exist field is valid or not, only l3 route needed */
#define CLX_L3_ADDR_FLAGS_OPT_EXIST_VLD (1U << 1)

/* L3 URPF Check Mode, per Interface Configurable */
typedef enum clx_l3_urpf_mode_e {
    CLX_L3_URPF_MODE_DISABLED = 0,      /* no rpf check */
    CLX_L3_URPF_MODE_STRICT,            /* strict mode: igr interface of packet must
                                         * equal to egr interface of search result when
                                         * search sip in fib table, check pass, else
                                         * check fail
                                         */
    CLX_L3_URPF_MODE_LOOSE,             /* loose mode: if find match route when search
                                         * sip in fib table, check pass, else check fail.
                                         */
    CLX_L3_URPF_MODE_LOOSE_IGNORE_DFLT, /* if find match non-default route when
                                         * search sip in fib table, check pass,
                                         * else check fail
                                         */
    CLX_L3_URPF_MODE_LAST
} clx_l3_urpf_mode_t;

/* L3 MCAST forwarding action */
typedef enum clx_l3_mcast_act_e {
    CLX_L3_MCAST_ACT_DROP = 0,  /* drop when mcast miss or rpf check fail */
    CLX_L3_MCAST_ACT_SEND2CPU,  /* send to cpu when mcast miss or rpf check fail */
    CLX_L3_MCAST_ACT_L2MC_LKUP, /* fallback to l2 when mcast miss or rpf check fail */
    CLX_L3_MCAST_ACT_NONE,      /* no mcast rpf check */
    CLX_L3_MCAST_ACT_FORWARD,   /* forwarding when mcast lookup miss */
    CLX_L3_MCAST_ACT_LAST
} clx_l3_mcast_act_t;

/* IP Multicast Egress Interface Type */
typedef enum clx_l3_mcast_egr_intf_type_e {
    CLX_L3_MCAST_EGR_INTF_TYPE_L3 = 0, /* l3 */
    CLX_L3_MCAST_EGR_INTF_TYPE_TNL,    /* nvo3 */
    CLX_L3_MCAST_EGR_INTF_TYPE_MPLS,   /* mpls */
    CLX_L3_MCAST_EGR_INTF_TYPE_LAST
} clx_l3_mcast_egr_intf_type_t;

/* L3 Interface Information */
typedef struct clx_l3_intf_igr_s {
    uint16 mtu_size;               /* mtu size */
    clx_fwd_action_t mtu_fail_act; /* mtu check fail action */
    uint32 cnt_id;                 /* counter id */
    uint32 dist_cnt_id;            /* distribution counter id */
    clx_sample_t sample;           /* sample configuration */
    uint32 mir_session_bmp;        /* mirror session bitmap */
    uint32 meter_id;               /* meter id */
} clx_l3_intf_igr_t;

typedef struct clx_l3_intf_egr_s {
    uint16 mtu_size;               /* mtu size */
    clx_fwd_action_t mtu_fail_act; /* mtu check fail action */
    uint32 cnt_id;                 /* counter id */
    uint32 dist_cnt_id;            /* distribution counter id */
    clx_sample_t sample;           /* sample configuration */
    uint32 mir_session_bmp;        /* mirror session bitmap */
    uint32 meter_id;               /* meter id */
} clx_l3_intf_egr_t;

typedef struct clx_l3_intf_s {
    uint32 intf_id;                        /* L3 interface ID */
    clx_bridge_domain_t bdid;              /* while create l3if for both bridging
                                            * and routing l2 interface, need to create
                                            * bridge domain by this bdid firstly,
                                            * otherwise, interface cannot work correctly
                                            */
    uint32 vrf_id;                         /* vrf id for the l3if */
    clx_l3_intf_igr_t igr;                 /* setting for l3if ingress */
    clx_l3_intf_egr_t egr;                 /* setting for l3if egress */
    clx_fwd_action_t urpf_fail_act;        /* ipv4/6 uc rpf check fail action */
    clx_l3_urpf_mode_t urpf_mode;          /* refer to the enum definition for detailed info */
    clx_l3_mcast_act_t ipv4_lkup_miss_act; /* ipv4 mc lookup miss action */
    clx_l3_mcast_act_t ipv6_lkup_miss_act; /* ipv6 mc lookup miss action */
    clx_l3_mcast_act_t ipv4_mrpf_fail_act; /* ipv4 mc rpf check fail action */
    clx_l3_mcast_act_t ipv6_mrpf_fail_act; /* ipv6 mc rpf check fail action */
    clx_mac_t mac;                         /* l3if mac, it will be used as smac
                                            * when ip packet is egressed from the l3if
                                            */
    uint32 rmac_idx;                       /* the index of my router mac,
                                            * update rmac when the field is specified
                                            */
    uint32 flags;                          /* for detailed info, refer to CLX_L3_INTF_FLAGS_XX */
} clx_l3_intf_t;
#define CLX_L3_INTF_FLAGS_IPV4_UC_EN      (1U << 0) /* ipv4 uc enable for the l3if */
#define CLX_L3_INTF_FLAGS_IPV4_MC_EN      (1U << 1) /* ipv4 mc enable for the l3if */
#define CLX_L3_INTF_FLAGS_IPV6_UC_EN      (1U << 2) /* ipv6 uc enable for the l3if */
#define CLX_L3_INTF_FLAGS_IPV6_MC_EN      (1U << 3) /* ipv6 mc enable for the l3if */
#define CLX_L3_INTF_FLAGS_SA_KEEP         (1U << 4) /* keep smac when packet forward from the l3if */
#define CLX_L3_INTF_FLAGS_DA_KEEP         (1U << 5) /* keep dmac when packet forward from the l3if */
#define CLX_L3_INTF_FLAGS_VLAN_KEEP       (1U << 6) /* keep vlan when packet forward from the l3if */
#define CLX_L3_INTF_FLAGS_ICMPV4_REDIR_EN (1U << 7)   /* icmpv4 redirect check enable */
#define CLX_L3_INTF_FLAGS_ICMPV6_REDIR_EN (1U << 8)   /* icmpv6 redirect check enable */
#define CLX_L3_INTF_FLAGS_IPV4_OPT_HDR_SW_FWD_EN                                             \
    (1U << 9)                                         /* v4 packet with option hdr would     \
                                                       * trap to cpu for software forwarding \
                                                       */
#define CLX_L3_INTF_FLAGS_IPV6_OPT_HDR_SW_FWD_EN                                             \
    (1U << 10)                                        /* v6 packet with option hdr would     \
                                                       * trap to cpu for software forwarding \
                                                       */
#define CLX_L3_INTF_FLAGS_WITH_ID          (1U << 11) /* using the input l3if id */
#define CLX_L3_INTF_FLAGS_IGR_METER_VLD    (1U << 12) /* igr meter id is valid */
#define CLX_L3_INTF_FLAGS_EGR_METER_VLD    (1U << 13) /* egr meter id is valid */
#define CLX_L3_INTF_FLAGS_IGR_CNT_VLD      (1U << 14) /* igr counter id is valid */
#define CLX_L3_INTF_FLAGS_EGR_CNT_VLD      (1U << 15) /* egr counter id is valid */
#define CLX_L3_INTF_FLAGS_IGR_DIST_CNT_VLD (1U << 16) /* igr dist counter id is valid */
#define CLX_L3_INTF_FLAGS_EGR_DIST_CNT_VLD (1U << 17) /* egr dist counter id is valid */
#define CLX_L3_INTF_FLAGS_IGR_MIR_VLD      (1U << 18) /* igr mir session bmp is valid */
#define CLX_L3_INTF_FLAGS_EGR_MIR_VLD      (1U << 19) /* egr mir session bmp is valid */
#define CLX_L3_INTF_FLAGS_RMAC_CHK_SKIP    (1U << 20) /* skip router mac check */
#define CLX_L3_INTF_FLAGS_RMAC_IDX_VLD     (1U << 21) /* the rmac_idx field is valid */

/* IP Host Information */
typedef struct clx_l3_host_s {
    clx_l3_addr_t addr; /* host ip address */
    clx_nhp_t nhp;      /* the nexthop info, tnl type not support */
    uint32 mpls_lbl;    /* the label of mpls */
    uint32 grp_lbl;     /* the label of cia */
    uint32 sa_dc;       /* pim-sm source dr flag */
    uint32 flags;       /* for detailed info, refer to CLX_L3_HOST_FLAGS_XX */
} clx_l3_host_t;
#define CLX_L3_HOST_FLAGS_DROP          (1U << 0) /* it means the nhp field is invalid */
#define CLX_L3_HOST_FLAGS_TTL_KEEP      (1U << 1) /* ttl no change */
#define CLX_L3_HOST_FLAGS_SIP_HIT       (1U << 2) /* indicates entry was hit on sip */
#define CLX_L3_HOST_FLAGS_MPLS_LBL_EN   (1U << 3) /* mpls label enable */
#define CLX_L3_HOST_FLAGS_FLUSH_GRP_LBL (1U << 4) /* flush host Match group_label. */

/* Subnet Broadcast Information */
typedef struct clx_l3_subnet_bcast_s {
    clx_l3_addr_t addr;                              /* subnet bcast address */
    uint32 grp_lbl;                                  /* the label of cia */
    uint32 mcast_id;                                 /* multicast id */
    uint32 flags;                                    /* refer to CLX_L3_SUBNET_BCAST_FLAGS_XX */
} clx_l3_subnet_bcast_t;
#define CLX_L3_SUBNET_BCAST_FLAGS_TTL_KEEP (1U << 0) /* ttl no change */

/* IP Route Information */
typedef struct clx_l3_route_s {
    clx_l3_addr_t addr; /* route ip address */
    clx_nhp_t nhp;      /* the nexthop info, tnl type not support */
    uint32 grp_lbl;     /* the label of cia */
    uint32 mpls_lbl;    /* the label of mpls */
    uint32 flags;       /* for detailed info, refer to CLX_L3_ROUTE_FLAGS_XX */
    uint32 attr_bitmap; /* for detailed info, refer to CLX_L3_ROUTE_ATTR_XX  */
} clx_l3_route_t;
#define CLX_L3_ROUTE_FLAGS_DROP        (1U << 0) /* it means the nhp field is invalid */
#define CLX_L3_ROUTE_FLAGS_TTL_KEEP    (1U << 1) /* ttl no change */
#define CLX_L3_ROUTE_FLAGS_SIP_HIT     (1U << 2) /* indicates entry was hit on sip */
#define CLX_L3_ROUTE_FLAGS_MPLS_LBL_EN (1U << 3) /* mpls label enable */

#define CLX_L3_ROUTE_ATTR_ACTION  (1U << 0)      /* Only set drop flag field.   */
#define CLX_L3_ROUTE_ATTR_OUTPUT  (1U << 1)      /* Only set output info.       */
#define CLX_L3_ROUTE_ATTR_GRP_LBL (1U << 2)      /* Only set grp label info.    */

typedef struct clx_l3_bulk_route_s {
    uint32 route_cnt;           /* the count of route to add/del/get */
    clx_l3_route_t *route_info; /* route information array, while del/get, route addr need only */
    clx_error_no_t *rc;         /* output all of the return code for add/del/get */
} clx_l3_bulk_route_t;

/* Ecmp Algorithm mode */
typedef enum clx_l3_ecmp_algo_mode_e {
    CLX_L3_ECMP_ALGO_MODE_HI = 0, /* use act list only */
    CLX_L3_ECMP_ALGO_MODE_LO,     /* use org list only */
    CLX_L3_ECMP_ALGO_MODE_BOTH,   /* use org and act list both */
    CLX_L3_ECMP_ALGO_MODE_LAST
} clx_l3_ecmp_algo_mode_t;

/* ECMP Hash Configuration */
typedef struct clx_l3_ecmp_hsh_cfg_s {
    clx_l3_ecmp_algo_mode_t algo_mode; /* Different algorithms correspond to different path
                                          selection results*/

    uint32 hsh_val_cnt;                /* configured hash value count */
    uint32 hsh_sel;                    /* select which hash engine */
    uint32 flags;                      /* refer to CLX_L3_ECMP_HSH_FLAGS_XX */
} clx_l3_ecmp_hsh_cfg_t;
#define CLX_L3_ECMP_HSH_FLAGS_ALGO_MODE (1U << 0) /* set algo_mode */
#define CLX_L3_ECMP_HSH_FLAGS_SEL_EN    (1U << 1) /* set hsh_sel */

/* ECMP Group Configuration */
typedef struct clx_l3_ecmp_grp_s {
    uint32 ecmp_id;
    clx_nhp_type_t type;           /* Group type not support CLX_NHP_TYPE_ECMP. */
    uint32 path_cnt;               /* The total ecmp path number currently. This number
                                    * is valid only when user uses clx_l3_ecmp_grp_get to
                                    * get ECMP group information.
                                    */
    uint32 weight_cnt;             /* The total ecmp group weight currently. This
                                    * number is valid only when user uses clx_l3_ecmp_grp_get
                                    * to get ECMP group information.
                                    */
    clx_l3_ecmp_hsh_cfg_t hsh_cfg; /* Refer to clx_l3_ecmp_hsh_cfg_t. */
    uint32 orig_tot;               /* only for FLEX,orig list path num. */
    uint32 act_tot;                /* only for FLEX,act list path num. */

    uint32 flags;                  /* Refer to CLX_L3_ECMP_GRP_FLAGS_XX. */
} clx_l3_ecmp_grp_t;
#define CLX_L3_ECMP_GRP_FLAGS_WECMP      (1U << 0) /* weighted ecmp enable */
#define CLX_L3_ECMP_GRP_FLAGS_ORDER      (1U << 1) /* ordered ecmp enable */
#define CLX_L3_ECMP_GRP_FLAGS_FINE_GRAIN (1U << 2) /* fine grain ecmp enable */
#define CLX_L3_ECMP_GRP_FLAGS_WITH_ID    (1U << 3) /* set ecmp with the input id */
#define CLX_L3_ECMP_GRP_FLAGS_FLEX       (1U << 4) /* FLEX ecmp enable */
#define CLX_L3_ECMP_GRP_FLAGS_ORIG_TOT   (1U << 5) /* only for FLEX, modify orig_tot. */
#define CLX_L3_ECMP_GRP_FLAGS_ACT_TOT    (1U << 6) /* only for FLEX, modify act_tot. */

/* ECMP Path for Hash Value and Next Hop Configuration */
typedef struct clx_l3_ecmp_path_s {
    uint32 ecmp_id;
    clx_nhp_type_t type;   /* Path type not support CLX_L3_OUTPUT_TYPE_ECMP. */
    uint32 output_path_id; /* L3 adjacency ID, NVO3 adjacency ID or MPLS port. */
    uint32 mpls_adj_id;    /* New in CL8600, L3 adjacency ID. */
    uint32 monitor_id;     /* Rebalance monitor ID which is used by DLB. If it
                            * is not set, fill in 0. */
    uint32 mpls_lbl;       /* MPLS label */
    uint32 weight;         /* The weight of weighted ECMP path. */
    uint32 state;          /* only for FLEX,The state of path. */
    uint32 flags;          /* Refer to CLX_L3_ECMP_PATH_FLAGS_XX. */
} clx_l3_ecmp_path_t;
#define CLX_L3_ECMP_PATH_FLAGS_MPLS_LBL_VLD (1U << 0) /* the mpls_label field is valid */
#define CLX_L3_ECMP_PATH_FLAGS_STATE        (1U << 1) /* only for FLEX, set state */

typedef struct clx_l3_ecmp_path_state_s {
    uint32 index;          /*member index*/
    uint32 output_path_id; /* L3 adjacency ID, NVO3 adjacency ID or MPLS port. */
    uint32 is_active;
    uint32 is_new;
} clx_l3_ecmp_path_state_t;

typedef struct clx_l3_ecmp_all_path_s {
    uint32 ecmp_id;
    clx_l3_ecmp_algo_mode_t algo_mode;
    uint32 orig_tot; /* only for FLEX,orig list path num. */
    uint32 act_tot;  /* only for FLEX,act list path num. */
    clx_l3_ecmp_path_state_t orig_list[1023];
    clx_l3_ecmp_path_state_t act_list[1023];
} clx_l3_ecmp_all_path_t;

typedef struct clx_l3_ecmp_path_hsh_s {
    clx_l3_ecmp_path_t path; /* path info */
    uint32 hsh_cnt;          /* hash count */
    uint32 *hsh_val;         /* hash value array */
} clx_l3_ecmp_path_hsh_t;

/* ecmp hash path result info */
typedef struct clx_l3_ecmp_path_hsh_rslt_s {
    uint32 hash_value;   /* flow hash value, hash value only use 0-11 bit */
    uint32 hash_path_di; /* ecmp hash path di */
    uint32 hash_path_bd; /* ecmp hash path bd */
    uint32 output_type;  /* ecmp member type  */
    uint32 output_id;    /* ecmp member id    */
    clx_gport_type_t port_type;
    uint32 port_id;
} clx_l3_ecmp_path_hsh_rslt_t;

/* Frr Configuration */
typedef enum clx_l3_frr_type_e {
    CLX_L3_FRR_TYPE_ADJ = 0, /* l3 adj type for l3 frr path */
    CLX_L3_FRR_TYPE_MPLS,    /* mpls transit type for frr path */
    CLX_L3_FRR_TYPE_LAST
} clx_l3_frr_type_t;

typedef struct clx_l3_frr_s {
    clx_l3_frr_type_t type; /* frr type */
    uint32 frr_id;          /* the Fast re-reute ID */
} clx_l3_frr_t;

/* Frr Path Configuration */
typedef struct clx_l3_frr_path_s {
    uint32 frr_id;    /* fast-reroute id */
    clx_nhp_t nhp;    /* nexthop path info */
    boolean isbackup; /* whether the backup path */
    uint32 mpls_lbl;  /* mpls label */
    uint32 flags;     /* for detailed info, fefer to CLX_L3_FRR_PATH_FLAGS_XX */
} clx_l3_frr_path_t;
#define CLX_L3_FRR_PATH_FLAGS_MPLS_LBL_VLD (1U << 0) /* the mpls_lbl field is valid */

/* My Router MAC Information */
typedef struct clx_l3_rmac_s {
    uint32 idx;        /* the hardware index of MyRouterMAC table */
    clx_mac_t mac;     /* router mac addr */
    clx_mac_t mac_msk; /* router mac mask */
    uint32 intf_id;    /* ifidx */
    uint32 intf_msk;   /* ifidx mask */
    uint32 flags;      /* for detailed info, refer to CLX_L3_RMAC_FLAGS_XX */
} clx_l3_rmac_t;
/* flex rmac mode support bind multiple mac addr, if set that the intf_id is flex rmac index */
#define CLX_L3_RMAC_FLAGS_FLEX (1U << 0)
/* global rmac, only for flex rmac mode */
#define CLX_L3_RMAC_FLAGS_GLB (1U << 1)

/* VRF Information */
typedef struct clx_l3_vrf_s {
    uint32 vrf_id;                                /* virtual routing forwarding ID */
    uint32 ipv4_state;                            /* ipv4 admin state control */
    uint32 ipv6_state;                            /* ipv6 admin state control */
    uint32 flags;                                 /* Refer to CLX_L3_VRF_FLAGS_XX */
} clx_l3_vrf_t;
#define CLX_L3_VRF_FLAGS_IPV4_ADMIN_VLD (1U << 0) /* ipv4 admin state valid */
#define CLX_L3_VRF_FLAGS_IPV6_ADMIN_VLD (1U << 1) /* ipv6 admin state valid */

typedef struct clx_l3_mcast_addr_s {
    uint32 vrf_id;          /* vrf id as KEY of the mcast group */
    clx_ip_addr_t src_addr; /* src addr as KEY of the mcast group, which needs to be set
                             * for (S, G) group, for (, G) group, src addr must be set to 0,
                             * and the ip version must be the same with group ip.
                             */
    clx_ip_addr_t grp_addr; /* group addr as KEY of the mcast group */
} clx_l3_mcast_addr_t;

typedef struct clx_l3_mcast_df_intf_s {
    uint32 intf_id;         /* the df interface */
    uint32 rp_cnt;          /* the rp addr count */
    clx_ip_addr_t *rp_addr; /* the rp addr array */
} clx_l3_mcast_df_intf_t;

/* IP Multicast Route Information */
typedef struct clx_l3_mcast_route_s {
    clx_l3_mcast_addr_t addr;        /* l3 multicast router address */
    uint32 mcast_id;                 /* mcast forwarding id */
    clx_ip_addr_t rp_addr;           /* rendezvous point addr which used in BIDIR-PIM protocol
                                      * can use clx_l3_mcast_df_intf_add to add the rp addr to
                                      * the df state for one interface.
                                      */
    clx_l3_mcast_act_t rpf_fail_act; /* if mcast rpf check fail, mcast packet
                                      * will forward by the setting of this field
                                      */
    uint32 rpf_intf_id;              /* interface id used by rpf check,
                                      * if CLX_L3_MCAST_ROUTE_FLAGS_PIM_BIDIR flag is set to 1,
                                      * the rpf check will fail when the ingress interface
                                      * is not included in the DF interface of this group.
                                      * if CLX_L3_MCAST_ROUTE_FLAGS_PIM_BIDIR flag is set to 0,
                                      * the rpf check will fail when the ingress interface
                                      * is not equal to rpf_intf_id.
                                      */
    uint32 flags;                    /* for detailed info, refer to CLX_L3_MCAST_ROUTE_FLAGS_XXX */
} clx_l3_mcast_route_t;
#define CLX_L3_MCAST_ROUTE_FLAGS_PIM_BIDIR                                           \
    (1U << 0)                                     /* Per G entry                     \
                                                   * If set to 1, PIM-BIDIR support, \
                                                   * else support PIM-SM             \
                                                   */
#define CLX_L3_MCAST_ROUTE_FLAGS_DROP                                                   \
    (1U << 1)                                     /* Per (*,G) or (S,G)                 \
                                                   * If set to 1, the packet match this \
                                                   * group entry will be dropped.       \
                                                   */
#define CLX_L3_MCAST_ROUTE_FLAGS_KEEP_TTL                                         \
    (1U << 2)                                     /* Per (*,G) or (S,G)           \
                                                   * If set to 1, not modify TTL, \
                                                   * else modify TTL.             \
                                                   */
#define CLX_L3_MCAST_ROUTE_FLAGS_SPT_READY                                                               \
    (1U << 3)                                     /* Per (S,G) group config                              \
                                                   * If set to 1, forward packet from S to G.            \
                                                   * If use PIM-SM protocol, before the Short-Path       \
                                                   * tree is ready, the flag should be set to 0,         \
                                                   * mcast packet will send to CPU and encapsulated      \
                                                   * as unicast packet, then, routing to RP. RP will     \
                                                   * unpack the tunnel packet back to mcast packet       \
                                                   * and send to host join the grp. After Short-Path     \
                                                   * tree is ready, hardware table entry for mcast       \
                                                   * packet forwarding is OK, the bit should be set to 1 \
                                                   * the mcast packet will not be send to CPU again.     \
                                                   */
#define CLX_L3_MCAST_ROUTE_FLAGS_HIT    (1U << 4) /* indicates mcast group hit */
#define CLX_L3_MCAST_ROUTE_FLAGS_TO_CPU (1U << 5) /* copy to cpu */
#define CLX_L3_MCAST_ROUTE_FLAGS_SA_DC                                                 \
    (1U << 6)                                     /* src ip direct connect to src DR,  \
                                                   * means need to encap mc to uc pkt, \
                                                   * CL8600 new field                  \
                                                   */

/* IP Multicast Egress Interface Setting For TNL */
typedef struct clx_l3_mcast_egr_intf_tnl_s {
    clx_tnl_info_t tnl_key; /* MC Tunnel */
    clx_port_t port;        /* UC Tunnel */
    uint32 nvo3_adj_id;     /* For tunnel encapsulation */
} clx_l3_mcast_egr_intf_tnl_t;

/* IP Multicast Egress Interface Setting For MPLS */
typedef struct clx_l3_mcast_egr_intf_mpls_s {
    clx_port_t port;    /* tunnel port */
    uint32 nvo3_adj_id; /* for tunnel encapsulation */
    uint32 mpls_lbl;    /* mpls label */
    uint32 swap_lbl;    /* mpls lsp label */
    uint32 flags;       /* for detailed info, refer to CLX_L3_MCAST_EGR_MPLS_FLAGS_XX */
} clx_l3_mcast_egr_intf_mpls_t;
#define CLX_L3_MCAST_EGR_MPLS_FLAGS_LBL     (1U << 0) /* the mpls_lbl field is valid */
#define CLX_L3_MCAST_EGR_MPLS_FLAGS_TNL     (1U << 1) /* the port field is valid */
#define CLX_L3_MCAST_EGR_MPLS_FLAGS_TRANSIT (1U << 2) /* transit valid */
#define CLX_L3_MCAST_EGR_MPLS_FLAGS_IS_SWAP (1U << 3) /* the swap_lbl is valid */

/* IP Multicast Egress Interface Setting */
typedef struct clx_l3_mcast_egr_intf_s {
    clx_l3_mcast_egr_intf_type_t intf_type; /* type of mcast egr interface */
    uint32 intf_id;                         /* egr l3if id */
    uint32 port_num;                        /* the egress port num */
    clx_port_t *port_list;                  /* the egress port list */
    union {
        clx_l3_mcast_egr_intf_tnl_t tnl;    /* egr setting for intf of nvo3 */
        clx_l3_mcast_egr_intf_mpls_t mpls;  /* egr setting for intf of mpls */
    };
} clx_l3_mcast_egr_intf_t;

typedef struct clx_l3_mcast_egr_s {
    uint32 mcast_id;               /* mcast forwarding id */
    uint32 intf_cnt;               /* the egress interface count */
    clx_l3_mcast_egr_intf_t *intf; /* the egress interface info array */
} clx_l3_mcast_egr_t;

/* Adjacency type */
typedef enum clx_l3_adj_type_e {
    CLX_L3_ADJ_TYPE_L3 = 0, /* l3 adjacency */
    CLX_L3_ADJ_TYPE_TNL,    /* nvo3 adjacency */
    CLX_L3_ADJ_TYPE_LAST
} clx_l3_adj_type_t;

/* Adjacency Information */
typedef struct clx_l3_adj_s {
    uint32 adj_id;                          /* adj id */
    clx_l3_adj_type_t type;                 /* adj type */
    clx_port_t port;                        /* dst intf port id */
    uint32 intf_id;                         /* egr l3if id */
    clx_vlan_t cvid;                        /* vlan id for customer, only nvo3 support */
    clx_mac_t dmac;                         /* dst mac */
    clx_mac_t smac;                         /* src mac, nvo3 only */
    uint8 pcp;                              /* nvo3 only, tag pcp for outer hdr vlan,
                                             * implemented by clx_tnl_entry_encap_add originally
                                             */
    uint8 dei;                              /* nvo3 only, tag dei for outer hdr vlan,
                                             * implemented by clx_tnl_entry_encap_add originally
                                             */
    uint16 mtu_size;                        /* nvo3 only */
    uint32 frr_id;                          /* fast-reroute group id */
    uint32 frr_backup_path;                 /* backup adj id for fast-reroute */
    uint32 flags;                           /* for detailed info, refer to CLX_L3_ADJ_FLAGS_XX */
} clx_l3_adj_t;
#define CLX_L3_ADJ_FLAGS_CVID_VLD (1U << 0) /* whether cvid inserted to pkt, nov3 support */
#define CLX_L3_ADJ_FLAGS_DA_VLD   (1U << 1) /* whether dmac inserted to pkt */
#define CLX_L3_ADJ_FLAGS_FRR_EN   (1U << 2) /* fast-reroute enable for the adj */
#define CLX_L3_ADJ_FLAGS_WITH_ID  (1U << 3) /* set adj with the input id */
/* black hole, the port field will be invalid \
 * support l3 unicast host or route only,     \
 * not support frr, ecmp and nvo3             \
 */
#define CLX_L3_ADJ_FLAGS_DROP (1U << 4)
/* copy pcp and dei from inner frame,      \
 * set to 1, pcp & dei from inner vlan tag \
 * set to 0, use specific pcp & dei        \
 */
#define CLX_L3_ADJ_FLAGS_QOS_TNL_UNIFORM (1U << 5)

/* host type */
typedef enum clx_l3_host_type_e {
    CLX_L3_HSH_V4_V6 = 0,
    CLX_L3_HSH_V4,
    CLX_L3_HSH_V6,
    CLX_L3_TCAM_V4,
    CLX_L3_TCAM_V6,
    CLX_L3_V4_ALL,
    CLX_L3_V6_ALL,
    CLX_L3_HOST_TYPE_LAST
} clx_l3_host_type_t;

/* l3 param type */
typedef enum clx_l3_param_e {
    CLX_L3_PARAM_V4_V6 = CLX_SWC_L3_RSRC_TYPE_LAST,
    CLX_L3_PARAM_V4,
    CLX_L3_PARAM_V6,
    CLX_L3_PARAM_V6_2X,
    CLX_L3_PARAM_V6_4X,
    CLX_L3_PARAM_TYPE_LAST
} clx_l3_param_t;

/* -------------------------------------------------------------- Traverse Callbacks */
typedef clx_error_no_t (*clx_l3_adj_trav_func_t)(const uint32 unit,
                                                 const clx_l3_adj_t *ptr_adj,
                                                 void *ptr_cookie);

typedef clx_error_no_t (*clx_l3_intf_trav_func_t)(const uint32 unit,
                                                  const clx_l3_intf_t *ptr_intf,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*clx_l3_rmac_trav_func_t)(const uint32 unit,
                                                  const clx_l3_rmac_t *ptr_rmac,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*clx_l3_ecmp_grp_trav_func_t)(const uint32 unit,
                                                      const uint32 ecmp_grp_id,
                                                      const clx_l3_ecmp_grp_t *ptr_ecmp_grp_info,
                                                      const clx_l3_ecmp_path_t *ptr_ecmp_path_info,
                                                      void *ptr_cookie);

typedef clx_error_no_t (*clx_l3_host_trav_func_t)(const uint32 unit,
                                                  const clx_l3_host_t *ptr_host,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*clx_l3_bcast_trav_func_t)(const uint32 unit,
                                                   const clx_l3_subnet_bcast_t *ptr_bcast,
                                                   void *ptr_cookie);

typedef clx_error_no_t (*clx_l3_route_trav_func_t)(const uint32 unit,
                                                   const clx_l3_route_t *ptr_route,
                                                   void *ptr_cookie);

typedef clx_error_no_t (*clx_l3_mcast_route_trav_func_t)(const uint32 unit,
                                                         const clx_l3_mcast_route_t *ptr_mc_route,
                                                         void *ptr_cookie);

/**
 * @brief The API is used to get the interface information according to the specified interface ID.
 *
 * The user must create the interface first. If the IP network address bound to this interface
 * cannot be obtained, the user needs to use clx_l3_host_get and clx_l3_route_get to retrieve the
 * added host and route entries.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_intf    - The intf_id must be provided.
 * @param [out]    ptr_intf    - The interface property, including MAC,
 *                               VRF ID, MTU, URPF check mode, etc.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified interface has not been created.
 */
clx_error_no_t
clx_l3_intf_get(const uint32 unit, clx_l3_intf_t *ptr_intf);

/**
 * @brief The API is used to add the interface based on bridge domain ID.
 *        User should specify the bridge domain ID and the interface configuration.
 *
 * The user needs to create the bridge domain with this bridge domain ID first. Otherwise, the
 * interface cannot work correctly.
 * The user only needs to fill in the VRF ID and MAC if a VLAN-based interface is created.
 * If this L3 interface exists, the API may change the configuration of the interface.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_intf    - The interface information. If flags & CLX_L3_INTF_FLAGS_WITH_ID is
 *                               set, it means the L3 interface exists,
 *                               and the API will change the configuration of this interface.
 * @param [out]    ptr_intf    - The intf_id will be returned as output.
 *                               If flags & CLX_L3_INTF_FLAGS_WITH_ID is unset,
 *                               it means adding a new one.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can't be added.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_l3_intf_add(const uint32 unit, clx_l3_intf_t *ptr_intf);

/**
 * @brief The API is used to delete the interface based on the interface ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    intf_id    - L3 interface ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified interface has not been created.
 */
clx_error_no_t
clx_l3_intf_del(const uint32 unit, const uint32 intf_id);

/**
 * @brief The API is used to get all interfaces.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by the user.
 *                                 The user can perform actions on each node's data in this
 *                                 callback function.
 * @param [in]     ptr_cookie    - User-defined cookie data, used as an input parameter of the
 *                                 callback function.
 * @param [out]    ptr_cookie    - User-defined cookie data, used as an output parameter of the
 *                                 callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_intf_trav(const uint32 unit, const clx_l3_intf_trav_func_t cb, void *ptr_cookie);

/**
 * @brief The API is used to get my router MAC information in my router MAC table.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_rmac    - The HW idx must be input.
 * @param [out]    ptr_rmac    - The MyRouterMAC information, including MAC/MAC mask and
 *                               ifidx/ifidx mask.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified interface has not been created.
 */
clx_error_no_t
clx_l3_rmac_get(const uint32 unit, clx_l3_rmac_t *ptr_rmac);

/**
 * @brief The API is used to add my router MAC address and interface to my router MAC table.
 *        User should specify the entry index, interface ID, and my MAC address.
 *
 * The user needs to specify the index of MyRouterMAC table and the data of entry, including the
 * interface ID, MAC address, and the mask of them.
 * MyRouterMAC table is used to judge the incoming packet whether need to send to L3 unicast packet
 * flow. Unicast IP routing can be enabled on per port or per forwarding domain basis.
 * When packet arrives, ingress L3 interface will be derived. If IPv4/IPv6 routing is enabled,
 * the ingress L3 interface together with the Layer 2 destination MAC address are used to lookup
 * the MyRouterMAC table, if the ingress interface ID and destination MAC address of incoming packet
 * can't match, packet will not go to L3 unicast packet flow.
 * User can set mask bit to 0 in order to multiplex one entry by multiple interface ID and MAC
 * address.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_rmac    - The MyRouterMAC information, including HW idx,
 *                              MAC/MAC mask, and ifidx/ifidx mask.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, entry can't be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_l3_rmac_add(const uint32 unit, const clx_l3_rmac_t *ptr_rmac);

/**
 * @brief The API is used to delete my router MAC address and interface to my router MAC table.
 *        The user should specify the entry index.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    idx     - Hardware access index.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified interface has not been created.
 */
clx_error_no_t
clx_l3_rmac_del(const uint32 unit, const uint32 idx);

/**
 * @brief The API is used to get all my router MAC entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_rmac_trav(const uint32 unit, const clx_l3_rmac_trav_func_t cb, void *ptr_cookie);

/**
 * @brief The API is used to get the Adjacency information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     ptr_adj    - The adj_id must be input.
 * @param [out]    ptr_adj    - The adjacency information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_adj_get(const uint32 unit, clx_l3_adj_t *ptr_adj);

/**
 * @brief The API is used to add or set an adjacency.
 *
 * The API is used to add or set an adjacency for a host, a route, or an ECMP group.
 * If the ptr_adj->flags & CLX_L3_ADJ_FLAGS_WITH_ID is 0, means add a new adjacency,
 * and the ptr_adj->adj_id will be the return value. Otherwise, set an existing adjacency,
 * and the ptr_adj->adj_id will be the same with input value.
 * If this adjacency is used by host, route, or ecmp group, the packet will be affected when the
 * adjacency is set.
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     ptr_adj    - The adjacency information, if flags & CLX_L3_ADJ_FLAGS_WITH_ID set,
 *                              it means the adj is existed, the API would change the configuration
 *                              of this adj.
 * @param [out]    ptr_adj    - The adj_id will be return as output, if flags &
 *                              CLX_L3_INTF_FLAGS_WITH_ID unset, it means add a new one.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_adj_add(const uint32 unit, clx_l3_adj_t *ptr_adj);

/**
 * @brief The API is used to delete an adjacency.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    adj_id    - The adjacency ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_adj_del(const uint32 unit, const uint32 adj_id);

/**
 * @brief The API is used to get all Adjacencies.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - Adjacency type.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_adj_trav(const uint32 unit,
                const clx_l3_adj_type_t type,
                const clx_l3_adj_trav_func_t cb,
                void *ptr_cookie);

/**
 * @brief The API is used to get an L3 host entry.
 *
 * User only needs to fill IP address and VRF ID into ptr_host.
 * NV and VM modules can also call this API to get the host entry.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_host    - The addr must be input, only need host's key: IP address and VRF
 *                               ID.
 * @param [out]    ptr_host    - The host information, including IP address,
 *                               VRF ID, the nexthop and etc.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified host entry has not been created.
 */
clx_error_no_t
clx_l3_host_get(const uint32 unit, clx_l3_host_t *ptr_host);

/**
 * @brief The API is used to add an l3 host entry.
 *
 * The detailed information of L3 host entry refers to structure of clx_l3_host_t.
 * Key of entry is IP address and VRF ID.
 * For packets which are attached to the Host lookup L3 host to find adjacency and egress
 * interface information, the lookup process uses the whole destination IP address in the
 * packet and the VRF ID assigned to packet's ingress interface. If a matched entry is found,
 * the egress interface will be used for delivery.
 * If the host entry exists, this API will change the attribute of entry. The key of entry cannot be
 * changed. NV and VM modules can also call this API to add the host entry.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_host    - The host information, including IP address,
 *                              VRF ID, the nexthop and etc.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, entry can't be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_l3_host_add(const uint32 unit, const clx_l3_host_t *ptr_host);

/**
 * @brief The API is used to delete an l3 host entry.
 *
 * User only needs to fill the IP address and VRF ID into ptr_host_addr.
 * NV and VM modules can also call this API to delete the host entry.
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_host_addr    - The host address, including IP address,
 *                                   VRF ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified host entry has not been created.
 */
clx_error_no_t
clx_l3_host_del(const uint32 unit, const clx_l3_addr_t *ptr_host_addr);

/**
 * @brief The API is used to get all host entries.
 *
 * NV and VM modules can also call this API to traverse all host entries.
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function user provided by user,
 *                                 user can do self action for every node data in this callback
 *                                 function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_host_trav(const uint32 unit, const clx_l3_host_trav_func_t cb, void *ptr_cookie);

/**
 * @brief The API is used to get an L3 Subnet Broadcast entry.
 *
 * User only needs to fill in IP subnet address and VRF ID.
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_subnet_bc    - The addr must be input, including IP subnet address and VRF
 *                                    ID.
 * @param [out]    ptr_subnet_bc    - The subnet broadcast information,
 *                                    including IP subnet address, VRF ID,
 *                                    the nexthop and etc.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created.
 */
clx_error_no_t
clx_l3_subnet_bcast_get(const uint32 unit, clx_l3_subnet_bcast_t *ptr_subnet_bc);

/**
 * @brief The API is used to add an L3 Subnet Broadcast entry.
 *
 * IP subnet address and VRF ID need to be filled into ptr_subnet_bc.
 * If the subnet entry exists, some attributes of this entry will be changed.
 * The key of entry cannot be changed.
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_subnet_bc    - The subnet broadcast information, including subnet address,
 *                                   VRF ID, mcast ID and etc, key is the subnet address and VRF ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, the entry can not be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_l3_subnet_bcast_add(const uint32 unit, const clx_l3_subnet_bcast_t *ptr_subnet_bc);

/**
 * @brief The API is used to delete an L3 Route entry.
 *
 * The detailed information of route refers to structure of clx_l3_subnet_bcast_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    ptr_subnet_addr    - The subnet broadcast address, IP subnet address and VRF ID
 *                                     must be input.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created.
 */
clx_error_no_t
clx_l3_subnet_bcast_del(const uint32 unit, const clx_l3_addr_t *ptr_subnet_addr);

/**
 * @brief The API is used to get an L3 Route entry.
 *
 * User only needs to fill in IP network address and VRF ID.
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_route    - The addr must be input, including IP network address and VRF ID.
 * @param [out]    ptr_route    - The route information, including IP network address,
 *                                VRF ID, the path ID and etc.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created.
 */
clx_error_no_t
clx_l3_route_get(const uint32 unit, clx_l3_route_t *ptr_route);

/**
 * @brief The API is used to add an L3 Route entry.
 *
 * The detailed information of route refers to structure of clx_l3_route_t.
 * If the route entry exists, some attributes of this entry will be changed.
 * The key of entry cannot be changed.
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_route    - The route information, including network address,
 *                               VRF ID, the nexthop and etc, key is the network address and VRF ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, the entry can not be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_l3_route_add(const uint32 unit, const clx_l3_route_t *ptr_route);

/**
 * @brief The API is used to delete an L3 Route entry.
 *
 * IP network address and VRF ID need to be filled into ptr_route_addr.
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ptr_route_addr    - The route address, IP network address and VRF ID must be
 *                                    input.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created.
 */
clx_error_no_t
clx_l3_route_del(const uint32 unit, const clx_l3_addr_t *ptr_route_addr);

/**
 * @brief The API is used to get all Route entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_route_trav(const uint32 unit, const clx_l3_route_trav_func_t cb, void *ptr_cookie);

/**
 * @brief The API is used to get ECMP route group information. User should specify the group ID of
 *        the ECMP route group.
 *
 * For detailed information of the ECMP group, refer to clx_l3_ecmp_grp_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_ecmp    - The ecmp_id must be input.
 * @param [out]    ptr_ecmp    - The ECMP group information, including nhp_type,
 *                               frp_id, path_cnt, dlb_cfg and hash sel.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified host entry has not been created.
 */
clx_error_no_t
clx_l3_ecmp_grp_get(const uint32 unit, clx_l3_ecmp_grp_t *ptr_ecmp);

/**
 * @brief The API is used to add or set an ECMP route Group.
 *
 * User should specify the configuration of the ECMP route group,
 * If the ptr_ecmp->flags & CLX_L3_ECMP_GRP_FLAGS_WITH_ID is 0, means add a new ecmp group,
 * and the ptr_ecmp->ecmp_id will be the return value. Otherwise, the ptr_ecmp->ecmp_id
 * will be as the input value to set an existing ecmp group.
 * Equal-cost multi-path (ECMP) is a routing technique for routing packets along
 * multiple paths of equal cost. The forwarding engine identifies paths by adjacency.
 * When forwarding a packet, the router must decide which adjacency to use. For
 * detailed information of ECMP group, refer to clx_l3_ecmp_grp_t.
 * User can set the property of ECMP route group when creating the ECMP group or use
 * this API to modify property of ECMP group at a later time.
 * In order to add the ECMP route, user can follow the steps below:
 * 1) Create ECMP route group with API: clx_l3_ecmp_grp_add. Group index will be
 * allocate and return to user.
 * 2) Add one or multiple ECMP paths to this ECMP group with API:  clx_l3_ecmp_path_add.
 * 3) Add one ECMP route using this ECMP group with API: clx_l3_route_add.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_ecmp    - The ECMP group information, including nhp id,
 *                               weight, mpls_label, and DLB flag. If flags &
 *                               CLX_L3_ECMP_GRP_FLAGS_WITH_ID is set, it means the ECMP group
 *                               exists, and the API will change the configuration of this ECMP
 *                               group.
 * @param [out]    ptr_ecmp    - The ecmp_id allocated will be returned as output.
 *                               If flags & CLX_L3_INTF_FLAGS_WITH_ID is unset,
 *                               it means adding a new ECMP group.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can't be added.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_l3_ecmp_grp_add(const uint32 unit, clx_l3_ecmp_grp_t *ptr_ecmp);

/**
 * @brief The API is used to delete an ECMP route group. User should specify the group ID of the
 *        ECMP route group.
 *
 * This API is used to delete an ECMP group entry. All ECMP paths and ECMP hash paths will be
 * deleted. If an ECMP route uses this deleted ECMP group, this route will be invalid. User
 * needs to delete this route and add this route again with the new adjacency information.
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ecmp_id    - Specify group ID to be deleted.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group entry has not been created.
 */
clx_error_no_t
clx_l3_ecmp_grp_del(const uint32 unit, const uint32 ecmp_id);

/**
 * @brief The API is used to get all ECMP groups.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - Ecmp type.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_ecmp_grp_trav(const uint32 unit,
                     const clx_nhp_type_t type,
                     const clx_l3_ecmp_grp_trav_func_t cb,
                     void *ptr_cookie);

/**
 * @brief The API is used to sync two ecmp group member.
 *
 * Now only support CLX_L3_ECMP_ALGO_MODE_BOTH mode ecmp without weight and L3 type.
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ori_ecmp_id    - Original ECMP group.
 * @param [in]    cur_ecmp_id    - Current ECMP group.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_ecmp_grp_sync(const uint32 unit, const uint32 ori_ecmp_id, const uint32 cur_ecmp_id);

/**
 * @brief The API is used to get an ECMP path from an ECMP route group according to index.
 *        User should specify the group ID of the ECMP route group and the ECMP path index.
 *        The ECMP path information will be output.
 *
 * Detail information of the ECMP path refers to clx_l3_ecmp_path_t.
 * User can get the total path number by API: clx_l3_ecmp_grp_get; the path_cnt in structure
 * clx_l3_ecmp_grp_t is the total path number. Path index starts from 0 to path number-1.
 * The ECMP path is sorted by the order by which user adds the ECMP path. The new ECMP path is
 * always the last in the order.But if user deletes an ECMP path, the ECMP path belonging to the
 * same ECMP group will be re-sorted.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     path_idx    - ECMP path index.
 * @param [in]     ptr_path    - The ecmp_id must be input.
 * @param [out]    ptr_path    - The ECMP path information, including ECMP group ID and path info.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group entry or ECMP path entry has
 *                                            not been created.
 */
clx_error_no_t
clx_l3_ecmp_path_get_by_idx(const uint32 unit, const uint32 path_idx, clx_l3_ecmp_path_t *ptr_path);

/**
 * @brief The API is used to add an ECMP path to an ECMP route group. User should specify the group
 *        ID of the ECMP route group and the ECMP path information.
 *
 * For detailed information of the ECMP path, refer to clx_l3_ecmp_path_t.
 * User can add multiple ECMP paths to one ECMP group.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_path    - The ECMP path information, including ECMP group ID and path info.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_l3_ecmp_path_add(const uint32 unit, const clx_l3_ecmp_path_t *ptr_path);

/**
 * @brief The API is used to delete an ECMP path to an ECMP route group.
 *        User should specify the group ID of the ECMP route group and the ECMP path information.
 *        User should not delete all paths from a group if the group is used by others.
 *
 * For detailed information of the ECMP path, refer to clx_l3_ecmp_path_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_path    - The ECMP path to be deleted, including ECMP group ID and path info.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group entry or ECMP path has not
 *                                           been created.
 */
clx_error_no_t
clx_l3_ecmp_path_del(const uint32 unit, const clx_l3_ecmp_path_t *ptr_path);

/**
 * @brief The API is used to set the hash value for an ECMP path. User should specify the ECMP
 *        route group ID, the hash value and the ECMP path information.
 *
 * For detailed information of the ECMP path, refer to clx_l3_ecmp_path_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_hsh_set    - The ECMP path setting information, including path info,
 *                                 hash count and hash value.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group or ECMP path entry has not
 *                                           been created.
 */
clx_error_no_t
clx_l3_ecmp_path_hsh_set(const uint32 unit, const clx_l3_ecmp_path_hsh_t *ptr_hsh_set);

/**
 * @brief The API is used to get the hash value of an ECMP path. User should specify the ECMP route
 *        group ID and the ECMP path information. The hash value list will be output.
 *
 * For detailed information of the ECMP path, refer to clx_l3_ecmp_path_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_hsh_get    - User need to specify path info, the excepted hsh_cnt,
 *                                  and alloc memory based the hsh_cnt for the hsh_val array.
 * @param [out]    ptr_hsh_get    - Output the actual hsh_cnt and hsh_val array for the path,
 *                                  and the actual hsh_cnt not greater than the excepted hsh_cnt.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified ECMP group or ECMP path entry has not
 *                                            been created.
 */
clx_error_no_t
clx_l3_ecmp_path_hsh_get(const uint32 unit, clx_l3_ecmp_path_hsh_t *ptr_hsh_get);

/**
 * @brief The API is used to set the idx path and state.
 *
 * For detailed information of the ECMP path, refer to clx_l3_ecmp_path_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    is_org      - Select orig or act list, True is orig, FALSE is act list.
 * @param [in]    idx         - Select location in list.
 * @param [in]    ptr_path    - ECMP path information, including output path ID,
 *                              path state.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_ecmp_path_list_set(const uint32 unit,
                          const boolean is_org,
                          const uint32 idx,
                          const clx_l3_ecmp_path_t *ptr_path);

/**
 * @brief The API is used to get the ECMP path list.
 *
 * For detailed information of the ECMP path, refer to clx_l3_ecmp_path_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     is_org      - Select orig or act list, True is orig,
 *                               FALSE is act list.
 * @param [in]     idx         - Select location in list.
 * @param [out]    ptr_path    - ECMP path information, including output path ID,
 *                               path state.
 */
clx_error_no_t
clx_l3_ecmp_path_list_get(const uint32 unit,
                          const boolean is_org,
                          const uint32 idx,
                          clx_l3_ecmp_path_t *ptr_path);

/**
 * @brief The API is used to get the ECMP path list info.
 *
 * For detailed information of the ECMP path, refer to clx_l3_ecmp_path_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     allPatchInfo    - The ecmp_id must be input.
 * @param [out]    allPatchInfo    - ECMP info, include member orig_list and act_list adj state etc
 *                                   info.
 */
clx_error_no_t
clx_l3_ecmp_grp_all_path_list_get(const uint32 unit, clx_l3_ecmp_all_path_t *allPatchInfo);
/**
 * @brief The API is used to set the packet handling action on a Virtual Routing Forwarding.
 *        User should specify the VRF ID and the packet handling action.
 *
 * For detailed packet handling configuration, refer to clx_l3_vrf_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_vrf    - The Virtual Routing Forwarding configuration.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified VRF has not been created.
 */
clx_error_no_t
clx_l3_vrf_set(const uint32 unit, const clx_l3_vrf_t *ptr_vrf);

/**
 * @brief The API is used to get the packet handling action on a Virtual Routing Forwarding.
 *        User should specify the VRF ID. The packet handling action will be output.
 *
 * For detailed packet handling configuration, refer to clx_l3_vrf_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     ptr_vrf    - The vrf_id must be input.
 * @param [out]    ptr_vrf    - The Virtual Routing Forwarding configuration.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified VRF has not been created.
 */
clx_error_no_t
clx_l3_vrf_get(const uint32 unit, clx_l3_vrf_t *ptr_vrf);

/**
 * @brief The API is used to allocate a multicast forwarding ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     flags           - The L3 multicast flags, refer to CLX_L3_MCAST_FLAGS_XXX.
 * @param [in]     ptr_mcast_id    - It's the specified ID for multicast creating while flags &
 *                                   CLX_L3_INTF_FLAGS_WITH_ID set.
 * @param [out]    ptr_mcast_id    - It's the allocate ID while flags & CLX_L3_INTF_FLAGS_WITH_ID
 *                                   unset.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - No more memory for the entry.
 */
clx_error_no_t
clx_l3_mcast_grp_create(const uint32 unit, const uint32 flags, uint32 *ptr_mcast_id);

/**
 * @brief The API is used to release a multicast forwarding ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    mcast_id    - The multicast forwarding ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_mcast_grp_destroy(const uint32 unit, const uint32 mcast_id);

/**
 * @brief The API is used to get the rough info on a multicast forwarding ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     mcast_id    - The multicast forwarding ID.
 * @param [out]    port_bmp    - The egress port bitmap, if a bit is set to 1,
 *                               the corresponding port is the member port.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The multicast forwarding ID is not used.
 */
clx_error_no_t
clx_l3_mcast_port_bmp_get(const uint32 unit, const uint32 mcast_id, clx_port_bitmap_t port_bmp);

/**
 * @brief The API is used to get an IP multicast route information.
 *
 * For detailed route information, refer to description of clx_l3_mcast_route_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     ptr_mcast_route    - The addr must be input, only need to fill VRF ID and
 *                                      multicast IP address for (*,G) group.
 *                                      The source IP address also need for (S,
 *                                      G) group.
 * @param [out]    ptr_mcast_route    - The output multicast data information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_l3_mcast_route_get(const uint32 unit, clx_l3_mcast_route_t *ptr_mcast_route);

/**
 * @brief The API is used to add an IP multicast route.
 *
 * The VRF ID, multicast IP address must be set for adding (*.G) group, the source IP address
 * also needs to be set for adding (S,G) group. If the multicast route exists, update the route
 * property. For other route properties, refer to the description of clx_l3_mcast_route_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    ptr_mcast_route    - The multicast route information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - No more memory for the entry.
 */
clx_error_no_t
clx_l3_mcast_route_add(const uint32 unit, const clx_l3_mcast_route_t *ptr_mcast_route);

/**
 * @brief The API is used to delete an IP multicast route.
 *
 * Only need to fill VRF ID and multicast IP address in ptr_mcast_addr for deleting (*,G) group.
 * The source IP address is also needed for deleting (S,G) group.
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ptr_mcast_addr    - The multicast address information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_l3_mcast_route_del(const uint32 unit, const clx_l3_mcast_addr_t *ptr_mcast_addr);

/**
 * @brief The API is used to get all group entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function user provided by user,
 *                                 user can do self action for every node data in this callback
 *                                 function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_mcast_route_trav(const uint32 unit,
                        const clx_l3_mcast_route_trav_func_t cb,
                        void *ptr_cookie);

/**
 * @brief The API is used to replace the whole egress interface list on a port for a multicast
 *        forwarding ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_egr    - The egress interface information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_l3_mcast_egr_intf_set(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

/**
 * @brief The API is used to get all egress interfaces of an IP multicast group in an egress port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     mcast_id    - The multicast forwarding ID.
 * @param [in]     port_id     - The egress port ID.
 * @param [in]     ptr_cnt     - User must specify the excepted intf_cnt.
 * @param [out]    ptr_cnt     - Output the actual intf_cnt, and the actual not greater than the
 *                               excepted.
 * @param [out]    ptr_intf    - Output the actual intf array.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_mcast_egr_intf_get_by_port(const uint32 unit,
                                  const uint32 mcast_id,
                                  const clx_port_t port_id,
                                  uint32 *ptr_cnt,
                                  clx_l3_mcast_egr_intf_t *ptr_intf);

/**
 * @brief The API is used to add the egress interface of an IP multicast group in an egress port.
 *
 * If the egress port is the CPU port, the egress interface count must be 0.
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_egr    - The mcast egress interface information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - No more memory for the entry.
 */
clx_error_no_t
clx_l3_mcast_egr_intf_add(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

/**
 * @brief The API is used to delete the egress interface of an IP multicast group in an egress port.
 *
 * If the egress port is the CPU port, the egress interface count must be 0.
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_egr    - The mcast egress interface information, while del the egress
 *                             interface, the port, intf id and intf type must be input.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_l3_mcast_egr_intf_del(const uint32 unit, const clx_l3_mcast_egr_t *ptr_egr);

/**
 * @brief The API is used to get the egress interface number of an IP multicast group in an egress
 *        port.
 *
 * The API is used to get egress interface number of an egress port of IP multicast group.
 * One L3 multicast group can have multiple egress ports, and one egress port can be sent out from
 * multiple egress interfaces.
 * Therefore, user needs to use this API to get the interface number per port, and then use the API
 * "clx_l3_mcast_egr_intf_cnt_get_by_port" to get all egress interfaces listed in this port.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mcast_id        - The multicast forwarding ID.
 * @param [in]     port_id         - The egress port ID.
 * @param [out]    ptr_intf_cnt    - The egress interface count of the egress port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_mcast_egr_intf_cnt_get_by_port(const uint32 unit,
                                      const uint32 mcast_id,
                                      const clx_port_t port_id,
                                      uint32 *ptr_intf_cnt);

/**
 * @brief The API is used to get the RP IP address list if the specified interface is a DF
 *        interface.
 *
 * The API is only used for PIM-BIDIR mode.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_rslt    - User must specify the DF interface, excepted rp_cnt,
 *                               and alloc memory based the excepted rp_cnt for the rp_addr array.
 * @param [out]    ptr_rslt    - Output the rp_addr with the actual rp_cnt,
 *                               and the actual count not greater than the excepted.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_mcast_df_intf_get(const uint32 unit, clx_l3_mcast_df_intf_t *ptr_rslt);

/**
 * @brief The API is used to add a specific interface as the DF interface for a multicast group.
 *
 * The API is used to add a specific interface as the DF interface for a multicast group.
 * The API is only used before a multicast group is set to BIDIR-PIM mode. Otherwise, it will return
 * fail when set or add the multicast group.
 * The ptr_rp_addr is set in a multicast group.
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_df_intf    - The DF interface information, including the logical interface ID
 *                                 and the RP IP address.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_mcast_df_intf_add(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_df_intf);

/**
 * @brief The API is used to delete a specific interface as the DF interface for a multicast group.
 *
 * The API is only used for PIM-BIDIR mode.
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_df_intf    - The DF interface information, including the logical interface ID
 *                                 and the RP IP address.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_mcast_df_intf_del(const uint32 unit, const clx_l3_mcast_df_intf_t *ptr_df_intf);

/**
 * @brief The API is used to create a Fast Re-Route. This ID can be used in clx_l3_ecmp_path_t or
 *        clx_l3_adj_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     ptr_frr    - The outpath type must be input, Only support ADJ & NVO3_ADJ.
 * @param [out]    ptr_frr    - The Fast Re-Route ID will be return.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_frr_create(const uint32 unit, clx_l3_frr_t *ptr_frr);

/**
 * @brief The API is used to destroy a state ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    frr_id    - Fast Re-Route ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_frr_destroy(const uint32 unit, const uint32 frr_id);

/**
 * @brief The API is used to set the linkup status for a specific state ID.
 *        The status of the state_id can imply the status of a specific port or path.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    frr_id    - Fast Re-Route ID.
 * @param [in]    state     - The linkup status for this frr.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_frr_state_set(const uint32 unit, const uint32 frr_id, const boolean state);

/**
 * @brief The API is used to get the linkup status for a specific state ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     frr_id       - Fast Re-Route ID.
 * @param [out]    ptr_state    - The setting status for this frr.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_frr_state_get(const uint32 unit, const uint32 frr_id, boolean *ptr_state);

/**
 * @brief The API is used to add frr path.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_path    - The FRR path info, including FRR ID, the nhp path,
 *                              mpls label and etc.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_frr_path_add(const uint32 unit, const clx_l3_frr_path_t *ptr_path);

/**
 * @brief The API is used to del frr path.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_path    - The FRR path info, including FRR ID, the nhp path,
 *                              mpls label and etc.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_l3_frr_path_del(const uint32 unit, const clx_l3_frr_path_t *ptr_path);

/**
 * @brief The API is used to get bulk L3 Route entries.
 *
 * User only needs to fill in IP network address and VRF ID.
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     mode              - Bulk Mode.
 * @param [in]     ptr_bulk_route    - The Route information, including route count,
 *                                     network addr, and VRF ID must be input.
 * @param [out]    ptr_bulk_route    - The Route information and pointer of a return code array,
 *                                     user need alloc firstly.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created.
 */
clx_error_no_t
clx_l3_bulk_route_get(const uint32 unit,
                      const clx_bulk_op_mode_t mode,
                      clx_l3_bulk_route_t *ptr_bulk_route);

/**
 * @brief The API is used to add bulk L3 Route entries.
 *
 * The detailed information of route refers to structure of clx_l3_route_t.
 * If the route entry exists, some attributes of this entry will be changed.
 * The key of entry cannot be changed.
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     mode              - Bulk Mode, no use now because wirte hw only one times.
 * @param [in]     ptr_bulk_route    - The Route information, including route count,
 *                                     addr, the nexthop and etc. Key is the network address and
 *                                     VRF ID.
 * @param [out]    ptr_bulk_route    - Pointer of a return code array, user need alloc firstly.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, the entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_l3_bulk_route_add(const uint32 unit,
                      const clx_bulk_op_mode_t mode,
                      clx_l3_bulk_route_t *ptr_bulk_route);

/**
 * @brief The API is used to delete bulk L3 Route entries.
 *
 * IP network address and VRF ID need to be filled into ptr_bulk_route.
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     mode              - Bulk Mode, no use now because wirte hw only one times.
 * @param [in]     ptr_bulk_route    - The Route information, route count,
 *                                     network address and VRF ID must be input.
 * @param [out]    ptr_bulk_route    - Pointer of a return code array, user need alloc firstly.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_NO_MEMORY          - No available memory.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been deleted.
 */
clx_error_no_t
clx_l3_bulk_route_del(const uint32 unit,
                      const clx_bulk_op_mode_t mode,
                      clx_l3_bulk_route_t *ptr_bulk_route);

/**
 * @brief This API is used to remove L3 host which match the specified criteria with the newly
 *        specified values.
 *
 * User only needs to fill in specified values.
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_host_info    - Need ipv4 or ipv6 and flush key: group_label or other.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified route entry has not been created.
 */
clx_error_no_t
clx_l3_host_flush(const uint32 unit, const clx_l3_host_t *ptr_host_info);

#endif