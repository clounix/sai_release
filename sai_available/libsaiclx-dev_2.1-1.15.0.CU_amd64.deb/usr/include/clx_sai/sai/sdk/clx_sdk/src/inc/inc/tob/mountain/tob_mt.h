/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME: tob_mt.h
 * PURPOSE:
 *     Table operation bus(TOB) driver
 * NOTES:
 */

#ifndef TOB_MT_H
#define TOB_MT_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
#define TOB_MT_TCAM_INDEX_OFFSET 0
#define TOB_MT_TCAM_INDEX_LEN    20
#define TOB_MT_TCAM_INST_OFFSET  20
#define TOB_MT_TCAM_INST_LEN     4

#define TOB_MT_NB_FPU_INDEX_LEN 20

#define TOB_MT_HASH_INDEX_OFFSET 0
#define TOB_MT_HASH_INDEX_LEN    15
#define TOB_MT_HASH_TILE_OFFSET  15
#define TOB_MT_HASH_TILE_LEN     3
#define TOB_MT_HASH_STAGE_OFFSET 18
#define TOB_MT_HASH_STAGE_LEN    2
#define TOB_MT_HASH_INST_OFFSET  20
#define TOB_MT_HASH_INST_LEN     4

#define TOB_MT_DMA_FALSE 0
#define TOB_MT_DMA_TRUE  1

#define TOB_MT_NB_FPU_SRAM_NUM_PER_SLICE (32 * 1024)

#define TOB_MT_MULTI_TBL_NUM 27

#define TOB_MT_NB_FPU_HASH_CONFLICT_INDEX_OFFSET 24
#define TOB_MT_NB_FPU_HASH_CONFLICT_INDEX_LEN    15

#define TOB_MT_TABLE_COPY_DMA_NUM 128

#define TOB_MT_MASTER_INST_IDX_BCAST_0     0x7EEEEEEE
#define TOB_MT_MASTER_INST_IDX_BCAST_1     0x6EEEEEEE
#define TOB_MT_SLAVE_INST_IDX_BCAST_0      0x5EEEEEEE
#define TOB_MT_SLAVE_INST_IDX_BCAST_1      0x4EEEEEEE
#define TOB_MT_MASTER_SUB_INST_IDX_BCAST_0 0x3EEEEEEE
#define TOB_MT_MASTER_SUB_INST_IDX_BCAST_1 0x2EEEEEEE

#define TOB_MT_DOUBLE_INST_IDX_BEGIN_BC_1 4

#define TOB_MT_HASH_GET_INSTID(entry_index, inst_id) \
    (inst_id = ((entry_index >> TOB_MT_HASH_INST_OFFSET) & ((1 << TOB_MT_HASH_INST_LEN) - 1)))

#define TOB_MT_HASH_GET_STAGEID(entry_index, stage_id) \
    (stage_id = ((entry_index >> TOB_MT_HASH_STAGE_OFFSET) & ((1 << TOB_MT_HASH_STAGE_LEN) - 1)))

#define TOB_MT_HASH_GET_TILEID(entry_index, tile_id) \
    (tile_id = ((entry_index >> TOB_MT_HASH_TILE_OFFSET) & ((1 << TOB_MT_HASH_TILE_LEN) - 1)))

#define TOB_MT_HASH_GET_INDEX(entry_index, index) \
    (index = ((entry_index >> TOB_MT_HASH_INDEX_OFFSET) & ((1 << TOB_MT_HASH_INDEX_LEN) - 1)))

#define TOB_MT_TCAM_GET_INSTID(entry_index, inst_id) \
    (inst_id = ((entry_index >> TOB_MT_TCAM_INST_OFFSET) & ((1 << TOB_MT_TCAM_INST_LEN) - 1)))

#define TOB_MT_TCAM_GET_INDEX(entry_index, index) \
    (index = ((entry_index >> TOB_MT_TCAM_INDEX_OFFSET) & ((1 << TOB_MT_TCAM_INDEX_LEN) - 1)))

#define TOB_MT_NB_FPU_GET_IDX(entry_index, index) \
    (index = (entry_index & ((1 << TOB_MT_NB_FPU_INDEX_LEN) - 1)))

#define TOB_MT_MULT_TBL_ENTRY_MAX(unit, table_id)         \
    (HAL_TBL_INFO((unit), (table_id))->entry_max_number * \
     HAL_TBL_INFO((unit), (table_id))->subinst_count)

#define TOB_MT_MULT_TBL_SUB_INST(unit, table_id, entry_id) \
    ((entry_id) / HAL_TBL_INFO((unit), (table_id))->entry_max_number)

#define TOB_MT_MULT_TBL_ENTRY_ID(unit, table_id, entry_id) \
    ((entry_id) % HAL_TBL_INFO((unit), (table_id))->entry_max_number)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum tob_mt_proc_type_e {
    TOB_MT_PROC_CMST = 0,
    TOB_MT_PROC_PDMA,
    TOB_MT_PROC_ECPU,
    TOB_MT_PROC_LAST
} tob_mt_proc_type_t;

typedef enum tob_mt_double_bc_type_e {
    TOB_MT_DOUBLE_BC_MASTER = 0,
    TOB_MT_DOUBLE_BC_SLAVE,
    TOB_MT_DOUBLE_BC_LAST
} tob_mt_double_bc_type_t;

typedef enum tob_mt_bcast_e {
    TOB_MT_BCAST_NONE = 0,
    TOB_MT_BCAST_INST_ODD = 1,
    TOB_MT_BCAST_INST_EVEN = 2,
    TOB_MT_BCAST_SUBINST = 3,
    TOB_MT_BCAST_INST_MASTER_0 = 4,
    TOB_MT_BCAST_INST_MASTER_1 = 5,
    TOB_MT_BCAST_INST_SLAVE_0 = 6,
    TOB_MT_BCAST_INST_SLAVE_1 = 7,
    TOB_MT_BCAST_SUB_INST_MASTER_0 = 8,
    TOB_MT_BCAST_SUB_INST_MASTER_1 = 9,
    TOB_MT_BCAST_ALL = 10,
    TOB_MT_BCAST_LAST
} tob_mt_bcast_t;

typedef enum tob_mt_cmd_mode_e {
    TOB_MT_CMD_MEM_WRITE = 0,
    TOB_MT_CMD_MEM_DMA,
    TOB_MT_CMD_LASE
} tob_mt_cmd_mode_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
typedef clx_error_no_t (*TOB_MT_NB_MEM_CHECK)(const uint32 unit,
                                              const uint32 inst_idx,
                                              const uint32 subinst_idx,
                                              const uint32 bank_bmp,
                                              const uint32 table_id,
                                              const uint32 entry_idx,
                                              const uint32 entry_num,
                                              uint32 *ptr_entry);

clx_error_no_t
tob_mt_nb_inst_map(const tob_chip_info_t chip_info,
                   const uint32 table_id,
                   uint32 *ptr_map_inst_idx,
                   uint32 *ptr_map_sub_inst_idx);

clx_error_no_t
tob_mt_nb_entry_write(const tob_chip_info_t chip_info, const tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_nb_entry_read(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_nb_fields_write(const tob_chip_info_t chip_info,
                       const tob_entry_fields_info_t *ptr_fields_info);

clx_error_no_t
tob_mt_nb_fields_read(const tob_chip_info_t chip_info, tob_entry_fields_info_t *ptr_fields_info);

clx_error_no_t
tob_mt_nb_hash_entry_add(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_nb_hash_entry_update(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_nb_hash_entry_lookup(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_nb_hash_entry_del(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

void
tob_mt_nb_dma_entry_size_get(const uint32 unit, const uint32 table_id, uint32 *ptr_size);

clx_error_no_t
tob_mt_nb_dma_entry_write(const tob_chip_info_t chip_info, const tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_nb_dma_entry_read(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

clx_error_no_t
tob_mt_nb_table_copy(const tob_chip_info_t chip_info, const tob_tbl_copy_info_t *ptr_copy_info);

clx_error_no_t
tob_mt_nb_table_reset(const tob_chip_info_t chip_info, const tob_tbl_reset_info_t *ptr_reset_info);

clx_error_no_t
tob_mt_nb_index_logic2phy(const uint32 unit,
                          const tob_entry_index_info_t *ptr_index_info,
                          uint32 *ptr_phy_idx);

clx_error_no_t
tob_mt_nb_index_phy2logic(const uint32 unit,
                          const tob_entry_index_info_t *ptr_index_info,
                          uint32 *ptr_logic_idx);

boolean
tob_mt_nb_index_is_valid(const uint32 unit, const tob_entry_index_info_t *ptr_index_info);

clx_error_no_t
tob_mt_nb_init(const uint32 unit);

clx_error_no_t
tob_mt_nb_deinit(const uint32 unit);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif /* End of TOB_H */
