/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_tnl.h
 * PURPOSE:
 *      It provide tunnel hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_TNL_H
#define HAL_MT_NB_TNL_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_RPF_BD_MAX   (0x1FF) /* rpf_bd max value for mgo and msgo */
#define HAL_MT_NB_RPF_BD_MIN   (0)     /* rpf_bd min value for mgo and msgo */
#define HAL_MT_NB_ES_GROUP_MAX (0x7F)  /* evpn_esi max value for sec_tep */
#define HAL_MT_NB_ES_GROUP_MIN (0)     /* evpn_esi min value for sec_tep */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_nb_ip_tnl_type_enum_e {
    HAL_MT_NB_IP_TNL_GRE_WO_KEY = 0,
    HAL_MT_NB_IP_TNL_GRE_W_KEY = 1,
    HAL_MT_NB_IP_TNL_RAW = 2,
    HAL_MT_NB_IP_TNL_ISATAP = 3,
    HAL_MT_NB_IP_TNL_6TO4 = 4,
    HAL_MT_NB_IP_TNL_VXLAN_BAS = 5,
    HAL_MT_NB_IP_TNL_VXLAN_GPE_WO_VNI = 6,
    HAL_MT_NB_IP_TNL_VXLAN_GPE_W_VNI = 7,
    HAL_MT_NB_IP_TNL_GENEVE = 8,
    HAL_MT_NB_IP_TNL_INT_REPORT = 9,
    HAL_MT_NB_IP_TNL_SRV6_ENCAP = 10,
    HAL_MT_NB_IP_TNL_SRV6_INSERT = 11,
    HAL_MT_NB_IP_TNL_FLEX_0 = 12,
    HAL_MT_NB_IP_TNL_FLEX_1 = 13,
    HAL_MT_NB_IP_TNL_FLEX_2 = 14,
    HAL_MT_NB_IP_TNL_FLEX_3 = 15,
    HAL_MT_NB_IP_TNL_LAST
} hal_mt_nb_ip_tnl_type_enum_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_nb_tnl_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_tnl_mac_add(const uint32 unit,
                      const uint32 index,
                      const clx_tnl_mac_info_t *ptr_mac_info);

clx_error_no_t
hal_mt_nb_tnl_mac_del(const uint32 unit, const uint32 index);

clx_error_no_t
hal_mt_nb_tnl_mac_get(const uint32 unit, const uint32 index, clx_tnl_mac_info_t *ptr_mac_info);

clx_error_no_t
hal_mt_nb_tnl_mac_trav(const uint32 unit, const clx_tnl_mac_trav_t cb, void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tnl_entry_encap_add(const uint32 unit,
                              const clx_tnl_info_t *ptr_tnl_info,
                              const clx_tnl_encap_info_t *ptr_encap_info);

clx_error_no_t
hal_mt_nb_tnl_entry_encap_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

clx_error_no_t
hal_mt_nb_tnl_entry_encap_get(const uint32 unit,
                              const clx_tnl_info_t *ptr_tnl_info,
                              clx_tnl_encap_info_t *ptr_encap_info);

clx_error_no_t
hal_mt_nb_tnl_entry_encap_trav(const uint32 unit,
                               const clx_tnl_encap_trav_func_t cb,
                               void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tnl_nvo3_adj_add(const uint32 unit, clx_l3_adj_t *ptr_nvo3_adj_info);

clx_error_no_t
hal_mt_nb_tnl_nvo3_adj_del(const uint32 unit, const uint32 nvo3_adj_id);

clx_error_no_t
hal_mt_nb_tnl_nvo3_adj_get(const uint32 unit, clx_l3_adj_t *ptr_nvo3_adj_info);

clx_error_no_t
hal_mt_nb_tnl_nvo3_adj_trav(const uint32 unit,
                            const clx_l3_adj_trav_func_t callback,
                            void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tnl_entry_decap_add(const uint32 unit,
                              const clx_tnl_info_t *ptr_tnl_info,
                              const clx_tnl_decap_info_t *ptr_decap_info);

clx_error_no_t
hal_mt_nb_tnl_entry_decap_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

clx_error_no_t
hal_mt_nb_tnl_entry_decap_get(const uint32 unit,
                              const clx_tnl_info_t *ptr_tnl_info,
                              clx_tnl_decap_info_t *ptr_decap_info);

clx_error_no_t
hal_mt_nb_tnl_entry_decap_trav(const uint32 unit,
                               const clx_tnl_decap_trav_func_t cb,
                               void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tnl_entry_decap_add_general(const uint32 unit,
                                      const clx_tnl_info_t *ptr_tnl_info,
                                      const clx_tnl_decap_info_t *ptr_tunnel_term_info,
                                      const boolean erspan);

clx_error_no_t
hal_mt_nb_tnl_entry_decap_del_general(const uint32 unit,
                                      const clx_tnl_info_t *ptr_tnl_info,
                                      const boolean erspan);

clx_error_no_t
hal_mt_nb_tnl_entry_decap_get_general(const uint32 unit,
                                      const clx_tnl_info_t *ptr_tnl_info,
                                      clx_tnl_decap_info_t *ptr_decap_info,
                                      const boolean erspan);

clx_error_no_t
hal_mt_nb_tnl_nvo3_route_add(const uint32 unit,
                             const clx_tnl_info_t *ptr_tnl_info,
                             const clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

clx_error_no_t
hal_mt_nb_tnl_nvo3_route_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

clx_error_no_t
hal_mt_nb_tnl_nvo3_route_get(const uint32 unit,
                             const clx_tnl_info_t *ptr_tnl_info,
                             clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

clx_error_no_t
hal_mt_nb_tnl_nvo3_route_trav(const uint32 unit,
                              const clx_tnl_nvo3_route_trav_func_t cb,
                              void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tnl_flex_tnl_add(const uint32 unit,
                           const uint32 index,
                           const clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

clx_error_no_t
hal_mt_nb_tnl_flex_tnl_del(const uint32 unit, const uint32 index);

clx_error_no_t
hal_mt_nb_tnl_flex_tnl_get(const uint32 unit,
                           const uint32 index,
                           clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

clx_error_no_t
hal_mt_nb_tnl_flex_tnl_udf_cfg(const uint32 unit, const uint32 index, const uint32 flags);

clx_error_no_t
hal_mt_nb_tnl_phy_port_set(const uint32 unit,
                           const clx_port_t port,
                           const clx_tnl_port_info_t *ptr_port_info);

clx_error_no_t
hal_mt_nb_tnl_phy_port_get(const uint32 unit,
                           const clx_port_t port,
                           clx_tnl_port_info_t *ptr_port_info);

clx_error_no_t
hal_mt_nb_tnl_es_grp_create(const uint32 unit, const uint32 flags, uint32 *ptr_es_grp);

clx_error_no_t
hal_mt_nb_tnl_es_grp_destroy(const uint32 unit, const uint32 es_grp);

clx_error_no_t
hal_mt_nb_tnl_es_grp_mbr_add(const uint32 unit,
                             const uint32 es_grp,
                             const clx_port_t *ptr_port_mbr,
                             const uint32 port_num);

clx_error_no_t
hal_mt_nb_tnl_es_grp_mbr_del(const uint32 unit,
                             const uint32 es_grp,
                             const clx_port_t *ptr_port_mbr,
                             const uint32 port_num);

clx_error_no_t
hal_mt_nb_tnl_es_grp_mbr_get(const uint32 unit,
                             const uint32 es_grp,
                             clx_port_t *ptr_port_mbr,
                             uint32 *ptr_port_num);

clx_error_no_t
hal_mt_nb_tnl_tnl_to_list_trav(const uint32 unit,
                               const hal_tnl_trav_type_t type,
                               util_lib_list_t *ptr_list);

clx_error_no_t
hal_mt_nb_tnl_trans_nvo3_adj_to_ecmp_path(const uint32 unit,
                                          const uint32 nvo3_adj_id,
                                          tob_fvp_t *ptr_path_info,
                                          uint32 *ptr_buf);

clx_error_no_t
hal_mt_nb_tnl_encap_ip_idx_cfg(const uint32 unit,
                               const clx_ip_addr_t *ptr_src_ip,
                               const clx_ip_addr_t *ptr_dst_ip,
                               uint32 *ptr_src_ip_idx,
                               uint32 *ptr_dst_ip_idx);

clx_error_no_t
hal_mt_nb_tnl_cfg_ecmp_path_by_nvo3_adj_info(const uint32 unit,
                                             const uint32 ecmp_path_idx,
                                             const clx_port_t port);

clx_error_no_t
hal_mt_nb_tnl_port_dflt_set(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_tnl_reset_port_default(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_tnl_ip_sa_idx_alloc(const uint32 unit,
                              const boolean is_ipv4,
                              const clx_ip_addr_t *ptr_src_ip,
                              uint32 *ptr_idx);

clx_error_no_t
hal_mt_nb_tnl_ip_sa_idx_free(const uint32 unit, const boolean is_ipv4, const uint32 idx);

clx_error_no_t
hal_mt_nb_tnl_ip_da_idx_alloc(const uint32 unit,
                              const boolean is_ipv4,
                              const clx_ip_addr_t *ptr_dst_ip,
                              const boolean is_seglist,
                              const clx_srv6_sidlist_t *ptr_segment_list,
                              uint32 *ptr_idx);

clx_error_no_t
hal_mt_nb_tnl_ip_da_idx_free(const uint32 unit,
                             const boolean is_ipv4,
                             const boolean is_seglist,
                             const uint32 segments_left,
                             const uint32 idx);

clx_error_no_t
hal_mt_nb_tnl_dst_tep_idx_alloc(const uint32 unit, const boolean is_ipv4, uint32 *ptr_idx);

clx_error_no_t
hal_mt_nb_tnl_dst_tep_idx_free(const uint32 unit, const boolean is_ipv4, const uint32 idx);

clx_error_no_t
hal_mt_nb_tnl_rwo_hsh_bdo_vlan_cfg(const uint32 unit,
                                   const hal_cmn_action_t action,
                                   const uint32 key_tnl_bd,
                                   const uint32 key_port,
                                   uint32 *ptr_rslt_vid);

/**
 * @brief Set tnl exception's action.
 *
 * NB now only support TTL0/1 action now.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    property    - Exception enum.
 * @param [in]    action      - Drop/to_cpu/forward.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_excpt_act_set(const uint32 unit,
                            const clx_swc_cfg_t property,
                            clx_fwd_action_t action);

/**
 * @brief Get tnl exception's action.
 *
 * NB now only support TTL0/1 action now.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    property      - Exception enum.
 * @param [in]    ptr_action    - Drop/to_cpu/forward.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_excpt_act_get(const uint32 unit,
                            const clx_swc_cfg_t property,
                            clx_fwd_action_t *ptr_action);

/**
 * @brief Enable/Disable the VXLAN Router Alert feature.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - 0 or 1.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_vxlan_ra_chk_set(const uint32 unit, const uint32 enable);

/**
 * @brief Get the VXLAN Router Alert Enable/Disable status.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - 0 or 1.
 * @return         Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_vxlan_ra_chk_get(const uint32 unit, uint32 *ptr_enable);

/**
 * @brief Enable/Disable the NVGRE Router Alert feature.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - 0 or 1.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_nvgre_ra_chk_set(const uint32 unit, const uint32 enable);

/**
 * @brief Get the NVGRE Router Alert Enable/Disable status.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - 0 or 1.
 * @return         Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_nvgre_ra_chk_get(const uint32 unit, uint32 *ptr_enable);

/**
 * @brief Add or set a tunnel to a specified segment and related service.
 *
 * The ptr_seg_srv->vid_bdid value modification is not allowed.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header info.
 * @param [in]    ptr_segment     - Pointer to segment information.
 * @param [in]    bdid            - Bdid.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_seg_srv_add(const uint32 unit,
                          const clx_tnl_info_t *ptr_tnl_info,
                          const clx_tnl_seg_key_t *ptr_segment,
                          const uint32 bdid);

/**
 * @brief Delete a tunnel from a specified segment.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header info.
 * @param [in]    ptr_segment     - Pointer to segment information.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_seg_srv_del(const uint32 unit,
                          const clx_tnl_info_t *ptr_tnl_info,
                          const clx_tnl_seg_key_t *ptr_segment);

/**
 * @brief Get the service of a (segment, tunnel) pair.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_tnl_info    - Tunnel header info.
 * @param [in]     ptr_segment     - Pointer to segment information.
 * @param [out]    ptr_bdid        - Pointer to bdid.
 * @return         Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_seg_srv_get(const uint32 unit,
                          const clx_tnl_info_t *ptr_tnl_info,
                          const clx_tnl_seg_key_t *ptr_segment,
                          uint32 *ptr_bdid);

/**
 * @brief Set vxlan udp_port.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    dport    - Vxlan udp_port.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_vxlan_udp_port_set(const uint32 unit, const uint32 dport);

/**
 * @brief Get vxlan udp dport.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_dport    - Vxlan udp dport.
 * @return         Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_vxlan_udp_port_get(const uint32 unit, uint32 *ptr_dport);

/**
 * @brief Set hw parsering tunnel enable.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    type            - Tunnel parser type.
 * @param [in]    slice_bmp_en    - Parser en per slice.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_psr_en_set(const uint32 unit,
                         const clx_tnl_psr_type_t type,
                         const uint32 slice_bmp_en);

/**
 * @brief Get hw parsering tunnel enable status.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Tunnel parser type.
 * @param [out]    slice_bmp_en    - Parser en per slice.
 * @return         Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_psr_en_get(const uint32 unit, const clx_tnl_psr_type_t type, uint32 *slice_bmp_en);

/**
 * @brief Set hw ipv6 ext opt value.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    type        - Ipv6 ext type.
 * @param [in]    optValue    - Opt Value.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_ipv6_ext_set(const uint32 unit,
                           const clx_tnl_ipv6_ext_type_t type,
                           const uint32 optValue);

/**
 * @brief Get hw ipv6 ext opt value.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Ipv6 ext type.
 * @param [out]    ptr_optValue    - OptValue.
 * @return         Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_tnl_ipv6_ext_get(const uint32 unit,
                           const clx_tnl_ipv6_ext_type_t type,
                           uint32 *ptr_optValue);

#endif /* End of HAL_MT_NB_TNL_H */
