/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_pkj_handle.h
 * PURPOSE:
 *      It provides handle function of packet journal.
 *
 * NOTES:
 *
 */

#ifndef HAL_PKJ_HANDLE_H
#define HAL_PKJ_HANDLE_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PKJ_TBL_HANDLE_INFO_IDX (0)
#define HAL_PKJ_CB_HANDLE_INFO_IDX  (1)

/* MACRO FUNCTION DECLARATIONS
 */
typedef struct hal_pkj_tbl_cb_info_s {
    uint32 tbl_id;
    uint32 tbl_cb_id;
    boolean is_cb;
    uint32 *ptr_buf;
} hal_pkj_tbl_cb_info_t;

typedef clx_error_no_t (*HAL_PKJ_HANDLER)(const uint32 unit,
                                          const uint32 inst,
                                          const uint32 sub_inst,
                                          const hal_pkj_tbl_cb_info_t *ptr_tbl_info,
                                          void *ptr_cookie);

typedef struct hal_pkj_handler_vec_s {
    boolean is_cb_valid; /* 1: call callback when cb.valid is 1 */
    HAL_PKJ_HANDLER callback;
} hal_pkj_handler_vec_t;

typedef struct hal_pkj_handler_entry_s {
    uint32 tbl_id;
    uint32 handler_num;
    hal_pkj_handler_vec_t *ptr_handler_list;
} hal_pkj_handler_entry_t;

typedef struct hal_pkj_handler_info_s {
    uint32 num;
    hal_pkj_handler_entry_t *ptr_entry_list;
} hal_pkj_handler_info_t;

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

#endif /* #ifndef HAL_PKJ_HANDLE_H */
