/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mir.h
 * PURPOSE:
 *    It provides HAL driver API functions for mirror module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MIR_H
#define HAL_MIR_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_mir.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MIR_SESSION_ID_NUM           (8)
#define HAL_MIR_SESSION_ENTRY_NUM        (HAL_MIR_SESSION_ID_NUM * 2)
#define HAL_MIR_EGRESS_SESSION_ENTRY_MIN (HAL_MIR_SESSION_ID_NUM)
#define HAL_MIR_EGRESS_SESSION_ENTRY_MAX (HAL_MIR_SESSION_ID_NUM * 2 - 1)

#define HAL_MIR_ERSPAN_TERM_NUM (16)

#define HAL_MIR_IS_SESSION_BMP_VALID(unit, session_bmp) \
    (CLX_E_OK == hal_mir_session_bmp_is_valid(unit, session_bmp))

#define HAL_MIR_SESSION_BMP_TO_ID(session_bmp, session_id) \
    hal_mir_session_bmp_to_id_trans(session_bmp, &(session_id))

#define HAL_MIR_SESSION_ID_TO_BMP(session_id, session_bmp) ((session_bmp) = 1U << (session_id))

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_mir_meter_entry_s {
    uint32 trunc_size;
    uint32 bs_level;
    uint32 refresh_token;
    uint32 layer1_meter_add_token;
    uint32 packet;
    uint32 valid;
    uint32 bs_level_enable;
} hal_mir_meter_entry_t;

typedef struct hal_mir_dest_seg_srv_s {
    uint32 seg;
    uint32 is_single_tag;
    clx_port_bitmap_t local_ports;
} hal_mir_dest_seg_srv_t;

typedef struct hal_mir_warm_dest_seg_srv_s {
    uint32 seg;
    uint32 is_single_tag;
    uint32 local_ports[CLX_BITMAP_SIZE(160)];
} hal_mir_warm_dest_seg_srv_t;

typedef struct hal_mir_session_s {
    uint32 valid;                      /* is allocated */
    clx_mir_type_t mir_type;           /* mirror type  */
    clx_port_t port;                   /* Destination port/lag */
    hal_mir_meter_entry_t meter_entry; /* meter  */
    uint32 init_seq_num;               /* register write only */
    uint32 sample_rate;                /* sample rate, value CLX_INVALID_ID is drop */
} hal_mir_session_t;

typedef struct hal_mir_erspan_term_s {
    clx_ip_addr_t src_ip;
    clx_ip_addr_t dst_ip;
    uint32 erspan_id;
    uint32 session_vld;
    uint32 session_id;
    uint32 srv_intf_id; /* HAL_INVALID_ID means entry invalid */
    uint16 vrfo;        /* Vrf id of the underlay network. CLX86 only */
} hal_mir_erspan_term_t;

typedef struct hal_mir_sel_flw_s {
    uint32 enable;
    clx_swc_hsh_pkt_type_t hash_type; /* only support CLX_SWC_HSH_PKT_TYPE_LAG */
    uint32 hash_value;
    uint32 hash_mask;
    uint32 src_port;
    uint32 mir_id;
    uint32 flags; /* CLX_SWC_SELECTIVE_FLOW_FLAGS_XXX */
} hal_mir_sel_flw_t;

typedef struct hal_mir_cb_s {
    clx_semaphore_id_t sema;
    hal_mir_session_t session[HAL_MIR_SESSION_ENTRY_NUM];
    hal_mir_erspan_term_t erspan_term[HAL_MIR_ERSPAN_TERM_NUM];
    uint32 meter_add_token;
    uint32 lag_member_auto_update;
    hal_mir_sel_flw_t select_flow;
} hal_mir_cb_t;

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init Mirror module.
 *
 * @param [in]    unit    - Device unit index.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_mir_init(const uint32 unit);

/**
 * @brief De-init Mirror module.
 *
 * @param [in]    unit    - Device unit index.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - De-init fail.
 */
clx_error_no_t
hal_mir_deinit(const uint32 unit);

/**
 * @brief This API is used to add or set a mirror session. Mirror module supports five mirror
 *        session types, including: (1). Local SPAN session (2). RSPAN encap session (3).
 *        RSPAN decap session (4). ERSPAN encap session (5). ERSPAN decap session User should
 *        specify the session ID, direction and type when set a existed session.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    direction          - The session direction.
 * @param [in]    mir_id             - The session ID.
 * @param [in]    ptr_session_cfg    - The session information.
 * @return        CLX_E_OK               - Operation is success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - The session has been created.
 */
clx_error_no_t
hal_mir_session_add(const uint32 unit,
                    const clx_mir_direct_t direction,
                    const uint32 mir_id,
                    const clx_mir_session_cfg_t *ptr_session_cfg);

/**
 * @brief This API is used to delete a mirror session. User should specify the mirror direction and
 *        mirror id. Before deleting a mirror session, all sources binding to the session should be
 *        un-bound first.
 *
 * Before deleting a mirror session, all mirror sources bound to the session
 * should be removed first.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    direction    - The session direction.
 * @param [in]    mir_id       - The session ID.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
hal_mir_session_del(const uint32 unit, const clx_mir_direct_t direction, const uint32 mir_id);

/**
 * @brief This API is used to get mirror session information. User should specify the direction and
 *        session ID.
 *
 * User must specify the direction, session_id.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     direction          - The session direction.
 * @param [in]     mir_id             - The session ID.
 * @param [out]    ptr_session_cfg    - The information of this session to be obtained.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
hal_mir_session_get(const uint32 unit,
                    const clx_mir_direct_t direction,
                    const uint32 mir_id,
                    clx_mir_session_cfg_t *ptr_session_cfg);

/**
 * @brief This API is used to add a physical port as mirror session source or remove a physical
 *        port from mirror session source. User should specify the physical port ID,
 *        mirror session bitmap.
 *
 * @param [in]    unit                  - Device unit number.
 * @param [in]    port                  - Port ID.
 * @param [in]    dir                   - Ingress or egress mirror session.
 * @param [in]    mir_session_bitmap    - Mirror session bitmap.
 * @return        CLX_E_OK                 - Operation is success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
hal_mir_src_port_set(const uint32 unit,
                     const uint32 port,
                     const clx_dir_t dir,
                     const uint32 mir_session_bitmap);

/**
 * @brief This API is used to get the mirror session bitmap bound to a port.
 *
 * @param [in]     unit                      - Device unit ID.
 * @param [in]     port                      - The physical port ID.
 * @param [in]     dir                       - Ingress or egress mirror session.
 * @param [out]    ptr_mir_session_bitmap    - The mirror session is bound to the specified
 *                                             physical port on specified direction.
 *                                             If bit 0 is set, it means that the mirror session 0
 *                                             is bound to the port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
hal_mir_src_port_get(const uint32 unit,
                     const uint32 port,
                     const clx_dir_t dir,
                     uint32 *ptr_mir_session_bitmap);

/**
 * @brief This API is used to add an ERSPAN tunnel decap.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_decap_key    - The ERSPAN decap key.
 * @param [in]    mir_id           - The mirror id.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
hal_mir_erspan_decap_add(const uint32 unit,
                         const clx_mir_erspan_decap_key_t *ptr_decap_key,
                         const uint32 mir_id);

/**
 * @brief This API is used to delete an ERSPAN tunnel decap.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_decap_key    - The ERSPAN decap key.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
hal_mir_erspan_decap_del(const uint32 unit, const clx_mir_erspan_decap_key_t *ptr_decap_key);

/**
 * @brief This API is used to get an erspan term information.
 *
 * @param [in]     unit             - Device unit ID.
 * @param [in]     ptr_decap_key    - The erspan termination key.
 * @param [out]    ptr_mir_id       - Mirror session id.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
hal_mir_erspan_decap_get(const uint32 unit,
                         const clx_mir_erspan_decap_key_t *ptr_decap_key,
                         uint32 *ptr_mir_id);

/**
 * @brief This API is used to traverse ERSPAN tunnel decap information.
 *
 * @param [in]     unit          - Device unit ID.
 * @param [in]     callback      - The callback function of type clx_mir_erspan_decap_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified entry has not been created.
 */
clx_error_no_t
hal_mir_erspan_decap_trav(const uint32 unit,
                          const clx_mir_erspan_decap_trav_func_t callback,
                          void *ptr_cookie);

/**
 * @brief This API is used to configure ERSPAN term miss action.
 *
 * @param [in]    unit           - Device unit ID.
 * @param [in]    miss_action    - ERSPAN term miss action.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_erspan_term_miss_act_set(const uint32 unit, const uint32 miss_action);

/**
 * @brief This API is used to get ERSPAN term miss action.
 *
 * @param [in]     unit               - Device unit id.
 * @param [out]    ptr_miss_action    - ERSPAN term miss action.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_erspan_term_miss_act_get(const uint32 unit, uint32 *ptr_miss_action);

/**
 * @brief Set mirror meter layer mode (global).
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    layer_mode    - The mirror meter layer mode. 1 - layer 1;
 *                                0 - layer 2.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_meter_layer_set(const uint32 unit, const uint32 layer_mode);

/**
 * @brief Get mirror meter layer mode (global).
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_layer_mode    - The mirror meter layer mode. 1 - layer 1;
 *                                     0 - layer 2.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_meter_layer_get(const uint32 unit, uint32 *ptr_layer_mode);

/**
 * @brief Check mirror session bitmap.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    session_bmp    - Mirror session bmp.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_session_bmp_is_valid(const uint32 unit, const uint32 session_bmp);

/**
 * @brief Trans mirror session bitmap to id.
 *
 * @param [in]     session_bmp       - Mirror session bmp.
 * @param [out]    ptr_session_id    - Mirror session id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_session_bmp_to_id_trans(const uint32 session_bmp, uint32 *ptr_session_id);

/**
 * @brief Check mirror session id.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - Mirror session id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_session_id_is_valid(const uint32 unit, const uint32 session_id);

/**
 * @brief Update Lag port for mirror.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    event       - Lag port evnet.
 * @param [in]    lag_port    - Lag port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
void
hal_mir_lag_port_event_update(const uint32 unit, const uint32 event, const clx_port_t lag_port);

/**
 * @brief Get mirror control block.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
hal_mir_cb_t *
hal_mir_cb_get(const uint32 unit);

/**
 * @brief To set selective flow config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ptr_select_cfg    - Selective flow config.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_selective_flow_mir_set(const uint32 unit,
                               const clx_swc_selective_flow_cfg_t *ptr_select_cfg);

/**
 * @brief To get selective flow config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_select_cfg    - Selective flow config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mir_selective_flow_mir_get(const uint32 unit, clx_swc_selective_flow_cfg_t *ptr_select_cfg);

#endif /* end of HAL_MIR_H */
