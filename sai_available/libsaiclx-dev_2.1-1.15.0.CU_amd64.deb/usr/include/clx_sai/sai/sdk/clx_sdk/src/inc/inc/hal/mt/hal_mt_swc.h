/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_swc.h
 * PURPOSE:
 *    It provides HAL driver API functions for swc module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_SWC_H
#define HAL_MT_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <math.h>
#include <clx/clx_pkt.h>
#include <hal/mt/hal_mt_pkt_rsrc.h>
#include <hal/hal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_SWC_RSN_PRI_MIN         (0)
#define HAL_MT_SWC_RSN_PRI_MAX         (15)
#define HAL_MT_SWC_RSN_CLK_TO_NS(unit) (1000.0 / HAL_DEVICE_FREQ(unit))
#define HAL_MT_SWC_RSN_PRI_SPT         (12)
#define HAL_MT_SWC_RSN_PRI_SPT_HIGHT   (HAL_MT_SWC_RSN_PRI_SPT + 1)

#define HAL_MT_SWC_HSH_ID_ECMP_L3    (0)
#define HAL_MT_SWC_HSH_ID_ECMP_NVO3  (1)
#define HAL_MT_SWC_HSH_ID_MPLS       (1)
#define HAL_MT_SWC_HSH_ID_LAG        (2)
#define HAL_MT_SWC_HSH_ID_FABRIC_LAG (2)
#define HAL_MT_SWC_HSH_ID_ECMP_L2    (3)
#define HAL_MT_SWC_HSH_ENG_NUM       (4)
#define HAL_MT_SWC_HSH_KEY_ALL       (0x3ffffff)

#define HAL_MT_SWC_CB(unit) (&_hal_mt_swc_cb[unit])
#define HAL_MT_SWC_LOCK(unit) \
    HAL_COMMON_LOCK_RESOURCE(&(_hal_mt_swc_cb[unit].sema_id), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_SWC_UNLOCK(unit)          HAL_COMMON_FREE_RESOURCE(&(_hal_mt_swc_cb[unit].sema_id))
#define HAL_MT_CHIP_INIT_PP_TCAM_CHK_NUM (14)
#define HAL_MT_CHIP_INIT_PP_HSH_CHK_NUM  (12)

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_swc_epp_rsn_act_e {
    HAL_MT_SWC_EPP_RSN_ACT_DISABLE = 0,
    HAL_MT_SWC_EPP_RSN_ACT_COPY,
    HAL_MT_SWC_EPP_RSN_ACT_REDIR,
    HAL_MT_SWC_EPP_RSN_ACT_DROP,
    HAL_MT_SWC_EPP_RSN_ACT_LAST
} hal_mt_swc_epp_rsn_act_t;

typedef enum hal_mt_swc_wbdb_obj_type_e {
    HAL_MT_SWC_WBDB_CFG_ID = 0,
    HAL_MT_SWC_WBDB_CB_ID,
    HAL_MT_SWC_WBDB_OBJ_LAST
} hal_mt_swc_wbdb_obj_type_t;

typedef struct hal_mt_swc_cb_s {
    clx_semaphore_id_t sema_id;
    boolean excpt_ctrl;
    clx_swc_rsn_act_t rx_reason_action[CLX_PKT_RX_REASON_LAST];
    clx_fwd_action_t excpt_act[CLX_PKT_RX_REASON_LAST];
    uint32 reason_prio[HAL_MT_PKT_PP_RSN_LAST];
} hal_mt_swc_cb_t;

typedef void (*hal_swc_tcam_cfg_func_t)(uint32 unit,
                                        uint32 tcam_table,
                                        uint32 *tcam_field,
                                        uint32 *stage_cfg_buf);
typedef struct {
    clx_swc_tcam_type_t tcam_type;
    hal_swc_tcam_cfg_func_t tcam_cfg;
} hal_mt_swc_hal_tcam_cfg_t;

typedef struct {
    clx_swc_hsh_tile_type_t hash_tile;
    hal_hash_type_t hash_type;
} hal_mt_swc_hal_tile_bmp_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_swc_hsh_tile_bmp_get(const uint32 unit,
                            const clx_swc_hsh_tile_type_t hash_tile_type,
                            hal_swc_hsh_tile_bmp_t ptr_bmp);

clx_error_no_t
hal_mt_swc_tcam_bmp_get(const uint32 unit,
                        const clx_swc_tcam_type_t tcam_type,
                        hal_swc_tcam_bmp_t ptr_bmp);

/**
 * @brief Set hash engine configuration.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    hash_type      - Hash engine.
 * @param [in]    hash_engine    - Hash engine attributes.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHER            - Config fail.
 */
clx_error_no_t
hal_mt_swc_hsh_eng_set(const uint32 unit,
                       const clx_swc_hsh_pkt_type_t hash_type,
                       const clx_swc_hsh_eng_t *hash_engine);

/**
 * @brief Get hash engine configuration.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hash_type      - Hash engine.
 * @param [out]    hash_engine    - Pointer to hash engine attributes.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHER            - Config fail.
 */
clx_error_no_t
hal_mt_swc_hsh_eng_get(const uint32 unit,
                       const clx_swc_hsh_pkt_type_t hash_type,
                       clx_swc_hsh_eng_t *hash_engine);

/**
 * @brief Get switch control bitmap of all hash keys.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    key_bmp    - Hash key bitmap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_all_hsh_key_bmp_get(const uint32 unit, clx_swc_hsh_key_bmp_t *key_bmp);

/**
 * @brief Set switch control hash keys.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    hash_type    - Hash type.
 * @param [in]    key_bmp      - Hash key bitmap.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_hsh_key_set(const uint32 unit,
                       const clx_swc_hsh_pkt_type_t hash_type,
                       const clx_swc_hsh_key_bmp_t key_bmp);

/**
 * @brief Get switch control hash keys.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     hash_type    - Hash type.
 * @param [out]    key_bmp      - Hash key bitmap.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_hsh_key_get(const uint32 unit,
                       const clx_swc_hsh_pkt_type_t hash_type,
                       clx_swc_hsh_key_bmp_t *key_bmp);

/**
 * @brief Set hash engine polynominal coefficients.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    hash_type     - Hash engine to be config.
 * @param [in]    hash_const    - Hash constant.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHER            - Config fail.
 */
clx_error_no_t
hal_mt_swc_hsh_const_set(const uint32 unit,
                         const clx_swc_hsh_pkt_type_t hash_type,
                         const uint32 hash_const);

/**
 * @brief Get hash engine polynominal coefficients.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     hash_type         - Hash engine to be config.
 * @param [out]    ptr_hash_const    - Pointer to array of constants.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_hsh_const_get(const uint32 unit,
                         const clx_swc_hsh_pkt_type_t hash_type,
                         uint32 *ptr_hash_const);

/**
 * @brief To set table reason_code_act_x and field actx in each stage.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    epp_reason_code    - Epp reason code.
 * @param [in]    cpu_vld            - Cpu cpoy or not.
 * @param [in]    fwd_vld            - Fwd copy or not.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_epp_rsn_act_tbl_set(const uint32 unit,
                               const hal_mt_pkt_pp_rsn_t epp_reason_code,
                               const uint32 cpu_vld,
                               const uint32 fwd_vld);

/**
 * @brief To set PP reason priority.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    pp_reason_code    - Pp reason code.
 * @param [in]    priority          - Reason priority.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_pp_rsn_pri_set(const uint32 unit, const uint32 pp_reason_code, const uint32 priority);

/**
 * @brief To get PP reason priority.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     pp_reason_code    - Pp reason code.
 * @param [out]    priority          - Reason priority.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_pp_rsn_pri_get(const uint32 unit, const uint32 pp_reason_code, uint32 *priority);

/**
 * @brief Set RX reason action. Asign drop reason code if fowarding action is dropping.
 *        Asign CPU qeueu if fowarding action is copy to CPU or redirect to CPU.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    rx_reason_code      - Rx reason code.
 * @param [in]    rx_reason_action    - Rx reason aciton.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_rsn_act_set(const uint32 unit,
                       const clx_pkt_rx_reason_t rx_reason_code,
                       const clx_swc_rsn_act_t *rx_reason_action);

/**
 * @brief Get RX reason action. Get drop reason code or cpu queue.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    rx_reason_code      - Rx reason code.
 * @param [in]    rx_reason_action    - Rx reason aciton.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_rsn_act_get(const uint32 unit,
                       const clx_pkt_rx_reason_t rx_reason_code,
                       clx_swc_rsn_act_t *rx_reason_action);

/**
 * @brief This function is to set reason priority.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    rx_reason_code    - Rx reason code.
 * @param [in]    priority          - Reason priority.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_rsn_pri_set(const uint32 unit,
                       const clx_pkt_rx_reason_t rx_reason_code,
                       const uint32 priority);

/**
 * @brief This function is to get reason priority.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     rx_reason_code    - Rx reason code.
 * @param [out]    priority          - Reason priority.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_rsn_pri_get(const uint32 unit,
                       const clx_pkt_rx_reason_t rx_reason_code,
                       uint32 *priority);

/**
 * @brief This function is to set reason bloom filter configuration.
 *
 * @param [in]    unit                  - Device unit number.
 * @param [in]    bloom_filter_type     - Bloom filter type.
 * @param [in]    bloom_filter_value    - Bloom filter value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_rsn_bloom_filter_set(const uint32 unit,
                                const clx_swc_cfg_rsn_bloom_filter_type_t bloom_filter_type,
                                const uint32 bloom_filter_value);

/**
 * @brief This function is to get reason bloom filter configuration.
 *
 * @param [in]    unit                  - Device unit number.
 * @param [in]    bloom_filter_type     - Bloom filter type.
 * @param [in]    bloom_filter_value    - Bloom filter value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_rsn_bloom_filter_get(const uint32 unit,
                                const clx_swc_cfg_rsn_bloom_filter_type_t bloom_filter_type,
                                uint32 *bloom_filter_value);

/**
 * @brief Set exceptions to drop, to CPU or foward.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - Enable or restore exceptions.
 * @param [in]    action    - Drop, forward or send to the CPU.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_excpt_set(const uint32 unit, const uint32 enable, const clx_fwd_action_t action);

/**
 * @brief Trap all packets to CPU.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - Enable or disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_trap_all_set(const uint32 unit, const uint32 enable);

/**
 * @brief This function is to get max timestamp sec.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    max_ts_sec    - Max Timestamp sec.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_max_ts_sec_get(const uint32 unit, uint32 *max_ts_sec);

/**
 * @brief This function is to get tod info.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_swc_tod_info_get(const uint32 unit);

/**
 * @brief Set the EPP action based on the MOD's status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - MOD enable.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_mt_swc_mod_epp_rsn_set(const uint32 unit, boolean enable);

/**
 * @brief Set the drop reason based on the MOD's status.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - MOD enable.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_mt_swc_mod_drop_rsn_set(const uint32 unit, boolean enable);

/**
 * @brief To get register table information.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     tbl_type        - Table type.
 * @param [out]    ptr_tbl_list    - Pointer of register table array.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Get failed.
 */
clx_error_no_t
hal_mt_swc_reg_tbl_info_get(const uint32 unit, hal_swc_tbl_type_t tbl_type, uint32 *ptr_tbl_list);

/**
 * @brief To initialize switch control module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_mt_swc_init(const uint32 unit);

/**
 * @brief To deinitialize switch control module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_mt_swc_deinit(const uint32 unit);

#endif /* End of HAL_MT_SWC_H */
