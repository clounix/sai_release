/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_stp.h
 * PURPOSE:
 *      It provides STP module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_STP_H
#define CLX_STP_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
#define CLX_STP_CREATE_WITH_ID (1U << 0) /* The stgid is be specified by user */

typedef enum clx_stp_state_e {
    CLX_STP_STATE_DISABLED = 0, /* Disabled/forward */
    CLX_STP_STATE_DISCARD,      /* BPDUs/no learns/discard */
    CLX_STP_STATE_LEARN,        /* BPDUs/learns/disard */
    CLX_STP_STATE_FORWARD,      /* BPDUs/learns/forward */
    CLX_STP_STATE_LAST
} clx_stp_state_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Create a new STG.
 *
 * This API is used to create a new STG. The stgid can be specified
 * by user or automatically assigned by the software.
 * STG 0 has been created in STP module initialization process, and
 * it should not be created again.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number
 * @param [in]     flag       - Flag to specify the operation
 * @param [in,out] ptr_stgid  - Point to stgid
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_ENTRY_EXISTS     - Entry already exists
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
clx_error_no_t
clx_stp_create(const uint32 unit, const uint32 flag, uint32 *ptr_stgid);

/**
 * @brief Destroy a STG with user specified STG ID.
 *
 * If the STG ID is bound to some Bridge Domains, user should
 * bind them to other existing STG(s) before destroying this STG.
 * clx_bd_cfg_set is used to bind a STG to a Bridge Domain.
 * STG 0 is always active and should not be deleted.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     stgid  - STG ID which will be deleted
 * @return         CLX_E_OK                 - Operation success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry does not exist
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 */
clx_error_no_t
clx_stp_destroy(const uint32 unit, const uint32 stgid);

/**
 * @brief Set the STP state of a specified port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     stgid        - STG ID
 * @param [in]     port         - Port ID
 * @param [in]     stp_state    - Stp state
 * @return         CLX_E_OK                 - Operation success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry does not exist
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 */
clx_error_no_t
clx_stp_portstate_set(const uint32 unit,
                      const uint32 stgid,
                      const uint32 port,
                      const clx_stp_state_t stp_state);

/**
 * @brief Get the STP state for a specified port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     stgid            - STG ID
 * @param [in]     port             - Port ID
 * @param [out]    ptr_stp_state    - Point to stp state
 * @return         CLX_E_OK                 - Operation success
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry does not exist
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 */
clx_error_no_t
clx_stp_portstate_get(const uint32 unit,
                      const uint32 stgid,
                      const uint32 port,
                      clx_stp_state_t *ptr_stp_state);

/**
 * @brief Check whether a specified STG is created.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     stgid   - STG ID
 * @return         CLX_E_OK                 - The STG has been created
 * @return         CLX_E_ENTRY_NOT_FOUND    - The STG has not been created
 */
clx_error_no_t
clx_stp_is_valid(const uint32 unit, const uint32 stgid);

#endif /* End of CLX_STP_H */
