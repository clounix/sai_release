/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt.h
 * PURPOSE:
 *  1. Provide whole HAL resource initialization API.
 *  2. Provide HAL per-unit initialization and de-initialization function
 *     APIs.
 *  3. Provide HAL database access APIs.
 *  4. Provide a HAL multiplexing function vector.
 *
 * NOTES:
 */

#ifndef HAL_MT_H
#define HAL_MT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_MT_CPUDI_CPU_ID  (0)
#define HAL_MT_CPUDI_ECPU_ID (1)
#define HAL_MT_CPUDI_CPI0_ID (2)
#define HAL_MT_CPUDI_CPI1_ID (3)

#define HAL_MT_DFLT_CPUDI_QUEUE_ID 13
#define HAL_MT_DFLT_CPUDI_PRIORITY 3

#define HAL_MT_CPUDI_BASE          0x8 /* check DI[15:8] = 0x8, means 2k */
#define HAL_MT_CPUDI_BASE_OFFSET   8   /* cpu di base = DI[15:8] = 0x8 */
#define HAL_MT_CPUDI_CPU_ID_OFFSET 6   /* cpu id = DI[7:6] */
#define HAL_MT_CPU_ID_QUEUE_ID_TO_CPUDI(cpu_id, queue)                                          \
    ((HAL_MT_CPUDI_BASE << HAL_MT_CPUDI_BASE_OFFSET) | (cpu_id << HAL_MT_CPUDI_CPU_ID_OFFSET) | \
     (queue & 0x3f))

#define HAL_MT_BLACKHOLE_DI (4096 - 1)
#define HAL_MT_DELETED_PORT (40)

#endif /* #ifndef HAL_MT_H */
