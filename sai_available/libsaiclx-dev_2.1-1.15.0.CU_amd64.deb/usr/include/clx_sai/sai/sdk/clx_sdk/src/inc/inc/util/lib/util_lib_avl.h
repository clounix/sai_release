/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_avl.h
 * PURPOSE:
 *  this file is used to provide AVL tree API.
 * NOTES:
 *  it contains operations as below:
 *      1. create an AVL tree
 *      2. destroy an AVL tree
 *      3. insert user data to an AVL tree
 *      4. delete a user data from an AVL tree
 *      5. lookup a user data from an AVL tree
 *      6. traver an AVL tree in-order
 *      7. get the AVL tree nodes count
 *
 *
 */
#ifndef UTIL_LIB_AVL_H
#define UTIL_LIB_AVL_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <util/lib/util_lib.h>
#include <util/lib/util_lib_mpool.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* FUNCTION TYPE NAME: util_lib_avl_cmp_func_t
 * PURPOSE:
 *     it is used to compare user data with node data.
 * INPUT:
 *     ptr_user_param  -- user param, saved in avl tree head
 *     ptr_user_data   -- user data
 *     ptr_node_data   -- the data saved in node
 * OUTPUT:
 *     None.
 * RETURN:
 *     ==0 : user data is equal to node data
 *     <0  : user data is less than node data
 *     >0  : user data is more than node data
 * NOTES:
 *
 */
typedef int32 (*util_lib_avl_cmp_func_t)(void *ptr_user_param,
                                         void *ptr_user_data,
                                         void *ptr_node_data);

/* FUNCTION TYPE NAME: util_lib_avl_destroy_func_t
 * PURPOSE:
 *     it is used in destroy function, when user want to destroy an avl tree,
 *     use this function to release node data.
 * INPUT:
 *     ptr_user_param  -- user param, saved in avl tree head
 *     ptr_node_data   -- the data saved in node.
 * OUTPUT:
 *     None.
 * RETURN:
 *     None
 * NOTES:
 *
 */
typedef void (*util_lib_avl_destroy_func_t)(void *ptr_user_param, void *ptr_node_data);

/* FUNCTION TYPE NAME: util_lib_avl_trav_func_t
 * PURPOSE:
 *     it is used in traverse function, when traverse an avl tree, this function
 *     is used to process avl tree node data.
 * INPUT:
 *     ptr_user_param  -- user param, saved in avl tree head
 *     ptr_node_data   -- the data saved in node will be traversed.
 *     ptr_cookie      -- traverse data, a cookie data which is one of
 *                          parameters of traverse func
 * OUTPUT:
 *     None.
 * RETURN:
 *     CLX_E_OK     -- traverse success
 *     CLX_E_OTHERS -- traverse fail, stop traversing.
 * NOTES:
 *
 */
typedef clx_error_no_t (*util_lib_avl_trav_func_t)(void *ptr_user_param,
                                                   void *ptr_node_data,
                                                   void *ptr_cookie);

/* avl tree node structure */
typedef struct util_lib_avl_node_s {
    struct util_lib_avl_node_s *ptr_left;  /* point to left avl subtree   */
    struct util_lib_avl_node_s *ptr_right; /* point to right avl subtree  */
    void *ptr_data;                        /* user data saved in the node */
    uint32 height;                         /* height of the tree node     */
} util_lib_avl_node_t;

/* avl tree head node structure*/
typedef struct util_lib_avl_head_s {
    util_lib_avl_node_t *ptr_root;    /* root pointer                */
    char *ptr_name;                   /* name of avl tree            */
    util_lib_mpool_t *ptr_node_pool;  /* node pool                   */
    util_lib_avl_cmp_func_t cmp_func; /* compare function            */
    void *ptr_user_param;             /* user parameter data         */
    uint32 node_count;                /* number of node in the tree  */
    uint32 capacity;                  /* the capacity of the tree
                                       * 0 : unfixed size
                                       * >0: fixed size              */
} util_lib_avl_head_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Allocate an avl tree head and init with parameters. if capacity > 0 then allocate all the
 *        nodes and linked in one free node list. if capacity == 0 do not allocate nodes when init
 *        the head and the count of nodes is not limited, it's only limited by system memory.
 *
 * @param [in]     ptr_user_param    - User private parameter, can be NULL.
 *                                     it is a cookie data used in compare callback,
 *                                     traverse callback, destroy callback.
 * @param [in]     capacity          - >0 : the avl tree capacity is fixed.
 *                                     ==0: the capacity is not fixed.
 * @param [in]     cmp_func          - The compare function, must not be NULL.
 * @param [in]     ptr_name          - The avl tree name, max length is
 *                                     UTIL_LIB_NAME_LEN_MAX(include '\0').
 * @param [out]    pptr_head         - The avl tree head will be init with parameters.
 * @return         CLX_E_OK               - Create success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 * @return         CLX_E_NO_MEMORY        - Alloc avl tree head failed.
 * @return         CLX_E_OTHERS           - Create node pool failed.
 */
clx_error_no_t
util_lib_avl_create(void *ptr_user_param,
                    const uint32 capacity,
                    const util_lib_avl_cmp_func_t cmp_func,
                    const char *ptr_name,
                    util_lib_avl_head_t **pptr_head);

/**
 * @brief It is used to destroy an AVL tree, if user provide a destroy function,
 *        then when remove nodes from the tree, every node data will be processed by destroy
 *        function. it will release the head.
 *
 * @param [in]    ptr_head        - The avl tree head will be destroy.
 * @param [in]    destroy_func    - For processing the node data when removing nodes,
 *                                  if it is null, don't process node data.
 * @return        CLX_E_OK               - Destroy success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
util_lib_avl_destroy(const util_lib_avl_head_t *ptr_head,
                     const util_lib_avl_destroy_func_t destroy_func);

/**
 * @brief Insert a data into the avl tree. it allocate an avl tree node and save the data in the
 *        node, then insert the node into the tree. if the data has been in the tree,
 *        and overwrite_flag is false, then insert failed. or if overwrite_flag is true,
 *        intert the data to the node and the node data saved in pptr_overwriten_data and return to
 *        user.
 *
 * If overwrite_flag is TRUE, when insert success, please check the
 * pptr_overwriten_data if it is NULL. it may return overwritten data to user.
 *
 * @param [in]     ptr_head                 - The avl head will be inserted.
 * @param [in]     ptr_data                 - It will be passed to 2nd parameter of compare
 *                                            callback, if insertion success,
 *                                            the ptr_user_data will be saved in tree node and the
 *                                            node will be inserted into the tree.
 * @param [in]     overwrite_flag           - TRUE : if data exists, overwrite and return the old
 *                                            data in pptr_overwriten_data.
 *                                            FALSE: if data exists, insert failed,
 *                                            return CLX_E_ENTRY_EXISTS.
 * @param [out]    pptr_overwritten_data    - If a node data is overwritten,
 *                                            the node data will be saved in it and return to user.
 *                                            if overwrite_flag is FALSE,
 *                                            this can be NULL.
 * @return         CLX_E_OK               - Insert success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 * @return         CLX_E_NO_MEMORY        - Alloc avl tree node failed,
 *                                          it is for unfixed size avl tree.
 * @return         CLX_E_ENTRY_EXISTS     - The node has existed in the tree and overwrite_flag is
 *                                          false.
 * @return         CLX_E_TABLE_FULL       - No free nodes. it is for fixed size avl tree.
 */
clx_error_no_t
util_lib_avl_insert(util_lib_avl_head_t *ptr_head,
                    void *ptr_data,
                    const boolean overwrite_flag,
                    void **pptr_overwritten_data);

/**
 * @brief It used to delete an avl tree node by a specified data. after deletion,
 *        the deleted node will be returned by a parameter. if the deleted node doesn't exist,
 *        return CLX_E_ENTRY_NOT_FOUND.
 *
 * @param [in]     ptr_head          - The avl head will be deleted from.
 * @param [in]     ptr_data          - The data is used to find the node which will be deleted from
 *                                     avl tree, it will be passed to compare callback as the 2nd
 *                                     parameter to compare with node data.
 *                                     if the compare result is 0, the node will be deleted.
 * @param [out]    pptr_node_data    - The node data saved in the node which is deleted.
 * @return         CLX_E_OK                 - Delete success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The deleted node doesn't exist.
 */
clx_error_no_t
util_lib_avl_delete(util_lib_avl_head_t *ptr_head, void *ptr_data, void **pptr_node_data);

/**
 * @brief Find a node data by ptr_data in the avl tree. if the node doesn't exist return failure.
 *
 * @param [in]     ptr_head          - The avl head will be looked up.
 * @param [in]     ptr_data          - The data is used to find the node which is required by user
 *                                     from avl tree, if it compare with a node data and the result
 *                                     is 0, the node will be found.
 * @param [out]    pptr_node_data    - After lookup success, it is used save the node data.
 * @return         CLX_E_OK                 - Lookup success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The finding node doesn't exist.
 */
clx_error_no_t
util_lib_avl_lookup(const util_lib_avl_head_t *ptr_head, void *ptr_data, void **pptr_node_data);

/**
 * @brief Traverse every tree node in order to do traverse callback function for every node data.
 *        if callback return error, stop traversing and return the error to user.
 *
 * @param [in]    ptr_head      - The avl head will be traversed.
 * @param [in]    trav_func     - The traverse callback function.
 * @param [in]    ptr_cookie    - Traverse data, a cookie data for traverse function,
 *                                can be NULL.
 * @return        CLX_E_OK               - Traverse success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 * @return        CLX_E_OTHERS           - Traverse stop by traverse callback.
 */
clx_error_no_t
util_lib_avl_trav(const util_lib_avl_head_t *ptr_head,
                  const util_lib_avl_trav_func_t trav_func,
                  void *ptr_cookie);

/**
 * @brief Get the number of nodes in the avl tree.
 *
 * @param [in]     ptr_head     - The avl head will be counted.
 * @param [out]    ptr_count    - The count of nodes.
 * @return         CLX_E_OK               - Get count success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
util_lib_avl_count_get(const util_lib_avl_head_t *ptr_head, uint32 *ptr_count);

/**
 * @brief Get the next closest data for the specified user data in the avl tree.
 *        (In other words, the specified user data(ptr_data) may not be in the avl tree).
 *
 * @param [in]     ptr_head          - The avl head will be lookup.
 * @param [in]     ptr_data          - Pointer to the date that will be used to find its next
 *                                     closest data.
 * @param [out]    pptr_next_data    - Pointer to the next data address.
 * @return         CLX_E_OK                 - Get the next data success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Get the next data failed.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 */

clx_error_no_t
util_lib_avl_next_data_get(const util_lib_avl_head_t *ptr_head,
                           void *ptr_data,
                           void **pptr_next_data);

/**
 * @brief Get the prev closest data for the specified user data in the avl tree.
 *        (In other words, the specified user data(ptr_data) may not be in the avl tree).
 *
 * @param [in]     ptr_head          - The avl head will be lookup.
 * @param [in]     ptr_data          - Pointer to the date that will be used to find its prev
 *                                     closest data.
 * @param [out]    pptr_prev_data    - Pointer to the prev data address.
 * @return         CLX_E_OK                 - Get the prev data success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Get the prev data failed.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 */

clx_error_no_t
util_lib_avl_prev_data_get(const util_lib_avl_head_t *ptr_head,
                           void *ptr_data,
                           void **pptr_prev_data);

#endif /* End of UTIL_LIB_AVL_H */
