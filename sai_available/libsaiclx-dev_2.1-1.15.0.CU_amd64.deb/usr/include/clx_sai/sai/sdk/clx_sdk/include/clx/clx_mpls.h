/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_mpls.h
 * PURPOSE:
 *      It provides the declarations of the MPLS Module APIs.
 * NOTES:
 */

#ifndef CLX_MPLS_H
#define CLX_MPLS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <clx/clx_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_MPLS_LSP_ENCAP_NUM (4) /* Maximum label number(exclude ELI/EL) */
#define CLX_MPLS_DECAP_NUM     (4) /* Maximum match label number(exclude ELI/EL) */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* MPLS switch action */
typedef enum clx_mpls_get_type_e {
    CLX_MPLS_GET_TYPE_PORT = 0, /* mpls get port */
    CLX_MPLS_GET_TYPE_ID,       /* mpls get id */
    CLX_MPLS_GET_TYPE_KEY,      /* mpls get key */
    CLX_MPLS_GET_TYPE_LAST
} clx_mpls_get_type_t;

typedef enum clx_mpls_lbl_oper_e {
    CLX_MPLS_LBL_OPER_NONE = 0,  /* Keep switch label */
    CLX_MPLS_LBL_OPER_SWAP,      /* switch lable swap to a new label */
    CLX_MPLS_LBL_OPER_PUSH,      /* Remove switch and push a label */
    CLX_MPLS_LBL_OPER_SWAP_PUSH, /* Swap and Push at the same time*/
    CLX_MPLS_LBL_OPER_PHP,       /* For Penultimate-Hop Popping */
    CLX_MPLS_LBL_OPER_POP,       /* Similar to PHP, */
    CLX_MPLS_LBL_OPER_LAST
} clx_mpls_lbl_oper_t;

/* MPLS VPN type */
typedef enum clx_mpls_vpn_type_e {
    CLX_MPLS_L2VPN_VPLS = 0, /* VPN type: Virtual Private LAN Service (VPLS)*/
    CLX_MPLS_L2VPN_VPWS,     /* VPN type: Virtual Private Wire Service (VPWS)*/
    CLX_MPLS_L3VPN,          /* VPN type: Layer 3 Virtual Private Network (L3VPN)*/
    CLX_MPLS_VPN_LAST
} clx_mpls_vpn_type_t;

typedef struct clx_mpls_match_info_s {
    uint32 lbl_num;                     /* Match label numbers.mt: always 1 */
    uint32 lbl_arr[CLX_MPLS_DECAP_NUM]; /* Match label values in label entrys,mt switch always 1 */
    uint32 namespace_id;                /* Namespace id.mt: is vrf */
    uint32 flags;
} clx_mpls_match_info_t;
#define CLX_MPLS_MATCH_FLAGS_SWITCH_WITH_DECAP (1U << 0) /* Transit was preceded by term. */

typedef struct clx_mpls_pw_port_s {
    clx_mpls_vpn_type_t type;             /* vpn type. */
    uint32 encap_vc_lbl;                  /*VPN label to encapsulation. */
    clx_mpls_match_info_t term_match_key; /* Inbound match key,mt:only vpn label */
    clx_nhp_t nhp;                        /* next hop info*/
    clx_port_t pw_port;                   /* pw port*/
    uint32 flags;
} clx_mpls_pw_port_t;
#define CLX_MPLS_PW_PORT_FLAGS_OUT_VALID     (1U << 0) /* Outbound valid flag. */
#define CLX_MPLS_PW_PORT_FLAGS_PW_WITH_DECAP (1U << 1) /* PW was preceded by term.*/

typedef enum clx_mpls_el_lbl_pos_e {
    CLX_MPLS_EL_LBL_NONE = 0,   /* No el label */
    CLX_MPLS_EL_LBL_ABOVE_LBL0, /* EL label above label0 */
    CLX_MPLS_EL_LBL_UNDER_LBL0, /* EL label under label0 */
    CLX_MPLS_EL_LBL_UNDER_LBL1, /* EL label under label1 */
    CLX_MPLS_EL_LBL_LAST
} clx_mpls_el_lbl_pos_t;

typedef enum clx_mpls_lbl_range_type_e {
    CLX_MPLS_LBL_TYPE_P2P_UHP = 0, /* P2P label range.*/
    CLX_MPLS_LBL_TYPE_P2MP_UHP,    /* P2MP label range.*/
    CLX_MPLS_LBL_TYPE_LAST
} clx_mpls_lbl_range_type_t;
/* MPLS label range p2p/p2mp */
typedef struct clx_mpls_lbl_range_s {
    clx_mpls_lbl_range_type_t type; /* p2p or mp range type*/
    uint32 min_lbl_val;             /* min label range*/
    uint32 max_lbl_val;             /* max label range*/
} clx_mpls_lbl_range_t;

/* MPLS LSP label stack info */
typedef struct clx_mpls_lsp_lbl_arr_s {
    uint32 ttl;                   /* lsp encap ttl value */
    uint32 exp;                   /* lsp encap exp value */
    clx_mpls_el_lbl_pos_t el_pos; /* el label position. */
    uint32 lsp_lbl;               /* lsp encap label value */
    uint32 flags;
} clx_mpls_lsp_lbl_arr_t;
#define CLX_MPLS_LSP_LBL_FLAGS_SET_TTL                                                     \
    (1U << 0) /* Set TTL to lsp label.                                                     \
               * Set this flag at ingress is pipe/short-pipe model,encap with lsp_ttl.     \
               * without this flag is uniform model: encap with lsp_ttl form inner header. \
               */

#define CLX_MPLS_LSP_LBL_FLAGS_SET_EXP                                                     \
    (1U << 1) /* Set exp to lsp label.                                                     \
               * Set this flag at ingress is pipe/short-pipe model,encap with lsp_ttl.     \
               * without this flag is uniform model: encap with lsp_ttl form inner header. \
               */

#define CLX_MPLS_LSP_LBL_FLAGS_EL                          \
    (1U << 2) /* Push ELI/EL label flag , CL8600 can point \
                 position*/

typedef struct clx_mpls_lsp_info_s {
    uint32 lbl_num;                                         /* ENCAP LSP layers */
    clx_mpls_lsp_lbl_arr_t lsp_arr[CLX_MPLS_LSP_ENCAP_NUM]; /* ENCAP label array, 0 is the topmost
                                                               label */
    clx_port_t lsp_port; /*create lsp port or input lsp port with id*/
    uint32 flags;
} clx_mpls_lsp_info_t;
#define CLX_MPLS_LSP_FLAGS_WITH_ID (1U << 1) /* Specified the tunnel port */

/* MPLS Encapsulation Info */
typedef struct clx_mpls_encap_info_s {
    uint32 output_id;         /* output_id:LSP NVO3 adj idx */
    clx_port_t lsp_port;      /* LSP port bind to the nexthop*/
    clx_vlan_tpid_t egr_tpid; /* Inner valn tpid of inner payload
                                                             (Optional). */
    uint16 l2_mtu_size;       /* Egress L2 mtu size.*/
    uint32 mir_session_bmp;   /* Egress Mirror session ID bitmap (Optional) */
    clx_qos_prof_t egr_qos;   /* Egress qos */
    uint32 dist_cnt_id;       /* Egress distribution counter (Optional) */
    clx_sample_t sample;      /* Egress Sampling*/
    uint32 grp_lbl;           /* Egress LSP acl idx (Optional)*/
    uint32 meter_id;          /* Egress Egress meter  (Optional) */
    uint32 cnt_id;            /* Egress Egress counter (Optional) */
    uint32 flags;
} clx_mpls_encap_info_t;
#define CLX_MPLS_ENCAP_FLAGS_CW   (1U << 0)     /* Control word valid flag.*/
#define CLX_MPLS_ENCAP_FLAGS_PWEL (1U << 1)     /* Flow entropy label valid flag.*/
#define CLX_MPLS_ENCAP_FLAGS_ESI                                                            \
    (1U << 2)                                   /* NEW push ESI label encap esi label flag. \
                                                 */
#define CLX_MPLS_ENCAP_FLAGS_METER    (1U << 3) /* Meter valid flag */
#define CLX_MPLS_ENCAP_FLAGS_CNT      (1U << 4) /* Service counter valid flag */
#define CLX_MPLS_ENCAP_FLAGS_DIST_CNT (1U << 5) /* Distribution counter valid flag */
#define CLX_MPLS_ENCAP_FLAGS_KEEP_INNER_TAG                                    \
    (1U << 6)                                   /* set to 1 if keep inner tag. \
                                                 */
#define CLX_MPLS_ENCAP_FLAGS_VLAN_TAG (1U << 7) /* inner vlan tag valid flag. */

/* MPLS LSP decapsulation Info */
typedef struct clx_mpls_decap_info_s {
    clx_mpls_match_info_t term_key;                       /* Termination keys*/
    clx_bridge_domain_t bdid;                             /* LSP forwarding domain */
    clx_vlan_tpid_t igr_tpid[CLX_PORT_INTF_TPID_MAX_NUM]; /* Inner VLAN TAG of inner payload
                                                             (Optional) */
    uint32 dflt_pcp;          /* Inner Default PCP for inner payload (Optional) */
    uint32 meter_id;          /* Igress Meter ID (Optional)*/
    uint32 cnt_id;            /* Igress Service counter ID (Optional)*/
    uint32 dist_cnt_id;       /* Igress Distribution counter ID (Optional)*/
    clx_qos_prof_t igr_qos;   /* Ingress qos */
    uint32 l2_mtu;            /* Igress L2 MTU value (Optional) */
    uint32 grp_lbl;           /* Igress Group label (Optional) */
    clx_sample_t sample;      /* Igress Sampling*/
    uint32 mir_session_bmp;   /* Igress Mirror session ID bitmap (Optional) */
    clx_port_t lsp_port_bind; /* term lcl idx bind with a lsp port. */
    uint32 flags;
} clx_mpls_decap_info_t;
#define CLX_MPLS_DECAP_FLAGS_COPY_TTL_TO_INNER                                                              \
    (1U << 0)                                         /* Copy popped label's TTL to inner.                  \
                                                       * Set this flag means using uniform model at egress. \
                                                       * Otherwise, using pipe/short-pipe model             \
                                                       */
#define CLX_MPLS_DECAP_FLAGS_KEEP_INNER_QOS (1U << 1) /* Keep inner QoS flag */
#define CLX_MPLS_DECAP_FLAGS_USE_INNER_PHB  (1U << 2) /* User EXP of inner LSE for PHB flag */
#define CLX_MPLS_DECAP_FLAGS_DFLT_PCP       (1U << 3) /* Default PCP/DEI valid flag */
#define CLX_MPLS_DECAP_FLAGS_DFLT_DEI                                                            \
    (1U << 4)                                   /* Default DEI value while Default PCP/DEI valid \
                                                 */
#define CLX_MPLS_DECAP_FLAGS_METER    (1U << 5) /* Meter ID valid flag */
#define CLX_MPLS_DECAP_FLAGS_CNT      (1U << 6) /* Service counter ID valid flag */
#define CLX_MPLS_DECAP_FLAGS_DIST_CNT (1U << 7) /* Distribution counter ID valid flag */
#define CLX_MPLS_DECAP_FLAGS_PWCW     (1U << 8) /* Check PW CW valid flag.*/
#define CLX_MPLS_DECAP_FLAGS_QOS_TNL_UNIFORM \
    (1U << 9) /* outer copy to inner qos_dnt_modify=1 qos_tnl_uniform=1 qos_phb_inner=0.*/
#define CLX_MPLS_DECAP_FLAGS_L2VPN             (1U << 10) /* is L2VPN .*/
#define CLX_MPLS_DECAP_FLAGS_DISABLE_MAC_LEARN (1U << 11) /* disabel mac learn.*/
/* MPLS switch for transit LSR */
typedef struct clx_mpls_switch_info_s {
    clx_mpls_match_info_t switch_key; /* the keys for LSR switch */
    clx_bridge_domain_t bdid;         /* switch forwarding domain. */
    clx_mpls_lbl_oper_t nh_oper;      /* label actionfor nexthop */
    uint32 swap_lbl;                  /* swap label value */
    clx_nhp_t nhp;                    /*next hop info*/
    uint32 exp_to_phb_prof_id;        /* EXP to PHB mapping profile ID (Optional).*/
    uint16 l2_mtu_size;               /* L2 mtu size.*/
    uint32 flags;
} clx_mpls_switch_info_t;
#define CLX_MPLS_NH_FLAGS_KEEP_INNER_QOS    (1U << 1) /* Keep inner Qos for PHP case */
#define CLX_MPLS_NH_FLAGS_COPY_TTL_TO_INNER (1U << 2) /* Copy TTL to inner flag */
#define CLX_MPLS_NH_FLAGS_NO_DEC_TTL        (1U << 3) /* Don't decrement TTL*/
#define CLX_MPLS_NH_FLAGS_P2MP \
    (1U << 4) /* P2MP LSP. If the flag is set, the output_id is mcast_id */
#define CLX_MPLS_NH_FLAGS_EXP_TO_PHB_PROF (1U << 5) /* EXP to PHB profile ID valid flag */
#define CLX_MPLS_NH_FLAGS_USE_INNER_PHB   (1U << 6) /* Use inner exp for PHB flag.*/

typedef struct clx_mpls_pw_info_s {
    clx_port_t pw_port; /* pw port */
    uint32 vpn_id;      /* vpn id.*/
} clx_mpls_pw_info_t;

typedef struct clx_mpls_vpws_s {
    uint32 vpn_id;      /* vpn id.*/
    clx_port_t pw_port; /* vc port */
    clx_port_t ac_port; /* AC port */
    clx_vlan_t svid;    /* Service VLAN */
    clx_vlan_t cvid;    /* Customer VLAN */
    uint32 flags;
} clx_mpls_vpws_t;
#define CLX_MPLS_AC_FLAGS_SVID (1U << 0) /* Service VLAN ID valid flag.*/
#define CLX_MPLS_AC_FLAGS_CVID (1U << 1) /* Customer VLAN ID  valid flag.*/

typedef struct clx_mpls_vpn_info_s {
    clx_bridge_domain_t bdid;       /* pw bdid*/
    clx_bridge_domain_t bdid_extra; /* ac bdid, used for nb VPWS.*/
    clx_mpls_vpn_type_t type;       /* MPLS vpn type. */
    uint32 vpn_id;                  /*vpn id*/
} clx_mpls_vpn_info_t;

typedef clx_error_no_t (*clx_mpls_encap_trav_fun_t)(const uint32 unit,
                                                    const clx_mpls_lsp_info_t *ptr_key,
                                                    const clx_mpls_encap_info_t *ptr_init,
                                                    void *ptr_cookie);
typedef clx_error_no_t (*clx_mpls_transit_trav_func_t)(const uint32 unit,
                                                       const clx_mpls_switch_info_t *ptr_nhlfe,
                                                       void *ptr_cookie);

typedef clx_error_no_t (*clx_mpls_decap_trav_func_t)(const uint32 unit,
                                                     const clx_mpls_decap_info_t *ptr_term,
                                                     void *ptr_cookie);
typedef clx_error_no_t (*clx_mpls_pw_trav_func_t)(const uint32 unit,
                                                  const clx_mpls_pw_port_t *ptr_key,
                                                  const clx_mpls_pw_info_t *ptr_pw,
                                                  void *ptr_cookie);
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief The API is used to create a vpn id.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     vpn_info    - Bdid and mpls type info.
 * @param [out]    vpn_id      - Create vpn id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_vpn_id_create(const uint32 unit, const clx_mpls_vpn_info_t *vpn_info, uint32 *vpn_id);

/**
 * @brief The API is used to destroy a vpn id.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    vpn_id    - Vpn id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_vpn_id_destroy(const uint32 unit, uint32 vpn_id);

/**
 * @brief The API is used to get a vpn id.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - MPLS type.
 * @param [out]    ptr_key    - Get vpn id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_vpn_id_get(const uint32 unit,
                    const clx_mpls_get_type_t type,
                    clx_mpls_vpn_info_t *ptr_key);

/**
 * @brief The API is used to create the MPLS LSP port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_lsp_port    - MPLS tunnel encapsulation label info.
 * @param [out]    ptr_lsp_port    - Created MPLS tunnel port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_lsp_port_create(const uint32 unit, clx_mpls_lsp_info_t *ptr_lsp_port);

/**
 * @brief The API is used to destroy a MPLS tunnel port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - MPLS tunnel port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_lsp_port_destroy(const uint32 unit, const clx_port_t port);

/**
 * @brief The API is used to get MPLS LSP port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Get port or get key.
 * @param [out]    ptr_lsp_port    - LSP port info.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_lsp_port_get(const uint32 unit,
                      const clx_mpls_get_type_t type,
                      clx_mpls_lsp_info_t *ptr_lsp_port);

/**
 * @brief The API is used to add a MPLS LSP encapsulation, bind LSP tunnel to nvo3.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_encap    - Pointer of LSP tunnel initiation.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_encap_add(const uint32 unit, const clx_mpls_encap_info_t *ptr_encap);

/**
 * @brief The API is used to delete a MPLS LSP tunnel initiation.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    lsp_port    - MPLS LSP port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_encap_del(const uint32 unit, const clx_port_t lsp_port);

/**
 * @brief The API is used to get a MPLS LSP initiator information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_encap    - MPLS tunnel port.
 * @param [out]    ptr_encap    - Pointer of LSP tunnel initiation.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_encap_get(const uint32 unit, clx_mpls_encap_info_t *ptr_encap);

/**
 * @brief The API is used to add a MPLS LSP tunnel termination.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_term    - Pointer of LSP tunnel termination.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_decap_add(const uint32 unit, const clx_mpls_decap_info_t *ptr_term);

/**
 * @brief The API is used to get all MPLS init entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_encap_trav(const uint32 unit, const clx_mpls_encap_trav_fun_t cb, void *ptr_cookie);

/**
 * @brief The API is used to delete a MPLS LSP tunnel termination.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_key    - Pointer of LSP tunnel termination match key.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_decap_del(const uint32 unit, const clx_mpls_match_info_t *ptr_key);

/**
 * @brief The API is used to get a MPLS LSP tunnel termination.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_term    - Pointer of LSP tunnel termination.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_decap_get(const uint32 unit, clx_mpls_decap_info_t *ptr_term);

/**
 * @brief The API is used to get all MPLS term entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_decap_trav(const uint32 unit, const clx_mpls_decap_trav_func_t cb, void *ptr_cookie);

/**
 * @brief The API is used to add a MPLS transit for LSR.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_nh_info    - Pointer of LSP transit next hop information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_transit_add(const uint32 unit, const clx_mpls_switch_info_t *ptr_nh_info);

/**
 * @brief The API is used to delete a MPLS LSR transit.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_key    - Pointer of LSP transit match key.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_transit_del(const uint32 unit, const clx_mpls_match_info_t *ptr_key);

/**
 * @brief The API is used to get a MPLS transit LSP.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_nh_info    - Pointer of LSP transit next hop information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_transit_get(const uint32 unit, clx_mpls_switch_info_t *ptr_nh_info);

/**
 * @brief The API is used to get all MPLS transit entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_transit_trav(const uint32 unit, const clx_mpls_transit_trav_func_t cb, void *ptr_cookie);

/**
 * @brief The API is used to create a PW port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_pw_port    - PW port info.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_pw_port_create(const uint32 unit, clx_mpls_pw_port_t *ptr_pw_port);

/**
 * @brief The API is used to destroy a PW port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    pw_port    - PW port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_pw_port_destroy(const uint32 unit, const clx_port_t pw_port);

/**
 * @brief The API is used to get a PW port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     type      - Get port or key.
 * @param [out]    ptr_pw    - PW port info.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_pw_port_get(const uint32 unit, const clx_mpls_get_type_t type, clx_mpls_pw_port_t *ptr_pw);

/**
 * @brief The API is used to add a MPLS PW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_pw_info    - PW port info.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_pw_add(const uint32 unit, const clx_mpls_pw_info_t *ptr_pw_info);

/**
 * @brief The API is used to delete a MPLS PW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    pw_port    - PW port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_pw_del(const uint32 unit, const clx_port_t pw_port);

/**
 * @brief The API is used to get a MPLS PW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_pw_info    - PW port info.
 * @param [out]    ptr_pw_info    - Pointer of MPLS PW.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_pw_get(const uint32 unit, clx_mpls_pw_info_t *ptr_pw_info);

/**
 * @brief The API is used to get all MPLS PW entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_pw_trav(const uint32 unit, const clx_mpls_pw_trav_func_t cb, void *ptr_cookie);

/**
 * @brief The API is used to add a MPLS VPWS.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_vpws    - Add PW port and ac port to a VPWS.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_vpws_add(const uint32 unit, const clx_mpls_vpws_t *ptr_vpws);

/**
 * @brief The API is used to delete a MPLS VPWS.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    pw_port    - PW port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_vpws_del(const uint32 unit, const clx_port_t pw_port);

/**
 * @brief The API is used to get a MPLS VPWS.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_vpws    - Pointer of PW AC information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_mpls_vpws_get(const uint32 unit, clx_mpls_vpws_t *ptr_vpws);

/**
 * @brief The API is used to set MPLS label value range.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    lbl_range    - P2P and MP label range.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_lbl_range_set(const uint32 unit, const clx_mpls_lbl_range_t lbl_range);

/**
 * @brief The API is used to get MPLS label value range.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    lbl_range    - P2P and MP label range.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_mpls_lbl_range_get(const uint32 unit, clx_mpls_lbl_range_t *lbl_range);

#endif
