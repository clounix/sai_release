/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_pkj.h
 * PURPOSE:
 *     It provides packet journal APIs.
 *
 * NOTES:
 *
 */
#ifndef HAL_PKJ_H
#define HAL_PKJ_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <tob/tob.h>
#include <hal/hal_pkj_buf.h>
#include <hal/hal_pkj_tbl.h>
#include <hal/hal_pkj_decoder.h>
#include <hal/hal_pkj_handle.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PKJ_MAX_TYPE_LENGTH   (32)
#define HAL_PKJ_MAX_ENTRY_SIZE    (MAX_ENTRY_SIZE)
#define HAL_PKJ_MAX_ENTRY_WORDS   (HAL_MAX_ENTRY_WORD_SIZE)
#define HAL_PKJ_MAX_MPLS_LBL_NUM  (3)
#define HAL_PKJ_MAX_VLAN_NUM      (0xFFF)
#define HAL_PKJ_MAX_IPV6_FLOW_LBL (0xFFFFF)
#define HAL_PKJ_MAX_MPLS_LBL      (0xFFFFF)
#define HAL_PKJ_MAX_VXLAN_VNI_ID  (0xFFFFFF)
#define HAL_PKJ_MAX_PPH_DATA_NUM  (10)

/* CLX8600 pipeline module flags */
#define HAL_MT_PKJ_PP_FLAGS_TDS  (1U << 0)
#define HAL_MT_PKJ_PP_FLAGS_DIS  (1U << 1)
#define HAL_MT_PKJ_PP_FLAGS_FPU  (1U << 2)
#define HAL_MT_PKJ_PP_FLAGS_ICIA (1U << 3)
#define HAL_MT_PKJ_PP_FLAGS_FWR  (1U << 4)
#define HAL_MT_PKJ_PP_FLAGS_ITM  (1U << 5)
#define HAL_MT_PKJ_PP_FLAGS_ETM  (1U << 6)
#define HAL_MT_PKJ_PP_FLAGS_RWI  (1U << 7)
#define HAL_MT_PKJ_PP_FLAGS_ECIA (1U << 8)
#define HAL_MT_PKJ_PP_FLAGS_RWO  (1U << 9)
#define HAL_MT_PKJ_PP_FLAGS_NFE  (1U << 10)
#define HAL_MT_PKJ_PP_FLAGS_ALL  (0x7FF)

/* Pkj trigger key type flags */
#define HAL_PKJ_KEY_FLAGS_PORT  (1U << 0)
#define HAL_PKJ_KEY_FLAGS_MAC   (1U << 1)
#define HAL_PKJ_KEY_FLAGS_VLAN  (1U << 2)
#define HAL_PKJ_KEY_FLAGS_ARP   (1U << 3)
#define HAL_PKJ_KEY_FLAGS_IPV4  (1U << 4)
#define HAL_PKJ_KEY_FLAGS_IPV6  (1U << 5)
#define HAL_PKJ_KEY_FLAGS_DECAP (1U << 6)
#define HAL_PKJ_KEY_FLAGS_VXLAN (1U << 7)
#define HAL_PKJ_KEY_FLAGS_MPLS  (1U << 8)
#define HAL_PKJ_KEY_FLAGS_ALL   (0x1FF)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_PKJ_INFO(__unit__) (_ext_chip_control_block[(__unit__)].ptr_driver_info->ptr_pkj_info)

#define HAL_PKJ_PP_INFO(__unit__, __pipe__) &(HAL_PKJ_INFO((__unit__))->ptr_pp_info[(__pipe__)])

#define HAL_PKJ_TBL_INFO(__unit__, __tbl_id__) HAL_PKJ_INFO((__unit__))->pptr_tbl_info[(__tbl_id__)]

#define HAL_PKJ_BUF_INFO(__unit__, __buf_id__) HAL_PKJ_INFO((__unit__))->pptr_buf_info[(__buf_id__)]

#define HAL_PKJ_WORD_SIZE(__bit_num__) ((((__bit_num__) - 1) / 32) + 1)

#define HAL_PKJ_LIST_NUM(__list__) sizeof((__list__)) / sizeof((__list__)[0])

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_pkj_action_e {
    HAL_PKJ_ACTION_EN_DISABLE = 0,
    HAL_PKJ_ACTION_EN_ENABLE,
    HAL_PKJ_ACTION_EN_RESET,
    HAL_PKJ_ACTION_EN_LAST,
} hal_pkj_action_t;

typedef enum hal_pkj_property_e {
    HAL_PKJ_PROPERTY_ENABLE = 0,
    HAL_PKJ_PROPERTY_HIT_OVERWRITE,
    HAL_PKJ_PROPERTY_IGR_STATUS_OUTER,
    HAL_PKJ_PROPERTY_IGR_STATUS_INNER,
    HAL_PKJ_PROPERTY_EGR_STATUS,
    HAL_PKJ_PROPERTY_LAST,
} hal_pkj_property_t;

typedef struct hal_pkj_trig_key_port_s {
    uint32 igr_port;
    uint32 flags; /* pkj port trigger key flags, use HAL_PKJ_TRIG_KEY_PORT_FLAGS_XXX */
} hal_pkj_trig_key_port_t;

#define HAL_PKJ_TRIG_KEY_PORT_FLAGS_IGR_CLEAR (1 << 0)
#define HAL_PKJ_TRIG_KEY_PORT_FLAGS_DISABLE   (1 << 1)

typedef enum hal_pkj_value_e {
    HAL_PKJ_VALUE_DATA = 0,
    HAL_PKJ_VALUE_MSK,
    HAL_PKJ_VALUE_LAST,
} hal_pkj_value_t;

typedef struct hal_pkj_trig_key_mac_s {
    clx_mac_t dmac[HAL_PKJ_VALUE_LAST];
    clx_mac_t smac[HAL_PKJ_VALUE_LAST];
    uint16 ether_type[HAL_PKJ_VALUE_LAST];
} hal_pkj_trig_key_mac_t;

typedef struct hal_pkj_trig_key_vlan_s {
    clx_vlan_t svid[HAL_PKJ_VALUE_LAST];
    clx_vlan_t cvid[HAL_PKJ_VALUE_LAST];
} hal_pkj_trig_key_vlan_t;

typedef enum hal_pkj_trig_key_arp_frame_e {
    HAL_PKJ_ARP_FRAME_ARP_REQUEST = 1,
    HAL_PKJ_ARP_FRAME_ARP_RESPONSE = 2,
    HAL_PKJ_ARP_FRAME_RARP_REQUEST = 3,
    HAL_PKJ_ARP_FRAME_RARP_RESPONSE = 4,
} hal_pkj_trig_key_arp_frame_t;

typedef struct hal_pkj_trig_key_arp_s {
    clx_mac_t sender_mac[HAL_PKJ_VALUE_LAST];
    clx_mac_t target_mac[HAL_PKJ_VALUE_LAST];
    clx_ipv4_t sender_ip[HAL_PKJ_VALUE_LAST];
    clx_ipv4_t target_ip[HAL_PKJ_VALUE_LAST];
    hal_pkj_trig_key_arp_frame_t arp_frame_type;
    uint32 flags; /* pkj arp trigger key flags, use HAL_PKJ_TRIG_KEY_ARP_FLAGS_XXX */
} hal_pkj_trig_key_arp_t;

#define HAL_PKJ_TRIG_KEY_ARP_FLAGS_FRAME_TYPE_VALID (1 << 0)

typedef struct hal_pkj_trig_key_ipv4_s {
    clx_ipv4_t dip[HAL_PKJ_VALUE_LAST];
    clx_ipv4_t sip[HAL_PKJ_VALUE_LAST];
    uint16 dst_port[HAL_PKJ_VALUE_LAST];
    uint16 src_port[HAL_PKJ_VALUE_LAST];
    uint8 proto[HAL_PKJ_VALUE_LAST];
} hal_pkj_trig_key_ipv4_t;

typedef struct hal_pkj_trig_key_ipv6_s {
    clx_ipv6_t dip[HAL_PKJ_VALUE_LAST];
    clx_ipv6_t sip[HAL_PKJ_VALUE_LAST];
    uint16 dst_port[HAL_PKJ_VALUE_LAST];
    uint16 src_port[HAL_PKJ_VALUE_LAST];
    uint32 flow_lbl[HAL_PKJ_VALUE_LAST];
    uint8 proto[HAL_PKJ_VALUE_LAST];
} hal_pkj_trig_key_ipv6_t;

typedef enum hal_pkj_trig_key_decap_type_e {
    HAL_PKJ_DECAP_TYPE_NA = 0,
    HAL_PKJ_DECAP_TYPE_IP,
    HAL_PKJ_DECAP_TYPE_MPLS,
    HAL_PKJ_DECAP_TYPE_ERSPAN,
    HAL_PKJ_DECAP_TYPE_SRV6_POP_SRH,
    HAL_PKJ_DECAP_TYPE_SRV6_POP_IP_SRH,
    HAL_PKJ_DECAP_TYPE_FRC,
    HAL_PKJ_DECAP_TYPE_LAST,
} hal_pkj_trig_key_decap_type_t;

typedef struct hal_pkj_trig_key_decap_s {
    hal_pkj_trig_key_decap_type_t decap_type;
    uint32 flags; /* pkj decap trigger key flags, use HAL_PKJ_TRIG_KEY_DECAP_FLAGS_XXX */
} hal_pkj_trig_key_decap_t;

#define HAL_PKJ_TRIG_KEY_DECAP_FLAGS_VALID (1 << 0)

typedef struct hal_pkj_trig_key_mpls_s {
    uint32 mpls_lbl[HAL_PKJ_MAX_MPLS_LBL_NUM][HAL_PKJ_VALUE_LAST];
} hal_pkj_trig_key_mpls_t;

typedef struct hal_pkj_trig_key_vxlan_s {
    uint32 vnid[HAL_PKJ_VALUE_LAST];
} hal_pkj_trig_key_vxlan_t;

typedef struct hal_pkj_trig_key_s {
    hal_pkj_trig_key_port_t port_key;
    hal_pkj_trig_key_mac_t mac_key;
    hal_pkj_trig_key_mac_t inner_mac_key;
    hal_pkj_trig_key_vlan_t vlan_key;
    hal_pkj_trig_key_vlan_t inner_vlan_key;
    hal_pkj_trig_key_arp_t arp_key;
    hal_pkj_trig_key_ipv4_t ipv4_key;
    hal_pkj_trig_key_ipv4_t inner_ipv4_key;
    hal_pkj_trig_key_ipv6_t ipv6_key;
    hal_pkj_trig_key_ipv6_t inner_ipv6_key;
    hal_pkj_trig_key_decap_t decap_key;
    hal_pkj_trig_key_mpls_t mpls_key;
    hal_pkj_trig_key_vxlan_t vxlan_key;
    uint32 flags; /* pkj trigger key set flags, use HAL_PKJ_TRIG_KEY_FLAGS_XXX */
} hal_pkj_trig_key_t;

#define HAL_PKJ_TRIG_KEY_FLAGS_OUTER_VALID (1 << 0)
#define HAL_PKJ_TRIG_KEY_FLAGS_INNER_VALID (1 << 1)
#define HAL_PKJ_TRIG_KEY_FLAGS_GET_HW      (1 << 2)
#define HAL_PKJ_TRIG_KEY_FLAGS_CLEAR       (1 << 3)

typedef enum hal_pkj_chip_type_e {
    HAL_PKJ_CHIP_TYPE_NB = 0,
    HAL_PKJ_CHIP_TYPE_LAST,
} hal_pkj_chip_type_t;

typedef enum hal_pkj_nb_tm_capture_sel_asm_e {
    HAL_PKJ_NB_TM_CAPTURE_SEL_ASM_PDBWR2ASM = 0,
    HAL_PKJ_NB_TM_CAPTURE_SEL_ASM_ASM2REP,
    HAL_PKJ_NB_TM_CAPTURE_SEL_ASM_LAST,
} hal_pkj_nb_tm_capture_sel_asm_t;

typedef enum hal_pkj_nb_tm_capture_sel_rep_e {
    HAL_PKJ_NB_TM_CAPTURE_SEL_REP_REP2BAC = 0,
    HAL_PKJ_NB_TM_CAPTURE_SEL_REP_LAG_GRP_TBL,
    HAL_PKJ_NB_TM_CAPTURE_SEL_REP_LAG_MBR_TBL,
    HAL_PKJ_NB_TM_CAPTURE_SEL_REP_UC_DI_TBL,
    HAL_PKJ_NB_TM_CAPTURE_SEL_REP_FL_GRP_TBL,
    HAL_PKJ_NB_TM_CAPTURE_SEL_REP_FL_MBR_TBL,
    HAL_PKJ_NB_TM_CAPTURE_SEL_REP_LAST,
} hal_pkj_nb_tm_capture_sel_rep_t;

typedef enum hal_pkj_nb_tm_capture_sel_pdm_e {
    HAL_PKJ_NB_TM_CAPTURE_SEL_PDM_OQC2DQC_PD = 0,
    HAL_PKJ_NB_TM_CAPTURE_SEL_PDM_OQC2DQC_INFO,
    HAL_PKJ_NB_TM_CAPTURE_SEL_PDM_OQC2FRG,
    HAL_PKJ_NB_TM_CAPTURE_SEL_PDM_LAST,
} hal_pkj_nb_tm_capture_sel_pdm_t;

typedef enum hal_pkj_nb_tm_capture_sel_bac_e {
    HAL_PKJ_NB_TM_CAPTURE_SEL_BAC_REP2BAC = 0,
    HAL_PKJ_NB_TM_CAPTURE_SEL_BAC_LAST,
} hal_pkj_nb_tm_capture_sel_bac_t;

typedef enum hal_pkj_nb_tm_capture_sel_oqc_e {
    HAL_PKJ_NB_TM_CAPTURE_SEL_OQC_BAC2OQC = 0,
    HAL_PKJ_NB_TM_CAPTURE_SEL_OQC_OQC2PDM_WR_CMD_INFO,
    HAL_PKJ_NB_TM_CAPTURE_SEL_OQC_OQC2PDM_WR_CMD_KEY,
    HAL_PKJ_NB_TM_CAPTURE_SEL_OQC_LAST,
} hal_pkj_nb_tm_capture_sel_oqc_t;

typedef enum hal_pkj_nb_tm_capture_sel_dqc_e {
    HAL_PKJ_NB_TM_CAPTURE_SEL_DQC_OQC2DQC_L = 0,
    HAL_PKJ_NB_TM_CAPTURE_SEL_DQC_OQC2DQC_H,
    HAL_PKJ_NB_TM_CAPTURE_SEL_DQC_DQC2FRG,
    HAL_PKJ_NB_TM_CAPTURE_SEL_DQC_LAST,
} hal_pkj_nb_tm_capture_sel_dqc_t;

typedef enum hal_pkj_nb_tm_capture_sel_frg_e {
    HAL_PKJ_NB_TM_CAPTURE_SEL_FRG_DQC2FRG_PD = 0,
    HAL_PKJ_NB_TM_CAPTURE_SEL_FRG_OQC2FRG,
    HAL_PKJ_NB_TM_CAPTURE_SEL_FRG_SUB0_FRG2PDB,
    HAL_PKJ_NB_TM_CAPTURE_SEL_FRG_SUB1_FRG2PDB,
    HAL_PKJ_NB_TM_CAPTURE_SEL_FRG_DQC2FRG_DEL_PD,
    HAL_PKJ_NB_TM_CAPTURE_SEL_FRG_LAST,
} hal_pkj_nb_tm_capture_sel_frg_t;

typedef struct hal_pkj_nb_tm_capture_sel_s {
    hal_pkj_nb_tm_capture_sel_asm_t asm_sel;
    hal_pkj_nb_tm_capture_sel_rep_t rep_sel;
    hal_pkj_nb_tm_capture_sel_pdm_t pdm_sel;
    hal_pkj_nb_tm_capture_sel_bac_t bac_sel;
    hal_pkj_nb_tm_capture_sel_oqc_t oqc_sel;
    hal_pkj_nb_tm_capture_sel_dqc_t dqc_sel;
    hal_pkj_nb_tm_capture_sel_frg_t frg_sel;
    uint32 flags; /* pkj tm capture select mouleds, use HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_XXX  */
} hal_pkj_nb_tm_capture_sel_t;

#define HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_ASM_VALID (1 << 0)
#define HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_REP_VALID (1 << 1)
#define HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_PDM_VALID (1 << 2)
#define HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_BAC_VALID (1 << 3)
#define HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_OQC_VALID (1 << 4)
#define HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_DQC_VALID (1 << 5)
#define HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_FRG_VALID (1 << 6)
#define HAL_PKJ_NB_TM_CAPTURE_SEL_FLAGS_ALL_VALID (0x7F)

typedef struct hal_pkj_tm_capture_sel_s {
    hal_pkj_chip_type_t chip_type;
    union {
        hal_pkj_nb_tm_capture_sel_t nb_tm_sel;
    };
} hal_pkj_tm_capture_sel_t;

typedef struct hal_pkj_buf_meta_s {
    uint32 valid;
    uint32 hit;
    uint32 idx;
} hal_pkj_buf_meta_t;

typedef struct hal_pkj_dump_cbid_info_s {
    uint32 plane;
    uint32 cb_id;
} hal_pkj_dump_cbid_info_t;

typedef struct hal_pkj_dump_info_s {
    uint32 flags; /* HAL_PKJ_DUMP_FLAGS_XXX, if HAL_PKJ_DUMP_FLAGS_CBID, use cbid_info */
    union {
        uint32 pipe_flags;
        hal_pkj_dump_cbid_info_t cbid_info;
    };
} hal_pkj_dump_info_t;

#define HAL_PKJ_DUMP_FLAGS_FILTER0 (1U << 0)
#define HAL_PKJ_DUMP_FLAGS_MORE    (1U << 1)
#define HAL_PKJ_DUMP_FLAGS_RAW_BUF (1U << 2)
#define HAL_PKJ_DUMP_FLAGS_CBID    (1U << 3)
#define HAL_PKJ_DUMP_FLAGS_BRIEF   (1U << 4)

#define HAL_PKJ_DUMP_INTERNAL_FLAGS_ICIA    (1U << 27)
#define HAL_PKJ_DUMP_INTERNAL_FLAGS_ECIA    (1U << 28)
#define HAL_PKJ_DUMP_INTERNAL_FLAGS_NO_HEAD (1U << 29)
#define HAL_PKJ_DUMP_INTERNAL_FLAGS_ITM     (1U << 30)
#define HAL_PKJ_DUMP_INTERNAL_FLAGS_ETM     (1U << 31)

/* drv_vec */
typedef clx_error_no_t (*HAL_PKJ_INIT)(const uint32 unit);

typedef clx_error_no_t (*HAL_PKJ_DEINIT)(const uint32 unit);

typedef clx_error_no_t (*HAL_PKJ_PROPERTY_SET)(const uint32 unit,
                                               const hal_pkj_property_t property,
                                               const uint32 value);

typedef clx_error_no_t (*HAL_PKJ_PROPERTY_GET)(const uint32 unit,
                                               const hal_pkj_property_t property,
                                               uint32 *ptr_value);

typedef clx_error_no_t (*HAL_PKJ_TRIGGER_KEY_SET)(const uint32 unit,
                                                  const uint32 flags,
                                                  const hal_pkj_trig_key_t *ptr_trig_key);

typedef clx_error_no_t (*HAL_PKJ_TRIGGER_KEY_GET)(const uint32 unit,
                                                  hal_pkj_trig_key_t *ptr_trig_key);

typedef clx_error_no_t (*HAL_PKJ_TM_CAPTURE_SEL_SET)(const uint32 unit,
                                                     const hal_pkj_tm_capture_sel_t *ptr_tm_sel);

typedef clx_error_no_t (*HAL_PKJ_TM_CAPTURE_SEL_GET)(const uint32 unit,
                                                     hal_pkj_tm_capture_sel_t *ptr_tm_sel);

typedef clx_error_no_t (*HAL_PKJ_TABLE_DUMP)(const uint32 unit,
                                             const hal_pkj_dump_info_t *ptr_info);

typedef clx_error_no_t (*HAL_PKJ_DBG_ANALYZE)(const uint32 unit);

typedef struct hal_pkj_info_s {
    const char *driver_desc;
    hal_pkj_pp_info_t *ptr_pp_info;
    hal_pkj_buf_info_t **pptr_buf_info;
    hal_pkj_tbl_info_t **pptr_tbl_info;
    hal_pkj_handler_info_t *ptr_handler_info;
    HAL_PKJ_INIT init;
    HAL_PKJ_DEINIT deinit;
    HAL_PKJ_PROPERTY_SET property_set;
    HAL_PKJ_PROPERTY_GET property_get;
    HAL_PKJ_TRIGGER_KEY_SET trigger_key_set;
    HAL_PKJ_TRIGGER_KEY_GET trigger_key_get;
    HAL_PKJ_TM_CAPTURE_SEL_SET tm_capture_sel_set;
    HAL_PKJ_TM_CAPTURE_SEL_GET tm_capture_sel_get;
    HAL_PKJ_TABLE_DUMP table_dump;
    HAL_PKJ_DBG_ANALYZE dbg_analyze;
} hal_pkj_info_t;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
void
hal_pkj_cb_meta_unpack(const uint32 unit,
                       const hal_pkj_tbl_cb_info_t *ptr_tbl_cb_info,
                       hal_pkj_buf_meta_t *ptr_meta);

clx_error_no_t
hal_pkj_field_print(const uint32 unit,
                    const uint32 inst,
                    const uint32 sub_inst,
                    const hal_pkj_tbl_cb_info_t *ptr_tbl_cb_info,
                    const uint32 flags);

/* EXPOSED HAL PROGRAMS
 */
/**
 * @brief Pkj init.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_pkj_init(const uint32 unit);

/**
 * @brief Pkj deinit.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_pkj_deinit(const uint32 unit);

/**
 * @brief Pkj property set.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    property    - Pkj property type.
 * @param [in]    value       - Pkj property value.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter error.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_pkj_property_set(const uint32 unit, const hal_pkj_property_t property, const uint32 value);

/**
 * @brief Pkj property get.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     property     - Pkj property type.
 * @param [out]    ptr_value    - Pkj property value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter error.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_pkj_property_get(const uint32 unit, const hal_pkj_property_t property, uint32 *ptr_value);

/**
 * @brief Pkj trigger key set.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     flags           - Pkj trigger key set modules, use HAL_PKJ_KEY_FLAGS_XXX.
 * @param [out]    ptr_trig_key    - Pkj trigger key info.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter error.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_pkj_trigger_key_set(const uint32 unit,
                        const uint32 flags,
                        const hal_pkj_trig_key_t *ptr_trig_key);

/**
 * @brief Pkj trigger key get.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit            - Device unit number.
 * @param [out]    ptr_trig_key    - Pkj trigger key info.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter error.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_pkj_trigger_key_get(const uint32 unit, hal_pkj_trig_key_t *ptr_trig_key);

/**
 * @brief Pkj tm capture select set.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    ptr_tm_sel    - Pkj tm capture select info.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter error.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_pkj_tm_capture_sel_set(const uint32 unit, const hal_pkj_tm_capture_sel_t *ptr_tm_sel);

/**
 * @brief Pkj tm capture select get.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_tm_sel    - Pkj tm capture select info.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter error.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_pkj_tm_capture_sel_get(const uint32 unit, hal_pkj_tm_capture_sel_t *ptr_tm_sel);

/**
 * @brief Pkj capture table info dump.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_info    - Pkj capture table info.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter error.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_pkj_table_dump(const uint32 unit, const hal_pkj_dump_info_t *ptr_info);

/**
 * @brief Pkj capture table info analyze debug.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_pkj_dbg_analyze(const uint32 unit);
#endif /* End of HAL_PKJ_H */
