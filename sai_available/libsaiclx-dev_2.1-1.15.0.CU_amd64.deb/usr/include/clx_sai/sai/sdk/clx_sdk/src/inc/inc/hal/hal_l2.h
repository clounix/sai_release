/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_l2.h
 * PURPOSE:
 *    Provide HAL driver API functions of L2 module.
 *
 * NOTES:
 *
 */

#ifndef HAL_L2_H
#define HAL_L2_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_l2.h>
#include <hal/hal_const_cmn.h>
#include <hal/hal_lag.h>
#include <hal/hal_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_L2_FDB_ENTRY_MCAST_CP_TO_CPU_IDX (1)
#define HAL_L2_FDB_ENTRY_UCAST_CP_TO_CPU_IDX (1)
#define HAL_L2_FDB_NOTIFY_HANDLER_NUM        (4)
#define HAL_L2_FDB_SW_LEARN_HANDLER_NUM      (4)

#define HAL_L2_FDB_ENTRY_WORDS_MAX (MT_NB_CDB_FPU_HSH_L2_WORDS)

#define HAL_L2_FDB_MUTEX_SEMA_NAME      ("FDB_MUTEX_SEMA")
#define HAL_L2_NOTIFY_MUTEX_SEMA_NAME   ("NOTIFY_MUTEX_SEMA")
#define HAL_L2_SW_LEARN_MUTEX_SEMA_NAME ("SW_LEARN_MUTEX_SEMA")
#define HAL_L2_TRAV_MUTEX_SEMA_NAME     ("TRAV_MUTEX_SEMA")
#define HAL_L2_CALLBACK_MUTEX_SEMA_NAME ("CALLBACK_MUTEX_SEMA")

#define HAL_L2_TRAV_FDB_DMA_ENTRY_NUM    (512)
#define HAL_L2_TRAV_FDB_SLEEP_USEC       (5 * 1000)
#define HAL_L2_TRAV_FDB_SLEEP_TH_DMA_NUM (16)

#define HAL_L2_FAST_CMD_DONE_POLLING_USEC (1000)
#define HAL_L2_FAST_CMD_ENTRY_WORDS       (6)
#define HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS  (8)

#define HAL_L2_AGE_SEC_MIN     (3)
#define HAL_L2_AGE_SEC_MAX     (3145725) /* (2^20 - 1) * 3 */
#define HAL_L2_AGE_STEPS       (4)
#define HAL_L2_AGE_SEC_DEFAULT (300)

#define HAL_L2_MCAST_FDB_MUTEX_SEMA_NAME       ("MCAST_FDB_MUTEX_SEMA")
#define HAL_L2_MCAST_FDB_INDIR_RSLT_IDX_OFFSET (0x40000) /* (8 * 16k) */

#define HAL_L2_DEFAULT_MIR_KEEP_IGR_VLAN_TAGS (0)
#define HAL_L2_DI_FORWARD_DROP(unit)          (HAL_DROP_MIN(unit))

#define HAL_L2_OPERATING_MODE_FIFO (1)

#define HAL_L2_FIFO_TASK_NAME                 ("FIFO_TASK")
#define HAL_L2_FIFO_READ_PTR_UPDATE_THRESHOLD (42)
#define HAL_L2_FIFO_TASK_SLEEP_USEC           (10 * 1000)
#define HAL_L2_FIFO_TASK_SLEEP_TH_ENTRY_NUM   (HAL_L2_FIFO_READ_PTR_UPDATE_THRESHOLD * 256)
#define HAL_L2_FIFO_RING_BUF_EXTRA_ENTRY_NUM  (16 * 1024)
#define HAL_L2_FIFO_ENTRY_BYTES               (32)
#define HAL_L2_FIFO_UPLOAD_TH_FILL_COUNT      (42)
#define HAL_L2_FIFO_UPLOAD_TH_TIME            (100)
#define HAL_L2_FIFO_MAX_RING_BUF_ENTRY_NUM    (65535)
#define HAL_L2_FIFO_FDB_AVL_NAME              ("FIFO_FDB_AVL")
#define HAL_L2_FIFO_MC_FDB_AVL_NAME           ("FIFO_MC_FDB_AVL")

#define HAL_L2_POLLING_TASK_NAME       ("POLLING_TASK")
#define HAL_L2_POLLING_TASK_SLEEP_USEC (10 * 1000)

#define HAL_L2_TRAV_TASK_NAME ("TRAV_TASK")

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_L2_FDB_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].fdb_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_FDB_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].fdb_mutex_sema_id)
#define HAL_L2_NOTIFY_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].notify_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_NOTIFY_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].notify_mutex_sema_id)
#define HAL_L2_SW_LEARN_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].sw_learn_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_SW_LEARN_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_fdb_cb[(_unit_)].sw_learn_mutex_sema_id)
#define HAL_L2_MCAST_FDB_LOCK(_unit_)                                                 \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_mcast_fdb_cb[(_unit_)].mcast_fdb_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_MCAST_FDB_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_mcast_fdb_cb[(_unit_)].mcast_fdb_mutex_sema_id)
#define HAL_L2_CALLBACK_LOCK(_unit_)                                            \
    HAL_COMMON_LOCK_RESOURCE(&_hal_l2_trav_cb[(_unit_)].callback_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_L2_CALLBACK_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_l2_trav_cb[(_unit_)].callback_mutex_sema_id)

#define HAL_L2_UI32_MSK(__bits__) (0xFFFFFFFF >> (32 - (__bits__)))
#define HAL_L2_UI32_FLD_MSK(__unit__, __tbl_id__, __fld_id__) \
    (HAL_L2_UI32_MSK((TOB_TABLE((__unit__), (__tbl_id__))->ptr_table_entry[(__fld_id__)].length)))

#define HAL_L2_PLANE_BMP_FOREACH(__unit__, __plane__)                           \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

#define HAL_L2_DP_PLANE_PORT_BMP_FOREACH(__dp_plane_port_bmp__, __dp_plane_port__)    \
    for ((__dp_plane_port__) = HAL_PLANE_ETH_DP_PORT_MIN;                             \
         (__dp_plane_port__) <= HAL_PLANE_ETH_DP_PORT_MAX_CMN; (__dp_plane_port__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((__dp_plane_port_bmp__), (__dp_plane_port__)))

#define HAL_L2_PRINT_FDB_ENTRY(__flags__, __prefix_str__, __hw_fdb_entry__, __postfix_str__)    \
    do {                                                                                        \
        UTIL_LOG_PRINT(UTIL_LOG_L2, (__flags__), "%sfdb-entry=%08x.%08x.%08x.%08x.%08x.%08x%s", \
                       (__prefix_str__), (__hw_fdb_entry__)[5], (__hw_fdb_entry__)[4],          \
                       (__hw_fdb_entry__)[3], (__hw_fdb_entry__)[2], (__hw_fdb_entry__)[1],     \
                       (__hw_fdb_entry__)[0], (__postfix_str__));                               \
    } while (0)

#define HAL_L2_CHECK_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)         \
    do {                                                                                    \
        if (!HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __value__)) {  \
            UTIL_LOG_PRINT(UTIL_LOG_L2, UTIL_LOG_WARN, "u=%u, invalid " #__value__ "=%d\n", \
                           __unit__, __value__);                                            \
            return CLX_E_BAD_PARAMETER;                                                     \
        }                                                                                   \
    } while (0)

#define HAL_L2_GET_MCAST_EGR_PORT(_ptr_egr_intf_, _clx_port_) \
    do {                                                      \
        switch (_ptr_egr_intf_->type) {                       \
            case CLX_L2_MCAST_EGR_INTF_TYPE_PORT:             \
                _clx_port_ = _ptr_egr_intf_->port;            \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_L2:               \
                _clx_port_ = _ptr_egr_intf_->l2.port;         \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_TNL:              \
                _clx_port_ = _ptr_egr_intf_->tnl.port;        \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_SRV6:             \
                _clx_port_ = _ptr_egr_intf_->srv6.port;       \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_MPLS:             \
                _clx_port_ = _ptr_egr_intf_->mpls.port;       \
                break;                                        \
            default:                                          \
                return CLX_E_BAD_PARAMETER;                   \
                break;                                        \
        }                                                     \
    } while (0)

#define HAL_L2_SET_MCAST_EGR_PORT(_ptr_egr_intf_, _clx_port_) \
    do {                                                      \
        switch (_ptr_egr_intf_->type) {                       \
            case CLX_L2_MCAST_EGR_INTF_TYPE_PORT:             \
                _ptr_egr_intf_->port = _clx_port_;            \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_L2:               \
                _ptr_egr_intf_->l2.port = _clx_port_;         \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_TNL:              \
                _ptr_egr_intf_->tnl.port = _clx_port_;        \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_SRV6:             \
                _ptr_egr_intf_->srv6.port = _clx_port_;       \
                break;                                        \
            case CLX_L2_MCAST_EGR_INTF_TYPE_MPLS:             \
                _ptr_egr_intf_->mpls.port = _clx_port_;       \
                break;                                        \
            default:                                          \
                return CLX_E_BAD_PARAMETER;                   \
                break;                                        \
        }                                                     \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_l2_trav_action_e {
    HAL_L2_TRAV_ACTION_NOTIFY_CALLBACK = 0,
    HAL_L2_TRAV_ACTION_GET_COUNT = 1,
    HAL_L2_TRAV_ACTION_INIT_POLL = 2,
    HAL_L2_TRAV_ACTION_INIT_FIFO = 3,
} hal_l2_trav_action_t;

typedef enum hal_l2_fdb_hw_type_e {
    HAL_L2_FDB_HW_TYPE_HASH = 0,
    HAL_L2_FDB_HW_TYPE_TCAM,
} hal_l2_fdb_hw_type_t;
typedef enum hal_l2_type_e {
    HAL_L2_TYPE_UC = 0,
    HAL_L2_TYPE_MC,
} hal_l2_type_t;
typedef enum hal_l2_callback_reason_e {
    HAL_L2_CALLBACK_REASON_ADD = 0,
    HAL_L2_CALLBACK_REASON_MODIFY,
    HAL_L2_CALLBACK_REASON_DELETE,
    HAL_L2_CALLBACK_REASON_NEW_LEARN,
    HAL_L2_CALLBACK_REASON_MOVE,
    HAL_L2_CALLBACK_REASON_LAST,
} hal_l2_callback_reason_t;

typedef uint32 hal_l2_fast_cmd_entry_t[HAL_L2_FAST_CMD_ENTRY_WORDS];
typedef uint32 hal_l2_fast_cmd_tcam_entry_t[HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS];

typedef uint32 hal_l2_fdb_entry_t[HAL_L2_FDB_ENTRY_WORDS_MAX];

typedef struct hal_l2_callback_info_s {
    hal_l2_callback_reason_t reason;
    clx_l2_addr_t addr;
} hal_l2_callback_info_t;

typedef struct hal_l2_bum_mc_id_s {
    uint32 bc;
    uint32 umc;
    uint32 uuc;
} hal_l2_bum_mc_id_t;

typedef struct hal_l2_grp_nbr_sn_info_s {
    uint32 sn;
    uint32 mel_id;
    clx_l2_mcast_egr_intf_t member_info;
} hal_l2_grp_nbr_sn_info_t;

typedef struct hal_l2_warm_grp_info_s {
    uint32 group_size;
    boolean not_allow_reuse;
    uint32 logical_mc_id_ref_cnt;
    union {
        clx_port_bitmap_t non_port_intf_pbm;
        uint32 logical_mc_id;
    };
} hal_l2_warm_grp_info_t;
typedef struct hal_l2_grp_info_s {
    uint32 group_size;       /* Number of group member. */
    boolean not_allow_reuse; /* Indicate this phy mcast id is not allowed to reuse.
                              * Only members with non replicate, non tnl and non fabric link
                              * mcast group can be reused.
                              */
    uint32 logical_mc_id_ref_cnt;
    union {
        clx_port_bitmap_t non_port_intf_pbm; /* Group member port bitmap. Used when not_allow_reuse
                                                is FALSE */
        uint32 logical_mc_id; /* The logical mcast id corresponding to this phy mcast id. Used when
                                 not_allow_reuse is TRUE */
    };
    util_lib_list_t *ptr_member_list; /* mcast group member list */
} hal_l2_grp_info_t;

typedef struct hal_l2_mcast_fdb_cb_s {
    clx_semaphore_id_t mcast_fdb_mutex_sema_id;  /* mcast group process sema */
    uint32 group_num;                            /* max mcast group number */
    uint32 **pptr_hsh_mc_sc_ref_cnt;             /* per plane db, not use */
    hal_l3_mcast_mel_sub_entry_t *ptr_mel_entry; /* used for get mcast egr intf, not use */
    hal_l2_grp_info_t *ptr_group_info;           /* phy mcast group arry, index is phy mc id */
} hal_l2_mcast_fdb_cb_t;

typedef struct hal_l2_entry_idx_s {
    hal_l2_fdb_hw_type_t type;
    union {
        uint32 hash_idx; /* use for hash index,
                          * bit 0~14: idx, bit15~17: tile,
                          * bit 18~19: stage, bit 20~23: inst */
        uint32 tcam_id;  /* tcam allocate index */
    };
} hal_l2_entry_idx_t;
typedef struct hal_l2_fifo_sw_entry_s {
    uint32 fdid;       /* avl key. NB */
    clx_mac_t clx_mac; /* avl key. NB */
    uint32 is_valid;
    uint32 is_new_learn;
    hal_l2_entry_idx_t entry_idx; /* NB */
    uint32 age_event_bit;         /* NB */
    uint32 logical_mc_id;         /* NB. For mc fdb */
    hal_l2_fdb_entry_t fdb_entry;
} hal_l2_fifo_sw_entry_t;

typedef struct hal_l2_fifo_cb_s {
    clx_thread_id_t fifo_task_id;

    hal_l2_fifo_sw_entry_t *ptr_sw_fdb;
    hal_l2_fifo_sw_entry_t *ptr_sw_mc_fdb; /* NB */
    uint8 *ptr_ring_buf_start_not_align;
    uint8 *ptr_ring_buf_start;
    uint8 *ptr_ring_buf_nxt_read;
    uint8 *ptr_ring_buf_desc_start_not_align; /* NB */
    uint8 *ptr_ring_buf_desc_start;           /* NB */
    uint32 ring_buf_entry_num;
    uint32 nxt_seq_num;                       /* work idx */
    util_lib_avl_head_t *ptr_fdb_avl;         /* NB */
    util_lib_avl_head_t *ptr_mc_fdb_avl;      /* NB */
} hal_l2_fifo_cb_t;

typedef struct hal_l2_fdb_notify_handler_s {
    clx_l2_addr_notify_func_t callback;
    void *ptr_cookie;
} hal_l2_fdb_notify_handler_t;
typedef struct hal_l2_fdb_sw_learn_handler_s {
    clx_l2_addr_sw_learn_func_t callback;
    void *ptr_cookie;
} hal_l2_fdb_sw_learn_handler_t;
typedef struct hal_l2_fdb_cb_s {
    uint32 operating_mode;
    uint32 thread_pri;
    uint32 thread_stack_size;
    hal_l2_fifo_cb_t fifo_cb;

    clx_semaphore_id_t fdb_mutex_sema_id;
    clx_semaphore_id_t notify_mutex_sema_id;   /* protect ptr_notify_handler */
    clx_semaphore_id_t sw_learn_mutex_sema_id; /* protect ptr_sw_learn_handler */
    uint32 entry_num;
    hal_l2_fdb_notify_handler_t *ptr_notify_handler;
    hal_l2_fdb_sw_learn_handler_t *ptr_sw_learn_handler;

    void *ptr_trav_dma_fdb_entry_not_align;
    void *ptr_trav_dma_fdb_entry;
#if defined(CLX_MOCK)
    uint32 use_entry_num;    /* tmp for get usage in asicsim */
    uint32 use_mc_entry_num; /* tmp for get usage in asicsim */
#endif
} hal_l2_fdb_cb_t;
typedef struct hal_l2_trav_callback_node_s {
    clx_l2_addr_trav_func_t uc_callback;
    clx_l2_mcast_addr_trav_func_t mc_callback;
} hal_l2_trav_callback_node_t;
typedef struct hal_l2_trav_match_addr_s {
    clx_l2_addr_trav_match_t uc_addr;
    clx_l2_mcast_addr_trav_match_t mc_addr;
} hal_l2_trav_match_addr_t;
typedef struct hal_l2_trav_callback_info_s {
    hal_l2_type_t type;
    hal_l2_trav_callback_node_t callback;
    hal_l2_trav_match_addr_t match;
    void *cookie;
} hal_l2_trav_callback_info_t;
typedef struct hal_l2_trav_non_blocking_cb_s {
    /* Thread control */
    clx_thread_id_t task_id;
    uint32 thread_pri;
    uint32 thread_stack_size;
    clx_semaphore_id_t trav_mutex_sema_id;
    clx_semaphore_id_t callback_mutex_sema_id; /* protect ptr_callback_list */

    /* User callback parameters */
    util_lib_list_t *ptr_callback_list;

} hal_l2_trav_non_blocking_cb_t;

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */
extern hal_l2_fdb_cb_t _hal_l2_fdb_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern hal_l2_mcast_fdb_cb_t _hal_l2_mcast_fdb_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern hal_l2_trav_non_blocking_cb_t _hal_l2_trav_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

int32
hal_l2_fdb_avl_node_cmp(void *ptr_user_param, void *ptr_user_data, void *ptr_node_data);

void
hal_l2_list_node_free(void *ptr_node_data);

void
hal_l2_avl_node_free(void *ptr_user_param, void *ptr_node_data);

void
hal_l2_notify_addr_callback(const uint32 unit,
                            const clx_l2_addr_notify_reason_t reason,
                            const clx_l2_addr_t *ptr_addr);

void
hal_l2_sw_learn_addr_callback(const uint32 unit,
                              const clx_l2_addr_sw_learn_reason_t reason,
                              const clx_l2_addr_t *ptr_addr);

void
hal_l2_callback_handle(const uint32 unit,
                       util_lib_list_t **ptr_callback_list,
                       util_lib_list_t *ptr_list_1,
                       util_lib_list_t *ptr_list_2);

void
hal_l2_callback_node_add(const uint32 unit,
                         const hal_l2_callback_reason_t reason,
                         const clx_l2_addr_t *ptr_addr,
                         util_lib_list_t *ptr_callback_list);

clx_error_no_t
hal_l2_trav_callback_node_add(const uint32 unit,
                              const hal_l2_type_t type,
                              const hal_l2_trav_match_addr_t match,
                              const hal_l2_trav_callback_node_t callback,
                              void *ptr_cookie);

clx_error_no_t
hal_l2_addr_notify_cb_register(const uint32 unit,
                               const clx_l2_addr_notify_func_t callback,
                               void *ptr_cookie);

clx_error_no_t
hal_l2_addr_notify_cb_deregister(const uint32 unit,
                                 const clx_l2_addr_notify_func_t callback,
                                 void *ptr_cookie);

clx_error_no_t
hal_l2_addr_sw_learn_cb_register(const uint32 unit,
                                 const clx_l2_addr_sw_learn_func_t callback,
                                 void *ptr_cookie);

clx_error_no_t
hal_l2_addr_sw_learn_cb_deregister(const uint32 unit,
                                   const clx_l2_addr_sw_learn_func_t callback,
                                   void *ptr_cookie);

clx_error_no_t
hal_l2_port_is_my_chip_id_check(const uint32 unit,
                                const clx_port_t port,
                                boolean *ptr_is_my_chip_id);

void
hal_l2_sw_shadow_trav(const uint32 unit, const hal_l2_type_t type);

void
hal_l2_mc_mbr_trav(const uint32 unit, const uint32 mcast_id);

void
hal_l2_mcast_id_print(const uint32 unit, const uint32 tbl_id);

#endif /* End of HAL_L2_H */
