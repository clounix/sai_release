/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_port.h
 * PURPOSE:
 *      It provides PORT module API.
 * NOTES:
 */

#ifndef CLX_PORT_H
#define CLX_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_qos.h>
#include <clx/clx_meter.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_PORT_NUM             (288)
#define CLX_PORT_BITMAP_SIZE     CLX_BITMAP_SIZE(CLX_PORT_NUM)
#define CLX_PORT_PROFILE_INVALID (uint32)(-1)
#define CLX_PHY_MAX_MACRO        (33)

/* Port MAP API flags */
/* This port will be active(exist, not enable) after SDK boot-up */
#define CLX_PORT_FLAGS_INIT_ACTIVE    (1U << 0)
#define CLX_PORT_FLAGS_GUARANTEED     (1U << 1) /* This port will be guaranteed bandwidth */
#define CLX_PORT_FLAGS_SET_MAP_DONE   (1U << 2) /* Indicate setting port map completely */
#define CLX_PORT_FLAGS_CPI            (1U << 3) /* This port will be CPI port */
#define CLX_PORT_FLAGS_RCP            (1U << 4) /* This port will be RCP port */
#define CLX_PORT_FLAGS_DUAL_UMAC_56G  (1U << 6) /* This port will support 56G dual UMAC mode*/
#define CLX_PORT_FLAGS_DUAL_UMAC_112G (1U << 7) /* This port will support 112G dual UMAC mode*/
#define CLX_PORT_FLAGS_ECPU_AS_RCP    (1U << 8) /* This port will use ECPU port as RCP port */

/*Port auto-negotiation and link-traning flags*/
#define CLX_PORT_ANLT_DISABLE   (0) /* Disable auto-negotiation and link-traning */
#define CLX_PORT_ANLT_ENABLE    (1) /* Enable auto-negotiation and link-traning */
#define CLX_PORT_ANLT_ENABLE_LT (2) /* Enable link-traning only */
#define CLX_PORT_ANLT_LAST      (3)

/*Port fec flags*/
#define CLX_PORT_FEC_DISABLE   (0) /* Disable fec */
#define CLX_PORT_FEC_ENABLE    (1) /* Enable fec */
#define CLX_PORT_FEC_RS528     (2) /* Fec mode rs528 */
#define CLX_PORT_FEC_RS544     (3) /* Fec mode rs544 */
#define CLX_PORT_FEC_RS272     (4) /* Fec mode rs272 */
#define CLX_PORT_FEC_RS544_INT (5)
#define CLX_PORT_FEC_RS272_INT (6)
#define CLX_PORT_FEC_LAST      (7)
#define CLX_PORT_FEC_RS        CLX_PORT_FEC_RS528 /* Fec mode rs */

#define CLX_PORT_FEC_NONE_BITMAP      (1U << CLX_PORT_FEC_DISABLE)
#define CLX_PORT_FEC_BASER_BITMAP     (1U << CLX_PORT_FEC_ENABLE)
#define CLX_PORT_FEC_RS528_BITMAP     (1U << CLX_PORT_FEC_RS528)
#define CLX_PORT_FEC_RS544_BITMAP     (1U << CLX_PORT_FEC_RS544)
#define CLX_PORT_FEC_RS272_BITMAP     (1U << CLX_PORT_FEC_RS272)
#define CLX_PORT_FEC_RS544_INT_BITMAP (1U << CLX_PORT_FEC_RS544_INT)
#define CLX_PORT_FEC_RS272_INT_BITMAP (1U << CLX_PORT_FEC_RS272_INT)
#define CLX_PORT_FEC_LAST_BITMAP      (1U << CLX_PORT_FEC_LAST)

#define CLX_PORT_FEC_NONE_BASER (CLX_PORT_FEC_NONE_BITMAP | CLX_PORT_FEC_BASER_BITMAP)

#define CLX_PORT_FEC_NONE_RS528 (CLX_PORT_FEC_NONE_BITMAP | CLX_PORT_FEC_RS528_BITMAP)

#define CLX_PORT_FEC_NONE_BASER_RS528 \
    (CLX_PORT_FEC_NONE_BITMAP | CLX_PORT_FEC_BASER_BITMAP | CLX_PORT_FEC_RS528_BITMAP)

#define CLX_PORT_FEC_RS544_RS272 (CLX_PORT_FEC_RS544_BITMAP | CLX_PORT_FEC_RS272_BITMAP)

#define CLX_PORT_FEC_RS544_RS272_RSINT                                                       \
    (CLX_PORT_FEC_RS544_BITMAP | CLX_PORT_FEC_RS272_BITMAP | CLX_PORT_FEC_RS544_INT_BITMAP | \
     CLX_PORT_FEC_RS272_INT_BITMAP)

#define CLX_PORT_FEC_RS528_RS544_RS272 \
    (CLX_PORT_FEC_RS528_BITMAP | CLX_PORT_FEC_RS544_BITMAP | CLX_PORT_FEC_RS272_BITMAP)

#define CLX_PORT_FEC_NONE_RS528_RS544_RS272                                             \
    (CLX_PORT_FEC_NONE_BITMAP | CLX_PORT_FEC_RS528_BITMAP | CLX_PORT_FEC_RS544_BITMAP | \
     CLX_PORT_FEC_RS272_BITMAP)

#define CLX_PORT_FEC_NONE_BASER_RS528_RS544_RS272                                       \
    (CLX_PORT_FEC_NONE_BITMAP | CLX_PORT_FEC_BASER_BITMAP | CLX_PORT_FEC_RS528_BITMAP | \
     CLX_PORT_FEC_RS544_BITMAP | CLX_PORT_FEC_RS272_BITMAP)

/*Port link flags*/
#define CLX_PORT_LINK_DOWN (0) /* Port status link down */
#define CLX_PORT_LINK_UP   (1) /* Port status link up */

/*Port fault flags*/
#define CLX_PORT_FAULT_NONE   (0) /* Port fault detect none */
#define CLX_PORT_FAULT_LOCAL  (1) /* Port fault detect local */
#define CLX_PORT_FAULT_REMOTE (2) /* Port fault detect remote */

/*Port flow control flags*/
#define CLX_PORT_FC_STATUS_OFF   (0) /* Flow control status off */
#define CLX_PORT_FC_STATUS_ON    (1) /* Flow control status on */
#define CLX_PORT_FC_PRIO_MAX_NUM (7) /* priority flow control max number */

#define CLX_PORT_LANE_MAX_NUM (8)    /* Port max lane number */

#define CLX_PORT_MBURST_PATT_LENTH         (4)
#define CLX_PORT_MBURST_HIST_THRESHOLD_NUM (7)
#define CLX_PORT_MBURST_MAX_WEIGHT_CNT     (3)
#define CLX_PORT_MBURST_HIST_MIN_VALUE     (10)
#define CLX_PORT_MBURST_HIST_MAX_VALUE     (16)
#define CLX_PORT_MBURST_WINDOW_190NS       (8)
#define CLX_PORT_MBURST_WINDOW_381NS       (9)
#define CLX_PORT_MBURST_WINDOW_769NS       (10)
#define CLX_PORT_MBURST_WINDOW_1538NS      (11)
#define CLX_PORT_MBURST_WINDOW_3076NS      (12)
#define CLX_PORT_MBURST_WINDOW_MIN         (8)
#define CLX_PORT_MBURST_WINDOW_MAX         (12)
#define CLX_PORT_FC_DEFAULT_PRI            (0xFF)
/* MACRO FUNCTION DECLARATIONS
 */
#define CLX_PORT_ADD(bitmap, port) (((bitmap)[(port) / 32]) |= (1U << ((port) % 32)))
#define CLX_PORT_DEL(bitmap, port) (((bitmap)[(port) / 32]) &= ~(1U << ((port) % 32)))
#define CLX_PORT_CHK(bitmap, port) ((((bitmap)[(port) / 32] & (1U << ((port) % 32)))) != 0)

#define CLX_PORT_FOREACH(bitmap, port)          \
    for (port = 0; port < CLX_PORT_NUM; port++) \
        if (CLX_PORT_CHK(bitmap, port))

#define CLX_PORT_BITMAP_CLEAR(bitmap)                                                    \
    ((bitmap)[0] = (bitmap)[1] = (bitmap)[2] = (bitmap)[3] = (bitmap)[4] = (bitmap)[5] = \
         (bitmap)[6] = (bitmap)[7] = (bitmap)[8] = 0)

#define CLX_PORT_BITMAP_EMPTY(bitmap)                                                        \
    (((bitmap)[0] == 0) && ((bitmap)[1] == 0) && ((bitmap)[2] == 0) && ((bitmap)[3] == 0) && \
     ((bitmap)[4] == 0) && ((bitmap)[5] == 0) && ((bitmap)[6] == 0) && ((bitmap)[7] == 0) && \
     ((bitmap)[8] == 0))

#define CLX_PORT_BITMAP_EQUAL(bitmap_a, bitmap_b)                            \
    (((bitmap_a)[0] == (bitmap_b)[0]) && ((bitmap_a)[1] == (bitmap_b)[1]) && \
     ((bitmap_a)[2] == (bitmap_b)[2]) && ((bitmap_a)[3] == (bitmap_b)[3]) && \
     ((bitmap_a)[4] == (bitmap_b)[4]) && ((bitmap_a)[5] == (bitmap_b)[5]) && \
     ((bitmap_a)[6] == (bitmap_b)[6]) && ((bitmap_a)[7] == (bitmap_b)[7]) && \
     ((bitmap_a)[8] == (bitmap_b)[8]))

#define CLX_PORT_BITMAP_ADD(bitmap_a, bitmap_b)            \
    do {                                                   \
        uint32 idx;                                        \
        for (idx = 0; idx < 9; idx++) {                    \
            bitmap_a[idx] = bitmap_a[idx] | bitmap_b[idx]; \
        }                                                  \
    } while (0)

#define CLX_PORT_BITMAP_DEL(bitmap_a, bitmap_b)             \
    do {                                                    \
        uint32 idx;                                         \
        for (idx = 0; idx < 9; idx++) {                     \
            bitmap_a[idx] = bitmap_a[idx] & ~bitmap_b[idx]; \
        }                                                   \
    } while (0)

#define DSH_MAX_HEX_NUM (16)

/* macro to get user CPU port */
#define CLX_PORT_CPU_PORT(__unit__) (HAL_CPU_PORT(__unit__))

/* macro to get user ECPU port */
#define CLX_PORT_ECPU_PORT(__unit__, __idx__) (HAL_ECPU_PORT(__unit__, __idx__))

#define CLX_PORT_IS_ECPU_PORT(__unit__, __port__)                     \
    (((__port__) == CLX_PORT_ECPU_PORT(__unit__, HAL_ECPU_PORT_0)) || \
     ((__port__) == CLX_PORT_ECPU_PORT(__unit__, HAL_ECPU_PORT_1)) || \
     ((__port__) == CLX_PORT_ECPU_PORT(__unit__, HAL_ECPU_PORT_2)) || \
     ((__port__) == CLX_PORT_ECPU_PORT(__unit__, HAL_ECPU_PORT_3)) || \
     ((__port__) == CLX_PORT_ECPU_PORT(__unit__, HAL_ECPU_PORT_4)))

#define CLX_PORT_ECPU_PORT_FOREACH(__unit__, __idx__)                   \
    for (__idx__ = 0; __idx__ < HAL_ECPU_PORT_NUM(__unit__); __idx__++) \
        if (CLX_PORT_INVALID != CLX_PORT_ECPU_PORT(__unit__, (HAL_ECPU_PORT_0 + __idx__)))

/* macro to get user CPI ports */
#define CLX_PORT_CPI_PORT_0(__unit__) (HAL_CPI_PORT(__unit__, 0))
#define CLX_PORT_CPI_PORT_1(__unit__) (HAL_CPI_PORT(__unit__, 1))

#define CLX_PORT_IS_CPI_PORT(__unit__, __port__) (HAL_IS_CPI_PORT(__unit__, __port__))

/* macro to get user RC ports */
#define CLX_PORT_RC_PORT(__unit__, __idx__) (HAL_RC_PORT(__unit__, __idx__))

#define CLX_PORT_IS_RC_PORT(__unit__, __port__)                   \
    (((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_0)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_1)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_2)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_3)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_4)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_5)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_6)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_7)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_8)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_9)) || \
     ((__port__) == CLX_PORT_RC_PORT(__unit__, HAL_RC_PORT_10)))

#define CLX_PORT_RC_PORT_FOREACH(__unit__, __idx__)                   \
    for (__idx__ = 0; __idx__ < HAL_RC_PORT_NUM(__unit__); __idx__++) \
        if (CLX_PORT_INVALID != CLX_PORT_RC_PORT(__unit__, (HAL_RC_PORT_0 + __idx__)))

/* macro to get user-port bitmap */
#define CLX_PORT_BMP(__unit__)       (HAL_PORT_BMP(__unit__))
#define CLX_PORT_BMP_PP(__unit__)    (HAL_PORT_BMP_PP(__unit__))
#define CLX_PORT_BMP_ETH(__unit__)   (HAL_PORT_BMP_ETH(__unit__))
#define CLX_PORT_BMP_PHY(__unit__)   (HAL_PORT_BMP_PHY(__unit__))
#define CLX_PORT_BMP_TOTAL(__unit__) (HAL_PORT_BMP_TOTAL(__unit__))

/* macro for coding decision statement */
#define CLX_PORT_IS_PORT_VALID(__unit__, __user_port__) (HAL_IS_PORT_VALID(__unit__, __user_port__))
#define CLX_PORT_IS_ETH_PORT_VALID(__unit__, __user_port__) \
    (HAL_IS_ETH_PORT_VALID(__unit__, __user_port__))

/* macro to check user-port (check fail will return directly) */
#define CLX_PORT_CHECK_PORT(__unit__, __user_port__)                                       \
    do {                                                                                   \
        HAL_CHECK_UNIT(__unit__);                                                          \
        if (!HAL_IS_PORT_VALID((__unit__), (__user_port__))) {                             \
            UTIL_LOG_PRINT(UTIL_LOG_PORT, UTIL_LOG_WARN, "u=%u, invalid port=%u, rc=%d\n", \
                           __unit__, __user_port__, CLX_E_BAD_PARAMETER);                  \
            return CLX_E_BAD_PARAMETER;                                                    \
        }                                                                                  \
    } while (0)

#define CLX_PORT_CHECK_ETH_PORT(__unit__, __user_port__)                                       \
    do {                                                                                       \
        HAL_CHECK_UNIT(__unit__);                                                              \
        if (!HAL_IS_ETH_PORT_VALID((__unit__), (__user_port__))) {                             \
            UTIL_LOG_PRINT(UTIL_LOG_PORT, UTIL_LOG_WARN, "u=%u, invalid eth port=%u, rc=%d\n", \
                           __unit__, __user_port__, CLX_E_BAD_PARAMETER);                      \
            return CLX_E_BAD_PARAMETER;                                                        \
        }                                                                                      \
    } while (0)

#define CLX_PORT_CHECK_PP_PORT(__unit__, __user_port__)                                      \
    do {                                                                                     \
        HAL_CHECK_UNIT(__unit__);                                                            \
        if (!HAL_IS_PP_PORT_VALID((__unit__), (__user_port__))) {                            \
            UTIL_LOG_PRINT(UTIL_LOG_PORT, UTIL_LOG_ERR, "u=%u, invalid pp port=%u, rc=%d\n", \
                           __unit__, __user_port__, CLX_E_BAD_PARAMETER);                    \
            return CLX_E_BAD_PARAMETER;                                                      \
        }                                                                                    \
    } while (0)

#define CLX_PORT_CHECK_PHY_PORT(__unit__, __user_port__)                                       \
    do {                                                                                       \
        HAL_CHECK_UNIT(__unit__);                                                              \
        if (!HAL_IS_PHY_PORT_VALID((__unit__), (__user_port__))) {                             \
            UTIL_LOG_PRINT(UTIL_LOG_PORT, UTIL_LOG_WARN, "u=%u, invalid phy port=%u, rc=%d\n", \
                           __unit__, __user_port__, CLX_E_BAD_PARAMETER);                      \
            return CLX_E_BAD_PARAMETER;                                                        \
        }                                                                                      \
    } while (0)

/* macro to check user-port bitmaps (check fail will return directly) */
#define CLX_PORT_CHECK_PORT_BITMAP(__unit__, __user_pbmp__)                                    \
    do {                                                                                       \
        HAL_CHECK_UNIT(__unit__);                                                              \
        clx_port_bitmap_t __bitmap__;                                                          \
                                                                                               \
        UTIL_LIB_PORT_BMP_INV(__bitmap__, HAL_PORT_BMP((__unit__)));                           \
        UTIL_LIB_PORT_BMP_AND(__bitmap__, (__user_pbmp__));                                    \
                                                                                               \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                                              \
            UTIL_LOG_PRINT(UTIL_LOG_PORT, UTIL_LOG_WARN, "u=%u, invalid port bitmap, rc=%d\n", \
                           __unit__, CLX_E_BAD_PARAMETER);                                     \
            return CLX_E_BAD_PARAMETER;                                                        \
        }                                                                                      \
    } while (0)

#define CLX_PORT_CHECK_ETH_PORT_BITMAP(__unit__, __user_pbmp__)          \
    do {                                                                 \
        HAL_CHECK_UNIT(__unit__);                                        \
        clx_port_bitmap_t __bitmap__;                                    \
                                                                         \
        UTIL_LIB_PORT_BMP_INV(__bitmap__, HAL_PORT_BMP_ETH((__unit__))); \
        UTIL_LIB_PORT_BMP_AND(__bitmap__, (__user_pbmp__));              \
                                                                         \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                        \
            UTIL_LOG_PRINT(UTIL_LOG_PORT, UTIL_LOG_WARN,                 \
                           "u=%u, invalid eth port bitmap, "             \
                           "rc=%d\n",                                    \
                           __unit__, CLX_E_BAD_PARAMETER);               \
            return CLX_E_BAD_PARAMETER;                                  \
        }                                                                \
    } while (0)

#define CLX_PORT_CHECK_PP_PORT_BITMAP(__unit__, __user_pbmp__)          \
    do {                                                                \
        HAL_CHECK_UNIT(__unit__);                                       \
        clx_port_bitmap_t __bitmap__;                                   \
                                                                        \
        UTIL_LIB_PORT_BMP_INV(__bitmap__, HAL_PORT_BMP_PP((__unit__))); \
        UTIL_LIB_PORT_BMP_AND(__bitmap__, (__user_pbmp__));             \
                                                                        \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                       \
            UTIL_LOG_PRINT(UTIL_LOG_PORT, UTIL_LOG_WARN,                \
                           "u=%u, invalid pp port bitmap, "             \
                           "rc=%d\n",                                   \
                           __unit__, CLX_E_BAD_PARAMETER);              \
            return CLX_E_BAD_PARAMETER;                                 \
        }                                                               \
    } while (0)

#define CLX_PORT_CHECK_PHY_PORT_BITMAP(__unit__, __user_pbmp__)          \
    do {                                                                 \
        HAL_CHECK_UNIT(__unit__);                                        \
        clx_port_bitmap_t __bitmap__;                                    \
                                                                         \
        UTIL_LIB_PORT_BMP_INV(__bitmap__, HAL_PORT_BMP_PHY((__unit__))); \
        UTIL_LIB_PORT_BMP_AND(__bitmap__, (__user_pbmp__));              \
                                                                         \
        if (!CLX_PORT_BITMAP_EMPTY(__bitmap__)) {                        \
            UTIL_LOG_PRINT(UTIL_LOG_PORT, UTIL_LOG_WARN,                 \
                           "u=%u, invalid phy port bitmap, "             \
                           "rc=%d\n",                                    \
                           __unit__, CLX_E_BAD_PARAMETER);               \
            return CLX_E_BAD_PARAMETER;                                  \
        }                                                                \
    } while (0)

/* DATA TYPE DECLARATIONS
 */

/* Port Speed */
typedef enum {
    CLX_PORT_SPEED_1G = 1000,     /* Speed 1g */
    CLX_PORT_SPEED_10G = 10000,   /* Speed 10g */
    CLX_PORT_SPEED_25G = 25000,   /* Speed 25g */
    CLX_PORT_SPEED_40G = 40000,   /* Speed 40g */
    CLX_PORT_SPEED_50G = 50000,   /* Speed 50g */
    CLX_PORT_SPEED_100G = 100000, /* Speed 100g */
    CLX_PORT_SPEED_200G = 200000, /* Speed 200g */
    CLX_PORT_SPEED_400G = 400000, /* Speed 400g */
    CLX_PORT_SPEED_800G = 800000, /* Speed 800g */
    CLX_PORT_SPEED_LAST
} clx_port_speed_t;

typedef enum {
    CLX_PORT_LANE_SPEED_10P3125 = 0,
    CLX_PORT_LANE_SPEED_25P78125,
    CLX_PORT_LANE_SPEED_26P5625,
    CLX_PORT_LANE_SPEED_53P125_NRZ,
    CLX_PORT_LANE_SPEED_53P125_PAM4,
    CLX_PORT_LANE_SPEED_56P25_PAM4,
    CLX_PORT_LANE_SPEED_106P25,
    CLX_PORT_LANE_SPEED_112P5,
    CLX_PORT_LANE_SPEED_LAST
} clx_port_lane_speed_t;

/* Flow Control */
typedef enum clx_port_fc_dir_e {
    CLX_PORT_FC_DIR_OFF = 0, /* Both TX, RX disabled */
    CLX_PORT_FC_DIR_TXONLY,  /* Only TX enabled */
    CLX_PORT_FC_DIR_RXONLY,  /* Only RX enabled */
    CLX_PORT_FC_DIR_ON,      /* Both TX, RX enabled */
    CLX_PORT_FC_DIR_LAST
} clx_port_fc_dir_t;

/* EEE Mode */
typedef enum {
    CLX_PORT_EEE_MODE_DISABLE = 0, /* Disable eee mode */
    CLX_PORT_EEE_MODE_FASTWAKEUP,  /* Eee fast wake up */
    CLX_PORT_EEE_MODE_DEEPSLEEP,   /* Eee deep sleep */
    CLX_PORT_EEE_MODE_LAST,
} CLX_PORT_EEE_MODE_T;

/* Auto-negotiation Ability Bitmap for Port Speed */
typedef enum {
    CLX_PORT_ABILITY_SPEED_NULL = (0),
    CLX_PORT_ABILITY_SPEED_1000BASE_X = (1U << 0),    /* Auto-negotiation Ability 1000base&X */
    CLX_PORT_ABILITY_SPEED_10GBASE_KR = (1U << 1),    /* Auto-negotiation Ability 10GBASE_KR */
    CLX_PORT_ABILITY_SPEED_40GBASE_KR4 = (1U << 2),   /* Auto-negotiation Ability 40GBASE_CR4 */
    CLX_PORT_ABILITY_SPEED_40GBASE_CR4 = (1U << 3),   /* Auto-negotiation Ability 40GBASE_CR4 */
    CLX_PORT_ABILITY_SPEED_100GBASE_CR10 = (1U << 4), /* Auto-negotiation Ability 100GBASE_CR10 */
    CLX_PORT_ABILITY_SPEED_100GBASE_KR4 = (1U << 5),  /* Auto-negotiation Ability 100GBASE_KR4 */
    CLX_PORT_ABILITY_SPEED_100GBASE_CR4 = (1U << 6),  /* Auto-negotiation Ability 100GBASE_CR4 */
    /* Auto-negotiation Ability 25GBASE_KR_CR_S */
    CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR_S = (1U << 7),
    CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR = (1U << 8), /* Auto-negotiation Ability 25GBASE_KR_CR */
    CLX_PORT_ABILITY_SPEED_50GBASE_KR_CR = (1U << 9), /* Auto-negotiation Ability 50GBASE_KR_CR */
    /* Auto-negotiation Ability 100GBASE_KR2_CR2 */
    CLX_PORT_ABILITY_SPEED_100GBASE_KR2_CR2 = (1U << 10),
    /* Auto-negotiation Ability 200GBASE_KR4_CR4 */
    CLX_PORT_ABILITY_SPEED_200GBASE_KR4_CR4 = (1U << 11),
    /* Auto-negotiation Ability 400GBASE_CONSORTIUM */
    CLX_PORT_ABILITY_SPEED_400GBASE_CONSORTIUM = (1U << 12),
    /* Auto-negotiation Ability 100GBASE_KR_CR */
    CLX_PORT_ABILITY_SPEED_100GBASE_KR_CR = (1U << 13),
    /* Auto-negotiation Ability 200GBASE_KR2_CR2 */
    CLX_PORT_ABILITY_SPEED_200GBASE_KR2_CR2 = (1U << 14),
    /* Auto-negotiation Ability 400GBASE_KR4_CR4 */
    CLX_PORT_ABILITY_SPEED_400GBASE_KR4_CR4 = (1U << 15),
    /* Auto-negotiation Ability 800GBASE_KR8_CR8 */
    CLX_PORT_ABILITY_SPEED_800GBASE_KR8_CR8 = (1U << 16),
    CLX_PORT_ABILITY_SPEED_50GBASE_KR2_CONSORTIUM = (1U << 17), /* Auto-negotiation Ability
                                                                   50GBASE_KR2 */
    CLX_PORT_ABILITY_SPEED_50GBASE_CR2_CONSORTIUM = (1U << 18), /* Auto-negotiation Ability
                                                                   50GBASE_CR2 */
} clx_port_ability_speed_t;

/* Auto-negotiation Ability Bitmap for Flow Control */
typedef enum {
    CLX_PORT_ABILITY_PAUSE_NULL = (0),
    CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE = (1U << 0), /* Auto-negotiation Ability asymmetric pause */
    CLX_PORT_ABILITY_PAUSE_SYM_PAUSE = (1U << 1),  /* Auto-negotiation Ability symmetric pause */
} clx_port_ability_pause_t;

/* Auto-negotiation Ability Bitmap for EEE */
typedef enum {
    CLX_PORT_ABILITY_EEE_NULL = (0),
    CLX_PORT_ABILITY_EEE_10GBASE_KR = (1U << 0),    /* Auto-negotiation Ability 10GBASE_KR eee */
    CLX_PORT_ABILITY_EEE_40GBASE_KR4 = (1U << 1),   /* Auto-negotiation Ability 40GBASE_KR4 eee */
    CLX_PORT_ABILITY_EEE_40GBASE_CR4 = (1U << 2),   /* Auto-negotiation Ability 40GBASE_CR4 eee */
    CLX_PORT_ABILITY_EEE_100GBASE_CR10 = (1U << 3), /* Auto-negotiation Ability 100GBASE_CR10 eee */
    CLX_PORT_ABILITY_EEE_100GBASE_KR4 = (1U << 4),  /* Auto-negotiation Ability 100GBASE_KR4 eee */
    CLX_PORT_ABILITY_EEE_100GBASE_CR4 = (1U << 5),  /* Auto-negotiation Ability 100GBASE_CR4 eee */
    CLX_PORT_ABILITY_EEE_25GBASE_R = (1U << 6),     /* Auto-negotiation Ability 25GBASE_R eee */
} clx_port_ability_eee_t;

/* Auto-negotiation Ability Bitmap for Forward Error Correction */
typedef enum {
    CLX_PORT_ABILITY_FEC_NULL = (0),
    CLX_PORT_ABILITY_FEC_ABILITY = (1U << 0),    /* Auto-negotiation Ability fec ability */
    CLX_PORT_ABILITY_FEC_REQUEST = (1U << 1),    /* Auto-negotiation Ability fec request */
    CLX_PORT_ABILITY_FEC_RS_REQUEST = (1U << 2), /* Auto-negotiation Ability fec rs request */
    /* Auto-negotiation Ability fec base r request */
    CLX_PORT_ABILITY_FEC_BASE_R_REQUEST = (1U << 3),
    CLX_PORT_ABILITY_FEC_RS_INT_REQUEST = (1U << 4),
} clx_port_ability_fec_t;

/*  Auto-negotiation Ability Bitmap for Interface */
typedef enum {
    CLX_PORT_ABILITY_INTERFACE_GMII = (1U << 0),    /* Auto-negotiation Ability interface gmii */
    CLX_PORT_ABILITY_INTERFACE_XGMII = (1U << 1),   /* Auto-negotiation Ability interface xgmii */
    CLX_PORT_ABILITY_INTERFACE_XLGMII = (1U << 2),  /* Auto-negotiation Ability interface xlgmii */
    CLX_PORT_ABILITY_INTERFACE_CGMII = (1U << 3),   /* Auto-negotiation Ability interface cgmii */
    CLX_PORT_ABILITY_INTERFACE_25GMII = (1U << 4),  /* Auto-negotiation Ability interface 25gmii */
    CLX_PORT_ABILITY_INTERFACE_50GMII = (1U << 5),  /* Auto-negotiation Ability interface 50gmii */
    CLX_PORT_ABILITY_INTERFACE_200GMII = (1U << 6), /* Auto-negotiation Ability interface 200gmii */
    CLX_PORT_ABILITY_INTERFACE_400GMII = (1U << 7), /* Auto-negotiation Ability interface 400gmii */
    CLX_PORT_ABILITY_INTERFACE_800GMII = (1U << 8), /* Auto-negotiation Ability interface 800gmii */
    CLX_PORT_ABILITY_INTERFACE_LAST
} clx_port_ability_interface_t;

/*  Auto-negotiation Ability Bitmap for Medium */
typedef enum {
    CLX_PORT_ABILITY_MEDIUM_FIBER = (1U << 0),  /* Auto-negotiation Ability medium fiber */
    CLX_PORT_ABILITY_MEDIUM_COPPER = (1U << 1), /* Auto-negotiation Ability medium copper */
    CLX_PORT_ABILITY_MEDIUM_LAST
} clx_port_ability_medium_t;

/* Local Loopback Types */
typedef enum {
    CLX_PORT_LOOPBACK_DISABLE = 0,           /* Local Loopback disable */
    CLX_PORT_LOOPBACK_MAC,                   /* Local Loopback mac */
    CLX_PORT_LOOPBACK_PHY,                   /* Local Loopback phy */
    CLX_PORT_LOOPBACK_PHY_NEAR_END_PARALLEL, /* Local parallel loopback, pcs tx -> nep -> pcs rx */
    CLX_PORT_LOOPBACK_PHY_FAR_END_SERIAL,    /* Remote serial loopback, low-speed only support, link
                                                partner -> rx -> fes -> tx -> link partner */
    CLX_PORT_LOOPBACK_PHY_FAR_END_PARALLEL,  /* Remote parallel loopback external phy, link partner
                                                -> rx -> fep -> tx -> link partner */
    CLX_PORT_LOOPBACK_EXTERNAL_PHY,          /* Local Loopback external phy */
    CLX_PORT_LOOPBACK_LAST
} clx_port_loopback_t;

/* PHY Type */
typedef enum {
    CLX_PORT_PHY_LOCATION_INT = 0, /* Phy location int */
    CLX_PORT_PHY_LOCATION_EXT_SS,  /* Phy location ext ss */
    CLX_PORT_PHY_LOCATION_EXT_LS,  /* Phy location ext ls */
    CLX_PORT_PHY_LOCATION_LAST
} clx_port_phy_location_t;

/* Medium Type */
typedef enum clx_port_medium_e {
    CLX_PORT_MEDIUM_SGMII = 0, /* Medium type sgmii */
    CLX_PORT_MEDIUM_X,         /* Medium type 1000BASE_X */
    CLX_PORT_MEDIUM_CR,
    CLX_PORT_MEDIUM_KR,
    CLX_PORT_MEDIUM_SR,
    CLX_PORT_MEDIUM_LR,
    CLX_PORT_MEDIUM_ER,
    CLX_PORT_MEDIUM_CR2,
    CLX_PORT_MEDIUM_KR2,
    CLX_PORT_MEDIUM_SR2,
    CLX_PORT_MEDIUM_LR2,
    CLX_PORT_MEDIUM_ER2,
    CLX_PORT_MEDIUM_CR4,
    CLX_PORT_MEDIUM_KR4,
    CLX_PORT_MEDIUM_SR4,
    CLX_PORT_MEDIUM_LR4,
    CLX_PORT_MEDIUM_ER4,
    CLX_PORT_MEDIUM_CR8,
    CLX_PORT_MEDIUM_KR8,
    CLX_PORT_MEDIUM_SR8,
    CLX_PORT_MEDIUM_LR8,
    CLX_PORT_MEDIUM_ER8,
    CLX_PORT_MEDIUM_LAST
} clx_port_medium_t;

/* PHY Configuration */
typedef enum {
    CLX_PORT_PHY_PROPERTY_LANE_SWAP_TX = 0, /* PHY property type lane swap tx */
    CLX_PORT_PHY_PROPERTY_LANE_SWAP_RX,     /* PHY property type lane swap rx */
    CLX_PORT_PHY_PROPERTY_POL_REV_TX,       /* PHY property type tx polarity-reversal */
    CLX_PORT_PHY_PROPERTY_POL_REV_RX,       /* PHY property type rx polarity-reversal */
    CLX_PORT_PHY_PROPERTY_TX_COEF_CN1,      /* PHY property type cn1 tx coefficient */
    CLX_PORT_PHY_PROPERTY_TX_COEF_C0,       /* PHY property type c0 tx coefficient */
    CLX_PORT_PHY_PROPERTY_TX_COEF_C1,       /* PHY property type c1 tx coefficient */
    CLX_PORT_PHY_PROPERTY_TX_COEF_C2,       /* PHY property type c2 tx coefficient */
    CLX_PORT_PHY_PROPERTY_TX_COEF_CN2,      /* PHY property type cn2 tx coefficient */
    CLX_PORT_PHY_PROPERTY_TX_COEF_CN3,      /* PHY property type cn3 tx coefficient */
    CLX_PORT_PHY_PROPERTY_TX_COEF_C3,       /* PHY property type c3 tx coefficient */
    CLX_PORT_PHY_PROPERTY_CLK_ROUTE,        /* PHY property type ref clk route */
    CLX_PORT_PHY_PROPERTY_LAST
} clx_port_phy_property_t;

typedef struct clx_port_cfg_s {
    uint32 admin_status;
    uint32 autoneg_status;
    uint32 cut_through;
    uint32 unidir_link;
    uint32 tx_en;
    uint32 rx_en;
    uint32 rx_idle;
    uint32 mxlink_en;
    uint32 mxhdr_en;
    uint32 crc_replace;
    clx_sample_t igr_sample; /* Ingress sample */
    clx_sample_t egr_sample; /* Egress sample */
    uint32 fec;
    uint32 lane_cnt;
    uint32 medium_auto;
    uint32 time_stamp;
    uint32 trunc_mask;
    uint32 mib_max_len;
    uint32 synce_mode;
    uint32 ptp_step;
    uint32 ptp_mode;
    uint32 igr_mir_bmp;     /* Ingress mirror id bitmap  */
    uint32 egr_mir_bmp;     /* Egress mirror id bitmap */
    uint32 igr_meter_id;    /* Ingress meter ID */
    uint32 egr_meter_id;    /* Egress meter ID */
    uint32 igr_srv_cnt_id;  /* Ingress counter ID */
    uint32 egr_srv_cnt_id;  /* Egress counter ID */
    uint32 igr_dist_cnt_id; /* Ingress destribution counter ID */
    uint32 egr_dist_cnt_id; /* Egress destribution counter ID */
    uint32 telm_port_role;  /* telemetry INT role. Refer to CLX_TELM_INT_PORT_ROLE_XXX. */
    uint32 tx_signal;       /* phy tx signal. */
    uint32 ipg0b_en;
    uint32 ipg_len;
    uint32 layer1_len; /* layer1 length, unit: bytes, used for meter, storm control, mirror meter */
    uint32 origin_si;  /* port origin si */
    uint32 flags;      /* Refer to CLX_PORT_CFG_FLAGS_XXX */
    uint64 attr_bmp;   /* Refer to CLX_PORT_CFG_ATTR_XXX */
} clx_port_cfg_t;
#define CLX_PORT_CFG_FLAGS_IGR_VLAN_FILTER_EN (1ULL << 0) /* enable ingress vlan filter */
#define CLX_PORT_CFG_FLAGS_EGR_VLAN_FILTER_EN (1ULL << 1) /* enable egress vlan filter */
#define CLX_PORT_CFG_FLAGS_QINQ_MASK_CVLAN    (1ULL << 2) /* packet's CVLAN will be parsed to 0 */
#define CLX_PORT_CFG_FLAGS_IGR_METER_EN       (1ULL << 3) /* Ingress meter enable */
#define CLX_PORT_CFG_FLAGS_EGR_METER_EN       (1ULL << 4) /* Egress meter enable */
#define CLX_PORT_CFG_FLAGS_IGR_SRV_CNT_EN     (1ULL << 5) /* Ingress counter enable */
#define CLX_PORT_CFG_FLAGS_EGR_SRV_CNT_EN     (1ULL << 6) /* Egress counter enable */
#define CLX_PORT_CFG_FLAGS_IGR_DIST_CNT_EN    (1ULL << 7) /* Ingress distribution counter enable */
#define CLX_PORT_CFG_FLAGS_EGR_DIST_CNT_EN    (1ULL << 8) /* Egress distribution counter enable */
#define CLX_PORT_CFG_FLAGS_SPLIT_HORIZON      (1ULL << 9) /* enable split horizon. CL8600 only*/
#define CLX_PORT_CFG_FLAGS_TELM_FORCE_ON_EN \
    (1ULL << 10) /* telemetry per-port globally turn on without ACL reconfig */
#define CLX_PORT_CFG_FLAGS_TELM_IOAM_DCI_EN  (1ULL << 11) /* telemetry ioam dci enable */
#define CLX_PORT_CFG_FLAGS_TS_REPLACE_MAC_EN (1ULL << 12) /* timestamp replace mac enable */
#define CLX_PORT_CFG_FLAGS_IGR_TS_REPLACE_SRC_MAC_EN \
    (1ULL << 13)                                          /* timestamp replace src mac enable */
#define CLX_PORT_CFG_FLAGS_EGR_TS_REPLACE_DST_MAC_EN \
    (1ULL << 14)                                          /* timestamp replace dst mac enable */
#define CLX_PORT_CFG_FLAGS_RX_EN     (1ULL << 15)         /* config rx enable */
#define CLX_PORT_CFG_FLAGS_TX_EN     (1ULL << 16)         /* config tx enable */
#define CLX_PORT_CFG_FLAGS_MXLINK_EN (1ULL << 17)         /* config mx-link enable */
#define CLX_PORT_CFG_FLAGS_MXHDR_EN  (1ULL << 18)         /* config mx-header enable */
#define CLX_PORT_CFG_FLAGS_EGR_HIGH_LATENCY_EXC_EN \
    (1ULL << 21) /* Port config type high latency exception enable */

#define CLX_PORT_CFG_ATTR_ALL             (0xFFFFFFFFFFFFFFFF) /* Set all physical port config attrs */
#define CLX_PORT_CFG_ATTR_IGR_VLAN_FILTER (1ULL << 0)
/* ingress vlan filtering attr igr_vlan_filter */
#define CLX_PORT_CFG_ATTR_EGR_VLAN_FILTER (1ULL << 1)
/* egress vlan filtering attr egr_vlan_filter */
#define CLX_PORT_CFG_ATTR_QINQ_MASK_CVLAN (1ULL << 2) /* qinq mask cvlan attr qinq_mask_cvlan */
#define CLX_PORT_CFG_ATTR_IGR_SAMPLE      (1ULL << 3) /* Ingress sample attr igr_sample */
#define CLX_PORT_CFG_ATTR_EGR_SAMPLE      (1ULL << 4) /* Egress sample attr egr_sample */
#define CLX_PORT_CFG_ATTR_IGR_MIR         (1ULL << 5) /* Ingress mirror attr igr_mir_bmp */
#define CLX_PORT_CFG_ATTR_EGR_MIR         (1ULL << 6) /* Egress mirror attr egr_mir_bmp */
#define CLX_PORT_CFG_ATTR_IGR_METER       (1ULL << 7) /* Ingress Meter attr igr_meter_id */
#define CLX_PORT_CFG_ATTR_EGR_METER       (1ULL << 8) /* Egress Meter attr egr_meter_id */
/* Ingress service counter attr igr_srv_cnt_en,igr_srv_cnt_id */
#define CLX_PORT_CFG_ATTR_IGR_SRV_CNT (1ULL << 9)
/* Egress service counter attr igr_srv_cnt_en,egr_srv_cnt_id */
#define CLX_PORT_CFG_ATTR_EGR_SRV_CNT (1ULL << 10)
/* Ingress destination counter attr egr_dist_cnt_en,igr_dist_cnt_id */
#define CLX_PORT_CFG_ATTR_IGR_DIST_CNT (1ULL << 11)
/* Egress destination counter attr egr_dist_cnt_en,egr_dist_cnt_id */
#define CLX_PORT_CFG_ATTR_EGR_DIST_CNT   (1ULL << 12)
#define CLX_PORT_CFG_ATTR_SPLIT_HORIZON  (1ULL << 13) /* attr split_horizon */
#define CLX_PORT_CFG_ATTR_TELM_PORT_ROLE (1ULL << 14) /* telemetry FP port role */
#define CLX_PORT_CFG_ATTR_TELM_FORCE_ON \
    (1ULL << 15) /* telemetry per-port globally turn on without ACL reconfig */
#define CLX_PORT_CFG_ATTR_TELM_IOAM_DCI (1ULL << 16) /* telemetry ioam dci enable */

#define CLX_PORT_CFG_ATTR_ADMIN_STATE             (1ULL << 17)
#define CLX_PORT_CFG_ATTR_AUTONEG_STATUS          (1ULL << 18)
#define CLX_PORT_CFG_ATTR_FEC                     (1ULL << 19)
#define CLX_PORT_CFG_ATTR_LANE_CNT                (1ULL << 20)
#define CLX_PORT_CFG_ATTR_CUT_THROUGH             (1ULL << 21)
#define CLX_PORT_CFG_ATTR_UNIDIRECT_LINK          (1ULL << 22)
#define CLX_PORT_CFG_ATTR_TX_EN                   (1ULL << 23)
#define CLX_PORT_CFG_ATTR_RX_EN                   (1ULL << 24)
#define CLX_PORT_CFG_ATTR_MXLINK_EN               (1ULL << 25)
#define CLX_PORT_CFG_ATTR_MIB_MAX_LEN             (1ULL << 26)
#define CLX_PORT_CFG_ATTR_TRUNC_MASK              (1ULL << 27)
#define CLX_PORT_CFG_ATTR_SYNCE_MODE              (1ULL << 28)
#define CLX_PORT_CFG_ATTR_MXHDR_EN                (1ULL << 29)
#define CLX_PORT_CFG_ATTR_1G_MEDIUM_AUTO          (1ULL << 30)
#define CLX_PORT_CFG_ATTR_CRC_REPLACE             (1ULL << 31)
#define CLX_PORT_CFG_ATTR_TS_EN                   (1ULL << 32)
#define CLX_PORT_CFG_ATTR_TS_INSERT_EOF_IGR       (1ULL << 33)
#define CLX_PORT_CFG_ATTR_TS_INSERT_EOF_EGR       (1ULL << 34)
#define CLX_PORT_CFG_ATTR_TS_REPLACE_MAC          (1ULL << 35)
#define CLX_PORT_CFG_ATTR_IGR_TS_REPLACE_SRC_MAC  (1ULL << 36)
#define CLX_PORT_CFG_ATTR_EGR_TS_REPLACE_DST_MAC  (1ULL << 37)
#define CLX_PORT_CFG_ATTR_EGR_HIGH_LATENCY_EXC_EN (1ULL << 38)
#define CLX_PORT_CFG_ATTR_PTP_MODE                (1ULL << 39)
#define CLX_PORT_CFG_ATTR_TX_SIGNAL               (1ULL << 40)
#define CLX_PORT_CFG_ATTR_TX_IPG                  (1ULL << 41)
#define CLX_PORT_CFG_ATTR_LAYER1_LEN              (1ULL << 42)
#define CLX_PORT_CFG_ATTR_ORIGIN_SI               (1ULL << 43)
#define CLX_PORT_CFG_ATTR_RX_IDLE                 (1ULL << 44)

typedef struct clx_port_flow_control_s {
    uint32 fc_mode; /* pfc or pause */
    uint32 pri;
    clx_port_fc_dir_t dir;
} clx_port_flow_control_t;
#define CLX_PORT_FLOW_CONTROL_PAUSE   1
#define CLX_PORT_FLOW_CONTROL_PFC     2
#define CLX_PORT_FLOW_CONTROL_DISABLE 3

/* Prbs pattern */
typedef enum {
    CLX_PORT_PRBS_PATTERN_DISABLE = 0x0, /* Prbs pattern disable */
    CLX_PORT_PRBS_PATTERN_9,             /* Prbs pattern 9 */
    CLX_PORT_PRBS_PATTERN_13,            /* Prbs pattern 13 */
    CLX_PORT_PRBS_PATTERN_31,            /* Prbs pattern 31 */
    CLX_PORT_PRBS_PATTERN_SQUARE,        /* Prbs pattern square */
    CLX_PORT_PRBS_PATTERN_LAST
} clx_port_prbs_pattern_t;

typedef enum {
    CLX_PORT_ACC_HI_Z = 0,
    CLX_PORT_ACC_TERM_VSS_AC = 1, /**< termination to vss, onchip AC coupling */
    CLX_PORT_ACC_TERM_FL_AC = 2,  /**< floating termination, onchip AC coupling */
    // RES1 = 3, // Reserved
    // RES2 = 4, // Reserved
    CLX_PORT_ACC_TERM_VSS_DC = 5, /**< termination to vss, DC coupled */
    CLX_PORT_ACC_TERM_FL_DC = 6,  /**< floating termination to vss, DC coupled */
    // RES3 = 7, // Reserved
} clx_port_acc_term_mode_t;

typedef enum {
    CLX_PORT_ATEST_MODE_ADC = 0,
    CLX_PORT_ATEST_MODE_PMON,
    CLX_PORT_ATEST_MODE_LAST,
} clx_port_atest_mode_t;

/* Fec cnt type */
typedef enum {
    CLX_PORT_FEC_CNT_TYPE_CERR = 0x0, /* Fec count type corrected err */
    CLX_PORT_FEC_CNT_TYPE_UCERR,      /* Fec count type uncorrected err */
    CLX_PORT_FEC_CNT_TYPE_SERR,       /* Fec count type symbol err */
    CLX_PORT_FEC_CNT_TYPE_LAST
} clx_port_fec_cnt_type_t;

/* Eye scan */
typedef enum {
    CLX_PORT_EYE_SCAN_DIAGRAM = 0x0, /* Eye scan diagram */
    CLX_PORT_EYE_SCAN_BER,           /* Eye scan ber */
    CLX_PORT_EYE_SCAN_LAST
} clx_port_eye_scan_t;

/* Synce mode */
typedef enum {
    CLX_PORT_SYNCE_MODE_DISABLE = 0x0, /* Synce mode disable */
    CLX_PORT_SYNCE_MODE_0,             /* Synce mode 0 */
    CLX_PORT_SYNCE_MODE_1,             /* Synce mode 1 */
    CLX_PORT_SYNCE_MODE_LAST

} clx_port_synce_mode_t;

/* clx_port_bitmap_t is the data type for physical port bitmap. */
typedef uint32 clx_port_bitmap_t[CLX_PORT_BITMAP_SIZE];

/* Vlan tag */
typedef enum clx_port_vlan_tag_mode_e {
    CLX_PORT_VLAN_TAG_MODE_8021Q,  /* vlan tag mode 802.1q */
    CLX_PORT_VLAN_TAG_MODE_8021AD, /* vlan tag mode 802.1ad */
    CLX_PORT_VLAN_TAG_MODE_EXT,    /* Extended 24-bit vlan tag mode */
    CLX_PORT_VLAN_TAG_MODE_LAST
} clx_port_vlan_tag_mode_t;
typedef enum clx_port_vlan_keep_src_tag_e {
    CLX_PORT_VLAN_KEEP_SRC_TAG_NONE, /* Do not keep source packet VLAN tag */
    CLX_PORT_VLAN_KEEP_SRC_TAG_CTAG, /* Keep customer VLAN tag of the source packet */
    CLX_PORT_VLAN_KEEP_SRC_TAG_STAG, /* Keep sercie VLAN tag of the source packet */
    CLX_PORT_VLAN_KEEP_SRC_TAG_ALL,  /* Keep both service and customer VLAN tag of the source packet
                                      */
    CLX_PORT_VLAN_KEEP_SRC_TAG_LAST
} clx_port_vlan_keep_src_tag_t;

typedef enum {
    CLX_PORT_MBURST_CALA_SELECT_CNT_BYTE,
    CLX_PORT_MBURST_CALA_SELECT_CNT_PKT,
    CLX_PORT_MBURST_CALA_SELECT_CNT_MATCH_BYTE,
    CLX_PORT_MBURST_CALA_SELECT_CNT_MATCH_PKT,
    CLX_PORT_MBURST_CALA_SELECT_CNT_LAST
} clx_port_mburst_cala_select_cnt_t;

typedef struct clx_port_fec_cnt_s {
    uint64 fec_cerr_codeword;
    uint64 fec_cerr_sym_err[16];
    uint64 fec_ucerr_codeword;
    uint64 fec_ch_sym_err;

#define CLX_PORT_FEC_TYPE_COUNTERED_CODEWORDS            (1U << 0)
#define CLX_PORT_FEC_TYPE_COUNTERED_SYMBOL_ERROR_COUNTER (1U << 1)
#define CLX_PORT_FEC_TYPE_UNCOTTECTED_CODEWORDS          (1U << 2)
#define CLX_PORT_FEC_TYPE_CH_SYMBOL_ERROR_COUNTER        (1U << 3)
    uint32 fec_type_bmp;
} clx_port_fec_cnt_t;

typedef struct clx_port_mburst_cfg_s {
    clx_dir_t mburst_direction;                          /* mburst direction */
    uint32 mburst_window;                                /* mburst window */
    uint32 mburst_weight;                                /* mburst weight */
    uint32 mburst_calc_select;                           /* mburst calculate select */
    uint32 mburst_calc_add_cxheader;                     /* mburst calculate rate add cxheader */
    uint32 mburst_patt_data[CLX_PORT_MBURST_PATT_LENTH]; /* mburst pattern match */
    uint32 mburst_patt_mask[CLX_PORT_MBURST_PATT_LENTH]; /* mburst pattern mask */
    uint32 mburst_histogram_admin;                       /* mburst histogram admin */
    uint32 mburst_histogram_max_value;                   /* mburst histogram max_hit_cnt value */
    uint32 mburst_histogram_num;                         /* mburst histogram num */
    uint32 mburst_histogram_threshold[CLX_PORT_MBURST_HIST_THRESHOLD_NUM]; /* mburst histogram
                                                                              threshold */

#define CLX_PORT_MBURST_PROPERTY_MONITOR           (1U << 0)
#define CLX_PORT_MBURST_PROPERTY_WINDOW            (1U << 1)
#define CLX_PORT_MBURST_PROPERTY_WEIGHT            (1U << 2)
#define CLX_PORT_MBURST_PROPERTY_CALC_SELECT       (1U << 3)
#define CLX_PORT_MBURST_PROPERTY_CALC_ADD_CXHEADER (1U << 4)
#define CLX_PORT_MBURST_PROPERTY_PATTERN           (1U << 5)
#define CLX_PORT_MBURST_PROPERTY_HIST_ADMIN        (1U << 6)
#define CLX_PORT_MBURST_PROPERTY_HIST_MAX_VALUE    (1U << 7)
#define CLX_PORT_MBURST_PROPERTY_HIST_THRD         (1U << 8)
#define CLX_PORT_MBURST_PROPERTY_ATTR_ALL          (0xFFFFFFFFU)
    uint32 attr_bmp; /* Mark which fields to set */
} clx_port_mburst_cfg_t;

typedef struct clx_port_mburst_stat_s {
    uint32 mburst_is_enabled; /* mburst enable flag */
    uint32 mburst_count;      /* mburst count */
    uint32 mburst_i_rate;     /* mburst instant rate */
    uint32 mburst_m_rate;     /* mburst max rate */
    uint32 mburst_m_rate_ts;  /* mburst max rate timestamp */
    uint32 mburst_a_rate;     /* mburst averge rate */
} clx_port_mburst_stat_t;

typedef struct clx_port_xoff_status_s {
    boolean ipl_fast_tm_pfc;
    uint32 bac2ipl_xoff_cnt;
    uint32 asm2ipl_unirdy_cnt;
    uint32 ipl2umac_xoff_status;
    uint32 epl_xoff_status; // xoff status of eth_port. every eth port has 3 queue in EPL.
} clx_port_xoff_status_t;

typedef struct clx_port_vlan_tag_ctrl_s {
    clx_port_vlan_keep_src_tag_t keep_src_vlan;          /* Keep source VLAN */
    clx_vlan_t svid;                                     /* Service VLAN ID */
    clx_vlan_t cvid;                                     /* Customer VLAN ID */
    uint32 flags;
} clx_port_vlan_tag_ctrl_t;                              /* Support on CL8600 */
#define CLX_PORT_VLAN_TAG_CTRL_FLAGS_ADD_SVLAN (1U << 0) /* Add Service VLAN */
#define CLX_PORT_VLAN_TAG_CTRL_FLAGS_ADD_CVLAN (1U << 1) /* Add Customer VLAN */
#define CLX_PORT_VLAN_TAG_CTRL_FLAGS_ADD_ENTRY (1U << 2) /* Add entry when not exist */
#define CLX_PORT_VLAN_TAG_CTRL_FLAGS_DEL_ENTRY (1U << 3) /* Del entry when added for not exist */

/* Port ability */
typedef struct clx_port_ability_s {
    clx_port_ability_speed_t speed; /* Auto-negotiation Ability Bitmap for Port Speed */
    clx_port_ability_pause_t pause; /* Auto-negotiation Ability Bitmap for Flow Control */
    clx_port_ability_fec_t fec; /* Auto-negotiation Ability Bitmap for Forward Error Correction */
    clx_port_ability_eee_t eee; /* Auto-negotiation Ability Bitmap for EEE */
    clx_port_ability_interface_t interface; /* Auto-negotiation Ability Bitmap for Interface */
    clx_port_ability_medium_t medium;       /* Auto-negotiation Ability Bitmap for Medium */
#define CLX_PORT_ABILITY_FLAGS_AUTONEG (1U << 0)
    uint32 flags;
} clx_port_ability_t;

/* VLAN Tag Mode */
typedef enum clx_port_acpt_frm_type_e {
    CLX_PORT_ACPT_FRM_TYPE_ALL,      /* accept tagged and untagged frames */
    CLX_PORT_ACPT_FRM_TYPE_NONE,     /* not accept tagged and untagged frames */
    CLX_PORT_ACPT_FRM_TYPE_TAGGED,   /* accept tagged frames */
    CLX_PORT_ACPT_FRM_TYPE_UNTAGGED, /* accept untagged frames */
    CLX_PORT_ACPT_FRM_TYPE_DFLT_VID, /* accept unatgged or tagged frames with default vid */
    CLX_PORT_ACPT_FRM_TYPE_LAST
} clx_port_acpt_frm_type_t;

/* Interface property */
#define CLX_PORT_INTF_TPID_MAX_NUM (8)
/* Interface config */
typedef struct clx_port_intf_cfg_s {
    clx_port_acpt_frm_type_t acpt_frm_type; /* acceptable frame type */
    clx_port_vlan_tag_mode_t vlan_tag_mode; /* VLAN tag mode */
    clx_vlan_tpid_t igr_tpid[CLX_PORT_INTF_TPID_MAX_NUM];
    clx_vlan_tpid_t egr_tpid;
    uint8 dflt_pcp;                /* Default pcp */
    uint8 dflt_dei;                /* Default dei */
    uint32 dflt_vlan;              /* Default vid */
    clx_sa_miss_rsn_t sa_miss_rsn; /* SA MAC miss reason */
    uint32 igr_mtu;                /* Ingress MTU */
    uint32 egr_mtu;                /* Egress MTU, CL8600 only */
    clx_sample_t igr_sample;       /* Ingress sample */
    clx_sample_t egr_sample;       /* Egress sample */
    uint32 igr_mir_bmp;            /* Ingress mirror id bitmap  */
    uint32 egr_mir_bmp;            /* Egress mirror id bitmap */
    uint32 igr_meter_id;           /* Ingress meter ID */
    uint32 egr_meter_id;           /* Egress meter ID */
    uint32 igr_srv_cnt_id;         /* Ingress counter ID */
    uint32 egr_srv_cnt_id;         /* Egress counter ID */
    uint32 igr_dist_cnt_id;        /* Ingress destination counter ID */
    uint32 egr_dist_cnt_id;        /* Egress destination counter ID */
    uint32 igr_grp_lbl;            /* interface group label, set 0 to clear */
    uint32 egr_grp_lbl;            /* interface group label, set 0 to clear */
    clx_qos_prof_t igr_qos;        /* Ingress qos */
    clx_qos_prof_t egr_qos;        /* Egress qos */
    uint32 flags;
    uint64 attr_bmp;               /* Refer to CLX_PORT_INTF_CFG_ATTR_FLAG_XXX */
} clx_port_intf_cfg_t;
/* enable interface mac learning, CL8600 only */
#define CLX_PORT_INTF_CFG_FLAGS_MAC_LEARN    (1ULL << 0)
#define CLX_PORT_INTF_CFG_FLAGS_ACPT_PRI_FRM (1ULL << 1) /* accept priority frame, CL8600 only  */
/* keep all VLAN attr keep_all_vlan, CL8600 only */
#define CLX_PORT_INTF_CFG_FLAGS_KEEP_ALL_VLAN (1ULL << 2) /* CL8600 only */
#define CLX_PORT_INTF_CFG_FLAGS_TRUST_PCP_DEI (1ULL << 3) /* Trust 802.1p */
#define CLX_PORT_INTF_CFG_FLAGS_TRUST_VLAN    (1ULL << 4) /* Trust VLAN */
/* If packet is C-TAGGED only, use default vlan to forward, CL8600 only */
#define CLX_PORT_INTF_CFG_FLAGS_CTAG_USE_DFLT_VLAN (1ULL << 5)
#define CLX_PORT_INTF_CFG_FLAGS_IGR_METER_EN       (1ULL << 6) /* Ingress meter ID enable */
#define CLX_PORT_INTF_CFG_FLAGS_EGR_METER_EN       (1ULL << 7) /* Egress meter ID enable */
#define CLX_PORT_INTF_CFG_FLAGS_IGR_SRV_CNT_EN     (1ULL << 8) /* Ingress counter ID enable */
#define CLX_PORT_INTF_CFG_FLAGS_EGR_SRV_CNT_EN     (1ULL << 9) /* Egress counter ID enable */
/* Ingress distribution counter ID enable */
#define CLX_PORT_INTF_CFG_FLAGS_IGR_DIST_CNT_EN (1ULL << 10)
/* Egress distribution counter ID enable */
#define CLX_PORT_INTF_CFG_FLAGS_EGR_DIST_CNT_EN   (1ULL << 11)
#define CLX_PORT_INTF_CFG_FLAGS_QOS_DO_NOT_MODIFY (1ULL << 12) /* Qos not modify, CL8600 only */
/* enable ECN service. false: disable ECN marking capabilities on all frames from the local
 * interface */
#define CLX_PORT_INTF_CFG_FLAGS_ECN_EN (1ULL << 13)

#define CLX_PORT_INTF_CFG_ATTR_ALL (0xFFFFFFFFFFFFFFFF) /* Set all interface config attrs */
/* mac learning attr CLX_PORT_INTF_CFG_FLAGS_MAC_LEARN */
#define CLX_PORT_INTF_CFG_ATTR_MAC_LEARN (1ULL << 0)
/* acceptable frame type attr acpt_frm_type */
#define CLX_PORT_INTF_CFG_ATTR_ACPT_FRM_TYPE (1ULL << 1)
/* accept priority frame attr CLX_PORT_INTF_CFG_FLAGS_ACPT_PRI_FRM */
#define CLX_PORT_INTF_CFG_ATTR_ACPT_PRI_FRM (1ULL << 2)
/* keep all VLAN attr CLX_PORT_INTF_CFG_FLAGS_KEEP_ALL_VLAN */
#define CLX_PORT_INTF_CFG_ATTR_KEEP_ALL_VLAN (1ULL << 3)
#define CLX_PORT_INTF_CFG_ATTR_VLAN_TAG_MODE (1ULL << 4) /* VLAN tag mode attr vlan_tag_mode */
/* ingress VLAN tpid attr igr_tpid[CLX_PORT_INTF_TPID_MAX_NUM] */
#define CLX_PORT_INTF_CFG_ATTR_IGR_VLAN_TPID (1ULL << 5)
/* egress VLAN tpid attr egr_tpid */
#define CLX_PORT_INTF_CFG_ATTR_EGR_VLAN_TPID (1ULL << 6)
#define CLX_PORT_INTF_CFG_ATTR_DFLT_PCP      (1ULL << 7) /* Default pcp attr dflt_pcp */
#define CLX_PORT_INTF_CFG_ATTR_DFLT_DEI      (1ULL << 8) /* Default dei attr dflt_dei */
#define CLX_PORT_INTF_CFG_ATTR_DFLT_VLAN     (1ULL << 9) /* Default vid attr dflt_vlan */
/* Trust 802.1p attr CLX_PORT_INTF_CFG_FLAGS_TRUST_PCP_DEI */
#define CLX_PORT_INTF_CFG_ATTR_TRUST_PCP_DEI (1ULL << 10)
/* Trust VLAN attr CLX_PORT_INTF_CFG_FLAGS_TRUST_VLAN */
#define CLX_PORT_INTF_CFG_ATTR_TRUST_VLAN (1ULL << 11)
/* C-TAG packet use default VLAN attr CLX_PORT_INTF_CFG_FLAGS_CTAG_USE_DFLT_VLAN */
#define CLX_PORT_INTF_CFG_ATTR_CTAG_USE_DFLT_VLAN (1ULL << 12)
/* Source mac miss reasion attr sa_miss_rsn */
#define CLX_PORT_INTF_CFG_ATTR_SA_MISS_RSN (1ULL << 13)
#define CLX_PORT_INTF_CFG_ATTR_IGR_MTU     (1ULL << 14) /* Ingress MTU attr igr_mtu */
#define CLX_PORT_INTF_CFG_ATTR_EGR_MTU     (1ULL << 15) /* Egress MTU attr egr_mtu */
#define CLX_PORT_INTF_CFG_ATTR_IGR_SAMPLE  (1ULL << 16) /* Ingress sample attr igr_sample */
#define CLX_PORT_INTF_CFG_ATTR_EGR_SAMPLE  (1ULL << 17) /* Egress sample attr egr_sample */
#define CLX_PORT_INTF_CFG_ATTR_IGR_MIR     (1ULL << 18) /* Ingress mirror attr igr_mir_bitmap */
#define CLX_PORT_INTF_CFG_ATTR_EGR_MIR     (1ULL << 19) /* Egress mirror attr egr_mir_bitmap */
/* Ingress Meter attr igr_meter_id,CLX_PORT_INTF_CFG_FLAGS_IGR_METER_EN */
#define CLX_PORT_INTF_CFG_ATTR_IGR_METER (1ULL << 20)
/* Egress Meter attr egr_meter_id,CLX_PORT_INTF_CFG_FLAGS_EGR_METER_EN */
#define CLX_PORT_INTF_CFG_ATTR_EGR_METER (1ULL << 21)
/* Ingress service counter attr igr_srv_cnt_id,CLX_PORT_INTF_CFG_FLAGS_IGR_SRV_CNT_EN */
#define CLX_PORT_INTF_CFG_ATTR_IGR_SRV_CNT (1ULL << 22)
/* Egress service counter attr egr_srv_cnt_id,CLX_PORT_INTF_CFG_FLAGS_EGR_SRV_CNT_EN */
#define CLX_PORT_INTF_CFG_ATTR_EGR_SRV_CNT (1ULL << 23)
/* Ingress distribution counter attr igr_dist_cnt_id,CLX_PORT_INTF_CFG_FLAGS_IGR_DIST_CNT_EN */
#define CLX_PORT_INTF_CFG_ATTR_IGR_DIST_CNT (1ULL << 24)
/* Egress distribution counter attr egr_dist_cnt_id,CLX_PORT_INTF_CFG_FLAGS_EGR_DIST_CNT_EN */
#define CLX_PORT_INTF_CFG_ATTR_EGR_DIST_CNT (1ULL << 25)
#define CLX_PORT_INTF_CFG_ATTR_IGR_GRP_LBL  (1ULL << 26) /* Ingress group label attr igr_grp_lbl */
#define CLX_PORT_INTF_CFG_ATTR_EGR_GRP_LBL  (1ULL << 27) /* Egress group label attr egr_grp_lbl */
#define CLX_PORT_INTF_CFG_ATTR_IGR_QOS      (1ULL << 28) /* Ingress QOS attr igr_qos */
#define CLX_PORT_INTF_CFG_ATTR_EGR_QOS      (1ULL << 29) /* Egress QOS attr egr_qos */
/* QOS do not modify attr CLX_PORT_INTF_CFG_FLAGS_QOS_DO_NOT_MODIFY */
#define CLX_PORT_INTF_CFG_ATTR_QOS_DO_NOT_MODIFY (1ULL << 30)
/* ECN enable attr CLX_PORT_INTF_CFG_FLAGS_ECN_EN */
#define CLX_PORT_INTF_CFG_ATTR_ECN_EN (1ULL << 31)

/* Prbs config */
typedef enum {
    /** PRBS Disable */
    CLX_PORT_PRBS_CONFIG_DISABLE = 0,
    /** Enable both PRBS Transmitter and Receiver */
    CLX_PORT_PRBS_CONFIG_ENABLE_TX_RX,
    /** Enable PRBS Receiver */
    CLX_PORT_PRBS_CONFIG_ENABLE_RX,
    /** Enable PRBS Transmitter */
    CLX_PORT_PRBS_CONFIG_ENABLE_TX,
    CLX_PORT_PRBS_LAST
} clx_port_prbs_config_t;

/* Ts entry */
typedef struct clx_port_ts_entry_s {
    uint16 seq_num; /* sequence number */
    uint16 sec_hi;  /* Bit[47:32] seconds for timestamp */
    uint32 sec_low; /* Bit[31:0]  seconds for timestamp */
    uint32 nsec;    /* nano seconds for timestamp */
} clx_port_ts_entry_t;

/* Port status */
typedef struct clx_port_status_s {
    clx_port_speed_t speed; /* port speed */
    uint32 link;            /* port link status */
    uint32 fault;           /* port fault status */
    uint32 rx_fc;           /* rx flow control */
    uint32 rx_pfc;          /* rx prority flow control */
} clx_port_status_t;

/* Tx coef flags */
typedef struct clx_port_tx_coef_s {
#define CLX_PORT_TX_COEF_FLAGS_CN1 (1U << 0) /* Tx coefficient */
#define CLX_PORT_TX_COEF_FLAGS_CN2 (1U << 1) /* Tx coefficient */
#define CLX_PORT_TX_COEF_FLAGS_CN3 (1U << 2) /* Tx coefficient */
#define CLX_PORT_TX_COEF_FLAGS_C0  (1U << 3) /* Tx coefficient */
#define CLX_PORT_TX_COEF_FLAGS_C1  (1U << 4) /* Tx coefficient */
#define CLX_PORT_TX_COEF_FLAGS_C2  (1U << 5) /* Tx coefficient */
#define CLX_PORT_TX_COEF_FLAGS_C3  (1U << 6) /* Tx coefficient */
    uint32 flags;
    uint32 cn3;
    uint32 cn2;
    uint32 cn1;
    uint32 c0;
    uint32 c1;
    uint32 c2;
    uint32 c3;
} clx_port_tx_coef_t;

typedef struct clx_port_phy_cfg_s {
    uint32 lane_swap_tx[DSH_MAX_HEX_NUM];
    uint32 lane_swap_rx[DSH_MAX_HEX_NUM];
    uint32 pol_rev_tx[DSH_MAX_HEX_NUM];
    uint32 pol_rev_rx[DSH_MAX_HEX_NUM];
    uint32 tx_coef_cn3[DSH_MAX_HEX_NUM];
    uint32 tx_coef_cn2[DSH_MAX_HEX_NUM];
    uint32 tx_coef_cn1[DSH_MAX_HEX_NUM];
    uint32 tx_coef_c0[DSH_MAX_HEX_NUM];
    uint32 tx_coef_c1[DSH_MAX_HEX_NUM];
    uint32 tx_coef_c2[DSH_MAX_HEX_NUM];
    uint32 tx_coef_c3[DSH_MAX_HEX_NUM];
    clx_port_phy_location_t location;
    uint32 lane_cnt;
    uint32 prbs_err_cnt;
    uint32 lane_bmp;
    uint32 tunning_step;
    uint32 isola_mode;
    uint32 lane_speed;
    uint32 eth_ver;
    uint32 cpi_ver;
    uint32 tx_elecidle;
    uint32 atest_mode;
    uint32 snr_int[DSH_MAX_HEX_NUM];
    uint32 snr_dec[DSH_MAX_HEX_NUM];
    uint32 lane_idle[DSH_MAX_HEX_NUM];
    uint32 term_mode;
    uint64 attr_bmp; /* Refer to CLX_PORT_PHY_PORT_ATTR_XXX */
} clx_port_phy_cfg_t;
#define CLX_PORT_PHY_ATTR_LANE_SWAP_TX     (1ULL << 0)
#define CLX_PORT_PHY_ATTR_LANE_SWAP_RX     (1ULL << 1)
#define CLX_PORT_PHY_ATTR_POL_REV_TX       (1ULL << 2)
#define CLX_PORT_PHY_ATTR_POL_REV_RX       (1ULL << 3)
#define CLX_PORT_PHY_ATTR_TX_COEF_CN1      (1ULL << 4)
#define CLX_PORT_PHY_ATTR_TX_COEF_CN2      (1ULL << 5)
#define CLX_PORT_PHY_ATTR_TX_COEF_CN3      (1ULL << 6)
#define CLX_PORT_PHY_ATTR_TX_COEF_C0       (1ULL << 7)
#define CLX_PORT_PHY_ATTR_TX_COEF_C1       (1ULL << 8)
#define CLX_PORT_PHY_ATTR_TX_COEF_C2       (1ULL << 9)
#define CLX_PORT_PHY_ATTR_TX_COEF_C3       (1ULL << 10)
#define CLX_PORT_PHY_ATTR_CLK_ROUTE        (1ULL << 11)
#define CLX_PORT_PHY_ATTR_FW_VERSION       (1ULL << 12)
#define CLX_PORT_PHY_ATTR_RXEQ_AUTOTUNNING (1ULL << 13)
#define CLX_PORT_PHY_ATTR_RATE             (1ULL << 14)
#define CLX_PORT_PHY_ATTR_PRBS_ERRINJECT   (1ULL << 15)
#define CLX_PORT_PHY_ATTR_PRBS_ERRCLEAR    (1ULL << 16)
#define CLX_PORT_PHY_ATTR_ISOLA_MODE       (1ULL << 17)
#define CLX_PORT_PHY_ATTR_TX_POWERUP       (1ULL << 18)
#define CLX_PORT_PHY_ATTR_RX_POWERUP       (1ULL << 19)
#define CLX_PORT_PHY_ATTR_TX_ELECIDLE      (1ULL << 20)
#define CLX_PORT_PHY_ATTR_RX_TERMINATION   (1ULL << 21)
#define CLX_PORT_PHY_ATTR_ATEST_PMON       (1ULL << 22)
#define CLX_PORT_PHY_ATTR_RX_SNR           (1ULL << 23)

/*lane map info*/
typedef struct clx_port_lane_map_info_s {
    uint32 eth_macro;
    uint32 lane;
    clx_port_speed_t max_speed;
    uint32 flags; /* used by CLX_PORT_FLAGS_XXX */
    clx_port_speed_t lane_speed;
    uint32 ppid;
    uint32 port_di;
} clx_port_lane_map_info_t;

/* Interface Monitor Mode */
typedef enum {
    CLX_PORT_IFMON_MODE_INTR = 0,
    CLX_PORT_IFMON_MODE_POLL,
    CLX_PORT_IFMON_MODE_LAST
} clx_port_ifmon_mode_t;

typedef void (*clx_port_ifmon_notify_func_t)(const uint32 unit,
                                             const uint32 port,
                                             const uint32 link,
                                             void *ptr_cookie);

typedef void (*clx_port_phy_notify_func_t)(const uint32 unit, const uint32 port, void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to set the medium type for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    medium    - Medium type.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_medium_type_set(const uint32 unit, const uint32 port, const clx_port_medium_t medium);

/**
 * @brief This API is used to get the medium type for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_medium    - Medium type.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_medium_type_get(const uint32 unit, const uint32 port, clx_port_medium_t *ptr_medium);

/**
 * @brief To set the speed for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Physical port ID.
 * @param [in]    speed    - The speed of the physical port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

/**
 * @brief To get the speed for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [out]    ptr_speed    - The speed of the physical port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *ptr_speed);

/**
 * @brief To get the speedlist for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - Physical port ID.
 * @param [in]     max_len           - The max length of speedlist.
 * @param [out]    ptr_speed_list    - Speedlist of the port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_speed_list_get(const uint32 unit,
                        const uint32 port,
                        const uint32 max_len,
                        clx_port_speed_t *ptr_speed_list);

/**
 * @brief To set the flow control configuration for a specific port.
 *
 * The API is used in the force flow control mode.
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    ptr_fc    - The flow control configuration of the physical port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_flow_ctrl_set(const uint32 unit, const uint32 port, const clx_port_flow_control_t *ptr_fc);

/**
 * @brief To get the flow control configuration for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port ID.
 * @param [out]    ptr_fc    - The flow control configuration of the physical port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_flow_ctrl_get(const uint32 unit, const uint32 port, clx_port_flow_control_t *ptr_fc);

/**
 * @brief To set the auto-negotiation advertisement for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port ID.
 * @param [in]    ptr_ability    - Auto-negotiation ability setting per port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_local_adv_ability_set(const uint32 unit,
                               const uint32 port,
                               const clx_port_ability_t *ptr_ability);

/**
 * @brief To get the auto-negotiation advertisement for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Auto-negotiation ability setting per port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_local_adv_ability_get(const uint32 unit,
                               const uint32 port,
                               clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to get the auto-negotiation remote advertisement for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Auto-negotiation ability setting per port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_remote_adv_ability_get(const uint32 unit,
                                const uint32 port,
                                clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to get the auto-negotiation ability for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [out]    ptr_ability    - Auto-negotiation ability setting per port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_ability_get(const uint32 unit, const uint32 port, clx_port_ability_t *ptr_ability);

/**
 * @brief This API is used to set the loopback for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    loopback    - Loopback type: CLX_PORT_LOOPBACK_DISABLE: disable loopback
 *                              CLX_PORT_LOOPBACK_PHY: local PHY loopback CLX_PORT_LOOPBACK_MAC:
 *                              local MAC loopback.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_loopback_set(const uint32 unit, const uint32 port, const clx_port_loopback_t loopback);

/**
 * @brief This API is used to get the loopback information for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port ID.
 * @param [out]    ptr_loopback    - Loopback type: CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                                   CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                                   CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_loopback_get(const uint32 unit, const uint32 port, clx_port_loopback_t *ptr_loopback);

/**
 * @brief This API is used to probe a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_probe(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to initialize a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_create(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to deinitialize a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_destroy(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to set the MAC address for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    mac     - The MAC address.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_mac_addr_set(const uint32 unit, const uint32 port, const clx_mac_t mac);

/**
 * @brief This API is used to get the MAC address for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_mac    - The MAC address.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_mac_addr_get(const uint32 unit, const uint32 port, clx_mac_t *ptr_mac);

/**
 * @brief This API is used to get the physical link status for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_link    - Link status (please refer to CLX_PORT_LINK_XXX).
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_link_get(const uint32 unit, const uint32 port, uint32 *ptr_link);

/**
 * @brief To get the physical fault status for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [out]    ptr_fault    - Fault status (please refer to CLX_PORT_FAULT_XXX).
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_fault_get(const uint32 unit, const uint32 port, uint32 *ptr_fault);

/**
 * @brief This API is used to set the PHY property for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    config    - PHY config.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_phy_cfg_set(const uint32 unit, const uint32 port, const clx_port_phy_cfg_t *config);

/**
 * @brief This API is used to get the property for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    config    - PHY config.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_phy_cfg_get(const uint32 unit, const uint32 port, clx_port_phy_cfg_t *config);

/**
 * @brief This API is used to bind port or port_vlan to bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Interface object.
 * @param [in]    svid    - First layer VLAN.
 * @param [in]    cvid    - Second layer VLAN.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_vlan_bd_bind(const uint32 unit,
                      const clx_port_t port,
                      const uint32 svid,
                      const uint32 cvid,
                      const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to unbind port vlan and bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Interface object.
 * @param [in]    svid    - First layer VLAN.
 * @param [in]    cvid    - Second layer VLAN.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_vlan_bd_unbind(const uint32 unit,
                        const clx_port_t port,
                        const uint32 svid,
                        const uint32 cvid,
                        const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to unbind port vlan and bridge domain.
 *
 * Support CLX_GPORT_TYPE_UNIT_PORT and CLX_GPORT_TYPE_SRV6.
 * if svid=CLX_INVALID_ID, cvid=CLX_INVALID_ID, port base derive bridge domain.
 * if svid=valid vid, cvid=CLX_INVALID_ID, port+single_vlan derive bridge domain.
 * if svid=valid vid, cvid=valid vid, port + double_vlan derive bridge domain.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Interface object.
 * @param [in]     svid        - First layer VLAN.
 * @param [in]     cvid        - Second layer VLAN.
 * @param [out]    ptr_bdid    - Bridge domain id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_vlan_bd_get(const uint32 unit,
                     const clx_port_t port,
                     const uint32 svid,
                     const uint32 cvid,
                     clx_bridge_domain_t *ptr_bdid);

/**
 * @brief Set Port config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port ID.
 * @param [in]    ptr_config    - Port config.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_cfg_set(const uint32 unit, const uint32 port, const clx_port_cfg_t *ptr_config);

/**
 * @brief Get Port config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port ID.
 * @param [out]    ptr_config    - Port config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_cfg_get(const uint32 unit, const uint32 port, clx_port_cfg_t *ptr_config);

/**
 * @brief This API is used to set the mapping between unit/port and eth-macro/lane number.
 *
 * This API is suggested to be used during SDK initialization.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Physical port ID.
 * @param [in]    ptr_lane_map    - Lane map info pointer.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_lane_map_set(const uint32 unit,
                      const uint32 port,
                      const clx_port_lane_map_info_t *ptr_lane_map);

/**
 * @brief This API is used to get the mapping between unit/port and eth-macro/lane number.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port ID.
 * @param [out]    ptr_lane_map    - Lane map info pointer.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_lane_map_get(const uint32 unit, const uint32 port, clx_port_lane_map_info_t *ptr_lane_map);

/**
 * @brief This API is used to create a UNIT_PORT object.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_port    - The pointer of the UNIT_PORT object.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_gport_create(const uint32 unit, const uint32 port, clx_port_t *ptr_port);

/**
 * @brief This API is used to destroy a UNIT_PORT object.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - UNIT_PORT object.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_gport_destroy(const uint32 unit, clx_port_t port);

/**
 * @brief This API is used to get UNIT_PORT object port from port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [out]    ptr_port    - The pointer of the UNIT_PORT.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_port_to_gport(const uint32 unit, const uint32 port, clx_port_t *ptr_port);

/**
 * @brief This API is used to get port from UNIT_PORT interface object.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     clx_port    - The UNIT_PORT interface object.
 * @param [out]    ptr_port    - The pointer of Port ID.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_gport_to_port(const uint32 unit, const clx_port_t clx_port, uint32 *ptr_port);

/**
 * @brief This API is used to set the properties for a specific interface object.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Interface object.
 * @param [in]    ptr_property    - The pointer of the interface properties.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_intf_cfg_set(const uint32 unit,
                      const clx_port_t port,
                      const clx_port_intf_cfg_t *ptr_property);

/**
 * @brief This API is used to get the properties for a specific interface object.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Interface object.
 * @param [out]    ptr_property    - The pointer of the interface properties.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_intf_cfg_get(const uint32 unit, const clx_port_t port, clx_port_intf_cfg_t *ptr_property);

/**
 * @brief Get port tx time stamp entry information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port ID.
 * @param [out]    ptr_ts_entry    - Time stamp entry information.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_ts_tx_entry_get(const uint32 unit, const uint32 port, clx_port_ts_entry_t *ptr_ts_entry);

/**
 * @brief Get port rx time stamp entry information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Physical port ID.
 * @param [out]    ptr_ts_entry    - Time stamp entry information.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_ts_rx_entry_get(const uint32 unit, const uint32 port, clx_port_ts_entry_t *ptr_ts_entry);

/**
 * @brief Get port type. It is used to lookup corresponding database to get its key.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Interface object.
 * @param [out]    ptr_type    - Type of clx_gport_type_t.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_gport_type_get(const uint32 unit, const clx_port_t port, clx_gport_type_t *ptr_type);

/**
 * @brief This API is used to set prbs pattern for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Physical port ID.
 * @param [in]    prbs_pattern    - PRBS pattern.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_prbs_pattern_set(const uint32 unit,
                          const uint32 port,
                          const clx_port_prbs_pattern_t prbs_pattern);

/**
 * @brief This API is used to get prbs pattern for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port                - Physical port ID.
 * @param [out]    ptr_prbs_pattern    - Pattern on PRBS.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_prbs_pattern_get(const uint32 unit,
                          const uint32 port,
                          clx_port_prbs_pattern_t *ptr_prbs_pattern);

/**
 * @brief This API is used to set prbs generator for a specific lane.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port ID.
 * @param [in]    config    - Prbs conifg type.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_prbs_generator_set(const uint32 unit,
                            const uint32 port,
                            const clx_port_prbs_config_t config);

/**
 * @brief This API is used to dump eye scan for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port ID.
 * @param [in]    lane_idx       - Lane offset within th port.
 * @param [in]    eye_scan       - Eye scan type.
 * @param [in]    sample_deep    - Sample deep.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_eye_scan_dump(const uint32 unit,
                       const uint32 port,
                       const uint32 lane_idx,
                       const clx_port_eye_scan_t eye_scan,
                       const uint32 sample_deep);

/**
 * @brief This API is used to set mdio register for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port ID.
 * @param [in]    phy_type    - PHY type.
 * @param [in]    dev_addr    - PHY device address.
 * @param [in]    reg_addr    - Register address.
 * @param [in]    reg_data    - Register data.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_mdio_reg_set(const uint32 unit,
                      const uint32 port,
                      const clx_phy_type_t phy_type,
                      const uint32 dev_addr,
                      const uint32 reg_addr,
                      const uint32 reg_data);

/**
 * @brief This API is used to get mdio register for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     phy_type    - PHY type.
 * @param [in]     dev_addr    - PHY device address.
 * @param [in]     reg_addr    - Register address.
 * @param [out]    ptr_data    - Register data.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_mdio_reg_get(const uint32 unit,
                      const uint32 port,
                      const clx_phy_type_t phy_type,
                      const uint32 dev_addr,
                      const uint32 reg_addr,
                      uint32 *ptr_data);

/**
 * @brief Get the status per physical port.
 *
 * There is 8 bits for 8 RX priority flow control status in rx_pfc.
 * RX flow control status for priority x (x = 0~7) =
 * rx_pfc & (CLX_PORT_FC_STATUS_ON << x).
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - Physical port id.
 * @param [out]    ptr_status    - Port status speed - reference to clx_port_speed_t link -
 *                                 reference to CLX_PORT_LINK_XXX fault - reference to
 *                                 CLX_PORT_FAULT_XXX rx_fc - reference to CLX_PORT_FC_STATUS_XXX
 *                                 rx_pfc - reference to CLX_PORT_FC_STATUS_XXX.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_status_get(const uint32 unit, const uint32 port, clx_port_status_t *ptr_status);

/**
 * @brief This API is used to set the TX coefficients for a specific lane.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port           - Physical port ID.
 * @param [in]    lane_idx       - Lane offset within th port.
 * @param [in]    location       - PHY location.
 * @param [in]    ptr_tx_coef    - TX coefficient types and values.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_tx_coef_set(const uint32 unit,
                     const uint32 port,
                     const uint32 lane_idx,
                     const clx_port_phy_location_t location,
                     clx_port_tx_coef_t *ptr_tx_coef);

/**
 * @brief This API is used to get the TX coefficients value for a specific lane.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [in]     lane_idx       - Lane offset within th port.
 * @param [in]     location       - PHY location.
 * @param [out]    ptr_tx_coef    - TX coefficient types and values.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_tx_coef_get(const uint32 unit,
                     const uint32 port,
                     const uint32 lane_idx,
                     const clx_port_phy_location_t location,
                     clx_port_tx_coef_t *ptr_tx_coef);

/**
 * @brief This API is used to get fec count for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port           - Physical port ID.
 * @param [in]     ptr_fec_cnt    - Fec count.
 * @param [out]    ptr_fec_cnt    - Fec count.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_port_fec_cnt_get(const uint32 unit, const uint32 port, clx_port_fec_cnt_t *ptr_fec_cnt);

/**
 * @brief Set port egress vlan tag control.
 *
 * Users can add hash entries using CLX_PORT_VLAN_TAG_CTRL_FLAGS_ADD_ENTRY,
 * must use CLX_PORT_VLAN_TAG_CTRL_FLAGS_DEL_ENTRY to delete entries.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Logic port ID.
 * @param [in]    bdid            - Bridge domain ID.
 * @param [in]    ptr_port_tag    - Port VLAN tag control information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_vlan_tag_ctrl_set(const uint32 unit,
                           const clx_port_t port,
                           const clx_bridge_domain_t bdid,
                           const clx_port_vlan_tag_ctrl_t *ptr_port_tag);

/**
 * @brief Get port egress vlan tag control.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Logic port ID.
 * @param [in]     bdid            - Bridge domain ID.
 * @param [out]    ptr_port_tag    - Port VLAN tag control information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
clx_error_no_t
clx_port_vlan_tag_ctrl_get(const uint32 unit,
                           const clx_port_t port,
                           const clx_bridge_domain_t bdid,
                           clx_port_vlan_tag_ctrl_t *ptr_port_tag);

/**
 * @brief Set Mburst property.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port ID.
 * @param [in]    prt_cfg    - Property type.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_mburst_cfg_set(const uint32 unit, const uint32 port, const clx_port_mburst_cfg_t *prt_cfg);

/**
 * @brief Get Mburst property.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    prt_cfg    - Property type.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_mburst_cfg_get(const uint32 unit, const uint32 port, clx_port_mburst_cfg_t *prt_cfg);

/**
 * @brief Get mburst statistic.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port ID.
 * @param [in]     dir       - Direction.
 * @param [out]    p_stat    - Mburst statistic.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_mburst_stat_get(const uint32 unit,
                         const uint32 port,
                         const clx_dir_t dir,
                         clx_port_mburst_stat_t *p_stat);

/**
 * @brief Get Mburst histogram count.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port ID.
 * @param [in]     dir         - IPL or EPL.
 * @param [in]     thrd_num    - Threshold number.
 * @param [out]    p_count     - Histogram count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_mburst_hist_cnt_get(const uint32 unit,
                             const uint32 port,
                             const clx_dir_t dir,
                             const uint32 thrd_num,
                             uint32 *p_count);

/**
 * @brief Clear Mburst count.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    dir     - IPL or EPL.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_mburst_cnt_clear(const uint32 unit, const uint32 port, const clx_dir_t dir);

/**
 * @brief To set led bit control force mode message.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    led_id      - Led module id.
 * @param [in]    bit_id      - Led bit id.
 * @param [in]    led_mode    - 0:actual, 1: on, 2: off.
 */
clx_error_no_t
clx_port_led_bit_set(const uint32 unit, const uint32 led_id, const uint32 bit_id, uint32 *led_mode);

/**
 * @brief To get led bit control force mode message.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     led_id      - Led module id.
 * @param [in]     bit_id      - Led bit id.
 * @param [out]    led_mode    - 0:actual, 1: on, 2: off.
 */
clx_error_no_t
clx_port_led_bit_get(const uint32 unit, const uint32 led_id, const uint32 bit_id, uint32 *led_mode);

/**
 * @brief This API is used to get interface monitor mode, interface monitor port bitmap,
 *        and interface monitor interval.
 *
 * The polling interval is valid if and only if the interface monitor
 * polling mode is used.
 * Support_chip: CLX86.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_mode           - Pointer for interface monitor mode.
 * @param [out]    ptr_port_bitmap    - Pointer for interface monitor port bitmap.
 * @param [out]    ptr_interval_us    - Pointer for interface monitor polling interval in
 *                                      microseconds.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_ifmon_mode_get(const uint32 unit,
                        clx_port_ifmon_mode_t *ptr_mode,
                        clx_port_bitmap_t *ptr_port_bitmap,
                        uint32 *ptr_interval_us);

/**
 * @brief This API is used to set interface monitor mode, interface monitor port bitmap,
 *        and interface monitor interval.
 *
 * The polling interval is valid if and only if the interface monitor
 * polling mode is used.
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    mode           - Interface monitor mode.
 * @param [in]    port_bitmap    - Interface monitor port bitmap.
 * @param [in]    interval_us    - Interface monitor polling interval in microseconds.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_ifmon_mode_set(const uint32 unit,
                        const clx_port_ifmon_mode_t mode,
                        const clx_port_bitmap_t port_bitmap,
                        const uint32 interval_us);

/**
 * @brief This API is used to register a callback function to handle a port link change.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    notify_func    - Callback function.
 * @param [in]    ptr_cookie     - Cookie data of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_ifmon_register(const uint32 unit,
                        const clx_port_ifmon_notify_func_t notify_func,
                        void *ptr_cookie);

/**
 * @brief This API is used to deregister a callback function from callback functions.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    notify_func    - Callback function.
 * @param [in]    ptr_cookie     - Cookie data of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_ifmon_deregister(const uint32 unit,
                          const clx_port_ifmon_notify_func_t notify_func,
                          void *ptr_cookie);

/**
 * @brief This API is used to register/deregister port phy tx signal callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    func          - Callback function,NULL is deregister.
 * @param [in]    ptr_cookie    - Cookie data of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_txsignal_register(const uint32 unit,
                           const clx_port_phy_notify_func_t func,
                           void *ptr_cookie);

/**
 * @brief This API is used to set port DI for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    di      - Destination index.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_di_set(const uint32 unit, const uint32 port, uint32 di);

/**
 * @brief This API is used to get port DI for a specific port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - Physical port ID.
 * @param [out]    ptr_di    - Destination index.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_port_di_get(const uint32 unit, const uint32 port, uint32 *ptr_di);
#endif /* End of CLX_PORT_H */
