/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_bd.h
 * PURPOSE:
 *  Define the declartion for bridge domain module for CL8600.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_BD_H
#define HAL_MT_NB_BD_H

#define HAL_MT_NB_BUM_DROP_DI  (HAL_DROP_BASE_ID(unit))
#define HAL_MT_NB_INVALID_BDID (HAL_INVALID_FDID)

/**
 * @brief Check if bridge domain has been created.
 *
 * No vlan lock.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    bdid    - The Bridge domain id.
 * @return        CLX_E_OK                 - Bridge domain exist.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Bridge domain not exust.
 */
clx_error_no_t
hal_mt_nb_bd_exist_chk(const uint32 unit, const clx_bridge_domain_t bdid);

/**
 * @brief Create a bridge domain.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    bdid    - The Bridge domain id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        others                 - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_create(const uint32 unit, const clx_bridge_domain_t bdid);

/**
 * @brief Destroy a forwarding domain entry.
 *
 * Will disable fdid only.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    bdid    - L2 bridge domain id.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        others                 - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_destroy(const uint32 unit, const clx_bridge_domain_t bdid);

/**
 * @brief Set bridge domain configuration.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    bdid          - Bridge domain ID.
 * @param [in]    ptr_bd_cfg    - Bridge domain configuration.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        others                 - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_cfg_set(const uint32 unit,
                     const clx_bridge_domain_t bdid,
                     const clx_bd_cfg_t *ptr_bd_cfg);

/**
 * @brief Get bridge domain configuration.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     bdid          - Bridge domain ID.
 * @param [out]    ptr_bd_cfg    - Bridge domain configuration.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_bd_cfg_get(const uint32 unit, const clx_bridge_domain_t bdid, clx_bd_cfg_t *ptr_bd_cfg);

/**
 * @brief Update stg of bridge domain for bind/unbind VLAN.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    bdid             - Bridge domain ID.
 * @param [in]    is_bind          - Bridge domain bind VLAN or not.
 * @param [in]    ptr_vlan_bdid    - Bridge domain of VLAN.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        others                 - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_stg_update(const uint32 unit,
                        const clx_bridge_domain_t bdid,
                        const boolean is_bind,
                        clx_bridge_domain_t *ptr_vlan_bdid);

/**
 * @brief Update hardware STG id.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    bdid         - Bridge domain ID.
 * @param [in]    hw_stg_id    - Hardware STG ID.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        others                 - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_hw_stg_update(const uint32 unit,
                           const clx_bridge_domain_t bdid,
                           const uint32 hw_stg_id);

/**
 * @brief Print created bridge domain ID.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_mt_nb_bd_created_print(const uint32 unit);

/**
 * @brief Get capacity of vlan-related hw resource type.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Vlan-related hw resource type.
 * @param [in]     param       - Optional parameter.
 * @param [out]    ptr_size    - Capacity size.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_bd_capacity_get(const uint32 unit,
                          const clx_swc_rsrc_t type,
                          const uint32 param,
                          uint32 *ptr_size);

/**
 * @brief Get used of vlan-related hw resource type.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Vlan-related hw resource type.
 * @param [in]     param      - Optional parameter.
 * @param [out]    ptr_cnt    - Count of usage.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_bd_usage_get(const uint32 unit,
                       const clx_swc_rsrc_t type,
                       const uint32 param,
                       uint32 *ptr_cnt);

/**
 * @brief Init bridge domain module.
 *
 * 1) Create default vlan and add all port as untagged member.
 * 2) Create default bridge domain and bind default vlan to that.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Operate success.
 * @return        CLX_E_ALREADY_INITED    - Unexpected init.
 * @return        CLX_E_OTHER             - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_init(const uint32 unit);

/**
 * @brief Deinit bridge domain module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Operate success.
 * @return        CLX_E_NOT_INITED    - Unexpected deinit.
 * @return        CLX_E_OTHER         - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_deinit(const uint32 unit);

#endif
