/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_bd_hsh.h
 * PURPOSE:
 *  Define the declartion for bd hash module for CL8600.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_BD_HSH_H
#define HAL_MT_NB_BD_HSH_H

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_vlan.h>
#include <hal/hal_const_cmn.h>
#include <hal/mt/nb/hal_mt_nb_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */
typedef enum hal_mt_nb_bd_hsh_module_e {
    HAL_MT_NB_BD_HSH_MODULE_VLAN,
    HAL_MT_NB_BD_HSH_MODULE_PORT,
    HAL_MT_NB_BD_HSH_MODULE_PORT_VLAN,
    HAL_MT_NB_BD_HSH_MODULE_PVLAN,
    HAL_MT_NB_BD_HSH_MODULE_L3,
    HAL_MT_NB_BD_HSH_MODULE_MPLS,
    HAL_MT_NB_BD_HSH_MODULE_NV,
    HAL_MT_NB_BD_HSH_MODULE_USER,
    HAL_MT_NB_BD_HSH_MODULE_LAST,
} hal_mt_nb_bd_hsh_module_t;

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_NB_BD_HSH_LOCK(unit)   hal_mt_nb_bd_hsh_rsc_lock(unit)
#define HAL_MT_NB_BD_HSH_UNLOCK(unit) hal_mt_nb_bd_hsh_rsc_unlock(unit)

/* DATA TYPE DECLARATIONS
 */

typedef struct hal_mt_nb_bd_hsh_bdi_info_s {
    uint32 lcl_intf;        /* Key, logic interface */
    uint32 s_vlan;          /* Key, service VLAN */
    uint32 c_vlan;          /* Key, customer VLAN */
    uint32 bdi;             /* Value, bridge domain ID */
    uint32 pvlan_port_type; /* value, pvlan port type */
} hal_mt_nb_bd_hsh_bdi_info_t;

typedef struct hal_mt_nb_bd_hsh_vlan_info_s {
    uint32 lcl_intf;        /* Key, logic interface */
    uint32 bdi;             /* Key, bridge domain ID */
    uint32 s_vlan;          /* Value, service VLAN */
    uint32 c_vlan;          /* Value, customer VLAN */
    uint32 s_vlan_opt;      /* Value, service VLAN operation */
    uint32 c_vlan_opt;      /* Value, customer VLAN operation */
    uint32 pvlan_port_type; /* Value, pvlan port type */
    uint32 keep_src_vlan;   /* Value, keep source VLAN tag */
} hal_mt_nb_bd_hsh_vlan_info_t;

/* MACRO API DECLARATIONS
 */

/* Init dis_hsh_bdi info key */
#define HAL_MT_NB_BD_INIT_HSH_BDI_INFO_KEY(hsh_info, lcl_port, svid, cvid) \
    do {                                                                   \
        (hsh_info).lcl_intf = lcl_port;                                    \
        (hsh_info).s_vlan = (svid);                                        \
        (hsh_info).c_vlan = (cvid);                                        \
    } while (0)

/* Init rwi_hsh_vlan info key */
#define HAL_MT_NB_BD_INIT_HSH_VLAN_INFO_KEY(hsh_info, lcl_port, bdid) \
    do {                                                              \
        (hsh_info).lcl_intf = lcl_port;                               \
        (hsh_info).bdi = (bdid);                                      \
    } while (0)

/* Init dis_hsh_bdi info */
#define HAL_MT_NB_BD_INIT_HSH_BDI_INFO(hsh_info, lcl_port, svid, cvid, bdid) \
    do {                                                                     \
        (hsh_info).lcl_intf = lcl_port;                                      \
        (hsh_info).s_vlan = (svid);                                          \
        (hsh_info).c_vlan = (cvid);                                          \
        (hsh_info).bdi = (bdid);                                             \
        (hsh_info).pvlan_port_type = (HAL_MT_NB_VLAN_PVLAN_PORT_TYPE_N);     \
    } while (0)

/* Init rwi_hsh_vlan info */
#define HAL_MT_NB_BD_INIT_HSH_VLAN_INFO(hsh_info, lcl_port, bdid, svid, cvid, s_opt, c_opt, \
                                        keep_src)                                           \
    do {                                                                                    \
        (hsh_info).lcl_intf = lcl_port;                                                     \
        (hsh_info).bdi = (bdid);                                                            \
        (hsh_info).s_vlan = (svid);                                                         \
        (hsh_info).c_vlan = (cvid);                                                         \
        (hsh_info).s_vlan_opt = (s_opt);                                                    \
        (hsh_info).c_vlan_opt = (c_opt);                                                    \
        (hsh_info).pvlan_port_type = (HAL_MT_NB_VLAN_PVLAN_PORT_TYPE_N);                    \
        (hsh_info).keep_src_vlan = (keep_src);                                              \
    } while (0)

/**
 * @brief Dis_hsh_bdi/rwi_hsh_vlan lock.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_hsh_rsc_lock(const uint32 unit);

/**
 * @brief Dis_hsh_bdi/rwi_hsh_vlan unlock.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_hsh_rsc_unlock(const uint32 unit);

/**
 * @brief Add DIS_HSH_BDI hash table. Exposed to other module.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - Module ID
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_dis_hsh_bdi_add(const uint32 unit,
                             const hal_mt_nb_bd_hsh_module_t module,
                             const hal_mt_nb_bd_hsh_bdi_info_t *hash_info);

/**
 * @brief Delete ingress DIS_HSH_BDI hash table. Exposed to other module.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - Module ID
 * @param [in]     hash_info    - Hash information, lcl_intf/svid/cvid is key
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_dis_hsh_bdi_del(const uint32 unit,
                             const hal_mt_nb_bd_hsh_module_t module,
                             const hal_mt_nb_bd_hsh_bdi_info_t *hash_info);

/**
 * @brief Get DIS_HSH_BDI hash table. Exposed to other module.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - Module ID
 * @param [in]     hash_info    - Hash information, lcl_intf/svid/cvid
 * @param [out]    hash_info    - Hash information, bdid/pvlan_port_type
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_dis_hsh_bdi_get(const uint32 unit,
                             const hal_mt_nb_bd_hsh_module_t module,
                             hal_mt_nb_bd_hsh_bdi_info_t *hash_info);

/**
 * @brief Update ingress hash table to vlan.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User mode
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_dis_hsh_bdi_update(const uint32 unit,
                                const hal_mt_nb_bd_hsh_module_t module,
                                const hal_mt_nb_bd_hsh_bdi_info_t *hash_info);

/**
 * @brief Add RWI_HSH_VLAN hash table. Exposed to other module.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User ID
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_rwi_hsh_vlan_add(const uint32 unit,
                              const hal_mt_nb_bd_hsh_module_t module,
                              const hal_mt_nb_bd_hsh_vlan_info_t *hash_info);

/**
 * @brief Delete egress hash table to vlan.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User mode
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_rwi_hsh_vlan_del(const uint32 unit,
                              const hal_mt_nb_bd_hsh_module_t module,
                              const hal_mt_nb_bd_hsh_vlan_info_t *hash_info);

/**
 * @brief User update egress hash table.
 *
 * just for clx_port_vlan_tag_ctrl_set use, other module use hal_mt_nb_bd_rwi_hsh_vlan_update
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_user_rwi_hsh_vlan_update(const uint32 unit,
                                      const hal_mt_nb_bd_hsh_vlan_info_t *hash_info);

/**
 * @brief Update egress hash table to vlan.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User mode
 * @param [in]     hash_info    - Hash information
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_rwi_hsh_vlan_update(const uint32 unit,
                                 const hal_mt_nb_bd_hsh_module_t module,
                                 const hal_mt_nb_bd_hsh_vlan_info_t *hash_info);

/**
 * @brief Delete egress hash table to vlan.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     module       - User mode
 * @param [in]     hash_info    - Hash key, lcl_intf/bdid
 * @param [out]    hash_info    - Hash value, s_vlan/c_vlan/pvlan_port_type/keep_src_vlan
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_rwi_hsh_vlan_get(const uint32 unit,
                              const hal_mt_nb_bd_hsh_module_t module,
                              hal_mt_nb_bd_hsh_vlan_info_t *hash_info);

/**
 * @brief Get egress hash table.
 *
 * just for clx_port_vlan_tag_ctrl_get use, other module use hal_mt_nb_bd_rwi_hsh_vlan_update
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     hash_info    - Hash key, lcl_intf/bdid
 * @param [out]    hash_info    - Hash value, s_vlan/c_vlan/pvlan_port_type/keep_src_vlan
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate failed.
 */
clx_error_no_t
hal_mt_nb_bd_user_rwi_hsh_vlan_get(const uint32 unit, hal_mt_nb_bd_hsh_vlan_info_t *hash_info);

/**
 * @brief Update hash entry when vlan tag mode change
 *
 * Must call in hsh lock
 *
 * @param [in]     unit                 - Device unit number
 * @param [in]     lcl_intf             - Logic interface
 * @param [in]     old_vlan_tag_mode    - Port old vlan tag mode
 * @param [in]     new_vlan_tag_mode    - New old vlan tag mode
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Operate fail.
 */
clx_error_no_t
_hal_mt_nb_bd_vlan_tag_mode_update(const uint32 unit,
                                   const uint32 lcl_intf,
                                   const hal_mt_nb_vlan_hw_vlan_tag_mode_t old_vlan_tag_mode,
                                   const hal_mt_nb_vlan_hw_vlan_tag_mode_t new_vlan_tag_mode);

/**
 * @brief Warmboot init dis_hsh_bdi list.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Logic interface
 * @param [in]     obj         - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_igr_hsh_list_warm_init(const uint32 unit,
                                    const uint32 lcl_intf,
                                    const hal_io_obj_meta_t *obj);

/**
 * @brief Warmboot init rwi_hsh_vlan entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Logic interface
 * @param [in]     obj         - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_egr_hsh_list_warm_init(const uint32 unit,
                                    const uint32 lcl_intf,
                                    const hal_io_obj_meta_t *obj);

/**
 * @brief Warmboot init port isolated.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     obj     - Object meta
 */
void
hal_mt_nb_bd_portiso_warm_init(const uint32 unit, const hal_io_obj_meta_t *obj);

/**
 * @brief Warmboot deinit dis_hsh_bdi hash entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Logic interface
 * @param [in]     obj         - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_igr_hsh_list_warm_deinit(const uint32 unit,
                                      const uint32 lcl_intf,
                                      hal_io_obj_meta_t *obj);

/**
 * @brief Warmboot deinit rwi_hsh_vlan hash entry.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Logic interface
 * @param [in]     obj         - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_egr_hsh_list_warm_deinit(const uint32 unit,
                                      const uint32 lcl_intf,
                                      hal_io_obj_meta_t *obj);

/**
 * @brief Warmboot deinit port isolated.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     obj     - Object meta
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_portIso_warm_deinit(const uint32 unit, hal_io_obj_meta_t *obj);

/**
 * @brief Init dis_hsh_bdi and rwi_hsh_vlan entry.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_hsh_Init(const uint32 unit);

/**
 * @brief Deinit dis_hsh_bdi and rwi_hsh_vlan entry.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_hsh_deinit(const uint32 unit);

/**
 * @brief Show dis_hsh_bdi entry.
 *
 * support show hash entry by lcl-intf.
 * support show hash entry by lcl-intf + vlan
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - lcl intferface
 * @param [in]     s_vlan      - Service vlan
 * @param [in]     c_vlan      - Customer vlan
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_dis_hsh_bdi_entry_show(const uint32 unit,
                                    const uint32 lcl_intf,
                                    const clx_vlan_t s_vlan,
                                    const clx_vlan_t c_vlan);

/**
 * @brief Show rwi_hsh_vlan entry.
 *
 * support show hash entry by lcl-intf.
 * support show hash entry by lcl-intf + bdi
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - lcl intferface
 * @param [in]     bdi         - Bridge domain index
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Init fail.
 */
clx_error_no_t
hal_mt_nb_bd_rwi_hsh_vlan_entry_show(const uint32 unit,
                                     const uint32 lcl_intf,
                                     const clx_bridge_domain_t bdi);

/**
 * @brief Add isolated port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Local interface
 * @param [in]     dir         - Set direction
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate fail.
 */
clx_error_no_t
hal_mt_nb_bd_isolated_port_add(const uint32 unit, const uint32 lcl_intf, const clx_dir_t dir);

/**
 * @brief Delete isolated port.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     lcl_intf    - Local interface
 * @param [in]     dir         - Set direction
 * @return         CLX_E_OK    - Operate success.
 * @return         others      - Operate fail.
 */
clx_error_no_t
hal_mt_nb_bd_isolated_port_del(const uint32 unit, const uint32 lcl_intf, const clx_dir_t dir);

#endif
