/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_swc.h
 * PURPOSE:
 *      API & special number for CL8570. For example: IEV, EMI.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NAMCHABARWA_SWC_H
#define HAL_MT_NAMCHABARWA_SWC_H

#include <clx/clx_cfg.h>
#include <clx/clx_swc.h>

#include <hal/hal_swc.h>
#define HAL_MT_NAMCHABARWA_SWC_HASH_STAGE_NUM          (3)
#define HAL_MT_NAMCHABARWA_SWC_HASH_TILE_NUM_PER_STAGE (8)
#define HAL_MT_NAMCHABARWA_SWC_HASH_TILE_NUM           (24)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_NUM_PER_TYPE       (16)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_NUM \
    (HAL_SWC_TCAM_TYPE * HAL_MT_NAMCHABARWA_SWC_TCAM_NUM_PER_TYPE)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_ENTRY_NUM (HAL_MT_NAMCHABARWA_SWC_TCAM_NUM * 1024)

#define HAL_MT_NAMCHABARWA_SWC_HASH_TILE_PRI_NUM_PER_FPU (12)
#define HAL_MT_NAMCHABARWA_SWC_HASH_TILE_PRI_NUM \
    (HAL_MT_NAMCHABARWA_SWC_HASH_TILE_PRI_NUM_PER_FPU * 2)

#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_ENABLE          (1)
#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_DEFAULT_COUNTER (10000)
#define HAL_MT_NAMCHABARWA_SWC_REASON_BF_DEFAULT_TIMER   (1000)

#define HAL_MT_NAMCHABARWA_SWC_EMI_BANK_NUM                (8)
#define HAL_MT_NAMCHABARWA_SWC_EMI_NSH_BANK_BASE           (HAL_MT_NAMCHABARWA_SWC_EMI_BANK_NUM - 1)
#define HAL_MT_NAMCHABARWA_SWC_PAGE_NUM_PER_BANK           (4)
#define HAL_MT_NAMCHABARWA_SWC_ILE_TCAM_BANK_NUM           (64)
#define HAL_MT_NAMCHABARWA_SWC_ILE_TCAM_ENTRY_NUM_PER_BANK (256)
#define HAL_MT_NAMCHABARWA_SWC_MASTER_DIE_ID               (4) /* t die */

#define HAL_MT_NAMCHABARWA_SWC_EPG_MAC_HDR_LEN (60)            /* bytes */
#define HAL_MT_NAMCHABARWA_SWC_EPG_MAC_MAX_IPG (1024)          /* register 10 bits */

#define HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD        0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD      1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD     2
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED 3

#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA           0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA           1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2           0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3           1
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID 0xFFFF
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_2X      0
#define HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X      1

#if defined(CLX_ASICSIM)
#define HAL_MT_NAMCHABARWA_SWC_DEFAULT_DROP_REASON 63
#endif

static inline void
hal_mt_nb_swc_tcam_off_cfg(uint32 unit, uint32 tcam_table, uint32 *tcam_field, uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 0,
                        stage_cfg_buf);
}

static inline void
hal_mt_nb_swc_tcam_l3_sa_cfg(uint32 unit,
                             uint32 tcam_table,
                             uint32 *tcam_field,
                             uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l3_da_cfg(uint32 unit,
                             uint32 tcam_table,
                             uint32 *tcam_field,
                             uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l3_sa_4x_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA, stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table,
                        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l3_da_4x_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA, stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table,
                        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_IPV6_2X_OR_4X_FILED],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_IPV6_4X, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L3, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l2_uc_sa_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_SA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l2_uc_da_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

static inline void
hal_mt_nb_swc_tcam_l2_mc_da_cfg(uint32 unit,
                                uint32 tcam_table,
                                uint32 *tcam_field,
                                uint32 *stage_cfg_buf)
{
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_ENABLE_FIELD], 1,
                        stage_cfg_buf);
    tob_field_ui32_pack(unit, tcam_table, tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_SA_OR_DA_FIELD],
                        HAL_MT_NAMCHABARWA_SWC_TCAM_IS_DA, stage_cfg_buf);
    if (HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2L3_INVALID !=
        tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD]) {
        tob_field_ui32_pack(unit, tcam_table,
                            tcam_field[HAL_MT_NAMCHABARWA_SWC_TCAM_L2_OR_FIB_FIELD],
                            HAL_MT_NAMCHABARWA_SWC_TCAM_IS_L2, stage_cfg_buf);
    }
}

#define HAL_MT_NAMCHABARWA_SWC_HASH_MAC_ENTRIES_PER_TILE      (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ARP_ENTRIES_PER_TILE      (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_AFIB_ENTRIES_PER_TILE     (64 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_L3_ENTRIES_PER_TILE       (16 * 1024)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ARP_DEFAULT_TILE_NUM      (4)
#define HAL_MT_NAMCHABARWA_SWC_HASH_AFIB_DEFAULT_TILE_NUM     (5)
#define HAL_MT_NAMCHABARWA_SWC_HASH_L3_DEFAULT_TILE_NUM       (5)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MPLS_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_SRV6_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MGI_DEFAULT_TILE_NUM      (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MSGI_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ECMP_GRP_DEFAULT_TILE_NUM (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_ECMP_MBR_DEFAULT_TILE_NUM (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_RPFC_DEFAULT_TILE_NUM     (1)
#define HAL_MT_NAMCHABARWA_SWC_HASH_MAC_DEFAULT_TILE_NUM      (0)

#define HAL_MT_NAMCHABARWA_SWC_TCAM_TYPE_ONLY_L3    (0)
#define HAL_MT_NAMCHABARWA_SWC_TCAM_TYPE_L2L3       (1)
#define HAL_MT_NAMCHABARWA_SWC_DMAC_TCAM_START      (16)
#define HAL_MT_NAMCHABARWA_SWC_DMAC_MAX_TCAM_NUM    (16)
#define HAL_MT_NAMCHABARWA_SWC_DIP_DEFAULT_TCAM_NUM (10)
#define HAL_MT_NAMCHABARWA_SWC_MAX_TCAM_NUM         (32)
#define HAL_MT_NAMCHABARWA_SWC_MAX_TILE_NUM         (24)
#define HAL_MT_NAMCHABARWA_ENTRIES_PER_TCAM         (1024)
#define HAL_MT_NAMCHABARWA_ENTRIES_PER_TCAM_BIT     (10)
#define HAL_MT_NAMCHABARWA_MAC_ENTRIES_PER_TCAM     (512)
#define HAL_MT_NB_L3_ENTRIES_PER_TCAM               (1024)
#define HAL_MT_NAMCHABARWA_SWC_DUAL_MAX_TCAM_NUM    (64)
#define HAL_MT_NAMCHABARWA_SWC_DUAL_MAX_TILE_NUM    (48)

clx_error_no_t
hal_mt_nb_swc_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_swc_epg_pkt_init(hal_swc_epg_pkt_t *ptr_pkt);

/**
 * @brief Set MAC EPG packet related configuration (header, payload, ipg,
 *        ...).
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_pkt    - Packet information to be sent.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_swc_epg_mac_hw_set(const uint32 unit, const hal_swc_epg_pkt_t *ptr_pkt);

/**
 * @brief Trigger MAC EPG to send packets.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - EPG ingress port.
 * @param [in]    lpbk    - 0: Traffic is sent to PP; 1: MAC loopback.
 * @return        Clx_error_no_tr.
 */
clx_error_no_t
hal_mt_nb_swc_epg_mac_pkt_send(const uint32 unit, const uint32 port, const uint32 lpbk);

/**
 * @brief Trigger MAC EPG to send packets.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - EPG ingress port.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_swc_epg_mac_done_chk(const uint32 unit, const uint32 port);

/**
 * @brief Stop MAC EPG from sending packets.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - EPG ingress port.
 * @return        Clx_error_no_t.
 */
clx_error_no_t
hal_mt_nb_swc_epg_mac_pkt_stop(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_arp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_afib_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l3_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_mpls_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_srv6_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l2uc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l2mc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_mgi_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_msgi_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_ecmp_mbr_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_ecmp_grp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_rpfc_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_policy_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l2_ecmp_grp_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_hsh_tile_l2_ecmp_mbr_cfg(const uint32 unit, uint32 entry_num);

clx_error_no_t
hal_mt_nb_swc_tcam_l2_cfg(const uint32 unit, uint32 uc_entry_num, uint32 mc_entry_num);

clx_error_no_t
hal_mt_nb_swc_host_tcam_cfg(const uint32 unit,
                            uint32 entry_2x_num,
                            uint32 entry_4x_num,
                            uint32 sip_check);

clx_error_no_t
hal_mt_nb_swc_route_tcam_cfg(const uint32 unit,
                             uint32 entry_2x_num,
                             uint32 entry_4x_num,
                             uint32 sip_check);

clx_error_no_t
hal_mt_nb_swc_tile_type_get(const uint32 unit,
                            const uint32 slice_id,
                            const uint32 stage_id,
                            const uint32 tile_id,
                            uint32 *ptr_tile_type);

clx_error_no_t
hal_mt_nb_swc_ts_set(const uint32 unit, const clx_swc_ts_t ts_val);

clx_error_no_t
hal_mt_nb_swc_ts_get(const uint32 unit, clx_swc_ts_t *ptr_ts_val);

clx_error_no_t
hal_mt_nb_swc_dev_info_get(const uint32 unit, clx_swc_device_info_t *ptr_device_info);

clx_error_no_t
hal_mt_nb_swc_ts_offset_set(const uint32 unit, const int32 nsec);

clx_error_no_t
hal_mt_nb_swc_cso_mode_set(const uint32 unit, const clx_swc_cso_mode_t mode);

/**
 * @brief Get chip PLL status.
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_pll_status    - Pointer to the status of chip PLL.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_chip_pll_status_get(const uint32 unit, clx_swc_chip_pll_status_t *ptr_pll_status);

/**
 * @brief Set the ipl runt pkt fwd action.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - Enable or disable runt pkt fwd.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_skip_rx_crc_check_set(const uint32 unit, const uint32 enable);

/**
 * @brief Get the ipl runt pkt fwd action.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - Enable or disable runt pkt fwd.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_skip_rx_crc_check_get(const uint32 unit, uint32 *ptr_enable);

/**
 * @brief Set the rwo runt pkt fwd action.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    enable    - Enable or disable runt pkt fwd.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_runt_pkt_fwd_set(const uint32 unit, const uint32 enable);

/**
 * @brief Get the rwo runt pkt fwd action.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_enable    - Enable or disable runt pkt fwd.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_swc_runt_pkt_fwd_get(const uint32 unit, uint32 *ptr_enable);

#endif
