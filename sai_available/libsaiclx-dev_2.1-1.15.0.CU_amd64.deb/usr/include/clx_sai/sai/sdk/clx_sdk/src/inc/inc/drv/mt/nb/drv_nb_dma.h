/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv_nb_dma.h
 * PURPOSE:
 *  1. Provide the access interfaces of DMA and CLD DMA to chip Device Control Command(DRV_MT).
 *  2. Define DRV_MT DMA and CLD DMA related structures.
 *
 * NOTES:
 *
 */

#ifndef DRV_DMA_NB_H
#define DRV_DMA_NB_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>
#include <clx/clx_init.h>
#include <drv/drv_dma.h>
#include <drv/mt/drv_mt_dma.h>
#include <linux/include/nb/nb_chip.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define DRV_DMA_NB_WORD_LENGTH            (4)                       /* words, means 4 bytes */
#define DRV_DMA_NB_DFLT_RING_SIZE         (2)                       /* default ring size */
#define DRV_DMA_NB_DFLT_CLD_DMA_RING_SIZE (4096)                    /* default CLD DMA ring size */
#define DRV_DMA_NB_DFLT_OP_MODE           (DRV_DMA_CH_OP_MODE_POLL) /* defalut operation mode */
#ifdef NB_EMU_DEV
#define DRV_DMA_NB_DFLT_MAX_TIMEOUT_CNT (3000000000)
#else
#define DRV_DMA_NB_DFLT_MAX_TIMEOUT_CNT (1000000)
#endif
#define DRV_DMA_NB_MAX_RETRY_NUM (100)

#define DRV_DMA_NB_DFLT_CLD_THREAD_STACK (32 * 1024)
#define DRV_DMA_NB_DFLT_CLD_THREAD_PRI   (80)
#define DRV_DMA_NB_DFLT_CLD_SLEEP_PERIOD (3000000)

#define NB_SET_BITMAP(bitmap, mask_bitmap) (bitmap = ((bitmap) | (mask_bitmap)))
#define NB_CLR_BITMAP(bitmap, mask_bitmap) (bitmap = ((bitmap) & (~(mask_bitmap))))
#define NB_GET_BITMAP(flags, bit)          ((((flags) & (bit)) > 0) ? 1 : 0)

// /********************DMA register************************************/

// #define NB_DMA_SCRATCH                    0x051C1400
// #define NB_CTL_CHAIN_INTR_MSK             0x051C00BC
// #define NB_CFG_PDMA_CH_ENABLE             0X051C1404
// #define NB_CFG_PDMA_DESC_LOCATION         0x051C1408
// #define NB_CFG_PDMA_DESC_ENDIAN           0x051C140C
// #define NB_CFG_PDMA_CRC_EN                0x051C1434
// #define NB_CFG_PDMA_DATA_ENDIAN_SWAP      0x051C1410
// #define NB_CFG_AXI_PROTO_INFO             0x051C1414
// #define NB_CFG_AXI_FIFO_ALM_FULL          0x051C1418
// #define NB_CFG_AXI_TIMEOUT_THR            0x051C141C
// #define NB_CFG_AXI0_OUTSTD_SIZE           0x051C1428
// #define NB_CFG_AXI1_OUTSTD_SIZE           0x051C142C
// #define NB_CFG_FIFIO_PATH_SEL             0x051C1430
// #define NB_CFG_CRC_EN                     0x051C1434
// #define NB_CFG_P2H_RX_FIFO_ALM_FULL       0x051C1438
// #define NB_CFG_P2H_TX_FIFO_ALM_FULL       0x051C143c
// #define NB_CFG_P2E_RX_FIFO_ALM_FULL       0x051C1440
// #define NB_CFG_P2E_TX_FIFO_ALM_FULL       0x051C1444
// #define NB_CFG_TX_FIFO_TIMEOUT_THR        0x051C1448
// #define NB_CFG_SLV_TIMEOUT_THR            0x051C144C
// #define NB_CFG_PDMA2PCIE_INTR_MASK        0X051C14A4
// #define NB_CFW_PDMA2PCIE_INTR_CLR         0X051C14A8
// #define NB_CFW_PDMA2PCIE_INTR_TEST        0X051C14AC
// #define NB_STA_PDMA_NORMAL_INTR           0X051C14B4
// #define NB_CFG_PDMA_CH0_RING_BASE         0X051C14B8
// #define NB_CFG_PDMA_CH0_RING_SIZE         0X051C1558
// #define NB_CFG_PDMA_CH0_DESC_WORK_IDX     0X051C15A8
// #define NB_STA_PDMA_CH0_DESC_POP_IDX      0X051C15F8
// #define NB_CFG_PDMA_CH0_MODE              0x051C1648
// #define NB_CFW_PDMA_CH_RESET              0X051C174C
// #define NB_CFW_PDMA_CH_RESTART            0X051C1750
// #define NB_CFG_PDMA2PCIE_INTR_MASK_ALL    0X051C2120
// #define NB_CFG_PDMA2PCIE_INTR_CH0_MASK    0X051C2124
// #define NB_IRQ_PDMA_ABNORMAL_CH0_INTR     0X051C216C
// #define NB_IRQ_PDMA_ABNORMAL_CH0_INTR_MSK 0X051C2170

// #define NB_CFG_PDMA_CHx_RING_BASE(__channel__)     (NB_CFG_PDMA_CH0_RING_BASE + 0x8 *
// (__channel__)) #define NB_CFG_PDMA_CHx_RING_SIZE(__channel__)     (NB_CFG_PDMA_CH0_RING_SIZE +
// 0x4 * (__channel__)) #define NB_CFG_PDMA_CHx_DESC_WORK_IDX(__channel__)
// (NB_CFG_PDMA_CH0_DESC_WORK_IDX + 0x4 * (__channel__)) #define
// NB_STA_PDMA_CHx_DESC_POP_IDX(__channel__)  (NB_STA_PDMA_CH0_DESC_POP_IDX + 0x4 * (__channel__))
// #define NB_CFG_PDMA_CHx_MODE(__channel__)          (NB_CFG_PDMA_CH0_MODE + 0x4 * (__channel__))

/********************DMA register end************************************/

typedef enum drv_dma_mt_ch_mode_e {
    MT_DMA_HOSTMEM_TO_HOSTMEM = 0,
    MT_DMA_DEVICE_TO_HOSTMEM = 1,
    MT_DMA_HOSTMEM_TO_DEVICE = 2,
    MT_DMA_DEVICE_TO_DEVICE = 3,
} drv_dma_nb_ch_mode_t;

typedef enum drv_dma_nb_channel_e {
    DRV_DMA_NB_CH_RX0 = 0,
    DRV_DMA_NB_CH_RX1 = 1,
    DRV_DMA_NB_CH_RX2 = 2,
    DRV_DMA_NB_CH_RX3 = 3,
    DRV_DMA_NB_CH_TX0 = 4,
    DRV_DMA_NB_CH_TX1 = 5,
    DRV_DMA_NB_CH_TX2 = 6,
    DRV_DMA_NB_CH_TX3 = 7,
    DRV_DMA_NB_CH_RSRV0 = 8,
    DRV_DMA_NB_CH_DTOH = 9,
    DRV_DMA_NB_CH_HTOD = 10,
    DRV_DMA_NB_CH_DTOD = 11,
    DRV_DMA_NB_CH_RSRV1 = 12,
    DRV_DMA_NB_CH_RSRV2 = 13,
    DRV_DMA_NB_CH_CLD = 14,
    DRV_DMA_NB_CH_RSRV3 = 15,
    DRV_DMA_NB_CH_ECPU_RX = 16,
    DRV_DMA_NB_CH_ECPU_TX = 17,
    DRV_DMA_NB_CH_L2_FIFO = 18,
    DRV_DMA_NB_CH_IOAM_FIFO = 19,

    DRV_DMA_NB_CH_LAST
} drv_dma_nb_channel_t;

typedef struct drv_dma_nb_ch_cb_s {
    clx_semaphore_id_t sema;      /* mutually exclusive access the same table */
    clx_semaphore_id_t sync_sema; /* intr sync */
    clx_thread_id_t task_id;
    uint32 task_sleep_intvl;
    drv_dma_ch_op_mode_t op_mode;
    uint32 timeout_cnt;

    uint32 work_idx;
    uint32 pop_idx;
    uint32 ring_size;
    drv_dma_nb_ch_mode_t ch_mode;

    volatile drv_dma_mt_desc_t *ring_base;
    volatile drv_dma_mt_desc_t *ring_base_align;
    boolean err_flag;
} drv_dma_nb_ch_cb_t;

#endif /* END of DRV_DMA_NB_H*/
