/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_swc.h
 * PURPOSE:
 *      It provides hal switch control module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_SWC_H
#define HAL_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_cfg.h>
#include <clx/clx_swc.h>
#include <tob/tob.h>

/* NAMING CONSTANT DECLARATIONS
 */

/*IPP hash engine for: ECMP, LAG*/
#define HAL_SWC_HASH_ID_ECMP_L3    (0)
#define HAL_SWC_HASH_ID_ECMP_NVO3  (1)
#define HAL_SWC_HASH_ID_LAG        (2)
#define HAL_SWC_HASH_ID_FABRIC_LAG (3)

/*EPP hash engine for: packet generation during tunnel initialization*/
#define HAL_SWC_HASH_ID_MPLS_FLOW_LABEL        (0)
#define HAL_SWC_HASH_ID_MPLS_FLOW_LABEL_MSB    (1)
#define HAL_SWC_HASH_ID_MPLS_ENTROPY_LABEL     (2)
#define HAL_SWC_HASH_ID_MPLS_ENTROPY_LABEL_MSB (3)

#define HAL_SWC_HASH_ID_L3T_IPV6_FLOW_LABEL     (0)
#define HAL_SWC_HASH_ID_L3T_IPV6_FLOW_LABEL_MSB (1)
#define HAL_SWC_HASH_ID_VXLAN_UDP_SRC_PORT      (2)
#define HAL_SWC_HASH_ID_NVGRE_FLOW_ID           (3)

#define HAL_SWC_ILE_HASH_BANK_NUM                 (16)
#define HAL_SWC_HASH_ENTRY_NUM_PER_BANK           (16 * 1024)
#define HAL_SWC_FPU_HSH_POLICY_ENTRY_NUM_PER_BANK (10 * 1024) /*need to rename*/

#define HAL_SWC_ILE_TCAM_BANK_NUM  (64)
#define HAL_SWC_ILE_TCAM_ENTRY_NUM (16 * 1024)

#define HAL_SWC_HASH_L2_FDB_REGION_MAX           (14 * HAL_SWC_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L2_FDB_REGION_DEFAULT       (4 * HAL_SWC_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L2_GROUP_REGION_DEFAULT     (1 * HAL_SWC_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_128_REGION_DEFAULT       (1 * HAL_SWC_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_64_REGION_DEFAULT        (1 * HAL_SWC_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_L3_NO_PREFIEX_DEFAULT       (6 * HAL_SWC_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_SECURITY_REGION_DEFAULT     (1 * HAL_SWC_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_HASH_FLOW_REGION_DEFAULT         (2 * HAL_SWC_HASH_ENTRY_NUM_PER_BANK)
#define HAL_SWC_TCAM_L2_FDB_REGION_DEFAULT       (3 * 512)
#define HAL_SWC_TCAM_L2_FDB_GROUP_REGION_DEFAULT (1 * 512)
#define HAL_SWC_TCAM_L3_128_REGION_DEFAULT       (HAL_SWC_ILE_TCAM_ENTRY_NUM / 2)
#define HAL_SWC_TCAM_L3_64_REGION_DEFAULT        (HAL_SWC_ILE_TCAM_ENTRY_NUM / 2)

/*ILE TCAM bank define*/
#define HAL_SWC_ILE_TCAM_128_BMP(unit) _hal_swc_cb[unit]._ile_tcam_128_bmp
#define HAL_SWC_ILE_TCAM_64_BMP(unit)  _hal_swc_cb[unit]._ile_tcam_64_bmp

#define HAL_SWC_EPG_2B      (2)
#define HAL_SWC_EPG_4B      (4)
#define HAL_SWC_EPG_6B      (6)
#define HAL_SWC_EPG_PLD_LEN (128)

#define HAL_SWC_EXCEPTION_WORD_NUM              (10) /* 4 ids, 4 iev, 2 eme */
#define HAL_SWC_TRAP_ALL_CFG_CTRL2CPU_ENTRY_NUM (4)
#define HAL_SWC_TRAP_ALL_CFG_EXCEPTION_WORD_NUM (HAL_SWC_EXCEPTION_WORD_NUM)
/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SWC_LOCK(unit) \
    HAL_COMMON_LOCK_RESOURCE(&(_hal_swc_cb[unit].sema_id), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_SWC_UNLOCK(unit)                 HAL_COMMON_FREE_RESOURCE(&(_hal_swc_cb[unit].sema_id))
#define HAL_SWC_CONST_EMI(__unit__, __idx__) (PTR_HAL_CONST_INFO(__unit__, swc)->emi[__idx__])

/* 25.6T 1FPU 24TILE and 32K TCAM; 12.8T 2FPU 48TILE and 64k TCAM*/
#define HAL_SWC_FPU_NUM   (2)
#define HAL_SWC_FPU_INST0 (0)
#define HAL_SWC_FPU_INST1 (1)

#define HAL_SWC_HSH_STAGE_MAX_NUM          (10)
#define HAL_SWC_HSH_TILE_MAX_NUM_PER_STAGE (8)
#define HAL_SWC_HSH_TILE_MAX_NUM           (24)
#define HAL_SWC_HSH_TILE_WORD_WIDTH        (32)
#define HAL_SWC_HSH_TILE_BMP_SIZE \
    (((HAL_SWC_HSH_TILE_MAX_NUM - 1) / HAL_SWC_HSH_TILE_WORD_WIDTH) + 1)
typedef uint32 hal_swc_hsh_tile_bmp_t[HAL_SWC_HSH_TILE_BMP_SIZE * 2];

#define HAL_SWC_TCAM_TYPE       (2)
#define HAL_SWC_TCAM_MAX_NUM    (32)
#define HAL_SWC_TCAM_WORD_WIDTH (32)
#define HAL_SWC_TCAM_BMP_SIZE   (((HAL_SWC_TCAM_MAX_NUM - 1) / HAL_SWC_TCAM_WORD_WIDTH) + 1)
#define HAL_SWC_TCAM_CFG_FLD    (4)

typedef uint32 hal_swc_tcam_bmp_t[HAL_SWC_TCAM_BMP_SIZE * 2];

#define HAL_SWC_HSH_TILE_PRI_NUM_PER_FPU (12)
#define HAL_SWC_HSH_TILE_PRI_MAX_NUM     (HAL_SWC_HSH_TILE_PRI_NUM_PER_FPU * 2)
/* DATA TYPE DECLARATIONS
 */
typedef enum hal_swc_tbl_type_e {
    HAL_SWC_TBL_TYPE_PERF_TEST_REG = 0,
    HAL_SWC_TBL_TYPE_PERF_TEST_DMA_READ,
    HAL_SWC_TBL_TYPE_PERF_TEST_DMA_WRITE,
    HAL_SWC_TBL_TYPE_LAST
} hal_swc_tbl_type_t;

typedef enum hal_swc_wbdb_obj_type_e {
    HAL_SWC_WBDB_CFG_ID = 0,
    HAL_SWC_WBDB_RIM_ID,
    HAL_SWC_WBDB_OBJ_LAST
} hal_swc_wbdb_obj_type_t;

typedef struct hal_swc_epg_pkt_s {
    clx_mac_t dmac;
    clx_mac_t smac;

    uint16 tpid;
    uint32 pcp;
    uint32 dei;
    uint32 vid;

    uint32 ip; /* user inputs sip&dip */
    clx_ip_addr_t sip;
    clx_ip_addr_t dip;

    uint32 len;
    uint32 num;
    clx_port_speed_t speed;
    clx_port_bitmap_t pbm;

    uint8 pld[HAL_SWC_EPG_PLD_LEN];
    uint32 pld_len;

    uint8 fill;

    uint32 rep_num;
    uint32 duration;
} hal_swc_epg_pkt_t;

typedef struct hal_swc_err_handler_s {
    uint32 valid;
    clx_swc_err_func_t callback;
    void *ptr_cookie;
} hal_swc_err_handler_t;

typedef struct hal_swc_notify_handler_s {
    uint32 valid;
    clx_swc_notify_func_t callback;
    void *ptr_cookie;
} hal_swc_notify_handler_t;

typedef struct hal_swc_trap_all_cfg_usr_data_s {
    clx_pkt_ctrl_to_cpu_entry_t ctrl2cpu_entry[HAL_SWC_TRAP_ALL_CFG_CTRL2CPU_ENTRY_NUM];
    uint32 excpt_word[HAL_SWC_TRAP_ALL_CFG_EXCEPTION_WORD_NUM];
} hal_swc_trap_all_cfg_usr_data_t;

typedef struct hal_swc_trap_all_cfg_s {
    boolean enabled;
    hal_swc_trap_all_cfg_usr_data_t usr_data;
} hal_swc_trap_all_cfg_t;

typedef clx_error_no_t (*hal_swc_hsh_tile_cfg_func_t)(uint32 unit, uint32 entry_num);

typedef struct hal_swc_tcam_used_s {
    hal_swc_tcam_bmp_t tcam_bmp;
    uint32 tcam_counter;
    uint32 l3_route_tcam_start_index;
    uint32 l3_host_tcam_start_index;
    uint32 l2_tcam_start_index;
} hal_swc_tcam_used_t;

typedef struct hal_swc_tcam_info_s {
    hal_swc_tcam_bmp_t tcam_bmp;
    uint32 tcam_counter;
    uint32 tcam_start_index;
    uint32 tcam_end_index;
} hal_swc_tcam_info_t;

typedef struct hal_swc_tile_cfg_s {
    clx_swc_hsh_tile_type_t hash_tile_type;
    hal_swc_hsh_tile_cfg_func_t hash_tile_cfg;
} hal_swc_tile_cfg_t;

typedef struct hal_swc_hsh_tile_info_s {
    hal_swc_hsh_tile_bmp_t hash_tile_bmp;
    uint32 hash_tile_counter;
    uint32 hash_tile[HAL_SWC_FPU_NUM * HAL_SWC_HSH_TILE_MAX_NUM];
    uint32 high_pri;
    uint32 low_pri;
} hal_swc_hsh_tile_info_t;

typedef struct hal_swc_hsh_tile_pri_s {
    uint32 tile_pri;
    uint32 tile_used;
} hal_swc_hsh_tile_pri_t;

typedef struct hal_swc_cb_s {
    clx_swc_hsh_key_bmp_t key_bmp[CLX_SWC_HSH_PKT_TYPE_LAST];
    clx_semaphore_id_t sema_id;
    uint32 _ile_tcam_128_bmp[CLX_BITMAP_SIZE(HAL_SWC_ILE_TCAM_BANK_NUM)];
    uint32 _ile_tcam_64_bmp[CLX_BITMAP_SIZE(HAL_SWC_ILE_TCAM_BANK_NUM)];
    uint32 _ile_hash_l2_fdb_base;
    uint32 _ile_hash_l2_fdb_bank_num;
    clx_cfg_type_t _ile_hash_bank_type[HAL_SWC_ILE_HASH_BANK_NUM];
    clx_cfg_type_t _ile_tcam_bank_type[HAL_SWC_ILE_TCAM_BANK_NUM];
    hal_swc_err_handler_t error_handler[CLX_SWC_ERR_TYPE_LAST];
    hal_swc_notify_handler_t notify_handler[CLX_SWC_NOTIFY_CATEGORY_LAST];
    clx_swc_cso_mode_t cso_mode;
    /* Set excetions to drop or CPU. Not support warmboot */
    uint32 excpt_ctrl_en;
    uint32 excpt_en_bmp[HAL_SWC_EXCEPTION_WORD_NUM];
    uint32 excpt_trap_en_bmp[HAL_SWC_EXCEPTION_WORD_NUM];
    uint32 excpt_supp_cpu_cp_bmp[HAL_SWC_EXCEPTION_WORD_NUM];

    /* Database for trap-all config */
    hal_swc_trap_all_cfg_t trap_all_cfg;

    /* HASH configuration*/
    hal_swc_hsh_tile_info_t hash_tile_info[CLX_SWC_HSH_TILE_TYPE_LAST];
    hal_swc_hsh_tile_pri_t hash_tile_pri[HAL_SWC_FPU_NUM][HAL_SWC_HSH_STAGE_MAX_NUM]
                                        [HAL_SWC_HSH_TILE_MAX_NUM_PER_STAGE];
    uint32 hash_pri_num[HAL_SWC_HSH_TILE_PRI_MAX_NUM];
    uint32 hash_pri_min;

    /* TCAM configuration*/
    hal_swc_tcam_info_t tcam_info[CLX_SWC_TCAM_TYPE_LAST];
    hal_swc_tcam_used_t tcam_used;

    /* Memory check flag*/
    tob_mem_check_info_t mem_check;
} hal_swc_cb_t;

typedef struct hal_swc_hsh_reg_reg_info_s {
    uint32 plane;  /* plane id */
    uint32 reg_id; /*register id*/
    uint32 reg_num;
    uint32 field_id;
    uint32 *ptr_field_values;
} hal_swc_hsh_reg_reg_info_t;
/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
/**
 * @brief Set switch control property.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    property    - Property type.
 * @param [in]    param0      - First parameter.
 * @param [in]    param1      - Second parameter.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_cfg_set(const uint32 unit,
                const clx_swc_cfg_t property,
                const uint32 param0,
                const uint32 param1);

/**
 * @brief Get switch control property.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     property      - Property type.
 * @param [out]    ptr_param0    - First parameter.
 * @param [out]    ptr_param1    - Second parameter.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_cfg_get(const uint32 unit,
                const clx_swc_cfg_t property,
                uint32 *ptr_param0,
                uint32 *ptr_param1);

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_chip_temp_get(const uint32 unit, int32 *ptr_temperature);

/**
 * @brief Register error callback function.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    error         - Error source type.
 * @param [in]    callback      - The callback function of type clx_swc_err_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_err_cb_register(const uint32 unit,
                        const clx_swc_err_type_t error,
                        const clx_swc_err_func_t callback,
                        void *ptr_cookie);

/**
 * @brief Deregister error callback function.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    error         - Error source type.
 * @param [in]    callback      - The callback function of type clx_swc_err_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_err_cb_deregister(const uint32 unit,
                          const clx_swc_err_type_t error,
                          const clx_swc_err_func_t callback,
                          void *ptr_cookie);

void
hal_swc_err_cb_ntfy(const uint32 unit,
                    const clx_swc_err_type_t error,
                    const clx_swc_err_info_t *ptr_error_info);

/**
 * @brief Register notify callback function.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    category      - Notify category.
 * @param [in]    callback      - The callback function of type clx_swc_notify_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_notify_cb_register(const uint32 unit,
                           const clx_swc_notify_category_t category,
                           const clx_swc_notify_func_t callback,
                           void *ptr_cookie);

/**
 * @brief Deregister notify callback function.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    category      - Notify category.
 * @param [in]    callback      - The callback function of type clx_swc_notify_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_notify_cb_deregister(const uint32 unit,
                             const clx_swc_notify_category_t category,
                             const clx_swc_notify_func_t callback,
                             void *ptr_cookie);

/**
 * @brief Other module use this function to notify health event.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    event_type     - Event type.
 * @param [in]    severity       - Event severity.
 * @param [in]    category       - Event category.
 * @param [in]    description    - Event description.
 */
void
hal_swc_health_event_ntfy(const uint32 unit,
                          const uint32 event_type,
                          const uint32 severity,
                          const uint32 category,
                          const char *description);
/**
 * @brief Get device information.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_device_info    - The device information.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_dev_info_get(const uint32 unit, clx_swc_device_info_t *ptr_device_info);

/**
 * @brief Get port bitmap of current config.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_port_config    - Type of clx_swc_port_cfg_t.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_swc_port_cfg_get(const uint32 unit, clx_swc_port_cfg_t *ptr_port_config);

/**
 * @brief Get resource capacity.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Resource type.
 * @param [in]     param       - Parameter if necessary.
 * @param [out]    ptr_size    - Size of capacity.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_capacity_get(const uint32 unit,
                     const clx_swc_rsrc_t type,
                     const uint32 param,
                     uint32 *ptr_size);

/**
 * @brief Get resource usage.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Resource type.
 * @param [in]     param      - Parameter if necessary.
 * @param [out]    ptr_cnt    - Count of usage.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_usage_get(const uint32 unit, const clx_swc_rsrc_t type, const uint32 param, uint32 *ptr_cnt);

/**
 * @brief Get clock servo mode.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_mode    - Clock servo mode.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_cso_mode_get(const uint32 unit, clx_swc_cso_mode_t *ptr_mode);

/**
 * @brief This function is to set reason priority.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    rx_reason_code    - Rx reason code.
 * @param [in]    priority          - Reason priority.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_rsn_pri_set(const uint32 unit,
                    const clx_pkt_rx_reason_t rx_reason_code,
                    const uint32 priority);

/**
 * @brief This function is to get reason priority.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     rx_reason_code    - Rx reason code.
 * @param [out]    priority          - Reason priority.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_rsn_pri_get(const uint32 unit, const clx_pkt_rx_reason_t rx_reason_code, uint32 *priority);

/**
 * @brief To set PP reason priority.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    pp_reason_code    - Pp reason code.
 * @param [in]    priority          - Reason priority.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_pp_rsn_pri_set(const uint32 unit, const uint32 pp_reason_code, const uint32 priority);

/**
 * @brief To get PP reason priority.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     pp_reason_code    - Pp reason code.
 * @param [out]    priority          - Reason priority.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_pp_rsn_pri_get(const uint32 unit, const uint32 pp_reason_code, uint32 *priority);

/**
 * @brief This function is to get max timestamp sec.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    max_ts_sec    - Max Timestamp sec.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_swc_max_ts_sec_get(const uint32 unit, uint32 *max_ts_sec);

/**
 * @brief This function is to get chip configurable information.
 *
 * @param [in]    unit     - Device unit number, get chip configuration is required,
 *                           but get global configuration is not required.
 * @param [in]    type     - Type for get chip configurable information.
 * @param [in]    para0    - Parameter0 if necessary.
 * @param [in]    para1    - Parameter1 if necessary ptr_value.
 * @return        CLX_E_OK             - Operate success.
 * @return        CLX_E_NOT_SUPPORT    - Not support.
 * @return        other                - Operate fail.
 */
clx_error_no_t
hal_swc_chip_cfg_info_get(const uint32 unit,
                          const clx_swc_chip_cfg_info_type_t type,
                          const uint32 para0,
                          const uint32 para1,
                          uint32 *ptr_value);

/**
 * @brief This function is to get table name by table id.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     tbl_id          - Table id.
 * @param [in]     tbl_name_len    - Table name length.
 * @param [out]    ptr_tbl_name    - Table name.
 * @return         CLX_E_OK             - Operate success.
 * @return         CLX_E_NOT_SUPPORT    - Not support.
 * @return         other                - Operate fail.
 */
clx_error_no_t
hal_swc_tbl_name_get(const uint32 unit,
                     const uint32 tbl_id,
                     const uint32 tbl_name_len,
                     char *ptr_tbl_name);

/**
 * @brief This function retrieves the string name based on the index.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     data_type    - Data Type.
 * @param [in]     index        - Index.
 * @param [in]     str_len      - String length.
 * @param [out]    str_name     - String name.
 * @return         CLX_E_OK             - Operate success.
 * @return         CLX_E_NOT_SUPPORT    - Not support.
 * @return         other                - Operate fail.
 */
clx_error_no_t
hal_swc_str_name_get(const uint32 unit,
                     const clx_swc_data_type_t data_type,
                     const uint32 index,
                     const uint32 str_len,
                     char *str_name);
#endif
