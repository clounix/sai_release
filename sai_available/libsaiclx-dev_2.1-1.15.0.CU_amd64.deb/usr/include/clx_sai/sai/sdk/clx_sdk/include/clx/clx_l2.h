/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_l2.h
 *
 * PURPOSE:
 *      It provides L2 switching module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_L2_H
#define CLX_L2_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* Use the specified multicast ID while creating */
#define CLX_L2_MCAST_FLAGS_ADD_WITH_ID (1U << 0)
/* Logical mcast id can not be compressed. Only supported on CL8600. */
#define CLX_L2_MCAST_FLAGS_LOGICAL_ID_NO_COMPRESS (1U << 1)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct clx_l2_addr_s {
    clx_bridge_domain_t bdid; /* Bridge domain ID */
    clx_mac_t mac;            /* 802.3 MAC address */
    clx_port_t port;          /* Port number */
    uint32 grp_lbl;           /* ACL label */
    uint32 flags;             /* CLX_L2_ADDR_FLAGS_XXX flags */
    uint32 attr_bmp;          /* Mark which fields to set, CLX_L2_ADDR_ATTR_XXX */
} clx_l2_addr_t;
/* Set entry static.                                                     \
 * In CL8600 means this entry does not allow aging and station movement. \
 * In CL8360 means this entry does not allow aging.                      \
 */
#define CLX_L2_ADDR_FLAGS_STATIC (1U << 0)
#define CLX_L2_ADDR_FLAGS_DROP   (1U << 1) /* Frames which hit this entry will be dropped */
#define CLX_L2_ADDR_FLAGS_SECURE (1U << 2) /* Set entry secure */
#define CLX_L2_ADDR_FLAGS_TO_CPU (1U << 3) /* Copy to cpu. Not supported on CL8600 */
/* Support when operation mode is polling mode.                     \
 * The l2 polling events will not be generated if this flag is set. \
 */
#define CLX_L2_ADDR_FLAGS_NO_CALLBACK (1U << 4)
/* Not supported on CL8360.                       \
 * Overwrite entry while the hash bucket is full. \
 */
#define CLX_L2_ADDR_FLAGS_OVERWRITE_DYNAMIC (1U << 5)

#define CLX_L2_ADDR_ATTR_PORT    (1ULL << 0) /* set port */
#define CLX_L2_ADDR_ATTR_GRP_LBL (1ULL << 1) /* set group label */
#define CLX_L2_ADDR_ATTR_FLAGS   (1ULL << 2) /* set flags */
#define CLX_L2_ADDR_ATTR_ALL     0xFFFFFFFF

typedef enum clx_l2_addr_flush_flags_e {
    CLX_L2_ADDR_FLUSH_FLAGS_DYNAMIC = (1U << 0),
    CLX_L2_ADDR_FLUSH_FLAGS_STATIC = (1U << 1),
    CLX_L2_ADDR_FLUSH_FLAGS_NO_CALLBACK = (1U << 2),
    CLX_L2_ADDR_FLUSH_FLAGS_LAST
} clx_l2_addr_flush_flags_t;

typedef enum clx_l2_addr_flush_op_type_e {
    CLX_L2_ADDR_FLUSH_OP_BY_MAC = 0,
    CLX_L2_ADDR_FLUSH_OP_BY_BDID,
    CLX_L2_ADDR_FLUSH_OP_BY_PORT,
    CLX_L2_ADDR_FLUSH_OP_BY_MAC_PORT,
    CLX_L2_ADDR_FLUSH_OP_BY_BDID_PORT,
    CLX_L2_ADDR_FLUSH_OP_ALL,
    CLX_L2_ADDR_FLUSH_OP_LAST
} clx_l2_addr_flush_op_type_t;

typedef struct clx_l2_addr_flush_s {
    clx_bridge_domain_t bdid; /* Bridge domain ID */
    clx_mac_t mac;            /* 802.3 MAC address */
    clx_port_t port;          /* Port number */
} clx_l2_addr_flush_t;

typedef enum clx_l2_addr_replace_match_e {
    CLX_L2_ADDR_REPLACE_MATCH_MAC = (1U << 0),
    CLX_L2_ADDR_REPLACE_MATCH_BDID = (1U << 1), /* Replace all L2 entries matching given bdid */
    CLX_L2_ADDR_REPLACE_MATCH_PORT = (1U << 2), /* Replace all L2 entries matching given port */
    /* Replace all L2 entries matching given static status */
    CLX_L2_ADDR_REPLACE_MATCH_STATIC = (1U << 3),
    /* Replace all L2 entries matching given secure status */
    CLX_L2_ADDR_REPLACE_MATCH_SECURE = (1U << 4),
    CLX_L2_ADDR_REPLACE_MATCH_GRP_LBL = (1U << 5),
    CLX_L2_ADDR_REPLACE_MATCH_UNEQUAL = (1U << 6), /* Only supported on CL8600. */
    CLX_L2_ADDR_REPLACE_MATCH_LAST
} clx_l2_addr_replace_match_t;

typedef enum clx_l2_addr_replace_e {
    /* Delete L2 unicast MAC address entries.
     * If this field is set, other fields will be ignored.
     */
    CLX_L2_ADDR_REPLACE_DEL = (1U << 0),
    /* Replace port.
     * Need to specify bdid value if port type is ip tnl.
     */
    CLX_L2_ADDR_REPLACE_PORT = (1U << 1),
    CLX_L2_ADDR_REPLACE_DROP = (1U << 2),    /* Replace drop field */
    CLX_L2_ADDR_REPLACE_STATIC = (1U << 3),  /* Replace static field */
    CLX_L2_ADDR_REPLACE_SECURE = (1U << 4),  /* Replace secure field */
    CLX_L2_ADDR_REPLACE_GRP_LBL = (1U << 5), /* Replace group label field */
    CLX_L2_ADDR_REPLACE_LAST
} clx_l2_addr_replace_t;

typedef enum clx_l2_addr_notify_reason_e {
    CLX_L2_ADDR_NOTIFY_ADD = 0, /* New entry added in L2 FDB */
    CLX_L2_ADDR_NOTIFY_MODIFY,  /* Entry modified in L2 FDB */
    CLX_L2_ADDR_NOTIFY_DEL,     /* Entry deleted in L2 FDB */
    CLX_L2_ADDR_NOTIFY_LAST
} clx_l2_addr_notify_reason_t;

typedef enum clx_l2_addr_sw_learn_reason_e {
    CLX_L2_ADDR_SW_LEARN_NEW_LEARN, /* Entry new learn in L2 FDB. */
    CLX_L2_ADDR_SW_LEARN_MOVE,      /* Entry moved in L2 FDB. */
    CLX_L2_ADDR_SW_LEARN_LAST
} clx_l2_addr_sw_learn_reason_t;

/* Callback function use for receiving notification about insertions into,
 * modifications, and deletions from the L2 table dynamically as they occur.
 */
typedef void (*clx_l2_addr_notify_func_t)(const uint32 unit,
                                          const clx_l2_addr_notify_reason_t reason,
                                          const clx_l2_addr_t *ptr_addr,
                                          void *ptr_cookie);
typedef void (*clx_l2_addr_sw_learn_func_t)(const uint32 unit,
                                            const clx_l2_addr_sw_learn_reason_t reason,
                                            const clx_l2_addr_t *ptr_addr,
                                            void *ptr_cookie);

typedef enum clx_l2_mcast_egr_intf_type_e {
    /* If use this type,
     *  - for uni/nni port, egress s-vlan tag will be removed/added.
     *  - for non uni/nni port,
     *    egress vlan will be the same as ingress classified vlan.
     */
    CLX_L2_MCAST_EGR_INTF_TYPE_PORT = 0,
    CLX_L2_MCAST_EGR_INTF_TYPE_L2,
    CLX_L2_MCAST_EGR_INTF_TYPE_FL,   /* Fabric link. Only supported on CL8600 */
    CLX_L2_MCAST_EGR_INTF_TYPE_TNL,
    CLX_L2_MCAST_EGR_INTF_TYPE_SRV6, /* Only supported on CL8600 */
    CLX_L2_MCAST_EGR_INTF_TYPE_MPLS,
    CLX_L2_MCAST_EGR_INTF_TYPE_LAST
} clx_l2_mcast_egr_intf_type_t;

typedef struct clx_l2_mcast_egr_intf_l2_s {
    clx_port_t port;
    clx_bridge_domain_t bdid;
} clx_l2_mcast_egr_intf_l2_t;

typedef struct clx_l2_mcast_egr_intf_tnl_s {
    clx_port_t port;
    clx_port_t tnl_port;    /* unicast tunnel */
    clx_tnl_info_t tnl_key; /* multicast tunnel */
    uint32 nvo3_adj_id;
} clx_l2_mcast_egr_intf_tnl_t;

typedef struct clx_l2_mcast_egr_intf_srv6_s {
    clx_port_t port;
    clx_port_t srv6_port;
    uint32 nvo3_adj_id;
} clx_l2_mcast_egr_intf_srv6_t;

typedef struct clx_l2_mcast_egr_intf_mpls_s {
    clx_port_t port;
    clx_port_t pw_port;
} clx_l2_mcast_egr_intf_mpls_t;

typedef struct clx_l2_mcast_egr_intf_s {
    clx_l2_mcast_egr_intf_type_t type;     /* If (type == CLX_L2_MCAST_EGR_INTF_TYPE_PORT),
                                              only the port field should be filled,
                                              the other fileds will be ignored. */
    union {
        clx_port_t port;                   /* Port number.
                                            * Only support port type CLX_PORT_TYPE_NORMAL
                                            * and CLX_PORT_TYPE_LAG  */
        clx_l2_mcast_egr_intf_l2_t l2;     /* Port number with bdid */
        uint32 fl_id;                      /* Fabric link ID. Only supported on CL8600. */
        clx_l2_mcast_egr_intf_tnl_t tnl;
        clx_l2_mcast_egr_intf_srv6_t srv6; /* Only supported on CL8600. */
        clx_l2_mcast_egr_intf_mpls_t mpls;
    };
} clx_l2_mcast_egr_intf_t;

typedef struct clx_l2_mcast_egr_mbr_s {
    uint32 egr_intf_cnt;
    uint32 actual_egr_intf_cnt; /* Only use in clx_l2_mcast_egr_intf_get.
                                 * Return actual number of egress interface obtained */
    clx_l2_mcast_egr_intf_t *ptr_egr_intf;
} clx_l2_mcast_egr_mbr_t;

typedef struct clx_l2_mcast_addr_s {
    clx_bridge_domain_t bdid; /* Bridge domain ID */
    clx_mac_t mac;            /* 802.3 mac address */
    uint32 mcast_id;          /* Multicast ID */
    uint32 grp_lbl;           /* ACL label */
    uint32 flags;             /* CLX_L2_MCAST_ADDR_FLAGS_XXX flags */
    uint32 attr_bmp;          /* Mark which fields to set, CLX_L2_MCAST_ADDR_ATTR_XXX */
} clx_l2_mcast_addr_t;
#define CLX_L2_MCAST_ADDR_FLAGS_DROP   (1U << 0) /* Frames which hit this entry will be dropped */
#define CLX_L2_MCAST_ADDR_FLAGS_TO_CPU (1U << 1) /* copy to cpu. Not supported on CL8600. */

#define CLX_L2_MCAST_ADDR_ATTR_MCAST_ID (1ULL << 0) /* set Multicast ID */
#define CLX_L2_MCAST_ADDR_ATTR_GRP_LBL  (1ULL << 1) /* set group label */
#define CLX_L2_MCAST_ADDR_ATTR_FLAGS    (1ULL << 2) /* set flags */
#define CLX_L2_MCAST_ADDR_ATTR_ALL      0xFFFFFFFF

typedef enum clx_l2_entry_trav_mode_s {
    CLX_L2_ENTRY_TRAV_MODE_BLOCKING = 0, /* Traverse blocking mode */
    CLX_L2_ENTRY_TRAV_MODE_NON_BLOCKING, /* Traverse non blocking mode */
    CLX_L2_ENTRY_TRAV_MODE_LAST
} clx_l2_entry_trav_mode_t;

/* L2 traverse unicast entry callback */
typedef clx_error_no_t (*clx_l2_addr_trav_func_t)(const uint32 unit,
                                                  const clx_l2_addr_t *ptr_addr,
                                                  void *ptr_cookie);

/* L2 traverse multicast entry callback */
typedef clx_error_no_t (*clx_l2_mcast_addr_trav_func_t)(const uint32 unit,
                                                        const clx_l2_mcast_addr_t *ptr_addr,
                                                        void *ptr_cookie);
typedef struct clx_l2_addr_trav_match_S {
    clx_l2_addr_t uc_addr;
    uint32 match_flags; /* CLX_L2_ENTRY_TRAV_MATCH_XXX */
} clx_l2_addr_trav_match_t;

typedef struct clx_l2_mcast_addr_trav_match_addr_s {
    clx_l2_mcast_addr_t mc_addr;
    uint32 match_flags; /* CLX_L2_ENTRY_TRAV_MATCH_XXX */
} clx_l2_mcast_addr_trav_match_t;

typedef enum clx_l2_entry_trav_match_e {
    CLX_L2_ENTRY_TRAV_MATCH_NONE = (1U << 0),
    CLX_L2_ENTRY_TRAV_MATCH_MAC = (1U << 1),
    CLX_L2_ENTRY_TRAV_MATCH_BDID = (1U << 2),
    CLX_L2_ENTRY_TRAV_MATCH_PORT = (1U << 3),
    CLX_L2_ENTRY_TRAV_MATCH_MCAST_ID = (1U << 4),
    CLX_L2_ENTRY_TRAV_MATCH_GRP_LBL = (1U << 5),
    CLX_L2_ENTRY_TRAV_MATCH_STATIC = (1U << 6),
    CLX_L2_ENTRY_TRAV_MATCH_DROP = (1U << 7),
    CLX_L2_ENTRY_TRAV_MATCH_SECURE = (1U << 8),
    CLX_L2_ENTRY_TRAV_MATCH_LAST
} clx_l2_entry_trav_match_t;

/* Ecmp Algorithm mode */
typedef enum clx_l2_ecmp_algo_mode_e {
    CLX_L2_ECMP_ALGO_MODE_HI = 0, /* use org list only */
    CLX_L2_ECMP_ALGO_MODE_LO,     /* use act list only */
    CLX_L2_ECMP_ALGO_MODE_BOTH,   /* use org and act list both */
    CLX_L2_ECMP_ALGO_MODE_LAST
} clx_l2_ecmp_algo_mode_t;

/* ECMP Hash Configuration */
typedef struct clx_l2_ecmp_hsh_cfg_s {
    clx_l2_ecmp_algo_mode_t algo_mode; /* Different algorithms correspond to different path
                                          selection results*/

    uint32 hsh_val_cnt;                /* configured hash value count */
    uint32 hsh_sel;                    /* select which hash engine */
    uint32 flags;                      /* refer to CLX_L2_ECMP_HSH_FLAGS_XX */
} clx_l2_ecmp_hsh_cfg_t;
#define CLX_L2_ECMP_HSH_FLAGS_ALGO_MODE (1U << 0) /* set algo_mode */
#define CLX_L2_ECMP_HSH_FLAGS_SEL_EN    (1U << 1) /* set hsh_sel */

typedef struct clx_l2_ecmp_grp_s {
    uint32 path_cnt;               /* total ecmp path number, only valid when get. */
    uint32 weight_cnt;
    clx_l2_ecmp_hsh_cfg_t hsh_cfg; /* Refer to clx_l2_ecmp_hsh_cfg_t. */

    uint32 flags;                  /* Refer to CLX_L2_ECMP_GRP_FLAGS_XX, do not use now. */
} clx_l2_ecmp_grp_t;
#define CLX_L2_ECMP_GRP_FLAGS_WECMP_EN (1U << 0) /* Enable weighted ECMP. */
#define CLX_L2_ECMP_GRP_FLAGS_WITH_ID  (1U << 1) /* set ecmp with the input id */

typedef struct clx_l2_ecmp_path_s {
    clx_port_t output_port; /* output port */
    uint32 weight;          /* weight */
} clx_l2_ecmp_path_t;

typedef struct clx_l2_ecmp_path_hsh_s {
    clx_l2_ecmp_path_t path; /* path info */
    uint32 hsh_cnt;          /* hash count */
    uint32 *hsh_val;         /* hash value array */
} clx_l2_ecmp_path_hsh_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to add/set a L2 unicast MAC address entry.
 *
 * If the address entry does not exist, it will add the entry;
 * if the address entry already exists, it will set the entry with user input value.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_addr    - The L2 address entry to be added/set.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_add(const uint32 unit, const clx_l2_addr_t *ptr_addr);

/**
 * @brief This API is used to delete a L2 unicast MAC address entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    bdid     - Bridge domain ID.
 * @param [in]    mac      - Mac address.
 * @param [in]    flags    - CLX_L2_ADDR_FLAGS_NO_CALLBACK.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_del(const uint32 unit,
                const clx_bridge_domain_t bdid,
                const clx_mac_t mac,
                const uint32 flags);

/**
 * @brief This API is used to get a L2 unicast MAC address entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_addr    - The L2 address entry to be obtained. User should only fill the key
 *                               fields "bdid" and "mac". The other fields will be ignored.
 * @param [out]    ptr_addr    - The fully filled L2 address entry obtained.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_get(const uint32 unit, clx_l2_addr_t *ptr_addr);

/**
 * @brief This API is used to flush L2 unicast MAC address entries which match the specified
 *        criteria with the newly specified values.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    flags             - Refer to CLX_L2_ADDR_FLUSH_FLAGS_XXX.
 * @param [in]    flush_type        - Refer to CLX_L2_ADDR_FLUSH_OP_XXX.
 * @param [in]    ptr_match_addr    - Specify the values of matched fields used to perform matching.
 *                                    User need to input values of these fields which are chosen by
 *                                    "flush_type" parameter.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_flush(const uint32 unit,
                  const uint32 flags,
                  const clx_l2_addr_flush_op_type_t flush_type,
                  const clx_l2_addr_flush_t *ptr_match_addr);

/**
 * @brief This API is used to replace L2 unicast MAC address entries which match the specified
 *        criteria with the newly specified values.
 *
 * When user specifies the "replace_field" with CLX_L2_ADDR_REPLACE_DEL set,
 * other values which are included by "replace_field" parameter will be ignored,
 * and the parameter "ptr_replace_addr" can be NULL.
 * Support_chip: CLX86.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    match_flags         - Indicate which fields of L2 uncast MAC address entry are
 *                                      used to match the given "ptr_match_addr".
 *                                      User can choose one or more fields to do matching.
 *                                      Refer to CLX_L2_ADDR_REPLACE_MATCH_XXX.
 * @param [in]    ptr_match_addr      - Specify the values of matched fields used to perform
 *                                      matching. User need to input values of these fields which
 *                                      are chosen by "match_field" parameter.
 * @param [in]    replace_flags       - Indicate which fields' values will be replaced with new
 *                                      values. Refer to CLX_L2_ADDR_REPLACE_XXX.
 * @param [in]    ptr_replace_addr    - Specify the new values used to replace the old values for
 *                                      the matched MAC address entries.
 *                                      User need to input values of these fields which are chosen
 *                                      by "replace_field" parameter.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_replace(const uint32 unit,
                    const uint32 match_flags,
                    const clx_l2_addr_t *ptr_match_addr,
                    const uint32 replace_flags,
                    const clx_l2_addr_t *ptr_replace_addr);

/**
 * @brief This API is used to traverse all the L2 unicast MAC address entries,
 *        and handle it by user's callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     mode              - The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 * @param [in]     ptr_match_addr    - Specify the values of matched fields used to perform.
 * @param [in]     callback          - The callback function to be called when each L2 address
 *                                     entry is traversed.
 * @param [in]     ptr_cookie        - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie        - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_trav(const uint32 unit,
                 const clx_l2_entry_trav_mode_t mode,
                 const clx_l2_addr_trav_match_t *ptr_match_addr,
                 const clx_l2_addr_trav_func_t callback,
                 void *ptr_cookie);

/**
 * @brief This API is used to register a callback function that will be called whenever the L2
 *        unicast MAC address table is updated.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_l2_addr_notify_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_notify_cb_register(const uint32 unit,
                               const clx_l2_addr_notify_func_t callback,
                               void *ptr_cookie);

/**
 * @brief This API is used to degister a callback function that will be called whenever the L2
 *        unicast MAC address table is updated.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_l2_addr_notify_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_notify_cb_deregister(const uint32 unit,
                                 const clx_l2_addr_notify_func_t callback,
                                 void *ptr_cookie);

/**
 * @brief This API is used to register a callback function that will be called whenever the L2
 *        unicast entry needs to be learned by sofware.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_l2_addr_sw_learn_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_sw_learn_cb_register(const uint32 unit,
                                 const clx_l2_addr_sw_learn_func_t callback,
                                 void *ptr_cookie);

/**
 * @brief This API is used to degister a callback function that will be called whenever the L2
 *        unicast entry needs to be learned by sofware.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_l2_addr_sw_learn_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_addr_sw_learn_cb_deregister(const uint32 unit,
                                   const clx_l2_addr_sw_learn_func_t callback,
                                   void *ptr_cookie);

/**
 * @brief This API is used to get a L2 unicast MAC address entry age status.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     bdid              - Bridge domain ID.
 * @param [in]     mac               - Mac address.
 * @param [out]    ptr_age_status    - Age status.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_age_status_get(const uint32 unit,
                      const clx_bridge_domain_t bdid,
                      const clx_mac_t mac,
                      uint32 *ptr_age_status);

/**
 * @brief This API is used to create a L2 multicast forwarding group ID.
 *
 * After the L2 multicast ID is added, L2 multicast egress interfaces can be added to it.
 * If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set, this API will add L2 multicast ID with the ID
 * pointed by ptr_mcast_id; if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a
 * L2 multicast ID.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     flags           - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [in]     ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                                   this field specifies the L2 multicast ID to be added.
 * @param [out]    ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                                   this field specifies the allocated L2 multicast ID.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_grp_create(const uint32 unit, const uint32 flags, uint32 *ptr_mcast_id);

/**
 * @brief This API is used to create multiple L2 multicast forwarding group ID.
 *
 * After the L2 multicast ID is added, L2 multicast egress interfaces can be added to it.
 * If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set, this API will add L2 multicast ID with the ID
 * pointed by ptr_mcast_id; if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a
 * set of L2 multicast ID.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     flags           - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [in]     mcast_id_cnt    - The number of L2 multicast ID need to be added.
 * @param [in]     ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                                   this field specifies the L2 multicast ID to be added.
 * @param [out]    ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                                   this field specifies the first allocated L2 multicast ID.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_multi_mcast_grp_create(const uint32 unit,
                              const uint32 flags,
                              const uint32 mcast_id_cnt,
                              uint32 *ptr_mcast_id);

/**
 * @brief This API is used to destroy a L2 multicast forwarding group ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    mcast_id    - The L2 multicast ID to be deleted.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_grp_destroy(const uint32 unit, const uint32 mcast_id);

/**
 * @brief This API is used to get L2 multicast interface in the form of port bitmap.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     mcast_id     - The L2 multicast ID to be obtained.
 * @param [out]    ptr_flags    - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [out]    port_bmp     - The egress port bitmap.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_intf_pbmp_get(const uint32 unit,
                           const uint32 mcast_id,
                           uint32 *ptr_flags,
                           clx_port_bitmap_t port_bmp);

/**
 * @brief This API is used to add egress interface for a L2 multicast ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    mcast_id       - The L2 multicast ID.
 * @param [in]    ptr_egr_mbr    - The egress interface list to be added.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_egr_intf_add(const uint32 unit,
                          const uint32 mcast_id,
                          const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

/**
 * @brief This API is used to delete egress interface for a L2 multicast ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    mcast_id       - The L2 multicast ID.
 * @param [in]    ptr_egr_mbr    - The egress interface list to be deleted.
 *                                 user should only fill the "type", "bdid" and "port" fields,
 *                                 and the other fields will be ignored.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_egr_intf_del(const uint32 unit,
                          const uint32 mcast_id,
                          const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

/**
 * @brief This API is used to get egress interface count for a L2 multicast ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     mcast_id            - The L2 multicast ID.
 * @param [out]    ptr_egr_intf_cnt    - The egress interface count.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_egr_intf_cnt_get(const uint32 unit, const uint32 mcast_id, uint32 *ptr_egr_intf_cnt);

/**
 * @brief This API is used to get egress interface for a L2 multicast ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     mcast_id       - The L2 multicast ID.
 * @param [out]    ptr_egr_mbr    - The egress interface list obtained.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_egr_intf_get(const uint32 unit,
                          const uint32 mcast_id,
                          clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

/**
 * @brief This API is used to check if the egress interface is exist in the L2 multicast ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mcast_id        - The L2 multicast ID.
 * @param [in]     egr_intf        - The egress interface need to be checked.
 * @param [out]    ptr_is_exist    - Is exist flag.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_egr_intf_check(const uint32 unit,
                            const uint32 mcast_id,
                            const clx_l2_mcast_egr_intf_t egr_intf,
                            boolean *ptr_is_exist);

/**
 * @brief This API is used to add/set a L2 multicast MAC address entry.
 *
 * If the multicast address entry does not exist, it will add the entry;
 * if the multicast address entry already exists, it will set the entry with user input
 * value.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_addr    - The L2 multicast address entry to be added/set.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_addr_add(const uint32 unit, const clx_l2_mcast_addr_t *ptr_addr);

/**
 * @brief This API is used to delete a L2 multicast address entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    bdid    - Bridge domain ID.
 * @param [in]    mac     - Mac address.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_addr_del(const uint32 unit, const clx_bridge_domain_t bdid, const clx_mac_t mac);

/**
 * @brief This API is used to get a L2 multicast address entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_addr    - The L2 multicast address entry to be obtained.
 *                               User should only fill the key fields "bdid" and "mac".
 *                               The other fields will be ignored.
 * @param [out]    ptr_addr    - The full filled L2 multicast address entry obtained.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_addr_get(const uint32 unit, clx_l2_mcast_addr_t *ptr_addr);

/**
 * @brief This API is used to traverse all the L2 multicast MAC address entries,
 *        and handle it by user's callback.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     mode              - The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 * @param [in]     ptr_match_addr    - Specify the values of matched fields used to perform.
 * @param [in]     callback          - The callback function to be called when each L2 multicast
 *                                     address entry is traversed.
 * @param [in]     ptr_cookie        - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie        - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_mcast_addr_trav(const uint32 unit,
                       const clx_l2_entry_trav_mode_t mode,
                       const clx_l2_mcast_addr_trav_match_t *ptr_match_addr,
                       const clx_l2_mcast_addr_trav_func_t callback,
                       void *ptr_cookie);

/**
 * @brief This API is used to create l2 ecmp port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_ecmp_info    - The l2 ecmp info.
 * @param [out]    ptr_ecmp_port    - The l2 ecmp port obtained.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_ecmp_grp_add(const uint32 unit, clx_l2_ecmp_grp_t *ptr_ecmp_info, clx_port_t *ptr_ecmp_port);

/**
 * @brief This API is used to del l2 ecmp port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ecmp_port    - The l2 ecmp port.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_ecmp_grp_del(const uint32 unit, const clx_port_t ecmp_port);

/**
 * @brief This API is used to get l2 ecmp port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ecmp_port        - The l2 ecmp port.
 * @param [out]    ptr_ecmp_info    - The l2 ecmp info obtained.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_ecmp_grp_get(const uint32 unit,
                    const clx_port_t ecmp_port,
                    clx_l2_ecmp_grp_t *ptr_ecmp_info);

/**
 * @brief This API is used to add l2 ecmp path and only support tunnel port now.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ecmp_port        - The l2 ecmp port.
 * @param [in]    ptr_path_info    - The l2 ecmp path info.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_ecmp_path_add(const uint32 unit,
                     const clx_port_t ecmp_port,
                     const clx_l2_ecmp_path_t *ptr_path_info);

/**
 * @brief This API is used to del l2 ecmp path.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ecmp_port        - The l2 ecmp port.
 * @param [in]    ptr_path_info    - The l2 ecmp path info.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_ecmp_path_del(const uint32 unit,
                     const clx_port_t ecmp_port,
                     const clx_l2_ecmp_path_t *ptr_path_info);

/**
 * @brief This API is used to get l2 ecmp path by idx.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ecmp_port        - The l2 ecmp port.
 * @param [in]     path_idx         - The l2 ecmp path index.
 * @param [out]    ptr_path_info    - The l2 ecmp path info.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_ecmp_path_get_by_idx(const uint32 unit,
                            const clx_port_t ecmp_port,
                            const uint32 path_idx,
                            clx_l2_ecmp_path_t *ptr_path_info);

/**
 * @brief This API is used to set l2 ecmp set path offset.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    ecmp_port            - The l2 ecmp port.
 * @param [in]    ptr_hash_val_list    - Hash value list.
 * @param [in]    hash_val_cnt         - Total hash value count.
 * @param [in]    ptr_path_info        - The l2 ecmp path info.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_ecmp_path_hsh_set(const uint32 unit,
                         const clx_port_t ecmp_port,
                         uint32 *ptr_hash_val_list,
                         const uint32 hash_val_cnt,
                         const clx_l2_ecmp_path_t *ptr_path_info);

/**
 * @brief This API is used to get l2 ecmp path offset.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                       - Device unit number.
 * @param [in]     ecmp_port                  - The l2 ecmp port.
 * @param [in]     hash_val_cnt               - Total hash value count.
 * @param [in]     ptr_path_info              - The l2 ecmp path info.
 * @param [out]    ptr_hash_val_list          - Hash value list.
 * @param [out]    ptr_actual_hash_val_cnt    - Actual hash value count.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_l2_ecmp_path_hsh_get(const uint32 unit,
                         const clx_port_t ecmp_port,
                         const uint32 hash_val_cnt,
                         const clx_l2_ecmp_path_t *ptr_path_info,
                         uint32 *ptr_hash_val_list,
                         uint32 *ptr_actual_hash_val_cnt);
#endif /* End of CLX_L2_H */
