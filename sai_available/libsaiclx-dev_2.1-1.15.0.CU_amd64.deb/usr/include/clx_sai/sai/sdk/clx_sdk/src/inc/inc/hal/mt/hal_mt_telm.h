/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_telm.h
 * PURPOSE:
 *    Provide HAL driver API functions for NB.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_TELM_H
#define HAL_MT_TELM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_telm.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_TELM_INT_LFSR_IDX_OFFSET             (8)
#define HAL_MT_TELM_INT_PROFILE_NUM                 (8)
#define HAL_MT_TELM_TYPE_NUM                        (3)
#define HAL_MT_TELM_SAMPLER_THRESHOLD_DEFAULT_VALUE (0)
#define HAL_MT_TELM_SAMPLER_VALUE_DEFAULT_VALUE     (0xDEADBEEF)
#define HAL_MT_TELM_SAMPLER_TAPS_DEFAULT_VALUE      (0x80200003)
#define HAL_MT_TELM_INT_INSTR_BMP_DEFAULT_VALUE     (0)
#define HAL_MT_TELM_INT_CUD_ENTRY_NUM               (50)
#define HAL_MT_TELM_ROLE_TBL_PORT_NUM               (16)
#define HAL_MT_TELM_IS_EDGE_TBL_DI_NUM              (32)
#define HAL_MT_TELM_INSTR_MASK_DEFAULT_VALUE        (0xFFFE)
#define HAL_MT_TELM_INT_REPORT_DEFAULT_DI           (HAL_MT_BLACKHOLE_DI)
#define HAL_MT_TELM_HW_ID_MAX_VALUE                 (0x3F)
#define HAL_MT_TELM_TNL_REPORT_INDEX_INT(unit)      (HAL_LCL_INTF_GRP_ID_TNL_MAX_NUM(unit) - 2)
#define HAL_MT_TELM_TNL_REPORT_INDEX_MOD(unit)      (HAL_LCL_INTF_GRP_ID_TNL_MAX_NUM(unit) - 1)
#define HAL_MT_TELM_MOD_BLOOM_CLK_TO_NS(unit)       (1000.0 / HAL_DEVICE_FREQ(unit))
#define HAL_MT_TELM_MOD_BLOOM_TIMER_MAX_NS(unit) \
    ((uint32)(0xFFFFFFFF / HAL_DEVICE_FREQ(unit)) * 1000)
#define HAL_MT_TELM_MOD_BLOOM_TH_MAX (1023)
#define HAL_MT_TELM_MOD_BLOOM_TIMER_DFLT(unit) \
    (HAL_DEVICE_FREQ(unit) * 1000000) /* 1s at device frequency */
#define HAL_MT_TELM_MOD_BLOOM_TH_DFLT  (0x300)
#define HAL_MT_TELM_MOD_DELETE_PORT_OQ (4095)

#define HAL_MT_TELM_REP_O_CUD_OFFSET (1)
#define HAL_MT_TELM_REP_C_ACT_OFFSET (6)
#define HAL_MT_TELM_REP_C_CUD_OFFSET (7)
#define HAL_MT_TELM_REP_R_ACT_OFFSET (12)
#define HAL_MT_TELM_REP_R_CUD_OFFSET (13)

#define HAL_MT_TELM_REP_O_ACT_FIELD_ID (0)
#define HAL_MT_TELM_REP_O_CUD_FIELD_ID (1)
#define HAL_MT_TELM_REP_C_ACT_FIELD_ID (2)
#define HAL_MT_TELM_REP_C_CUD_FIELD_ID (3)
#define HAL_MT_TELM_REP_R_ACT_FIELD_ID (4)
#define HAL_MT_TELM_REP_R_CUD_FIELD_ID (5)

#define HAL_MT_TELM_INT_IDENTS                                                    \
    (CLX_TELM_INT_DOMAIN_ATTR_IDENT_GENEVE | CLX_TELM_INT_DOMAIN_ATTR_IDENT_GRE | \
     CLX_TELM_INT_DOMAIN_ATTR_IDENT_VXLAN | CLX_TELM_INT_DOMAIN_ATTR_IDENT_TCP |  \
     CLX_TELM_INT_DOMAIN_ATTR_IDENT_UDP)
#define HAL_MT_TELM_IOAM_FIFO_NOTIFY_MUTEX_SEMA_NAME ("IOAM_FIFO_NOTIFY_MUTEX_SEMA")
#define HAL_MT_TELM_IOAM_FIFO_TASK_NAME              ("IOAM_FIFO_TASK")
#define HAL_MT_TELM_IOAM_FIFO_DMA_ENTRY_NUM \
    (32 * 1024) /* FIFO entry dma size is 256b in 2^N unit. */
#define HAL_MT_TELM_IOAM_MAX_RING_BUF_ENTRY_NUM      (65535)
#define HAL_MT_TELM_IOAM_FIFO_UPLOAD_SEQ_NUM_BASE    (0)
#define HAL_MT_TELM_IOAM_STATS_FIFO_THRESHOLD_COUNT  (0x20)
#define HAL_MT_TELM_IOAM_STATS_FIFO_ALM_FULL_DEFAULT (0X4)
#define HAL_MT_TELM_IOAM_STATS_FIFO_TIMEOUT_DEFAULT(unit) \
    (HAL_DEVICE_FREQ(unit) * 1000 * 10) /* 10ms, unit is 1/1.35Ghz */
#define HAL_MT_TELM_IOAM_CFG_FWR_SAMPLE_INTERVAL_DEFAULT (0x1000)

#define HAL_MT_TELM_IOAM_CFG_IP_PROTOCOL  (0xba) /* identify ioam header protocol for ipv4 */
#define HAL_MT_TELM_IFA_IP_PROTOCOL       (0x83) /* identify ifa header protocol for ipv4 */
#define HAL_MT_TELM_IOAM_CFG_HBH_OPT_TYPE (0x11) /* identify ioam header protocol for ipv6 */
#define HAL_MT_TELM_IOAM_CFG_HBH_OPT_TYPE_MASK \
    (0x1f) /* mask opt type, fix to 0x1f, not expose to user to set */

#define HAL_MT_TELM_IOAM_STATS_FIFO_READ_PTR_UPDATE_THRESHOLD \
    (HAL_MT_TELM_IOAM_STATS_FIFO_THRESHOLD_COUNT)
#define HAL_MT_TELM_IOAM_FIFO_ENTRY_BYTES \
    (MT_NB_CDB_RWI_SLV_IOAM_STATS_FIFO_WORDS * HAL_BYTES_OF_WORD)

#define HAL_MT_TELM_IOAM_FIFO_TASK_SLEEP_USEC (10 * 1000)
#define HAL_MT_TELM_IOAM_FIFO_TASK_SLEEP_TH_ENTRY_NUM \
    (HAL_MT_TELM_IOAM_STATS_FIFO_READ_PTR_UPDATE_THRESHOLD * 256)

#define HAL_MT_TELM_TM_LUT_ENTRY_PER_LC_MAX_NUM (25)

#define HAL_MT_TELM_RWI_MOD_RPT_CFG_DEFAULT_TNL_IDX  (0x1ffe)
#define HAL_MT_TELM_RWI_MOD_RPT_CFG_DEFAULT_INTR_BMP (0xEF81)

#define HAL_MT_TELM_IOAM_FIFO_CHANNEL_NUM (19)
#define HAL_MT_TELM_IOAM_FIFO_CHANNEL_BMP (1 << HAL_MT_TELM_IOAM_FIFO_CHANNEL_NUM)
/* CH19_CLR/MASk offset bit is 17 */
#define HAL_MT_TELM_IOAM_FIFO_CHANNEL_CLR_BMP (1 << 17)

/* TODO: temp define here. interface.h */
#define HAL_MT_TELM_IFMON_ETH_LANE_NUM_PER_SLICE (32)
#define HAL_MT_TELM_IFMON_SLICE_NUM              (8)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_MT_TELM_CHECK_RC_RETURN(rc, module, level, format, arg...)  \
    do {                                                                \
        if (rc != CLX_E_OK) {                                           \
            UTIL_LOG_PRINT(module, level, "rc:%u, " format, rc, ##arg); \
            return rc;                                                  \
        }                                                               \
    } while (0);

#define HAL_MT_TELM_CHECK_RC_NOT_RETURN(rc, module, level, format, arg...) \
    do {                                                                   \
        if (rc != CLX_E_OK) {                                              \
            UTIL_LOG_PRINT(module, level, "rc:%u, " format, rc, ##arg);    \
        }                                                                  \
    } while (0);

#define HAL_MT_TELM_TOB_WRITE_PSR_SLV_ENTRY(__unit__, __inst_idx__, __subinst_idx__, __table_id__, \
                                            __entry_idx__, __ptr_entry__)                          \
    ({                                                                                             \
        TOB_CHIP_INFO_SET(chip_info, unit, __inst_idx__, __subinst_idx__);                         \
        TOB_ENTRY_INFO_SET(tob_entry_info, MT_NB_REG_TDS_PSR_SLV_##__table_id__, 0, __entry_idx__, \
                           1, NULL, __ptr_entry__);                                                \
        rc += tob_entry_write(chip_info, &tob_entry_info);                                         \
        TOB_ENTRY_INFO_SET(tob_entry_info, MT_NB_REG_DIS_PSR_SLV_##__table_id__, 0, __entry_idx__, \
                           1, NULL, __ptr_entry__);                                                \
        rc += tob_entry_write(chip_info, &tob_entry_info);                                         \
        TOB_ENTRY_INFO_SET(tob_entry_info, MT_NB_REG_RWI_PSR_SLV_INNER_##__table_id__, 0,          \
                           __entry_idx__, 1, NULL, __ptr_entry__);                                 \
        rc += tob_entry_write(chip_info, &tob_entry_info);                                         \
        TOB_ENTRY_INFO_SET(tob_entry_info, MT_NB_REG_RWI_PSR_SLV_OUTER_##__table_id__, 0,          \
                           __entry_idx__, 1, NULL, __ptr_entry__);                                 \
        rc += tob_entry_write(chip_info, &tob_entry_info);                                         \
    })

#define HAL_MT_TELM_TM_LUT_ENTRY_PACK(r_cud, r_act, c_cud, c_act, o_cud, o_act)          \
    ((r_cud << HAL_MT_TELM_REP_R_CUD_OFFSET) | (r_act << HAL_MT_TELM_REP_R_ACT_OFFSET) | \
     (c_cud << HAL_MT_TELM_REP_C_CUD_OFFSET) | (c_act << HAL_MT_TELM_REP_C_ACT_OFFSET) | \
     (o_cud << HAL_MT_TELM_REP_O_CUD_OFFSET) | o_act)

/* DATA TYPE DECLARATIONS
 */

typedef struct hal_mt_telm_prof_tbl_fld_s {
    uint32 lfsr_tbl_id;
    uint32 lfsr_fld;
    uint32 instr_tbl_id;
    uint32 instr_fld;
} hal_mt_telm_prof_tbl_fld_t;

typedef enum hal_mt_telm_cud_type_e {
    HAL_MT_TELM_CUD_UC = 0x0,
    HAL_MT_TELM_CUD_MC,
    HAL_MT_TELM_CUD_MIR,
    HAL_MT_TELM_CUD_CPU,
    HAL_MT_TELM_CUD_MOD,
    HAL_MT_TELM_CUD_INT_ENCAP_SHIM, // 5
    HAL_MT_TELM_CUD_INT_DECAP_SHIM,
    HAL_MT_TELM_CUD_INT_ENCAP_SHIM_META,
    HAL_MT_TELM_CUD_INT_ENCAP_META,
    HAL_MT_TELM_CUD_INT_DECAP_SHIM_META, // 9
    HAL_MT_TELM_CUD_INT_ENCAP_REPORT,    // a
    HAL_MT_TELM_CUD_INT_ENCAP_SHIM_TRUNC,
    HAL_MT_TELM_CUD_INT_ENCAP_SHIM_META_TRUNC,
    HAL_MT_TELM_CUD_INT_NO_DECAP_TRUNC,
    HAL_MT_TELM_CUD_INT_MASK,
    HAL_MT_TELM_CUD_INT_DECAP_SHIM_AND_MASK,
    HAL_MT_TELM_CUD_LAST
} hal_mt_telm_cud_type_t;

/*
 * INT LUT ENTRY
 * % # [17:13]  int_r_cud - INT report CUD type
 * % # [12]     int_r_act - INT report action
 * % # [11:07]  int_c_cud - INT clone  CUD type
 * % # [06]     int_c_act - INT clone  action
 * % # [05:01]  int_o_cud - INT origin CUD type
 * % # [00]     int_o_act - INT origin action
 */
typedef struct hal_mt_telm_lut_entry_s {
    boolean rep_o_act;
    hal_mt_telm_cud_type_t rep_o_cud;
    boolean rep_c_act;
    hal_mt_telm_cud_type_t rep_c_cud;
    boolean rep_r_act;
    hal_mt_telm_cud_type_t rep_r_cud;
} hal_mt_telm_lut_entry_t;

typedef struct hal_mt_telm_int_cb_s {
    uint32 sample_rate[HAL_MT_TELM_INT_PROFILE_NUM];
} hal_mt_telm_int_cb_t;

typedef enum hal_mt_telm_wbdb_e {
    HAL_MT_TELM_WBDB_MOD_GLB_EN,
    HAL_MT_TELM_WBDB_INT_CB,
    HAL_MT_TELM_WBDB_LAST
} hal_mt_telm_wbdb_t;

typedef struct hal_mt_telm_ioam_fifo_notify_handler_s {
    clx_telm_ioam_fifo_read_func_t callback;
    void *ptr_cookie;
} hal_mt_telm_ioam_fifo_notify_handler_t;

typedef struct hal_mt_telm_ioam_cb_s {
    /* ioam read fifo task thread */
    uint32 thread_pri;
    uint32 thread_stack_size;
    clx_thread_id_t thread_id;

    hal_mt_telm_ioam_fifo_notify_handler_t notify_handler;

    hal_intr_type_t intr_type;

    uint8 *ptr_ring_buf_start_not_align;
    uint8 *ptr_ring_buf_start;
    uint8 *ptr_ring_buf_desc_start_not_align;
    uint8 *ptr_ring_buf_desc_start;
    uint8 *ptr_ring_buf_nxt_read;
    uint32 ring_buf_entry_num;
    uint32 nxt_seq_num;

    /* new proc flow in NB. Use index instead of addr for ringbuf loop,
     record the last pop index (also the write pointer in LT), and compare it with the curr index,
     then read each fifo entry from dma. The maximum number of entries is the work index (the read
     pointer in LT). */
    uint32 next_read_index;
    uint32 work_index;
} hal_mt_telm_ioam_cb_t;

typedef struct hal_mt_telm_mod_cb_s {
    // clx_pkt_rx_reason_t rx_reason;
    uint32 mod_glb_en;
    uint32 out_port; /* user configed out port */
    uint32 queue_id; /* user configed queue id in per port */
} hal_mt_telm_mod_cb_t;

typedef struct hal_mt_telm_hop_cnt_zero_s {
    clx_telm_hop_cnt_zero_func_t callback;
    void *ptr_cookie;
} hal_mt_telm_hop_cnt_zero_t;

typedef struct hal_mt_telm_ifa_exceed_notify_handler_s {
    clx_telm_ifa_max_len_exceed_func_t callback;
    void *ptr_cookie;
} hal_mt_telm_ifa_exceed_notify_handler_t;

typedef struct hal_mt_telm_irq_cb_s {
    hal_mt_telm_hop_cnt_zero_t hop_cnt_zero_notify_handler;
    hal_mt_telm_ifa_exceed_notify_handler_t ifa_exceed_notify_handler;
} hal_mt_telm_irq_cb_t;

typedef struct hal_mt_telm_cb_s {
    hal_mt_telm_int_cb_t telm_int_cb;
    hal_mt_telm_ioam_cb_t telm_ioam_cb;
    hal_mt_telm_mod_cb_t telm_mod_cb;
    hal_mt_telm_irq_cb_t telm_irq_cb;
} hal_mt_telm_cb_t;

typedef struct hal_mt_telm_ioam_diag_reg_cfg_s {
    uint32 stats_fifo_threshold;
    uint32 stats_fifo_timeout_l;
    uint32 stats_fifo_timeout_h;
    uint32 fast_reload;
    uint32 color_switch_by_pkt;
    uint32 fifo_alm_full;
} hal_mt_telm_ioam_diag_reg_cfg_t;

typedef enum hal_mt_telm_rwi_port_speed_e {
    /* port speed. 0: 10G;  1: 25G; 2: 40G; 3: 50G; 4:100G; 5:200G; 6:400G */
    HAL_MT_TELM_RWI_PORT_SPEED_10G = 0,
    HAL_MT_TELM_RWI_PORT_SPEED_25G,
    HAL_MT_TELM_RWI_PORT_SPEED_40G,
    HAL_MT_TELM_RWI_PORT_SPEED_50G,
    HAL_MT_TELM_RWI_PORT_SPEED_100G,
    HAL_MT_TELM_RWI_PORT_SPEED_200G,
    HAL_MT_TELM_RWI_PORT_SPEED_400G,
    HAL_MT_TELM_RWI_PORT_SPEED_800G,
    HAL_MT_TELM_RWI_PORT_SPEED_LAST
} hal_mt_telm_rwi_port_speed_t;

typedef enum hal_mt_telm_trunc_type_e {
    HAL_MT_TELM_TRUNC_TYPE_INT, /* clone truncate for INT CUD types */
    HAL_MT_TELM_TRUNC_TYPE_MOD, /* clone truncate for MOD CUD type */
    HAL_MT_TELM_TRUNC_TYPE_LAST
} hal_mt_telm_trunc_type_t;

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

clx_error_no_t
hal_mt_telm_init(const uint32 unit);

clx_error_no_t
hal_mt_telm_deinit(const uint32 unit);

clx_error_no_t
hal_mt_telm_int_role_set(const uint32 unit, const uint32 port, const uint32 int_role);

clx_error_no_t
hal_mt_telm_int_role_get(const uint32 unit, const uint32 port, uint32 *ptr_int_role);

clx_error_no_t
hal_mt_telm_force_en_set(const uint32 unit, const uint32 port, const boolean enable);

clx_error_no_t
hal_mt_telm_force_en_get(const uint32 unit, const uint32 port, boolean *ptr_enable);

clx_error_no_t
hal_mt_telm_port_dci_set(const uint32 unit, const uint32 port, const boolean dci_en);

clx_error_no_t
hal_mt_telm_port_dci_get(const uint32 unit, const uint32 port, boolean *ptr_dci_en);

clx_error_no_t
hal_mt_telm_swc_cfg_set(const uint32 unit,
                        const clx_swc_cfg_t cfg,
                        const uint32 param0,
                        const uint32 param1);

clx_error_no_t
hal_mt_telm_swc_cfg_get(const uint32 unit,
                        const clx_swc_cfg_t cfg,
                        uint32 *ptr_param0,
                        uint32 *ptr_param1);

clx_error_no_t
hal_mt_telm_notify_cb_register(const uint32 unit,
                               const clx_telm_irq_type_t irq_type,
                               const void *callback,
                               void *ptr_cookie);

clx_error_no_t
hal_mt_telm_notify_cb_deregister(const uint32 unit,
                                 const clx_telm_irq_type_t irq_type,
                                 const void *callback,
                                 void *ptr_cookie);

clx_error_no_t
hal_mt_telm_cfg_set(const uint32 unit,
                    const clx_telm_cfg_t cfg,
                    const clx_telm_cfg_param_t *ptr_param);

clx_error_no_t
hal_mt_telm_cfg_get(const uint32 unit, const clx_telm_cfg_t cfg, clx_telm_cfg_param_t *ptr_param);

/* ========================= INT api list =========================== */

clx_error_no_t
hal_mt_telm_int_prof_set(const uint32 unit,
                         const uint32 profile_id,
                         const clx_telm_int_prof_t *ptr_profile_cfg);

clx_error_no_t
hal_mt_telm_int_prof_get(const uint32 unit,
                         const uint32 profile_id,
                         clx_telm_int_prof_t *ptr_profile_cfg);

clx_error_no_t
hal_mt_telm_int_glb_set(const uint32 unit,
                        const clx_telm_int_domain_t *ptr_domain_cfg,
                        const clx_telm_int_device_t *ptr_device_cfg);

clx_error_no_t
hal_mt_telm_int_glb_get(const uint32 unit,
                        clx_telm_int_domain_t *ptr_domain_cfg,
                        clx_telm_int_device_t *ptr_device_cfg);

/* ========================= IOAM api list =========================== */

clx_error_no_t
hal_mt_telm_ioam_cfg_set(const uint32 unit, const clx_telm_ioam_cfg_t *ptr_ioam_cfg);

clx_error_no_t
hal_mt_telm_ioam_cfg_get(const uint32 unit, clx_telm_ioam_cfg_t *ptr_ioam_cfg);

clx_error_no_t
hal_mt_telm_ioam_diag_cfg_get(uint32 unit, hal_mt_telm_ioam_diag_reg_cfg_t *ptr_ioam_diag_reg);

/* ========================= IFA api list =========================== */

clx_error_no_t
hal_mt_telm_ifa_cfg_set(const uint32 unit, const clx_telm_ifa_cfg_t *ptr_ifa_cfg);

clx_error_no_t
hal_mt_telm_ifa_cfg_get(const uint32 unit, clx_telm_ifa_cfg_t *ptr_ifa_cfg);

/* ========================= ＭOD api list =========================== */

clx_error_no_t
hal_mt_telm_mod_cfg_get(const uint32 unit, clx_telm_mod_cfg_t *ptr_mod_cfg);

clx_error_no_t
hal_mt_telm_mod_cfg_set(const uint32 unit, const clx_telm_mod_cfg_t *ptr_mod_cfg);

clx_error_no_t
hal_mt_telm_collector_set(const uint32 unit,
                          const clx_telm_collector_type_t collector_type,
                          const clx_telm_collector_cfg_info_t *ptr_clct_cfg_info);

clx_error_no_t
hal_mt_telm_collector_get(const uint32 unit,
                          const clx_telm_collector_type_t collector_type,
                          clx_telm_collector_cfg_info_t *ptr_clct_cfg_info);

clx_error_no_t
hal_mt_telm_ioam_diag_cfg_set(uint32 unit, hal_mt_telm_ioam_diag_reg_cfg_t *ptr_ioam_diag_reg);

clx_error_no_t
hal_mt_telm_port_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

clx_error_no_t
hal_mt_telm_mod_reg_set(const uint32 unit, const clx_telm_mod_cfg_t *ptr_mod_cfg);

clx_error_no_t
hal_mt_telm_mod_reg_get(const uint32 unit, clx_telm_mod_cfg_t *ptr_mod_cfg);

/**
 * @brief Port link change notify MOD to modify oq. Only support cpu or eth port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Cl port.
 * @param [in]    drop    - Link status is down, oq set at del port, in order to drop.
 * @return        CLX_E_OK    - Operate success.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_telm_mod_link_chg_ntf(const uint32 unit, const uint32 port, const boolean drop);

#endif /* End of HAL_MT_TELM_H */
