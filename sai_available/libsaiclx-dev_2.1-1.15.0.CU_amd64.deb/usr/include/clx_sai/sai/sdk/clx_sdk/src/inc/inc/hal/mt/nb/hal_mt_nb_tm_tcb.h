/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_nb_tm_tcb.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_MT_NB_TM_TCB_H
#define HAL_MT_NB_TM_TCB_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_init.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>
#include <clx/clx_tm.h>

typedef enum hal_mt_nb_tm_tcb_tbl_id_e {
    HAL_MT_NB_TM_TCB_IPP2PDBWR_TBL_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_TBL_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_TBL_ID,
    HAL_MT_NB_TM_TCB_LAST_TBL_ID
} hal_mt_nb_tm_tcb_tbl_id_t;

typedef enum hal_mt_nb_tm_tcb_pdbrd2epp_field_id_e {
    HAL_MT_NB_TM_TCB_PDBRD2EPP_FD_PD_FIFO_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_FD_DPORT_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_FD_ERROR_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_FD_FRAG_SIZE_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_FD_EOP_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_FD_SOP_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_FD_RSVD_FD_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_PD_TRUNC_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_PD_CPA_MARK_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_PD_ECN_MARK_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_PD_CUD_VALUE_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_PD_CUD_TYPE_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_PD_OQ_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_PD_PKT_SIZE_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_PD_RSVD_PD_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_VALID_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_RESERVED_FIELD_ID,
    HAL_MT_NB_TM_TCB_PDBRD2EPP_LAST_FIELD_ID
} hal_mt_nb_tm_tcb_pdbrd2epp_field_id_t;

typedef enum hal_mt_nb_tm_tcb_ipp2pdbwr_field_id_e {
    HAL_MT_NB_TM_TCB_IPP2PDBWR_FD_DROP_REASON_CODE_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_FD_SPORT_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_FD_RCV_VLD_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_FD_FRAG_SIZE_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_FD_EOP_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_FD_SOP_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_FD_RSVD_FD_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_PKJ_JOURNAL_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_METER_COLOR_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_FLOW_HASH_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_CPA_EN_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_ACL_REDIRECT_TRUNC_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_MOD_EN_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_MIRROR_SESSION_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_PKT_SIZE_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_CT_MODE_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_CPU_QID_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_CPU_DEST_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_CPU_REDIR_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_CPU_VALID_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_TC_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_INT_CLONE_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_INT_MODE_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_INT_ROLE_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_DI_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_PD_RSVD_PD_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_VALID_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_RESERVED_FIELD_ID,
    HAL_MT_NB_TM_TCB_IPP2PDBWR_LAST_FIELD_ID
} hal_mt_nb_tm_tcb_ipp2pdbwr_field_id_t;

clx_error_no_t
hal_mt_nb_tm_tcb_init(const uint32 unit);

void
hal_mt_nb_tm_tcb_sw_pkt_buf_show(const uint32 unit);

void
hal_mt_nb_tm_tcb_sw_trigger_data_show(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_tcb_hw_status_show(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_tcb_match_set(const uint32 unit,
                           const clx_tm_tcb_match_type_t type,
                           const clx_tm_tcb_match_t *ptr_match);

clx_error_no_t
hal_mt_nb_tm_tcb_match_get(const uint32 unit,
                           const clx_tm_tcb_match_type_t type,
                           clx_tm_tcb_match_t *ptr_match);

clx_error_no_t
hal_mt_nb_tm_tcb_cfg_set(const uint32 unit, const clx_tm_tcb_cfg_type_t type, const uint32 value);

clx_error_no_t
hal_mt_nb_tm_tcb_cfg_get(const uint32 unit, const clx_tm_tcb_cfg_type_t type, uint32 *ptr_value);

clx_error_no_t
hal_mt_nb_tm_tcb_cb_register(const uint32 unit, const clx_tm_tcb_func_t func, void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tm_tcb_cb_deregister(const uint32 unit, const clx_tm_tcb_func_t func, void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tm_tcb_rsrc_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_tcb_rsrc_deinit(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_tcb_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_tcb_wb_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

#endif /* End of HAL_MT_NB_TM_TCB_H */