/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_tm.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_TM_H
#define HAL_TM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_init.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>
#include <clx/clx_mir.h>
#include <clx/clx_tm.h>
#include <osal/osal_timer.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* front port num + pcie + 2 cpi + 2 rc */
#define HAL_TM_HW_PORT_NUM (HAL_PORT_NUM_MAX + 1 + 2 + 2)

/*#define HAL_TM_DEBUG_PRINTF_EABLED*/
/*high 4 bit(bit[31:28]) means object type*/
#define HAL_TM_HANDLER_TYPE_SHIFT (28)

/* queue num*/
#define HAL_TM_CPU_QUEUE_NUM       (48)
#define HAL_TM_UNICAST_QUEUE_NUM   (8)
#define HAL_TM_MULTICAST_QUEUE_NUM (8)
#define HAL_TM_LEGACY_QUEUE_NUM    (8)
#define HAL_TM_CPI_QUEUE_NUM       (8)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TM_MISC_LOCK(unit)   (hal_tm_misc_rsrc_lock(unit))
#define HAL_TM_MISC_UNLOCK(unit) (hal_tm_misc_rsrc_unlock(unit))

#define HAL_TM_HANDLER_SET(handler, type, id) \
    ((handler) = ((type) << HAL_TM_HANDLER_TYPE_SHIFT) + (id))

#define HAL_TM_HANDLER_GET(handler, type, id)                         \
    do {                                                              \
        (type) = ((handler) >> HAL_TM_HANDLER_TYPE_SHIFT);            \
        (id) = ((handler) & ((1U << HAL_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while (0)

#define HAL_TM_HANDLER_ID_GET(handler, id)                            \
    do {                                                              \
        (id) = ((handler) & ((1U << HAL_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while (0)

/* handler id valid check*/
#define HAL_TM_UNICAST_QUEUE_HANDLER_ID_VALID(id) (((id) >= 0) && ((id) < HAL_TM_UNICAST_QUEUE_NUM))

#define HAL_TM_CPU_QUEUE_HANDLER_ID_VALID(id) ((id) < HAL_TM_CPU_QUEUE_NUM)

#define HAL_TM_LEGACY_QUEUE_HANDLER_ID_VALID(id) (((id) >= 0) && ((id) < HAL_TM_LEGACY_QUEUE_NUM))

/*check macro*/
#define HAL_TM_CHECK_MIN_MAX_RANGE(__value__, __min__, __max__) \
    (((__value__) > (__max__)) || ((__value__) < (__min__)))

#define HAL_TM_CHECK_MAX_RANGE(__value__, __max__) ((__value__) > (__max__))

/* PFCWD Task */
#define HAL_TM_PFCWD_DFLT_INTERVAL_MS (10) // Defaule 10ms
#define HAL_TM_PFCWD_STACK_SIZE       (64 * 1024)
#define HAL_TM_PFCWD_SEM_NAME         ("TM_PFCWD")
#define HAL_TM_PFCWD_TASK_NAME        ("PFCWD_TASK")
#define HAL_TM_PFCWD_THREAD_PRI       (10)
#define HAL_TM_PFCWD_CB_NUM           (3)
#define HAL_TM_PFCWD_PFC_PRI_NUM      (8)

#define HAL_TM_ERROR_RETURN(module, rc, fmt, args...)                                            \
    {                                                                                            \
        if (CLX_E_OK != rc) {                                                                    \
            UTIL_LOG_PRINT(module, UTIL_LOG_ERR, "[error:%s-%d]:" fmt, clx_error_string_get(rc), \
                           rc, ##args);                                                          \
            return rc;                                                                           \
        }                                                                                        \
    }

#define HAL_TM_ERROR_NO_RETURN(module, rc, fmt, args...)                                         \
    {                                                                                            \
        if (CLX_E_OK != rc) {                                                                    \
            UTIL_LOG_PRINT(module, UTIL_LOG_ERR, "[error:%s-%d]:" fmt, clx_error_string_get(rc), \
                           rc, ##args);                                                          \
        }                                                                                        \
    }

#define HAL_TM_ERROR_GOTO_LABEL(module, rc, label, fmt, args...)                                 \
    {                                                                                            \
        if (CLX_E_OK != rc) {                                                                    \
            UTIL_LOG_PRINT(module, UTIL_LOG_ERR, "[error:%s-%d]:" fmt, clx_error_string_get(rc), \
                           rc, ##args);                                                          \
            goto label;                                                                          \
        }                                                                                        \
    }

/* DATA TYPE DECLARATIONS
 */

/* Port Speed */
/* Please check HW define for all speed setting when add other speed*/
typedef enum hal_tm_port_speed_e {
    HAL_TM_PORT_SPEED_1G = 0,
    HAL_TM_PORT_SPEED_10G,
    HAL_TM_PORT_SPEED_25G,
    HAL_TM_PORT_SPEED_40G,
    HAL_TM_PORT_SPEED_50G,
    HAL_TM_PORT_SPEED_100G,
    HAL_TM_PORT_SPEED_200G,
    HAL_TM_PORT_SPEED_400G,
    HAL_TM_PORT_SPEED_800G,
    HAL_TM_PORT_SPEED_LAST
} hal_tm_port_speed_t;

typedef enum hal_tm_pfcwd_event_e {
    HAL_TM_PFCWD_EVENT_ENABLE, /* Feature turn to enable */
    HAL_TM_PFCWD_EVENT_DISABLE,
    HAL_TM_PFCWD_EVENT_DETECTED,
    HAL_TM_PFCWD_EVENT_RECOVER_TIMEOUT,
    HAL_TM_PFCWD_EVENT_CONFIG_CHANGE, /* Already Enabled but configure change */
    HAL_TM_PFCWD_EVENT_PFC_MAP_CHANGED,
    HAL_TM_PFCWD_EVENT_WARM_DEINIT,   /* Warmboot deinit, restore to oper state */
    HAL_TM_PFCWD_EVENT_LAST
} hal_tm_pfcwd_event_t;

/*control block for misc module*/
typedef struct hal_tm_misc_cb_s {
    clx_semaphore_id_t misc_sema; /*semaphore for misc module*/
} hal_tm_misc_cb_t;

typedef struct hal_tm_pfcwd_timer_entry_s {
    uint32 unit;
    uint32 port;
    uint8 queue_id;
} hal_tm_pfcwd_timer_entry_t;

typedef struct hal_tm_pfcwd_asyn_event_s {
    uint32 unit;
    uint32 port;
    uint8 queue_id;
    hal_tm_pfcwd_event_t event;
    uint32 arg;
} hal_tm_pfcwd_asyn_event_t;

typedef struct hal_tm_pfcwd_queue_entry_s {
    boolean enable;
    uint8 queue;
    uint8 reg_member_idx;
    clx_tm_pfcwd_state_t state;
    uint32 detection_time;
    uint32 recovery_time;
    clx_tm_pfcwd_action_t action;
    uint32 rx_pfc_pri_mapping;
    clx_port_fc_dir_t old_mac_pfc_config[HAL_TM_PFCWD_PFC_PRI_NUM];
    osal_timer_id_t timerid;
    hal_tm_pfcwd_timer_entry_t *restore_timer_entry; /* arg for timeout, need free when timeout or
                                                        timer stop*/
} hal_tm_pfcwd_queue_entry_t;

typedef struct hal_tm_pfcwd_port_entry_s {
    clx_semaphore_id_t sem;
    uint8 supported_pfc_num;
    hal_tm_pfcwd_queue_entry_t *queue_entry;
} hal_tm_pfcwd_port_entry_t;

typedef struct hal_tm_pfcwd_callback_s {
    clx_tm_pfcwd_handle_func_t callback;
    void *ptr_cookie;
} hal_tm_pfcwd_callback_t;

typedef struct hal_tm_task_pfcwd_cb_s {
    clx_semaphore_id_t sem_pfcwd; // Protect callback_list, port entry also has it own lock.
    clx_thread_id_t task_id;
    uint32 interval;
    hal_tm_pfcwd_port_entry_t entry_array[HAL_PORT_NUM_MAX];
    hal_tm_pfcwd_callback_t callback_list[HAL_TM_PFCWD_CB_NUM];
} hal_tm_task_pfcwd_cb_t;

typedef enum hal_tm_trunc_type_e {
    HAL_TM_TRUNC_TYPE_MIRROR = 0,      /* mirror type */
    HAL_TM_TRUNC_TYPE_TOCPU,           /* to cpu type */
    HAL_TM_TRUNC_TYPE_MOD,             /* mod type */
    HAL_TM_TRUNC_TYPE_ENCAP_SHIM,      /* encap shim type */
    HAL_TM_TRUNC_TYPE_ENCAP_SHIM_META, /* encap shim meta type */
    HAL_TM_TRUNC_TYPE_NO_DECAP,        /* no decap type */
    HAL_TM_TRUNC_TYPE_CPA_MARK,        /* cpa(cut payload) mark type */
    HAL_TM_TRUNC_TYPE_ACL,             /* mirror type */
    HAL_TM_TRUNC_TYPE_LAST
} hal_tm_trunc_type_t;

typedef enum hal_tm_trunc_size_e {
    HAL_TM_TRUNC_SIZE_64 = 0, /* 64 bytes*/
    HAL_TM_TRUNC_SIZE_128,    /* 128 bytes */
    HAL_TM_TRUNC_SIZE_192,    /* 192 bytes */
    HAL_TM_TRUNC_SIZE_256,    /* 256 bytes */
    HAL_TM_TRUNC_SIZE_512,    /* 512 bytes */
    HAL_TM_TRUNC_SIZE_984,    /* 984 bytes */
    HAL_TM_TRUNC_SIZE_LAST
} hal_tm_trunc_size_t;

typedef struct hal_tm_trunc_prof_s {
    hal_tm_trunc_type_t trunc_type; /* truncation packet type */
    uint32 prof_id;                 /* truncation profile index*/
    hal_tm_trunc_size_t trunc_size; /* packet truncation size*/
                                    /* only support 64/128/192/256/512/1024 byte*/
    boolean enable;                 /* the prof_id prof enable or disable truncation function*/
} hal_tm_trunc_prof_t;

typedef struct hal_tm_trunc_cfg_s {
    hal_tm_trunc_type_t trunc_type; /* truncation packet type */
    clx_mir_direct_t dir;           /* type is mirror to use, mirror direction*/
    uint32 session_id;              /* type is mirror to use, mirror session*/
    uint32 cpu_queue_id;            /* type is toCpu to use, cpu queueu id*/
    uint32 prof_id;                 /* truncation prof index*/
} hal_tm_trunc_cfg_t;

typedef struct hal_tm_tcb_trigger_igr_data_s {
    uint32 valid;                 /* valid, 1 bit */
    uint32 di;                    /* di, 16 bits */
    uint32 int_role;              /* INT role, 2 bits */
    uint32 int_mode;              /* IMT mode, 2 bit */
    uint32 int_clone;             /* IMT clone, 1 bit */
    uint32 tc;                    /* tc, 2 bits */
    uint32 cpu_valid;             /* cpu valid, 1 bit */
    uint32 cpu_redir;             /* cpu redirect, 1 bit */
    uint32 cpu_dest;              /* cpu dest, 2 bit */
    uint32 cpu_queue;             /* cpu queue id, 6 bit */
    uint32 ct_mode;               /* cut through mode, 1 bit */
    uint32 pkt_size;              /* packet size, 14 bits */
    uint32 mirror_session;        /* mirror session id, 8 bits */
    uint32 mod_en;                /* Mod enable, 1 bit */
    uint32 acl_redirect_trunc_en; /* Acl redirect truncation enable, 1 bit */
    uint32 cpa_en;                /* CPU enable, 1 bit */
    uint32 flow_hash;             /* flow hash, 10 bit */
    uint32 meter_color;           /* meter color, 2 bit */
    uint32 pkj;                   /* pkj, 1 bit */
    uint32 sop;                   /* sop, 1 bit */
    uint32 eop;                   /* eop, 1 bit */
    uint32 frag_size;             /* frag size, 8 bit */
    uint32 rec_vld;               /* recive valid, 1 bit */
    uint32 sport;                 /* source port, cl port */
    uint32 drop_reason_code;      /* drop reason code, 6 bit*/
} hal_tm_tcb_trigger_igr_data_t;

typedef struct hal_tm_tcb_trigger_egr_data_s {
    uint32 valid;       /* valid, 1 bit */
    uint32 pkt_size;    /* packet size, 14 bits*/
    uint32 oq;          /* out queue, 12 bits */
    uint32 cud_type;    /* cud type, 5 bits */
    uint32 cud_value;   /* cud value, 16 bits */
    uint32 ecn_mark;    /* ecn mark, 1 bit */
    uint32 cpa_mark;    /* cpa mark, 1 bit */
    uint32 trunc;       /* truncation, 1 bit */
    uint32 sop;         /* sop, 1 bit */
    uint32 eop;         /* eop, 1 bit */
    uint32 frag_size;   /* frag size, 8 bit */
    uint32 error;       /* error flag, 1 bit */
    uint32 dport;       /* dest port, cl port */
    uint32 pd_fifo_num; /* pd fifo num, 2 bit */
} hal_tm_tcb_trigger_egr_data_t;

typedef struct hal_tm_tcb_capture_key_s {
#define HAL_TM_TCB_MATCH_TYPE_INGRESS (0)    /* TCB match ingress type */
#define HAL_TM_TCB_MATCH_TYPE_EGRESS  (1)    /* TCB match egress type */
    uint32 match_type;                       /* TCB match type */
    hal_tm_tcb_trigger_igr_data_t igr_match; /* ingress match key */
    hal_tm_tcb_trigger_igr_data_t igr_mask;  /* ingress match mask */
    hal_tm_tcb_trigger_egr_data_t egr_match; /* egress match key */
    hal_tm_tcb_trigger_egr_data_t egr_mask;  /* egress match mask */
} hal_tm_tcb_capture_key_t;

typedef enum hal_tm_elam_module_e {
    HAL_TM_ELAM_MODULE_ASM,        /* NB TM submodule ASM */
    HAL_TM_ELAM_MODULE_REP,        /* NB TM submodule REP */
    HAL_TM_ELAM_MODULE_BAC,        /* NB TM submodule BAC */
    HAL_TM_ELAM_MODULE_BAC_TOP,    /* NB TM submodule BAC_TOP */
    HAL_TM_ELAM_MODULE_OQC,        /* NB TM submodule OQC */
    HAL_TM_ELAM_MODULE_DQC,        /* NB TM submodule DQC */
    HAL_TM_ELAM_MODULE_DQC_TOP,    /* NB TM submodule DQC_TOP */
    HAL_TM_ELAM_MODULE_FRG,        /* NB TM submodule FRG */
    HAL_TM_ELAM_MODULE_PDB_CENTER, /* NB TM submodule PDB_CENTER */
    HAL_TM_ELAM_MODULE_LAST
} hal_tm_elam_module_t;

typedef struct hal_tm_elam_trigger_cfg_s {
    hal_tm_elam_module_t module; /* NB TM submodule */
    uint32 slice;                /* slice id or plane id */
    uint32 bus_sel;              /* bus select */
    uint32 count;                /* trigger count */
    boolean enable;              /* enable or disable trigger */
} hal_tm_elam_trigger_cfg_t;

typedef struct hal_tm_elam_trigger_data_s {
#define HAL_TM_ELAM_TRIGGER_DATA_SIZE (16)             /* ELAM trigger data length */
    uint8 trigger_data[HAL_TM_ELAM_TRIGGER_DATA_SIZE]; /* ELAM trigger data */
} hal_tm_elam_trigger_data_t;

typedef struct hal_tm_elam_capture_data_s {
    hal_tm_elam_trigger_data_t trigger_data; /* ELAM capture trigger data */
    uint64 timestamp;                        /* ELAM capture timestamp */
} hal_tm_elam_capture_data_t;

typedef struct hal_tm_elam_trigger_key_s {
    hal_tm_elam_trigger_data_t match; /* ELAM trigger math key */
    hal_tm_elam_trigger_data_t mask;  /* ELAM trigger math mask */
} hal_tm_elam_trigger_key_t;

clx_error_no_t
hal_tm_misc_rsrc_lock(const uint32 unit);

clx_error_no_t
hal_tm_misc_rsrc_unlock(const uint32 unit);

clx_error_no_t
hal_tm_misc_rsrc_init(const uint32 unit);

clx_error_no_t
hal_tm_misc_rsrc_deinit(const uint32 unit);

clx_error_no_t
hal_tm_rsrc_init(const uint32 unit);

clx_error_no_t
hal_tm_rsrc_deinit(const uint32 unit);

clx_error_no_t
hal_tm_cfg_set(const uint32 unit,
               const uint32 port,
               const clx_tm_handler_t handler,
               const clx_tm_cfg_t *ptr_cfg);

clx_error_no_t
hal_tm_cfg_get(const uint32 unit,
               const uint32 port,
               const clx_tm_handler_t handler,
               clx_tm_cfg_t *ptr_cfg);

clx_error_no_t
hal_tm_db_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_tm_reg_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_tm_pfcwd_port_rsrc_lock(const uint32 unit, const clx_port_t port);
clx_error_no_t
hal_tm_pfcwd_port_rsrc_unlock(const uint32 unit, const clx_port_t port);
clx_error_no_t
hal_tm_pfcwd_rsrc_lock(const uint32 unit);
clx_error_no_t
hal_tm_pfcwd_rsrc_unlock(const uint32 unit);
clx_error_no_t
hal_tm_pfcwd_task_rsrc_init(const uint32 unit);
clx_error_no_t
hal_tm_pfcwd_task_rsrc_deinit(const uint32 unit);
char *
hal_tm_pfcwd_event_str_get(const hal_tm_pfcwd_event_t event);
char *
hal_tm_pfcwd_state_str_get(const clx_tm_pfcwd_state_t state);

clx_error_no_t
hal_tm_pfcwd_task_ctrl_block_get(const uint32 unit, hal_tm_task_pfcwd_cb_t **pptr_cb);

clx_error_no_t
hal_tm_pfcwd_queue_entry_get(const uint32 unit,
                             const clx_port_t port,
                             const uint32 queue,
                             hal_tm_pfcwd_queue_entry_t **pptr_entry);

clx_error_no_t
hal_tm_pfcwd_cb_register(const uint32 unit,
                         const clx_tm_pfcwd_handle_func_t notify_function,
                         void *ptr_cookie);

clx_error_no_t
hal_tm_pfcwd_cb_deregister(const uint32 unit,
                           const clx_tm_pfcwd_handle_func_t notify_function,
                           void *ptr_cookie);

clx_error_no_t
hal_tm_pfcwd_state_event_handle(const uint32 unit,
                                const clx_port_t port,
                                const uint8 queue_id,
                                const hal_tm_pfcwd_event_t event,
                                const clx_tm_pfcwd_cfg_t *new_pfcwd_config);

/**
 * @brief This API is used to configure PFCWD on queue.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Physical port ID.
 * @param [in]    queue        - Queue ID.
 * @param [in]    ptr_entry    - PFCWD Configuration.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_tm_pfcwd_set(const uint32 unit,
                 const clx_port_t port,
                 const uint32 queue,
                 const clx_tm_pfcwd_cfg_t *ptr_entry);

/**
 * @brief This API is used to get current configuration of PFCWD.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [in]     queue        - Queue ID.
 * @param [out]    ptr_entry    - PFCWD Configuration.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_tm_pfcwd_get(const uint32 unit,
                 const clx_port_t port,
                 const uint32 queue,
                 clx_tm_pfcwd_cfg_t *ptr_entry);

/**
 * @brief This API is used to get current state of PFCWD.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port ID.
 * @param [in]     queue        - Queue ID.
 * @param [out]    ptr_state    - PFCWD Current State.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_tm_pfcwd_state_get(const uint32 unit,
                       const clx_port_t port,
                       const uint32 queue,
                       clx_tm_pfcwd_state_t *ptr_state);

void
hal_tm_pfcwd_cb_func_proc(const uint32 unit,
                          const clx_port_t port,
                          const uint8 queue,
                          const clx_tm_pfcwd_event_t pfcwd_event);

void
hal_tm_pfcwd_restore_timer_handle(void *arg);
#endif /* #ifndef HAL_TM_H */
