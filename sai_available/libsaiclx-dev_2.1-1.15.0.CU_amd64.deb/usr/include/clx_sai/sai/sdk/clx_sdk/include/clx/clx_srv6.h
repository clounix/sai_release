/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_srv6.h
 *
 * PURPOSE:
 *      It provides SRv6 module api.
 * NOTES:
 *
 */

#ifndef CLX_SRV6_H
#define CLX_SRV6_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <clx/clx_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_SRV6_FLAGS_WITH_ID (0x1U << 0) /* Use user input srv6_port to set parameter */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct clx_srv6_local_cfg_s {
    clx_ipv6_t src_ipv6;                    /* The source IP address of source node */
    uint32 underlay_vrf;                    /* Vrf id of the SRv6, default is zero */
    uint16 dflt_vid;                        /* Default vid */
    uint8 dflt_pcp;                         /* Default pcp */
    uint8 dflt_dei;                         /* Default dei */
    clx_vlan_tpid_t igr_tpid[CLX_PORT_INTF_TPID_MAX_NUM];
    clx_port_vlan_tag_mode_t vlan_tag_mode; /* VLAN tag mode */
    clx_qos_prof_t igr_qos;            /* ingress qos, including dscp-to-phb and dot1p-to-phb */
    uint16 dflt_bdid;                  /* if BD lookup miss, use default BD. */
    clx_sample_t sample;               /* Ingress Sampling */
    uint32 mir_session_bmp;            /* Mirror session ID bitmap */
    uint32 meter_id;                   /* Meter ID */
    uint32 cnt_id;                     /* Regular,Service counter ID */
    uint32 dist_cnt_id;                /* Distribution counter ID */
    uint16 l2_mtu;                     /* L2 mtu size */
    uint32 grp_lbl;                    /* Port ACL label label */
    clx_port_acpt_frm_type_t drop_pkt; /* Acceptable Frame Type */
    clx_sa_miss_rsn_t sa_rsn;          /* CLX_SA_MISS_RSN_0/1 */

    uint32 flags;                      /* Refer to CLX_SRV6_LOCAL_FLAGS_XXX */
    uint64 attr_bmp;                   /* Refer to CLX_SRV6_LOCAL_ATTR_XXX */
} clx_srv6_local_cfg_t;

#define CLX_SRV6_LOCAL_FLAGS_TRUST_VID       (0x1U << 0)    /* Trust vlan */
#define CLX_SRV6_LOCAL_FLAGS_TRUST_1P        (0x1U << 1)    /* Trust 802.1p */
#define CLX_SRV6_LOCAL_FLAGS_PRIO_TAG_ENABLE (0x1U << 2)    /* Accept priority tagged frame */
#define CLX_SRV6_LOCAL_FLAGS_NOT_ALLOW_CTAG                                                   \
    (0x1U << 3)                                             /* If packet is C-TAGGED only use \
                                                             * default vlan to forward        \
                                                             */
#define CLX_SRV6_LOCAL_FLAGS_USE_INNER_PHB                                                     \
    (0x1U << 4)                                             /* Use inner header QoS(DSCP/PCP/  \
                                                             * DEI) as traffic class and color \
                                                             * source                          \
                                                             */
#define CLX_SRV6_LOCAL_FLAGS_KEEP_INNER_QOS                                                  \
    (0x1U << 5)                                             /* Don't modify inner header QoS \
                                                             * (DSCP/PCP/DEI) value          \
                                                             */
#define CLX_SRV6_LOCAL_FLAGS_QOS_UNIFORM                                                      \
    (0x1U << 6)                                             /* QoS uniform mode,              \
                                                             * set CLX_SRV6_LOCAL_FLAGS_KEEP_ \
                                                             * INNER_QOS first                \
                                                             */
#define CLX_SRV6_LOCAL_FLAGS_TTL_UNIFORM       (0x1U << 7)  /* TTL uniform mode */
#define CLX_SRV6_LOCAL_FLAGS_IPV4_SRC_GUARD_EN (0x1U << 8)  /* IPv4 source guard enable */
#define CLX_SRV6_LOCAL_FLAGS_IPV6_SRC_GUARD_EN (0x1U << 9)  /* IPv6 source guard enable */
#define CLX_SRV6_LOCAL_FLAGS_METER_ID          (0x1U << 10) /* Apply meter */
#define CLX_SRV6_LOCAL_FLAGS_CNT_ID            (0x1U << 11) /* Apply counter */
#define CLX_SRV6_LOCAL_FLAGS_DIST_CNT_ID       (0x1U << 12) /* Apply distribution counter */
#define CLX_SRV6_LOCAL_FLAGS_ECN_DISABLE       (0x1U << 13) /* Disable ECN */
#define CLX_SRV6_LOCAL_FLAGS_MAC_LEARN_EN      (0x1U << 14) /* Enable MAC address learning */
#define CLX_SRV6_LOCAL_FLAGS_GBP_EN            (0x1U << 15) /* Derive gbp tag in SRH */

#define CLX_SRV6_LOCAL_ATTR_TRUST_VID (0x1ULL << 0)         /* Set CLX_SRV6_LOCAL_FLAGS_TRUST_VID */
#define CLX_SRV6_LOCAL_ATTR_TRUST_1P  (0x1ULL << 1)         /* Set CLX_SRV6_LOCAL_FLAGS_TRUST_1P */
#define CLX_SRV6_LOCAL_ATTR_PRIO_TAG_ENABLE \
    (0x1ULL << 2)                                     /* Set CLX_SRV6_LOCAL_FLAGS_PRIO_TAG_ENABLE */
#define CLX_SRV6_LOCAL_ATTR_NOT_ALLOW_CTAG \
    (0x1ULL << 3)                                     /* Set CLX_SRV6_LOCAL_FLAGS_NOT_ALLOW_CTAG */
#define CLX_SRV6_LOCAL_ATTR_USE_INNER_PHB                                                       \
    (0x1ULL << 4)                                     /* Set CLX_SRV6_LOCAL_FLAGS_USE_INNER_PHB \
                                                       */
#define CLX_SRV6_LOCAL_ATTR_KEEP_INNER_QOS \
    (0x1ULL << 5)                                     /* Set CLX_SRV6_LOCAL_FLAGS_KEEP_INNER_QOS */
#define CLX_SRV6_LOCAL_ATTR_QOS_UNIFORM (0x1ULL << 6) /* Set CLX_SRV6_LOCAL_FLAGS_QOS_UNIFORM */
#define CLX_SRV6_LOCAL_ATTR_TTL_UNIFORM (0x1ULL << 7) /* Set CLX_SRV6_LOCAL_FLAGS_TTL_UNIFORM */
#define CLX_SRV6_LOCAL_ATTR_IGR_QOS     (0x1ULL << 8) /* Set igr_qos */
#define CLX_SRV6_LOCAL_ATTR_IPV4_SRC_GUARD_EN \
    (0x1ULL << 9)                                 /* Set CLX_SRV6_LOCAL_FLAGS_IPV4_SRC_GUARD_EN */
#define CLX_SRV6_LOCAL_ATTR_IPV6_SRC_GUARD_EN \
    (0x1ULL << 10)                                /* Set CLX_SRV6_LOCAL_FLAGS_IPV6_SRC_GUARD_EN */
#define CLX_SRV6_LOCAL_ATTR_METER_ID \
    (0x1ULL << 11)                                /* Set CLX_SRV6_LOCAL_FLAGS_METER_ID, meter_id */
#define CLX_SRV6_LOCAL_ATTR_CNT_ID (0x1ULL << 12) /* Set CLX_SRV6_LOCAL_FLAGS_CNT_ID, cnt_id */
#define CLX_SRV6_LOCAL_ATTR_DIST_CNT_ID \
    (0x1ULL << 13) /* Set CLX_SRV6_LOCAL_FLAGS_DIST_CNT_ID, dist_cnt_id */
#define CLX_SRV6_LOCAL_ATTR_ECN_DISABLE (0x1ULL << 14)   /* Set CLX_SRV6_LOCAL_FLAGS_ECN_DISABLE */
#define CLX_SRV6_LOCAL_ATTR_MAC_LEARN_EN                                                          \
    (0x1ULL << 15)                                       /* Set CLX_SRV6_LOCAL_FLAGS_MAC_LEARN_EN \
                                                          */
#define CLX_SRV6_LOCAL_ATTR_SFLOW         (0x1ULL << 16) /* Set sample */
#define CLX_SRV6_LOCAL_ATTR_GBP_EN        (0x1ULL << 17) /* Set CLX_SRV6_LOCAL_FLAGS_GBP_EN */
#define CLX_SRV6_LOCAL_ATTR_DFLT_VID      (0x1ULL << 18) /* Set dflt_vid */
#define CLX_SRV6_LOCAL_ATTR_DFLT_PCP      (0x1ULL << 19) /* Set dflt_pcp */
#define CLX_SRV6_LOCAL_ATTR_DFLT_DEI      (0x1ULL << 20) /* Set dflt_dei */
#define CLX_SRV6_LOCAL_ATTR_IGR_TPID      (0x1ULL << 21) /* Set igr_tpid */
#define CLX_SRV6_LOCAL_ATTR_VLAN_TAG_MODE (0x1ULL << 22) /* Set vlan_tag_mode */

#define CLX_SRV6_LOCAL_ATTR_DFLT_BDID       (0x1ULL << 23)       /* Set dflt_bdid */
#define CLX_SRV6_LOCAL_ATTR_MIR_SESSION_BMP (0x1ULL << 24)       /* Set mir_session_bmp */
#define CLX_SRV6_LOCAL_ATTR_L2_MTU          (0x1ULL << 25)       /* Set l2_mtu */
#define CLX_SRV6_LOCAL_ATTR_GRP_LBL         (0x1ULL << 26)       /* Set grp_lbl */
#define CLX_SRV6_LOCAL_ATTR_DROP_PKT        (0x1ULL << 27)       /* Set drop_pkt */
#define CLX_SRV6_LOCAL_ATTR_SA_RSN          (0x1ULL << 28)       /* Set sa_rsn */
#define CLX_SRV6_LOCAL_ATTR_ALL             (0xFFFFFFFFFFFFFFFF) /* Set all fields */

typedef struct clx_srv6_sidlist_s {
    uint8 segments_left;
    clx_ipv6_t segment_list[4];
} clx_srv6_sidlist_t;

typedef enum clx_srv6_encap_behavior_e {
    CLX_SRV6_ENCAP_BEHAVIOR_H_ENCAPS = 0,
    CLX_SRV6_ENCAP_BEHAVIOR_H_ENCAPS_RED,
    CLX_SRV6_ENCAP_BEHAVIOR_H_ENCAPS_L2,
    CLX_SRV6_ENCAP_BEHAVIOR_H_ENCAPS_L2_RED,
    CLX_SRV6_ENCAP_BEHAVIOR_H_INSERT,
    CLX_SRV6_ENCAP_BEHAVIOR_H_INSERT_RED,
    CLX_SRV6_ENCAP_BEHAVIOR_END_B6_INSERT,
    CLX_SRV6_ENCAP_BEHAVIOR_END_B6_ENCAPS,
    CLX_SRV6_ENCAP_BEHAVIOR_END_BM,
    CLX_SRV6_ENCAP_BEHAVIOR_END_B6_INSERT_RED,
    CLX_SRV6_ENCAP_BEHAVIOR_END_B6_ENCAPS_RED,
    CLX_SRV6_ENCAP_BEHAVIOR_LAST
} clx_srv6_encap_behavior_t;

typedef struct clx_srv6_encap_cfg_s {
    clx_srv6_sidlist_t sid_list;              /* Encaps or insert SR policys */
    clx_ipv6_t encap_src_ip;                  /* Encaps source IP */
    clx_srv6_encap_behavior_t encap_beh_code; /* SRv6 headend behavior or endpoint encap behavior */
    clx_qos_prof_t egr_qos;                   /* Egress qos */
    uint8 dscp;                               /* SRv6 header DSCP value */
    uint8 ttl;                                /* SRv6 header TTL value */
    uint32 mir_session_bmp;                   /* Mirror session ID bitmap */
    uint32 grp_lbl;                           /* ACL grouping label */
    uint32 meter_id;                          /* Meter ID */
    uint32 cnt_id;                            /* Regular Service counter ID */
    uint32 dist_cnt_id;                       /* Distribution counter ID */
    uint16 l2_mtu;                            /* L2 mtu size */
    clx_sample_t sample;                      /* Egress Sampling */
    clx_vlan_tpid_t egr_tpid;                 /* Inner header's TPID setting. */
    clx_nhp_type_t output_type;               /* Refer to clx_nhp_type_t */
    uint32 output_id;                         /* Support ADJ and ECMP type */

    uint32 flags;                             /* Refer to CLX_SRV6_ENCAP_FLAGS_XXX. */
    uint64 attr_bmp;                          /* Refer to CLX_SRV6_ENCAP_ATTR_XXX. */
} clx_srv6_encap_cfg_t;
#define CLX_SRV6_ENCAP_FLAGS_TTL_UNIFORM    (0x1U << 0) /* TTL uniform mode */
#define CLX_SRV6_ENCAP_FLAGS_QOS_UNIFORM    (0x1U << 1) /* DSCP uniform mode */
#define CLX_SRV6_ENCAP_FLAGS_ECN_STANDARD   (0x1U << 2) /* Normal mode defined in RFC6040 */
#define CLX_SRV6_ENCAP_FLAGS_KEEP_INNER_TAG (0x1U << 3) /* Keep packet inner vlan */
#define CLX_SRV6_ENCAP_FLAGS_FLOWLABEL_COPY_INNER \
    (0x1U << 4) /* Copy inner header flowlabel value to outer header */
#define CLX_SRV6_ENCAP_FLAGS_METER_ID    (0x1U << 5)   /* Apply meter */
#define CLX_SRV6_ENCAP_FLAGS_CNT_ID      (0x1U << 6)   /* Apply counter */
#define CLX_SRV6_ENCAP_FLAGS_DIST_CNT_ID (0x1U << 7)   /* Apply distribution counter */
#define CLX_SRV6_ENCAP_FLAGS_GBP_EN      (0x1U << 8)   /* Encapsulate gbp tag to SRH */

#define CLX_SRV6_ENCAP_ATTR_TTL_UNIFORM  (0x1ULL << 0) /* Set CLX_SRV6_ENCAP_FLAGS_TTL_UNIFORM */
#define CLX_SRV6_ENCAP_ATTR_QOS_UNIFORM  (0x1ULL << 1) /* Set CLX_SRV6_ENCAP_FLAGS_QOS_UNIFORM */
#define CLX_SRV6_ENCAP_ATTR_ECN_STANDARD (0x1ULL << 2) /* Set CLX_SRV6_ENCAP_FLAGS_ECN_STANDARD */
#define CLX_SRV6_ENCAP_ATTR_KEEP_INNER_TAG \
    (0x1ULL << 3)                                      /* Set CLX_SRV6_ENCAP_FLAGS_KEEP_INNER_TAG */
#define CLX_SRV6_ENCAP_ATTR_FLOWLABEL_COPY_INNER \
    (0x1ULL << 4) /* Set CLX_SRV6_ENCAP_FLAGS_FLOWLABEL_COPY_INNER */
#define CLX_SRV6_ENCAP_ATTR_EGR_QOS (0x1ULL << 5) /* Apply egr_qos */
#define CLX_SRV6_ENCAP_ATTR_METER_ID                                                             \
    (0x1ULL << 6)                                 /* Set CLX_SRV6_ENCAP_FLAGS_METER_ID, meter_id \
                                                   */
#define CLX_SRV6_ENCAP_ATTR_CNT_ID (0x1ULL << 7)  /* Set CLX_SRV6_ENCAP_FLAGS_CNT_ID, cnt_id */
#define CLX_SRV6_ENCAP_ATTR_DIST_CNT_ID \
    (0x1ULL << 8) /* Set CLX_SRV6_ENCAP_FLAGS_DIST_CNT_ID, dist_cnt_id */
#define CLX_SRV6_ENCAP_ATTR_SFLOW           (0x1ULL << 9)  /* Set sample */
#define CLX_SRV6_ENCAP_ATTR_GBP_EN          (0x1ULL << 10) /* Set CLX_SRV6_ENCAP_FLAGS_GBP_EN */
#define CLX_SRV6_ENCAP_ATTR_SIDLIST         (0x1ULL << 11) /* Set sid_list */
#define CLX_SRV6_ENCAP_ATTR_ENCAP_SRC_IP    (0x1ULL << 12) /* Set encap_src_ip */
#define CLX_SRV6_ENCAP_ATTR_ENCAP_BEH_CODE  (0x1ULL << 13) /* Set encap_beh_code */
#define CLX_SRV6_ENCAP_ATTR_DSCP            (0x1ULL << 14) /* Set dscp */
#define CLX_SRV6_ENCAP_ATTR_TTL             (0x1ULL << 15) /* Set ttl */
#define CLX_SRV6_ENCAP_ATTR_MIR_SESSION_BMP (0x1ULL << 16) /* Set mir_session_bmp */
#define CLX_SRV6_ENCAP_ATTR_GRP_LBL         (0x1ULL << 17) /* Set grp_lbl */
#define CLX_SRV6_ENCAP_ATTR_L2_MTU          (0x1ULL << 18) /* Set l2_mtu */
#define CLX_SRV6_ENCAP_ATTR_EGR_TPID        (0x1ULL << 19) /* Set payload_tpid_prof */
#define CLX_SRV6_ENCAP_ATTR_OUTPUT_ID       (0x1ULL << 20) /* Set output_type, output_id */
#define CLX_SRV6_ENCAP_ATTR_ALL             (0xFFFFFFFFFFFFFFFF) /* Set all fields */

typedef enum clx_srv6_endpoint_behavior_e {
    CLX_SRV6_ENDPOINT_BEHAVIOR_END = 0,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_T = CLX_SRV6_ENDPOINT_BEHAVIOR_END,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_X = 1,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_B6_INSERT = 2,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_B6_ENCAPS = 3,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_BM = 4,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DX6 = 5,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DX4 = 6,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DT6 = 7,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DT4 = 8,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DT46 = 9,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DX2 = 10,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DX2V = 11,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DT2U = 12,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_DT2M = 13,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_B6_INSERT_RED = 14,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_B6_ENCAPS_RED = 15,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_NEXT_ONLY_CSID = 16,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_X_NEXT_ONLY_CSID = 17,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_RSVD = 18,
    CLX_SRV6_ENDPOINT_BEHAVIOR_END_RSVD_MAX = 32
} clx_srv6_endpoint_behavior_t;

typedef struct clx_srv6_mysid_entry_s {
    uint16 underlay_vrf;     /* Key: Locator IPv6 address vrf */
    clx_ipv6_t mysid;        /* Key: IPv6 Address for My SID */
    clx_ipv6_t locator_mask; /* Key: Locator IP mask which is mysid locator part */
} clx_srv6_mysid_entry_t;

typedef struct clx_srv6_mysid_cfg_s {
    clx_srv6_endpoint_behavior_t end_beh_code;        /* Endpoint behavior code */
    uint32 service_id;                                /* VPN instance identification label */

    uint32 flags;                                     /* Refer to CLX_SRV6_MYSID_FLAGS_XXX */
    uint64 attr_bmp;                                  /* Refer to CLX_SRV6_MYSID_ATTR_XXX */
} clx_srv6_mysid_cfg_t;
#define CLX_SRV6_MYSID_FLAGS_USID_FUNC_EN (0x1U << 0) /* Enable function field in usid */
#define CLX_SRV6_MYSID_FLAGS_USID_ARG_EN  (0x1U << 1) /* Enable argument field in usid */
#define CLX_SRV6_MYSID_FLAGS_REDIR2CPU    (0x1U << 2) /* Redirect to cpu */
#define CLX_SRV6_MYSID_FLAGS_COC          (0x1U << 3) /* COC flavor */
#define CLX_SRV6_MYSID_FLAGS_NXTCSID      (0x1U << 4) /* NEXT-CSID flavor */
#define CLX_SRV6_MYSID_FLAGS_PSP          (0x1U << 5) /* PSP flavor */
#define CLX_SRV6_MYSID_FLAGS_USP          (0x1U << 6) /* USP flavor */
#define CLX_SRV6_MYSID_FLAGS_USD          (0x1U << 7) /* USD flavor */
#define CLX_SRV6_MYSID_FLAGS_USE_DST_TEP_2X                                                       \
    (0x1U << 8) /* If tunnel mac not set SRv6 only and locator_len <= 4 byte, this flag should be \
                   set */

#define CLX_SRV6_MYSID_ATTR_USID_FUNC_EN (0x1ULL << 0) /* Set CLX_SRV6_MYSID_FLAGS_USID_FUNC_EN */
#define CLX_SRV6_MYSID_ATTR_USID_ARG_EN  (0x1ULL << 1) /* Set CLX_SRV6_MYSID_FLAGS_USID_ARG_EN */
#define CLX_SRV6_MYSID_ATTR_REDIR2CPU    (0x1ULL << 2) /* Set CLX_SRV6_MYSID_FLAGS_REDIR2CPU */
#define CLX_SRV6_MYSID_ATTR_COC          (0x1ULL << 3) /* Set CLX_SRV6_MYSID_FLAGS_COC */
#define CLX_SRV6_MYSID_ATTR_NXTCSID      (0x1ULL << 4) /* Set CLX_SRV6_MYSID_FLAGS_NXTCSID */
#define CLX_SRV6_MYSID_ATTR_PSP          (0x1ULL << 5) /* Set CLX_SRV6_MYSID_FLAGS_PSP */
#define CLX_SRV6_MYSID_ATTR_USP          (0x1ULL << 6) /* Set CLX_SRV6_MYSID_FLAGS_USP */
#define CLX_SRV6_MYSID_ATTR_USD          (0x1ULL << 7) /* Set CLX_SRV6_MYSID_FLAGS_USD */
#define CLX_SRV6_MYSID_ATTR_END_BEH_CODE (0x1ULL << 8) /* Set end_beh_code */
#define CLX_SRV6_MYSID_ATTR_SERVICE_ID   (0x1ULL << 9) /* Set service_id */
#define CLX_SRV6_MYSID_ATTR_ALL          (0xFFFFFFFFFFFFFFFF) /* Set all fields */

typedef enum clx_srv6_sid_mode_e {
    CLX_SRV6_SID_MODE_DISABLE = 0,
    CLX_SRV6_SID_MODE_SRV6,
    CLX_SRV6_SID_MODE_USID,
    CLX_SRV6_SID_MODE_GSRV6,
    CLX_SRV6_SID_MODE_LAST
} clx_srv6_sid_mode_t;

typedef struct clx_srv6_property_s {
    clx_srv6_sid_mode_t mode;   /* Select SRv6 parse mode */
    uint32 locator_len;         /* Locator size in octets */
    uint32 func_len;            /* Function size in octets, up to 4 bytes */
    uint32 arg_len;             /* Argument size in octets, up to 2 bytes */
    uint32 usid_block_len;      /* uSID block size in octets, up to 7 bytes */
    uint32 usid_node_id_len;    /* uSID ID size in octets
                                 * uSID locator length equals block size plus node id size.
                                 */
    uint32 gsrv6_prefix_len;    /* G-SRv6 prefix length in otects, up to 12 byte */
    uint32 gsrv6_si_offset_len; /* Offset of the G-SRv6 SID index */
    clx_mac_t dx2v_mac;         /* Configure dst-mac for END.DX2V */

    uint32 flags;               /* Refer to CLX_SRV6_PROPERTY_FLAGS_XXX */
    uint64 attr_bmp;            /* Refer to CLX_SRV6_PROPERTY_ATTR_XXX */
} clx_srv6_property_t;
#define CLX_SRV6_PROPERTY_FLAGS_ENCAPS_RED (0x1U << 0) /* H.encaps with reduced encapsulation */
#define CLX_SRV6_PROPERTY_FLAGS_INSERT_RED (0x1U << 1) /* H.insert with reduced insertion */

#define CLX_SRV6_PROPERTY_ATTR_MODE            (0x1ULL << 0) /* set mode */
#define CLX_SRV6_PROPERTY_ATTR_LOCATOR         (0x1ULL << 1) /* set locator_len */
#define CLX_SRV6_PROPERTY_ATTR_FUNC            (0x1ULL << 2) /* set func_len */
#define CLX_SRV6_PROPERTY_ATTR_ARG             (0x1ULL << 3) /* set arg_len */
#define CLX_SRV6_PROPERTY_ATTR_USID_BLOCK      (0x1ULL << 4) /* set usid_block_len */
#define CLX_SRV6_PROPERTY_ATTR_USID_NODE       (0x1ULL << 5) /* set usid_node_id_len */
#define CLX_SRV6_PROPERTY_ATTR_GSRV6_PREFIX    (0x1ULL << 6) /* set gsrv6_prefix_len */
#define CLX_SRV6_PROPERTY_ATTR_GSRV6_SI_OFFSET (0x1ULL << 7) /* set gsrv6_si_offset_len */
#define CLX_SRV6_PROPERTY_ATTR_DX2V_MAC        (0x1ULL << 8) /* set dx2v_mac */
#define CLX_SRV6_PROPERTY_ATTR_ENCAPS_RED \
    (0x1ULL << 9)  /* set CLX_SRV6_SID_GLOBAL_PROFILE_FLAGS_ENCAPS_RED */
#define CLX_SRV6_PROPERTY_ATTR_INSERT_RED \
    (0x1ULL << 10) /* set CLX_SRV6_SID_GLOBAL_PROFILE_FLAGS_INSERT_RED */
#define CLX_SRV6_PROPERTY_ATTR_ALL (0xFFFFFFFFFFFFFFFF) /* Set all fields */

typedef struct clx_srv6_nvo3_route_info_s {
    clx_nhp_t nhp; /* Nexthop information */
} clx_srv6_nvo3_route_info_t;

typedef struct clx_srv6_endpoint_policy_s {
    uint16 vrf;        /* Key: Vrf id of the SRv6, default is zero */
    uint32 service_id; /* Key: Segment re-route domain label */
    clx_nhp_t nhp;     /* Nexthop information */
    uint32 grp_lbl;    /* ACL grouping label */

    uint32 flags;      /* Refer to CLX_SRV6_ENDPOINT_POLICY_FLAGS_XXX */
    uint64 attr_bmp;   /* Refer to CLX_SRV6_ENDPOINT_POLICY_ATTR_XXX */
} clx_srv6_endpoint_policy_t;
#define CLX_SRV6_ENDPOINT_POLICY_FLAGS_DECREMENT_TTL (0x1U << 0) /* Decrement the SRv6 IPv6 TTL */

#define CLX_SRV6_ENDPOINT_POLICY_ATTR_DECREMENT_TTL \
    (0x1ULL << 0) /* Set CLX_SRV6_ENDPOINT_POLICY_FLAGS_DECREMENT_TTL */
#define CLX_SRV6_ENDPOINT_POLICY_ATTR_NH      (0x1ULL << 1)        /* Set nh */
#define CLX_SRV6_ENDPOINT_POLICY_ATTR_GRP_LBL (0x1ULL << 2)        /* Set grp_lbl */
#define CLX_SRV6_ENDPOINT_POLICY_ATTR_ALL     (0xFFFFFFFFFFFFFFFF) /* Set all fields */

typedef enum clx_srv6_hash_type_e {
    CLX_SRV6_HASH_TYPE_BDO = 0,
    CLX_SRV6_HASH_TYPE_SRC_TEP,
    CLX_SRV6_HASH_TYPE_MGO,
    CLX_SRV6_HASH_TYPE_MSGO,
    CLX_SRV6_HASH_TYPE_MPLS_LSP,
    CLX_SRV6_HASH_TYPE_ALL,
    CLX_SRV6_HASH_TYPE_LAST
} clx_srv6_hash_type_t;

typedef struct clx_srv6_hash_action_e {
    boolean hash_algo_murmur[4]; /* 0: GF16; 1: Murmur */
    uint32 seed[4];              /* seed for Murmur or GF16 algorithm */
    uint32 fac[4];               /* fac for GF16 algorithm */
    // #define CLX_SRV6_HASH_ACTION_ATTR_HASH_ALGO_MURMUR              (0x1ULL << 0)
    // #define CLX_SRV6_HASH_ACTION_ATTR_SEED                          (0x1ULL << 1)
    // #define CLX_SRV6_HASH_ACTION_ATTR_FAC                           (0x1ULL << 2)
    // #define CLX_SRV6_HASH_ACTION_ATTR_ALL                           (0xFFFFFFFFFFFFFFFF)
    // uint64                  attr_bmp;                            /* Mark which fields to set
    // */
} clx_srv6_hash_action_t;

typedef clx_error_no_t (*clx_srv6_port_trav_func_t)(const uint32 unit,
                                                    const clx_port_t port,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*clx_srv6_local_trav_func_t)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const clx_srv6_local_cfg_t *ptr_local_info,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*clx_srv6_encap_trav_func_t)(const uint32 unit,
                                                     const clx_port_t port,
                                                     const clx_srv6_encap_cfg_t *ptr_encap_info,
                                                     void *ptr_cookie);

typedef clx_error_no_t (*clx_srv6_mysid_entry_trav_func_t)(
    const uint32 unit,
    const clx_srv6_mysid_entry_t *ptr_mysid_entry,
    const clx_srv6_mysid_cfg_t *ptr_mysid_info,
    void *ptr_cookie);

typedef clx_error_no_t (*clx_srv6_endpoint_policy_trav_func_t)(
    const uint32 unit,
    const clx_srv6_endpoint_policy_t *ptr_endpoint_policy,
    void *ptr_cookie);

typedef clx_error_no_t (*clx_srv6_nvo3_route_trav_func_t)(
    const uint32 unit,
    const clx_port_t port,
    const clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route,
    void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Create SRv6 port.
 *
 * This API is used to create a SRv6 port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     flag        - Refers to CLX_SRV6_FLAGS_XXX.
 * @param [out]    ptr_port    - Point to the generated SRv6 port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Resources exhausted.
 */
clx_error_no_t
clx_srv6_port_create(const uint32 unit, const uint32 flag, clx_port_t *ptr_port);

/**
 * @brief Destroy SRv6 port.
 *
 * This API is used to destroy a SRv6 port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit    - Device unit number.
 * @param [out]    port    - Destroy SRv6 port number.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_srv6_port_destroy(const uint32 unit, const clx_port_t port);

/**
 * @brief Traverse all configured SRv6 port.
 *
 * This API is used to traverse all SRv6 port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_srv6_port_trav(const uint32 unit, const clx_srv6_port_trav_func_t callback, void *ptr_cookie);

/**
 * @brief Add a SRv6 local entry.
 *
 * This API is used to add a SRv6 local entry.
 * For detailed information of this entry, refer to clx_srv6_local_cfg_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - SRv6 port.
 * @param [in]     ptr_local_info    - Add SRv6 local information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 */
clx_error_no_t
clx_srv6_local_add(const uint32 unit,
                   const clx_port_t port,
                   const clx_srv6_local_cfg_t *ptr_local_info);

/**
 * @brief Delete a SRv6 local entry.
 *
 * This API is used to delete a SRv6 local entry.
 * For detailed information of this entry, refer to clx_srv6_local_cfg_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - SRv6 port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND  - No entry is found.
 */
clx_error_no_t
clx_srv6_local_del(const uint32 unit, const clx_port_t port);

/**
 * @brief Set a SRv6 local entry.
 *
 * This API is used to set a SRv6 local entry.
 * For detailed information of this entry, refer to clx_srv6_local_cfg_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - SRv6 port.
 * @param [in]     ptr_local_info    - Set SRv6 local information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND  - No entry is found.
 */
clx_error_no_t
clx_srv6_local_set(const uint32 unit,
                   const clx_port_t port,
                   const clx_srv6_local_cfg_t *ptr_local_info);

/**
 * @brief Get a SRv6 local entry.
 *
 * This API is used to get a SRv6 local entry.
 * For detailed information of this entry, refer to clx_srv6_local_cfg_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - SRv6 port.
 * @param [out]    ptr_local_info    - Get SRv6 local information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_srv6_local_get(const uint32 unit, const clx_port_t port, clx_srv6_local_cfg_t *ptr_local_info);

/**
 * @brief Traverse all configured SRv6 Local entries.
 *
 * This API is used to traverse all SRv6 local entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_srv6_local_trav(const uint32 unit, const clx_srv6_local_trav_func_t callback, void *ptr_cookie);

/**
 * @brief Add a SRv6 encapsulation entry.
 *
 * This API is used to add a SRv6 encapsulation entry.
 * For detailed information of this entry, refer to clx_srv6_encap_cfg_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - SRv6 port.
 * @param [in]     ptr_encap_info   - Add SRv6 encaps information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter. "unit"  is invalid.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_srv6_encap_add(const uint32 unit,
                   const clx_port_t port,
                   const clx_srv6_encap_cfg_t *ptr_encap_info);

/**
 * @brief Delete a SRv6 encapsulation entry.
 *
 * This API is used to delete a SRv6 encapsulation entry.
 * For detailed information of this entry, refer to clx_srv6_encap_cfg_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - SRv6 port.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 * @return         CLX_E_NO_MEMORY          - No available memory.
 */
clx_error_no_t
clx_srv6_encap_del(const uint32 unit, const clx_port_t port);

/**
 * @brief Add a SRv6 encapsulation entry.
 *
 * This API is used to set a SRv6 encapsulation entry.
 * For detailed information of this entry, refer to clx_srv6_encap_cfg_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - SRv6 port.
 * @param [in]     ptr_encap_info   - Set SRv6 encaps information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 * @return         CLX_E_OP_INVALID         - Operation is invalid.
 */
clx_error_no_t
clx_srv6_encap_set(const uint32 unit,
                   const clx_port_t port,
                   const clx_srv6_encap_cfg_t *ptr_encap_info);

/**
 * @brief Get a SRv6 encapsulation entry.
 *
 * This API is used to get a SRv6 encapsulation entry.
 * For detailed information of this entry, refer to clx_srv6_encap_cfg_t.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port              - SRv6 port.
 * @param [out]    ptr_encap_info    - Get SRv6 encaps information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_encap_get(const uint32 unit, const clx_port_t port, clx_srv6_encap_cfg_t *ptr_encap_info);

/**
 * @brief Traverse all configured SRv6 encapsulation entries.
 *
 * This API is used to traverse all SRv6 encapsulation entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_srv6_encap_trav(const uint32 unit, const clx_srv6_encap_trav_func_t callback, void *ptr_cookie);

/**
 * @brief Add a SRv6 MySID entry.
 *
 * This API is used to add a MySID entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [in]     ptr_mysid_entry         - SRv6 MySID entry.
 * @param [in]     ptr_mysid_info          - Add SRv6 MySID entry information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_EXISTS       - Entry already exists.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_mysid_entry_add(const uint32 unit,
                         const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                         const clx_srv6_mysid_cfg_t *ptr_mysid_info);

/**
 * @brief Delete a SRv6 MySID entry.
 *
 * This API is used to delete a MySID entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [in]     ptr_mysid_entry         - SRv6 MySID entry.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_mysid_entry_del(const uint32 unit, const clx_srv6_mysid_entry_t *ptr_mysid_entry);

/**
 * @brief Set a SRv6 MySID entry.
 *
 * This API is used to set a MySID entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [in]     ptr_mysid_entry         - SRv6 MySID entry.
 * @param [in]     ptr_mysid_info          - Set SRv6 MySID entry information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_mysid_entry_set(const uint32 unit,
                         const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                         const clx_srv6_mysid_cfg_t *ptr_mysid_info);

/**
 * @brief Get a SRv6 MySID entry.
 *
 * This API is used to get a MySID entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [in]     ptr_mysid_entry         - SRv6 MySID entry.
 * @param [out]    ptr_mysid_info          - Get SRv6 MySID entry information.
 * @return         CLX_E_OK                - Operation success.
 * @return         CLX_E_BAD_PARAMETER     - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_ENTRY_NOT_FOUND   - No entry is found.
 * @return         CLX_E_NO_MEMORY         - No available memory.
 */
clx_error_no_t
clx_srv6_mysid_entry_get(const uint32 unit,
                         const clx_srv6_mysid_entry_t *ptr_mysid_entry,
                         clx_srv6_mysid_cfg_t *ptr_mysid_info);

/**
 * @brief Traverse all configured SRv6 MySID entries.
 *
 * This API is used to traverse all MySID entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_srv6_mysid_entry_trav(const uint32 unit,
                          const clx_srv6_mysid_entry_trav_func_t callback,
                          void *ptr_cookie);

/**
 * @brief Set SRv6 global configurations.
 *
 * This API is used to set SRv6 global configurations.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_property  - SRv6 global configurations.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.  "unit"  is invalid.
 * @return         CLX_E_OP_INVALID         - Operation is invalid.
 */
clx_error_no_t
clx_srv6_property_set(const uint32 unit, const clx_srv6_property_t *ptr_property);

/**
 * @brief Get SRv6 global configurations.
 *
 * This API is used to get SRv6 global configurations.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_property  - SRv6 global configurations.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
clx_error_no_t
clx_srv6_property_get(const uint32 unit, clx_srv6_property_t *ptr_property);

/**
 * @brief Add a NVO3 route. If ECMP flag is set, add a NVO3 ECMP route.
 *
 * This API is used to add a NVO3 route entry.
 * When user needs to set an IP packet forward from SRv6 tunnel, it can be used
 * to set the IP packet which matches one route entry forwarded from a SRv6 tunnel.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     port                   - SRv6 port.
 * @param [in]     ptr_srv6_nvo3_route    - Add NVO3 route information.
 *                                          For ECMP route, the NVO3 ECMP group ID needs to be
 *                                          specified.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_srv6_nvo3_route_add(const uint32 unit,
                        const clx_port_t port,
                        const clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

/**
 * @brief Set a NVO3 route. If ECMP flag is set, set a NVO3 ECMP route.
 *
 * This API is used to set a NVO3 route entry.
 * When user needs to set an IP packet forward from SRv6 tunnel, it can be used
 * to set the IP packet which matches one route entry forwarded from a SRv6 tunnel.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     port                   - SRv6 port.
 * @param [in]     ptr_srv6_nvo3_route    - Add NVO3 route information.
 *                                          For ECMP route, the NVO3 ECMP group ID needs to be
 *                                          specified.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_srv6_nvo3_route_set(const uint32 unit,
                        const clx_port_t port,
                        const clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

/**
 * @brief Delete a NVO3 route of SRv6 tunnel.
 *
 * This API is used to delete a NVO3 route entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     port                   - SRv6 port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory
 */
clx_error_no_t
clx_srv6_nvo3_route_del(const uint32 unit, const clx_port_t port);

/**
 * @brief Get a NVO3 route of SRv6 tunnel.
 *
 * This API is used to get a NVO3 route entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     port                   - SRv6 port.
 * @param [out]    ptr_srv6_nvo3_route    - Get NVO3 route information.
 *                                          If it is ECMP route, it will return the ECMP group ID.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input destination IP.
 */
clx_error_no_t
clx_srv6_nvo3_route_get(const uint32 unit,
                        const clx_port_t port,
                        clx_srv6_nvo3_route_info_t *ptr_srv6_nvo3_route);

/**
 * @brief Traverse all configured nvo3_route entries.
 *
 * This API is used to traverse all NVO3 route entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_srv6_nvo3_route_trav(const uint32 unit,
                         const clx_srv6_nvo3_route_trav_func_t callback,
                         void *ptr_cookie);

/**
 * @brief Add a SRv6 endpoint policy.
 *
 * This API is used to add a SRv6 endpoint policy.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                        - Device unit number.
 * @param [in]     ptr_endpoint_policy         - Add SRv6 endpoint policy.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_endpoint_policy_add(const uint32 unit,
                             const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

/**
 * @brief Delete a SRv6 endpoint policy.
 *
 * This API is used to delete a SRv6 endpoint policy.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                        - Device unit number.
 * @param [in]     ptr_endpoint_policy         - Delete SRv6 endpoint policy.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_endpoint_policy_del(const uint32 unit,
                             const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

/**
 * @brief Set a SRv6 endpoint policy.
 *
 * This API is used to set a SRv6 endpoint policy.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                        - Device unit number.
 * @param [in]     ptr_endpoint_policy         - Set SRv6 endpoint policy.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_endpoint_policy_set(const uint32 unit,
                             const clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

/**
 * @brief Get a SRv6 endpoint policy.
 *
 * This API is used to get a SRv6 endpoint policy.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                        - Device unit number.
 * @param [in]     ptr_endpoint_policy         - Get SRv6 endpoint policy.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_endpoint_policy_get(const uint32 unit, clx_srv6_endpoint_policy_t *ptr_endpoint_policy);

/**
 * @brief Traverse all configured SRv6 endpoint policy entries.
 *
 * This API is used to traverse all SRv6 endpoint policies.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_srv6_endpoint_policy_trav(const uint32 unit,
                              const clx_srv6_endpoint_policy_trav_func_t callback,
                              void *ptr_cookie);

/**
 * @brief Add a SRv6 overlay service mapping entry.
 *
 * This API is used to add a VPN mapping entry on SRv6 port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - SRv6 port.
 * @param [in]     service_id   - VPN label.
 * @param [in]     bdid         - Bdid.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 * @return         CLX_E_ENTRY_EXISTS       - Entry already exists.
 */
clx_error_no_t
clx_srv6_seg_srv_add(const uint32 unit,
                     const clx_port_t port,
                     const uint32 service_id,
                     const uint32 bdid);

/**
 * @brief Delete a SRv6 overlay service mapping entry.
 *
 * This API is used to delete a VPN mapping entry on SRv6 port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - SRv6 port.
 * @param [in]     service_id   - VPN label.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_seg_srv_del(const uint32 unit, const clx_port_t port, const uint32 service_id);

/**
 * @brief Set a SRv6 overlay service mapping entry.
 *
 * This API is used to set a VPN mapping entry on SRv6 port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - SRv6 port.
 * @param [in]     service_id   - VPN label.
 * @param [in]     bdid         - Bdid.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_seg_srv_set(const uint32 unit,
                     const clx_port_t port,
                     const uint32 service_id,
                     const uint32 bdid);

/**
 * @brief Get a SRv6 overlay service mapping entry.
 *
 * This API is used to get a VPN mapping entry on SRv6 port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - SRv6 port.
 * @param [in]     service_id   - VPN label.
 * @param [out]    ptr_bdid     - Get bdid information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found.
 */
clx_error_no_t
clx_srv6_seg_srv_get(const uint32 unit,
                     const clx_port_t port,
                     const uint32 service_id,
                     uint32 *ptr_bdid);

/**
 * @brief Set SRv6 hash action information.
 *
 * This API is used to set SRv6 related hash table configurations.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     hash_type            -  SRv6 hash type.
 * @param [in]     ptr_hash_action      -  SRv6 hash action.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
clx_error_no_t
clx_srv6_hash_action_set(const uint32 unit,
                         const clx_srv6_hash_type_t hash_type,
                         const clx_srv6_hash_action_t *ptr_hash_action);

/**
 * @brief Get SRv6 hash action information.
 *
 * This API is used to get SRv6 related hash table configurations.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     hash_type            -  SRv6 hash type.
 * @param [out]    ptr_hash_action      -  SRv6 hash action.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
clx_error_no_t
clx_srv6_hash_action_get(const uint32 unit,
                         const clx_srv6_hash_type_t hash_type,
                         clx_srv6_hash_action_t *ptr_hash_action);

#endif /* End of CLX_SRV6_H */
