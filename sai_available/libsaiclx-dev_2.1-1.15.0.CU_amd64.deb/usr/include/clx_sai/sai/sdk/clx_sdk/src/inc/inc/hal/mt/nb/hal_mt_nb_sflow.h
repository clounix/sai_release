/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_sflow.h
 * PURPOSE:
 *      Provide sflow hal layer api.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NB_SFLOW_H
#define HAL_MT_NB_SFLOW_H

#define HAL_MT_NB_SFLOW_PROFILE_ENTRY_NUM (64)

/**
 * @brief This API is used to register the impl into API layer, please note that the parameter should keep availablity
 * during the code runtime, in another word, stack variable is not accepted, you should use a global
 * variable for that.
 *
 *
 * @param [in]     ecpu_hw_access_impl         - readonly pointer to struct HAL_ECPU_HW_ACCESS_HANDLE_T
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_mt_nb_sflow_cfg_init(const uint32 unit);

/**
 * @brief This API is used to initialize the hardware related functions. If there is no hw related component needs to
 * initialize, we can put this function as a stub function.
 *
 *
 * @param [in]     void   - void
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_NOT_INITED       - Error happens, the impl will porvides more detail.
 */
clx_error_no_t
hal_mt_nb_sflow_high_latency_cfg_set(const uint32 unit,
                                     const uint32 threshold,
                                     const uint32 sflw_lat_en);

/**
 * @brief This API is used to deinitialize the hardware related functions.
 *
 *
 * @param [in]     void - void
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_NOT_INITED       - Error happens, the impl will porvides more detail.
 */
clx_error_no_t
hal_mt_nb_sflow_igr_cfg_sflow_mir_get(const uint32 unit,
                                      const uint32 profile_id,
                                      uint32 *ptr_sflw_mir_en,
                                      uint32 *ptr_sflw_mir_bidx);

/**
 * @brief This API is used to return the shared memory info in the purpose of communication bwtween eCPU and host CPU.
 * The shared memory includes the tx and rx shared memory, the upper layer code should be resonsible
 * for manage the control part, data part etc.
 *
 *
 * @param [in]      address               - An output parameter to carry out the address.
 * @param [in]      offset                - Offset of the address.
 * @param [in]      size                  - The size of the memory region.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_egr_cfg_sflow_mir_get(const uint32 unit,
                                      const uint32 profile_id,
                                      uint32 *ptr_sflw_mir_en,
                                      uint32 *ptr_sflw_mir_bidx);

clx_error_no_t
hal_mt_nb_sflow_igr_cfg_sflow_set(const uint32 unit,
                                  const uint32 profile_id,
                                  const uint32 sflw_splr_threshold);

/**
 * @brief This API is used to issue an itnerrupt to eCPU.
 *
 *
 * @param [in]     unit         - Device unit number.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_igr_cfg_sflow_mir_set(const uint32 unit,
                                      const uint32 profile_id,
                                      const uint32 sflw_mir_en,
                                      const uint32 sflw_mir_bidx);

/**
 * @brief This API is used to clear the interrupt from eCPU.
 *
 *
 * @param [in]     unit         - Device unit number.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_egr_cfg_sflow_set(const uint32 unit,
                                  const uint32 profile_id,
                                  const uint32 sflw_splr_threshold);

/**
 * @brief This API is used to enable the interrupt from eCPU.
 *
 *
 * @param [in]     unit         - Device unit number.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_egr_cfg_sflow_mir_set(const uint32 unit,
                                      const uint32 profile_id,
                                      const uint32 sflw_mir_en,
                                      const uint32 sflw_mir_bidx);

/**
 * @brief This API is used to trigger message sync.
 *
 *
 * @param [in]     addr         - Address pointer.
 * @param [in]     len          - The length of memory that needs to be synchronized.
 *
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
hal_mt_nb_sflow_profile_alloc(const uint32 unit,
                              const hal_sflow_src_type_t src_type,
                              const hal_sflow_dst_type_t dst_type,
                              const uint32 mir_session_id,
                              const uint32 profile_id,
                              const uint32 sampling_rate,
                              const boolean sample_high_latency);

#endif
