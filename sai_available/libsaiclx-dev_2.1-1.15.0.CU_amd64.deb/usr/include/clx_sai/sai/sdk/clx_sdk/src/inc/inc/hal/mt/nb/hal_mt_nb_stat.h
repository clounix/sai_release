/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_NB_STAT_H
#define HAL_MT_NB_STAT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_stat.h>
#include <clx/clx_tm.h>
#include <hal/hal_cmn.h>
#include <hal/hal_cmn_drv.h>
#include <hal/hal_stat.h>
#include <hal/hal_sec.h>

/* #define HAL_MT_NB_STAT_USE_CLD_DMA */
/* #define HAL_MT_NB_STAT_EN_RSFEC_CNT */

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_STAT_MIB_SRAM_CPI_IDX_OFFSET   (256)
#define HAL_MT_NB_STAT_MIB_SRAM_LANE_IDX_OFFSET  (128)
#define HAL_MT_NB_STAT_UMAC_ENTRY_NUM            (1935)
#define HAL_MT_NB_STAT_SRV_CNT_IDX_OFFSET        (10)
#define HAL_MT_NB_STAT_SRV_CNT_NUM_PER_BANK      ((1U << HAL_MT_NB_STAT_SRV_CNT_IDX_OFFSET) * 6)
#define HAL_MT_NB_STAT_SRV_CNT_IDX_SEL_OFFSET    (3)
#define HAL_MT_NB_STAT_SRV_CNT_BANK_NUM          (16)
#define HAL_MT_NB_STAT_DST_CNT_NUM_PER_BANK      (256)
#define HAL_MT_NB_STAT_DST_CNT_BANK_NUM          (4)
#define HAL_MT_NB_STAT_TM_IOS_CNT_SUBINST_OFFSET (108)
#define HAL_MT_NB_STAT_TM_IOS_CNT_PLANE_OFFSET   (HAL_MT_NB_STAT_TM_IOS_CNT_SUBINST_OFFSET * 4)
#define HAL_MT_NB_STAT_TM_TMI_CNT_TYPE_OFFSET    (34)
#define HAL_MT_NB_STAT_TM_TMI_CNT_PLANE_OFFSET   (HAL_MT_NB_STAT_TM_TMI_CNT_TYPE_OFFSET * 7)
#define HAL_MT_NB_STAT_TM_ENB_CNT_TYPE_OFFSET    (34)
#define HAL_MT_NB_STAT_TM_ENB_CNT_PLANE_OFFSET   (HAL_MT_NB_STAT_TM_ENB_CNT_TYPE_OFFSET * 12)
#define HAL_MT_NB_STAT_TM_CMS_CNT_BIN_OFFSET     (89 * 4)
#define HAL_MT_NB_STAT_TM_ADM_CNT_PLANE_OFFSET   (396 * 4)
#define HAL_MT_NB_STAT_TM_DEB_CNT_PLANE_OFFSET   (34)
#define HAL_MT_NB_STAT_TM_EPM_CNT_PLANE_OFFSET   (34 * 2)
#define HAL_MT_NB_STAT_TM_ADM_CMS_CNT_CPI_OFFSET (48)
#define HAL_MT_NB_STAT_EXCPT_CNT_PLANE_OFFSET    (33)
#define HAL_MT_NB_STAT_EXCPT_CNT_TYPE_NUM_IGR    (260)
#define HAL_MT_NB_STAT_EXCPT_CNT_TYPE_NUM_EGR    (69)
#define HAL_MT_NB_STAT_EXCPT_CNT_BMP_WORD_IGR \
    (((HAL_MT_NB_STAT_EXCPT_CNT_TYPE_NUM_IGR - 1) / 32) + 1)
#define HAL_MT_NB_STAT_EXCPT_CNT_BMP_WORD_EGR \
    (((HAL_MT_NB_STAT_EXCPT_CNT_TYPE_NUM_EGR - 1) / 32) + 1)
#define HAL_MT_NB_STAT_DIE_NUM                      (4)
#define HAL_MT_NB_STAT_MAC_NUM_PER_DIE              (8)
#define HAL_MT_NB_STAT_LANE_NUM_PER_MAC             (8)
#define HAL_MT_NB_STAT_ETHL_LANE_NUM                (256)
#define HAL_MT_NB_STAT_ETHX_LANE_NUM                (2)
#define HAL_MT_NB_STAT_CPU_LANE_NUM                 (1)
#define HAL_MT_NB_STAT_TM_QUEUECNT_NUM_PER_PLANE    (576)
#define HAL_MT_NB_STAT_TM_CPU_QUEUE_NUM             (48)
#define HAL_MT_NB_STAT_TM_CPI_QUEUE_NUM             (16)
#define HAL_MT_NB_STAT_FLEX_CNT_ID_IGR_PARITY_DROP  (9)
#define HAL_MT_NB_STAT_FLEX_CNT_ID_L3_IGR_BLACKHOLE (10)
#define HAL_MT_NB_STAT_FLEX_CNT_ID_L3_IGR_DROP      (11)
#define HAL_MT_NB_STAT_MAX_TOLORENCE_INTERVAL       (1350000)
#define HAL_MT_NB_STAT_DEFAULT_POLLING_INTERVAL_MS  (500)
#define HAL_MT_NB_STAT_MIN_POLLING_INTERVAL_MS      (250)
#define HAL_MT_NB_STAT_MAX_POLLING_INTERVAL_MS      (1000)
#define HAL_MT_NB_STAT_RSFEC_DEFAULT_UPDATE_INTVL   (1000000)
/* single-die all rsfec-cerr counter update time estimate is around 1500us, \
 * limit interval to be the safe side for suppporting 4-die */
#define HAL_MT_NB_STAT_RSFEC_MIN_UPDATE_INTVL (10000)

#define HAL_MT_NB_STAT_CFG_SAI_STAT_BANK0               (0)
#define HAL_MT_NB_STAT_CFG_SAI_STAT_BANK1               (1)
#define HAL_MT_NB_STAT_OQ_DROP_ECN_CNT_NUM              (4)
#define HAL_MT_NB_STAT_SQ_NUM_PER_PLANE                 (328)
#define HAL_MT_NB_STAT_SQ_NUM_PER_PORT                  (8)
#define HAL_MT_NB_STAT_GET_SQ_ID(ppid, id)              (((ppid) << 3) + (id))
#define HAL_MT_NB_STAT_PP_HEADER_LEN                    (40)
#define HAL_MT_NB_STAT_PL_FLAGS_MAC                     (1U << 0)
#define HAL_MT_NB_STAT_PP_FLAGS_TDS                     (1U << 1)
#define HAL_MT_NB_STAT_PP_FLAGS_DIS                     (1U << 2)
#define HAL_MT_NB_STAT_PP_FLAGS_FPU                     (1U << 3)
#define HAL_MT_NB_STAT_PP_FLAGS_ICIA                    (1U << 4)
#define HAL_MT_NB_STAT_PP_FLAGS_FWR                     (1U << 5)
#define HAL_MT_NB_STAT_PP_FLAGS_TM                      (1U << 6)
#define HAL_MT_NB_STAT_PP_FLAGS_RWI                     (1U << 7)
#define HAL_MT_NB_STAT_PP_FLAGS_ECIA                    (1U << 8)
#define HAL_MT_NB_STAT_PP_FLAGS_RWO                     (1U << 9)
#define HAL_MT_NB_STAT_PP_FLAGS_ALL                     (0x1FF)
#define HAL_MT_NAMCHABARWA_TBL_CNT_RSLT_xPORT_ENTRY_NUM (240)
#define HAL_MT_NB_STAT_CNT_RSN_GRP0_xPORT_ENTRY_NUM     (40)
#define HAL_MT_NB_STAT_CNT_RSN_GRP0_ID                  (0x7)
#define HAL_MT_NB_STAT_CNT_RSN_GRP0_VALID               (0x1)
#define HAL_MT_NB_STAT_CNT_IPL_xPORT_ENTRY_NUM          (32)

#define HAL_MT_NB_STAT_TM_CNT_UPDATE(dst, src, clear) \
    do {                                              \
        if (clear) {                                  \
            UI64_SET(src, _hal_mt_nb_stat_ui64_zero); \
        } else {                                      \
            dst += src;                               \
        }                                             \
    } while (0)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_MT_NB_STAT_RSFEC_LOCK(__unit__) \
    osal_semaphore_take(&(_hal_stat_rsfec_cb[__unit__].sema), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_NB_STAT_RSFEC_UNLOCK(__unit__) \
    osal_semaphore_give(&(_hal_stat_rsfec_cb[__unit__].sema))

#ifdef CLX_STAT_EN_HPC_CNT
#define HAL_MT_NB_STAT_HPC_MAX_FIFO_SIZE           (4 * 1024)
#define HAL_MT_NB_STAT_HPC_MIN_FIFO_SIZE           (1 * 1024)
#define HAL_MT_NB_STAT_HPC_MAX_POLLING_INTERVAL_US (500000)
#define HAL_MT_NB_STAT_HPC_MIN_POLLING_INTERVAL_US (800)
#define HAL_MT_NB_STAT_HPC_THREAD_STACK_SIZE       (32 * 1024)
#define HAL_MT_NB_STAT_HPC_THREAD_PRIORITY         (80)
#define HAL_MT_NB_STAT_HPC_CNT_LOCK(__unit__)                              \
    osal_semaphore_take(&(_hal_mt_nb_stat_hpc_cb[__unit__].stat_buf.sema), \
                        CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_NB_STAT_HPC_CNT_UNLOCK(__unit__) \
    osal_semaphore_give(&(_hal_mt_nb_stat_hpc_cb[__unit__].stat_buf.sema))
#define HAL_MT_NB_STAT_HPC_DMA_LOCK(__unit__) \
    osal_semaphore_take(&(_hal_mt_nb_stat_hpc_cb[__unit__].sema_dma), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_NB_STAT_HPC_DMA_UNLOCK(__unit__) \
    osal_semaphore_give(&(_hal_mt_nb_stat_hpc_cb[__unit__].sema_dma))
#define HAL_MT_NB_STAT_HPC_QUEUE_LOCK(__unit__)                                   \
    osal_semaphore_take(&(_hal_mt_nb_stat_hpc_cb[__unit__].hpc_queue.sema_queue), \
                        CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_NB_STAT_HPC_QUEUE_UNLOCK(__unit__) \
    osal_semaphore_give(&(_hal_mt_nb_stat_hpc_cb[__unit__].hpc_queue.sema_queue))

#define HAL_MT_NB_STAT_HPC_DMA_MIB_BUF_SIZE(__unit__)                                           \
    (HAL_MAX_NUM_OF_PLANE * TOB_TABLE(__unit__, MT_NB_REG_UMAC_AXI_MIB_MEM_ID)->subinst_count * \
     TOB_TABLE(__unit__, MT_NB_REG_UMAC_AXI_MIB_MEM_ID)->entry_size *                           \
     HAL_MT_NB_STAT_LANE_NUM_PER_MAC * HAL_MT_NB_STAT_MIB_SRAM_LANE_IDX_OFFSET)

#define HAL_MT_NB_STAT_HPC_IPL_UTILIZATION_DMA_BUF_SIZE(__unit__) \
    CLX_STAT_HPC_TOTAL_PORT *TOB_TABLE(__unit__,                  \
                                       MT_NB_REG_IPL_APP_MBURST_AVERAGE_RATE_0_ID) -> entry_size

#define HAL_MT_NB_STAT_HPC_DMA_EPL_UTILIZATION_BUF_SIZE(__unit__) \
    CLX_STAT_HPC_TOTAL_PORT *TOB_TABLE(                           \
        __unit__, MT_NB_REG_EPL_APP_STA_AVERAGE_RATE_ETH_PORT_0_ID) -> entry_size

#define HAL_MT_NB_STAT_HPC_DMA_BUF_SIZE(__unit__)                   \
    HAL_MT_NB_STAT_HPC_DMA_MIB_BUF_SIZE(__unit__) +                 \
        HAL_MT_NB_STAT_HPC_IPL_UTILIZATION_DMA_BUF_SIZE(__unit__) + \
        HAL_MT_NB_STAT_HPC_DMA_EPL_UTILIZATION_BUF_SIZE(__unit__)

#define HAL_MT_NB_STAT_REG_UMAC_AXI_MIB_MEM_ADDR(__unit__, __inst__, __subinst__, __entry__) \
    (TOB_TABLE(__unit__, MT_NB_REG_UMAC_AXI_MIB_MEM_ID)->table_addr +                        \
     ((__inst__ / 2) * TOB_TABLE(__unit__, MT_NB_REG_UMAC_AXI_MIB_MEM_ID)->slot_size +       \
      (__inst__ % 2) * 0x00140000) +                                                         \
     TOB_TABLE(__unit__, MT_NB_REG_UMAC_AXI_MIB_MEM_ID)->subinst_offset * __subinst__ +      \
     TOB_TABLE(__unit__, MT_NB_REG_UMAC_AXI_MIB_MEM_ID)->entry_size * __entry__)

/* Calculate SRAM offset based on unit and port */
#define HAL_MT_NB_STAT_SRAM_OFFSET(__unit__, __port__, __sram_idx_offset__)          \
    do {                                                                             \
        uint32 __plane_id = HAL_MT_PORT_TO_PLANE_FOR_MAC(__unit__, __port__);        \
        uint32 __macro_id = HAL_MT_PORT_TO_MACRO_FOR_MAC(__unit__, __port__);        \
        uint32 __chan_id = HAL_CL_PORT_TO_MACRO_PORT(__unit__, __port__);            \
        __sram_idx_offset__ =                                                        \
            (__plane_id * HAL_MT_NB_STAT_DIE_NUM * HAL_MT_NB_STAT_LANE_NUM_PER_MAC * \
             HAL_MT_NB_STAT_MIB_SRAM_LANE_IDX_OFFSET) +                              \
            (__macro_id * HAL_MT_NB_STAT_LANE_NUM_PER_MAC *                          \
             HAL_MT_NB_STAT_MIB_SRAM_LANE_IDX_OFFSET) +                              \
            (__chan_id * HAL_MT_NB_STAT_MIB_SRAM_LANE_IDX_OFFSET);                   \
    } while (0)

/* #define HAL_MT_NB_STAT_HPC_QUEUE_DEBUG_EN  // use to dump all queue info, debug only */
/* #define HAL_MT_NB_STAT_HPC_DEBUG_EN  // use to dump all UMAC, debug only */
/* #define HAL_MT_NB_STAT_HPC_PERFORMANCE_TEST  // debug only */
#ifdef HAL_MT_NB_STAT_HPC_PERFORMANCE_TEST
#define HAL_MT_NB_STAT_HPC_MEASURE_COUNT (1000)
#endif
#define HAL_MT_NB_STAT_FIXED_SLEEP_TIME // Fixed sleep time to stabilize port rate */
#endif                                  /* End of CLX_STAT_EN_HPC_CNT */

#define HAL_MT_NB_STAT_UMAC_BASE_ADDR                  (0xC000)
#define HAL_MT_NB_STAT_UMAC_FEC_CERR_BASE_ADDR         (0xD3B0)
#define HAL_MT_NB_STAT_UMAC_FEC_UCERR_BASE_ADDR        (0xDB90)
#define HAL_MT_NB_STAT_UMAC_FEC_CERR_SYM_ERR_BASE_ADDR (0xE000)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_MT_NB_STAT_MIB_FRAMESXMITOK = 0,
    HAL_MT_NB_STAT_MIB_FRAMESXMITALL,
    HAL_MT_NB_STAT_MIB_FRAMESXMITERROR,
    HAL_MT_NB_STAT_MIB_OCTETSXMITOK,
    HAL_MT_NB_STAT_MIB_OCTETSXMITALL,
    HAL_MT_NB_STAT_MIB_FRAMESXMITUNICAST,
    HAL_MT_NB_STAT_MIB_FRAMESXMITMULTICAST,
    HAL_MT_NB_STAT_MIB_FRAMESXMITBROADCAST,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPAUSE,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRIPAUSE,
    HAL_MT_NB_STAT_MIB_FRAMESXMITVLAN,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZELT64,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZEEQ64,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZE65TO127,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZE128TO255,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZE256TO511,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZE512TO1023 = 16,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZE1024TO1518,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZE1519TO2047,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZE2048TO4095,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZE4096TO8191,
    HAL_MT_NB_STAT_MIB_FRAMESSMITSIZE8912TO9215,
    HAL_MT_NB_STAT_MIB_FRAMESXMITSIZEGT9216,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRI0,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRI1,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRI2,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRI3,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRI4,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRI5,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRI6,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPRI7,
    HAL_MT_NB_STAT_MIB_XMITPRI0PAUSE1US,
    HAL_MT_NB_STAT_MIB_XMITPRI1PAUSE1US = 32,
    HAL_MT_NB_STAT_MIB_XMITPRI2PAUSE1US,
    HAL_MT_NB_STAT_MIB_XMITPRI3PAUSE1US,
    HAL_MT_NB_STAT_MIB_XMITPRI4PAUSE1US,
    HAL_MT_NB_STAT_MIB_XMITPRI5PAUSE1US,
    HAL_MT_NB_STAT_MIB_XMITPRI6PAUSE1US,
    HAL_MT_NB_STAT_MIB_XMITPRI7PAUSE1US,
    HAL_MT_NB_STAT_MIB_FRAMESXMITDRAINED,
    HAL_MT_NB_STAT_MIB_FRAMESXMITJABBERED,
    HAL_MT_NB_STAT_MIB_FRAMESXMITPADDED,
    HAL_MT_NB_STAT_MIB_FRAMESXMITTRUNCATED,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDOK,
    HAL_MT_NB_STAT_MIB_OCTECTSRCVDOK,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDALL,
    HAL_MT_NB_STAT_MIB_OCTECTSRCVDALL,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDCRCERROR,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDERROR = 48,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDUNICAST,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDMULTICAST,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDBROADCAST,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPAUSE,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDLENERROR,
    HAL_MT_NB_STAT_MIB_RESERVED0,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDOVERSIZED,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDFRAGMENTS,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDJABBER,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRIPAUSE,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDCRCERRSTOMP,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDMAXFRMSIZEVIO,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDVLAN,
    HAL_MT_NB_STAT_MIB_RESERVED1,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZELT64,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZEEQ64 = 64,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE65TO127,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE128TO255,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE256TO511,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE512TO1023,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE1024TO1518,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE1419TO2047,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE2048TO4095,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE4096TO8191,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZE8912TO9215,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDSIZEGT9216,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRI0,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRI1,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRI2,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRI3,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRI4,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRI5 = 80,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRI6,
    HAL_MT_NB_STAT_MIB_FRAMESRCVDPRI7,
    HAL_MT_NB_STAT_MIB_RCVDPRI0PAUSE1US,
    HAL_MT_NB_STAT_MIB_RCVDPRI1PAUSE1US,
    HAL_MT_NB_STAT_MIB_RCVDPRI2PAUSE1US,
    HAL_MT_NB_STAT_MIB_RCVDPRI3PAUSE1US,
    HAL_MT_NB_STAT_MIB_RCVDPRI4PAUSE1US,
    HAL_MT_NB_STAT_MIB_RCVDPRI5PAUSE1US,
    HAL_MT_NB_STAT_MIB_RCVDPRI6PAUSE1US,
    HAL_MT_NB_STAT_MIB_RCVDPRI7PAUSE1US,
    HAL_MT_NB_STAT_MIB_RCVDSTDPAUSE1US,
    HAL_MT_NB_STAT_MIB_RESERVED2,
    HAL_MT_NB_STAT_MIB_RESERVED3,
    HAL_MT_NB_STAT_MIB_INVALIDPREAMBLE,
    HAL_MT_NB_STAT_MIB_NORMALLENINVALIDCRC,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_BER_ERROR_COUNTER = 96,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_ERRORED_BLOCKS_COUNTER,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_VALID_ERRORED_BLOCK_COUNTER,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_UNKNOWN_ERRORED_BLOCK_COUNTER,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_INVALID_ERRORED_BLOCK_COUNTER,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_TEST_PATTERN_ERRORS_COUNTER,
    HAL_MT_NB_STAT_MIB_RESERVED4,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_BLOCK_LOCK_LOSS_COUNTER,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_HIBER_COUNTER,
    HAL_MT_NB_STAT_MIB_RESERVED5,
    HAL_MT_NB_STAT_MIB_RESERVED6,
    HAL_MT_NB_STAT_MIB_RSFEC_COUNTERED_CODEWORDS,
    HAL_MT_NB_STAT_MIB_RSFEC_UNCOTTECTED_CODEWORDS,
    HAL_MT_NB_STAT_MIB_RSFEC_CH_SYMBOL_ERROR_COUNTER,
    HAL_MT_NB_STAT_MIB_HSMC_PCS_LANE_BIP_N_ERRORS_COUNTER,
    HAL_MT_NB_STAT_MIB_FCFEC_LANE_N_CORRECTED_CODEWORDS,
    HAL_MT_NB_STAT_MIB_FCFEC_LANE_N_UNCORRECTED_CODEWORDS = 112,
    HAL_MT_NB_STAT_MIB_RSFEC_LANE_N_SYMBOL_ERRORS,
    HAL_MT_NB_STAT_MIB_SRAM_TYPE_LAST
} hal_mt_nb_stat_mib_sram_type_t;

typedef enum {
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV4_UC = 0,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV4_MC,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV4_RECV,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV4_INVALID_HEADER,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV4_INVALID_ADDR,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV4_DROP,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV6_UC,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV6_MC,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV6_RECV,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV6_INVALID_HEADER,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV6_INVALID_ADDR,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_IPV6_DROP,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_TAGGED,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_UNTAGGED,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_L3_DROP,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_ACL_DROP,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_ICC_DROP,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_ACL_DROP_CPU,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_ERR_DROP,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_DI_RANGE_CNT0,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_DI_RANGE_CNT1,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_DI_RANGE_CNT2,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_DI_RANGE_CNT3,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_DI_RANGE_CNT4,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_DI_RANGE_CNT5,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_DI_RANGE_CNT6,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_DI_RANGE_CNT7,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_EXCPT_CNT0,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_EXCPT_CNT1,
    HAL_MT_NB_STAT_FLEX_CNT_IGR_LAST
} hal_mt_nb_stat_flex_cnt_igr_type_t;

typedef struct hal_mt_nb_stat_rsfec_task_s {
    uint32 inst_idx;
    uint32 subinst_idx;
    uint32 entry_idx;
} hal_mt_nb_stat_rsfec_task_t;

typedef struct hal_mt_nb_stat_rsfec_cb_s {
    uint64 *ptr_results;
    uint32 task_cnt;
    uint32 *ptr_tasks_id;
    hal_mt_nb_stat_rsfec_task_t *ptr_tasks;
    clx_semaphore_id_t sema;
    clx_thread_id_t update_thread_id;
    uint32 sleep_intvl;
} hal_mt_nb_stat_rsfec_cb_t;

typedef struct hal_mt_nb_stat_oq_drop_cnt_info_s {
    hal_stat_hw_type_t hw_cnt_type;
    uint32 table_id;
} hal_mt_nb_stat_oq_drop_cnt_info_t;

#ifdef CLX_STAT_EN_HPC_CNT
typedef struct {
    clx_stat_hpc_cnt_t *data;      /* Queue data buffer */
    uint32 size;                   /* Total queue size */
    uint32 head;                   /* Index for dequeue */
    uint32 tail;                   /* Index for enqueue */
    uint32 count;                  /* Current number of elements */
    clx_semaphore_id_t sema_queue; /* Queue mutex */
    boolean initialized;           /* Queue initialization flag */
} hal_mt_nb_hpc_queue_t;

typedef struct hal_mt_nb_stat_hpc_cb_s {
    hal_stat_buf_t stat_buf;
    hal_mt_nb_hpc_queue_t hpc_queue;
    clx_stat_hpc_cfg_t cfg;
    clx_semaphore_id_t sema_dma;
    boolean is_created;
    clx_thread_id_t task_id;
} hal_mt_nb_stat_hpc_cb_t;

#endif

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init stat module control blocks.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Init success.
 * @return        CLX_E_NO_MEMORY        - Allocate control block failed.
 * @return        CLX_E_OTHERS           - Init fail.
 * @return        CLX_E_BAD_PARAMETER    - Parameter invalid.
 */
clx_error_no_t
hal_mt_nb_stat_init(const uint32 unit);

/**
 * @brief Deinit stat module control blocks and free resource.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Deinit success.
 * @return        CLX_E_OTHERS           - DeInit fail.
 * @return        CLX_E_BAD_PARAMETER    - Parameter invalid.
 */
clx_error_no_t
hal_mt_nb_stat_deinit(const uint32 unit);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Port ID.
 * @param [in]     handler    - The handler of TM queue.
 * @param [in]     type       - The TM counter type.
 * @param [out]    ptr_cnt    - Counter value.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stat_tm_cnt_get(const uint32 unit,
                          const uint32 port,
                          const clx_tm_handler_t handler,
                          const clx_stat_tm_t type,
                          clx_stat_tm_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port ID.
 * @param [in]    handler    - The handler of TM queue.
 * @param [in]    type       - The TM counter type.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stat_tm_cnt_clear(const uint32 unit,
                            const uint32 port,
                            const clx_tm_handler_t handler,
                            const clx_stat_tm_t type);

/**
 * @brief This API is used to clear oq drop or ecn counter by port, queue.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port ID.
 * @param [in]    handler    - The handler of TM queue.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stat_tm_sai_oq_cnt_clear(const uint32 unit,
                                   const uint32 port,
                                   const clx_tm_handler_t handler);

/**
 * @brief This API is used to get port MIB raw counter.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port.
 * @param [in]     hw_type     - The type of HW, ETHC or ETHX.
 * @param [in]     cnt_type    - The type of counter.
 * @param [out]    ptr_cnt     - Pointer to counter.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_mib_raw_get(const uint32 unit,
                           const uint32 port,
                           const hal_stat_hw_type_t hw_type,
                           const hal_mt_nb_stat_mib_sram_type_t cnt_type,
                           uint64 *ptr_cnt);

/**
 * @brief This API is used to get FEC port MIB raw counter.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Physical port.
 * @param [in]     hw_type      - The type of HW, ETHC or ETHX.
 * @param [in]     entry_idx    - The index of the entry.
 * @param [out]    ptr_cnt      - Pointer to counter.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_mib_fec_raw_get(const uint32 unit,
                               const uint32 port,
                               const hal_stat_hw_type_t hw_type,
                               const uint32 entry_idx,
                               uint64 *ptr_cnt);

/**
 * @brief This API is used to clear port MIB raw counter.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port.
 * @param [in]    hw_type     - The type of HW, ETHC or ETHX.
 * @param [in]    cnt_type    - The type of counter.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_mib_raw_clear(const uint32 unit,
                             const uint32 port,
                             const hal_stat_hw_type_t hw_type,
                             const hal_mt_nb_stat_mib_sram_type_t cnt_type);

/**
 * @brief This API is used to get FEC port MIB raw counter.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - Physical port.
 * @param [in]    hw_type      - The type of HW, ETHC or ETHX.
 * @param [in]    entry_idx    - The index of the entry.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_mib_fec_raw_clear(const uint32 unit,
                                 const uint32 port,
                                 const hal_stat_hw_type_t hw_type,
                                 const uint32 entry_idx);

/**
 * @brief This API is used to get how many times the counter has been updated.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cnt    - Update count.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_update_cnt_get(const uint32 unit, uint64 *ptr_cnt);

/**
 * @brief This API is used to get PP exception counter by port.
 *
 * It's caller's responsibility to pass an bitmap of correct size.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     dir           - Ingress or egress.
 * @param [in]     port          - Physical port.
 * @param [out]    excpt_bmap    - Exception state: bitmap for occurrence indication.
 * @param [out]    ptr_cnt       - Pointer to counter value.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_getExcptCnt(const uint32 unit,
                           const clx_dir_t dir,
                           const uint32 port,
                           uint32 *excpt_bmap,
                           uint64 *ptr_cnt);

/**
 * @brief This API is used to clear PP exception counter by port.
 *
 * This API will clear both counter and exception state.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    dir     - Ingress or egress.
 * @param [in]    port    - Physical port.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_clearExcptCnt(const uint32 unit, const clx_dir_t dir, const uint32 port);

/**
 * @brief This API is used to get PP storm control counter by index.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     plane      - Plane number.
 * @param [in]     cnt_idx    - The strom control counter index.
 * @param [out]    ptr_cnt    - Pointer to corresponding counter entry (3 values).
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_storm_cnt_get(const uint32 unit,
                             const uint32 plane,
                             const uint32 cnt_idx,
                             hal_sec_sccounter_entry_t *ptr_cnt);

/**
 * @brief This API is used to clear PP storm control counter by index.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    plane      - Plane number.
 * @param [in]    cnt_idx    - The strom control counter index.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_storm_cnt_clear(const uint32 unit, const uint32 plane, const uint32 cnt_idx);

/**
 * @brief This API is used to show debug counter.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port         - CLX port number.
 * @param [in]    stage_bmp    - The bitmap of stage: bit0: mac; bit1: ipm;
 *                               bit2: ios: bit3: ipp; bit4: xbn; bit5: tm;
 *                               bit6: epp; bit7: epm; bit8: lbm.
 * @param [in]    flags        - Show the counter or not if it is zero.
 */
clx_error_no_t
hal_mt_nb_stat_dbg_cnt_show(const uint32 unit,
                            const uint32 port,
                            const uint32 stage_bmp,
                            const uint32 flags);

/**
 * @brief This API is used to clear all debug counter.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_dbg_cnt_clear(const uint32 unit);

/**
 * @brief This API is used to trigger manually counter update to get latest counter value.
 *
 * The API takes time to collect latest counter please use it wisely.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK             - Success.
 * @return        CLX_E_NOT_SUPPORT    - Not support in current mode.
 */
clx_error_no_t
hal_mt_nb_stat_cnt_refresh(const uint32 unit);

/**
 * @brief This API is used to set RS-FEC error distribution counter polling interval.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    interval    - Polling interval (unit: microsecond).
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_rs_err_dist_cnt_interval_set(const uint32 unit, const uint32 interval);

/**
 * @brief This API is used to get PP counter HW index using SW index.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     sw_cnt_id         - SW counter id.
 * @param [in]     cnt_type          - Counter type.
 * @param [in]     pp_obj_type       - PP binding object type.
 * @param [out]    ptr_hw_cnt_idx    - HW counter idx.
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_TABLE_FULL         - No available HW resource.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The SW counter has not been created.
 */
clx_error_no_t
hal_mt_nb_stat_cnt_hw_idx_get(const uint32 unit,
                              const uint32 sw_cnt_id,
                              const hal_stat_hw_type_t cnt_type,
                              const hal_stat_pp_obj_type_t pp_obj_type,
                              uint32 *ptr_hw_cnt_idx);

/**
 * @brief To get a PP HW counter bank Id and corresponding index Id.
 *
 * @param [in]     unit                       - Device unit number.
 * @param [in]     hw_cnt_id                  - HW counter Id.
 * @param [in]     mode                       - Counter mode.
 * @param [out]    ptr_bank_id                - The HW bank Id of the corresponding counter.
 * @param [out]    ptr_sw_bmap_idx_of_bank    - The index the corresponding counter in the bank.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 */
clx_error_no_t
hal_mt_nb_stat_pp_bank_id_get(const uint32 unit,
                              const uint32 hw_cnt_id,
                              const clx_stat_srv_cnt_mode_t mode,
                              uint32 *ptr_bank_id,
                              uint32 *ptr_sw_bmap_idx_of_bank);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * The number of counters value return is determined by the type of counter under study.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     cnt_id     - Counter ID.
 * @param [out]    ptr_cnt    - The return counter values.
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
hal_mt_nb_stat_cnt_get(const uint32 unit, const uint32 cnt_id, clx_stat_srv_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter ID.
 * @return        CLX_E_OK                 - Success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
hal_mt_nb_stat_cnt_clear(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     rx_reason_code    - Rx reason code.
 * @param [out]    ptr_cnt           - The return counter values.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_reason_cnt_get(const uint32 unit,
                              const clx_pkt_rx_reason_t rx_reason_code,
                              uint64 *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    rx_reason_code    - Rx reason code.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_reason_cnt_clear(const uint32 unit, const clx_pkt_rx_reason_t rx_reason_code);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     rsn_code    - Rx reason code.
 * @param [out]    ptr_cnt     - The return counter values.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_nb_stat_hw_reason_cnt_get(const uint32 unit,
                                 const clx_pkt_hw_reason_t rsn_code,
                                 uint64 *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    rsn_code    - RX reason code.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_mt_nb_stat_hw_reason_cnt_clear(const uint32 unit, const clx_pkt_hw_reason_t rsn_code);

/**
 * @brief This API is used to get TM queue counter index by TM handler.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     handler    - The handler of TM queue.
 * @param [out]    ptr_idx    - Queue counter index.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_queue_cnt_idx_get(const uint32 unit,
                                 const clx_tm_handler_t handler,
                                 uint32 *ptr_idx);

/**
 * @brief This API is used to get port rate type from port cnt type.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - The type of port cnt.
 * @param [out]    rate_type    - The type of traffic rate.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_port_rate_type_get(const uint32 unit,
                                  const clx_stat_port_t type,
                                  clx_stat_rate_type_t *rate_type);

#ifdef CLX_STAT_EN_HPC_CNT

/**
 * @brief This API is used to set mburst property.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Port number.
 * @param [in]    window    - Window size.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OP_INVALID       - Operation invalid.
 */
clx_error_no_t
hal_mt_nb_stat_mburst_property_set(const uint32 unit, const uint32 port, const uint32 window);

/**
 * @brief This API is used to get HPC counter state.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Operation success.
 * @return        CLX_E_NOT_INITED    - Not initialized.
 */
clx_error_no_t
hal_mt_nb_stat_hpc_state(const uint32 unit);

/**
 * @brief This API is used to create HPC counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cfg     - Cfg with polling time and FIFO size.
 * @return        CLX_E_OK                - Operation success.
 * @return        CLX_E_ALREADY_INITED    - Already initialized.
 * @return        CLX_E_BAD_PARAMETER     - Bad parameter.
 * @return        CLX_E_NO_MEMORY         - No memory.
 * @return        CLX_E_OTHER             - Other error.
 */
clx_error_no_t
hal_mt_nb_stat_hpc_create(const uint32 unit, const clx_stat_hpc_cfg_t cfg);

/**
 * @brief This API is used to destroy HPC counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - Not initialized.
 */
clx_error_no_t
hal_mt_nb_stat_hpc_destroy(const uint32 unit);

clx_error_no_t
hal_mt_nb_stat_hpc_dequeue(const uint32 unit, clx_stat_hpc_cnt_t *ptr_hpc_cnt_node);
#endif /* End of CLX_STAT_EN_HPC_CNT */

/**
 * @brief This API is used to get watermark counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Port number.
 * @param [in]     handler    - Tm queue handler.
 * @param [out]    ptr_cnt    - The return counter values.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_hrm_watermark_get(const uint32 unit,
                                 const uint32 port,
                                 const clx_tm_handler_t handler,
                                 uint32 *ptr_cnt);

/**
 * @brief This API is used to clear the watermark counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port number.
 * @param [in]    handler    - Tm queue handler.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_hrm_watermark_clear(const uint32 unit,
                                   const uint32 port,
                                   const clx_tm_handler_t handler);

/**
 * @brief This API is used to get the watermark counter occupancy.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Port number.
 * @param [in]     handler          - Tm queue handler.
 * @param [out]    ptr_occupancy    - Watermark counter occupancy.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stat_hrm_occupancy_get(const uint32 unit,
                                 const uint32 port,
                                 const clx_tm_handler_t handler,
                                 uint32 *ptr_occupancy);
#endif /* End of HAL_MT_NB_STAT_H */
