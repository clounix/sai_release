/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv_dma_mt_dma.h
 * PURPOSE:
 *  1. Provide the access interfaces of DMA and CLD DMA to chip Device Control Command(DRV_MT).
 *  2. Define DRV_MT DMA and CLD DMA related structures.
 *
 * NOTES:
 *
 */

#ifndef DRV_DMA_MT_H
#define DRV_DMA_MT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>
#include <clx/clx_init.h>
#include <drv/drv_dma.h>

/* NAMING CONSTANT DECLARATIONS
 */

/*
 * descriptor
    63---------------47-----------------------------------------------0
    |       size     |                  s_addr                        |
    |      [63:48]   |                  [47:0]                        |
0x8  ----------------|------------------------------------------------|
    |      status    |                  d_addr                        |
    |      [63:48]   |                  [47:0]                        |
0x10 ----------------|------------------------------------------------|

*/
#if defined(CLX_EN_LITTLE_ENDIAN)
typedef struct drv_dma_mt_desc_s {
    uint32 s_addr_lo : 32;
    uint32 s_addr_hi : 16;
    uint32 size : 16;
    uint32 d_addr_lo : 32;
    uint32 d_addr_hi : 16;

    /*status[127:112]*/
    uint32 interrupt : 1;
    uint32 err : 1;
    uint32 eop : 1;
    uint32 sop : 1;
    uint32 sinc : 1;
    uint32 dinc : 1;
    uint32 xfer_size : 5;
    uint32 reserve : 5;

} drv_dma_mt_desc_t;
#elif defined(CLX_EN_BIG_ENDIAN)
typedef struct drv_dma_mt_desc_s {
    /*status[127:112]*/
    uint32 reserve : 5;
    uint32 xfer_size : 5;
    uint32 dinc : 1;
    uint32 sinc : 1;
    uint32 sop : 1;
    uint32 eop : 1;
    uint32 err : 1;
    uint32 interrupt : 1;

    uint32 d_addr_lo : 32;
    uint32 d_addr_hi : 16;
    uint32 size : 16;
    uint32 s_addr_lo : 32;
    uint32 s_addr_hi : 16;

} drv_dma_mt_desc_t;
#else
#error "Host DMA endian is not defined\n"
#endif

typedef clx_error_no_t (*drv_dma_channel_no_value__func_t)(uint32_t unit, uint32_t channel);
typedef clx_error_no_t (*drv_dma_channel_uint64_set_func_t)(uint32_t unit,
                                                            uint32_t channel,
                                                            clx_addr_t ring_base);
typedef clx_error_no_t (*drv_dma_channel_uint64_get_func_t)(uint32_t unit,
                                                            uint32_t channel,
                                                            clx_addr_t *ring_base);
typedef clx_error_no_t (*drv_dma_channel_uint32_set_func_t)(uint32_t unit,
                                                            uint32_t channel,
                                                            uint32_t ring_size);
typedef clx_error_no_t (*drv_dma_channel_uint32_get_func_t)(uint32_t unit,
                                                            uint32_t channel,
                                                            uint32_t *ring_size);

typedef struct drv_dma_ch_reg_s {
    drv_dma_channel_no_value__func_t drv_dma_channel_enable;
    drv_dma_channel_no_value__func_t drv_dma_channel_disable;
    drv_dma_channel_no_value__func_t drv_dma_channel_reset;
    drv_dma_channel_no_value__func_t drv_dma_channel_restart;
    drv_dma_channel_uint64_set_func_t drv_dma_channel_ring_base_set;
    drv_dma_channel_uint64_get_func_t drv_dma_channel_ring_base_get;
    drv_dma_channel_uint32_set_func_t drv_dma_channel_ring_size_set;
    drv_dma_channel_uint32_get_func_t drv_dma_channel_ring_size_get;
    drv_dma_channel_uint32_set_func_t drv_dma_channel_work_idx_set;
    drv_dma_channel_uint32_get_func_t drv_dma_channel_work_idx_get;
    drv_dma_channel_uint32_get_func_t drv_dma_channel_pop_idx_get;
} drv_dma_ch_reg_t;

extern drv_dma_ch_reg_t *drv_dma_ch_reg;

clx_error_no_t
drv_dma_mt_channel_enable(uint32_t unit, uint32_t channel);
clx_error_no_t
drv_dma_mt_channel_disable(uint32_t unit, uint32_t channel);
clx_error_no_t
drv_dma_mt_channel_ring_base_set(uint32_t unit, uint32_t channel, clx_addr_t ring_base);
clx_error_no_t
drv_dma_mt_channel_ring_base_get(uint32_t unit, uint32_t channel, clx_addr_t *ring_base);
clx_error_no_t
drv_dma_mt_channel_ring_size_set(uint32_t unit, uint32_t channel, uint32_t ring_size);
clx_error_no_t
drv_dma_mt_channel_ring_size_get(uint32_t unit, uint32_t channel, uint32_t *ring_size);
clx_error_no_t
drv_dma_mt_channel_work_idx_set(uint32_t unit, uint32_t channel, uint32_t work_idx);
clx_error_no_t
drv_dma_mt_channel_work_idx_get(uint32_t unit, uint32_t channel, uint32_t *work_idx);
clx_error_no_t
drv_dma_mt_channel_pop_idx_get(uint32_t unit, uint32_t channel, uint32_t *pop_idx);
clx_error_no_t
drv_dma_mt_channel_reset(uint32_t unit, uint32_t channel);
clx_error_no_t
drv_dma_mt_channel_restart(uint32_t unit, uint32_t channel);

#endif /* END of DRV_DMA_MT_H*/
