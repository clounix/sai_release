/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_mpool.h
 * PURPOSE:
 *  provide memory pool API to other modules.
 * NOTES:
 *  1. create a new memory pool.
 *  2. allocate a memory block from the memory pool.
 *  3. free a memory block to the memory pool.
 *  4. destroy a memory pool.
 *
 */
#ifndef UTIL_LIB_MPOOL_H
#define UTIL_LIB_MPOOL_H
/* INCLUDE FILE DECLARATIONS
 */
#include <util/lib/util_lib.h>
/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
/* DATA TYPE DECLARATIONS
 */

struct util_lib_mpool_node_s;

/* mem pool node */
typedef struct util_lib_mpool_node_s {
    struct util_lib_mpool_node_s *ptr_next; /* point to next node */
} util_lib_mpool_node_t;

/* mem pool control block */
typedef struct util_lib_mpool_s {
    uint8 *ptr_buf;                       /* mem pool start address      */
    util_lib_mpool_node_t *ptr_free_list; /* free list                   */
    uint32 block_count;                   /* block count in the mem pool */
    uint32 block_size;                    /* block size in bytes         */
    uint32 init_count;                    /* the inited count of block   */
    void *ptr_user_buf;                   /* user provide to mem pool    */
} util_lib_mpool_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief it is used to release a data to mem pool.
 *
 * @param [in]     ptr_mpool    - the mem pool owns the data.
 * @param [in]     ptr_data     - the data will be released.
 * @return         CLX_E_OK               - free succes.
 * @return         CLX_E_BAD_PARAMETER    - parameter is null pointer or data is not belonged
 *                                          the mem pool.
 */
clx_error_no_t
util_lib_mpool_free(util_lib_mpool_t *ptr_mpool, void *ptr_data);

/**
 * @brief it is used to allocate a data from the mem pool.
 *
 * @param [in]     ptr_mpool    - the mem pool owns the data.
 *                           void pointer  -- Successfully allocate this size of memory pool.
 * @return         NULL    - Fail to allocate data memory.
 */
void *
util_lib_mpool_alloc(util_lib_mpool_t *ptr_mpool);

/**
 * @brief it is used to create a mem pool.
 *
 * if user provide the buffer:
 * if the block size is more than or equal to 4 bytes, the user buffer size
 * can be block_size * block_count.
 * if the block size is less than 4 bytes, the user buffer size should be
 * 4 * block_count.
 * eg:
 * block_size = 1, block_count = 1K, the user buffer must be 4*1K=4K.
 * block_size = 5, block_count = 1K, the user buffer must be 5*1K=5K.
 * in 64-bits environment, above "4 bytes" should change to "8 bytes"
 *
 * @param [in]     block_size      - the mem block size, in bytes.
 * @param [in]     block_count     - the count of blocks in the mem pool.
 * @param [in]     ptr_user_buf    - NULL    : the mem pool need allocate all the blocks.
 *                                   non NULL: user provide the blocks buffer.
 * @param [in]     ptr_name        - the mpool name, max length is UTIL_LIB_NAME_LEN_MAX(include
 * '\0')
 * @param [out]    pptr_mpool      - new mem pool control block.
 * @return         CLX_E_OK               - free succes.
 * @return         CLX_E_BAD_PARAMETER    - block size * block_count overflow or block size
 *                                          is 0 or block count is 0, or there is null
 *                                          pointer.
 * @return         CLX_E_NO_MEMORY        - allocate mem pool control block or blocks buffer
 *                                          failed.
 */
clx_error_no_t
util_lib_mpool_create(uint32 block_size,
                      const uint32 block_count,
                      void *const ptr_user_buf,
                      const char *ptr_name,
                      util_lib_mpool_t **pptr_mpool);

/**
 * @brief it is used to destroy a mem pool.
 *
 * @param [in]     ptr_mpool        - the mem pool will be destroyed.
 * @param [out]    pptr_user_buf    - if the mem pool block buffer is provided by user, it
 *                                    is used to return the buffer to user. or it can be
 *                                    null.
 * @return         CLX_E_OK               - free succes.
 * @return         CLX_E_BAD_PARAMETER    - there is null pointer. if the mem pool block
 *                                          buffer is not provided by user, pptr_user_buf
 *                                          can be null.
 */
clx_error_no_t
util_lib_mpool_destroy(util_lib_mpool_t *ptr_mpool, void **pptr_user_buf);

#endif /* End of UTIL_LIB_MPOOL_H */
