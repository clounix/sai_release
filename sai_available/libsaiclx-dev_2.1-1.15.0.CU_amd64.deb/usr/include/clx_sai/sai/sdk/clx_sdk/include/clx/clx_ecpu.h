/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_ecpu.h
 *
 * PURPOSE:
 *      It provides ecpu module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_ECPU_H
#define CLX_ECPU_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <util/lib/util_lib_queue.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_ECPU_FW_NAME_LEN_MAX     128
#define CLX_ECPU_FW_APP_NAME_LEN_MAX 128
#define CLX_ECPU_FW_DESC_LEN_MAX     128
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum clx_ecpu_fw_feature_type_e {
    CLX_ECPU_FW_FEATURE_TYPE_PTP = 0,              /* PTP */
    CLX_ECPU_FW_FEATURE_TYPE_BFD,                  /* BFD */
    CLX_ECPU_FW_FEATURE_TYPE_MICRO_BURST_DETECTOR, /* MicroBurstDetector */
    CLX_ECPU_FW_FEATURE_TYPE_HEAD_ROOM_COUNTER,    /* HeadRoomCounter */
    CLX_ECPU_FW_FEATURE_TYPE_MAX,                  /* Max */
} clx_ecpu_fw_feature_type_t;

typedef struct clx_ecpu_fw_app_info_s {
    char name[CLX_ECPU_FW_APP_NAME_LEN_MAX]; /* App name */
    char desc[CLX_ECPU_FW_DESC_LEN_MAX];     /* App description */
} clx_ecpu_fw_app_info_t;

typedef struct clx_ecpu_fw_desc_s {
    uint32 index;                        /* Firmware index */
    char name[CLX_ECPU_FW_NAME_LEN_MAX]; /* Firmware name */
    uint32 app_num;                      /* App number */
} clx_ecpu_fw_desc_t;

typedef clx_error_no_t (*clx_ecpu_fw_trav_func_t)(const clx_ecpu_fw_desc_t *ptr_fw_info,
                                                  const clx_ecpu_fw_app_info_t *ptr_app_info,
                                                  const uint32 app_len,
                                                  void *ptr_cookie);

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief This API is used to check whether ecpu feature is supported.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    feature_type    - Feature type.
 * @return        CLX_E_OK             - Successfully.
 * @return        CLX_E_NOT_SUPPORT    - Feature is not supported.
 */
clx_error_no_t
clx_ecpu_fw_feature_is_supported(const uint32 unit, const clx_ecpu_fw_feature_type_t feature_type);

/**
 * @brief This API is used to set the default firmware index.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    index    - Default firmware index.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ecpu_fw_dflt_set(const uint32 unit, const uint32 index);

/**
 * @brief This API is used to get the default firmware index.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_index    - Default firmware index.
 * @return         CLX_E_OK        - Successfully.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ecpu_fw_dflt_get(const uint32 unit, uint32 *ptr_index);

/**
 * @brief This API is used to get the running firmware index.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [out]    ptr_index    - Running firmware index.
 * @return         CLX_E_OK            - Successfully.
 * @return         CLX_E_NOT_INITED    - Ecpu is not running.
 */
clx_error_no_t
clx_ecpu_fw_running_get(const uint32 unit, uint32 *ptr_index);

/**
 * @brief This API is used to get the firmware info.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    callback      - Firmware index.
 * @param [in]    ptr_cookie    - Firmware description.
 * @return        CLX_E_OK                 - Successfully.
 * @return        CLX_E_BAD_PARAMETER      - Other errors.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No memory.
 */
clx_error_no_t
clx_ecpu_fw_info_trav(const uint32 unit, const clx_ecpu_fw_trav_func_t callback, void *ptr_cookie);

#endif /* End of CLX_ECPU_H */
