/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_qos.h
 * PURPOSE:
 *      It provides hal qos module API.
 * NOTES:
 *      None.
 */

#ifndef HAL_QOS_H
#define HAL_QOS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_qos.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_QOS_PHB_PROF_NUM   (128) /* qos phb_prof_idx max alloc number */
#define HAL_QOS_PRI_NUM        (8)
#define HAL_QOS_DIRECTION_NUM  (2)   /* including ingress and egress */
#define HAL_QOS_PCP_DEI_OFFSET (4)
#define HAL_QOS_DEI_OFFSET     (1)
#define HAL_QOS_DSCP_OFFSET    (6)
#define HAL_QOS_EXP_OFFSET     (3)
#define HAL_QOS_PHB_OFFSET     (5)
#define HAL_QOS_COLOR_OFFSET   (2)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_QOS_IDX_PCP_DEI_TO_PHB_OFFSET(_DEI_, _PCP_, _PCP_DEI_TO_PHB_PROFILE_IDX_) \
    (((_PCP_DEI_TO_PHB_PROFILE_IDX_) << HAL_QOS_PCP_DEI_OFFSET) |                     \
     ((_PCP_) << HAL_QOS_DEI_OFFSET) | (_DEI_))
#define HAL_QOS_IDX_DSCP_TO_PHB_OFFSET(_DSCP_, _DSCP_TO_PHB_PROFILE_IDX_) \
    (((_DSCP_TO_PHB_PROFILE_IDX_) << HAL_QOS_DSCP_OFFSET) | (_DSCP_))
#define HAL_QOS_IDX_EXP_TO_PHB_OFFSET(_EXP_, _EXP_TO_PHB_PROFILE_IDX_) \
    (((_EXP_TO_PHB_PROFILE_IDX_) << HAL_QOS_EXP_OFFSET) | (_EXP_))
#define HAL_QOS_IDX_PHB_TO_PRI_OFFSET(_COLOR_, _TC_, _PHB_TO_PRI_PROFILE_IDX_)               \
    (((_PHB_TO_PRI_PROFILE_IDX_) << HAL_QOS_PHB_OFFSET) | ((_TC_) << HAL_QOS_COLOR_OFFSET) | \
     (_COLOR_))

#define HAL_QOS_LOCK(unit)   HAL_COMMON_LOCK_RESOURCE(&_prof_sema[unit], CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_QOS_UNLOCK(unit) HAL_COMMON_FREE_RESOURCE(&_prof_sema[unit])

typedef uint32 hal_qos_used_bitmap[4];

typedef struct hal_qos_used_flag_s {
    hal_qos_used_bitmap hal_ing_dot1p_used_bitmap;
    hal_qos_used_bitmap hal_egr_dot1p_used_bitmap;
    hal_qos_used_bitmap hal_ing_dscp_used_bitmap;
    hal_qos_used_bitmap hal_egr_dscp_used_bitmap;
    hal_qos_used_bitmap hal_ing_exp_used_bitmap;
    hal_qos_used_bitmap hal_egr_exp_used_bitmap;
} hal_qos_used_flag_t;

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_qos_intf_type_e {
    HAL_QOS_INTF_TYPE_LCL_INTF,
    HAL_QOS_INTF_TYPE_SRV_INTF,
    HAL_QOS_INTF_TYPE_LAST
} hal_qos_intf_type_t;

typedef enum { HAL_QOS_WBDB_CB, HAL_QOS_WBDB_PROFILE, HAL_QOS_WBDB_LAST } HAL_QOS_WBDB_T;

typedef struct hal_qos_pri_to_phb_sw_entry_s {
    uint8 priority;
    clx_color_t color;
} hal_qos_pri_to_phb_sw_entry_t;

typedef struct hal_qos_pri_to_phb_field_s {
    uint32 priority : 1;
    uint32 color : 1;
} hal_qos_pri_to_phb_field_t;

typedef struct hal_qos_phb_to_dot1p_sw_entry_s {
    uint8 pcp;
    uint8 dei;
} hal_qos_phb_to_dot1p_sw_entry_t;

typedef struct hal_qos_phb_to_dot1p_field_s {
    uint32 dot1p : 1;
} hal_qos_phb_to_dot1p_field_t;

typedef struct hal_qos_phb_to_dscp_sw_entry_s {
    uint8 dscp;
} hal_qos_phb_to_dscp_sw_entry_t;

typedef struct hal_qos_phb_to_dscp_field_s {
    uint32 dscp : 1;
} hal_qos_phb_to_dscp_field_t;

typedef struct hal_qos_phb_to_exp_sw_entry_s {
    uint8 exp;
    uint8 exp_l_lsp;
} hal_qos_phb_to_exp_sw_entry_t;

typedef struct hal_qos_phb_to_exp_field_s {
    uint32 exp : 1;
    uint32 exp_l_lsp : 1;
} hal_qos_phb_to_exp_field_t;

typedef struct hal_qos_init_phb_to_dot1p_entry_s {
    uint32 dot1p;
} hal_qos_init_phb_to_dot1p_entry_t;

typedef struct hal_qos_init_phb_to_dscp_entry_s {
    uint8 dscp;
} hal_qos_init_phb_to_dscp_entry_t;

typedef struct hal_qos_init_phb_to_exp_entry_s {
    uint8 exp;
    uint8 exp_l_lsp;
} hal_qos_init_phb_to_exp_entry_t;

typedef struct hal_qos_init_pri_to_phb_entry_s {
    uint8 priority;
    clx_color_t color;
} hal_qos_init_pri_to_phb_entry_t;

/* LOCAL SUBPROGRAM DECLARATIONS
 */

/**
 * @brief Init qos module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Init fail.
 */
clx_error_no_t
hal_qos_init(const uint32 unit);

/**
 * @brief Deinitialize Qos module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Deinitialize success.
 * @return        CLX_E_OTHERS    - Deinitialize failed.
 */
clx_error_no_t
hal_qos_deinit(const uint32 unit);

/**
 * @brief This API is used to create a new QoS profile (also called QoS mapping).
 *        QoS mapping is the mapping between {pcp,dei}, {dscp} or {exp} to {priority,
 *        color}. priority(traffic class) is used by chip to derivate queue by another API
 *        clx_tm_setTcQueueMapping.
 *
 * Use this API to create a new mapping profile.
 * support_chip all.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    direction       - Mapping direction, including CLX_DIR_INGRESS and CLX_DIR_EGRESS.
 * @param [in]    mapping_type    - The type of the mapping profile. CLX_QOS_MAPPING_TYPE_DOT1P
 *                                  means the mapping of ingress pcp/dei to phb or egress phb to
 *                                  pcp/dei. CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress
 *                                  dscp to phb or egress phb to dscp. CLX_QOS_MAPPING_TYPE_EXP
 *                                  means the mapping of ingress exp to phb or egress phb to exp.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_DOT1P, CLX_QOS_MAPPING_TYPE_DFLT_DSCP,
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_EXP donot support.
 * @param [in]    profile_id      - An assigned number that represents the software profile ID and
 *                                  the index of hardware table on this QoS mapping type.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - NO more memory for the entry.
 * @return        CLX_E_ENTRY_EXISTS     - The mapping profile is already created.
 */
clx_error_no_t
hal_qos_prof_create(const uint32 unit,
                    const clx_dir_t direction,
                    const clx_qos_mapping_type_t mapping_type,
                    const uint32 profile_id);

/**
 * @brief This API is used to delete a QoS profile.
 *
 * Use this API to destroy a mapping profile. The mapping profile can be destroyed
 * only when the mapping profile is not used by other objects
 * (such as port/vm/interface/tunnel etc.).
 * support_chip all.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    direction       - Mapping direction, including CLX_DIR_INGRESS and CLX_DIR_EGRESS.
 * @param [in]    mapping_type    - The type of the mapping profile. CLX_QOS_MAPPING_TYPE_DOT1P
 *                                  means the mapping of ingress pcp/dei to phb or egress phb to
 *                                  pcp/dei. CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress
 *                                  dscp to phb or egress phb to dscp. CLX_QOS_MAPPING_TYPE_EXP
 *                                  means the mapping of ingress exp to phb or egress phb to exp.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_DOT1P, CLX_QOS_MAPPING_TYPE_DFLT_DSCP,
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_EXP donot support.
 * @param [in]    profile_id      - An assigned number that represents the software profile ID and
 *                                  the index of hardware table on this QoS mapping type.
 * @return        CLX_E_OK                 - Operation successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The mapping profile is not exist.
 * @return        CLX_E_NOT_SUPPORT        - Not support to delete the mapping profile.
 *                                           (eg. the mapping profile has been applied to a
 *                                           port/vm/interface/ tunnel and so on).
 */
clx_error_no_t
hal_qos_prof_destroy(const uint32 unit,
                     const clx_dir_t direction,
                     const clx_qos_mapping_type_t mapping_type,
                     const uint32 profile_id);

/**
 * @brief This API is used to configure a profile entry.
 *
 * Use this API to configure a mapping entry. User should set all fields needed according to the
 * "mapping_type" parameter in the entry.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DOT1P or CLX_QOS_MAPPING_TYPE_DFLT_DOT1P,
 * fields "pcp", "dei", "priority", "color" must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_DSCP or CLX_QOS_MAPPING_TYPE_DFLT_DSCP,
 * fields "dscp", "priority", "color" must be input by user, and other fields must be ignored.
 * If "mapping_type" is CLX_QOS_MAPPING_TYPE_EXP or CLX_QOS_MAPPING_TYPE_DFLT_EXP,
 * fields "exp", "priority", "color" must be input by user, and other fields must be ignored.
 * support_chip all.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    direction       - Mapping direction, including CLX_DIR_INGRESS and CLX_DIR_EGRESS.
 * @param [in]    mapping_type    - The type of the mapping profile. CLX_QOS_MAPPING_TYPE_DOT1P
 *                                  means the mapping of ingress pcp/dei to phb or egress phb to
 *                                  pcp/dei. CLX_QOS_MAPPING_TYPE_DSCP means the mapping of ingress
 *                                  dscp to phb or egress phb to dscp. CLX_QOS_MAPPING_TYPE_EXP
 *                                  means the mapping of ingress exp to phb or egress phb to exp.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_DOT1P means the default mapping of
 *                                  egress phb to pcp/dei when packets untag in.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_DSCP means the default mapping of
 *                                  egress phb to dscp when packets untag in.
 *                                  CLX_QOS_MAPPING_TYPE_DFLT_EXP means the default mapping of
 *                                  egress phb to exp when packets untag in.
 * @param [in]    profile_id      - An assigned number that represents the software profile ID and
 *                                  the index of hardware table on this QoS mapping type.
 *                                  For CLX_QOS_MAPPING_DFLT_PHB_TO_PCP_DEI,
 *                                  CLX_QOS_MAPPING_DFLT_PHB_TO_DSCP and
 *                                  CLX_QOS_MAPPING_DFLT_PHB_TO_EXP, the profile_id should set to 0.
 * @param [in]    ptr_cfg         - The config of the priority mapping.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The mapping profile is not found.
 */
clx_error_no_t
hal_qos_prof_set(const uint32 unit,
                 const clx_dir_t direction,
                 const clx_qos_mapping_type_t mapping_type,
                 const uint32 profile_id,
                 const clx_qos_mapping_cfg_t *ptr_cfg);

/**
 * @brief Apply or unapply a priority mapping profile.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     direction           - Mapping direction, including CLX_DIR_INGRESS and
 *                                       CLX_DIR_EGRESS.
 * @param [in]     intf_type           - Interface type: Local interface and L2 service interface.
 * @param [in]     mapping_type        - The type of the mapping profile.
 *                                       CLX_QOS_MAPPING_TYPE_DOT1P means the mapping of ingress
 *                                       pcp/dei to phb CLX_QOS_MAPPING_TYPE_DSCP means the mapping
 *                                       of ingress dscp to phb CLX_QOS_MAPPING_TYPE_EXP means the
 *                                       mapping of ingress exp to phb CLX_QOS_MAPPING_TYPE_DOT1P
 *                                       means the mapping of egress phb to pcp/dei
 *                                       CLX_QOS_MAPPING_TYPE_DSCP means the mapping of egress phb
 *                                       to dscp CLX_QOS_MAPPING_TYPE_EXP means thße mapping of
 *                                       egress phb to exp.
 * @param [in]     profile_id          - An int value which means the mapping profile id and aslo
 *                                       the index in hardware table. 0 ~ 127: apply profile;
 *                                       CLX_QOS_INVALID_PROFILE_ID: cancel to apply profile.
 * @param [in]     ptr_phb_prof_idx    - Pointer for the old phb_prof_idx in table L2_LCL_INTF or
 *                                       L2_SRV_INTF.
 * @param [out]    ptr_phb_prof_idx    - Qos module return a new phb_prof_idx to applier.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - NO more memory for apply.
 */
clx_error_no_t
hal_qos_prof_apply(const uint32 unit,
                   const clx_dir_t direction,
                   const hal_qos_intf_type_t intf_type,
                   const clx_qos_mapping_type_t mapping_type,
                   const uint32 profile_id,
                   uint32 *ptr_phb_prof_idx);

/**
 * @brief Init qos profile of profile_id = 0.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    profile_id    - Mapping profile id.
 * @return        CLX_E_OK              - Operate success.
 * @return        CLX_E_ENTRY_EXISTS    - Already existed.
 */
clx_error_no_t
_hal_qos_mapping_prof_init(const uint32 unit, uint32 profile_id);

/**
 * @brief Init qos profile and warmboot.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Operate success.
 * @return        CLX_E_ALREADY_INITED    - Already inited.
 */
clx_error_no_t
_hal_qos_rsrc_init(const uint32 unit);

/**
 * @brief Init qos warmboot.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Operate success.
 * @return        CLX_E_ALREADY_INITED    - Already inited.
 */
clx_error_no_t
_hal_qos_wb_init(const uint32 unit);

/**
 * @brief Delete software resources.
 *
 * This function will free memory.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Deinitialize success.
 * @return        CLX_E_OTHERS    - Deinitialize failed.
 */
clx_error_no_t
_hal_qos_rsrc_deinit(const uint32 unit);

/**
 * @brief Delete software warmboot.
 *
 * This function will free memory.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Deinitialize success.
 * @return        CLX_E_OTHERS    - Deinitialize failed.
 */
clx_error_no_t
_hal_qos_wb_deinit(const uint32 unit);
#endif /* End of HAL_QOS_H */
