/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_ecpu_bfd.h
 * PURPOSE:
 *  1. To maintain eCPU BFD related API.
 * NOTES:
 */

#ifndef HAL_MT_ECPU_BFD_H
#define HAL_MT_ECPU_BFD_H

#include <clx/clx_bfd.h>

typedef enum {
    HAL_MT_ECPU_BFD_E_OK = 0,
    HAL_MT_ECPU_BFD_E_MSG_LEN,
    HAL_MT_ECPU_BFD_E_NO_MEMORY,
    HAL_MT_ECPU_BFD_E_BAD_PARAMETER,
    HAL_MT_ECPU_BFD_E_OTHERS,
    HAL_MT_ECPU_BFD_E_NOT_FIND_SESSION,
    HAL_MT_ECPU_BFD_E_SESSION_EXISTED,
    HAL_MT_ECPU_BFD_E_NOT_ENABLE,
    HAL_MT_ECPU_BFD_E_HAS_ENABLED,
    HAL_MT_ECPU_BFD_E_MAX,
} hal_mt_ecpu_bfd_err_t;

typedef enum {
    HAL_MT_ECPU_BFD_SET_SESSION_CREATE,
    HAL_MT_ECPU_BFD_SET_SESSION_DELETE,
    HAL_MT_ECPU_BFD_SET_SESSION_DELETE_ALL,
    HAL_MT_ECPU_BFD_SET_SESSION_UPDATE,
    HAL_MT_ECPU_BFD_GET_SESSION_PKT_STATS,
    HAL_MT_ECPU_BFD_GET_SESSION_DROP_PKT_STATS,
    HAL_MT_ECPU_BFD_SET_SESSION_CLEAR_PKT_STATS,
    HAL_MT_ECPU_BFD_GET_SESSION_STATUS,
    HAL_MT_ECPU_BFD_SET_SESSION_TRIGGER_POLL,
    HAL_MT_ECPU_BFD_SET_SESSION_ADMIN_STATUS,
    HAL_MT_ECPU_BFD_SET_CLEAR_DROP_PKT_STATS,
    HAL_MT_ECPU_BFD_SET_SHA1_ENTRY,
    HAL_MT_ECPU_BFD_GET_SHA1_ENTRY,
    HAL_MT_ECPU_BFD_SET_SIMPLE_PASSWORD_ENTRY,
    HAL_MT_ECPU_BFD_GET_SIMPLE_PASSWORD_ENTRY,
    HAL_MT_ECPU_BFD_GET_SESSION_ENTRY,
    HAL_MT_ECPU_BFD_GET_NEXT_SESSION_ENTRY,
} hal_mt_ecpu_bfd_host2ecpu_req_msg_type_t;

typedef enum {
    HAL_MT_ECPU_BFD_STATE_CHANGE_EVENT,
} hal_mt_ecpu_bfd_ecpu2host_ntf_msg_type_t;

typedef struct hal_mt_ecpu_bfd_req_msg_hdr_s {
    uint8 msg_type;
    uint8 seq;
    uint16 len;
    uint32 flag;
    uint8 data[0];
} hal_mt_ecpu_bfd_req_msg_hdr_t;

typedef struct hal_mt_ecpu_bfd_resp_msg_hdr_s {
    uint8 msg_type;
    uint8 code;
    uint8 seq;
    uint8 resv[1];
    uint16 len;
    uint8 data[0];
} hal_mt_ecpu_bfd_resp_msg_hdr_t;

typedef struct hal_mt_ecpu_bfd_notify_msg_hdr_s {
    uint8 msg_type;
    uint8 resv[1];
    uint16 len;
    uint8 data[0];
} hal_mt_ecpu_bfd_notify_msg_hdr_t;

typedef struct hal_mt_ecpu_bfd_event_info_s {
    uint32 session_id;
    uint32 event;
} hal_mt_ecpu_bfd_event_info_t;

typedef enum hal_mt_ecpu_bfd_event_msg_type_e {
    HAL_MT_ECPU_BFD_EVENT_MSG_TYPE_ECHO_REQUEST = 0,   /* Ask for BFD daemon or data plane for echo
                                                          packet. */
    HAL_MT_ECPU_BFD_EVENT_MSG_TYPE_ECHO_REPLY = 1,     /* Answer a ECHO_REQUEST packet. */
    HAL_MT_ECPU_BFD_EVENT_MSG_TYPE_ADD_SESSION = 2,    /* Add or update BFD peer session. */
    HAL_MT_ECPU_BFD_EVENT_MSG_TYPE_DELETE_SESSION = 3, /* Delete BFD peer session. */
    HAL_MT_ECPU_BFD_EVENT_MSG_TYPE_STATE_CHANGE = 4,   /* State change. */
    HAL_MT_ECPU_BFD_EVENT_MSG_TYPE_REQUEST_SESSION_COUNTERS = 5, /* Ask for BFD session counters. */
    HAL_MT_ECPU_BFD_EVENT_MSG_TYPE_SESSION_COUNTERS = 6, /* Tell BFD daemon about counters values.
                                                          */
    HAL_MT_ECPU_BFD_EVENT_MSG_TYPE_MAX,
} hal_mt_ecpu_bfd_event_msg_type_t;

typedef struct hal_mt_ecpu_bfd_event_msg_s {
    struct {
        uint8 version; /* Protocol version. */
        uint8 resv;
        uint16 type;   /* Message contents type, refer to hal_mt_ecpu_bfd_event_msg_type_t. */
        uint32 id;     /* Session id. */
    } hdr;
    struct {
        uint32 local_session_id;    /* Local session id. */
        uint32 remote_session_id;   /* Remote session id. */
        uint32 remote_flags;        /* Remote flags. */
        uint32 desired_tx;          /* Desired tx. */
        uint32 required_rx;         /* Required rx. */
        uint32 required_echo_rx;    /* Required echo rx. */
        uint8 state;                /* State. */
        uint8 diagnostics;          /* Diagnostics. */
        uint8 detection_multiplier; /* Detection multiplier. */
        uint8 resv;
    } state;
} hal_mt_ecpu_bfd_event_msg_t;

typedef struct hal_mt_ecpu_bfd_session_admin_info_s {
    uint32 session_id;
    uint32 status;
} hal_mt_ecpu_bfd_session_admin_info_t;

typedef struct hal_mt_ecpu_bfd_session_stats_clr_s {
    uint32 session_id;
    uint32 flags;
} hal_mt_ecpu_bfd_session_stats_clr_t;

/**
 * @brief This API is used to initialize the ecpu bfd module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_ecpu_bfd_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize the ecpu bfd module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_ecpu_bfd_deinit(const uint32 unit);

/**
 * @brief This API is used to create a bfd session.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    cfg_session    - Bfd session configuration.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_create(const uint32 unit, clx_bfd_session_cfg_info_t *cfg_session);
/**
 * @brief This API is used to delete a bfd session.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - Bfd session id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_delete(const uint32 unit, const uint32 session_id);

/**
 * @brief This API is used to delete all bfd sessions.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_all_session_delete(const uint32 unit);

/**
 * @brief This API is used to get a bfd session configuration.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     session_id     - Bfd session id.
 * @param [out]    cfg_session    - Bfd session configuration.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_cfg_info_get(const uint32 unit,
                                     const uint32 session_id,
                                     clx_bfd_session_cfg_info_t *cfg_session);

/**
 * @brief This API is used to get the next bfd session configuration.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     session_id     - Bfd session id.
 * @param [out]    cfg_session    - Bfd session configuration.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_next_session_cfg_info_get(const uint32 unit,
                                          const uint32 session_id,
                                          clx_bfd_session_cfg_info_t *cfg_session);
/**
 * @brief This API is used to update a bfd session configuration.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    cfg_session    - Bfd session configuration.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_update(const uint32 unit, clx_bfd_session_cfg_info_t *cfg_session);

/**
 * @brief This API is used to get a bfd session packet statistics.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     session_id    - Bfd session id.
 * @param [out]    stats         - Bfd session statistics.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_pkt_stats_get(const uint32 unit,
                                      const uint32 session_id,
                                      clx_bfd_session_stats_t *stats);

/**
 * @brief This API is used to get a bfd session drop packet statistics.
 *
 * @param [in]     unit     - Device unit number.
 * @param [out]    stats    - Bfd session drop packet statistics.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_drop_pkt_stats_get(const uint32 unit, clx_bfd_drop_stats_t *stats);

/**
 * @brief This API is used to clear a bfd session packet statistics.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - Bfd session id.
 * @param [in]    flags         - Flags to clear.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_pkt_stats_clear(const uint32 unit,
                                        const uint32 session_id,
                                        const uint32 flags);

/**
 * @brief This API is used to clear bfd sessions drop packet statistics.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_drop_pkt_stats_clear(const uint32 unit);

/**
 * @brief This API is used to get a bfd session status.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     session_id    - Bfd session id.
 * @param [out]    status        - Bfd session status.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_status_get(const uint32 unit,
                                   const uint32 session_id,
                                   clx_bfd_session_status_t *status);

/**
 * @brief This API is used to trigger a bfd session poll.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - Bfd session id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_poll_trigger(const uint32 unit, const uint32 session_id);

/**
 * @brief This API is used to set a bfd session admin status.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    session_id    - Bfd session id.
 * @param [in]    status        - Bfd session admin status.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_admin_set(const uint32 unit,
                                  const uint32 session_id,
                                  const clx_bfd_admin_status_t status);

/**
 * @brief This API is used to register the bfd session event callback.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cb            - BFD event callback.
 * @param [in]    ptr_cookie    - Pointer to cookie.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_event_cb_register(const uint32 unit,
                                          const clx_bfd_event_cb_t cb,
                                          void *ptr_cookie);

/**
 * @brief This API is used to unregister the bfd session event callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_bfd_session_event_cb_unregister(const uint32 unit);

#endif /* HAL_MT_ECPU_BFD_H */