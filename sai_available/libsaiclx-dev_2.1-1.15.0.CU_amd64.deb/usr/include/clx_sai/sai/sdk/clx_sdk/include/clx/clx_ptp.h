/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_ptp.h
 *
 * PURPOSE:
 *      It provides ptp module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_PTP_H
#define CLX_PTP_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_PTP_CLK_ID_LEN 8
typedef uint8 clx_clk_id_t[CLX_PTP_CLK_ID_LEN];

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum clx_ptp_bmca_select_e {
    CLX_PTP_BMCA_PTP,  /* PTP mode */
    CLX_PTP_BMCA_NOOP, /* Noop mode */
    CLX_PTP_BMCA_LAST,
} clx_ptp_bmca_select_t;

typedef enum clx_ptp_clk_type_e {
    CLX_PTP_CLK_TYPE_NONE = 0, /* None */
    CLX_PTP_CLK_TYPE_ORDINARY, /* Ordinary clock */
    CLX_PTP_CLK_TYPE_BOUNDARY, /* Boundary clock */
    CLX_PTP_CLK_TYPE_P2P,      /* P2P clock */
    CLX_PTP_CLK_TYPE_E2E,      /* E2E clock */
    CLX_PTP_CLK_TYPE_MGMT,     /* Management clock */
    CLX_PTP_CLK_TYPE_LAST,
} clx_ptp_clk_type_t;

typedef enum clx_ptp_role_e {
    CLX_PTP_ROLE_NONE,   /* None */
    CLX_PTP_ROLE_MASTER, /* Master role */
    CLX_PTP_ROLE_SLAVE,  /* Slave role */
    CLX_PTP_ROLE_LAST,
} clx_ptp_role_t;

typedef enum clx_ptp_trans_type_e {
    CLX_PTP_TRANS_UDP_IPV4 = 0, /* IPv4 */
    CLX_PTP_TRANS_UDP_IPV6,     /* IPv6 */
    CLX_PTP_TRANS_IEEE_802_3,   /* IEEE 802.3 */
    CLX_PTP_TRANS_TYPE_LAST,
} clx_ptp_trans_type_t;

typedef enum clx_ptp_delay_mechanism_e {
    CLX_PTP_DM_NONE, /* None */
    CLX_PTP_DM_E2E,  /* E2E */
    CLX_PTP_DM_P2P,  /* P2P */
    CLX_PTP_DM_LAST,
} clx_ptp_delay_mechanism_t;

typedef enum clx_ptp_step_mode_e {
    CLX_PTP_STEP_ONE = 0, /* One step */
    CLX_PTP_STEP_TWO,     /* Two step */
    CLX_PTP_STEP_LAST,
} clx_ptp_step_mode_t;

typedef enum clx_ptp_leap_mode_e {
    CLX_PTP_LEAP_NONE = 0, /* None */
    CLX_PTP_LEAP_61,       /* leap 61 */
    CLX_PTP_LEAP_59,       /* leap 59 */
    CLX_PTP_LEAP_LAST,
} clx_ptp_leap_mode_t;

typedef enum clx_ptp_link_mode_e {
    CLX_PTP_LINK_UP,   /* Link up */
    CLX_PTP_LINK_DOWN, /* Link down */
    CLX_PTP_LINK_LAST,
} clx_ptp_link_mode_t;

typedef enum clx_ptp_mon_status_e {
    CLX_PTP_MON_ENABLE,  /* Monitor enable */
    CLX_PTP_MON_DISABLE, /* Monitor disable */
    CLX_PTP_MON_LAST,
} clx_ptp_mon_status_t;

#define CLX_PTP_CLK_FLAGS_TYPE                 0x1
#define CLX_PTP_CLK_FLAGS_ROLE                 0x2
#define CLX_PTP_CLK_FLAGS_OFFSET_SCALEDLOG_VAR 0x4
#define CLX_PTP_CLK_FLAGS_STEP_MODE            0x8
#define CLX_PTP_CLK_FLAGS_DOMAIN_NUM           0x10
#define CLX_PTP_CLK_FLAGS_UTC_OFFSET           0x20
#define CLX_PTP_CLK_FLAGS_LEAP_MODE            0x40
#define CLX_PTP_CLK_FLAGS_ACCURACY             0x80
#define CLX_PTP_CLK_FLAGS_CLASS                0x100
#define CLX_PTP_CLK_FLAGS_PRIORITY1            0x200
#define CLX_PTP_CLK_FLAGS_PRIORITY2            0x400
#define CLX_PTP_CLK_FLAGS_ID                   0x800
#define CLX_PTP_CLK_FLAGS_DST_MAC              0x1000

typedef struct clx_ptp_clk_cfg_s {
    uint32 flags;                  /* PTP clock attribute flags, refer to CLX_PTP_CLK_FLAGS_XXX */
    uint8 domain_number;           /* Domain number */
    clx_ptp_clk_type_t clk_type;   /* PTP clock type, refer to CLX_PTP_CLK_TYPE_XXX */
    clx_ptp_role_t role;           /* PTP clock role, refer to CLX_PTP_ROLE_XXX */
    clx_ptp_step_mode_t step_mode; /* PTP clock step mode, refer to CLX_PTP_STEP_MODE_XXX */
    clx_ptp_leap_mode_t leap_mode; /* PTP clock leap mode, refer to CLX_PTP_LEAP_MODE_XXX */
    uint64 leap_date;              /* Leap date */
    uint32 utc_offset;             /* UTC offset */
    uint8 priority1;               /* Priority1, clock quality parameter */
    uint8 priority2;               /* Priority2, clock quality parameter */
    uint8 clk_class;               /* Clock class, clock quality parameter */
    uint8 clk_accuracy;            /* Clock accuracy, clock quality parameter */
    uint16 offset_scaled_log_variance; /* Offset scaled log variance, clock quality parameter,  */
    clx_clk_id_t clk_id;               /* Clock ID */
    clx_mac_t dst_mac;                 /* Destination MAC address */
} clx_ptp_clk_cfg_t;

#define CLX_PTP_PORT_FLAGS_ROLE                  0x1
#define CLX_PTP_PORT_FLAGS_NETWORK_TRANSPORT     0x2
#define CLX_PTP_PORT_FLAGS_BMCA_MODE             0x4
#define CLX_PTP_PORT_FLAGS_DELAY_MECHANISM       0x8
#define CLX_PTP_PORT_FLAGS_BDID                  0x10
#define CLX_PTP_PORT_FLAGS_DELAY_ASYM            0x20
#define CLX_PTP_PORT_FLAGS_ANNOUNCE_INTERVAL     0x40
#define CLX_PTP_PORT_FLAGS_ANNOUNCE_TIMEOUT      0x80
#define CLX_PTP_PORT_FLAGS_SYNC_INTERVAL         0x100
#define CLX_PTP_PORT_FLAGS_SYNC_TIMEOUT          0x200
#define CLX_PTP_PORT_FLAGS_MIN_DELAYREQ_INTERVAL 0x400
#define CLX_PTP_PORT_FLAGS_PDELAY_INTERVAL       0x800
#define CLX_PTP_PORT_FLAGS_SRC_IP                0x1000
#define CLX_PTP_PORT_FLAGS_SRC_IP6               0x2000
#define CLX_PTP_PORT_FLAGS_DST_MAC               0x4000
#define CLX_PTP_PORT_FLAGS_SRC_MAC               0x8000
#define CLX_PTP_PORT_FLAGS_LINK_STATUS           0x10000
#define CLX_PTP_PORT_FLAGS_INHIBIT_ANNOUNCE      0x20000

typedef struct clx_ptp_port_cfg_s {
    uint32 flags;        /* PTP port attribute flags, refer to CLX_PTP_PORT_FLAGS_XXX */
    clx_ptp_role_t role; /* PTP port role, refer to CLX_PTP_ROLE_XXX */
    clx_ptp_trans_type_t network_trans; /* Network transport, refer to CLX_PTP_TRANSPORT_TYPE_XXX */
    clx_ptp_bmca_select_t bmca_mode;    /* BMCA mode, refer to CLX_PTP_BMCA_SELECT_XXX */
    clx_ptp_delay_mechanism_t delay_mechanism; /* Delay mechanism, refer to
                                                  CLX_PTP_DELAY_MECHANISM_XXX */
    uint32 bdid;                               /* BDID */
    int32 delay_asymmetry;                     /* Delay asymmetry */
    int32 log_announce_interval; /* Log announce interval, interval = 2^log_announce_interval * 1s,
                                    min = 0 */
    uint32 announce_timeout;     /* Announce timeout */
    int32 log_sync_interval; /* Log sync interval, interval = 2^log_sync_interval * 1s, min = -7 */
    uint32 sync_timeout;     /* Sync timeout */
    int32 log_min_delayreq_interval; /* Log min delayreq interval, interval =
                                        2^log_min_delayreq_interval * 1s, min = 0 */
    int32 log_pdelay_interval; /* Log pdelay interval, interval = 2^log_pdelay_interval * 1s, min =
                                  0 */
    uint32 inhibit_announce;   /* Inhibit announce */
    clx_ip_t src_ip;           /* Source IP address */
    clx_ptp_link_mode_t link_status; /* Link status, refer to CLX_PTP_LINK_MODE_XXX */
    clx_mac_t dst_mac;               /* Destination MAC address */
    clx_mac_t src_mac;               /* Source MAC address */
} clx_ptp_port_cfg_t;

typedef struct clx_ptp_clk_s {
    int64 offset;     /* calculated offset between local clock and parent clock */
    int64 wire_delay; /* calculated wire delay between local port and parent port */
} clx_ptp_clk_rslt_t;

typedef struct clx_ptp_port_wire_delay_s {
    int64 wire_delay; /* calculated wire delay between local port and peer port */
} clx_ptp_port_wire_delay_t;

typedef struct clx_ptp_port_msg_cnt_s {
    uint32 announce;              /* The counter of announce messages */
    uint32 sync;                  /* The counter of sync messages */
    uint32 signaling;             /* The counter of signaling messages */
    uint32 delay_req;             /* The counter of delay request messages */
    uint32 delay_resp;            /* The counter of delay response messages */
    uint32 sync_follow_up;        /* The counter of sync follow-up messages */
    uint32 pdelay_req;            /* The counter of pdelay request messages */
    uint32 pdelay_resp;           /* The counter of pdelay response messages */
    uint32 pdelay_resp_follow_up; /* The counter of pdelay response follow-up messages */
} clx_ptp_port_msg_cnt_t;

typedef struct clx_ptp_port_rx_err_s {
    uint32 msg_len;        /* The length of the message */
    uint32 transport_type; /* The type of the transport */
    uint32 version;        /* The version of the message */
    uint32 msg_type;       /* The type of the message */
    uint32 suffix_len;     /* The length of the suffix */
    uint32 domain_id;      /* The domain ID */
    uint32 path_trace;     /* The path trace */
    uint32 transport_specific;
    uint32 clk_id;
} clx_ptp_port_rx_err_t;

typedef struct clx_ptp_port_cnt_s {
    clx_ptp_port_msg_cnt_t tx;         /* The counter of transmit messages */
    clx_ptp_port_msg_cnt_t rx;         /* The counter of receive messages */
    clx_ptp_port_msg_cnt_t tx_discard; /* The counter of transmit discard messages */
    clx_ptp_port_msg_cnt_t rx_discard; /* The counter of receive discard messages */
    clx_ptp_port_rx_err_t rx_err;      /* The error information of receive messages */
} clx_ptp_port_cnt_t;

#define CLX_PTP_MON_FLAGS_MEAN_PATH_DELAY_THD    0x1
#define CLX_PTP_MON_FLAGS_OFFSET_FROM_MASTER_THD 0x2
#define CLX_PTP_MON_FLAGS_SKEW_THD               0x4

typedef struct clx_ptp_mon_cfg_s {
    uint32 flags;                  /* The flags of the monitor configuration */
    uint32 mean_path_delay_thd;    /* The threshold of mean path delay */
    uint32 offset_from_master_thd; /* The threshold of offset from master */
    uint32 skew_thd;               /* The threshold of skew */
} clx_ptp_mon_cfg_t;

typedef struct clx_ptp_mon_stat_data_s {
    uint32 cnt;       /* The counter of the statistic data */
    int32 last_value; /* The last value of the statistic data */
} clx_ptp_mon_stat_data_t;

typedef struct clx_ptp_mon_event_stat_s {
    clx_ptp_mon_stat_data_t mean_path_delay;    /* The statistic data of mean path delay */
    clx_ptp_mon_stat_data_t offset_from_master; /* The statistic data of offset from master */
    clx_ptp_mon_stat_data_t skew;               /* The statistic data of skew */
} clx_ptp_mon_event_stat_t;

typedef struct clx_ptp_mon_stat_s {
    clx_ptp_mon_cfg_t cfg;          /* The configuration of the monitor */
    clx_ptp_mon_event_stat_t stats; /* The statistic data of the monitor */
} clx_ptp_mon_stat_t;

typedef struct clx_ptp_masters_info_s {
    uint8 grandmaster_priority1;                   /* The priority1 of the grandmaster */
    uint8 grandmaster_clk_class;                   /* The clock class of the grandmaster */
    uint8 grandmaster_clk_accuracy;                /* The clock accuracy of the grandmaster */
    uint8 grandmaster_priority2;                   /* The priority2 of the grandmaster */
    uint16 grandmaster_offset_scaled_log_variance; /* The offset scaled log variance of the
                                                      grandmaster */
    uint16 parent_port_number;                     /* The number of the parent port */
    clx_clk_id_t local_clk_id;                     /* The local clock ID */
    clx_clk_id_t parent_clk_id;                    /* The parent clock ID */
    clx_clk_id_t grandmaster_clk_id;               /* The grandmaster clock ID */
} clx_ptp_masters_info_t;

typedef enum clx_ptp_state_type_e {
    CLX_PTP_PS_INITIALIZING = 1, /* Initializing */
    CLX_PTP_PS_FAULTY,           /* Faulty */
    CLX_PTP_PS_DISABLED,         /* Disabled */
    CLX_PTP_PS_LISTENING,        /* Listening */
    CLX_PTP_PS_PRE_MASTER,       /* Pre-master */
    CLX_PTP_PS_MASTER,           /* Master */
    CLX_PTP_PS_PASSIVE,          /* Passive */
    CLX_PTP_PS_UNCALIBRATED,     /* Uncalibrated */
    CLX_PTP_PS_SLAVE,            /* Slave */
    CLX_PTP_PS_GRAND_MASTER,     /* Grandmaster */
    CLX_PTP_PS_LAST,
} clx_ptp_state_type_t;

typedef struct clx_ptp_port_state_s {
    clx_ptp_state_type_t state; /* The state of the port */
} clx_ptp_port_state_t;

/**
 * @brief This API is used to create a PTP clock.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_cfg    - PTP clock configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_clk_create(const uint32 unit, const clx_ptp_clk_cfg_t *ptr_cfg);

/**
 * @brief This API is used to destroy a PTP clock.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_clk_destroy(const uint32 unit);

/**
 * @brief This API is used to set the PTP clock attribute.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_cfg    - PTP clock configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_clk_cfg_set(const uint32 unit, const clx_ptp_clk_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get the PTP clock configuration.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cfg    - PTP clock configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_clk_cfg_get(const uint32 unit, clx_ptp_clk_cfg_t *ptr_cfg);

/**
 * @brief This API is used to add a PTP port.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - PTP port id.
 * @param [in]    ptr_cfg    - PTP port configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_port_add(const uint32 unit, const uint32 port_id, const clx_ptp_port_cfg_t *ptr_cfg);

/**
 * @brief This API is used to delete a PTP port.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - PTP port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_port_del(const uint32 unit, const uint32 port_id);

/**
 * @brief This API is used to set the PTP port attribute.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - PTP port id.
 * @param [in]    ptr_cfg    - PTP port configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_port_cfg_set(const uint32 unit, const uint32 port_id, const clx_ptp_port_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get the PTP port attribute.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port_id    - PTP port id.
 * @param [out]    ptr_cfg    - PTP port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_port_cfg_get(const uint32 unit, const uint32 port_id, clx_ptp_port_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get the PTP port tx/rx packet counter.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port_id    - PTP port id.
 * @param [out]    ptr_cnt    - PTP port tx/rx packet counter.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_port_cnt_get(const uint32 unit, const uint32 port_id, clx_ptp_port_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear the PTP port tx/rx packet counter.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - PTP port id.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_port_cnt_clr(const uint32 unit, const uint32 port_id);

/**
 * @brief This API is used to get the PTP clock calculation result.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_rslt    - PTP clock result.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_clk_rslt_get(const uint32 unit, clx_ptp_clk_rslt_t *ptr_rslt);

/**
 * @brief This API is used to get the PTP port wire delay.(Only support P2P mode).
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port_id      - PTP port id.
 * @param [out]    ptr_delay    - PTP port wire delay.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_port_wire_delay_get(const uint32 unit,
                            const uint32 port_id,
                            clx_ptp_port_wire_delay_t *ptr_delay);

/**
 * @brief This API is used to enable the PTP monitor.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_cfg    - PTP monitor configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_mon_enable(const uint32 unit, const clx_ptp_mon_cfg_t *ptr_cfg);

/**
 * @brief This API is used to disable the PTP monitor.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_mon_disable(const uint32 unit);

/**
 * @brief This API is used to set the PTP monitor configuration.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_cfg    - PTP monitor configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_mon_cfg_set(const uint32 unit, const clx_ptp_mon_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get the PTP monitor configuration.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cfg    - PTP monitor configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_mon_cfg_get(const uint32 unit, clx_ptp_mon_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get the PTP monitor statistic.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_stat    - PTP monitor statistic.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_mon_stat_get(const uint32 unit, clx_ptp_mon_stat_t *ptr_stat);

/**
 * @brief This API is used to clear the PTP monitor statistic.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_mon_stat_clr(const uint32 unit);

/**
 * @brief This API is used to get the PTP master.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_master    - PTP master.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_masters_get(const uint32 unit, clx_ptp_masters_info_t *ptr_master);

/**
 * @brief This API is used to get the PTP port state.
 *
 * Support_chip: CLX84, CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port_id      - PTP port id.
 * @param [out]    ptr_state    - PTP port state.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_ptp_port_state_get(const uint32 unit, const uint32 port_id, clx_ptp_port_state_t *ptr_state);

#endif /* CLX_PTP_H */
