/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecpu.h
 * PURPOSE:
 *    Provide HAL driver API functions of ecpu module.
 *
 * NOTES:
 *
 */

#ifndef HAL_ECPU_H
#define HAL_ECPU_H

/* INCLUDE FILE DECLARATIONS
 */
#include <stdio.h>
#include "hal/hal_ecpu_elink.h"
/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_ECPU_WAIT_MEM_DONE_LOOP (1000)
/*for Cfg*/
#define HAL_ECPU_CFG_TIMEOUT          (1000 * 1000 * 8) /*8s*/
#define HAL_ECPU_CFG_SEM_TAKE_TIMEOUT (1000)            /*1ms*/

/*for ecpu fw update*/
#define HAL_ECPU_FW_UPDATE_TIMEOUT    (1000 * 1000 * 300) /*300s*/
#define HAL_ECPU_MD5_LEN              (16)
#define HAL_ECPU_READ_BUFFER_SIZE     (256)
#define HAL_ECPU_VERSION_INFO_MAX_LEN (41)
#define HAL_ECPU_REGION_0             (1)
#define HAL_ECPU_REGION_1             (2)
#define HAL_ECPU_BOOT_MAGIC           (0x424f4f54)
#define HAL_ECPU_APP_MAGIC            (0x41505055)
#define HAL_ECPU_PCIE_CFGFILE_MAGIC   (0x50434945)
#define HAL_ECPU_UPDATE_END_MAGIC     (0x42594554)
#define HAL_ECPU_FW_SIZE_MAX          (0xe1000) /*900KB*/

#define HAL_ECPU_FW_DESC_FILE         "clx_ecpu_fw_desc.json"
#define HAL_ECPU_FW_DIR_ROOT_PATH     "/root/"
#define HAL_ECPU_FW_DIR_DEFAULT_PATH  "/var/lib/"
#define HAL_ECPU_PATH_MAX_LEN         (256)
#define HAL_ECPU_MAX_FIRMWARE_NUM     (16)
#define HAL_ECPU_MAX_FEATURE_NAME_LEN (64)
#define HAL_ECPU_MAX_FEATURES_PER_FW  (16)

#define HAL_ECPU_FW_FEATURE_HEADROOM "HeadRoomCounter"

/* MACRO FUNCTION DECLARATIONS
 */
typedef clx_error_no_t (*init_func_t)(const uint32 unit);
typedef clx_error_no_t (*deinit_func_t)(const uint32 unit);

/* DATA TYPE DECLARATIONS
 */
typedef enum { HAL_ECPU_WBDB_FW_PATH, HAL_ECPU_WBDB_STATE, HAL_ECPU_WBDB_LAST } hal_ecpu_wbdb_t;

typedef enum {
    HAL_ECPU_CFG_APP_UPDATE,
    HAL_ECPU_CFG_GET_FW_VERSION,
    HAL_ECPU_CFG_SET_FW_DEFAULT_VERSION,
    HAL_ECPU_CFG_SET_FW_NEXT_VERSION,
    HAL_ECPU_CFG_SET_PCIE_DEFAULT_VERSION,
    HAL_ECPU_CFG_SET_PCIE_NEXT_VERSION,
    HAL_ECPU_CFG_GET_ELINK_INFO,
    HAL_ECPU_CFG_CLEAR_ELINK_STATICS,
    HAL_ECPU_CFG_GET_PORT_INFO,
    HAL_ECPU_CFG_CLEAR_PORT_STATICS,
    HAL_ECPU_CFG_GET_CPU_UTILIZATION,
    HAL_ECPU_CFG_GET_MEM_UTILIZATION,
    HAL_ECPU_CFG_GET_DIAG_BUF_INFO,
    HAL_ECPU_CFG_LAST
} hal_ecpu_cfg_type_t;

typedef enum {
    HAL_ECPU_CODE_E_NORMAL,
    HAL_ECPU_CODE_E_GET_METADATA,
    HAL_ECPU_CODE_E_SET_METADATA,
    HAL_ECPU_CODE_E_NO_VERSION,
    HAL_ECPU_CODE_E_NOT_SUPPORT,
    HAL_ECPU_CODE_E_OTHER,
    HAL_ECPU_CODE_E_LAST
} hal_ecpu_cfg_code_t;

typedef enum update_code {
    HAL_ECPU_UPDATE_E_OK,
    HAL_ECPU_UPDATE_E_NOSTART,
    HAL_ECPU_UPDATE_E_SEQ,     /*sequence error*/
    HAL_ECPU_UPDATE_E_MAGIC,   /*magic error*/
    HAL_ECPU_UPDATE_E_LEN,     /*file length error*/
    HAL_ECPU_UPDATE_E_MSGLEN,  /*update message length error*/
    HAL_ECPU_UPDATE_E_ERASE,   /*flash erase error*/
    HAL_ECPU_UPDATE_E_READ,    /*flash read error*/
    HAL_ECPU_UPDATE_E_PROGRAM, /*flash write error*/
    HAL_ECPU_UPDATE_E_STRIP,   /*received data length is less than the file length*/
    HAL_ECPU_UPDATE_E_MD5,     /*file md5 error*/
    HAL_ECPU_UPDATE_E_OTHER
} hal_ecpu_update_code_t;

typedef enum app_updatemsg_type {
    HAL_ECPU_UPDATE_BOOT_START, /*identify start boot-loader update*/
    HAL_ECPU_UPDATE_APP_START,
    HAL_ECPU_UPDATE_PCIEFILE_START,
    HAL_ECPU_UPDATE_DATA,
    HAL_ECPU_UPDATE_END
} hal_ecpu_app_updatemsg_type_t;

#pragma pack(1)
typedef struct hal_ecpu_update_start_msg_hdr_s {
    uint8 msg_type;
    uint32 magic;
    uint32 length;
    char version[HAL_ECPU_VERSION_INFO_MAX_LEN];
    uint8 md5[HAL_ECPU_MD5_LEN];
} hal_ecpu_update_start_msg_hdr_t;

typedef struct hal_ecpu_update_data_msg_hdr_s {
    uint8 msg_type;
    uint32 seq; /*sequence*/
    uint8 data[0];
} hal_ecpu_update_data_msg_hdr_t;

typedef struct hal_ecpu_update_end_msg_hdr_s {
    uint8 msg_type;
    uint32 magic;
} hal_ecpu_update_end_msg_hdr_t;

typedef struct hal_ecpu_update_resp_hdr_s {
    uint8 msg_type; /*HAL_ECPU_UPDATE_APP_START ...*/
    uint32 seq;     /*sequence*/
} hal_ecpu_update_rsp_hdr_t;

typedef struct hal_ecpu_cfg_data_hdr_s {
    uint32 cfg_type; /*hal_ecpu_cfg_type_t*/
    uint8 data[0];
} hal_ecpu_cfg_data_hdr_t;

typedef struct hal_ecpu_cfg_rsp_hdr_s {
    uint32 cfg_type; /*hal_ecpu_cfg_type_t*/
    uint32 code;
} hal_ecpu_cfg_rsp_hdr_t;

typedef struct hal_ecpu_cfg_update_start_hdr_s {
    hal_ecpu_cfg_data_hdr_t cfg; /*hal_ecpu_cfg_type_t*/
    hal_ecpu_update_start_msg_hdr_t start;
} hal_ecpu_cfg_update_start_hdr_t;

typedef struct hal_ecpu_cfg_update_data_hdr_s {
    hal_ecpu_cfg_data_hdr_t cfg; /*hal_ecpu_cfg_type_t*/
    hal_ecpu_update_data_msg_hdr_t data;
} hal_ecpu_cfg_update_data_hdr_t;

typedef struct hal_ecpu_cfg_update_end_hdr_s {
    hal_ecpu_cfg_data_hdr_t cfg; /*hal_ecpu_cfg_type_t*/
    hal_ecpu_update_end_msg_hdr_t end;
} hal_ecpu_cfg_update_end_hdr_t;

/*for fw update*/
typedef struct hal_ecpu_cfg_fw_update_rsp_s {
    hal_ecpu_cfg_rsp_hdr_t rsp;
    hal_ecpu_update_rsp_hdr_t update;
} hal_ecpu_cfg_fw_update_rsp_t;

typedef struct hal_ecpu_diag_buf_info_s {
    uint32 addr;
    uint32 len;
} hal_ecpu_diag_buf_info_t;

/*for diagnostic log buffer*/
typedef struct hal_ecpu_cfg_diag_buf_rsp_s {
    hal_ecpu_cfg_rsp_hdr_t rsp;
    hal_ecpu_diag_buf_info_t buf_info;
} hal_ecpu_cfg_diag_buf_t;
#pragma pack()

typedef struct hal_feature_cache_item_s {
    char feature_name[HAL_ECPU_MAX_FEATURE_NAME_LEN];
    boolean supported;
} hal_feature_cache_item_t;

typedef struct hal_fw_features_s {
    boolean initialized;
    uint32 feature_count;
    hal_feature_cache_item_t features[HAL_ECPU_MAX_FEATURES_PER_FW];
} hal_fw_features_t;

typedef enum {
    HAL_ECPU_FW_APP_TYPE_PTP,
    HAL_ECPU_FW_APP_TYPE_BFD,
    HAL_ECPU_FW_APP_TYPE_LAST
} hal_ecpu_fw_app_type_t;

typedef struct hal_ecpu_fw_app_cb_s {
    char name[CLX_ECPU_FW_APP_NAME_LEN_MAX];
    uint32 app_id;
    init_func_t init;
    deinit_func_t deinit;
    boolean initialized;
} hal_ecpu_fw_app_cb_t;

typedef enum hal_ecpu_flash_update_type_e {
    HAL_ECPU_FLASH_UPDATE_TYPE_BOOTLOADER = 1,
    HAL_ECPU_FLASH_UPDATE_TYPE_APP,
    HAL_ECPU_FLASH_UPDATE_TYPE_PCIE_FILE,
    HAL_ECPU_FLASH_UPDATE_TYPE_LAST
} hal_ecpu_flash_update_type_t;

typedef enum hal_ecpu_flash_update_status_e {
    HAL_ECPU_FLASH_UPDATE_IDLE,
    HAL_ECPU_FLASH_UPDATE_DOING,
    HAL_ECPU_FLASH_UPDATE_SUCCESS,
    HAL_ECPU_FLASH_UPDATE_FAILURE,
} hal_ecpu_flash_update_status_t;

typedef struct hal_ecpu_flash_update_info_s {
    hal_ecpu_flash_update_type_t type;
    hal_ecpu_flash_update_status_t result;
} hal_ecpu_flash_update_info_t;

typedef struct hal_ecpu_flash_update_ctrl_s {
    uint32 unit;
    FILE *fp;
    clx_thread_id_t task_id;
    hal_ecpu_flash_update_info_t stats[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
    boolean running; /*true: update is running*/
} hal_ecpu_flash_update_ctrl_t;

typedef struct hal_ecpu_flash_ver_s {
    char fw_version[HAL_ECPU_VERSION_INFO_MAX_LEN];
    char boot_version[HAL_ECPU_VERSION_INFO_MAX_LEN];
    char fw0_version[HAL_ECPU_VERSION_INFO_MAX_LEN];
    char fw1_version[HAL_ECPU_VERSION_INFO_MAX_LEN];
    char pcie0_version[HAL_ECPU_VERSION_INFO_MAX_LEN];
    char pcie1_version[HAL_ECPU_VERSION_INFO_MAX_LEN];
    uint8 fw_dft_start;    /*0:fw0; 1:fw1*/
    uint8 fw_next_start;   /*0:fw0; 1:fw1*/
    uint8 pcie_dft_start;  /*0:pcie0; 1:pcie1*/
    uint8 pcie_next_start; /*0:pcie0; 1:pcie1*/
} hal_ecpu_flash_ver_t;

typedef struct hal_ecpu_flash_ver_cfg_s {
    hal_ecpu_cfg_data_hdr_t cfg;
    char version[HAL_ECPU_VERSION_INFO_MAX_LEN];
} hal_ecpu_flash_ver_cfg_t;

/*for get fw version*/
typedef struct hal_ecpu_flash_ver_cfg_rsp_s {
    hal_ecpu_cfg_rsp_hdr_t rsp;
    hal_ecpu_flash_ver_t ver;
} hal_ecpu_flash_ver_cfg_rsp_t;

typedef struct hal_ecpu_pkt_stat_s {
    uint32 rx_bytes;
    uint32 tx_bytes;
    uint32 rx_pkts;
    uint32 tx_pkts;
    uint32 rx_broadcast;
    uint32 tx_broadcast;
    uint32 rx_multicast;
    uint32 tx_multicast;
    uint32 rx_error;
    uint32 tx_error;
} hal_ecpu_pkt_stat_t;

typedef struct hal_ecpu_port_cfg_info_rsp_s {
    hal_ecpu_cfg_rsp_hdr_t rsp;
    hal_ecpu_pkt_stat_t pkt_stat;
} hal_ecpu_port_cfg_info_rsp_t;

/* for get ecpu utilization */
typedef struct hal_ecpu_usage_s {
    uint32 core_num;
    uint32 utilization[0];
} hal_ecpu_usage_t;

typedef struct hal_ecpu_cpu_cfg_utilization_rsp_s {
    hal_ecpu_cfg_rsp_hdr_t rsp;
    hal_ecpu_usage_t cpu_usage;
} hal_ecpu_cpu_cfg_utilization_rsp_t;

typedef struct hal_ecpu_mem_statistics_s {
    uint32 total;
    uint32 used;
} hal_ecpu_mem_statistics_t;

typedef struct hal_ecpu_mem_usage_s {
    hal_ecpu_mem_statistics_t heap[2]; /*1: sys_heap;2:k_heap*/
    uint32 core_num;
    hal_ecpu_mem_statistics_t sram[0];
} hal_ecpu_mem_usage_t;

/* for get ecpu memory utilization */
typedef struct hal_ecpu_mem_cfg_utilization_rsp_s {
    hal_ecpu_cfg_rsp_hdr_t rsp;
    hal_ecpu_mem_usage_t mem_usage;
} hal_ecpu_mem_cfg_utilization_rsp_t;

typedef struct hal_ecpu_elink_stat_s {
    uint32 status;
    uint32 tx_write_idx;
    uint32 tx_read_idx;
    uint32 rx_write_idx;
    uint32 rx_read_idx;
    hal_elink_statistic_t host;
    hal_elink_statistic_t ecpu;
} hal_ecpu_elink_stat_t;

/*for get elink info*/
typedef struct hal_ecpu_elink_info_rsp_s {
    hal_ecpu_cfg_rsp_hdr_t rsp;
    hal_elink_statistic_t elink_stats;
} hal_ecpu_elink_info_rsp_t;

typedef struct hal_ecpu_health_chk_cb_s {
    uint32 unit;
    osal_timer_id_t timer_id;
    boolean elink_status;
} hal_ecpu_health_chk_cb_t;

/* STATIC VARIABLE DECLARATIONS
 */

/* GLOBAL VARIABLE DECLARATIONS
 */
extern boolean _hal_ecpu_fw_running[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern char *_hal_ecpu_fw_path[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern boolean _hal_ecpu_headroom_running[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
extern uint32 hal_ecpu_running_firmware_index;
extern boolean _hal_ecpu_mburst_running[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize the ecpu module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_OTHERS             - Operate failed.
 * @return        CLX_E_ALREADY_INITED     - Already inited.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Not found entry.
 */
clx_error_no_t
hal_ecpu_init(const uint32 unit);

/**
 * @brief Deinitialize the ecpu module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 * @return        CLX_E_NOT_INITED       - No inited.
 */
clx_error_no_t
hal_ecpu_deinit(const uint32 unit);

/**
 * @brief This API is used to read diagnostic log buffer.
 *
 * @param [in]     unit     - Device unit number.
 * @param [out]    ppbuf    - Diagnostic log buffer pointer.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_ecpu_diag_log_read(const uint32 unit, char **ppbuf);

/**
 * @brief This API is used to send start updating message.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    type        - Application type.
 * @param [in]    size        - Message size.
 * @param [in]    pversion    - Version pointer.
 * @param [in]    md5         - Md5 pointer.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_ecpu_msg_update_start_send(const uint32 unit,
                               const hal_ecpu_flash_update_type_t type,
                               const uint32 size,
                               const uint8 *pversion,
                               const uint8 *md5);

/**
 * @brief This API is used to send end updating message.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_ecpu_msg_update_end_send(const uint32 unit);

/**
 * @brief This API is used to update flash firmware.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    path    - Flash firmware path.
 * @param [in]    type    - Application type.
 * @return        CLX_E_OK            - Operate success.
 * @return        CLX_E_OTHERS        - Operate failed.
 * @return        CLX_E_TIMEOUT       - Time out.
 * @return        CLX_E_NOT_INITED    - No inited.
 */
clx_error_no_t
hal_ecpu_fw_flash_update(const uint32 unit,
                         const char *path,
                         const hal_ecpu_flash_update_type_t type);

/**
 * @brief This API is used to set flash firmware path.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    path    - Flash firmware path.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_OTHERS           - Operate failed.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_ecpu_fw_path_set(const uint32 unit, const char *path);

/**
 * @brief This API is used to Check whether ecpu is running.
 *
 * @param [in]    unit    - Device unit number.
 * @return        TURE     - Ecpu is running.
 * @return        FALSE    - Ecpu is not running.
 */
boolean
hal_ecpu_is_running(const uint32 unit);

/**
 * @brief This API is used to get the firmware description file path. first find the path from
 *        environment variable CLX_CFG_ECPU_FW_DESC, if not found, search the path from the default
 *        path.
 *
 * Support_chip: CLX86.
 *
 * @param [out]    path_buf    - Firmware description file path.
 * @param [in]     buf_len     - Buffer length.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_ecpu_fw_desc_path_get(char *path_buf, uint32 buf_len);

/**
 * @brief This API is used to get the firmware path from the firmware description file.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     desc_path    - Firmware description file path.
 * @param [in]     index        - Firmware index.
 * @param [out]    path_buf     - Firmware path.
 * @param [in]     buf_len      - Buffer length.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_ecpu_fw_path_get(const char *desc_path, uint32 index, char *path_buf, uint32 buf_len);

/**
 * @brief This API is used to check if a firmware supports a specific feature.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    desc_path    - Firmware description file path.
 * @param [in]    fw_index     - Firmware index in the description file.
 * @param [in]    feature      - Feature name to check.
 * @return        TRUE     - Feature is supported.
 * @return        FALSE    - Feature is not supported.
 */
boolean
hal_ecpu_fw_feature_chk(const char *desc_path, uint32 fw_index, const char *feature);

/**
 * @brief This API is used to check whether ecpu feature is supported.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    feature_type    - Feature type.
 * @return        CLX_E_OK             - Successfully.
 * @return        CLX_E_NOT_SUPPORT    - Feature is not supported.
 */
clx_error_no_t
hal_ecpu_fw_feature_is_supported(const uint32 unit, const clx_ecpu_fw_feature_type_t feature_type);

/**
 * @brief This API is used to get the firmware description.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     index       - Firmware index.
 * @param [out]    pfw_desc    - Firmware description.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_ecpu_fw_info_get(const uint32 index, clx_ecpu_fw_desc_t *pfw_desc);

/**
 * @brief This API is used to get the firmware apps info.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     index      - Firmware index.
 * @param [out]    pfw_app    - Firmware apps info.
 * @param [in]     len        - Length of the apps info.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_ecpu_fw_apps_info_get(const uint32 index, clx_ecpu_fw_app_info_t *pfw_app, const uint32 len);

/**
 * @brief This API is used to get the running firmware index.
 *
 * @param [out]    index    - Running firmware index.
 * @return         CLX_E_OK            - Successfully.
 * @return         CLX_E_NOT_INITED    - Ecpu is not running.
 */
clx_error_no_t
hal_ecpu_fw_running_get(uint32 *index);

/**
 * @brief This API is used to set the default firmware index.
 *
 * @param [in]    index    - Default firmware index.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_ecpu_fw_dflt_set(uint32 index);

/**
 * @brief This API is used to get the default firmware index.
 *
 * @param [out]    index    - Default firmware index.
 * @return         CLX_E_OK               - Successfully.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_ecpu_fw_dflt_get(uint32 *index);

/**
 * @brief This API is used to start the ecpu health check timer.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_ecpu_health_chk_timer_start(const uint32 unit);

/**
 * @brief This API is used to stop the ecpu health check timer.
 *
 * @param [in]    unit    - Device unit number.
 */
void
hal_ecpu_health_chk_timer_stop(const uint32 unit);

/**
 * @brief This API is used to initialize the ecpu apps.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_ecpu_app_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize the ecpu apps.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_ecpu_app_deinit(const uint32 unit);

/**
 * @brief This API is used to get the app name.
 *
 * @param [in]     app_id    - Application ID.
 * @param [out]    name      - App name.
 * @param [in]     len       - Name length.
 * @return         CLX_E_OK                 - Successfully.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
clx_error_no_t
hal_ecpu_fw_app_name_get(const uint8 app_id, char *name, const uint32 len);

/**
 * @brief This API is used to traverse the firmware info.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    callback      - Callback function.
 * @param [in]    ptr_cookie    - Cookie.
 * @return        CLX_E_OK                 - Successfully.
 * @return        CLX_E_BAD_PARAMETER      - Other errors.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No memory.
 */
clx_error_no_t
hal_ecpu_fw_info_trav(const clx_ecpu_fw_trav_func_t callback, void *ptr_cookie);

/**
 * @brief This API is used to check if the flash upgrade is running.
 *
 * @return        TRUE The flash upgrade is running FALSE The flash upgrade is not running.
 */
boolean
hal_ecpu_flash_is_updating(void);

/**
 * @brief This API is used to upgrade files on Flash.
 *
 * @param unit Unit number
 * @param path File path
 * @param type Upgrade type.
 *
 * @return        CLX_E_OK Successfully started the upgrade thread CLX_E_OTHERS Failed to start
 *                upgrade thread CLX_E_BAD_PARAMETER Parameters are invalid.
 */
clx_error_no_t
hal_ecpu_flash_update(const uint32 unit, char *path, hal_ecpu_flash_update_type_t type);

/**
 * @brief This API is used to get flash fw upgrade status.
 *
 * @param unit Unit number
 * @param pinfo FW type and status.
 *
 * @return        CLX_E_OK Successfully get fw version CLX_E_BAD_PARAMETER Parameters are invalid.
 */
clx_error_no_t
hal_ecpu_flash_update_status_get(const uint32 unit, hal_ecpu_flash_update_info_t *pinfo);

/**
 * @brief This API is used to get fw version includes fw in itcm, fw and pcie configure files on
 *        norflash.
 *
 * @param unit Unit number
 * @param pversion App and pcie file version.
 *
 * @return        CLX_E_OK Successfully get fw version CLX_E_BAD_PARAMETER Parameters are invalid
 *                CLX_E_OTHERS Failed to get fw version.
 */
clx_error_no_t
hal_ecpu_flash_ver_get(const uint32 unit, hal_ecpu_flash_ver_t *pversion);

/**
 * @brief This API is used to set the fw startup version of norflash.
 *
 * @param unit Unit number
 * @param type FW type
 * @param pver Fw version.
 *
 * @return        CLX_E_OK Successfully set fw version CLX_E_BAD_PARAMETER Parameters are invalid
 *                CLX_E_OTHERS Failed to set fw version.
 */
clx_error_no_t
hal_ecpu_flash_ver_set(const uint32 unit, const hal_ecpu_cfg_type_t type, char *pver);

/**
 * @brief This API is used to get ecpu tx/rx pkt statistics.
 *
 * @param unit Unit number
 * @param pstat ecpu tx/rx pkt statistics.
 *
 * @return        CLX_E_OK Successfully get tx/rx pkt statistics CLX_E_BAD_PARAMETER Parameters are
 *                invalid CLX_E_OTHERS Failed to get tx/rx pkt statistics.
 */
clx_error_no_t
hal_ecpu_pkt_stat_get(const uint32 unit, hal_ecpu_pkt_stat_t *pstat);

/**
 * @brief This API is used to clear ecpu port statistics.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_ecpu_pkt_stat_clr(const uint32 unit);

/**
 * @brief This API is used to get ecpu utilization.
 *
 * @param [in]     unit      - Device unit number.
 * @param [out]    pusage    - Ecpu utilization.
 * @return         CLX_E_OK        - Successfully.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_ecpu_cpu_utilization_get(const uint32 unit, hal_ecpu_usage_t **pusage);

/**
 * @brief This API is used to get ecpu memory utilization.
 *
 * @param [in]     unit      - Device unit number.
 * @param [out]    pusage    - Ecpu memory utilization.
 * @return         CLX_E_OK        - Successfully.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_ecpu_mem_utilization_get(const uint32 unit, hal_ecpu_mem_usage_t **pusage);

/**
 * @brief This API is used to get elink statistics.
 *
 * @param [in]     unit     - Device unit number.
 * @param [out]    pinfo    - Elink statistics.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Parameters are invalid.
 * @return         CLX_E_OTHERS           - Operate failed.
 */
clx_error_no_t
hal_ecpu_elink_stat_get(const uint32 unit, hal_ecpu_elink_stat_t *pinfo);

#endif
