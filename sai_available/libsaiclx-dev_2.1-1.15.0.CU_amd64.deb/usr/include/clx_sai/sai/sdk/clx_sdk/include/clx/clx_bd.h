/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_bd.h
 * PURPOSE:
 *      It provides bridge domain module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_BD_H
#define CLX_BD_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_meter.h>

typedef struct clx_bd_cfg_s {
    clx_bum_t bum;                                   /* BUM */
    clx_sample_t igr_sample;                         /* Ingress sample */
    clx_sample_t egr_sample;                         /* Egress sample */
    uint32 igr_mir_session_bmp;                      /* Ingress mirror session id bitmap */
    uint32 egr_mir_session_bmp;                      /* Egress mirror session id bitmap */
    uint32 stg;                                      /* STG id */
    uint32 igr_meter_id;                             /* Ingress meter ID */
    uint32 egr_meter_id;                             /* Egress meter ID */
    uint32 igr_srv_cnt_id;                           /* Ingress service counter ID */
    uint32 egr_srv_cnt_id;                           /* Egress service counter ID */
    uint32 igr_dist_cnt_id;                          /* Ingress distribution counter ID */
    uint32 egr_dist_cnt_id;                          /* Egress distribution counter ID */
    clx_qos_prof_t igr_qos;                          /* Ingress QOS, not support EXP */
    clx_qos_prof_t egr_qos;                          /* Egress QOS, not support EXP */
    clx_sa_miss_rsn_t sa_miss_rsn;                   /* SA MAC miss reason */
    uint32 seg_id;                                   /* Segment id applied to NV/MPLS header */
    clx_evpn_type_t evpn;                            /* Enable nvo3-evpn, mpls-evpn, or srv6-evpn */
    uint32 flags;                                    /* Refence to CLX_BD_CFG_FLAGS_* */
    uint64 attr_bmp;                                 /* Refence to CLX_BD_CFG_ATTR_* */
} clx_bd_cfg_t;
#define CLX_BD_CFG_FLAGS_L3_ONLY          (1U << 0)  /* Enable L3 only */
#define CLX_BD_CFG_FLAGS_MAC_LEARN        (1U << 1)  /* Enable MAC learn */
#define CLX_BD_CFG_FLAGS_IGR_METER_VLD    (1U << 2)  /* Ingress meter valid */
#define CLX_BD_CFG_FLAGS_EGR_METER_VLD    (1U << 3)  /* Egress meter valid */
#define CLX_BD_CFG_FLAGS_IGR_SRV_CNT_VLD  (1U << 4)  /* Ingress service conter valid */
#define CLX_BD_CFG_FLAGS_EGR_SRV_CNT_VLD  (1U << 5)  /* Egress service conter valid */
#define CLX_BD_CFG_FLAGS_IGR_DIST_CNT_VLD (1U << 6)  /* Ingress distribution conter valid */
#define CLX_BD_CFG_FLAGS_EGR_DIST_CNT_VLD (1U << 7)  /* Egress distribution conter valid */
#define CLX_BD_CFG_FLAGS_MLD_SNOOPING     (1U << 8)  /* Enable MLD snooping */
#define CLX_BD_CFG_FLAGS_IGMP_SNOOPING    (1U << 9)  /* Enable IGMP snooping */
#define CLX_BD_CFG_FLAGS_HSH_FAVOR_INNER  (1U << 10) /* Hash favor inner */
#define CLX_BD_CFG_FLAGS_ACL_FAVOR_INNER  (1U << 11) /* ACL favor inner */
#define CLX_BD_CFG_FLAGS_UC_SRC_PRUNE     (1U << 12) /* Enable UC source prune */
#define CLX_BD_CFG_FLAGS_MC_SRC_PRUNE     (1U << 13) /* Enable MC source prune */

#define CLX_BD_CFG_ATTR_BUM        (1ULL << 0)       /* bum */
#define CLX_BD_CFG_ATTR_IGR_SAMPLE (1ULL << 1)       /* igr_sample */
#define CLX_BD_CFG_ATTR_EGR_SAMPLE (1ULL << 2)       /* gr_sample */
#define CLX_BD_CFG_ATTR_IGR_MIR    (1ULL << 3)       /* igr_mir_bitmap */
#define CLX_BD_CFG_ATTR_EGR_MIR    (1ULL << 4)       /* egr_mir_bitmap */
#define CLX_BD_CFG_ATTR_STG        (1ULL << 5)       /* stg */
#define CLX_BD_CFG_ATTR_IGR_METER                                     \
    (1ULL << 6)                                      /* igr_meter_id, \
                                                        CLX_BD_CFG_FLAGS_IGR_METER_VLD */
#define CLX_BD_CFG_ATTR_EGR_METER                                     \
    (1ULL << 7)                                      /* egr_meter_id, \
                                                        CLX_BD_CFG_FLAGS_EGR_METER_VLD */
#define CLX_BD_CFG_ATTR_IGR_SRV_CNT                                     \
    (1ULL << 8)                                      /* igr_srv_cnt_id, \
                                                        CLX_BD_CFG_FLAGS_IGR_SRV_CNT_VLD */
#define CLX_BD_CFG_ATTR_EGR_SRV_CNT                                     \
    (1ULL << 9)                                      /* egr_srv_cnt_id, \
                                                        CLX_BD_CFG_FLAGS_EGR_SRV_CNT_VLD */
#define CLX_BD_CFG_ATTR_IGR_DIST_CNT                                     \
    (1ULL << 10)                                     /* igr_dist_cnt_id, \
                                                        CLX_BD_CFG_FLAGS_IGR_DIST_CNT_VLD */
#define CLX_BD_CFG_ATTR_EGR_DIST_CNT                                     \
    (1ULL << 11)                                     /* egr_dist_cnt_id, \
                                                        CLX_BD_CFG_FLAGS_EGR_DIST_CNT_VLD */
#define CLX_BD_CFG_ATTR_IGR_QOS         (1ULL << 12) /* igr_qos */
#define CLX_BD_CFG_ATTR_EGR_QOS         (1ULL << 13) /* egr_qos */
#define CLX_BD_CFG_ATTR_SA_MISS_RSN     (1ULL << 14) /* sa_miss_rsn */
#define CLX_BD_CFG_ATTR_SEG_ID          (1ULL << 15) /* seg_id */
#define CLX_BD_CFG_ATTR_EVPN            (1ULL << 16) /* evpn */
#define CLX_BD_CFG_ATTR_UC_SRC_PRUNE    (1ULL << 17) /* CLX_BD_CFG_FLAGS_UC_SRC_PRUNE */
#define CLX_BD_CFG_ATTR_MC_SRC_PRUNE    (1ULL << 18) /* CLX_BD_CFG_FLAGS_MC_PRUNE_EN */
#define CLX_BD_CFG_ATTR_MAC_LEARN       (1ULL << 19) /* CLX_BD_CFG_FLAGS_MAC_LEARN */
#define CLX_BD_CFG_ATTR_L3_ONLY         (1ULL << 20) /* CLX_BD_CFG_FLAGS_L3_ONLY */
#define CLX_BD_CFG_ATTR_MLD_SNOOPING    (1ULL << 21) /* CLX_BD_CFG_FLAGS_MLD_SNOOPING */
#define CLX_BD_CFG_ATTR_IGMP_SNOOPING   (1ULL << 22) /* CLX_BD_CFG_FLAGS_IGMP_SNOOPING */
#define CLX_BD_CFG_ATTR_HSH_FAVOR_INNER (1ULL << 23) /* CLX_BD_CFG_FLAGS_HSH_FAVOR_INNER */
#define CLX_BD_CFG_ATTR_ACL_FAVOR_INNER (1ULL << 24) /* CLX_BD_CFG_FLAGS_ACL_FAVOR_INNER */

#define CLX_BD_CFG_ATTR_MT_NB_SUPPORT                                                            \
    (CLX_BD_CFG_ATTR_BUM | CLX_BD_CFG_ATTR_IGR_SAMPLE | CLX_BD_CFG_ATTR_EGR_SAMPLE |             \
     CLX_BD_CFG_ATTR_IGR_MIR | CLX_BD_CFG_ATTR_EGR_MIR | CLX_BD_CFG_ATTR_STG |                   \
     CLX_BD_CFG_ATTR_IGR_METER | CLX_BD_CFG_ATTR_EGR_METER | CLX_BD_CFG_ATTR_IGR_SRV_CNT |       \
     CLX_BD_CFG_ATTR_EGR_SRV_CNT | CLX_BD_CFG_ATTR_IGR_DIST_CNT | CLX_BD_CFG_ATTR_EGR_DIST_CNT | \
     CLX_BD_CFG_ATTR_IGR_QOS | CLX_BD_CFG_ATTR_EGR_QOS | CLX_BD_CFG_ATTR_SA_MISS_RSN |           \
     CLX_BD_CFG_ATTR_SEG_ID | CLX_BD_CFG_ATTR_EVPN | CLX_BD_CFG_ATTR_UC_SRC_PRUNE |              \
     CLX_BD_CFG_ATTR_MC_SRC_PRUNE | CLX_BD_CFG_ATTR_MAC_LEARN | CLX_BD_CFG_ATTR_L3_ONLY |        \
     CLX_BD_CFG_ATTR_MLD_SNOOPING | CLX_BD_CFG_ATTR_IGMP_SNOOPING |                              \
     CLX_BD_CFG_ATTR_HSH_FAVOR_INNER | CLX_BD_CFG_ATTR_ACL_FAVOR_INNER)

/**
 * @brief This API is used to create a bridge domain.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - Bridge domain id
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_ENTRY_EXISTS     - Bridge domain already created
 */
clx_error_no_t
clx_bd_create(const uint32 unit, const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to destroy a bridge domain.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     bdid    - Bridge domain id
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND  - Bridge domain not created
 */
clx_error_no_t
clx_bd_destroy(const uint32 unit, const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to set the configuration of BD of the bridge domain.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     bdid             - Bridge domain id
 * @param [out]    ptr_bd_cfg       - Bridge domain configuration
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND  - Bridge domain not created
 */
clx_error_no_t
clx_bd_cfg_set(const uint32 unit, const clx_bridge_domain_t bdid, const clx_bd_cfg_t *ptr_bd_cfg);

/**
 * @brief This API is used to get the configuration of BD of the bridge domain.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     bdid             - Bridge domain id
 * @param [out]    ptr_bd_cfg       - Bridge domain configuration
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND  - Bridge domain not created
 */
clx_error_no_t
clx_bd_cfg_get(const uint32 unit, const clx_bridge_domain_t bdid, clx_bd_cfg_t *ptr_bd_cfg);

#endif
