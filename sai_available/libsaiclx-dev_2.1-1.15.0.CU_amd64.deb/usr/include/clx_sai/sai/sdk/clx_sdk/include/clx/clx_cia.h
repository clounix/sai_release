/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_cia.h
 * PURPOSE:
 *      Define the declaration for CIA module in CLX SDK.
 *
 * NOTES:
 */

#ifndef CLX_CIA_H
#define CLX_CIA_H

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <clx/clx_pkt.h>
#include <clx/clx_swc.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_CIA_PKG_NUM       (48) /* Maximum CIA PKG key byte number for CIA */
#define CLX_CIA_EXACT_PKG_NUM (31) /* Maximum CIA PKG key byte number for hash */
#define CLX_CIA_RANGE_NUM     (16) /* Maximum range number  */
#define CLX_CIA_FCM_NUM       (9)  /* Maximum FCM fcm profile number */
#define CLX_CIA_FCM_DATA_NUM  (16) /* Maximum FCM fcm byte number */
#define CLX_CIA_EXACT_WORDS   (5)
#define CLX_CIA_UNION_NUM     (8)  /* Maximum union number */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef enum clx_cia_stage_e {
    CLX_CIA_STAGE_IGR_EXACT = 0, /* stage ingress exact */
    CLX_CIA_STAGE_IGR,           /* stage ingress */
    CLX_CIA_STAGE_IGR_POST,      /* stage ingress post */
    CLX_CIA_STAGE_EGR,           /* stage egress */
    CLX_CIA_STAGE_EGR_POST,      /* stage egress post */
    CLX_CIA_STAGE_LAST
} clx_cia_stage_t;

typedef enum clx_cia_l2_frm_e {
    CLX_CIA_L2_FRM_ETHERNET = 0, /* Ethernet frame */
    CLX_CIA_L2_FRM_RFC1042,      /* RFC1042 */
    CLX_CIA_L2_FRM_LLC_OTHER,    /* L2 has LLC header but not SNAP */
    CLX_CIA_L2_FRM_LAST
} clx_cia_l2_frm_t;

typedef enum clx_cia_tnl_e {
    CLX_CIA_TNL_IPV4 = 0, /* IPv4 tunnel type */
    CLX_CIA_TNL_MPLS,     /* MPLS tunnel typey */
    CLX_CIA_TNL_IPV6,     /* IPv6 tunnel type */
    CLX_CIA_TNL_LAST
} clx_cia_tnl_t;

typedef enum clx_cia_frg_e {
    CLX_CIA_FRG_NONE = 0, /* None fragment packet */
    CLX_CIA_FRG_FIRST,    /* First fragment packet, fragment offset field is zero */
    CLX_CIA_FRG_MIDDLE,   /* Middle fragment packet, fragment offset and more fragments flag fields
                             are not zero */
    CLX_CIA_FRG_END,      /* Final fragment packet, more fragments flag is 0 in the flags field */
    CLX_CIA_FRG_FIRST_NONE, /* First fragment packet and None fragment packet, fragment offset is
                               zero */
    CLX_CIA_FRG_MIDDLE_END, /* Middle fragment and final fragment packet, also not first fragment
                               packet, fragment offset is not zero */
    CLX_CIA_FRG_LAST
} clx_cia_frg_t;

typedef enum clx_cia_ttl_e {
    CLX_CIA_TTL_ZERO = 0, /* TTL is 0 */
    CLX_CIA_TTL_ONE,      /* TTL is 1 */
    CLX_CIA_TTL_GT_ONE,   /* TTL is grater than 1 */
    CLX_CIA_TTL_LAST
} clx_cia_ttl_t;

typedef enum clx_cia_arp_frm_type_e {
    CLX_CIA_ARP_FRM_TYPE_REQUEST = 0, /* ARP frame type is ARP request */
    CLX_CIA_ARP_FRM_TYPE_RESPONSE,    /* ARP frame type is ARP response */
    CLX_CIA_ARP_FRM_TYPE_LAST,
} clx_cia_arp_frm_type_t;

typedef enum clx_cia_pkt_vlan_type_e {
    CLX_CIA_PKT_VLAN_TYPE_NO_VLAN = 0, /* no vlan tag packet */
    CLX_CIA_PKT_VLAN_TYPE_SINGLE_VLAN, /* match svid in 1ad; match cvid in 1q
                                        * treat cvid as 1st vid if s_tpid is the same as c_tpid */
    CLX_CIA_PKT_VLAN_TYPE_DOUBLE_VLAN, /* double vlan tag packet */
    CLX_CIA_PKT_VLAN_TYPE_VLAN_LAST,
} clx_cia_pkt_vlan_type_t;

typedef enum clx_cia_rim_alloc_e {
    CLX_CIA_RIM_ALLOC_FCM = 0,            /* frame content modify */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L2_UC,   /* redirect l2_uc */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L2_ECMP, /* redirect l2_ecmp */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L3_UC,   /* redirect l3_uc */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L3_ECMP, /* redirect l3_ecmp */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L2_MC,   /* redirect l2_mc */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L3_MC,   /* redirect l3_mc */
    CLX_CIA_RIM_ALLOC_REDIR_TYPE_L3_MPLS, /* redirect L3 mpls */
    CLX_CIA_RIM_ALLOC_LAST
} clx_cia_rim_alloc_t;

typedef enum clx_cia_cfg_l3_proto_type_e {
    CLX_CIA_CFG_L3_PROTO_TYPE_ALL = 0,
    CLX_CIA_CFG_L3_PROTO_TYPE_IPV6_HOPOPT,
    CLX_CIA_CFG_L3_PROTO_TYPE_IPV6_RTE,
    CLX_CIA_CFG_L3_PROTO_TYPE_IPV6_FRG,
    CLX_CIA_CFG_L3_PROTO_TYPE_AH,
    CLX_CIA_CFG_L3_PROTO_TYPE_IFA,
    CLX_CIA_CFG_L3_PROTO_TYPE_IOAM,
    CLX_CIA_CFG_L3_PROTO_TYPE_LAST
} clx_cia_cfg_l3_proto_type_t;

typedef struct clx_cia_grp_prof_s {
    uint32 pri;                                     /* group priority */
    uint32 mac_pkt_format_flags;                    /* CLX_CIA_GRP_FORMAT_XXX, CIA search only */
    uint32 arp_pkt_format_flags;                    /* CLX_CIA_GRP_FORMAT_XXX, CIA search only */
    uint32 ipv4_pkt_format_flags;                   /* CLX_CIA_GRP_FORMAT_XXX, CIA search only */
    uint32 ipv6_pkt_format_flags;                   /* CLX_CIA_GRP_FORMAT_XXX, CIA search only */
    uint32 mpls_pkt_format_flags;                   /* CLX_CIA_GRP_FORMAT_XXX, CIA search only. */
    uint32 grp_size;                                /* Fixed grp size,
                                                     * 512 for mt series. Not support auto-extend if assign grp_size */
    uint32 flags;                                   /* CLX_CIA_GRP_PROF_XXX flags */
} clx_cia_grp_prof_t;
#define CLX_CIA_GRP_FORMAT_UDF_KEY_SINGLE (1U << 0) /* single udf key */
#define CLX_CIA_GRP_FORMAT_UDF_KEY_DOUBLE (1U << 1) /* double udf key */
#define CLX_CIA_GRP_FORMAT_UDF_L3_GRP_LBL_ENABLE                                               \
    (1U << 2)                                       /* replace lsb 32bits as L3 da/sa label of \
                                                     udf key. defeature*/
#define CLX_CIA_GRP_FORMAT_TC_COLOR                                                                         \
    (1U << 3)                                       /* for BASE_L2 KEY/BASE L3 KEY,                         \
                                                     * if use tc_color as key, can not use pcp/dei/dscp/ecn \
                                                     * as key */
#define CLX_CIA_GRP_FORMAT_L2_SWAP     (1U << 4)    /* l2 sa/da swap-direction */
#define CLX_CIA_GRP_FORMAT_L3_SWAP     (1U << 5)    /* l3 sa/da swap-direction */
#define CLX_CIA_GRP_FORMAT_L4_SWAP     (1U << 6)    /* l4 dp/sp swap-direction */
#define CLX_CIA_GRP_FORMAT_BASE_KEY_L2 (1U << 7)    /* l2 base key */
#define CLX_CIA_GRP_FORMAT_BASE_KEY_L3 (1U << 8)    /* l3 base key */
#define CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_DA                                               \
    (1U << 9)                                       /* replace BASE IP DA addr by flow_label \
                                                     */
#define CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_SA                                               \
    (1U << 10)                                      /* replace BASE IP SA addr by flow_label \
                                                     */

#define CLX_CIA_GRP_PROF_FLAGS_PORT_BMP                        \
    (1U << 0) /* CIA search only.                              \
               * for pure BASE_L2/L3_KEY, if use port bitmap   \
               * as key, can not use intf_grp_lbl,             \
               * l2/l3_da/sa_grp_lbl, igr_cia_grp_lbl, arp.tpa \
               * as key.                                       \
               */
#define CLX_CIA_GRP_PROF_FLAGS_RANGE                          \
    (1U << 1) /* Select range                                 \
               * availible only if                            \
               * CLX_CIA_GRP_PROF_FLAGS_PORT_BMP and          \
               * CLX_CIA_GRP_PROF_FLAGS_GRP_LBL       are not \
               * selected.                                    \
               */
#define CLX_CIA_GRP_PROF_FLAGS_GRP_LBL            \
    (1U << 2) /* IGR: da/sa grp label; EGR:       \
               * igr_grp_lbl.     conflict with   \
               * CLX_CIA_GRP_PROF_FLAGS_PORT_BMP. \
               */
#define CLX_CIA_GRP_PROF_FLAGS_ARP_TPA                                               \
    (1U << 3) /* Arp pkt_format only, conflict with CLX_CIA_GRP_PROF_FLAGS_PORT_BMP, \
               * CLX_CIA_GRP_PROF_FLAGS_GRP_LBL and CLX_CIA_GRP_PROF_FLAGS_RANGE.    \
               */
#define CLX_CIA_GRP_PROF_FLAGS_SIZE                                  \
    (1U << 4) /* CIA only, not support auto-extend if enable this    \
               * flag for mountain series should be multiples of 512 \
               */
#define CLX_CIA_GRP_PROF_FLAGS_PREEMPT_BY_EXACT                                             \
    (1U << 5) /* CIA only, indicate CIA exact entry could use action pointer to CIA result. \
               * Not allow to add CIA entry into this group anymore */

typedef struct clx_cia_exact_grp_prof_s {
    uint32 pri;                                                          /* group priority */
    uint32 exact_ignore_msk[CLX_SWC_HSH_TILE_LAST][CLX_CIA_EXACT_WORDS]; /* set to 1 to mask out
                            corresponding bit as don’t care on flw_key,
                            flags &
                            CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK -
                            use tile 0 to config all mask, flags &
                            CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK_WITH_TILE
                            - use tile array to config tile mask */
    uint32 flags; /* CLX_CIA_EXACT_GRP_PROF_XXX flags */
} clx_cia_exact_grp_prof_t;

#define CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK (1U << 1)
#define CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_DA_LBL \
    (1U << 2) /* Exact only, replace lsb 16 bits  \
            as da_lbl of udf key. */
#define CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_SA_LBL \
    (1U << 3) /* Exact only, replace lsb 16 bits  \
               as sa_lbl of udf key. */
#define CLX_CIA_EXACT_GRP_PROF_FLAGS_EXACT_IGNORE_MSK_WITH_TILE (1U << 4)

typedef struct clx_cia_pkt_format_s {
    uint16 ethertype;             /* ethertype key */
    uint16 ethertype_msk;         /* ethertype key mask */
    uint8 proto;                  /* ip protocol */
    uint8 proto_msk;              /* ip protocol mask */
    uint16 src_port;              /* l4 source port */
    uint16 src_port_msk;          /* l4 source port mask */
    uint16 dst_port;              /* l4 destination port */
    uint16 dst_port_msk;          /* l4 destination port mask */
    clx_cia_l2_frm_t l2_frm_type; /* l2 frame type */
    clx_cia_tnl_t tnl_type;       /* tunnel type and decap pass = 1, ingress only */

    uint32 flags;                 /* CLX_CIA_PKT_FORMAT_XXX flags*/
    uint32 flags_msk;             /* CLX_CIA_PKT_FORMAT_XXX flags*/
} clx_cia_pkt_format_t;

#define CLX_CIA_PKT_FORMAT_FLAGS_L2_FRM_TYPE_VLD (1U << 0) /* l2 frame type flag */
#define CLX_CIA_PKT_FORMAT_FLAGS_TNL_TYPE_VLD    (1U << 1) /* tunnel type flag, ingress only */
#define CLX_CIA_PKT_FORMAT_FLAGS_STAG_VLD        (1U << 2) /* service vlan tag valid flag */
#define CLX_CIA_PKT_FORMAT_FLAGS_CTAG_VLD        (1U << 3) /* custom vlan tag valid flag */
/* indicates ctag_vld is in 1'st or 2'nd vlan */
#define CLX_CIA_PKT_FORMAT_FLAGS_VLAN_TAG_MODE_1Q (1U << 4)
#define CLX_CIA_PKT_FORMAT_FLAGS_L2_SKIP_0_VLD    (1U << 5)
#define CLX_CIA_PKT_FORMAT_FLAGS_L2_SKIP_1_VLD    (1U << 6)

typedef enum clx_cia_pkg_base_e {
    CLX_CIA_PKG_BASE_NONE = 0,
    CLX_CIA_PKG_BASE_START_L2_HDR,    /* l2 header start */
    CLX_CIA_PKG_BASE_START_L3_HDR,    /* l3 header start */
    CLX_CIA_PKG_BASE_START_L4_HDR,    /* l4 header start */
    CLX_CIA_PKG_BASE_START_INNER_HDR, /* inner header start, ingress only */
    CLX_CIA_PKG_BASE_LAST
} clx_cia_pkg_base_t;

typedef struct clx_cia_pkg_cfg_s {
    clx_cia_pkg_base_t type; /* pkg type */
    uint32 offset;           /* byte offset */
    uint32 msk;              /* pkg data mask, cia search only */
    uint32 flags;            /* CLX_CIA_PKG_FLAGS_XXX */
} clx_cia_pkg_cfg_t;
/* Both first and second must select this flag. \
 * For consecutive byte, type, offset mask must be zero. */
#define CLX_CIA_PKG_FLAGS_CONSECUTIVE_BYTE (1U << 0)

typedef struct clx_cia_udf_prof_s {
    clx_cia_pkg_cfg_t pkg_cfg[CLX_CIA_PKG_NUM];             /* pkg key config */
    uint32 pkg_cnt;                                         /* 48 for consective mode.*/
    uint32 internal_key_bmp;                                /* CLX_CIA_UDF_INTERNAL_KEY_XXX */

    clx_cia_pkg_cfg_t exact_pkg_cfg[CLX_CIA_EXACT_PKG_NUM]; /* ingress only */
    uint32 exact_pkg_cnt;                                   /* ingress only */
    uint32 exact_internal_key_bmp;                          /* ingress only */
} clx_cia_udf_prof_t;
/* l2 sa group label; mt: ingress exact only */
#define CLX_CIA_UDF_INTERNAL_KEY_L2_SA_GRP_LBL (1U << 0)
/* l2 da group label; mt: ingress exact only */
#define CLX_CIA_UDF_INTERNAL_KEY_L2_DA_GRP_LBL (1U << 1)
/* l3 sa group label, need to enable
 * CLX_CFG_TYPE_TCAM_L3_SIP_ENABLE
 * for Tcam search; mt: ingress exact only */
#define CLX_CIA_UDF_INTERNAL_KEY_L3_SA_GRP_LBL (1U << 2)
/* l3 da group label; mt: ingress exact only */
#define CLX_CIA_UDF_INTERNAL_KEY_L3_DA_GRP_LBL (1U << 3)
#define CLX_CIA_UDF_INTERNAL_KEY_INTF_GRP_LBL  (1U << 4) /* interface group label, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_RANGE         (1U << 5) /* range key.*/
#define CLX_CIA_UDF_INTERNAL_KEY_PORT_BMP                                                         \
    (1U << 6)                                            /* port bmp key, supported on CL8570 and \
                                                             cia search only. not support exact entry */
#define CLX_CIA_UDF_INTERNAL_KEY_BDID (1U << 7)          /* bridge domain id, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_VRF                             \
    (1U << 8) /* virtual routing and forwarding id, ingress only \
               */
/* service vlan id, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_STAG_VID (1U << 9)
/* custom vlan id, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_CTAG_VID (1U << 10)
/* service vlan pcp/dei, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_STAG_PCP_DEI (1U << 11)
/* custom vlan pcp/dei, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_CTAG_PCP_DEI (1U << 12)
/* vlan tag mode 802.1q, ingress only,
   indicates ctag_vid/pcp_dei is in 1'st or 2'nd vlan */
#define CLX_CIA_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q (1U << 13)
#define CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE         (1U << 14) /* is l3 routing, ingress only */
#define CLX_CIA_UDF_INTERNAL_KEY_TCP_FLAGS        (1U << 15) /* 12 bits TCP flags */
/* 16 bits ingress cia group label, egr only */
#define CLX_CIA_UDF_INTERNAL_KEY_IGR_CIA_GRP_LBL (1U << 16)

typedef enum clx_cia_range_e {
    CLX_CIA_RANGE_NONE = 0,     /* No range*/
    CLX_CIA_RANGE_SVID,         /* service vlan range */
    CLX_CIA_RANGE_CVID,         /* custom vlan range */
    CLX_CIA_RANGE_IP_TTL,       /* ip ttl range */
    CLX_CIA_RANGE_L4_SRC_PORT,  /* l4 source port range */
    CLX_CIA_RANGE_L4_DST_PORT,  /* l4 destination port range */
    CLX_CIA_RANGE_PKG,          /* pkg key range */
    CLX_CIA_RANGE_IP_TOTAL_LEN, /* IP packet total length range */
    CLX_CIA_RANGE_VID_NUM,      /* VID number, ingress only*/
    CLX_CIA_RANGE_IP_TOS,       /* IP TOS range */
    CLX_CIA_RANGE_FRM_LEN,      /* L2 frame length range, ingress only*/
    CLX_CIA_RANGE_VRF,          /* L3 VRF range, ingress only */
    CLX_CIA_RANGE_BDID,         /* Bridge domain range */
    CLX_CIA_RANGE_IGR_CIA_LBL,  /* ingress cia group label, egress only */
    CLX_CIA_RANGE_LAST
} clx_cia_range_t;

typedef struct clx_cia_range_cfg_s {
    clx_cia_range_t type;                         /* range type */
    clx_cia_pkg_base_t pkg_base_type;             /* pkg base type if select CLX_CIA_RANGE_PKG */
    uint32 pkg_offset;                            /* pkg byte offset */
    uint16 val_msk;                               /* value mask */
    uint16 val_max;                               /* range value maximum */
    uint16 val_min;                               /* range value minimum */
    uint32 flags;                                 /* CLX_CIA_RANGE_CFG_XXX flags*/
} clx_cia_range_cfg_t;
#define CLX_CIA_RANGE_CFG_FLAGS_INVERSE (1U << 0) /* range inverse */
/* indicates range_cvid is in 1'st or 2'nd vlan */
#define CLX_CIA_RANGE_CFG_FLAGS_VLAN_TAG_MODE_1Q (1U << 1)

typedef enum clx_cia_classify_key_e {
    CLX_CIA_CLASSIFY_KEY_MAC = 0, /* mac frame classify key */
    CLX_CIA_CLASSIFY_KEY_ARP,     /* arp frame classify key */
    CLX_CIA_CLASSIFY_KEY_IPV4,    /* ipv4 frame classify key */
    CLX_CIA_CLASSIFY_KEY_IPV6,    /* ipv6 frame classify key */
    CLX_CIA_CLASSIFY_KEY_MPLS,    /* mpls frame classify key */
    CLX_CIA_CLASSIFY_KEY_UDF,     /* udf frame classify key */
    CLX_CIA_CLASSIFY_KEY_LAST
} clx_cia_classify_key_t;

typedef struct clx_cia_mac_key_s {
    clx_mac_t dmac;                        /* destination mac */
    clx_mac_t dmac_msk;                    /* destination mac mask */
    clx_mac_t smac;                        /* source mac */
    clx_mac_t smac_msk;                    /* source mac mask */
    uint16 ether_type;                     /* ether type */
    uint16 ether_type_msk;                 /* ether type mask */
    clx_cia_pkt_vlan_type_t pkt_vlan_type; /* packet vlan tag type */

    uint32 flags;                          /* CLX_CIA_MAC_KEY_FLAGS_XXX flags */
} clx_cia_mac_key_t;

#define CLX_CIA_MAC_KEY_FLAGS_PKT_VLAN_TYPE_VLD (1U << 0) /* packet vlan tag type flag */
/* indicates ctag_valid is in 1'st or 2'nd vlan */
#define CLX_CIA_MAC_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 1)

typedef struct clx_cia_arp_key_s {
    clx_mac_t sender_mac;                /* sender mac */
    clx_mac_t sender_mac_msk;            /* sender mac mask */
    clx_mac_t target_mac;                /* target mac */
    clx_mac_t target_mac_msk;            /* target mac mask*/
    clx_ipv4_t sender_ip;                /* sender ip address */
    clx_ipv4_t sender_ip_msk;            /* sender ip address mask */
    clx_ipv4_t target_ip;                /* target ip address */
    clx_ipv4_t target_ip_msk;            /* target ip address mask */
    clx_cia_arp_frm_type_t arp_frm_type; /* arp frame type */
    uint32 flags;                        /* clx_cia_arp_key_flags_t flags */
} clx_cia_arp_key_t;

#define CLX_CIA_ARP_FRM_TYPE_VLD (1U << 0) /* arp frame valid flag */

typedef struct clx_cia_ipv4_key_s {
    clx_ipv4_t dip;         /* destination ip address */
    clx_ipv4_t dip_msk;     /* destination ip address mask */
    clx_ipv4_t sip;         /* source ip address */
    clx_ipv4_t sip_msk;     /* source ip address mask*/
    uint8 proto;            /* ip protocol */
    uint8 proto_msk;        /* ip protocol mask */
    uint16 dst_port;        /* l4 destination port */
    uint16 dst_port_msk;    /* l4 destination port mask */
    uint16 src_port;        /* l4 source port */
    uint16 src_port_msk;    /* l4 source port mask */
    uint16 tcp_flag;        /* tcp flag, mt: 12bits */
    uint16 tcp_flag_msk;    /* tcp flag mask */
    uint8 icmp_type;        /* icmp type value */
    uint8 icmp_type_msk;    /* icmp type mask */
    uint8 icmp_code;        /* icmp code value */
    uint8 icmp_code_msk;    /* icmp code value mask */
    uint8 igmp_type;        /* igmp type value */
    uint8 igmp_type_msk;    /* igmp type value mask */
    clx_cia_frg_t frg_type; /* ip fragment type */
    clx_cia_ttl_t ttl_type; /* ttl type */
    uint32 flags;           /* CLX_CIA_IPV4_KEY_XXX flags */
    uint32 flags_msk;       /* CLX_CIA_IPV4_KEY_XXX flags mask */
} clx_cia_ipv4_key_t;

#define CLX_CIA_IPV4_KEY_FLAGS_FRG_TYPE_VLD   (1U << 0) /* ip fragment type valid flag */
#define CLX_CIA_IPV4_KEY_FLAGS_TTL_TYPE_VLD   (1U << 1) /* ttl type valid flag */
#define CLX_CIA_IPV4_KEY_FLAGS_AUTH_HDR_EXIST (1U << 2) /* Authentication header exist flag */
#define CLX_CIA_IPV4_KEY_FLAGS_OPT_HDR_EXIST  (1U << 3) /* option header exist flag */

typedef struct clx_cia_ipv6_key_s {
    clx_ipv6_t dip;         /* destination ip address */
    clx_ipv6_t dip_msk;     /* destination ip address mask */
    clx_ipv6_t sip;         /* source ip address */
    clx_ipv6_t sip_msk;     /* source ip address mask */
    uint8 proto;            /* ip protocol */
    uint8 proto_msk;        /* ip protocol mask */
    uint16 dst_port;        /* l4 destination port */
    uint16 dst_port_msk;    /* l4 destination port mask */
    uint16 src_port;        /* l4 source port */
    uint16 src_port_msk;    /* l4 source port mask */
    uint16 tcp_flag;        /* tcp flag, mt: 12bits */
    uint16 tcp_flag_msk;    /* tcp flag mask */
    uint8 icmp_type;        /* icmp type value */
    uint8 icmp_type_msk;    /* icmp type value mask */
    uint8 icmp_code;        /* icmp code value */
    uint8 icmp_code_msk;    /* icmp code value mask */
    uint8 igmp_type;        /* igmp type value */
    uint8 igmp_type_msk;    /* igmp type value mask */
    clx_cia_frg_t frg_type; /* ip fragment type */
    clx_cia_ttl_t ttl_type; /* ttl type */

    uint32 flags;           /* CLX_CIA_IPV6_KEY_XXX flags */
    uint32 flags_msk;       /* CLX_CIA_IPV6_KEY_XXX flags mask */
} clx_cia_ipv6_key_t;

#define CLX_CIA_IPV6_KEY_FLAGS_FRG_TYPE_VLD   (1U << 0) /* ip fragment type valid flag */
#define CLX_CIA_IPV6_KEY_FLAGS_TTL_TYPE_VLD   (1U << 1) /* ttl type valid flag */
#define CLX_CIA_IPV6_KEY_FLAGS_AUTH_HDR_EXIST (1U << 2) /* Authentication header exist flag */

typedef struct clx_cia_mpls_key_s {
    uint32 lbl0;            /* MPLS label 0 */
    uint32 lbl0_msk;        /* MPLS label 0 mask */
    uint32 lbl1;            /* MPLS label 1 */
    uint32 lbl1_msk;        /* MPLS label 1 mask */
    uint32 lbl2;            /* MPLS label 2 */
    uint32 lbl2_msk;        /* MPLS label 2 mask */
    uint32 lbl3;            /* MPLS label 3 */
    uint32 lbl3_msk;        /* MPLS label 3 mask */
    clx_cia_ttl_t ttl_type; /* ttl type */
    uint32 flags;           /* CLX_CIA_MPLS_KEY_XXX flags */
    uint32 flags_msk;       /* CLX_CIA_MPLS_KEY_XXX flags mask */
} clx_cia_mpls_key_t;

#define CLX_CIA_MPLS_KEY_FLAGS_TTL_TYPE_VLD (1U << 1) /* ttl type valid flag */

typedef struct clx_cia_qos_key_s {
    uint8 pcp;      /* 1q:cvlan pcp, 1ad: svlan pcp if svlan exists; otherwise, cvlan pcp.*/
    uint8 pcp_msk;  /* 1q:cvlan pcp mask, 1ad: svlan pcp mask if svlan exists; otherwise, cvlan pcp
                       mask.*/
    uint8 dei;      /* 1q:cvlan dei, 1ad: svlan dei if svlan exists; otherwise, cvlan dei.*/
    uint8 dei_msk;  /* 1q:cvlan dei mask, 1ad: svlan dei mask if svlan exists; otherwise, cvlan dei
                       mask.*/
    uint8 dscp;     /* dscp for l3 packet */
    uint8 dscp_msk; /* dscp mask for l3 packet */
    uint8 exp;      /* exp for mpls packet  */
    uint8 exp_msk;  /* exp mask for mpls packet  */
    uint8 ecn;      /* ecn for l3 packet */
    uint8 ecn_msk;  /* ecn mask for l3 packet */
    uint8 tc;       /* tc */
    uint8 tc_msk;   /* tc mask */
    clx_color_t color; /* color type */
    uint32 flags;      /* clx_cia_qos_key_flags_XXX */
} clx_cia_qos_key_t;

#define CLX_CIA_QOS_KEY_FLAGS_PCP_DEI   (1U << 0) /* vlan pcp/dei */
#define CLX_CIA_QOS_KEY_FLAGS_DSCP_ECN  (1U << 1) /* dscp/ecn flag */
#define CLX_CIA_QOS_KEY_FLAGS_TC_COLOR  (1U << 2) /* enable both tc and color flag */
#define CLX_CIA_QOS_KEY_FLAGS_COLOR_VLD (1U << 3) /* color valid flag */
#define CLX_CIA_QOS_KEY_FLAGS_EXP       (1U << 4) /* mpls exp flag  */

typedef struct clx_cia_pp_info_key_s {
    uint32 intf_grp_lbl;          /* mt: 16 bits, local interface group label*/
    uint32 intf_grp_lbl_msk;      /* mt: 16 bits, local interface group label mask */
    uint32 igr_cia_grp_lbl;       /* mt: 16 bits, ingress cia search group label,
                                            egress match only */
    uint32 igr_cia_grp_lbl_msk;   /* mt: 16 bits, ingress cia search group label
                                              mask, egress match only */
    uint32 l2_da_grp_lbl;         /* mt: 16 bits, l2 destination address group label */
    uint32 l2_da_grp_lbl_msk;     /* mt: 16 bits, l2 destination address group label
                                          mask */
    uint32 l2_sa_grp_lbl;         /* mt: 16 bits, l2 source address group label */
    uint32 l2_sa_grp_lbl_msk;     /* mt: 16 bits, l2 source address group label mask
                                   */
    uint32 l3_da_grp_lbl;         /* mt: 16 bits need to enable
                                   * CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_DA, l3 destination
                                   * address group label */
    uint32 l3_da_grp_lbl_msk;     /* mt: 16 bits, l3 destination address group label
                                          mask */
    uint32 l3_sa_grp_lbl;         /* mt: 16 bits need to enable
                                   * CLX_CIA_GRP_FORMAT_BASE_LBL_REPLACE_SA, l3 source
                                   * address group label */
    uint32 l3_sa_grp_lbl_msk;     /* mt: 16 bits, l3 source address group label mask */
    uint32 bdid;                  /* Ingress : match ingress fdid
                                     Egress  : match egress bdid, must match flags_l3_route=0 simultaneously */
    uint32 bdid_msk;
    clx_cia_l2_frm_t l2_frm_type; /* l2 frame type */
    uint32 flags;                 /* clx_cia_pp_info_key_flags_xxx */
    uint32 flags_msk;             /* clx_cia_pp_info_key_flags_xxx */
} clx_cia_pp_info_key_t;

#define CLX_CIA_PP_INFO_KEY_FLAGS_L2_FRM_TYPE_VLD (1U << 0) /* l2 frame type valid flag */
#define CLX_CIA_PP_INFO_KEY_FLAGS_L3_ROUTE        (1U << 1) /* is l3 route flag */
#define CLX_CIA_PP_INFO_KEY_FLAGS_TNL_TERM        (1U << 2) /* is tunnel decap pass flag */
/* indicates cvid/ctag_valid is in 1'st or 2'nd vlan */
#define CLX_CIA_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 3)
#define CLX_CIA_PP_INFO_KEY_FLAGS_STAG_VLD         (1U << 4) /* stag vlaid */
#define CLX_CIA_PP_INFO_KEY_FLAGS_CTAG_VLD         (1U << 5) /* ctag vlaid */

typedef struct clx_cia_pkg_key_s {
    uint32 l2_sa_grp_lbl;         /* mt:10 bits, l2 source address group label */
    uint32 l2_sa_grp_lbl_msk;     /* mt:10 bits, l2 source address group label mask */
    uint32 l2_da_grp_lbl;         /* mt:10 bits, l2 destination address group label */
    uint32 l2_da_grp_lbl_msk;     /* mt:10 bits, l2 destination address group label mask */
    uint32 l3_sa_grp_lbl;         /* mt:16 bits, l3 source address group label */
    uint32 l3_sa_grp_lbl_msk;     /* mt:16 bits, l3 source address group label mask */
    uint32 l3_da_grp_lbl;         /* mt:16 bits, l3 destination address group label */
    uint32 l3_da_grp_lbl_msk;     /* mt:16 bits, l3 destination address group label mask */
    uint32 intf_grp_lbl;          /* mt:16 bits, local interface group label*/
    uint32 intf_grp_lbl_msk;      /* mt:16 bits, local interface group label mask */
    uint32 igr_cia_grp_lbl;       /* 12 bits, ingress cia search group label */
    uint32 igr_cia_grp_lbl_msk;   /* 12 bits, ingress cia search group label mask */
    uint32 vrf;                   /* 13 bits, virtual routing forwarding index */
    uint32 vrf_msk;               /* 13 bits, virtual routing forwarding index mask */
    uint32 bdid;                  /* 14 bits, bridge domain index */
    uint32 bdid_msk;              /* 14 bits, bridge domain index mask */
    uint32 tcp_flag;              /* 12 bits, tcp flag */
    uint32 tcp_flag_msk;          /* 12 bits, tcp flag mask */

    uint16 svid;                  /* service vlan id */
    uint16 svid_msk;              /* service vlan id mask */
    uint8 spcp;                   /* service vlan pcp */
    uint8 spcp_msk;               /* service vlan pcp mask */
    uint8 sdei;                   /* service vlan dei */
    uint8 sdei_msk;               /* service vlan dei mask */
    uint16 cvid;                  /* custom vlan id */
    uint16 cvid_msk;              /* custom vlan id mask */
    uint8 cpcp;                   /* custom vlan pcp */
    uint8 cpcp_msk;               /* custom vlan pcp mask */
    uint8 cdei;                   /* custom vlan dei */
    uint8 cdei_msk;               /* custom vlan dei mask */

    uint32 pkg_cnt;               /* pkg key byte count */
    uint32 data[CLX_CIA_PKG_NUM]; /* pkg key data */
    uint32 msk[CLX_CIA_PKG_NUM];  /* pkg key data mask */

    uint32 flags;                 /* clx_cia_pkg_key_flags_xxx */
    uint32 flags_msk;             /* clx_cia_pkg_key_flags_xxx */
} clx_cia_pkg_key_t;

/* indicates cvid/cpcp/cdei is in 1'st or 2'nd vlan */
#define CLX_CIA_PKG_KEY_FLAGS_VLAN_TAG_MODE_1Q (1U << 0)
#define CLX_CIA_PKG_KEY_FLAGS_L3_ROUTE         (1U << 1) /* is l3 route */

typedef struct clx_cia_classify_s {
    clx_cia_classify_key_t classify_key_type; /* CLX_CIA_CLASSIFY_KEY_MAC  :
                                                 mac/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_ARP  :
                                                 mac/arp/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_IPV4 :
                                                 mac/ipv4/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_IPV6 :
                                                 mac/ipv6/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_MPLS :
                                                 mac/mpls/qos/pp_info/pkg/range_key
                                                 CLX_CIA_CLASSIFY_KEY_UDF  : pkg/range_key */
    clx_port_bitmap_t port_bmp;        /* ingress/egress port bitmap for ingress/egress stage */
    clx_cia_mac_key_t mac_key;         /* mac key */
    clx_cia_arp_key_t arp_key;         /* arp key */
    clx_cia_ipv4_key_t ipv4_key;       /* ipv4 key */
    clx_cia_ipv6_key_t ipv6_key;       /* ipv6 key */
    clx_cia_mpls_key_t mpls_key;       /* mpls key */
    clx_cia_qos_key_t qos_key;         /* qos key */
    clx_cia_pp_info_key_t pp_info_key; /* pp info key */
    clx_cia_pkg_key_t pkg_key;         /* pkg key */
    uint32 udf_key_prof_id;            /* udf key profile id */
    uint32 udf_key_prof_id_msk;        /* udf key profile id mask */
    uint32 range_bmp;
    uint32 range_bmp_msk;
    uint32 flags; /* clx_cia_classify_flags_t */
} clx_cia_classify_t;

#define CLX_CIA_CLASSIFY_FLAGS_MAC_KEY (1U << 0) /* mac key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_ARP_KEY (1U << 1) /* arp key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_IPV4_KEY                                                         \
    (1U << 2)                                    /* ipv4 key flag, depends on classify_key_type \
                                                  */
#define CLX_CIA_CLASSIFY_FLAGS_IPV6_KEY                                                         \
    (1U << 3)                                    /* ipv6 key flag, depends on classify_key_type \
                                                  */
#define CLX_CIA_CLASSIFY_FLAGS_MPLS_KEY                                                         \
    (1U << 4)                                    /* mpls key flag, depends on classify_key_type \
                                                  */
#define CLX_CIA_CLASSIFY_FLAGS_QOS_KEY (1U << 5) /* qos key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_PP_INFO_KEY                                       \
    (1U << 6)                                    /* pp info key flag, depends on \
                                               classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_PKG_KEY (1U << 7) /* pkg key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_RANGE_KEY \
    (1U << 8)                                    /* range key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_UDF_VLD (1U << 9) /* udf key flag, depends on classify_key_type */
#define CLX_CIA_CLASSIFY_FLAGS_PORT_BMP_VLD                                          \
    (1U << 10)                                   /* port bitmap key flag, depends on \
                                                       classify_key_type */

typedef struct clx_cia_exact_pkg_key_s {
    boolean l2_sa_grp_lbl_vld;
    uint32 l2_sa_grp_lbl;   /* mt:10 bits, l2 source address group label */
    boolean l2_da_grp_lbl_vld;
    uint32 l2_da_grp_lbl;   /* mt:10 bits, l2 destination address group label */
    boolean l3_sa_grp_lbl_vld;
    uint32 l3_sa_grp_lbl;   /* mt:16 bits, l3 source address group label */
    boolean l3_da_grp_lbl_vld;
    uint32 l3_da_grp_lbl;   /* mt:16 bits, l3 destination address group label */
    boolean intf_grp_lbl_vld;
    uint32 intf_grp_lbl;    /* mt:16 bits, local interface group label*/
    boolean igr_cia_grp_lbl_vld;
    uint32 igr_cia_grp_lbl; /* 12 bits, ingress cia search group label */
    boolean vrf_vld;
    uint32 vrf;             /* 13 bits, virtual routing forwarding index */
    boolean bdid_vld;
    uint32 bdid;            /* 14 bits, bridge domain index */
    boolean tcp_flag_vld;
    uint32 tcp_flag;        /* 12 bits, tcp flag */

    boolean svid_vld;
    uint16 svid;                        /* service vlan id */
    boolean spcp_vld;
    uint8 spcp;                         /* service vlan pcp */
    boolean sdei_vld;
    uint8 sdei;                         /* service vlan dei */
    boolean cvid_vld;
    uint16 cvid;                        /* custom vlan id */
    boolean cpcp_vld;
    uint8 cpcp;                         /* custom vlan pcp */
    boolean cdei_vld;
    uint8 cdei;                         /* custom vlan dei */

    uint32 pkg_cnt;                     /* pkg key byte count */
    uint32 data[CLX_CIA_EXACT_PKG_NUM]; /* pkg key data */

    uint32 flags_vld;                   /* clx_cia_exact_pkg_key_flags_xxx */
    uint32 flags;                       /* clx_cia_exact_pkg_key_flags_xxx */
} clx_cia_exact_pkg_key_t;

#define CLX_CIA_EXACT_PKG_KEY_FLAGS_VLAN_TAG_MODE_1Q \
    (1U << 0) /* indicates cvid/cpcp/cdei is in 1'st or 2'nd vlan */
#define CLX_CIA_EXACT_PKG_KEY_FLAGS_L3_ROUTE (1U << 1) /* is l3 route */

typedef struct clx_cia_exact_classify_s {
    uint32 udf_key_prof_id;          /* udf entry id */
    clx_cia_exact_pkg_key_t pkg_key; /* pkg key */
    uint32 range_bmp;
    uint32 flags;                    /* clx_cia_exact_classify_flags_xxx */
    uint32 logic_tile;
} clx_cia_exact_classify_t;

#define CLX_CIA_EXACT_CLASSIFY_FLAGS_RANGE_KEY      (1U << 0)
#define CLX_CIA_EXACT_CLASSIFY_FLAGS_ADD_LOGIC_TILE (1U << 1)

typedef struct clx_cia_qos_act_s {
    uint8 pcp;         /* remark pcp */
    uint8 dei;         /* remark dei */
    uint8 dscp;        /* remark dscp */
    uint8 ecn;         /* remark ecn */
    uint8 exp;         /* remark exp */
    uint8 tc;          /* remark tc */
    clx_color_t color; /* remark color */
    uint32 flags;      /* CLX_CIA_QOS_ACT_FLAGS_XXX */
} clx_cia_qos_act_t;

#define CLX_CIA_QOS_ACT_FLAGS_REMARK_PCP   (1U << 0) /* remark pcp flag, egress only */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_DEI   (1U << 1) /* remark dei flag, egress only */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_DSCP  (1U << 2) /* remark dscp flag, egress only */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_ECN   (1U << 3) /* remark ecn flag */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_EXP   (1U << 4) /* remark exp flag, egress only */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_TC    (1U << 5) /* remark tc flag */
#define CLX_CIA_QOS_ACT_FLAGS_REMARK_COLOR (1U << 6) /* remark color flag */
#define CLX_CIA_QOS_ACT_FLAGS_DROP         (1U << 7) /* per qos color decision drop forward flag */
/* qos do not modify, ingress only */
#define CLX_CIA_QOS_ACT_FLAGS_QOS_DO_NOT_MODIFY (1U << 9)

typedef enum clx_cia_redir_e {
    CLX_CIA_REDIR_L2_UC,   /* redirect to L2 unicast */
    CLX_CIA_REDIR_L3_UC,   /* redirect to L3 unicast */
    CLX_CIA_REDIR_L3_ECMP, /* redirect to L3 ecmp group */
    CLX_CIA_REDIR_L2_MC,   /* redirect to L2 multicast group */
    CLX_CIA_REDIR_L3_MC,   /* redirect to L3 multicast group */
    CLX_CIA_REDIR_L3_MPLS, /* redirect to L25 mpls */
    CLX_CIA_REDIR_CPU,     /* redirect to cpu port */
    CLX_CIA_REDIR_LAST
} clx_cia_redir_t;

typedef struct clx_cia_redir_act_s {
    clx_cia_redir_t redir_type;
    clx_port_t port;                  /* used for L2_UC */
    clx_bridge_domain_t bdid;         /* used for L2_UC(nv) */
    uint32 adj_id;                    /* used for L3_UC */
    uint32 ecmp_grp_id;               /* used for L3_ECMP */
    uint32 mcast_id;                  /* used for L2/L3_MC */
    uint32 swap_lbl;                  /* used for L25 MPLS */
    clx_pkt_rx_rsn_bmp_t cpu_rsn_bmp; /* used for CPU */
    uint32 redir_idx;                 /* redirect idx */
    uint32 flags;                     /* CLX_CIA_REDIR_ACT_FLAGS_XXX */
} clx_cia_redir_act_t;

#define CLX_CIA_REDIR_ACT_FLAGS_BYPASS_PRUNE (1U << 0) /* used for L2_UC */
#define CLX_CIA_REDIR_ACT_FLAGS_SWAP_LBL     (1U << 1) /* used for L25 */
/* used for index mode, if the index contains the behavior of redirecting BDID,
need to set flag CLX_ACL_REDIRECT_ACTION_FLAGS_REDIR_WITH_BDID */
#define CLX_CIA_REDIR_ACT_FLAGS_INDEX_MODE (1U << 2)
/* redirect with bdid assigned, valid on L2_UC/L2_MC/L3_MC */
#define CLX_CIA_REDIR_ACT_FLAGS_REDIR_WITH_BDID (1U << 3)

typedef enum clx_cia_fcm_act_e {
    CLX_CIA_FCM_DEL = 1,      /* del packet info */
    CLX_CIA_FCM_ADD,          /* add packet info */
    CLX_CIA_FCM_SET,          /* replace packet info */
    CLX_CIA_FCM_SET_WITH_MSK, /* replace packet info with mask */
    CLX_CIA_FCM_LAST
} clx_cia_fcm_act_t;

typedef enum clx_cia_fcm_type_e {
    CLX_CIA_FCM_TYPE_UDF = 0,     /* User define tlv format */
    CLX_CIA_FCM_TYPE_CVLAN,       /* CLX_CIA_FCM_SET_WITH_MSK 2Bytes, custom vlan */
    CLX_CIA_FCM_TYPE_SVLAN,       /* CLX_CIA_FCM_SET_WITH_MSK 2Bytes, service vlan */
    CLX_CIA_FCM_TYPE_SRC_MAC_HI,  /* CLX_CIA_FCM_SET 2Bytes, source mac address
                                         high */
    CLX_CIA_FCM_TYPE_SRC_MAC_LO,  /* CLX_CIA_FCM_SET 4Bytes, source mac address low */
    CLX_CIA_FCM_TYPE_DST_MAC_HI,  /* CLX_CIA_FCM_SET 2Bytes, destination mac
                                         address high */
    CLX_CIA_FCM_TYPE_DST_MAC_LO,  /* CLX_CIA_FCM_SET 4Bytes, destination mac address low */
    CLX_CIA_FCM_TYPE_SRC_IPV4,    /* CLX_CIA_FCM_SET 4Bytes, source IPv4 address */
    CLX_CIA_FCM_TYPE_DST_IPV4,    /* CLX_CIA_FCM_SET 4Bytes, destination IPv4 address */
    CLX_CIA_FCM_TYPE_SRC_IPV6_0,  /* CLX_CIA_FCM_SET 4Bytes, source IPv6 address 0 */
    CLX_CIA_FCM_TYPE_SRC_IPV6_1,  /* CLX_CIA_FCM_SET 4Bytes, source IPv6 address 1*/
    CLX_CIA_FCM_TYPE_SRC_IPV6_2,  /* CLX_CIA_FCM_SET 4Bytes, source IPv6 address 2*/
    CLX_CIA_FCM_TYPE_SRC_IPV6_3,  /* CLX_CIA_FCM_SET 4Bytes, source IPv6 address 3*/
    CLX_CIA_FCM_TYPE_DST_IPV6_0,  /* CLX_CIA_FCM_SET 4Bytes, destination IPv6 address 0 */
    CLX_CIA_FCM_TYPE_DST_IPV6_1,  /* CLX_CIA_FCM_SET 4Bytes, destination IPv6 address 1 */
    CLX_CIA_FCM_TYPE_DST_IPV6_2,  /* CLX_CIA_FCM_SET 4Bytes, destination IPv6 address 2 */
    CLX_CIA_FCM_TYPE_DST_IPV6_3,  /* CLX_CIA_FCM_SET 4Bytes, destination IPv6 address 3 */
    CLX_CIA_FCM_TYPE_TOS_IPV4,    /* CLX_CIA_FCM_SET_WITH_MSK 1Byte, IPv4 TOS */
    CLX_CIA_FCM_TYPE_TOS_IPV6,    /* CLX_CIA_FCM_SET_WITH_MSK 1Byte, IPv6 TOS */
    CLX_CIA_FCM_TYPE_L4_SRC_PORT, /* CLX_CIA_FCM_SET 2Bytes, l4 source port */
    CLX_CIA_FCM_TYPE_L4_DST_PORT, /* CLX_CIA_FCM_SET 2Bytes, l4 destination port */
    CLX_CIA_FCM_TYPE_LAST
} clx_cia_fcm_type_t;

typedef struct clx_cia_fcm_cfg_s {
    clx_cia_fcm_type_t fcm_type;      /* udf or internal pre-define offset*/
    clx_cia_fcm_act_t type;           /* fcm action type */
    clx_cia_pkg_base_t pkg_base_type; /* fcm base type */
    uint32 byte_offset; /* value should be multiple of two bytes, and offsets must maintain
                         * ascending sequence when deleting or adding packet information
                         */
    uint32 byte_cnt;    /* value should be multiple of two bytes */
    uint8 data[CLX_CIA_FCM_DATA_NUM]; /* fcm data */
    uint8 msk[CLX_CIA_FCM_DATA_NUM];  /* fcm data mask */
} clx_cia_fcm_cfg_t;

typedef struct clx_cia_pkt_fcm_s {
    clx_cia_fcm_cfg_t fcm_cfg[CLX_CIA_FCM_NUM]; /* fcm config array */
    uint32 fcm_cnt;                             /* fcm config count */
    uint32 fcm_idx;                             /* index mode */
    uint32 flags;
} clx_cia_pkt_fcm_t;

#define CLX_CIA_PKT_FCM_FLAGS_IDX_MODE (1U << 0) /* FCM index mode */
#define CLX_CIA_PKT_FCM_FLAGS_NOP      (1U << 1) /* FCM NOP, used to conflict with other fcm */

typedef struct clx_cia_cmcc_ioam_s {
    uint8 delay;        /* 2 bits delay */
    uint8 color_enable; /* 1 bit color */
    uint16 flow_id;     /* flow id */
} clx_cia_cmcc_ioam_t;

typedef enum clx_cia_telm_type_e {
    CLX_CIA_TELM_TYPE_INT = 0,   /* INT */
    CLX_CIA_TELM_TYPE_CMCC_IOAM, /* CMCC IOAM */
    CLX_CIA_TELM_TYPE_LAST
} clx_cia_telm_type_t;

typedef struct clx_cia_telm_s {
    boolean enable;                  /* telemetry enable */
    clx_cia_telm_type_t type;        /* telemetry type */
    clx_cia_cmcc_ioam_t ioam_config; /* cmcc ioam config */
    uint8 int_prof_id;               /* int profile index */
} clx_cia_telm_t;

typedef enum clx_cia_mir_policer_type_e {
    CLX_CIA_MIR_POLICER_TYPE_MIR = 0, /* mirror policer type mirror */
    CLX_CIA_MIR_POLICER_TYPE_COPP,    /* mirror policer type copp */
    CLX_CIA_MIR_POLICER_TYPE_LAST
} clx_cia_mir_policer_type_t;

typedef enum clx_cia_mir_policer_act_e {
    CLX_CIA_MIR_POLICER_ACT_NONE = 0, /* No policer action */
    CLX_CIA_MIR_POLICER_ACT_DROP,     /* policer action drop */
    CLX_CIA_MIR_POLICER_ACT_LAST
} clx_cia_mir_policer_act_t;

typedef struct clx_cia_mir_policer_s {
    clx_cia_mir_policer_type_t type;      /* mirror policer type */
    clx_cia_mir_policer_act_t yellow_act; /* policer yellow action */
    uint32 meter_id;                      /* meter id */
} clx_cia_mir_policer_t;

typedef enum clx_cia_vid_ctrl_type_e {
    CLX_CIA_VID_TRY_POP_1, /* try to pop 1 tag */
    CLX_CIA_VID_TRY_POP_2, /* try to pop 2 tags */
    CLX_CIA_VID_TRY_POP_3, /* try to pop 3 tags */
    CLX_CIA_VID_TRY_POP_4, /* try to pop 4 tags */
    CLX_CIA_VID_KEEP_1,    /* keep 1 tag */
    CLX_CIA_VID_KEEP_2,    /* keep 2 tags */
    CLX_CIA_VID_KEEP_ALL,  /* keep all tags */
    CLX_CIA_VID_LAST
} clx_cia_vid_ctrl_type_t;

typedef struct clx_cia_vid_act_s {
    clx_cia_vid_ctrl_type_t vid_ctrl_type;
    uint32 flags;
} clx_cia_vid_act_t;

#define CLX_CIA_VID_ACT_FLAGS_PUSH_TRACING_VLAN (1U << 0)
#define CLX_CIA_VID_ACT_FLAGS_PUSH_RULE_VLAN    (1U << 1)
#define CLX_CIA_VID_ACT_FLAGS_VID_CTRL_VLD      (1U << 2)

typedef struct clx_cia_act_s {
    uint32 pri;                             /* value :
                                                    mt: 0-15, can only set to 0 for exact
                                                    1-15 for cia */
    boolean mod_en;                         /* mirror on drop enable, ingress only */
    uint32 mir_session_bmp;                 /* Mirror session ID bitmap */
    clx_sample_t sample;                    /* sample packet */
    uint32 meter_id;                        /* meter index */
    uint32 counter_id;                      /* counter index */
    uint32 dist_counter_id;                 /* distribution counter index */
    uint32 igr_cia_grp_lbl;                 /* write ingress cia group label */
    clx_cia_qos_act_t qos_act_color_blind;  /* color blind qos action */
    clx_cia_qos_act_t qos_act_color_yellow; /* color yellow qos action */
    clx_cia_qos_act_t qos_act_color_red;    /* color red qos action */
    clx_pkt_rx_rsn_bmp_t cpu_rsn_bmp;       /* can only set one bit of the bitmap */
    clx_cia_redir_act_t redir_act;          /* redirect action */
    clx_cia_pkt_fcm_t pkt_fcm;              /* packet fcm action */
    clx_cia_telm_t telm_act;                /* int/cmcc-ioam action */
    clx_cia_mir_policer_t mir_policer;      /* mirror policer */
    clx_cia_vid_act_t vid_act;              /* vid control action */
    uint32 flags;                           /* clx_cia_action_flags_t*/
} clx_cia_act_t;

#define CLX_CIA_ACT_FLAGS_METER_VLD             (1U << 0) /* meter valid flag */
#define CLX_CIA_ACT_FLAGS_COUNTER_VLD           (1U << 1) /* counter valid flag */
#define CLX_CIA_ACT_FLAGS_DIST_COUNTER_VLD      (1U << 2) /* distribution counter valid flag */
#define CLX_CIA_ACT_FLAGS_CANCEL_LEARN          (1U << 3) /* ingress only */
#define CLX_CIA_ACT_FLAGS_BYPASS_RPF_CHECK_FAIL (1U << 4) /* ingress only */
#define CLX_CIA_ACT_FLAGS_COPY_TO_CPU           (1U << 5) /* copy to cpu action valid flag */
#define CLX_CIA_ACT_FLAGS_REDIR                 (1U << 6) /* redirect action, ingress only */
#define CLX_CIA_ACT_FLAGS_DROP                  (1U << 7) /* drop normal port/redirect to cpu packet */
#define CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND                                             \
    (1U << 8)                                             /* color blind qos action valid \
                                                             flag */
#define CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW                                             \
    (1U << 9)                                             /* color yellow qos action valid \
                                                             flag */
#define CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED                                                  \
    (1U << 10)                                            /* color red qos action valid flag \
                                                           */
#define CLX_CIA_ACT_FLAGS_PKT_FCM                                                                  \
    (1U << 11)                                            /* packet fcm action valid flag, ingress \
                                                             only */
#define CLX_CIA_ACT_FLAGS_BYPASS_TTL_CHECK_FAIL                                             \
    (1U << 12)                                            /* bypass ttl check fail, ingress \
                                                       only */
#define CLX_CIA_ACT_FLAGS_KEEP_TTL                                                          \
    (1U << 13)                                    /* ingress only. If this flag is set, not \
                                                support redirect action */
#define CLX_CIA_ACT_FLAGS_TELM_ACT_VLD (1U << 14) /* telemetry action config valid flag */
#define CLX_CIA_ACT_FLAGS_XOR_LFSR                                                        \
    (1U << 15)                                    /* xor LFSR to final hash, ingress only \
                                                   */
#define CLX_CIA_ACT_FLAGS_ALLOW_TRUNCATE                                              \
    (1U << 16)                                    /* allow tm to do truncate, ingress \
                                                  only */
#define CLX_CIA_ACT_FLAGS_FORCE_DECAP                                                    \
    (1U << 17)                                    /* force remove outer IP/MPLS, ingress \
                                                 only */
#define CLX_CIA_ACT_FLAGS_MIR_POLICER_VLD                                       \
    (1U << 18)                                    /* Mirror policer valid, only \
                                                   */
#define CLX_CIA_ACT_FLAGS_VID_ACT_VLD                                               \
    (1U << 19)                                    /* Vid action valid, ingress only \
                                                   */
#define CLX_CIA_ACT_FLAGS_UDF_RSN_VLD (1U << 20)  /* Udf reason valid flag */

typedef struct clx_cia_grp_info_s {
    clx_cia_stage_t stage;       /* cia group stage type */
    uint32 grp_id;               /* cia group index */
    clx_cia_grp_prof_t grp_prof; /* group profile */
} clx_cia_grp_info_t;

typedef struct clx_cia_exact_grp_info_s {
    clx_cia_stage_t stage;             /* cia exact group stage type */
    uint32 grp_id;                     /* cia exact group index */
    clx_cia_exact_grp_prof_t grp_prof; /* group profile */
} clx_cia_exact_grp_info_t;

typedef struct clx_cia_entry_s {
    boolean entry_vld;           /* entry valid bit */
    clx_cia_classify_t classify; /* entry classify */
    clx_cia_act_t act;           /* entry action */
} clx_cia_entry_t;

typedef struct clx_cia_entry_info_s {
    clx_cia_stage_t stage;      /* group stage type */
    uint32 grp_id;              /* group index */
    uint32 entry_id;            /* entry index */
    uint32 pri;                 /* entry priority */
    uint32 hw_entry_id;         /* hardware entry index */
    uint32 norm_width;          /* key width of entry */
    clx_cia_entry_t entry_info; /* classify and action */
} clx_cia_entry_info_t;

typedef struct clx_cia_exact_entry_s {
    clx_cia_exact_classify_t classify; /* entry classify */
    clx_cia_act_t act;                 /* entry action */
} clx_cia_exact_entry_t;

typedef struct clx_cia_exact_entry_info_s {
    clx_cia_stage_t stage; /* group stage type */
    uint32 grp_id;         /* group index */
    uint32 entry_id;       /* entry index */
    uint32 hw_entry_id;    /* hardware entry index */
    clx_cia_exact_entry_t entry_info;
} clx_cia_exact_entry_info_t;

typedef struct clx_cia_udf_entry_s {
    clx_cia_pkt_format_t pkt_format;
    clx_cia_udf_prof_t prof;
} clx_cia_udf_entry_t;

typedef struct clx_cia_udf_info_s {
    clx_cia_stage_t stage;
    uint32 udf_key_prof_id;
    clx_cia_udf_entry_t entry;
} clx_cia_udf_info_t;

typedef struct clx_cia_range_info_s {
    clx_cia_stage_t stage;         /* group stage */
    uint32 range_id;               /* range index, 0-15 */
    clx_cia_range_cfg_t range_cfg; /* range config */
} clx_cia_range_info_t;

typedef clx_error_no_t (*clx_cia_rim_trav_func_t)(const uint32 unit,
                                                  const void *ptr_act,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_grp_trav_func_t)(const uint32 unit,
                                                  const clx_cia_grp_info_t *ptr_grp_info,
                                                  void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_exact_grp_trav_func_t)(const uint32 unit,
                                                        const clx_cia_exact_grp_info_t *ptr_grp_info,
                                                        void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_entry_trav_func_t)(const uint32 unit,
                                                    const clx_cia_entry_info_t *ptr_entry_info,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_exact_entry_trav_func_t)(
    const uint32 unit,
    const clx_cia_exact_entry_info_t *ptr_entry_info,
    void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_udf_entry_trav_func_t)(const uint32 unit,
                                                        const clx_cia_udf_info_t *ptr_entry_info,
                                                        void *ptr_cookie);

typedef clx_error_no_t (*clx_cia_range_trav_func_t)(const uint32 unit,
                                                    const clx_cia_range_info_t *ptr_range_info,
                                                    void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The API is used to get the configuration information of UCP group.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     grp_id          - The UCP group id to be deleted.
 * @param [out]    ptr_grp_prof    - UCP group profile to be returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_grp_get(const uint32 unit,
                const clx_cia_stage_t stage,
                const uint32 grp_id,
                clx_cia_grp_prof_t *ptr_grp_prof);

/**
 * @brief The API is used to add an UCP group.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     ptr_grp_prof    - UCP group profile.
 * @param [out]    ptr_grp_id      - UCP group id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_grp_add(const uint32 unit,
                const clx_cia_stage_t stage,
                const clx_cia_grp_prof_t *ptr_grp_prof,
                uint32 *ptr_grp_id);

/**
 * @brief The API is used to delete an UCP group.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    stage     - UCP group stage type.
 * @param [in]    grp_id    - The UCP group id to be deleted.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_grp_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 grp_id);

/**
 * @brief The API is used to traverse UCP groups.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     callback      - The callback function of type clx_cia_grp_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_grp_trav(const uint32 unit,
                 const clx_cia_stage_t stage,
                 const clx_cia_grp_trav_func_t callback,
                 void *ptr_cookie);

/**
 * @brief The API is used to get the configuration information of exact UCP group.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     grp_id          - The UCP group id to be deleted.
 * @param [out]    ptr_grp_prof    - UCP group profile to be returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_grp_get(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 grp_id,
                      clx_cia_exact_grp_prof_t *ptr_grp_prof);

/**
 * @brief The API is used to add a exact UCP group.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group stage type.
 * @param [in]     ptr_grp_prof    - UCP group profile.
 * @param [out]    ptr_grp_id      - UCP group id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_grp_add(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const clx_cia_exact_grp_prof_t *ptr_grp_prof,
                      uint32 *ptr_grp_id);

/**
 * @brief The API is used to delete a exact UCP group.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    stage     - UCP group stage type.
 * @param [in]    grp_id    - The UCP group id to be deleted.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_grp_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 grp_id);

/**
 * @brief The API is used to traverse exact UCP groups.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     callback      - The callback function of type CLX_CIA_GRP_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_grp_trav(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const clx_cia_exact_grp_trav_func_t callback,
                       void *ptr_cookie);

/**
 * @brief The API is used to get the configuration information of udf key profile.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - Udf key profile stage type.
 * @param [in]     udf_entry_id      - The udf key profile id to be get.
 * @param [out]    ptr_entry_info    - The output udf entry info.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_udf_entry_get(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 udf_entry_id,
                      clx_cia_udf_entry_t *ptr_entry_info);

/**
 * @brief The API is used to add an udf key profile.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    stage             - Udf key profile stage type.
 * @param [in]    udf_entry_id      - The udf key profile id to be added.
 * @param [in]    ptr_entry_info    - The UDF info.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_udf_entry_add(const uint32 unit,
                      const clx_cia_stage_t stage,
                      const uint32 udf_entry_id,
                      const clx_cia_udf_entry_t *ptr_entry_info);

/**
 * @brief The API is used to delete an udf key profile.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    stage           - Udf key profile stage type.
 * @param [in]    udf_entry_id    - Udf key profile id to be deleted.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_udf_entry_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 udf_entry_id);

/**
 * @brief The API is used to traverse udf key profile.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - Udf key profile stage type.
 * @param [in]     callback      - The callback function of type clx_cia_udf_entry_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_udf_entry_trav(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const clx_cia_udf_entry_trav_func_t callback,
                       void *ptr_cookie);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     entry_id         - Entry id.
 * @param [out]    ptr_stage        - The UCP group type of the entry id to be returned.
 * @param [out]    ptr_grp_id       - The group id of the entry id to be returned.
 * @param [out]    ptr_entry_pri    - The entry priority of the entry id to be returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_id_info_get(const uint32 unit,
                          const uint32 entry_id,
                          clx_cia_stage_t *ptr_stage,
                          uint32 *ptr_grp_id,
                          uint32 *ptr_entry_pri);

/**
 * @brief The API is used to allocate a logic id for UCP entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     stage           - UCP group type.
 * @param [in]     grp_id          - Allocate a entry id from UCP group.
 * @param [in]     entry_pri       - Entry priority.
 * @param [out]    ptr_entry_id    - The entry id to be returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_id_alloc(const uint32 unit,
                       const clx_cia_stage_t stage,
                       const uint32 grp_id,
                       const uint32 entry_pri,
                       uint32 *ptr_entry_id);

/**
 * @brief The API is used to free the logic id for UCP entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_id_free(const uint32 unit, const uint32 entry_id);

/**
 * @brief The API is used to get an UCP entry from HW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     entry_id          - Entry id.
 * @param [out]    ptr_entry_info    - The entry information returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_get(const uint32 unit, const uint32 entry_id, clx_cia_entry_t *ptr_entry_info);

/**
 * @brief The API is used to add an Tcam entry to HW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    entry_id          - Entry id.
 * @param [in]    ptr_entry_info    - The entry information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_add(const uint32 unit, const uint32 entry_id, const clx_cia_entry_t *ptr_entry_info);

/**
 * @brief The API is used to set valid bit of Tcam entry to HW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    entry_id     - Entry id.
 * @param [in]    entry_vld    - The valid bit of entry.
 * @return        CLX_E_OK    - Operation success.
 */

clx_error_no_t
clx_cia_entry_vld_set(const uint32 unit, const uint32 entry_id, const boolean entry_vld);

/**
 * @brief The API is used to delete an Tcam entry from HW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_del(const uint32 unit, const uint32 entry_id);

/**
 * @brief The API is used to traverse UCP entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage.
 * @param [in]     grp_id        - Group id.
 * @param [in]     callback      - The callback function of type CLX_CIA_ENTRY_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_entry_trav(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const uint32 grp_id,
                   const clx_cia_entry_trav_func_t callback,
                   void *ptr_cookie);

/**
 * @brief The API is used to get an exact match entry from HW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - UCP group stage type.
 * @param [in]     grp_id            - Group id.
 * @param [in]     entry_id          - Entry id.
 * @param [out]    ptr_entry_info    - The entry information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_get(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        const uint32 entry_id,
                        clx_cia_exact_entry_t *ptr_entry_info);

/**
 * @brief The API is used to add an exact match entry to HW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     stage             - UCP group stage type.
 * @param [in]     grp_id            - Group id.
 * @param [in]     ptr_entry_info    - The entry information.
 * @param [out]    ptr_entry_id      - The returned entry id from HW.
 * @return         Clx_error_no_t.
 */
clx_error_no_t
clx_cia_exact_entry_add(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        const clx_cia_exact_entry_t *ptr_entry_info,
                        uint32 *ptr_entry_id);

/**
 * @brief The API is used to delete an exact match entry from HW.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    stage       - UCP group stage type.
 * @param [in]    grp_id      - Group id.
 * @param [in]    entry_id    - Entry id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_del(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 grp_id,
                        const uint32 entry_id);

/**
 * @brief The API is used to traverse UCP entries.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP group stage type.
 * @param [in]     grp_id        - Group id.
 * @param [in]     callback      - The callback function of type CLX_CIA_ENTRY_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_trav(const uint32 unit,
                         const clx_cia_stage_t stage,
                         const uint32 grp_id,
                         const clx_cia_exact_entry_trav_func_t callback,
                         void *ptr_cookie);

/**
 * @brief The API is used to get logic id information for UCP entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     entry_id      - Flow entry id.
 * @param [out]    ptr_stage     - The UCP group stage type of the entry id to be returned.
 * @param [out]    ptr_grp_id    - The group id of the entry id to be returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_exact_entry_id_info_get(const uint32 unit,
                                const uint32 entry_id,
                                clx_cia_stage_t *ptr_stage,
                                uint32 *ptr_grp_id);

/**
 * @brief The API is used to alloc resource index.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - Resouce index type.
 * @param [out]    ptr_index    - Alloc index.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_alloc(const uint32 unit, const clx_cia_rim_alloc_t type, uint32 *ptr_index);

/**
 * @brief The API is used to free resource index.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    type     - Resouce index type.
 * @param [in]    index    - Free index.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_free(const uint32 unit, const clx_cia_rim_alloc_t type, const uint32 index);

/**
 * @brief The API is used to set index action.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    type       - Resouce index type.
 * @param [in]    index      - Set index.
 * @param [in]    ptr_act    - Set index action.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_act_set(const uint32 unit,
                    const clx_cia_rim_alloc_t type,
                    const uint32 index,
                    const void *ptr_act);

/**
 * @brief The API is used to get index action.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Resouce index type.
 * @param [in]     index      - Get index.
 * @param [out]    ptr_act    - Get index action.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_act_get(const uint32 unit,
                    const clx_cia_rim_alloc_t type,
                    const uint32 index,
                    void *ptr_act);

/**
 * @brief The API is used to traverse rim resouce.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     type          - Resouce index type.
 * @param [in]     callback      - The callback function of type CLX_CIA_RIM_TRAVERSE_FUNC_T.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
clx_cia_rim_act_trav(const uint32 unit,
                     const clx_cia_rim_alloc_t type,
                     const clx_cia_rim_trav_func_t callback,
                     void *ptr_cookie);

/**
 * @brief The API is used to add/set the range configuration information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    stage        - UCP stage type: Ingress/Egress.
 * @param [in]    range_id     - The range id to be added/set.
 * @param [in]    ptr_range    - The range configuration information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_add(const uint32 unit,
                  const clx_cia_stage_t stage,
                  const uint32 range_id,
                  const clx_cia_range_cfg_t *ptr_range);

/**
 * @brief The API is used to delete the range configuration information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    stage       - UCP stage type: Ingress/Egress.
 * @param [in]    range_id    - The range id to be deleted.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_del(const uint32 unit, const clx_cia_stage_t stage, const uint32 range_id);

/**
 * @brief The API is used to get the range configuration information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     stage        - UCP stage type: Ingress/Egress.
 * @param [in]     range_id     - The range id to be get.
 * @param [out]    ptr_range    - The range configuration information to be returned.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_get(const uint32 unit,
                  const clx_cia_stage_t stage,
                  const uint32 range_id,
                  clx_cia_range_cfg_t *ptr_range);

/**
 * @brief The API is used to traverse range.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     stage         - UCP stage type: Ingress/Egress.
 * @param [in]     callback      - The callback function of type clx_cia_range_trav_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_trav(const uint32 unit,
                   const clx_cia_stage_t stage,
                   const clx_cia_range_trav_func_t callback,
                   void *ptr_cookie);

/**
 * @brief The API is used to set range_or_bitmap.
 *
 * Range_or_bitmap, each bit set to 1 indicates the corresponding range participates in the logical
 * "OR" operation of bit map profile, range_or_bitmap is zero means logical "AND" within 16 range of
 * udf profile.
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    stage        - UCP stage type: Ingress/Egress.
 * @param [in]    union_id     - The union id.
 * @param [in]    range_bmp    - The range bitmap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_union_set(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 union_id,
                        const uint32 range_bmp);

/**
 * @brief The API is used to get range_or_bitmap.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     stage            - UCP stage type: Ingress/Egress.
 * @param [in]     union_id         - The union id.
 * @param [out]    ptr_range_bmp    - The range bitmap.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_cia_range_union_get(const uint32 unit,
                        const clx_cia_stage_t stage,
                        const uint32 union_id,
                        uint32 *ptr_range_bmp);

#endif
