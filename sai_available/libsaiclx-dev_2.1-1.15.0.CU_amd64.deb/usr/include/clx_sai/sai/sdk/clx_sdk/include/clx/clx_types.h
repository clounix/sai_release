/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_types.h
 * PURPOSE:
 *      Define the commom data type in CLX SDK.
 * NOTES:
 */

#ifndef CLX_TYPES_H
#define CLX_TYPES_H

/* INCLUDE FILE DECLARATIONS
 */

#include <osal/osal_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_BIT_OFF 0
#define CLX_BIT_ON  1

#define CLX_INVALID_ID   (0xFFFFFFFF)
#define CLX_PORT_INVALID (CLX_INVALID_ID)
#define CLX_SEG_INVALID  (CLX_INVALID_ID)
#define CLX_FDID_INVALID (0)

/* for CPU Rx packet, indicate that the packet
 * is not received from remote switch
 */
#define CLX_PATH_INVALID (CLX_INVALID_ID)

#define CLX_SEMAPHORE_BINARY       (1)
#define CLX_SEMAPHORE_SYNC         (0)
#define CLX_SEMAPHORE_WAIT_FOREVER (0xFFFFFFFF)

/* MACRO FUNCTION DECLARATIONS
 */
#if defined(CLX_EN_HOST_32_BIT_BIG_ENDIAN) || defined(CLX_EN_HOST_32_BIT_LITTLE_ENDIAN)
typedef unsigned int clx_huge_t;
#elif defined(CLX_EN_HOST_64_BIT_BIG_ENDIAN) || defined(CLX_EN_HOST_64_BIT_LITTLE_ENDIAN)
typedef unsigned long long int clx_huge_t;
#else
#error "The 32bit and 64bit compatible data type are not defined !!"
#endif

#if defined(CLX_EN_HOST_64_BIT_BIG_ENDIAN) || defined(CLX_EN_HOST_64_BIT_LITTLE_ENDIAN) || \
    defined(CLX_EN_64BIT_ADDR)
typedef unsigned long long int clx_addr_t;
#else
typedef unsigned int clx_addr_t;
#endif

#if defined(CLX_EN_HOST_64_BIT_BIG_ENDIAN) || defined(CLX_EN_HOST_64_BIT_LITTLE_ENDIAN) || \
    defined(CLX_EN_64BIT_ADDR)
#define CLX_ADDR_PRINT "0x%llx"
#else
#define CLX_ADDR_PRINT "0x%x"
#endif

#if defined(CLX_EN_HOST_64_BIT_BIG_ENDIAN) || defined(CLX_EN_HOST_64_BIT_LITTLE_ENDIAN) || \
    defined(CLX_EN_64BIT_ADDR)
#define CLX_ADDR_64_HI(__addr__)  ((uint32)((__addr__) >> 32))
#define CLX_ADDR_64_LOW(__addr__) ((uint32)((__addr__) & 0xFFFFFFFF))
#define CLX_ADDR_32_TO_64(__hi32__, __low32__) \
    (((unsigned long long int)(__low32__)) | (((unsigned long long int)(__hi32__)) << 32))
#else
#define CLX_ADDR_64_HI(__addr__)               (0)
#define CLX_ADDR_64_LOW(__addr__)              (__addr__)
#define CLX_ADDR_32_TO_64(__hi32__, __low32__) (__low32__)
#endif

#define CLX_BITMAP_SIZE(bit_num)    (((bit_num) > 0) ? ((((bit_num) - 1) / 32) + 1) : (0))
#define CLX_IPV4_IS_MULTICAST(addr) (0xE0000000 == ((addr) & 0xF0000000))
#define CLX_IPV6_IS_MULTICAST(addr) (0xFF == (((uint8 *)(addr))[0]))
#define CLX_MAC_IS_MULTICAST(mac)   ((mac[0]) & (0x1))

/* DATA TYPE DECLARATIONS
 */
typedef uint8 clx_bit_mask_8_t;
typedef uint16 clx_bit_mask_16_t;
typedef uint32 clx_bit_mask_32_t;
typedef uint64 clx_bit_mask_64_t;

typedef uint8 clx_mac_t[6];
typedef uint32 clx_ipv4_t;
typedef uint8 clx_ipv6_t[16];

typedef uint64 clx_time_t;

/* Bridge Domain id data type. */
typedef uint32 clx_bridge_domain_t;

typedef union clx_ip_u {
    clx_ipv4_t ipv4_addr;
    clx_ipv6_t ipv6_addr;
} clx_ip_t;

typedef struct clx_ip_addr_s {
    clx_ip_t ip_addr;
    clx_ip_t ip_mask;
    boolean ipv4;
} clx_ip_addr_t;

/* Nexthop type */
typedef enum clx_nhp_type_e {
    CLX_NHP_TYPE_ADJ = 0,    /* specify nexthop type is l3 adjacency */
    CLX_NHP_TYPE_ECMP,       /* specify nexthop type is ecmp */
    CLX_NHP_TYPE_FRR,        /* specify nexthop type is frr */
    CLX_NHP_TYPE_TNL,        /* specify nexthop type is nvo3 */
    CLX_NHP_TYPE_MPLS_LSP,   /* specify nexthop type is mpls label switch path */
    CLX_NHP_TYPE_MPLS_PW,    /* specify nexthop type is mpls pseudowire */
    CLX_NHP_TYPE_L2_ECMP,    /* specify nexthop type is l2 ecmp */
    CLX_NHP_TYPE_MPLS_TRANS, /* specify nexthop type is mpls transit */
    CLX_NHP_TYPE_LAST
} clx_nhp_type_t;

typedef struct clx_nhp_s {
    clx_nhp_type_t type; /* Refer to clx_l3_nhp_type_t */
    uint32 id;           /* nexthop id */
} clx_nhp_t;

typedef enum clx_tnl_info_type_e {
    CLX_TNL_HDR_TYPE_IPV4INIPV4 = 0, /* RFC2003, IPv4-in-IPv4 tunnel */
    CLX_TNL_HDR_TYPE_IPV4INIPV6,     /* RFC2003, IPv4-in-IPv6 tunnel */
    CLX_TNL_HDR_TYPE_IPV6INIPV4,     /* RFC2003, IPv6-in-IPv4 tunnel */
    CLX_TNL_HDR_TYPE_IPV6INIPV6,     /* RFC2003, IPv6-in-IPv6 tunnel */
    CLX_TNL_HDR_TYPE_GREIPV4INIPV4,  /* RFC2784/RFC2890,GRE IPv4-in-IPv4 tunnel */
    CLX_TNL_HDR_TYPE_GREIPV6INIPV4,  /* RFC2784/RFC2890,GRE IPv6-in-IPv4 tunnel */
    CLX_TNL_HDR_TYPE_GREIPV4INIPV6,  /* RFC2784/RFC2890,GRE IPv4-in-IPv6 tunnel */
    CLX_TNL_HDR_TYPE_GREIPV6INIPV6,  /* RFC2784/RFC2890,GRE IPv6-in-IPv6 tunnel */
    CLX_TNL_HDR_TYPE_GRE_NSH,
    CLX_TNL_HDR_TYPE_GRE_L2,
    CLX_TNL_HDR_TYPE_6TO4,   /* RFC3056, 6to4 tunnel*/
    CLX_TNL_HDR_TYPE_ISATAP, /* RFC5214, ISATAP tunnel */
    CLX_TNL_HDR_TYPE_NVGRE_L2,
    CLX_TNL_HDR_TYPE_NVGRE_V4,
    CLX_TNL_HDR_TYPE_NVGRE_V6,
    CLX_TNL_HDR_TYPE_NVGRE_NSH,
    CLX_TNL_HDR_TYPE_VXLAN,
    CLX_TNL_HDR_TYPE_MPLSINGRE,
    CLX_TNL_HDR_TYPE_VXLANGPE_L2,
    CLX_TNL_HDR_TYPE_VXLANGPE_V4,
    CLX_TNL_HDR_TYPE_VXLANGPE_V6,
    CLX_TNL_HDR_TYPE_VXLANGPE_NSH,
    CLX_TNL_HDR_TYPE_GENEVE_L2,
    CLX_TNL_HDR_TYPE_GENEVE_V4,
    CLX_TNL_HDR_TYPE_GENEVE_V6,
    CLX_TNL_HDR_TYPE_INT_REPORT,
    CLX_TNL_HDR_TYPE_FLEX0_L2,
    CLX_TNL_HDR_TYPE_FLEX0_V4,
    CLX_TNL_HDR_TYPE_FLEX0_V6,
    CLX_TNL_HDR_TYPE_FLEX0_NSH,
    CLX_TNL_HDR_TYPE_FLEX1_L2,
    CLX_TNL_HDR_TYPE_FLEX1_V4,
    CLX_TNL_HDR_TYPE_FLEX1_V6,
    CLX_TNL_HDR_TYPE_FLEX1_NSH,
    CLX_TNL_HDR_TYPE_FLEX2_L2,
    CLX_TNL_HDR_TYPE_FLEX2_V4,
    CLX_TNL_HDR_TYPE_FLEX2_V6,
    CLX_TNL_HDR_TYPE_FLEX2_NSH,
    CLX_TNL_HDR_TYPE_FLEX3_L2,
    CLX_TNL_HDR_TYPE_FLEX3_V4,
    CLX_TNL_HDR_TYPE_FLEX3_V6,
    CLX_TNL_HDR_TYPE_FLEX3_NSH,
    CLX_TNL_HDR_TYPE_LAST
} clx_tnl_hdr_type_t;

typedef struct clx_tnl_info_s {
    clx_ip_addr_t src_ip; /* key: The outer source IP address used by tunnel encapsulation. */
    clx_ip_addr_t dst_ip; /* key: The outer destination IP address used by tunnel encapsulation.
                           * For automatic tunnel, this is not required. If not specified,
                           * its ip address value must be set to 0, but the IP version
                           * must be same with src_ip.
                           */
    uint16 underlay_vrf;  /* key: Vrf id of the ip-tnl underlay network. */
    clx_tnl_hdr_type_t tnl_hdr_type; /* key: The tunnel hdr type. */
} clx_tnl_info_t;

typedef uint16 clx_vlan_t;
typedef uint32 clx_port_t;
typedef uint32 clx_gport_t;

typedef enum clx_gport_type_e {
    CLX_GPORT_TYPE_LOCAL = 0,
    CLX_GPORT_TYPE_UNIT_PORT,
    CLX_GPORT_TYPE_LAG,
    CLX_GPORT_TYPE_CPU_PORT,
    CLX_GPORT_TYPE_ECPU_PORT,
    CLX_GPORT_TYPE_ECMP_PORT,
    CLX_GPORT_TYPE_IP_TNL,
    CLX_GPORT_TYPE_MPLS_LSP,
    CLX_GPORT_TYPE_MPLS_PW,
    CLX_GPORT_TYPE_SRV6,
    CLX_GPORT_TYPE_LAST
} clx_gport_type_t;

/*support Green/Yellow/Red color*/
typedef enum clx_color_e {
    CLX_COLOR_GREEN = 0, /* The green color */
    CLX_COLOR_YELLOW,    /* The yellow color */
    CLX_COLOR_RED,       /* The red color */
    CLX_COLOR_LAST
} clx_color_t;
typedef enum clx_fwd_action_e {
    CLX_FWD_ACTION_FLOOD = 0, /* CL8600 not support. */
    CLX_FWD_ACTION_NORMAL,
    CLX_FWD_ACTION_DROP,
    CLX_FWD_ACTION_COPY_TO_CPU,
    CLX_FWD_ACTION_REDIRECT_TO_CPU,
    CLX_FWD_ACTION_FLOOD_COPY_TO_CPU, /* CL8600 not support. */
    CLX_FWD_ACTION_DROP_COPY_TO_CPU,  /* CL8600 not support. */
    CLX_FWD_ACTION_LAST
} clx_fwd_action_t;

typedef clx_huge_t clx_thread_id_t;
typedef clx_huge_t clx_semaphore_id_t;
typedef clx_huge_t clx_isrlock_id_t;
typedef clx_huge_t clx_irq_flags_t;
typedef clx_huge_t clx_lock_id_t;

typedef enum clx_lock_e { CLX_LOCK_NORMAL = 0, CLX_LOCK_RECURSIVE, CLX_LOCK_LAST } clx_lock_t;

typedef enum clx_dir_e {
    CLX_DIR_INGRESS = 0,
    CLX_DIR_EGRESS,
    CLX_DIR_BOTH,
    CLX_DIR_LAST
} clx_dir_t;

typedef enum clx_vlan_action_e {
    CLX_VLAN_ACTION_DEFAULT = 0, /* In LT it means CLX_VLAN_ACTION_SET.
                                  * In NB it means CLX_VLAN_ACTION_NOT_SUPPORT.
                                  */
    CLX_VLAN_ACTION_SET,
    CLX_VLAN_ACTION_KEEP,
    CLX_VLAN_ACTION_REMOVE,
    CLX_VLAN_ACTION_LAST
} clx_vlan_action_t;

/* VLAN Precedence */
/* 000 = SUBNET_PROTOCOL_MAC_PORT
 * 001 = SUBNET_MAC_PROTOCOL_PORT
 * 010 = PROTOCOL_SUBNET_MAC_PORT
 * 011 = PROTOCOL_MAC_SUBNET_PORT
 * 100 = MAC_SUBNET_PROTOCOL_PORT
 * 101 = MAC_PROTOCOL_SUBNET_PORT
 */
typedef enum clx_vlan_precedence_e {
    CLX_VLAN_PRECEDENCE_UNUSED = 0,
    CLX_VLAN_PRECEDENCE_FAVOR_TYPE = 8,
    CLX_VLAN_PRECEDENCE_FAVOR_ADDR = 9,
    CLX_VLAN_PRECEDENCE_LAST
} clx_vlan_precedence_t;

/* VLAN Tag Type */
typedef enum clx_vlan_tag_e {
    CLX_VLAN_TAG_NONE = 0,   /* UnTag                                */
    CLX_VLAN_TAG_SINGLE_PRI, /* Single Customer/Service Priority Tag */
    CLX_VLAN_TAG_SINGLE,     /* Single Customer/Service Tag          */
    CLX_VLAN_TAG_DOUBLE_PRI, /* Double Tag with any VID=0            */
    CLX_VLAN_TAG_DOUBLE,     /* Double Tag                           */
    CLX_VLAN_TAG_LAST
} clx_vlan_tag_t;

typedef struct clx_bum_info_s {
    uint32 mcast_id;
    uint32 group_label; /* l2 da group label */
    uint32 vid;         /* used when FLAGS_ADD_VID is set */
    uint32 flags;       /* refer to CLX_BUM_INFO_FLAGS_XXX */
} clx_bum_info_t;
#define CLX_BUM_INFO_FLAGS_MCAST_VALID (1U << 0)
#define CLX_BUM_INFO_FLAGS_TO_CPU      (1U << 1)
#define CLX_BUM_INFO_FLAGS_ADD_VID     (1U << 2) /* single tag to double tag (i.e) QinQ */

typedef struct clx_bum_s {
    uint32 bc_mcast_id;
    uint32 umc_mcast_id;
    uint32 uuc_mcast_id;
    uint32 flags;
} clx_bum_t;
#define CLX_BUM_FLAGS_BC_MCAST_VLD  (1U << 0)
#define CLX_BUM_FLAGS_UMC_MCAST_VLD (1U << 1)
#define CLX_BUM_FLAGS_UUC_MCAST_VLD (1U << 2)

typedef enum clx_phy_type_e {
    CLX_PHY_TYPE_INTERNAL = 0x0,
    CLX_PHY_TYPE_EXTERNAL,
    CLX_PHY_TYPE_LAST
} clx_phy_type_t;

typedef enum clx_phy_device_addr_e {
    CLX_PHY_DEVICE_ADDR_PMA_PMD = 1,
    CLX_PHY_DEVICE_ADDR_WIS = 2,
    CLX_PHY_DEVICE_ADDR_PCS = 3,
    CLX_PHY_DEVICE_ADDR_PHY_XS = 4,
    CLX_PHY_DEVICE_ADDR_DTE_XS = 5,
    CLX_PHY_DEVICE_ADDR_TC = 6,
    CLX_PHY_DEVICE_ADDR_AN = 7,
    CLX_PHY_DEVICE_ADDR_VENDOR_1 = 30,
    CLX_PHY_DEVICE_ADDR_VENDOR_2 = 31,
    CLX_PHY_DEVICE_ADDR_LAST
} clx_phy_device_addr_t;

typedef enum clx_bulk_op_mode_e {
    CLX_BULK_OP_MODE_ERR_STOP = 0,
    CLX_BULK_OP_MODE_ERR_CONTINUE,
    CLX_BULK_OP_MODE_LAST
} clx_bulk_op_mode_t;

typedef struct clx_range_info_s {
    uint32 min_id;
    uint32 max_id;
    uint32 max_member_cnt;
    uint32 flags; /* refer to CLX_RANGE_INFO_FLAGS_XXX */
} clx_range_info_t;
#define CLX_RANGE_INFO_FLAGS_MAX_MEMBER_CNT (1U << 0)

typedef struct clx_fdl_info_s {
    uint32 probability /* percentage from 0~100 */;
    uint32 threshold; /* range 0 ~ (2^20)-1 */
} clx_fdl_info_t;

typedef enum clx_evpn_type_e {
    CLX_EVPN_TYPE_NONE = 0,
    CLX_EVPN_TYPE_NVO3,
    CLX_EVPN_TYPE_MPLS,
    CLX_EVPN_TYPE_SRV6,
    CLX_EVPN_TYPE_LAST,
} clx_evpn_type_t;

typedef struct clx_src_prune_s {
    boolean uc_src_prune;
    boolean mc_src_prune;
} clx_src_prune_t;

typedef enum clx_sa_move_rsn_e {
    CLX_SA_MOVE_RSN_NONE = 0, /* No SA MAC move exception */
    CLX_SA_MOVE_RSN_0,        /* SA MAC move exception 0 */
    CLX_SA_MOVE_RSN_LAST
} clx_sa_move_rsn_t;

typedef struct clx_sample_s {
    uint32 rate;              // sample rate
    uint32 to_mir_session_id; // sample pacekt to mirror session id
    uint32 flags;             // CLX_SAMPLE_FLAGS_XXX
} clx_sample_t;
#define CLX_SAMPLE_FLAGS_SAMPLE_TO_MIR           (1 << 0)
#define CLX_SAMPLE_FLAGS_EGR_SAMPLE_HIGH_LATENCY (1 << 1) // only support egress sample

typedef struct clx_qos_prof_s {
    uint32 pcp_dei_prof_id;
    uint32 dscp_prof_id;
    uint32 exp_prof_id;
    uint32 flags; // CLX_QOS_PROF_FLAGS_*
} clx_qos_prof_t;
#define CLX_QOS_PROF_FLAGS_PCP_DEI_VALID (1 << 0)
#define CLX_QOS_PROF_FLAGS_DSCP_VALID    (1 << 1)
#define CLX_QOS_PROF_FLAGS_EXP_VALID     (1 << 2)

typedef enum clx_sa_miss_rsn_e {
    CLX_SA_MISS_RSN_0, /* SA MAC miss exception 0 */
    CLX_SA_MISS_RSN_1, /* SA MAC miss exception 1 */
    CLX_SA_MISS_RSN_LAST
} clx_sa_miss_rsn_t;

typedef struct clx_vlan_tpid_s {
    uint16 s_tpid;
    uint16 c_tpid;
} clx_vlan_tpid_t;
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

#endif /* CLX_TYPES_H */
