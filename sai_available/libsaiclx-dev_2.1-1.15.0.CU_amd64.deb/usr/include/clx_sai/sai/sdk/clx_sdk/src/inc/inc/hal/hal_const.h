/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_const.h
 * PURPOSE:
 *  It provides constant definition for use.
 *
 * NOTES:
 */

#ifndef HAL_CONST_H
#define HAL_CONST_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <tob/tob.h>
#include <hal/hal_swc.h>
#include <hal/hal_stat.h>
/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_VLAN_ENTRY_NUM (4096)
#define HAL_QOS_DOT1P_NUM  (16) /* 3 bit PCP and 1bit DEI in VLAN tag */
#define HAL_QOS_PCP_NUM    (8)  /* 3 bit PCP in VLAN tag */
#define HAL_QOS_DEI_NUM    (2)  /* 1 bit DEI in VLAN tag */
#define HAL_QOS_DSCP_NUM   (64) /* 6 bit DSCP in IP header */
#define HAL_QOS_EXP_NUM    (8)  /* 3 bit EXP in MPLS Lable */
#define HAL_QOS_COLOR_NUM  (3)  /* 3 bit colors(Green/Yellow/Red) */

/* MACRO FUNCTION DECLARATIONS
 */
#define PTR_HAL_CONST_INFO(__unit__, __module__) \
    (_ext_chip_control_block[(__unit__)].ptr_driver_info->ptr_const_info->ptr_##__module__##_const)

/* DATA TYPE DECLARATIONS
 */

typedef struct hal_const_bd_info_s {
    uint32 bdid_min;
    uint32 bdid_max;
} hal_const_bd_info_t;

typedef struct hal_const_vlan_info_s {
    uint32 vid_ctl_add;
} hal_const_vlan_info_t;

typedef struct hal_const_pkt_info_s {
    uint32 ipp_excpt_num;
    uint32 ipp_l3_excpt_num;
    uint32 ipp_copy2cpu_num;
    uint32 ipp_rsn_num;
    uint32 epp_excpt_num;
    uint32 epp_copy2cpu_num;
    uint32 pcie_que_num;
    uint32 cpi_que_num;
} hal_const_pkt_info_t;

typedef struct hal_const_swc_info_s {
    uint32 tcam_bank_num;
    uint32 tcam_bank_entry;
    uint32 master_die_id;
    uint32 fpu_stage_num;
    uint32 fpu_tile_num_per_stage;
    uint32 fpu_tile_num_per_slice;
    uint32 fpu_tile_num;
    uint32 fpu_tcam_num_per_slice;
    uint32 fpu_tcam_num;
    uint32 fpu_tcam_entry_num;
} hal_const_swc_info_t;

typedef struct hal_const_stat_info_s {
    uint32 pp[HAL_STAT_CAP_PP_LAST];
    uint32 mac[HAL_STAT_CAP_MAC_LAST];
    uint32 tm[HAL_STAT_CAP_TM_LAST];
} hal_const_stat_info_t;

typedef struct hal_const_cia_info_s {
    uint32 udf_int_key_vld_bmp_exact;
    uint32 udf_int_key_vld_bmp_igr;
    uint32 udf_int_key_vld_bmp_egr;
    uint32 udf_0_pkg_tlv_base_id;
    uint32 act_flags_igr;
    uint32 act_flags_egr;
    uint32 igr_cia_grp_lbl_full_lsb_vld_bits;
    uint32 igr_cia_grp_lbl_share_lsb_vld_bits;
    uint32 rewr_page_num;
    uint32 igr_ucp_num;
    uint32 egr_ucp_num;
    uint32 exact_ucp_num;
    uint32 igr_grp_num;
    uint32 egr_grp_num;
    uint32 exact_grp_num;
    uint32 ucp_entry_num;
    uint32 igr_entry_num;
    uint32 egr_entry_num;
    uint32 ucp_entry_bits;
    uint32 fpu_1_level_start;
    uint32 fpu_1_grp_offset;
    uint32 igr_post_grp_num;
    uint32 egr_post_grp_num;
    uint32 igr_post_entry_num;
    uint32 egr_post_entry_num;
    uint32 igr_post_ucp_num;
    uint32 egr_post_ucp_num;
} hal_const_cia_info_t;

typedef struct hal_const_lag_info_s {
    uint32 lag_hw_grp_tbl;
    uint32 lag_hw_grp_ori_base_field;
    uint32 lag_hw_grp_ori_size_field;
    uint32 lag_hw_grp_act_base_field;
    uint32 lag_hw_grp_act_size_field;
    uint32 lag_igr_phy_port_tbl;
    uint32 lag_igr_phy_port_src_idx_field;
    uint32 lag_hw_ori_port_di_tbl;
    uint32 lag_hw_ori_port_di_field;
    uint32 lag_hw_ori_port_state_tbl;
    uint32 lag_hw_ori_port_state_field;
    uint32 lag_hw_act_port_di_tbl;
    uint32 lag_hw_act_port_di_field;
    uint32 lag_hw_act_port_state_tbl;
    uint32 lag_hw_act_port_state_field;
    uint32 lag_port_num;
    uint32 lag_port_max_per_grp;
    uint32 lag_base_id;
    uint32 lag_port_min;
    uint32 lag_port_max;
    uint32 lag_grp_id_min;
    uint32 lag_grp_id_max;
} hal_const_lag_info_t;

typedef struct hal_const_sflow_info_s {
    uint32 profile_entry_num;
} hal_const_sflow_info_t;

typedef struct hal_const_tm_info_s {
    uint32 cpu_queue_num;
    uint32 port_pfc_max_num; // Max num of pfc priority support on port
    uint32 cell_size;
    uint32 legacy_queue_max_num;
    uint32 unicast_queue_max_num;
    uint32 multicast_queue_max_num;
    uint32 burst_size_max_num_bps;
    uint32 burst_size_max_num_pps;
} hal_const_tm_info_t;
typedef struct hal_const_qos_info_s {
    uint32 tc_max_num;
    uint32 phb_profile_max_num;
} hal_const_qos_info_t;
typedef struct hal_const_tnl_info_s {
    uint32 ip_tnl_gre_no_key;
    uint32 ip_tnl_gre_w_key;
    uint32 ip_tnl_raw;
    uint32 ip_tnl_isatap;
    uint32 ip_tnl_6to4;
    uint32 ip_tnl_vxlan_bas;
    uint32 ip_tnl_vxlan_gpe;
    uint32 ip_tnl_geneve;
    uint32 ip_tnl_int_rep;
    uint32 ip_tnl_srv6_encap;
    uint32 ip_tnl_srv6_insert;
    uint32 ip_tnl_flex0;
    uint32 ip_tnl_flex1;
    uint32 ip_tnl_flex2;
    uint32 ip_tnl_flex3;
    uint32 tunnel_di_base;
    uint32 nvo3adj_num;
    uint32 invalid_nvo3_encap_idx;
    uint32 invalid_nvo3_adj_idx;
} hal_const_tnl_info_t;

typedef struct hal_const_port_info_s {
    uint32 drop_di_base;
    uint32 drop_di_num;
    uint32 cpu_di_base;
    uint32 l2_mtu_min;
    uint32 l2_mtu_max;
    uint32 hal_port_num;
    uint32 hal_plane_num;
    uint32 hal_plane_bits;
    uint32 hal_plane_mask;
    uint32 hal_plane_eth_port_max;
    uint32 hal_plane_eth_dp_port_max;
} hal_const_port_info_t;

typedef struct hal_const_meter_info_s {
    uint32 p_bank_capacity;   /* plane meter bank capacity, unit: double bucket */
    uint32 p_rate_max;        /* max plane global meter rate, unit: kbps */
    uint32 p_bucket_max;      /* max global meter bucket size, unit: bytes */

    uint32 g_bank_capacity;   /* global meter bank capacity, unit: double bucket */
    uint32 g_rate_max;        /* max global meter rate, unit: kbps */
    uint32 g_bucket_max;      /* max global meter bucket size, unit: bytes */

    uint32 rsv_bank_capacity; /* reserved meter bank capacity, unit: double bucket */

    uint32 rate_gra;          /* meter rate granularity, unit: kbps */
    uint32 bucket_gra;        /* meter bucket granularity, unit: byte */
    uint32 igr_grp_num;       /* ucp group number for ingress cia */
    uint32 egr_grp_num;       /* ucp group number for egress cia */
} hal_const_meter_info_t;

typedef struct hal_const_sec_info_s {
    uint32 max_icmpv4_size;    /* maximum icmpv4 size */
    uint32 max_icmpv6_size;    /* maximum icmpv6 size */
    uint32 max_l4_prot;        /* maximum l4 protocol */
    uint32 min_udp_size;       /* minimum udp size */
    uint32 min_udp_frg_off;    /* minimum udp fragment offset */
    uint32 min_tcp_size;       /* minimum tcp size */
    uint32 min_tcp_frg_off;    /* minimum tcp fragment offset */
    uint32 min_sctp_size;      /* minimum sctp size */
    uint32 min_sctp_frg_off;   /* minimum sctp fragment offset */
    uint32 min_ipv6_frag_size; /* minimum ipv6 fragment size */
    uint32 max_sc_meter_rate;  /* maximum storm control meter rate, unit: kbps */
    uint32 max_sc_burst_size;  /* maximum storm control meter burst size, unit: bytes */
    uint32 max_isolation_grp;  /* maximum isolation group number */
} hal_const_sec_info_t;

typedef struct hal_const_l2_info_s {
    uint32 mgid_base_id;
    uint32 mgid_drop_offset;
    uint32 mgid_stk_cpu_bcast_offset;
    uint32 mgid_stk_cpu_neighbor_offset;
    uint32 mgid_dflt_vlan_offset;
    uint32 mgid_dflt_vlan_rsv1_offset;
    uint32 mgid_dflt_vlan_rsv2_offset;
} hal_const_l2_info_t;

typedef struct hal_const_info_s {
    /* bd */
    hal_const_bd_info_t *const ptr_bd_const;
    /* vlan */
    hal_const_vlan_info_t *const ptr_vlan_const;
    /* pkt */
    hal_const_pkt_info_t *const ptr_pkt_const;
    /* swc */
    hal_const_swc_info_t *ptr_swc_const;
    /* stat */
    hal_const_stat_info_t *const ptr_stat_const;
    /* acl */
    hal_const_cia_info_t *ptr_cia_const;
    /* lag */
    hal_const_lag_info_t *const ptr_lag_const;
    /* sflow */
    hal_const_sflow_info_t *const ptr_sflow_const;
    /* tnl */
    hal_const_tnl_info_t *const ptr_tnl_const;
    /* port */
    hal_const_port_info_t *const ptr_port_const;
    /* meter */
    hal_const_meter_info_t *const ptr_meter_const;
    /* security */
    hal_const_sec_info_t *const ptr_sec_const;
    /* l2 */
    hal_const_l2_info_t *const ptr_l2_const;
    /* tm */
    hal_const_tm_info_t *const ptr_tm_const;
    /* qos */
    hal_const_qos_info_t *const ptr_qos_const;
} hal_const_info_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif /* #ifndef HAL_CONST_H */
