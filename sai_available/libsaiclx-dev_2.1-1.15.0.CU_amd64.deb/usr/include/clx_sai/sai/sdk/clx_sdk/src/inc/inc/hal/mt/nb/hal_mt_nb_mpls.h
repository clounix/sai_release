/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_mpls.h
 * PURPOSE:
 *  Provides MPLS HAL API for CL8570.
 *
 * NOTES:
 *
 */

#ifndef hal_mt_nb_mpls_H
#define hal_mt_nb_mpls_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <hal/mt/nb/hal_mt_nb_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

clx_error_no_t
hal_mt_nb_mpls_initcfg(const uint32 unit);

clx_error_no_t
hal_mt_nb_mpls_initwarm(const uint32 unit);

clx_error_no_t
hal_mt_nb_mpls_deinitwarm(const uint32 unit);

clx_error_no_t
hal_mt_nb_mpls_deinitcfg(const uint32 unit);

/**
 * @brief Create a vpn id.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     vpn_info    - Bdid1, bdid2, mpls type.
 * @param [out]    vpn_id      - Create vpn id.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_vpn_id_create(const uint32 unit,
                             const clx_mpls_vpn_info_t *vpn_info,
                             uint32 *vpn_id);

/**
 * @brief Destroy a vpn id.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    vpn_id    - Vpn id.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_vpn_id_destroy(const uint32 unit, const uint32 vpn_id);

/**
 * @brief Destroy a vpn id or vpn info.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Get type.
 * @param [out]    vpn_info    - Get VPN ID or Key info.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_vpn_id_get(const uint32 unit,
                          const clx_mpls_get_type_t type,
                          clx_mpls_vpn_info_t *vpn_info);

/**
 * @brief Create the MPLS LSP port.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_lsp_port    - MPLS tunnel encapsulation label and flag info.
 * @param [out]    ptr_lsp_port    - The lsp port to be obtained.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_lsp_port_create(const uint32 unit, clx_mpls_lsp_info_t *ptr_lsp_port);

/**
 * @brief Destroy a MPLS tunnel port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - MPLS tunnel port.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_lsp_port_destroy(const uint32 unit, const clx_port_t port);

/**
 * @brief Get MPLS LSP port.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - Get port or get key.
 * @param [out]    ptr_lsp_port    - The lsp info to be obtained.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_lsp_port_get(const uint32 unit,
                            const clx_mpls_get_type_t type,
                            clx_mpls_lsp_info_t *ptr_lsp_port);

/**
 * @brief Add a MPLS LSP encapsulation, bind LSP tunnel to nvo3.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_encap    - Pointer of LSP tunnel initiation.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_encap_add(const uint32 unit, const clx_mpls_encap_info_t *ptr_encap);

/**
 * @brief Delete a MPLS LSP tunnel initiation.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    lsp_port    - MPLS LSP port.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_encap_del(const uint32 unit, const clx_port_t lsp_port);

/**
 * @brief Get a MPLS LSP initiator information.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_encap    - MPLS tunnel port.
 * @param [out]    ptr_encap    - The encap info to be obtained.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_encap_get(const uint32 unit, clx_mpls_encap_info_t *ptr_encap);

/**
 * @brief Add a MPLS LSP tunnel termination.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_term    - Pointer of LSP tunnel termination.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_decap_add(const uint32 unit, const clx_mpls_decap_info_t *ptr_term);

/**
 * @brief Get a MPLS LSP tunnel termination.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_term    - Pointer of LSP tunnel termination.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_decap_get(const uint32 unit, clx_mpls_decap_info_t *ptr_term);

/**
 * @brief Delete a MPLS LSP tunnel termination.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_key    - Pointer of LSP tunnel termination match key.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_decap_del(const uint32 unit, const clx_mpls_match_info_t *ptr_key);

/**
 * @brief Add a MPLS transit for LSR.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_nh_info    - Pointer of LSP transit next hop information.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_transit_add(const uint32 unit, const clx_mpls_switch_info_t *ptr_nh_info);

/**
 * @brief Get a MPLS transit LSP.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_nh_info    - Pointer of LSP transit next hop information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_transit_get(const uint32 unit, clx_mpls_switch_info_t *ptr_nh_info);

/**
 * @brief Delete a MPLS LSR transit.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_key    - Pointer of LSP transit match key.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_transit_del(const uint32 unit, const clx_mpls_match_info_t *ptr_key);

/**
 * @brief Get MPLS label value range.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    lbl_range    - P2p/p2mp min/max label range.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_lbl_range_get(const uint32 unit, clx_mpls_lbl_range_t *lbl_range);

/**
 * @brief Set MPLS label value range.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    lbl_range    - P2p/p2mp min/max label range.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_lbl_range_set(const uint32 unit, const clx_mpls_lbl_range_t lbl_range);

/**
 * @brief Create a PW port.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_pw_port    - Use pw port obtain pw decapsulation and encapsulation info.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - Hardware table is full.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_pw_port_create(const uint32 unit, clx_mpls_pw_port_t *ptr_pw_port);

/**
 * @brief Get a PW port.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     type      - Get port or key.
 * @param [out]    ptr_pw    - The pw port or key info to be obtained.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_pw_port_get(const uint32 unit,
                           const clx_mpls_get_type_t type,
                           clx_mpls_pw_port_t *ptr_pw);

/**
 * @brief Destroy a PW port.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    pw_port    - Pw port.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_pw_port_destroy(const uint32 unit, const clx_port_t pw_port);

/**
 * @brief Add a MPLS PW.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    ptr_pw_info    - The pw info to be added.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_pw_add(const uint32 unit, const clx_mpls_pw_info_t *ptr_pw_info);

/**
 * @brief Delete a MPLS PW.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    pw_port    - Pw port.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_pw_del(const uint32 unit, const clx_port_t pw_port);

/**
 * @brief Get a MPLS PW.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_pw_info    - The pw_port must be input.
 * @param [out]    ptr_pw_info    - The pw info to be obtained.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_pw_get(const uint32 unit, clx_mpls_pw_info_t *ptr_pw_info);

/**
 * @brief Add a MPLS VPWS.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_vpws    - Add PW port and ac port to a VPWS.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_vpws_add(const uint32 unit, const clx_mpls_vpws_t *ptr_vpws);

/**
 * @brief Delete a MPLS VPWS.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    pw_port    - PW port.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_vpws_del(const uint32 unit, const clx_port_t pw_port);

/**
 * @brief Get a MPLS VPWS.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_vpws    - Pointer of PW AC information.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_vpws_get(const uint32 unit, clx_mpls_vpws_t *ptr_vpws);

/**
 * @brief Update vpws ac lag port.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    lag_id            - Lag port.
 * @param [in]    add_member_cnt    - Add port cnt. ptr_add_member_di -- add port member.
 *                                    del_member_cnt -- del port cnt ptr_del_member_di -- del port
 *                                    member.
 * @return        CLX_E_OK        - Operation is successful.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_vpws_lag_member_update(const uint32 unit,
                                      const uint32 lag_id,
                                      const uint32 add_member_cnt,
                                      const uint32 *ptr_add_member_di,
                                      const uint32 del_member_cnt,
                                      const uint32 *ptr_del_member_di);

/**
 * @brief Get all MPLS init entries.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_encap_trav(const uint32 unit, const clx_mpls_encap_trav_fun_t cb, void *ptr_cookie);

/**
 * @brief Get all MPLS transit entries.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_transit_trav(const uint32 unit,
                            const clx_mpls_transit_trav_func_t cb,
                            void *ptr_cookie);

/**
 * @brief Get all MPLS term entries.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_decap_trav(const uint32 unit, const clx_mpls_decap_trav_func_t cb, void *ptr_cookie);

/**
 * @brief Get all MPLS PW entries.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user, user can do self action to
 *                                 every node data in this callback function.
 * @param [in]     ptr_cookie    - User cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - User cookie data as input parameter of callback function.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_pw_trav(const uint32 unit, const clx_mpls_pw_trav_func_t cb, void *ptr_cookie);

/**
 * @brief Get MPLS path information.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - MPLS tunnel or PW port.
 * @param [out]    ptr_path    - Pointer of the path info of the port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_path_info_get(const uint32 unit, const clx_port_t port, hal_mpls_path_t *ptr_path);

/**
 * @brief Get MPLS tunnel or PW por by path information.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_path    - Pointer of the path info of the port. Shall specify the seg and th
 *                               di of the path.
 * @param [out]    ptr_port    - MPLS tunnel or PW port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return         CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_get_port_by_path_info(const uint32 unit,
                                     const hal_mpls_path_t *ptr_path,
                                     clx_port_t *ptr_port);

/**
 * @brief Translate L3 multicast egress interface to HW MEL info.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Egress physical port.
 * @param [in]     ptr_intf        - Pointer of egress interface.
 * @param [out]    ptr_mel_info    - Pointer of MEL info.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_mcast_transit_egr_intf_to_mel_info(const uint32 unit,
                                                  const uint32 port,
                                                  const hal_l3_mcast_egr_intf_t *ptr_intf,
                                                  hal_mt_nb_l3_mcast_mel_info_t *ptr_mel_info);

/**
 * @brief Update adjacency information.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    adj_id    - Nvo3 adjacency ID.
 * @param [in]    port      - Egress port.
 * @return        CLX_E_OK                 - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 * @return        CLX_E_OTHERS             - Operation fail.
 */
clx_error_no_t
hal_mt_nb_mpls_nvo3_adj_info_update(const uint32 unit, const uint32 adj_id, const clx_port_t port);

/**
 * @brief Check a path whether or not a MPLS path.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    di      - Egress destination ID.
 * @param [in]    seg     - Segment ID.
 * @return        TRUE/FALSE.
 */
boolean
hal_mt_nb_mpls_path_chk(const uint32 unit, const uint32 di, const uint32 seg);

#endif
