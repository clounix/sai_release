/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_vlan.h
 * PURPOSE:
 *      It provides vlan module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_VLAN_H
#define CLX_VLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

#define CLX_VLAN_EXT_TPID_NUM (8)

typedef enum clx_vlan_tag_mode_e {
    CLX_VLAN_TAG_MODE_TAG,   /* VLAN port member is tag mode. */
    CLX_VLAN_TAG_MODE_UNTAG, /* VLAN port member is untag mode. */
    CLX_VLAN_TAG_MODE_LAST
} clx_vlan_tag_mode_t;

/* VLAN type */
typedef enum clx_vlan_type_e {
    CLX_VLAN_TYPE_N, /* Normal VLAN, default */
    CLX_VLAN_TYPE_P, /* Primary VLAN. */
    CLX_VLAN_TYPE_I, /* Isolated VLAN. */
    CLX_VLAN_TYPE_C, /* Community VLAN. */
    CLX_VLAN_TYPE_LAST
} clx_vlan_type_t;

typedef struct clx_vlan_ext_tpid_s {
    uint16 tpid2; /* 0 is not valid */
    uint16 tpid3; /* 0 is not valid */
} clx_vlan_ext_tpid_t;

typedef clx_vlan_ext_tpid_t clx_vlan_ext_tpid_grp_t[CLX_VLAN_EXT_TPID_NUM];

typedef enum clx_vlan_ext_tpid_type_s {
    CLX_VLAN_EXT_TPID_TYPE_INNER, /* Inner. */
    CLX_VLAN_EXT_TPID_TYPE_OUTER, /* Outer. */
    CLX_VLAN_EXT_TPID_TYPE_LAST
} clx_vlan_ext_tpid_type_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Create a vlan.
 *
 * This function will create vlan entry and set fields of vlan entry include
 * portlist, untag portlist to default value.
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - 802.1Q VLAN id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_vlan_create(const uint32 unit, const clx_vlan_t vid);

/**
 * @brief Destroy a vlan.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - 802.1Q VLAN id.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No such entry.
 */
clx_error_no_t
clx_vlan_destroy(const uint32 unit, const clx_vlan_t vid);

/**
 * @brief Get the port members of VLAN.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     vid            - 802.1Q VLAN id.
 * @param [out]    port_bmp       - Port member.
 * @param [out]    ut_port_bmp    - Untag ports.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 * @return         CLX_E_NOT_INITED         - VLAN module not initialized.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_vlan_port_get(const uint32 unit,
                  const clx_vlan_t vid,
                  clx_port_bitmap_t port_bmp,
                  clx_port_bitmap_t ut_port_bmp);

/**
 * @brief Add VLAN port members, default tag mode is taged.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    vid            - 802.1Q VLAN id.
 * @param [in]    port_bmp       - Port member.
 * @param [in]    ut_port_bmp    - Untag ports.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 * @return        CLX_E_NOT_INITED         - VLAN module not initialized.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_vlan_port_add(const uint32 unit,
                  const clx_vlan_t vid,
                  const clx_port_bitmap_t port_bmp,
                  const clx_port_bitmap_t ut_port_bmp);

/**
 * @brief Delete VLAN port members.
 *
 * Port member includes untag port.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    vid         - 802.1Q VLAN id.
 * @param [in]    port_bmp    - Port member.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 * @return        CLX_E_NOT_INITED         - VLAN module not initialized.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_vlan_port_del(const uint32 unit, const clx_vlan_t vid, const clx_port_bitmap_t port_bmp);

/**
 * @brief Set VLAN port member tag/untag mode.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    vid         - 802.1Q VLAN id.
 * @param [in]    port_bmp    - VLAN port member bitmap.
 * @param [in]    mode        - Tag/untag Mode.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No such entry.
 * @return        CLX_E_NOT_INITED         - VLAN module not initialized.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_vlan_tag_mode_set(const uint32 unit,
                      const clx_vlan_t vid,
                      const clx_port_bitmap_t port_bmp,
                      const clx_vlan_tag_mode_t mode);

typedef clx_error_no_t (*CLX_VLAN_TRAV_FUNC_T)(const uint32 unit,
                                               const clx_vlan_t vid,
                                               const clx_port_bitmap_t port_bmp,
                                               const clx_port_bitmap_t ut_port_bmp,
                                               void *ptr_cookie);

/**
 * @brief Traverse vlan tagged/untagged member port for active vlan.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    callback      - The callback function to be called for each traversed vlan entry.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK             - Operation success.
 * @return        CLX_E_NOT_SUPPORT    - Not supported feature.
 */
clx_error_no_t
clx_vlan_trav(const uint32 unit, const CLX_VLAN_TRAV_FUNC_T callback, void *ptr_cookie);

/**
 * @brief This API is used to bind VLAN and bridge domain.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - 802.1Q VLAN id.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_vlan_bd_bind(const uint32 unit, const clx_vlan_t vid, const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to unbind VLAN and bridge domain.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - 802.1Q VLAN id.
 * @param [in]    bdid    - Bridge domain id.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_vlan_bd_unbind(const uint32 unit, const clx_vlan_t vid, const clx_bridge_domain_t bdid);

/**
 * @brief This API is used to get the bridge domain bound to VLAN.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     vid     - 802.1Q VLAN id.
 * @param [out]    bdid    - Bridge domain id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_vlan_bd_get(const uint32 unit, const clx_vlan_t vid, clx_bridge_domain_t *bdid);

/**
 * @brief Set VLAN type.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    vid     - 802.1Q VLAN id.
 * @param [in]    type    - Normal/private VLAN.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 */
clx_error_no_t
clx_vlan_type_set(const uint32 unit, const clx_vlan_t vid, const clx_vlan_type_t type);

/**
 * @brief Get VLAN type.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit    - Device unit number.
 * @param [in]     vid     - 802.1Q VLAN id.
 * @param [out]    type    - Normal/private VLAN.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - VLAN not created.
 */
clx_error_no_t
clx_vlan_type_get(const uint32 unit, const clx_vlan_t vid, clx_vlan_type_t *type);

/**
 * @brief Add private VLAN extension trunk port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    vid         - Primary/community/isolated VLAN id.
 * @param [in]    port_bmp    - Trunk port bitmap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - Private VLAN index is in use.
 */
clx_error_no_t
clx_vlan_private_tport_add(const uint32 unit,
                           const clx_vlan_t vid,
                           const clx_port_bitmap_t port_bmp);

/**
 * @brief Delete private VLAN extension trunk port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    vid         - Primary/community/isolated VLAN id.
 * @param [in]    port_bmp    - Trunk port bitmap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - Private VLAN index is in use.
 */
clx_error_no_t
clx_vlan_private_tport_del(const uint32 unit,
                           const clx_vlan_t vid,
                           const clx_port_bitmap_t port_bmp);

/**
 * @brief Get private VLAN extension trunk port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     vid         - Primary/community/isolated VLAN id.
 * @param [out]    port_bmp    - Trunk port bitmap.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Private VLAN index is in use.
 */
clx_error_no_t
clx_vlan_private_tport_get(const uint32 unit, const clx_vlan_t vid, clx_port_bitmap_t port_bmp);

/**
 * @brief This API is used to add extend TPID.
 *
 * Support adding multiple groups at once
 * both tpid2 and tpid3 being 0 indicate invalid configurations.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    type        - TPID type.
 * @param [in]    tpid_grp    - Extend TPID group.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_vlan_ext_tpid_add(const uint32 unit,
                      const clx_vlan_ext_tpid_type_t type,
                      const clx_vlan_ext_tpid_grp_t tpid_grp);

/**
 * @brief This API is used to del extend TPID.
 *
 * Support deleting multiple groups at once
 * Both tpid2 and tpid3 being 0 indicate invalid configurations.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    type        - TPID type.
 * @param [in]    tpid_grp    - Extend TPID group.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_vlan_ext_tpid_del(const uint32 unit,
                      const clx_vlan_ext_tpid_type_t type,
                      const clx_vlan_ext_tpid_grp_t tpid_grp);

/**
 * @brief This API is used to get extend TPID.
 *
 * Both tpid2 and tpid3 being 0 indicate invalid configurations.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - TPID type.
 * @param [out]    tpid_grp    - Extend TPID group.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_vlan_ext_tpid_get(const uint32 unit,
                      const clx_vlan_ext_tpid_type_t type,
                      clx_vlan_ext_tpid_grp_t tpid_grp);

#endif /* End of CLX_VLAN_H */
