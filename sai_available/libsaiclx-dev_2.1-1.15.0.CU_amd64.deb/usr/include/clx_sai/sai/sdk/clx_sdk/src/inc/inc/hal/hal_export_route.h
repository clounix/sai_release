/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_export_route.h
 * PURPOSE:
 *      It provide export route module api.
 * NOTES:
 *
 */

#ifndef __HAL_EXPORT_ROUTE_H__
#define __HAL_EXPORT_ROUTE_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_l3.h>
#include <hal/hal_eparser.h>
/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_export_route_msg_type_e {
    HAL_EXPORT_ROUTE_MSG_INVALID = 0,
    HAL_EXPORT_ROUTE_MSG_START = 1,
    HAL_EXPORT_ROUTE_MSG_DONE = 2,
    HAL_EXPORT_ROUTE_MSG_ERROR = 3,
} hal_export_route_msg_type_t;

// AFIB IP format definition
typedef enum hal_export_route_afib_ip_format_e {
    AFIB_IP_FORMAT_1X = 1, // 1x format
    AFIB_IP_FORMAT_2X,     // 2x format
    AFIB_IP_FORMAT_4X      // 4x format
} hal_export_route_afib_ip_format_t;

/* Message header structure with fragment flags */
typedef struct hal_export_route_msg_header_s {
    hal_export_route_msg_type_t msg_type; /* Message type */
    uint8_t fragment_index;               /* Current fragment index, 0-based */
    uint8_t total_fragments;              /* Total number of fragments */
    uint16_t reserved;                    /* Reserved for future use */
} hal_export_route_msg_header_t;

/* After eparser header, without hal_export_route_msg_header_t. */
typedef struct hal_export_route_request_msg_s {
    hal_export_route_msg_type_t msg_type; /* Message type, should be HAL_EXPORT_ROUTE_MSG_START:1 */
    uint8_t isIncludeIpv4;                /* 0: not include, 1: include */
    uint8_t isIncludeIpv6;                /* 0: not include, 1: include */
    uint8_t isIncludeOutSeg;              /* 0: not include, 1: include */
    uint8_t reserved;                     /* Reserved for future use */
} hal_export_route_request_msg_t;

/* TLV TYPES */
#define TLV_TYPE_IPV4_COUNT     (0x01) /* IPv4 counter */
#define TLV_TYPE_IPV4_ENTRY_LEN (0x02) /* IPv4 per entry length */
#define TLV_TYPE_IPV4_ENTRIES   (0x03) /* IPv4 entries */
#define TLV_TYPE_IPV6_COUNT     (0x04) /* IPv6 counter */
#define TLV_TYPE_IPV6_ENTRY_LEN (0x05) /* IPv6 per entry length */
#define TLV_TYPE_IPV6_ENTRIES   (0x06) /* IPv6 entries */
#define TLV_TYPE_FWD_PTR_COUNT  (0x07) /* Forward pointer counter */
#define TLV_TYPE_FWD_PTR_ENTRY  (0x08) /* Forward pointer entry */

typedef struct hal_export_ipv4_route_s {
    uint32_t ip_addr;   /* IPv4 address */
    uint16_t vrf;       /* VRF identifier */
    uint8_t prefix_len; /* Prefix length */
    uint8_t flags;      /* flags */
    uint32_t fwd_ptr;   /* Forwarding pointer */
} hal_export_ipv4_route_t;

typedef struct hal_export_ipv6_route_s {
    uint8_t ipv6_addr[16]; /* IPv6 address */
    uint16_t vrf;          /* VRF identifier */
    uint8_t prefix_len;    /* Prefix length */
    uint8_t flags;         /* flags */
    uint32_t fwd_ptr;      /* Forwarding pointer */
} hal_export_ipv6_route_t;

typedef struct hal_export_l3_outseg_s {
    uint32_t outseg_port_id; /* Output segment interface ID */

} hal_export_l3_outseg_t;

typedef struct hal_export_l3_fwd_ptr_s {
    uint32_t fwd_ptr;                     /* Forwarding pointer */
    uint8_t outseg_num;                   /* Number of output segments */
    uint8_t reserved[3];                  /* Reserved */
    hal_export_l3_outseg_t outsegment[0]; /* Output segment info */
} hal_export_l3_fwd_ptr_t;
/**
 * @brief Initialize the export route module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK    - Operation successful.
 */
clx_error_no_t
hal_export_route_init(uint32 unit);

/**
 * @brief Deinitialize the export route module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_export_route_deinit(uint32 unit);

/**
 * @brief Start route export operation.
 *
 * This function initiates a route export operation for the specified unit.
 * It creates multiple threads to parse and export route data.
 *
 * @param [in]    unit        - Chip unit number.
 * @param [in]    msg_type    - Message type.
 * @param [in]    msg         - Message pointer from eparser, can be NULL.
 * @param [in]    length      - Length of the message.
 * @return        CLX_E_OK            - Operation successful.
 * @return        CLX_E_NOT_INITED    - Module not initialized.
 * @return        CLX_E_NO_MEMORY     - Memory allocation failed.
 * @return        CLX_E_OTHERS        - Operation failed.
 */
clx_error_no_t
hal_export_route_handle_start(uint32 unit, eparse_msg_type_t msg_type, void *msg, uint32_t length);
#endif /* __HAL_EXPORT_ROUTE_H__ */