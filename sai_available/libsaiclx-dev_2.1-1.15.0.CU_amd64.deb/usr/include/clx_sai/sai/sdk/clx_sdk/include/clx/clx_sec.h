/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_sec.h
 * PURPOSE:
 *      Define the declaration for Security module in CLX SDK.
 *
 * NOTES:
 *
 */

#ifndef CLX_SEC_H
#define CLX_SEC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>

/* STORM CONTROL */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* Dos check item */
typedef enum clx_sec_dos_chk_e {
    CLX_SEC_DOS_CHK_MAC_ALL_ZEROS,         /* smac or dmac is all zeros */
    CLX_SEC_DOS_CHK_SMAC_INVALID,          /* smac invalid */
    CLX_SEC_DOS_CHK_DMAC_EQ_SMAC,          /* smac eq dmac */
    CLX_SEC_DOS_CHK_LEN_ENCAP_ERR,         /* L2 length encap error */
    CLX_SEC_DOS_CHK_IPV4_LOOPBACK_ADDR,    /* ipv4 loopback address */
    CLX_SEC_DOS_CHK_IPV4_CLASS_E_ADDR,     /* ipv4 class E address */
    CLX_SEC_DOS_CHK_IPV4_MARTIAN_ADDR,     /* ipv4 martian address */
    CLX_SEC_DOS_CHK_IPV6_MARTIAN_ADDR,     /* ipv6 martian address */
    CLX_SEC_DOS_CHK_IPV6_ICMP_SIZE_EN,     /* ipv6 icmp size enable */
    CLX_SEC_DOS_CHK_IPV4_ICMP_SIZE_EN,     /* ipv4 icmp size enable*/
    CLX_SEC_DOS_CHK_IPV4_FRAG_ICMP,        /* ipv4 icmp fragment */
    CLX_SEC_DOS_CHK_IPV6_FRAG_ICMP,        /* ipv6 icmp fragment */
    CLX_SEC_DOS_CHK_TCP_SYN_FIN_SCAN,      /* tcp syn fin scan */
    CLX_SEC_DOS_CHK_TCP_NULL_SCAN,         /* tcp null scan */
    CLX_SEC_DOS_CHK_TCP_FIN_SCAN,          /* tcp fin scan */
    CLX_SEC_DOS_CHK_TCP_XMAS_SCAN,         /* tcp xmas scan */
    CLX_SEC_DOS_CHK_DPORT_EQ_SPORT,        /* l4 dport eq sport */
    CLX_SEC_DOS_CHK_DIP_EQ_SIP,            /* dip eq sip */
    CLX_SEC_DOS_CHK_UDP_FRAGGLE,           /* udp raggle */
    CLX_SEC_DOS_CHK_UDP_SNORK,             /* udp snork */
    CLX_SEC_DOS_CHK_UDP_BOMB,              /* udp bomb */
    CLX_SEC_DOS_CHK_IPV4_PROTO_MAX_ERR,    /* ipv4 protocol max error */
    CLX_SEC_DOS_CHK_IPV6_FRAG_SIZE_EN,     /* ipv6 fragment size enable */
    CLX_SEC_DOS_CHK_IPV6_ROUTING_TYPE_0,   /* ipv6 routing type 0 */
    CLX_SEC_DOS_CHK_IPV4_FRAG_ERR,         /* ipv4 fragment error */
    CLX_SEC_DOS_CHK_IPV6_FRAG_OFFSET_ERR,  /* ipv6 fragment offset error */
    CLX_SEC_DOS_CHK_IPV4_FRAG_OFFSET_ERR,  /* ipv4 fragment offset error */
    CLX_SEC_DOS_CHK_IPV6_MIN_LEN_ERR,      /* ipv6 min length error */
    CLX_SEC_DOS_CHK_IPV4_MIN_LEN_ERR,      /* ipv4 min length error */
    CLX_SEC_DOS_CHK_IPV4_HDR_LEN_ERR,      /* ipv4 header length error */
    CLX_SEC_DOS_CHK_IPV6_NEXT_HDR_MAX_ERR, /* ipv6 next header max error */
    CLX_SEC_DOS_CHK_TCP_TINY_FRAG_EN,      /* tcp tiny fragment enable */
    CLX_SEC_DOS_CHK_TCP_HDR_SIZE_EN,       /* tcp header size enable */
    CLX_SEC_DOS_CHK_IPV4_UDP_TINY_FRG,     /* ipv4 udp tiny fragment */
    CLX_SEC_DOS_CHK_IPV6_UDP_TINY_FRG,     /* ipv6 udp tiny fragment */
    CLX_SEC_DOS_CHK_IPV4_UDP_MIN_SIZE,     /* ipv4 udp min size */
    CLX_SEC_DOS_CHK_IPV6_UDP_MIN_SIZE,     /* ipv6 udp min size */
    CLX_SEC_DOS_CHK_IPV4_SCTP_TINY_FRG,    /* ipv4 sctp tiny fragment */
    CLX_SEC_DOS_CHK_IPV6_SCTP_TINY_FRG,    /* ipv6 sctp tiny fragment */
    CLX_SEC_DOS_CHK_IPV4_SCTP_MIN_SIZE,    /* ipv4 sctp min size */
    CLX_SEC_DOS_CHK_IPV6_SCTP_MIN_SIZE,    /* ipv6 sctp min size */
    CLX_SEC_DOS_CHK_LAND_ATTACK_TCP,       /* land attack tcp */
    CLX_SEC_DOS_CHK_LAND_ATTACK_UDP,       /* land attack udp */
    CLX_SEC_DOS_CHK_ICMPV4_TYPE_CHK,       /* icmpv4 unknown type chk */
    CLX_SEC_DOS_CHK_ICMPV6_TYPE_CHK,       /* icmpv6 unknown type chk */
    CLX_SEC_DOS_CHK_LAST
} clx_sec_dos_chk_t;

/* DoS check item number */
#define CLX_SEC_DOS_CHK_NUM (CLX_SEC_DOS_CHK_LAST)
/* Security word width */
#define CLX_SEC_WORD_WIDTH (32)
/* DoS check item bitmap size */
#define CLX_SEC_DOS_CHK_BMP_SIZE (((CLX_SEC_DOS_CHK_NUM - 1) / CLX_SEC_WORD_WIDTH) + 1)

/* DoS check item bitmap */
typedef uint32 clx_sec_dos_chk_bmp_t[CLX_SEC_DOS_CHK_BMP_SIZE];

/* DoS check bit set */
#define CLX_SEC_DOS_BMP_SET(bitmap, dos_chk)                 \
    (((uint32 *)(bitmap))[(dos_chk) / CLX_SEC_WORD_WIDTH] |= \
     (0x1U << ((dos_chk) % CLX_SEC_WORD_WIDTH)))
/* DoS check bit clear */
#define CLX_SEC_DOS_BMP_CLEAR(bitmap, dos_chk)               \
    (((uint32 *)(bitmap))[(dos_chk) / CLX_SEC_WORD_WIDTH] &= \
     ~(0x1U << ((dos_chk) % CLX_SEC_WORD_WIDTH)))
/* DoS check bit check */
#define CLX_SEC_DOS_BMP_CHK(bitmap, dos_chk)                \
    (((uint32 *)(bitmap))[(dos_chk) / CLX_SEC_WORD_WIDTH] & \
     (0x1U << ((dos_chk) % CLX_SEC_WORD_WIDTH)))

/* DoS check Port config */
typedef struct clx_sec_dos_port_cfg_s {
    clx_sec_dos_chk_bmp_t dos_chk; /* DoS check bitmap */
} clx_sec_dos_port_cfg_t;

/* DoS check status */
typedef struct clx_sec_dos_status_s {
    clx_sec_dos_chk_bmp_t status; /* DoS status bitmap */
} clx_sec_dos_status_t;

/* Dos Check Count */
typedef struct clx_sec_dos_cnt_s {
    uint64 total_pkt_cnt; /* total packet count */
} clx_sec_dos_cnt_t;

/* DoS check global config */
typedef struct clx_sec_dos_cfg_s {
    uint16 max_l4_proto;         /* max L4 protocol */
    uint16 min_ipv6_frag_size;   /* min ipv6 fragment size */
    uint16 max_icmpv4_size;      /* max icmpv4 size */
    uint16 max_icmpv6_size;      /* max icmpv6 size */
    uint16 min_tcp_size;         /* min tcp size */
    uint16 min_tcp_frag_offset;  /* min tcp fragment offset */
    uint16 min_udp_size;         /* min udp size */
    uint16 min_udp_frag_offset;  /* min udp fragment offset */
    uint16 min_sctp_size;        /* min sctp size */
    uint16 min_sctp_frag_offset; /* min sctp fragment offset */
} clx_sec_dos_cfg_t;

/* Storm control count */
typedef struct clx_sec_storm_ctrl_cnt_s {
    uint64 fwd_byte_cnt; /* byte count */
    uint64 fwd_pkt_cnt;  /* packet count*/
    uint64 drop_pkt_cnt; /* packet count*/
} clx_sec_storm_ctrl_cnt_t;

/* Storm control stats */
typedef struct clx_sec_storm_ctrl_stats_s {
    clx_sec_storm_ctrl_cnt_t uuc; /* uuc count */
    clx_sec_storm_ctrl_cnt_t umc; /* umc count */
    clx_sec_storm_ctrl_cnt_t bc;  /* bc count */
} clx_sec_storm_ctrl_stats_t;

/* Storm control */
typedef struct clx_sec_storm_ctrl_s {
    uint32 rate;       /* storm control rate */
    uint32 burst_size; /* burst size */
    uint32 flags;      /* storm control flags, refer to CLX_SEC_STORM_CTRL_FLAGS_XXX */
} clx_sec_storm_ctrl_t;

#define CLX_SEC_STORM_CTRL_FLAGS_PACKET_RATE (1U << 0) /* packet rate */
#define CLX_SEC_STORM_CTRL_FLAGS_EN          (1U << 1) /* storm control enable  */
#define CLX_SEC_STORM_CTRL_FLAGS_LAYER1      (1U << 2) /* storm control layer1 for bps mode */

/* storm control configuration */
typedef struct clx_sec_storm_ctrl_cfg_s {
    clx_sec_storm_ctrl_t uuc; /* storm control uuc */
    clx_sec_storm_ctrl_t umc; /* storm control umc */
    clx_sec_storm_ctrl_t bc;  /* storm control bc */
    uint64 attr_bmap; /*  Mark which fields to set, refer to  CLX_SEC_STORM_CTRL_CFG_ATTR_XXX */
} clx_sec_storm_ctrl_cfg_t;

#define CLX_SEC_STORM_CTRL_CFG_ATTR_UUC (1U << 0)     /* UUC */
#define CLX_SEC_STORM_CTRL_CFG_ATTR_UMC (1U << 1)     /* UMC */
#define CLX_SEC_STORM_CTRL_CFG_ATTR_BC  (1U << 2)     /* BC */
#define CLX_SEC_STORM_CTRL_CFG_ATTR_ALL (0xFFFFFFFF); /* all */

/* Source guard configuration */
typedef struct clx_sec_src_guard_cfg_s {
    uint32 flags; /* check flags, refer to CLX_SEC_SRC_GUARD_CFG_FLAGS_XXX */
} clx_sec_src_guard_cfg_t;

#define CLX_SEC_SRC_GUARD_CFG_FLAGS_PORT_CHK     (1U << 0) /* ip source port check */
#define CLX_SEC_SRC_GUARD_CFG_FLAGS_MAC_CHK      (1U << 1) /* ip mac address check */
#define CLX_SEC_SRC_GUARD_CFG_FLAGS_VLAN_SEG_CHK (1U << 2) /* ip vlan check */

/* Source guard entry */
typedef struct clx_sec_src_guard_entry_s {
    uint32 port;           /* port */
    clx_mac_t mac;         /* source mac address */
    clx_ip_addr_t ip_addr; /* ip address */
    uint32 seg0;           /* segment 0 */
    uint32 seg1;           /* segment 1 */
    uint32 flags;          /* field flags, refer to CLX_SEC_SRC_GUARD_ENTRY_FLAGS_XXX */
} clx_sec_src_guard_entry_t;

#define CLX_SEC_SRC_GUARD_ENTRY_FLAGS_IP       (1U << 0) /* flag ip entry */
#define CLX_SEC_SRC_GUARD_ENTRY_FLAGS_MAC      (1U << 1) /* flag mac address */
#define CLX_SEC_SRC_GUARD_ENTRY_FLAGS_VLAN_SEG (1U << 2) /* flag segment of vlan */
#define CLX_SEC_SRC_GUARD_ENTRY_FLAGS_PORT     (1U << 3) /* flag port */

/* Isolation group config */
typedef struct clx_sec_isolation_grp_cfg_s {
    clx_port_bitmap_t dst_bmp; /* destination port bitmap */
} clx_sec_isolation_grp_cfg_t;

/* Isolation port config */
typedef struct clx_sec_isolation_port_cfg_s {
    uint32 grp_id; /* isolation group id */
    boolean en;    /* group id setting enable/disable */
} clx_sec_isolation_port_cfg_t;

/**
 * @brief This API is used to get global DoS configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cfg    - DoS global configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_sec_dos_cfg_get(const uint32 unit, clx_sec_dos_cfg_t *ptr_cfg);

/**
 * @brief This API is used to set global DoS configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    ptr_cfg    - DoS global configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_sec_dos_cfg_set(const uint32 unit, const clx_sec_dos_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get port DoS configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Port ID.
 * @param [out]    ptr_port_cfg    - DoS per port configuration.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_sec_dos_port_cfg_get(const uint32 unit,
                         const uint32 port,
                         clx_sec_dos_port_cfg_t *ptr_port_cfg);

/**
 * @brief This API is used to set port DoS configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Port ID.
 * @param [in]    ptr_port_cfg    - DoS per port configuration.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_sec_dos_port_cfg_set(const uint32 unit,
                         const uint32 port,
                         const clx_sec_dos_port_cfg_t *ptr_port_cfg);

/**
 * @brief This API is used to get DoS status.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_status    - DoS status.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_sec_dos_status_get(const uint32 unit, clx_sec_dos_status_t *ptr_status);

/**
 * @brief This API is used to clear DoS status.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_sec_dos_status_clear(const uint32 unit);

/**
 * @brief This API is used to get DoS count.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cnt    - DoS count.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_sec_dos_cnt_get(const uint32 unit, clx_sec_dos_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear DoS count.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_sec_dos_cnt_clear(const uint32 unit);

/**
 * @brief This API is used to get storm control stats information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Port ID.
 * @param [out]    ptr_stats    - The storm control stats information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_storm_ctrl_stats_get(const uint32 unit,
                             const uint32 port,
                             clx_sec_storm_ctrl_stats_t *ptr_stats);

/**
 * @brief This API is used to clear storm control stats information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_storm_ctrl_stats_clear(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get storm control configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Port ID.
 * @param [out]    ptr_cfg    - The storm control configuration for the specified port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_storm_ctrl_cfg_get(const uint32 unit, const uint32 port, clx_sec_storm_ctrl_cfg_t *ptr_cfg);

/**
 * @brief This API is used to set storm control configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port ID.
 * @param [in]    ptr_cfg    - The storm control configuration for the specified port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_storm_ctrl_cfg_set(const uint32 unit,
                           const uint32 port,
                           const clx_sec_storm_ctrl_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get source guard configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Port ID.
 * @param [out]    ptr_cfg    - The source guard configuration for the specified port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_src_guard_cfg_get(const uint32 unit, const uint32 port, clx_sec_src_guard_cfg_t *ptr_cfg);

/**
 * @brief This API is used to set source guard configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port ID.
 * @param [in]    ptr_cfg    - The source guard configuration for the specified port.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_src_guard_cfg_set(const uint32 unit,
                          const uint32 port,
                          const clx_sec_src_guard_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get source guard bridge domain configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     bdid       - Bridge Domain Id.
 * @param [out]    ptr_cfg    - The source guard configuration for the bridge domain.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_src_guard_bd_cfg_get(const uint32 unit,
                             const clx_bridge_domain_t bdid,
                             clx_sec_src_guard_cfg_t *ptr_cfg);

/**
 * @brief This API is used to set source guard bridge domain configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    bdid       - Bridge Domain Id.
 * @param [in]    ptr_cfg    - The source guard configuration for the bridge domain.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_src_guard_bd_cfg_set(const uint32 unit,
                             const clx_bridge_domain_t bdid,
                             const clx_sec_src_guard_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get a source guard entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     ptr_entry    - The source guard entry which will be provided.
 *                                It should be filled with the keys, which are used to get the
 *                                source guard entry.
 * @param [out]    ptr_entry    - The source guard entry which will be provided.
 *                                It includes keys and checked contents.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_src_guard_entry_get(const uint32 unit, clx_sec_src_guard_entry_t *ptr_entry);

/**
 * @brief This API is used to add a source guard entry or set an existing source guard entry.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - The source guard entry which will be added or set.
 *                               It should at least be filled with the keys.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return        CLX_E_TABLE_FULL       - Table is full.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_src_guard_entry_add(const uint32 unit, const clx_sec_src_guard_entry_t *ptr_entry);

/**
 * @brief This API is used to delete a source guard entry.
 *
 * Once the input source guard entry keys matches an existing source guard entry keys,
 * no matter the source guard entry contents are matched or not, the entry will be deleted.
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ptr_entry    - The source guard entry which will be deleted.
 *                               It should at least be filled with the keys.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_NO_MEMORY          - No available memory for this operation.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The entry doesn't exist.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_sec_src_guard_entry_del(const uint32 unit, const clx_sec_src_guard_entry_t *ptr_entry);

/**
 * @brief This API is used to get isolation group config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     grp_id         - Isolation group id.
 * @param [out]    ptr_grp_cfg    - Isolation group config information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_isolation_grp_cfg_get(const uint32 unit,
                              const uint32 grp_id,
                              clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

/**
 * @brief This API is used to set isolation group config.
 *
 * In an isolation group, the packet isn't allowed to be sent to the egress port.
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    grp_id         - Isolation group id.
 * @param [in]    ptr_grp_cfg    - Isolation group config information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_isolation_grp_cfg_set(const uint32 unit,
                              const uint32 grp_id,
                              const clx_sec_isolation_grp_cfg_t *ptr_grp_cfg);

/**
 * @brief This API is used to get isolation port config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port            - Port id.
 * @param [out]    ptr_port_cfg    - Isolation port config information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_isolation_port_cfg_get(const uint32 unit,
                               const clx_port_t port,
                               clx_sec_isolation_port_cfg_t *ptr_port_cfg);

/**
 * @brief This API is used to set isolation port config.
 *
 * The traffic on the port is isolated by a given isolation group.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port            - Port id.
 * @param [in]    ptr_port_cfg    - Isolation port config information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_sec_isolation_port_cfg_set(const uint32 unit,
                               const clx_port_t port,
                               const clx_sec_isolation_port_cfg_t *ptr_port_cfg);

#endif /* CLX_SEC_H */
