/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mpls.h
 * PURPOSE:
 *  It provides MPLS HAL API.
 *
 * NOTES:
 *
 */

#ifndef HAL_MPLS_H
#define HAL_MPLS_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_mpls.h>
#include <clx/clx_vlan.h>
#include <hal/hal_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MPLS_MAX_NAME_SPACE   (3) /* Maximum name space */
#define HAL_MPLS_LBL_VLD_OFFSET   (21)
#define HAL_MPLS_CW_VLD_OFFSET    (23)
#define HAL_MPLS_PWEL_VLD_OFFSET  (22)
#define HAL_MPLS_EL_VLD_OFFSET    (20)
#define HAL_MPLS_L_LSP_VLD_OFFSET (23)

#define HAL_MPLS_PW_IDX_MIN (0)
#define HAL_MPLS_PW_IDX_MAX (16 * 1024)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MPLS_SEG_IS_LABEL_VALID(seg) \
    (((seg) < HAL_INVALID_SEG_VMID) && ((seg) & (1U << HAL_MPLS_LBL_VLD_OFFSET)))

#define HAL_MPLS_SEG_IS_LABEL_SWAP(seg) (HAL_MPLS_SEG_IS_LABEL_VALID(seg))

#define HAL_MPLS_ENCAP_LABEL_TO_SEG(lbl_val, el_vld, pwel_vld, cw_vld)                 \
    (((cw_vld) << HAL_MPLS_CW_VLD_OFFSET) | ((pwel_vld) << HAL_MPLS_PWEL_VLD_OFFSET) | \
     (1U << HAL_MPLS_LBL_VLD_OFFSET) | ((el_vld) << HAL_MPLS_EL_VLD_OFFSET) |          \
     ((lbl_val) & 0xFFFFF))

#define HAL_MPLS_PW_LABEL_TO_SEG(lbl_val, pwel_vld, cw_vld) \
    HAL_MPLS_ENCAP_LABEL_TO_SEG(lbl_val, 0, pwel_vld, cw_vld)

#define HAL_MPLS_SWAP_LABEL_TO_SEG(l_lsp_vld, el_vld, lbl_val)                      \
    (((l_lsp_vld) << HAL_MPLS_L_LSP_VLD_OFFSET) | (1U << HAL_MPLS_LBL_VLD_OFFSET) | \
     ((el_vld) << HAL_MPLS_EL_VLD_OFFSET) | ((lbl_val) & 0xFFFFF))

#define HAL_MPLS_SEG_TO_LABEL(seg) ((seg) & 0xFFFFF)

#define HAL_MPLS_SEG_TO_CW(seg) (((seg) & (1U << HAL_MPLS_CW_VLD_OFFSET)) ? 1 : 0)

#define HAL_MPLS_SEG_TO_PWEL(seg) (((seg) & (1U << HAL_MPLS_PWEL_VLD_OFFSET)) ? 1 : 0)

#define HAL_MPLS_CHECK_ENCAP_KEY(ptr_key)                                            \
    do {                                                                             \
        uint32 i;                                                                    \
        for (i = 0; i < (ptr_key)->lbl_num; i++) {                                   \
            if ((ptr_key)->lsp_arr[i].lsp_lbl > HAL_MPLS_MAX_LABEL ||                \
                (ptr_key)->lsp_arr[i].ttl > 0xFF || (ptr_key)->lsp_arr[i].exp > 7) { \
                return CLX_E_BAD_PARAMETER;                                          \
            }                                                                        \
        }                                                                            \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mpls_encap_type_s {
    HAL_MPLS_ENCAP_TYPE_P2P = 1,
    HAL_MPLS_ENCAP_TYPE_P2MP,
    HAL_MPLS_ENCAP_TYPE_FRR,
    HAL_MPLS_ENCAP_TYPE_ECMP,
    HAL_MPLS_ENCAP_TYPE_LAST
} hal_mpls_encap_type_t;

typedef struct hal_mpls_path_s {
    clx_port_t intf;
    uint32 di;
    uint32 seg;
    uint32 vid_ctl;
    uint32 vid1;
    uint32 vid2;
    uint32 adj_id;
    uint32 nvo3_adj_id;
    uint32 encap_idx;
    uint32 encap_ecmp_idx;
    uint32 l3_intf_id;
    uint32 mpls_ctl; /* CL8600 only */
    uint32 pw_bdi;   /* CL8600 only */

    uint32 flags;
} hal_mpls_path_t;
#define HAL_MPLS_PATH_FLAGS_L2VPN       (1U << 0)
#define HAL_MPLS_PATH_FLAGS_SEG_VLD     (1U << 1)
#define HAL_MPLS_PATH_FLAGS_VID_CTL_VLD (1U << 2)
#define HAL_MPLS_PATH_FLAGS_PORT_VLD    (1U << 3)
typedef struct hal_mpls_cb_s {
    util_lib_avl_head_t *ptr_pw_avl;
    util_lib_avl_head_t *ptr_pw_key_avl;
    util_lib_avl_head_t *ptr_adj_iev_avl;
    clx_semaphore_id_t sema;
    uint32 adj_id;          /* to remove L2 header */
    uint32 ids_lcl_intf;    /* shared lcl_intf */
    uint32 *ptr_encap_info; /* index: encap_idx */
    util_lib_avl_head_t *ptr_iev_avl;
    util_lib_avl_head_t *ptr_transit_avl;
    util_lib_avl_head_t *ptr_term_avl;
    util_lib_avl_head_t *ptr_mpls_lsp_hsh_avl;  /* tds mpls lsp hash key ref_cnt, CL8600 only */
    util_lib_avl_head_t *ptr_mpls_vpws_lag_avl; /* vpws lag update, CL8600 only */
    util_lib_avl_head_t *ptr_mpls_vpn_id_avl;   /* vpws lag update  CL8600 only */
    uint32 pw_port_idx_min;                     /* CL8600 only */
    uint32 pw_port_idx_max;                     /* CL8600 only */
    uint32 *ptr_pw_port_bmp;                    /* bitmap of pw port index, CL8600 only */
} hal_mpls_cb_t;

typedef struct hal_mpls_decap_tdshsh_avl_node_s {
    uint32_t entry_idx; /* tnl_decap's entry_idx */
    uint16_t ref_cnt;   /* reference count */
} hal_mpls_decap_tdshsh_avl_node_t;

typedef struct hal_mpls_vpws_lag_update_avl_node_t {
    uint16_t lag;
    clx_vlan_t vid1;
    clx_vlan_t vid2;
    uint32 ac_pw_bdi;
    uint32 pw_ac_bdi;
} hal_mpls_vpws_lag_update_avl_node_t;

typedef struct hal_mpls_vpn_id_avl_node_s {
    uint32 bd_id;             /* pw bdid.*/
    uint32 bd_id_extra;       /* ac bdid, used for nb VPWS.*/
    clx_mpls_vpn_type_t type; /* vpn type.*/
    uint32 is_used;           /* is used.*/
} hal_mpls_vpn_id_avl_node_t;
typedef struct hal_mpls_pw_s {
    clx_port_t port;
    uint32 srv_idx;
    clx_mpls_pw_port_t key;
    clx_mpls_vpws_t ac;
    uint32 bdid;
    uint32 acbdid;
    uint32 encap_ecmp_idx; /* encap-idx for underlay ECMP */

    uint32 flags;
} hal_mpls_pw_t;
#define HAL_MPLS_PW_FLAGS_CREATED    (1U << 0)
#define HAL_MPLS_PW_FLAGS_BOUND_AC   (1U << 1)
#define HAL_MPLS_PW_FLAGS_FRR_BACKUP (1U << 2) /* FRR backup PW */

typedef struct hal_mpls_adj_iev_s {
    clx_l3_adj_type_t adj_type;
    uint32 adj_id;
    boolean is_ecmp_path;
    uint32 iev_idx;
} hal_mpls_adj_iev_t;

typedef struct hal_mpls_adj_cookie_s {
    uint32 unit;
    clx_l3_adj_type_t adj_type;
    hal_l3_adj_info_t adj_info;
} hal_mpls_adj_cookie_t;

typedef struct hal_mpls_pw_trav_coolie_s {
    uint32 cnt;
    uint32 idx;
    hal_mpls_pw_t *ptr_buf;
} hal_mpls_pw_trav_cookie_t;

typedef struct hal_mpls_match_trav_cookie_s {
    uint32 cnt;
    uint32 idx;
    clx_mpls_match_info_t *ptr_buf;
} hal_mpls_match_trav_cookie_t;

typedef struct hal_mpls_transit_match_trav_cookie_s {
    uint32 cnt;
    uint32 idx;
    clx_mpls_switch_info_t *ptr_buf;
} hal_mpls_transit_match_trav_cookie_t;

/* iev_rslt_idx for LSP or PW port */
typedef struct hal_mpls_iev_s {
    uint32 iev_idx;
    clx_port_t port;
} hal_mpls_iev_t;

typedef struct hal_mpls_iev_cookie_s {
    uint32 unit;
    clx_port_t port;
    uint32 di;
} hal_mpls_iev_cookie_t;

typedef hal_mpls_cb_t hal_mpls_cb_p[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

clx_error_no_t
hal_mpls_adj_iev_add(const uint32 unit,
                     const clx_l3_adj_type_t adj_type,
                     const uint32 adj_id,
                     const boolean is_ecmp_path,
                     const uint32 iev_idx);

clx_error_no_t
hal_mpls_adj_iev_del(const uint32 unit,
                     const clx_l3_adj_type_t adj_type,
                     const uint32 adj_id,
                     const boolean is_ecmp_path,
                     const uint32 iev_idx);

clx_error_no_t
hal_mpls_check_iev_cb(void *ptr_user_param, void *ptr_node_data, void *ptr_cookie);

clx_error_no_t
hal_mpls_check_iev_by_port(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_mpls_iev_add(const uint32 unit, const uint32 iev_idx, const clx_port_t port);

clx_error_no_t
hal_mpls_iev_del(const uint32 unit, const uint32 iev_idx);

clx_error_no_t
hal_mpls_iev_update(const uint32 unit, const uint32 iev_idx, const clx_port_t port);

clx_error_no_t
hal_mpls_iev_port_get(const uint32 unit, const uint32 iev_idx, clx_port_t *ptr_port);

clx_error_no_t
hal_mpls_get_di_by_intf(const uint32 unit, const clx_port_t intf, uint32 *ptr_di);

clx_error_no_t
hal_mpls_adj_path_info_get(const uint32 unit,
                           const uint32 adj_id,
                           const clx_l3_adj_type_t adj_type,
                           hal_mpls_path_t *ptr_path);

clx_error_no_t
hal_mpls_pw_entry_copy(void *ptr_user_param, void *ptr_node_data, void *ptr_cookie);

clx_error_no_t
hal_mpls_match_key_copy(void *ptr_user_param, void *ptr_node_data, void *ptr_cookie);
clx_error_no_t
hal_mpls_transit_match_key_copy(void *ptr_user_param, void *ptr_node_data, void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize MPLS module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK                - Initialize success.
 * @return        CLX_E_OTHERS            - Initialize failed.
 * @return        CLX_E_ALREADY_INITED    - Already iniialized.
 */
clx_error_no_t
hal_mpls_init(const uint32 unit);

/**
 * @brief Deinitialize the MPLS module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Deinitialization success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Deinitialization failed.
 */
clx_error_no_t
hal_mpls_deinit(const uint32 unit);

/**
 * @brief Dump MPLS software DB.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    flags    - Dump flags.
 * @return        CLX_E_OK        - Operation is successful.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mpls_db_dump(const uint32 unit, const uint32 flags);

/**
 * @brief Get MPLS path DI.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     port      - MPLS tunnel or PW port.
 * @param [out]    ptr_di    - Pointer of the DI of the port.
 * @return         CLX_E_OK                 - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry is not found.
 */
clx_error_no_t
hal_mpls_di_get(const uint32 unit, const clx_port_t port, uint32 *ptr_di);

/**
 * @brief Add IEV rslt info of output to LSP.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    iev_idx    - IEV rslt idx.
 * @param [in]    adj_id     - Adjacency ID.
 * @param [in]    port       - MPLS port.
 * @return        CLX_E_OK        - Operation is successful.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mpls_iev_info_add(const uint32 unit,
                      const uint32 iev_idx,
                      const uint32 adj_id,
                      const clx_port_t port);

/**
 * @brief Delete IEV rslt info of output to LSP.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    iev_idx    - IEV rslt idx.
 * @param [in]    adj_id     - Adjacency ID.
 * @return        CLX_E_OK        - Operation is successful.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_mpls_iev_info_del(const uint32 unit, const uint32 iev_idx, const uint32 adj_id);

hal_mpls_cb_p *
hal_mpls_ctrl_block_get(const uint32 unit);
#endif
