/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecc.h
 * PURPOSE:
 *  Provide HAL ECC manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_ECC_H
#define HAL_ECC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_ecc.h>
#include <hal/hal_io.h>
#include <hal/hal_intr.h>
#include <drv/drv_dma.h>
#include <osal/osal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_ECC_LOG_NUM                       (128)
#define HAL_ECC_TABLE_INST_MAX                (8)
#define HAL_ECC_LOG_FILTER_INTERVAL_MICRO_SEC (100000) /* default interval = 100ms (100000us) */

#define HAL_ECC_ENTRY_SIZE_WORDS_MAX (128)
#define HAL_ECC_RDATA_WORDS_MAX      (128) /* max rdata words for tcam/sram */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_ECC_GET_ECC_INFO_PTR(__unit__) \
    (_ext_chip_control_block[(__unit__)].ptr_driver_info->ptr_ecc_info)

/* DATA TYPE DECLARATIONS
 */

typedef struct hal_ecc_tbl_cnt_info_s {
    uint32 table_id; /* key : share_table_id */
    clx_ecc_cnt_info_t inst_cnt_info[HAL_ECC_TABLE_INST_MAX];
} hal_ecc_tbl_cnt_info_t;

typedef struct hal_ecc_log_info_s {
    boolean valid;
    osal_tm_t time;
    osal_timespec_t timespec;
    uint32 serr_addr;
    uint32 derr_addr;

    uint32 inst;
    uint32 sub_inst;
    uint32 table_id; /* invalid : CLX_SWC_ECC_ERR_INFO_INVALID_TBL_ID */
    uint32 serr_table_entry_start;
    uint32 serr_table_entry_end;
    uint32 derr_table_entry_start;
    uint32 derr_table_entry_end;

    uint32 serr_cnt;
    uint32 derr_cnt;
    uint32 test_intr_cnt;

    clx_swc_ecc_correction_status_t serr_correction;
    clx_swc_ecc_correction_status_t derr_correction;

    uint32 rdata[HAL_ECC_RDATA_WORDS_MAX];
} hal_ecc_log_info_t;

typedef clx_error_no_t (*hal_ecc_traverse_tbl_cnt_func_t)(const uint32 unit,
                                                          const hal_ecc_tbl_cnt_info_t *ptr_info,
                                                          void *ptr_cookie);

typedef clx_error_no_t (*hal_ecc_init_sram_func_t)(const uint32 unit, hal_io_wb_db_t *ptr_db);

typedef clx_error_no_t (*hal_ecc_deinit_sram_func_t)(const uint32 unit, hal_io_wb_db_t *ptr_db);

/* add for NB api */
typedef clx_error_no_t (*hal_ecc_set_cfg_func_t)(const uint32 unit,
                                                 const clx_ecc_module_type_t module_type,
                                                 const uint32 tbl_type,
                                                 const clx_ecc_cfg_t *ptr_ecc_cfg);

typedef clx_error_no_t (*hal_ecc_get_cfg_func_t)(const uint32 unit,
                                                 const clx_ecc_module_type_t module_type,
                                                 const uint32 tbl_type,
                                                 clx_ecc_cfg_t *ptr_ecc_cfg);

typedef clx_error_no_t (*hal_ecc_get_log_info_func_t)(const uint32 unit,
                                                      hal_ecc_log_info_t **ptr_ecc_log);

typedef clx_error_no_t (*hal_ecc_clear_log_info_func_t)(const uint32 unit);

typedef clx_error_no_t (*hal_ecc_lock_cb_func_t)(const uint32 unit, const uint32 lock_en);

typedef clx_error_no_t (*hal_ecc_err_cnt_get_func_t)(const uint32 unit,
                                                     const uint32 table_id,
                                                     clx_ecc_cnt_info_t *ptr_cnt_info);

typedef clx_error_no_t (*hal_ecc_err_cnt_clear_func_t)(const uint32 unit, const uint32 table_id);

typedef struct hal_ecc_info_s {
    /* sram ecc */
    hal_ecc_init_sram_func_t init_sram_func;
    hal_ecc_deinit_sram_func_t deinit_sram_func;
    /* add for NB */
    hal_ecc_set_cfg_func_t set_ecc_cfg;
    hal_ecc_get_cfg_func_t get_ecc_cfg;
    hal_ecc_get_log_info_func_t get_ecc_log_info;
    hal_ecc_clear_log_info_func_t clear_ecc_log_info;
    hal_ecc_lock_cb_func_t lock_ecc_cb;
} hal_ecc_info_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/************************************
 * SRAM ECC DISPATCH API
 ************************************/
clx_error_no_t
hal_ecc_sram_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_ecc_sram_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

/************************************
 * ECC COMMON API
 ************************************/
clx_error_no_t
hal_ecc_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_ecc_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_ecc_tbl_cnt_get(const uint32 unit, const uint32 table_id, hal_ecc_tbl_cnt_info_t *ptr_info);

clx_error_no_t
hal_ecc_tbl_cnt_traverse(const uint32 unit,
                         const hal_ecc_traverse_tbl_cnt_func_t callback,
                         void *ptr_cookie);

clx_error_no_t
hal_ecc_tbl_cnt_clear(const uint32 unit, const uint32 table_id); /* HAL_INVALID_ID : clear all table
                                                                  cnt */

clx_error_no_t
hal_ecc_log_get(const uint32 unit, const uint32 entry_id, hal_ecc_log_info_t *ptr_info);

clx_error_no_t
hal_ecc_log_clear(const uint32 unit);

clx_error_no_t
hal_ecc_log_update_notify(uint32 unit, hal_ecc_log_info_t *ptr_log_info);
/* add for NB */
clx_error_no_t
hal_ecc_cfg_set(const uint32 unit,
                const clx_ecc_module_type_t module_type,
                const uint32 tbl_type,
                const clx_ecc_cfg_t *ptr_ecc_cfg);

clx_error_no_t
hal_ecc_cfg_get(const uint32 unit,
                const clx_ecc_module_type_t module_type,
                const uint32 tbl_type,
                clx_ecc_cfg_t *ptr_ecc_cfg);
clx_error_no_t
hal_ecc_err_cnt_get(const uint32 unit, const uint32 table_id, clx_ecc_cnt_info_t *ptr_cnt_info);

clx_error_no_t
hal_ecc_err_cnt_clear(const uint32 unit, const uint32 table_id);

#endif /* #ifndef HAL_ECC_H */
