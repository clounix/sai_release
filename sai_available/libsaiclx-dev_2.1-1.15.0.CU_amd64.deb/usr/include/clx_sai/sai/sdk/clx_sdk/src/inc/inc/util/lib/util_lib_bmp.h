/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_bmp.h
 * PURPOSE:
 *  this file is used to provide bitmap API.
 * NOTES:
 *
 */
#ifndef UTIL_LIB_BMP_H
#define UTIL_LIB_BMP_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <util/util.h>
#include <util/lib/util_lib.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* MACRO FUNCTION DECLARATIONS
 */
#define UTIL_LIB_BMP_BIT_ADD(bitmap, bit) (((bitmap)[(bit) / 32]) |= (1U << ((bit) % 32)))
#define UTIL_LIB_BMP_BIT_DEL(bitmap, bit) (((bitmap)[(bit) / 32]) &= ~(1U << ((bit) % 32)))
#define UTIL_LIB_BMP_BIT_CHK(bitmap, bit) ((((bitmap)[(bit) / 32] & (1U << ((bit) % 32)))) != 0)

#define UTIL_LIB_BMP_BIT_FOREACH(bitmap, bit, word) \
    for (bit = 0; bit < (word * 32); bit++)         \
        if (UTIL_LIB_BMP_BIT_CHK(bitmap, bit))

#define UTIL_LIB_BMP_OP(bitmap_a, bitmap_b, word, bitwise_operator) \
    do {                                                            \
        uint32 i;                                                   \
        for (i = 0; i < word; i++) {                                \
            (((bitmap_a)[i])bitwise_operator((bitmap_b)[i]));       \
        }                                                           \
    } while (0)

#define UTIL_LIB_BMP_SET(bitmap_a, bitmap_b, word) UTIL_LIB_BMP_OP(bitmap_a, bitmap_b, word, =)
#define UTIL_LIB_BMP_ADD(bitmap_a, bitmap_b, word) UTIL_LIB_BMP_OP(bitmap_a, bitmap_b, word, |=)
#define UTIL_LIB_BMP_DEL(bitmap_a, bitmap_b, word) UTIL_LIB_BMP_OP(bitmap_a, bitmap_b, word, &= ~)
#define UTIL_LIB_BMP_AND(bitmap_a, bitmap_b, word) UTIL_LIB_BMP_OP(bitmap_a, bitmap_b, word, &=)
#define UTIL_LIB_BMP_INV(bitmap_a, bitmap_b, word) UTIL_LIB_BMP_OP(bitmap_a, bitmap_b, word, = ~)
#define UTIL_LIB_BMP_OR(bitmap_a, bitmap_b, word)  UTIL_LIB_BMP_OP(bitmap_a, bitmap_b, word, |=)
#define UTIL_LIB_BMP_XOR(bitmap_a, bitmap_b, word) UTIL_LIB_BMP_OP(bitmap_a, bitmap_b, word, ^=)
#define UTIL_LIB_BMP_COUNT(bitmap, count, word)  \
    do {                                         \
        uint32 i;                                \
        count = 0;                               \
        for (i = 0; i < word; i++) {             \
            count += util_popcount((bitmap)[i]); \
        }                                        \
    } while (0)

#define UTIL_LIB_BMP_CLEAR(bitmap, word)             osal_memset(bitmap, 0, word * 4)
#define UTIL_LIB_BMP_EMPTY(bitmap, word)             util_lib_bmp_empty(bitmap, word)
#define UTIL_LIB_BMP_EQUAL(bitmap_a, bitmap_b, word) (!osal_memcmp(bitmap_a, bitmap_b, (word * 4)))
#define UTIL_LIB_BMP_RANGE_SET(bitmap, firstbit, bitnum, word) \
    do {                                                       \
        uint32 i;                                              \
        UTIL_LIB_BMP_CLEAR(bitmap, word);                      \
        for (i = 0; i < bitnum; i++) {                         \
            UTIL_LIB_BMP_BIT_ADD(bitmap, firstbit + i);        \
        }                                                      \
    } while (0)

#define UTIL_LIB_BMP_RANGE_VAL_SET(bitmap, firstbit, bitnum, val) \
    do {                                                          \
        uint32 i;                                                 \
        for (i = 0; i < bitnum; i++) {                            \
            if (val & (0x1 << i)) {                               \
                UTIL_LIB_BMP_BIT_ADD(bitmap, firstbit + i);       \
            } else {                                              \
                UTIL_LIB_BMP_BIT_DEL(bitmap, firstbit + i);       \
            }                                                     \
        }                                                         \
    } while (0)

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Util_lib_bmp_empty() is a function to check if ptr_bitmap is empty.
 *
 * @param [in]    ptr_bitmap    - The specified bitmap pointer.
 * @param [in]    word          - The size of specified bitmap.
 * @return        uint32    - Return 1 or 0. 1: empty, 0: not empty.
 */
uint32
util_lib_bmp_empty(const uint32 *ptr_bitmap, const uint32 word);

/**
 * @brief Util_lib_bmp_free_idx_get() is a function to check if ptr_bitmap is empty.
 *
 * @param [in]     ptr_bitmap    - The specified bitmap pointer.
 * @param [in]     word          - The size of specified bitmap.
 * @param [out]    ptr_idx       - Found pointer index.
 * @return         CLX_E_OK                 - Get the free index success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Get the free index failed.
 */
clx_error_no_t
util_lib_bmp_free_idx_get(const uint32 *ptr_bitmap, const uint32 word, uint32 *ptr_idx);

/**
 * @brief Util_lib_bmp_free_idx_get_from_back() is a function to git free index from bank.
 *
 * @param [in]     ptr_bitmap    - The specified bitmap pointer.
 * @param [in]     word          - The size of specified bitmap.
 * @param [out]    ptr_idx       - Found pointer index.
 * @return         CLX_E_OK                 - Get the free index success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Get the free index failed.
 */
clx_error_no_t
util_lib_bmp_free_idx_get_from_back(const uint32 *ptr_bitmap, const uint32 word, uint32 *ptr_idx);

#endif /* End of UTIL_LIB_BMP_H */
