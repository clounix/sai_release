/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_PKT_RSRC_H
#define HAL_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx/clx_cfg.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_PKT_PDMA_COMMON       (0x1UL << 0)
#define HAL_PKT_PDMA_TX           (0x1UL << 1)
#define HAL_PKT_PDMA_RX           (0x1UL << 2)
#define HAL_PKT_FORWARD_TO_CPUPKT (0x1UL << 3)

#if defined(CLX_EN_BIG_ENDIAN)
#define HAL_PKT_ENDIAN_SWAP32(val) (val)
#define HAL_PKT_ENDIAN_SWAP16(val) (val)
#else
#define HAL_PKT_ENDIAN_SWAP32(val)                                      \
    ((((uint32)(val) & 0xFF) << 24) | (((uint32)(val) & 0xFF00) << 8) | \
     (((uint32)(val) & 0xFF0000) >> 8) | (((uint32)(val) & 0xFF000000) >> 24))

#define HAL_PKT_ENDIAN_SWAP16(val) ((((uint16)(val) & 0xFF) << 8) | (((uint16)(val) & 0xFF00) >> 8))
#endif

typedef struct {
    boolean enabled;
    uint32 unit;
    uint32 channel;
    uint32 tc;
    clx_color_t color;
    clx_port_bitmap_t egr_port_bitmap;
    boolean with_header;
} HAL_PKT_RX_FWD_CB_T;

/* Keep these values applied to different modules. */
#define HAL_PKT_IPP_EXCPT_NUM    (256)
#define HAL_PKT_EPP_EXCPT_NUM    (64)
#define HAL_PKT_IPP_L3_EXCPT_NUM (6)
#define HAL_PKT_IPP_RSN_NUM      (16)
#define HAL_PKT_IPP_COPY2CPU_NUM (16)
#define HAL_PKT_EPP_COPY2CPU_NUM (8)

/* capacities are the same between CL8360 and CL8570 */
#define HAL_PKT_IPP_EXCPT_BITMAP_SIZE    (CLX_BITMAP_SIZE(HAL_PKT_IPP_EXCPT_NUM))
#define HAL_PKT_IPP_L3_EXCPT_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_PKT_IPP_L3_EXCPT_NUM))
#define HAL_PKT_EPP_EXCPT_BITMAP_SIZE    (CLX_BITMAP_SIZE(HAL_PKT_EPP_EXCPT_NUM))
#define HAL_PKT_IPP_RSN_BITMAP_SIZE      (CLX_BITMAP_SIZE(HAL_PKT_IPP_RSN_NUM))
#define HAL_PKT_IPP_COPY2CPU_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_PKT_IPP_COPY2CPU_NUM))
#define HAL_PKT_EPP_COPY2CPU_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_PKT_EPP_COPY2CPU_NUM))

typedef uint32 HAL_PKT_IPP_EXCPT_BITMAP_T[HAL_PKT_IPP_EXCPT_BITMAP_SIZE];
typedef uint32 HAL_PKT_IPP_L3_EXCPT_BITMAP_T[HAL_PKT_IPP_L3_EXCPT_BITMAP_SIZE];
typedef uint32 HAL_PKT_EPP_EXCPT_BITMAP_T[HAL_PKT_EPP_EXCPT_BITMAP_SIZE];
typedef uint32 HAL_PKT_IPP_RSN_BITMAP_T[HAL_PKT_IPP_RSN_BITMAP_SIZE];
typedef uint32 HAL_PKT_IPP_COPY2CPU_BITMAP_T[HAL_PKT_IPP_COPY2CPU_BITMAP_SIZE];
typedef uint32 HAL_PKT_EPP_COPY2CPU_BITMAP_T[HAL_PKT_EPP_COPY2CPU_BITMAP_SIZE];

typedef struct {
    /* excpt */
    HAL_PKT_IPP_EXCPT_BITMAP_T ipp_excpt_bitmap;
    HAL_PKT_IPP_L3_EXCPT_BITMAP_T ipp_l3_excpt_bitmap;
    HAL_PKT_EPP_EXCPT_BITMAP_T epp_excpt_bitmap;

    /* cp */
    HAL_PKT_IPP_RSN_BITMAP_T ipp_rsn_bitmap;
    HAL_PKT_IPP_COPY2CPU_BITMAP_T ipp_copy2cpu_bitmap;
    HAL_PKT_EPP_COPY2CPU_BITMAP_T epp_copy2cpu_bitmap;
} HAL_PKT_RX_REASON_BITMAP_T;

typedef enum {
    HAL_PKT_RX_CALLBACK_ACTION_REPLACE = 0,
    HAL_PKT_RX_CALLBACK_ACTION_APPEND = 1,
    HAL_PKT_RX_CALLBACK_ACTION_DELETE = 2,
    HAL_PKT_RX_CALLBACK_ACTION_DELETE_ALL = 3,
    HAL_PKT_RX_CALLBACK_ACTION_LAST
} HAL_PKT_RX_CALLBACK_ACTION_T;

/* rfc definition */
#define HAL_PKT_L2_ARP                     (0x0806)
#define HAL_PKT_L2_ARP_OPERATION_DEFAULT   (0) /* both request & response */
#define HAL_PKT_L2_ARP_OPERATION_REQUEST   (1)
#define HAL_PKT_L2_ARP_OPERATION_RESPONSE  (2)
#define HAL_PKT_L2_RARP                    (0x8035)
#define HAL_PKT_L2_RARP_OPERATION_REQUEST  (3)
#define HAL_PKT_L2_RARP_OPERATION_RESPONSE (4)

#define HAL_PKT_IPV4_ICMP (1)
#define HAL_PKT_IPV6_ICMP (58)

#define HAL_PKT_PP_RSN_STR_LEN   (64)
#define HAL_PKT_RSN_STR_LEN      (64)
#define HAL_PKT_DROP_RSN_STR_LEN (64)

/* field bits to mask */
#define HAL_PKT_UI32_MSK(__bits__) (0xFFFFFFFF >> (32 - (__bits__)))

#define HAL_PKT_RSRC_LOCK(unit) \
    osal_semaphore_take(&_hal_pkt_rsrc_cb[unit].sema, CLX_SEMAPHORE_WAIT_FOREVER)

#define HAL_PKT_RSRC_UNLOCK(unit) osal_semaphore_give(&_hal_pkt_rsrc_cb[unit].sema)

#define HAL_PKT_GET_BIT(flags, bit) ((((flags) & (bit)) > 0) ? 1 : 0)

/* Control block for PKT resource management */
typedef struct {
    clx_semaphore_id_t sema;
} HAL_PKT_RSRC_CB_T;

extern HAL_PKT_RSRC_CB_T _hal_pkt_rsrc_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief To de-initialize the SW resource.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Success to perform de-initializtion.
 * @return        CLX_E_OTHERS    - Fail to perform de-initializtion.
 */
clx_error_no_t
hal_pkt_rsrc_deinit(const uint32 unit);

/**
 * @brief To initialize the SW resource.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Success to perform initializtion.
 * @return        CLX_E_OTHERS    - Fail to perform initializtion.
 */
clx_error_no_t
hal_pkt_rsrc_init(const uint32 unit);
#endif /* End of HAL_VLAN_H */
