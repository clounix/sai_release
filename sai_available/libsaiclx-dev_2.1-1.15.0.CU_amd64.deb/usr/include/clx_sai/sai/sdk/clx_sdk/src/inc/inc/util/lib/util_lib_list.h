/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_list.h
 * PURPOSE:
 *  this file is used to provide linked list operations to other users.
 *  linked list include: singly linked list, doubly linked list
 *
 * NOTES:
 *
 */
#ifndef UTIL_LIB_LIST_H
#define UTIL_LIB_LIST_H
/* INCLUDE FILE DECLARATIONS
 */
#include <util/lib/util_lib.h>
/* NAMING CONSTANT DECLARATIONS
 */

/* linked list type */
typedef enum util_lib_list_type_e {
    UTIL_LIB_LIST_TYPE_SINGLY = 0, /* singly linked list type   */
    UTIL_LIB_LIST_TYPE_DOUBLY,     /* doubly linked list type   */
    UTIL_LIB_LIST_TYPE_LAST,
} util_lib_list_type_t;

/* MACRO FUNCTION DECLARATIONS
 */
/* DATA TYPE DECLARATIONS
 */

/* linked list node */
typedef struct util_lib_list_node_s {
    void *ptr_data;                        /* node data                   */
    struct util_lib_list_node_s *ptr_next; /* point to next link node     */
    struct util_lib_list_node_s *ptr_prev; /* point to previous link node */
} util_lib_list_node_t;

struct util_lib_list_s;

/* FUNCTION TYPE NAME: util_lib_list_cmp_func_t
 * PURPOSE:
 *      it is used to find which position the node should be inserted.
 * INPUT:
 *      ptr_node_data   -- the checked linked list node data.
 *      ptr_insert_data -- the data will be inserted.
 * OUTPUT:
 *      None.
 * RETURN:
 *      0     -- the insert node should be inserted before the node.
 *      non 0 -- it is not the right position.
 * NOTES:
 *
 */
typedef int32 (*util_lib_list_cmp_func_t)(void *ptr_node_data, void *ptr_insert_data);

/* FUNCTION TYPE NAME: util_lib_list_locate_func_t
 * PURPOSE:
 *      it is used to locate a linked list node.
 * INPUT:
 *      ptr_node_data  -- the checked linked list node data.
 *      ptr_cookie     -- the data used to check the linked list node. it is
 *                          one of locate function parameters.
 * OUTPUT:
 *      None.
 * RETURN:
 *      0     -- locate success
 *      non 0 -- locate failed, should continue to check.
 * NOTES:
 *
 */
typedef int32 (*util_lib_list_locate_func_t)(void *ptr_node_data, void *ptr_cookie);

/* FUNCTION TYPE NAME: util_lib_list_destroy_func_t
 * PURPOSE:
 *      it is used to release linked list node when destroy a linked list.
 * INPUT:
 *      ptr_node_data  -- the linked list node data will be destroyed.
 * OUTPUT:
 *      None.
 * RETURN:
 *      None.
 * NOTES:
 *
 */
typedef void (*util_lib_list_destroy_func_t)(void *ptr_node_data);

typedef util_lib_list_destroy_func_t util_lib_list_delete_func_t;

/* linked list operations */
typedef struct util_lib_list_ops_s {
    clx_error_no_t (*node_data_get)(struct util_lib_list_s *ptr_list, /* the node owner */
                                    util_lib_list_node_t *ptr_node, /* the node will be get the data
                                                                     */
                                    void **pptr_node_data); /* the data pointer saved in the node */

    clx_error_no_t (*insert_by_func)(/* it used to insert a node by a function        */
                                     struct util_lib_list_s *ptr_list, /* the linked list in which
                                                                       the node is inserted */
                                     void *ptr_data, /* the inserted data                */
                                     util_lib_list_cmp_func_t insert_callback); /* the insert
                                                                                 * function decide
                                                                                 * where the data is
                                                                                 * inserted.
                                                                                 */

    clx_error_no_t (*insert_to_head)(/* it used to insert a data to the head          */
                                     struct util_lib_list_s *ptr_list, /* the linked list in which
                                                                       the node is inserted */
                                     void *ptr_data); /* the inserted data               */

    clx_error_no_t (*insert_to_tail)(/* it used to insert a data to the tail          */
                                     struct util_lib_list_s *ptr_list, /* the linked list in which
                                                                       the node is inserted */
                                     void *ptr_data); /* the inserted data               */

    clx_error_no_t (*insert_before)(/* insert a data before a specified node         */
                                    struct util_lib_list_s *ptr_list, /* the linked list in which
                                                                      the node is inserted */
                                    util_lib_list_node_t *ptr_node,   /* the specified node   */
                                    void *ptr_insert_data);           /* the inserted data        */

    clx_error_no_t (*insert_after)(/* insert a data after a specified node          */
                                   struct util_lib_list_s *ptr_list, /* the linked list in which the
                                                                     node is inserted */
                                   util_lib_list_node_t *ptr_node,   /* the specified node   */
                                   void *ptr_insert_data);           /* the inserted data        */

    clx_error_no_t (*node_delete)(/* delete a node from a linked list     */
                                  struct util_lib_list_s *ptr_list, /* the linked list from which
                                                                     * delete
                                                                     */
                                  util_lib_list_node_t *ptr_delete_node); /* the node will be
                                                                           * deleted
                                                                           */

    clx_error_no_t (*delete_by_data)(struct util_lib_list_s *ptr_list, void *ptr_data);

    clx_error_no_t (*locate_by_func)(/* locate a node from a linked list    */
                                     struct util_lib_list_s *ptr_list, /* the linked list from which
                                                                       locate   */
                                     void *ptr_cookie, /* the cookie data for locate callback */
                                     util_lib_list_locate_func_t locate_callback, /* locate calback
                                                                                  function */
                                     util_lib_list_node_t **pptr_node); /* the located node */

    clx_error_no_t (*head_locate)(/* get the head node from a linked list */
                                  struct util_lib_list_s *ptr_list,  /* the linked list from which
                                                                      * get
                                                                      */
                                  util_lib_list_node_t **pptr_node); /* the head node */

    clx_error_no_t (*tail_locate)(/* get the tail node from a linked list */
                                  struct util_lib_list_s *ptr_list,  /* the linked list from which
                                                                      * get
                                                                      */
                                  util_lib_list_node_t **pptr_node); /* the tail node */

    clx_error_no_t (*next)(/* get next node of the specified node */
                           struct util_lib_list_s *ptr_list, /* the node of this linked list */
                           util_lib_list_node_t *ptr_node, /* the speicified node                 */
                           util_lib_list_node_t **pptr_next_node); /* the next node */

    clx_error_no_t (*prev)(/* get previous node of the specified node */
                           struct util_lib_list_s *ptr_list, /* the node of this linked list */
                           util_lib_list_node_t *ptr_node,   /* the speicified node         */
                           util_lib_list_node_t **pptr_prev_node); /* the previous node */

    clx_error_no_t (*len_get)(/* get the node count of a linked list     */
                              struct util_lib_list_s *ptr_list, /* the linked list */
                              uint32 *ptr_length); /* the linked list, output parameter       */

    clx_error_no_t (*destroy)(                     /* destroy a linked list     */
                              struct util_lib_list_s *ptr_list, /* the destroyed linked list */
                              util_lib_list_destroy_func_t destroy_callback); /* the destroy
                                                                               * function for
                                                                               * releasing linked
                                                                               * list node data
                                                                               */
    clx_error_no_t (*all_node_delete)(/* destroy all nodes from a linked list*/
                                      struct util_lib_list_s *ptr_list, /*  the linked list*/
                                      util_lib_list_delete_func_t delete_callback); /*  the delete
                                                                                       function for
                                                                                       releasing
                                                                                       node data*/

} util_lib_list_ops_t;

/* linked list head */
typedef struct util_lib_list_s {
    util_lib_list_node_t *ptr_head_node; /* linked list head node   */
    util_lib_list_node_t *ptr_tail_node; /* linked list tail node   */
    util_lib_list_type_t type;           /* list type */
    uint32 capacity;                     /* max count of nodes in list
                                          * size=0: the capacity is unlimited.
                                          * size>0: the capacity is limited.
                                          */
    void *ptr_node_pool;                 /* node pool */
    uint32 node_count;                   /* the count of nodes in the list */
    util_lib_list_ops_t *ptr_ops;        /* linked list operations         */
} util_lib_list_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief it is used to create a linked list head.
 *
 * @param [in]     list_type    - the linked list type.
 *                                UTIL_LIB_LIST_TYPE_SINGLY  : singly linked list.
 *                                UTIL_LIB_LIST_TYPE_DOUBLY  : doubly linked list.
 * @param [in]     capacity     - the linked list capacity, if it is 0 then the linked list
 *                                size is unfixed, or is fixed.
 * @param [in]     ptr_name     - the linked list name, max length is UTIL_LIB_NAME_LEN_MAX(include
 * '\0')
 * @param [out]    pptr_list    - the new list head.
 * @return         CLX_E_OK               - create success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null or the type is invalid.
 * @return         CLX_E_NO_MEMORY        - list head failed.
 * @return         CLX_E_OTHERS           - create node pool failed.
 */
clx_error_no_t
util_lib_list_create(const uint32 capacity,
                     const util_lib_list_type_t list_type,
                     const char *ptr_name,
                     util_lib_list_t **pptr_list);

/**
 * @brief it is used to destroy a linked list and release head and nodes. if user
 *        provide a destroy function, it will release every node data in the
 *        linked list.
 *
 * @param [in]     ptr_list            - the destroyed linked list.
 * @param [in]     destroy_callback    - destroy function is used to destroy node data.
 * @return         CLX_E_OK               - destroy success.
 * @return         CLX_E_BAD_PARAMETER    - ptr_list is null.
 */
clx_error_no_t
util_lib_list_destroy(util_lib_list_t *ptr_list,
                      const util_lib_list_destroy_func_t destroy_callback);

/**
 * @brief it is used to get the node data, the node may be singly/doubly/circular
 *        linked list node.
 *
 * @param [in]     ptr_list          - the list owns the node
 * @param [in]     ptr_node          - the node will be get data
 * @param [out]    pptr_node_data    - the data saved in the node.
 * @return         CLX_E_OK               - destroy success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 */
clx_error_no_t
util_lib_list_node_data_get(util_lib_list_t *ptr_list,
                            util_lib_list_node_t *ptr_node,
                            void **pptr_node_data);

/**
 * @brief it is used to insert a data by a insert function which is used to decide
 *        where the inserted node should be inserted. if the insert function does
 *        not give a position(node), the node will be inserted to the tail of the
 *        linked list. if the insert function give a position(node), the node will
 *        be inserted before the position(node).
 *
 * @param [in]     ptr_list        - the node will be inseted in it.
 * @param [in]     ptr_data        - the inserted data.
 * @param [in]     cmp_callback    - the inserted callback function, used to find the
 *                                   insert position.
 * @return         CLX_E_OK               - insert success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_TABLE_FULL       - the linked list is full, this is for capacity>0
 * @return         CLX_E_NO_MEMORY        - allocate node failed, this is for capacity==0.
 */
clx_error_no_t
util_lib_list_insert_by_func(util_lib_list_t *ptr_list,
                             void *ptr_data,
                             const util_lib_list_cmp_func_t cmp_callback);

/**
 * @brief it is used to insert a data to the front of linked list.
 *
 * @param [in]     ptr_list    - the node will be inserted in it.
 * @param [in]     ptr_data    - the inserted data.
 * @return         CLX_E_OK               - insert success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_TABLE_FULL       - the linked list is full, this is for capacity>0
 * @return         CLX_E_NO_MEMORY        - allocate node failed, this is for capacity==0.
 */
clx_error_no_t
util_lib_list_insert_to_head(util_lib_list_t *ptr_list, void *ptr_data);

/**
 * @brief it is used to insert a data to the tail of linked list.
 *
 * @param [in]     ptr_list    - the node will be inserted in it.
 * @param [in]     ptr_data    - the inserted data.
 * @return         CLX_E_OK               - insert success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_TABLE_FULL       - the linked list is full, this is for capacity>0
 * @return         CLX_E_NO_MEMORY        - allocate node failed, this is for capacity==0.
 */
clx_error_no_t
util_lib_list_insert_to_tail(util_lib_list_t *ptr_list, void *ptr_data);

/**
 * @brief it is used to insert a data before a specified node.
 *
 * singly & circular linked list don't support this operation.
 *
 * @param [in]     ptr_list    - the node will be inserted in it.
 * @param [in]     ptr_node    - insert before it.
 * @param [in]     ptr_data    - the inserted data.
 * @return         CLX_E_OK               - insert success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_TABLE_FULL       - the linked list is full, this is for capacity>0
 * @return         CLX_E_NO_MEMORY        - allocate node failed, this is for capacity==0.
 * @return         CLX_E_NOT_SUPPORT       - list don't support this operation
 */
clx_error_no_t
util_lib_list_insert_before(util_lib_list_t *ptr_list,
                            util_lib_list_node_t *ptr_node,
                            void *ptr_data);

/**
 * @brief it is used to insert a data after a specified node.
 *
 * @param [in]     ptr_list    - the node will be inserted in it.
 * @param [in]     ptr_node    - insert after it.
 * @param [in]     ptr_data    - the inserted data.
 * @return         CLX_E_OK               - insert success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_TABLE_FULL       - the linked list is full, this is for capacity>0
 * @return         CLX_E_NO_MEMORY        - allocate node failed, this is for capacity==0.
 */
clx_error_no_t
util_lib_list_insert_after(util_lib_list_t *ptr_list,
                           util_lib_list_node_t *ptr_node,
                           void *ptr_data);

/**
 * @brief it is used to delete a node from a linked list.
 *
 * the delete node data will not process in this function
 *
 * @param [in]     ptr_list           - the node will delete from it.
 * @param [in]     ptr_delete_node    - the deleted node pointer.
 * @return         CLX_E_OK                 - delete success.
 * @return         CLX_E_BAD_PARAMETER      - parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - the delete node is not in the linked list
 */
clx_error_no_t
util_lib_list_node_delete(util_lib_list_t *ptr_list, util_lib_list_node_t *ptr_delete_node);

/**
 * @brief it is used to delete alll node from a linked list.
 *
 * If the list is empty, we return CLX_E_OK.
 *
 * @param [in]     ptr_list           - the node will delete from it.
 * @param [in]     delete_callback    - delete function is used to destroy node data.
 * @return         CLX_E_OK               - delete success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 */
clx_error_no_t
util_lib_list_all_node_delete(util_lib_list_t *ptr_list,
                              const util_lib_list_delete_func_t delete_callback);

/**
 * @brief it is used to delete a node from a linked list by user data pointer.
 *
 * @param [in]     ptr_list    - the node will delete from it.
 * @param [in]     ptr_data    - the deleted user data pointer.
 * @return         CLX_E_OK                 - delete success.
 * @return         CLX_E_BAD_PARAMETER      - parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - the delete node is not in the linked list
 */
clx_error_no_t
util_lib_list_node_delete_by_data(util_lib_list_t *ptr_list, void *ptr_data);

/**
 * @brief it is used to locate a node data from a linked list by a locate function.
 *
 * @param [in]     ptr_list           - the linked list.
 * @param [in]     ptr_cookie         - cookie data for locate function.
 * @param [in]     locate_callback    - locate function for location.
 * @param [out]    pptr_node          - the located node.
 * @return         CLX_E_OK                 - locate success.
 * @return         CLX_E_BAD_PARAMETER      - parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - the locate data is not in the linked list
 */
clx_error_no_t
util_lib_list_locate_by_func(util_lib_list_t *ptr_list,
                             void *ptr_cookie,
                             const util_lib_list_locate_func_t locate_callback,
                             util_lib_list_node_t **pptr_node);

/**
 * @brief it is used to get the first node of the linked list.
 *
 * @param [in]     ptr_list     - the linked list.
 * @param [out]    pptr_node    - the head data node.
 * @return         CLX_E_OK                 - locate success.
 * @return         CLX_E_BAD_PARAMETER      - parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - no data node, it means list is empty
 */
clx_error_no_t
util_lib_list_head_locate(util_lib_list_t *ptr_list, util_lib_list_node_t **pptr_node);

/**
 * @brief it is used to get the last node of the linked list.
 *
 * @param [in]     ptr_list     - the linked list.
 * @param [out]    pptr_node    - the tail node.
 * @return         CLX_E_OK                 - locate success.
 * @return         CLX_E_BAD_PARAMETER      - parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - no data node, it means list is empty
 */
clx_error_no_t
util_lib_list_tail_locate(util_lib_list_t *ptr_list, util_lib_list_node_t **pptr_node);

/**
 * @brief it is used to get the next node of a specified node.
 *
 * @param [in]     ptr_list          - the linked list.
 * @param [in]     ptr_node          - the specified node.
 * @param [out]    pptr_next_node    - the next node.
 * @return         CLX_E_OK                 - get next node success.
 * @return         CLX_E_BAD_PARAMETER      - parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - no next node
 */
clx_error_no_t
util_lib_list_next(util_lib_list_t *ptr_list,
                   util_lib_list_node_t *ptr_node,
                   util_lib_list_node_t **pptr_next_node);

/**
 * @brief it is used to get the previous node of a specified node.
 *
 * singly & circular linked list don't support this operation.
 *
 * @param [in]     ptr_list          - the linked list.
 * @param [in]     ptr_node          - the specified node.
 * @param [out]    pptr_prev_node    - the previous node.
 * @return         CLX_E_OK                 - get previous node success.
 * @return         CLX_E_BAD_PARAMETER      - parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - no previous node
 * @return         CLX_E_NOT_SUPPORT        - list don't support this operation
 */
clx_error_no_t
util_lib_list_prev(util_lib_list_t *ptr_list,
                   util_lib_list_node_t *ptr_node,
                   util_lib_list_node_t **pptr_prev_node);

/**
 * @brief it is used to get the count of nodes in the linked list.
 *
 * @param [in]     ptr_list      - the linked list.
 * @param [out]    ptr_len       - the number of nodes in the linked list.
 * @return         CLX_E_OK               - destroy success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 */
clx_error_no_t
util_lib_list_len_get(util_lib_list_t *ptr_list, uint32 *ptr_len);

#endif /* End of UTIL_LIB_LIST_H */
