/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_io.h
 * PURPOSE:
 *      1. hal_io.h provides HAL IO manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_IO_H
#define HAL_IO_H

#include <clx/clx_module.h>
#include <util/lib/util_lib_avl.h>
#include <util/lib/util_lib_list.h>
#include <util/lib/util_lib_hsh.h>

typedef struct hal_io_sub_hdr_s {
    uint32 cnt;      /* meta unit count */
    uint32 unit_len; /* the length of one meta unit */
} hal_io_sub_hdr_t;

typedef struct hal_io_swdb_avl_cookie_s {
    hal_io_sub_hdr_t header;
    char *ptr_data;
} hal_io_swdb_avl_cookie_t;

typedef struct hal_io_obj_meta_s {
    uint32 obj_id;
    uint32 obj_ver;
    uint32 data_size;
    char *ptr_data;
} hal_io_obj_meta_t;

typedef struct hal_io_wb_db_s {
    uint32 max_cnt;        /* used when closeNonVolatile */
    uint32 cur_idx;        /* used when addWbObj         */
    uint32 total_obj_size; /* used when closeNonVolatile */
    hal_io_obj_meta_t *ptr_objs;
} hal_io_wb_db_t;

clx_error_no_t
hal_io_nonvolatile_open(const uint32 unit, const uint32 write_mode);

clx_error_no_t
hal_io_nonvolatile_close(const uint32 unit);

clx_error_no_t
hal_io_nonvolatile_get(const uint32 unit,
                       const clx_module_t module,
                       char **pptr_buf,
                       uint32 *ptr_num_bytes);

/**
 * @brief The function is used to save AVL tree to buffer. Please note that
 *        avl node should not have pointer field.
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_avl         - Pointer of the avl tree head
 * @param [in]     ptr_obj_meta    - Object Meta for the avl storage
 * @param [out]    ptr_obj_meta    - Object Meta for the avl storage
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_io_avl_tree_save(const uint32 length,
                     const util_lib_avl_head_t *ptr_avl,
                     hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief The function is used to restore AVL tree from buffer
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_avl         - Pointer of the avl tree head
 * @param [in]     ptr_obj_meta    - Object Meta for the avl storage
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_io_avl_tree_restore(const uint32 length,
                        const util_lib_avl_head_t *ptr_avl,
                        const hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief The function is used to save List to buffer. Please note that
 *        list node should not have pointer field.
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_list        - Pointer of the list head
 * @param [in]     ptr_obj_meta    - Object Meta for the list storage
 * @param [out]    ptr_obj_meta    - Object Meta for the list storage
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_io_list_save(const uint32 length,
                 const util_lib_list_t *ptr_list,
                 hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief The function is used to restore List from buffer
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_list        - Pointer of the List head
 * @param [in]     ptr_obj_meta    - Object Meta for the list storage
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_io_list_restore(const uint32 length,
                    const util_lib_list_t *ptr_list,
                    const hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief The function is used to save Array to buffer. Please note that
 *        1. array node should not have pointer field.
 *
 * @param [in]     length          - Node size
 * @param [in]     count           - Node count
 * @param [in]     ptr_array       - Pointer of the array head
 * @param [in]     ptr_obj_meta    - Object Meta for the array storage
 * @param [out]    ptr_obj_meta    - Object Meta for the array storage
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_io_array_save(const uint32 length,
                  const uint32 count,
                  const void *ptr_array,
                  hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief The function is used to restore Array from buffer
 *
 * @param [in]     ptr_array       - Pointer of the Array head
 * @param [in]     ptr_obj_meta    - Object Meta for the array storage
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_io_array_restore(void *ptr_array, const hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief The function is used to save hash table to buffer.
 *
 * @param [in]     length          - Node size
 * @param [in]     ptr_hash_tbl    - Pointer of the hash table
 * @param [in]     ptr_obj_meta    - Object Meta for the hash table
 * @param [out]    ptr_obj_meta    - Object Meta for the hash table
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_NO_MEMORY - No memory.
 */
clx_error_no_t
hal_io_hash_tbl_save(const uint32 length,
                     util_lib_hsh_tbl_t *ptr_hash_tbl,
                     hal_io_obj_meta_t *ptr_obj_meta);

/**
 * @brief The function is used to restore hash table from buffer
 *
 * @param [in]     length          - Node size
 * @param [in]     key_offset      - Key offset in node
 * @param [in]     ptr_obj_meta    - Object Meta for the hash table
 * @param [in]     ptr_hash_tbl    - Pointer of the hash table
 * @param [out]    ptr_hash_tbl    - Pointer of the hash table
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_io_hash_tbl_restore(const uint32 length,
                        const uint32 key_offset,
                        const hal_io_obj_meta_t *ptr_obj_meta,
                        util_lib_hsh_tbl_t *ptr_hash_tbl);

/**
 * @brief The function is used to create a warmboot database.
 *
 * @param [in]     obj_count    - Total object count
 * @param [out]    pptr_db      - Pointer to the warmboot database
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_io_wb_db_create(uint32 obj_count, hal_io_wb_db_t **pptr_db);

/**
 * @brief The function is used to add object(s) to warmboot database.
 *
 * @param [in]     ptr_db       - Pointer to the warmboot database
 * @param [out]    obj_count    - Object count to be added
 * @param [out]    ptr_objs     - Objects to be added
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_io_wb_obj_add(hal_io_wb_db_t *ptr_db, uint32 obj_count, hal_io_obj_meta_t *ptr_objs);

/**
 * @brief The function is used to dump warmboot database to nonvolatile storage
 *
 * @param [in]     unit      - Device unit
 * @param [in]     module    - Module id
 * @param [in]     ptr_db    - Pointer to the warmboot database
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_io_wb_db_write(uint32 unit, clx_module_t module, hal_io_wb_db_t *ptr_db);

/**
 * @brief The function is used to destroy warmboot database
 *        after dumping to nonvolatile storage
 *
 * @param [in]     ptr_db    - Pointer to the warmboot database
 */
void
hal_io_wb_db_destroy(hal_io_wb_db_t *ptr_db);

/**
 * @brief The function is used to read warmboot database from nonvolatile storage
 *
 * WbDb format in Nonvolatile Data:
 *              +----------------------------------------------+
 * 0x00         | Object Count                                 |
 *              +----------------------------------------------+
 * 0x04         | Object 1 Offset                              |
 *              +----------------------------------------------+
 * 0x08         | Object 2 Offset                              |
 *              +----------------------------------------------+
 * 0x12         | Object 3 Offset                              |
 *              +----------------------------------------------+
 * 0x16         | Object 4 Offset                              |
 *              +----------------------------------------------+
 * (4 + 4(N-1)) | Object N Offset                              |
 *              +----------------------------------------------+
 * (4 + 4N)     | <Object 1>                                   |
 *              | Obj1_ID | Obj1_VER | Obj1_DATA (with size s1)|
 *              +----------------------------------------------+
 * (4 + 4N      | <Object 2>                                   |
 * + 8 + s1 )   | Obj2_ID | Obj2_VER | Obj2_DATA (with size s2)|
 *              +----------------------------------------------+
 * (4+4N+8+s1   | <Object 3>                                   |
 * + 8 + s2)    | Obj3_ID | Obj3_VER | Obj3_DATA (with size s3)|
 *              +----------------------------------------------+
 * (4+4N+8(N-1) | <Object N>                                   |
 * + sigma      | Objn_ID | Objn_VER | Objn_DATA (with size sn)|
 * (s[1~n-1]))  |                                              |
 *              +----------------------------------------------+
 *
 * @param [in]     unit       - Device unit
 * @param [in]     module     - Module id
 * @param [out]    pptr_db    - Pointer to the warmboot database
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_io_wb_db_read(uint32 unit, clx_module_t module, hal_io_wb_db_t **pptr_db);

/**
 * @brief The function is used to get object from warmboot database
 *
 * It would try to find the best-matched object by obj_ver from wbdb.
 * If possible, it returns the object with obj_ver = CLX_WB_VER_RELEASE;
 * if not found, it returns the object with the closest version.
 *
 * @param [in]     ptr_db     - Pointer to the warmboot database
 * @param [in]     obj_id     - Object id
 * @param [out]    ptr_obj    - Object
 * @return         CLX_E_OK                 - Object with same obj_id is found
 * @return         CLX_E_ENTRY_NOT_FOUND    - Object is not found
 */
clx_error_no_t
hal_io_wb_obj_get(const hal_io_wb_db_t *ptr_db, uint32 obj_id, hal_io_obj_meta_t *ptr_obj);

/**
 * @brief The function is used to get currently loaded nonvolitile version
 *
 * @param [in]     unit    - Device unit
 * @return         db_ver    - Currently loaded nonvolitile version
 */
uint32
hal_io_db_ver_get(uint32 unit);

#endif /* #ifndef HAL_IO_H */