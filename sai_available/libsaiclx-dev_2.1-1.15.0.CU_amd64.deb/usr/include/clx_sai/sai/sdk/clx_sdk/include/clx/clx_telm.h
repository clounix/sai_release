/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_telm.h
 * PURPOSE:
 *      It provides TELM module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_TELM_H
#define CLX_TELM_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_init.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>
#include <clx/clx_pkt.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_TELM_INT_PORT_ROLE_DISABLE (0)                  /* telemetry INT port role disabled */
#define CLX_TELM_INT_PORT_ROLE_SOURCE  (1)                  /* telemetry INT port role is source */
#define CLX_TELM_INT_PORT_ROLE_TRANSIT (2)                  /* telemetry INT port role is transit */
#define CLX_TELM_INT_PORT_ROLE_SINK    (3)                  /* telemetry INT port role is sink */

#define CLX_TELM_INT_INSTR_TYPE_NODE_ID        (0x1U << 15) /* globlal node id */
#define CLX_TELM_INT_INSTR_TYPE_L1_IF_ID       (0x1U << 14) /* level 1 ingress/egress interface ID */
#define CLX_TELM_INT_INSTR_TYPE_HOP_LATENCY    (0x1U << 13) /* hop latency */
#define CLX_TELM_INT_INSTR_TYPE_QUE_ID_OCCUP   (0x1U << 12) /* queue ID and queue occupancy */
#define CLX_TELM_INT_INSTR_TYPE_IGR_TS         (0x1U << 11) /* ingress timestamp */
#define CLX_TELM_INT_INSTR_TYPE_EGR_TS         (0x1U << 10) /* egress timestamp */
#define CLX_TELM_INT_INSTR_TYPE_L2_IF_ID       (0x1U << 9) /* level 2 ingress/egress interface ID */
#define CLX_TELM_INT_INSTR_TYPE_EGR_IF_TX_UTIL (0x1U << 8) /* egress interface tx utilization */
#define CLX_TELM_INT_INSTR_TYPE_BUF_ID_OCCUP   (0x1U << 7) /* buffer ID and buffer occupancy */
/* bit0 is drop reason. defult enable drop bit, if user not need, config this bit to 1 */
#define CLX_TELM_INT_INSTR_TYPE_DROP_REASON_INVALID (0x1U << 0)

/* telemetry port speed in rwi */
#define CLX_TELM_PORT_SPEED_10  (0) /* 0: 10G;  */
#define CLX_TELM_PORT_SPEED_25  (1) /* 1: 25G;  */
#define CLX_TELM_PORT_SPEED_40  (2) /* 2: 40G;  */
#define CLX_TELM_PORT_SPEED_50  (3) /* 3: 50G;  */
#define CLX_TELM_PORT_SPEED_100 (4) /* 4:100G;  */
#define CLX_TELM_PORT_SPEED_200 (5) /* 5:200G;  */
#define CLX_TELM_PORT_SPEED_400 (6) /* 6:400G;  */
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* Telemetry type */
typedef enum clx_telm_type_e {
    CLX_TELM_INT = 0,  /* INT type */
    CLX_TELM_IOAM = 1, /* IOAM type */
    CLX_TELM_IFA = 2,  /* IFA type */
    CLX_TELM_TYPE_LAST
} clx_telm_type_t;

/* Telemetry irq */
typedef enum clx_telm_irq_type_e {
    CLX_TELM_IRQ_HOP_CNT_ZERO,       /* IRQ for INT or IFA hop cnt zero */
    CLX_TELM_IRQ_IFA_MAX_LEN_EXCEED, /* IRQ for IFA max len exceed */
    CLX_TELM_IRQ_IOAM_READ_FIFO,     /* IRQ for IOAM read FIFO */
    CLX_TELM_IRQ_LAST
} clx_telm_irq_type_t;

typedef enum clx_telm_cfg_e {
    CLX_TELM_CFG_EGR_PORT_IS_EDGE, /* Egress port is INT edge */
    CLX_TELM_CFG_LAST
} clx_telm_cfg_t;

typedef struct clx_telm_cfg_param_s {
    clx_port_t port;
    boolean enable;
} clx_telm_cfg_param_t;

/* int struct */
typedef enum clx_telm_mode_e {
    /* value same with asic */
    CLX_TELM_MX = 0, /* INT-MX mode */
    CLX_TELM_MD = 1, /* INT-MD mode */
    CLX_TELM_XD = 2, /* INT-XD mode */
    CLX_TELM_LAST
} clx_telm_mode_t;

typedef enum clx_telm_int_version_e {
    CLX_TELM_INT_VERSION_2 = 2, /* Telemetry report specification defines version 2 */
    CLX_TELM_INT_VERSION_LAST
} clx_telm_int_version_t;

typedef enum clx_telm_int_l4_type_e {
    CLX_TELM_INT_USE_IP_DSCP,   /* use ip dscp as identifier for tcp/udp over INT */
    CLX_TELM_INT_USE_DEST_PORT, /* use tcp/udp dest port as identifier for tcp/udp over INT */
    CLX_TELM_INT_LAST
} clx_telm_int_l4_type_t;

typedef struct clx_telm_int_l4_s {
    boolean valid;               /* enable int over tcp/udp, default off */
    clx_telm_int_l4_type_t type; /* use ip dscp or tcp/udp dest port for INT shim, default use dscp
                                  */
    uint16 dst_port_val;         /* dest port value as INT identifier */
    uint8 dscp_val;              /* ip dscp value as INT identifier */
    uint8 dscp_mask;             /* mask for ip dscp, check for INT identifier */
} clx_telm_int_l4_t;

typedef struct clx_telm_int_identifier_s {
    uint16 geneve_val;     /* geneve.opt value as INT identifier */
    uint16 gre_val;        /* gre.proto value as INT identifier */
    uint8 vxlan_val;       /* vxlan.gpe.proto value as INT identifier */
    clx_telm_int_l4_t tcp; /* ip.dscp or tcp.dest_port vlaue for INT shim */
    clx_telm_int_l4_t udp; /* ip.dscp or udp.dest_port vlaue for INT shim */
} clx_telm_int_identifier_t;

typedef struct clx_telm_int_domain_s {
    clx_telm_mode_t telm_mode;                             /* INT mode */
    boolean int_clone;                                     /* INT clone mode */
    clx_telm_int_identifier_t identifier;                  /* INT indentifier */
    uint32 attr_bmp;                                       /* CLX_TELM_INT_DOMAIN_ATTR_XXX flags */
} clx_telm_int_domain_t;
#define CLX_TELM_INT_DOMAIN_ATTR_MODE         (0x1U << 0)  /* set or get telm mode */
#define CLX_TELM_INT_DOMAIN_ATTR_CLONE        (0x1U << 1)  /* set or get int clone */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_GENEVE (0x1U << 2)  /* set or get int geneve identifier  */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_GRE    (0x1U << 3)  /* set or get int gre identifier */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_VXLAN  (0x1U << 4)  /* set or get int vxlan identifier */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_TCP    (0x1U << 5)  /* set or get int tcp identifier */
#define CLX_TELM_INT_DOMAIN_ATTR_IDENT_UDP    (0x1U << 6)  /* set or get int udp identifier */
#define CLX_TELM_INT_DOMAIN_ATTR_ALL          (0xFFFFFFFF) /* set or get all */

typedef struct clx_telm_restore_dscp_s {
    boolean tcp; /* restore tcp dscp when decap INT */
    boolean udp; /* restore udp dscp when decap INT */
} clx_telm_restore_dscp_t;

typedef enum clx_telm_trunc_pkt_size_e {
    CLX_TELM_TRUNC_TO_64,  /* 0: 64 if pkt size > 64 */
    CLX_TELM_TRUNC_TO_128, /* 1:128 if pkt size > 128 */
    CLX_TELM_TRUNC_TO_192, /* 2:192 if pkt size > 192 */
    CLX_TELM_TRUNC_TO_256, /* 3:256 if pkt size > 256 */
    CLX_TELM_TRUNC_TO_512, /* 4:512 if pkt size > 512, for MOD, 472 (512-40) is the real pkt size
                              after truncated */
    CLX_TELM_TRUNC_TO_984, /* 5:984 if pkt size > 984, MOD not support */
    CLX_TELM_TRUNC_LAST
} clx_telm_trunc_pkt_size_t;

typedef struct clx_telm_trunc_s {
    boolean cut_en;                     /* cut enable. default is 0, not cut */
    clx_telm_trunc_pkt_size_t pkt_size; /* packet size after truncation */
} clx_telm_trunc_t;

typedef enum clx_telm_collector_type_e {
    CLX_TELM_COLLECTOR_TYPE_INT,
    CLX_TELM_COLLECTOR_TYPE_MOD,
    CLX_TELM_COLLECTOR_TYPE_LAST,
} clx_telm_collector_type_t;

typedef struct clx_telm_collector_cfg_info_s {
    boolean collector_set; /* config collector. if disable del collector. must be set */
    clx_mac_t src_mac;     /* source mac */
    clx_mac_t dst_mac;     /* destination mac */
    // clx_vlan_t svid;      /* service provider vlan id */
    clx_vlan_t cvid; /* customer vlan id */
    uint8 dscp;      /* dscp value */
    uint8 pcp;
    uint8 dei;
    uint8 ttl;
    clx_ip_addr_t src_ip;
    clx_ip_addr_t dst_ip;
    uint16 mtu_size;
    uint16 udp_dst_port;                             /* collector udp dest port */
    uint32 attr_bmp;                                 /* CLX_TELM_COLLECTOR_CFG_ATTR_XXX flags */
} clx_telm_collector_cfg_info_t;
#define CLX_TELM_COLLECTOR_CFG_ATTR_SMAC (0x1U << 0) /* set or get source mac */
#define CLX_TELM_COLLECTOR_CFG_ATTR_DMAC (0x1U << 1) /* set or get destination mac  */
// #define CLX_TELM_COLLECTOR_CFG_ATTR_SVID      (0x1U << 2)  /* set or get service provider vlan id
// */
#define CLX_TELM_COLLECTOR_CFG_ATTR_CVID      (0x1U << 3)  /* set or get customer vlan id */
#define CLX_TELM_COLLECTOR_CFG_ATTR_DSCP      (0x1U << 4)  /* set or get dscp value */
#define CLX_TELM_COLLECTOR_CFG_ATTR_PCP       (0x1U << 5)  /* set or get pcp */
#define CLX_TELM_COLLECTOR_CFG_ATTR_DEI       (0x1U << 6)  /* set or get dei */
#define CLX_TELM_COLLECTOR_CFG_ATTR_TTL       (0x1U << 7)  /* set or get ttl */
#define CLX_TELM_COLLECTOR_CFG_ATTR_SIP       (0x1U << 8)  /* set or get source ip */
#define CLX_TELM_COLLECTOR_CFG_ATTR_DIP       (0x1U << 9)  /* set or get dest ip */
#define CLX_TELM_COLLECTOR_CFG_ATTR_MTU       (0x1U << 10) /* set or get mtu */
#define CLX_TELM_COLLECTOR_CFG_ATTR_UDP_DPORT (0x1U << 11) /* set or get udp dest port */
#define CLX_TELM_COLLECTOR_CFG_ATTR_ALL       (0xFFFFFFFF) /* set all */

typedef enum clx_telm_int_l2_intf_e {
    CLX_TELM_INT_L2_INTF_USE_SRC_AND_DST_IDX, /* use source and dest index as L2 interface
                                                 information */
    CLX_TELM_INT_L2_INTF_USE_BD,              /* use BD as L2 interface information */
    CLX_TELM_INT_L2_INTF_LAST
} clx_telm_int_l2_intf_t;

typedef struct clx_telm_int_mata_info_s {
    uint32 latency_comp;            /* hop latency compensation to compensate the pl latency */
    uint8 buf_id;                   /* buffer id, default is 0 */
    boolean expand_oq_width;        /* an option to expand output queue size in metadata */
    clx_telm_int_l2_intf_t l2_intf; /* metadata l2 interface information, default use src and dest
                                       idx */
} clx_telm_int_mata_info_t;

typedef struct clx_telm_int_device_s {
    clx_telm_restore_dscp_t dscp_restore; /* restore dscp when terminate int, default is to restore
                                           */
    clx_telm_trunc_t int_truncate;        /* int truncate clone packets into a specific size */
    uint16 instr_mask;                    /* instruction mask */

    /* report */
    clx_port_t report_egr_port;              /* int report egress port */
    clx_telm_collector_cfg_info_t collector; /* config collector info */

    /* meta md header */
    uint32 max_hop_cnt; /* hop cnt value put in int shim header in int-source */

    /* meta info */
    clx_telm_int_mata_info_t meta_info;                   /* metadata info */
    uint32 attr_bmp;                                      /* clx_telm_int_device_attr_xxx flags */
} clx_telm_int_device_t;
#define CLX_TELM_INT_DEVICE_ATTR_DSCP_RESTORE (0x1U << 0) /* set or get int dscp restore */
#define CLX_TELM_INT_DEVICE_ATTR_INT_TRUNCATE (0x1U << 1) /* set or get int clone trancate */
#define CLX_TELM_INT_DEVICE_ATTR_INSTR_MASK   (0x1U << 2) /* set or get instruction mask  */
#define CLX_TELM_INT_DEVICE_ATTR_REP_EGR_PORT (0x1U << 3) /* set or get report egr port */
#define CLX_TELM_INT_DEVICE_ATTR_COLLECTOR    (0x1U << 4) /* set or get collector info */
#define CLX_TELM_INT_DEVICE_ATTR_MAX_HOP_CNT \
    (0x1U << 5)                                         /* set or get max hop cnt for meta header */
#define CLX_TELM_INT_DEVICE_ATTR_META_INFO (0x1U << 6)  /* set or get meta info */
#define CLX_TELM_INT_DEVICE_ATTR_ALL       (0xFFFFFFFF) /* set or get all */

typedef struct clx_telm_int_prof_s {
    uint32 sampling_rate; /* sampling rate for int profile */
    uint16 int_instr_bmp; /* CLX_TELM_INT_DEVICE_ATTR_XXX flags */
} clx_telm_int_prof_t;

typedef struct clx_telm_hop_cnt_zero_info_s {
    uint32 telm_type; /* telm type is int or ifa */
    uint32 node_id;   /* int node id */
} clx_telm_hop_cnt_zero_info_t;

typedef void (*clx_telm_hop_cnt_zero_func_t)(
    const uint32 unit,
    const clx_telm_hop_cnt_zero_info_t *ptr_hop_cnt_zero_info,
    void *ptr_cookie);

/* ioam struct */
typedef struct clx_telm_ioam_cfg_s {
    uint32 ipv4_next_prot;    /* ipv4 next protocol, for identify ioam header: 0xba */
    uint32 ipv6_hbh_opt_type; /* opt type in ipv6 hbh ext header: 0x11, high 3 bits=0 */

    /* if color_en=0, sample window size, clock frequency is 1.35ghz HAL_DEVICE_FREQ */
    uint32 color_disa_interval;

    uint32 color_en_interval_low;  /* if color_en=1, 40b sample interval low32 */
    uint32 color_en_interval_high; /* if color_en=1, 40b sample interval high*/
} clx_telm_ioam_cfg_t;

typedef struct clx_telm_ioam_fifo_entry_s {
    uint64 color_cnt;          /* 40b counter */
    uint32 color_en;           /* color enable flag */
    uint32 color;              /* color */
    uint32 flow_id;            /* ioam flow id */
    uint32 delay_en;           /* delay enable */
    uint32 igr_timestamp;      /* ingress timestamp */
    uint32 egr_timestamp;      /* egress timestamp */
    uint32 egr_timestamp_h16b; /* egress timestamp high 16b */
} clx_telm_ioam_fifo_entry_t;

typedef void (*clx_telm_ioam_fifo_read_func_t)(const uint32 unit,
                                               const clx_telm_ioam_fifo_entry_t *ptr_fifo_entry,
                                               void *ptr_cookie);

/* ifa struct */
typedef struct clx_telm_ifa_cfg_s {
    uint32 ip_prot;       /* ifa protocol type in ipv4/v6 header */
    uint32 lcl_namespace; /* local namespace in metadata */
} clx_telm_ifa_cfg_t;

typedef struct clx_telm_ifa_max_len_exceed_info_s {
    uint32 node_id;       /* node_id in metadata, set rwi_slv */
    uint32 lcl_namespace; /* local namespace in metadata */
} clx_telm_ifa_max_len_exceed_info_t;

typedef void (*clx_telm_ifa_max_len_exceed_func_t)(
    const uint32 unit,
    const clx_telm_ifa_max_len_exceed_info_t *ptr_max_len_exceed_info,
    void *ptr_cookie);

/* mod struct */
typedef enum clx_telm_mod_filter_type_e {
    CLX_TELM_MOD_FILTER_TYPE_NONE,
    CLX_TELM_MOD_FILTER_TYPE_BLOOM,
    CLX_TELM_MOD_FILTER_TYPE_LFSR,
    CLX_TELM_MOD_FILTER_TYPE_BOTH,
    CLX_TELM_MOD_FILTER_TYPE_LAST
} clx_telm_mod_filter_type_t;

typedef enum clx_telm_mod_compress_rate_e {
    CLX_TELM_MOD_COMPRESS_RATE_10_TO_1, /* 0-> 10:1 */
    CLX_TELM_MOD_COMPRESS_RATE_100_TO_1,
    CLX_TELM_MOD_COMPRESS_RATE_1000_TO_1,
    CLX_TELM_MOD_COMPRESS_RATE_10000_TO_1,
    CLX_TELM_MOD_COMPRESS_RATE_LAST
} clx_telm_mod_compress_rate_t;

typedef struct clx_telm_mod_reg_cfg_s {
    uint32 drp_rsn_bmp[2];   /* clx_pkt_drop_reason_t drop reason bitmap(64bits) */
    uint32 out_port;         /* report output port */
    uint32 out_queue;        /* queue of out port, ucq or mcq */

    uint32 report_instr_bmp; /* report instr bitmap, bit0 is drop reason */

    /* 2'b00:none, 2'b01:bloom, 2'b10:LFSR, 2'b11:bloom and LFSR. default:'b00 */
    clx_telm_mod_filter_type_t filter_type;

    /* filtertype=lfsr, 0->10:1, 1->100:1, 2->1000:1, 3->10000:1. Default: 10000:1 */
    clx_telm_mod_compress_rate_t compress_rate;
    uint32 bloom_timer; /* bloom filter reset by timer, unit is ns. range:1ns ~ 3s */
    uint32 bloom_th;    /* bloom filter reset by flow threshold, max: 1024 */
    /* mod truncate packets into a specific size */
    clx_telm_trunc_t mod_truncate;
    uint32 attr_bmp; /* CLX_TELM_MOD_REG_CFG_ATTR_XXX flags */
} clx_telm_mod_reg_cfg_t;
#define CLX_TELM_MOD_REG_CFG_ATTR_DROP_REASON   (0x1U << 0)  /* set or get drop reason bitmap */
#define CLX_TELM_MOD_REG_CFG_ATTR_OUT_PORT      (0x1U << 1)  /* set or get report output port */
#define CLX_TELM_MOD_REG_CFG_ATTR_OUT_QUEUE     (0x1U << 2)  /* set or get out queue */
#define CLX_TELM_MOD_REG_CFG_ATTR_INSTR_BMP     (0x1U << 3)  /* set or get report instr bitmap */
#define CLX_TELM_MOD_REG_CFG_ATTR_FILTER_TYPE   (0x1U << 4)  /* set or get filter type */
#define CLX_TELM_MOD_REG_CFG_ATTR_COMPRESS_RATE (0x1U << 5)  /* set or get compress rate */
#define CLX_TELM_MOD_REG_CFG_ATTR_MOD_TRUNC     (0x1U << 6)  /* set or get mod truncate */
#define CLX_TELM_MOD_REG_CFG_ATTR_BLOOM_TIMER   (0x1U << 7)  /* set or get bloom filter timer */
#define CLX_TELM_MOD_REG_CFG_ATTR_BLOOM_TH      (0x1U << 8)  /* set or get bloom filter pkt cnt */
#define CLX_TELM_MOD_REG_CFG_ATTR_ALL           (0xFFFFFFFF) /* set all */

typedef struct clx_telm_mod_cfg_s {
    /* config MOD register */
    clx_telm_mod_reg_cfg_t reg_cfg;

    /* config collector info */
    clx_telm_collector_cfg_info_t collector;

    uint32 attr_bmp;                                /* CLX_TELM_MOD_CFG_ATTR_XXX flags */
} clx_telm_mod_cfg_t;
#define CLX_TELM_MOD_CFG_ATTR_REGISTER  (0x1U << 0) /* set or get mod register */
#define CLX_TELM_MOD_CFG_ATTR_COLLECTOR (0x1U << 1) /* set or get collector info */

/* telm api */

/**
 * @brief This API is used to register a callback function that will be called
 *        whenever TELM IRQ trigger.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     irq_type      - The TELM IRQ type
 * @param [in]     cb            - The callback function of TELM IRQ
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors
 */
clx_error_no_t
clx_telm_notify_cb_register(const uint32 unit,
                            const clx_telm_irq_type_t irq_type,
                            const void *cb,
                            void *ptr_cookie);

/**
 * @brief This API is used to deregister a callback function
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number
 * @param [in]     irq_type      - The TELM IRQ type
 * @param [in]     cb            - The callback function of TELM IRQ
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors
 */
clx_error_no_t
clx_telm_notify_cb_deregister(const uint32 unit,
                              const clx_telm_irq_type_t irq_type,
                              const void *cb,
                              void *ptr_cookie);

/**
 * @brief Set telemetry configurations.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     cfg         - Config type
 * @param [in]     ptr_param   - Parameters
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
clx_error_no_t
clx_telm_cfg_set(const uint32 unit,
                 const clx_telm_cfg_t cfg,
                 const clx_telm_cfg_param_t *ptr_param);

/**
 * @brief Get telemetry configurations.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     cfg         - Config type
 * @param [out]    ptr_param   - Parameters
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 */
clx_error_no_t
clx_telm_cfg_get(const uint32 unit, const clx_telm_cfg_t cfg, clx_telm_cfg_param_t *ptr_param);

/* int api */

/**
 * @brief Set telemetry INT profile information with instruction bitmap and sample rate.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     prof_id              - Profile id.
 * @param [in]     ptr_prof_cfg         - INT profile config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_int_prof_set(const uint32 unit,
                      const uint32 prof_id,
                      const clx_telm_int_prof_t *ptr_prof_cfg);

/**
 * @brief Get telemetry profile information with ACL configuration and LFSR sampler.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     prof_id            - Profile id.
 * @param [out]    ptr_prof_cfg       - INT profile config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_int_prof_get(const uint32 unit, const uint32 prof_id, clx_telm_int_prof_t *ptr_prof_cfg);

/**
 * @brief Set telemetry domain and device information for INT usage.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_domain_cfg    - INT domain config.
 * @param [in]     ptr_device_cfg    - INT device config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_int_glb_set(const uint32 unit,
                     const clx_telm_int_domain_t *ptr_domain_cfg,
                     const clx_telm_int_device_t *ptr_device_cfg);

/**
 * @brief Get telemetry domain and device information for INT usage.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_domain_cfg    - TELM INT domain config.
 * @param [out]    ptr_device_cfg    - TELM INT device config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_int_glb_get(const uint32 unit,
                     clx_telm_int_domain_t *ptr_domain_cfg,
                     clx_telm_int_device_t *ptr_device_cfg);

/* ioam api */

/**
 * @brief Set telemetry ioam config information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_ioam_cfg    - ioam config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_ioam_cfg_set(const uint32 unit, const clx_telm_ioam_cfg_t *ptr_ioam_cfg);

/**
 * @brief Get telemetry configuration information for IOAM usage.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [out]    ptr_ioam_cfg    - TELM IOAM config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_ioam_cfg_get(const uint32 unit, clx_telm_ioam_cfg_t *ptr_ioam_cfg);

/* ifa api */

/**
 * @brief Set telemetry IFA config information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_ifa_cfg    - ifa config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_ifa_cfg_set(const uint32 unit, const clx_telm_ifa_cfg_t *ptr_ifa_cfg);

/**
 * @brief Get telemetry configuration information for IFA usage.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_ifa_cfg    - TELM IFA config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_ifa_cfg_get(const uint32 unit, clx_telm_ifa_cfg_t *ptr_ifa_cfg);

/* mod api */

/**
 * @brief Set telemetry MOD config information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_mod_cfg    - mod config information struct.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_mod_cfg_set(const uint32 unit, const clx_telm_mod_cfg_t *ptr_mod_cfg);

/**
 * @brief Get telemetry configuration information for MOD usage.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    ptr_mod_cfg    - TELM MOD config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_telm_mod_cfg_get(const uint32 unit, clx_telm_mod_cfg_t *ptr_mod_cfg);

#endif /* End of CLX_TELM_H */
