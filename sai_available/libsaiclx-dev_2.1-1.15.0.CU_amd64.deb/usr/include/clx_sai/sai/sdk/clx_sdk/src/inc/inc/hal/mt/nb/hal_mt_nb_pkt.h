/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_pkt.h
 * PURPOSE:
 *      It provides hal pkt module API.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_PKT_H
#define HAL_MT_NB_PKT_H

/* INCLUDE FILE DECLARTIONS
 */
#include <linux/include/nb/nb_chip.h>
#include <hal/hal_pkt_rsrc.h>

/* MACRO FUNCTION DECLARATIONS
 */
/*---------------------------------------------------------------------------*/
#if defined(CLX_EN_BIG_ENDIAN)
#define HAL_MT_NB_PKT_ENDIAN_SWAP32(val) (val)
#else
#define HAL_MT_NB_PKT_ENDIAN_SWAP32(val) UTIL_ENDIAN_SWAP32(val)
#endif
/*---------------------------------------------------------------------------*/
#define HAL_MT_NB_PKT_GET_BIT(flags, bit) ((((flags) & (bit)) > 0) ? 1 : 0)
/*---------------------------------------------------------------------------*/
#define HAL_MT_NB_PKT_GET_TX_INTR_TYPE(channel) (HAL_MT_INTR_TYPE_PDMA_NORMAL)
#define HAL_MT_NB_PKT_GET_RX_INTR_TYPE(channel) (HAL_MT_INTR_TYPE_PDMA_NORMAL)

/* RX packet Buffer Allocate Function  */
typedef void *(*hal_mt_nb_pkt_rx_alloc_func_t)(void);

/* RX Packet Buffer Free Function  */
typedef clx_error_no_t (*hal_mt_nb_pkt_rx_free_func_t)(const void *ptr_pkt_buf);

/*********************** TODO: clean up **********************/
#define HAL_MT_NB_PORT_NUM                 (256)
#define HAL_MT_NB_PORT_DI_MAX_NUM          (2048)
#define HAL_MT_NB_PKT_PDMA_MAX_GPD_PER_PKT (100) /* <= 256   */
/* CPU, CPI queue number */
#define HAL_MT_NB_PKT_CPU_QUE_NUM (48)
#define HAL_MT_NB_PKT_CPI_QUE_NUM (8)

/* Mode */
#define HAL_MT_NB_PKT_TX_WAIT_MODE (HAL_MT_NB_PKT_TX_WAIT_ASYNC)

/* TX Queue */
#define HAL_MT_NB_PKT_TX_TASK_MAX_LOOP (HAL_DFLT_CFG_PKT_TX_QUEUE_LEN)

/* RX Queue */
#define HAL_MT_NB_PKT_RX_QUEUE_NUM     (HAL_MT_NB_PKT_RX_CH_LAST)
#define HAL_MT_NB_PKT_RX_TASK_MAX_LOOP (HAL_DFLT_CFG_PKT_RX_QUEUE_LEN)

/* MAX TC*/
#define HAL_MT_NB_PKT_MAX_TC_NUM (0x7)

typedef nb_descriptor_t hal_mt_nb_pkt_tx_gpd_t;
typedef nb_descriptor_t hal_mt_nb_pkt_rx_gpd_t;

typedef enum hal_mt_nb_pkt_tx_ch_e {
    HAL_MT_NB_PKT_TX_CH_0 = 0,
    HAL_MT_NB_PKT_TX_CH_1,
    HAL_MT_NB_PKT_TX_CH_2,
    HAL_MT_NB_PKT_TX_CH_3,
    HAL_MT_NB_PKT_TX_CH_LAST

} hal_mt_nb_pkt_tx_ch_t;

typedef enum hal_mt_nb_pkt_rx_ch_e {
    HAL_MT_NB_PKT_RX_CH_0 = 0,
    HAL_MT_NB_PKT_RX_CH_1,
    HAL_MT_NB_PKT_RX_CH_2,
    HAL_MT_NB_PKT_RX_CH_3,
    HAL_MT_NB_PKT_RX_CH_LAST
} hal_mt_nb_pkt_rx_ch_t;

typedef struct hal_mt_nb_pkt_rx_sw_gpd_s {
    boolean rx_complete; /* FALSE when PDMA error occurs */
    hal_mt_nb_pkt_rx_gpd_t rx_gpd;
    union {
        nb_pkt_pph_l2_t *ptr_pph_l2;
        nb_pkt_pph_l3uc_t *ptr_pph_l3uc;
        nb_pkt_pph_l3mc_t *ptr_pph_l3mc;
        nb_pkt_pph_l25_t *ptr_pph_l25;
    };
    struct hal_mt_nb_pkt_rx_sw_gpd_s *ptr_next;

    void *ptr_cookie; /* Pointer of virt-addr */

} hal_mt_nb_pkt_rx_sw_gpd_t;

#define HAL_MT_NB_PKT_RX_CH(channel_offset) (channel_offset)
#define HAL_MT_NB_PKT_TX_CH(channel_offset) (channel_offset + 4)

typedef void (*hal_mt_nb_pkt_tx_func_t)(const uint32 unit,
                                        const void *ptr_sw_gpd, /* SW-GPD to be processed
                                                                 */
                                        void *ptr_coockie);     /* Private data of SDK     */

typedef struct hal_mt_nb_pkt_tx_sw_gpd_s {
    hal_mt_nb_pkt_tx_func_t callback; /* (unit, ptr_sw_gpd, ptr_cookie) */
    void *ptr_cookie;                 /* Pointer of clx_pkt_tx_pkt_t    */
    hal_mt_nb_pkt_tx_gpd_t tx_gpd;
    union {
        nb_pkt_pph_l2_t *ptr_pph_l2;
        nb_pkt_pph_l3uc_t *ptr_pph_l3uc;
        nb_pkt_pph_l3mc_t *ptr_pph_l3mc;
        nb_pkt_pph_l25_t *ptr_pph_l25;
    };
    uint32 gpd_num;
    struct hal_mt_nb_pkt_tx_sw_gpd_s *ptr_next;
    uint32 channel; /* For counter */
} hal_mt_nb_pkt_tx_sw_gpd_t;

typedef struct hal_mt_nb_pkt_tx_ch_cnt_s {
    uint32 send_ok;
    uint32 gpd_empty;
    uint32 poll_timeout;

    /* queue */
    uint32 enque_ok;
    uint32 enque_retry;

    /* event */
    uint32 trig_event;

    /* normal interrupt */
    uint32 tx_done;

    /* abnormal interrupt */
    uint32 rd_desc_err; /* bit-0  */
    uint32 wr_desc_err; /* bit-1  */
    uint32 rd_data_err; /* bit-2  */
    uint32 wr_data_err; /* bit-3  */

    /* others */
    uint32 err_recover;
    uint32 ecc_err;

} hal_mt_nb_pkt_tx_ch_cnt_t;

typedef struct hal_mt_nb_pkt_tx_cnt_s {
    hal_mt_nb_pkt_tx_ch_cnt_t channel[HAL_MT_NB_PKT_TX_CH_LAST];
    uint32 invoke_gpd_callback;
    uint32 no_memory;

    /* queue */
    uint32 deque_ok;
    uint32 deque_fail;

    /* event */
    uint32 wait_event;

} hal_mt_nb_pkt_tx_cnt_t;

typedef struct hal_mt_nb_pkt_rx_ch_cnt_s {
    /* queue */
    uint32 enque_ok;
    uint32 enque_retry;
    uint32 deque_ok;
    uint32 deque_fail;

    /* event */
    uint32 trig_event;

    /* normal interrupt */
    uint32 rx_done;

    /* abnormal interrupt */
    uint32 rd_desc_err; /* bit-0  */
    uint32 wr_desc_err; /* bit-1  */
    uint32 rd_data_err; /* bit-2  */
    uint32 wr_data_err; /* bit-3  */

    /* malform interrupt */
    uint32 p2h_rx_fifo_ovf; /* bit-10 11 12 13 */

    /* others */
    uint32 err_recover;
    uint32 ecc_err;

#if defined(CLX_EN_NETIF)
    /* it means that user doesn't create intf on that port */
    uint32 netdev_miss;
#endif

} hal_mt_nb_pkt_rx_ch_cnt_t;

typedef struct hal_mt_nb_pkt_rx_cnt_s {
    hal_mt_nb_pkt_rx_ch_cnt_t channel[HAL_MT_NB_PKT_RX_CH_LAST];
    uint32 invoke_gpd_callback;
    uint32 no_memory;

    /* event */
    uint32 wait_event;

} hal_mt_nb_pkt_rx_cnt_t;

typedef enum hal_mt_nb_pkt_cb_staus_e {
    HAL_MT_NB_PKT_C_NEXT = 0, /* callback continuous */
    HAL_MT_NB_PKT_C_STOP = 1,
    HAL_MT_NB_PKT_C_OTHERS = 2
} hal_mt_nb_pkt_cb_staus_t;

typedef enum hal_mt_nb_pkt_tx_wait_e {
    HAL_MT_NB_PKT_TX_WAIT_ASYNC = 0,
    HAL_MT_NB_PKT_TX_WAIT_SYNC_INTR = 1,
    HAL_MT_NB_PKT_TX_WAIT_SYNC_POLL = 2

} hal_mt_nb_pkt_tx_wait_t;

typedef enum hal_mt_nb_pkt_rx_sched_e {
    HAL_MT_NB_PKT_RX_SCHED_RR = 0,
    HAL_MT_NB_PKT_RX_SCHED_WRR = 1

} hal_mt_nb_pkt_rx_sched_t;

/* ----------------------------------------------------------------------------------- Deinit */
/**
 * @brief To de-initialize the Task for packet module.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_data    - The pointer of data.
 * @return        CLX_E_OK        - Successfully dinitialize the control block.
 * @return        CLX_E_OTHERS    - Initialize the control block failed.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_task_deinit(const uint32 unit, void *ptr_data);

/**
 * @brief To invoke the functions to de-initialize the control block for each PDMA subsystem.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_data    - The pointer of data.
 * @return        CLX_E_OK        - Successfully de-initialize the control blocks.
 * @return        CLX_E_OTHERS    - De-initialize the control blocks failed.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_deinit(const uint32 unit, void *ptr_data);

/* ----------------------------------------------------------------------------------- Init */
/**
 * @brief To initialize the Task for packet module.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_data    - The pointer of data.
 * @return        CLX_E_OK        - Successfully dinitialize the control block.
 * @return        CLX_E_OTHERS    - Initialize the control block failed.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_task_init(const uint32 unit, void *ptr_data);

/**
 * @brief To invoke the functions to initialize the control block for each PDMA subsystem.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_data    - The pointer of data.
 * @return        CLX_E_OK        - Successfully initialize the control blocks.
 * @return        CLX_E_OTHERS    - Initialize the control blocks failed.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_init(const uint32 unit, void *ptr_data);

/**
 * @brief To initialize the packet module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully initialize the packet module.
 * @return        CLX_E_OTHERS    - Initialize the packet module failed.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_pkt_srv_exit(const uint32 unit);

/**
 * @brief To perform the packet transmission form CPU to the switch.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    ptr_tx_pkt    - Pointer for the TX packet.
 * @return        CLX_E_OK    - Successfully perform the transferring.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_tx_gpd_send(const uint32 unit, const clx_pkt_tx_pkt_t *ptr_tx_pkt);

/*********************** TODO: clean up end**********************/

/* ----------------------------------------------------------------------------------- PP Type */
typedef struct hal_mt_nb_pkt_pph_s {
    union {
        nb_pkt_pph_l2_t pph_l2;
        nb_pkt_pph_l3uc_t pph_l3uc;
        nb_pkt_pph_l3mc_t pph_l3mc;
        nb_pkt_pph_l25_t pph_l25;
    };
} hal_mt_nb_pkt_pph_t;

/* ----------------------------------------------------------------------------------- Reg Type */
typedef enum hal_mt_nb_pkt_tx_ch_cfg_e {
    HAL_MT_NB_PKT_TX_CH_CFG_IOC = (0x1UL << 0),
    HAL_MT_NB_PKT_TX_CH_CFG_CHKSUM = (0x1UL << 1),
    HAL_MT_NB_PKT_TX_CH_CFG_PFC = (0x1UL << 2),
    HAL_MT_NB_PKT_TX_CH_CFG_PKT_LEN_CHK = (0x1UL << 3),
    HAL_MT_NB_PKT_TX_CH_CFG_EARLY_DONE_IRQ = (0x1UL << 4),
    HAL_MT_NB_PKT_TX_CH_CFG_CHK_COS = (0x1UL << 5),
    HAL_MT_NB_PKT_TX_CH_CFG_ADV_GPD_WRBK = (0x1UL << 6),
    HAL_MT_NB_PKT_TX_CH_CFG_GPD_WRBK_FULL_PKT_LEN = (0x1UL << 7),
    HAL_MT_NB_PKT_TX_CH_CFG_LAST = (0x1UL << 8)

} hal_mt_nb_pkt_tx_ch_cfg_t;

typedef enum hal_mt_nb_pkt_rx_ch_cfg_e {
    HAL_MT_NB_PKT_RX_CH_CFG_IOC = (0x1UL << 0),
    HAL_MT_NB_PKT_RX_CH_CFG_CHKSUM = (0x1UL << 1),
    HAL_MT_NB_PKT_RX_CH_CFG_LAST = (0x1UL << 2)

} hal_mt_nb_pkt_rx_ch_cfg_t;

/* ----------------------------------------------------------------------------------- Rx */

typedef hal_mt_nb_pkt_cb_staus_t (*hal_mt_nb_pkt_rx_func_t)(const uint32 unit,
                                                            const void *ptr_sw_gpd, /* SW-GPD to be
                                                                                       processed  */
                                                            void *ptr_cookie); /* Private data of
                                                                                  SDK     */

typedef struct hal_mt_nb_pkt_rx_cb_s {
    hal_mt_nb_pkt_rx_func_t callback; /* (unit, ptr_sw_gpd, ptr_cookie) */
    clx_pkt_rx_func_t cb;
    void *ptr_cookie;
    struct hal_mt_nb_pkt_rx_cb_s *ptr_next;
} hal_mt_nb_pkt_rx_cb_t;

/* ----------------------------------------------------------------------------------- Reg */
#if defined(CLX_EN_LITTLE_ENDIAN)

typedef union {
    uint32 reg;
    struct {
        uint32 tch_axlen_cfg : 3;
        uint32 : 5;
        uint32 tch_axi_free_arvalid : 1;
        uint32 : 7;
        uint32 tch_arvalid_thrhold_cfg : 2;
        uint32 : 6;
        uint32 tch_rready_low_4_hdr : 1;
        uint32 tch_ios_crdt_add_en : 1;
        uint32 : 6;
    } field;
} HAL_MT_NB_PKT_AXI_LEN_CFG_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 pdma_lbk_en : 1;
        uint32 : 3;
        uint32 pdma_lbk_plane : 2;
        uint32 : 2;
        uint32 pm_lbk_en : 1;
        uint32 : 7;
        uint32 pm_lbk_rqid : 6;
        uint32 : 2;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_LBK_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 pdma_lbk_rqid0 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid1 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid2 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid3 : 6;
        uint32 : 2;
    } field;
} HAL_MT_NB_PKT_LBK_RQID0_3_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 pdma_lbk_rqid4 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid5 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid6 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid7 : 6;
        uint32 : 2;
    } field;
} HAL_MT_NB_PKT_LBK_RQID4_7_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 cos_pfc_sts0 : 8;
        uint32 cos_pfc_sts1 : 8;
        uint32 cos_pfc_sts2 : 8;
        uint32 cos_pfc_sts3 : 8;
    } field;
} HAL_MT_NB_PKT_COS_PFC_STS_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 pdma_ela_en : 1;
        uint32 : 7;
        uint32 pdma_ela_valid_sel : 8;
        uint32 : 8;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_ELA_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 pdma_ela_word0_sel : 8;
        uint32 pdma_ela_word1_sel : 8;
        uint32 pdma_ela_word2_sel : 8;
        uint32 pdma_ela_word3_sel : 8;
    } field;
} HAL_MT_NB_PKT_ELA_SEL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 ingr_pln_ios_credit_base_size_lo : 8;
        uint32 ingr_pln_ios_credit_base_size_hi : 8;
        uint32 ingr_pln_ios_credit_set : 1;
        uint32 : 7;
        uint32 : 1;
        uint32 ingr_pln_full_pkt_mode : 1;
        uint32 : 6;
    } field;
} HAL_MT_NB_PKT_IGR_PLN_CREDIT_CFG_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 ingr_pln_cur_ios_credit_lo : 8;
        uint32 ingr_pln_cur_ios_credit_hi : 8;
        uint32 ingr_pln_ios_credit_ovfl : 1;
        uint32 ingr_pln_ios_credit_udfl : 1;
        uint32 : 6;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_IGR_PLN_CREDIT_STS_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 ingr_pln_ios_credit_rdy_lo_bound : 8;
        uint32 ingr_pln_ios_credit_rdy_hi_bound : 8;
        uint32 : 8;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_IGR_PLN_CREDIT_THR_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 rch_stomp_crc_en : 1;
        uint32 : 7;
        uint32 rch_crc_regen_en : 1;
        uint32 : 7;
        uint32 rch_pfc_fun_en : 1;
        uint32 : 7;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_RCH_STOMP_CRC_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 rch_ioc_en : 1;
        uint32 : 7;
        uint32 rch_chksm_en : 1;
        uint32 : 7;
        uint32 : 8;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_RCH_MISC_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 rch_gpd_pfc_lo : 8;
        uint32 rch_gpd_pfc_hi : 8;
        uint32 : 8;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_RCH_GPD_PFC_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 rch_fifo_pfc_lo_lo : 8;
        uint32 rch_fifo_pfc_lo_hi : 3;
        uint32 : 5;
        uint32 rch_fifo_pfc_hi_lo : 8;
        uint32 rch_fifo_pfc_hi_hi : 3;
        uint32 : 5;
    } field;
} HAL_MT_NB_PKT_RCH_FIFO_PFC_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 rch_cmdq_pfc_lo : 5;
        uint32 : 3;
        uint32 rch_cmdq_pfc_hi : 5;
        uint32 : 3;
        uint32 : 8;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_RCH_CMDQ_PFC_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 rch_fifo_ovf_drop_cnt_clr : 1;
        uint32 rch_cmdq_ovf_drop_cnt_clr : 1;
        uint32 rch_ovsz_drop_cnt_clr : 1;
        uint32 rch_udsz_drop_cnt_clr : 1;
        uint32 rch_pkterr_drop_cnt_clr : 1;
        uint32 rch_flush_cnt_clr : 1;
        uint32 : 2;
        uint32 : 8;
        uint32 : 8;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_RCH_CNT_CLR_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 rch_active : 1;
        uint32 rch_avbl_gpd_pfc : 1;
        uint32 rch_fifo_pfc : 1;
        uint32 rch_cmdq_pfc : 1;
        uint32 rch_pfc : 1;
        uint32 : 3;
        uint32 : 8;
        uint32 rch_avbl_gpd_no_lo : 8;
        uint32 rch_avbl_gpd_no_hi : 8;
    } field;
} HAL_MT_NB_PKT_RCH_STATUS_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 tch_ioc_en : 1;
        uint32 tch_chksm_en : 1;
        uint32 tch_pfc_en : 1;
        uint32 tch_pktlen_chk_en : 1;
        uint32 tch_early_done_irq : 1;
        uint32 tch_chk_cos_en : 1;
        uint32 tch_adv_gpd_wrbk : 1;
        uint32 tch_gpd_wrbk_full_pkt_len : 1;
        uint32 : 8;
        uint32 : 8;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_TCH_CFG_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 tch_active : 1;
        uint32 tch_pfc : 1;
        uint32 tch_gpd_rd_dma_act : 1;
        uint32 : 5;
        uint32 : 8;
        uint32 tch_avbl_gpd_no : 1;
        uint32 : 7;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_TCH_STS_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 tch_gpd_dmar_qos : 4;
        uint32 : 4;
        uint32 tch_pkt_dmar_qos : 4;
        uint32 : 4;
        uint32 tch_gpd_dmaw_qos : 4;
        uint32 : 4;
        uint32 : 8;
    } field;
} HAL_MT_NB_PKT_TCH_QOS_CFG_REG_T;

#elif defined(CLX_EN_BIG_ENDIAN)

typedef union {
    uint32 reg;
    struct {
        uint32 : 6;
        uint32 tch_ios_crdt_add_en : 1;
        uint32 tch_rready_low_4_hdr : 1;
        uint32 : 6;
        uint32 tch_arvalid_thrhold_cfg : 2;
        uint32 : 7;
        uint32 tch_axi_free_arvalid : 1;
        uint32 : 5;
        uint32 tch_axlen_cfg : 3;
    } field;
} HAL_MT_NB_PKT_AXI_LEN_CFG_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 2;
        uint32 pm_lbk_rqid : 6;
        uint32 : 7;
        uint32 pm_lbk_en : 1;
        uint32 : 2;
        uint32 pdma_lbk_plane : 2;
        uint32 : 3;
        uint32 pdma_lbk_en : 1;
    } field;
} HAL_MT_NB_PKT_LBK_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 2;
        uint32 pdma_lbk_rqid3 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid2 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid1 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid0 : 6;
    } field;
} HAL_MT_NB_PKT_LBK_RQID0_3_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 2;
        uint32 pdma_lbk_rqid7 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid6 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid5 : 6;
        uint32 : 2;
        uint32 pdma_lbk_rqid4 : 6;
    } field;
} HAL_MT_NB_PKT_LBK_RQID4_7_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 cos_pfc_sts3 : 8;
        uint32 cos_pfc_sts2 : 8;
        uint32 cos_pfc_sts1 : 8;
        uint32 cos_pfc_sts0 : 8;
    } field;
} HAL_MT_NB_PKT_COS_PFC_STS_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 8;
        uint32 pdma_ela_valid_sel : 8;
        uint32 : 7;
        uint32 pdma_ela_en : 1;
    } field;
} HAL_MT_NB_PKT_ELA_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 pdma_ela_word3_sel : 8;
        uint32 pdma_ela_word2_sel : 8;
        uint32 pdma_ela_word1_sel : 8;
        uint32 pdma_ela_word0_sel : 8;
    } field;
} HAL_MT_NB_PKT_ELA_SEL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 6;
        uint32 ingr_pln_full_pkt_mode : 1;
        uint32 : 1;
        uint32 : 7;
        uint32 ingr_pln_ios_credit_set : 1;
        uint32 ingr_pln_ios_credit_base_size_hi : 8;
        uint32 ingr_pln_ios_credit_base_size_lo : 8;
    } field;
} HAL_MT_NB_PKT_IGR_PLN_CREDIT_CFG_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 6;
        uint32 ingr_pln_ios_credit_udfl : 1;
        uint32 ingr_pln_ios_credit_ovfl : 1;
        uint32 ingr_pln_cur_ios_credit_hi : 8;
        uint32 ingr_pln_cur_ios_credit_lo : 8;
    } field;
} HAL_MT_NB_PKT_IGR_PLN_CREDIT_STS_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 8;
        uint32 ingr_pln_ios_credit_rdy_hi_bound : 8;
        uint32 ingr_pln_ios_credit_rdy_lo_bound : 8;
    } field;
} HAL_MT_NB_PKT_IGR_PLN_CREDIT_THR_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 7;
        uint32 rch_pfc_fun_en : 1;
        uint32 : 7;
        uint32 rch_crc_regen_en : 1;
        uint32 : 7;
        uint32 rch_stomp_crc_en : 1;
    } field;
} HAL_MT_NB_PKT_RCH_STOMP_CRC_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 8;
        uint32 : 7;
        uint32 rch_chksm_en : 1;
        uint32 : 7;
        uint32 rch_ioc_en : 1;
    } field;
} HAL_MT_NB_PKT_RCH_MISC_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 8;
        uint32 rch_gpd_pfc_hi : 8;
        uint32 rch_gpd_pfc_lo : 8;
    } field;
} HAL_MT_NB_PKT_RCH_GPD_PFC_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 5;
        uint32 rch_fifo_pfc_hi_hi : 3;
        uint32 rch_fifo_pfc_hi_lo : 8;
        uint32 : 5;
        uint32 rch_fifo_pfc_lo_hi : 3;
        uint32 rch_fifo_pfc_lo_lo : 8;
    } field;
} HAL_MT_NB_PKT_RCH_FIFO_PFC_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 8;
        uint32 : 3;
        uint32 rch_cmdq_pfc_hi : 5;
        uint32 : 3;
        uint32 rch_cmdq_pfc_lo : 5;
    } field;
} HAL_MT_NB_PKT_RCH_CMDQ_PFC_CTRL_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 8;
        uint32 : 8;
        uint32 : 2;
        uint32 rch_flush_cnt_clr : 1;
        uint32 rch_pkterr_drop_cnt_clr : 1;
        uint32 rch_udsz_drop_cnt_clr : 1;
        uint32 rch_ovsz_drop_cnt_clr : 1;
        uint32 rch_cmdq_ovf_drop_cnt_clr : 1;
        uint32 rch_fifo_ovf_drop_cnt_clr : 1;
    } field;
} HAL_MT_NB_PKT_RCH_CNT_CLR_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 rch_avbl_gpd_no_hi : 8;
        uint32 rch_avbl_gpd_no_lo : 8;
        uint32 : 8;
        uint32 : 3;
        uint32 rch_pfc : 1;
        uint32 rch_cmdq_pfc : 1;
        uint32 rch_fifo_pfc : 1;
        uint32 rch_avbl_gpd_pfc : 1;
        uint32 rch_active : 1;
    } field;
} HAL_MT_NB_PKT_RCH_STATUS_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 8;
        uint32 : 8;
        uint32 tch_gpd_wrbk_full_pkt_len : 1;
        uint32 tch_adv_gpd_wrbk : 1;
        uint32 tch_chk_cos_en : 1;
        uint32 tch_early_done_irq : 1;
        uint32 tch_pktlen_chk_en : 1;
        uint32 tch_pfc_en : 1;
        uint32 tch_chksm_en : 1;
        uint32 tch_ioc_en : 1;
    } field;
} HAL_MT_NB_PKT_TCH_CFG_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 7;
        uint32 tch_avbl_gpd_no : 1;
        uint32 : 8;
        uint32 : 5;
        uint32 tch_gpd_rd_dma_act : 1;
        uint32 tch_pfc : 1;
        uint32 tch_active : 1;
    } field;
} HAL_MT_NB_PKT_TCH_STS_REG_T;

typedef union {
    uint32 reg;
    struct {
        uint32 : 8;
        uint32 : 4;
        uint32 tch_gpd_dmaw_qos : 4;
        uint32 : 4;
        uint32 tch_pkt_dmar_qos : 4;
        uint32 : 4;
        uint32 tch_gpd_dmar_qos : 4;
    } field;
} HAL_MT_NB_PKT_TCH_QOS_CFG_REG_T;

#else
#error "Host GPD endian is not defined\n"
#endif

/* ----------------------------------------------------------------------------------- CLX_EN_NETIF
 */
#if defined(CLX_EN_NETIF)
#define HAL_MT_NB_PKT_DRIVER_MAJOR_NUM (10)
#define HAL_MT_NB_PKT_DRIVER_MINOR_NUM (252) /* DO NOT use MISC_DYNAMIC_MINOR */
#define HAL_MT_NB_PKT_DRIVER_NAME      "clx_netif"
#define HAL_MT_NB_PKT_DRIVER_PATH      "/dev/" HAL_MT_NB_PKT_DRIVER_NAME
#endif /* End of CLX_EN_NETIF */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* ----------------------------------------------------------------------------------- Debug APIs */
/**
 * @brief To display the PDMA registers.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    flags      - Reg type flag.
 * @param [in]    cookies    - The target channel.
 * @return        CLX_E_OK    - Successfully display the control block.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_reg_show(const uint32 unit, const uint32 flags, const void *cookies);

/**
 * @brief Set the queue info by RX queue,flags should specified.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ptr_queue_cfg    - The Pointer of the specified queue config.
 * @return        CLX_E_OK        - Operation is successful.
 * @return        CLX_E_OTHERS    - Fail.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_queue_cfg_set(const uint32 unit, const clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

/**
 * @brief Get the queue info by RX queue,flags should specified.
 *
 * @param [in]     unit             - Device unit number.
 * @param [out]    ptr_queue_cfg    - The Pointer of the specified queue config.
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Fail.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_queue_cfg_get(const uint32 unit, clx_pkt_rx_queue_cfg_t *ptr_queue_cfg);

/**
 * @brief To display the PDMA TX counters of the target channel.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    channel    - The target channel.
 * @return        CLX_E_OK    - Successfully display the counters.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_tx_dbg_cnt_show(const uint32 unit, const uint32 channel);

/**
 * @brief To display the PDMA RX counters of the target channel.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    channel    - The target channel.
 * @return        CLX_E_OK    - Successfully display the counters.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_rx_dbg_cnt_show(const uint32 unit, const uint32 channel);

/* ----------------------------------------------------------------------------------- Diag APIs */
/**
 * @brief To clear the PDMA RX counters of the target channel.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    channel       - The target channel.
 * @param [in]    ptr_tx_cnt    - Pointer for the counter.
 * @return        CLX_E_OK                 - Successfully get the counter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The channel is invalid.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_tx_cnt_get(const uint32 unit, const uint32 channel, clx_pkt_tx_cnt_t *ptr_tx_cnt);

/**
 * @brief To get the PDMA RX counters of the target channel.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    channel       - The target channel.
 * @param [in]    ptr_rx_cnt    - Pointer for the counter.
 * @return        CLX_E_OK                 - Successfully get the counter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The channel is invalid.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_rx_cnt_get(const uint32 unit, const uint32 channel, clx_pkt_rx_cnt_t *ptr_rx_cnt);

/**
 * @brief To clear the PDMA TX counters of the target channel.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    channel    - The target channel.
 * @return        CLX_E_OK    - Successfully clear the counters.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_tx_cnt_clear(const uint32 unit, const uint32 channel);

/**
 * @brief To clear the PDMA RX counters of the target channel.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    channel    - The target channel.
 * @return        CLX_E_OK    - Successfully clear the counters.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_rx_cnt_clear(const uint32 unit, const uint32 channel);

/**
 * @brief Get the packet and byte counters for a specific CPU reason code.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     cpu_reason           - The CPU reason code to get counters for.
 * @param [out]    ptr_rx_reason_cnt    - Pointer to store the counter values.
 * @return         CLX_E_OK        - Successfully get the counters.
 * @return         CLX_E_OTHERS    - Failed to get the counters.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_rx_reason_cnt_get(const uint32 unit,
                                    const clx_pkt_rx_reason_t cpu_reason,
                                    clx_pkt_rx_reason_cnt_t *ptr_rx_reason_cnt);

/**
 * @brief Clear the packet and byte counters for a specific CPU reason code.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cpu_reason    - The CPU reason code to clear counters for.
 * @return        CLX_E_OK        - Successfully clear the counters.
 * @return        CLX_E_OTHERS    - Failed to clear the counters.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_rx_reason_cnt_clear(const uint32 unit, const clx_pkt_rx_reason_t cpu_reason);

/* ----------------------------------------------------------------------------------- pkt_srv */
/**
 * @brief To transfer the packet form CPU to the switch.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    ptr_tx_pkt    - Pointer for the TX packet.
 * @return        CLX_E_OK    - Successfully transfer the packet.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_tx_send(const uint32 unit, const clx_pkt_tx_pkt_t *ptr_tx_pkt);

/**
 * @brief To prepare tx packet.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_pkt         - The packet structure of the TX packet.
 * @param [in]    ptr_data_buf    - The buffer payload.
 * @param [in]    len             - The packet length.
 * @return        CLX_E_OK        - Operation is successful.
 * @return        CLX_E_OTHERS    - Fail.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_tx_prepare(const uint32 unit,
                             clx_pkt_tx_pkt_t *ptr_pkt,
                             const uint8 *ptr_data_buf,
                             uint32 len);

/**
 * @brief To invoke the user callback function for the RX packet.
 *
 * The packet will also be store in the packet monitor.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    ptr_rx_pkt    - Pointer for the rx packet.
 * @param [in]    ptr_cookie    - The Rx callback cookie.
 * @return        CLX_E_OK    - Successfully invoke the callback function.
 */
hal_mt_nb_pkt_cb_staus_t
hal_mt_nb_pkt_srv_rx_usr_cb_invoke(const uint32 unit,
                                   clx_pkt_rx_pkt_t *ptr_rx_pkt,
                                   void *ptr_cookie);

/**
 * @brief To invoke the cpu forward callback function for the RX packet.
 *
 * The packet will also be store in the packet monitor.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    ptr_sw_gpd    - Pointer for the SW Rx GPD link list.
 * @param [in]    ptr_cookie    - The Rx callback cookie.
 * @return        CLX_E_OK    - Successfully invoke the callback function.
 */
hal_mt_nb_pkt_cb_staus_t
hal_mt_nb_pkt_srv_forward_to_cpu_set(const uint32 unit, const void *ptr_sw_gpd, void *ptr_cookie);

/* ----------------------------------------------------------------------------------- Rx Init */
/**
 * @brief To register a callback function for receiving RX packet.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    func          - The callback function.
 * @param [in]    ptr_cookie    - The pointer for the private data.
 * @param [in]    action        - To insert, append, delete or delete all.
 * @return        CLX_E_OK        - Successfully register the callback.
 * @return        CLX_E_OTHERS    - Register the callback failed.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_rx_gpd_cb_set(const uint32 unit,
                                const hal_mt_nb_pkt_rx_func_t func,
                                void *ptr_cookie,
                                const HAL_PKT_RX_CALLBACK_ACTION_T action);

/**
 * @brief To register a callback function for receiving RX packet.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    flags      - The callback flags.
 * @param [in]    action     - The callback list action.
 * @param [in]    cookies    - The pointer for the private data.
 * @return        CLX_E_OK        - Successfully register the callback.
 * @return        CLX_E_OTHERS    - Register the callback failed.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_rx_gdp_cb_list_set(const uint32 unit,
                                     const uint32 flags,
                                     HAL_PKT_RX_CALLBACK_ACTION_T action,
                                     void *cookies);
/**
 * @brief To transfer rx_alloc,rx_free from srv to drv layer.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    rx_alloc    - Rx alloc func.
 * @param [in]    rx_free     - Rx free func.
 * @return        CLX_E_OK        - Successfully configure the RX parameters.
 * @return        CLX_E_OTHERS    - Configure the parameter failed.
 */
void
hal_mt_nb_pkt_drv_rx_pkt_cfg_set(const uint32 unit,
                                 const hal_mt_nb_pkt_rx_alloc_func_t rx_alloc,
                                 const hal_mt_nb_pkt_rx_free_func_t rx_free);

/**
 * @brief To set port map in kernel module.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Phy port.
 * @return        CLX_E_OK        - Successfully dinitialize the control block.
 * @return        CLX_E_OTHERS    - Initialize the control block failed.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_port_map_set(const uint32 unit, const uint32 port);

/**
 * @brief To clear port map in kernel module.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Phy port.
 * @return        CLX_E_OK        - Successfully dinitialize the control block.
 * @return        CLX_E_OTHERS    - Initialize the control block failed.
 */
clx_error_no_t
hal_mt_nb_pkt_drv_port_map_clear(const uint32 unit, const uint32 port);

/**
 * @brief Rx init.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully configure the RX parameters.
 * @return        CLX_E_OTHERS    - Configure the parameter failed.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_rx_init(const uint32 unit);

/**
 * @brief Rx deinit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully configure the RX parameters.
 * @return        CLX_E_OTHERS    - Configure the parameter failed.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_rx_deinit(const uint32 unit);

/**
 * @brief Rx callback register.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cb            - The rx callback func.
 * @param [in]    ptr_cookie    - The Pointer of the rx callback func cookie.
 * @param [in]    op_mode       - The Operate mode of the rx callback func.
 * @return        CLX_E_OK        - Successfully configure the RX parameters.
 * @return        CLX_E_OTHERS    - Configure the parameter failed.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_rx_cb_set(const uint32 unit,
                            const clx_pkt_rx_func_t cb,
                            void *ptr_cookie,
                            const clx_pkt_cb_op_t op_mode);

/**
 * @brief To set rx_alloc,rx_free from srv to drv layer.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    alloc_cb    - Rx alloc func.
 * @param [in]    free_cb     - Rx free func.
 * @return        CLX_E_OK        - Successfully configure the RX parameters.
 * @return        CLX_E_OTHERS    - Configure the parameter failed.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_udf_rx_mem_cb_set(const uint32 unit,
                                    const clx_pkt_rx_alloc_func_t alloc_cb,
                                    const clx_pkt_rx_free_func_t free_cb);

/* ----------------------------------------------------------------------------------- Deinit */
/**
 * @brief To de-initialize the packet module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully de-initialize the packet module.
 * @return        CLX_E_OTHERS    - De-initialize the packet module failed.
 */
clx_error_no_t
hal_mt_nb_pkt_srv_deinit(const uint32 unit);

/* ----------------------------------------------------------------------------------- NETIF APIs */
clx_error_no_t
hal_mt_nb_pkt_drv_intf_create(const uint32 unit,
                              const clx_netif_intf_t *ptr_net_intf,
                              uint32 *ptr_intf_id);

clx_error_no_t
hal_mt_nb_pkt_drv_intf_destroy(const uint32 unit, const uint32 id);

clx_error_no_t
hal_mt_nb_pkt_drv_intf_get(const uint32 unit, const uint32 intf_id, clx_netif_intf_t *ptr_net_intf);

clx_error_no_t
hal_mt_nb_pkt_drv_intf_set(const uint32 unit,
                           const uint32 intf_id,
                           const clx_netif_intf_t *ptr_net_intf);

clx_error_no_t
hal_mt_nb_pkt_drv_prof_create(const uint32 unit,
                              const clx_netif_prof_t *ptr_net_profile,
                              uint32 *ptr_prof_id);

clx_error_no_t
hal_mt_nb_pkt_drv_prof_destroy(const uint32 unit, const uint32 id);

clx_error_no_t
hal_mt_nb_pkt_drv_prof_get(const uint32 unit,
                           const uint32 prof_id,
                           clx_netif_prof_t *ptr_net_profile);

clx_error_no_t
hal_mt_nb_pkt_drv_intf_cnt_get(const uint32 unit,
                               const uint32 id,
                               clx_netif_intf_cnt_t *ptr_intf_cnt);

clx_error_no_t
hal_mt_nb_pkt_drv_intf_cnt_clear(const uint32 unit, const uint32 id);

clx_error_no_t
hal_mt_nb_pkt_drv_intf_rx_reason_cnt_get(const uint32 unit,
                                         const uint32 intf_id,
                                         const clx_pkt_rx_reason_t cpu_reason,
                                         clx_netif_rx_reason_cnt_t *ptr_rx_reason_cnt);

clx_error_no_t
hal_mt_nb_pkt_drv_intf_rx_reason_cnt_clear(const uint32 unit,
                                           const uint32 intf_id,
                                           const clx_pkt_rx_reason_t cpu_reason);

clx_error_no_t
hal_mt_nb_pkt_drv_ifa_cfg_set(const uint32 unit, const clx_netif_ifa_cfg_t *ptr_ifa_cfg);

clx_error_no_t
hal_mt_nb_pkt_drv_ifa_cfg_get(const uint32 unit, clx_netif_ifa_cfg_t *ptr_ifa_cfg);

clx_error_no_t
hal_mt_nb_pkt_drv_netlink_create(const uint32 unit,
                                 const clx_netif_netlink_t *ptr_netlink,
                                 uint32 *ptr_netlink_id);

clx_error_no_t
hal_mt_nb_pkt_drv_netlink_destroy(const uint32 unit, const uint32 netlink_id);

clx_error_no_t
hal_mt_nb_pkt_drv_netlink_get(const uint32 unit,
                              const uint32 netlink_id,
                              clx_netif_netlink_t *ptr_netlink);

clx_error_no_t
hal_mt_nb_pkt_drv_db_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_mt_nb_pkt_drv_reg_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_mt_nb_pkt_drv_virt_to_phy_convert(const uint32 unit,
                                      void *ptr_virt_addr,
                                      clx_addr_t *ptr_phy_addr);

clx_error_no_t
hal_mt_nb_pkt_drv_phy_to_virt_convert(const uint32 unit,
                                      clx_addr_t phy_addr,
                                      void **pptr_virt_addr);

clx_error_no_t
hal_mt_nb_pkt_srv_tx_sample_send(const uint32 unit,
                                 const uint32 i_channel,
                                 const uint32 i_port,
                                 const uint32 i_len,
                                 const uint32 i_num,
                                 clx_mac_t *p_dmac,
                                 clx_mac_t *p_smac,
                                 const char *p_payload);

clx_error_no_t
hal_mt_nb_pkt_drv_clxport_to_phyport_di_convert(const uint32 unit,
                                                const clx_port_t clx_port,
                                                uint32 *ptr_phy_port_di);

clx_error_no_t
hal_mt_nb_pkt_drv_clxport_to_phyport_convert(const uint32 unit,
                                             const clx_port_t clx_port,
                                             uint32 *ptr_port);

clx_error_no_t
hal_mt_nb_pkt_drv_phyport_di_to_clxport_convert(const uint32 unit,
                                                const uint32 phy_port_di,
                                                clx_port_t *ptr_clx_port);

clx_error_no_t
hal_mt_nb_pkt_drv_mod_mac_set(const uint32 unit, clx_mac_t mod_dmac);

clx_error_no_t
hal_mt_nb_pkt_drv_mod_mac_get(const uint32 unit, clx_mac_t mod_dmac);

#endif /* End of HAL_MT_NB_PKT_H */
