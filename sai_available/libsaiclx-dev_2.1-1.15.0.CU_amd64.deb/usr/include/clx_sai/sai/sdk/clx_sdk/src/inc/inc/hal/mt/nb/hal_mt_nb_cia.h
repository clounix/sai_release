/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_cia.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_CIA_H
#define HAL_MT_NB_CIA_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_cia.h>
#include <hal/hal_cia.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_CIA_UDF_INT_KEY_VLD_BMP_EXACT                                          \
    (CLX_CIA_UDF_INTERNAL_KEY_L2_SA_GRP_LBL | CLX_CIA_UDF_INTERNAL_KEY_L2_DA_GRP_LBL |   \
     CLX_CIA_UDF_INTERNAL_KEY_L3_SA_GRP_LBL | CLX_CIA_UDF_INTERNAL_KEY_L3_DA_GRP_LBL |   \
     CLX_CIA_UDF_INTERNAL_KEY_INTF_GRP_LBL | CLX_CIA_UDF_INTERNAL_KEY_RANGE |            \
     CLX_CIA_UDF_INTERNAL_KEY_BDID | CLX_CIA_UDF_INTERNAL_KEY_VRF |                      \
     CLX_CIA_UDF_INTERNAL_KEY_TCP_FLAGS | CLX_CIA_UDF_INTERNAL_KEY_STAG_VID |            \
     CLX_CIA_UDF_INTERNAL_KEY_CTAG_VID | CLX_CIA_UDF_INTERNAL_KEY_STAG_PCP_DEI |         \
     CLX_CIA_UDF_INTERNAL_KEY_CTAG_PCP_DEI | CLX_CIA_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q | \
     CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE)
#define HAL_MT_NB_CIA_UDF_INT_KEY_VLD_BMP_IGR                                            \
    (CLX_CIA_UDF_INTERNAL_KEY_INTF_GRP_LBL | CLX_CIA_UDF_INTERNAL_KEY_RANGE |            \
     CLX_CIA_UDF_INTERNAL_KEY_BDID | CLX_CIA_UDF_INTERNAL_KEY_VRF |                      \
     CLX_CIA_UDF_INTERNAL_KEY_TCP_FLAGS | CLX_CIA_UDF_INTERNAL_KEY_STAG_VID |            \
     CLX_CIA_UDF_INTERNAL_KEY_CTAG_VID | CLX_CIA_UDF_INTERNAL_KEY_STAG_PCP_DEI |         \
     CLX_CIA_UDF_INTERNAL_KEY_CTAG_PCP_DEI | CLX_CIA_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q | \
     CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE | CLX_CIA_UDF_INTERNAL_KEY_PORT_BMP)
#define HAL_MT_NB_CIA_UDF_INT_KEY_VLD_BMP_EGR                                 \
    (CLX_CIA_UDF_INTERNAL_KEY_RANGE | CLX_CIA_UDF_INTERNAL_KEY_BDID |         \
     CLX_CIA_UDF_INTERNAL_KEY_TCP_FLAGS | CLX_CIA_UDF_INTERNAL_KEY_L3_ROUTE | \
     CLX_CIA_UDF_INTERNAL_KEY_IGR_CIA_GRP_LBL)

#define HAL_MT_NB_CIA_UDF_0_PKG_TLV_BASE_ID (0)
#define HAL_MT_NB_CIA_ACTION_FLAGS_IGR                                                          \
    (CLX_CIA_ACT_FLAGS_METER_VLD | CLX_CIA_ACT_FLAGS_COUNTER_VLD |                              \
     CLX_CIA_ACT_FLAGS_DIST_COUNTER_VLD | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND |               \
     CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW |             \
     CLX_CIA_ACT_FLAGS_CANCEL_LEARN | CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_REDIR | \
     CLX_CIA_ACT_FLAGS_DROP | CLX_CIA_ACT_FLAGS_PKT_FCM | CLX_CIA_ACT_FLAGS_KEEP_TTL |          \
     CLX_CIA_ACT_FLAGS_TELM_ACT_VLD | CLX_CIA_ACT_FLAGS_XOR_LFSR |                              \
     CLX_CIA_ACT_FLAGS_ALLOW_TRUNCATE | CLX_CIA_ACT_FLAGS_FORCE_DECAP |                         \
     CLX_CIA_ACT_FLAGS_MIR_POLICER_VLD | CLX_CIA_ACT_FLAGS_BYPASS_TTL_CHECK_FAIL |              \
     CLX_CIA_ACT_FLAGS_BYPASS_RPF_CHECK_FAIL | CLX_CIA_ACT_FLAGS_VID_ACT_VLD |                  \
     CLX_CIA_ACT_FLAGS_UDF_RSN_VLD)

#define HAL_MT_NB_CIA_ACTION_FLAGS_EGR                                                            \
    (CLX_CIA_ACT_FLAGS_METER_VLD | CLX_CIA_ACT_FLAGS_COUNTER_VLD |                                \
     CLX_CIA_ACT_FLAGS_DIST_COUNTER_VLD | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_BLIND |                 \
     CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_RED | CLX_CIA_ACT_FLAGS_QOS_ACT_COLOR_YELLOW |               \
     CLX_CIA_ACT_FLAGS_COPY_TO_CPU | CLX_CIA_ACT_FLAGS_DROP | CLX_CIA_ACT_FLAGS_MIR_POLICER_VLD | \
     CLX_CIA_ACT_FLAGS_UDF_RSN_VLD)

#define HAL_MT_NB_CIA_IGR_CIA_GROUP_LABEL_LSB_VLD_BITS (16)
#define HAL_MT_NB_CIA_REWR_PAGE_NUM                    (32)
#define HAL_MT_NB_CIA_IGR_UCP_DEFAULT_NUM              (24)
#define HAL_MT_NB_CIA_EGR_UCP_DEFAULT_NUM              (8)
#define HAL_MT_NB_CIA_EGR_UCP_16K_NUM                  (32)
#define HAL_MT_NB_CIA_EGR_UCP_12K_NUM                  (24)
#define HAL_MT_NB_CIA_EGR_UCP_8K_NUM                   (16)
#define HAL_MT_NB_CIA_EGR_UCP_0K_NUM                   (0)
#define HAL_MT_NB_CIA_IGR_UCP_16K_NUM                  (32)
#define HAL_MT_NB_CIA_IGR_UCP_8K_NUM                   (16)
#define HAL_MT_NB_CIA_IGR_UCP_4K_NUM                   (8)
#define HAL_MT_NB_CIA_IGR_UCP_0K_NUM                   (0)
#define HAL_MT_NB_CIA_IGR_UCP_NUM                      (24)
#define HAL_MT_NB_CIA_EGR_UCP_NUM                      (8)
#define HAL_MT_NB_CIA_IGR_POST_UCP_NUM                 (HAL_MT_NB_CIA_IGR_UCP_NUM)
#define HAL_MT_NB_CIA_EGR_POST_UCP_NUM                 (HAL_MT_NB_CIA_EGR_UCP_NUM)
#define HAL_MT_NB_CIA_EXACT_UCP_NUM                    (24)
#define HAL_MT_NB_CIA_IGR_GROUP_NUM                    (12)
#define HAL_MT_NB_CIA_EGR_GROUP_NUM                    (4)
#define HAL_MT_NB_CIA_IGR_POST_GROUP_NUM               (HAL_MT_NB_CIA_IGR_GROUP_NUM)
#define HAL_MT_NB_CIA_EGR_POST_GROUP_NUM               (HAL_MT_NB_CIA_EGR_GROUP_NUM)
#define HAL_MT_NB_CIA_EXACT_GROUP_NUM                  (24)
#define HAL_MT_NB_CIA_UCP_ENTRY_NUM                    (512)
#define HAL_MT_NB_CIA_UCP_ENTRY_BITS                   (9)
#define HAL_MT_NB_CIA_IGR_ENTRY_NUM                    (HAL_MT_NB_CIA_IGR_UCP_NUM * HAL_MT_NB_CIA_UCP_ENTRY_NUM)
#define HAL_MT_NB_CIA_EGR_ENTRY_NUM                    (HAL_MT_NB_CIA_EGR_UCP_NUM * HAL_MT_NB_CIA_UCP_ENTRY_NUM)

#define HAL_MT_NB_CIA_IGR_POST_ENTRY_NUM \
    (HAL_MT_NB_CIA_IGR_POST_UCP_NUM * HAL_MT_NB_CIA_UCP_ENTRY_NUM)
#define HAL_MT_NB_CIA_EGR_POST_ENTRY_NUM \
    (HAL_MT_NB_CIA_EGR_POST_UCP_NUM * HAL_MT_NB_CIA_UCP_ENTRY_NUM)
#define HAL_MT_NB_CIA_FPU_1_LEVEL_START  (HAL_EXACT_BMP_LEVEL_MAX / 2)
#define HAL_MT_NB_CIA_FPU_1_GROUP_OFFSET (HAL_CIA_EXACT_GRP_NUM_MAX / 2)
#define HAL_MT_NB_CIA_TBL_ENTRY_GET(__unit__, __entry_1x_id__, __stage__, __tbl_entry_id__)       \
    do {                                                                                          \
        uint32 ucp_num = 0;                                                                       \
        if ((CLX_CIA_STAGE_IGR == __stage__) || (CLX_CIA_STAGE_IGR_POST == __stage__)) {          \
            __tbl_entry_id__ = __entry_1x_id__;                                                   \
        } else if (CLX_CIA_STAGE_EGR == __stage__) {                                              \
            hal_mt_cia_ucp_num_get(unit, CLX_CIA_STAGE_IGR, &ucp_num);                            \
            __tbl_entry_id__ =                                                                    \
                (__entry_1x_id__ + (ucp_num * PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_num)); \
        } else if (CLX_CIA_STAGE_EGR_POST == __stage__) {                                         \
            hal_mt_cia_ucp_num_get(unit, CLX_CIA_STAGE_IGR_POST, &ucp_num);                       \
            __tbl_entry_id__ =                                                                    \
                (__entry_1x_id__ + (ucp_num * PTR_HAL_CONST_INFO(__unit__, cia)->ucp_entry_num)); \
        } else {                                                                                  \
            __tbl_entry_id__ = HAL_INVALID_ID;                                                    \
        }                                                                                         \
    } while (0)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_nb_cia_ucp_cfg_set(const uint32 unit,
                          const uint32 type,
                          const uint32 tbl_id,
                          const uint32 ucp_id,
                          const hal_ucp_frm_type_t frame_type,
                          uint32 *ptr_buf);

clx_error_no_t
hal_mt_nb_cia_hw_entry_add(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 entry_1x_id,
                           const uint32 norm_width,
                           const hal_cia_plane_bcast_info_t *ptr_bcast_info,
                           uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

clx_error_no_t
hal_mt_nb_cia_hw_entry_vld_set(const uint32 unit,
                               const clx_cia_stage_t stage,
                               const uint32 hw_entry_id,
                               const uint32 norm_width,
                               const boolean entry_valid);

clx_error_no_t
hal_mt_nb_cia_hw_entry_read(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 entry_1x_id,
                            const uint32 norm_width,
                            uint32 (*ptr_entry_2d_buf)[HAL_CIA_ENTRY_WORDS]);

clx_error_no_t
hal_mt_nb_cia_hw_entry_del(const uint32 unit,
                           const clx_cia_stage_t stage,
                           const uint32 entry_1x_id,
                           const uint32 norm_width);

clx_error_no_t
hal_mt_nb_cia_cont_hw_entry_clear(const uint32 unit,
                                  const clx_cia_stage_t stage,
                                  const uint32 start_1x_entry,
                                  const uint32 last_1x_entry);

clx_error_no_t
hal_mt_nb_cia_hw_entry_move(const uint32 unit,
                            const clx_cia_stage_t stage,
                            const uint32 tbl_id,
                            const int32 src_1x_entry_id,
                            const int32 dst_1x_entry_id,
                            const uint32 tot_1x_move_entry_num,
                            const drv_dma_d2d_dir_t d2d_dir,
                            const uint32 shift_cnt,
                            const uint32 cont_move);

clx_error_no_t
hal_mt_nb_cia_move_tbl_id_get(const uint32 unit,
                              const clx_cia_stage_t stage,
                              const uint32 norm_width,
                              uint32 *ptr_tbl_id);

#endif /* End of HAL_MT_NB_CIA_H */
