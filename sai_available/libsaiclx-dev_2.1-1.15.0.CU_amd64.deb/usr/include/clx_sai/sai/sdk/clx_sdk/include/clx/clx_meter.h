/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_meter.h
 * PURPOSE:
 *      Define the declaration for Meter module in CLX SDK.
 *
 * NOTES:
 *      None
 *
 */

#ifndef CLX_METER_H
#define CLX_METER_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* Invalid Meter ID */
#define CLX_METER_INVALID_ID (0xFFFFFFFF)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* Meter Parameter */
typedef struct clx_meter_param_s {
    uint32 cir;     /* cir, unit: 1kbps or 1pps        */
    uint32 cbs;     /* cbs, unit: 1byte or 1pkt        */
    uint32 pir_eir; /* pir or eir, unit: 1kbps or 1pps */
    uint32 pbs_ebs; /* pbs or ebs, unit: 1byte or 1pkt */
} clx_meter_param_t;

/* Meter Algorithm */
typedef enum clx_meter_algo_e {
    CLX_METER_ALGO_SRTCM = 0, /* SrTCM                 */
    CLX_METER_ALGO_TRTCM,     /* TrTCM                 */
    CLX_METER_ALGO_MTRTCM,    /* modified TrTCM        */
    CLX_METER_ALGO_1R2CM,     /* single rate two color */
    CLX_METER_ALGO_LAST
} clx_meter_algo_t;

/* Meter Configuration */
typedef struct clx_meter_cfg_s {
    uint32 flags;               /* Refer to CLX_METER_CFG_FLAGS_XXX             */
    clx_meter_algo_t algo_mode; /* Meter Algorithm */
    clx_meter_param_t param;    /* Bucket cir/cbs/pir/pbs/eir/ebs */
} clx_meter_cfg_t;

#define CLX_METER_CFG_FLAGS_COLOR_AWARE (1U << 0) /* bit on: color aware; bit off: color blind */
#define CLX_METER_CFG_FLAGS_LAYER1      (1U << 1) /* bit on: layer 1; bit off: layer 2            */
#define CLX_METER_CFG_FLAGS_PORT_BASED  (1U << 2) /* bit on: port based; bit off: device based */
#define CLX_METER_CFG_FLAGS_PACKET_RATE (1U << 3) /* bit on: packet rate; bit off: bit rate */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Get a meter configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     meter_id         - The ID of the meter
 * @param [out]    ptr_cfg          - The configuration information of the created meter
 * @return         CLX_E_OK                 - Operation success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified Meter has not been created
 * @return         CLX_E_OTHERS             - Other errors
 */
clx_error_no_t
clx_meter_get(const uint32 unit, const uint32 meter_id, clx_meter_cfg_t *ptr_cfg);

/**
 * @brief Destroy the meter of the assigned ID.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     meter_id    - The ID of the meter to be destroyed
 * @return         CLX_E_OK                 - Operation success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - The specified Meter has not been created
 * @return         CLX_E_OTHERS             - Other errors
 */
clx_error_no_t
clx_meter_destroy(const uint32 unit, const uint32 meter_id);

/**
 * @brief Create a meter for interface (Rx(ingress)/ Tx(egress)),
 *        domain (Forwarding Domain or VRF), or flow (ingress ACL or egress ACL).
 *
 * The meter configurations except rate and bucket size are not modified.
 * However, if user needs to modify these configurations, user should delete
 * the meter and create a new one.
 * Meter ID is used to present a meter; it can be used by destroying, getting,
 * and setting functions to operate the specified meter.
 * If user needs to use a meter, the meter should be bound to an object (e.g.
 * interface, domain, acl rule). When a meter is not used, it should be unbound
 * from the object (e.g. interface, domain, acl rule).
 * For CBS/EBS/PBS setting, the suggestive value is CBS/EBS/PBS = CIR/EIR/PIR *
 * 125 us, the best value maybe less than the suggestive value.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     ptr_cfg          - The configuration of the created meter
 * @param [out]    ptr_meter_id     - The logical ID of the created meter
 * @return         CLX_E_OK               - Operation success
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter
 * @return         CLX_E_TABLE_FULL       - There is no Meter to serve
 * @return         CLX_E_OTHERS           - Other errors
 */
clx_error_no_t
clx_meter_create(const uint32 unit, const clx_meter_cfg_t *ptr_cfg, uint32 *ptr_meter_id);

/**
 * @brief Modify a meter rate and burst (bucket) size.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit               - Device unit number
 * @param [in]     meter_id           - It indicates the meter to be set
 * @param [in]     ptr_param    - The new configuration
 * @return         CLX_E_OK                 - Operation success
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter
 * @return         CLX_E_ENTRY_NOT_FOUND    - The meter does not exist.
 * @return         CLX_E_OTHERS             - Other errors
 */
clx_error_no_t
clx_meter_param_set(const uint32 unit, const uint32 meter_id, const clx_meter_param_t *ptr_param);

#endif
