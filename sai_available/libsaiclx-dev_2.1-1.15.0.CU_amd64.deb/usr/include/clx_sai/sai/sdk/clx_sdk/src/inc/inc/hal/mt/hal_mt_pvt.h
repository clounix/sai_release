/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_pvt.h
 * PURPOSE:
 *    It provides HAL driver API functions for PVT module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_MT_PVT_H
#define HAL_MT_PVT_H

#ifdef __cplusplus
extern "C" {
#endif
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <osal/osal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_PVT_REASON_PRIORITY_MIN (0)

/*
 * Multiplies an integer by a fraction, while avoiding unnecessary
 * overflow or loss of precision.
 */
#define HAL_MT_PVT_MULT_FRAC(x, numer, denom)           \
    ({                                                  \
        typeof(x) quot = (x) / (denom);                 \
        typeof(x) rem = (x) % (denom);                  \
        (quot * (numer)) + ((rem * (numer)) / (denom)); \
    })

#define HAL_MT_PVT_RESULT_CHECK(rc, sema, mem) \
    if ((rc) != CLX_E_OK) {                    \
        if (sema) {                            \
            osal_semaphore_give(sema);         \
        }                                      \
        if (mem) {                             \
            osal_free(mem);                    \
        }                                      \
        return (rc);                           \
    }

/* DATA TYPE DECLARATIONS
 */
/*
 * struct HAL_MT_PVT_POLY_TERM_T - a term descriptor of the PVT data translation
 *              polynomial
 * @deg: degree of the term.
 * @coef: multiplication factor of the term.
 * @divider: distributed divider per each degree.
 * @divider_leftover: divider leftover, which couldn't be redistributed.
 */
typedef struct {
    uint32 deg;
    int32 coef;
    int32 divider;
    int32 divider_leftover;
} HAL_MT_PVT_POLY_TERM_T;

/*
 * struct HAL_MT_PVT_POLY_T - PVT data translation polynomial descriptor
 * @total_divider: total data divider.
 * @terms: polynomial terms up to a free one.
 */
typedef struct {
    int32 total_divider;
    HAL_MT_PVT_POLY_TERM_T terms[];
} HAL_MT_PVT_POLY_T;

typedef enum {
    HAL_MT_PVT_TEMP,
    HAL_MT_PVT_VOLT,
    HAL_MT_PVT_LVT,
    HAL_MT_PVT_ULVT,
    HAL_MT_PVT_SVT,
    HAL_MT_PVT_SENSORS_MAX
} HAL_MT_PVT_SENSOR_TYPE_T;

typedef enum {
    HAL_MT_PVT_TRIMO,
    HAL_MT_PVT_TRIMG,
    HAL_MT_PVT_VTRIM,
    HAL_MT_PVT_TRIM_TYPE_MAX
} HAL_MT_PVT_TRIM_TYPE_T;

typedef struct {
    uint32 bit_offset;
    uint32 bit_num;
    uint32 bit_msk;
    uint32 value;
} HAL_MT_PVT_TRIM_T;

typedef struct {
    uint32 bit_offset;
    uint32 bit_num;
    uint32 bit_msk;
    uint32 value;
} HAL_MT_PVT_CTRL_REG_FILED_T;

/*
it it mapping to PVT field, it is derived from
hal_mt_nb_reg_top_cfg_pvt10_control_field_t
*/
typedef enum {
    HAL_MT_CONTROL_PVT_VSAMPLE_FIELD_ID,
    HAL_MT_CONTROL_PVT_PSAMPLE_FIELD_ID,
    HAL_MT_CONTROL_PVT_TRIMO_FIELD_ID,
    HAL_MT_CONTROL_PVT_TRIMG_FIELD_ID,
    HAL_MT_CONTROL_PVT_VTRIM_FIELD_ID,
    HAL_MT_CONTROL_PADDING1_FIELD_ID,
    HAL_MT_CONTROL_LAST_FIELD_ID
} HAL_MT_PVT_CONTROL_FIELD_T;

typedef struct {
    uint32 id;
    clx_semaphore_id_t sema;
    uint32 ctrl_reg;
    uint32 data_reg;
    uint32 ena_reg;
    uint32 ready_reg;
    HAL_MT_PVT_TRIM_T trim[HAL_MT_PVT_TRIM_TYPE_MAX];
} HAL_MT_PVT_DEV_T;

typedef struct {
    uint32 trim[HAL_MT_PVT_TRIM_TYPE_MAX];
} HAL_MT_S_PVT_TRIM_T;

typedef enum {
    HAL_MT_PVT_ID_0,
    HAL_MT_PVT_ID_1,
    HAL_MT_PVT_ID_2,
    HAL_MT_PVT_ID_3,
    HAL_MT_PVT_ID_4,
    HAL_MT_PVT_ID_5,
    HAL_MT_PVT_ID_6,
    HAL_MT_PVT_ID_7,
    HAL_MT_PVT_ID_8,
    HAL_MT_PVT_ID_9,
    HAL_MT_PVT_ID_10,
    HAL_MT_PVT_ID_11,
    HAL_MT_PVT_ID_12,
    HAL_MT_PVT_ID_13,
    HAL_MT_PVT_ID_14,
    HAL_MT_PVT_ID_MAX
} HAL_MT_PVT_ID_T;

typedef enum { HAL_MT_S_PVT_ID_0, HAL_MT_S_PVT_ID_MAX } HAL_MT_S_PVT_ID_T;

#define HAL_MT_PVT_TIME_OUT 1000

#define HAL_MT_PVT_ENA_ENABLE    1
#define HAL_MT_PVT_ENA_DISENABLE 0

typedef struct {
    uint32 vsample;
    uint32 psample;
} HAL_MT_PVT_EVA_T;

/* EFUSE BIT mapping for PVT TRIMG/TRIMO/VTRIM */
#define HAL_MT_EFUSE_PAGE_SIZE      256
#define HAL_MT_PVT_REG_BIT_NUM      32
#define HAL_MT_PVT_TRIMO_BIT_OFFSET 384 /* Bit 384 ~ 504 */
#define HAL_MT_PVT_TRIMO_BIT_NUM    8
#define HAL_MT_PVT_TRIMO_MASK       0xFF

#define HAL_MT_PVT_TRIMG_BIT_OFFSET 512 /* BIt 512 ~ 587 */
#define HAL_MT_PVT_TRIMG_BIT_NUM    5
#define HAL_MT_PVT_TRIMG_MASK       0x1F

#define HAL_MT_PVT_VTRIM_BIT_OFFSET 592 /* BIt 592 ~ 667 */
#define HAL_MT_PVT_VTRIM_BIT_NUM    5
#define HAL_MT_PVT_VTRIM_MASK       0x1F

#define HAL_MT_PVT_ID_CHK(unit, id) OSAL_ASSERT((id) < HAL_MT_PVT_ID_MAX);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_pvt_chip_temp_get(const uint32 unit, int32 *ptr_temperature);

/**
 * @brief Get chip temperature.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature list.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_pvt_chip_temp_list_get(const uint32 unit, clx_swc_thermal_list_t *ptr_temperature);

/**
 * @brief Get PVT calibration information.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     inst              - Instance number.
 * @param [out]    ptr_calib_info    - PVT calibration information.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_pvt_calib_info_get(const uint32 unit,
                          const uint32 inst,
                          clx_swc_pvt_calib_info_t *ptr_calib_info);

clx_error_no_t
hal_mt_pvt_init(const uint32 unit);

clx_error_no_t
hal_mt_pvt_deinit(const uint32 unit);

int32
hal_mt_pvt_poly_calc(const HAL_MT_PVT_POLY_T *poly, int32 data);

clx_error_no_t
hal_mt_pvt_chip_temp_get(const uint32 unit, int32 *ptr_temperature);

clx_error_no_t
_hal_mt_pvt_trim_set(const uint32 unit, HAL_MT_PVT_ID_T pvt_id, HAL_MT_PVT_SENSOR_TYPE_T pvt_type);

clx_error_no_t
_hal_mt_pvt_cfg(const uint32 unit, HAL_MT_PVT_ID_T pvt_id, HAL_MT_PVT_SENSOR_TYPE_T pvt_type);

clx_error_no_t
_hal_mt_pvt_enable(const uint32 unit, HAL_MT_PVT_ID_T pvt_id, boolean enable);

clx_error_no_t
_hal_mt_pvt_data_read(const uint32 unit,
                      HAL_MT_PVT_ID_T pvt_id,
                      HAL_MT_PVT_SENSOR_TYPE_T type,
                      int32 *val);

clx_error_no_t
_hal_mt_pvt_trim_cfg_get(const uint32 unit,
                         HAL_MT_PVT_DEV_T *dev,
                         HAL_MT_PVT_TRIM_TYPE_T type,
                         uint32 *data);

#ifdef __cplusplus
}
#endif
#endif /* End of HAL_MT_PVT_H */
