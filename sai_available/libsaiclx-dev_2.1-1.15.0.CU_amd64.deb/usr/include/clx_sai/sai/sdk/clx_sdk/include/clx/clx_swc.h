/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_swc.h
 * PURPOSE:
 *      It provides switch control module API.
 *
 * NOTES:
 *
 */

#ifndef CLX_SWC_H
#define CLX_SWC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_tm.h>
#include <clx/clx_port.h>
#include <clx/clx_pkt.h>
#include <time.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_SWC_ECC_ERR_INFO_INVALID_HUB    (0xFFFFFFFF) /* Invalid hub. */
#define CLX_SWC_ECC_ERR_INFO_INVALID_MEM    (0xFFFFFFFF) /* Invalid memory0 */
#define CLX_SWC_ECC_ERR_INFO_INVALID_TBL_ID (0xFFFFFFFF) /* Invalid table ID. */
#define CLX_SWC_HEALTH_EVENT_DESC_MAX_LEN   (256)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum clx_swc_cfg_e {
    CLX_SWC_CFG_IPV4_VER_ERR,   /* IPv4 header version err action. */
    CLX_SWC_CFG_IPV4_CHKSM_ERR, /* IPv4 header checksum err action. */
    CLX_SWC_CFG_IPV4_OPT,       /* IPv4 packet has options action. */
    CLX_SWC_CFG_IPV4_LEN_ERR,   /* IPv4 header length is unmatched to payload length action. */
    CLX_SWC_CFG_IPV6_VER_ERR,   /* IPv6 header version err action. */
    CLX_SWC_CFG_IPV6_LEN_ERR,   /* IPv6 header total length does not cover 40-Bytes IPv6 base
                                        header. action */
    CLX_SWC_CFG_L2_AGING_TIME,  /* Set L2 entry aging time. */
    CLX_SWC_CFG_ICMP_REDIR,     /* Packet icmp redirect type. */
    CLX_SWC_CFG_L3_URPF,        /* URPF fail action. */
    CLX_SWC_CFG_L3_MCAST_ADDR_VALIDATE, /* Multicast packet destination MAC not match
                                                destination IP action. */
    CLX_SWC_CFG_VXLAN_ROUTER_ALERT,     /* Enable VXLAN router alert bit. */
    CLX_SWC_CFG_VXLAN_UDP_PORT,         /* Set UDP destination port of VXLAN packet. */
    CLX_SWC_CFG_NVGRE_ROUTER_ALERT,     /* Enable NVGRE router alert bit. */
    CLX_SWC_CFG_MIR_ERSPAN_MISS_ACTION, /* ERSPAN term miss action. */
    CLX_SWC_CFG_MIR_METER_LAYER,        /* Set mirror meter layer mode. */
    /* exceptions, param0 is clx_fwd_action_t */
    CLX_SWC_CFG_L2_SA_MOVE_ACTION,       /* Set source address move action, param0 is
                                                 clx_fwd_action_t */
    CLX_SWC_CFG_L2_SA_MISS_ACTION,       /* Set source address miss action, param0 is
                                                 clx_fwd_action_t */
    CLX_SWC_CFG_L3_IPV4_MC_MISS_ACTION,  /* IPv4 multicast search fail action. */
    CLX_SWC_CFG_L3_IPV6_MC_MISS_ACTION,  /* IPv6 multicast search fail action.*/
    CLX_SWC_CFG_L3_IPV4_OPT_HDR_ACTION,  /* IPv4 with option action. */
    CLX_SWC_CFG_L3_IPV6_OPT_HDR_ACTION,  /* IPv6 with next header action. */
    CLX_SWC_CFG_L3_IGR_MTU_FAIL_ACTION,  /* L3 ingress mtu error action. */
    CLX_SWC_CFG_L3_EGR_MTU_FAIL_ACTION,  /* L3 egress mtu err action. */
    CLX_SWC_CFG_L3_TTL0_ACTION,          /* L3 ttl0 action. */
    CLX_SWC_CFG_L3_IGR_TTL1_ACTION,      /* L3 ingress ttl1 action, only for L3 unicast. */
    CLX_SWC_CFG_TNL_TTL0_ACTION,         /* IP tunnel ingress ttl0 action. */
    CLX_SWC_CFG_TNL_TTL1_ACTION,         /* IP tunnel ingress ttl1 action. */
    CLX_SWC_CFG_TNL_IPV6_EXT_HDR_ACTION, /* IP tunnel ingress ipv6 with ext header action. */
    CLX_SWC_CFG_TNL_IPV4_AH_HDR_ACTION,  /* IP tunnel ingress ipv4 with AH header action. */
    CLX_SWC_CFG_TNL_IPV6_AH_HDR_ACTION,  /* IP tunnel ingress ipv6 with AH header action. */
    /* Configure the latency threshold to sample high latency packets for sflow. */
    /* NB */
    /* 0:disable, 1-65535ns */
    CLX_SWC_CFG_SAMPLE_HIGH_LATENCY_THD,
    CLX_SWC_CFG_TNL_TPID_PROF,         /* L3T TPID profile. */
    CLX_SWC_CFG_TELM_INT_VER,          /* Set INT version(CLX_TELM_INT_VERSION_2), only support on
                                               CL860256 */
    CLX_SWC_CFG_TELM_NODE_ID,          /* Set node id, only support on CL860256 */
    CLX_SWC_CFG_TELM_HW_ID,            /* Set hw id, only support on CL860256 */
    CLX_SWC_CFG_TELM_FORCE_OFF,        /* Telemetry force off. */
    CLX_SWC_CFG_TELM_CLONE_PRI,        /* Telemetry clone priority. */
    CLX_SWC_CFG_TELM_MOD_GLB_EN,       /* Enable/Disable global mod.  */
    CLX_SWC_CFG_TELM_MOD_TM_EN,        /* Enable/Disable global mod.  */
    CLX_SWC_CFG_PORT_HIGH_LATENCY_THD, /* Configure the latency threshold to high latency
                                                     packets for port. param0: 0-0x7FFF8000. */
    CLX_SWC_CFG_TNL_PSR_ENABLE,        /* Set hw parsering different tunnel type status, default
                                                   en. */
    CLX_SWC_CFG_TNL_ECN_MAP,           /* IP tunnel decap ecn map. */
    CLX_SWC_CFG_L2_SA_MISS_1_ACTION,   /* Set source address miss 1 action, param0 is
                                               clx_fwd_action_t. */
    CLX_SWC_CFG_L3_ECMP_RESILIENT_EN,  /* Set L3 Ecmp Resilient Enable. */
    CLX_SWC_CFG_L3_ECMP_ALGO_MODE,     /* Set L3 Ecmp Algo Mode. */
    CLX_SWC_CFG_L3_ECMP_HSH_ENG_ALGO_MODE,     /* Set ECMP hsh engine algorithms. 0:gf16 1:murmur */
    CLX_SWC_CFG_L3_ECMP_GRPMAXNUM,             /* Set L3 Ecmp Grp Max Num. */
    CLX_SWC_CFG_METER_PLANE_RATE_MAX,          /* plane meter rate max : kbps */
    CLX_SWC_CFG_METER_PLANE_BUCKET_SIZE_MAX,   /* plane meter bucket size max, unit:byte */
    CLX_SWC_CFG_METER_GLB_RATE_MAX,            /* global meter rate max, unit:kbps */
    CLX_SWC_CFG_METER_GLOBAL_BUCKET_SIZE_MAX,  /* global bucket size max, unit:byte */
    CLX_SWC_CFG_METER_RATE_GRANULARITY,        /* meter rate granularity, unit:kbps */
    CLX_SWC_CFG_METER_BUCKET_SIZE_GRANULARITY, /* bucket size granularity, unit:byte */
    CLX_SWC_CFG_METER_PACKET_PLANE_RATE_MAX,   /* plane meter packet rate max, unit:pps */
    CLX_SWC_CFG_METER_PACKET_PLANE_BUCKET_SIZE_MAX,   /* plane meter packet bucket size, unit:
                                                              packet */
    CLX_SWC_CFG_METER_PACKET_GLOBAL_RATE_MAX,         /* global meter packet rate max, unit:pps */
    CLX_SWC_CFG_METER_PACKET_GLOBAL_BUCKET_SIZE_MAX,  /* global meter packet bucket size, unit:
                                                              packet */
    CLX_SWC_CFG_METER_PACKET_RATE_GRANULARITY,        /* packet rate granularity, unit: pps */
    CLX_SWC_CFG_METER_PACKET_BUCKET_SIZE_GRANULARITY, /* packet bucket size granularity, unit:
                                                              packet */
    CLX_SWC_CFG_CPU_DI_PROPERTY,     /* Param0 is clx_swc_cpu_di_property_t, and param1 is value.
                                      */
    CLX_SWC_CFG_REASON_BLOOM_FILTER, /* Set reason bloom filter configuration. */
    CLX_SWC_CFG_CPA,                 /* CPA mark property.
                                      * param0: CPA property type, define in CLX_SWC_CFG_CPA_TYPE_T
                                      * param1: the value of the cpa property type */
    CLX_SWC_CFG_COPY_TO_2ND,         /* Keep pcp/dei of inner vlan.
                                      * param0: to_2nd defined in RWI_SLV_QOS_PCP_DEI*/
    CLX_SWC_CFG_CIA_TRUNC_SIZE,      /* CIA allow TM truncate size. */
    CLX_SWC_CFG_CIA_ACTION_TRACING_VLAN_TPID, /* CIA vid action - push tracing vlan tpid, only
                                                      support on CL860256 */
    CLX_SWC_CFG_CIA_ACTION_RULE_VLAN_TPID,    /* CIA vid action - push rule vlan tpid, only
                                                      support on CL860256 */
    CLX_SWC_CFG_MEM_CHECK,                    /* Set memory check mode, only support on CL860256 */
    CLX_SWC_CFG_ISOLATION_GRP_NUM_MAX,        /* Isolation group number max */
    CLX_SWC_CFG_L3_PROTO_PSR_EN,              /* Set hw parsering l3 protocol, default en. param0:
                                                 clx_cia_cfg_l3_proto_type, param1: TRUE or FALSE */
    CLX_SWC_CFG_LAG_MC_HASH_ENGINE,           /* Set lag group mc hash-engine */
    CLX_SWC_CFG_L3_IPV4_MC_LCL,               /* Set ipv4 mc link-local addr */
    CLX_SWC_CFG_L3_IPV6_MC_LCL,               /* Set ipv6 mc link-local addr */
    CLX_SWC_CFG_STK_FL_HASH_SEL,              /* Set fabric link hash select method. */
    CLX_SWC_CFG_SKIP_RX_CRC_CHECK,            /* Set skip rx crc check. */
    CLX_SWC_CFG_RUNT_PKT_FWD,                 /* Set runt pkt fwd. */
    CLX_SWC_CFG_TELM_QOCC_UNIT_SIZE,          /* Set telemetry oqc unit size(set cud shift bits) */
    CLX_SWC_CFG_TELM_QSIZE_STAT_MODE,         /* Set telemetry qsize stat mode */
    CLX_SWC_CFG_SEARCH_FAVOR_INNER,           /* Use inner mac_addr/ip_addr as key to lookup. */
    CLX_SWC_CFG_TNL_IPV6_EXT, /*Set hw  IPV6_EXT the value of the opt,support on CL8600 only.*/
    CLX_SWC_CFG_LAST
} clx_swc_cfg_t;

typedef enum clx_swc_hsh_key_type_e {
    /* Outer hash key */
    CLX_SWC_HSH_KEY_TYPE_IGR_PORT,               /* Hash key : Ingress port. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L2_DMAC,          /* Hash key : Outer L2 header destination MAC. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L2_SMAC,          /* Hash key : Outer L2 header source MAC. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L2_MAC_NORMALIZE, /* Hash key : Outer L2 header MAC normalize. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L2_OUTER_VID,     /* Hash key : Outer L2 header outer VLAN ID. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L2_INNER_VID,     /* Hash key : Outer L2 header inner VLAN ID. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L2_ETHERTYPE,     /* Hash key : Outer L2 header EtherType. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L3_DIP,           /* Hash key : Outer destination IP. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L3_SIP,           /* Hash key : Outer source IP. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L3_IP_NORMALIZE,  /* Hash key : Outer IP normalize. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L3_PROTO, /* Hash key : Outer transport layer protocol number. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L4_DPORT, /* Hash key : Outer L4 destination port. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L4_SPORT, /* Hash key : Outer L4 source port. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_L4_PORT_NORMALIZE, /* Hash key : Outer L4 port normalize. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_IPV6_FLOW_LBL,     /* Hash key : Outer IPv6 flow label. */
    CLX_SWC_HSH_KEY_TYPE_USE_INNER,               /* Hash key : Use inner. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_MPLS_LBL0,         /* Hash key : 1st label in the MPLS-over-IP-tunnel
                                                        header. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_MPLS_LBL1,         /* Hash key : 2nd label in the MPLS-over-IP-tunnel
                                                        header. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_MPLS_LBL2,         /* Hash key : 3rd label in the MPLS-over-IP-tunnel
                                                        header. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_MPLS_LBL3,         /* Hash key : 4th label in the MPLS-over-IP-tunnel
                                                        header. */
    CLX_SWC_HSH_KEY_TYPE_OUTER_MPLS_LBL4,         /* Hash key : 5th label in the MPLS-over-IP-tunnel
                                                        header. */
    /* Inner hash key */
    CLX_SWC_HSH_KEY_TYPE_L2_DMAC,           /* Hash key : L2 header destination MAC. */
    CLX_SWC_HSH_KEY_TYPE_L2_SMAC,           /* Hash key : L2 header source MAC. */
    CLX_SWC_HSH_KEY_TYPE_L2_MAC_NORMALIZE,  /* Hash key : L2 header MAC normalize. */
    CLX_SWC_HSH_KEY_TYPE_L2_OUTER_VID,      /* Hash key : L2 header outer VLAN ID. */
    CLX_SWC_HSH_KEY_TYPE_L2_INNER_VID,      /* Hash key : L2 header inner VLAN ID. */
    CLX_SWC_HSH_KEY_TYPE_L2_ETHERTYPE,      /* Hash key : L2 header EtherType. */
    CLX_SWC_HSH_KEY_TYPE_L3_DIP,            /* Hash key : L3 destination IP. */
    CLX_SWC_HSH_KEY_TYPE_L3_SIP,            /* Hash key : L3 source IP. */
    CLX_SWC_HSH_KEY_TYPE_L3_IP_NORMALIZE,   /* Hash key : L3 IP normalize. */
    CLX_SWC_HSH_KEY_TYPE_L3_PROTO,          /* Hash key : L3 protocol number. */
    CLX_SWC_HSH_KEY_TYPE_L4_DPORT,          /* Hash key : L4 destination port. */
    CLX_SWC_HSH_KEY_TYPE_L4_SPORT,          /* Hash key : L4 source port. */
    CLX_SWC_HSH_KEY_TYPE_L4_PORT_NORMALIZE, /* Hash key : L4 port normalize. */
    CLX_SWC_HSH_KEY_TYPE_IPV6_FLOW_LBL,     /* Hash key : IPv6 flow label. */
    CLX_SWC_HSH_KEY_TYPE_MPLS_LBL0,         /* Hash key : 1st label in the MPLS header. */
    CLX_SWC_HSH_KEY_TYPE_MPLS_LBL1,         /* Hash key : 2nd label in the MPLS header. */
    CLX_SWC_HSH_KEY_TYPE_MPLS_LBL2,         /* Hash key : 3rd label in the MPLS header. */
    CLX_SWC_HSH_KEY_TYPE_MPLS_LBL3,         /* Hash key : 4th label in the MPLS header. */
    CLX_SWC_HSH_KEY_TYPE_MPLS_LBL4,         /* Hash key : 5th label in the MPLS header. */
    CLX_SWC_HSH_KEY_TYPE_NORMALIZE,         /* Hash key : Normalize. */
    CLX_SWC_HSH_KEY_TYPE_ENTROPY,           /* Hash key : Entropy. */
    CLX_SWC_HSH_KEY_TYPE_NV_SEG,            /* Hash key : Segment ID in the NV-tunnel header. */
    CLX_SWC_HSH_KEY_TYPE_LAST
} clx_swc_hsh_key_type_t;

typedef enum clx_swc_rsrc_e {
    CLX_SWC_RSRC_L2_UC_ADDR = 0,           /* L2 unicast entry resource. */
    CLX_SWC_RSRC_L2_MC_ID,                 /* L2 mcast ID resource. */
    CLX_SWC_RSRC_L3_ECMP_GRP,              /* L3 ECMP group resource. */
    CLX_SWC_RSRC_L3_ECMP_PATH,             /* L3 ECMP path resource. */
    CLX_SWC_RSRC_L3_ECMP_HSH,              /* L3 ECMP hash resource. */
    CLX_SWC_RSRC_L3_ECMP_MAX_PATH_CNT,     /* L3 ECMP max path cnt resource. */
    CLX_SWC_RSRC_L3_INTF,                  /* L3 interface resource. */
    CLX_SWC_RSRC_L3_ADJ,                   /* L3 adjacency resource. */
    CLX_SWC_RSRC_L3_RMAC,                  /* L3 router MAC resource. */
    CLX_SWC_RSRC_L3_HOST,                  /* L3 host resource. */
    CLX_SWC_RSRC_L3_RTE,                   /* L3 route resource. */
    CLX_SWC_RSRC_L3_MCAST,                 /* L3 mutlcast resource. */
    CLX_SWC_RSRC_L3_RESOURCE,              /* L3 resource. */
    CLX_SWC_RSRC_CIA_IGR_UCP,              /* CIA ingress UCP resource. */
    CLX_SWC_RSRC_CIA_IGR_POST_UCP,         /* CIA ingress post UCP resource. */
    CLX_SWC_RSRC_CIA_UCP_ENTRY,            /* CIA UCP entry resource. */
    CLX_SWC_RSRC_CIA_IGR_GRP,              /* CIA ingress group resource. */
    CLX_SWC_RSRC_CIA_IGR_POST_GRP,         /* CIA ingress post group resource. */
    CLX_SWC_RSRC_CIA_IGR_GRP_ENTRY,        /* CIA ingress group entry resource. */
    CLX_SWC_RSRC_CIA_IGR_POST_GRP_ENTRY,   /* CIA ingress post group entry resource. */
    CLX_SWC_RSRC_CIA_IGR_UDF_KEY_PROF,     /* CIA ingress UDF key profile resource. */
    CLX_SWC_RSRC_CIA_IGR_EXACT_GRP,        /* CIA ingress exact group resource */
    CLX_SWC_RSRC_CIA_IGR_EXACT_GRP_ENTRY,  /* CIA ingress exact group entry resource */
    CLX_SWC_RSRC_CIA_IGR_EXACT_GRP_ID_MIN, /* CIA ingress exact group id min */
    CLX_SWC_RSRC_CIA_IGR_EXACT_GRP_ID_MAX, /* CIA ingress exact group id max */
    CLX_SWC_RSRC_CIA_EGR_UCP,              /* CIA egress UCP resource. */
    CLX_SWC_RSRC_CIA_EGR_POST_UCP,         /* CIA egress post UCP resource. */
    CLX_SWC_RSRC_CIA_EGR_GRP,              /* CIA egress group resource. */
    CLX_SWC_RSRC_CIA_EGR_POST_GRP,         /* CIA egress post group resource. */
    CLX_SWC_RSRC_CIA_EGR_GRP_ENTRY,        /* CIA egress group entry resource. */
    CLX_SWC_RSRC_CIA_EGR_POST_GRP_ENTRY,   /* CIA egress post group entry resource. */
    CLX_SWC_RSRC_CIA_EGR_UDF_KEY_PROF,     /* CIA UDF key profile resource. */
    CLX_SWC_RSRC_CIA_IGR_RANGE_ENTRY,      /* CIA ingress range entry resource. */
    CLX_SWC_RSRC_CIA_EGR_RANGE_ENTRY,      /* CIA egress range entry resource. */
    CLX_SWC_RSRC_LAG_GRP,                  /* LAG group resource. */
    CLX_SWC_RSRC_BDID,                     /* Bridge domain resource. */
    CLX_SWC_RSRC_PORT_LOCAL_INTF,          /* Port local interface resource */
    CLX_SWC_RSRC_PORT_SUB_MACRO_LANE_NUM,  /* Port sub-macro lane number */
    CLX_SWC_RSRC_PORT_DUAL_UMAC_MODE,      /* Port dual umac mode */
    CLX_SWC_RSRC_MAX_TS_SEC,               /* max timestamp seconds value */
    CLX_SWC_RSRC_MIR_IGR_SESSION,          /* ingress mirror session number */
    CLX_SWC_RSRC_MIR_EGR_SESSION,          /* egress mirror session number */
    CLX_SWC_RSRC_PORT_FEC,                 /* Port FEC capacity */
    CLX_SWC_RSRC_L2_MC_ADDR,               /* L2 mcast address resource. */
    CLX_SWC_RSRC_LAST
} clx_swc_rsrc_t;

typedef enum clx_swc_data_type_e {
    CLX_SWC_DATA_TYPE_REG_TBL,  /* Register table. */
    CLX_SWC_DATA_TYPE_RSN,      /* Reason. */
    CLX_SWC_DATA_TYPE_PP_RSN,   /* Hardware reason. */
    CLX_SWC_DATA_TYPE_DROP_RSN, /* Drop reason. */
    CLX_SWC_DATA_TYPE_LAST
} clx_swc_data_type_t;

#define CLX_SWC_HSH_KEY_NUM        (CLX_SWC_HSH_KEY_TYPE_LAST)
#define CLX_SWC_HSH_KEY_WORD_WIDTH (32)
#define CLX_SWC_HSH_KEY_BMP_SIZE   (((CLX_SWC_HSH_KEY_NUM - 1) / CLX_SWC_HSH_KEY_WORD_WIDTH) + 1)

typedef uint32 clx_swc_hsh_key_bmp_t[CLX_SWC_HSH_KEY_BMP_SIZE];

#define CLX_SWC_SET_HSHKEYBIT(key_bmp, hash_key)                   \
    (((uint32 *)key_bmp)[hash_key / CLX_SWC_HSH_KEY_WORD_WIDTH] |= \
     (0x1UL << (hash_key % CLX_SWC_HSH_KEY_WORD_WIDTH)))
#define CLX_SWC_CLEAR_HSHKEYBIT(key_bmp, hash_key)                 \
    (((uint32 *)key_bmp)[hash_key / CLX_SWC_HSH_KEY_WORD_WIDTH] &= \
     ~(0x1UL << (hash_key % CLX_SWC_HSH_KEY_WORD_WIDTH)))
#define CLX_SWC_CHK_HSHKEYBIT(key_bmp, hash_key)                  \
    (((uint32 *)key_bmp)[hash_key / CLX_SWC_HSH_KEY_WORD_WIDTH] & \
     (0x1UL << (hash_key % CLX_SWC_HSH_KEY_WORD_WIDTH)))
#define CLX_SWC_FOREACH_HSHKEYBIT(key_bmp, hash_key)               \
    for (hash_key = 0; hash_key < CLX_SWC_HSH_KEY_NUM; hash_key++) \
        if (CLX_SWC_CHK_HSHKEYBIT(key_bmp, hash_key))

typedef enum clx_swc_hsh_pkt_type_e {
    CLX_SWC_HSH_PKT_TYPE_ECMP_L3,    /* For egress path is normal L3 flow. */
    CLX_SWC_HSH_PKT_TYPE_ECMP_NVO3,  /* For egress path is nvo3 flow. */
    CLX_SWC_HSH_PKT_TYPE_MPLS,       /* For egress path is MPLS flow. */
    CLX_SWC_HSH_PKT_TYPE_LAG,        /* LAG loading balance. */
    CLX_SWC_HSH_PKT_TYPE_LAG_FABRIC, /* LAG loading balance for fabric port selection. */
    CLX_SWC_HSH_PKT_TYPE_ECMP_L2,    /* For egress path is normal L2 flow. */
    CLX_SWC_HSH_PKT_TYPE_LAST
} clx_swc_hsh_pkt_type_t;

typedef enum clx_swc_hsh_algo_e {
    CLX_SWC_HSH_ALGO_GF16 = 0,
    CLX_SWC_HSH_ALGO_MURMUR,
    CLX_SWC_HSH_ALGO_LAST
} clx_swc_hsh_algo_t;

typedef enum clx_swc_err_type_e {
    CLX_SWC_ERR_TYPE_ECC = 0, /* SWC error source is ECC. */
    CLX_SWC_ERR_TYPE_LAST,
} clx_swc_err_type_t;

typedef enum clx_swc_ecc_correction_status_e {
    CLX_SWC_ECC_CORRECTION_STATUS_NON_CORRECTABLE = 0, /* Error non-correctable. */
    CLX_SWC_ECC_CORRECTION_STATUS_CORRECTED,           /* Error corrected. */
} clx_swc_ecc_correction_status_t;

typedef enum clx_swc_cso_mode_e {
    CLX_SWC_CSO_MODE_SLAVE = 0, /* CSO mode slave. */
    CLX_SWC_CSO_MODE_MASTER,    /* CSO mode master. */
    CLX_SWC_CSO_MODE_LAST
} clx_swc_cso_mode_t;

typedef enum clx_swc_hsh_stage_type_e {
    CLX_SWC_HSH_STAGE_TYPE_OFF = 0,
    CLX_SWC_HSH_STAGE_TYPE_8_PARALLEL,
    CLX_SWC_HSH_STAGE_TYPE_4_BY_4,
    CLX_SWC_HSH_STAGE_TYPE_2_BY_2_BY_4,
    CLX_SWC_HSH_STAGE_TYPE_4_BY_2_BY_2,
    CLX_SWC_HSH_STAGE_TYPE_2_BY_2_BY_2_BY_2,
    CLX_SWC_HSH_STAGE_TYPE_LAST
} clx_swc_hsh_stage_type_t;

typedef enum clx_swc_hsh_tile_type_e {
    /*Don't modify*/
    CLX_SWC_HSH_TILE_TYPE_OFF = 0,
    CLX_SWC_HSH_TILE_TYPE_MGI,
    CLX_SWC_HSH_TILE_TYPE_MSGI,
    CLX_SWC_HSH_TILE_TYPE_POLICY,
    CLX_SWC_HSH_TILE_TYPE_L3 = 8,
    CLX_SWC_HSH_TILE_TYPE_AFIB,
    CLX_SWC_HSH_TILE_TYPE_L2UC,
    CLX_SWC_HSH_TILE_TYPE_RPFC,
    CLX_SWC_HSH_TILE_TYPE_ECMP_GRP,
    CLX_SWC_HSH_TILE_TYPE_ECMP_MBR,
    CLX_SWC_HSH_TILE_TYPE_L2_ECMP_GRP,
    CLX_SWC_HSH_TILE_TYPE_L2_ECMP_MBR,
    /*Don't modify*/
    CLX_SWC_HSH_TILE_TYPE_MPLS,
    CLX_SWC_HSH_TILE_TYPE_ARP,
    CLX_SWC_HSH_TILE_TYPE_L2MC,
    CLX_SWC_HSH_TILE_TYPE_SRV6,
    CLX_SWC_HSH_TILE_TYPE_LAST
} clx_swc_hsh_tile_type_t;

typedef enum clx_swc_hsh_stage_e {
    CLX_SWC_HSH_STAGE_0 = 0,
    CLX_SWC_HSH_STAGE_1,
    CLX_SWC_HSH_STAGE_2,
    CLX_SWC_HSH_STAGE_3,
    CLX_SWC_HSH_STAGE_4,
    CLX_SWC_HSH_STAGE_5,
    CLX_SWC_HSH_STAGE_LAST,
} clx_swc_hsh_stage_t;

typedef enum clx_swc_hsh_tile_e {
    CLX_SWC_HSH_TILE_0 = 0,
    CLX_SWC_HSH_TILE_1,
    CLX_SWC_HSH_TILE_2,
    CLX_SWC_HSH_TILE_3,
    CLX_SWC_HSH_TILE_4,
    CLX_SWC_HSH_TILE_5,
    CLX_SWC_HSH_TILE_6,
    CLX_SWC_HSH_TILE_7,
    CLX_SWC_HSH_TILE_LAST,
} clx_swc_hsh_tile_t;

typedef enum clx_swc_tcam_type_e {
    CLX_SWC_TCAM_TYPE_OFF = 0,
    CLX_SWC_TCAM_TYPE_L3_ROUTE_DA_4X,
    CLX_SWC_TCAM_TYPE_L3_ROUTE_DA,
    CLX_SWC_TCAM_TYPE_L3_ROUTE_SA_4X,
    CLX_SWC_TCAM_TYPE_L3_ROUTE_SA,
    CLX_SWC_TCAM_TYPE_L3_HOST_DA_4X,
    CLX_SWC_TCAM_TYPE_L3_HOST_DA,
    CLX_SWC_TCAM_TYPE_L3_HOST_SA_4X,
    CLX_SWC_TCAM_TYPE_L3_HOST_SA,
    CLX_SWC_TCAM_TYPE_L2UC_DA,
    CLX_SWC_TCAM_TYPE_L2UC_SA,
    CLX_SWC_TCAM_TYPE_L2MC_DA,
    CLX_SWC_TCAM_TYPE_LAST
} clx_swc_tcam_type_t;

typedef enum {
    CLX_SWC_TCAM_0 = 0,
    CLX_SWC_TCAM_1,
    CLX_SWC_TCAM_2,
    CLX_SWC_TCAM_3,
    CLX_SWC_TCAM_4,
    CLX_SWC_TCAM_5,
    CLX_SWC_TCAM_6,
    CLX_SWC_TCAM_7,
    CLX_SWC_TCAM_8,
    CLX_SWC_TCAM_9,
    CLX_SWC_TCAM_10,
    CLX_SWC_TCAM_11,
    CLX_SWC_TCAM_12,
    CLX_SWC_TCAM_13,
    CLX_SWC_TCAM_14,
    CLX_SWC_TCAM_15,
    CLX_SWC_TCAM_16,
    CLX_SWC_TCAM_17,
    CLX_SWC_TCAM_18,
    CLX_SWC_TCAM_19,
    CLX_SWC_TCAM_20,
    CLX_SWC_TCAM_21,
    CLX_SWC_TCAM_22,
    CLX_SWC_TCAM_23,
    CLX_SWC_TCAM_24,
    CLX_SWC_TCAM_25,
    CLX_SWC_TCAM_26,
    CLX_SWC_TCAM_27,
    CLX_SWC_TCAM_28,
    CLX_SWC_TCAM_29,
    CLX_SWC_TCAM_30,
    CLX_SWC_TCAM_31,
    CLX_SWC_TCAM_32,
    CLX_SWC_TCAM_33,
    CLX_SWC_TCAM_34,
    CLX_SWC_TCAM_35,
    CLX_SWC_TCAM_36,
    CLX_SWC_TCAM_37,
    CLX_SWC_TCAM_38,
    CLX_SWC_TCAM_39,
    CLX_SWC_TCAM_40,
    CLX_SWC_TCAM_41,
    CLX_SWC_TCAM_42,
    CLX_SWC_TCAM_43,
    CLX_SWC_TCAM_44,
    CLX_SWC_TCAM_45,
    CLX_SWC_TCAM_46,
    CLX_SWC_TCAM_47,
    CLX_SWC_TCAM_48,
    CLX_SWC_TCAM_49,
    CLX_SWC_TCAM_50,
    CLX_SWC_TCAM_51,
    CLX_SWC_TCAM_52,
    CLX_SWC_TCAM_53,
    CLX_SWC_TCAM_54,
    CLX_SWC_TCAM_55,
    CLX_SWC_TCAM_56,
    CLX_SWC_TCAM_57,
    CLX_SWC_TCAM_58,
    CLX_SWC_TCAM_59,
    CLX_SWC_TCAM_60,
    CLX_SWC_TCAM_61,
    CLX_SWC_TCAM_62,
    CLX_SWC_TCAM_63,
    CLX_SWC_TCAM_LAST
} CLX_SWC_TCAM_T;

typedef enum clx_swc_cpu_di_property_e {
    CLX_SWC_CPU_DI_PROPERTY_PRIORITY,
    CLX_SWC_CPU_DI_PROPERTY_L2UC_CPU_PORT,
    CLX_SWC_CPU_DI_PROPERTY_L2UC_CPU_QUEUE,
    CLX_SWC_CPU_DI_PROPERTY_L3UC_CPU_PORT,
    CLX_SWC_CPU_DI_PROPERTY_L3UC_CPU_QUEUE,
} clx_swc_cpu_di_property_t;

typedef enum clx_swc_rsn_bloom_filter_type_e {
    CLX_SWC_CFG_RSN_BLOOM_FILTER_TYPE_ENABLE = 0, /* Enable bloom filter. */
    CLX_SWC_CFG_RSN_BLOOM_FILTER_TYPE_COUNTER,    /* Set bloom filter counter. (1 ~ (2^32)-1) */
    CLX_SWC_CFG_RSN_BLOOM_FILTER_TYPE_TIMER,      /* Set bloom filter timer (1ns ~ 3s) */
    CLX_SWC_CFG_RSN_BLOOM_FILTER_TYPE_LAST
} clx_swc_cfg_rsn_bloom_filter_type_t;

typedef enum clx_swc_cfg_trunc_size_e {
    CLX_SWC_CFG_TRUNC_SIZE_NONE = 0, /* 0: disable trunction */
    CLX_SWC_CFG_TRUNC_SIZE_64,       /* 1: 64 if pkt size > 64 */
    CLX_SWC_CFG_TRUNC_SIZE_128,      /* 2: 128 if pkt size > 128 */
    CLX_SWC_CFG_TRUNC_SIZE_192,      /* 3: 192 if pkt size > 192 */
    CLX_SWC_CFG_TRUNC_SIZE_256,      /* 4: 256 if pkt size > 256 */
    CLX_SWC_CFG_TRUNC_SIZE_512,      /* 5: 512 if pkt size > 512 */
    CLX_SWC_CFG_TRUNC_SIZE_984,      /* 6: 984 if pkt size > 984 */
    CLX_SWC_CFG_TRUNC_SIZE_LAST
} clx_swc_cfg_trunc_size_t;

typedef enum clx_swc_cfg_cpa_type_e {
    CLX_SWC_CFG_CPA_TYPE_EN,               /* Enable cpa mark */
    CLX_SWC_CFG_CPA_TYPE_PPL_IDX,          /* CPA PPL index in tcp reserved field */
    CLX_SWC_CFG_CPA_TYPE_CPA_IDX,          /* CPA support index in tcp reserved field */
    CLX_SWC_CFG_CPA_TYPE_REDO_QOS_EN,      /* CPA redo qos enable */
    CLX_SWC_CFG_CPA_TYPE_REDO_QOS_DSCP,    /* CPA redo qos dscp value */
    CLX_SWC_CFG_CPA_TYPE_REDO_QOS_PCP_DEI, /* CPA redo qos pcp and dei value */
    CLX_SWC_CFG_CPA_TYPE_HIGH_PRI_QUEUE,   /* CPA packet high priority queue */
    CLX_SWC_CFG_CPA_TYPE_TRUNCATION_SIZE,  /* CPA truncation size, only support
                                            * 64/128/192/256/512/1024 byte,  value define in
                                            * clx_swc_cfg_trunc_size_t */
    CLX_SWC_CFG_CPA_TYPE_LAST
} clx_swc_cfg_cpa_type_t;

typedef enum clx_swc_cpu_di_e {
    CLX_SWC_CPU_DI_CPU_ID = 0,
    CLX_SWC_CPU_DI_ECPU_ID,
    CLX_SWC_CPU_DI_CPI0_ID,
    CLX_SWC_CPU_DI_CPI1_ID,
    CLX_SWC_CPU_DI_LAST
} clx_swc_cpu_di_t;

typedef enum clx_swc_rsn_cnt_grp_type_e {
    CLX_SWC_RSN_CNT_GRP_TYPE_DEFAULT,
    CLX_SWC_RSN_CNT_GRP_TYPE_DROP,
    CLX_SWC_RSN_CNT_GRP_TYPE_NON_DROP,
    CLX_SWC_RSN_CNT_GRP_TYPE_LAST
} clx_swc_rsn_cnt_grp_type_t;

typedef enum clx_swc_hsh_path_pkt_type_e {
    CLX_SWC_HSH_PATH_PKT_TYPE_NORMAL,
    CLX_SWC_HSH_PATH_PKT_TYPE_NON_DECAP_TUNNEL,
    CLX_SWC_HSH_PATH_PKT_TYPE_DEDCAP_TUNNEL,
    CLX_SWC_HSH_PATH_PKT_TYPE_LAST
} clx_swc_hsh_path_pkt_type_t;

typedef enum clx_swc_cfg_qsize_stat_mode_e {
    CLX_SWC_CFG_QSIZE_STAT_MODE_PER_QUEUE_PACKET_NUMBER,
    CLX_SWC_CFG_QSIZE_STAT_MODE_PER_QUEUE_BYTE_NUMBER,
    CLX_SWC_CFG_QSIZE_STAT_MODE_LAST
} clx_swc_cfg_qsize_stat_mode_t;

typedef enum clx_swc_cfg_qocc_unit_size_e {
    CLX_SWC_CFG_QOCC_UNIT_SIZE_1B = 0,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_2B = 1,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_4B = 2,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_8B = 3,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_16B = 4,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_32B = 5,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_64B = 6,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_128B = 7,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_256B = 8,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_512B = 9,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_1KB = 10,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_2KB = 11,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_4KB = 12, /* NB support max 4KB */
    CLX_SWC_CFG_QOCC_UNIT_SIZE_8KB = 13,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_16KB = 14,
    CLX_SWC_CFG_QOCC_UNIT_SIZE_32KB = 15, /* KG support max 32KB */
    CLX_SWC_CFG_QOCC_UNIT_SIZE_LAST
} clx_swc_cfg_qocc_unit_size_t;

typedef struct clx_swc_err_info_ecc_s {
    uint32 hub;                        /* Invalid : CLX_SWC_ECC_ERR_INFO_INVALID_HUB. */
    uint32 memory;                     /* Invalid : CLX_SWC_ECC_ERR_INFO_INVALID_MEM. */
    uint32 single_err_addr;            /* Single error address. */
    uint32 double_err_addr;            /* Double error address. */

    uint32 inst;                       /* Table inst. */
    uint32 sub_inst;                   /* Table sub-inst. */
    uint32 table_id;                   /* Invalid : CLX_SWC_ECC_ERR_INFO_INVALID_TBL_ID. */
    uint32 single_err_tbl_entry_start; /* Single error table entry start. */
    uint32 single_err_tbl_entry_end;   /* Single error table entry end. */
    uint32 double_err_tbl_entry_start; /* Double error table entry start. */
    uint32 double_err_tbl_entry_end;   /* Double error table entry end. */

    uint32 single_err_cnt;             /* Single error count. */
    uint32 double_err_cnt;             /* Double error count. */

    clx_swc_ecc_correction_status_t single_err_correction; /* Single error correction state. */
    clx_swc_ecc_correction_status_t double_err_correction; /* Double error correction state. */
} clx_swc_err_info_ecc_t;

typedef struct clx_swc_err_info_s {
    union {
        clx_swc_err_info_ecc_t ecc_info; /* ECC error info. */
    };
} clx_swc_err_info_t;

typedef void (*clx_swc_err_func_t)(const uint32 unit,
                                   const clx_swc_err_info_t *ptr_error_info,
                                   void *ptr_cookie);

typedef struct clx_swc_device_info_s {
    uint32 vendor_id;
    uint32 device_id;
    char device_pn[32];
    uint32 revision_id;
    char uid[24];
} clx_swc_device_info_t;

typedef struct clx_swc_port_cfg_s {
    clx_port_bitmap_t bitmap_all;    /* Include active, inactive eth, mxlink, cpu, and cpi ports. */
    clx_port_bitmap_t bitmap_active; /* Include active eth, mxlink, cpu, and cpi ports. */
    clx_port_bitmap_t bitmap_mxlink; /* Active mxlink ports. */
    clx_port_bitmap_t bitmap_breakout; /* Active breakout ports. */
    clx_port_bitmap_t bitmap_cpu;      /* Active cpu ports. */
    clx_port_bitmap_t bitmap_cpi;      /* Active cpi ports. */
    clx_port_bitmap_t bitmap_rcp;      /* Active recirculation ports. */
    clx_port_bitmap_t bitmap_10g;      /* Active 10g ports. */
    clx_port_bitmap_t bitmap_25g;      /* Active 25g ports. */
    clx_port_bitmap_t bitmap_40g;      /* Active 40g ports. */
    clx_port_bitmap_t bitmap_50g;      /* Active 50g ports. */
    clx_port_bitmap_t bitmap_100g;     /* Active 100g ports. */
    clx_port_bitmap_t bitmap_200g;     /* Active 200g ports. */
    clx_port_bitmap_t bitmap_400g;     /* Active 400g ports. */
    clx_port_bitmap_t bitmap_800g;     /* Active 800g ports. */
} clx_swc_port_cfg_t;

typedef struct clx_swc_ts_s {
    uint16 sec_hi;  /* Bit[47:32] seconds for timestamp */
    uint32 sec_low; /* Bit[31:0]  seconds for timestamp */
    uint32 nsec;    /* Bit[29:0]  nano seconds for timestamp */
} clx_swc_ts_t;

typedef struct clx_swc_hsh_eng_s {
    boolean hsh_eng_en;                  /* 0: disable; 1: enable */
    boolean inner_five_tuple_en;         /* 0: disable; 1: enable */
    boolean ip_fragment_l4_inner_en;     /* 0: disable; 1: enable */
    boolean ip_fragment_l4_outer_enable; /* 0: disable; 1: enable */
    uint32 inner_l4_src_port_mask;       /* mask for inner l4 source port */
    uint32 outer_l4_src_port_mask;       /* mask for outer l4 source port */
    clx_swc_hsh_algo_t hsh_algo;         /* 0: GF16; 1: Murmur */
    uint32 seed;                         /* seed for Murmur or GF16 algorithm */
    uint32 fac; /* fac for GF16 algorithm. if the fac is 0, use the first 16 bits of the original
                   seed value as the parameter. */
    uint32 attr_bmp;
} clx_swc_hsh_eng_t;
#define CLX_SWC_HSH_ENG_ATTR_EN                   (1U << 0)
#define CLX_SWC_HSH_ENG_ATTR_INNER_FIVE_TUPLE     (1U << 1)
#define CLX_SWC_HSH_ENG_ATTR_IP_FRG_L4_INNER_PORT (1U << 2)
#define CLX_SWC_HSH_ENG_ATTR_IP_FRG_L4_OUTER_PORT (1U << 3)
#define CLX_SWC_HSH_ENG_ATTR_INNER_L4_SRC_PORT    (1U << 4)
#define CLX_SWC_HSH_ENG_ATTR_OUTER_L4_SRC_PORT    (1U << 5)
#define CLX_SWC_HSH_ENG_ATTR_ALGO                 (1U << 6)
#define CLX_SWC_HSH_ENG_ATTR_SEED                 (1U << 7)
#define CLX_SWC_HSH_ENG_ATTR_FAC                  (1U << 8)
#define CLX_SWC_HSH_ENG_ATTR_ALL                  0xFFFFFFFF

/* RX Packet Reasons Aciton */
typedef struct clx_swc_rsn_act_s {
    clx_fwd_action_t action;
    clx_swc_cpu_di_t cpu_id;
    uint32 cpu_queue;
    clx_pkt_drop_reason_t drop_reason;
    boolean sa_learn;
    boolean bloom_filter_en;
    uint32 attr_bmp;
    clx_swc_rsn_cnt_grp_type_t rsn_cnt_grp_type;
} clx_swc_rsn_act_t;
#define CLX_SWC_CPU_RSN_ATTR_ACT          (1U << 0)
#define CLX_SWC_CPU_RSN_ATTR_CPU_QUEUE    (1U << 1)
#define CLX_SWC_CPU_RSN_ATTR_DROP_RSN     (1U << 2)
#define CLX_SWC_CPU_RSN_ATTR_SA_LRN       (1U << 3)
#define CLX_SWC_CPU_RSN_ATTR_BLOOM_FILTER (1U << 4)
#define CLX_SWC_CPU_RSN_ATTR_CNT_GRP_TYPE (1U << 5)
#define CLX_SWC_CPU_RSN_ATTR_ALL          0xFFFFFFFF

typedef struct clx_swc_flow_hsh_si_l2_key_s {
    uint32 si;
    clx_mac_t dmac;
    clx_mac_t smac;
} clx_swc_flow_hsh_si_l2_key_t;

typedef struct clx_swc_flow_hsh_l2_vid_key_s {
    uint32 svlan;
    uint32 cvlan;
    uint32 ether_type;
} clx_swc_flow_hsh_l2_vid_key_t;

typedef struct clx_swc_flow_hsh_l3_ip_key_s {
    clx_ip_t ip_addr;
    boolean ipv4;
} clx_swc_flow_hsh_l3_ip_key_t;

typedef struct clx_swc_flow_hsh_mpls_key_s {
    uint32 mpls_label[4];
} clx_swc_flow_hsh_mpls_key_t;

typedef struct clx_swc_flow_hsh_l4_key_s {
    uint32 l3_ipv6_flw_lbl;
    uint32 l3_ulp;
    uint32 l4_dp;
    uint32 l4_sp;
    uint32 tnl_vni;
    uint32 entropy;
} clx_swc_flow_hsh_l4_key_t;

typedef struct clx_swc_flow_hsh_l4_inner_key_s {
    uint32 l3_ulp;
    uint32 l4_dp;
    uint32 l4_sp;
} clx_swc_flow_hsh_l4_inner_key_t;

typedef struct clx_swc_flow_hsh_key_s {
    clx_swc_flow_hsh_si_l2_key_t si_l2_key;
    clx_swc_flow_hsh_l2_vid_key_t l2_vid_key;
    clx_swc_flow_hsh_l3_ip_key_t l3_dip_key;
    clx_swc_flow_hsh_l3_ip_key_t l3_sip_key;
    clx_swc_flow_hsh_mpls_key_t mpls_key;
    clx_swc_flow_hsh_l4_key_t l4_key;
    clx_swc_flow_hsh_l3_ip_key_t l3_dip_inner_key;
    clx_swc_flow_hsh_l3_ip_key_t l3_sip_inner_key;
    clx_swc_flow_hsh_l4_inner_key_t l4_inner_key;
    uint32 flags;
} clx_swc_flow_hsh_key_t;
#define CLX_SWC_FLOW_HSH_MPLS_KEY_VLD   (1 << 0)
#define CLX_SWC_FLOW_HSH_KEY_IS_OUTER   (1 << 1)
#define CLX_SWC_FLOW_HSH_KEY_IS_IP_FRG  (1 << 2)
#define CLX_SWC_FLOW_HSH_KEY_NO_CARE_HW (1 << 3)

#define CLX_SWC_THERMAL_NUM_MAX  (32)
#define CLX_SWC_THERMAL_NAME_LEN (32)

typedef struct clx_swc_thermal_s {
    char thermal_name[CLX_SWC_THERMAL_NAME_LEN];
    int32 thermal_value;
} clx_swc_thermal_t;

typedef struct clx_swc_thermal_list_s {
    uint32 thermal_count;
    clx_swc_thermal_t thermal_list[CLX_SWC_THERMAL_NUM_MAX];
} clx_swc_thermal_list_t;

typedef struct clx_swc_hsh_path_rslt_info_s {
    uint32 port_id;
    clx_gport_type_t port_type;
    uint32 output_id;
    uint32 hash_value;
} clx_swc_hsh_path_rslt_info_t;

typedef struct clx_swc_hsh_path_pkt_info_s {
    clx_swc_hsh_path_pkt_type_t pkt_type;
    boolean ip_fragment;
    boolean mpls;
} clx_swc_hsh_path_pkt_info_t;

typedef struct clx_swc_selective_flow_cfg_s {
    uint32 enable; /* enable/disable selective flow */
    clx_swc_hsh_pkt_type_t hash_type;
    uint32 hash_value;
    uint32 hash_mask;
    uint32 src_port;
    uint32 mir_id;
    uint32 flags;
    uint32 attr_bmp;
} clx_swc_selective_flow_cfg_t;
#define CLX_SWC_SELECTIVE_FLOW_FLAGS_SRC_PORT (1U << 0) /* set src port */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_EN        (1U << 0) /* set/get enable */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_HSH_TYPE  (1U << 1) /* set/get hash_type */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_HSH_VALUE (1U << 2) /* set/get hash_value */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_HSH_MASK  (1U << 3) /* set/get hash_mask */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_SRC_PORT  (1U << 4) /* set/get src_port */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_MIR_ID    (1U << 5) /* set/get mir_id */
#define CLX_SWC_SELECTIVE_FLOW_ATTR_ALL       0xffffffff

typedef enum clx_swc_chip_cfg_info_type_e {
    CLX_SWC_CHIP_CFG_INFO_TYPE_BD_ID_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_BD_ID_MAX,

    CLX_SWC_CHIP_CFG_INFO_TYPE_VLAN_ID_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_VLAN_ID_MAX,

    CLX_SWC_CHIP_CFG_INFO_TYPE_TYPE_VLAN_IDX_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TYPE_VLAN_IDX_MAX,

    CLX_SWC_CHIP_CFG_INFO_TYPE_L2_AGE_SEC_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_L2_AGE_SEC_MAX,

    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_CPU_QUEUE_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_PORT_PFC_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_CELL_SIZE,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_LEGACY_QUEUE_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_UCAST_QUEUE_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_MCAST_QUEUE_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_BURST_SIZE_BPS_MAX_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_TM_BURST_SIZE_PPS_MAX_NUM,

    CLX_SWC_CHIP_CFG_INFO_TYPE_LAG_ID_MIN,
    CLX_SWC_CHIP_CFG_INFO_TYPE_LAG_ID_MAX,
    CLX_SWC_CHIP_CFG_INFO_TYPE_LAG_ID_NUM,
    CLX_SWC_CHIP_CFG_INFO_TYPE_LAST
} clx_swc_chip_cfg_info_type_t;

typedef enum clx_swc_chip_pll_status_e {
    CLX_SWC_CHIP_PLL_STATUS_UNLOCKED,
    CLX_SWC_CHIP_PLL_STATUS_LOCKED,
    CLX_SWC_CHIP_PLL_STATUS_ERR,
    CLX_SWC_CHIP_PLL_STATUS_IDLE,
    CLX_SWC_CHIP_PLL_STATUS_BUSY
} clx_swc_chip_pll_status_t;

typedef struct clx_swc_pvt_calib_info_s {
    uint32 trimo_value;
    uint32 trimg_value;
} clx_swc_pvt_calib_info_t;

typedef enum clx_swc_l3_rsrc_e {
    CLX_SWC_L3_RSRC_TYPE_V4_REALTIME = 0, /* v4 real time resource num */
    CLX_SWC_L3_RSRC_TYPE_V6_2X_REALTIME,  /* v6 real time 2x resource num for mask < 64 */
    CLX_SWC_L3_RSRC_TYPE_V6_4X_REALTIME,  /* v6 real time 4x resource num for mask > 64  */
    CLX_SWC_L3_RSRC_TYPE_LAST
} clx_swc_l3_rsrc_t;

/* System event category definitions */
typedef enum clx_swc_notify_category_e {
    CLX_SWC_NOTIFY_CATEGORY_HEALTH_EVENT_SW = 0,  /* System health sw related events */
    CLX_SWC_NOTIFY_CATEGORY_HEALTH_EVENT_FW,      /* System health fw related events */
    CLX_SWC_NOTIFY_CATEGORY_HEALTH_EVENT_CPU_HW,  /* System health cpu hw related events */
    CLX_SWC_NOTIFY_CATEGORY_HEALTH_EVENT_ASIC_HW, /* System health asic hw related events */
    /*other event category*/
    CLX_SWC_NOTIFY_CATEGORY_LAST /* Category end marker */
} clx_swc_notify_category_t;

/* System event severity definitions */
typedef enum clx_swc_notify_severity_e {
    CLX_SWC_NOTIFY_SEVERITY_FATAL = 0, /* System fatal events */
    CLX_SWC_NOTIFY_SEVERITY_WARNING,   /* System warning events */
    CLX_SWC_NOTIFY_SEVERITY_NOTICE,    /* System notice events */
    CLX_SWC_NOTIFY_SEVERITY_LAST       /* Severity end marker */
} clx_swc_notify_severity_t;

typedef enum clx_swc_health_event_type_e {
    /* Software Health Event */
    CLX_SWC_HEALTH_EVENT_SW_MEMORY_LOW = 0, /* Low memory */

    /* ASIC Health Event */
    CLX_SWC_HEALTH_EVENT_ASIC_INTR_BAC_TOP_GEN,     /* bac_top_general_irq */
    CLX_SWC_HEALTH_EVENT_ASIC_INTR_BAC_GEN,         /* bac_general_irq */
    CLX_SWC_HEALTH_EVENT_ASIC_INTR_OQC_TOP_LA_DONE, /* oqc_top_la_done_irq */
    CLX_SWC_HEALTH_EVENT_ASIC_INTR_REP_ABN,         /* rep_abnormal_irq */

    CLX_SWC_HEALTH_EVENT_ECPU_OVERLOAD,
    CLX_SWC_HEALTH_EVENT_ECPU_LOST,
    CLX_SWC_HEALTH_EVENT_ECPU_MEMORY_LOW,
    /* ECPU Health Event */
    CLX_SWC_HEALTH_LAST /* Health event type end marker */
} clx_swc_health_event_type_t;

/* System health event data structure */
typedef struct clx_swc_health_event_s {
    uint32 event_type;                                   /* Specific event type */
    clx_swc_notify_severity_t severity;                  /* Event severity */
    struct timespec timestamp;                           /* Event timestamp */
    char description[CLX_SWC_HEALTH_EVENT_DESC_MAX_LEN]; /* Event description */

} clx_swc_health_event_t;

/* System event data structure */
typedef struct clx_swc_notify_event_s {
    union {
        clx_swc_health_event_t health_event_info; /* System health event info. */
    };
} clx_swc_notify_event_t;

/* Callback function type definition */
typedef void (*clx_swc_notify_func_t)(const uint32 unit,
                                      const clx_swc_notify_event_t *event,
                                      void *ptr_cookie);

/**
 * @brief Register notify callback function.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    category      - Notify category.
 * @param [in]    callback      - The callback function of type clx_swc_notify_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_notify_cb_register(const uint32 unit,
                           const clx_swc_notify_category_t category,
                           const clx_swc_notify_func_t callback,
                           void *ptr_cookie);

/**
 * @brief Deregister notify callback function.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    category      - Notify category.
 * @param [in]    callback      - The callback function of type clx_swc_notify_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_notify_cb_deregister(const uint32 unit,
                             const clx_swc_notify_category_t category,
                             const clx_swc_notify_func_t callback,
                             void *ptr_cookie);

/**
 * @brief Get chip PLL status.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_pll_status    - Point to the status of chip PLL.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_chip_pll_status_get(const uint32 unit, clx_swc_chip_pll_status_t *ptr_pll_status);

/**
 * @brief Get private calibration information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     inst              - Instance number.
 * @param [out]    ptr_calib_info    - Point to the calibration information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_pvt_calib_info_get(const uint32 unit,
                           const uint32 inst,
                           clx_swc_pvt_calib_info_t *ptr_calib_info);

/**
 * @brief Set switch control hash keys.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    hash_type    - Hash type.
 * @param [in]    key_bmp      - Hash key bitmap.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_hsh_key_set(const uint32 unit,
                    const clx_swc_hsh_pkt_type_t hash_type,
                    const clx_swc_hsh_key_bmp_t key_bmp);

/**
 * @brief Get switch control hash keys.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hash_type      - Hash type.
 * @param [out]    ptr_key_bmp    - Pointer of hash key bitmap.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_hsh_key_get(const uint32 unit,
                    const clx_swc_hsh_pkt_type_t hash_type,
                    clx_swc_hsh_key_bmp_t *ptr_key_bmp);

/**
 * @brief Set hash engine configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    hash_type      - Hash engine.
 * @param [in]    hash_engine    - Hash engine attributes.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_swc_hsh_eng_set(const uint32 unit,
                    const clx_swc_hsh_pkt_type_t hash_type,
                    const clx_swc_hsh_eng_t *hash_engine);

/**
 * @brief Get hash engine configuration.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hash_type      - Hash engine.
 * @param [out]    hash_engine    - Point to hash engine attributes.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_swc_hsh_eng_get(const uint32 unit,
                    const clx_swc_hsh_pkt_type_t hash_type,
                    clx_swc_hsh_eng_t *hash_engine);

/**
 * @brief Set switch control property.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    property    - Property type.
 * @param [in]    param0      - First parameter.
 * @param [in]    param1      - Second parameter.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_cfg_set(const uint32 unit,
                const clx_swc_cfg_t property,
                const uint32 param0,
                const uint32 param1);

/**
 * @brief Get switch control property.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     property      - Property type.
 * @param [out]    ptr_param0    - First parameter.
 * @param [out]    ptr_param1    - Second parameter.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */

clx_error_no_t
clx_swc_cfg_get(const uint32 unit,
                const clx_swc_cfg_t property,
                uint32 *ptr_param0,
                uint32 *ptr_param1);

/**
 * @brief Set timestamp value of system.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit      - Device unit number.
 * @param [out]    ts_val    - Timestamp value.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_swc_ts_set(const uint32 unit, const clx_swc_ts_t ts_val);

/**
 * @brief Get timestamp value of system.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_ts_val    - Pointer of timestamp value.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_swc_ts_get(const uint32 unit, clx_swc_ts_t *ptr_ts_val);

/**
 * @brief Set timestamp offset.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    nsec    - Signed nano seconds for timestamp offset.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_swc_ts_offset_set(const uint32 unit, const int32 nsec);

/**
 * @brief Set hash engine polynomial coefficients.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    hash_type     - Hash engine to be config.
 * @param [in]    hash_const    - Hash constant.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_swc_hsh_const_set(const uint32 unit,
                      const clx_swc_hsh_pkt_type_t hash_type,
                      const uint32 hash_const);

/**
 * @brief Get hash engine polynomial coefficients.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     hash_type         - Hash engine to be config.
 * @param [out]    ptr_hash_const    - Point to hash constant.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_hsh_const_get(const uint32 unit,
                      const clx_swc_hsh_pkt_type_t hash_type,
                      uint32 *ptr_hash_const);

/**
 * @brief Register error callback function.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    error         - Error source type.
 * @param [in]    callback      - The callback function of type clx_swc_err_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_err_cb_register(const uint32 unit,
                        const clx_swc_err_type_t error,
                        const clx_swc_err_func_t callback,
                        void *ptr_cookie);

/**
 * @brief Deregister error callback function.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    error         - Error source type.
 * @param [in]    callback      - The callback function of type clx_swc_err_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_err_cb_deregister(const uint32 unit,
                          const clx_swc_err_type_t error,
                          const clx_swc_err_func_t callback,
                          void *ptr_cookie);

/**
 * @brief Get device information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_device_info    - The device information.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_dev_info_get(const uint32 unit, clx_swc_device_info_t *ptr_device_info);

/**
 * @brief Get port bitmap of current config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_port_config    - Port bitmaps of current config.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_swc_port_cfg_get(const uint32 unit, clx_swc_port_cfg_t *ptr_port_config);

/**
 * @brief Get resource capacity.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     type        - Resource type.
 * @param [in]     param       - Parameter if necessary.
 * @param [out]    ptr_size    - Size of capacity.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_capacity_get(const uint32 unit,
                     const clx_swc_rsrc_t type,
                     const uint32 param,
                     uint32 *ptr_size);

/**
 * @brief Get resource usage.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     type       - Resource type.
 * @param [in]     param      - Parameter if necessary.
 * @param [out]    ptr_cnt    - Count of usage.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_usage_get(const uint32 unit, const clx_swc_rsrc_t type, const uint32 param, uint32 *ptr_cnt);

/**
 * @brief Set clock servo mode.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    mode    - Clock servo mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_cso_mode_set(const uint32 unit, const clx_swc_cso_mode_t mode);

/**
 * @brief Get clock servo mode.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [out]    ptr_mode    - Clock servo mode.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_cso_mode_get(const uint32 unit, clx_swc_cso_mode_t *ptr_mode);

/**
 * @brief Get chip temperature.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit               - Device unit number.
 * @param [out]    ptr_temperature    - Chip temperature.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_chip_temp_get(const uint32 unit, int32 *ptr_temperature);

/**
 * @brief Get chip temperature.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit                    - Device unit number.
 * @param [out]    ptr_temperature_list    - Chip temperature list.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_chip_temp_list_get(const uint32 unit, clx_swc_thermal_list_t *ptr_temperature_list);

/**
 * @brief Set RX reason action. Assign drop reason code if fowarding action is dropping.
 *        Assign CPU qeueu if fowarding action is copy to CPU or redirect to CPU.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    rx_reason_code      - Rx reason code.
 * @param [in]    rx_reason_action    - Rx reason aciton.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_rsn_act_set(const uint32 unit,
                    const clx_pkt_rx_reason_t rx_reason_code,
                    const clx_swc_rsn_act_t *rx_reason_action);

/**
 * @brief Get RX reason action. Get drop reason code or cpu queue.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    rx_reason_code      - Rx reason code.
 * @param [in]    rx_reason_action    - Rx reason aciton.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_rsn_act_get(const uint32 unit,
                    const clx_pkt_rx_reason_t rx_reason_code,
                    clx_swc_rsn_act_t *rx_reason_action);

/**
 * @brief This function is to set reason priority.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    rx_reason_code    - RX reason code.
 * @param [in]    priority          - Reason priority.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_rsn_pri_set(const uint32 unit,
                    const clx_pkt_rx_reason_t rx_reason_code,
                    const uint32 priority);

/**
 * @brief This function is to get reason priority.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     rx_reason_code    - RX reason code.
 * @param [out]    priority          - Reason priority.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_rsn_pri_get(const uint32 unit, const clx_pkt_rx_reason_t rx_reason_code, uint32 *priority);

/**
 * @brief This function is to set all exceptions action.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    en      - Restore the exception action.
 * @param [in]    act     - Action.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_excpt_set(const uint32 unit, const uint32 en, const clx_fwd_action_t act);

/**
 * @brief This function is to get Tod Info.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_tod_info_get(const uint32 unit);

/**
 * @brief This function is to get chip configurable information.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    type     - Type for get chip configurable information.
 * @param [in]    para0    - Parameter0 if necessary.
 * @param [in]    para1    - Parameter1 if necessary ptr_value.
 * @return        CLX_E_OK             - Operation success.
 * @return        CLX_E_NOT_SUPPORT    - Not support.
 * @return        other                - Operate fail.
 */
clx_error_no_t
clx_swc_chip_cfg_info_get(const uint32 unit,
                          const clx_swc_chip_cfg_info_type_t type,
                          const uint32 para0,
                          const uint32 para1,
                          uint32 *ptr_value);

/**
 * @brief This function retrieves the string name based on the index.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     data_type    - Data Type.
 * @param [in]     index        - Index.
 * @param [in]     str_len      - String length.
 * @param [out]    str_name     - String name.
 * @return         CLX_E_OK             - Operation success.
 * @return         CLX_E_NOT_SUPPORT    - Not support.
 * @return         other                - Operate fail.
 */
clx_error_no_t
clx_swc_str_name_get(const uint32 unit,
                     const clx_swc_data_type_t data_type,
                     const uint32 index,
                     const uint32 str_len,
                     char *str_name);

/**
 * @brief To get packet hash path.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     hash_type       - Hash type.
 * @param [in]     ptr_hash_key    - Pointer of hash key.
 * @param [in]     id              - Lag id / ECMP group id.
 * @param [out]    ptr_rslt        - Pointer of result.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_swc_hsh_path_get(const uint32 unit,
                     const clx_swc_hsh_pkt_type_t hash_type,
                     const clx_swc_flow_hsh_key_t *ptr_hash_key,
                     const uint32 id,
                     clx_swc_hsh_path_rslt_info_t *ptr_rslt);

/**
 * @brief To get hash path key.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hash_type      - Hash type.
 * @param [in]     pkt_info       - Packet info.
 * @param [out]    ptr_key_bmp    - Pointer of hash key bitmap.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_swc_hsh_path_key_get(const uint32 unit,
                         const clx_swc_hsh_pkt_type_t hash_type,
                         const clx_swc_hsh_path_pkt_info_t pkt_info,
                         clx_swc_hsh_key_bmp_t *ptr_key_bmp);

/**
 * @brief This API is used to set selective flow config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ptr_select_cfg    - Selective flow config.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_NOT_SUPPORT      - Not support.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_selective_flow_mir_set(const uint32 unit,
                               const clx_swc_selective_flow_cfg_t *ptr_select_cfg);

/**
 * @brief This API is used to get selective flow config.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [out]    ptr_select_cfg    - Selective flow config.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_NOT_SUPPORT      - Not support.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_swc_selective_flow_mir_get(const uint32 unit, clx_swc_selective_flow_cfg_t *ptr_select_cfg);
#endif
