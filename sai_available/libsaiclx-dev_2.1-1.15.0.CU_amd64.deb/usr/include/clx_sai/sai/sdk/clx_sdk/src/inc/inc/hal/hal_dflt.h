/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_dflt.h
 * PURPOSE:
 *  1. Provide definition for sdk default
 *  2. Provide registration/deregistration
 *  3. Provide data structure declaration
 *  4. Provide
 *
 * NOTES:
 */

#ifndef HAL_DFLT_H
#define HAL_DFLT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_module.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
   ----USER CONFIG (follow clx_cfg_type_t enum sequence)----
 */
/* SWC module */
#define HAL_DFLT_CFG_CHIP_MODE (0)
/* chip operating mode. 0: legacy mode; 1:hybrid mode */

/* PORT module related configuration */
#define HAL_DFLT_CFG_PORT_MAX_SPEED (0)
/* port max speed is not applied */
#define HAL_DFLT_CFG_PORT_LANE_NUM (0)
/* port lane num is not applied */
#define HAL_DFLT_CFG_PORT_TX_LANE (0)
/* port tx lane is not applied */
#define HAL_DFLT_CFG_PORT_RX_LANE (0)
/* port rx lane is not appied */
#define HAL_DFLT_CFG_PORT_TX_POLARITY_REV (0)
/* port tx polarity rev is not applied */
#define HAL_DFLT_CFG_PORT_RX_POLARITY_REV (0)
/* port rx polarity rev is not applied */
#define HAL_DFLT_CFG_PORT_EXT_LANE (0)
/* port ext lane is not applied */
#define HAL_DFLT_CFG_PORT_VALID (0)
/* port valid is not applied */

/* l2 module related configuration */
#define HAL_DFLT_CFG_L2_THREAD_PRI   (50)
#define HAL_DFLT_CFG_L2_THREAD_STACK (64 * 1024)
/* customize L2 thread stack size in bytes */
#define HAL_DFLT_CFG_L2_ADDR_MODE (0)
/* L2 address operation mode. 0: Polling mode, 1: FIFO mode */
#define HAL_DFLT_CFG_L2_POLLING_INTERVAL (4000)
/* Times (msec) to poll all L2 FDB entries */
#define HAL_DFLT_CFG_L2_TRAV_THREAD_PRI       (60)
#define HAL_DFLT_CFG_L2_TRAV_THREAD_STACK     (64 * 1024)
#define HAL_DFLT_CFG_L2_CALLBACK_THREAD_PRI   (50)
#define HAL_DFLT_CFG_L2_CALLBACK_THREAD_STACK (64 * 1024)

/* PKT module related configuration */
#define HAL_DFLT_CFG_PKT_TX_GPD_NUM    (1024)
#define HAL_DFLT_CFG_PKT_RX_GPD_NUM    (1024)
#define HAL_DFLT_CFG_PKT_RX_SCHED_MODE (0)
/* 0: RR mode, 1: WRR mode                      */
#define HAL_DFLT_CFG_PKT_TX_QUEUE_LEN    (HAL_DFLT_CFG_PKT_TX_GPD_NUM * 10)
#define HAL_DFLT_CFG_PKT_RX_QUEUE_LEN    (HAL_DFLT_CFG_PKT_RX_GPD_NUM * 10)
#define HAL_DFLT_CFG_PKT_RX_QUEUE_WEIGHT (0)
/* valid while CLX_CFG_TYPE_PKT_RX_SCHED_MODE is 1
 * param0: queue
 * param1: NA
 * value : weight
 */
#define HAL_DFLT_CFG_PKT_RX_ISR_THREAD_PRI   (80)
#define HAL_DFLT_CFG_PKT_RX_ISR_THREAD_STACK (64 * 1024)
/* customize PKT RX ISR thread stack size in bytes */
#define HAL_DFLT_CFG_PKT_RX_FREE_THREAD_PRI   (80)
#define HAL_DFLT_CFG_PKT_RX_FREE_THREAD_STACK (64 * 1024)
/* customize PKT RX free thread stack size in bytes */
#define HAL_DFLT_CFG_PKT_TX_ISR_THREAD_PRI   (80)
#define HAL_DFLT_CFG_PKT_TX_ISR_THREAD_STACK (64 * 1024)
/* customize PKT TX ISR thread stack size in bytes */
#define HAL_DFLT_CFG_PKT_TX_FREE_THREAD_PRI   (80)
#define HAL_DFLT_CFG_PKT_TX_FREE_THREAD_STACK (64 * 1024)
/* customize PKT TX free thread stack size in bytes */
#define HAL_DFLT_CFG_PKT_ERROR_ISR_THREAD_PRI   (80)
#define HAL_DFLT_CFG_PKT_ERROR_ISR_THREAD_STACK (64 * 1024)
/* customize PKT ERROR ISR thread stack size in bytes */
#define HAL_DFLT_CFG_PKT_DMA_ENHANCE_ENABLE (0)

/* STAT module related configuration */
#define HAL_DFLT_CFG_CNT_THREAD_PRI   (0)
#define HAL_DFLT_CFG_CNT_THREAD_STACK (0)
/* customize CNT thread stack size in bytes */

/* IFMON module related configuration */
#define HAL_DFLT_CFG_IFMON_THREAD_PRI   (0)
#define HAL_DFLT_CFG_IFMON_THREAD_STACK (0)
/* customize IFMON thread stack size in bytes */

/* share memory related configuration */
#define HAL_DFLT_CFG_SHARE_MEM_SDN_ENTRY_NUM (0)
/* SDN flow table entry number from share memory */
#define HAL_DFLT_CFG_SHARE_MEM_L3_ENTRY_NUM (0)
/* L3 entry number from share memory */
#define HAL_DFLT_CFG_SHARE_MEM_L2_ENTRY_NUM (0)
/* L2 entry number from share memory */

/* DLB related configuration */
#define HAL_DFLT_CFG_DLB_MONITOR_MODE (0)
/* DLB monitor mode. 1: async, 0: sync */
#define HAL_DFLT_CFG_DLB_LAG_MONITOR_THREAD_PRI         (0)
#define HAL_DFLT_CFG_DLB_LAG_MONITOR_THREAD_SLEEP_TIME  (0)
#define HAL_DFLT_CFG_DLB_L3_MONITOR_THREAD_PRI          (0)
#define HAL_DFLT_CFG_DLB_L3_MONITOR_THREAD_SLEEP_TIME   (0)
#define HAL_DFLT_CFG_DLB_L3_INTR_THREAD_PRI             (0)
#define HAL_DFLT_CFG_DLB_NVO3_MONITOR_THREAD_PRI        (0)
#define HAL_DFLT_CFG_DLB_NVO3_MONITOR_THREAD_SLEEP_TIME (0)
#define HAL_DFLT_CFG_DLB_NVO3_INTR_THREAD_PRI           (0)

/* l3 related configuration */
#define HAL_DFLT_CFG_L3_ECMP_MIN_BLOCK_SIZE                        (0)
#define HAL_DFLT_CFG_L3_ECMP_BLOCK_SIZE                            (0)
#define HAL_DFLT_CFG_TCAM_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM (0)
#define HAL_DFLT_CFG_TCAM_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM  (0)
#define HAL_DFLT_CFG_TCAM_L3_WITH_IPV6_PREFIX_128_REGION_RSVD      (1)

/* share memory related configuration */
#define HAL_DFLT_CFG_HASH_L2_FDB_REGION_ENTRY_NUM                  (0)
#define HAL_DFLT_CFG_HASH_L2_GROUP_REGION_ENTRY_NUM                (0)
#define HAL_DFLT_CFG_HASH_SECURITY_REGION_ENTRY_NUM                (0)
#define HAL_DFLT_CFG_HASH_L3_WITH_IPV6_PREFIX_128_REGION_ENTRY_NUM (0)
#define HAL_DFLT_CFG_HASH_L3_WITH_IPV6_PREFIX_64_REGION_ENTRY_NUM  (0)
#define HAL_DFLT_CFG_HASH_L3_WITHOUT_PREFIX_REGION_ENTRY_NUM       (0)
#define HAL_DFLT_CFG_HASH_L3_RPF_REGION_ENTRY_NUM                  (0)
#define HAL_DFLT_CFG_HASH_FLOW_REGION_ENTRY_NUM                    (0)

#define HAL_DFLT_CFG_PORT_FC_MODE (0)
/* only use to init port TM buffer
 * configuration for specific FC mode,
 * which not enable/disable FC/PFC
 * for the port/pcp.
 * param0: port.
 * param1: Invalid.
 * value : 0, FC disable;
 *         1, 802.3x FC;
 *         2, PFC.
 */
#define HAL_DFLT_CFG_PORT_PFC_STATE (0)
/* valid while CLX_CFG_TYPE_PORT_TYPE_FC_MODE
 * of the port is PFC.
 * param0: port.
 * param1: pcp.
 * value : 0, PFC disable;
 *         1, PFC enable.
 */
#define HAL_DFLT_CFG_PORT_PFC_QUEUE_STATE (0)
/* valid while CLX_CFG_TYPE_PORT_TYPE_FC_MODE
 * of the port is PFC.
 * param0: port.
 * param1: queue.
 * value : 0, PFC disable;
 *         1, PFC enable;
 */
#define HAL_DFLT_CFG_PORT_PFC_MAPPING (0)
/* valid while CLX_CFG_TYPE_PORT_FC_MODE
 * of the port is PFC.
 * param0: port.
 * param1: queue.
 * value : PCP bitmap;
 *
 */
#define HAL_DFLT_CFG_USE_UNIT_PORT (0)
/* use UNIT_PORT or native port of clx_port_t
 * 1 : UNIT_PORT, 0 : native port
 */
#define HAL_DFLT_CFG_MAC_VLAN_ENABLE (0)
/* use dadicate mac vlan table */
#define HAL_DFLT_CFG_CPI_PORT_MODE (0)
/* use to init CPI port working mode.
 * param0: CPI port number.
 * param1: NA.
 * value : 0, CPI mode.
 *         1, Ether mode.
 */
#define HAL_DFLT_CFG_PHY_ADDR (0)
#define HAL_DFLT_CFG_LED_CFG  (0)

#define HAL_DFLT_CFG_FABRIC_MODE_ENABLE (0)
/* set value 0: Non-farbic chip mode. (default)
 * set value 1: Fabric chip mode.
 */
#define HAL_DFLT_CFG_ACL_TCP_FLAGS_ENCODE_ENABLE (1)
/* set value 0: Do not encode tcp flags at acl entry.
 *              (Can only match bit 0-6 of tcp flags.)
 * set value 1: Encode tcp flags at acl entry. (default)
 */
#define HAL_DFLT_CFG_TCAM_ECC_SCAN_ENABLE (0)
/* set value 0: Disable ECC TCAM scanning. (default)
 * set value 1: Enable  ECC TCAM scanning.
 */
#define HAL_DFLT_CFG_PORT_BUF_MAX (0)

#define HAL_DFLT_CFG_MPLS_SR_NUM (0)
/* MPLS Segment Routing
 * value: encapsulation number
 */
#define HAL_DFLT_CFG_L2_BYPASS_LAG_PRUNE_GROUP_NUM (0)
/* default value: 0 */
#define HAL_DFLT_CFG_L3_BYPASS_LAG_PRUNE_GROUP_NUM (0)
/* default value: 0 */

/* TELEMETRY related configuration */
#define HAL_DFLT_CFG_TELM_TYPE                   (0x0)
#define HAL_DFLT_CFG_TELM_PROFILE_ID             (0x0)
#define HAL_DFLT_CFG_TELM_IOAM_THREAD_PRI        (50)
#define HAL_DFLT_CFG_TELM_IOAM_THREAD_STACK_SIZE (64 * 1024)

/* l3 related configuration */
#define HAL_DFLT_CFG_TCAM_L3_SIP_ENABLE (0)
/* default value: 0, enable bulk route */
#define HAL_DFLT_CFG_L3_ROUTE_LABEL_ENABLE (1)
/* set value 0: disable acl label on L3 routing entry.
 * set value 1: enable acl label on L3 routing entry (default).
 */
#define HAL_DFLT_CFG_L3_BULK_ROUTE_ENABLE (1)
#define HAL_DFLT_CFG_L3_PRE_ALLOC_ENABLE  (1)
/* default value: 0, to expand TCAM capacity */
#define HAL_DFLT_CFG_L3_ECMP_FDL_ENABLE (0)
/* default value: 0, to reserve adj for FDL */

#define HAL_DFLT_CFG_HASH_L3_IPV4_PREFIX_LENGTH_ENTRY_NUM (0)
/* param0: prefix-length (1~32) */
/* param1: 1: vrf, 0: global */
/* value: entry number */

#define HAL_DFLT_CFG_HASH_L3_IPV6_PREFIX_LENGTH_ENTRY_NUM (0)
/* param0: prefix-length (1~128) */
/* param1: 1: vrf, 0: global */
/* value: entry number */

#define HAL_DFLT_CFG_ACL_DROP_REDIRECT_CPU_PKT (0)
/* set value 0: acl drop_cpu action would not drop redirect to cpu pkt.
 *              (default)
 * set value 1: acl drop_cpu action would drop redirect to cpu pkt.
 */
#define HAL_DFLT_CFG_STACKING_CHIP_PORT_NUM (0)
/* In stacking/chassis system, max used port num per device.
 * default value: hw default max port
 */

#define HAL_DFLT_CFG_SEC_DOS_CHECK_ENABLE (1)
/* set value 0: disable.
 * set value 1: enable (default).
 */

/* NAMING CONSTANT DECLARATIONS
   ----DEFAULT PROPERTY ----
 */
/* ---- VLAN ---- */
#define HAL_DFLT_VLAN (1)
#define HAL_DFLT_BDID (1)

/* ---- PORT ---- */
#define HAL_DFLT_L2_MTU       (1536)
#define HAL_DFLT_TPID         (0x8100)
#define HAL_DFLT_INVALID_TPID (0x0)

/* ---- IFMON ---- */

/* ---- L2 ---- */

/* ---- STP ---- */
#define HAL_DFLT_STP_ID (0)

/* ---- LAG ---- */

/* ---- MIR ---- */

/* ---- L3 ---- */

/* ---- L3T ---- */

/* ---- QOS ---- */

/* ---- METER ---- */

/* ---- PKT ---- */

/* ---- ACL ---- */
#define HAL_DFLT_CFG_TYPE_ACL_HW_INSERT_DESCENDING (0)
/* set value 0: false (default).
 * set value 1: true.
 */

/* ---- CFG ---- */
#define HAL_DFLT_CFG_TYPE_SWITCH_MODE (0)
/* set value 0: legacy ethernet mode (default).
 * set value 1: experiement mode (Tapping).
 */
#define HAL_DFLT_CFG_TYPE_PORT_DI_MODE (0)

/* ---- STAT ---- */

/* ---- SEC ---- */

/* ---- SFLOW ---- */

/* ---- TM ---- */

/* ---- SWC ---- */

/* ---- SDN ---- */

/* ---- MPLS ---- */

/* ---- STK ---- */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef clx_error_no_t (*hal_dflt_set_switch_property_t)(const uint32 unit);   /* set/reset unit
                                                                                  default */
typedef clx_error_no_t (*hal_dflt_port_default_set_func_t)(const uint32 unit,
                                                           const uint32 port); /* set/reset port
                                                                                  default */

typedef struct {
    uint32 module_count;
    clx_module_t *ptr_module;
} hal_dflt_config_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* register callback function */

/* set default config */
clx_error_no_t
hal_dflt_default_config_set(const uint32 unit, clx_module_t *ptr_module, const uint32 module_num);
clx_error_no_t
hal_dflt_port_default_config_set(const uint32 unit, const uint32 port);

/* untie default config */
clx_error_no_t
hal_dflt_default_config_reset(const uint32 unit, clx_module_t *ptr_module, const uint32 module_num);
clx_error_no_t
hal_dflt_port_default_config_reset(const uint32 unit, const uint32 port);

#endif
