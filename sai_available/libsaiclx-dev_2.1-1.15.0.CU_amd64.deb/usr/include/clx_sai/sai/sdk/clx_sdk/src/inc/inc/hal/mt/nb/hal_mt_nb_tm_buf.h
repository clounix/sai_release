/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_tm_buf_buf.h
 * PURPOSE:
 *      It provides hal traffic management module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NB_TM_BUF_H
#define HAL_MT_NB_TM_BUF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_tm.h>
#include <osal/osal.h>
#include <hal/hal_tbl.h>
#include <hal/hal.h>
#include <hal/hal_const_cmn.h>
#include <hal/mt/nb/hal_mt_nb_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_NB_TM_CELL_SIZE (256)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct hal_mt_nb_tm_buf_queue_status_s {
    uint32 is_lossless; /* The buffer of the queue is lossy or lossless */
    uint32 egr_type;    /* The ECN mark status:
                           0:HAL_MT_NB_TM_BUF_EGR_PROF_TYPE_TAIL_DROP,
                           1:HAL_MT_NB_TM_BUF_EGR_PROF_TYPE_WRED_DROP,
                           2:HAL_MT_NB_TM_BUF_EGR_PROF_TYPE_WRED_ECN */
} hal_mt_nb_tm_buf_queue_status_t;

typedef struct hal_mt_nb_tm_buf_egr_pool_th_s {
    uint32 min;                   /* Minimum guarantee threshold */
    uint32 mid_th;                /* Middle threshold for wred drop or ecn */
    uint32 max_th;                /* Maximum threshold for wred drop or ecn */
} hal_mt_nb_tm_buf_egr_pool_th_t; /* Only NB support */

typedef enum hal_mt_nb_tm_buf_egr_prof_type_e {
    HAL_MT_NB_TM_BUF_EGR_PROF_TYPE_TAIL_DROP = 0,
    HAL_MT_NB_TM_BUF_EGR_PROF_TYPE_WRED_DROP,
    HAL_MT_NB_TM_BUF_EGR_PROF_TYPE_WRED_ECN,
    HAL_MT_NB_TM_BUF_EGR_PROF_TYPE_LAST
} hal_mt_nb_tm_buf_egr_prof_type_t;
/* HAL layer API structure */

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The function is used to init TM buffer management HW & SW DB.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_buf_rsrc_init(const uint32 unit);

/**
 * @brief The function is used to deinit TM buffer management HW & SW DB.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_buf_rsrc_deinit(const uint32 unit);

/**
 * @brief The function is used to init TM buffer management configuration.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_buf_cfg_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_buf_usage_get(const uint32 unit,
                           const uint32 port,
                           const clx_tm_handler_t handler,
                           const clx_tm_buf_stat_type_t buf_usage_type,
                           uint32 *ptr_usage);

clx_error_no_t
hal_mt_nb_tm_buf_wb_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_buf_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_buf_watermark_get(const uint32 unit,
                               const uint32 port,
                               const clx_tm_handler_t handler,
                               const clx_tm_buf_stat_type_t buf_watermark_type,
                               uint32 *ptr_watermark);

clx_error_no_t
hal_mt_nb_tm_buf_watermark_clear(const uint32 unit,
                                 const uint32 port,
                                 const clx_tm_handler_t handler,
                                 const clx_tm_buf_stat_type_t buf_watermark_type);

clx_error_no_t
hal_mt_nb_tm_buf_task_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_buf_task_deinit(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_buf_port_dflt_set(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_tm_buf_prof_create(const uint32 unit,
                             const clx_tm_buf_prof_type_t buf_prof_type,
                             const uint32 prof_id);

clx_error_no_t
hal_mt_nb_tm_buf_prof_destroy(const uint32 unit,
                              const clx_tm_buf_prof_type_t type,
                              const uint32 prof_id);

clx_error_no_t
hal_mt_nb_tm_buf_prof_set(const uint32 unit, const uint32 prof_id, const clx_tm_buf_prof_t *prof);

clx_error_no_t
hal_mt_nb_tm_buf_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_buf_prof_t *prof);

clx_error_no_t
hal_mt_nb_tm_buf_cfg_set(const uint32 unit,
                         const uint32 port,
                         const clx_tm_handler_t handler,
                         const clx_tm_buf_cfg_t *config);

clx_error_no_t
hal_mt_nb_tm_buf_cfg_get(const uint32 unit,
                         const uint32 port,
                         const clx_tm_handler_t handler,
                         clx_tm_buf_cfg_t *config);

clx_error_no_t
hal_mt_nb_tm_buf_wred_prof_create(const uint32_t unit, const uint32_t profile_id);

clx_error_no_t
hal_mt_nb_tm_buf_wred_prof_destroy(const uint32_t unit, const uint32_t profile_id);

clx_error_no_t
hal_mt_nb_tm_buf_wred_prof_set(const uint32 unit,
                               const uint32 prof_id,
                               const clx_tm_wred_prof_t *ptr_wred_prof);

clx_error_no_t
hal_mt_nb_tm_buf_wred_prof_get(const uint32 unit,
                               const uint32 prof_id,
                               clx_tm_wred_prof_t *ptr_wred_prof);
clx_error_no_t
hal_mt_nb_tm_buf_wred_cfg_set(const uint32 unit,
                              const uint32 port,
                              const clx_tm_handler_t handler,
                              const clx_tm_wred_cfg_t *ptr_wred_cfg);

clx_error_no_t
hal_mt_nb_tm_buf_wred_cfg_get(const uint32 unit,
                              const uint32 port,
                              const clx_tm_handler_t handler,
                              clx_tm_wred_cfg_t *ptr_wred_cfg);

clx_error_no_t
hal_mt_nb_tm_buf_oq_cfg_update(const uint32 unit, const uint32 port, const uint32 queue);

clx_error_no_t
hal_mt_nb_tm_buf_histogram_cfg_set(const uint32 unit, const clx_tm_histogram_cfg_t *ptr_config);

clx_error_no_t
hal_mt_nb_tm_buf_histogram_cfg_get(const uint32 unit, clx_tm_histogram_cfg_t *ptr_config);

clx_error_no_t
hal_mt_nb_tm_buf_histogram_cb_register(const uint32 unit,
                                       const uint32 port,
                                       const clx_tm_histogram_cb_t func,
                                       void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tm_buf_histogram_cb_deregister(const uint32 unit,
                                         const uint32 port,
                                         const clx_tm_histogram_cb_t func,
                                         void *ptr_cookie);

clx_error_no_t
hal_mt_nb_tm_buf_dynamic_thd_set(const uint32 unit,
                                 const clx_tm_buf_dynamic_type_t type,
                                 const uint32 enable,
                                 const uint32 factor);

clx_error_no_t
hal_mt_nb_tm_buf_dynamic_thd_get(const uint32 unit,
                                 const clx_tm_buf_dynamic_type_t type,
                                 uint32 *enable,
                                 uint32 *factor);

clx_error_no_t
hal_mt_nb_tm_buf_share_pool_size_set(const uint32 unit,
                                     const uint32 lossy_pool_size,
                                     const uint32 lossless_pool_size,
                                     const boolean is_egr);

clx_error_no_t
hal_mt_nb_tm_buf_share_pool_size_get(const uint32 unit,
                                     uint32 *ptr_lossy_pool_size,
                                     uint32 *ptr_lossless_pool_size,
                                     const boolean is_egr);

clx_error_no_t
hal_mt_nb_tm_buf_headroom_size_set(const uint32 unit, const uint32 headroom_size);

clx_error_no_t
hal_mt_nb_tm_buf_headroom_size_get(const uint32 unit, uint32 *headroom_size);

clx_error_no_t
hal_mt_nb_tm_buf_red_base_yellow_en_set(const uint32 unit, const uint32 enable);

clx_error_no_t
hal_mt_nb_tm_buf_red_base_yellow_en_get(const uint32 unit, uint32 *ptr_enable);

clx_error_no_t
hal_mt_nb_tm_buf_egr_lvl_sel_set(const uint32 unit, const uint32 level_sel);

clx_error_no_t
hal_mt_nb_tm_buf_egr_lvl_sel_get(const uint32 unit, uint32 *ptr_level_sel);

clx_error_no_t
hal_mt_nb_tm_buf_dynamic_pool_set(const uint32_t unit,
                                  const uint32_t port,
                                  const clx_tm_handler_t handler,
                                  const uint32_t type,
                                  const uint32_t pool);

clx_error_no_t
hal_mt_nb_tm_buf_dynamic_pool_get(const uint32_t unit,
                                  const uint32_t port,
                                  const clx_tm_handler_t handler,
                                  const uint32_t type,
                                  uint32_t *ptr_pool);
clx_error_no_t
hal_mt_nb_tm_buf_dflt_set(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_buf_port_sq_depth_is_zero_chk(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_tm_buf_sq_policy_set(const uint32 unit, const uint32 port, const uint32 queue);

clx_error_no_t
hal_mt_nb_tm_buf_oq_policy_set(const uint32 unit,
                               const uint32 port,
                               const clx_tm_handler_t handler);

clx_error_no_t
hal_mt_nb_tm_buf_sw_tbl_set(const uint32 unit,
                            const uint32 port,
                            const uint32 uc_queue,
                            const uint32 lossless,
                            const uint32 type);

clx_error_no_t
hal_mt_nb_tm_buf_sw_tbl_get(const uint32 unit,
                            const uint32 oq_index,
                            hal_mt_nb_tm_buf_queue_status_t *ptr_status);

boolean
hal_mt_nb_tm_buf_is_flush_chip_traffic_chk(const uint32 unit, const clx_tm_buf_prof_type_t type);

clx_error_no_t
hal_mt_nb_tm_buf_histogram_cnt_clear(const uint32 unit,
                                     const uint32 port,
                                     const clx_tm_handler_t handler);
clx_error_no_t
hal_mt_nb_tm_buf_egr_pool_thd_set(const uint32 unit,
                                  const uint32 pool_id,
                                  const hal_mt_nb_tm_buf_egr_pool_th_t *ptr_th);
clx_error_no_t
hal_mt_nb_tm_buf_egr_pool_thd_get(const uint32 unit,
                                  const uint32 pool_id,
                                  hal_mt_nb_tm_buf_egr_pool_th_t *ptr_th);
clx_error_no_t
hal_mt_nb_tm_buf_port_flush(const uint32 unit, const uint32 port, const uint32 enable);

clx_error_no_t
hal_mt_nb_tm_buf_link_up_port_flush(const uint32 unit, const uint32 port, const uint32 enable);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_en(const uint32 unit, const boolean enable);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_en_set(const uint32 unit, const uint32 enable);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_en_get(const uint32 unit, uint32 *enable);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_prof_create(const uint32 unit, const uint32 prof_id);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_prof_destroy(const uint32 unit, const uint32 prof_id);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_prof_set(const uint32 unit,
                                 const uint32 prof_id,
                                 const clx_tm_mburst_prof_t *prof);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_prof_get(const uint32 unit,
                                 const uint32 prof_id,
                                 clx_tm_mburst_prof_t *prof);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_cfg_set(const uint32 unit,
                                const uint32 port,
                                const clx_tm_handler_t handler,
                                const clx_tm_mburst_cfg_t *ptr_cfg);

clx_error_no_t
hal_mt_nb_tm_buf_mburst_cfg_get(const uint32 unit,
                                const uint32 port,
                                const clx_tm_handler_t handler,
                                clx_tm_mburst_cfg_t *ptr_cfg);

clx_error_no_t
hal_mt_nb_tm_buf_sq_tcg_map_set(const uint32 unit,
                                const uint32 port,
                                const uint32 sq,
                                const uint32 tcg);

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The function is used to set TM BAC global lossless.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    tc_bmp    - The bit map of BAC global lossless.
 * @param [in]    mode      - PFC mode.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_buf_glb_lossless_set(const uint32 unit, const uint32 tc_bmp, hal_tm_fc_t mode);

/**
 * @brief The function is used to get TM BAC global lossless bit map.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     internal      - Internal or external.
 * @param [out]    ptr_tc_bmp    - The bit map of BAC global lossless.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_buf_glb_lossless_get(const uint32 unit, const boolean internal, uint32 *ptr_tc_bmp);

#endif /*end of HAL_MT_NB_TM_BUF_H*/
