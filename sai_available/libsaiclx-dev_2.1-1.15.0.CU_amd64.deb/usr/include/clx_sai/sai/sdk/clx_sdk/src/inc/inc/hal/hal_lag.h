/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  HAL_LAG.h
 * PURPOSE:
 *  Define the declartion for LAG module.
 *
 * NOTES:
 *
 */

#ifndef HAL_LAG_H
#define HAL_LAG_H

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_LAG_PORT_MAX_NUM               (128) /* Maximum for all chips */
#define HAL_LAG_GROUP_MAX_MEMBER_NUM       (512) /* Maximum for all chips */
#define HAL_LAG_PORT_LIST_ENTRY_NUM        (8192)
#define HAL_LAG_PORT_LIST_ENTRY_ID_MIN     (0)
#define HAL_LAG_PORT_LIST_ENTRY_ID_MAX     (HAL_LAG_PORT_LIST_ENTRY_NUM - 1)
#define HAL_LAG_PORT_LIST_RSVD_INVALID_IDX (0)
#define HAL_LAG_MEMBER_PBM_WORD_NUM        ((HAL_PHY_PORT_NUM + 31) / 32)
#define HAL_LAG_MEMBER_FLAG_NEW            (1UL << 0)
#define HAL_LAG_MEMBER_FLAG_ORIG           (1UL << 1)
#define HAL_LAG_HSH_SEL_HSH_NUM            (1024)

#define HAL_PHY_PORT_DI_MAX_NUM (2048)
#define HAL_LAG_LIST_IS_ORI     (0)
#define HAL_LAG_LIST_IS_ACT     (1)

#define HAL_LAG_PHY_PORT_ENTRY_SIZE (MT_NB_CDB_TDS_RSLT_POC_WORDS)

#define HAL_LAG_TAPPING_DISABLE (0)
/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_LAG_LOCK(unit) \
    HAL_COMMON_LOCK_RESOURCE(&_ext_hal_lag_cb[(unit)].mutex_sema_id, CLX_SEMAPHORE_WAIT_FOREVER)

#define HAL_LAG_UNLOCK(unit) HAL_COMMON_FREE_RESOURCE(&_ext_hal_lag_cb[(unit)].mutex_sema_id)
/* HAL_LAGID_BITMAP_T is the data type for physical port bitmap. */
#define HAL_LAGID_BITMAP_SIZE CLX_BITMAP_SIZE(HAL_LAG_PORT_MAX_NUM)
typedef uint32 HAL_LAGID_BITMAP_T[HAL_LAGID_BITMAP_SIZE];

#define HAL_LAGID_ADD(bitmap, lag_id) (((bitmap)[(lag_id) / 32]) |= (1U << ((lag_id) % 32)))
#define HAL_LAGID_DEL(bitmap, lag_id) (((bitmap)[(lag_id) / 32]) &= ~(1U << ((lag_id) % 32)))
#define HAL_LAGID_CHK(bitmap, lag_id) ((((bitmap)[(lag_id) / 32] & (1U << ((lag_id) % 32)))) != 0)

#define HAL_LAGID_FOREACH(bitmap, lag_id)                     \
    for (lag_id = 0; lag_id < HAL_LAG_PORT_MAX_NUM; lag_id++) \
        if (HAL_LAGID_CHK(bitmap, lag_id))

/* DATA TYPE DECLARATIONS
 */
typedef enum HAL_LAG_UPDATE_MODE_E {
    HAL_LAG_UPDATE_STATUS = 0, /* ori -> active,   update status active->new
                                  act -> ori/both, update status new->active */
    HAL_LAG_UPDATE_BASE,       /* both -> ori, sync ori and act base and update status active->new
                               both -> act, sync ori and act base and update status new->active */
    HAL_LAG_UPDATE_LAST
} HAL_LAG_UPDATE_MODE_T;

typedef struct HAL_LAG_CB_S {
    uint32 port_list_ori_cont_entry_num_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    uint32 port_list_ori_alloc_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    uint32 port_list_act_cont_entry_num_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    uint32 port_list_act_alloc_arr[HAL_LAG_PORT_LIST_ENTRY_NUM];
    clx_semaphore_id_t mutex_sema_id;
    clx_lag_type_t lag_type[HAL_LAG_PORT_MAX_NUM];
    uint32 lag_flag[HAL_LAG_PORT_MAX_NUM]; /* HAL_LAG_CB_XXX */
    uint32 lag_member_auto_update;
    uint32 lag_member_skip_port_check;
    uint32 lag_tapping;
    uint32 resilient_en;
    /* algorithm_mode */
    clx_lag_algorithm_mode_t algorithm_mode[HAL_LAG_PORT_MAX_NUM];
} HAL_LAG_CB_T;
#define HAL_LAG_CB_MEMBER_DEL          (1U << 0)
#define HAL_LAG_CB_MEMBER_SORT         (1U << 1)
#define HAL_LAG_CB_WITH_ID             (1U << 2)
#define HAL_LAG_CB_MEMBER_ETH_PORT     (1U << 3)
#define HAL_LAG_CB_MEMBER_CPI_RAW_PORT (1U << 4)

typedef enum {
    HAL_LAG_CPU_DI_CPI0_DI = 0,
    HAL_LAG_CPU_DI_CPI1_DI,
    HAL_LAG_CPU_DI_CPI0_LAG_DI,
    HAL_LAG_CPU_DI_CPI1_LAG_DI,
    HAL_LAG_CPU_DI_LAST
} HAL_LAG_CPU_DI_FLAG_T;

typedef enum {
    HAL_LAG_PORT_EVENT_CREATE = 0,
    HAL_LAG_PORT_EVENT_DESTROY,
    HAL_LAG_PORT_EVENT_SET_MEMBER,
    HAL_LAG_PORT_EVENT_LAST
} HAL_LAG_PORT_EVENT_T;

typedef struct HAL_LAG_PORT_LIST_ORIG_ENTRY_S {
    uint32 di;
    uint32 is_act;
} HAL_LAG_PORT_LIST_ORIG_ENTRY_T;

typedef struct HAL_LAG_PORT_LIST_ACT_ENTRY_S {
    uint32 di;
    uint32 is_new;
} HAL_LAG_PORT_LIST_ACT_ENTRY_T;

typedef struct HAL_LAG_INFO_S {
    uint32 ori_base_idx;
    uint32 ori_tot;
    HAL_LAG_PORT_LIST_ORIG_ENTRY_T ori_list[HAL_LAG_GROUP_MAX_MEMBER_NUM];
    uint32 act_base_idx;
    uint32 act_tot;
    HAL_LAG_PORT_LIST_ACT_ENTRY_T act_list[HAL_LAG_GROUP_MAX_MEMBER_NUM];
} HAL_LAG_INFO_T;

/* lag member info */
typedef struct HAL_LAG_MEMBER_INFO_S {
    uint32 flag;
    uint32 member_di;     /* Lag member di. */
    uint32 member_weight; /* The weight of lag member. */
} HAL_LAG_MEMBER_INFO_T;
#define HAL_LAG_MEMBER_ATTR_FLAG_INGRESS_DISABLE (1U << 0)
#define HAL_LAG_MEMBER_ATTR_FLAG_EGRESS_DISABLE  (1U << 1)

/* lag member di info */
typedef struct HAL_LAG_MEMBER_DI_INFO_S {
    uint32 flag;
    uint32 member_di; /* Lag member di. */
} HAL_LAG_MEMBER_DI_INFO_T;

/* lag weight info */
typedef struct HAL_LAG_GROUP_INFO_S {
    uint32 actual_num;
    uint32 greatest_common_divisor;
} HAL_LAG_GROUP_INFO_T;

/* lag weight info */
typedef struct HAL_LAG_MEMBER_CHECK_INFO_S {
    uint32 lag_di;
} HAL_LAG_MEMBER_CHECK_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Init LAG module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No memory.
 */
clx_error_no_t
hal_lag_init(const uint32 unit);

/**
 * @brief De-init LAG module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_lag_deinit(const uint32 unit);

/**
 * @brief Create a new lag. This API is used to create a new lag. The lag_id can be specified by
 *        user or automatically assigned by the software.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     ptr_lag_create_info    - The pointer to lag create info @param [in,
 *                                          out] ptr_lag_id - The pointer to lag id which will be
 *                                          created.
 * @param [out]    ptr_lag_port           - The pointer to lag port.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists.
 */
clx_error_no_t
hal_lag_create(const uint32 unit,
               const clx_lag_create_info_t *ptr_lag_create_info,
               uint32 *ptr_lag_id,
               clx_port_t *ptr_lag_port);

/**
 * @brief Destroy a lag with user specified lag id.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    lag_id    - Lag id which will be deleted.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 */
clx_error_no_t
hal_lag_destroy(const uint32 unit, const uint32 lag_id);

/**
 * @brief Set lag member.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    lag_id        - Lag id.
 * @param [in]    member_cnt    - Member port count.
 * @param [in]    ptr_member    - The pointer to lag member list.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_lag_member_set(const uint32 unit,
                   const uint32 lag_id,
                   const uint32 member_cnt,
                   const clx_lag_member_t *ptr_member);

/**
 * @brief Get lag member.
 *
 * @param [in]     unit                     - Device unit number.
 * @param [in]     lag_id                   - Lag id.
 * @param [in]     member_cnt               - Get member port count.
 * @param [out]    ptr_member               - The pointer to member list.
 * @param [out]    ptr_actual_member_cnt    - The pointer to actual member port count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_lag_member_get(const uint32 unit,
                   const uint32 lag_id,
                   const uint32 member_cnt,
                   clx_lag_member_t *ptr_member,
                   uint32 *ptr_actual_member_cnt);

/**
 * @brief Get lag id from lag port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     lag_port      - Lag gport.
 * @param [out]    ptr_lag_id    - The pointer to lag id.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_lag_id_get(const uint32 unit, clx_port_t lag_port, uint32 *ptr_lag_id);

/**
 * @brief Get lag port from lag id.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     lag_id          - Lag id.
 * @param [out]    ptr_lag_port    - The pointer to lag gport.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_lag_port_get(const uint32 unit, uint32 lag_id, clx_port_t *ptr_lag_port);

/**
 * @brief Traver all lags.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    callback      - The callback function of type clx_lag_trav_func_t.
 * @param [in]    ptr_cookie    - The cookie data as input parameter of callback function.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other error.
 */
clx_error_no_t
hal_lag_trav(const uint32 unit, const clx_lag_trav_func_t callback, void *ptr_cookie);

clx_error_no_t
hal_lag_getPort(const uint32 unit, const uint32 lag_id, clx_port_t *ptr_lag_port);

clx_error_no_t
hal_lag_getKey(const uint32 unit, const clx_port_t lag_port, uint32 *ptr_lag_id);

clx_error_no_t
hal_lag_getSrcSuppTag(const uint32 unit, const clx_port_t lag_port, uint32 *ptr_value);

clx_error_no_t
hal_lag_getCapacity(const uint32 unit,
                    const clx_swc_rsrc_t type,
                    const uint32 param,
                    uint32 *ptr_size);

clx_error_no_t
hal_lag_getUsage(const uint32 unit, const clx_swc_rsrc_t type, const uint32 param, uint32 *ptr_cnt);

void
hal_lag_updateMember(const uint32 unit, const uint32 port, const uint32 link, void *ptr_cookie);

clx_error_no_t
hal_lag_getLag(const uint32 unit, const clx_port_t member_port, clx_port_t *ptr_lag_port);

clx_error_no_t
hal_lag_check(const uint32 unit, const uint32 lag_id);

#if defined(CLX_HSH_LIB)
clx_error_no_t
hal_lag_hsh_path_get(const uint32 unit,
                     const clx_swc_hsh_pkt_type_t hash_type,
                     const clx_swc_flow_hsh_key_t *ptr_hash_key,
                     const uint32 lag_id,
                     clx_lag_hashpath_rslt_info_t *ptr_rslt);
#endif

clx_error_no_t
hal_lag_setAlgoMode(const uint32 unit, const uint32 lag_id, const clx_lag_algorithm_mode_t mode);

clx_error_no_t
hal_lag_getAlgoMode(const uint32 unit, const uint32 lag_id, clx_lag_algorithm_mode_t *mode);

clx_error_no_t
hal_lag_getMemberByHash(const uint32 unit,
                        const uint32 lag_id,
                        uint32 hash_value,
                        clx_port_t *ptr_member,
                        uint32 *di);

extern HAL_LAG_CB_T _ext_hal_lag_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];

#endif /* End of HAL_LAG_H */
