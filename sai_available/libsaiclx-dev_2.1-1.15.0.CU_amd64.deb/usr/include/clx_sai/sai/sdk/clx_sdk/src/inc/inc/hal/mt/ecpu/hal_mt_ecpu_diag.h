/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_ecpu_diag.h
 * PURPOSE:
 *  1. To maintain eCPU diag related API.
 * NOTES:
 */

#ifndef HAL_MT_ECPU_DIAG_H
#define HAL_MT_ECPU_DIAG_H

#include <clx/clx_types.h>
#include <clx/clx_error.h>

#define HAL_MT_ECPU_DIAG_TO_HOST 1
#define HAL_MT_ECPU_DIAG_TO_UART 2

typedef enum {
    HAL_MT_ECPU_DIAG_SET_LEVEL,
    HAL_MT_ECPU_DIAG_SET_OUTPUT,
    HAL_MT_ECPU_DIAG_GET_CFG,
} hal_mt_ecpu_diag_host2ecpu_msg_type_t;

typedef struct hal_mt_ecpu_diag_req_msg_hdr_s {
    uint8 msg_type;
    uint8 seq;
    uint16 len;
    uint8 data[0];
} hal_mt_ecpu_diag_req_msg_hdr_t;

typedef struct hal_mt_ecpu_diag_resp_msg_hdr_s {
    uint8 msg_type;
    uint8 code;
    uint8 seq;
    uint8 resv[1];
    uint16 len;
    uint8 data[0];
} hal_mt_ecpu_diag_resp_msg_hdr_t;

typedef struct hal_mt_ecpu_diag_attr_s {
    int32 level;
    int32 output;
} hal_mt_ecpu_diag_attr_t;

/**
 * @brief This API is used to initialize ecpu diag.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_diag_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize ecpu diag.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_diag_deinit(const uint32 unit);

/**
 * @brief This API is used to set ecpu diag attribute.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    type    - Attribute type.
 * @param [in]    attr    - Attribute value.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_diag_attr_set(const uint32 unit,
                          const uint32 type,
                          const hal_mt_ecpu_diag_attr_t *attr);

/**
 * @brief This API is used to get ecpu diag attribute.
 *
 * @param [in]     unit    - Device unit number.
 * @param [out]    attr    - Attribute value.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_mt_ecpu_diag_attr_get(const uint32 unit, hal_mt_ecpu_diag_attr_t *attr);

#endif /* HAL_MT_ECPU_DIAG_H */