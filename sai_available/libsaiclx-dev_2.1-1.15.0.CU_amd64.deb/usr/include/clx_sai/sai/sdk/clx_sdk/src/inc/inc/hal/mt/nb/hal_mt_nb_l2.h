/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_l2.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_L2_H
#define HAL_MT_NB_L2_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_l2.h>
#include <hal/hal_l2.h>
#include <hal/hal_stk.h>
#include <hal/hal_bd.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* Save SW tcam entry as hash entry
 * hash: MT_NB_CDB_FPU_HSH_L2_WORDS(3),
 * tcam key: MT_NB_CDB_FPU_TCAM_L2_WORDS(7)
 * tcam rslt: MT_NB_CDB_FPU_RSLT_L2_WORDS(2)
 */
#define HAL_MT_NB_L2_FDB_SW_ENTRY_WORDS (MT_NB_CDB_FPU_HSH_L2_WORDS)
#define HAL_MT_NB_L2_FDB_SW_ENTRY_BYTES (HAL_MT_NB_L2_FDB_SW_ENTRY_WORDS * HAL_BYTES_OF_WORD)

#define HAL_MT_NB_L2_FDB_ENTRY_WORDS_MAX     (MT_NB_CDB_FPU_TCAM_L2_WORDS)
#define HAL_MT_NB_L2_FDB_DMA_ENTRY_BYTES_MAX (HAL_MT_NB_L2_FDB_ENTRY_WORDS_MAX * HAL_BYTES_OF_WORD)

#define HAL_MT_NB_L2_FIFO_ENTRY_BYTES_ALIGN (16) /* L2 FIFO DMA is 16 bytes alignment */

/* NB FPU HSH DMA is 24 bytes alignment. TODO: maybe tob will have this macro */
#define HAL_MT_NB_L2_FDB_DMA_HSH_ENTRY_BYTES (24)
#define HAL_MT_NB_L2_FDB_DMA_HSH_ENTRY_WORDS \
    (HAL_MT_NB_L2_FDB_DMA_HSH_ENTRY_BYTES / HAL_BYTES_OF_WORD)

#define HAL_MT_NB_L2_AGE_TASK_NAME       ("AGE_TASK")
#define HAL_MT_NB_L2_AGE_STEPS           (2)
#define HAL_MT_NB_L2_AGE_MSEC_DEFAULT    (300 * 1000) /* 300 sec */
#define HAL_MT_NB_L2_AGE_MUTEX_SEMA_NAME ("AGE_MUTEX_SEMA")

#define HAL_MT_NB_L2_FIFO_ALM_FULL        (0xFA)    // TODO: need more accurate number
#define HAL_MT_NB_L2_BF_COUNTER           (0x3FFFF) // TODO: need more accurate number
#define HAL_MT_NB_L2_BF_TIMER             (0x3FFFF) // TODO: need more accurate number
#define HAL_MT_NB_L2_FIFO_CHANNEL_NUM     (18)
#define HAL_MT_NB_L2_FIFO_CHANNEL_CLR_BMP (1 << 16) /* CH18_CLR/MASK offset bit is 16 */
#define HAL_MT_NB_L2_FIFO_TBL_ADDR(_unit_) \
    (HAL_TBL_INFO((_unit_), MT_NB_REG_FWR_SLV_SA_LRN_FIFO_ID)->table_addr)
#define HAL_MT_NB_L2_FIFO_SLOT_SIZE(_unit_) \
    (HAL_TBL_INFO((_unit_), MT_NB_REG_FWR_SLV_SA_LRN_FIFO_ID)->slot_size)

#define HAL_MT_NB_L2_RSV_MEL_ID     (0)  /* Reserved */
#define HAL_MT_NB_L2_MC_MBR_MAX_NUM (32) // TODO: tmp, use for TMV

#if defined(NB_EMU_DEV) || defined(CLX_MOCK)
#define HAL_MT_NB_L2_HW_FPU_NUM (1) /* TODO: tmp, maybe tob will have this macro later */
#else
#define HAL_MT_NB_L2_HW_FPU_NUM (4) /* TODO: tmp, maybe tob will have this macro later */
#endif
#define HAL_MT_NB_L2_FAST_CMD_AGE    (0)
#define HAL_MT_NB_L2_FAST_CMD_SEARCH (1)

#define HAL_MT_NB_L2_FAST_CMD_UNEQUAL (0)
#define HAL_MT_NB_L2_FAST_CMD_EQUAL   (1)
#define HAL_MT_NB_L2_FAST_CMD_BOTH    (2)

#define HAL_MT_NB_L2_FAST_CMD_MODIFY (1)
#define HAL_MT_NB_L2_FAST_CMD_REMOVE (2)

#define HAL_MT_NB_L2_FAST_CMD_PUSH_TO_FIFO (1)

#define HAL_MT_NB_L2_FAST_CMD_TCAM_L2 (0)

#define HAL_MT_NB_L2_FAST_CMD_TCAM_SA    (0)
#define HAL_MT_NB_L2_FAST_CMD_TCAM_DA    (1)
#define HAL_MT_NB_L2_FAST_CMD_TCAM_SA_DA (2)

#define HAL_MT_NB_L2_FAST_CMD_DONE_POLLING_NUM_MAX (10000)

#define HAL_MT_NB_L2_CALLBACK_TASK_NAME       ("CALLBACK_TASK")
#define HAL_MT_NB_L2_CALLBACK_TASK_SLEEP_USEC (10 * 1000)

#if defined(CLX_MOCK)
#define HAL_MT_NB_L2_GRP_TBL       (MT_NB_TBL_TMV_RSLT_MC_GRP_SZ_ID)
#define HAL_MT_NB_L2_GRP_TBL_WORDS (MT_NB_CDB_TMV_RSLT_MC_GRP_SZ_WORDS)
#else
#define HAL_MT_NB_L2_GRP_TBL       (MT_NB_TBL_REP_MCGRP_MEM_BST_DMA0_ID)
#define HAL_MT_NB_L2_GRP_TBL_WORDS (MT_NB_CDB_REP_MCGRP_MEM_BST_DMA0_WORDS)
#endif

#define HAL_MT_NB_L2_HITBIT_WIDTH (32) // TODO: use tbl macro

#define HAL_MT_NB_L2_LOGICAL_MC_ID_NUM  (HAL_L2_MGID_NUM)
#define HAL_MT_NB_L2_LOGICAL_MC_ID_MIN  (0)
#define HAL_MT_NB_L2_LOGICAL_MC_ID_MAX  (HAL_MT_NB_L2_LOGICAL_MC_ID_NUM - 1)
#define HAL_MT_NB_L2_BUM_ENTRY_AVL_NAME ("BUM_ENTRY_AVL")
/* MACRO FUNCTION DECLARATIONS
 */
/* n bit for n fpu */
#define HAL_MT_NB_L2_AGE_EVENT_BIT_INIT(_unit_, _age_event_bit_) \
    do {                                                         \
        if (HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(_unit_)) {      \
            _age_event_bit_ = 0x3;                               \
        } else {                                                 \
            _age_event_bit_ = 0xF;                               \
        }                                                        \
    } while (0)

#define HAL_MT_NB_L2_SET_HASH_SW_IDX(_entry_idx_, _inst_) \
    (_entry_idx_ = (TOB_ODD_INST_IDX_BCAST == _inst_) ?   \
         (_entry_idx_ | (1 << TOB_MT_HASH_INST_OFFSET)) : \
         (_entry_idx_))

#define HAL_MT_NB_L2_SET_HASH_HW_IDX(_entry_hw_idx_, _hsh_idx_)       \
    (_entry_hw_idx_ = (_hsh_idx_.stage << TOB_MT_HASH_STAGE_OFFSET) | \
         (_hsh_idx_.tile << TOB_MT_HASH_TILE_OFFSET) | _hsh_idx_.fdb_entry_idx)

#define HAL_MT_NB_L2_GET_HASH_CDB_INST_FROM_FPU_IDX(_unit_, _fpu_idx_, _inst_)           \
    do {                                                                                 \
        if (HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(_unit_)) {                              \
            _inst_ = (1 & _fpu_idx_) ? TOB_ODD_INST_IDX_BCAST : TOB_EVEN_INST_IDX_BCAST; \
        } else {                                                                         \
            _inst_ = TOB_INST_IDX_BCAST;                                                 \
        }                                                                                \
    } while (0)

#define HAL_MT_NB_L2_GET_HASH_HW_IDX(_unit_, _entry_sw_idx_, _inst_, _entry_hw_idx_)    \
    do {                                                                                \
        uint32 inst_id;                                                                 \
        if (HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(_unit_)) {                             \
            TOB_MT_HASH_GET_INSTID(_entry_sw_idx_, inst_id);                            \
            _inst_ = (1 == inst_id) ? TOB_ODD_INST_IDX_BCAST : TOB_EVEN_INST_IDX_BCAST; \
            _entry_hw_idx_ = _entry_sw_idx_ & ((1 << TOB_MT_HASH_INST_OFFSET) - 1);     \
        } else {                                                                        \
            _inst_ = TOB_INST_IDX_BCAST;                                                \
            _entry_hw_idx_ = _entry_sw_idx_;                                            \
        }                                                                               \
    } while (0)

#define HAL_MT_NB_L2_GET_FIFO_FPU_INST(_unit_, _addr_, _inst_)                                    \
    (_inst_ =                                                                                     \
         ((_addr_ - HAL_MT_NB_L2_FIFO_TBL_ADDR(_unit_)) / HAL_MT_NB_L2_FIFO_SLOT_SIZE(_unit_)) >> \
         1)

#define HAL_MT_NB_L2_CHECK_UC_EXM(_unit_)                                                    \
    do {                                                                                     \
        hal_l2_fdb_cb_t *ptr_fdb_cb = &_hal_l2_fdb_cb[(_unit_)];                             \
        if (0 == ptr_fdb_cb->entry_num) {                                                    \
            UTIL_LOG_PRINT(UTIL_LOG_L2, UTIL_LOG_WARN, "u=%u, invalid fdb entry region=0\n", \
                           (_unit_));                                                        \
            return CLX_E_BAD_PARAMETER;                                                      \
        }                                                                                    \
    } while (0)

#define HAL_MT_NB_L2_CHECK_MC_EXM(_unit_)                                                    \
    do {                                                                                     \
        hal_mt_nb_l2_fdb_info_t *ptr_fdb_info = &_hal_mt_nb_l2_fdb_info[(_unit_)];           \
        if (0 ==                                                                             \
            (ptr_fdb_info->hash_mc_size[0] + ptr_fdb_info->tcam_mc_size[0] +                 \
             ptr_fdb_info->hash_mc_size[1] + ptr_fdb_info->tcam_mc_size[1])) {               \
            UTIL_LOG_PRINT(UTIL_LOG_L2, UTIL_LOG_WARN, "u=%u, invalid fdb entry region=0\n", \
                           (_unit_));                                                        \
            return CLX_E_BAD_PARAMETER;                                                      \
        }                                                                                    \
    } while (0)

#define HAL_MT_NB_L2_PACK_HSH_FIELD(__unit__, __hsh_field__, __ptr_entry__, __ptr_field__) \
    do {                                                                                   \
        tob_field_t *ptr_field_db = _hal_mt_nb_l2_hsh_field_offset + (__hsh_field__);      \
        hal_field_pack((__unit__), HAL_NAMCHABARWA_LAST_TBL_ID, 0, ptr_field_db->offset,   \
                       ptr_field_db->length, (__ptr_entry__), (__ptr_field__));            \
    } while (0)

#define HAL_MT_NB_L2_PACK_TCAM_FIELD(__unit__, __tcam_field__, __ptr_entry__, __ptr_field__) \
    do {                                                                                     \
        tob_field_t *ptr_field_db = _hal_mt_nb_l2_tcam_field_offset + (__tcam_field__);      \
        hal_field_pack((__unit__), HAL_NAMCHABARWA_LAST_TBL_ID, 0, ptr_field_db->offset,     \
                       ptr_field_db->length, (__ptr_entry__), (__ptr_field__));              \
    } while (0)

#define HAL_MT_NB_L2_FPU_SIZE(__bitmap__, __bitmap_size__, __fpu_size__, __size__) \
    do {                                                                           \
        uint32 bit;                                                                \
        __size__ = 0;                                                              \
        UTIL_LIB_BMP_BIT_FOREACH(__bitmap__, bit, __bitmap_size__)                 \
        {                                                                          \
            __size__ = __size__ + __fpu_size__;                                    \
        }                                                                          \
    } while (0)

#if 0
#define HAL_MT_NB_L2_FIND_MSB_FIRST_ONE(__bitmap__, __bit__) \
    do {                                                     \
        uint32 bmp = __bitmap__;                             \
        if (0 == bmp) {                                      \
            __bit__ = 0;                                     \
        } else {                                             \
            __bit__ = 0;                                     \
            while (0 != bmp) {                               \
                bmp = bmp / 2;                               \
                __bit__++;                                   \
            }                                                \
        }                                                    \
    } while (0)
#endif

#if 0
#define HAL_MT_NB_L2_TCAM_PACK_ENTRY(__fdb_key_entry__, __fdb_rslt_entry__, __fdb_entry__) \
    do {                                                                                   \
        osal_memcpy(__fdb_entry__, __fdb_rslt_entry__, sizeof(__fdb_rslt_entry__));        \
        osal_memcpy(__fdb_entry__ + MT_NB_CDB_FPU_RSLT_L2_WORDS, __fdb_key_entry__,        \
                    sizeof(__fdb_key_entry__));                                            \
    } while (0)

#define HAL_MT_NB_L2_TCAM_UNPACK_ENTRY(__fdb_entry__, __fdb_key_entry__, __fdb_rslt_entry__) \
    do {                                                                                     \
        osal_memcpy(__fdb_rslt_entry__, __fdb_entry__, sizeof(__fdb_rslt_entry__));          \
        osal_memcpy(__fdb_key_entry__, __fdb_entry__ + MT_NB_CDB_FPU_RSLT_L2_WORDS,          \
                    sizeof(__fdb_key_entry__));                                              \
    } while (0)
#endif

#define HAL_MT_NB_L2_TRANS_ECMP_DI(__ecmp_grp__, __di__, __offset__, __dir__) \
    do {                                                                      \
        if (0 == (__dir__)) {                                                 \
            (__di__) = (__ecmp_grp__) + (__offset__);                         \
        } else {                                                              \
            (__ecmp_grp__) = (__di__) - (__offset__);                         \
        }                                                                     \
    } while (0)

#define HAL_MT_NB_L2_GET_GRP_BY_PORT(__port__, __ecmp_grp__)                  \
    do {                                                                      \
        uint32 di;                                                            \
        HAL_OBJ_DI_GET(__port__, di);                                         \
        HAL_MT_NB_L2_TRANS_ECMP_DI(__ecmp_grp__, di, HAL_L2_ECMP_BASE_ID, 1); \
    } while (0)

#define HAL_MT_NB_L2_AGE_LOCK(_unit_)                                           \
    HAL_COMMON_LOCK_RESOURCE(&_hal_mt_nb_l2_age_cb[(_unit_)].age_mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_MT_NB_L2_AGE_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_mt_nb_l2_age_cb[(_unit_)].age_mutex_sema_id)

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_nb_l2_hsh_field_e {
    HAL_MT_NB_L2_HSH_MAC_ADDR_FIELD_ID,
    HAL_MT_NB_L2_HSH_BD_FIELD_ID,
    HAL_MT_NB_L2_HSH_DST_IDX_FIELD_ID,
    HAL_MT_NB_L2_HSH_IS_SECURE_FIELD_ID,
    HAL_MT_NB_L2_HSH_IS_STATIC_FIELD_ID,
    HAL_MT_NB_L2_HSH_ACL_LABEL_FIELD_ID,
    HAL_MT_NB_L2_HSH_LAST_FIELD_ID
} hal_mt_nb_l2_hsh_field_t;

typedef enum hal_mt_nb_l2_tcam_field_e {
    HAL_MT_NB_L2_TCAM_DST_IDX_FIELD_ID,
    HAL_MT_NB_L2_TCAM_IS_SECURE_FIELD_ID,
    HAL_MT_NB_L2_TCAM_IS_STATIC_FIELD_ID,
    HAL_MT_NB_L2_TCAM_ACL_LABEL_FIELD_ID,
    HAL_MT_NB_L2_TCAM_BD_FIELD_ID,
    HAL_MT_NB_L2_TCAM_MAC_FIELD_ID,
    HAL_MT_NB_L2_TCAM_VLD_FIELD_ID,
    HAL_MT_NB_L2_TCAM_HIT_BIT_FIELD_ID,
    HAL_MT_NB_L2_TCAM_LAST_FIELD_ID
} hal_mt_nb_l2_tcam_field_t;

typedef enum hal_mt_nb_l2_fifo_reason_e {
    HAL_MT_NB_L2_FIFO_REASON_SA_ADD = 1,
    HAL_MT_NB_L2_FIFO_REASON_SA_MOVE = 2,
    HAL_MT_NB_L2_FIFO_REASON_SA_AGE = 3,
    HAL_MT_NB_L2_FIFO_REASON_SA_SEARCH = 4,
} hal_mt_nb_l2_fifo_reason_t;

typedef enum hal_mt_nb_l2_hsh_action_e {
    HAL_MT_NB_L2_HSH_ACTION_ADD,
    HAL_MT_NB_L2_HSH_ACTION_UPDATE,
} hal_mt_nb_l2_hsh_action_t;

typedef enum hal_mt_nb_l2_wbdb_e {
    HAL_MT_NB_L2_WBDB_MCAST_CB_GROUP_INFO_ARR = 0,
    HAL_MT_NB_L2_WBDB_MCAST_CB_MEMBER_LIST_START,
    HAL_MT_NB_L2_WBDB_MCAST_CB_MEMBER_LIST_END =
        HAL_MT_NB_L2_WBDB_MCAST_CB_MEMBER_LIST_START + (HAL_L2_MGID_NUM - 1),
    HAL_MT_NB_L2_WBDB_LOGICAL_MC_DB_ARR,
    HAL_MT_NB_L2_WBDB_LOGICAL_MC_BUM_AVL_START,
    HAL_MT_NB_L2_WBDB_LOGICAL_MC_BUM_AVL_END =
        HAL_MT_NB_L2_WBDB_LOGICAL_MC_BUM_AVL_START + (HAL_MT_NB_L2_LOGICAL_MC_ID_NUM - 1),
    HAL_MT_NB_L2_WBDB_LOGICAL_MC_BUM_ARR,
    HAL_MT_NB_L2_WBDB_MC_ENTRY_LOGICAL_MC_ID_ARR,
    HAL_MT_NB_L2_WBDB_AGING_TIME,
    HAL_MT_NB_L2_WBDB_LAST
} hal_mt_nb_l2_wbdb_t;

typedef struct hal_mt_nb_l2_fpu_idx_s {
    uint32 stage; /* hash stage */
    uint32 tile;
    uint32 fdb_entry_idx;
} hal_mt_nb_l2_fpu_idx_t;
typedef struct hal_mt_nb_l2_hsh_range_info_s {
    uint32 tile_num;            /* hash start tile number */
    uint32 continuous_tile_num; /* number of continuous tile */
} hal_mt_nb_l2_hsh_range_info_t;
typedef struct hal_mt_nb_l2_fdb_info_s {
    uint32 hash_uc_size[HAL_SWC_FPU_NUM];
    uint32 hash_mc_size[HAL_SWC_FPU_NUM];
    uint32 tcam_uc_size[HAL_SWC_FPU_NUM]; /* sw uc tcam index, 512 per tcam, start with 0 */
    uint32 tcam_mc_size[HAL_SWC_FPU_NUM]; /* sw mc tcam index, 512 per tcam, start with 0 */
    uint32 tcam_uc_da_base[HAL_SWC_FPU_NUM];
    uint32 tcam_uc_sa_base[HAL_SWC_FPU_NUM];
    uint32 tcam_mc_da_base[HAL_SWC_FPU_NUM];
    util_lib_list_t *ptr_hash_uc_range_list[HAL_SWC_FPU_NUM];
    util_lib_list_t *ptr_hash_mc_range_list[HAL_SWC_FPU_NUM];
    uint32 tcam_start_idx[HAL_SWC_FPU_NUM];
    uint32 tcam_end_idx[HAL_SWC_FPU_NUM];
    uint32 hash_uc_total_size;
    uint32 hash_mc_total_size;
    uint32 tcam_uc_total_size;
    uint32 tcam_mc_total_size;
    hal_swc_tcam_bmp_t tcam_uc_sa_bmp;
} hal_mt_nb_l2_fdb_info_t;

typedef struct hal_mt_nb_l2_age_cb_s {
    osal_timer_id_t timer_id;
    clx_semaphore_id_t age_mutex_sema_id; /* used to protect aging time */
    uint32 aging_time;
    boolean is_stop;
    boolean is_run; /* aging task is running */
    tob_fvp_t hsh_content_fvp[HAL_L2_FAST_CMD_ENTRY_WORDS];
    tob_fvp_t hsh_msk_fvp[HAL_L2_FAST_CMD_ENTRY_WORDS];
    tob_fvp_t hsh_ne_content_fvp[HAL_L2_FAST_CMD_ENTRY_WORDS];
    tob_fvp_t hsh_ne_msk_fvp[HAL_L2_FAST_CMD_ENTRY_WORDS];
    tob_fvp_t hsh_write_msk_fvp[HAL_L2_FAST_CMD_ENTRY_WORDS];
    tob_fvp_t tcam_content_fvp[HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS];
    tob_fvp_t tcam_msk_fvp[HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS];
    tob_fvp_t tcam_ne_content_fvp[HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS];
    tob_fvp_t tcam_ne_msk_fvp[HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS];
    tob_fvp_t tcam_write_msk_fvp[HAL_L2_FAST_CMD_TCAM_ENTRY_WORDS];
} hal_mt_nb_l2_age_cb_t;

typedef struct hal_mt_nb_l2_callback_cb_s {
    clx_thread_id_t task_id;
    uint32 thread_pri;
    uint32 thread_stack_size;
    util_lib_list_t *ptr_list_1;
    util_lib_list_t *ptr_list_2;
    util_lib_list_t *ptr_callback_list; /* point to ptr_list_1 or ptr_list_2 */
} hal_mt_nb_l2_callback_cb_t;

typedef struct hal_mt_nb_l2_warm_logical_mc_id_info_s {
    boolean valid;
    boolean phy_mc_id_not_change;
    uint32 phy_mc_id;
} hal_mt_nb_l2_warm_logical_mc_id_info_t;

typedef struct hal_mt_nb_l2_bum_entry_s {
    uint32 bum_idx; /* avl key */
} hal_mt_nb_l2_bum_entry_t;

typedef struct hal_mt_nb_l2_logical_mc_id_info_s {
    boolean valid;                          /* Mark whether the MC ID has been created. */
    boolean phy_mc_id_not_change;           /* Indicate the phy_mc_id is allowed to change or not */
    uint32 phy_mc_id;                       /* Mcast_id from SDK */
    util_lib_avl_head_t *ptr_bum_entry_avl; /* DIS_RSLT_BDI entry index avl */
} hal_mt_nb_l2_logical_mc_id_info_t;

/* L2 logical mcast id management database */
typedef struct hal_mt_nb_l2_logical_mc_db_s {
    boolean disable_compression;                          /* Globally disable mcast compression */
    hal_stk_chip_mode_t chip_mode;                        /* Fabric mode not support compression*/
    hal_mt_nb_l2_logical_mc_id_info_t *ptr_mcast_id_info; /* logic mc arr, index is logic mc id*/
    uint32 bum_idx_arr[HAL_BD_ENTRY_NUM];                 /* bum entry -> logical mcast id */
} hal_mt_nb_l2_logical_mc_db_t;

typedef struct hal_mt_nb_l2_trav_bum_cookie_s {
    uint32 unit;
    uint32 logical_mc_id;
} hal_mt_nb_l2_trav_bum_cookie_t;

typedef uint32 hal_mt_nb_l2_fdb_tcam_entry_t[MT_NB_CDB_FPU_TCAM_L2_WORDS];
typedef uint32 hal_mt_nb_l2_dma_hsh_entry_t[HAL_MT_NB_L2_FDB_DMA_HSH_ENTRY_WORDS];
typedef uint32 hal_mt_nb_l2_dma_tcam_entry_t[MT_NB_CDB_FPU_TCAM_L2_WORDS];
typedef uint32 hal_mt_nb_l2_hsh_scan_status_t[MT_NB_CDB_FPUHSH_SLV_HSH_SCAN_STATUS_WORDS];
typedef uint32 hal_mt_nb_l2_tcam_scan_status_t[MT_NB_CDB_FPUTCAM_SLV_TCAM_SCAN_STATUS_WORDS];
typedef uint32 hal_mt_nb_l2_hsh_hit_buf_t[MT_NB_CDB_FPU_RSLT_HSH_HIT_WORDS];
typedef uint32 hal_mt_nb_l2_tcam_hit_buf_t[MT_NB_CDB_FPU_RSLT_TCAM_HIT_WORDS];

/**
 * @brief This API is used to initialize L2 module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize L2 module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_deinit(const uint32 unit);

/**
 * @brief This API is used to add/set a L2 unicast MAC address entry. If the address entry does not
 *        exist, it will add the entry; if the address entry already exists,
 *        it will set the entry with user input value.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_addr    - The L2 address entry to be added/set.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_add(const uint32 unit, const clx_l2_addr_t *ptr_addr);

/**
 * @brief This API is used to delete a L2 unicast MAC address entry.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    bdid     - Bridge domain ID.
 * @param [in]    mac      - Mac address.
 * @param [in]    flags    - CLX_L2_ADDR_FLAGS_NO_CALLBACK.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_del(const uint32 unit,
                      const clx_bridge_domain_t bdid,
                      const clx_mac_t mac,
                      const uint32 flags);

/**
 * @brief This API is used to get a L2 unicast MAC address entry.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_addr    - The L2 address entry to be obtained. User should only fill the key
 *                               fields "bdid" and "mac". The other fields will be ignored.
 * @param [out]    ptr_addr    - The fully filled L2 address entry obtained.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_get(const uint32 unit, clx_l2_addr_t *ptr_addr);

/**
 * @brief This API is used to flush L2 unicast MAC address entries which match the specified
 *        criteria with the newly specified values.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    flags             - Refer to CLX_L2_ADDR_FLUSH_FLAGS_XXX.
 * @param [in]    flush_type        - Refer to CLX_L2_ADDR_FLUSH_OP_XXX.
 * @param [in]    ptr_match_addr    - Specify the values of matched fields used to perform matching.
 *                                    User need to input values of these fields which are chosen by
 *                                    "flush_type" parameter.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_flush(const uint32 unit,
                        const uint32 flags,
                        const clx_l2_addr_flush_op_type_t flush_type,
                        const clx_l2_addr_flush_t *ptr_match_addr);

/**
 * @brief This API is used to replace L2 unicast MAC address entries which match the specified
 *        criteria with the newly specified values.
 *
 * When user specifies the "replace_field" with CLX_L2_ADDR_REPLACE_DEL set,
 * other values which are included by "replace_field" parameter will be ignored,
 * and the parameter "ptr_replace_addr" can be NULL.
 *
 * @param [in]    unit                - Device unit number.
 * @param [in]    match_flags         - Indicate which fields of L2 uncast MAC address entry are
 *                                      used to match the given "ptr_match_addr".
 *                                      User can choose one or more fields to do matching.
 *                                      Refer to CLX_L2_ADDR_REPLACE_MATCH_XXX.
 * @param [in]    ptr_match_addr      - Specify the values of matched fields used to perform
 *                                      matching. User need to input values of these fields which
 *                                      are chosen by "match_field" parameter.
 * @param [in]    replace_flags       - Indicate which fields' values will be replaced with new
 *                                      values. Refer to CLX_L2_ADDR_REPLACE_XXX.
 * @param [in]    ptr_replace_addr    - Specify the new values used to replace the old values for
 *                                      the matched MAC address entries.
 *                                      User need to input values of these fields which are chosen
 *                                      by "replace_field" parameter.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_replace(const uint32 unit,
                          const uint32 match_flags,
                          const clx_l2_addr_t *ptr_match_addr,
                          const uint32 replace_flags,
                          const clx_l2_addr_t *ptr_replace_addr);

/**
 * @brief This API is used to traverse all the L2 unicast MAC address entries,
 *        and handle it by user's callback.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     mode              - The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 * @param [in]     ptr_match_addr    - Specify the values of matched fields used to perform.
 * @param [in]     callback          - The callback function to be called when each L2 address
 *                                     entry is traversed.
 * @param [in]     ptr_cookie        - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie        - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_trav(const uint32 unit,
                       const clx_l2_entry_trav_mode_t mode,
                       const clx_l2_addr_trav_match_t *ptr_match_addr,
                       const clx_l2_addr_trav_func_t callback,
                       void *ptr_cookie);

/**
 * @brief This API is used to register a callback function that will be called whenever the L2
 *        unicast MAC address table is updated.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_l2_addr_notify_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_notify_cb_register(const uint32 unit,
                                     const clx_l2_addr_notify_func_t callback,
                                     void *ptr_cookie);

/**
 * @brief This API is used to degister a callback function that will be called whenever the L2
 *        unicast MAC address table is updated.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_l2_addr_notify_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_notify_cb_deregister(const uint32 unit,
                                       const clx_l2_addr_notify_func_t callback,
                                       void *ptr_cookie);

/**
 * @brief This API is used to register a callback function that will be called whenever the L2
 *        unicast entry needs to be learned by sofware.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_l2_addr_sw_learn_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_sw_learn_cb_register(const uint32 unit,
                                       const clx_l2_addr_sw_learn_func_t callback,
                                       void *ptr_cookie);

/**
 * @brief This API is used to degister a callback function that will be called whenever the L2
 *        unicast entry needs to be learned by sofware.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     callback      - The callback function of type clx_l2_addr_sw_learn_func_t.
 * @param [in]     ptr_cookie    - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie    - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_addr_sw_learn_cb_deregister(const uint32 unit,
                                         const clx_l2_addr_sw_learn_func_t callback,
                                         void *ptr_cookie);

/**
 * @brief This API is used to get a L2 unicast MAC address entry age status.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     bdid              - Bridge domain ID.
 * @param [in]     mac               - Mac address.
 * @param [out]    ptr_age_status    - Age status.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_age_status_get(const uint32 unit,
                            const clx_bridge_domain_t bdid,
                            const clx_mac_t mac,
                            uint32 *ptr_age_status);

/**
 * @brief This API is used to add a L2 multicast ID. After the L2 multicast ID is added,
 *        L2 multicast egress interfaces can be added to it. If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is
 *        set, this API will add L2 multicast ID with the ID pointed by ptr_mcast_id;
 *        if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a L2 multicast ID.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     flags           - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [in]     ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                                   this field specifies the L2 multicast ID to be added.
 * @param [out]    ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                                   this field specifies the allocated L2 multicast ID.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_grp_create(const uint32 unit, const uint32 flags, uint32 *ptr_mcast_id);

/**
 * @brief This API is used to destroy a L2 multicast forwarding group ID.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    mcast_id    - The L2 multicast ID to be deleted.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_grp_destroy(const uint32 unit, const uint32 mcast_id);

/**
 * @brief This API is used to get L2 multicast interface in the form of port bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     mcast_id       - The L2 multicast ID to be obtained.
 * @param [out]    ptr_flags      - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [out]    port_bitmap    - The egress port bitmap.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_intf_pbmp_get(const uint32 unit,
                                 const uint32 mcast_id,
                                 uint32 *ptr_flags,
                                 clx_port_bitmap_t port_bitmap);

/**
 * @brief This API is used to add egress interface for a L2 multicast ID.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    mcast_id       - The L2 multicast ID.
 * @param [in]    ptr_egr_mbr    - The egress interface list to be added.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_egr_intf_add(const uint32 unit,
                                const uint32 mcast_id,
                                const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

/**
 * @brief This API is used to delete egress interface for a L2 multicast ID.
 *
 * Support_chip: all.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    mcast_id       - The L2 multicast ID.
 * @param [in]    ptr_egr_mbr    - The egress interface list to be deleted.
 *                                 user should only fill the "type", "bdid" and "port" fields,
 *                                 and the other fields will be ignored.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_egr_intf_del(const uint32 unit,
                                const uint32 mcast_id,
                                const clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

/**
 * @brief This API is used to get egress interface count for a L2 multicast ID.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     mcast_id            - The L2 multicast ID.
 * @param [out]    ptr_egr_intf_cnt    - The egress interface count.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_egr_intf_cnt_get(const uint32 unit,
                                    const uint32 mcast_id,
                                    uint32 *ptr_egr_intf_cnt);

/**
 * @brief This API is used to get egress interface for a L2 multicast ID.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     mcast_id       - The L2 multicast ID.
 * @param [out]    ptr_egr_mbr    - The egress interface list obtained.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_egr_intf_get(const uint32 unit,
                                const uint32 mcast_id,
                                clx_l2_mcast_egr_mbr_t *ptr_egr_mbr);

/**
 * @brief This API is used to check if the egress interface is exist in the L2 multicast ID.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     mcast_id        - The L2 multicast ID.
 * @param [in]     egr_intf        - The egress interface need to be checked.
 * @param [out]    ptr_is_exist    - Is exist flag.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_egr_intf_check(const uint32 unit,
                                  const uint32 mcast_id,
                                  const clx_l2_mcast_egr_intf_t egr_intf,
                                  boolean *ptr_is_exist);

/**
 * @brief This API is used to add/set a L2 multicast MAC address entry.
 *        If the multicast address entry does not exist, it will add the entry;
 *        if the multicast address entry already exists, it will set the entry with user input
 *        value.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    ptr_addr    - The L2 multicast address entry to be added/set.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_addr_add(const uint32 unit, const clx_l2_mcast_addr_t *ptr_addr);

/**
 * @brief This API is used to delete a L2 multicast address entry.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    bdid    - Bridge domain ID.
 * @param [in]    mac     - Mac address.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_addr_del(const uint32 unit, const clx_bridge_domain_t bdid, const clx_mac_t mac);

/**
 * @brief This API is used to get a L2 multicast address entry.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     ptr_addr    - The L2 multicast address entry to be obtained.
 *                               User should only fill the key fields "bdid" and "mac".
 *                               The other fields will be ignored.
 * @param [out]    ptr_addr    - The full filled L2 multicast address entry obtained.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_addr_get(const uint32 unit, clx_l2_mcast_addr_t *ptr_addr);

/**
 * @brief This API is used to traverse all the L2 multicast MAC address entries,
 *        and handle it by user's callback.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     mode              - The L2 traverse mode. Refer to CLX_L2_ADDR_TRAVERSE_MODE_XXX.
 * @param [in]     ptr_match_addr    - Specify the values of matched fields used to perform.
 * @param [in]     callback          - The callback function to be called when each L2 multicast
 *                                     address entry is traversed.
 * @param [in]     ptr_cookie        - The cookie data as input parameter of callback function.
 * @param [out]    ptr_cookie        - The cookie data as output parameter of callback function.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_mcast_addr_trav(const uint32 unit,
                             const clx_l2_entry_trav_mode_t mode,
                             const clx_l2_mcast_addr_trav_match_t *ptr_match_addr,
                             const clx_l2_mcast_addr_trav_func_t callback,
                             void *ptr_cookie);

/**
 * @brief This API is used to create l2 ecmp port.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ptr_ecmp_info    - The l2 ecmp info.
 * @param [out]    ptr_ecmp_port    - The l2 ecmp port obtained.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_ecmp_grp_add(const uint32 unit,
                          clx_l2_ecmp_grp_t *ptr_ecmp_info,
                          clx_port_t *ptr_ecmp_port);

/**
 * @brief This API is used to del l2 ecmp port.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ecmp_port    - The l2 ecmp port.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_ecmp_grp_del(const uint32 unit, clx_port_t ecmp_port);

/**
 * @brief This API is used to get l2 ecmp port.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ecmp_port        - The l2 ecmp port.
 * @param [out]    ptr_ecmp_info    - The l2 ecmp info obtained.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_ecmp_grp_get(const uint32 unit,
                          const clx_port_t ecmp_port,
                          clx_l2_ecmp_grp_t *ptr_ecmp_info);

/**
 * @brief This API is used to add l2 ecmp path and only support tunnel port now.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ecmp_port        - The l2 ecmp port.
 * @param [in]    ptr_path_info    - The l2 ecmp path info.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_ecmp_path_add(const uint32 unit,
                           const clx_port_t ecmp_port,
                           const clx_l2_ecmp_path_t *ptr_path_info);

/**
 * @brief This API is used to del l2 ecmp path.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    ecmp_port        - The l2 ecmp port.
 * @param [in]    ptr_path_info    - The l2 ecmp path info.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_ecmp_path_del(const uint32 unit,
                           const clx_port_t ecmp_port,
                           const clx_l2_ecmp_path_t *ptr_path_info);

/**
 * @brief This API is used to get l2 ecmp path by idx.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     ecmp_port        - The l2 ecmp port.
 * @param [in]     path_idx         - The l2 ecmp path index.
 * @param [out]    ptr_path_info    - The l2 ecmp path info.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_ecmp_path_get_by_idx(const uint32 unit,
                                  const clx_port_t ecmp_port,
                                  const uint32 path_idx,
                                  clx_l2_ecmp_path_t *ptr_path_info);

/**
 * @brief This API is used to get l2 ecmp set path offset.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    ecmp_port            - The l2 ecmp port.
 * @param [in]    ptr_hash_val_list    - Hash value list.
 * @param [in]    hash_val_cnt         - Total hash value count.
 * @param [in]    ptr_path_info        - The l2 ecmp path info.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_ecmp_path_hsh_set(const uint32 unit,
                               const clx_port_t ecmp_port,
                               uint32 *ptr_hash_val_list,
                               const uint32 hash_val_cnt,
                               const clx_l2_ecmp_path_t *ptr_path_info);

/**
 * @brief This API is used to get l2 ecmp get path offset.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]     unit                       - Device unit number.
 * @param [in]     ecmp_port                  - The l2 ecmp port.
 * @param [in]     hash_val_cnt               - Total hash value count.
 * @param [in]     ptr_path_info              - The l2 ecmp path info.
 * @param [out]    ptr_hash_val_list          - Hash value list.
 * @param [out]    ptr_actual_hash_val_cnt    - Actual hash value count.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_ecmp_path_hsh_get(const uint32 unit,
                               const clx_port_t ecmp_port,
                               const uint32 hash_val_cnt,
                               const clx_l2_ecmp_path_t *ptr_path_info,
                               uint32 *ptr_hash_val_list,
                               uint32 *ptr_actual_hash_val_cnt);

/**
 * @brief This API is used to dump l2 ecmp port path state.
 *
 * Support_chip: CLX8600.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    ecmp_port    - The l2 ecmp port.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_grp_path_list_dump(const uint32 unit, const clx_port_t ecmp_port);

/**
 * @brief This API is used to add a L2 multicast ID. After the L2 multicast ID is added,
 *        L2 multicast egress interfaces can be added to it. If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is
 *        set, this API will add L2 multicast ID with the ID pointed by ptr_mcast_id;
 *        if CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set, this API will allocate a set of L2
 *        multicast ID.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     flags           - The L2 multicast flags. Refer to CLX_L2_MCAST_FLAGS_XXX.
 * @param [in]     mcast_id_cnt    - The number of L2 multicast ID need to be added.
 * @param [in]     ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is set,
 *                                   this field specifies the L2 multicast ID to be added.
 * @param [out]    ptr_mcast_id    - If CLX_L2_MCAST_FLAGS_ADD_WITH_ID is not set,
 *                                   this field specifies the first allocated L2 multicast ID.
 * @return         CLX_E_OK    - Operation succeeded.
 * @return         Others      - Operation failed.
 */
clx_error_no_t
hal_mt_nb_l2_multi_mcast_grp_create(const uint32 unit,
                                    const uint32 flags,
                                    const uint32 mcast_id_cnt,
                                    uint32 *ptr_mcast_id);

clx_error_no_t
hal_mt_nb_l2_capacity_get(const uint32 unit,
                          const clx_swc_rsrc_t type,
                          const uint32 param,
                          uint32 *ptr_size);

clx_error_no_t
hal_mt_nb_l2_usage_get(const uint32 unit,
                       const clx_swc_rsrc_t type,
                       const uint32 param,
                       uint32 *ptr_cnt);

clx_error_no_t
hal_mt_nb_l2_aging_time_set(const uint32 unit, const uint32 aging_time);

clx_error_no_t
hal_mt_nb_l2_aging_time_get(const uint32 unit, uint32 *ptr_aging_time);

clx_error_no_t
hal_mt_nb_l2_sa_move_action_set(const uint32 unit, const clx_fwd_action_t action);

clx_error_no_t
hal_mt_nb_l2_sa_move_action_get(const uint32 unit, uint32 *ptr_action);

clx_error_no_t
hal_mt_nb_l2_sa_miss_action_set(const uint32 unit,
                                const clx_swc_cfg_t reason,
                                const clx_fwd_action_t action);

clx_error_no_t
hal_mt_nb_l2_sa_miss_action_get(const uint32 unit, const clx_swc_cfg_t reason, uint32 *ptr_action);

clx_error_no_t
hal_mt_nb_l2_db_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_mt_nb_l2_mcast_id_print(const uint32 unit);

clx_error_no_t
hal_mt_nb_l2_mcast_grp_info_print(const uint32 unit,
                                  const uint32 logical_mc_id,
                                  const uint32 phy_mc_id);

clx_error_no_t
hal_mt_nb_l2_chip_cfg_info_get(const uint32 unit,
                               const clx_swc_chip_cfg_info_type_t type,
                               const uint32 para0,
                               const uint32 para1,
                               uint32 *ptr_value);

clx_error_no_t
hal_mt_nb_l2_addr_di_replace(const uint32 unit,
                             const uint32 match_ueid_mgid,
                             const uint32 replace_ueid_mgid);

/* used by pkj */
clx_error_no_t
hal_mt_nb_l2_phy_mc_id_get(const uint32 unit,
                           const uint32 phy_mc_id,
                           uint32 *ptr_flags,
                           clx_port_bitmap_t port_bitmap);

/* used by acl */
clx_error_no_t
hal_mt_nb_l2_uncompress_phy_mc_id_get(const uint32 unit,
                                      const uint32 logical_mc_id,
                                      uint32 *ptr_phy_mc_id);
/* used by vlan */
clx_error_no_t
hal_mt_nb_l2_bum_logical_mc_id_to_phy_id_trans(const uint32 unit,
                                               const uint32 logical_mc_id,
                                               uint32 *ptr_phy_mc_id,
                                               boolean *ptr_no_compress);
clx_error_no_t
hal_mt_nb_l2_bum_uncompress_phy_mc_id_get(const uint32 unit,
                                          const hal_l2_bum_mc_id_t logical_mc_id,
                                          hal_l2_bum_mc_id_t *ptr_phy_mc_id);
clx_error_no_t
hal_mt_nb_l2_bum_entry_logical_mc_id_set(const uint32 unit,
                                         const uint32 bum_entry_idx,
                                         const uint32 logical_mc_id);

clx_error_no_t
hal_mt_nb_l2_bum_entry_logical_mc_id_get(const uint32 unit,
                                         const uint32 bum_entry_idx,
                                         uint32 *ptr_logical_mc_id);
clx_error_no_t
hal_mt_nb_l2_bum_entry_idx_to_avl_add(const uint32 unit,
                                      const uint32 logical_mc_id,
                                      const uint32 bum_entry_idx);

clx_error_no_t
hal_mt_nb_l2_bum_entry_idx_from_avl_del(const uint32 unit,
                                        const uint32 logical_mc_id,
                                        const uint32 bum_entry_idx);
/* used by acl and vlan */
clx_error_no_t
hal_mt_nb_l2_uncompress_phy_mc_id_to_logical_id_trans(const uint32 unit,
                                                      const uint32 phy_mc_id,
                                                      const boolean lock,
                                                      uint32 *ptr_logical_mc_id);
#endif /* End of HAL_MT_NB_L2_H */
