/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_tnl.h
 * PURPOSE:
 *      It provide tunnel hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_TNL_H
#define HAL_TNL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_tnl.h>
#include <hal/hal_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define TERM_ECN_MAP_MODE (0) /* fix term ecn_map_mode to rfc6040 */

#define ALLOC_ZERO_FIELDS (0) /* alloc index in hal-rim only, no hw read-write */
#define ALLOC_ONE_ENTRY   (1)

/* Seg's MSB may be used as control bit, e.g. MPLSoTNL, thus 0 is safer */
#define HAL_TNL_INVALID_SEG (0x0)

#define HAL_TNL_MAX_NUM_OF_FLEX_TNL (0x4)

#define HAL_TNL_FLEX_TNL_TYPE_IP  (1)         /* IDS_KEY_DECAP_FLEX.typ */
#define HAL_TNL_FLEX_TNL_TYPE_UDP (2)         /* IDS_KEY_DECAP_FLEX.typ */

#define HAL_TNL_DFLT_UNDERLAY_VRF_ID    (0x0) /* Default vrf id of underlay network */
#define HAL_TNL_MAX_NUM_OF_UNDERLAY_VRF (512) /* Max number of vrfo */
#define HAL_TNL_MAX_VLAN_VAL            (0xFFF)
#define HAL_TNL_MAX_NUM_OF_ES_GRP       (128) /* Max number of ethernet segment group */
#define HAL_TNL_ENCAP_IDX_BMP_SIZE      (CLX_BITMAP_SIZE(HAL_TNL_NUM))
#define HAL_TNL_ROUTER_MAC_MAX_NUM      (512) /* entry number of IDS_KEY_TCAM_MY_TNL_MAC */
#define HAL_TNL_DST_TEP_MAX_NUM         (512) /* entry number of TDS_TCAM_DST_TEP */
#define HAL_TNL_FLAGS_SID_VLD           (0x1U << 1)
#define HAL_TNL_FLAGS_CID_VLD           (0x1U << 2)

/* {cp2cpu, drop, ecn[1:0]} */
#define HAL_TNL_ECN_ACT_GET(__val__) (__val__ = __val__ & 0xC)
#define HAL_TNL_ECN_ACT_CP2CPU       (0x8)   /* 0b10xx = cp2cpu        */
#define HAL_TNL_ECN_ACT_DROP         (0x4)   /* 0b01xx =          drop */
#define HAL_TNL_ECN_ACT_FWD          (0x0)   /* 0b00xx = n/a           */

#define HAL_TNL_PORT_MERGE_DFLT      (0xdff) /* Merge port index of vlan interface port */
#define HAL_TNL_INVALID_ECMP_MBR_IDX (0)     /* Invalid FWR_RSLT_TNL_ECMP_MBR idx */

/* https://tools.ietf.org/html/draft-singh-nvo3-vxlan-router-alert-01 */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
/* |R|R|R|R|I|R|R|RA|           Reserved                           |  */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
/* |                VXLAN Network Identifier (VNI) |   Reserved    |  */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
#define HAL_NV_VXLAN_LOC_RA_BIT (0x01000000) /* 0000-I00[RA]-0000-0000 */

/* https://tools.ietf.org/html/draft-singh-nvo3-nvgre-router-alert-00 */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
/* |0| |1|0| Reserved0     RA| Ver |   Protocol Type 0x6558        |  */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
/* |               Virtual Subnet ID (VSID)        |   Reserved    |  */
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+  */
#define HAL_NV_NVGRE_LOC_RA_BIT (0x00080000)   /* 00I0-0000-0000-[RA]VVV */

#define HAL_NV_VXLANGPE_LOC_O_BIT (0x01000000) /* 00I0-0000-0000-[RA]VVV */

#define HAL_NV_VXLAN_CTL_IDX_RA    (0)         /* vxlan_bas_ctl_flg_[msk/val/eq]   */
#define HAL_NV_VXLANGPE_CTL_IDX_O  (0)         /* vxlan_gpe_ctl_flg_[msk/val/eq]_0 */
#define HAL_NV_VXLANGPE_CTL_IDX_RA (1)         /* vxlan_gpe_ctl_flg_[msk/val/eq]_1 */
#define HAL_NV_NVGRE_CTL_IDX_RA    (0)         /* gre_ctl_flg_[msk/val/eq]_0       */

#define HAL_NV_CTL_FLG_EXP_EQ  (1)
#define HAL_NV_CTL_FLG_EXP_nEQ (0)

/* 24-bit value to identify the virtual layer 2 network */
#define HAL_NV_SEGMENT_ID_MIN (1)
#define HAL_NV_SEGMENT_ID_MAX (0xffffff)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TNL_DECAP_MODE_CHK(__mode__) (((HAL_TNL_MODE_DECAP & __mode__) > 0) ? TRUE : FALSE)
#define HAL_TNL_ENCAP_MODE_CHK(__mode__) (((HAL_TNL_MODE_ENCAP & __mode__) > 0) ? TRUE : FALSE)
#define HAL_TNL_DECAP_MODE_SET(__mode__) (__mode__ = (__mode__ | HAL_TNL_MODE_DECAP))
#define HAL_TNL_ENCAP_MODE_SET(__mode__) (__mode__ = (__mode__ | HAL_TNL_MODE_ENCAP))
#define HAL_TNL_DECAP_MODE_CLR(__mode__) (__mode__ = (__mode__ ^ HAL_TNL_MODE_DECAP))
#define HAL_TNL_ENCAP_MODE_CLR(__mode__) (__mode__ = (__mode__ ^ HAL_TNL_MODE_ENCAP))

#define HAL_TNL_HAS_SEG_ID(__unit__, __tnl_type__) (hal_tnl_seg_id_chk(__unit__, __tnl_type__))
#define HAL_TNL_USE_CLX_PORT(__key__, __rev__)     (hal_tnl_use_clx_port_chk(__key__, __rev__))

#define HAL_TNL_NVO3_ADJ_CPU_RSN (0)

/* Hw parser tunnel type value */
#define HAL_TNL_ULP_GRE_VAL         (0x2F)
#define HAL_TNL_ULP_IP_TNL_IPV4_VAL (0x4)
#define HAL_TNL_ULP_IP_TNL_IPV6_VAL (0x29)
#define HAL_TNL_VXLAN_BAS_VAL       (0x12B5)
#define HAL_TNL_VXLAN_GPE_VAL       (0x12B6)
#define HAL_TNL_VXLAN_GENEVE_VAL    (0x17C1)
#define HAL_TNL_UDP_DP_GTPU_VAL     (0x868)
#define HAL_TNL_INVALID_PROTO_VAL   (0)

#define HAL_TNL_REVERSE_TNL_HDR(__key_out__, __key_in__)                                     \
    do {                                                                                     \
        osal_memcpy(&((__key_out__).src_ip), &((__key_in__).dst_ip), sizeof(clx_ip_addr_t)); \
        osal_memcpy(&((__key_out__).dst_ip), &((__key_in__).src_ip), sizeof(clx_ip_addr_t)); \
        (__key_out__).tnl_hdr_type = (__key_in__).tnl_hdr_type;                              \
        (__key_out__).underlay_vrf = (__key_in__).underlay_vrf;                              \
    } while (0)
#define HAL_TNL_ENCAP_SIP_NUM (2048) /* cl8600: IPV4 srcip max encap number */
#define HAL_TNL_ENCAP_DIP_NUM (8192) /* cl8600: IPV4 dstip max encap number */
/* cl8600: srcip usage bitmap */
#define HAL_TNL_ENCAP_SIP_USAGE_BMP_SIZE (CLX_BITMAP_SIZE(HAL_TNL_ENCAP_SIP_NUM))
/* cl8600: dstip usage bitmap */
#define HAL_TNL_ENCAP_DIP_USAGE_BMP_SIZE (CLX_BITMAP_SIZE(HAL_TNL_ENCAP_DIP_NUM))
/* cl8600: dst_tep usage bitmap */
#define HAL_TNL_DECAP_DST_TEP_USAGE_BMP_SIZE (CLX_BITMAP_SIZE(HAL_TNL_DST_TEP_MAX_NUM))
/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_TNL_MODE_NONE,
    HAL_TNL_MODE_DECAP,
    HAL_TNL_MODE_ENCAP,
    HAL_TNL_MODE_LAST
} hal_tnl_mode_t;

typedef enum {
    HAL_TNL_TRAV_TYPE_ENCAP,
    HAL_TNL_TRAV_TYPE_DECAP,
    HAL_TNL_TRAV_TYPE_NVO3_ROUTE,
    HAL_TNL_TRAV_TYPE_PORT,
    HAL_TNL_TRAV_TYPE_LAST
} hal_tnl_trav_type_t;

typedef enum {
    HAL_TNL_DB_DUMP_FLAGS_PORT = 0,
    HAL_TNL_DB_DUMP_FLAGS_ENCAP,
    HAL_TNL_DB_DUMP_FLAGS_DECAP,
    HAL_TNL_DB_DUMP_FLAGS_ROUTER_MAC,
    HAL_TNL_DB_DUMP_FLAGS_NVO3_ROUTE,
    HAL_TNL_DB_DUMP_FLAGS_NVO3_ADJ,
    HAL_TNL_DB_DUMP_FLAGS_NV,
    HAL_TNL_DB_DUMP_FLAGS_SE_GRP,
    HAL_TNL_DB_DUMP_FLAGS_MGO,
    HAL_TNL_DB_DUMP_FLAGS_LAST,
} hal_tnl_db_dumo_flags_t;

typedef enum {
    HAL_TNL_RM_TNL_ECMP_MODE_ADJ,
    HAL_TNL_RM_TNL_ECMP_MODE_ECMP,
    HAL_TNL_RM_TNL_ECMP_MODE_LAST
} hal_tnl_rm_rnl_ecmp_mode_t;

/* Packet type allowed to be terminated */
typedef enum {
    HAL_TNL_TERM_EN_TYPE_L2_IN_GRE,
    HAL_TNL_TERM_EN_TYPE_IP_IN_GRE,
    HAL_TNL_TERM_EN_TYPE_ERSPAN,
    HAL_TNL_TERM_EN_TYPE_IP_IN_IP,
    HAL_TNL_TERM_EN_TYPE_VXLAN,
    HAL_TNL_TERM_EN_TYPE_VXLAN_GPE_L2,
    HAL_TNL_TERM_EN_TYPE_VXLAN_GPE_IP,
    HAL_TNL_TERM_EN_TYPE_GENEVE_L2,
    HAL_TNL_TERM_EN_TYPE_GENEVE_IP,
    HAL_TNL_TERM_EN_TYPE_FLEX,
    HAL_TNL_TERM_EN_TYPE_LAST,
} hal_tnl_term_en_type_t;

typedef struct hal_tnl_erspan_decap_avl_node_s {
    clx_tnl_info_t tnl_key; /* AVL tree key: term view */
    uint16 lcl_intf_idx;
    uint32 src_tep_idx;
} hal_tnl_erspan_decap_avl_node_t;

typedef struct hal_tnl_hdr_avl_node_s {
    clx_tnl_info_t tnl_key; /* AVL tree key: init view */
    uint32 tnl_mode;        /* hal_tnl_mode_t */
    uint16 lcl_intf_idx;
    uint16 nvo3_encap_idx;
    uint16 mc_mode;
} hal_tnl_hdr_avl_node_t;

typedef struct hal_tnl_port_avl_node_s {
    clx_tnl_info_t tnl_key; /* AVL tree key: init view */
    uint32 tnl_mode;        /* hal_tnl_mode_t */
    uint16 nvo3_encap_idx;  /* relates clx_tnl_info_t and clx_port */
    uint32 tep_bind_idx;    /* relate to TDS_HSH_TEP_BIND */
} hal_tnl_port_avl_node_t;

typedef struct hal_tnl_nvo3_adj_avl_node_s {
    uint32 nvo3_adj_id;             /* nvo3_adj hardware index */
    clx_port_t port;                /* destination of nvo3_adj, only port/lag are allowed */
    util_lib_list_t *ptr_ecmp_list; /* uint32, ecmp path index list */
} hal_tnl_nvo3_adj_avl_node_t;

typedef struct hal_tnl_nvo3_encap_avl_node_s {
    boolean use_port;
    union {
        hal_tnl_port_avl_node_t *ptr_port_node;
        hal_tnl_hdr_avl_node_t *ptr_key_node;
    };
} hal_tnl_nvo3_encap_avl_node_t;

typedef struct hal_tnl_trav_node_s {
    clx_tnl_info_t key;
    union {
        clx_tnl_encap_info_t tnl_encap;
        clx_tnl_decap_info_t tnl_decap;
        clx_tnl_nvo3_route_info_t tnl_nvo3_route;
    };
} hal_tnl_trav_node_t;

typedef struct hal_tnl_router_mac_s {
    uint32 tnl_port_idx;
    uint32 vlan_id;
} hal_tnl_router_mac_t;

typedef struct hal_tnl_trav_cookie_s {
    uint32 unit;
    util_lib_list_t *ptr_list;
} hal_tnl_trav_cookie_t;

typedef struct hal_tnl_nvo3_adj_trav_node_s {
    uint32 adj_id;
    clx_l3_adj_t adj_info;
} hal_tnl_nvo3_adj_trav_node_t;

typedef struct hal_tnl_decap_dst_tep_key_s {
    uint16 vrfo;
    clx_ip_addr_t dst_ip;
} hal_tnl_decap_dst_tep_key_t;

typedef struct hal_tnl_decap_dip_avl_node_s {
    hal_tnl_decap_dst_tep_key_t dst_tep; /* AVL tree key, tunnel_term.dst_ip and tunnel_term.vrfo */
    uint16 entry_idx;                    /* tnl_decap's entry_idx */
    uint16 ref_cnt;                      /* reference count */
    uint32 ref_term_type[HAL_TNL_TERM_EN_TYPE_LAST]; /* reference count of term tunnel type */
} hal_tnl_decap_dip_avl_node_t;

typedef struct hal_tnl_decap_mgo_avl_node_s {
    hal_tnl_decap_dst_tep_key_t dst_tep; /* AVL tree key, tunnel_term.dst_ip and tunnel_term.vrfo */
    uint16 entry_idx;                    /* tnl_decap's entry_idx */
    uint16 ref_cnt;                      /* reference count */
} hal_tnl_decap_mgo_avl_node_t;

typedef struct hal_tnl_decap_sip_avl_node_s {
    clx_ip_addr_t src_ip;
    uint16 prof_idx;
    uint16 ref_cnt;
} hal_tnl_decap_sip_avl_node_t;

typedef struct hal_tnl_tnlfdid2seg_avl_node_s {
    uint32 lcl_intf_grp;
    uint32 fdid;
    uint32 seg;
} hal_tnl_tnlfdid2seg_avl_node_t;

/* seg_in equals to seg_out, unless tunnel have different segments
 * between local and remote
 */
typedef struct hal_tnl_intfbdid2seg_avl_node_s {
    clx_port_t intf;
    uint32 bdid;
    uint32 seg_in;
    uint32 seg_out;
} hal_tnl_intfbdid2seg_avl_node_t;

typedef struct hal_tnl_cb_s {
    util_lib_avl_head_t *ptr_key_avl;                      /* hal_tnl_hdr_avl_node_t       */
    util_lib_avl_head_t *ptr_port_avl;                     /* hal_tnl_port_avl_node_t  */
    util_lib_avl_head_t *ptr_term_dip_avl;                 /* hal_tnl_decap_dip_avl_node_t  */
    util_lib_avl_head_t *ptr_nvo3_adj_avl;                 /* hal_tnl_nvo3_adj_avl_node_t      */
    util_lib_avl_head_t *ptr_erspan_term_avl;              /* hal_tnl_erspan_decap_avl_node_t   */
    hal_tnl_nvo3_encap_avl_node_t *ptr_nvo3_encap_idx_arr; /* hal_tnl_nvo3_encap_avl_node_t */

    util_lib_avl_head_t *ptr_iev_ecmp_path_avl;            /* hal_cmn_rte_node_t   */
    hal_cmn_rte_node_t **pptr_iev_nvo3_adj_arr; /* maintain nvo3_adj_id->ecmp_path_idx relation */

    uint32 tnl_mac_vlan[HAL_TNL_ROUTER_MAC_MAX_NUM];                  /* HAL_L3T_FLAGS_xxx */

    hal_tnl_router_mac_t tnl_mac_key_arr[HAL_TNL_ROUTER_MAC_MAX_NUM]; /* tunnel mac hash key */
    uint32 sip_usage_bitmap[HAL_TNL_ENCAP_SIP_USAGE_BMP_SIZE];        /* for cl8600 */
    util_lib_avl_head_t *ptr_init_sip_avl;                     /* hal_tnl_decap_sip_avl_node_t */
    uint32 dip_usage_bitmap[HAL_TNL_ENCAP_DIP_USAGE_BMP_SIZE]; /* for cl8600 */
    uint32 dst_tep_usage_bitmap[HAL_TNL_DECAP_DST_TEP_USAGE_BMP_SIZE]; /* for cl8600 */
    uint32 esgrp_ref_arr[HAL_TNL_MAX_NUM_OF_ES_GRP]; /* Bound tunnel port, for cl8600 */
    util_lib_avl_head_t *ptr_term_mgo_avl;           /* hal_tnl_decap_mgo_avl_node_t  */

    clx_tnl_flex_tnl_hdr_type_t flex_tnl_arr[HAL_TNL_MAX_NUM_OF_FLEX_TNL];
    clx_tnl_flex_tnl_udf_prof_t flex_tnl_udf_profile_arr[HAL_TNL_MAX_NUM_OF_FLEX_TNL];

    uint32 nvo3_encap_idx_bitmap[HAL_TNL_ENCAP_IDX_BMP_SIZE];

    /* hal_tnl_tnlfdid2seg_avl_node_t, maintain mc lcl_intf + bdid -> segment mapping relation */
    util_lib_avl_head_t *ptr_nv_tnlfdid2seg_avl;
    /* hal_tnl_tnlfdid2seg_avl_node_t, maintain mc lcl_intf + segment -> bdid mapping relation */
    util_lib_avl_head_t *ptr_nv_tnlseg2fdid_avl;
    /* hal_tnl_intfbdid2seg_avl_node_t, maintain uc lcl_intf + bdid -> segment mapping relation */
    util_lib_avl_head_t *ptr_nv_intfbdid2segall_avl;
    /* hal_tnl_intfbdid2seg_avl_node_t, maintain uc lcl_intf + igr-segment -> bdid
     * mapping relation */
    util_lib_avl_head_t *ptr_nv_intfseglcl2bdid_avl;
    /* hal_tnl_intfbdid2seg_avl_node_t, maintain uc lcl_intf + egr-segment -> bdid
     * mapping relation */
    util_lib_avl_head_t *ptr_nv_intfsegrmt2bdid_avl;

    clx_semaphore_id_t tnl_sema;
    clx_semaphore_id_t nvo3_sema;
} hal_tnl_cb_t;

typedef hal_tnl_cb_t hal_tnl_cb_p[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_tnl_init(const uint32 unit);

clx_error_no_t
hal_tnl_deinit(const uint32 unit);

clx_error_no_t
hal_tnl_port_create(const uint32 unit,
                    const uint32 flag,
                    const clx_tnl_info_t *ptr_tnl_info,
                    clx_port_t *ptr_port);

clx_error_no_t
hal_tnl_port_destroy(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_tnl_port_get(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info, clx_port_t *ptr_tnl_port);

clx_error_no_t
hal_tnl_info_get(const uint32 unit, const clx_port_t tnl_port, clx_tnl_info_t *ptr_tnl_info);

clx_error_no_t
hal_tnl_entry_trav(const uint32 unit, const clx_tnl_port_trav_func_t cb, void *ptr_cookie);

clx_error_no_t
hal_tnl_trav(const uint32 unit,
             const hal_tnl_trav_type_t type,
             const void *ptr_callback,
             void *ptr_cookie);

clx_error_no_t
hal_tnl_flex_tnl_udf_set(const uint32 unit,
                         const uint32 index,
                         clx_tnl_flex_tnl_udf_prof_t *ptr_prof);

clx_error_no_t
hal_tnl_flex_tnl_udf_get(const uint32 unit,
                         const uint32 index,
                         clx_tnl_flex_tnl_udf_prof_t *ptr_prof);

/* EXPORTED HAL SUBPROGRAM BODIES
 */
boolean
hal_tnl_nsh_pld_chk(const clx_tnl_hdr_type_t tunnel_type);

boolean
hal_tnl_seg_id_chk(const uint32 unit, const clx_tnl_hdr_type_t tunnel_type);

boolean
hal_tnl_use_clx_port_chk(const clx_tnl_info_t tnl_hdr, const uint32 term);

boolean
hal_tnl_l2_pld_chk(const clx_tnl_hdr_type_t tunnel_type);

clx_error_no_t
hal_tnl_validate_tnl_port(const uint32 unit, const clx_port_t port);

clx_error_no_t
hal_tnl_hw_init_info_get(const uint32 unit,
                         const uint32 fdid,
                         const clx_port_t port,
                         const clx_tnl_info_t *ptr_key,
                         uint32 *ptr_seg0,
                         uint32 *ptr_seg1,
                         uint32 *ptr_nvo3_encap_idx);

clx_error_no_t
hal_tnl_sw_init_info_get(const uint32 unit,
                         const uint32 nvo3_encap_idx,
                         clx_port_t *ptr_port,
                         clx_tnl_info_t *ptr_key);

clx_error_no_t
hal_tnl_swdb_node_get(const uint32 unit,
                      const clx_tnl_info_t *ptr_key,
                      const boolean use_port,
                      const boolean erspan,
                      void **pptr_found_node);

clx_error_no_t
hal_tnl_hdr_swdb_cfg(const uint32 unit,
                     const hal_cmn_action_t swdb_action,
                     hal_tnl_hdr_avl_node_t *ptr_in_node,
                     hal_tnl_hdr_avl_node_t **pptr_out_node);

clx_error_no_t
hal_tnl_erspan_decap_swdb_cfg(const uint32 unit,
                              const hal_cmn_action_t swdb_action,
                              hal_tnl_erspan_decap_avl_node_t *ptr_in_node,
                              hal_tnl_erspan_decap_avl_node_t **pptr_out_node);

clx_error_no_t
hal_tnl_encap_sip_swdb_cfg(const uint32 unit,
                           const hal_cmn_action_t swdb_action,
                           hal_tnl_decap_sip_avl_node_t *ptr_in_node,
                           hal_tnl_decap_sip_avl_node_t **pptr_out_node);

clx_error_no_t
hal_tnl_nvo3_encap_idx_alloc(const uint32 unit, uint32 *ptr_nvo3_encap_idx);

clx_error_no_t
hal_tnl_lcl_intf_get(const uint32 unit,
                     const clx_tnl_info_t *ptr_key,
                     uint32 *ptr_lcl_intf,
                     clx_dir_t *ptr_dir);

clx_error_no_t
hal_tnl_erspan_decap_lcl_intf_get(const uint32 unit,
                                  const clx_ip_addr_t *ptr_src_ip,
                                  const clx_ip_addr_t *ptr_dst_ip,
                                  const uint32 vrfo,
                                  uint32 *ptr_lcl_intf,
                                  uint32 *ptr_src_tep);

clx_error_no_t
hal_tnl_clx_port_compose(const uint32 unit, const uint32 nvo3_encap_idx, clx_port_t *ptr_port);

clx_error_no_t
hal_tnl_adj_ecmp_list_cfg(const uint32 unit,
                          const hal_cmn_action_t action,
                          const uint32 adj_id,
                          const uint32 grp_id);

clx_error_no_t
hal_tnl_cfg_ecmp_path_by_nvo3_adj_info(const uint32 unit,
                                       const uint32 ecmp_path_idx,
                                       const clx_port_t port);

uint32
hal_tnl_flex_tnl_id_get(const clx_tnl_hdr_type_t tunnel_type);

clx_error_no_t
hal_tnl_flex_tnl_arr_get(const uint32 unit, clx_tnl_flex_tnl_hdr_type_t *ptr_flex_tnl_arr);

hal_tnl_cb_p *
hal_tnl_ctrl_block_get(const uint32 unit);

clx_error_no_t
hal_tnl_db_dump(const uint32 unit, const uint32 flags);

clx_error_no_t
hal_tnl_validate_tnl_type(const uint32 unit, const clx_tnl_hdr_type_t tunnel_type);

clx_error_no_t
hal_tnl_nvo3_adj_swdb_cfg(const uint32 unit,
                          const hal_cmn_action_t swdb_action,
                          hal_tnl_nvo3_adj_avl_node_t *ptr_in_node,
                          hal_tnl_nvo3_adj_avl_node_t **pptr_out_node);

clx_error_no_t
hal_tnl_nvo3_encap_idx_get(const uint32 unit,
                           const clx_tnl_info_t tnl_hdr,
                           uint32 *ptr_nvo3_encap_idx);

clx_error_no_t
hal_tnl_hdr_type_hw_get(const uint32 unit,
                        const clx_tnl_hdr_type_t tnl_type,
                        uint32 *ptr_init_ip_tnl_type);

void
hal_tnl_decap_clx_key_compose(const clx_tnl_info_t *ptr_key_swdb, clx_tnl_info_t *ptr_key_clx);

void
hal_tnl_decap_swdb_key_compose(const clx_tnl_info_t *ptr_key_clx, clx_tnl_info_t *ptr_key_swdb);

clx_error_no_t
hal_tnl_decap_dip_swdb_cfg(const uint32 unit,
                           const hal_cmn_action_t swdb_action,
                           hal_tnl_decap_dip_avl_node_t *ptr_in_node,
                           hal_tnl_decap_dip_avl_node_t **pptr_out_node);

void
hal_tnl_adj_avl_data_destroy(void *ptr_node_data);

clx_error_no_t
hal_tnl_get_hdr_by_port_or_hdr(const uint32 unit,
                               const clx_port_t port,
                               const clx_tnl_info_t *ptr_key,
                               clx_tnl_info_t *ptr_get_key);

/**
 * @brief get seg by tunnel and fdid
 *
 * @param [in]     unit            - Device unit number
 * @param [in]     fdid            - Forwarding domain
 * @param [in]     lcl_intf_grp    - Local interface group
 * @param [out]    ptr_seg         - Segment value (24 bits)
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_tnl_get_segment_by_tnl_fdid(const uint32 unit,
                                const uint32 fdid,
                                const uint32 lcl_intf_grp,
                                uint32 *ptr_seg);

/**
 * @brief get seg by clx_port and fdid
 *
 * ptr_seg0 usually equals to ptr_seg1, unless there are
 * different segments between local and remote
 *
 * @param [in]     unit        - Device unit number
 * @param [in]     port        - Port interface
 * @param [in]     bdid        - Bridge domain
 * @param [out]    ptr_seg0    - Segment0 of local
 * @param [out]    ptr_seg1    - Segment1 of remote
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_tnl_get_segment_by_port_bdid(const uint32 unit,
                                 const clx_port_t port,
                                 const uint32 bdid,
                                 uint32 *ptr_seg0,
                                 uint32 *ptr_seg1);

/**
 * @brief get bdid by clx_port and seg.(for uc tunnel)
 *
 * @param [in]     unit    - Device unit number
 * @param [in]     port    - Port interface
 * @param [in]     seg     - Segment
 * @param [in]     dir     - Direction
 * @param [out]    bdid    - Bridge Domain
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_tnl_get_bdid_by_port_segment(const uint32 unit,
                                 const clx_port_t port,
                                 const uint32 seg,
                                 const clx_dir_t dir,
                                 uint32 *bdid);

/**
 * @brief get fdid by tunnel and seg.(for mc tunnel)
 *
 * @param [in]     unit             - Device unit number
 * @param [in]     lcl_intf_grp     - Local interface group
 * @param [in]     seg              - Segment
 * @param [in]     dir              - Direction
 * @param [out]    ptr_fdid         - Pointer to forwarding domain
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_tnl_get_fdid_by_tnl_segment(const uint32 unit,
                                const uint32 lcl_intf_grp,
                                const uint32 seg,
                                const clx_dir_t dir,
                                uint32 *ptr_fdid);

/**
 * @brief update swdb for seg <-> fdid for service composed of clx_port.
 *
 * @param [in]     unit      - device unit number
 * @param [in]     add       - 1 for add, 0 for del
 * @param [in]     port      - clx_port
 * @param [in]     seg0      - local segment
 * @param [in]     seg1      - remote segment (usually equal to seg0)
 * @param [in]     bdid      - bridge domain ID (don't care for del)
 * @return    clx_error_no_t
 */
clx_error_no_t
hal_tnl_port_db_update(const uint32 unit,
                       const uint32 add,
                       const clx_port_t port,
                       const uint32 seg0,
                       const uint32 seg1,
                       const uint32 bdid);

/**
 * @brief Get tunnel term type from tunnel header type
 *
 * @param [in]     unit                    - device unit number
 * @param [in]     tnl_type                - clx_tnl_hdr_type_t
 * @param [in]     erspan                  - TRUE: erspan-term, FALSE: ip-tunnel
 * @param [out]    ptr_en_type             - pointer to enabled tunnel term type
 * @return    clx_error_no_t
 */
void
hal_tnl_term_en_type_get(const uint32 unit,
                         const clx_tnl_hdr_type_t tnl_type,
                         const boolean erspan,
                         hal_tnl_term_en_type_t *ptr_en_type);

#endif
