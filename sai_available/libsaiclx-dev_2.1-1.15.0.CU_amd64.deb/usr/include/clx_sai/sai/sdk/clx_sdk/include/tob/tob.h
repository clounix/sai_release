/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN HANGZHOU,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME: tob.h
 * PURPOSE:
 *     Table operation bus(TOB) driver
 * NOTES:
 */

#ifndef TOB_H
#define TOB_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <hal/hal_tbl.h>
/* NAMING CONSTANT DECLARATIONS
 */

/* broadcast inst_idx */
#define TOB_INST_IDX_BCAST 0xFFFFFFFF

/* special inst_idx for broadcast */
#define TOB_ODD_INST_IDX_BCAST  0x9FFFFFFF
#define TOB_EVEN_INST_IDX_BCAST 0x8FFFFFFF

#define TOB_MASTER_INST_IDX_BCAST 0x7FFFFFFF
#define TOB_SLAVE_INST_IDX_BCAST  0x6FFFFFFF

/* MACRO FUNCTION DECLARATIONS
 */
#define TOB_DMA_MEM_ALLOC(__ptr_orig__, __ptr_align__, __size__)                               \
    do {                                                                                       \
        (__ptr_align__) = NULL;                                                                \
        (__ptr_orig__) = osal_dma_alloc((__size__) + 32);                                      \
        if (NULL != (__ptr_orig__)) {                                                          \
            (__ptr_align__) = (void *)(__ptr_orig__) + 16 - ((clx_huge_t)(__ptr_orig__) % 16); \
        }                                                                                      \
    } while (0)

#define TOB_DMA_MEM_FREE(__ptr_orig__)   \
    do {                                 \
        if (NULL != (__ptr_orig__)) {    \
            osal_dma_free(__ptr_orig__); \
        }                                \
    } while (0)

#define TOB_CHIP_INFO_SET(__chip_info__, __unit__, __inst_idx__, __subinst_idx__) \
    do {                                                                          \
        __chip_info__.unit = __unit__;                                            \
        __chip_info__.inst_idx = __inst_idx__;                                    \
        __chip_info__.subinst_idx = __subinst_idx__;                              \
    } while (0)

#define TOB_ENTRY_INFO_SET(__entry_info__, __table_id__, __flags__, __entry_idx__, __entry_num__, \
                           __ptr_bank_bmp__, __buf__)                                             \
    do {                                                                                          \
        osal_memset(&__entry_info__, 0, sizeof(tob_entry_info_t));                                \
        __entry_info__.table_id = __table_id__;                                                   \
        __entry_info__.flags = __flags__;                                                         \
        __entry_info__.entry_idx = __entry_idx__;                                                 \
        __entry_info__.entry_num = __entry_num__;                                                 \
        __entry_info__.ptr_bank_bmp = __ptr_bank_bmp__;                                           \
        __entry_info__.ptr_entry = __buf__;                                                       \
    } while (0)

#define TOB_FVP_INFO_SET(__fvp_info__, __field_id__, __value_type__, __value__, __ptr_value__) \
    do {                                                                                       \
        osal_memset(&__fvp_info__, 0, sizeof(tob_fvp_t));                                      \
        __fvp_info__.field_id = __field_id__;                                                  \
        __fvp_info__.value_type = __value_type__;                                              \
        if (NULL == __ptr_value__) {                                                           \
            __fvp_info__.value = __value__;                                                    \
        } else {                                                                               \
            __fvp_info__.ptr_value = __ptr_value__;                                            \
        }                                                                                      \
    } while (0)

#define TOB_FIELDS_INFO_SET(__fields_info__, __table_id__, __entry_idx__, __fvp_count__, \
                            __fvp_info__)                                                \
    do {                                                                                 \
        osal_memset(&__fields_info__, 0, sizeof(tob_entry_fields_info_t));               \
        __fields_info__.table_id = __table_id__;                                         \
        __fields_info__.entry_idx = __entry_idx__;                                       \
        __fields_info__.fvp_count = __fvp_count__;                                       \
        __fields_info__.ptr_fvp = __fvp_info__;                                          \
    } while (0)

#define TOB_TBL_COPY_SET(__copy_info__, __table_id__, __flags__, __src_entry_idx__, \
                         __dst_entry_idx__, __entry_num__)                          \
    do {                                                                            \
        osal_memset(&__copy_info__, 0, sizeof(tob_tbl_copy_info_t));                \
        __copy_info__.table_id = __table_id__;                                      \
        __copy_info__.flags = __flags__;                                            \
        __copy_info__.src_entry_idx = __src_entry_idx__;                            \
        __copy_info__.dst_entry_idx = __dst_entry_idx__;                            \
        __copy_info__.entry_num = __entry_num__;                                    \
    } while (0)

#define TOB_TBL_RESET_SET(__reset_info__, __table_id__, __buf__)       \
    do {                                                               \
        osal_memset(&__reset_info__, 0, sizeof(tob_tbl_reset_info_t)); \
        __reset_info__.table_id = __table_id__;                        \
        __reset_info__.ptr_entry = __buf__;                            \
    } while (0)

/* mem_service needs to be set separately */
#define TOB_INDEX_INFO_SET(__index_info__, __table_id__, __entry_idx__, __type__) \
    do {                                                                          \
        osal_memset(&__index_info__, 0, sizeof(tob_entry_index_info_t));          \
        __index_info__.table_id = __table_id__;                                   \
        __index_info__.entry_idx = __entry_idx__;                                 \
        __index_info__.type = __type__;                                           \
    } while (0)

/*
 * Usage: clx mac address to hardware mac address.
 * Example is as below.
 *  clx_mac_t clx_mac = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};
 *  uint32    hw_mac[2];
 *
 *  After TOB_MAC_CLX_TO_HW(clx_mac, hw_mac),
 *  hw_mac[0] = 0x33445566;
 *  hw_mac[1] = 0x1122;
 */
#define TOB_MAC_CLX_TO_HW(__clx_mac__, __hw_mac__)                                        \
    do {                                                                                  \
        (__hw_mac__)[1] = ((uint32)(((__clx_mac__)[0] << 8) | (__clx_mac__)[1]));         \
        (__hw_mac__)[0] = ((uint32)(((__clx_mac__)[2] << 24) | ((__clx_mac__)[3] << 16) | \
                                    ((__clx_mac__)[4] << 8) | (__clx_mac__)[5]));         \
    } while (0)

/*
 * Usage: hardware mac address to clx mac address.
 * Example is as below.
 *  clx_mac_t clx_mac;
 *  uint32    hw_mac[2] = {0x33445566, 0x1122};
 *
 *  After TOB_MAC_HW_TO_CLX(hw_mac, clx_mac),
 *  clx_mac[0] = 0x11; clx_mac[1] = 0x22;
 *  clx_mac[2] = 0x33; clx_mac[3] = 0x44, clx_mac[4] = 0x55, clx_mac[5] = 0x66;
 */
#define TOB_MAC_HW_TO_CLX(__hw_mac__, __clx_mac__)                 \
    do {                                                           \
        (__clx_mac__)[5] = ((__hw_mac__)[0] & 0x000000FF);         \
        (__clx_mac__)[4] = (((__hw_mac__)[0] >> 8) & 0x000000FF);  \
        (__clx_mac__)[3] = (((__hw_mac__)[0] >> 16) & 0x000000FF); \
        (__clx_mac__)[2] = (((__hw_mac__)[0] >> 24) & 0x000000FF); \
        (__clx_mac__)[1] = ((__hw_mac__)[1] & 0x000000FF);         \
        (__clx_mac__)[0] = (((__hw_mac__)[1] >> 8) & 0x000000FF);  \
    } while (0)

/*
 * Usage: clx ipv6 address to hardware mac address.
 * Example is as below.
 *  clx_ipv6_t clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x00, 0x01,
 *                         0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 *  uint32     hw_ipv6[4];
 *
 *  After TOB_IPV6_CLX_TO_HW(clx_mac, hw_mac),
 *  hw_ipv6[0] = 0xFEA7686B;
 *  hw_ipv6[1] = 0x0A0020FF;
 *  hw_ipv6[2] = 0x1F8D0001;
 *  hw_ipv6[3] = 0x3FFE0B80;
 */
#define TOB_IPV6_CLX_TO_HW(__clx_ipv6__, __hw_ipv6__)                                         \
    do {                                                                                      \
        (__hw_ipv6__)[3] = (uint32)(((__clx_ipv6__)[0] << 24) | ((__clx_ipv6__)[1] << 16) |   \
                                    ((__clx_ipv6__)[2] << 8) | (__clx_ipv6__)[3]);            \
        (__hw_ipv6__)[2] = (uint32)(((__clx_ipv6__)[4] << 24) | ((__clx_ipv6__)[5] << 16) |   \
                                    ((__clx_ipv6__)[6] << 8) | (__clx_ipv6__)[7]);            \
        (__hw_ipv6__)[1] = (uint32)(((__clx_ipv6__)[8] << 24) | ((__clx_ipv6__)[9] << 16) |   \
                                    ((__clx_ipv6__)[10] << 8) | (__clx_ipv6__)[11]);          \
        (__hw_ipv6__)[0] = (uint32)(((__clx_ipv6__)[12] << 24) | ((__clx_ipv6__)[13] << 16) | \
                                    ((__clx_ipv6__)[14] << 8) | (__clx_ipv6__)[15]);          \
    } while (0)

/*
 * Usage: hardware ipv6 address to clx mac address.
 * Example is as below.
 *  uint32     hw_ipv6[4] = {0xFEA7686B, 0x0A0020FF, 0x1F8D0001, 0x3FFE0B80};
 *  clx_ipv6_t clx_ipv6;
 *
 *  After TOB_IPV6_HW_TO_CLX(hw_ipv6, clx_ipv6),
 *  clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x00, 0x01,
 *              0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 */
#define TOB_IPV6_HW_TO_CLX(__hw_ipv6__, __clx_ipv6__)                 \
    do {                                                              \
        (__clx_ipv6__)[15] = ((__hw_ipv6__)[0] & 0x000000FF);         \
        (__clx_ipv6__)[14] = (((__hw_ipv6__)[0] >> 8) & 0x000000FF);  \
        (__clx_ipv6__)[13] = (((__hw_ipv6__)[0] >> 16) & 0x000000FF); \
        (__clx_ipv6__)[12] = (((__hw_ipv6__)[0] >> 24) & 0x000000FF); \
        (__clx_ipv6__)[11] = ((__hw_ipv6__)[1] & 0x000000FF);         \
        (__clx_ipv6__)[10] = (((__hw_ipv6__)[1] >> 8) & 0x000000FF);  \
        (__clx_ipv6__)[9] = (((__hw_ipv6__)[1] >> 16) & 0x000000FF);  \
        (__clx_ipv6__)[8] = (((__hw_ipv6__)[1] >> 24) & 0x000000FF);  \
        (__clx_ipv6__)[7] = ((__hw_ipv6__)[2] & 0x000000FF);          \
        (__clx_ipv6__)[6] = (((__hw_ipv6__)[2] >> 8) & 0x000000FF);   \
        (__clx_ipv6__)[5] = (((__hw_ipv6__)[2] >> 16) & 0x000000FF);  \
        (__clx_ipv6__)[4] = (((__hw_ipv6__)[2] >> 24) & 0x000000FF);  \
        (__clx_ipv6__)[3] = ((__hw_ipv6__)[3] & 0x000000FF);          \
        (__clx_ipv6__)[2] = (((__hw_ipv6__)[3] >> 8) & 0x000000FF);   \
        (__clx_ipv6__)[1] = (((__hw_ipv6__)[3] >> 16) & 0x000000FF);  \
        (__clx_ipv6__)[0] = (((__hw_ipv6__)[3] >> 24) & 0x000000FF);  \
    } while (0)

/*
 * Usage: clx mac address to hardware ipv6 address(divided info 76 and 52 parts).
 * Example is as below.
 *  clx_ipv6_t clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x34, 0x01,
 *                         0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 *  uint32     hw_ipv6[5];
 *
 *  After TOB_IPV6_CLX_TO_HW_76_52(clx_ipv6, hw_ipv6),
 *  hw_ipv6[0] = 0xFEA7686B;
 *  hw_ipv6[1] = 0x0A0020FF;
 *  hw_ipv6[2] = 0x00000401;
 *  hw_ipv6[3] = 0xB801F8D3;
 *  hw_ipv6[4] = 0x0003FFE0;
 */
#define TOB_IPV6_CLX_TO_HW_76_52(__clx_ipv6__, __hw_ipv6__)                                       \
    do {                                                                                          \
        (__hw_ipv6__)[4] = (uint32)(((__clx_ipv6__)[0] << 12) | ((__clx_ipv6__)[1] << 4) |        \
                                    ((__clx_ipv6__)[2] >> 4));                                    \
        (__hw_ipv6__)[3] = (uint32)(((__clx_ipv6__)[2] << 28) | ((__clx_ipv6__)[3] << 20) |       \
                                    ((__clx_ipv6__)[4] << 12) | ((__clx_ipv6__)[5] << 4) |        \
                                    ((__clx_ipv6__)[6] >> 4));                                    \
        (__hw_ipv6__)[2] = (uint32)(((__clx_ipv6__)[6] << 8) | ((__clx_ipv6__)[7] & 0x00000FFF)); \
        (__hw_ipv6__)[1] = (uint32)(((__clx_ipv6__)[8] << 24) | ((__clx_ipv6__)[9] << 16) |       \
                                    ((__clx_ipv6__)[10] << 8) | (__clx_ipv6__)[11]);              \
        (__hw_ipv6__)[0] = (uint32)(((__clx_ipv6__)[12] << 24) | ((__clx_ipv6__)[13] << 16) |     \
                                    ((__clx_ipv6__)[14] << 8) | (__clx_ipv6__)[15]);              \
    } while (0)

/*
 * Usage: hardware ipv6 address(divided info 76 and 52 parts) to clx mac address.
 * Example is as below.
 *  uint32     hw_ipv6[5] = {0xFEA7686B, 0x0A0020FF, 0x00000401, 0xB801F8D3, 0x0003FFE0};
 *  clx_ipv6_t clx_ipv6;
 *
 *  After TOB_IPV6_HW_76_52_TO_CLX(hw_ipv6, clx_ipv6),
 *  clx_ipv6 = {0x3F, 0xFE, 0x0B, 0x80, 0x1F, 0x8D, 0x34, 0x01,
 *              0x0A, 0x00, 0x20, 0xFF, 0xFE, 0xA7, 0x68, 0x6B};
 */
#define TOB_IPV6_HW_76_52_TO_CLX(__hw_ipv6__, __clx_ipv6__)           \
    do {                                                              \
        (__clx_ipv6__)[15] = ((__hw_ipv6__)[0] & 0x000000FF);         \
        (__clx_ipv6__)[14] = (((__hw_ipv6__)[0] >> 8) & 0x000000FF);  \
        (__clx_ipv6__)[13] = (((__hw_ipv6__)[0] >> 16) & 0x000000FF); \
        (__clx_ipv6__)[12] = (((__hw_ipv6__)[0] >> 24) & 0x000000FF); \
        (__clx_ipv6__)[11] = ((__hw_ipv6__)[1] & 0x000000FF);         \
        (__clx_ipv6__)[10] = (((__hw_ipv6__)[1] >> 8) & 0x000000FF);  \
        (__clx_ipv6__)[9] = (((__hw_ipv6__)[1] >> 16) & 0x000000FF);  \
        (__clx_ipv6__)[8] = (((__hw_ipv6__)[1] >> 24) & 0x000000FF);  \
        (__clx_ipv6__)[7] = ((__hw_ipv6__)[2] & 0x000000FF);          \
        (__clx_ipv6__)[6] = (((__hw_ipv6__)[3] << 4) & 0x000000F0) |  \
            (((__hw_ipv6__)[2] >> 8) & 0x0000000F);                   \
        (__clx_ipv6__)[5] = (((__hw_ipv6__)[3] >> 4) & 0x000000FF);   \
        (__clx_ipv6__)[4] = (((__hw_ipv6__)[3] >> 12) & 0x000000FF);  \
        (__clx_ipv6__)[3] = (((__hw_ipv6__)[3] >> 20) & 0x000000FF);  \
        (__clx_ipv6__)[2] = (((__hw_ipv6__)[4] << 4) & 0x000000F0) |  \
            (((__hw_ipv6__)[3] >> 28) & 0x0000000F);                  \
        (__clx_ipv6__)[1] = (((__hw_ipv6__)[4] >> 4) & 0x000000FF);   \
        (__clx_ipv6__)[0] = (((__hw_ipv6__)[4] >> 12) & 0x000000FF);  \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
/* chip info */
typedef struct tob_chip_info_s {
    uint32 unit;        /* unit id */
    uint32 inst_idx;    /* inst index */
    uint32 subinst_idx; /* sub inst index */
} tob_chip_info_t;

/* entry info */
typedef struct tob_entry_info_s {
    uint32 table_id;      /* table id */
    uint32 flags;         /* table entry set flags, TOB_ENTRY_FLAGS_xxx */
    uint32 entry_idx;     /* entry index */
    uint32 entry_num;     /* entry num, use for dma operation, else no care */
    uint32 *ptr_bank_bmp; /* bank bitmap, use for hash operation and dma, else no care */
    uint32 *ptr_entry;    /* entry data */
} tob_entry_info_t;

/* When setting table, the corresponding cache is not set（default set with cache） */
#define TOB_ENTRY_FLAGS_NO_CACHE (1U << 0)
/* Set tcam entry valid */
#define TOB_ENTRY_FLAGS_TCAM_VALID_SET (1U << 1)
/* Set tcam entry invalid */
#define TOB_ENTRY_FLAGS_TCAM_INVALID_SET (1U << 2)
/* Use for set fpu slice 1 */
#define TOB_ENTRY_FLAGS_FPU_SLC1 (1U << 3)
/* Use for hash operation */
#define TOB_ENTRY_FLAGS_HASH_OPERATION (1U << 4)
/* Use for dma operation */
#define TOB_ENTRY_FLAGS_DMA_OPERATION (1U << 5)
/* Use for operation without table lock */
#define TOB_ENTRY_FLAGS_NO_LOCK (1U << 6)
/* Use for mmio operation */
#define TOB_ENTRY_FLAGS_MMIO_OPERATION (1U << 7)

/* field value set type */
typedef enum tob_fvp_value_type_e {
    TOB_FVB_VALUE_TYPE_LENGTH,     /* base on filed length */
    TOB_FVB_VALUE_TYPE_UI32_FIELD, /* fvp value */
    TOB_FVB_VALUE_TYPE_FIELD,      /* fvp ptr_value */
    TOB_FVB_VALUE_TYPE_LAST
} tob_fvp_value_type_t;

/* field info */
typedef struct tob_fvp_s {
    uint32 field_id; /* field id */
    tob_fvp_value_type_t value_type;
    union {
        uint32 *ptr_value;
        uint32 value;
    };
} tob_fvp_t;

/* table fields info */
typedef struct tob_entry_fields_info_s {
    uint32 table_id;    /* table id */
    uint32 entry_idx;   /* entry index */
    uint32 fvp_count;   /* entry field count */
    tob_fvp_t *ptr_fvp; /* entry fields info */
} tob_entry_fields_info_t;

/* copy table info */
typedef struct tob_tbl_copy_info_s {
    uint32 table_id;      /* table id */
    uint32 flags;         /* copy table flag, TOB_COPY_FLAGS_xxx */
    uint32 src_entry_idx; /* source entry index */
    uint32 dst_entry_idx; /* destination entry index */
    uint32 entry_num;     /* number of entries are going to be transferred */
} tob_tbl_copy_info_t;

/* if set, it will be clear source entry hardware info */
#define TOB_COPY_FLAGS_CLEAR_SRC (1U << 0)

/* reset table info */
typedef struct tob_tbl_reset_info_s {
    uint32 table_id;   /* table id */
    uint32 *ptr_entry; /* table reset entry value */
} tob_tbl_reset_info_t;

/* entry index type: logic or phy */
typedef enum tob_entry_index_type_e {
    TOB_IDX_TYPE_LOGIC,
    TOB_IDX_TYPE_PHY,
    TOB_IDX_TYPE_LAST
} tob_entry_index_type_t;

/* entry index service type, currently only fpu hash and tcam used */
typedef union tob_entry_index_service_u {
    clx_swc_hsh_tile_type_t hash_type; /* fpu hash type */
    clx_swc_tcam_type_t tcam_type;     /* fpu tcam type */
} tob_entry_index_service_t;

/* entry index info */
typedef struct tob_entry_index_info_s {
    uint32 table_id;                       /* table id */
    uint32 entry_idx;                      /* entry index */
    tob_entry_index_type_t type;           /* entry index type: logic or phy */
    tob_entry_index_service_t mem_service; /* entry index service type */
} tob_entry_index_info_t;

typedef enum tob_mem_check_mode_e {
    TOB_MEM_CHECK_MODE_LOG = 0,
    TOB_MEM_CHECK_MODE_FAILURE = 1,
    TOB_MEM_CHECK_MODE_REWRITE = 2,
    TOB_MEM_CHECK_MODE_LAST
} tob_mem_check_mode_t;

typedef struct tob_mem_check_info_s {
    uint32 flag;
    tob_mem_check_mode_t mode;
} tob_mem_check_info_t;

typedef clx_error_no_t (*TOB_INST_MAP)(const tob_chip_info_t chip_info,
                                       const uint32 table_id,
                                       uint32 *ptr_map_inst_idx,
                                       uint32 *ptr_map_sub_inst_idx);

typedef clx_error_no_t (*TOB_ENTRY_WRITE)(const tob_chip_info_t chip_info,
                                          const tob_entry_info_t *ptr_entry_info);

typedef clx_error_no_t (*TOB_ENTRY_READ)(const tob_chip_info_t chip_info,
                                         tob_entry_info_t *ptr_entry_info);

typedef clx_error_no_t (*TOB_FIELDS_WRITE)(const tob_chip_info_t chip_info,
                                           const tob_entry_fields_info_t *ptr_fields_info);

typedef clx_error_no_t (*TOB_FIELDS_READ)(const tob_chip_info_t chip_info,
                                          tob_entry_fields_info_t *ptr_fields_info);

typedef clx_error_no_t (*TOB_HASH_ENTRY_ADD)(const tob_chip_info_t chip_info,
                                             tob_entry_info_t *ptr_entry_info);

typedef clx_error_no_t (*TOB_HASH_ENTRY_UPDATE)(const tob_chip_info_t chip_info,
                                                tob_entry_info_t *ptr_entry_info);

typedef clx_error_no_t (*TOB_HASH_ENTRY_LOOKUP)(const tob_chip_info_t chip_info,
                                                tob_entry_info_t *ptr_entry_info);

typedef clx_error_no_t (*TOB_HASH_ENTRY_DEL)(const tob_chip_info_t chip_info,
                                             tob_entry_info_t *ptr_entry_info);

typedef void (*TOB_DMA_ENTRY_SIZE_GET)(const uint32 unit, const uint32 table_id, uint32 *ptr_size);

typedef clx_error_no_t (*TOB_DMA_ENTRY_WRITE)(const tob_chip_info_t chip_info,
                                              const tob_entry_info_t *ptr_entry_info);

typedef clx_error_no_t (*TOB_DMA_ENTRY_READ)(const tob_chip_info_t chip_info,
                                             tob_entry_info_t *ptr_entry_info);

typedef clx_error_no_t (*TOB_TABLE_COPY)(const tob_chip_info_t chip_info,
                                         const tob_tbl_copy_info_t *ptr_copy_info);

typedef clx_error_no_t (*TOB_TABLE_RESET)(const tob_chip_info_t chip_info,
                                          const tob_tbl_reset_info_t *ptr_reset_info);

typedef clx_error_no_t (*TOB_INDEX_LOGIC2PHY)(const uint32 unit,
                                              const tob_entry_index_info_t *ptr_index_info,
                                              uint32 *ptr_phy_idx);

typedef clx_error_no_t (*TOB_INDEX_PHY2LOGIC)(const uint32 unit,
                                              const tob_entry_index_info_t *ptr_index_info,
                                              uint32 *ptr_logic_idx);

typedef boolean (*TOB_INDEX_IS_VALID)(const uint32 unit,
                                      const tob_entry_index_info_t *ptr_index_info);

typedef clx_error_no_t (*TOB_INIT)(const uint32 unit);

typedef clx_error_no_t (*TOB_DEINIT)(const uint32 unit);

typedef struct tob_proc_table_s {
    TOB_INST_MAP tob_inst_map;
    TOB_ENTRY_WRITE tob_entry_write;
    TOB_ENTRY_READ tob_entry_read;
    TOB_FIELDS_WRITE tob_fields_write;
    TOB_FIELDS_READ tob_fields_read;
    TOB_HASH_ENTRY_ADD tob_hash_entry_add;
    TOB_HASH_ENTRY_UPDATE tob_hash_entry_update;
    TOB_HASH_ENTRY_LOOKUP tob_hash_entry_lookup;
    TOB_HASH_ENTRY_DEL tob_hash_entry_del;
    TOB_DMA_ENTRY_SIZE_GET tob_dma_entry_size_get;
    TOB_DMA_ENTRY_WRITE tob_dma_entry_write;
    TOB_DMA_ENTRY_READ tob_dma_entry_read;
    TOB_TABLE_COPY tob_table_copy;
    TOB_TABLE_RESET tob_table_reset;
    TOB_INDEX_LOGIC2PHY tob_index_logic2phy;
    TOB_INDEX_PHY2LOGIC tob_index_phy2logic;
    TOB_INDEX_IS_VALID tob_index_is_valid;
    TOB_INIT tob_init;
    TOB_DEINIT tob_deinit;
} tob_proc_table_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the content in field
 *        buffer.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [in]     ptr_field    - Pointer to the field buffer.
 * @param [out]    ptr_entry    - Pointer to the entry buffer.
 */
void
tob_field_pack(const uint32 unit,
               const uint32 table_id,
               const uint32 field_id,
               const uint32 *ptr_field,
               uint32 *ptr_entry);

/**
 * @brief Extract the specified field from an entry buffer info field buffer.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [out]    ptr_field    - Pointer to the field buffer.
 */
void
tob_field_unpack(const uint32 unit,
                 const uint32 table_id,
                 const uint32 field_id,
                 const uint32 *ptr_entry,
                 uint32 *ptr_field);

/**
 * @brief Substitute the specified bits (field) in the entry buffer with the field value.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit         - Unit number.
 * @param [in]     table_id     - Table ID.
 * @param [in]     field_id     - Field ID.
 * @param [in]     ptr_entry    - Pointer to the entry buffer.
 * @param [in]     field        - Field value.
 * @param [out]    ptr_entry    - Pointer to the entry buffer.
 */
void
tob_field_ui32_pack(const uint32 unit,
                    const uint32 table_id,
                    const uint32 field_id,
                    const uint32 field,
                    uint32 *ptr_entry);

/**
 * @brief Extract the specified field from an entry buffer.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit         - Unit number.
 * @param [in]    table_id     - Table ID.
 * @param [in]    field_id     - Field ID.
 * @param [in]    ptr_entry    - Pointer to the entry buffer.
 * @return        Field value.
 */
uint32
tob_field_ui32_unpack(const uint32 unit,
                      const uint32 table_id,
                      const uint32 field_id,
                      const uint32 *ptr_entry);

/**
 * @brief Map software inst and sub-inst to hardware inst and sub-inst.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     chip_info               - Chip info: unit, inst, subinst.
 * @param [in]     table_id                - Table id.
 * @param [out]    ptr_map_inst_idx        - Map inst index.
 * @param [out]    ptr_map_sub_inst_idx    - Map sub-inst index.
 * @return         CLX_E_OK            - Map success.
 * @return         CLX_E_NOT_INITED    - Tob not inited.
 */
clx_error_no_t
tob_inst_map(const tob_chip_info_t chip_info,
             const uint32 table_id,
             uint32 *ptr_map_inst_idx,
             uint32 *ptr_map_sub_inst_idx);

/**
 * @brief Write an entry from entry buffer to hardware. 1. When writing TCAM table id,
 *        please use table id whose memory type is "MEMORY_TYPE_TABLE_TCAM_COM".
 *
 * Support_chip: CLX86.
 *
 * @param [in]    chip_info         - Chip info: unit, inst, subinst.
 * @param [in]    ptr_entry_info    - Pointer to the entry info.
 * @return        CLX_E_OK        - Write success.
 * @return        CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
tob_entry_write(const tob_chip_info_t chip_info, const tob_entry_info_t *ptr_entry_info);

/**
 * @brief Read an entry from hardware to entry buffer. 1. When reading TCAM table id,
 *        please use table id whose memory type is "MEMORY_TYPE_TABLE_TCAM_COM".
 *
 * If read by slice/sub-slice broadcast, the reading result is first slice/sub-slice table info.
 * Support_chip: CLX86.
 *
 * @param [in]     chip_info         - Chip info: unit, inst, subinst.
 * @param [in]     ptr_entry_info    - Pointer to the entry info.
 * @param [out]    ptr_entry_info    - Pointer to the entry info.
 * @return         CLX_E_OK        - Read success.
 * @return         CLX_E_OTHERS    - Read fail.
 */
clx_error_no_t
tob_entry_read(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

/**
 * @brief Write the specified fields of the specified entry in hardware with the content in field
 *        buffer.
 *
 * Principle: read table info->modify table fields info->write table info.
 * so: if write table fields by slice/sub-slice broadcast, it will copy first
 * slice/sub-slice table info to else slice/sub-slice.
 * Support_chip: CLX86.
 *
 * @param [in]    chip_info          - Chip info: unit, inst, subinst.
 * @param [in]    ptr_fields_info    - Fields info.
 * @return        CLX_E_OK        - Modify success.
 * @return        CLX_E_OTHERS    - Read or write fail.
 */
clx_error_no_t
tob_fields_write(const tob_chip_info_t chip_info, const tob_entry_fields_info_t *ptr_fields_info);

/**
 * @brief Reads the specified fields of the specified entry from hardware with the content in field
 *        buffer.
 *
 * If read by slice/sub-slice broadcast, the reading result is first slice/sub-slice table info.
 * Support_chip: CLX86.
 *
 * @param [in]     chip_info          - Chip info: unit, inst, subinst.
 * @param [in]     ptr_fields_info    - Fields info.
 * @param [out]    ptr_fields_info    - Fields info.
 * @return         CLX_E_OK        - Read success.
 * @return         CLX_E_OTHERS    - Read fail.
 */
clx_error_no_t
tob_fields_read(const tob_chip_info_t chip_info, tob_entry_fields_info_t *ptr_fields_info);

/**
 * @brief Add a hash entry info hardware.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     chip_info         - Chip info: unit, inst, subinst.
 * @param [in]     ptr_entry_info    - Pointer to the hash entry info.
 * @param [out]    ptr_entry_info    - Pointer to the hash entry info.
 * @return         CLX_E_OK        - Add success.
 * @return         CLX_E_OTHERS    - Add fail.
 */
clx_error_no_t
tob_hash_entry_add(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

/**
 * @brief Update a hash entry data info hardware.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     chip_info         - Chip info: unit, inst, subinst.
 * @param [in]     ptr_entry_info    - Pointer to the hash entry info.
 * @param [out]    ptr_entry_info    - Pointer to the hash entry info.
 * @return         CLX_E_OK        - Add success.
 * @return         CLX_E_OTHERS    - Add fail.
 */
clx_error_no_t
tob_hash_entry_update(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

/**
 * @brief Search a hash entry from hardware.
 *
 * If lookup by slice/sub-slice broadcast, the lookup result is first slice/sub-slice table info.
 * Support_chip: CLX86.
 *
 * @param [in]     chip_info         - Chip info: unit, inst, subinst.
 * @param [in]     ptr_entry_info    - Pointer to the hash entry info.
 * @param [out]    ptr_entry_info    - Pointer to the hash entry info.
 * @return         CLX_E_OK        - Search success.
 * @return         CLX_E_OTHERS    - Search fail.
 */
clx_error_no_t
tob_hash_entry_lookup(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

/**
 * @brief Delete a hash entry from hardware.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     chip_info         - Chip info: unit, inst, subinst.
 * @param [in]     ptr_entry_info    - Pointer to the hash entry info.
 * @param [out]    ptr_entry_info    - Pointer to the hash entry info.
 * @return         CLX_E_OK        - Delete success.
 * @return         CLX_E_OTHERS    - Delete fail.
 */
clx_error_no_t
tob_hash_entry_del(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

/**
 * @brief Get entry dma size.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Unit number.
 * @param [in]     table_id    - Table ID.
 * @param [out]    ptr_size    - Entry dma size.
 */
void
tob_dma_entry_size_get(const uint32 unit, const uint32 table_id, uint32 *ptr_size);

/**
 * @brief Write many entries from entry buffer to hardware by DMA.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    chip_info         - Chip info: unit, inst, subinst.
 * @param [in]    ptr_entry_info    - Pointer to the entry info for dma.
 * @return        CLX_E_OK        - Write success.
 * @return        CLX_E_OTHERS    - Write fail.
 */
clx_error_no_t
tob_dma_entry_write(const tob_chip_info_t chip_info, const tob_entry_info_t *ptr_entry_info);

/**
 * @brief Read many entries from hardware to entry buffer by DMA.
 *
 * If read by slice/sub-slice broadcast, the reading result is first slice/sub-slice table info.
 * Support_chip: CLX86.
 *
 * @param [in]     chip_info         - Chip info: unit, inst, subinst.
 * @param [in]     ptr_entry_info    - Pointer to the entry info for dma.
 * @param [out]    ptr_entry_info    - Pointer to the entry info for dma.
 * @return         CLX_E_OK        - Read success.
 * @return         CLX_E_OTHERS    - Read fail.
 */
clx_error_no_t
tob_dma_entry_read(const tob_chip_info_t chip_info, tob_entry_info_t *ptr_entry_info);

/**
 * @brief Copy table data from device to device.
 *
 * Namchabarwa chip, fpu tcam and ciat tcam, default clear src entry info and no operation to set;
 * other, support clear src by flag TOB_COPY_FLAGS_CLEAR_SRC.
 * Support_chip: CLX86.
 *
 * @param [in]    chip_info        - Chip info: unit, inst, subinst.
 * @param [in]    ptr_copy_info    - Pointer to the copy info.
 * @return        CLX_E_OK               - Successfully copy data from device to device.
 * @return        CLX_E_BAD_PARAMETER    - Input parameter has error configuration or value.
 * @return        CLX_E_OTHERS           - Fail to read data from device to device.
 */
clx_error_no_t
tob_table_copy(const tob_chip_info_t chip_info, const tob_tbl_copy_info_t *ptr_copy_info);

/**
 * @brief Write whole table entries with initialized vlue.
 *
 * Namchabarwa chip not support reset fpu hash and tcam table.
 * Support_chip: CLX86.
 *
 * @param [in]    chip_info         - Chip info: unit, inst, subinst.
 * @param [in]    ptr_reset_info    - Pointer to the reset info.
 * @return        CLX_E_OK        - Reset success.
 * @return        CLX_E_OTHERS    - Reset fail.
 */
clx_error_no_t
tob_table_reset(const tob_chip_info_t chip_info, const tob_tbl_reset_info_t *ptr_reset_info);

/**
 * @brief Table entry index mapping logic to phy.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Unit number.
 * @param [in]     ptr_index_info    - Pointer to the entry index info.
 * @param [out]    ptr_phy_idx       - The mapping entry index.
 * @return         CLX_E_OK        - Mapping success.
 * @return         CLX_E_OTHERS    - Mapping fail.
 */
clx_error_no_t
tob_index_logic2phy(const uint32 unit,
                    const tob_entry_index_info_t *ptr_index_info,
                    uint32 *ptr_phy_idx);

/**
 * @brief Table entry index mapping phy to logic.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Unit number.
 * @param [in]     ptr_index_info    - Pointer to the entry index info.
 * @param [out]    ptr_logic_idx     - The mapping entry index.
 * @return         CLX_E_OK        - Mapping success.
 * @return         CLX_E_OTHERS    - Mapping fail.
 */
clx_error_no_t
tob_index_phy2logic(const uint32 unit,
                    const tob_entry_index_info_t *ptr_index_info,
                    uint32 *ptr_logic_idx);

/**
 * @brief Check Table entry index is valid or not.
 *
 * Only support check CLX86 chip multiple table entry index is valid or not,
 * else direct return valid.
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Unit number.
 * @param [in]    ptr_index_info    - Pointer to the entry index info.
 * @return        TRUE     - Table entry index is valid.
 * @return        FALSE    - Table entry index is invalid.
 */
boolean
tob_index_is_valid(const uint32 unit, const tob_entry_index_info_t *ptr_index_info);

/**
 * @brief Tob init.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Unit number.
 * @return        CLX_E_OK        - Init success.
 * @return        CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
tob_init(const uint32 unit);

/**
 * @brief Tob deinit.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Unit number.
 * @return        CLX_E_OK        - Deinit success.
 * @return        CLX_E_OTHERS    - Deinit fail.
 */
clx_error_no_t
tob_deinit(const uint32 unit);

#endif /* End of TOB_H */
