/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_sec.h
 * PURPOSE:
 *      Define the declaration for Security module.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_SEC_H
#define HAL_SEC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_cfg.h>
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_sec.h>
#include <clx/clx_port.h>
#include <osal/osal.h>
#include <drv/drv.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* Macro function declarations for security module control block */
#define HAL_SEC_DOS_SEMA_NAME ("sec_dos") /* dos semaphore name */
#define HAL_SEC_SC_SEMA_NAME  ("sec_sc")  /* storm semaphore name */
#define HAL_SEC_SG_SEMA_NAME  ("sec_sg")  /* source guard semaphore name */
#define HAL_SEC_TI_SEMA_NAME  ("sec_ti")  /* traffic isolate semaphore name */

#define HAL_SEC_STORM_CTRL_RATE_NUM (3)   /* storm control rate mum */

/* port isolation group max */
#define HAL_SEC_PORT_ISOLATION_GRP_MAX (64)

/* storm meter packet length in pps mode */
#define HAL_SEC_MTR_PKT_LEN (128)

/* storm meter translate packet to rate
 * rate = (((packet) * HAL_SEC_MTR_PKT_LEN * 8) / 1000)
 */
#define HAL_SEC_MTR_PKT_TO_RATE(packet, rate)                 \
    do {                                                      \
        uint64 __pkt1__;                                      \
        uint64 __rate1__;                                     \
        osal_memset(&__pkt1__, 0, sizeof(uint64));            \
        osal_memset(&__rate1__, 0, sizeof(uint64));           \
        UI64_ADD_UI32(__pkt1__, packet);                      \
        UI64_MULT_UI32(__pkt1__, (HAL_SEC_MTR_PKT_LEN * 8));  \
        util_lib_bit_u64_div_u32(__pkt1__, 1000, &__rate1__); \
        rate = UI64_LOW(__rate1__);                           \
    } while (0)

/* storm meter translate rate to packet
 * packet =  (((rate) * 1000) / (HAL_SEC_MTR_PKT_LEN * 8))
 */
#define HAL_SEC_MTR_RATE_TO_PKT(rate, packet)                                      \
    do {                                                                           \
        uint64 __pkt2__;                                                           \
        uint64 __rate2__;                                                          \
        osal_memset(&__pkt2__, 0, sizeof(uint64));                                 \
        osal_memset(&__rate2__, 0, sizeof(uint64));                                \
        UI64_ADD_UI32(__rate2__, rate);                                            \
        UI64_MULT_UI32(__rate2__, (1000));                                         \
        util_lib_bit_u64_div_u32(__rate2__, (HAL_SEC_MTR_PKT_LEN * 8), &__pkt2__); \
        packet = UI64_LOW(__pkt2__);                                               \
    } while (0)

/* storm meter translate round rate to packet */
#define HAL_SEC_MTR_ROUND_RATE_TO_PKT(rate, packet)        \
    do {                                                   \
        uint32 __pkt__ = 0;                                \
        uint32 __rate__ = 0;                               \
        HAL_SEC_MTR_RATE_TO_PKT(rate, __pkt__);            \
        HAL_SEC_MTR_PKT_TO_RATE(__pkt__, __rate__);        \
        packet = __rate__ != rate ? __pkt__ + 1 : __pkt__; \
    } while (0)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_SEC_DOS_LOCK(unit)   hal_sec_sema((unit), HAL_SEC_ACT_LOCK, HAL_SEC_ST_DOS)
#define HAL_SEC_SC_LOCK(unit)    hal_sec_sema((unit), HAL_SEC_ACT_LOCK, HAL_SEC_ST_SC)
#define HAL_SEC_SG_LOCK(unit)    hal_sec_sema((unit), HAL_SEC_ACT_LOCK, HAL_SEC_ST_SG)
#define HAL_SEC_TI_LOCK(unit)    hal_sec_sema((unit), HAL_SEC_ACT_LOCK, HAL_SEC_ST_TI)
#define HAL_SEC_DOS_UNLOCK(unit) hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_DOS)
#define HAL_SEC_SC_UNLOCK(unit)  hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_SC)
#define HAL_SEC_SG_UNLOCK(unit)  hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_SG)
#define HAL_SEC_TI_UNLOCK(unit)  hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_TI)

/* DATA TYPE DECLARATIONS
 */

/* storm control packet rate mode */
typedef enum hal_sec_storm_ctrl_pkt_rate_mode_e {
    HAL_SEC_STORM_CTRL_PKT_RATE_MODE_KBPS, /* kbps */
    HAL_SEC_STORM_CTRL_PKT_RATE_MODE_PPS,  /* pps */
    HAL_SEC_STORM_CTRL_PKT_RATE_MODE_LAST
} hal_sec_storm_ctrl_pkt_rate_mode_t;

/* storm control meter config */
typedef struct hal_sec_sc_meter_cfg_s {
    hal_sec_storm_ctrl_pkt_rate_mode_t pkt_rate_mode; /* packet rate mode */
    boolean enable;                                   /* enable */
    uint32 meter_idx;                                 /* Storm control meter hw index. */
    uint32 rate_limit;  /* Storm control rate limit. The rate unit is 1 Kbps. */
    uint32 bucket_size; /* bucket size */
    uint32 layer1;      /* layer1 */
} hal_sec_sc_meter_cfg_t;

/* traffic isolation config */
typedef struct hal_sec_ti_cfg_s {
    clx_port_bitmap_t igr_pbm; /* ingress port bitmap */
    clx_port_bitmap_t egr_pbm; /* egress port bitmap */
} hal_sec_ti_cfg_t;

/* security control block */
typedef struct hal_sec_cb_s {
    hal_sec_ti_cfg_t ti[HAL_SEC_PORT_ISOLATION_GRP_MAX]; /* traffic isolation, CL8600 only */
} hal_sec_cb_t;

/* security warm boot database */
typedef enum hal_sec_wbdb_e {
    HAL_SEC_WBDB_TI_CFG, /* traffic isolation config */
    HAL_SEC_WBDB_LAST
} hal_sec_wbdb_t;

/* security action */
typedef enum hal_sec_action_e {
    HAL_SEC_ACT_INIT,   /* init */
    HAL_SEC_ACT_DEINIT, /* deinit */
    HAL_SEC_ACT_LOCK,   /* lock */
    HAL_SEC_ACT_UNLOCK, /* unlock */
    HAL_SEC_ACT_LAST,
} hal_sec_action_t;

/* Security SDK API Semaphore Type */
typedef enum hal_sec_sema_type_e {
    HAL_SEC_ST_DOS, /* semaphore type dos */
    HAL_SEC_ST_SC,  /* semaphore type storm control */
    HAL_SEC_ST_SG,  /* semaphore type source guard */
    HAL_SEC_ST_TI,  /* semaphore type traffic isolation */
    HAL_SEC_ST_LAST
} hal_sec_sema_type_t;

/* storm control counter pool entry */
typedef struct hal_sec_sccounter_entry_s {
    uint64 cnt[3]; /* cnt[0]: fwd byte;
                    * cnt[1]: fwd packet;
                    * cnt[2]: drop packet
                    */
} hal_sec_sccounter_entry_t;

/* security resource protection semaphores */
extern clx_semaphore_id_t _hal_sec_sema_dos[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM]; /* dos */
extern clx_semaphore_id_t _hal_sec_sema_sc[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];  /* storm control */
extern clx_semaphore_id_t _hal_sec_sema_sg[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];  /* source guard */
extern clx_semaphore_id_t _hal_sec_sema_ti[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];  /* traffic isolation
                                                                                */
extern hal_sec_cb_t _hal_sec_cb[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM]; /* security control block */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize security module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_sec_init(const uint32 unit);

/**
 * @brief Deinitialize security module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_sec_deinit(const uint32 unit);

/**
 * @brief Operate security controlled semaphore.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    action    - Device resource action.
 * @param [in]    type      - Device resource type.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Operation fail.
 */
clx_error_no_t
hal_sec_sema(const uint32 unit, const hal_sec_action_t action, const hal_sec_sema_type_t type);

/**
 * @brief Get Dos Port profile info.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    port              - Port id.
 * @param [in]    ptr_profile_id    - Profile info.
 * @param [in]    ptr_ref_cnt       - Reference count.
 * @return        CLX_E_OK    - Operation succeeded.
 * @return        Others      - Operation failed.
 */
clx_error_no_t
hal_sec_dos_port_prof_info_get(const uint32 unit,
                               const uint32 port,
                               uint32 *ptr_profile_id,
                               uint32 *ptr_ref_cnt);

/**
 * @brief This API is used to get storm control stats information.
 *
 * Support_chip: all.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port         - Port ID.
 * @param [out]    ptr_stats    - The storm control stats information.
 * @return         CLX_E_OK               - Operation is successful.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory for this operation.
 * @return         CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_sec_storm_ctrl_stats_get(const uint32 unit,
                             const uint32 port,
                             clx_sec_storm_ctrl_stats_t *ptr_stats);

/**
 * @brief This API is used to clear storm control stats information.
 *
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port ID.
 * @return        CLX_E_OK               - Operation is successful.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation fail.
 */
clx_error_no_t
hal_sec_storm_ctrl_stats_clear(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get DoS count.
 *
 * Support_chip: all.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cnt    - DoS count.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_sec_dos_cnt_get(const uint32 unit, clx_sec_dos_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear DoS count.
 *
 * Support_chip: all.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_sec_dos_cnt_clear(const uint32 unit);

#endif /* End of HAL_SEC_H */
