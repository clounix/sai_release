/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_STAT_H
#define HAL_STAT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_stat.h>
#include <clx/clx_tm.h>
#include <drv/drv_io.h>
#include <hal/hal_sec.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_STAT_ENABLE_PP_CNT
#define HAL_STAT_ENABLE_ETHX_CNT
#define HAL_STAT_POLLING_INTERVAL         (10000)
#define HAL_STAT_MAX_POLLING_CNT          ((4 * 1000000) / HAL_STAT_POLLING_INTERVAL)
#define HAL_STAT_THREAD_STACK_SIZE        (64 * 1024)
#define HAL_STAT_THREAD_PRIORITY          (30)
#define HAL_STAT_MAX_CPI_LANE             (4)
#define HAL_STAT_MAX_SRV_CNT_NUM_PER_BANK (1024 * 6)
#define HAL_STAT_MAX_SRV_CNT_BANK_NUM     (16)
#define HAL_STAT_MAX_SRV_CNT_EXT_BANK_NUM (4)
#define HAL_STAT_MAX_DST_CNT_NUM_PER_BANK (256)
#define HAL_STAT_MAX_DST_CNT_BANK_NUM     (4)
#define HAL_STAT_MAX_SRV_CNT_NUM          (HAL_STAT_MAX_SRV_CNT_NUM_PER_BANK * HAL_STAT_MAX_SRV_CNT_BANK_NUM)
#define HAL_STAT_MAX_DST_CNT_NUM          (HAL_STAT_MAX_DST_CNT_NUM_PER_BANK * HAL_STAT_MAX_DST_CNT_BANK_NUM)
#define HAL_STAT_MAX_PP_CNT_NUM           (HAL_STAT_MAX_SRV_CNT_NUM + HAL_STAT_MAX_DST_CNT_NUM)
#define HAL_STAT_MAX_FP_LANE              (256)
#define HAL_STAT_MAX_SERDES_LANE          (HAL_STAT_MAX_FP_LANE + HAL_STAT_MAX_CPI_LANE)
#define HAL_STAT_MAX_SW_TOTAL_PORT_NUM    (256 + 2 + 1)
#define HAL_STAT_MAX_SRV_CNT_BMP_SIZE     ((HAL_STAT_MAX_SRV_CNT_NUM - 1) / 32 + 1)
#define HAL_STAT_MAX_DST_CNT_BMP_SIZE     ((HAL_STAT_MAX_DST_CNT_NUM - 1) / 32 + 1)
#define HAL_STAT_INVALID_HW_CNT_IDX       (0xFFFFFF)
#define HAL_STAT_INVALID_SRV_CNT_ID       (0x3FFFF)
#define HAL_STAT_INVALID_DST_CNT_ID       (0x3FF)
#define HAL_STAT_INVALID_TM_QUEUE_IDX     (0xFFFFFFFF)
#define HAL_STAT_DST_CNT_FIELD_NUM        (12)
#define HAL_STAT_IPORT_OPORT_FIELD_NUM    (2)
#define HAL_STAT_INTER_FRAME_GAP_SIZE     (12)
#define HAL_STAT_PREAMBLE_SZIE            (8)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_STAT_INIT_TASK(task, inst_idx_in, subinst_idx_in, table_id_in, entry_idx_in, addr_in, \
                           ptr_buf_in, entry_len_in, entry_num_in)                                \
    do {                                                                                          \
        (task).inst_idx = (inst_idx_in);                                                          \
        (task).subinst_idx = (subinst_idx_in);                                                    \
        (task).table_id = (table_id_in);                                                          \
        (task).entry_idx = (entry_idx_in);                                                        \
        (task).addr = (addr_in);                                                                  \
        (task).ptr_buf = (ptr_buf_in);                                                            \
        (task).entry_len = (entry_len_in);                                                        \
        (task).entry_num = (entry_num_in);                                                        \
    } while (0)

#define HAL_STAT_UPDATE_CNT_SRC32(dest64, src32_now, src32_last, src_max) \
    do {                                                                  \
        UI64_ADD_UI32(dest64, (src32_now - src32_last) & src_max);        \
    } while (0)

#define HAL_STAT_UPDATE_CNT_SRC64(dest64, src64_now, src64_last, src_high_max)           \
    do {                                                                                 \
        uint64 _sub;                                                                     \
        uint64 _max;                                                                     \
        UI64_ASSIGN(_sub, UI64_HI(src64_now), UI64_LOW(src64_now));                      \
        UI64_ASSIGN(_max, src_high_max, 0xFFFFFFFFUL);                                   \
        UI64_SUB_UI64(_sub, src64_last);                                                 \
        UI64_AND(_sub, _max);                                                            \
        UI64_ADD_UI64(dest64, _sub);                                                     \
        if (UI64_CMP(src64_now, src64_last) < 0) {                                       \
            UTIL_LOG_PRINT(UTIL_LOG_STAT_DMA, UTIL_LOG_INFO, "now %x %x, last %x %x\n",  \
                           UI64_HI(src64_now), UI64_LOW(src64_now), UI64_HI(src64_last), \
                           UI64_LOW(src64_last));                                        \
        }                                                                                \
    } while (0)

#define HAL_STAT_LOCK(__unit__) \
    osal_semaphore_take(&(_ptr_hal_stat_cb[__unit__]->sema_rsrc), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_UNLOCK(__unit__) osal_semaphore_give(&(_ptr_hal_stat_cb[__unit__]->sema_rsrc))
#define HAL_STAT_WAIT(__unit__) \
    osal_semaphore_take(&(_ptr_hal_stat_cb[__unit__]->sema_task), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_SIGNAL(__unit__) osal_semaphore_give(&(_ptr_hal_stat_cb[__unit__]->sema_task))
#define HAL_STAT_DMA_LOCK(__unit__) \
    osal_semaphore_take(&(_ptr_hal_stat_cb[__unit__]->sema_dma), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_DMA_UNLOCK(__unit__) osal_semaphore_give(&(_ptr_hal_stat_cb[__unit__]->sema_dma))
#define HAL_STAT_CNT_LOCK(__unit__, __type__)                                   \
    osal_semaphore_take(&(_ptr_hal_stat_cb[__unit__]->stat_buf[__type__].sema), \
                        CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_CNT_UNLOCK(__unit__, __type__) \
    osal_semaphore_give(&(_ptr_hal_stat_cb[__unit__]->stat_buf[__type__].sema))
#define HAL_STAT_API_CNT_LOCK(__unit__) \
    osal_semaphore_take(&(_ptr_hal_stat_cb[__unit__]->api_cnt.sema), CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_STAT_API_CNT_UNLOCK(__unit__) \
    osal_semaphore_give(&(_ptr_hal_stat_cb[__unit__]->api_cnt.sema))
#define HAL_STAT_SW_CNT_INFO(__unit__) (_ptr_hal_stat_cb[__unit__]->sw_cnt_info)
#define HAL_STAT_SW_CNT_BMAP(__unit__) (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.usage_bmap)
#define HAL_STAT_SW_CNT_HW_ID(__unit__, __sw_id__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.hw_cnt_id[__sw_id__])
#define HAL_STAT_SW_CNT_CFG(__unit__, __sw_id__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.cfg[__sw_id__])
#define HAL_STAT_SW_REF_CNT(__unit__, __sw_id__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.ref_cnt[__sw_id__])
#define HAL_STAT_SRV_CNT_INFO(__unit__, __bank__) (_ptr_hal_stat_cb[__unit__]->srv_banks[__bank__])
#define HAL_STAT_DST_CNT_INFO(__unit__, __bank__) (_ptr_hal_stat_cb[__unit__]->dst_banks[__bank__])
#define HAL_STAT_MIB_SW_CNT(__unit__, __lane__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.mib_sw[__lane__][__type__])
#define HAL_STAT_API_RFC_CNT(__unit__, __port__, __type__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.rfc_cnt[__port__][__type__][__idx__])
#define HAL_STAT_RFC_BMAP(__unit__, __port__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.update_bmap[__port__])
#define HAL_STAT_CLX_MIB_SW_CNT(__unit__, __sw_port__, __type__) \
    (_ptr_hal_stat_cb[__unit__]                                  \
         ->api_cnt.clx_mib_sw[__sw_port__][__type__ - HAL_STAT_MIB_SW_CLX_MIB_START])
#define HAL_STAT_CLX_EXCPT_SW_CNT(__unit__, __sw_port__, __type__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.excpt_sw[__sw_port__][__type__][__idx__])
#define HAL_STAT_PP_RSN_CNT(__unit__, __rsn_idx__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.pp_rsn_cnt[__rsn_idx__][__type__])
#define HAL_STAT_CLX_PKT_RSN_CNT(__unit__, __rsn_idx__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.clx_pkt_rsn_cnt[__rsn_idx__][__type__])
#define HAL_STAT_CLX_MIB_SW_BMAP(__unit__, __sw_port__) \
    (_ptr_hal_stat_cb[__unit__]->api_cnt.update_bmap[__sw_port__])
#define HAL_STAT_PORT_RATE(__unit__, __lane__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->stat_rate.port[__lane__][__type__])
#define HAL_STAT_LAST_PORT_RATE(__unit__, __port__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->stat_rate.last_port_rate[__port__][__type__])
#define HAL_STAT_PORT_RATE_LAST_CNT(__unit__, __port__, __type__) \
    (_ptr_hal_stat_cb[__unit__]->stat_rate.last_value[__port__][__type__])
#define HAL_STAT_SRV_BMAP(__unit__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.srv_reset_bmap[__idx__])
#define HAL_STAT_DST_BMAP(__unit__, __idx__) \
    (_ptr_hal_stat_cb[__unit__]->sw_cnt_info.dst_reset_bmap[__idx__])
#define HAL_STAT_CONST_PP(__unit__, __idx__)  (PTR_HAL_CONST_INFO(__unit__, stat)->pp[__idx__])
#define HAL_STAT_CONST_MAC(__unit__, __idx__) (PTR_HAL_CONST_INFO(__unit__, stat)->mac[__idx__])
#define HAL_STAT_CONST_TM(__unit__, __idx__)  (PTR_HAL_CONST_INFO(__unit__, stat)->tm[__idx__])

#define HAL_STAT_GET_HW_CNT_TYPE(__virt_hw_cnt_id__) ((__virt_hw_cnt_id__ >> 24) & 0xFF)
#define HAL_STAT_GET_HW_CNT_IDX(__virt_hw_cnt_id__)  (__virt_hw_cnt_id__ & 0xFFFFFF)
#define HAL_STAT_SET_HW_CNT_ID(__virt_hw_cnt_id__, __hw_cnt_type__, __phy_hw_cnt_idx__) \
    (__virt_hw_cnt_id__ = (((__hw_cnt_type__ & 0xFF) << 24) | (__phy_hw_cnt_idx__ & 0xFFFFFF)))
#define HAL_STAT_SET_HW_CNT_TYPE(__virt_hw_cnt_id__, __hw_cnt_type__) \
    (__virt_hw_cnt_id__ = (((__hw_cnt_type__ & 0xFF) << 24) | (__virt_hw_cnt_id__ & 0xFFFFFF)))

#define HAL_STAT_LANE_IDX(__unit__, __port__)                                  \
    (HAL_IS_DEVICE_NAMCHABARWA_FAMILY(__unit__)) ?                             \
        ((HAL_CL_PORT_TO_ETH_MACRO(__unit__, __port__) *                       \
              HAL_STAT_CONST_MAC(__unit__, HAL_STAT_CAP_LANE_NUM_PER_MAC_ID) + \
          HAL_CL_PORT_TO_MACRO_PORT(__unit__, __port__))) :                    \
        (((HAL_CL_PORT_TO_DIE(__unit__, __port__) *                            \
           HAL_STAT_CONST_MAC(__unit__, HAL_STAT_CAP_MAC_NUM_PER_DIE_ID)) +    \
          HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__)) *                      \
             HAL_STAT_CONST_MAC(__unit__, HAL_STAT_CAP_LANE_NUM_PER_MAC_ID) +  \
         HAL_CL_PORT_TO_MACRO_PORT(__unit__, __port__))

#define HAL_STAT_CHECK_FILTER0(flags)   (flags & (1U << 0))
#define HAL_STAT_CHECK_HIDDEN_ON(flags) (flags & (1U << 1))

#define HAL_STAT_DBG_SHOW_INDENT(__space_num__) \
    do {                                        \
        uint32(__temp__) = (__space_num__);     \
        while (0 != (__temp__)) {               \
            osal_printf(" ");                   \
            (__temp__) -= 1;                    \
        }                                       \
    } while (0)

#ifdef CLX_STAT_EN_HPC_CNT
#define HAL_STAT_HPC_DEFAULT_POLLING_INTERVAL_MS (500)
#define HAL_STAT_HPC_MIN_POLLING_INTERVAL_MS     (250)
#define HAL_STAT_HPC_MAX_POLLING_INTERVAL_MS     (1000)
#define HAL_STAT_HPC_DEFAULT_UPDATE_INTVL_US     (10000)
#endif /* End of CLX_STAT_EN_HPC_CNT */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_STAT_WBDB_SW_CNT_ID = 0,
    HAL_STAT_WBDB_SRV_BANK_ID,
    HAL_STAT_WBDB_DST_BANK_ID,
    HAL_STAT_WBDB_TM_CFG_ID,
#ifdef CLX_STAT_EN_HPC_CNT
    HAL_STAT_WBDB_HPC_CFG_ID,
    HAL_STAT_WBDB_HPC_STATE_ID,
#endif /* End of CLX_STAT_EN_HPC_CNT */
    HAL_STAT_WBDB_OBJ_LAST
} hal_stat_wbdb_obj_type_t;

typedef enum {
    HAL_STAT_HW_TYPE_SRV_CNT = 0,
    HAL_STAT_HW_TYPE_SRV_CNT_EXT0,
    HAL_STAT_HW_TYPE_SRV_CNT_EXT1,
    HAL_STAT_HW_TYPE_SRV_CNT_EXT2,
    HAL_STAT_HW_TYPE_DST_CNT,
    HAL_STAT_HW_TYPE_STM_CNT,
    HAL_STAT_HW_TYPE_EXCPT_IEV_CNT,
    HAL_STAT_HW_TYPE_EXCPT_EME_CNT,
    HAL_STAT_HW_TYPE_ETHC_MIB_SRAM,
    HAL_STAT_HW_TYPE_ETHC_MIB_REG,
    HAL_STAT_HW_TYPE_ETHX_MIB_SRAM,
    HAL_STAT_HW_TYPE_ETHX_MIB_REG,
    HAL_STAT_HW_TYPE_TM,
    HAL_STAT_HW_TYPE_TM_ENB,
    HAL_STAT_HW_TYPE_TM_SPC_CNT,
    HAL_STAT_HW_TYPE_TM_XBN_EVENT,
    HAL_STAT_HW_TYPE_TM_XBN_CELL_ERR,
    HAL_STAT_HW_TYPE_TM_XBN_PATH_ERR,
    HAL_STAT_HW_TYPE_TM_ENB_STC,
    HAL_STAT_HW_TYPE_TM_ENB_STC_PKT,
    HAL_STAT_HW_TYPE_TM_ADM,
    HAL_STAT_HW_TYPE_TM_EA_P,
    HAL_STAT_HW_TYPE_TM_EA_G,
    HAL_STAT_HW_TYPE_TM_EA_G_STR,
    HAL_STAT_HW_TYPE_TM_IOS,
    HAL_STAT_HW_TYPE_TM_EPM,
    HAL_STAT_HW_TYPE_TM_EPM_LBK,
    HAL_STAT_HW_TYPE_TM_LBM,
    HAL_STAT_HW_TYPE_TM_ETM_DROP,
    HAL_STAT_HW_TYPE_TM_ETM_REMOTE_CPU_DROP,
    HAL_STAT_HW_TYPE_TM_EPM_DROP,
    HAL_STAT_HW_TYPE_TM_LBM_EMIR_DROP,
    HAL_STAT_HW_TYPE_TM_LBM_CP2CPU_DROP,
    HAL_STAT_HW_TYPE_TM_LBM_EXP2CPU_DROP,
    HAL_STAT_HW_TYPE_L2_MTU_ECNT,
    HAL_STAT_HW_TYPE_TM_ENB_BUF_FULL_TRUC,
    HAL_STAT_HW_TYPE_TM_EA_P_UC_AOQ_STA,
    HAL_STAT_HW_TYPE_TM_EA_P_MC_AOQ_STA,
    HAL_STAT_HW_TYPE_TM_EA_P_UCMC_AOQ_STA,
    HAL_STAT_HW_TYPE_TM_EA_PCIEQ_STA,
    HAL_STAT_HW_TYPE_TM_EA_EP0CPUQ_STA_STA,
    HAL_STAT_HW_TYPE_TM_EA_EP1CPUQ_STA_STA,
    HAL_STAT_HW_TYPE_TM_IA_AIQ_CNT,
    HAL_STAT_HW_TYPE_TM_IA_AIQ_HRM_CNT,
    /* CL8570 */
    HAL_STAT_HW_TYPE_FLEX_IGR_CNT,
    HAL_STAT_HW_TYPE_TM_ADM_TMIIN,
    HAL_STAT_HW_TYPE_TM_ADM_PASS,
    HAL_STAT_HW_TYPE_TM_ADM_DROP,
    HAL_STAT_HW_TYPE_TM_ADM_FULL,
    HAL_STAT_HW_TYPE_TM_EA_DROP,
    HAL_STAT_HW_TYPE_TM_EA_PASS,
    HAL_STAT_HW_TYPE_TM_EA_REQ,
    HAL_STAT_HW_TYPE_TM_IA_DROP,
    HAL_STAT_HW_TYPE_TM_IA_PASS,
    HAL_STAT_HW_TYPE_TM_IA_REQ,
    HAL_STAT_HW_TYPE_TM_DEB,
    HAL_STAT_HW_TYPE_TM_ENB_TYPE,
    HAL_STAT_HW_TYPE_TM_IPM,
    HAL_STAT_HW_TYPE_TM_TMI,
    HAL_STAT_HW_TYPE_TM_TMI_TYPE,
    HAL_STAT_HW_TYPE_TM_TMI_STC,
    HAL_STAT_HW_TYPE_TM_UQM,
    HAL_STAT_HW_TYPE_TM_XBNR,
    HAL_STAT_HW_TYPE_TM_XBNS,
    HAL_STAT_HW_TYPE_TM_ADM_CMS,
    HAL_STAT_HW_TYPE_TM_DEB_FLUSH,
    HAL_STAT_HW_TYPE_TM_EPM_ERR,
    HAL_STAT_HW_TYPE_TM_IOS_LBS,
    HAL_STAT_HW_TYPE_TM_IOS_SCNT,
    HAL_STAT_HW_TYPE_TM_IOS_DEQ,
    HAL_STAT_HW_TYPE_TM_IOS_LBS_DEQ,
    /* CL8600 */
    HAL_STAT_HW_TYPE_IN_PORT,
    HAL_STAT_HW_TYPE_OUT_PORT,
    HAL_STAT_HW_TYPE_EPP_RSN_CNT,
    HAL_STAT_HW_TYPE_IPP_RSN_CNT,
    HAL_STAT_HW_TYPE_CNT_RSN_GRP0,
    HAL_STAT_HW_TYPE_IPL_APP_DROP_PKT_CNT,

    HAL_STAT_HW_TYPE_TM_SQ_DROP_PKT_CNT_MEM0,
    HAL_STAT_HW_TYPE_TM_SQ_DROP_PKT_CNT_MEM1,
    HAL_STAT_HW_TYPE_TM_SQ_DROP_MISC_CNT_MEM0,
    HAL_STAT_HW_TYPE_TM_SQ_DROP_MISC_CNT_MEM1,

    HAL_STAT_HW_TYPE_TM_PORT_RX_DROP_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_PORT_RX_DROP_OCTETS_CNT,

    HAL_STAT_HW_TYPE_TM_OQ_WRED_DROP_ECN_PKT_CNT_MEM0,
    HAL_STAT_HW_TYPE_TM_OQ_WRED_DROP_ECN_PKT_CNT_MEM1,
    HAL_STAT_HW_TYPE_TM_OQ_WRED_DROP_ECN_MISC_CNT_MEM0,
    HAL_STAT_HW_TYPE_TM_OQ_WRED_DROP_ECN_MISC_CNT_MEM1,

    HAL_STAT_HW_TYPE_TM_OQ_WRED_ECN_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_OQ_WRED_ECN_MISC_CNT,

    HAL_STAT_HW_TYPE_TM_PORT_TX_DROP_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_PORT_TX_DROP_OCTETS_CNT,

    HAL_STAT_HW_TYPE_TM_PORT_TX_ECN_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_PORT_TX_ECN_OCTETS_CNT,

    HAL_STAT_HW_TYPE_TM_OQ_TX_CNT,
    HAL_STAT_HW_TYPE_TM_CPU_PORT_OQ_TX_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_CPU_PORT_OQ_TX_OCTETS_CNT,

    HAL_STAT_HW_TYPE_TM_DBG_START,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_PDBWR2ASM_FD_I_CNT = HAL_STAT_HW_TYPE_TM_DBG_START,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_PDBWR2ASM_FD_I_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_PDBWR2ASM_PD_I_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_PDBWR2ASM_PD_I_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_ASM2REP_PD_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_ASM2REP_PD_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_ASM2PPL_DUAL_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_ASM2PPL_DUAL_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_ASM2FRG_DROP_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_ASM2FRG_DROP_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB0_CP_ASM_SILENT_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_SUB1_CP_ASM_SILENT_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_ASM_CP_ASM2REP_2COM_PD_O_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_DQC_STA_RETRANSMIT_DURATION_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_DELETE_PORT_PD_IN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_OQC_PORT_PD_IN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_SUB0_PPL_KEY_OUT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_SUB1_PPL_KEY_OUT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_SUB0_PPL_RESULT_IN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_FRG_SUB1_PPL_RESULT_IN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT0,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT1,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT2,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT3,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT4,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT5,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT6,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2FRG_WF_PD_CBT_CNT7,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT0,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT1,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT2,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT3,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT4,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT5,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT6,
    HAL_STAT_HW_TYPE_TM_DBG_PDM_STA_PDM2DQC_RD_RPT_CBT_CNT7,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_ALL_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_EOP_ERR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_ECC_ERR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_DT_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE0_RD_INVLD_PTR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_ALL_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_EOP_ERR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_ECC_ERR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_DT_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_PDB_QUAD_SLICE1_RD_INVLD_PTR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_DRP_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_UC_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_MC_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_CPU_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_MIR_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_INT_C_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_L1_INT_R_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_DRP_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_UC_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_REP_MC_PKT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_PORT2QP_CREDIT_CNT_0,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_PORT2QP_CREDIT_CNT_1,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_PORT2QP_CREDIT_CNT_2,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_PORT2QP_CREDIT_CNT_3,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_QP2UCMC_CREDIT_CNT_0,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_QP2UCMC_CREDIT_CNT_1,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_QP2UCMC_CREDIT_CNT_2,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_QP2UCMC_CREDIT_CNT_3,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_OQ2SLICE_CREDIT_CNT_0,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_OQ2SLICE_CREDIT_CNT_1,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_SLICE_CREDIT_CNT_0,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_SLICE_CREDIT_CNT_1,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP2PORT_CREDIT_RETURN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_CIR_TIME_CREDIT_ASSIGN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_CIR_TIME_TOKEN_EVENT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_CIR_TIME_MAX_TOKEN_EVENT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_PIR_TIME_CREDIT_ASSIGN_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_PIR_TIME_TOKEN_EVENT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_STA_QP_WFQ_SHAPER_PIR_TIME_MAX_TOKEN_EVENT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_FC_PORT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_FC_QP_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_SCH_FC_DQC2SCH_CREDIT_GRANT_CNT,
    HAL_STAT_HW_TYPE_TM_DBG_END,
    HAL_STAT_HW_TYPE_DOS_EVENT_CNT,
    HAL_STAT_HW_TYPE_LAST
} hal_stat_hw_type_t;

typedef enum {
    HAL_STAT_HW_DUP_TYPE_PLANE = 0,
    HAL_STAT_HW_DUP_TYPE_DIE,
    HAL_STAT_HW_DUP_TYPE_SERDES_MACRO,
    HAL_STAT_HW_DUP_TYPE_BIN,
    HAL_STAT_HW_DUP_TYPE_LAST
} hal_stat_hw_dup_type_t;

typedef enum {
    HAL_STAT_PP_BANK_TYPE_NOT_ASSIGNED = 0,
    HAL_STAT_PP_BANK_TYPE_IFP_SRV1,
    HAL_STAT_PP_BANK_TYPE_IFP_SRV2,
    HAL_STAT_PP_BANK_TYPE_IFP_SRV3, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_IFP_SRV4, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_IFP_SRV5, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_IFP_SRV6, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP0,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP1,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP2,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP3,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP4,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP5,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP6,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP7,
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP8,       /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP9,       /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP10,      /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_GROUP11,      /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP0,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP1,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP2,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP3,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP4,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP5,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP6,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP7,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP8,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP9,  /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP10, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ICIA_POST_GROUP11, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_FLOW,
    HAL_STAT_PP_BANK_TYPE_EFP_SRV1,
    HAL_STAT_PP_BANK_TYPE_EFP_SRV2,
    HAL_STAT_PP_BANK_TYPE_EFP_SRV3,
    HAL_STAT_PP_BANK_TYPE_EFP_SRV4, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ECIA_GROUP0,
    HAL_STAT_PP_BANK_TYPE_ECIA_GROUP1,
    HAL_STAT_PP_BANK_TYPE_ECIA_GROUP2,
    HAL_STAT_PP_BANK_TYPE_ECIA_GROUP3,
    HAL_STAT_PP_BANK_TYPE_ECIA_POST_GROUP0, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ECIA_POST_GROUP1, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ECIA_POST_GROUP2, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_ECIA_POST_GROUP3, /*  CL8600 only */
    HAL_STAT_PP_BANK_TYPE_LAST
} hal_stat_pp_bank_type_t;

typedef enum {
    HAL_STAT_PP_OBJ_IN_SRV_L2_INTF = 0, /*  Vlan-based service l2 */
    HAL_STAT_PP_OBJ_IN_SRV_L3_INTF,     /*  L3 interface */
    HAL_STAT_PP_OBJ_IN_SRV_FDID,        /*  Set properties of the bridge domain */
    HAL_STAT_PP_OBJ_IN_L2_LCL_INTF,     /*  L2 lcl interface */
    HAL_STAT_PP_OBJ_IN_PORT_INTF,       /*  Port interface, CL8600 only */
    HAL_STAT_PP_OBJ_VRF,                /*  Set VRF */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP0,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP1,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP2,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP3,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP4,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP5,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP6,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP7,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP8,    /*  CIA UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP9,    /*  CIA UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP10,   /*  CIA UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_UCP_GROUP11,   /*  CIA UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP0,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP1,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP2,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP3,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP4,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP5,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP6,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP7,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP8,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP9,   /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP10,  /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ICIA_POST_GROUP11,  /*  Ingress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_FLOW,               /*  Flow group */
    HAL_STAT_PP_OBJ_OUT_L3_INTF,        /*  Egress L3 interface */
    HAL_STAT_PP_OBJ_OUT_L2_LCL_INTF,    /*  Egerss L2 LCL interface */
    HAL_STAT_PP_OBJ_OUT_SRV_L2_INTF,    /*  MPLS */
    HAL_STAT_PP_OBJ_OUT_PORT_INTF,      /*  Port interface, CL8600 only */
    HAL_STAT_PP_OBJ_ECIA_UCP_GROUP0,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ECIA_UCP_GROUP1,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ECIA_UCP_GROUP2,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ECIA_UCP_GROUP3,    /*  CIA UCP group */
    HAL_STAT_PP_OBJ_ECIA_POST_GROUP0,   /*  Egress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ECIA_POST_GROUP1,   /*  Egress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ECIA_POST_GROUP2,   /*  Egress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_ECIA_POST_GROUP3,   /*  Egress CIA post UCP group, CL8600 only */
    HAL_STAT_PP_OBJ_TYPE_LAST
} hal_stat_pp_obj_type_t;

typedef enum {
    HAL_STAT_CAP_SRV_IDX_OFFSET_ID,
    HAL_STAT_CAP_SRV_NUM_PER_BANK_ID,
    HAL_STAT_CAP_SRV_BANK_NUM_ID,
    HAL_STAT_CAP_SRV_NUM_ID,
    HAL_STAT_CAP_SRV_BMP_SIZE_ID,
    HAL_STAT_CAP_DST_NUM_PER_BANK_ID,
    HAL_STAT_CAP_DST_BANK_NUM_ID,
    HAL_STAT_CAP_DST_NUM_ID,
    HAL_STAT_CAP_DST_BMP_SIZE_ID,
    HAL_STAT_CAP_PP_CNT_NUM_ID,
    HAL_STAT_CAP_PP_LAST
} hal_stat_cap_pp_type_t;

typedef enum {
    HAL_STAT_CAP_MAC_NUM_PER_DIE_ID,
    HAL_STAT_CAP_LANE_NUM_PER_MAC_ID,
    HAL_STAT_CAP_FP_LANE_NUM_ID,
    HAL_STAT_CAP_CPI_LANE_NUM_ID,
    HAL_STAT_CAP_MAC_LAST
} hal_stat_cap_mac_type_t;

typedef enum {
    HAL_STAT_CAP_TM_QUEUECNT_PLANE_OFFSET_ID,
    HAL_STAT_CAP_TM_QUEUECNT_CPU_OFFSET_ID,
    HAL_STAT_CAP_TM_QUEUECNT_CPI_OFFSET_ID,
    HAL_STAT_CAP_TM_LAST
} hal_stat_cap_tm_type_t;

typedef enum {
    /* mib, per lane basis */
    HAL_STAT_MIB_SW_IN_OCTETS = 0,
    HAL_STAT_MIB_SW_IN_PKTS_ALL,
    HAL_STAT_MIB_SW_IN_PKTS_GOOD,
    HAL_STAT_MIB_SW_IN_PKTS_UC,
    HAL_STAT_MIB_SW_IN_PKTS_NUC,
    HAL_STAT_MIB_SW_IN_PKTS_PAUSE,
    HAL_STAT_MIB_SW_IN_PKTS_PAUSE_PFC,
    HAL_STAT_MIB_SW_IN_PKTS_ERR,
    HAL_STAT_MIB_SW_IN_PKTS_ERR_FCS,
    HAL_STAT_MIB_SW_IN_PKTS_ERR_LONG,
    HAL_STAT_MIB_SW_IN_PKTS_64B,
    HAL_STAT_MIB_SW_IN_PKTS_4096B_9216B,
    HAL_STAT_MIB_SW_IN_PKTS_9217B_MAX,
    HAL_STAT_MIB_SW_OUT_OCTETS,
    HAL_STAT_MIB_SW_OUT_PKTS_ALL,
    HAL_STAT_MIB_SW_OUT_PKTS_GOOD,
    HAL_STAT_MIB_SW_OUT_PKTS_UC,
    HAL_STAT_MIB_SW_OUT_PKTS_NUC,
    HAL_STAT_MIB_SW_OUT_PKTS_PAUSE_PFC,
    HAL_STAT_MIB_SW_OUT_PKTS_ERR,
    HAL_STAT_MIB_SW_OUT_PKTS_64B,
    HAL_STAT_MIB_SW_OUT_PKTS_4096B_9216B,
    HAL_STAT_MIB_SW_OUT_PKTS_9217B_MAX,
    HAL_STAT_MIB_SW_OUT_PKTS_OVERSIZE,
    /* non-mib start, per port basis */
    HAL_STAT_MIB_SW_CLX_MIB_START,
    HAL_STAT_MIB_SW_L3_DISCARDS = HAL_STAT_MIB_SW_CLX_MIB_START,
    HAL_STAT_MIB_SW_INGRESS_L3_DISCARDS,
    HAL_STAT_MIB_SW_EGRESS_L3_DISCARDS,
    HAL_STAT_MIB_SW_L3_BLACKHOLE_DISCARDS,
    HAL_STAT_MIB_SW_INGRESS_PARITY_DISCARDS,
    HAL_STAT_MIB_SW_EGRESS_NON_QUEUE_DISCARDS,
    HAL_STAT_MIB_SW_EGRESS_INVALID_VLAN_DISCARDS,
    HAL_STAT_MIB_SW_INGRESS_L2_MTU_DISCARDS,
    HAL_STAT_MIB_SW_BUFFER_DISCARDS,
    HAL_STAT_MIB_SW_INGRESS_NON_QUEUE_DISCARDS,
    HAL_STAT_MIB_SW_IN_PKTS_DROP,
    HAL_STAT_MIB_SW_OUT_PKTS_DROP,
    HAL_STAT_MIB_SW_PKTS_DROP,
    HAL_STAT_MIB_SW_IN_MAC_ERR,
    /* in/out port */
    HAL_STAT_MIB_SW_IN_START,
    HAL_STAT_MIB_SW_IN_DROP_NON_IP_PKTS = HAL_STAT_MIB_SW_IN_START,
    HAL_STAT_MIB_SW_IN_DROP_NON_IP_OCTETS,
    HAL_STAT_MIB_SW_IN_DROP_IPV4_PKTS,
    HAL_STAT_MIB_SW_IN_DROP_IPV4_OCTETS,
    HAL_STAT_MIB_SW_IN_DROP_IPV6_PKTS,
    HAL_STAT_MIB_SW_IN_DROP_IPV6_OCTETS,
    HAL_STAT_MIB_SW_IN_GOOD_PKTS,
    HAL_STAT_MIB_SW_IN_GOOD_OCTETS,
    HAL_STAT_MIB_SW_IN_GOOD_IPV4_PKTS,
    HAL_STAT_MIB_SW_IN_GOOD_IPV4_OCTETS,
    HAL_STAT_MIB_SW_IN_GOOD_IPV6_PKTS,
    HAL_STAT_MIB_SW_IN_GOOD_IPV6_OCTETS,
    HAL_STAT_MIB_SW_OUT_START,
    HAL_STAT_MIB_SW_OUT_DROP_NON_IP_PKTS = HAL_STAT_MIB_SW_OUT_START,
    HAL_STAT_MIB_SW_OUT_DROP_NON_IP_OCTETS,
    HAL_STAT_MIB_SW_OUT_DROP_IPV4_PKTS,
    HAL_STAT_MIB_SW_OUT_DROP_IPV4_OCTETS,
    HAL_STAT_MIB_SW_OUT_DROP_IPV6_PKTS,
    HAL_STAT_MIB_SW_OUT_DROP_IPV6_OCTETS,
    HAL_STAT_MIB_SW_OUT_GOOD_PKTS,
    HAL_STAT_MIB_SW_OUT_GOOD_OCTETS,
    HAL_STAT_MIB_SW_OUT_GOOD_IPV4_PKTS,
    HAL_STAT_MIB_SW_OUT_GOOD_IPV4_OCTETS,
    HAL_STAT_MIB_SW_OUT_GOOD_IPV6_PKTS,
    HAL_STAT_MIB_SW_OUT_GOOD_IPV6_OCTETS,
    HAL_STAT_MIB_SW_TYPE_LAST
} hal_stat_mib_sw_type_t;

typedef enum {
    HAL_STAT_RFC_CNT_SRC_SRAM = 0,
    HAL_STAT_RFC_CNT_SRC_REG,
    HAL_STAT_RFC_CNT_SRC_SW_L, /* lane based */
    HAL_STAT_RFC_CNT_SRC_SW_P, /* port based */
    HAL_STAT_RFC_CNT_SRC_TYPE_LAST,
} hal_stat_rfc_cnt_src_type_t;

typedef enum {
    HAL_STAT_RFC_CNT_BUF_OLD = 0,
    HAL_STAT_RFC_CNT_BUF_NEW,
    HAL_STAT_RFC_CNT_BUF_SHOW,
    HAL_STAT_RFC_CNT_BUF_TYPE_LAST
} hal_stat_rfc_cnt_buf_type_t;

typedef enum {
    HAL_STAT_RFC_CNT_SEL_BOTH = 0,
    HAL_STAT_RFC_CNT_SEL_LSB,
    HAL_STAT_RFC_CNT_SEL_MSB
} hal_stat_rfc_cnt_sel_type_t;

typedef clx_error_no_t (*hal_stat_update_func_t)(const uint32 unit,
                                                 const uint32 idx,
                                                 const boolean clear);

typedef struct hal_stat_hw_cb_s {
    hal_stat_hw_type_t hw_cnt_type;
    uint32 table_id;
    uint32 replica_cnt1;
    uint32 replica_cnt2;
    uint32 entry_size;
    uint32 entry_cnt;
    uint32 sw_aggr_factor;
    uint32 sw_hc_size;
    uint32 sub_task_cnt;
    hal_stat_update_func_t update_func;
    hal_stat_hw_dup_type_t dup_type;
} hal_stat_hw_cb_t;

typedef struct hal_stat_rfc_cnt_calc_s {
    hal_stat_rfc_cnt_src_type_t src;
    uint32 type;
    hal_stat_rfc_cnt_sel_type_t sel;
    uint32 mask;
} hal_stat_rfc_cnt_calc_t;

/* DMA task structure */
typedef struct hal_stat_task_s {
    uint32 inst_idx;    /* instance index.           */
    uint32 subinst_idx; /* sub instance index.       */
    uint32 table_id;    /* table ID.                 */
    uint32 entry_idx;   /* entry index in table.     */
    uint32 addr;        /* device address            */
    void *ptr_buf;      /* ptr to host address       */
    uint32 entry_len;   /* length of an entry (byte) */
    uint32 entry_num;   /* number of entries         */
} hal_stat_task_t;

typedef struct hal_stat_buf_s {
    void *ptr_dma_not_align;
    void *ptr_dma_buf; /* aligned 16 based address of ptr_dma_not_align */
    void *ptr_old_buf;
    uint64 *ptr_results;
    uint32 task_cnt;
    uint32 *ptr_tasks_id;
    hal_stat_task_t *ptr_tasks;
#define HAL_STAT_FLAGS_OLD_BUF_VALID     (1U << 0)
#define HAL_STAT_FLAGS_ADD_DMA_TASK_DONE (1U << 1)
    uint32 flags;
    clx_semaphore_id_t sema;
} hal_stat_buf_t;

typedef struct hal_stat_srv_cnt_s {
    uint32 usage_bmap[(HAL_STAT_MAX_SRV_CNT_NUM_PER_BANK - 1) / 32 + 1];
    uint32 sw_cnt_id[HAL_STAT_MAX_SRV_CNT_NUM_PER_BANK];
    hal_stat_pp_bank_type_t bank_type;
} hal_stat_srv_cnt_t;

typedef struct hal_stat_dst_cnt_s {
    uint32 usage_bmap[(HAL_STAT_MAX_DST_CNT_NUM_PER_BANK - 1) / 32 + 1];
    uint32 sw_cnt_id[HAL_STAT_MAX_DST_CNT_NUM_PER_BANK];
    hal_stat_pp_bank_type_t bank_type;
} hal_stat_dst_cnt_t;

typedef struct hal_stat_sw_cnt_s {
    uint32 usage_bmap[(HAL_STAT_MAX_PP_CNT_NUM - 1) / 32 + 1];
    uint32 hw_cnt_id[HAL_STAT_MAX_PP_CNT_NUM];
    clx_stat_srv_cnt_cfg_t cfg[HAL_STAT_MAX_PP_CNT_NUM];
    uint32 ref_cnt[HAL_STAT_MAX_PP_CNT_NUM];
    uint32 srv_reset_bmap[2][HAL_STAT_MAX_SRV_CNT_BMP_SIZE];
    uint32 dst_reset_bmap[2][HAL_STAT_MAX_DST_CNT_BMP_SIZE];
    uint32 srv_cnt_left;
    uint32 dst_cnt_left;
} hal_stat_sw_cnt_t;

#define HAL_STAT_SW_CNT_MIB_NUM (HAL_STAT_MIB_SW_CLX_MIB_START)
#define HAL_STAT_SW_CNT_CLX_NUM (HAL_STAT_MIB_SW_TYPE_LAST - HAL_STAT_MIB_SW_CLX_MIB_START)
#define HAL_STAT_SW_CNT_EXCPT_NUM \
    (CLX_STAT_PORT_EGRESS_INVALID_VLAN_DISCARDS - CLX_STAT_PORT_L3_DISCARDS + 1)
#define HAL_STAT_SW_CNT_IN_PORT_NUM  (HAL_STAT_MIB_SW_OUT_START - HAL_STAT_MIB_SW_IN_START)
#define HAL_STAT_SW_CNT_OUT_PORT_NUM (HAL_STAT_MIB_SW_TYPE_LAST - HAL_STAT_MIB_SW_OUT_START)

typedef struct hal_stat_api_cnt_cb_s {
    uint64 mib_sw[HAL_STAT_MAX_SERDES_LANE][HAL_STAT_SW_CNT_MIB_NUM];
    uint64 clx_mib_sw[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][HAL_STAT_SW_CNT_CLX_NUM];
    uint64 excpt_sw[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][HAL_STAT_SW_CNT_EXCPT_NUM]
                   [HAL_STAT_RFC_CNT_BUF_TYPE_LAST];
    uint64 rfc_cnt[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][CLX_STAT_PORT_LAST]
                  [HAL_STAT_RFC_CNT_BUF_TYPE_LAST];
    uint64 pp_rsn_cnt[CLX_PKT_HW_RSN_LAST][HAL_STAT_RFC_CNT_BUF_TYPE_LAST];
    uint64 clx_pkt_rsn_cnt[CLX_PKT_RX_REASON_LAST][HAL_STAT_RFC_CNT_BUF_TYPE_LAST];
    uint32 update_bmap[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][(CLX_STAT_PORT_LAST - 1) / 32 + 1];
    clx_semaphore_id_t sema;
} hal_stat_api_cnt_cb_t;

typedef struct hal_stat_tm_cnt_cfg_s {
    uint32 port;
    uint32 cpu_queue;
} hal_stat_tm_cnt_cfg_t;

typedef struct hal_stat_rate_cb_s {
    uint64 last_value[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][CLX_STAT_RATE_TYPE_LAST];
    uint64 port[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][CLX_STAT_RATE_TYPE_LAST];
    uint64 last_port_rate[HAL_STAT_MAX_SW_TOTAL_PORT_NUM][CLX_STAT_RATE_TYPE_LAST];
    clx_time_t last_update;
} hal_stat_rate_cb_t;

typedef enum {
    HAL_STAT_REFRESH_FREE = 0,
    HAL_STAT_REFRESH_WAITING,
    HAL_STAT_REFRESH_DOING,
} hal_stat_refresh_type_t;

typedef struct hal_stat_cb_s {
    clx_semaphore_id_t sema_rsrc;
    clx_semaphore_id_t sema_task;
    clx_thread_id_t update_thread_id;
    hal_stat_buf_t stat_buf[HAL_STAT_HW_TYPE_LAST];
    hal_stat_sw_cnt_t sw_cnt_info;
    hal_stat_srv_cnt_t srv_banks[HAL_STAT_MAX_SRV_CNT_BANK_NUM];
    hal_stat_dst_cnt_t dst_banks[HAL_STAT_MAX_DST_CNT_BANK_NUM];
    hal_stat_api_cnt_cb_t api_cnt;
    hal_stat_tm_cnt_cfg_t tm_cfg;
    hal_stat_rate_cb_t stat_rate;
    uint64 update_cnt;
    uint64 timestamp;
    clx_semaphore_id_t sema_dma;
    uint32 per_task_intvl;
#define HAL_STAT_FLAGS_POLLING (1U << 0)
    uint32 flags;
} hal_stat_cb_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Get Stat Control block of corresponding unit.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     ptr_hw_cb      - Pointer to HW control block info.
 * @param [in]     hw_cb_num      - Number of entries in HW control block.
 * @param [in]     ptr_formula    - Pointer to RFC API counter calculation formula.
 * @param [out]    pptr_cb        - Pointer to SW control block.
 * @return         CLX_E_OK        - Init success.
 * @return         CLX_E_OTHERS    - Init fail.
 */
clx_error_no_t
hal_stat_cb_init(const uint32 unit,
                 hal_stat_hw_cb_t *ptr_hw_cb,
                 uint32 hw_cb_num,
                 hal_stat_rfc_cnt_calc_t *ptr_formula,
                 hal_stat_cb_t **pptr_cb);

/**
 * @brief This API is used to clear all port based counters and port TM type counters when a port
 *        is initially created.
 *
 * This API clear counters.
 * (1) port based counters
 * (2) port tm type counters
 * This API not clear counters, user should manually clear them if need.
 * (1) SRV/DST PP counters
 * (2) debug counters
 * (3) exception counters.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Operate fail.
 */
clx_error_no_t
hal_stat_port_default_set(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to clear all port based counters and port TM type counters when a port
 *        is reset.
 *
 * This API clear counters.
 * (1) port based counters
 * (2) port tm type counters
 * This API not clear counters, user should manually clear them if need.
 * (1) SRV/DST PP counters
 * (2) debug counters
 * (3) exception counters.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Operate fail.
 */
clx_error_no_t
hal_stat_port_default_reset(const uint32 unit, const uint32 port);

/**
 * @brief This API is used to get port counter by physical port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port.
 * @param [in]     type       - The type of counter.
 * @param [out]    ptr_cnt    - Pointer to counter.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_port_cnt_get(const uint32 unit,
                      const uint32 port,
                      const clx_stat_port_t type,
                      uint64 *ptr_cnt);

/**
 * @brief This API is used to clear port counter by physical port.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @param [in]    type    - The type of counter.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_port_cnt_clear(const uint32 unit, const uint32 port, const clx_stat_port_t type);

/**
 * @brief This API is used to get TM queue counter index by TM handler.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     handler    - The handler of TM queue.
 * @param [out]    ptr_idx    - Queue counter index.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_queue_cnt_idx_get(const uint32 unit, const clx_tm_handler_t handler, uint32 *ptr_idx);

/**
 * @brief This API is used to get TM counter by TM queue.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     handler    - The handler of TM queue.
 * @param [out]    ptr_cnt    - Queue counter.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_queue_cnt_get(const uint32 unit,
                       const clx_tm_handler_t handler,
                       clx_stat_tm_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear TM counter by TM queue.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    handler    - The handler of TM queue.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - Allocate memory failed.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_stat_queue_cnt_clear(const uint32 unit, const clx_tm_handler_t handler);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Port ID.
 * @param [in]     handler    - The handler of TM queue.
 * @param [in]     type       - The TM counter type.
 * @param [out]    ptr_cnt    - Counter value.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_stat_tm_cnt_get(const uint32 unit,
                    const uint32 port,
                    const clx_tm_handler_t handler,
                    const clx_stat_tm_t type,
                    clx_stat_tm_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port ID.
 * @param [in]    handler    - The handler of TM queue.
 * @param [in]    type       - The TM counter type.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_stat_tm_cnt_clear(const uint32 unit,
                      const uint32 port,
                      const clx_tm_handler_t handler,
                      const clx_stat_tm_t type);

/**
 * @brief This API is used to create a distribution counter for ingress interface (L2,
 *        L3, tunnel), egress interface (L2, L3, tunnel), domain (VLAN,
 *        FD, VRF) and flow (ingress ACL and egress ACL).
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_cnt_id    - Counter logic ID.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - There is no counter to serve.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_stat_dist_cnt_create(const uint32 unit, uint32 *ptr_cnt_id);

/**
 * @brief This API is used to destroy a distribution counter.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter logic ID.
 * @return        CLX_E_OK                 - Success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return        CLX_E_OTHERS             - Operation failed.
 */
clx_error_no_t
hal_stat_dist_cnt_destroy(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to get a distribution counter.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     cnt_id     - Counter ID.
 * @param [out]    ptr_cnt    - Counter.
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Operation failed.
 */
clx_error_no_t
hal_stat_dist_cnt_get(const uint32 unit, const uint32 cnt_id, clx_stat_dist_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear a distribution counter.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter ID.
 * @return        CLX_E_OK                 - Success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return        CLX_E_OTHERS             - Operation failed.
 */
clx_error_no_t
hal_stat_dist_cnt_clear(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to create a counter for interface (ingress, egress) or domain (forward
 *        domain, VRF).
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_cfg       - The type of counter.
 * @param [out]    ptr_cnt_id    - Counter ID.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - There is no counter available.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_stat_cnt_create(const uint32 unit, const clx_stat_srv_cnt_cfg_t *ptr_cfg, uint32 *ptr_cnt_id);

/**
 * @brief This API is used to destroy a counter create via hal_stat_cnt_create.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter ID.
 * @return        CLX_E_OK                 - Success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
hal_stat_cnt_destroy(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to the config of the counter under study.
 *
 * The number of counters value return is determined by the type of counter under study.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     cnt_id     - Counter ID.
 * @param [out]    ptr_cfg    - The type of counter.
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
hal_stat_cnt_cfg_get(const uint32 unit, const uint32 cnt_id, clx_stat_srv_cnt_cfg_t *ptr_cfg);

/**
 * @brief This API is used to get port traffic rate by physical port.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port.
 * @param [in]     type        - The type of traffic rate.
 * @param [out]    ptr_rate    - Pointer to rate.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_port_rate_get(const uint32 unit,
                       const uint32 port,
                       const clx_stat_rate_type_t type,
                       uint64 *ptr_rate);

/**
 * @brief This API is used to get port rate type from port cnt type.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     type         - The type of port cnt.
 * @param [out]    rate_type    - The type of traffic rate.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_port_rate_type_get(const uint32 unit,
                            const clx_stat_port_t type,
                            clx_stat_rate_type_t *rate_type);

/**
 * @brief This API is used to get PP counter HW index using SW index.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     sw_cnt_id         - SW counter id.
 * @param [in]     cnt_type          - Counter type.
 * @param [in]     pp_obj_type       - PP binding object type.
 * @param [in]     old_hw_cnt_idx    - Old hw cnt index, old_hw_cnt_idx is not free when it's
 *                                     HAL_STAT_INVALID_HW_CNT_IDX.
 * @param [out]    ptr_hw_cnt_idx    - HW counter idx.
 * @return         CLX_E_OK                 - Success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_TABLE_FULL         - No available HW resource.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The SW counter has not been created.
 */
clx_error_no_t
hal_stat_cnt_hw_idx_get(const uint32 unit,
                        const uint32 sw_cnt_id,
                        const hal_stat_hw_type_t cnt_type,
                        const hal_stat_pp_obj_type_t pp_obj_type,
                        const uint32 old_hw_cnt_idx,
                        uint32 *ptr_hw_cnt_idx);

/**
 * @brief This API is used to get PP counter SW ID using HW index.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     hw_cnt_idx       - HW counter idx in HW table.
 * @param [in]     cnt_type         - Counter type.
 * @param [out]    ptr_sw_cnt_id    - HW counter id.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_cnt_sw_id_get(const uint32 unit,
                       const uint32 hw_cnt_idx,
                       const hal_stat_hw_type_t cnt_type,
                       uint32 *ptr_sw_cnt_id);

/**
 * @brief This API is used to get how many times the counter has been updated.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cnt    - Update count.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_update_cnt_get(const uint32 unit, uint64 *ptr_cnt);

/**
 * @brief This API is used to get PP storm control counter by index.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     plane      - Plane number.
 * @param [in]     cnt_idx    - The strom control counter index.
 * @param [out]    ptr_cnt    - Pointer to corresponding counter entry (3 values).
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_storm_cnt_get(const uint32 unit,
                       const uint32 plane,
                       const uint32 cnt_idx,
                       hal_sec_sccounter_entry_t *ptr_cnt);

/**
 * @brief This API is used to clear PP storm control counter by index.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    plane      - Plane number.
 * @param [in]    cnt_idx    - The strom control counter index.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_storm_cnt_clear(const uint32 unit, const uint32 plane, const uint32 cnt_idx);

/**
 * @brief This API is used to find the actual entry of _ptr_hal_stat_hw_types from type.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     type            - The type user wants to get.
 * @param [out]    pptr_hw_type    - The actual HAL_STAT_HW_CB which type is equal to type.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_stat_hw_type_lookup(const uint32 unit,
                        const hal_stat_hw_type_t type,
                        hal_stat_hw_cb_t **pptr_hw_type);

/**
 * @brief To get a free index from a bitmap array.
 *
 * @param [in]     ptr_bitmap    - Pointer to the UI32 bitmap array.
 * @param [in]     size          - Size of the bitmap array.
 * @param [in]     count         - Number of (countinuous, aligned) index to allocate.
 * @param [out]    ptr_idx       - The index allocated.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 * @return         CLX_E_TABLE_FULL       - No available index.
 */
clx_error_no_t
hal_stat_free_idx_get(const uint32 *ptr_bitmap,
                      const uint32 size,
                      const uint32 count,
                      uint32 *ptr_idx);

/**
 * @brief To free index from a bitmap array.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    cnt_type      - Counter type.
 * @param [in]    hw_cnt_idx    - HW counter idx in HW table.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameters.
 */
clx_error_no_t
hal_stat_cnt_hw_idx_free(const uint32 unit,
                         const hal_stat_hw_type_t cnt_type,
                         const uint32 hw_cnt_idx);

/**
 * @brief To get a PP HW counter bank Id and corresponding index Id.
 *
 * @param [in]     unit                       - Device unit number.
 * @param [in]     hw_cnt_id                  - HW counter Id.
 * @param [in]     mode                       - Counter mode.
 * @param [out]    ptr_bank_id                - The HW bank Id of the corresponding counter.
 * @param [out]    ptr_sw_bmap_idx_of_bank    - The index the corresponding counter in the bank.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid parameters.
 */
clx_error_no_t
hal_stat_pp_bank_id_get(const uint32 unit,
                        const uint32 hw_cnt_id,
                        const clx_stat_srv_cnt_mode_t mode,
                        uint32 *ptr_bank_id,
                        uint32 *ptr_sw_bmap_idx_of_bank);

/**
 * @brief This API is used to get the regular counter base index.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    mode    - Mode number.
 * @return        The index.
 */
uint32
hal_stat_srv_cnt_base_get(const uint32 unit, const uint32 mode);

/**
 * @brief This API is used to get the width of entry in regular counter.
 *
 * @param [in]    mode    - Mode number.
 * @return        Width number.
 */
uint32
hal_stat_srv_cnt_mode_get(const uint32 mode);

/**
 * @brief This API is used to get DoS check counter.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cnt    - Pointer to corresponding counter entry.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_stat_dos_cnt_get(const uint32 unit, clx_sec_dos_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear DoS check counter.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_stat_dos_cnt_clear(const uint32 unit);
#endif /* End of HAL_STAT_H */
