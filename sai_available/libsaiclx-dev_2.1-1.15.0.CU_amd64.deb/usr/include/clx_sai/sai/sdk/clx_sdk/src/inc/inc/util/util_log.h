/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_log.h
 * PURPOSE:
 *      It provides LOG module internal API
 *
 * NOTES:
 *
 */

#ifndef UTIL_LOG_H
#define UTIL_LOG_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_module.h>
#include <tob/tob.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define UTIL_LOG_PRINT_BUF_SIZE (512)
#define UTIL_LOG_ENTRY_MAX_NUM  (4 * 1024)
#define UTIL_LOG_SUBMODULE_LAST (16)

/* DATA TYPE DECLARATIONS
 */
typedef struct util_log_entry_e {
    osal_tm_t timestamp;
    clx_module_t module;
    uint32 dbg_level;
    char log[UTIL_LOG_PRINT_BUF_SIZE];
} util_log_entry_t;

/* debug level */
typedef enum util_log_e {
    UTIL_LOG_OFF = 0,
    UTIL_LOG_ERR = (0x1UL << 0),
    UTIL_LOG_WARN = (0x1UL << 1),
    UTIL_LOG_INFO = (0x1UL << 2),
    UTIL_LOG_LAST = (0x1UL << 3)
} util_log_t;

/* define LOG submodule start */

/* general LOG submodule */
typedef enum util_log_general_e {
    UTIL_LOG_GENERAL_ALL = -1, /* all submodule */
    UTIL_LOG_GENERAL_CMN,      /* the first submodule is usually a common module */
    UTIL_LOG_GENERAL_LAST
} util_log_general_t;

/* OSAL LOG submodule */
typedef enum util_log_osal_e { UTIL_LOG_OSAL, UTIL_LOG_OSAL_LAST } util_log_osal_t;

/* INIT LOG submodule */
typedef enum util_log_init_e { UTIL_LOG_INIT, UTIL_LOG_INIT_LAST } util_log_init_t;

/* UTIL LOG submodule */
typedef enum util_log_util_e {
    UTIL_LOG_UTIL,
    UTIL_LOG_UTIL_LIB,
    UTIL_LOG_UTIL_LAST
} util_log_util_t;

/* HAL */
typedef enum util_log_hal_e {
    UTIL_LOG_HAL,
    UTIL_LOG_HAL_TOB,
    UTIL_LOG_HAL_MII,
    UTIL_LOG_HAL_IO,
    UTIL_LOG_HAL_LAST
} util_log_hal_t;

/* CHIP */
typedef enum util_log_chip_e {
    UTIL_LOG_CHIP,
    UTIL_LOG_CHIP_ECC,
    UTIL_LOG_CHIP_EFUSE,
    UTIL_LOG_CHIP_CPU2JTAG,
    UTIL_LOG_CHIP_LAST
} util_log_chip_t;

/* PORT */
typedef enum util_log_port_e {
    UTIL_LOG_PORT,
    UTIL_LOG_PORT_INIT,
    UTIL_LOG_PORT_MAC,
    UTIL_LOG_PORT_PM,
    UTIL_LOG_PORT_LINK,
    UTIL_LOG_PORT_PL,
    UTIL_LOG_PORT_LED,
    UTIL_LOG_PORT_LAST
} util_log_port_t;

/* L2 LOG submodule */
typedef enum util_log_l2_e {
    UTIL_LOG_L2,
    UTIL_LOG_L2_POLL,
    UTIL_LOG_L2_ICM,
    UTIL_LOG_L2_TASK,
    UTIL_LOG_L2_LAST
} util_log_l2_t;

/* BD LOG submodule */
typedef enum util_log_bd_e { UTIL_LOG_BD, UTIL_LOG_BD_INIT, UTIL_LOG_BD_LAST } util_log_bd_t;

/* VLAN LOG submodule */
typedef enum util_log_vlan_e {
    UTIL_LOG_VLAN,
    UTIL_LOG_VLAN_INIT,
    UTIL_LOG_VLAN_SRV,
    UTIL_LOG_VLAN_VID_CTL,
    UTIL_LOG_VLAN_LAST
} util_log_vlan_t;

/* STP LOG submodule */
typedef enum util_log_stp_e {
    UTIL_LOG_STP,
    UTIL_LOG_STP_DIL,
    UTIL_LOG_STP_LAG_SEL,
    UTIL_LOG_STP_LAST
} util_log_stp_t;

/* LAG LOG submodule */
typedef enum util_log_lag_e { UTIL_LOG_LAG, UTIL_LOG_LAG_LAST } util_log_lag_t;

/* STK LOG submodule */
typedef enum util_log_stk_e {
    UTIL_LOG_STK,
    UTIL_LOG_STK_DIL,
    UTIL_LOG_STK_LAG_SEL,
    UTIL_LOG_STK_LAST
} util_log_stk_t;

/* METER LOG submodule */
typedef enum util_log_meter_e { UTIL_LOG_METER, UTIL_DBG_METER_LAST } util_log_meter_t;

/* STAT */
typedef enum util_log_stat_e {
    UTIL_LOG_STAT,
    UTIL_LOG_STAT_DMA,
    UTIL_LOG_STAT_PP,
    UTIL_LOG_STAT_TM,
    UTIL_LOG_STAT_MAC,
    UTIL_LOG_STAT_THREAD,
    UTIL_LOG_STAT_LAST
} util_log_stat_t;

/* IFMON LOG submodule */
typedef enum util_log_ifmon_e {
    UTIL_LOG_IFMON,
    UTIL_LOG_IFMON_INIT,
    UTIL_LOG_IFMON_TIME,
    UTIL_LOG_IFMON_VERB,
    UTIL_LOG_IFMON_STM,
    UTIL_LOG_IFMON_ANLT,
    UTIL_LOG_IFMON_ANLT_FSM,
    UTIL_LOG_IFMON_LAST
} util_log_ifmon_t;

/* ECPU LOG submodule */
typedef enum util_log_ecpu_e {
    UTIL_LOG_ECPU,
    UTIL_LOG_ECPU_ELINK,
    UTIL_LOG_ECPU_PTP,
    UTIL_LOG_ECPU_BFD,
    UTIL_LOG_ECPU_EPARSER,
    UTIL_LOG_ECPU_LAST
} util_log_ecpu_t;

/* TOD LOG submodule */
typedef enum util_log_tod_e { UTIL_LOG_TOD, UTIL_LOG_TOD_LAST } util_log_tod_t;

/* MIRROR LOG submodule */
typedef enum util_log_mir_e { UTIL_LOG_MIR, UTIL_LOG_MIR_LAST } util_log_mir_t;

/* MPLS LOG submodule */
typedef enum util_log_mpls_e { UTIL_LOG_MPLS, UTIL_LOG_MPLS_LAST } util_log_mpls_t;

/* QOS LOG submodule */
typedef enum util_log_qos_e { UTIL_LOG_QOS, UTIL_LOG_QOS_LAST } util_log_qos_t;

/* PHY LOG submodule */
typedef enum util_log_phy_e { UTIL_LOG_PHY, UTIL_LOG_PHY_LAST } util_log_phy_t;

/* SEC LOG submodule */
typedef enum util_log_sec_e { UTIL_LOG_SEC, UTIL_LOG_SEC_LAST } util_log_sec_t;

/* SFLOW LOG submodule */
typedef enum util_log_sflow_e { UTIL_LOG_SFLOW, UTIL_LOG_SFLOW_LAST } util_log_sflow_t;

/* DRV LOG submodule */
typedef enum util_log_drv_e {
    UTIL_LOG_DRV,
    UTIL_LOG_DRV_IO,
    UTIL_LOG_DRV_DMA,
    UTIL_LOG_DRV_LAST
} util_log_drv_t;

/* TELM LOG submodule */
typedef enum util_log_telm_e {
    UTIL_LOG_TELM,
    UTIL_LOG_TELM_INT,
    UTIL_LOG_TELM_IOAM,
    UTIL_LOG_TELM_IFA,
    UTIL_LOG_TELM_MOD,
    UTIL_LOG_TELM_LAST
} util_log_telm_t;

/* INTR LOG submodule */
typedef enum util_log_intr_e { UTIL_LOG_INTR, UTIL_LOG_INTR_LAST } util_log_intr_t;

/* CIA LOG submodule */
typedef enum util_log_cia_e {
    UTIL_LOG_CIA,
    UTIL_LOG_CIA_CFG,
    UTIL_LOG_CIA_WAR,
    UTIL_LOG_CIA_DEBUG,
    UTIL_LOG_CIA_CMP_RDT,
    UTIL_LOG_CIA_CMP_KEY,
    UTIL_LOG_CIA_LAST
} util_log_cia_t;

/* SRV6 LOG submodule */
typedef enum util_log_srv6_e { UTIL_LOG_SRV6, UTIL_LOG_SRV6_LAST } util_log_srv6_t;

/* L3 LOG submodule */
typedef enum util_log_l3_e {
    UTIL_LOG_L3,
    UTIL_LOG_L3_INTF,
    UTIL_LOG_L3_HOST,
    UTIL_LOG_L3_ROUTE,
    UTIL_LOG_L3_ADJ,
    UTIL_LOG_L3_ECMP,
    UTIL_LOG_L3_MCAST,
    UTIL_LOG_L3_VRF,
    UTIL_LOG_L3_LAST
} util_log_l3_t;

/* TNL LOG submodule */
typedef enum util_log_tnl_e { UTIL_LOG_TNL, UTIL_LOG_TNL_NVO3, UTIL_LOG_L3T_LAST } util_log_tnl_t;

/* PKT LOG submodule */
typedef enum util_log_pkt_e {
    UTIL_LOG_PKT,
    UTIL_LOG_PKT_REG,
    UTIL_LOG_PKT_INIT,
    UTIL_LOG_PKT_TX,
    UTIL_LOG_PKT_RX,
    UTIL_LOG_PKT_ISR,
    UTIL_LOG_PKT_LAST
} util_log_pkt_t;

/* DIAG LOG submodule */
typedef enum util_log_diag_e {
    UTIL_LOG_DIAG,
    UTIL_LOG_DIAG_LOOPBACK,
    UTIL_LOG_DIAG_LAST
} util_log_diag_t;

/* SWC LOG submodule */
typedef enum util_log_swc_e {
    UTIL_LOG_SWC,
    UTIL_LOG_SWC_HASH,
    UTIL_LOG_SWC_PRTY,
    UTIL_LOG_SWC_PKJ,
    UTIL_LOG_SWC_LAST
} util_log_swc_t;

/* TM LOG submodule */
typedef enum util_log_tm_e {
    UTIL_LOG_TM,
    UTIL_LOG_TM_SCH,
    UTIL_LOG_TM_BUF,
    UTIL_LOG_TM_MISC,
    UTIL_LOG_TM_PFCWD,
    UTIL_LOG_TM_REP,
    UTIL_LOG_TM_PFC,
    UTIL_LOG_TM_LAST
} util_log_tm_t;

/* define LOG submodule end */

#ifdef CLX_EN_DEBUG

#ifdef CLX_EN_COMPILER_SUPPORT_FUNCTION
#define UTIL_LOG_INFO_INIT(__module_id__, __file_name__) \
    static clx_module_t __CLX_MODULE__ = (__module_id__)

#define UTIL_LOG_PRINT(submodule, __flag__, ...)                                              \
    do {                                                                                      \
        if (CLX_E_OK == util_log_level_chk(__CLX_MODULE__, submodule, __flag__)) {            \
            if (0 != ((UTIL_LOG_ERR) & (__flag__))) {                                         \
                util_log_internal_log_print(__CLX_MODULE__, __flag__, __func__, __LINE__,     \
                                            ##__VA_ARGS__);                                   \
            }                                                                                 \
            if (0 != (__flag__)) {                                                            \
                util_log_print(__CLX_MODULE__, __func__, __LINE__, ##__VA_ARGS__);            \
                if (0 == ((UTIL_LOG_ERR) & (__flag__))) {                                     \
                    util_log_internal_log_print(__CLX_MODULE__, __flag__, __func__, __LINE__, \
                                                ##__VA_ARGS__);                               \
                }                                                                             \
            }                                                                                 \
        }                                                                                     \
    } while (0)

#else /* !CLX_EN_COMPILER_SUPPORT_FUNCTION */
#define UTIL_LOG_INFO_INIT(__module_id__, __file_name__)  \
    static clx_module_t __CLX_MODULE__ = (__module_id__); \
    static char *__CLX_FILE__ = (__file_name__)

#define UTIL_LOG_PRINT(submodule, __flag__, ...)                                                  \
    do {                                                                                          \
        if (CLX_E_OK == util_log_level_chk(__CLX_MODULE__, submodule, __flag__)) {                \
            if (0 != ((UTIL_LOG_ERR) & (__flag__))) {                                             \
                util_log_internal_log_print(__CLX_MODULE__, __flag__, __CLX_FILE__, __LINE__,     \
                                            ##__VA_ARGS__);                                       \
            }                                                                                     \
            if (0 != (__flag__)) {                                                                \
                util_log_print(__CLX_MODULE__, __CLX_FILE__, __LINE__, ##__VA_ARGS__);            \
                if (0 == ((UTIL_LOG_ERR) & (__flag__))) {                                         \
                    util_log_internal_log_print(__CLX_MODULE__, __flag__, __CLX_FILE__, __LINE__, \
                                                ##__VA_ARGS__);                                   \
                }                                                                                 \
            }                                                                                     \
        }                                                                                         \
    } while (0)

#endif /* #ifdef CLX_EN_COMPILER_SUPPORT_FUNCTION */

#define UTIL_LOG_RAW_PRINT(submodule, __flag__, ...)                               \
    do {                                                                           \
        if (CLX_E_OK == util_log_level_chk(__CLX_MODULE__, submodule, __flag__)) { \
            if (0 != (__flag__)) {                                                 \
                util_log_raw_print(__CLX_MODULE__, ##__VA_ARGS__);                 \
            }                                                                      \
        }                                                                          \
    } while (0)

#define UTIL_LOG_HEX_BUF_PRINT(submodule, __flag__, __ptr_buf__, __buf_size__)     \
    do {                                                                           \
        if (CLX_E_OK == util_log_level_chk(__CLX_MODULE__, submodule, __flag__)) { \
            if (0 != (__flag__)) {                                                 \
                util_log_hex_buf_print(__CLX_MODULE__, __ptr_buf__, __buf_size__); \
            }                                                                      \
        }                                                                          \
    } while (0)

#define UTIL_LOG_HEX_TBL_PRINT(submodule, __flag__, __ptr_buf__, __buf_word_size__)        \
    do {                                                                                   \
        if (CLX_E_OK == util_log_level_chk(__CLX_MODULE__, submodule, __flag__)) {         \
            if (0 != (__flag__)) {                                                         \
                util_log_wide_field_print(__CLX_MODULE__, __buf_word_size__, __ptr_buf__); \
            }                                                                              \
        }                                                                                  \
    } while (0)

#define UTIL_LOG_TBL_TRACK_EN
#ifdef UTIL_LOG_TBL_TRACK_EN

#define UTIL_LOG_MULTI_FEILDS_INFO_PRINT(submodule, __flag__, __unit__, __tbl_id__, __inst__,  \
                                         __subinst__, __entry__, __list__, __count__, __buf__) \
    do {                                                                                       \
        if (CLX_E_OK == util_log_level_chk(__CLX_MODULE__, submodule, __flag__)) {             \
            if (0 != (__flag__)) {                                                             \
                util_log_print(__CLX_MODULE__, __func__, __LINE__,                             \
                               "[C] %s inst=%u sub-inst=%u entry=%u:\n",                       \
                               TOB_TABLE(__unit__, __tbl_id__)->ptr_table_name, __inst__,      \
                               __subinst__, __entry__);                                        \
                util_log_multi_fields_print(__CLX_MODULE__, __unit__, __tbl_id__, __list__,    \
                                            __count__);                                        \
                util_log_tbl_info_print(__CLX_MODULE__, __unit__, __tbl_id__, __buf__);        \
            }                                                                                  \
        }                                                                                      \
    } while (0)

#define UTIL_LOG_SINGLE_FEILD_INFO_PRINT(submodule, __flag__, __unit__, __tbl_id__, __inst__, \
                                         __subinst__, __entry__, __value__, __fid__, __buf__) \
    do {                                                                                      \
        if (CLX_E_OK == util_log_level_chk(__CLX_MODULE__, submodule, __flag__)) {            \
            if (0 != (__flag__)) {                                                            \
                util_log_print(__CLX_MODULE__, __func__, __LINE__,                            \
                               "[C] %s inst=%u sub-inst=%u entry=%u:\n",                      \
                               TOB_TABLE(__unit__, __tbl_id__)->ptr_table_name, __inst__,     \
                               __subinst__, __entry__);                                       \
                util_log_single_field_print(__CLX_MODULE__, __unit__, __tbl_id__, __value__,  \
                                            __fid__);                                         \
                util_log_tbl_info_print(__CLX_MODULE__, __unit__, __tbl_id__, __buf__);       \
            }                                                                                 \
        }                                                                                     \
    } while (0)

#define UTIL_LOG_TBL_INFO_PRINT(submodule, __flag__, __unit__, __tbl_id__, __inst__, __subinst__, \
                                __entry__, __buf__)                                               \
    do {                                                                                          \
        if (CLX_E_OK == util_log_level_chk(__CLX_MODULE__, submodule, __flag__)) {                \
            if (0 != (__flag__)) {                                                                \
                util_log_print(__CLX_MODULE__, __func__, __LINE__,                                \
                               "[C] %s inst=%u sub-inst=%u entry=%u:\n",                          \
                               TOB_TABLE(__unit__, __tbl_id__)->ptr_table_name, __inst__,         \
                               __subinst__, __entry__);                                           \
                util_log_tbl_info_print(__CLX_MODULE__, __unit__, __tbl_id__, __buf__);           \
            }                                                                                     \
        }                                                                                         \
    } while (0)

#else /* !UTIL_LOG_TBL_TRACK_EN */
#define UTIL_LOG_MULTI_FEILDS_INFO_PRINT(...)
#define UTIL_LOG_SINGLE_FEILD_INFO_PRINT(...)
#define UTIL_LOG_TBL_INFO_PRINT(...)
#endif

#else /* !CLX_EN_DEBUG */
#define UTIL_LOG_INFO_INIT(__module_id__, __file_name__)
#define UTIL_LOG_PRINT(submodule, __flag__, ...)
#define UTIL_LOG_HEX_BUF_PRINT(submodule, __flag__, __ptr_buf__, __buf_size__)
#define UTIL_LOG_HEX_TBL_PRINT(submodule, __flag__, __ptr_buf__, __buf_word_size__)
#define UTIL_LOG_RAW_PRINT(...)
#define UTIL_LOG_MULTI_FEILDS_INFO_PRINT(...)
#define UTIL_LOG_SINGLE_FEILD_INFO_PRINT(...)
#define UTIL_LOG_TBL_INFO_PRINT(...)

#endif /* #ifdef CLX_EN_DEBUG */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This function initialize the LOG module.
 *
 * @return        CLX_E_OK           - Operate success.
 * @return        CLX_E_NO_MEMORY    - Bad parameter.
 * @return        CLX_E_OTHERS       - Operate failed.
 */
clx_error_no_t
util_log_init(void);

/**
 * @brief This function de-initialize the LOG module.
 *
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_log_deinit(void);

/**
 * @brief This function is used to enable/disable module's debug message recording.
 *
 * @param [in]    task_id      - Task id.
 * @param [in]    module_id    - Selected module item.
 * @param [in]    submodule    - Submodule id.
 * @param [in]    dbg_flag     - Debug level.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
util_log_dbg_flag_set(const osal_task_id_t task_id,
                      const clx_module_t module_id,
                      const uint32 submodule,
                      const uint32 dbg_flag);

/**
 * @brief This function is used to get current debug message recording status.
 *
 * @param [in]     task_id         - Task id.
 * @param [in]     module_id       - Selected module item.
 * @param [in]     submodule       - Submodule id.
 * @param [out]    ptr_dbg_flag    - Pointer to get the debug flag status.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
util_log_dbg_flag_get(const osal_task_id_t task_id,
                      const clx_module_t module_id,
                      const uint32 submodule,
                      uint32 *ptr_dbg_flag);

/**
 * @brief Check if log level matches.
 *
 * @param [in]    submodule    - Selected submodule item.
 * @param [in]    module       - Selected module item.
 * @param [in]    dbg_level    - Current dbg level.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_log_level_chk(const clx_module_t module, const uint32 submodule, const uint32 dbg_level);

void
util_log_raw_print(const clx_module_t module, const char *ptr_fmt, ...);

void
util_log_wide_field_print(const clx_module_t module,
                          const uint32 data_size_in_word,
                          const uint32 *value_list);

void
util_log_tbl_info_print(const clx_module_t module,
                        const uint32 unit,
                        const uint32 table_id,
                        const uint32 *ptr_buf);

void
util_log_single_field_print(const clx_module_t module,
                            const uint32 unit,
                            const uint32 table_id,
                            const uint32 *value_list,
                            const uint32 field_id);

void
util_log_multi_fields_print(const clx_module_t module,
                            const uint32 unit,
                            const uint32 table_id,
                            const tob_fvp_t *value_list,
                            const uint32 field_count);

/**
 * @brief This function is used to output debug message to console or/and save to LOG buffer.
 *
 * @param [in]    module      - Selected module item.
 * @param [in]    ptr_func    - Function or file name string.
 * @param [in]    line        - Line number.
 * @param [in]    ptr_fmt     - Input string pointer.
 */
void
util_log_print(const clx_module_t module,
               const char *ptr_func,
               const uint32 line,
               const char *ptr_fmt,
               ...);

/**
 * @brief This function is used to output debug message into internal log.
 *
 * @param [in]    module       - Selected module item.
 * @param [in]    dbg_level    - Debug level.
 * @param [in]    ptr_func     - Function or file name string.
 * @param [in]    line         - Line number.
 * @param [in]    ptr_fmt      - Input string pointer.
 */
void
util_log_internal_log_print(const clx_module_t module,
                            const uint32 dbg_level,
                            const char *ptr_func,
                            const uint32 line,
                            const char *ptr_fmt,
                            ...);

/**
 * @brief This function is used to get internal log buffer.
 *
 * @param [out]    ptr_entry_index    - The curent index of internal log.
 * @param [out]    ptr_entry_count    - The entry count of internal log.
 * @param [out]    ptr_entry          - The snapshot of all internal logs.
 */
void
util_log_internal_log_get(uint32 *ptr_entry_index,
                          uint32 *ptr_entry_count,
                          util_log_entry_t *ptr_entry);

/**
 * @brief This function is used to clear all internal log.
 *
 */
void
util_log_internal_log_clear(void);

/**
 * @brief This function is used to enable internal log mode to wrap mode or not.
 *
 * @param [in]    wrap_mode_enable    - Enable wrap mode or not.
 */
void
util_log_internal_log_wrap_mode_set(const boolean wrap_mode_enable);

/**
 * @brief This function is used to get internal log if wrap mode or not.
 *
 * @param [out]    ptr_mode    - Pointer of wrap mode.
 */
void
util_log_internal_log_wrap_mode_get(boolean *ptr_mode);

/**
 * @brief Print buf in hex style.
 *
 * @param [in]    module      - Selected module item.
 * @param [in]    ptr_buf     - Data buf.
 * @param [in]    buf_size    - Print size.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
void
util_log_hex_buf_print(const clx_module_t module, const uint8 *ptr_buf, const uint32 buf_size);

#endif
