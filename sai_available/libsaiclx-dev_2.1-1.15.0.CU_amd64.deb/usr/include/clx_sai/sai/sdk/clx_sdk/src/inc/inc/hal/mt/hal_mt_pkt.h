/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_pkt.h
 * PURPOSE:
 *    Define the declaration for pkt module.
 *
 * NOTES:
 *    None
 */

#ifndef HAL_MT_PKT_H
#define HAL_MT_PKT_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_pkt.h>
#include <hal/hal_pkt_rsrc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* define c2c key field bits */
#define HAL_MT_PKT_IPV4_KEY_HEADER_LEN_BITS (4)
#define HAL_MT_PKT_KEY_BDID_BITS            (14)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* Control-to-CPU Action Types */
typedef enum hal_pkt_ctrl_to_cpu_action_type_e {
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_NONE = 0,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_REDIR,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_CP2CPU,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_DROP,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_LAST
} hal_pkt_ctrl_to_cpu_action_type_t;

/* Control-to-CPU Decap Types */
typedef enum hal_pkt_ctrl_to_cpu_decap_type_e {
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_NONE = 0,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_TRILL,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_MPLS,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_GRE,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_VXLAN_GPE,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_VXLAN_BAS,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_RAW,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_FLEX,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_LAST
} hal_pkt_ctrl_to_cpu_decap_type_t;

/* Control-to-CPU Types */
typedef enum hal_pkt_ctrl_to_cpu_type_e {
    HAL_PKT_CTRL_TO_CPU_TYPE_L2 = 0,
    HAL_PKT_CTRL_TO_CPU_TYPE_IPV4,
    HAL_PKT_CTRL_TO_CPU_TYPE_IPV6,
    HAL_PKT_CTRL_TO_CPU_TYPE_ARP,
    HAL_PKT_CTRL_TO_CPU_TYPE_LAST
} hal_pkt_ctrl_to_cpu_type_t;

/* Key Value, L2 */
typedef struct hal_pkt_ctrl_to_cpu_key_l2_s {
    uint32 vld;
    hal_pkt_ctrl_to_cpu_decap_type_t decap_type;
    uint32 is_router_mac;
    uint32 is_router_mac_msk;
    uint32 is_len;
    uint32 is_len_msk;
    uint32 l2_hdr_complete;
    uint32 l2_hdr_complete_msk;
    uint32 type_len;
    uint32 type_len_msk;
    uint32 l2_da[2];
    uint32 l2_da_msk[2];
    uint32 pld[3];
    uint32 pld_msk[3];
    uint32 pld_1[2];
    uint32 pld_1_msk[2];
    uint32 bd;
    uint32 bd_msk;
} hal_pkt_ctrl_to_cpu_key_l2_t;

/* Key Value, IPV4 */
typedef struct hal_pkt_ctrl_to_cpu_key_ipv4_s {
    uint32 vld;
    hal_pkt_ctrl_to_cpu_decap_type_t decap_type;
    uint32 is_router_mac;
    uint32 is_router_mac_msk;
    uint32 l3_ip_rte_en;
    uint32 l3_ip_rte_en_msk;
    uint32 l3_da_rng_bmap;
    uint32 l3_da_rng_bmap_msk;
    uint32 l3_hdr_complete;
    uint32 l3_ip_proto;
    uint32 l3_ip_proto_msk;
    uint32 l2_hdr_present;
    uint32 l2_hdr_present_msk;
    uint32 l3_ipv4_ihl;
    uint32 l3_ipv4_ihl_msk;
    uint32 l3_ipv4_ihl_ne_5;
    uint32 l3_ipv4_ihl_ne_5_msk;
    uint32 l3_ipv4_frag;
    uint32 l3_ipv4_frag_msk;
    uint32 pld[3];
    uint32 pld_msk[3];
    uint32 l3_da;
    uint32 l3_da_msk;
    uint32 pld_1[2];
    uint32 pld_1_msk[2];
    uint32 bd;
    uint32 bd_msk;
} hal_pkt_ctrl_to_cpu_key_ipv4_t;

/* Key Value, IPv6 */
typedef struct hal_pkt_ctrl_to_cpu_key_ipv6_s {
    uint32 vld;
    hal_pkt_ctrl_to_cpu_decap_type_t decap_type;
    uint32 is_router_mac;
    uint32 is_router_mac_msk;
    uint32 l3_ip_rte_en;
    uint32 l3_ip_rte_en_msk;
    uint32 l3_da_rng_bmap;
    uint32 l3_da_rng_bmap_msk;
    uint32 l3_hdr_complete;
    uint32 l3_ip_proto;
    uint32 l3_ip_proto_msk;
    uint32 l2_hdr_present;
    uint32 l2_hdr_present_msk;
    uint32 l3_da[4];
    uint32 l3_da_msk[4];
    uint32 pld[2];
    uint32 pld_msk[2];
    uint32 bd;
    uint32 bd_msk;
    uint32 opt_exist;
    uint32 opt_exist_msk;
} hal_pkt_ctrl_to_cpu_key_ipv6_t;

/* Key Value, ARP */
typedef struct hal_pkt_ctrl_to_cpu_key_arp_s {
    uint32 vld;
    hal_pkt_ctrl_to_cpu_decap_type_t decap_type;
    uint32 is_router_mac;
    uint32 is_router_mac_msk;
    uint32 type_len;
    uint32 type_len_msk;
    uint32 l2_da[2];
    uint32 l2_da_msk[2];
    uint32 req;
    uint32 req_msk;
    uint32 res;
    uint32 res_msk;
    uint32 l2_da_is_bc;
    uint32 l2_da_is_bc_msk;
    uint32 l2_da_eq_tha;
    uint32 l2_da_eq_tha_msk;
    uint32 l2_sa_eq_sha;
    uint32 l2_sa_eq_sha_msk;
    uint32 bd;
    uint32 bd_msk;
    uint32 l2_sa[2];
    uint32 l2_sa_msk[2];
    uint32 sender_ip;
    uint32 sender_ip_msk;
    uint32 target_ip;
    uint32 target_ip_msk;
} hal_pkt_ctrl_to_cpu_key_arp_t;

/* Key Value */
typedef union hal_pkt_ctrl_to_cpu_key_u {
    hal_pkt_ctrl_to_cpu_key_l2_t l2;
    hal_pkt_ctrl_to_cpu_key_ipv4_t ipv4;
    hal_pkt_ctrl_to_cpu_key_ipv6_t ipv6;
    hal_pkt_ctrl_to_cpu_key_arp_t arp;
} hal_pkt_ctrl_to_cpu_key_t;

/* Entry of Control-to-CPU Table */
typedef struct {
    /* Key */
    hal_pkt_ctrl_to_cpu_type_t type;
    hal_pkt_ctrl_to_cpu_key_t key;

    /* Action */
    hal_pkt_ctrl_to_cpu_action_type_t action;
    uint32 supp_ep2ul;
    uint32 supp_ul2ul;
    uint32 supp_bpdu_blk;
    uint32 supp_sa_learn;
} hal_pkt_ctrl_to_cpu_entry_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief To set a specify ctrl2cpu entry.
 *
 * Must get the entry first, and then modify the fields want to set.
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     index        - The entry index in HW table which user want to set
 * @param [in]     ptr_entry    - The value of the entry user want to set.
 * @return         CLX_E_OK        - Success to set the ctrl2cpu entry.
 * @return         CLX_E_OTHERS    - Fail to set the ctrl2cpu entry.
 */
clx_error_no_t
hal_mt_pkt_ctrl_to_cpu_entry_set(const uint32 unit,
                                 const uint32 index,
                                 const clx_pkt_ctrl_to_cpu_entry_t *ptr_entry);

/**
 * @brief To get the content of the target entry of ctrl2cpu table
 *
 * @param [in]     unit         - Device unit number
 * @param [in]     index        - The target index
 * @param [out]    ptr_entry    - Pointer to the entry content
 * @return         CLX_E_OK        - Success to get the entry content.
 * @return         CLX_E_OTHERS    - Get the entry content failed.
 */
clx_error_no_t
hal_mt_pkt_ctrl_to_cpu_entry_get(const uint32 unit,
                                 const uint32 index,
                                 clx_pkt_ctrl_to_cpu_entry_t *ptr_entry);

/**
 * @brief To clear all ctrl-to-CPU entries configured.
 *
 * @param [in]     unit    - Device unit number
 * @return         CLX_E_OK        - Operation is successful.
 * @return         CLX_E_OTHERS    - Fail
 */
clx_error_no_t
hal_mt_pkt_ctrl_to_cpu_entry_all_clear(const uint32 unit);

#endif /* End of HAL_MT_PKT_H */
