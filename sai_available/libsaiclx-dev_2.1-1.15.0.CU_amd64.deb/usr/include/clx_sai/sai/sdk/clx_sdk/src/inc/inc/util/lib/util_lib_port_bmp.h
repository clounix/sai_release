/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_port_bmp.h
 * PURPOSE:
 *  this file is used to provide port bitmap API.
 * NOTES:
 *
 */
#ifndef UTIL_LIB_PORT_BMP_H
#define UTIL_LIB_PORT_BMP_H
/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_port.h>
#include <clx/clx_types.h>
#include <util/util.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* MACRO FUNCTION DECLARATIONS
 */
#define UTIL_LIB_PORT_BMP_OP(bitmap_a, bitmap_b, bitwise_operator) \
    do {                                                           \
        ((bitmap_a)[0]) bitwise_operator((bitmap_b)[0]);           \
        ((bitmap_a)[1]) bitwise_operator((bitmap_b)[1]);           \
        ((bitmap_a)[2]) bitwise_operator((bitmap_b)[2]);           \
        ((bitmap_a)[3]) bitwise_operator((bitmap_b)[3]);           \
        ((bitmap_a)[4]) bitwise_operator((bitmap_b)[4]);           \
        ((bitmap_a)[5]) bitwise_operator((bitmap_b)[5]);           \
        ((bitmap_a)[6]) bitwise_operator((bitmap_b)[6]);           \
        ((bitmap_a)[7]) bitwise_operator((bitmap_b)[7]);           \
        ((bitmap_a)[8]) bitwise_operator((bitmap_b)[8]);           \
    } while (0)

#define UTIL_LIB_PORT_BMP_SET(bitmap_a, bitmap_b) UTIL_LIB_PORT_BMP_OP(bitmap_a, bitmap_b, =)
#define UTIL_LIB_PORT_BMP_ADD(bitmap_a, bitmap_b) UTIL_LIB_PORT_BMP_OP(bitmap_a, bitmap_b, |=)
#define UTIL_LIB_PORT_BMP_DEL(bitmap_a, bitmap_b) UTIL_LIB_PORT_BMP_OP(bitmap_a, bitmap_b, &= ~)
#define UTIL_LIB_PORT_BMP_AND(bitmap_a, bitmap_b) UTIL_LIB_PORT_BMP_OP(bitmap_a, bitmap_b, &=)
#define UTIL_LIB_PORT_BMP_OR(bitmap_a, bitmap_b)  UTIL_LIB_PORT_BMP_OP(bitmap_a, bitmap_b, |=)
#define UTIL_LIB_PORT_BMP_XOR(bitmap_a, bitmap_b) UTIL_LIB_PORT_BMP_OP(bitmap_a, bitmap_b, ^=)
#define UTIL_LIB_PORT_BMP_INV(bitmap_a, bitmap_b) UTIL_LIB_PORT_BMP_OP(bitmap_a, bitmap_b, = ~)
#define UTIL_LIB_PORT_BMP_COUNT(bitmap, count)                                                     \
    do {                                                                                           \
        count = util_popcount((bitmap)[0]) + util_popcount((bitmap)[1]) +                          \
            util_popcount((bitmap)[2]) + util_popcount((bitmap)[3]) + util_popcount((bitmap)[4]) + \
            util_popcount((bitmap)[5]) + util_popcount((bitmap)[6]) + util_popcount((bitmap)[7]) + \
            util_popcount((bitmap)[8]);                                                            \
    } while (0)

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

#endif /* End of UTIL_LIB_PORT_BMP_H */
