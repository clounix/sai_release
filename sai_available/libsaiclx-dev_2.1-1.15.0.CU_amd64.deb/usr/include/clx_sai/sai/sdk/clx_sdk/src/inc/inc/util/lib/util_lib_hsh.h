/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_hsh.h
 * PURPOSE:
 * NOTES:
 *
 *
 *
 */
#ifndef UTIL_LIB_HSH_H
#define UTIL_LIB_HSH_H
/* INCLUDE FILE DECLARATIONS
 */
#include <util/lib/util_lib.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef uint32 util_lib_hsh_t;

/* FUNCTION TYPE NAME: util_lib_hsh_func_t
 * PURPOSE:
 *      it is used to get hash value from a key.
 * INPUT:
 *      ptr_key  -- the key used to get hash value.
 *      key_size -- the length of key, in bytes.
 * OUTPUT:
 *      ptr_hash  -- the hash value of the key.
 * RETURN:
 *      CLX_E_OK            -- get hash value success.
 *      CLX_E_BAD_PARAMETER -- null pointer.
 * NOTES:
 *
 */
typedef clx_error_no_t (*util_lib_hsh_func_t)(void *ptr_key,
                                              const uint32 key_size,
                                              util_lib_hsh_t *ptr_hash);

/* FUNCTION TYPE NAME: util_lib_hsh_cmp_func_t
 * PURPOSE:
 *      it is used to compare key with user data, if the key matches the
 *  user data.
 * INPUT:
 *      ptr_key       -- the key used to compare.
 *      key_size      -- the length of key, in bytes.
 *      ptr_user_data -- the user data pointer.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK            -- the key matches the user data.
 *      CLX_E_BAD_PARAMETER -- null pointer.
 *      CLX_E_OTHERS        -- the key does not belong to the user data.
 * NOTES:
 *
 */
typedef clx_error_no_t (*util_lib_hsh_cmp_func_t)(void *ptr_key,
                                                  const uint32 key_size,
                                                  void *ptr_user_data);

/* FUNCTION TYPE NAME: util_lib_hsh_destroy_func_t
 * PURPOSE:
 *      it is used to process entry data when destroy a hash table.
 * INPUT:
 *      ptr_entry_data  -- user data saved in the hash entry.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK            -- process ok.
 *      CLX_E_BAD_PARAMETER -- null pointer.
 * NOTES:
 *
 */
typedef clx_error_no_t (*util_lib_hsh_destroy_func_t)(void *ptr_entry_data);

/* FUNCTION TYPE NAME: util_lib_hsh_delete_func_t
 * PURPOSE:
 *      it is used to process the deleted data entry.
 * INPUT:
 *      ptr_cookie     -- the cookie data from delete function, it can be NULL.
 *      ptr_entry_data -- the entry data will be deleted.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK            -- process ok.
 *      CLX_E_BAD_PARAMETER -- null pointer.
 * NOTES:
 *
 */
typedef clx_error_no_t (*util_lib_hsh_delete_func_t)(void *ptr_cookie, void *ptr_entry_data);

/* FUNCTION TYPE NAME: util_lib_hsh_trav_func_t
 * PURPOSE:
 *      it is used to process entry data when traverse a hash table.
 * INPUT:
 *      ptr_cookie     -- the cookie data.
 *      ptr_entry_data -- the user data saved in the entry.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK            -- process ok.
 *      CLX_E_BAD_PARAMETER -- null pointer.
 *      CLX_E_OTHERS        -- traverse error.
 * NOTES:
 *
 */
typedef clx_error_no_t (*util_lib_hsh_trav_func_t)(void *ptr_cookie, void *ptr_entry_data);

typedef struct util_lib_hsh_tbl_entry_s {
    struct util_lib_hsh_tbl_entry_s *ptr_next; /* point to next entry */
    void *ptr_data;                            /* point to user data  */
} util_lib_hsh_tbl_entry_t;

typedef struct util_lib_hsh_tbl_bucket_s {
    util_lib_hsh_tbl_entry_t *ptr_entry; /* point to the entry list */
} util_lib_hsh_tbl_bucket_t;

typedef struct util_lib_hsh_tbl_s {
    uint32 max_entry_count;                 /* max count of entry      */
    uint32 bucket_count;                    /* the bucket array size   */
    uint32 entry_count;                     /* the count of entry in the
                                             * hash table.
                                             */
    uint32 key_size;                        /* hash key length: bytes  */
    util_lib_hsh_func_t hash_callback;      /* hash callback           */
    util_lib_hsh_cmp_func_t cmp_callback;   /* compare callback        */
    util_lib_hsh_tbl_bucket_t *ptr_buckets; /* point to bucket array   */

    void *ptr_entry_pool;                   /* it is used to manage table
                                             * entrys.
                                             */
} util_lib_hsh_tbl_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief It is used to create a hash table control block, set the bucket array size as
 *        bucket_count, allocate max_entry_count entries. then return the control block to user.
 *
 * @param [in]     max_entry_count    - Max entry count in hash table.
 * @param [in]     bucket_count       - The count of bucket in the hash table,
 *                                      it must be more than 0.
 * @param [in]     key_size           - The hash key length, in bytes, it will be put in hash
 *                                      callback and compare callback function.
 * @param [in]     hash_callback      - Hash function provided by user.
 * @param [in]     cmp_callback       - Compare key with user data, provided by user.
 * @param [in]     ptr_tbl_name       - The hash table name, max length is UTIL_LIB_NAME_LEN_MAX
 *                                      (include '\0').
 * @param [out]    pptr_hash_tbl      - The new hash table control block.
 * @return         CLX_E_OK               - Create ok.
 * @return         CLX_E_BAD_PARAMETER    - Null pointer or count is 0.
 * @return         CLX_E_NO_MEMORY        - Allocate hash table or buckets failed.
 */
clx_error_no_t
util_lib_hsh_create(const uint32 max_entry_count,
                    const uint32 bucket_count,
                    const uint32 key_size,
                    const util_lib_hsh_func_t hash_callback,
                    const util_lib_hsh_cmp_func_t cmp_callback,
                    const char *ptr_tbl_name,
                    util_lib_hsh_tbl_t **pptr_hash_tbl);

/**
 * @brief It is used to insert user data into the hash table. if the hash table is full before the
 *        insertion, it return CLX_E_TABLE_FULL. if the insert user data exists in the hash table,
 *        if "is_overwrite" is true, the existed data will be overwritten and the overwritten data
 *        will be returned by the last parameter. if "is_overwrite" is false,
 *        it will return CLX_E_ENTRY_EXISTS.
 *
 * If "is_overwrite" is true, when return CLX_E_OK, please check the
 * "pptr_overwritten_data" if is NULL, when it is not NULL pointer, it means
 * there is an overwritten data returned to user.
 *
 * @param [in]     ptr_hash_tbl             - The hash table control block.
 * @param [in]     ptr_key                  - The key of the user data.
 * @param [in]     ptr_user_data            - The user data pointer.
 * @param [in]     is_overwrite             - If overwrite the existing data TRUE: overwrite the
 *                                            existing data and return the overwritten data by the
 *                                            last parameter. FALSE: do not overwrite the existing
 *                                            data, return CLX_E_ENTRY_EXISTS.
 * @param [out]    pptr_overwritten_data    - If the entry exists, then replace the entry data with
 *                                            the new data, this is used to return old entry data
 *                                            to user. it could be NULL when is_overwrite is false.
 * @return         CLX_E_OK               - Insert ok.
 * @return         CLX_E_BAD_PARAMETER    - Null pointer.
 * @return         CLX_E_ENTRY_EXISTS     - Entry exists and the is_overwrite is FALSE.
 * @return         CLX_E_OTHERS           - Hash function return error.
 * @return         CLX_E_TABLE_FULL       - Allocate entry failed, all entrys are allocated.
 */
clx_error_no_t
util_lib_hsh_insert(util_lib_hsh_tbl_t *ptr_hash_tbl,
                    void *ptr_key,
                    void *ptr_user_data,
                    const boolean is_overwrite,
                    void **pptr_overwritten_data);

/**
 * @brief It is used to delete an entry from a hash table by a key. if the entry does not exist,
 *        it return CLX_E_ENTRY_NOT_FOUND.
 *
 * @param [in]     ptr_hash_tbl         - The hash table control block.
 * @param [in]     ptr_key              - The key used to find the entry which will be deleted.
 * @param [out]    pptr_deleted_data    - If the entry exists, return the entry data to user.
 * @return         CLX_E_OK                 - Delete ok.
 * @return         CLX_E_BAD_PARAMETER      - Null pointer.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The entry does not exist.
 * @return         CLX_E_OTHERS             - Get bucket index failed.
 */
clx_error_no_t
util_lib_hsh_delete(util_lib_hsh_tbl_t *ptr_hash_tbl, void *ptr_key, void **pptr_deleted_data);

/**
 * @brief It is used to delete all table entries in the hash table.
 *
 * @param [in]    ptr_hash_tbl    - The hash table control block.
 * @param [in]    ptr_cookie      - Cookie data used in del_callback, it can be NULL.
 * @param [in]    del_callback    - It is used to process the deleted data entries.
 * @return        CLX_E_OK        - Delete ok.
 * @return        CLX_E_OTHERS    - Delete callback return error.
 */
clx_error_no_t
util_lib_hsh_all_delete(util_lib_hsh_tbl_t *ptr_hash_tbl,
                        void *ptr_cookie,
                        const util_lib_hsh_delete_func_t del_callback);

/**
 * @brief It is used to lookup an entry data by a key. if the entry does not exist,
 *        it return CLX_E_ENTRY_NOT_FOUND.
 *
 * @param [in]     ptr_hash_tbl       - The hash table control block.
 * @param [in]     ptr_key            - The key used to find the entry.
 * @param [out]    pptr_found_data    - The found entry data.
 * @return         CLX_E_OK                 - Delete ok.
 * @return         CLX_E_BAD_PARAMETER      - Null pointer.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The entry does not exist.
 * @return         CLX_E_OTHERS             - Get bucket index failed.
 */
clx_error_no_t
util_lib_hsh_lookup(util_lib_hsh_tbl_t *ptr_hash_tbl, void *ptr_key, void **pptr_found_data);

/**
 * @brief It is used to traverse all entry data of a hash table and call trav_callback function to
 *        access the entry data.
 *
 * The traverse order is from the first bucket to the last. in one bucket,
 * it is from the first entry to the last entry.
 *
 * @param [in]    ptr_hash_tbl     - The hash table control block.
 * @param [in]    ptr_cookie       - It is used in traverse callback function.
 * @param [in]    trav_callback    - Traverse callback function.
 * @return        CLX_E_OK               - Traverse ok.
 * @return        CLX_E_BAD_PARAMETER    - Null pointer.
 * @return        CLX_E_OTHERS           - Traverse callback return error.
 */
clx_error_no_t
util_lib_hsh_trav(util_lib_hsh_tbl_t *ptr_hash_tbl,
                  void *ptr_cookie,
                  util_lib_hsh_trav_func_t trav_callback);

/**
 * @brief It is used to get the count of entry in the hash table.
 *
 * @param [in]     ptr_hash_tbl    - The hash table control block.
 * @param [out]    ptr_count       - It is used to output the count.
 * @return         CLX_E_OK               - Get count ok.
 * @return         CLX_E_BAD_PARAMETER    - Null pointer.
 */
clx_error_no_t
util_lib_hsh_count_get(util_lib_hsh_tbl_t *ptr_hash_tbl, uint32 *ptr_count);

/**
 * @brief It is used to destroy a hash table. if user provides a destroy callback the destroy
 *        callback will access every entry data in the hash table.
 *
 * Destroy callback is used to release entry data. it could be null, when
 * user do not process entry data.
 *
 * @param [in]    ptr_hash_tbl        - The hash table control block.
 * @param [in]    destroy_callback    - It is used to process every entry data by user purpose.
 *                                      it could be NULL.
 * @return        CLX_E_OK               - Destroy ok.
 * @return        CLX_E_BAD_PARAMETER    - Null pointer.
 * @return        CLX_E_OTHERS           - Destroy callback return error.
 */
clx_error_no_t
util_lib_hsh_destroy(util_lib_hsh_tbl_t *ptr_hash_tbl,
                     util_lib_hsh_destroy_func_t destroy_callback);

#endif /* End of UTIL_LIB_HSH_H */
