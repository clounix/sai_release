/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_diag.h
 * PURPOSE:
 *      It provides DIAG (Diagnosis) module internal API
 *
 * NOTES:
 *
 */

#ifndef UTIL_DIAG_H
#define UTIL_DIAG_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <tob/tob.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

#define UTIL_DIAG_BYTES_OF_WORD (4)
#define UTIL_DIAG_MAX_ENTRY_LEN (MAX_ENTRY_SIZE)
#define UTIL_DIAG_MAX_FIELD_LEN (MAX_FIELD_SIZE)
#define UTIL_DIAG_MAX_FIELD_NUM (MAX_FIELD_NUM)

/* DATA TYPE DECLARATIONS
 */
/* DIAG Table CLI Input Type selection */
typedef enum util_diag_input_type_e {
    UTIL_DIAG_INPUT_TYPE_NAME = 0,
    UTIL_DIAG_INPUT_TYPE_ID,
    UTIL_DIAG_INPUT_TYPE_RAW,
    UTIL_DIAG_INPUT_TYPE_LAST
} util_diag_input_type_t;

/* DIAG Show cmd format option */
typedef enum util_diag_show_cmd_field_opt_e {
    UTIL_DIAG_SHOW_CMD_FIELD_OPT_NORMAL = 0,
    UTIL_DIAG_SHOW_CMD_FIELD_OPT_FILTER0,
    UTIL_DIAG_SHOW_CMD_FIELD_OPT_RAW,
    UTIL_DIAG_SHOW_CMD_FIELD_OPT_LAST
} util_diag_show_cmd_field_opt_t;

typedef enum util_diag_show_cmd_entry_opt_e {
    UTIL_DIAG_SHOW_CMD_ENTRY_OPT_NORMAL = 0,
    UTIL_DIAG_SHOW_CMD_ENTRY_OPT_FILTER0,
    UTIL_DIAG_SHOW_CMD_ENTRY_OPT_LAST
} util_diag_show_cmd_entry_opt_t;

typedef struct util_diag_field_e {
    uint32 field_id;
    uint32 data[UTIL_DIAG_MAX_FIELD_LEN];
    uint32 mask[UTIL_DIAG_MAX_FIELD_LEN];
    uint32 data_size;
    uint32 mask_size;
    boolean zero;
} util_diag_field_t;

typedef struct util_diag_fields_meta_s {
    uint32 valid_field_num;
    util_diag_field_t field_info[UTIL_DIAG_MAX_FIELD_NUM];
    uint32 raw_data[UTIL_DIAG_MAX_ENTRY_LEN];
    uint32 raw_mask[UTIL_DIAG_MAX_ENTRY_LEN];
    boolean valid_entry;
    boolean allZero;
} util_diag_fields_meta_t;

typedef enum util_diag_set_mode_e {
    UTIL_DIAG_SET_MODE_SET_ONLY = 0,
    UTIL_DIAG_SET_MODE_VERIFY_ONLY,
    UTIL_DIAG_SET_MODE_SET_AND_VERIFY,
    UTIL_DIAG_SET_MODE_LAST
} util_diag_set_mode_t;

/**
 * @brief Show table/reg by field data according to the util_diag_fields_meta_t.
 *
 * @param [in]    unit                   - Unit index.
 * @param [in]    inst_idx               - Instance index.
 * @param [in]    sub_inst_idx           - Sub instance index.
 * @param [in]    entry_idx              - Entry index.
 * @param [in]    tbl_id                 - Table index.
 * @param [in]    flags                  - Operte flags.
 * @param [in]    ptr_diag_field_meta    - Pointer of util_diag_fields_meta_t to indicate which
 *                                         field shoud be shown.
 * @param [in]    opt                    - Show option.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_diag_mem_show(uint32 unit,
                   uint32 inst_idx,
                   uint32 sub_inst_idx,
                   uint32 entry_idx,
                   uint32 tbl_id,
                   uint32 flags,
                   util_diag_fields_meta_t *ptr_diag_field_meta,
                   util_diag_show_cmd_field_opt_t opt);

/**
 * @brief Set table/reg by field data and mask according to the util_diag_fields_meta_t.
 *
 * @param [in]    unit                   - Unit index.
 * @param [in]    inst_idx               - Instance index.
 * @param [in]    sub_inst_idx           - Sub instance index.
 * @param [in]    entry_idx              - Entry index.
 * @param [in]    tbl_id                 - Table index.
 * @param [in]    flags                  - Operte flags.
 * @param [in]    ptr_diag_field_meta    - Pointer of util_diag_fields_meta_t.
 * @param [in]    mode                   - Set mode.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_diag_mem_set(uint32 unit,
                  uint32 inst_idx,
                  uint32 sub_inst_idx,
                  uint32 entry_idx,
                  uint32 tbl_id,
                  uint32 flags,
                  util_diag_fields_meta_t *ptr_diag_field_meta,
                  util_diag_set_mode_t mode);

/**
 * @brief Set table/reg by overwrite data.
 *
 * @param [in]    unit              - Unit index.
 * @param [in]    inst_idx          - Instance index.
 * @param [in]    sub_inst_idx      - Sub instance index.
 * @param [in]    entry_idx         - Entry index.
 * @param [in]    tbl_id            - Table index.
 * @param [in]    flags             - Operte flags.
 * @param [in]    ptr_write_data    - Pointer of overwrite raw data buffer.
 * @param [in]    mode              - Set mode.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_diag_mem_overwrite_set(uint32 unit,
                            uint32 inst_idx,
                            uint32 sub_inst_idx,
                            uint32 entry_idx,
                            uint32 tbl_id,
                            uint32 flags,
                            uint32 *ptr_write_data,
                            util_diag_set_mode_t mode);

/**
 * @brief Add hash by field data according to the util_diag_fields_meta_t.
 *
 * @param [in]     unit                   - Unit index.
 * @param [in]     inst_idx               - Instance index.
 * @param [in]     sub_inst_idx           - Sub instance index.
 * @param [in]     bank_bmp               - Bank bitmap.
 * @param [in]     tbl_id                 - Table index.
 * @param [in]     flags                  - Operte flags.
 * @param [in]     ptr_diag_field_meta    - Pointer of util_diag_fields_meta_t.
 * @param [out]    ptr_entry_idx          - Added entry idx.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_diag_hash_add(uint32 unit,
                   uint32 inst_idx,
                   uint32 sub_inst_idx,
                   uint32 bank_bmp,
                   uint32 tbl_id,
                   uint32 flags,
                   util_diag_fields_meta_t *ptr_diag_field_meta,
                   uint32 *ptr_entry_idx);

/**
 * @brief Delete hash by field data according to the util_diag_fields_meta_t.
 *
 * @param [in]     unit                   - Unit index.
 * @param [in]     inst_idx               - Instance index.
 * @param [in]     sub_inst_idx           - Sub instance index.
 * @param [in]     bank_bmp               - Bank bitmap.
 * @param [in]     tbl_id                 - Table index.
 * @param [in]     flags                  - Operte flags.
 * @param [in]     ptr_diag_field_meta    - Pointer of util_diag_fields_meta_t.
 * @param [out]    ptr_entry_idx          - Deleted entry index.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_diag_hash_del(uint32 unit,
                   uint32 inst_idx,
                   uint32 sub_inst_idx,
                   uint32 bank_bmp,
                   uint32 tbl_id,
                   uint32 flags,
                   util_diag_fields_meta_t *ptr_diag_field_meta,
                   uint32 *ptr_entry_idx);

/**
 * @brief Lookup hash by field data according to the util_diag_fields_meta_t.
 *
 * @param [in]     unit                   - Unit index.
 * @param [in]     inst_idx               - Instance index.
 * @param [in]     sub_inst_idx           - Sub instance index.
 * @param [in]     bank_bmp               - Bank bitmap.
 * @param [in]     tbl_id                 - Table index.
 * @param [in]     flags                  - Operte flags.
 * @param [in]     ptr_diag_field_meta    - Pointer of util_diag_fields_meta_t.
 * @param [out]    ptr_entry_idx          - Lookup result.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_diag_hash_lookup(uint32 unit,
                      uint32 inst_idx,
                      uint32 sub_inst_idx,
                      uint32 bank_bmp,
                      uint32 tbl_id,
                      uint32 flags,
                      util_diag_fields_meta_t *ptr_diag_field_meta,
                      uint32 *ptr_entry_idx);

/**
 * @brief Update hash by field data according to the util_diag_fields_meta_t.
 *
 * @param [in]     unit                   - Unit index.
 * @param [in]     inst_idx               - Instance index.
 * @param [in]     sub_inst_idx           - Sub instance index.
 * @param [in]     bank_bmp               - Bank bitmap.
 * @param [in]     tbl_id                 - Table index.
 * @param [in]     flags                  - Operte flags.
 * @param [in]     ptr_diag_field_meta    - Pointer of util_diag_fields_meta_t.
 * @param [out]    ptr_entry_idx          - Added entry idx.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
util_diag_hash_update(uint32 unit,
                      uint32 inst_idx,
                      uint32 sub_inst_idx,
                      uint32 bank_bmp,
                      uint32 tbl_id,
                      uint32 flags,
                      util_diag_fields_meta_t *ptr_diag_field_meta,
                      uint32 *ptr_entry_idx);

#endif /* End of DIAG_H */
