/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv_io_mt_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DRV_MT).
 *  2. Define DRV_MT IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DRV_IO_MT_H
#define DRV_IO_MT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>
#include <clx/clx_init.h>
#include <drv/drv_io.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define DRV_IO_NB_BROADCAST_ADDR                (0x8000000)
#define DRV_IO_NB_BROADCAST_ECPU_REP_NUM_ADDR   (0x051C0038)
#define DRV_IO_NB_BROADCAST_ECPU_ADDR_STEP_ADDR (0x051C003C)
#define DRV_IO_NB_BROADCAST_PDMA_REP_NUM_ADDR   (0x051C0040)
#define DRV_IO_NB_BROADCAST_PDMA_ADDR_STEP_ADDR (0x051C0044)
#define DRV_IO_NB_BROADCAST_CMST_REP_NUM_ADDR   (0x051C0048)
#define DRV_IO_NB_BROADCAST_CMST_ADDR_STEP_ADDR (0x051C004C)

#define DRV_IO_KG_BROADCAST_ADDR                (0x4000000)
#define DRV_IO_KG_BROADCAST_ECPU_REP_NUM_ADDR   (0x00040040)
#define DRV_IO_KG_BROADCAST_ECPU_ADDR_STEP_ADDR (0x0004003C)
#define DRV_IO_KG_BROADCAST_PDMA_REP_NUM_ADDR   (0x00040040)
#define DRV_IO_KG_BROADCAST_PDMA_ADDR_STEP_ADDR (0x00040044)
#define DRV_IO_KG_BROADCAST_CMST_REP_NUM_ADDR   (0x00040048)
#define DRV_IO_KG_BROADCAST_CMST_ADDR_STEP_ADDR (0x0004004C)

typedef enum drv_io_mt_table_type_e {
    DRV_IO_MT_TABLE_HASH = 0,
    DRV_IO_MT_TABLE_HASH_BDI,
    DRV_IO_MT_TABLE_HASH_FPU,
    DRV_IO_MT_TABLE_TCAM,
    DRV_IO_MT_TABLE_TCAM_FPU,
    DRV_IO_MT_TABLE_SRAM_PL,
    DRV_IO_MT_TABLE_SRAM_TM,
    DRV_IO_MT_TABLE_LAST
} drv_io_mt_table_type_t;

typedef enum drv_io_mt_table_key_type_e {
    DRV_IO_MT_TABLE_KEY_1X = 0x0,
    DRV_IO_MT_TABLE_KEY_2X = 0x1,
    DRV_IO_MT_TABLE_KEY_4X = 0x2,
    DRV_IO_MT_TABLE_KEY_LAST
} drv_io_mt_table_key_type_t;

/* Hash cmd action */
typedef enum drv_io_mt_cmd_hash_act_e {
    DRV_IO_MT_CMD_HASH_DIRECT_READ = 0x0,
    DRV_IO_MT_CMD_HASH_DIRECT_WRITE = 0x1,
    DRV_IO_MT_CMD_HASH_SEARCH = 0x2,
    DRV_IO_MT_CMD_HASH_FIND = 0x3,
    DRV_IO_MT_CMD_HASH_INSERT = 0x4,
    DRV_IO_MT_CMD_HASH_DELETE = 0x5,
    DRV_IO_MT_CMD_HASH_UPDATE = 0x6,
    DRV_IO_MT_CMD_HASH_SCAN = 0xfff,
    DRV_IO_MT_CMD_HASH_LAST
} drv_io_mt_cmd_hash_act_t;

typedef enum drv_io_mt_hash_key_type_e {
    DRV_IO_MT_HASH_KEY_1X_IP = 0x0,
    DRV_IO_MT_HASH_KEY_2X_IP = 0x1,
    DRV_IO_MT_HASH_KEY_1X_MPLS_SID = 0x2,
    DRV_IO_MT_HASH_KEY_2X_MPLS_SIP = 0x3,
    DRV_IO_MT_HASH_KEY_LAST
} drv_io_mt_hash_key_type_t;

/* Tcam cmd action */
typedef enum drv_io_mt_cmd_tcam_act_e {
    DRV_IO_MT_CMD_TCAM_READ = 0x0,
    DRV_IO_MT_CMD_TCAM_WRITE = 0x1,
    DRV_IO_MT_CMD_TCAM_CMP = 0x2,
    DRV_IO_MT_CMD_TCAM_UNLOAD = 0x3,
    DRV_IO_MT_CMD_TCAM_FLUSH = 0x4,
    DRV_IO_MT_CMD_TCAM_VALID = 0x5,
    DRV_IO_MT_CMD_TCAM_MOVE = 0xff,
    DRV_IO_MT_CMD_TCAM_SCAN = 0xfff,
    DRV_IO_MT_CMD_TCAM_LAST
} drv_io_mt_cmd_tcam_act_t;

/* DRV_MT constant definition */
#define DRV_IO_MT_IND_CMD_CFG_OFFSET                       (0x0)
#define DRV_IO_MT_IND_ADDR_CFG_OFFSET                      (0x4)
#define DRV_IO_MT_IND_STATUS_STA_OFFSET                    (0x8)
#define DRV_IO_MT_IND_DATA_DHS_OFFSET                      (0xC)
#define DRV_IO_MT_IND_HASH_DATA_DHS_OFFSET                 (0x14)
#define DRV_IO_MT_IND_FPU_HASH_DATA_DHS_OFFSET             (0x54)
#define DRV_IO_MT_IND_PL_DATA_DHS_OFFSET                   (0x4)
#define DRV_IO_MT_IND_CIAT_TCAM_MOVE_CMD_CFG_OFFSET        (0x78)
#define DRV_IO_MT_IND_FPU_TCAM_SLC0_MOVE_CMD_CFG_OFFSET    (0x28)
#define DRV_IO_MT_IND_FPU_TCAM_SLC1_MOVE_CMD_CFG_OFFSET    (0x40)
#define DRV_IO_MT_IND_CIAT_TCAM_MOVE_STATUS_STA_OFFSET     (0x80)
#define DRV_IO_MT_IND_FPU_TCAM_SLC0_MOVE_STATUS_STA_OFFSET (0x30)
#define DRV_IO_MT_IND_FPU_TCAM_SLC1_MOVE_STATUS_STA_OFFSET (0x48)

#define DRV_IO_MT_IND_CMD_REG_WORD_SIZE             (1)
#define DRV_IO_MT_IND_ADDR_REG_WORD_SIZE            (1)
#define DRV_IO_MT_IND_STATUS_REG_WORD_SIZE          (1)
#define DRV_IO_MT_IND_HASH_STATUS_REG_WORD_SIZE     (3)
#define DRV_IO_MT_IND_FPU_HASH_STATUS_REG_WORD_SIZE (19)
#define DRV_IO_MT_IND_CMD_TCAM_MOVE_REG_WORD_SIZE   (2)

/* unit of time: us, all times need for further check */
#ifdef NB_EMU_DEV
#define DRV_IO_MT_CMD_BUSY_POLL_CNT (3000000)
#else
#define DRV_IO_MT_CMD_BUSY_POLL_CNT (1000)
#endif

#define DRV_IO_MT_IND_STATUS_DOING      (0)
#define DRV_IO_MT_IND_STATUS_DONE       (1)
#define DRV_IO_MT_IND_STATUS_OP_FAIL    (0)
#define DRV_IO_MT_IND_STATUS_OP_SUCCESS (1)

#pragma pack(push, 1)
#if defined(CLX_EN_BIG_ENDIAN)
typedef union drv_io_mt_reg_hash_ind_addr_reg_u {
    uint32 reg[DRV_IO_MT_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 12;
        uint32 ind_addr : 20;
    } field;
} drv_io_mt_reg_hash_ind_addr_reg_t;

typedef union drv_io_mt_reg_fpu_hash_stat_reg_u {
    uint32 reg[DRV_IO_MT_IND_FPU_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 32;
        uint32 : 8;
        uint32 cpu_fd_dup : 1;
        uint32 cpu_fd_hit : 1;
        uint32 cpu_fd_tile_no : 5;
        uint32 cpu_fd_idx : 15;
        uint32 op_suc : 1;
        uint32 ind_access_done : 1;
    } field;
} drv_io_mt_reg_fpu_hash_stat_reg_t;

/* Response status */
typedef union drv_io_mt_reg_hash_stat_reg_u {
    uint32 reg[DRV_IO_MT_IND_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_result2 : 32;
        uint32 ind_result1 : 32;
        uint32 ind_result0 : 30;
        uint32 op_suc : 1;
        uint32 ind_access_done : 1;
    } field;
} drv_io_mt_reg_hash_stat_reg_t;

typedef union drv_io_mt_reg_fpu_hash_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 del_hit_op : 1;
        uint32 insert_hit_op : 1;
        uint32 acc_bmp : 24;
        uint32 ecc_access : 1;
        uint32 key_type : 2;
        uint32 cmd : 3;
    } field;
} drv_io_mt_reg_fpu_hash_cmd_reg_t;

typedef union drv_io_mt_reg_hash_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 28;
        uint32 ecc_access : 1;
        uint32 cmd : 3;
    } field;
    struct {
        uint32 : 27;
        uint32 ecc_access : 1;
        uint32 key_type : 1;
        uint32 cmd : 3;
    } field1;
} drv_io_mt_reg_hash_cmd_reg_t;
typedef union drv_io_mt_reg_fpu_tcam_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 26;
        uint32 ind_slc_select : 1;
        uint32 mode : 2;
        uint32 cmd : 3;
    } field;
} drv_io_mt_reg_fpu_tcam_cmd_reg_t;

typedef union drv_io_mt_reg_tcam_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 26;
        uint32 mode : 3;
        uint32 cmd : 3;
    } field;
} drv_io_mt_reg_tcam_cmd_reg_t;

typedef union drv_io_mt_reg_fpu_tcam_addr_reg_u {
    uint32 reg[DRV_IO_MT_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 ind_mem_addr : 15;
    } field;
} drv_io_mt_reg_fpu_tcam_addr_reg_t;

typedef union drv_io_mt_reg_tcam_addr_reg_u {
    uint32 reg[DRV_IO_MT_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 : 18;
        uint32 ind_mem_addr : 14;
    } field;
} drv_io_mt_reg_tcam_addr_reg_t;

typedef union drv_io_mt_reg_tcam_sta_reg_u {
    uint32 reg[DRV_IO_MT_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 : 31;
        uint32 ind_access_done : 1;
    } field;
} drv_io_mt_reg_tcam_sta_reg_t;

typedef union drv_io_mt_reg_tcam_move_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_TCAM_MOVE_REG_WORD_SIZE];
    struct {
        uint32 move_mode : 2;
        uint32 op_num : 14;
        uint32 dst_addr : 14;
        uint32 src_addr : 14;
    } ciat_cmd;
    struct {
        uint32 move_mode : 2;
        uint32 op_num : 15;
        uint32 dst_addr : 15;
        uint32 src_addr : 15;
    } fpu_cmd;
} drv_io_mt_reg_tcam_move_cmd_reg_t;

typedef union drv_io_mt_reg_tcam_move_sta_reg_u {
    uint32 reg[DRV_IO_MT_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 cur_src_ptr : 14;
        uint32 move_done : 1;
        uint32 ack_lock : 4;
        uint32 cur_status : 3;
    } field;
} drv_io_mt_reg_tcam_move_sta_reg_t;

typedef union drv_io_mt_reg_ipl_cpx_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 20;
        uint32 mem_inst_sel : 4;
        uint32 address : 8;
    } field;
} drv_io_mt_reg_ipl_cpx_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_cpx_fd_buf_mem_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 22;
        uint32 address : 10;
    } field;
} drv_io_mt_reg_ipl_cpx_fd_buf_mem_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 14;
        uint32 mem_umac_id : 2;
        uint32 mem_bank_id : 4;
        uint32 address : 12;
    } field;
} drv_io_mt_reg_ipl_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_app_fd_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 15;
        uint32 mem_umac_id : 2;
        uint32 address : 15;
    } field;
} drv_io_mt_reg_ipl_app_fd_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_app_fbm_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 24;
        uint32 mem_umac_id : 2;
        uint32 address : 6;
    } field;
} drv_io_mt_reg_ipl_app_fbm_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_lbm_wd_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 20;
        uint32 dp_sel : 1;
        uint32 address : 11;
    } field;
} drv_io_mt_reg_ipl_lbm_wd_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_lbm_data_buf_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 mem_sel : 5;
        uint32 dp_sel : 1;
        uint32 address : 9;
    } field;
} drv_io_mt_reg_ipl_lbm_data_buf_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_app_umac_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 15;
        uint32 umac_id_sel : 2;
        uint32 bank_idx : 5;
        uint32 address : 10;
    } field;
} drv_io_mt_reg_epl_app_umac_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_umac_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 15;
        uint32 umac_id_sel : 2;
        uint32 bank_idx : 5;
        uint32 address : 10;
    } field;
} drv_io_mt_reg_epl_umac_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_umac_fd_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 17;
        uint32 umac_id_sel : 2;
        uint32 address : 13;
    } field;
} drv_io_mt_reg_epl_umac_fd_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_cpx_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 20;
        uint32 address : 7;
        uint32 bank_id : 5;
    } field;
} drv_io_mt_reg_epl_cpx_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_cpx_fd_buf_mem_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 22;
        uint32 address : 10;
    } field;
} drv_io_mt_reg_epl_cpx_fd_buf_mem_cmd_reg_t;

typedef union drv_io_mt_reg_tm_emu_verf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 : 14;
        uint32 mem_inst_sel : 9; /* range 0~287, range 0~71, emu0:0~35 , emu1:36~71 emu7:252-287 */
        uint32 address : 9;
    } field;
} drv_io_mt_reg_tm_emu_verf_mem_ind_cmd_reg_t;

#elif defined(CLX_EN_LITTLE_ENDIAN)
typedef union drv_io_mt_reg_hash_ind_addr_reg_u {
    uint32 reg[DRV_IO_MT_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_addr : 20;
        uint32 : 12;
    } field;
} drv_io_mt_reg_hash_ind_addr_reg_t;

/* Response status */
typedef union drv_io_mt_reg_fpu_hash_stat_reg_u {
    uint32 reg[DRV_IO_MT_IND_FPU_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
        uint32 op_suc : 1;
        uint32 cpu_fd_idx : 15;
        uint32 cpu_fd_tile_no : 5;
        uint32 cpu_fd_hit : 1;
        uint32 cpu_fd_dup : 1;
        // uint32 cpu_fd_hit_idx       :     360;
        // uint32 cpu_fd_key_exist_bmp :     24;
        // uint32 cpu_fd_row_freebmp   :     192;
    } field;
} drv_io_mt_reg_fpu_hash_stat_reg_t;

/* Response status */
typedef union drv_io_mt_reg_hash_stat_reg_u {
    uint32 reg[DRV_IO_MT_IND_HASH_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
        uint32 op_suc : 1;
        uint32 ind_result0 : 30;
        uint32 ind_result1 : 32;
        uint32 ind_result2 : 32;
    } field;
} drv_io_mt_reg_hash_stat_reg_t;

typedef union drv_io_mt_reg_fpu_hash_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 key_type : 2;
        uint32 ecc_access : 1;
        uint32 acc_bmp : 24;
        uint32 insert_hit_op : 1;
        uint32 del_hit_op : 1;
    } field;
} drv_io_mt_reg_fpu_hash_cmd_reg_t;

typedef union drv_io_mt_reg_hash_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 ecc_access : 1;
    } field;
    struct {
        uint32 cmd : 3;
        uint32 key_type : 1;
        uint32 ecc_access : 1;
    } field1;
} drv_io_mt_reg_hash_cmd_reg_t;
typedef union drv_io_mt_reg_fpu_tcam_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 mode : 2;
        uint32 ind_slc_select : 1;
    } field;
} drv_io_mt_reg_fpu_tcam_cmd_reg_t;

typedef union drv_io_mt_reg_tcam_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 cmd : 3;
        uint32 mode : 3;
    } field;
} drv_io_mt_reg_tcam_cmd_reg_t;

typedef union drv_io_mt_reg_fpu_tcam_addr_reg_u {
    uint32 reg[DRV_IO_MT_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_mem_addr : 15;
    } field;
} drv_io_mt_reg_fpu_tcam_addr_reg_t;

typedef union drv_io_mt_reg_tcam_addr_reg_u {
    uint32 reg[DRV_IO_MT_IND_ADDR_REG_WORD_SIZE];
    struct {
        uint32 ind_mem_addr : 14;
    } field;
} drv_io_mt_reg_tcam_addr_reg_t;

typedef union drv_io_mt_reg_tcam_sta_reg_u {
    uint32 reg[DRV_IO_MT_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 ind_access_done : 1;
    } field;
} drv_io_mt_reg_tcam_sta_reg_t;

typedef union drv_io_mt_reg_tcam_move_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_TCAM_MOVE_REG_WORD_SIZE];
    struct {
        uint32 src_addr : 14;
        uint32 dst_addr : 14;
        uint32 op_num : 14;
        uint32 move_mode : 2;
    } ciat_cmd;
    struct {
        uint32 src_addr : 15;
        uint32 dst_addr : 15;
        uint32 op_num : 15;
        uint32 move_mode : 2;
    } fpu_cmd;
} drv_io_mt_reg_tcam_move_cmd_reg_t;

typedef union drv_io_mt_reg_tcam_move_sta_reg_u {
    uint32 reg[DRV_IO_MT_IND_STATUS_REG_WORD_SIZE];
    struct {
        uint32 cur_status : 3;
        uint32 ack_lock : 4;
        uint32 move_done : 1;
        uint32 cur_src_ptr : 14;
    } field;
} drv_io_mt_reg_tcam_move_sta_reg_t;

typedef union drv_io_mt_reg_ipl_cpx_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 8;
        uint32 mem_inst_sel : 4;
    } field;
} drv_io_mt_reg_ipl_cpx_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_cpx_fd_buf_mem_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
    } field;
} drv_io_mt_reg_ipl_cpx_fd_buf_mem_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 12;
        uint32 mem_bank_id : 4;
        uint32 mem_umac_id : 2;
    } field;
} drv_io_mt_reg_ipl_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_app_fd_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 15;
        uint32 mem_umac_id : 2;
    } field;
} drv_io_mt_reg_ipl_app_fd_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_app_fbm_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 6;
        uint32 mem_umac_id : 2;
    } field;
} drv_io_mt_reg_ipl_app_fbm_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_lbm_wd_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 11;
        uint32 dp_sel : 1;
    } field;
} drv_io_mt_reg_ipl_lbm_wd_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_ipl_lbm_data_buf_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 9;
        uint32 mem_sel : 5;
        uint32 dp_sel : 1;
    } field;
} drv_io_mt_reg_ipl_lbm_data_buf_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_app_umac_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
        uint32 bank_idx : 5;
        uint32 umac_id_sel : 2;
    } field;
} drv_io_mt_reg_epl_app_umac_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_umac_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
        uint32 bank_idx : 5;
        uint32 umac_id_sel : 2;
    } field;
} drv_io_mt_reg_epl_umac_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_umac_fd_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 13;
        uint32 umac_id_sel : 2;
    } field;
} drv_io_mt_reg_epl_umac_fd_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_cpx_data_buf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 bank_id : 5;
        uint32 address : 7;
    } field;
} drv_io_mt_reg_epl_cpx_data_buf_mem_ind_cmd_reg_t;

typedef union drv_io_mt_reg_epl_cpx_fd_buf_mem_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 10;
    } field;
} drv_io_mt_reg_epl_cpx_fd_buf_mem_cmd_reg_t;

typedef union drv_io_mt_reg_tm_emu_verf_mem_ind_cmd_reg_u {
    uint32 reg[DRV_IO_MT_IND_CMD_REG_WORD_SIZE];
    struct {
        uint32 address : 9;
        uint32 mem_inst_sel : 9; /* range 0~287, range 0~71, emu0:0~35 , emu1:36~71 emu7:252-287 */
        uint32 : 14;
    } field;
} drv_io_mt_reg_tm_emu_verf_mem_ind_cmd_reg_t;

#else
#error "Host endian is not defined!!\n"
#endif
#pragma pack(pop)

typedef struct drv_io_mt_tcam_fpu_info_s {
    drv_io_mt_reg_fpu_tcam_cmd_reg_t ind_cmd;
    drv_io_mt_reg_fpu_tcam_addr_reg_t ind_addr;
    drv_io_mt_reg_tcam_sta_reg_t ind_sta;
    uint32 acc_bmp;
} drv_io_mt_tcam_fpu_info_t;

typedef struct drv_io_mt_tcam_info_s {
    drv_io_mt_reg_tcam_cmd_reg_t ind_cmd;
    drv_io_mt_reg_tcam_addr_reg_t ind_addr;
    drv_io_mt_reg_tcam_sta_reg_t ind_sta;
} drv_io_mt_tcam_info_t;

typedef struct drv_io_mt_hash_fpu_info_s {
    drv_io_mt_reg_fpu_hash_cmd_reg_t ind_cmd;
    drv_io_mt_reg_hash_ind_addr_reg_t ind_addr;
    drv_io_mt_reg_fpu_hash_stat_reg_t ind_sta;
} drv_io_mt_hash_fpu_info_t;

typedef struct drv_io_mt_hash_info_s {
    drv_io_mt_reg_hash_cmd_reg_t ind_cmd;
    drv_io_mt_reg_hash_ind_addr_reg_t ind_addr;
    drv_io_mt_reg_hash_stat_reg_t ind_sta;
} drv_io_mt_hash_info_t;

typedef struct drv_io_mt_tcam_move_info_s {
    drv_io_mt_reg_tcam_move_cmd_reg_t ind_move_cmd;
    drv_io_mt_reg_tcam_move_sta_reg_t ind_move_sta;
} drv_io_mt_tcam_move_info_t;

typedef union drv_io_mt_pl_tm_ind_mem_info_u {
    drv_io_mt_reg_tm_emu_verf_mem_ind_cmd_reg_t tm_emu_verf_mem_ind_cmd;
    drv_io_mt_reg_epl_cpx_data_buf_mem_ind_cmd_reg_t epl_cpx_data_buf_mem_ind_cmd;
    drv_io_mt_reg_epl_umac_fd_buf_mem_ind_cmd_reg_t epl_umac_fd_buf_mem_ind_cmd;
    drv_io_mt_reg_epl_umac_data_buf_mem_ind_cmd_reg_t epl_umac_data_buf_mem_ind_cmd;
    drv_io_mt_reg_epl_app_umac_data_buf_mem_ind_cmd_reg_t epl_app_umac_data_buf_mem_ind_cmd;
    drv_io_mt_reg_ipl_lbm_data_buf_ind_cmd_reg_t ipl_lbm_data_buf_ind_cmd;
    drv_io_mt_reg_ipl_lbm_wd_mem_ind_cmd_reg_t ipl_lbm_wd_mem_ind_cmd;
    drv_io_mt_reg_ipl_app_fbm_mem_ind_cmd_reg_t ipl_app_fbm_mem_ind_cmd;
    drv_io_mt_reg_ipl_app_fd_mem_ind_cmd_reg_t ipl_app_fd_mem_ind_cmd;
    drv_io_mt_reg_ipl_data_buf_mem_ind_cmd_reg_t ipl_data_buf_mem_ind_cmd;
    drv_io_mt_reg_ipl_cpx_fd_buf_mem_cmd_reg_t ipl_cpx_fd_bum_mem_ind_cmd;
    drv_io_mt_reg_ipl_cpx_data_buf_mem_ind_cmd_reg_t ipl_cpx_data_buf_mem_ind_cmd;
} drv_io_mt_pl_tm_ind_mem_info_t;

typedef struct drv_io_mt_table_meta_s {
    uint32 ind_cmd_addr;
    uint32 ind_address_addr;
    uint32 ind_status_addr;
    uint32 ind_data_addr;
    uint32 acc_bmp_addr;

    union {
        drv_io_mt_tcam_fpu_info_t tcam_fpu_info;
        drv_io_mt_tcam_fpu_info_t tcam_info;
        drv_io_mt_hash_fpu_info_t hash_fpu_info;
        drv_io_mt_hash_info_t hash_info;
        drv_io_mt_pl_tm_ind_mem_info_t tm_pl_info;
        drv_io_mt_tcam_move_info_t tcam_move_info;
    };

    drv_io_mt_table_type_t table_type;
    boolean access_by_dma;

} drv_io_mt_table_meta_t;

/* DRV CMST ERROR LOG */
#pragma pack(push, 1)
#if defined(CLX_EN_BIG_ENDIAN)
typedef struct drv_io_mt_error_cmst_code_s {
    uint32 req_addr_2 : 21;
    uint32 req_mid : 3;
    uint32 req_sn : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 : 2;
    uint32 req_addr_1 : 9;
} drv_io_mt_error_cmst_code_t;

typedef struct drv_io_mt_error_cslv_code_s {
    uint32 req_addr_2 : 21;
    uint32 req_mid : 3;
    uint32 req_sn : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 slv_error_code : 2;
    uint32 req_addr_1 : 9;
} drv_io_mt_error_cslv_code_t;

typedef struct drv_io_mt_error_other_code_s {
    uint32 chain_id_2 : 5;
    uint32 : 8;
    uint32 req_addr_lsb : 8;
    uint32 : 3;
    uint32 : 8;
    uint32 : 3;
    uint32 error_info_valid : 1;
    uint32 master_id : 3;
    uint32 cmst_error_code : 3;
    uint32 req_type : 2;
    uint32 req_attr : 3;
    uint32 req_size : 6;
    uint32 : 2;
    uint32 : 5;
    uint32 chain_id_1 : 4;
} drv_io_mt_error_other_code_t;
#elif defined(CLX_EN_LITTLE_ENDIAN)
typedef struct drv_io_mt_error_cmst_code_s {
    uint32 req_sn : 8;
    uint32 req_mid : 3;
    uint32 req_addr_2 : 21;
    uint32 req_addr_1 : 9;
    uint32 : 2;
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_io_mt_error_cmst_code_t;

typedef struct drv_io_mt_error_cslv_code_s {
    uint32 req_sn : 8;
    uint32 req_mid : 3;
    uint32 req_addr_2 : 21;
    uint32 req_addr_1 : 9;
    uint32 slv_error_code : 2;
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_io_mt_error_cslv_code_t;

typedef struct drv_io_mt_error_other_code_s {
    uint32 : 8;
    uint32 : 3;
    uint32 req_addr_lsb : 8;
    uint32 : 8;
    uint32 chain_id_2 : 5;
    uint32 chain_id_1 : 4;
    uint32 : 5;
    uint32 : 2;
    uint32 req_size : 6;
    uint32 req_attr : 3;
    uint32 req_type : 2;
    uint32 cmst_error_code : 3;
    uint32 master_id : 3;
    uint32 error_info_valid : 1;
    uint32 : 3;
} drv_io_mt_error_other_code_t;
#else
#error "Host endian is not defined!!\n"
#endif
#pragma pack(pop)

typedef struct drv_io_mt_error_code_s {
    union {
        drv_io_mt_error_cmst_code_t cmst_code;
        drv_io_mt_error_cslv_code_t cslv_code;
        drv_io_mt_error_other_code_t other_code;
    };

} drv_io_mt_error_code_t;

#endif /* END of DRV_IO_MT_H*/
