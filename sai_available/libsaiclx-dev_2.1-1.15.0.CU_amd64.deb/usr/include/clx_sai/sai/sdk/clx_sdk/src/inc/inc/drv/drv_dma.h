/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv_dma.h
 * PURPOSE:
 *  1. Provide the access interfaces of DMA and CLD DMA to chip Device Control Command(DRV).
 *  2. Define DRV DMA and CLD DMA related structures.
 *
 * NOTES:
 *
 */

#ifndef DRV_DMA_H
#define DRV_DMA_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <osal/osal.h>
#include <clx/clx_init.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef enum drv_dma_d2d_dir_e {
    DRV_DMA_D2D_DIR_DESCENDING = 0x0,
    DRV_DMA_D2D_DIR_ASCENDING,
    DRV_DMA_D2D_DIR_LAST
} drv_dma_d2d_dir_t;

typedef enum drv_dma_ch_op_mode_e {
    DRV_DMA_CH_OP_MODE_POLL = 0,
    DRV_DMA_CH_OP_MODE_INTR,
    DRV_DMA_CH_OP_MODE_LAST
} drv_dma_ch_op_mode_t;

typedef enum {
    DRV_DMA_CLD_STATUS_DOING = 0,
    DRV_DMA_CLD_STATUS_DONE,
    DRV_DMA_CLD_STATUS_ERROR,
    DRV_DMA_CLD_STATUS_LAST,
} DRV_DMA_CLD_STATUS_T;

typedef clx_error_no_t (*drv_dma_init_t)(const uint32 unit);
typedef clx_error_no_t (*drv_dma_deinit_t)(const uint32 unit);
typedef clx_error_no_t (*drv_dma_write_ind_entry_t)(const uint32 unit,
                                                    void *ptr_src_buf,
                                                    const uint32 addr,
                                                    const uint32 entry_len,
                                                    const uint32 entry_num);
typedef clx_error_no_t (*drv_dma_read_ind_entry_t)(const uint32 unit,
                                                   void *ptr_dst_buf,
                                                   const uint32 addr,
                                                   const uint32 entry_len,
                                                   const uint32 entry_num);
typedef clx_error_no_t (*drv_dma_write_entry_t)(const uint32 unit,
                                                void *ptr_src_buf,
                                                const uint32 addr,
                                                const uint32 entry_len,
                                                const uint32 entry_num);
typedef clx_error_no_t (*drv_dma_read_entry_t)(const uint32 unit,
                                               void *ptr_dst_buf,
                                               const uint32 addr,
                                               const uint32 entry_len,
                                               const uint32 entry_num);
typedef clx_error_no_t (*drv_dma_copy_ind_entry_t)(const uint32 unit,
                                                   const uint32 src_addr,
                                                   const uint32 dst_addr,
                                                   const uint32 entry_len,
                                                   const uint32 entry_num);
typedef clx_error_no_t (*drv_dma_copy_entry_t)(const uint32 unit,
                                               const uint32 src_addr,
                                               const uint32 dst_addr,
                                               const uint32 entry_len,
                                               const uint32 entry_num);
typedef clx_error_no_t (*drv_dma_add_cld_task_t)(const uint32 unit,
                                                 void *ptr_dst_buf,
                                                 const uint32 addr,
                                                 const uint32 entry_len,
                                                 const uint32 entry_num);
typedef clx_error_no_t (*drv_dma_trigger_cld_dma_event_t)(const uint32 unit);
typedef clx_error_no_t (*drv_dma_get_cld_dma_status_t)(const uint32 unit,
                                                       DRV_DMA_CLD_STATUS_T *status);
typedef void (*drv_dma_channel_show_info_t)(const uint32 unit, const uint32 channel);

typedef clx_error_no_t (*drv_dma_thread_init_t)(const uint32 unit);
typedef clx_error_no_t (*drv_dma_thread_deinit_t)(const uint32 unit);
typedef struct {
    drv_dma_init_t drv_dma_init;
    drv_dma_deinit_t drv_dma_deinit;
    drv_dma_read_ind_entry_t drv_dma_ind_entry_read;
    drv_dma_write_ind_entry_t drv_dma_ind_entry_write;
    drv_dma_read_entry_t drv_dma_entry_read;
    drv_dma_write_entry_t drv_dma_entry_write;
    drv_dma_copy_ind_entry_t drv_dma_ind_entry_copy;
    drv_dma_copy_entry_t drv_dma_entry_copy;
    drv_dma_channel_show_info_t drv_dma_channel_show_info;
    drv_dma_add_cld_task_t drv_dma_cld_task_add;
    drv_dma_trigger_cld_dma_event_t drv_dma_cld_dma_event_trigger;
    drv_dma_get_cld_dma_status_t drv_dma_cld_dma_status_get;
    drv_dma_thread_init_t drv_dma_thread_init;
    drv_dma_thread_deinit_t drv_dma_thread_deinit;
} drv_dma_t;

clx_error_no_t
drv_dma_init(void);
clx_error_no_t
drv_dma_deinit(void);
clx_error_no_t
drv_dma_entry_read(const uint32 unit,
                   void *ptr_dst_buf,
                   const uint32 addr,
                   const uint32 entry_len,
                   const uint32 entry_num);
clx_error_no_t
drv_dma_entry_write(const uint32 unit,
                    void *ptr_src_buf,
                    const uint32 addr,
                    const uint32 entry_len,
                    const uint32 entry_num);
clx_error_no_t
drv_dma_entry_copy(const uint32 unit,
                   const uint32 src_addr,
                   const uint32 dst_addr,
                   const uint32 entry_len,
                   const uint32 entry_num);
clx_error_no_t
drv_dma_indirect_entry_read(const uint32 unit,
                            void *ptr_dst_buf,
                            const uint32 addr,
                            const uint32 entry_len,
                            const uint32 entry_num);
clx_error_no_t
drv_dma_indirect_entry_write(const uint32 unit,
                             void *ptr_src_buf,
                             const uint32 addr,
                             const uint32 entry_len,
                             const uint32 entry_num);
clx_error_no_t
drv_dma_indirect_entry_copy(const uint32 unit,
                            const uint32 src_addr,
                            const uint32 dst_addr,
                            const uint32 entry_len,
                            const uint32 entry_num);

/**
 * @brief drv_dma_cld_task_add() is responsible for adding a task to the CLD DMA ring.
 * @param [in]     unit           - The specified unit number.
 * @param [in]     ptr_dst_buf    - The start address of host memory for DMA transfer. Please note
 * that this address is virtual address.
 * @param [in]     addr           - The start address of device table address for DMA transfer. This
 * address should be a valid address inside chip.
 * @param [in]     entry_len      - The length of an entry is going to be transferred.
 * @param [in]     entry_num      - Number of entries are going to be transferred.
 * @return         CLX_E_OK         - Successfully add a task to CLD DMA ring.
 * @return         CLX_E_OTHERS     - Fail to add a task to CLD DMA ring.
 * @return         CLX_E_TABLE_FULL - The number of tasks is greater than the CLD DMA ring size.
 * @return         CLX_E_BAD_PARAMETER  - Input parameter has error configuration or value.
 * @return         CLX_E_TIMEOUT    - Take semaphore timeout.
 */
clx_error_no_t
drv_dma_cld_task_add(const uint32 unit,
                     void *ptr_dst_buf,
                     const uint32 addr,
                     const uint32 entry_len,
                     const uint32 entry_num);

/**
 * @brief drv_dma_cld_event_trigger() is responsible for triggering the CLD DMA ring to perform one
 * cycle of operation.
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @return         CLX_E_OK           - Successfully initialize DRV_MT.
 * @return         CLX_E_TIMEOUT      - Take semaphore timeout.
 */
clx_error_no_t
drv_dma_cld_event_trigger(const uint32 unit);
/**
 * @brief drv_dma_cld_status_get() is responsible to check cld dma channel status.
 * @param [in]     unit    - The unit number that would like to be initialized.
 * @param [out]    status  - The CLD DMA channel status.
 * @return         CLX_E_OK           - Successfully initialize DRV_MT.
 * @return         CLX_E_OTHERS       - CLD DMA channel error.
 * @return         CLX_E_TIMEOUT      - Take semaphore timeout.
 */
clx_error_no_t
drv_dma_cld_status_get(const uint32 unit, DRV_DMA_CLD_STATUS_T *status);
clx_error_no_t
drv_dma_thread_init(void);
clx_error_no_t
drv_dma_thread_deinit(void);

/**
 * @brief calculate 4bytes aligned entry_len
 *
 * @param [in]     unit               - The specified unit number.
 * @param [in]     entry_len          - entry_len
 * @param [out]    entry_len_align    - 4 bytes aligned entry_len
 */
void
drv_dma_calculate_4bytes_align(const uint32 unit, uint32 entry_len, uint32 *entry_len_align);

/**
 * @brief calculate 2^N aligned entry_len
 *
 * @param [in]     unit               - The specified unit number.
 * @param [in]     entry_len          - entry_len
 * @param [out]    entry_len_align    - 2^N aligned entry_len
 */
void
drv_dma_calculate_nsquare_align(const uint32 unit, uint32 entry_len, uint32 *entry_len_align);

#endif /* END of DRV_DMA_H*/
