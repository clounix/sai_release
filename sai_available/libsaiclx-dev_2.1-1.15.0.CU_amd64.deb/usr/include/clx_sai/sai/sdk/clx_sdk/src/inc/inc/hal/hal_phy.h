/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_phy.h
 * PURPOSE:
 *      It provide HAL PHY module API.
 * NOTES:
 *
 */

#ifndef HAL_PHY_H
#define HAL_PHY_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PHY_BITS_PER_BYTE  (8)
#define HAL_PHY_BYTES_PER_WORD (2)
#define HAL_PHY_BITS_PER_WORD  (HAL_PHY_BITS_PER_BYTE * HAL_PHY_BYTES_PER_WORD)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_PHY_FOREACH_ABILITY(__field_value__, __field_start__, __field_end__, __ability__)     \
    for ((__ability__) = (__field_start__); (__ability__) < (__field_end__); (__ability__) <<= 1) \
        if (((__ability__) & (__field_value__)) > 0)

#define PTR_HAL_PHY_CB(unit, port, type) _hal_phy_driver_cb[unit][port].driver[type]

#define HAL_PHY_FUNC_CALL(__unit__, __port__, __type__, __func__, __param__)                        \
    ({                                                                                              \
        clx_error_no_t __rc = CLX_E_OK;                                                             \
        if (HAL_PHY_TYPE_INTERNAL == __type__) {                                                    \
            if ((NULL == PTR_HAL_FUNC_VECTOR(__unit__)->internal_phy_func_vec) ||                   \
                (NULL ==                                                                            \
                 PTR_HAL_FUNC_VECTOR(__unit__)->internal_phy_func_vec->hal_phy_##__func__)) {       \
                __rc = CLX_E_NOT_SUPPORT;                                                           \
            } else {                                                                                \
                UTIL_LOG_PRINT(UTIL_LOG_HAL, UTIL_LOG_INFO, "[N]\n");                               \
                __rc = (PTR_HAL_FUNC_VECTOR(__unit__)                                               \
                            ->internal_phy_func_vec->hal_phy_##__func__ __param__);                 \
            }                                                                                       \
        } else {                                                                                    \
            if (NULL == PTR_HAL_PHY_CB(__unit__, __port__, __type__)->hal_phy_##__func__) {         \
                __rc = CLX_E_NOT_SUPPORT;                                                           \
            } else {                                                                                \
                UTIL_LOG_PRINT(UTIL_LOG_PHY, UTIL_LOG_INFO, "[N]\n");                               \
                __rc =                                                                              \
                    ((PTR_HAL_PHY_CB(__unit__, __port__, __type__))->hal_phy_##__func__ __param__); \
            }                                                                                       \
        }                                                                                           \
        if (CLX_E_OK != __rc) {                                                                     \
            UTIL_LOG_PRINT(UTIL_LOG_PHY, UTIL_LOG_WARN, "u=%u p=%u, chip=0x%x rc=%d\n", __unit__,   \
                           __port__, HAL_DEVICE_CHIP_ID(unit), __rc);                               \
        }                                                                                           \
        __rc;                                                                                       \
    })

/* DATA TYPE DECLARACTIONS
 */
typedef enum {
    HAL_PHY_MDIO_DEVICE_TYPE_PMA_PMD = 1,
    HAL_PHY_MDIO_DEVICE_TYPE_WIS = 2,
    HAL_PHY_MDIO_DEVICE_TYPE_PCS = 3,
    HAL_PHY_MDIO_DEVICE_TYPE_PHY_XS = 4,
    HAL_PHY_MDIO_DEVICE_TYPE_DTE_XS = 5,
    HAL_PHY_MDIO_DEVICE_TYPE_TC = 6,
    HAL_PHY_MDIO_DEVICE_TYPE_AN = 7,
    HAL_PHY_MDIO_DEVICE_TYPE_VENDOR_1 = 30,
    HAL_PHY_MDIO_DEVICE_TYPE_VENDOR_2 = 31,
    HAL_PHY_MDIO_DEVICE_TYPE_LAST = (0x1UL << 5) /* 5-bit vlaue for device type */
} HAL_PHY_MDIO_DEVICE_TYPE_T;

typedef enum {
    HAL_PHY_ADMIN_STATE_TYPE_DISABLE = 0x0,
    HAL_PHY_ADMIN_STATE_TYPE_ENABLE,
    HAL_PHY_ADMIN_STATE_TYPE_LAST
} HAL_PHY_ADMIN_STATE_TYPE_T;

typedef enum {
    HAL_PHY_LINK_STATE_TYPE_DOWN = 0x0,
    HAL_PHY_LINK_STATE_TYPE_UP,
    HAL_PHY_LINK_STATE_TYPE_LAST
} HAL_PHY_LINK_STATE_TYPE_T;

typedef enum {
    HAL_PHY_SPEED_TYPE_1000M = 0x0,
    HAL_PHY_SPEED_TYPE_2500M,
    HAL_PHY_SPEED_TYPE_5G,
    HAL_PHY_SPEED_TYPE_10G,
    HAL_PHY_SPEED_TYPE_25G,
    HAL_PHY_SPEED_TYPE_26G,
    HAL_PHY_SPEED_TYPE_40G,
    HAL_PHY_SPEED_TYPE_50G,
    HAL_PHY_SPEED_TYPE_100G,
    HAL_PHY_SPEED_TYPE_200G,
    HAL_PHY_SPEED_TYPE_400G,
    HAL_PHY_SPEED_TYPE_800G,
    HAL_PHY_SPEED_TYPE_LAST
} HAL_PHY_SPEED_TYPE_T;

typedef enum {
    HAL_PHY_POWERUP_MODULE_TX,
    HAL_PHY_POWERUP_MODULE_RX,
    HAL_PHY_POWERUP_MODULE_LAST
} HAL_PHY_POWERUP_MODULE_TYPE_T;

typedef enum {
    HAL_PHY_LANE_SPEED_TYPE_10P3125 = 0x0,
    HAL_PHY_LANE_SPEED_TYPE_25P78125,
    HAL_PHY_LANE_SPEED_TYPE_26P5625,
    HAL_PHY_LANE_SPEED_TYPE_53P125_NRZ,
    HAL_PHY_LANE_SPEED_TYPE_53P125_PAM4,
    HAL_PHY_LANE_SPEED_TYPE_56P25_PAM4,
    HAL_PHY_LANE_SPEED_TYPE_106P25,
    HAL_PHY_LANE_SPEED_TYPE_112P5,
    HAL_PHY_LANE_SPEED_TYPE_LAST
} HAL_PHY_LANE_SPEED_TYPE_T;

typedef enum {
    HAL_PHY_ACC_HI_Z = 0,
    HAL_PHY_ACC_TERM_VSS_AC = 1, /**< termination to vss, onchip AC coupling */
    HAL_PHY_ACC_TERM_FL_AC = 2,  /**< floating termination, onchip AC coupling */
    // RES1 = 3, // Reserved
    // RES2 = 4, // Reserved
    HAL_PHY_ACC_TERM_VSS_DC = 5, /**< termination to vss, DC coupled */
    HAL_PHY_ACC_TERM_FL_DC = 6,  /**< floating termination to vss, DC coupled */
    // RES3 = 7, // Reserved
} HAL_PHY_ACC_TERM_MODE_T;

typedef enum {
    HAL_PHY_POWER_MODE_P0 = 0x0, /* power up, normal mode, eee disable */
    HAL_PHY_POWER_MODE_P0S,      /* wake : fast        up:P1,RX              down:TX */
    HAL_PHY_POWER_MODE_P1,       /* wake : medium      up:P2,synthersizer    down:RX/TX */
    HAL_PHY_POWER_MODE_P2, /* deep sleep,        up:receiver detection down:RX/TX,synthersizer */
    HAL_PHY_POWER_MODE_PD, /* power down */
    HAL_PHY_POWER_MODE_LAST
} HAL_PHY_POWER_MODE_T;

typedef enum {
    HAL_PHY_ATEST_MODE_ADC = 0x0,
    HAL_PHY_ATEST_MODE_PMON,
    HAL_PHY_ATEST_MODE_LAST
} HAL_PHY_ATEST_MODE_T;

typedef enum {
    HAL_PHY_EEE_TYPE_DISABLE = 0x0,
    HAL_PHY_EEE_TYPE_ENABLE,
    HAL_PHY_EEE_TYPE_LAST
} HAL_PHY_EEE_TYPE_T;

typedef enum {
    HAL_PHY_EEE_MODE_TYPE_DEEP_SLEEP = 0x0,
    HAL_PHY_EEE_MODE_TYPE_FAST_WAKE,
    HAL_PHY_EEE_MODE_TYPE_LAST
} HAL_PHY_EEE_MODE_TYPE_T;

typedef enum {
    HAL_PHY_FEC_TYPE_DISABLE = 0x0,
    HAL_PHY_FEC_TYPE_ENABLE,
    /* 3 RSFECs: RS528/RS544/RS272 */
    HAL_PHY_FEC_TYPE_RS528,
    HAL_PHY_FEC_TYPE_RS544,
    HAL_PHY_FEC_TYPE_RS272,
    HAL_PHY_FEC_TYPE_RS544_INT,
    HAL_PHY_FEC_TYPE_RS272_INT,
    HAL_PHY_FEC_TYPE_LAST
} HAL_PHY_FEC_TYPE_T;

typedef enum {
    HAL_PHY_FEC_CNT_TYPE_CERR = 0x0,
    HAL_PHY_FEC_CNT_TYPE_UCERR,
    HAL_PHY_FEC_CNT_TYPE_SERR,
    HAL_PHY_FEC_CNT_TYPE_LAST
} HAL_PHY_FEC_CNT_TYPE_T;

typedef struct HAL_PHY_FEC_CNT_S {
    uint64 fec_cerr_codeword;
    uint64 fec_cerr_sym_err[16];
    uint64 fec_ucerr_codeword;
    uint64 fec_ch_sym_err;

#define HAL_PHY_FEC_CNT_CORRECTED_CODEWORDS            (1U << 0)
#define HAL_PHY_FEC_CNT_CORRECTED_SYMBOL_ERROR_COUNTER (1U << 1)
#define HAL_PHY_FEC_CNT_UNCORRECTED_CODEWORDS          (1U << 2)
#define HAL_PHY_FEC_CNT_CH_SYMBOL_ERROR_COUNTER        (1U << 3)
    uint32 fec_type_bmp;
} HAL_PHY_FEC_CNT_T;

typedef enum {
    HAL_PHY_LOOPBACK_TYPE_DISABLE = 0x0,
    HAL_PHY_LOOPBACK_TYPE_LOCAL,
    HAL_PHY_LOOPBACK_TYPE_NEAR_END_PARALLEL, /* parallel loopback, pcs tx -> nep -> pcs rx */
    HAL_PHY_LOOPBACK_TYPE_FAR_END_SERIAL,    /* remote serial loopback, low-speed only support, link
                                                partner -> rx -> fes -> tx -> link partner*/
    HAL_PHY_LOOPBACK_TYPE_FAR_END_PARALLEL,  /* remote parallel loopback, link partner -> rx -> fep
                                                -> tx -> link partner*/
    HAL_PHY_LOOPBACK_TYPE_LAST
} HAL_PHY_LOOPBACK_TYPE_T;

typedef enum {
    HAL_PHY_INTF_LOCATION_TYPE_INTERNAL = 0x0,
    HAL_PHY_INTF_LOCATION_TYPE_EXTERNAL_SYSTEM_SIDE,
    HAL_PHY_INTF_LOCATION_TYPE_EXTERNAL_LINE_SIDE,
    HAL_PHY_INTF_LOCATION_TYPE_LAST
} HAL_PHY_INTF_LOCATION_TYPE_T;

typedef enum {
    HAL_PHY_PMA_INTF_TYPE_NONE = 0x0,
    HAL_PHY_PMA_INTF_TYPE_SGMII,
    HAL_PHY_PMA_INTF_TYPE_XFI,
    HAL_PHY_PMA_INTF_TYPE_SFI,
    HAL_PHY_PMA_INTF_TYPE_KR,
    HAL_PHY_PMA_INTF_TYPE_KR4,
    HAL_PHY_PMA_INTF_TYPE_CR4,
    HAL_PHY_PMA_INTF_TYPE_XLAUI,
    HAL_PHY_PMA_INTF_TYPE_XLPPI,
    HAL_PHY_PMA_INTF_TYPE_CAUI,
    HAL_PHY_PMA_INTF_TYPE_CPPI,
    HAL_PHY_PMA_INTF_TYPE_LAST
} HAL_PHY_PMA_INTF_TYPE_T;

typedef enum {
    HAL_PHY_PMD_INTF_TYPE_SGMII = 0x0,
    HAL_PHY_PMD_INTF_TYPE_X,
    HAL_PHY_PMD_INTF_TYPE_CR,
    HAL_PHY_PMD_INTF_TYPE_KR,
    HAL_PHY_PMD_INTF_TYPE_SR,
    HAL_PHY_PMD_INTF_TYPE_LR,
    HAL_PHY_PMD_INTF_TYPE_ER,
    HAL_PHY_PMD_INTF_TYPE_CR2,
    HAL_PHY_PMD_INTF_TYPE_KR2,
    HAL_PHY_PMD_INTF_TYPE_SR2,
    HAL_PHY_PMD_INTF_TYPE_LR2,
    HAL_PHY_PMD_INTF_TYPE_ER2,
    HAL_PHY_PMD_INTF_TYPE_CR4,
    HAL_PHY_PMD_INTF_TYPE_KR4,
    HAL_PHY_PMD_INTF_TYPE_SR4,
    HAL_PHY_PMD_INTF_TYPE_LR4,
    HAL_PHY_PMD_INTF_TYPE_ER4,
    HAL_PHY_PMD_INTF_TYPE_CR8,
    HAL_PHY_PMD_INTF_TYPE_KR8,
    HAL_PHY_PMD_INTF_TYPE_SR8,
    HAL_PHY_PMD_INTF_TYPE_LR8,
    HAL_PHY_PMD_INTF_TYPE_ER8,
    HAL_PHY_PMD_INTF_TYPE_LAST
} HAL_PHY_PMD_INTF_TYPE_T;

typedef enum {
    HAL_PHY_AN_TARGET_TYPE_SELF = 0x0,
    HAL_PHY_AN_TARGET_TYPE_PEER,
    HAL_PHY_AN_TARGET_TYPE_LAST
} HAL_PHY_AN_TARGET_TYPE_T;

typedef enum {
    HAL_PHY_ANLT_TYPE_DISABLE = 0x0,
    HAL_PHY_ANLT_TYPE_ENABLE,
    HAL_PHY_ANLT_TYPE_ENABLE_LT, /* Link-training only without Auto negotiation */
    HAL_PHY_ANLT_TYPE_LAST
} HAL_PHY_ANLT_TYPE_T;

typedef enum {
    HAL_PHY_AN_RE_AN_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_RE_AN_TYPE_RESTART,
    HAL_PHY_AN_RE_AN_TYPE_LAST
} HAL_PHY_AN_RE_AN_TYPE_T;

typedef enum {
    HAL_PHY_AN_SPEED_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_SPEED_TYPE_1000BASE_KX = (0x1UL << 0),
    HAL_PHY_AN_SPEED_TYPE_10GBASE_KX4 = (0x1UL << 1),
    HAL_PHY_AN_SPEED_TYPE_10GBASE_KR = (0x1UL << 2),
    HAL_PHY_AN_SPEED_TYPE_40GBASE_KR4 = (0x1UL << 3),
    HAL_PHY_AN_SPEED_TYPE_40GBASE_CR4 = (0x1UL << 4),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_CR10 = (0x1UL << 5),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KP4 = (0x1UL << 6),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KR4 = (0x1UL << 7),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_CR4 = (0x1UL << 8),
    HAL_PHY_AN_SPEED_TYPE_25GBASE_KR_CR_S = (0x1UL << 9),
    HAL_PHY_AN_SPEED_TYPE_25GBASE_KR_CR = (0x1UL << 10),
    HAL_PHY_AN_SPEED_TYPE_2G5BASE_KX = (0x1UL << 11),
    HAL_PHY_AN_SPEED_TYPE_5GBASE_KR = (0x1UL << 12),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_KR_CR = (0x1UL << 13),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KR2_CR2 = (0x1UL << 14),
    HAL_PHY_AN_SPEED_TYPE_200GBASE_KR4_CR4 = (0x1UL << 15),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KR_CR = (0x1UL << 16),
    HAL_PHY_AN_SPEED_TYPE_200GBASE_KR2_CR2 = (0x1UL << 17),
    HAL_PHY_AN_SPEED_TYPE_400GBASE_KR4_CR4 = (0x1UL << 18),
    HAL_PHY_AN_SPEED_TYPE_800GBASE_KR8_CR8 = (0x1UL << 19),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_KR2_CR2 = (0x1UL << 20),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_KR2_CONSORTIUM = (0x1UL << 21),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_CR2_CONSORTIUM = (0x1UL << 22),
    HAL_PHY_AN_SPEED_TYPE_400GBASE_CONSORTIUM = (0x1UL << 23),
    HAL_PHY_AN_SPEED_TYPE_LAST = (0x1UL << 24)
} HAL_PHY_AN_SPEED_TYPE_T;

typedef enum {
    HAL_PHY_AN_EEE_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_EEE_TYPE_1000BASE_KX = (0x1UL << 0),
    HAL_PHY_AN_EEE_TYPE_10GBASE_KX4 = (0x1UL << 1),
    HAL_PHY_AN_EEE_TYPE_10GBASE_KR = (0x1UL << 2),
    HAL_PHY_AN_EEE_TYPE_40GBASE_KR4 = (0x1UL << 3),
    HAL_PHY_AN_EEE_TYPE_40GBASE_CR4 = (0x1UL << 4),
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR10 = (0x1UL << 5),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KP4 = (0x1UL << 6),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KR4 = (0x1UL << 7),
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR4 = (0x1UL << 8),
    HAL_PHY_AN_EEE_TYPE_25GBASE_R = (0x1UL << 9), /* NOTE: defined in EEE capability p8023_d3p2 */
    /*defined in section 78 of 8023cd_d3p4*/ /* not confirmed: waiting for SerDes confirmation */
    HAL_PHY_AN_EEE_TYPE_40GBASE_ER4 = (0x1UL << 10),
    HAL_PHY_AN_EEE_TYPE_50GBASE_KR = (0x1UL << 11),
    HAL_PHY_AN_EEE_TYPE_50GBASE_CR = (0x1UL << 12),
    HAL_PHY_AN_EEE_TYPE_50GBASE_SR = (0x1UL << 13),
    HAL_PHY_AN_EEE_TYPE_50GBASE_FR = (0x1UL << 14),
    HAL_PHY_AN_EEE_TYPE_50GBASE_LR = (0x1UL << 15),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KR2 = (0x1UL << 16),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_CR10   = (0x1UL << 17),*/
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR2 = (0x1UL << 17),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_SR10   = (0x1UL << 18),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_100GBASE_SR4 = (0x1UL << 18),
    HAL_PHY_AN_EEE_TYPE_100GBASE_SR2 = (0x1UL << 19),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_DR     = (0x1UL << 21),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_100GBASE_LR4 = (0x1UL << 20),
    HAL_PHY_AN_EEE_TYPE_100GBASE_ER4 = (0x1UL << 21),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_KR4    = (0x1UL << 25),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_CR4    = (0x1UL << 26),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_SR4    = (0x1UL << 27),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_DR4    = (0x1UL << 24),*/ /* Not support */
    /*defined in section 78 of 802d3bs_d3p5*/ /* not comfirmed: wiaitng for SerDes confirmation */
    /*HAL_PHY_AN_EEE_TYPE_200GBASE_DR4    = (0x1UL << 25),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_200GBASE_FR4 = (0x1UL << 22),
    HAL_PHY_AN_EEE_TYPE_200GBASE_LR4 = (0x1UL << 23),
    /*HAL_PHY_AN_EEE_TYPE_400GBASE_LR16   = (0x1UL << 28),*/ /*Not support*/
    /*HAL_PHY_AN_EEE_TYPE_400GBASE_DR4    = (0x1UL << 29),*/ /*Not support*/
    HAL_PHY_AN_EEE_TYPE_400GBASE_FR8 = (0x1UL << 24),
    HAL_PHY_AN_EEE_TYPE_400GBASE_LR8 = (0x1UL << 25),
    HAL_PHY_AN_EEE_TYPE_LAST
} HAL_PHY_AN_EEE_TYPE_T;

typedef enum {
    HAL_PHY_AN_FEC_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_FEC_TYPE_ABILITY = (0x1UL << 0),
    HAL_PHY_AN_FEC_TYPE_REQUEST = (0x1UL << 1),
    HAL_PHY_AN_FEC_TYPE_25G_RS_REQUEST = (0x1UL << 2),
    HAL_PHY_AN_FEC_TYPE_25G_BASER_REQUEST = (0x1UL << 3),
    HAL_PHY_AN_FEC_TYPE_100G_RS_INT_REQUEST = (0x1UL << 4),
    HAL_PHY_AN_FEC_TYPE_LAST
} HAL_PHY_AN_FEC_TYPE_T;

typedef enum {
    HAL_PHY_AN_FC_TYPE_CL37_NO_PAUSE = 0x0,
    HAL_PHY_AN_FC_TYPE_CL73_NO_PAUSE = 0x0,
    HAL_PHY_AN_FC_TYPE_CL37_PAUSE = (0x1UL << 0),
    HAL_PHY_AN_FC_TYPE_CL37_ASM_DIR = (0x1UL << 1),
    HAL_PHY_AN_FC_TYPE_CL73_ASYM_PAUSE = (0x1UL << 2),
    HAL_PHY_AN_FC_TYPE_CL73_SYM_PAUSE = (0x1UL << 3),
    HAL_PHY_AN_FC_TYPE_LAST = (0x1UL << 4)
} HAL_PHY_AN_FC_TYPE_T;

typedef enum {
    HAL_PHY_AN_DUPLEX_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_DUPLEX_TYPE_FULL = (0x1UL << 0),
    HAL_PHY_AN_DUPLEX_TYPE_HALF = (0x1UL << 1),
    HAL_PHY_AN_DUPLEX_TYPE_LAST = (0x1UL << 2)
} HAL_PHY_AN_DUPLEX_TYPE_T;

typedef enum {
    HAL_PHY_AN_RF_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_RF_TYPE_1 = (0x1UL << 0),
    HAL_PHY_AN_RF_TYPE_2 = (0x1UL << 1),
    HAL_PHY_AN_RF_TYPE_LAST = (0x1UL << 2)
} HAL_PHY_AN_RF_TYPE_T;

typedef enum {
    HAL_PHY_EYE_SCAN_TYPE_DIAGRAM = 0x0,
    HAL_PHY_EYE_SCAN_TYPE_BER,
    HAL_PHY_EYE_SCAN_TYPE_LAST
} HAL_PHY_EYE_SCAN_TYPE_T;

typedef enum {
    HAL_PHY_PRBS_PATTERN_TYPE_DISABLE = 0x0,
    HAL_PHY_PRBS_PATTERN_TYPE_7,
    HAL_PHY_PRBS_PATTERN_TYPE_9,
    HAL_PHY_PRBS_PATTERN_TYPE_11,
    HAL_PHY_PRBS_PATTERN_TYPE_13,
    HAL_PHY_PRBS_PATTERN_TYPE_15,
    HAL_PHY_PRBS_PATTERN_TYPE_23,
    HAL_PHY_PRBS_PATTERN_TYPE_31,
    HAL_PHY_PRBS_PATTERN_TYPE_13Q,
    HAL_PHY_PRBS_PATTERN_TYPE_JP03A,
    HAL_PHY_PRBS_PATTERN_TYPE_JP03B,
    HAL_PHY_PRBS_PATTERN_TYPE_LINEARITY_PATTERN,
    HAL_PHY_PRBS_PATTERN_TYPE_FULL_RATE_CLOCK,
    HAL_PHY_PRBS_PATTERN_TYPE_HALF_RATE_CLOCK,
    HAL_PHY_PRBS_PATTERN_TYPE_QUARTER_RATE_CLOCK,
    HAL_PHY_PRBS_PATTERN_TYPE_PATT_32_1S_32_0S,
    HAL_PHY_PRBS_PATTERN_TYPE_SQUARE,
    HAL_PHY_PRBS_PATTERN_TYPE_LAST
} HAL_PHY_PRBS_PATTERN_TYPE_T;

typedef enum {
    HAL_PHY_PRBS_CHECKER_TYPE_DISABLE = 0x0,
    HAL_PHY_PRBS_CHECKER_TYPE_ENABLE,
    HAL_PHY_PRBS_CHECKER_TYPE_LAST
} HAL_PHY_PRBS_CHECKER_TYPE_T;

typedef enum {
    /** PRBS Disable */
    HAL_PHY_PRBS_CONFIG_DISABLE = 0,
    /** Enable both PRBS Transmitter and Receiver */
    HAL_PHY_PRBS_CONFIG_ENABLE_TX_RX,
    /** Enable PRBS Receiver */
    HAL_PHY_PRBS_CONFIG_ENABLE_RX,
    /** Enable PRBS Transmitter */
    HAL_PHY_PRBS_CONFIG_ENABLE_TX,
    HAL_PHY_PRBS_LAST
} HAL_PHY_PRBS_CONFIG_T;

typedef enum {
    HAL_PHY_AN_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_TYPE_ENABLE,
    HAL_PHY_AN_TYPE_LAST
} HAL_PHY_AN_TYPE_T;

typedef enum {
    HAL_PHY_LINK_TRAINING_TYPE_DISABLE = 0x0,
    HAL_PHY_LINK_TRAINING_TYPE_ENABLE,
    HAL_PHY_LINK_TRAINING_TYPE_LAST
} HAL_PHY_LINK_TRAINING_TYPE_T;

typedef enum {
    HAL_PHY_PRBS_BER_TYPE_DISABLE = 0x0,
    HAL_PHY_PRBS_BER_TYPE_BER4,
    HAL_PHY_PRBS_BER_TYPE_BER5,
    HAL_PHY_PRBS_BER_TYPE_BER6,
    HAL_PHY_PRBS_BER_TYPE_LAST
} HAL_PHY_PRBS_BER_TYPE_T;

typedef struct HAL_PHY_PRBS_CHECKER_S {
    HAL_PHY_PRBS_CHECKER_TYPE_T checker_mode;
    HAL_PHY_PRBS_BER_TYPE_T ber_mode;
} HAL_PHY_PRBS_CHECKER_T;

typedef enum {
    HAL_PHY_PRBS_CHKSTS_TYPE_UNLOCK = 0x0,
    HAL_PHY_PRBS_CHKSTS_TYPE_PASS = 0x1,
    HAL_PHY_PRBS_CHKSTS_TYPE_FAIL = 0x3,
    HAL_PHY_PRBS_CHKSTS_TYPE_LAST
} HAL_PHY_PRBS_CHKSTS_TYPE_T;

typedef struct HAL_PHY_PRBS_ERRCNT_S {
    HAL_PHY_PRBS_CHKSTS_TYPE_T cmpsts;
    uint32 errcnt;
} HAL_PHY_PRBS_ERRCNT_T;

typedef enum {
    HAL_PHY_SERDES_DUMP_TYPE_MEM = 0x0,
    HAL_PHY_SERDES_DUMP_TYPE_REG,
    HAL_PHY_SERDES_DUMP_TYPE_COEF,
    HAL_PHY_SERDES_DUMP_TYPE_MSGQ,
    HAL_PHY_SERDES_DUMP_TYPE_LAST
} HAL_PHY_SERDES_DUMP_TYPE_T;

typedef enum {
    HAL_PHY_LED_MODE_TYPE_NORMAL = 0x0,
    HAL_PHY_LED_MODE_TYPE_FORCE,
    HAL_PHY_LED_MODE_TYPE_BIT_ON,
    HAL_PHY_LED_MODE_TYPE_BIT_OFF,
    HAL_PHY_LED_MODE_TYPE_LAST
} HAL_PHY_LED_MODE_TYPE_T;

typedef enum {
    HAL_PHY_LED_STS_TYPE_NORMAL_ON = 0x0,
    HAL_PHY_LED_STS_TYPE_NORMAL_OFF,
    HAL_PHY_LED_STS_TYPE_FORCE_ON,
    HAL_PHY_LED_STS_TYPE_FORCE_OFF,
    HAL_PHY_LED_STS_TYPE_LAST
} HAL_PHY_LED_STS_TYPE_T;

typedef enum {
    HAL_PHY_PROPERTY_TYPE_LANE_SWAP_TX = 0x0,
    HAL_PHY_PROPERTY_TYPE_LANE_SWAP_RX,
    HAL_PHY_PROPERTY_TYPE_POLARITY_REV_TX,
    HAL_PHY_PROPERTY_TYPE_POLARITY_REV_RX,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C0,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C1,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C2,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_CN1,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_CN2,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_CN3,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C3,
    HAL_PHY_PROPERTY_TYPE_REFCLK_ROUTE,
    HAL_PHY_PROPERTY_TYPE_LAST
} HAL_PHY_PROPERTY_TYPE_T;

typedef struct {
#define HAL_PHY_RX_EQ_FLAGS_MLSD           (1UL << 0)
#define HAL_PHY_RX_EQ_FLAGS_CTLERATE       (1UL << 1)
#define HAL_PHY_RX_EQ_FLAGS_CTLEADAPT      (1UL << 2)
#define HAL_PHY_RX_EQ_FLAGS_VGAADAPT       (1UL << 3)
#define HAL_PHY_RX_EQ_FLAGS_ACCBOOST       (1UL << 4)
#define HAL_PHY_RX_EQ_FLAGS_DFE            (1UL << 5)
#define HAL_PHY_RX_EQ_FLAGS_DFERATIO       (1UL << 6)
#define HAL_PHY_RX_EQ_FLAGS_FFETAP         (1UL << 7)
#define HAL_PHY_RX_EQ_FLAGS_CTLECAPADAPT   (1UL << 8)
#define HAL_PHY_RX_EQ_FLAGS_BACKGROUNDADAP (1UL << 9)
#define HAL_PHY_RX_EQ_FLAGS_RXDS           (1UL << 10)
#define HAL_PHY_RX_EQ_FLAGS_AUTOEQ         (1UL << 11)
#define HAL_PHY_RX_EQ_FLAGS_CTLECAPENANT   (1UL << 12)
    uint32 flags;
    uint32 rx_acc_boost;
    uint32 ctle_adapt_enable;
    uint32 ctle_boost_a;
    uint32 ctle_takeover;
    uint32 ctle_takeover_ratio;
    uint32 ctle_rate;
    uint32 vga_adapt_enable;
    uint32 vga_cap;
    uint32 vga_takeover;
    uint32 vga_takeover_ratio;
    uint32 tap_count;
    uint32 dfe_adapt_enable;
    uint32 mlsd_enable;
    uint32 dfe_ratio;
    uint32 ctle_cap_adapt;
    uint32 backgound_adapt_enable;
    uint32 rx_ds;
    uint32 auto_eq_enable;
    uint32 ctle_cap_ena_nt;
} HAL_PHY_RX_EQPARAMS_T;

/*
 * mountain:
 * 'CM3': c(-3) value (pre-cursor 3), up to 7 max, 3b unsigned
 * 'CM2': c(-2) value  (pre-cursor 2), up to 7 max, 3b unsigned
 * 'CM1': c(-1) value  (pre-cursor 1), up to 24 max, 6b unsigned
 * 'C0': c(0) value  (main cursor), up to 60 max, 6b unsigned
 * 'C1': c(1) value  (post-cursor 1), up to 24 max, 6b unsigned
 * 'MAIN_OR_MAX': 0 - c0 is main cursor, 1 - c0 is max elements
 */
typedef struct HAL_PHY_TX_COEF_S {
#define HAL_PHY_TX_COEF_FLAGS_C0  (1UL << 0) /* C0 must the last set coefficient */
#define HAL_PHY_TX_COEF_FLAGS_C1  (1UL << 1)
#define HAL_PHY_TX_COEF_FLAGS_CN1 (1UL << 2)
#define HAL_PHY_TX_COEF_FLAGS_C2  (1UL << 3)
#define HAL_PHY_TX_COEF_FLAGS_CN2 (1UL << 4)
#define HAL_PHY_TX_COEF_FLAGS_CN3 (1UL << 5)
#define HAL_PHY_TX_COEF_FLAGS_C3  (1UL << 6)
    uint32 flags;
    uint32 cn3;
    uint32 cn2;
    uint32 cn1;
    uint32 c0;
    uint32 c1;
    uint32 c2;
    uint32 main_or_max;
    uint32 c3;
} HAL_PHY_TX_COEF_T;

#if defined(CLX_EN_BIG_ENDIAN)
typedef union {
    uint32 value;
    struct {
        uint32 bus : 16;
        uint32 addr : 16;
    } field;
} HAL_PHY_ADDR_T;
#else
typedef union {
    uint32 value;
    struct {
        uint32 addr : 16;
        uint32 bus : 16;
    } field;
} HAL_PHY_ADDR_T;
#endif

typedef enum {
    HAL_PHY_TYPE_INTERNAL = 0x0,
    HAL_PHY_TYPE_EXTERNAL,
    HAL_PHY_TYPE_LAST
} HAL_PHY_TYPE_T;

typedef struct HAL_PMA_LT_DEBUG_S {
    uint32 frame_lock;
    uint32 lt_running;
    uint32 lt_done;
    uint32 lt_training_failure;
    uint32 lt_rx_ready;
    uint32 lt_main_fsm;
    uint32 lt_local_fsm;
    uint32 rxlinkeval_state;
    uint32 lt_iter;
    uint32 linkeval_state;
    uint32 lt_ctrl_fsm;
    uint32 lt_state_train;
    uint32 lt_rx_ctl_init_cond;
    uint32 lt_rx_ctl_mod_pre;
    uint32 lt_rx_ctl_coeff_sel;
    uint32 lt_rx_ctl_coeff_req;
    uint32 incdec_pre1;
    uint32 incdec_c0;
    uint32 incdec_post1;
    uint32 c0_iter_remain;
} HAL_PMA_LT_DEBUG_T;

typedef struct HAL_PMA_VGA_OPT_S {
    uint32 en;
    uint32 vga_cap;
    uint32 use_custom_takeover_ratio;
    uint32 custom_takeover_ratio;
    uint32 custom_nyq_mask;
} HAL_PMA_VGA_OPT_T;

typedef struct HAL_PMA_AFE_DATA_S {
    uint32 ctle_rate;
    uint32 ctle_boost;
    uint32 vga_coarse;
    uint32 vga_fine;
    uint32 vga_offset;
} HAL_PMA_AFE_DATA_T;

typedef struct HAL_PMA_LT_S {
    HAL_PMA_LT_DEBUG_T lt_status;
    HAL_PHY_TX_COEF_T txfir_cfg;
    HAL_PMA_VGA_OPT_T opts;
    HAL_PMA_AFE_DATA_T rx_afe_data;
} HAL_PMA_LT_T;

typedef struct {
    clx_error_no_t (*hal_phy_init)(const uint32 unit);
    clx_error_no_t (*hal_phy_deinit)(const uint32 unit);
    clx_error_no_t (*hal_phy_port_init)(const uint32 unit, const uint32 port_id);
    clx_error_no_t (*hal_phy_port_deinit)(const uint32 unit, const uint32 port_id);

    clx_error_no_t (*hal_phy_admin_state_set)(const uint32 unit,
                                              const uint32 port_id,
                                              const HAL_PHY_ADMIN_STATE_TYPE_T admin_state);
    clx_error_no_t (*hal_phy_admin_state_get)(const uint32 unit,
                                              const uint32 port_id,
                                              HAL_PHY_ADMIN_STATE_TYPE_T *hal_phy_ptr_admin_state);

    clx_error_no_t (*hal_phy_link_state_get)(const uint32 unit,
                                             const uint32 port_id,
                                             HAL_PHY_LINK_STATE_TYPE_T *hal_phy_ptr_link_state);

    clx_error_no_t (*hal_phy_speed_set)(const uint32 unit,
                                        const uint32 port_id,
                                        const HAL_PHY_SPEED_TYPE_T speed);
    clx_error_no_t (*hal_phy_speed_get)(const uint32 unit,
                                        const uint32 port_id,
                                        HAL_PHY_SPEED_TYPE_T *hal_phy_ptr_speed);

    clx_error_no_t (*hal_phy_eee_set)(const uint32 unit,
                                      const uint32 port_id,
                                      const HAL_PHY_EEE_TYPE_T eee);
    clx_error_no_t (*hal_phy_eee_get)(const uint32 unit,
                                      const uint32 port_id,
                                      HAL_PHY_EEE_TYPE_T *hal_phy_ptr_eee);

    clx_error_no_t (*hal_phy_eee_mode_set)(const uint32 unit,
                                           const uint32 port_id,
                                           const HAL_PHY_EEE_MODE_TYPE_T eee_mode);
    clx_error_no_t (*hal_phy_eee_mode_get)(const uint32 unit,
                                           const uint32 port_id,
                                           HAL_PHY_EEE_MODE_TYPE_T *hal_phy_ptr_eee_mode);

    clx_error_no_t (*hal_phy_fec_set)(const uint32 unit,
                                      const uint32 port_id,
                                      const HAL_PHY_FEC_TYPE_T fec);
    clx_error_no_t (*hal_phy_fec_get)(const uint32 unit,
                                      const uint32 port_id,
                                      HAL_PHY_FEC_TYPE_T *hal_phy_ptr_fec);

    clx_error_no_t (*hal_phy_lb_set)(const uint32 unit,
                                     const uint32 port_id,
                                     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                     const HAL_PHY_LOOPBACK_TYPE_T loopback);
    clx_error_no_t (*hal_phy_lb_get)(const uint32 unit,
                                     const uint32 port_id,
                                     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                     HAL_PHY_LOOPBACK_TYPE_T *hal_phy_ptr_loopback);

    clx_error_no_t (*hal_phy_pma_intf_set)(const uint32 unit,
                                           const uint32 port_id,
                                           const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                           const HAL_PHY_PMA_INTF_TYPE_T pma_intf);
    clx_error_no_t (*hal_phy_pma_intf_get)(const uint32 unit,
                                           const uint32 port_id,
                                           const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                           HAL_PHY_PMA_INTF_TYPE_T *hal_phy_ptr_pma_intf);

    clx_error_no_t (*hal_phy_pmd_intf_set)(const uint32 unit,
                                           const uint32 port_id,
                                           const HAL_PHY_PMD_INTF_TYPE_T pmd_intf);
    clx_error_no_t (*hal_phy_pmd_intf_get)(const uint32 unit,
                                           const uint32 port_id,
                                           HAL_PHY_PMD_INTF_TYPE_T *hal_phy_ptr_pmd_intf);

    clx_error_no_t (*hal_phy_an_set)(const uint32 unit,
                                     const uint32 port_id,
                                     const HAL_PHY_ANLT_TYPE_T an);
    clx_error_no_t (*hal_phy_an_get)(const uint32 unit,
                                     const uint32 port_id,
                                     HAL_PHY_ANLT_TYPE_T *hal_phy_ptr_an);

    clx_error_no_t (*hal_phy_an_restart_set)(const uint32 unit,
                                             const uint32 port_id,
                                             const HAL_PHY_AN_RE_AN_TYPE_T an_restart);
    clx_error_no_t (*hal_phy_an_restart_get)(const uint32 unit,
                                             const uint32 port_id,
                                             HAL_PHY_AN_RE_AN_TYPE_T *hal_phy_ptr_an_restart);

    clx_error_no_t (*hal_phy_an_speed_set)(const uint32 unit,
                                           const uint32 port_id,
                                           const HAL_PHY_AN_SPEED_TYPE_T an_speed);
    clx_error_no_t (*hal_phy_an_speed_get)(const uint32 unit,
                                           const uint32 port_id,
                                           const HAL_PHY_AN_TARGET_TYPE_T an_target,
                                           HAL_PHY_AN_SPEED_TYPE_T *hal_phy_ptr_an_speed);

    clx_error_no_t (*hal_phy_an_eee_set)(const uint32 unit,
                                         const uint32 port_id,
                                         const HAL_PHY_AN_EEE_TYPE_T an_eee);
    clx_error_no_t (*hal_phy_an_eee_get)(const uint32 unit,
                                         const uint32 port_id,
                                         const HAL_PHY_AN_TARGET_TYPE_T an_target,
                                         HAL_PHY_AN_EEE_TYPE_T *hal_phy_ptr_an_eee);

    clx_error_no_t (*hal_phy_an_fec_set)(const uint32 unit,
                                         const uint32 port_id,
                                         const HAL_PHY_AN_FEC_TYPE_T an_fec);
    clx_error_no_t (*hal_phy_an_fec_get)(const uint32 unit,
                                         const uint32 port_id,
                                         const HAL_PHY_AN_TARGET_TYPE_T an_target,
                                         HAL_PHY_AN_FEC_TYPE_T *hal_phy_ptr_an_fec);

    clx_error_no_t (*hal_phy_an_fc_set)(const uint32 unit,
                                        const uint32 port_id,
                                        const HAL_PHY_AN_FC_TYPE_T an_fc);
    clx_error_no_t (*hal_phy_an_fc_get)(const uint32 unit,
                                        const uint32 port_id,
                                        const HAL_PHY_AN_TARGET_TYPE_T an_target,
                                        HAL_PHY_AN_FC_TYPE_T *hal_phy_ptr_an_fc);

    clx_error_no_t (*hal_phy_an_duplex_set)(const uint32 unit,
                                            const uint32 port_id,
                                            const HAL_PHY_AN_DUPLEX_TYPE_T an_duplex);
    clx_error_no_t (*hal_phy_an_duplex_get)(const uint32 unit,
                                            const uint32 port_id,
                                            const HAL_PHY_AN_TARGET_TYPE_T an_target,
                                            HAL_PHY_AN_DUPLEX_TYPE_T *hal_phy_ptr_an_duplex);

    clx_error_no_t (*hal_phy_an_rf_set)(const uint32 unit,
                                        const uint32 port_id,
                                        const HAL_PHY_AN_RF_TYPE_T an_rf);
    clx_error_no_t (*hal_phy_an_rf_get)(const uint32 unit,
                                        const uint32 port_id,
                                        const HAL_PHY_AN_TARGET_TYPE_T an_target,
                                        HAL_PHY_AN_RF_TYPE_T *hal_phy_ptr_an_rf);

    clx_error_no_t (*hal_phy_cfg_set)(const uint32 unit,
                                      const uint32 port_id,
                                      const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                      const clx_port_phy_cfg_t *hal_phy_ptr_config);
    clx_error_no_t (*hal_phy_cfg_get)(const uint32 unit,
                                      const uint32 port_id,
                                      const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                      clx_port_phy_cfg_t *hal_phy_ptr_config);
    clx_error_no_t (*hal_phy_mdio_reg_set)(const uint32 unit,
                                           const uint32 port_id,
                                           const HAL_PHY_TYPE_T phy_type,
                                           const uint32 dev_type,
                                           const uint32 reg_addr,
                                           const uint32 reg);
    clx_error_no_t (*hal_phy_mdio_reg_get)(const uint32 unit,
                                           const uint32 port_id,
                                           const HAL_PHY_TYPE_T phy_type,
                                           const uint32 dev_type,
                                           const uint32 reg_addr,
                                           uint32 *hal_phy_ptr_reg);
    clx_error_no_t (*hal_phy_temp_get)(const uint32 unit,
                                       const uint32 port_id,
                                       int32 *hal_phy_ptr_temp);

    clx_error_no_t (*hal_phy_eye_scan_dump)(const uint32 unit,
                                            const uint32 port_id,
                                            const uint32 lane_cnt,
                                            const HAL_PHY_EYE_SCAN_TYPE_T property,
                                            const uint32 sample_deep);

    clx_error_no_t (*hal_phy_prbs_pattern_set)(const uint32 unit,
                                               const uint32 port_id,
                                               const HAL_PHY_PRBS_PATTERN_TYPE_T prbs_pattern);

    clx_error_no_t (*hal_phy_prbs_pattern_get)(
        const uint32 unit,
        const uint32 port_id,
        HAL_PHY_PRBS_PATTERN_TYPE_T *hal_phy_ptr_prbs_pattern);

    clx_error_no_t (*hal_phy_prbs_checker_set)(const uint32 unit,
                                               const uint32 port_id,
                                               const HAL_PHY_PRBS_CHECKER_TYPE_T prbs_checker,
                                               const uint32 ber_mode);

    clx_error_no_t (*hal_phy_prbs_checker_get)(
        const uint32 unit,
        const uint32 port_id,
        HAL_PHY_PRBS_CHECKER_TYPE_T *hal_phy_ptr_prbs_checker);

    clx_error_no_t (*hal_phy_prbs_generator_set)(const uint32 unit,
                                                 const uint32 port_id,
                                                 HAL_PHY_PRBS_CONFIG_T prbs_gen);

    clx_error_no_t (*hal_phy_prbs_generator_get)(const uint32 unit,
                                                 const uint32 port_id,
                                                 HAL_PHY_PRBS_CONFIG_T *hal_phy_prbs_gen);

    clx_error_no_t (*hal_phy_prbs_error_cnt_get)(const uint32 unit,
                                                 const uint32 port_id,
                                                 const uint32 lane_bmp,
                                                 HAL_PHY_PRBS_BER_TYPE_T *hal_phy_ptr_ber_mode,
                                                 HAL_PHY_PRBS_ERRCNT_T *hal_phy_ptr_error_cnt);

    clx_error_no_t (*hal_phy_led_bit_set)(const uint32 unit,
                                          const uint32 led_id,
                                          const uint32 bit_id,
                                          const uint32 *hal_phy_ptr_led_mode);

    clx_error_no_t (*hal_phy_led_bit_get)(const uint32 unit,
                                          const uint32 led_id,
                                          const uint32 bit_id,
                                          uint32 *hal_phy_ptr_led_mode);

    clx_error_no_t (*hal_phy_mdio_clk_rate_set)(const uint32 unit,
                                                const uint32 chn_id,
                                                const uint32 rate_khz);

    clx_error_no_t (*hal_phy_addr_set)(const uint32 unit,
                                       const uint32 port_id,
                                       const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                       HAL_PHY_ADDR_T phy_addr);

    clx_error_no_t (*hal_phy_addr_get)(const uint32 unit,
                                       const uint32 port_id,
                                       const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                       HAL_PHY_ADDR_T *hal_phy_ptr_phy_addr);

    clx_error_no_t (*hal_phy_serdes_info_dump)(const uint32 unit,
                                               const uint32 port_id,
                                               const uint32 lane_bmp,
                                               const HAL_PHY_SERDES_DUMP_TYPE_T dump_type,
                                               const uint32 more);

    clx_error_no_t (*hal_phy_tx_coef_set)(const uint32 unit,
                                          const uint32 port_id,
                                          const uint32 lane_id,
                                          const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                          HAL_PHY_TX_COEF_T *hal_phy_ptr_tx_coef);

    clx_error_no_t (*hal_phy_tx_coef_get)(const uint32 unit,
                                          const uint32 port_id,
                                          const uint32 lane_id,
                                          const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                                          HAL_PHY_TX_COEF_T *hal_phy_ptr_tx_coef);

    clx_error_no_t (*hal_phy_mxlink_set)(const uint32 unit,
                                         const uint32 port_id,
                                         const uint32 enable);

    clx_error_no_t (*hal_phy_mxlink_get)(const uint32 unit,
                                         const uint32 port_id,
                                         uint32 *hal_phy_ptr_enable);

    clx_error_no_t (*hal_phy_fec_cnt_get)(const uint32 unit,
                                          const uint32 port_id,
                                          HAL_PHY_FEC_CNT_T *hal_phy_ptr_cnt);

    clx_error_no_t (*hal_phy_fec_cnt_clear)(const uint32 unit,
                                            const uint32 port_id,
                                            const uint32 land_id,
                                            const HAL_PHY_FEC_CNT_TYPE_T cnt_type);

    clx_error_no_t (*hal_phy_prbs_err_inject)(const uint32 unit,
                                              const uint32 port_id,
                                              const uint32 num_err);

    clx_error_no_t (*hal_phy_prbs_err_cnt_clear_set)(const uint32 unit,
                                                     const uint32 port_id,
                                                     const uint32 lane_bmp);

    clx_error_no_t (*hal_phy_fw_version_get)(const uint32 unit,
                                             const uint32 port_id,
                                             uint32 *hal_phy_version_eth,
                                             uint32 *hal_phy_version_cpi);

    clx_error_no_t (*hal_phy_rxeq_tunning_set)(const uint32 unit,
                                               const uint32 port_id,
                                               const uint32 lane_bmp,
                                               const uint32 phase);

    clx_error_no_t (*hal_phy_rate_get)(const uint32 unit,
                                       const uint32 port_id,
                                       uint32 *hal_phy_rate);

    clx_error_no_t (*hal_phy_isola_mode_set)(const uint32 unit,
                                             const uint32 port_id,
                                             const uint32 lane_bmp,
                                             const uint32 enable);

    clx_error_no_t (*hal_phy_txrx_powerup_set)(const uint32 unit,
                                               const uint32 port_id,
                                               const uint32 lane_bmp,
                                               const HAL_PHY_POWERUP_MODULE_TYPE_T module,
                                               const HAL_PHY_LANE_SPEED_TYPE_T pma_speed);

    clx_error_no_t (*hal_phy_tx_elecidle_set)(const uint32 unit,
                                              const uint32 port_id,
                                              const uint32 enable);

    clx_error_no_t (*hal_phy_tx_elecidle_get)(const uint32 unit,
                                              const uint32 port_id,
                                              uint32 *hal_phy_ptr_enable);

    clx_error_no_t (*hal_phy_rx_term_set)(const uint32 unit,
                                          const uint32 port_id,
                                          const uint32 lane_bmp,
                                          const HAL_PHY_ACC_TERM_MODE_T mode);

    clx_error_no_t (*hal_phy_rx_term_get)(const uint32 unit,
                                          const uint32 port_id,
                                          HAL_PHY_ACC_TERM_MODE_T *hal_phy_ptr_mode);

    clx_error_no_t (*hal_phy_rxeq_set)(const uint32 unit,
                                       const uint32 port_id,
                                       const uint32 lane_id,
                                       HAL_PHY_RX_EQPARAMS_T *hal_phy_ptr_rxeq_config);

    clx_error_no_t (*hal_phy_rxeq_get)(const uint32 unit,
                                       const uint32 port_id,
                                       const uint32 lane_id,
                                       HAL_PHY_RX_EQPARAMS_T *hal_phy_ptr_rxeq_config);

    clx_error_no_t (*hal_phy_rxeq_update)(const uint32 unit, const uint32 port_id);

    clx_error_no_t (*hal_phy_fw_reload)(const uint32 unit, const uint32 port_id);

    clx_error_no_t (*hal_phy_reg_read)(const uint32 unit,
                                       const uint32 port_id,
                                       const uint32 lane_id,
                                       uint32 reg_addr);

    clx_error_no_t (*hal_phy_reg_write)(const uint32 unit,
                                        const uint32 port_id,
                                        const uint32 lane_id,
                                        uint32 reg_addr,
                                        const uint32 value);

    clx_error_no_t (*hal_phy_atest_pmon_get)(const uint32 unit,
                                             const uint32 port_id,
                                             const uint32 lane_id,
                                             const uint32 test_mode);

    clx_error_no_t (*hal_phy_rx_snr_get)(const uint32 unit,
                                         const uint32 port_id,
                                         uint32 *ptr_snr_int,
                                         uint32 *ptr_snr_dec);

    clx_error_no_t (*hal_phy_anlt_status_get)(const uint32 unit,
                                              const uint32 port_id,
                                              const uint32 lane_id,
                                              uint32 *ptr_anlt_status);
    clx_error_no_t (*hal_phy_lt_state_get)(const uint32 unit,
                                           const uint32 port_id,
                                           const uint32 lane_id,
                                           uint32 *lt_done,
                                           HAL_PMA_LT_T *lt_stat);

    clx_error_no_t (*hal_phy_tx_signal_set)(const uint32 unit,
                                            const uint32 port_id,
                                            const uint32 enable);
    clx_error_no_t (*hal_phy_tx_signal_get)(const uint32 unit,
                                            const uint32 port_id,
                                            uint32 *ptr_enable);
    clx_error_no_t (*hal_phy_tx_signal_register)(const uint32 unit,
                                                 clx_port_phy_notify_func_t func,
                                                 void *ptr_cookie);
    clx_error_no_t (*hal_phy_tx_signal_deregister)(const uint32 unit,
                                                   clx_port_phy_notify_func_t func,
                                                   void *ptr_cookie);
} HAL_PHY_FUNC_VEC_T;

#if defined(CLX_EN_BIG_ENDIAN)
typedef union {
    uint32 value;
    struct {
        uint32 oui : 22;
        uint32 model : 6;
        uint32 revision : 4;
    } field;
} HAL_PHY_DEVICE_ID_T;
#else
typedef union {
    uint32 value;
    struct {
        uint32 revision : 4;
        uint32 model : 6;
        uint32 oui : 22;
    } field;
} HAL_PHY_DEVICE_ID_T;
#endif

typedef struct {
    HAL_PHY_FUNC_VEC_T *ptr_driver;
    HAL_PHY_DEVICE_ID_T device_id;
    uint32 device_id_mask;
} HAL_EXT_PHY_DEVICE_T;

typedef struct {
    HAL_PHY_FUNC_VEC_T *driver[HAL_PHY_TYPE_LAST];
    boolean known_device[HAL_PHY_TYPE_LAST];
} HAL_PHY_DRIVER_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Init the PHY drive per unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_init(const uint32 unit);

/**
 * @brief Deinit PHY driver per unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_deinit(const uint32 unit);

/**
 * @brief Probe the port and init itself.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_port_probe(const uint32 unit, const uint32 port_id);

/**
 * @brief Remove the port and deinit itself.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_port_remove(const uint32 unit, const uint32 port_id);

clx_error_no_t
hal_phy_tx_signal_set(const uint32 unit, const uint32 port_id, const uint32 enable);

clx_error_no_t
hal_phy_tx_signal_get(const uint32 unit, const uint32 port_id, uint32 *ptr_enable);

clx_error_no_t
hal_phy_tx_signal_register(const uint32 unit, clx_port_phy_notify_func_t func, void *ptr_cookie);

clx_error_no_t
hal_phy_tx_signal_deregister(const uint32 unit, clx_port_phy_notify_func_t func, void *ptr_cookie);

/**
 * @brief Set admin state to enable or disable.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port_id        - Device port number.
 * @param [in]    admin_state    - Port admin state.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_admin_state_set(const uint32 unit,
                        const uint32 port_id,
                        const HAL_PHY_ADMIN_STATE_TYPE_T admin_state);

/**
 * @brief Get admin state.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port_id            - Device port number.
 * @param [out]    ptr_admin_state    - Port admin state.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_admin_state_get(const uint32 unit,
                        const uint32 port_id,
                        HAL_PHY_ADMIN_STATE_TYPE_T *ptr_admin_state);

/**
 * @brief Get link state.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port_id           - Device port number.
 * @param [out]    ptr_link_state    - Port link state.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_link_state_get(const uint32 unit,
                       const uint32 port_id,
                       HAL_PHY_LINK_STATE_TYPE_T *ptr_link_state);

/**
 * @brief Set speed.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    speed      - Port speed.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_speed_set(const uint32 unit, const uint32 port_id, const HAL_PHY_SPEED_TYPE_T speed);

/**
 * @brief Get speed.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port_id      - Device port number.
 * @param [out]    ptr_speed    - Port speed.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_speed_get(const uint32 unit, const uint32 port_id, HAL_PHY_SPEED_TYPE_T *ptr_speed);

/**
 * @brief Set EEE(Energy-Efficient Ethernet) ability.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    eee        - EEE ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_eee_set(const uint32 unit, const uint32 port_id, const HAL_PHY_EEE_TYPE_T eee);

/**
 * @brief Get EEE(Energy-Efficient Ethernet) ability.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port_id    - Device port number.
 * @param [out]    ptr_eee    - EEE ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_eee_get(const uint32 unit, const uint32 port_id, HAL_PHY_EEE_TYPE_T *ptr_eee);

/**
 * @brief Set EEE(Energy-Efficient Ethernet) mode as deep-sleep or fast-wakeup.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    eee_mode    - EEE mode.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_eee_mode_set(const uint32 unit,
                     const uint32 port_id,
                     const HAL_PHY_EEE_MODE_TYPE_T eee_mode);

/**
 * @brief Get EEE(Energy-Efficient Ethernet) mode.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port_id         - Device port number.
 * @param [out]    ptr_eee_mode    - EEE mode.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_eee_mode_get(const uint32 unit,
                     const uint32 port_id,
                     HAL_PHY_EEE_MODE_TYPE_T *ptr_eee_mode);

/**
 * @brief Set FEC(Forward Error Correction) ability.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    fec        - FEC ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_fec_set(const uint32 unit, const uint32 port_id, const HAL_PHY_FEC_TYPE_T fec);

/**
 * @brief Get FEC(Forward Error Correction) ability.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port_id    - Device port number.
 * @param [out]    ptr_fec    - FEC ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_fec_get(const uint32 unit, const uint32 port_id, HAL_PHY_FEC_TYPE_T *ptr_fec);

/**
 * @brief Set local loopback ability to enable or disable it.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port_id          - Device port number.
 * @param [in]    intf_location    - Where the loopback interface locates.
 * @param [in]    loopback         - Loopback ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_lb_set(const uint32 unit,
               const uint32 port_id,
               const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
               const HAL_PHY_LOOPBACK_TYPE_T loopback);

/**
 * @brief Get local loopback ability.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port_id          - Device port number.
 * @param [in]     intf_location    - Where the loopback interface locates.
 * @param [out]    ptr_loopback     - Loopback ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_lb_get(const uint32 unit,
               const uint32 port_id,
               const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
               HAL_PHY_LOOPBACK_TYPE_T *ptr_loopback);

/**
 * @brief Set the type of PMA interface.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port_id          - Device port number.
 * @param [in]    intf_location    - Where the interface locates.
 * @param [in]    pma_intf         - Type of PMA interface.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_pma_intf_set(const uint32 unit,
                     const uint32 port_id,
                     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                     const HAL_PHY_PMA_INTF_TYPE_T pma_intf);

/**
 * @brief Get the type of PMA interface.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port_id          - Device port number.
 * @param [in]     intf_location    - Where the interface locates.
 * @param [out]    ptr_pma_intf     - Type of PMA interface.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_pma_intf_get(const uint32 unit,
                     const uint32 port_id,
                     const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                     HAL_PHY_PMA_INTF_TYPE_T *ptr_pma_intf);

/**
 * @brief Set the type of PMD interface.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    pmd_intf    - Type of PMD interface.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_pmd_intf_set(const uint32 unit,
                     const uint32 port_id,
                     const HAL_PHY_PMD_INTF_TYPE_T pmd_intf);

/**
 * @brief Get the type of PMD interface.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port_id         - Device port number.
 * @param [out]    ptr_pmd_intf    - Type of PMD interface.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_pmd_intf_get(const uint32 unit,
                     const uint32 port_id,
                     HAL_PHY_PMD_INTF_TYPE_T *ptr_pmd_intf);

/**
 * @brief Set AN(Auto-Negotiation) ability to enable or disable.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    anlt       - ANLT/LT/DISABLE.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_anlt_set(const uint32 unit, const uint32 port_id, const HAL_PHY_ANLT_TYPE_T anlt);

/**
 * @brief Get AN(Auto-Negotiation) ability.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port_id     - Device port number.
 * @param [out]    ptr_anlt    - ANLT/LT/DISABLE.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_anlt_get(const uint32 unit, const uint32 port_id, HAL_PHY_ANLT_TYPE_T *ptr_anlt);

/**
 * @brief Set Re-AN(Auto-Negotiation) ability to restart or disable.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port_id       - Device port number.
 * @param [in]    an_restart    - Re-AN ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_restart_set(const uint32 unit,
                       const uint32 port_id,
                       const HAL_PHY_AN_RE_AN_TYPE_T an_restart);

/**
 * @brief Get Re-AN(Auto-Negotiation) ability.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     port_id           - Device port number.
 * @param [out]    ptr_an_restart    - Re-AN ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_restart_get(const uint32 unit,
                       const uint32 port_id,
                       HAL_PHY_AN_RE_AN_TYPE_T *ptr_an_restart);

/**
 * @brief Set AN speed ability.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    an_speed    - AN speed ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_speed_set(const uint32 unit,
                     const uint32 port_id,
                     const HAL_PHY_AN_SPEED_TYPE_T an_speed);

/**
 * @brief Get AN speed ability.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     port_id         - Device port number.
 * @param [in]     an_target       - The target of AN ability such as local or remote peer.
 * @param [out]    ptr_an_speed    - AN speed ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_speed_get(const uint32 unit,
                     const uint32 port_id,
                     const HAL_PHY_AN_TARGET_TYPE_T an_target,
                     HAL_PHY_AN_SPEED_TYPE_T *ptr_an_speed);

/**
 * @brief Set AN EEE ability.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    an_eee     - AN EEE ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_eee_set(const uint32 unit, const uint32 port_id, const HAL_PHY_AN_EEE_TYPE_T an_eee);

/**
 * @brief Get AN EEE ability.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port_id       - Device port number.
 * @param [in]     an_target     - The target of AN ability such as local or remote peer.
 * @param [out]    ptr_an_eee    - AN EEE ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_eee_get(const uint32 unit,
                   const uint32 port_id,
                   const HAL_PHY_AN_TARGET_TYPE_T an_target,
                   HAL_PHY_AN_EEE_TYPE_T *ptr_an_eee);

/**
 * @brief Set AN FEC ability.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    an_fec     - AN FEC ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_fec_set(const uint32 unit, const uint32 port_id, const HAL_PHY_AN_FEC_TYPE_T an_fec);

/**
 * @brief Get AN FEC ability.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port_id       - Device port number.
 * @param [in]     an_target     - The target of AN ability such as local or remote peer.
 * @param [out]    ptr_an_fec    - AN FEC ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_fec_get(const uint32 unit,
                   const uint32 port_id,
                   const HAL_PHY_AN_TARGET_TYPE_T an_target,
                   HAL_PHY_AN_FEC_TYPE_T *ptr_an_fec);

/**
 * @brief Set AN flow control ability.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    an_fc      - AN flow control ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_fc_set(const uint32 unit, const uint32 port_id, const HAL_PHY_AN_FC_TYPE_T an_fc);

/**
 * @brief Get AN flow control ability.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port_id      - Device port number.
 * @param [in]     an_target    - The target of AN ability such as local or remote peer.
 * @param [out]    ptr_an_fc    - AN flow control ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_fc_get(const uint32 unit,
                  const uint32 port_id,
                  const HAL_PHY_AN_TARGET_TYPE_T an_target,
                  HAL_PHY_AN_FC_TYPE_T *ptr_an_fc);

/**
 * @brief Set AN Duplex ability.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port_id      - Device port number.
 * @param [in]    an_duplex    - AN duplex ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_duplex_set(const uint32 unit,
                      const uint32 port_id,
                      const HAL_PHY_AN_DUPLEX_TYPE_T an_duplex);

/**
 * @brief Get AN duplex ability.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port_id          - Device port number.
 * @param [in]     an_target        - The target of AN ability such as local or remote peer.
 * @param [out]    ptr_an_duplex    - AN duplex ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_duplex_get(const uint32 unit,
                      const uint32 port_id,
                      const HAL_PHY_AN_TARGET_TYPE_T an_target,
                      HAL_PHY_AN_DUPLEX_TYPE_T *ptr_an_duplex);

/**
 * @brief Set AN remote-fault ability.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    an_rf      - AN remote fault ability.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_rf_set(const uint32 unit, const uint32 port_id, const HAL_PHY_AN_RF_TYPE_T an_rf);

/**
 * @brief Get AN remote-fault ability.
 *
 * @param [in]     unit         - Device unit number.
 * @param [in]     port_id      - Device port number.
 * @param [in]     an_target    - The target of AN ability such as local or remote peer.
 * @param [out]    ptr_an_rf    - AN remote-fault ability.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_an_rf_get(const uint32 unit,
                  const uint32 port_id,
                  const HAL_PHY_AN_TARGET_TYPE_T an_target,
                  HAL_PHY_AN_RF_TYPE_T *ptr_an_rf);

/**
 * @brief Set phy config such as lane-swap, polarity-reversion and tx-coefficient.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port_id          - Device port number.
 * @param [in]    location_type    - Where the interface locates.
 * @param [in]    ptr_config       - PHY config.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_cfg_set(const uint32 unit,
                const uint32 port_id,
                const HAL_PHY_INTF_LOCATION_TYPE_T location_type,
                const clx_port_phy_cfg_t *ptr_config);

/**
 * @brief Get phy config such as lane-swap, polarity-reversion and tx-coefficient.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port_id          - Device port number.
 * @param [in]    intf_location    - Where the interface locates.
 * @param [in]    ptr_config       - PHY config.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_cfg_get(const uint32 unit,
                const uint32 port_id,
                const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                clx_port_phy_cfg_t *ptr_config);

/**
 * @brief Set all tx coefficients (CN2, CN1, C0, C1, C2) for a specific lane Note 1: different
 *        switch family supports different coefficient number Note 2: when summation of coefficient
 *        is overflow, C0 got reduction Note 3: partial coefficients configuration is allowed
 *        (flags within struct config is necessary).
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port_id          - Device port number.
 * @param [in]    lane_id          - Lane offset inside the port.
 * @param [in]    intf_location    - Where the interface locates.
 * @param [in]    ptr_tx_coef      - The tx coefficients applied to the specific lane.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_tx_coef_set(const uint32 unit,
                    const uint32 port_id,
                    const uint32 lane_id,
                    const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                    HAL_PHY_TX_COEF_T *ptr_tx_coef);

/**
 * @brief Get all tx coefficients (CN2, CN1, C0, C1, C2) for a spceific lane Note 1: different
 *        switch family supports different coefficient number Note 2: flags within the struct
 *        indicates the coefficients supported in this switch family.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port_id          - Device port number.
 * @param [in]     lane_id          - Lane offset inside the port.
 * @param [in]     intf_location    - Where the interface locates.
 * @param [out]    ptr_tx_coef      - The tx coefficients applied to the specific lane.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_tx_coef_get(const uint32 unit,
                    const uint32 port_id,
                    const uint32 lane_id,
                    const HAL_PHY_INTF_LOCATION_TYPE_T intf_location,
                    HAL_PHY_TX_COEF_T *ptr_tx_coef);

/**
 * @brief Get temperature of external PHY.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port_id     - Device port number.
 * @param [out]    ptr_temp    - Temperature of enternal PHY.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_temp_get(const uint32 unit, const uint32 port_id, int32 *ptr_temp);

/**
 * @brief Dump eye scan result.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    port_id        - Device port number.
 * @param [in]    lane_cnt       - Lane count within the port.
 * @param [in]    property       - Optional perperty setting.
 * @param [in]    sample_deep    - Sample deep.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_eye_scan_dump(const uint32 unit,
                      const uint32 port_id,
                      const uint32 lane_cnt,
                      const HAL_PHY_EYE_SCAN_TYPE_T property,
                      const uint32 sample_deep);

/**
 * @brief Set the PRBS test pattern.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port_id         - Device port number.
 * @param [in]    prbs_pattern    - Test pattern on PRBS.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_prbs_pattern_set(const uint32 unit,
                         const uint32 port_id,
                         const HAL_PHY_PRBS_PATTERN_TYPE_T prbs_pattern);

/**
 * @brief Get the PRBS test pattern.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port_id             - Device port number.
 * @param [out]    ptr_prbs_pattern    - Test pattern on PRBS.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_prbs_pattern_get(const uint32 unit,
                         const uint32 port_id,
                         HAL_PHY_PRBS_PATTERN_TYPE_T *ptr_prbs_pattern);

/**
 * @brief Enable/disable the PRBS test checker.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    port_id         - Device port number.
 * @param [in]    prbs_checker    - Enable/Disable checke.
 * @param [in]    ber_mode        - Enable/Disable ber mode.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_prbs_checker_set(const uint32 unit,
                         const uint32 port_id,
                         const HAL_PHY_PRBS_CHECKER_TYPE_T prbs_checker,
                         const uint32 ber_mode);

/**
 * @brief Get the PRBS test checker status (enable/disable).
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     port_id             - Device port number.
 * @param [out]    ptr_prbs_checker    - Test checker status (enable/disable).
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_prbs_checker_get(const uint32 unit,
                         const uint32 port_id,
                         HAL_PHY_PRBS_CHECKER_TYPE_T *ptr_prbs_checker);

/**
 * @brief Get the PRBS checker error count.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port_id          - Device port number.
 * @param [in]     lane_bmp         - Specify the lanes to report prbs error cnt.
 * @param [out]    ptr_ber_mode     - For PAM4/NRZ PRBS, ber_mode is enable/disable.
 * @param [out]    ptr_error_cnt    - Error bit counter (including lock sts + error counter).
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_prbs_error_cnt_get(const uint32 unit,
                           const uint32 port_id,
                           const uint32 lane_bmp,
                           HAL_PHY_PRBS_BER_TYPE_T *ptr_ber_mode,
                           HAL_PHY_PRBS_ERRCNT_T *ptr_error_cnt);

/**
 * @brief Dump serdes internal information.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    port_id      - Device port number.
 * @param [in]    lane_bmp     - Focus the lane list within the port (started from 0).
 * @param [in]    dump_type    - HAL_PHY_SERDES_DUMP_TYPE_MEM/ HAL_PHY_SERDES_DUMP_TYPE_REG/
 *                               HAL_PHY_SERDES_DUMP_TYPE_COEF.
 * @param [in]    more         - More flag to dump more detail serdes sdk module osal_printf
 *                               directly.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_serdes_info_dump(const uint32 unit,
                         const uint32 port_id,
                         const uint32 lane_bmp,
                         const HAL_PHY_SERDES_DUMP_TYPE_T dump_type,
                         const uint32 more);

/**
 * @brief Set the bit within the shift register for LED.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    led_id          - LED module ID.
 * @param [in]    ptr_led_mode    - LED mode to set.
 * @param [in]    bit_id          - The bit to set.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_led_bit_set(const uint32 unit,
                    const uint32 led_id,
                    const uint32 bit_id,
                    const uint32 *ptr_led_mode);

/**
 * @brief Get the bit within the shift register for LED.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     led_id          - LED module ID.
 * @param [in]     bit_id          - The bit to set.
 * @param [out]    ptr_led_mode    - LED status [on/off (normal/force)].
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_led_bit_get(const uint32 unit,
                    const uint32 led_id,
                    const uint32 bit_id,
                    uint32 *ptr_led_mode);

/**
 * @brief Set MDIO(Management Data Input/Output) register of PHY.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    phy_type    - Type of PHY such as internal or external.
 * @param [in]    dev_type    - Type of PHY device.
 * @param [in]    reg_addr    - Register address.
 * @param [in]    reg         - Register data.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_mdio_reg_set(const uint32 unit,
                     const uint32 port_id,
                     const HAL_PHY_TYPE_T phy_type,
                     const HAL_PHY_MDIO_DEVICE_TYPE_T dev_type,
                     const uint32 reg_addr,
                     const uint32 reg);

/**
 * @brief Get MDIO(Management Data Input/Output) register of PHY.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port_id     - Device port number.
 * @param [in]     phy_type    - Type of PHY such as internal or external.
 * @param [in]     dev_type    - Type of PHY device.
 * @param [in]     reg_addr    - Register address.
 * @param [out]    ptr_reg     - Register data.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_mdio_reg_get(const uint32 unit,
                     const uint32 port_id,
                     const HAL_PHY_TYPE_T phy_type,
                     const HAL_PHY_MDIO_DEVICE_TYPE_T dev_type,
                     const uint32 reg_addr,
                     uint32 *ptr_reg);

/**
 * @brief Set MDIO(Management Data Input/Output) clock rate in KHZ on specified channel.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    bus         - MDIO channel ID.
 * @param [in]    rate_khz    - MDIO clock rate.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_mdio_clk_rate_set(const uint32 unit, const uint32 bus, const uint32 rate_khz);

/**
 * @brief Set MDIO PHY address.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port_id          - Device port number.
 * @param [in]    location_type    - Where the interface locates.
 * @param [in]    phy_addr         - PHY slave address.
 * @return        CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_addr_set(const uint32 unit,
                 const uint32 port_id,
                 const HAL_PHY_INTF_LOCATION_TYPE_T location_type,
                 HAL_PHY_ADDR_T phy_addr);

/**
 * @brief Get MDIO PHY address.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port_id          - Device port number.
 * @param [in]     location_type    - Where the interface locates.
 * @param [out]    ptr_phy_addr     - PHY slave address.
 * @return         CLX_E_OK    - Operate success.
 */
clx_error_no_t
hal_phy_addr_get(const uint32 unit,
                 const uint32 port_id,
                 const HAL_PHY_INTF_LOCATION_TYPE_T location_type,
                 HAL_PHY_ADDR_T *ptr_phy_addr);

/**
 * @brief Set port to support MxLink feature.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    enable     - 1: enable mxlink 0: disable mxlink.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 * @return        CLX_E_NOT_SUPPORT      - Hardware does not support.
 */
clx_error_no_t
hal_phy_mxlink_set(const uint32 unit, const uint32 port_id, const uint32 enable);

/**
 * @brief Get MxLink enable/disable.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port_id       - Device port number.
 * @param [out]    ptr_enable    - Show mxlink enable/disable.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 * @return         CLX_E_NOT_SUPPORT      - Hardware does not support.
 */
clx_error_no_t
hal_phy_mxlink_get(const uint32 unit, const uint32 port_id, uint32 *ptr_enable);

/**
 * @brief This API is used to get fec count for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port_id    - Physical port ID.
 * @param [in]     ptr_cnt    - Fec count.
 * @param [out]    ptr_cnt    - Fec count.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
hal_phy_fec_cnt_get(const uint32 unit, const uint32 port_id, HAL_PHY_FEC_CNT_T *ptr_cnt);

/**
 * @brief Clear fec counter value based on counter type.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    lane_id     - Device lane number.
 * @param [in]    cnt_type    - CERR/UCERR/lane SERR.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 * @return        CLX_E_NOT_SUPPORT      - Hardware does not support.
 */
clx_error_no_t
hal_phy_fec_cnt_clear(const uint32 unit,
                      const uint32 port_id,
                      const uint32 lane_id,
                      const HAL_PHY_FEC_CNT_TYPE_T cnt_type);

clx_error_no_t
hal_phy_prbs_generator_set(const uint32 unit, const uint32 port_id, HAL_PHY_PRBS_CONFIG_T prbs_gen);

clx_error_no_t
hal_phy_prbs_generator_get(const uint32 unit,
                           const uint32 port_id,
                           HAL_PHY_PRBS_CONFIG_T *prbs_gen);

/**
 * @brief Set phy prbs error inject.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    num_err    - Inject error numbers.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_prbs_err_inject(const uint32 unit, const uint32 port_id, const uint32 num_err);

/**
 * @brief Set phy prbs error inject.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    lane_bmp    - Lane bitmamp.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_prbs_err_cnt_clear_set(const uint32 unit, const uint32 port_id, const uint32 lane_bmp);

/**
 * @brief Get phy firmware version.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port_id            - Device port number.
 * @param [out]    ptr_version_eth    - Eth phy firmware version.
 * @param [out]    ptr_version_cpi    - Cpi phy firmware version.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_fw_version_get(const uint32 unit,
                       const uint32 port_id,
                       uint32 *ptr_version_eth,
                       uint32 *ptr_version_cpi);

/**
 * @brief Set phy rx equalize tuning once.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    phase       - Tuning phase.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_rxeq_tunning_set(const uint32 unit,
                         const uint32 port_id,
                         const uint32 lane_bmp,
                         const uint32 phase);

/**
 * @brief Set phy rx equalize tunning once.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port_id     - Device port number.
 * @param [out]    pma_rate    - Phy rate code: 0: 10P3125 1: 25P78125 2: 26P5625 3: 53P125_NRZ 4:
 *                               53P125_PAM4 5: 56P25_PAM4 6: 106P25 7: 112P5.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_rate_get(const uint32 unit, const uint32 port_id, uint32 *pma_rate);

/**
 * @brief Set phy isolation mode enable/disable.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    enable      - Enable/disable isolation mode.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_isola_mode_set(const uint32 unit,
                       const uint32 port_id,
                       const uint32 lane_bmp,
                       const uint32 enable);

/**
 * @brief Set phy tx or rx powerup.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port_id       - Device port number.
 * @param [in]    lane_bmp      - Lane bitmap.
 * @param [in]    module        - Tx or rx.
 * @param [in]    lane_speed    - Serdes lane speed.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_txrx_powerup_set(const uint32 unit,
                         const uint32 port_id,
                         const uint32 lane_bmp,
                         const HAL_PHY_POWERUP_MODULE_TYPE_T module,
                         const HAL_PHY_LANE_SPEED_TYPE_T lane_speed);

/**
 * @brief Set phy tx elecidle.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @param [in]    enable     - Enable or disable.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_tx_elecidle_set(const uint32 unit, const uint32 port_id, const uint32 enable);

/**
 * @brief Get phy tx elecidle.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port_id       - Device port number.
 * @param [out]    ptr_enable    - Phy tx elecidle.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_tx_elecidle_get(const uint32 unit, const uint32 port_id, uint32 *ptr_enable);

/**
 * @brief Set phy rx termination mode.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    mode        - Termination mode.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_rx_term_set(const uint32 unit,
                    const uint32 port_id,
                    const uint32 lane_bmp,
                    const HAL_PHY_ACC_TERM_MODE_T mode);

/**
 * @brief Get phy rx termination mode.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port_id     - Device port number.
 * @param [out]    ptr_mode    - Phy rx termination mode.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_rx_term_get(const uint32 unit, const uint32 port_id, uint32 *ptr_mode);

/**
 * @brief Get phy Atest or Pmon data.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Physical port ID.
 * @param [in]    lane_bmp    - Lane bitmap.
 * @param [in]    mode        - Atest mode.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_phy_atest_pmon_get(const uint32 unit,
                       const uint32 port_id,
                       const uint32 lane_bmp,
                       const uint32 mode);
/**
 * @brief Set phy rx eq config.
 *
 * @param [in]    unit               - Device unit number.
 * @param [in]    port_id            - Device port number.
 * @param [in]    lane_id            - Device lane number.
 * @param [in]    ptr_rxeq_config    - Rx eq config.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_rxeq_set(const uint32 unit,
                 const uint32 port_id,
                 const uint32 lane_id,
                 HAL_PHY_RX_EQPARAMS_T *ptr_rxeq_config);

/**
 * @brief Get phy rx eq config.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port_id            - Device port number.
 * @param [in]     lane_id            - Device lane number.
 * @param [out]    ptr_rxeq_config    - Phy rx eq config.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_rxeq_get(const uint32 unit,
                 const uint32 port_id,
                 const uint32 lane_id,
                 HAL_PHY_RX_EQPARAMS_T *ptr_rxeq_config);

/**
 * @brief Update phy rx eq config.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_rxeq_update(const uint32 unit, const uint32 port_id);

/**
 * @brief Reload phy macro firmware.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port_id    - Device port number.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_fw_reload(const uint32 unit, const uint32 port_id);

/**
 * @brief Read phy reg.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    lane_id     - Lane_id within the port.
 * @param [in]    reg_addr    - Lane0 reg addr.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_reg_read(const uint32 unit, const uint32 port_id, const uint32 lane_id, uint32 reg_addr);

/**
 * @brief Write phy reg.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port_id     - Device port number.
 * @param [in]    lane_id     - Lane_id within the port.
 * @param [in]    reg_addr    - Lane0 reg addr.
 * @param [in]    value       - The value to be set in the reg.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_reg_write(const uint32 unit,
                  const uint32 port_id,
                  const uint32 lane_id,
                  uint32 reg_addr,
                  const uint32 value);

/**
 * @brief Get phy rx snr.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     port_id        - Physical port ID.
 * @param [out]    ptr_snr_int    - Snr calculate integer value.
 * @param [out]    ptr_snr_dec    - Snr calculate decimal value.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_phy_rx_snr_get(const uint32 unit,
                   const uint32 port_id,
                   uint32 *ptr_snr_int,
                   uint32 *ptr_snr_dec);

/**
 * @brief Read anlt status.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     port_id            - Device port number.
 * @param [in]     lane_id            - Lane_id within the port.
 * @param [out]    ptr_anlt_status    - Anlt status value.
 * @return         CLX_E_OK               - Operate success.
 * @return         CLX_E_BAD_PARAMETER    - Invalid input.
 */
clx_error_no_t
hal_phy_anlt_status_get(const uint32 unit,
                        const uint32 port_id,
                        const uint32 lane_id,
                        uint32 *ptr_anlt_status);

clx_error_no_t
hal_phy_lt_state_get(const uint32 unit,
                     const uint32 port_id,
                     const uint32 lane_id,
                     uint32 *lt_done,
                     HAL_PMA_LT_T *ptr_lt_status);
#endif /* End of HAL_PHY_H */
