/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/**
 * @brief CoMira MAC IP defines.
 *
 * @file hal_mt_nb_mac.h.
 *
 */

#ifndef HAL_MT_NB_MAC_H
#define HAL_MT_NB_MAC_H

#include <util/util_log.h>
#include <hal/hal_port.h>

#define HAL_MT_NB_MTU              10200
#define HAL_MT_NB_PPH_LEANGTH      40
#define HAL_MT_NB_OUTER_MAC_LENGTH 12
#define HAL_MT_NB_MAC_TXJABBER_DFT \
    HAL_MT_NB_MTU + HAL_MT_NB_PPH_LEANGTH + HAL_MT_NB_OUTER_MAC_LENGTH
#define HAL_MT_NB_MAC_RXJABBER_DFT     HAL_MT_NB_MAC_TXJABBER_DFT
#define HAL_MT_NB_MAC_RXMAXFRMSIZE_DFT 1518
#define HAL_MT_NB_CMAC_RXMAXFRMSIZE_DFT \
    HAL_MT_NB_MAC_TXJABBER_DFT /* CPX port can't msk drop rsn, so set it as jabber*/

/* plane_idx of cpi port is used to ipl/epl, cmac defined in pcx and no need plane_idx */
#define HAL_MT_PORT_TO_PLANE_FOR_MAC(__unit__, __port__)             \
    (HAL_IS_CPI_PORT(__unit__, __port__) ?                           \
         0 :                                                         \
         ((HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(__unit__)) ?         \
              (HAL_CL_PORT_TO_PLANE(__unit__, __port__) +            \
               (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__) / 4)) : \
              HAL_CL_PORT_TO_PLANE(__unit__, __port__)))

#ifndef HAL_MT_PORT_TO_MACRO_FOR_MAC
#define HAL_MT_PORT_TO_MACRO_FOR_MAC(__unit__, __port__)      \
    ((HAL_IS_DEV_NB_RESOURCE_DOUBLE_FAMILY(__unit__)) ?       \
         (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__) % 4) : \
         (HAL_CL_PORT_TO_MAC_MACRO(__unit__, __port__)))
#endif

typedef enum {
    HAL_MT_NB_DISABLED = 0,
    HAL_MT_NB_10G_R1 = 15,
    HAL_MT_NB_10G_R1_FC = 16,
    HAL_MT_NB_25G_R1 = 21,
    HAL_MT_NB_25G_R1_FC = 22,
    HAL_MT_NB_25G_R1_RS = 23,
    HAL_MT_NB_25G_R1_CON_RS = 24,
    HAL_MT_NB_40G_R4 = 26,
    HAL_MT_NB_40G_R4_FC = 27,
    HAL_MT_NB_50G_R2 = 37,
    HAL_MT_NB_50G_R2_RS = 39,
    HAL_MT_NB_50G_R1_KP = 43,
    HAL_MT_NB_100G_R2_KP_CK = 44,
    HAL_MT_NB_100G_R1_KP_CK = 45,
    HAL_MT_NB_100G_R4 = 46,
    HAL_MT_NB_100G_R4_RS = 47,
    HAL_MT_NB_100G_R2_KP = 50,
    HAL_MT_NB_100G_R1_KP = 51,
    HAL_MT_NB_200G_R8_KP = 52,
    HAL_MT_NB_200G_R4_KP = 53,
    HAL_MT_NB_200G_R2_KP = 54,
    HAL_MT_NB_400G_R8_KP = 56,
    HAL_MT_NB_400G_R4_KP = 57,
    HAL_MT_NB_800G_R8_KP = 59,
    HAL_MT_NB_800G_R8_CON_KP = 60,
    HAL_MT_NB_100G_R4_KP_CK = 62,
    HAL_MT_NB_CHMODE_LAST = 64,
} HAL_MT_NB_MAC_CHMODE_E;

/* MAC IP type */
typedef enum {
    HAL_MT_NB_MAC_UMAC = 0x0,
    HAL_MT_NB_MAC_CMAC,
} HAL_MT_NB_MAC_TYPE_E;

clx_error_no_t
hal_mt_nb_mac_app_cfg0_set(uint32 unit,
                           uint32 plane,
                           uint32 plane_port,
                           uint32 subinst_idx,
                           HAL_MT_NB_MAC_TYPE_E mac_type,
                           uint32 *buf);

clx_error_no_t
hal_mt_nb_mac_app_cfg0_get(uint32 unit,
                           uint32 plane,
                           uint32 plane_port,
                           uint32 subinst_idx,
                           HAL_MT_NB_MAC_TYPE_E mac_type,
                           uint32 *buf);

clx_error_no_t
hal_mt_nb_mac_version_get(uint32 unit,
                          uint32 plane,
                          uint32 plane_port,
                          uint32 subinst_idx,
                          HAL_MT_NB_MAC_TYPE_E mac_type,
                          uint32 *buf);

clx_error_no_t
hal_mt_nb_mac_ch_sts_get(uint32 unit,
                         uint32 plane,
                         uint32 plane_port,
                         uint32 subinst_idx,
                         HAL_MT_NB_MAC_TYPE_E mac_type,
                         uint32 *buf);

clx_error_no_t
hal_mt_nb_mac_override_set(uint32 unit, uint32 port, uint32 speed);

clx_error_no_t
hal_mt_nb_mac_chmode_set(uint32 unit, uint32 port, HAL_MT_NB_MAC_CHMODE_E mode);

clx_error_no_t
hal_mt_nb_mac_chmode_get(uint32 unit, uint32 port, HAL_MT_NB_MAC_CHMODE_E *mode);

clx_error_no_t
hal_mt_nb_mac_low_latency_set(uint32 unit, uint32 port, uint32 enable);

clx_error_no_t
hal_mt_nb_mac_low_latency_get(uint32 unit, uint32 port, uint32 *enable);

clx_error_no_t
hal_mt_nb_mac_tx_wr_thrd_set(uint32 unit, uint32 port, uint32 speed);

clx_error_no_t
hal_mt_nb_mac_tx_rd_thrd_set(uint32 unit, uint32 port, uint32 speed);

clx_error_no_t
hal_mt_nb_mac_fc_rx_filter_set(uint32 unit, uint32 port, uint32 enable);

clx_error_no_t
hal_mt_nb_mac_jabber_set(const uint32 unit, const uint32 port, uint32 rxjabber, uint32 txjabber);

clx_error_no_t
hal_mt_nb_mac_max_frm_size_set(const uint32 unit, const uint32 port, uint32 maxfrmsize);

/**
 * @brief This API is used to set the MAC address for a specific port.
 *
 * Example is as below.
 * clx_mac_t clx_mac = {0x0, 0x1, 0x2, 0x3, 0x4, 0x5};
 * uint32    hw_mac[2];
 * hw_mac[0] = 0x00010203;
 * hw_mac[1] = 0x0405;.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port ID.
 * @param [in]    mac     - The MAC address.
 * @return        CLX_E_OK               - The operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_mac_addr_set(const uint32 unit, const uint32 port, const clx_mac_t mac);

/**
 * @brief This API is used to get the MAC address for a specific port.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port ID.
 * @param [out]    ptr_mac    - The MAC address.
 * @return         CLX_E_OK               - The operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_mac_addr_get(const uint32 unit, const uint32 port, clx_mac_t *ptr_mac);

clx_error_no_t
hal_mt_nb_mac_wrap_reset(uint32 unit, uint32 plane, uint32 eth_macro, uint32 reset);

clx_error_no_t
hal_mt_nb_mac_wrap_misc_cfg(uint32 unit, uint32 plane, uint32 eth_macro);

clx_error_no_t
hal_mt_nb_mac_fabric_set(uint32 unit, uint32 port, uint32 fabric_en);

clx_error_no_t
hal_mt_nb_mac_tx_prbs_set(uint32 unit, uint32 port, uint32 pattern);

clx_error_no_t
hal_mt_nb_mac_rx_prbs_set(uint32 unit, uint32 port, uint32 pattern);

clx_error_no_t
hal_mt_nb_mac_stat_clear_set(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_mac_ifg_zero_set(const uint32 unit, const uint32 port, const uint32 ifg0b);

clx_error_no_t
hal_mt_nb_mac_ifg_zero_get(const uint32 unit, const uint32 port, uint32 *ifg0b);

clx_error_no_t
hal_mt_nb_mac_disautorst_set(const uint32 unit, const uint32 port, uint32 enable);

clx_error_no_t
hal_mt_nb_mac_wrap_mux_mapping_cfg(const uint32 unit, uint32 *init_112g);

#endif
