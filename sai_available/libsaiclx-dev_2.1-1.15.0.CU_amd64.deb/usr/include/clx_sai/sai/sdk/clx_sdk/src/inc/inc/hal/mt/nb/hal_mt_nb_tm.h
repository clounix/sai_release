/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_nb_tm.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_MT_NB_TM_H
#define HAL_MT_NB_TM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_init.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>
#include <clx/clx_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* queue num*/
#define HAL_MT_NB_TM_CPU_QUEUE_NUM (48)

#define HAL_MT_NB_TM_UCAST_QUEUE_NUM (8)

#define HAL_MT_NB_TM_MCAST_QUEUE_NUM    (4)
#define HAL_MT_NB_TM_LEGACY_QUEUE_NUM   (8)
#define HAL_MT_NB_TM_CPI_QUEUE_NUM      (8)
#define HAL_MT_NB_TM_PLANE_QUEUE_OFFSET (512)
#define HAL_MT_NB_TM_OQ_NUM             (4096)
#define HAL_MT_NB_TM_DELETE_OQ          (4095)

#define HAL_MT_NB_CPU_PLANE_PORT            (32)
#define HAL_MT_NB_CPI0_PLANE_PORT           (34)
#define HAL_MT_NB_CPI1_PLANE_PORT           (35)
#define HAL_MT_NB_ECPU_PLANE_PORT           (33)
#define HAL_MT_NB_RC0_PLANE_PORT            (36)
#define HAL_MT_NB_TM_PLANE_PORT_NUM         (40)
#define HAL_MT_NB_TM_PLANE_NETWROK_PORT_NUM (32)
#define HAL_MT_NB_TM_PLANE_DROP_PORT_ID     (40)
#define HAL_MT_NB_TM_PLANE_NUM              (8)
#define HAL_MT_NB_TM_TC_BMP_ALL_MASK        (0xff)

/* DQC_READ_OQ_PORT_MAP_MEM has 16 oq in every entry */
#define HAL_MT_NB_TM_OQ_INFO_GET_FLD_OFFSET(_value_) (_value_ % 16)

/* DQC_READ_OQ_PORT_MAP_MEM table entry number is 256, total 4k oq */
#define HAL_MT_NB_TM_OQ_INFO_GET_ENTRY_IDX(_value_) (_value_ / 16)

#define HAL_MT_NB_TM_LEGACY_QUEUE_VLD(queue) ((queue) < HAL_MT_NB_TM_LEGACY_QUEUE_NUM)

#define HAL_MT_NB_TM_UCAST_QUEUE_VLD(queue) ((queue) < HAL_MT_NB_TM_UCAST_QUEUE_NUM)

#define HAL_MT_NB_TM_MCAST_QUEUE_VLD(queue) ((queue) < HAL_MT_NB_TM_MCAST_QUEUE_NUM)

#define HAL_MT_NB_TM_CPU_QUEUE_VLD(queue) ((queue) < HAL_MT_NB_TM_CPU_QUEUE_NUM)

/*check macro*/
#define HAL_MT_NB_TM_CHK_MIN_MAX_RANGE(__value__, __min__, __max__) \
    (((__value__) > (__max__)) || ((__value__) < (__min__)))

/* DATA TYPE DECLARATIONS
 */

/* Type of Object ID for warm-boot */
typedef enum hal_mt_nb_tm_wbdb_s {
    HAL_MT_NB_TM_WBDB_SCHED_WEIGHT,
    HAL_MT_NB_TM_WBDB_BUF_PROF,
    HAL_MT_NB_TM_WBDB_PFC,
    HAL_MT_NB_TM_WBDB_MISC,
    HAL_MT_NB_TM_WBDB_PFCWD,
    HAL_MT_NB_TM_WBDB_TCB,
    HAL_MT_NB_TM_WBDB_LAST
} hal_mt_nb_tm_wbdb_t;

typedef struct hal_mt_nb_tm_oq_info_s {
    uint32 uc_oq_min;
    uint32 uc_oq_cnt;
    uint32 mc_oq_min;
    uint32 mc_oq_cnt;
} hal_mt_nb_tm_oq_info_t;

typedef enum hal_mt_nb_tm_port_type_s {
    HAL_MT_NB_TM_PORT_FP = 0,
    HAL_MT_NB_TM_PORT_CPU,
    HAL_MT_NB_TM_PORT_ECPU,
    HAL_MT_NB_TM_PORT_CPI,
    HAL_MT_NB_TM_PORT_RC,
    HAL_MT_NB_TM_PORT_LAST
} hal_mt_nb_tm_port_type_t;

clx_error_no_t
hal_mt_nb_tm_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_deinit(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_misc_cfg_init(const uint32 unit);

uint32
hal_mt_nb_tm_val_from_cfg_get(const uint32 unit,
                              const uint32 cfg,
                              const uint32 param0,
                              const uint32 param1,
                              uint32 value);

clx_error_no_t
hal_mt_nb_tm_cfg_set(const uint32 unit,
                     const uint32 port,
                     const clx_tm_handler_t handler,
                     const clx_tm_cfg_t *ptr_cfg);

clx_error_no_t
hal_mt_nb_tm_cfg_get(const uint32 unit,
                     const uint32 port,
                     const clx_tm_handler_t handler,
                     clx_tm_cfg_t *ptr_cfg);

clx_error_no_t
hal_mt_nb_tm_speed_set(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

clx_error_no_t
hal_mt_nb_tm_speed_get(const uint32 unit, const uint32 port, clx_port_speed_t *speed);

clx_error_no_t
hal_mt_nb_tm_port_dflt_set(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_tm_port_dflt_reset(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_tm_tc_prof_set(const uint32 unit, const uint32 prof_id, const clx_tm_tc_prof_t *prof);

clx_error_no_t
hal_mt_nb_tm_tc_prof_get(const uint32 unit, const uint32 prof_id, clx_tm_tc_prof_t *prof);

clx_error_no_t
hal_mt_nb_tm_tc_cut_through_set(const uint32 unit, const uint32 tc, const boolean enable);

clx_error_no_t
hal_mt_nb_tm_tc_cut_through_get(const uint32 unit, const uint32 tc, boolean *enable);

clx_error_no_t
hal_mt_nb_tm_trunc_prof_set(const uint32 unit, const hal_tm_trunc_prof_t *prof);

clx_error_no_t
hal_mt_nb_tm_trunc_prof_get(const uint32 unit, hal_tm_trunc_prof_t *prof);

clx_error_no_t
hal_mt_nb_tm_trunc_set(const uint32 unit, const hal_tm_trunc_cfg_t *cfg);

clx_error_no_t
hal_mt_nb_tm_trunc_get(const uint32 unit, hal_tm_trunc_cfg_t *cfg);

clx_error_no_t
hal_mt_nb_tm_all_sub_inst_entry_write(const uint32 unit,
                                      const uint32 inst_idx,
                                      const uint32 tbl_id,
                                      const uint32 entry_idx,
                                      uint32 *ptr_entry);

clx_error_no_t
hal_mt_nb_tm_all_sub_inst_entry_modify(const uint32 unit,
                                       const uint32 inst_idx,
                                       const uint32 tbl_id,
                                       const uint32 entry_idx,
                                       const uint32 fld_id,
                                       uint32 *ptr_fld);

clx_error_no_t
hal_mt_nb_tm_multi_all_sub_inst_entry_modify(const uint32 unit,
                                             const uint32 inst_idx,
                                             const uint32 tbl_id,
                                             const uint32 entry_idx,
                                             const uint32 fvp_count,
                                             tob_fvp_t *ptr_fvp);

void
hal_mt_nb_tm_oq_info_get(const uint32 unit, const uint32 port, hal_mt_nb_tm_oq_info_t *oq_info);

boolean
hal_mt_nb_tm_port_type_detect(const uint32 unit,
                              const uint32 port,
                              const hal_mt_nb_tm_port_type_t type);

clx_error_no_t
hal_mt_nb_tm_port_tc_prof_idx_get(const uint32 unit, const uint32 port, uint32 *prof_id);

clx_error_no_t
hal_mt_nb_tm_fabric_tc_prof_idx_get(const uint32 unit, const uint32 path, uint32 *prof_id);

clx_error_no_t
hal_mt_nb_tm_port_tc_prof_idx_set(const uint32 unit, const uint32 port, const uint32 prof_id);
clx_error_no_t
hal_mt_nb_tm_fabric_tc_prof_idx_set(const uint32 unit, const uint32 path, const uint32 prof_id);

uint32
hal_mt_nb_tm_speed_to_val_trans(const hal_tm_port_speed_t speed);

void
hal_mt_nb_tm_speed_to_tm_trans(const clx_port_speed_t speed, hal_tm_port_speed_t *ptr_tm_speed);

clx_error_no_t
hal_mt_nb_tm_cpa_set(const uint32 unit, const clx_swc_cfg_cpa_type_t type, const uint32 value);

clx_error_no_t
hal_mt_nb_tm_cpa_get(const uint32 unit, const clx_swc_cfg_cpa_type_t type, uint32 *ptr_value);

clx_error_no_t
hal_mt_nb_tm_port_flush(const uint32 unit, const uint32 port, const uint32 en);

clx_error_no_t
hal_mt_nb_tm_igr_traffic_flush(const uint32 unit, const uint32 port, const uint32 en);

clx_error_no_t
hal_mt_nb_tm_all_chip_traffic_flush(const uint32 unit, const uint32 en);

clx_error_no_t
hal_mt_nb_tm_misc_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_misc_wb_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_frg_fc_show(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_frg_pfc_show(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_fc_show(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_handler_create(const uint32 unit,
                            const uint32 port,
                            const clx_tm_handler_type_t handler_type,
                            const uint32 queue_id,
                            clx_tm_handler_t *ptr_handler);

clx_error_no_t
hal_mt_nb_tm_handler_destroy(const uint32 unit, const uint32 port, const clx_tm_handler_t handler);

clx_error_no_t
hal_mt_nb_tm_xoff_msk_set(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_tm_port_phy_plane_get(const uint32 unit, const uint32 port, uint32 *ptr_phy_slice);

clx_error_no_t
hal_mt_nb_tm_phy_plane_to_plane_convert(const uint32 unit,
                                        const uint32 phy_plane,
                                        uint32 *ptr_plane);

#endif /* #ifndef HAL_MT_NB_TM_H */
