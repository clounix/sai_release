/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *******************************************************************************/

/* FILE NAME:  hal_ecpu_eparser.h
 * PURPOSE:
 *      It provide eparser module api.
 * NOTES:
 *
 */

#ifndef __HAL_EPARSER_H__
#define __HAL_EPARSER_H__

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_ecpu.h>

#ifdef __cplusplus
extern "C" {
#endif

/* NAMING CONSTANT DECLARATIONS (Macro Definitions)
 */

/* DATA TYPE DECLARATIONS (Data Structure Definitions)
 */

/* Module identifier enum, add new modules here as needed */
typedef enum {
    HAL_EPARSER_MODULE_INVALID = 0,
    HAL_EPARSER_MODULE_EXPORT_ROUTE, /* Route export module */
    HAL_EPARSER_MODULE_HARDWARE_BFD, /* Hardware BFD module */
    HAL_EPARSER_MODULE_EXPORT_ARP,   /* ARP export module */
    HAL_EPARSER_MODULE_EXPORT_MAC,   /* MAC export module */
    HAL_EPARSER_MODULE_MAX
} hal_eparser_module_id_t;

/* Event type enum, defines different event types handled by eparser */
typedef enum {
    HAL_EPARSER_EVENT_INVALID = 0,
    HAL_EPARSER_EVENT_ASYNC_SEND,
    HAL_EPARSER_EVENT_COMMON_NOTIFY,
    HAL_EPARSER_EVENT_MAX
} hal_eparser_event_type_t;

// Message header structure
typedef struct eparse_common_header_s {
    uint32_t type : 28;                // Message type
    uint32_t unit : 4;                 // Chip unit number
    hal_eparser_module_id_t module_id; // 0 when type==EPARSE_MSG_TYPE_REGMESSAGE, otherwise module
                                       // id
    uint32_t length;                   // Message body length
} eparse_common_header_t;

// eparser message type definitions, shared by app and ecpu both direction
typedef enum {
    EPARSE_MSG_TYPE_REGMESSAGE = 1, /* app to eparser */
    EPARSE_MSG_TYPE_REQUEST_ASYNC,  /* app to eparser */
    EPARSE_MSG_TYPE_REQUEST_SYNC,   /* app to eparser */
    EPARSE_MSG_TYPE_RESPONSE,       /* eparser to app */
    EPARSE_MSG_TYPE_NOTIFY,         /* eparser to app */
    EPARSE_MSG_TYPE_MAX
} eparse_msg_type_t;

/* TLV header structure definition */
typedef struct tlv_header_s {
    uint16_t type;   /* TLV type */
    uint16_t length; /* TLV length */
} tlv_header_t;
// Registration message structure
typedef struct eparser_reg_msg_s {
    hal_eparser_module_id_t reg_module; // Registration module id
} eparser_reg_msg_t;

// Event callback control block
typedef struct eparser_event_cb_s {
    hal_eparser_event_type_t event_type; // event type
    hal_eparser_module_id_t module_id;   // event processing module id
    uint32_t unit;                       // chip unit number
    uint8_t data_takeover; // 0: data will memcpy,and caller need free data ptr; 1: data will not
                           // memcpy,and caller must't free data ptr
    union {
        eparse_msg_type_t send_msg_type;
        uint32_t data;
    } user_data;

} eparser_event_cb_t;

/* Module function pointer type definitions */
/* app to eparser message processing function */
typedef clx_error_no_t (*module_message_proc_func_t)(uint32 unit,
                                                     eparse_msg_type_t msg_type,
                                                     void *msg,
                                                     uint32_t length);
/* eparser event queue processing function */
typedef clx_error_no_t (*module_event_proc_func_t)(uint32 unit, void *data, uint32_t data_len);
/* module initialization function */
typedef clx_error_no_t (*module_init_func_t)(uint32 unit);
/* module deinitialization function */
typedef clx_error_no_t (*module_deinit_func_t)(uint32 unit);

/* Module function collection structure */
typedef struct hal_eparser_module_funcs_s {
    module_message_proc_func_t message_proc_func; /* Message processing function */
    module_event_proc_func_t event_proc_func;     /* Event processing function */
    module_init_func_t init_func;                 /* Module initialization function */
    module_deinit_func_t deinit_func;             /* Module deinitialization function */
} hal_eparser_module_funcs_t;

/* GLOBAL VARIABLE DECLARATIONS (Global Variable Declarations)
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS (External Function Declarations)
 */
/**
 * @brief Initialize eparser module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_eparser_init(uint32 unit);

/**
 * @brief Deinitialize eparser module.
 *
 * @param [in]    unit    - Chip unit number.
 * @return        CLX_E_OK        - Operation successful.
 * @return        CLX_E_OTHERS    - Operation failed.
 */
clx_error_no_t
hal_eparser_deinit(uint32 unit);

/**
 * @brief Register module function pointer.
 *
 * @param [in]    module_id    - Module identifier.
 * @param [in]    funcs        - Module function set.
 * @return        CLX_E_OK        - Operation successful.
 * @return        Other errors    - Operation failed.
 */
clx_error_no_t
hal_eparser_register_module(hal_eparser_module_id_t module_id,
                            const hal_eparser_module_funcs_t *funcs);
/**
 * @brief Unregister module function pointer.
 *
 * @param [in]    module_id    - Module identifier to unregister.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid module ID.
 */
clx_error_no_t
hal_eparser_deregister_module(hal_eparser_module_id_t module_id);

/**
 * @brief Enqueue event notification message to eparser event queue for asynchronous processing.
 *
 * This function adds an event notification message to the lock-free event queue
 * for asynchronous processing by the eparser main thread. The function validates
 * event callback parameters including event type and module ID before enqueuing.
 * This is a thread-safe function and can be called from multiple thread contexts.
 *
 * @param [in]    evt_cb      - Event callback structure containing event type,
 *                              module ID, and user data.
 * @param [in]    data        - Event data pointer (can be NULL if data_len is 0).
 * @param [in]    data_len    - Event data length in bytes.
 * @return        CLX_E_OK               - Event successfully enqueued.
 * @return        CLX_E_BAD_PARAMETER    - Invalid evt_cb pointer, event type,
 *                                         or module ID.
 * @return        CLX_E_NO_MEMORY        - Memory allocation failed for data copy.
 * @return        CLX_E_OTHERS           - Event queue is full or eventfd write failed.
 */
clx_error_no_t
hal_eparser_notify_event(eparser_event_cb_t *evt_cb, void *data, uint32_t data_len);

/**
 * @brief Send message to registered clients through event queue.
 *
 * This function enqueues the message to the event queue for asynchronous processing.
 * The actual sending will be performed in the event handler thread.
 *
 * @param [in]    module_id    - Module id registered with client.
 * @param [in]    msg_type     - Message type.
 * @param [in]    data         - Data to send.
 * @param [in]    data_len     - Data length.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_eparser_send_message(hal_eparser_module_id_t module_id,
                         eparse_msg_type_t msg_type,
                         const void *data,
                         uint32_t data_len);

/**
 * @brief Send message to registered clients with header and data sent separately.
 *
 * This function sends a message in two parts:
 * 1. First sends the message header containing type, unit, module_id and length information
 * 2. Then sends the actual data payload with a loop to handle large data.
 *
 * @param [in]    module_id    - Module id registered with client.
 * @param [in]    msg_type     - Message type.
 * @param [in]    data         - Data to send.
 * @param [in]    data_len     - Data length.
 * @return        CLX_E_OK               - Operation successful.
 * @return        CLX_E_BAD_PARAMETER    - Invalid parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
hal_eparser_send_message_immediately(hal_eparser_module_id_t module_id,
                                     eparse_msg_type_t msg_type,
                                     const void *data,
                                     uint32_t data_len);

#ifdef __cplusplus
}
#endif
#endif /* __HAL_EPARSER_H__ */