/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_rbt.h
 * PURPOSE:
 *  this file is used to provide red black tree operations to other users.
 * NOTES:
 *
 *
 */
#ifndef UTIL_LIB_RBT_H
#define UTIL_LIB_RBT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <util/lib/util_lib_mpool.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum util_lib_rbt_color_type_e {
    UTIL_LIB_RBT_COLOR_TYPE_BLACK = 0x0,
    UTIL_LIB_RBT_COLOR_TYPE_RED,
    UTIL_LIB_RBT_COLOR_TYPE_DOUBLE_BLACK,
    UTIL_LIB_RBT_COLOR_TYPE_LAST
} util_lib_rbt_color_type_t;

/* FUNCTION TYPE NAME: util_lib_rbt_cmp_func_t
 * PURPOSE:
 *     it is used to compare user data with node data.
 * INPUT:
 *     ptr_user_param  -- user param, saved in red black tree head
 *     ptr_user_data   -- user data
 *     ptr_node_data   -- the data saved in node
 * OUTPUT:
 *     None.
 * RETURN:
 *     ==0 : user data is equal to node data
 *     <0  : user data is less than node data
 *     >0  : user data is more than node data
 * NOTES:
 *
 */
typedef int32 (*util_lib_rbt_cmp_func_t)(void *ptr_user_param,
                                         void *ptr_user_data,
                                         void *ptr_node_data);

/* FUNCTION TYPE NAME: util_lib_rbt_destroy_func_t
 * PURPOSE:
 *     it is used in destroy function, when user want to destroy an rb tree,
 *     use this function to release node data.
 * INPUT:
 *     ptr_user_param  -- user param, saved in rb tree head
 *     ptr_node_data   -- the data saved in node.
 * OUTPUT:
 *     None.
 * RETURN:
 *     None
 * NOTES:
 *
 */
typedef void (*util_lib_rbt_destroy_func_t)(void *ptr_user_param, void *ptr_node_data);

typedef clx_error_no_t (*util_lib_rbt_trav_func_t)(void *ptr_user_param,
                                                   void *ptr_node_data,
                                                   void *ptr_cookie);

typedef void (*util_lib_rbt_update_func_t)(void *ptr_node, void *ptr_user_data);

/* rb tree node structure */
typedef struct util_lib_rbt_node_s {
    struct util_lib_rbt_node_s *ptr_left;   /* left child */
    struct util_lib_rbt_node_s *ptr_right;  /* right child */
    struct util_lib_rbt_node_s *ptr_parent; /* parent */
    void *ptr_data;                         /* user data saved in the node */
    util_lib_rbt_color_type_t color;        /* node color (BLACK, RED and DOUBLE_BLACK) */
} util_lib_rbt_node_t;

/* rb tree head node structure*/
typedef struct util_lib_rbt_head_s {
    util_lib_rbt_node_t *ptr_root;    /* root pointer */
    char *ptr_name;                   /* name of rb tree */
    util_lib_mpool_t *ptr_node_pool;  /* node pool */
    util_lib_rbt_cmp_func_t cmp_func; /* compare function             */
    void *ptr_user_param;             /* user parameter data          */
    uint32 node_count;                /* the count of nodes in the rb tree */
    uint32 capacity;                  /* the capacity of the rb tree
                                       * 0 : unfixed size
                                       * >0: fixed size
                                       */
    util_lib_rbt_node_t nil_node;     /* the null leaf node */
} util_lib_rbt_head_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/**
 * @brief Allocate an red black tree head and nodes.
 *
 * @param [in]     ptr_user_param    - User private parameter, can be NULL.
 *                                     it is a cookie data used in compare callback,
 *                                     traverse callback, destroy callback.
 * @param [in]     capacity          - The rb tree node number.
 * @param [in]     cmp_func          - The compare function, must not be NULL.
 * @param [in]     ptr_name          - The rb tree name, max length is
 *                                     UTIL_LIB_NAME_LEN_MAX(include '\0').
 * @param [out]    pptr_head         - The returned red black tree head.
 * @return         CLX_E_OK               - Create success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 * @return         CLX_E_NO_MEMORY        - Alloc red black tree head failed.
 */
clx_error_no_t
util_lib_rbt_create(void *ptr_user_param,
                    const uint32 capacity,
                    const util_lib_rbt_cmp_func_t cmp_func,
                    const char *ptr_name,
                    util_lib_rbt_head_t **pptr_head);

/**
 * @brief It is used to destroy an red black tree, if user provide a destroy function,
 *        then when remove nodes from the tree, every node data will be processed by destroy
 *        function. it will release the head.
 *
 * @param [in]    ptr_head        - The red black tree head will be destroy.
 * @param [in]    destroy_func    - For processing the node data when removing nodes,
 *                                  if it is null, don't process node data.
 * @return        CLX_E_OK               - Destroy success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
util_lib_rbt_destroy(util_lib_rbt_head_t *ptr_head, const util_lib_rbt_destroy_func_t destroy_func);

/**
 * @brief Insert a node into the red black tree.
 *
 * @param [in]     ptr_head                 - Rb tree root head.
 * @param [in]     ptr_data                 - Include key value.
 * @param [in]     overwrite_flag           - TRUE : if data exists, overwrite and return the old
 *                                            data in pptr_overwriten_data.
 *                                            FALSE: if data exists, insert failed,
 *                                            return CLX_E_ENTRY_EXISTS.
 * @param [out]    pptr_overwritten_data    - If a node data is overwritten,
 *                                            the node data will be saved in it and return to user.
 *                                            if overwrite_flag is FALSE,
 *                                            it would be NULL.
 * @param [out]    pptr_insert_node         - Save insert node pointer.
 * @return         CLX_E_OK               - Insert success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 * @return         CLX_E_NO_MEMORY        - Alloc rb tree node failed.
 * @return         CLX_E_TABLE_FULL       - Alloc rb tree node from pool failed.
 * @return         CLX_E_ENTRY_EXISTS     - The node has existed in the tree.
 */
clx_error_no_t
util_lib_rbt_insert(util_lib_rbt_head_t *ptr_head,
                    void *ptr_data,
                    const boolean overwrite_flag,
                    void **pptr_overwritten_data,
                    void **pptr_insert_node);

/**
 * @brief Delete a node from the red black tree.
 *
 * @param [in]     ptr_head          - Rb tree root head.
 * @param [in]     ptr_data          - Include key value.
 * @param [in]     dyn_cmp_func      - User compare function. If it is null,
 *                                     default compare function will be used.
 * @param [in]     update_func       - Update user data and tree node pointer maping relationship.
 *                                     Because user data may save corresponding tree node pointer.
 *                                     If it is null, do not perform this callback function.
 * @param [out]    pptr_node_data    - Return user data pointer.
 * @return         CLX_E_OK                 - Delete success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Delete fail.
 */
clx_error_no_t
util_lib_rbt_delete(util_lib_rbt_head_t *ptr_head,
                    void *ptr_data,
                    void **pptr_node_data,
                    const util_lib_rbt_cmp_func_t dyn_cmp_func,
                    const util_lib_rbt_update_func_t update_func);

/**
 * @brief Delete a node from the red black tree.
 *
 * @param [in]     ptr_head              - Rb tree root head.
 * @param [in]     ptr_del_node          - The rb tree node to be deleted.
 * @param [in]     update_func           - Update user data and tree node pointer maping
 *                                         relationship. Because user data may save corresponding
 *                                         tree node pointer. If it is null,
 *                                         do not perform this callback function.
 * @param [out]    pptr_del_node_data    - Return user data pointer.
 * @return         CLX_E_OK                 - Delete success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Delete fail.
 */
clx_error_no_t
util_lib_rbt_node_delete(util_lib_rbt_head_t *ptr_head,
                         const util_lib_rbt_node_t *ptr_del_node,
                         void **pptr_del_node_data,
                         const util_lib_rbt_update_func_t update_func);

/**
 * @brief Find first node in red black tree.
 *
 * @param [in]    ptr_head    - Red black tree root head.
 * @return        util_lib_rbt_node_t    - The first node in red black tree.
 * @return        NULL                   - The red black tree has no nodes.
 */
util_lib_rbt_node_t *
util_lib_rbt_first_get(const util_lib_rbt_head_t *ptr_head);

/**
 * @brief Find next node in red black tree.
 *
 * @param [in]    ptr_head    - Red black tree root head.
 * @param [in]    ptr_node    - Current red black tree node.
 * @return        util_lib_rbt_node_t    - The node next to ptr_node.
 * @return        NULL                   - The red black tree has no next nodes.
 */
util_lib_rbt_node_t *
util_lib_rbt_next_get(const util_lib_rbt_head_t *ptr_head, const util_lib_rbt_node_t *ptr_node);

/**
 * @brief Find previous node in red black tree.
 *
 * @param [in]    ptr_head    - Red black tree root head.
 * @param [in]    ptr_node    - Current red black tree node.
 * @return        util_lib_rbt_node_t    - The previous node to ptr_node.
 * @return        NULL                   - The red black tree has no previous nodes.
 */
util_lib_rbt_node_t *
util_lib_rbt_prev_get(const util_lib_rbt_head_t *ptr_head, const util_lib_rbt_node_t *ptr_node);

/**
 * @brief Traverse every node in red black tree and perform callback function in node.
 *
 * @param [in]    ptr_head      - Red black tree root head.
 * @param [in]    trav_func     - User register function in node.
 * @param [in]    ptr_cookie    - Cookie data for trav_callback.
 * @return        CLX_E_OK               - Traverse success.
 * @return        CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 * @return        CLX_E_OTHERS           - Traverse stop by traverse callback.
 */
clx_error_no_t
util_lib_rbt_trav(const util_lib_rbt_head_t *ptr_head,
                  const util_lib_rbt_trav_func_t trav_func,
                  void *ptr_cookie);

/**
 * @brief Get the number of nodes in the red black tree.
 *
 * @param [in]     ptr_head     - The red black tree head will be counted.
 * @param [out]    ptr_count    - The count of nodes.
 * @return         CLX_E_OK               - Get count success.
 * @return         CLX_E_BAD_PARAMETER    - Parameter pointer is null.
 */
clx_error_no_t
util_lib_rbt_count_get(const util_lib_rbt_head_t *ptr_head, uint32 *ptr_count);

/**
 * @brief Find node in red black tree with given key.
 *
 * @param [in]     ptr_head     - Red black tree root head.
 * @param [in]     ptr_data     - Include key value.
 * @param [out]    pptr_node    - Return found node pointer.
 * @return         CLX_E_OK                 - Find success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Find fail.
 */
clx_error_no_t
util_lib_rbt_find(const util_lib_rbt_head_t *ptr_head,
                  void *ptr_data,
                  util_lib_rbt_node_t **pptr_node);

/**
 * @brief Find next node in red black tree with given key.
 *
 * @param [in]     ptr_head     - Red black tree root head.
 * @param [in]     ptr_data     - Include key value.
 * @param [out]    pptr_node    - Return found node pointer.
 * @return         CLX_E_OK                 - Find success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Find fail.
 */
clx_error_no_t
util_lib_rbt_next_find(const util_lib_rbt_head_t *ptr_head,
                       void *ptr_data,
                       util_lib_rbt_node_t **pptr_node);

/**
 * @brief Find next node in red black tree with given key, the found node data key >= input data
 *        key.
 *
 * @param [in]     ptr_head     - Red black tree root head.
 * @param [in]     ptr_data     - Include key value.
 * @param [out]    pptr_node    - Return found node pointer.
 * @return         CLX_E_OK                 - Find success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Find fail.
 */
clx_error_no_t
util_lib_rbt_ge_find(const util_lib_rbt_head_t *ptr_head,
                     void *ptr_data,
                     util_lib_rbt_node_t **pptr_node);

/**
 * @brief Find prev node in red black tree with given key.
 *
 * @param [in]     ptr_head     - Red black tree root head.
 * @param [in]     ptr_data     - Include key value.
 * @param [out]    pptr_node    - Return found node pointer.
 * @return         CLX_E_OK                 - Find success.
 * @return         CLX_E_BAD_PARAMETER      - Parameter pointer is null.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Find fail.
 */
clx_error_no_t
util_lib_rbt_prev_find(const util_lib_rbt_head_t *ptr_head,
                       void *ptr_data,
                       util_lib_rbt_node_t **pptr_node);

#endif /* End of UTIL_LIB_RBT_H */
