/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_tm_pfc.h
 * PURPOSE:
 *      It provides TM module PFC API.
 * NOTES:
 *
 *
 */

#ifndef HAL_MT_NB_TM_PFC_H
#define HAL_MT_NB_TM_PFC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_tm.h>
#include <osal/osal.h>
#include <hal/hal_tbl.h>
#include <hal/hal.h>
#include <hal/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */
/* NB lossless pfc priority bitmap max num */
#define HAL_MT_NB_TM_PFC_LOSSLESS_BMP_MAX_NUM (2)
#define HAL_MT_NB_TM_MAX_PFC_SC_NUM           (2)
#define HAL_MT_NB_TM_INVALID_VAL              (0xFF)

/* TC classification */
typedef enum hal_mt_nb_tm_ipl_tc_type_s {
    HAL_MT_NB_TM_IPL_TC_LOSSY0 = 0,
    HAL_MT_NB_TM_IPL_TC_LOSSY1 = 1,
    HAL_MT_NB_TM_IPL_TC_LOSSLESS0 = 2,
    HAL_MT_NB_TM_IPL_TC_LOSSLESS1 = 3,
    HAL_MT_NB_TM_IPL_TC_LAST
} hal_mt_nb_tm_ipl_tc_type_t;

typedef enum hal_mt_nb_tm_epl_tc_type_s {
    HAL_MT_NB_TM_EPL_TC_LOSSLESS0 = 0,
    HAL_MT_NB_TM_EPL_TC_LOSSLESS1 = 1,
    HAL_MT_NB_TM_EPL_TC_LOSSY0 = 2,
    HAL_MT_NB_TM_EPL_TC_LOSSY1 = 3,
    HAL_MT_NB_TM_EPL_TC_LAST
} hal_mt_nb_tm_epl_tc_type_t;

/* IPL FIFO classification */
typedef enum hal_mt_nb_tm_ipl_plq_s {
    HAL_MT_NB_TM_IPL_PLQ0 = 0, /* plq0 => lossy0 */
    HAL_MT_NB_TM_IPL_PLQ1,     /* plq1 => lossy1 */
    HAL_MT_NB_TM_IPL_PLQ2,     /* plq2 => lossless0 */
    HAL_MT_NB_TM_IPL_PLQ3,     /* plq3 => lossless1 */
    HAL_MT_NB_TM_IPL_PL_LAST
} hal_mt_nb_tm_ipl_plq_t;

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief The function is used to set the mapping of the PCP and the queue group.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Physical port id.
 * @param [in]    queue      - Ingress or egress queue.
 * @param [in]    ptr_pfc    - PFC interface structl.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter. CLX_E_TABLE_FULL,
 *                                         -- Table is full.
 * @return        CLX_E_NOT_INITED       - SDK module has not been initialized.
 */
clx_error_no_t
hal_mt_nb_tm_pfc_mapping_set(const uint32 unit,
                             const uint32 port,
                             const uint32 queue,
                             const clx_tm_pfc_mapping_cfg_t *ptr_pfc);

/**
 * @brief The function is used to get the mapping of the PCP and the queue group.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port id.
 * @param [in]     queue      - Ingress or egress queue.
 * @param [out]    ptr_pfc    - PFC interface struct.
 * @return         CLX_E_OK       - Operate success.
 * @return         CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_pfc_mapping_get(const uint32 unit,
                             const uint32 port,
                             const uint32 queue,
                             clx_tm_pfc_mapping_cfg_t *ptr_pfc);

clx_error_no_t
hal_mt_nb_tm_pfc_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_pfc_wb_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_pfcwd_wb_init(const uint32 unit, hal_io_wb_db_t *ptr_db);

clx_error_no_t
hal_mt_nb_tm_pfcwd_wb_deinit(const uint32 unit, hal_io_wb_db_t *ptr_db);
/**
 * @brief The function is used to init TM PFC HW & SW DB.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_pfc_rsrc_init(const uint32 unit);

/**
 * @brief The function is used to deinit TM PFC HW & SW DB.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_pfc_rsrc_deinit(const uint32 unit);

/**
 * @brief The function is used to init pfc information.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Other error.
 */
clx_error_no_t
hal_mt_nb_tm_pfc_cfg_init(const uint32 unit);

/**
 * @brief The function is used to set flow control mode.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port id.
 * @param [in]    mode    - Flow control mode(lossy, FC, PFC).
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Other error.
 */

clx_error_no_t
hal_mt_nb_tm_pfc_fc_mode_set(const uint32 unit, const uint32 port, const hal_tm_fc_t mode);

boolean
hal_mt_nb_tm_pfc_sq_lossless_is(const uint32 unit, const uint32 port, const uint32 queue);

boolean
hal_mt_nb_tm_pfc_oq_lossless_is(const uint32 unit, const uint32 port, const uint32 uc_queue);

clx_error_no_t
hal_mt_nb_tm_pfc_pri_to_queue_fifo_get(const uint32 unit,
                                       const uint32 port,
                                       const uint32 queue_id,
                                       uint32 *fifo);

clx_error_no_t
hal_mt_nb_tm_pfcwd_detect_pbm_handle(const uint32 unit,
                                     const clx_port_bitmap_t timer0_pbm,
                                     const clx_port_bitmap_t timer1_pbm);

clx_error_no_t
hal_mt_nb_tm_pfcwd_async_event_send(const uint32 unit,
                                    const clx_port_t port,
                                    const uint32 queue,
                                    const hal_tm_pfcwd_event_t event,
                                    const uint32 arg);
clx_error_no_t
hal_mt_nb_tm_pfcwd_state_disable_event_handle(const uint32 unit,
                                              const clx_port_t port,
                                              const uint8 queue_id,
                                              const hal_tm_pfcwd_event_t event,
                                              hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

clx_error_no_t
hal_mt_nb_tm_pfcwd_state_oper_event_handle(const uint32 unit,
                                           const clx_port_t port,
                                           const uint8 queue_id,
                                           const hal_tm_pfcwd_event_t event,
                                           hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

clx_error_no_t
hal_mt_nb_tm_pfcwd_state_storm_event_handle(const uint32 unit,
                                            const clx_port_t port,
                                            const uint8 queue_id,
                                            const hal_tm_pfcwd_event_t event,
                                            hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

clx_error_no_t
hal_mt_nb_tm_pfcwd_state_cfg_not_ready_event_handle(const uint32 unit,
                                                    const clx_port_t port,
                                                    const uint8 queue_id,
                                                    const hal_tm_pfcwd_event_t event,
                                                    hal_tm_pfcwd_queue_entry_t *ptr_runing_entry);

clx_error_no_t
hal_mt_nb_tm_pfc_rx_pri_msk_set(const uint32 unit, const uint32 port, boolean mask_en);
#endif /*end of HAL_MT_NB_TM_PFC_H*/
