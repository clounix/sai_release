/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_PKT_RSRC_H
#define HAL_MT_NB_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_pkt.h>

#include <hal/hal_pkt_rsrc.h>
#include <hal/mt/hal_mt_pkt_rsrc.h>

/**
 * @brief To map the reason from user reason bitmap to hw epp exception bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     user_bitmap    - The user reason bitmap.
 * @param [out]    hw_bitmap      - The hw reason bitmap.
 * @return         CLX_E_OK        - Success to map the reason.
 * @return         CLX_E_OTHERS    - Fail to map the reason.
 */
clx_error_no_t
hal_mt_nb_pkt_rsrc_user_bmp_to_pp_bmp_convert(const uint32 unit,
                                              const clx_pkt_rx_rsn_bmp_t user_bitmap,
                                              hal_mt_pkt_pp_rsn_bmp_t hw_bitmap);

/**
 * @brief To map the reason from user reason bitmap to hw epp exception bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     hw_bitmap      - The hw reason bitmap.
 * @param [out]    user_bitmap    - The user reason bitmap.
 * @return         CLX_E_OK        - Success to map the reason.
 * @return         CLX_E_OTHERS    - Fail to map the reason.
 */
clx_error_no_t
hal_mt_nb_pkt_rsrc_pp_bmp_to_user_bmp_convert(const uint32 unit,
                                              hal_mt_pkt_pp_rsn_bmp_t hw_bitmap,
                                              clx_pkt_rx_rsn_bmp_t user_bitmap);

/**
 * @brief To map the reason from hw cpu reason to hw epp exception bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     cpu_reason     - The user reason bitmap.
 * @param [out]    user_bitmap    - The hw reason bitmap.
 * @return         CLX_E_OK        - Success to map the reason.
 * @return         CLX_E_OTHERS    - Fail to map the reason.
 */
clx_error_no_t
hal_mt_nb_pkt_rsrc_pp_to_user_bmp_convert(const uint32 unit,
                                          const uint32 cpu_reason,
                                          clx_pkt_rx_rsn_bmp_t user_bitmap);
#endif /* End of HAL_VLAN_H */
