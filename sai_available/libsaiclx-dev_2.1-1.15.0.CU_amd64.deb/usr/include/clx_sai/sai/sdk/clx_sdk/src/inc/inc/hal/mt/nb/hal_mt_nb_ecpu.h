/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_ecpu.h
 * PURPOSE:
 *  Provide HAL driver API functions of ecpu module.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_NB_ECPU_H
#define HAL_MT_NB_ECPU_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_swc.h>
#include <hal/hal_ecpu.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO  DECLARATIONS
 */
#define HAL_MT_NB_ECPU_ITCM_LOW_ADDR  (0)
#define HAL_MT_NB_ECPU_ITCM_HI_ADDR   (0x100000)
#define HAL_MT_NB_ECPU_DTCM_LOW_ADDR  (0x20000000)
#define HAL_MT_NB_ECPU_DTCM_HI_ADDR   (0x20100000)
#define HAL_MT_NB_ECPU_ITCMBASE       (0)
#define HAL_MT_NB_ECPU_DTCMBASE       (0x20000000)
#define HAL_MT_NB_ECPU_ITCMBASE_CHAIN (0x51cbc00) /*The address of ITCM on the chain*/
#define HAL_MT_NB_ECPU_DTCMBASE_CHAIN (0x52cbc00) /*The address of DTCM on the chain*/
#define HAL_MT_NB_EADDR2CHADDR(eaddr) \
    ((eaddr) - HAL_MT_NB_ECPU_DTCMBASE + HAL_MT_NB_ECPU_DTCMBASE_CHAIN)
#define HAL_MT_NB_CHADDR2EADDR(chaddr) \
    ((chaddr) - HAL_MT_NB_ECPU_DTCMBASE_CHAIN + HAL_MT_NB_ECPU_DTCMBASE)

/* Define elink ring buffer basic macro
 */
#define HAL_MT_NB_RING_BUFFER_BLOCK_SIZE   (1024 * 32)
#define HAL_MT_NB_RING_BUFFER_CONTROL_SIZE (1024) /*ring buffer control area size*/
#define HAL_MT_NB_RING_BUFFER_SIZE                                                             \
    (HAL_MT_NB_RING_BUFFER_BLOCK_SIZE - HAL_MT_NB_RING_BUFFER_CONTROL_SIZE) /*ring buffer data \
                                                                               area size*/
#define HAL_MT_NB_RING_BUFFER_BUFFER_SIZE (256)                             /*each buffer size*/

#define HAL_MT_NB_RING_BUFFER_OFFSET (0xf0000) /*Offset address of ring buffer in ITCM :64k*/

#define HAL_MT_NB_RING_BUFFER_TXBUFF_ADDR \
    (HAL_MT_NB_ECPU_ITCMBASE_CHAIN + HAL_MT_NB_RING_BUFFER_OFFSET)
#define HAL_MT_NB_RING_BUFFER_TXBUFF_BASE \
    (HAL_MT_NB_RING_BUFFER_TXBUFF_ADDR + HAL_MT_NB_RING_BUFFER_CONTROL_SIZE)

#define HAL_MT_NB_RING_BUFFER_RXBUFF_ADDR \
    (HAL_MT_NB_RING_BUFFER_TXBUFF_ADDR + HAL_MT_NB_RING_BUFFER_BLOCK_SIZE)
#define HAL_MT_NB_RING_BUFFER_RXBUFF_BASE \
    (HAL_MT_NB_RING_BUFFER_RXBUFF_ADDR + HAL_MT_NB_RING_BUFFER_CONTROL_SIZE)

#define HAL_MT_NB_ECPU_PORT_MIN_BANDWIDTH  0
#define HAL_MT_NB_ECPU_PORT_MIN_BURST_SIZE 0
#define HAL_MT_NB_ECPU_PORT_MAX_BANDWIDTH  5000 // pps
#define HAL_MT_NB_ECPU_PORT_MAX_BURST_SIZE 50

#define HAL_MT_NB_TM_ECPU_QUEUE_NUM                     8
#define HAL_MT_NB_TM_ECPU_MBURST_CFG_ADDR               0x000D0000 // on DTCM address
#define HAL_MT_NB_TM_ECPU_MBURST_CLEAR_WATERMARK_ADDR   0x000D0FFC
#define HAL_MT_NB_TM_ECPU_MBURST_REPORT_ADDR            0x000E0000 // on DTCM address
#define HAL_MT_NB_TM_ECPU_MBURST_REPORT_PORTBITMAP_ADDR HAL_MT_NB_TM_ECPU_MBURST_REPORT_ADDR
#define HAL_MT_NB_TM_ECPU_MBURST_REPORT_EVENT_INFO_ADDR \
    (HAL_MT_NB_TM_ECPU_MBURST_REPORT_ADDR + 0x1000)
#define HAL_MT_NB_TM_HISTOGRAM_PORT_PER_PLANE   (32)
#define HAL_MT_NB_TM_ECPU_MBURST_PORT_NUM       (256)              // 256 front ports
#define HAL_MT_NB_TM_ECPU_MBURST_QUEUE_PRE_PORT (8)                // 8 uc queue per port

#define HAL_MT_NB_TM_ECPU_HEADROOM_CFG_ADDR             0x000FEC00 // on DTCM address
#define HAL_MT_NB_TM_ECPU_HEADROOM_CLEAR_WATERMARK_ADDR 0x000FEFFC // on DTCM address
#define HAL_MT_NB_TM_HEADROOM_COUNT_PORT_PER_PLANE      (40)
#define HAL_MT_NB_TM_ECPU_HEADROOM_QUEUE_PRE_PORT       (8)
#define HAL_MT_NB_TM_ECPU_HEADROOM_WATERMARK_ADDR       0x000FBC00

#define HAL_MT_NB_ECPU_FORBID_READ_BAC_ADDR     0x000D2000 // on DTCM address
#define HAL_MT_NB_ECPU_FORBID_READ_BAC_ACK_ADDR 0x000D2004 // on DTCM address
#define HAL_MT_NB_ECPU_WAIT_FLAG_DONE_LOOP      (1000)
#define HAL_MT_NB_ECPU_RAW_CONFIG_ADDR          0x000D0000
#define HAL_MT_NB_ECPU_RAW_CONFIG_LEN           (0x2000)

#define HAL_MT_NB_ECPU_RAW_BINARY_DEFAULT_PATH "/usr/lib/ecpu.bin"
/* DATA TYPE DECLARATIONS
 */

typedef struct hal_mt_nb_ecpu_mburst_cfg_s {
    uint8_t port[256];       /* Port number of mburst */
    uint32_t threshold0;     /* Threshold value of histogram sections */
    uint32_t threshold1;     /* Threshold value of histogram sections */
    uint32_t cpu_port_plane; /* CPU port plane */
    uint32_t enable;         /* Enable mburst detection */
} hal_mt_nb_ecpu_mburst_cfg_t;

typedef struct hal_mt_nb_tm_buf_mburst_s {
    uint32 flag;
    uint32 high_th;
    uint32 low_th;
    boolean enable;
} hal_mt_nb_ecpu_mburst_t;
#define HAL_MT_NB_ECPU_MBURST_FLAG_SET_HIGH_TH (1 << 0)
#define HAL_MT_NB_ECPU_MBURST_FLAG_SET_LOW_TH  (1 << 1)
#define HAL_MT_NB_ECPU_MBURST_FLAG_SET_ENABLE  (1 << 2)

#pragma pack(1)
typedef struct hal_mt_nb_ecpu_mburst_event_s {
    uint64_t valid : 1;
    uint64_t type : 1;
    uint64_t port : 8;
    uint64_t event_time : 58;
    uint64_t watermark : 20;
    uint64_t watermark_time : 40;
    // UI64_T rsv            : 18;  //32 * 4 = 128
} hal_mt_nb_ecpu_mburst_event_t;
#pragma pack()

#define HAL_ECPU_MBURST_LOCK(_unit_)                                             \
    HAL_COMMON_LOCK_RESOURCE(&_hal_mt_nb_ecpu_mburst_cb[(_unit_)].mutex_sema_id, \
                             CLX_SEMAPHORE_WAIT_FOREVER)
#define HAL_ECPU_MBURST_UNLOCK(_unit_) \
    HAL_COMMON_FREE_RESOURCE(&_hal_mt_nb_ecpu_mburst_cb[(_unit_)].mutex_sema_id)

typedef struct hal_mt_nb_ecpu_headroom_cfg_s {
    uint8 port[320]; /* Port number of headroom */
    uint32 enable;   /* Enable headroom statistics */
} hal_mt_nb_ecpu_headroom_cfg_t;

/* FUNCTION MACRO DECLARATIONS
 */
/**
 * @brief This API is used to init ecpu tx/rx hw information.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Successfully.
 * @return        CLX_E_NOT_INITED    - Ecpu not started.
 * @return        CLX_E_OTHERS        - Failed to init hardware.
 */
clx_error_no_t
hal_mt_nb_ecpu_hw_init(const uint32 unit);
/**
 * @brief This API is used to reboot ecpu.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK            - Successfully.
 * @return        CLX_E_NOT_INITED    - Ecpu not started.
 * @return        CLX_E_OTHERS        - Failed to reboot.
 */
clx_error_no_t
hal_mt_nb_ecpu_reboot(const uint32 unit);

/**
 * @brief This API is used to stop the ecpu of the specified unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop ecpu.
 */
clx_error_no_t
hal_mt_nb_ecpu_force_stop(const uint32 unit);

/**
 * @brief This API is used to start the ecpu of the specified unit.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    index    - Firmware index.
 * @return        CLX_E_OK                 - Successfully.
 * @return        CLX_E_OTHERS             - Failed to start ecpu.
 * @return        CLX_E_BAD_PARAMETER      - Failed to get firmware path.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Failed to get firmware description path.
 */
clx_error_no_t
hal_mt_nb_ecpu_start(const uint32 unit, const uint32 index);

/**
 * @brief This API is used to stop ecpu of the specified unit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop ecpu.
 */
clx_error_no_t
hal_mt_nb_ecpu_stop(const uint32 unit);

/**
 * @brief This API is used to read ecpu memory.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    addr    - Memory address.
 * @param [in]    len     - Memory length.
 * @param [in]    pbuf    - Buffer.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Failed to read memory.
 * @return        CLX_E_BAD_PARAMETER    - Parameters is invalid.
 */
clx_error_no_t
hal_mt_nb_ecpu_memory_read(const uint32 unit, const uint32 addr, const uint32 len, uint32 *pbuf);

/**
 * @brief This API is used to upload fireware to ecpu sram and start ecpu.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    path    - Fireware file name.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Failed to upload fireware.
 * @return        CLX_E_BAD_PARAMETER    - Failed to open fireware file,
 *                                         maybe it doesn't exist.
 */
clx_error_no_t
hal_mt_nb_ecpu_sram_fw_update(const uint32 unit, char *path);

/**
 * @brief This API is used to set microburst detection configure.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    mburst_cfg    - Configure.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Ecpu not runing.
 * @return        CLX_E_BAD_PARAMETER    - Configure maybe error.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_set(const uint32 unit, const hal_mt_nb_ecpu_mburst_t *mburst_cfg);

/**
 * @brief This API is used to set microburst detection configure.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    mburst_cfg    - Configure.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_OTHERS           - Ecpu not runing.
 * @return        CLX_E_BAD_PARAMETER    - Configure maybe error.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_get(const uint32 unit, hal_mt_nb_ecpu_mburst_t *mburst_cfg);

/**
 * @brief This API is used to add microburst detection queue.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Port.
 * @param [in]    uc_queue    - Queue_id with 0-7.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Error with read config failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_queue_add(const uint32 unit, const uint32 port, const uint32 uc_queue);

/**
 * @brief This API is used to del microburst detection queue.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Port.
 * @param [in]    uc_queue    - Queue_id with 0-7.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Error with read config failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_queue_del(const uint32 unit, const uint32 port, const uint32 uc_queue);

/**
 * @brief This API is used to tell ecpu clear microburst watermark.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to stop microburst detection.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_watermark_clear(const uint32 unit);

/**
 * @brief This API is used to register ecpu microburst detection callback.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    ptr_func      - Callback function.
 * @param [in]    ptr_cookie    - Callback cookie.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to register microburst detection callback.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_cb_register(const uint32 unit,
                                  const clx_tm_mburst_func_t ptr_func,
                                  void *ptr_cookie);

/**
 * @brief This API is used to deregister ecpu microburst detection callback.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    ptr_func      - Callback function.
 * @param [in]    ptr_cookie    - Callback cookie.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to register microburst detection callback.
 */
clx_error_no_t
hal_mt_nb_ecpu_mburst_cb_deregister(const uint32 unit,
                                    const clx_tm_mburst_func_t ptr_func,
                                    void *ptr_cookie);

/**
 * @brief This API is used to register ecpu interrupt callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to register interrupt callback.
 */
clx_error_no_t
hal_mt_nb_ecpu_intr_register(const uint32 unit);

/**
 * @brief This API is used to unregister ecpu interrupt callback.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed to register interrupt callback.
 */
clx_error_no_t
hal_mt_nb_ecpu_intr_unregister(const uint32 unit);

/**
 * @brief This API is used to trigger host to ecpu interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_nb_intr_to_ecpu_trigger(const uint32 unit);

/**
 * @brief This API is used to clear ecpu to host interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_from_ecpu_intr_clr(const uint32 unit);

/**
 * @brief This API is used to enable ecpu to host interrupt.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_from_ecpu_intr_enable(const uint32 unit);

/**
 * @brief This API is used to get diag log buffer information.
 *
 * @param [out]    buf_info    - Buffer information pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_diag_log_buf_info_get(hal_ecpu_diag_buf_info_t *buf_info);

/**
 * @brief This API is used to get dtcm address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_dtcm_addr_get(uint64 *addr);

/**
 * @brief This API is used to get dtcm on chain address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_dtcm_on_chain_addr_get(uint64 *addr);

/**
 * @brief This API is used to get itcm address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_itcm_addr_get(uint64 *addr);

/**
 * @brief This API is used to get itcm on chain address.
 *
 * @param [out]    addr    - Dtcm address pointer.
 * @return         CLX_E_OK    - Successfully.
 */
clx_error_no_t
hal_mt_nb_ecpu_itcm_on_chain_addr_get(uint64 *addr);

/**
 * @brief This API is used to init ecpu ring buffer tx handle.
 *
 * @param [in]    unit    - Device unit number @param [inout] pbuf - Ring buffer tx handler.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_ecpu_ring_buf_tx_handler_init(const uint32 unit, hal_ecpu_ring_buffer_control_t *pbuf);

/**
 * @brief This API is used to init ecpu ring buffer rx handle.
 *
 * @param [in]    unit    - Device unit number @param [inout] pbuf - Ring buffer rx handler.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_ecpu_ring_buf_rx_handler_init(const uint32 unit, hal_ecpu_ring_buffer_control_t *pbuf);

/**
 * @brief This API is used to set port limit.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Successfully.
 * @return        CLX_E_BAD_PARAMETER    - Parameter is wrong.
 */
clx_error_no_t
hal_mt_nb_ecpu_port_limit(const uint32 unit);

/**
 * @brief This API is used to tell ecpu not read bac. set true to forbid read back.
 *        set false to allow read back.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    forbid    - Forbid read back.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_forbid_read_bac_set(const uint32 unit, boolean forbid);
/**
 * @brief This API is used to tell ecpu clear headroom watermark.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    port     - Port number.
 * @param [in]    queue    - Queue number.
 * @return        CLX_E_OK        - Successfully.
 * @return        CLX_E_OTHERS    - Failed.
 */
clx_error_no_t
hal_mt_nb_ecpu_headroom_watermark_clr(const uint32 unit, const uint32 port, const uint32 queue);

/**
 * @brief This API is used to check whether headroom statistics is running.
 *
 * @param [in]    unit    - Device unit number.
 * @return        TRUE     - Headroom statistics is running.
 * @return        FALSE    - Headroom statistics is not running.
 */
boolean
hal_mt_nb_ecpu_headroom_is_running(const uint32 unit);

#endif /* #ifndef HAL_MT_NB_ECPU_H */
