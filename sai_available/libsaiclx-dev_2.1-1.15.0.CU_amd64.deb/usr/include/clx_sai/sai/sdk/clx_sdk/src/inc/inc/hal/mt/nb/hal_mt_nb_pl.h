/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/**
 * @brief Namchabarwa PL defines.
 *
 * @file hal_mt_nb.h.
 *
 */

#ifndef __HAL_MT_NB_PL_H__
#define __HAL_MT_NB_PL_H__

#include <util/util_log.h>
#include <math.h>

#define HAL_MT_NB_DP0_ETH_PORT_MIN   0
#define HAL_MT_NB_DP0_ETH_PORT_MAX   15
#define HAL_MT_NB_DP1_ETH_PORT_MIN   16
#define HAL_MT_NB_DP1_ETH_PORT_MAX   31
#define HAL_MT_NB_ETH_PORT_PER_SLICE 32
#define HAL_MT_NB_CPU_PORT           32
#define HAL_MT_NB_ECPU_PORT          33
#define HAL_MT_NB_CPI_PORT0          34
#define HAL_MT_NB_CPI_PORT1          35
#define HAL_MT_NB_CPX_PORT_LAST      35
#define HAL_MT_NB_LBM_DP0            36
#define HAL_MT_NB_LBM_DP1            37

#define HAL_MT_NB_IPL_PST_DP0_VPORT_MAX 17
#define HAL_MT_NB_IPL_PST_DP1_VPORT_MAX 16

#define HAL_MT_NB_PL_PAUSE_MODE      0
#define HAL_MT_NB_PL_PFC_MODE        1
#define HAL_MT_NB_PL_FC_DIS_MODE     2
#define HAL_MT_NB_PL_PAUSE_MODE_LAST 3

#define HAL_MT_NB_PL_DEAD_LOCK_PAUSE_MODE      0
#define HAL_MT_NB_PL_DEAD_LOCK_PFC_MODE        1
#define HAL_MT_NB_PL_DEAD_LOCK_FC_DIS_MODE     2
#define HAL_MT_NB_PL_DEAD_LOCK_PFC_DIS_MODE    3
#define HAL_MT_NB_PL_DEAD_LOCK_PAUSE_MODE_LAST 4

#define HAL_MT_NB_PL_VLAN_PCP_NUM    8
#define HAL_MT_NB_PL_VLAN_DEI_NUM    2
#define HAL_MT_NB_PL_IPV4_6_DSCP_NUM 64
#define HAL_MT_NB_PL_MPLS_EXP_NUM    8

#define HAL_MT_NB_PL_PST_SCH_MODE_NORMAL      0
#define HAL_MT_NB_PL_PST_SCH_MODE_CUT_THROUGH 1

#define HAL_MT_NB_IPL_DATA_BUFF_BANK_SIZE 256

#define HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(SIZE_KB) \
    SIZE_KB * 1024 / HAL_MT_NB_IPL_DATA_BUFF_BANK_SIZE
// #define HAL_MT_NB_IPL_DATA_BUFF_TOTAL_SIZE_IN_KB(SIZE_KB)  SIZE_KB * 1024 /
// HAL_MT_NB_IPL_DATA_BUFF_BANK_SIZE #define
// HAL_MT_NB_IPL_DATA_BUFF_SIZE_IN_KB(SIZE_KB)        SIZE_KB * 1024 /
// HAL_MT_NB_IPL_DATA_BUFF_BANK_SIZE

#define HAL_MT_NB_IPL_DATA_BUFF_THD_WIDTH 12

#define HAL_MT_NB_PL_ETH_PORT_SPD(SPD)                      \
    ((SPD == CLX_PORT_SPEED_800G) ?                         \
         7 :                                                \
         ((SPD == CLX_PORT_SPEED_400G) ?                    \
              6 :                                           \
              ((SPD == CLX_PORT_SPEED_200G) ?               \
                   5 :                                      \
                   ((SPD == CLX_PORT_SPEED_100G) ?          \
                        4 :                                 \
                        ((SPD == CLX_PORT_SPEED_50G) ?      \
                             3 :                            \
                             ((SPD == CLX_PORT_SPEED_40G) ? \
                                  2 :                       \
                                  ((SPD == CLX_PORT_SPEED_25G) ? 1 : 0)))))))

#define HAL_MT_NB_PL_BANDWIDTH_100G (100)
#define HAL_MT_NB_PL_BANDWIDTH_200G (200)
#define HAL_MT_NB_PL_BANDWIDTH_400G (400)
#define HAL_MT_NB_PL_BANDWIDTH_800G (800)

#define HAL_MT_NB_PL_LSY_SPD_800G_TH    (0x1c)
#define HAL_MT_NB_PL_LSY_SPD_400G_TH    (0xc)
#define HAL_MT_NB_PL_LSY_SPD_200G_TH    (0x6)
#define HAL_MT_NB_PL_LSY_SPD_100G_TH    (0x4)
#define HAL_MT_NB_PL_LSY_SPD_50G_TH     (0x2)
#define HAL_MT_NB_PL_LSY_SPD_40G_TH     (0x2)
#define HAL_MT_NB_PL_LSY_SPD_25G_TH     (0x1)
#define HAL_MT_NB_PL_LSY_SPD_10G_TH     (0x1)
#define HAL_MT_NB_PL_LSY_SPD_800G_CT_TH (0x4) // EXP, make sure 99% traffic, umac not under run drop
#define HAL_MT_NB_PL_LSY_SPD_400G_CT_TH (0x2)
#define HAL_MT_NB_PL_LSY_SPD_200G_CT_TH (0x1)
#define HAL_MT_NB_PL_LSY_SPD_100G_CT_TH (0x1)
#define HAL_MT_NB_PL_LSY_SPD_50G_CT_TH  (0x1)
#define HAL_MT_NB_PL_LSY_SPD_40G_CT_TH  (0x1)
#define HAL_MT_NB_PL_LSY_SPD_25G_CT_TH  (0x1)
#define HAL_MT_NB_PL_LSY_SPD_10G_CT_TH  (0x1)
#define HAL_MT_NB_PL_LLS_SPD_800G_TH    (0x1c)
#define HAL_MT_NB_PL_LLS_SPD_400G_TH    (0x1c)
#define HAL_MT_NB_PL_LLS_SPD_200G_TH    (0x1c)
#define HAL_MT_NB_PL_LLS_SPD_100G_TH    (0x1c)
#define HAL_MT_NB_PL_LLS_SPD_50G_TH     (0x1c)
#define HAL_MT_NB_PL_LLS_SPD_40G_TH     (0x1c)
#define HAL_MT_NB_PL_LLS_SPD_25G_TH     (0x1c)
#define HAL_MT_NB_PL_LLS_SPD_10G_TH     (0x1c)

#define HAL_MT_NB_PL_RUNT_DFT         (64)
#define HAL_MT_NB_PL_PPH_LENGTH       (40)
#define HAL_MT_NB_PL_CXH_LENGTH       (20)
#define HAL_MT_NB_PL_OUTER_MAC_LENGTH (12)

#define HAL_MT_NB_PL_ETH_MODE_RUNT_DFT   (HAL_MT_NB_PL_RUNT_DFT)
#define HAL_MT_NB_PL_MXHDR_MODE_RUNT_DFT (HAL_MT_NB_PL_RUNT_DFT + HAL_MT_NB_PL_CXH_LENGTH)
#define HAL_MT_NB_PL_CPX_RAW_MODE_RUNT_DFT \
    (HAL_MT_NB_PL_RUNT_DFT + HAL_MT_NB_PL_PPH_LENGTH + HAL_MT_NB_PL_OUTER_MAC_LENGTH)
#define HAL_MT_NB_PL_CPU_PORT_RUNT_DFT (HAL_MT_NB_PL_RUNT_DFT + HAL_MT_NB_PL_PPH_LENGTH)

#define HAL_MT_NB_PL_GEN_PKT_DURATION     (100)
#define HAL_MT_NB_PL_GEN_PKT_LEN_MAX      (9600)
#define HAL_MT_NB_PL_GEN_PKT_LEN_MIN      (64)
#define HAL_MT_NB_PL_GEN_PKT_DATA_MAX     (9640)
#define HAL_MT_NB_PL_GEN_PKT_MAC_ADDR_LEN (6)
#define HAL_MT_NB_PL_CPX_DATA_BUF_REG_NUM (4)
#define HAL_MT_NB_PL_LINE_DATA_SIZE       (256)
#define HAL_MT_NB_PL_LINE_MAX_NUM         (128)
#define HAL_MT_NB_PL_BANK_DATA_SIZE       (16)
#define HAL_MT_NB_PL_DATA_ADDR_OFST       (5)
#define HAL_MT_NB_PL_BYTE_NUM_PRE_REG     (4)
#define HAL_MT_NB_PL_BYTE_BIT_OFST        (8)
#define HAL_MT_NB_PL_LINE_BANK_NUM        (24)
#define HAL_MT_NB_PL_LINE_DATABANK_NUM    (16)
#define HAL_MT_NB_PL_DPORT_OFST           (7)
#define HAL_MT_NB_PL_EOP_OFST             (13)
#define HAL_MT_NB_PL_PAYLOAD_OFST         (13)
#define HAL_MT_NB_PL_FRAG_SIZE_OFST       (14)
#define HAL_MT_NB_PL_CORE_CLOCK_MHZ       (1350)
#define HAL_MT_NB_PL_ETH_TYPE             (0x8809)

// fd buffer

// BANDWIDTH MODE
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PFC_Q0_DROP_THD   (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PFC_Q0_TRUNC_THD  (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PAUSE_Q0_DROP_THD (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PAUSE_Q0_TRUNC_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PFC_Q1_DROP_THD   (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PFC_Q1_TRUNC_THD  (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PAUSE_Q1_DROP_THD (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PAUSE_Q1_TRUNC_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))

// lossless queue num mode and speed mode
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PFC_Q2_DROP_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(45))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PFC_Q2_TRUNC_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q2_DROP_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(44))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q2_TRUNC_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(48))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_100G_Q2_DROP_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(90))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_100G_Q3_DROP_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(90))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_100G_Q3_TRUNC_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(100))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_800G_Q3_DROP_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(374))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_800G_Q3_TRUNC_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(384))

#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PFC_Q3_DROP_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(45))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PFC_Q3_TRUNC_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q3_DROP_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(64))
#define HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q3_TRUNC_THD \
    (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))

// set 100G default xon thd to 12KB, xoff = 16KB

#define HAL_MT_NB_IPL_DATA_BUFF_100G_PFC_XON   (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(26))
#define HAL_MT_NB_IPL_DATA_BUFF_PFC_XON        (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(13))
#define HAL_MT_NB_IPL_DATA_BUFF_100G_PFC_XOFF  (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(30))
#define HAL_MT_NB_IPL_DATA_BUFF_PFC_XOFF       (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(15))
#define HAL_MT_NB_IPL_DATA_BUFF_100G_PAUSE_XON (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(26))
#define HAL_MT_NB_IPL_DATA_BUFF_PAUSE_XON      (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(18))
#define HAL_MT_NB_IPL_DATA_BUFF_PAUSE_XOFF     (HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(20))

// #define
// HAL_MT_NB_IPL_DATA_BUFF_FD_BUF_START_ADDR(HAL_MT_NB_IPL_DATA_BUFF_THD_SIZE_IN_KB(18))
// #define HAL_MT_NB_IPL_PFC_UMAC_FD_BUF_SIZE
// (HAL_MT_NB_IPL_DATA_BUFF_SIZE_IN_KB(24))  //384
#define HAL_MT_NB_IPL_PFC_UMAC_FD_BUF_SIZE   (384) // 384
#define HAL_MT_NB_IPL_PAUSE_UMAC_FD_BUF_SIZE (384)

#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P0 (0)
#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P1 (3072)
#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P2 (6144)
#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P3 (9216)
#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P4 (12288)
#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P5 (15360)
#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P6 (18432)
#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P7 (21504)

#define HAL_MT_NB_IPL_100G_IOS_MIN_SIZE (16)

#define HAL_MT_NB_IPL_UMAC_FD_BUF_SIZE(MODE, BANDWIDTH)                            \
    ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                             \
         (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_PFC_UMAC_FD_BUF_SIZE) :         \
         (((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                     \
               (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_PAUSE_UMAC_FD_BUF_SIZE) : \
               0)))

#define HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR(PORT)                                                    \
    ((PORT % 8 == 0) ?                                                                             \
         (HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P0) :                                                  \
         ((PORT % 8 == 1) ?                                                                        \
              (HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P1) :                                             \
              ((PORT % 8 == 2) ?                                                                   \
                   (HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P2) :                                        \
                   ((PORT % 8 == 3) ?                                                              \
                        (HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P3) :                                   \
                        ((PORT % 8 == 4) ?                                                         \
                             (HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P4) :                              \
                             ((PORT % 8 == 5) ?                                                    \
                                  (HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P5) :                         \
                                  ((PORT % 8 == 6) ?                                               \
                                       (HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P6) :                    \
                                       ((PORT % 8 == 7) ? (HAL_MT_NB_IPL_UMAC_FD_BUF_ST_ADDR_P7) : \
                                                          0))))))))

// lossy queue drop thd
#define HAL_MT_NB_IPL_DATA_BUFF_Q0_DROP_THD(MODE, BANDWIDTH)                                      \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                                 \
         (0) :                                                                                    \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                                       \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PFC_Q0_DROP_THD) :        \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                                \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PAUSE_Q0_DROP_THD) : \
                   0)))

#define HAL_MT_NB_IPL_DATA_BUFF_Q1_DROP_THD(MODE, BANDWIDTH)                                       \
    ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                                             \
         ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                             \
              (ceil(2 * (BANDWIDTH) / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PFC_Q1_DROP_THD) :   \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PFC_Q1_DROP_THD)) :        \
         ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                                      \
              ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                        \
                   (ceil(2 * (BANDWIDTH) / 100.00) *                                               \
                    HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PFC_Q1_DROP_THD) :                               \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_LOSSY_PAUSE_Q1_DROP_THD)) : \
              0))

// lossy queue trunc thd
#define HAL_MT_NB_IPL_DATA_BUFF_Q0_TRUNC_THD(MODE, BANDWIDTH)                    \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                \
         (0) :                                                                   \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                      \
              (HAL_MT_NB_IPL_DATA_BUFF_Q0_DROP_THD(MODE, BANDWIDTH) + 40) :      \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                               \
                   (HAL_MT_NB_IPL_DATA_BUFF_Q0_DROP_THD(MODE, BANDWIDTH) + 40) : \
                   0)))

#define HAL_MT_NB_IPL_DATA_BUFF_Q1_TRUNC_THD(MODE, BANDWIDTH)             \
    ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                    \
         (HAL_MT_NB_IPL_DATA_BUFF_Q1_DROP_THD(MODE, BANDWIDTH) + 40) :    \
         ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                             \
              HAL_MT_NB_IPL_DATA_BUFF_Q1_DROP_THD(MODE, BANDWIDTH) + 40 : \
              0))

#define HAL_MT_NB_IPL_DATA_BUFF_XON_THD(MODE, BANDWIDTH)                            \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                   \
         (HAL_MT_NB_IPL_DATA_BUFF_100G_PFC_XON) :                                   \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                         \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_PFC_XON) :        \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                  \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_PAUSE_XON) : \
                   0)))

#define HAL_MT_NB_IPL_DATA_BUFF_XOFF_THD(MODE, BANDWIDTH)                            \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                    \
         (HAL_MT_NB_IPL_DATA_BUFF_100G_PFC_XOFF) :                                   \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                          \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_PFC_XOFF) :        \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                   \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_PAUSE_XOFF) : \
                   0)))

// lossless queue drop thd
#define HAL_MT_NB_IPL_DATA_BUFF_Q2_DROP_THD(MODE, BANDWIDTH)                                  \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                             \
         (0) :                                                                                \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                                   \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PFC_Q2_DROP_THD) : \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ? 0 : 0)))

#define HAL_MT_NB_IPL_DATA_BUFF_Q3_DROP_THD(MODE, BANDWIDTH)                                  \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                             \
         HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_100G_Q3_DROP_THD :                                  \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                                   \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PFC_Q3_DROP_THD) : \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                            \
                   ((HAL_MT_NB_PL_BANDWIDTH_800G == BANDWIDTH) ?                              \
                        HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_800G_Q3_DROP_THD :                   \
                        (ceil(BANDWIDTH / 100.00) *                                           \
                         HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_PAUSE_Q3_DROP_THD)) :               \
                   0)))

// lossless queue trunc thd
#define HAL_MT_NB_IPL_DATA_BUFF_Q2_TRUNC_THD(MODE, BANDWIDTH)             \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                         \
         (0) :                                                            \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                               \
              HAL_MT_NB_IPL_DATA_BUFF_Q2_DROP_THD(MODE, BANDWIDTH) + 40 : \
              (MODE == HAL_MT_NB_PL_PFC_MODE) ? 0 :                       \
                                                0))

#define HAL_MT_NB_IPL_DATA_BUFF_Q3_TRUNC_THD(MODE, BANDWIDTH)                  \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                              \
         HAL_MT_NB_IPL_DATA_BUFF_LOSSLESS_100G_Q3_TRUNC_THD :                  \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                    \
              (HAL_MT_NB_IPL_DATA_BUFF_Q3_DROP_THD(MODE, BANDWIDTH) + 40) :    \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                             \
                   HAL_MT_NB_IPL_DATA_BUFF_Q3_DROP_THD(MODE, BANDWIDTH) + 40 : \
                   0)))

// dedicate size
#define HAL_MT_NB_IPL_DATA_BUFF_Q0_IOS_MIN_SIZE(MODE, BANDWIDTH)                  \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                 \
         (0) :                                                                    \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                       \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE) :      \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE) : \
                   0)))

#define HAL_MT_NB_IPL_DATA_BUFF_Q1_IOS_MIN_SIZE(MODE, BANDWIDTH)                  \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                 \
         (2 * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE) :                                  \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                       \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE) :      \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                \
                   (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE) : \
                   0)))

#define HAL_MT_NB_IPL_DATA_BUFF_Q2_IOS_MIN_SIZE(MODE, BANDWIDTH)             \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                            \
         (0) :                                                               \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                  \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE) : \
              (((MODE == HAL_MT_NB_PL_PAUSE_MODE) ? 0 : 0))))

#define HAL_MT_NB_IPL_DATA_BUFF_Q3_IOS_MIN_SIZE(MODE, BANDWIDTH)                      \
    ((HAL_MT_NB_PL_BANDWIDTH_100G == BANDWIDTH) ?                                     \
         2 * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE :                                        \
         ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                           \
              (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE) :          \
              ((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                    \
                   (2 * ceil(BANDWIDTH / 100.00) * HAL_MT_NB_IPL_100G_IOS_MIN_SIZE) : \
                   0)))

#define HAL_MT_NB_IPL_ETH_PORT_EN_START 0
#define HAL_MT_NB_IPL_ETH_PORT_EN_END   0
#define HAL_MT_NB_IPL_ETH_PORT_EN_WIDTH \
    (HAL_MT_NB_IPL_ETH_PORT_EN_END - HAL_MT_NB_IPL_ETH_PORT_EN_START + 1)
#define HAL_MT_NB_IPL_ETH_FABRIC_PORT_EN_START 1
#define HAL_MT_NB_IPL_ETH_FABRIC_PORT_EN_END   1
#define HAL_MT_NB_IPL_ETH_FABRIC_PORT_EN_WIDTH \
    (HAL_MT_NB_IPL_ETH_FABRIC_PORT_EN_END - HAL_MT_NB_IPL_ETH_FABRIC_PORT_EN_START + 1)
#define HAL_MT_NB_IPL_ETH_PFC_MODE_EN_START 2
#define HAL_MT_NB_IPL_ETH_PFC_MODE_EN_END   2
#define HAL_MT_NB_IPL_ETH_PFC_MODE_EN_WIDTH \
    (HAL_MT_NB_IPL_ETH_PFC_MODE_EN_END - HAL_MT_NB_IPL_ETH_PFC_MODE_EN_START + 1)
#define HAL_MT_NB_IPL_ETH_IGNORE_TM_PFC_START 3
#define HAL_MT_NB_IPL_ETH_IGNORE_TM_PFC_END   3
#define HAL_MT_NB_IPL_ETH_IGNORE_TM_PFC_WIDTH \
    (HAL_MT_NB_IPL_ETH_IGNORE_TM_PFC_END - HAL_MT_NB_IPL_ETH_IGNORE_TM_PFC_START + 1)
#define HAL_MT_NB_IPL_ETH_READ_LIMIT_START 4
#define HAL_MT_NB_IPL_ETH_READ_LIMIT_END   7
#define HAL_MT_NB_IPL_ETH_READ_LIMIT_WIDTH \
    (HAL_MT_NB_IPL_ETH_READ_LIMIT_END - HAL_MT_NB_IPL_ETH_READ_LIMIT_START + 1)

#define HAL_MT_NB_IPL_PLTC_MPLS_DEPTH   64
#define HAL_MT_NB_IPL_PLTC_VLAN_DEPTH   128
#define HAL_MT_NB_IPL_PLTC_IPV4_6_DEPTH 512

#define HAL_MT_NB_IPL_SOFT_RESET_VALID_LEVEL 0
#define HAL_MT_NB_IPL_APP_VLAN_ETYPE_MAX     8

#define HAL_MT_NB_EPL_PFC_UMAC_FD_BUF_SIZE   (341) // 384
#define HAL_MT_NB_EPL_PAUSE_UMAC_FD_BUF_SIZE (341)

#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P0 (0)
#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P1 (1024)
#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P2 (2048)
#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P3 (3072)
#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P4 (4096)
#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P5 (5120)
#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P6 (6144)
#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P7 (7168)

#define HAL_MT_NB_EPL_UMAC_FD_BUF_SIZE(MODE, BANDWIDTH)                            \
    ((MODE == HAL_MT_NB_PL_PFC_MODE) ?                                             \
         (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_EPL_PFC_UMAC_FD_BUF_SIZE) :         \
         (((MODE == HAL_MT_NB_PL_PAUSE_MODE) ?                                     \
               (ceil(BANDWIDTH / 100.00) * HAL_MT_NB_EPL_PAUSE_UMAC_FD_BUF_SIZE) : \
               0)))

#define HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR(PORT)                                                    \
    ((PORT % 8 == 0) ?                                                                             \
         (HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P0) :                                                  \
         ((PORT % 8 == 1) ?                                                                        \
              (HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P1) :                                             \
              ((PORT % 8 == 2) ?                                                                   \
                   (HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P2) :                                        \
                   ((PORT % 8 == 3) ?                                                              \
                        (HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P3) :                                   \
                        ((PORT % 8 == 4) ?                                                         \
                             (HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P4) :                              \
                             ((PORT % 8 == 5) ?                                                    \
                                  (HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P5) :                         \
                                  ((PORT % 8 == 6) ?                                               \
                                       (HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P6) :                    \
                                       ((PORT % 8 == 7) ? (HAL_MT_NB_EPL_UMAC_FD_BUF_ST_ADDR_P7) : \
                                                          0))))))))

typedef struct HAL_MT_NB_IPL_APP_PARSE_S {
    uint32 jumbo_etype;
    uint32 skip2_len;
    uint32 skip1_len;
    uint32 skip1_etype;
    uint32 skip2_etype;
    uint32 inner_etype[HAL_MT_NB_IPL_APP_VLAN_ETYPE_MAX];
    uint32 outer_etype[HAL_MT_NB_IPL_APP_VLAN_ETYPE_MAX];
} HAL_MT_NB_IPL_APP_PARSE_T;

typedef struct HAL_MT_NB_IPL_APP_SPE_MAC_S {
    uint32 spe_mac_da[2];
    uint32 spe_mac_mask[2];
} HAL_MT_NB_IPL_APP_SPE_MAC_T;

typedef struct HAL_MT_NB_IPL_APP_TC2QUEUE_MIX_S {
    uint32 cfg_use_l3;
    uint32 ctrl_pkt_tc;
    uint32 unknown_tc;
} HAL_MT_NB_IPL_APP_TC2QUEUE_MIX_T;

typedef struct HAL_MT_NB_PL_TC_S {
    uint32 que[4]; // tc_value: range 0~7
} HAL_MT_NB_PL_TC_T;

typedef struct HAL_MT_NB_PL_LOSSY_THD_S {
    uint32 q0_drop;
    uint32 q0_trunc;
    uint32 q1_drop;
    uint32 q1_trunc;
} HAL_MT_NB_PL_LOSSY_THD_T;

typedef struct HAL_MT_NB_PL_LOSSLESS_THD_S {
    uint32 q2_drop;
    uint32 q2_trunc;
    uint32 q3_drop;
    uint32 q3_trunc;
} HAL_MT_NB_PL_LOSSLESS_THD_T;

typedef struct HAL_MT_NB_PL_PAUSE_THD_S {
    uint32 q2_xon;
    uint32 q3_xon;
    uint32 q2_xoff;
    uint32 q3_xoff;
} HAL_MT_NB_PL_PAUSE_THD_T;

typedef struct HAL_MT_NB_PL_BUFF_MODE_S {
    uint32 mode; // 0:8x100g three queue pfc, 1:8x100g three queue pause, 2:common pfc, 3:common
                 // pause
    uint32 channel_num; // total enable port num of one umac
    uint32 bandwidth;
} HAL_MT_NB_PL_BUFF_MODE_T;

typedef struct HAL_MT_NB_PL_PST_BUFF_SCH_S {
    uint32 pst_sch_mode; // 0:normal, 1:cut_through
    uint32 bandwidth;
    uint32 limit_rate;
} HAL_MT_NB_PL_PST_BUFF_SCH_T;

typedef struct HAL_MT_NB_IPL_FD_BUFF_ADDR_S {
    uint32 q0_addr;
    uint32 q1_addr;
    uint32 q2_addr;
    uint32 q3_addr;
} HAL_MT_NB_IPL_FD_BUFF_ADDR_T;

typedef struct HAL_MT_NB_IPL_BUFF_SIZE_S {
    uint32 q0_size;
    uint32 q1_size;
    uint32 q2_size;
    uint32 q3_size;
} HAL_MT_NB_IPL_BUFF_SIZE_T;

typedef struct HAL_MT_NB_EPL_FD_BUFF_ADDR_S {
    uint32 q0_addr;
    uint32 q1_addr;
    uint32 q2_addr;
} HAL_MT_NB_EPL_FD_BUFF_ADDR_T;

typedef struct HAL_MT_NB_EPL_BUFF_SIZE_S {
    uint32 q0_size;
    uint32 q1_size;
    uint32 q2_size;
} HAL_MT_NB_EPL_BUFF_SIZE_T;

typedef struct HAL_MT_NB_IPL_FD_BUFF_S {
    HAL_MT_NB_IPL_BUFF_SIZE_T size;
    HAL_MT_NB_IPL_FD_BUFF_ADDR_T addr;
} HAL_MT_NB_IPL_FD_BUFF_T;

typedef struct HAL_MT_NB_EPL_FD_BUFF_S {
    HAL_MT_NB_EPL_BUFF_SIZE_T size;
    HAL_MT_NB_EPL_FD_BUFF_ADDR_T addr;
} HAL_MT_NB_EPL_FD_BUFF_T;

typedef struct HAL_MT_NB_PL_BUFF_CFG_S {
    HAL_MT_NB_PL_LOSSY_THD_T ipl_lossy_thd;
    HAL_MT_NB_PL_LOSSLESS_THD_T ipl_lossless_thd;
    HAL_MT_NB_PL_PAUSE_THD_T ipl_pause_thd;
    HAL_MT_NB_IPL_BUFF_SIZE_T ipl_min_size;
    HAL_MT_NB_IPL_FD_BUFF_T ipl_fd_buff;
    HAL_MT_NB_EPL_FD_BUFF_T epl_fd_buff;
} HAL_MT_NB_PL_BUFF_CFG_T;

typedef struct HAL_MT_NB_PL_BUFF_CNT_S {
    uint32 in_total_cnt;    // received pkt count for ether port not including dropped packet
    uint32 out_total_cnt;   // received pkt count for ether port
    uint32 que_cnt[4];      // count remaing in data buffer for 4 queues, EPL only 3 queues
    uint32 hrm_num_used[2]; // IPL Normal port only. queue2/queue3
    uint32 empty;           // IPL CPX only
    uint32 afull;           // IPL CPX only
} HAL_MT_NB_PL_BUFF_CNT_T;

typedef struct HAL_MT_NB_IPL_ETH_CFG_S {
    uint32 port_spd;
    uint32 port_en;
    uint32 mode; // {fast_tm_pfc, pfc_mode, fabric_mode}
    uint32 leak_en;
    uint32 leak_size[2];

#define HAL_MT_NB_IPL_ETH_ENABLE   (1 << 0)
#define HAL_MT_NB_IPL_ETH_MODE     (1 << 1)
#define HAL_MT_NB_IPL_ETH_PORT_SPD (1 << 2)
    uint32 flag;
} HAL_MT_NB_IPL_ETH_CFG_T;

typedef struct HAL_MT_NB_PL_ETH_LEAK_S {
    uint32 lossy_leak_en;
    uint32 lossy_leak_size; // 20bit
    uint32 lossless_leak_en;
    uint32 lossless_leak_size;
} HAL_MT_NB_PL_ETH_LEAK_T;

typedef struct HAL_MT_NB_IPL_GLOBAL_S {
    uint32 dp_pst_sch_en;     //{dp1 and dp0} 1+1
    uint32 dp_pst_bubble_en;  //{dp1 and dp0} 1
    uint32 dp_pst_bubble_clr; //{dp1 and dp0} 1+1
} HAL_MT_NB_IPL_GLOBAL_T;

typedef struct HAL_MT_NB_IPL_CFG_CPX_PORT_S {
    uint32 en;               // port enable
    uint32 mode;             // 0-cpu, 1-cpi
    uint32 have_pph_already; // 0-no have pph,need insert, 1-noneed insert
    uint32 pfc_mode;         // only for cpi, 0-pause, 1-pfc
    uint32 id_sel;           // 2'b00-32, 01-33, 10-34, 11-35
    uint32 fast_tm_pfc;      // 1:ipl_pfc|tm_pfc, 0:ipl_pfc
    uint32 forced_mode;      // 2'b00/11-nomal, 01-force fc, 10-force rdy
} HAL_MT_NB_IPL_CFG_CPX_PORT_T;

typedef enum {
    HAL_MT_NB_IPL_FRM_ERR,
    HAL_MT_NB_IPL_CRC_ERR,          /* frames received with CRC Error */
    HAL_MT_NB_IPL_FRM_LEN_VIO,      /* Frames greater than programmed MaxFrameSize, violation */
    HAL_MT_NB_IPL_JABBER_ERR,       /* frames exceed Jabber size and have CRC Error */
    HAL_MT_NB_IPL_IEEE8023_LEN_ERR, /* frames received with Length Error, payload != length
                                                type */
} HAL_MT_NB_IPL_DROP_RSN_T;

typedef struct HAL_MT_NB_EPL_CFG_CPX_PORT_S {
    uint32 enable;             // port enable
    uint32 mode;               // 0-cpu/ecpu, 1-cpi
    uint32 keep_pph;           // 0-remove pph, 1-keep pph. cfg with ipl have_pph_already
    uint32 pfc_mode;           // only for cpi, 0-pause, 1-pfc
    uint32 id_sel;             // 2'b00-32, 01-33, 10-34, 11-35
    uint32 port_leak_en;       // port leak_timer_enable
    uint32 leak_thres;         // 16B unit, maximum 32KB
    uint32 cpi_port_spd;       // only valid for cpi port.3'd7~3'd5:unused;
                               // 3'd4:100G;3'd3:50G;3'd2:40G;3'd1:25G;3'd0:10G
    uint32 pfc_ignore;         // dbg for cpi port queue0~1 pfc mode dead_lock detect enable
    uint32 dead_lock_en;       // for cpi port queue0~1 pfc mode dead_lock detect enable
    uint32 que_flush_en;       // queue flush enable
    uint32 port_flush_en;      // port flush enable
    uint32 pause_dead_lock_en; // pause mode dead-lock detect enable
} HAL_MT_NB_EPL_CFG_CPX_PORT_T;

typedef struct HAL_MT_NB_EPL_CPX_S {
    uint32 outer_mac;
    uint32 tc2que_map[8];
    uint32 mtu;
    uint32 que_weight[4];
} HAL_MT_NB_EPL_CPX_T;

typedef struct HAL_MT_NB_EPL_ETH_PORT_S {
    uint32 enable;
    uint32 mode;
    uint32 port_spd;
} HAL_MT_NB_EPL_ETH_PORT_T;

typedef struct HAL_MT_NB_EPL_APP_ETH_PORT_S {
    uint32 mode;
    uint32 leak_en;
    uint32 leak_thres;
    uint32 port_spd;
} HAL_MT_NB_EPL_APP_ETH_PORT_T;

typedef struct HAL_MT_NB_EPL_APP_TC2QUE_MAP_S {
    uint32 tc[8]; // que_value: range 0~3
    uint32 tc_bitmap;
} HAL_MT_NB_EPL_APP_TC2QUE_MAP_T;

typedef struct HAL_MT_NB_EPL_CFG_ETH_PORT_S {
    HAL_MT_NB_EPL_ETH_PORT_T epl_eth;
    HAL_MT_NB_EPL_APP_ETH_PORT_T epl_app_eth;

#define HAL_MT_NB_EPL_ETH_ENABLE   (1 << 0)
#define HAL_MT_NB_EPL_ETH_MODE     (1 << 1)
#define HAL_MT_NB_EPL_ETH_PORT_SPD (1 << 2)
    uint32 flag;
} HAL_MT_NB_EPL_CFG_ETH_PORT_T;

typedef struct HAL_MT_NB_EPL_DP_QUE_SPD_READ_TH_S {
    uint32 lsy_spd_800g_th;
    uint32 lsy_spd_400g_th;
    uint32 lsy_spd_200g_th;
    uint32 lsy_spd_100g_th;
    uint32 lsy_spd_50g_th;
    uint32 lsy_spd_40g_th;
    uint32 lsy_spd_25g_th;
    uint32 lsy_spd_10g_th;
    uint32 lls_spd_800g_th;
    uint32 lls_spd_400g_th;
    uint32 lls_spd_200g_th;
    uint32 lls_spd_100g_th;
    uint32 lls_spd_50g_th;
    uint32 lls_spd_40g_th;
    uint32 lls_spd_25g_th;
    uint32 lls_spd_10g_th;
} HAL_MT_NB_EPL_DP_QUE_SPD_READ_TH_T;

typedef struct HAL_MT_NB_EPL_PKT_HEAD_VLAN_S {
    uint16 vlan_tpid; // 2bytes,   0x8100, IEEE 802.1Q tag
    uint8 vlan_pri;   // 3bits,    priority, 0-7
    uint8 vlan_cfi;   // 1bit,     0-std format mac addr, 1-non std
    uint16 vlan_id;   // 12bits,   vlan id, 0-4095
} HAL_MT_NB_EPL_PKT_HEAD_VLAN_T;

typedef struct HAL_MT_NB_EPL_PKT_HEAD_S {
    clx_mac_t dst_mac;  // 6bytes,   destination mac address
    clx_mac_t src_mac;  // 6bytes,   source mac address
    uint16 eth_ii_type; // 2bytes,   ethernet II type or 802.3 payload size
    uint8 vlan_vld;     // 1bit,     0-ethernet II pkt, 1-vlan pkt and need vlan_cfg
    HAL_MT_NB_EPL_PKT_HEAD_VLAN_T vlan_cfg; // vlan pkt field cfg
} HAL_MT_NB_EPL_PKT_HEAD_T;

typedef struct HAL_MT_NB_EPL_PKT_GEN_CFG_S {
    uint32 pkt_size;        // total bytes size of the pkt 64-9640
    HAL_MT_NB_EPL_PKT_HEAD_T pkt_head_cfg;
    uint8 dport;            // pkt destination port, 0-31
    uint8 repeat_num;       // 8bits, the pkt sent times during repeat duration in a loop
    uint8 loop_num;         // 8bits, times of repeat_num sent pkts, 0-continuously
    uint8 payload_ofst;     // 5bits, addr of payload start5'd13 is no vlan frame; 5'd17 vlan frame
    uint8 payload_random;   // 1bits, if use the random payload
    uint8 head_ofst;        // 4bits, addr of payload start5'd13 is no vlan frame; 5'd17 vlan frame
    uint8 head_random;      // 2bits, 2'b00/11-no change head, 2'b01-random, 2'b10-increase
    uint8 plen_random_en;   // 1bit
    uint8 data_duplication; // 1bit , data to multi umac dport
    uint16 repeat_duration; // 16bits, default 0x100
    uint32 payload_size;    // 32bits, payload size,
    uint8 pkt_payload[HAL_MT_NB_PL_GEN_PKT_LEN_MAX]; // pkt payload
} HAL_MT_NB_EPL_PKT_GEN_CFG_T;

clx_error_no_t
hal_mt_nb_pl_ipl_soft_reset(uint32 unit, uint32 plane, uint32 reset);

clx_error_no_t
hal_mt_nb_pl_ipl_vlan_pltc_map_cfg(const uint32 unit,
                                   const uint32 port,
                                   const uint32 pcp,
                                   const uint32 dei,
                                   uint32 loss_idx);

clx_error_no_t
hal_mt_nb_pl_ipl_vlan_pltc_map_get(const uint32 unit,
                                   const uint32 port,
                                   const uint32 pcp,
                                   const uint32 dei,
                                   uint32 *ptr_loss_idx);

clx_error_no_t
hal_mt_nb_pl_ipl_dscp_pltc_map_cfg(const uint32 unit,
                                   const uint32 port,
                                   const uint32 dscp,
                                   uint32 loss_idx);

clx_error_no_t
hal_mt_nb_pl_ipl_dscp_pltc_map_get(const uint32 unit,
                                   const uint32 port,
                                   const uint32 dscp,
                                   uint32 *ptr_loss_idx);

clx_error_no_t
hal_mt_nb_pl_ipl_exp_pltc_map_cfg(const uint32 unit,
                                  const uint32 port,
                                  const uint32 exp,
                                  uint32 loss_idx);

clx_error_no_t
hal_mt_nb_pl_ipl_exp_pltc_map_get(const uint32 unit,
                                  const uint32 port,
                                  const uint32 exp,
                                  uint32 *ptr_loss_idx);

clx_error_no_t
hal_mt_nb_pl_ipl_q2tc_map_cfg(uint32 unit, uint32 port, HAL_MT_NB_PL_TC_T *que2tc);

clx_error_no_t
hal_mt_nb_pl_ipl_q2tc_map_get(uint32 unit, uint32 port, HAL_MT_NB_PL_TC_T *que2tc);

clx_error_no_t
hal_mt_nb_pl_ipl_rsn_mask_cfg(const uint32 unit,
                              const uint32 plane,
                              const uint32 macro,
                              const HAL_MT_NB_IPL_DROP_RSN_T reason,
                              const boolean mask_en);

clx_error_no_t
hal_mt_nb_pl_cpx_mtu_cfg(const uint32 unit, const uint32 plane, const uint32 mtu);

clx_error_no_t
hal_mt_nb_pl_ipl_mtu_cfg(const uint32 unit,
                         const uint32 plane,
                         const uint32 macro,
                         const uint32 mtu);

clx_error_no_t
hal_mt_nb_pl_ipl_port_speed_cfg(const uint32 unit, const uint32 port, uint32 port_spd);

clx_error_no_t
hal_mt_nb_pl_epl_xoff_mask_port_pltc_cfg(const uint32 unit,
                                         const uint32 port,
                                         const uint32 pltc_bmp,
                                         const uint32 enable);

clx_error_no_t
hal_mt_nb_pl_ipl_buff_per_port_cfg(uint32 unit, uint32 port, HAL_MT_NB_PL_BUFF_MODE_T *buff_mode);

clx_error_no_t
hal_mt_nb_pl_ipl_buffer_cnt_get(const uint32 unit,
                                const uint32 port,
                                HAL_MT_NB_PL_BUFF_CNT_T *ptr_buff_cnt);

clx_error_no_t
hal_mt_nb_pl_epl_buffer_cnt_get(const uint32 unit,
                                const uint32 port,
                                HAL_MT_NB_PL_BUFF_CNT_T *ptr_buff_cnt);

clx_error_no_t
hal_mt_nb_pl_buffer_get(const uint32 unit,
                        const uint32 port,
                        HAL_MT_NB_PL_BUFF_CFG_T *ptr_buff_cfg,
                        uint32 channel_num);

clx_error_no_t
hal_mt_nb_pl_xoff_status_get(const uint32 unit,
                             const uint32 port,
                             clx_port_xoff_status_t *ptr_xoff_status);

clx_error_no_t
hal_mt_nb_pl_ipl_buffer_drop_thd_cfg(uint32 unit, uint32 port, HAL_MT_NB_PL_BUFF_MODE_T *drop_mode);

clx_error_no_t
hal_mt_nb_pl_epl_fd_buffer_cfg(uint32 unit, uint32 port, HAL_MT_NB_PL_BUFF_MODE_T *buff_mode);

clx_error_no_t
hal_mt_nb_pl_ipl_buf_empty_check(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_pl_epl_buf_empty_check(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_pl_ipl_admin_state_cfg(const uint32 unit, const uint32 port, const uint32 enable);

clx_error_no_t
hal_mt_nb_pl_epl_admin_state_cfg(const uint32 unit, const uint32 port, const uint32 enable);

clx_error_no_t
hal_mt_nb_pl_ipl_pst_sch_cfg(uint32 unit, uint32 port, const uint32 speed, uint32 pst_mode);

clx_error_no_t
hal_mt_nb_pl_epl_flush_en_cfg(const uint32 unit, const uint32 port, const uint32 enable);

clx_error_no_t
hal_mt_nb_pl_epl_que_flush_en_cfg(const uint32 unit,
                                  const uint32 port,
                                  const uint32 queue,
                                  const uint32 enable);

clx_error_no_t
hal_mt_nb_pl_epl_port_speed_cfg(const uint32 unit, const uint32 port, const uint32 port_spd);

clx_error_no_t
hal_mt_nb_pl_epl_tdm_slot_map_cfg(const uint32 unit,
                                  const uint32 port,
                                  const uint32 lane_cnt,
                                  const clx_port_speed_t speed);

clx_error_no_t
hal_mt_nb_pl_ipl_sch_umac_cfg(uint32 unit, uint32 port, uint32 speed, uint32 mode);

clx_error_no_t
hal_mt_nb_pl_ipl_cpx_port_get(const uint32 unit,
                              const uint32 plane,
                              HAL_MT_NB_IPL_CFG_CPX_PORT_T *cpx_cfg);

clx_error_no_t
hal_mt_nb_pl_ipl_cpx_port_set(const uint32 unit,
                              const uint32 plane,
                              HAL_MT_NB_IPL_CFG_CPX_PORT_T *cpx_cfg);

clx_error_no_t
hal_mt_nb_pl_epl_globa_port_cfg(uint32 unit, uint32 port, uint32 enable);

clx_error_no_t
hal_mt_nb_pl_ipl_cpx_runt_pkt_size_cfg(uint32 unit, uint32 port, uint32 pkt_size);

clx_error_no_t
hal_mt_nb_pl_epl_cpx_port_set(const uint32 unit,
                              const uint32 plane,
                              HAL_MT_NB_EPL_CFG_CPX_PORT_T *cpx_cfg);

clx_error_no_t
hal_mt_nb_pl_epl_cpx_port_get(const uint32 unit,
                              const uint32 plane,
                              HAL_MT_NB_EPL_CFG_CPX_PORT_T *cpx_cfg);

clx_error_no_t
hal_mt_nb_pl_epl_tc2que_map_cfg(uint32 unit, uint32 port, HAL_MT_NB_EPL_APP_TC2QUE_MAP_T *tc_que);

clx_error_no_t
hal_mt_nb_pl_epl_tc2que_map_get(uint32 unit, uint32 port, HAL_MT_NB_EPL_APP_TC2QUE_MAP_T *tc_que);

clx_error_no_t
hal_mt_nb_pl_ipl_all_mem_init(uint32 unit, uint32 plane);

clx_error_no_t
hal_mt_nb_pl_lbm_mem_init(uint32 unit, uint32 plane);

clx_error_no_t
hal_mt_nb_pl_lbm_traffic_th_init(uint32 unit, uint32 plane);

clx_error_no_t
hal_mt_nb_pl_epl_soft_reset(const uint32 unit, const uint32 plane, uint32 reset);

clx_error_no_t
hal_mt_nb_pl_epl_all_mem_init(uint32 unit, uint32 plane);

clx_error_no_t
hal_mt_nb_pl_epl_all_mem_done_init(uint32 unit, uint32 plane, uint32 *init_done);
clx_error_no_t
hal_mt_nb_pl_epl_cpx_cfg(uint32 unit, uint32 plane, HAL_MT_NB_EPL_CPX_T *cpx_cfg);

clx_error_no_t
hal_mt_nb_pl_epl_cpx_speed_set(const uint32 unit, const uint32 port, clx_port_speed_t speed);

clx_error_no_t
hal_mt_nb_pl_epl_lsy_que_spd_read_th_cfg(uint32 unit,
                                         uint32 plane,
                                         HAL_MT_NB_EPL_DP_QUE_SPD_READ_TH_T *que_spd);

clx_error_no_t
hal_mt_nb_pl_epl_que_spd_read_th_cfg(uint32 unit,
                                     uint32 plane,
                                     HAL_MT_NB_EPL_DP_QUE_SPD_READ_TH_T *que_spd);

clx_error_no_t
hal_mt_nb_pl_ipl_port_fc_mode_cfg(uint32 unit, uint32 port, uint32 mode);

clx_error_no_t
hal_mt_nb_pl_ipl_eth_port_cfg(uint32 unit, uint32 port, HAL_MT_NB_IPL_ETH_CFG_T *eth_cfg);

clx_error_no_t
hal_mt_nb_pl_ipl_port_fast_tm_pfc_cfg(uint32 unit, uint32 port, uint32 mode);

clx_error_no_t
hal_mt_nb_pl_ipl_port_fc_mode_get(uint32 unit, uint32 port, uint32 *ptr_mode);

clx_error_no_t
hal_mt_nb_pl_epl_eth_fc_mode_cfg(const uint32 unit, const uint32 port, const uint32 mode);

clx_error_no_t
hal_mt_nb_pl_epl_eth_dead_lock_cfg(const uint32 unit,
                                   const uint32 port,
                                   const uint32 queue,
                                   const uint32 mode);

clx_error_no_t
hal_mt_nb_pl_epl_dead_lock_detect_th_cfg(const uint32 unit,
                                         const uint32 port,
                                         const uint32 threshold);

clx_error_no_t
hal_mt_nb_pl_epl_flow_ctrl_ignore_cfg(const uint32 unit,
                                      const uint32 port,
                                      const uint32 queue,
                                      const uint32 enable);

clx_error_no_t
hal_mt_nb_pl_fabric_set(uint32 unit, uint32 port, uint32 fabric_en);

clx_error_no_t
hal_mt_nb_pl_fabric_get(uint32 unit, uint32 port, uint32 *fabric_en);

/**
 * @brief Initialize time stamp fifo.
 *
 * @param [in]    unit        - Chip id.
 * @param [in]    plane_id    - Device plane id in specific chip.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_pl_ts_fifo_init(const uint32 unit, const uint32 plane_id);

/**
 * @brief Get port tx time stamp entry count.
 *
 * @param [in]     unit         - Chip id.
 * @param [in]     port         - Port id.
 * @param [out]    ptr_count    - Time stamp entry information.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_nb_pl_ts_entry_count_get(const uint32 unit, const uint32 port, uint32 *ptr_count);

clx_error_no_t
hal_mt_nb_pl_ts_entry_get(const uint32 unit,
                          const uint32 port,
                          const uint32 count,
                          clx_port_ts_entry_t *ptr_ts_entry);

clx_error_no_t
hal_mt_nb_pl_ts_fifo_irq_check(uint32 unit, uint32 port);

clx_error_no_t
hal_mt_nb_pl_mxhdr_en_set(const uint32 unit, const uint32 port, const boolean enable);

clx_error_no_t
hal_mt_nb_pl_mxhdr_en_get(const uint32 unit, const uint32 port, uint32 *enable);

clx_error_no_t
hal_mt_nb_pl_ipl_init(const uint32 unit, const uint32 port, const clx_port_speed_t speed);

clx_error_no_t
hal_mt_nb_pl_epl_init(const uint32 unit,
                      const uint32 port,
                      const uint32 lane_cnt,
                      const clx_port_speed_t speed);

clx_error_no_t
hal_mt_nb_pl_ipl_deinit(const uint32 unit, const uint32 port, const uint32 lane_num);

clx_error_no_t
hal_mt_nb_pl_epl_deinit(const uint32 unit, const uint32 port, const uint32 lane_num);

clx_error_no_t
hal_mt_nb_pl_mburst_calc_port_set(const uint32 unit, const uint32 port, const clx_dir_t dir);

clx_error_no_t
hal_mt_nb_pl_mburst_calc_port_get(const uint32 unit,
                                  const uint32 port,
                                  const clx_dir_t dir,
                                  uint32 *p_port);

clx_error_no_t
hal_mt_nb_pl_mburst_patt_match_set(const uint32 unit,
                                   const uint32 port,
                                   const clx_dir_t dir,
                                   uint32 *p_pattern);

clx_error_no_t
hal_mt_nb_pl_mburst_patt_match_get(const uint32 unit,
                                   const uint32 port,
                                   const clx_dir_t dir,
                                   uint32 *p_pattern);

clx_error_no_t
hal_mt_nb_pl_mburst_patt_mask_set(const uint32 unit,
                                  const uint32 port,
                                  const clx_dir_t dir,
                                  uint32 *p_mask);

clx_error_no_t
hal_mt_nb_pl_mburst_patt_mask_get(const uint32 unit,
                                  const uint32 port,
                                  const clx_dir_t dir,
                                  uint32 *p_mask);

clx_error_no_t
hal_mt_nb_pl_mburst_win_div_set(const uint32 unit,
                                const uint32 port,
                                const clx_dir_t dir,
                                const uint32 window_count,
                                const uint32 div_shift);

clx_error_no_t
hal_mt_nb_pl_mburst_win_div_get(const uint32 unit,
                                const uint32 port,
                                const clx_dir_t dir,
                                uint32 *window_cnt,
                                uint32 *div_shift);

clx_error_no_t
hal_mt_nb_pl_mburst_rate_wgt_set(const uint32 unit,
                                 const uint32 port,
                                 const clx_dir_t dir,
                                 const uint32 weight);

clx_error_no_t
hal_mt_nb_pl_mburst_rate_wgt_get(const uint32 unit,
                                 const uint32 port,
                                 const clx_dir_t dir,
                                 uint32 *p_weight);

clx_error_no_t
hal_mt_nb_pl_mburst_calc_rate_sel_set(const uint32 unit,
                                      const uint32 port,
                                      const clx_dir_t dir,
                                      const uint32 mode);

clx_error_no_t
hal_mt_nb_pl_mburst_calc_rate_sel_get(const uint32 unit,
                                      const uint32 port,
                                      const clx_dir_t dir,
                                      uint32 *p_mode);

clx_error_no_t
hal_mt_nb_pl_mburst_calc_add_cxheader_set(const uint32 unit,
                                          const uint32 port,
                                          const clx_dir_t dir,
                                          const uint32 status);

clx_error_no_t
hal_mt_nb_pl_mburst_calc_add_cxheader_get(const uint32 unit,
                                          const uint32 port,
                                          const clx_dir_t dir,
                                          uint32 *p_status);

clx_error_no_t
hal_mt_nb_pl_mburst_rate_thrd_set(const uint32 unit,
                                  const uint32 port,
                                  const clx_dir_t dir,
                                  const uint32 thrd_num,
                                  const uint32 threshold);

clx_error_no_t
hal_mt_nb_pl_mburst_rate_thrd_get(const uint32 unit,
                                  const uint32 port,
                                  const clx_dir_t dir,
                                  const uint32 thrd_num,
                                  uint32 *p_thrd);

clx_error_no_t
hal_mt_nb_pl_mburst_count_get(const uint32 unit,
                              const uint32 port,
                              const clx_dir_t dir,
                              const uint32 cnt_type,
                              uint32 *p_count);

clx_error_no_t
hal_mt_nb_pl_mburst_instant_rate_get(const uint32 unit,
                                     const uint32 port,
                                     const clx_dir_t dir,
                                     uint32 *p_rate);

clx_error_no_t
hal_mt_nb_pl_mburst_max_rate_get(const uint32 unit,
                                 const uint32 port,
                                 const clx_dir_t dir,
                                 uint32 *p_rate);

clx_error_no_t
hal_mt_nb_pl_mburst_max_rate_ts_get(const uint32 unit,
                                    const uint32 port,
                                    const clx_dir_t dir,
                                    uint32 *p_rate_ts);

clx_error_no_t
hal_mt_nb_pl_mburst_average_rate_get(const uint32 unit,
                                     const uint32 port,
                                     const clx_dir_t dir,
                                     uint32 *p_rate);

clx_error_no_t
hal_mt_nb_pl_mburst_hist_irq_mask_set(const uint32 unit,
                                      const uint32 port,
                                      const clx_dir_t dir,
                                      const uint32 enable);

clx_error_no_t
hal_mt_nb_pl_mburst_hist_irq_mask_get(const uint32 unit,
                                      const uint32 port,
                                      const clx_dir_t dir,
                                      uint32 *p_enable);

clx_error_no_t
hal_mt_nb_pl_mburst_hist_max_value_set(const uint32 unit,
                                       const uint32 port,
                                       const clx_dir_t dir,
                                       const uint32 value);

clx_error_no_t
hal_mt_nb_pl_mburst_hist_max_value_get(const uint32 unit,
                                       const uint32 port,
                                       const clx_dir_t dir,
                                       uint32 *p_value);

clx_error_no_t
hal_mt_nb_pl_mburst_hist_cnt_get(const uint32 unit,
                                 const uint32 port,
                                 const clx_dir_t dir,
                                 const uint32 thrd_num,
                                 uint32 *p_count);

clx_error_no_t
hal_mt_nb_pl_mburst_clear_set(const uint32 unit,
                              const uint32 port,
                              const clx_dir_t dir,
                              const uint32 enable);

clx_error_no_t
hal_mt_nb_pl_epl_cpx_mem_empty_get(const uint32 unit, const uint32 plane, uint32 *empty);

clx_error_no_t
hal_mt_nb_pl_epl_test_mode_get(const uint32 unit, const uint32 plane, uint32 *ptr_enable);

clx_error_no_t
hal_mt_nb_pl_pkt_gen_en_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);
clx_error_no_t
hal_mt_nb_pl_pkt_gen(const uint32 unit,
                     const uint32 port,
                     clx_port_speed_t speed,
                     HAL_MT_NB_EPL_PKT_GEN_CFG_T *pkt_cfg);

clx_error_no_t
hal_mt_nb_pl_gen_pkt_stop(const uint32 unit, const uint32 port);

clx_error_no_t
hal_mt_nb_pl_pfc_map_init(uint32 unit);
#endif
