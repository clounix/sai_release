/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  osal_mdc.h
 * PURPOSE:
 * 1. Provide device operate from DRV interface
 * NOTES:
 *
 */

#ifndef OSAL_MDC_H
#define OSAL_MDC_H

/* INCLUDE FILE DECLARATIONS */
#ifndef CLX_LINUX_KERNEL_MODE
#ifndef __KERNEL__
#include <util/lib/util_lib_list.h>
#endif
#endif
#include <clx/clx_types.h>
#include <drv/drv.h>

#include <linux/include/knet_common.h>

#define OSAL_MDC_PCI_BUS_WIDTH (CLX_PCI_BUS_WIDTH)

#define OSAL_MDC_DMA_LIST_SZ_UNLIMITED (0)
#define OSAL_MDC_DMA_LIST_NAME         "RSRV_DMA"
#define OSAL_MDC_DMA_SEMAPHORE_NAME    "DMALIST"
#define OSAL_MDC_DEV_FILE_PATH         "/dev/" CLX_DRIVER_NAME

/* NAMING CONSTANT DECLARATIONS
 */
/* linked list node */
#if defined(CLX_LINUX_KERNEL_MODE)

typedef struct osal_mdc_list_node_s {
    void *ptr_data;                        /* node data                   */
    struct osal_mdc_list_node_s *ptr_next; /* point to next link node     */
    struct osal_mdc_list_node_s *ptr_prev; /* point to previous link node */
} osal_mdc_list_node_t;

/* linked list head */
typedef struct osal_mdc_list_s {
    osal_mdc_list_node_t *ptr_head_node; /* linked list head node   */
    osal_mdc_list_node_t *ptr_tail_node; /* linked list tail node   */
    uint32 capacity;                     /* max count of nodes in list
                                          * size=0: the capacity is unlimited.
                                          * size>0: the capacity is limited.
                                          */
    uint32 node_cnt;                     /* the count of nodes in the list */
} osal_mdc_list_t;

#endif /* End of defined(CLX_LINUX_KERNEL_MODE) */

typedef struct {
    clx_addr_t phy_addr;
    void *ptr_virt_addr;
    clx_addr_t size;
    clx_addr_t bus_addr;

#if defined(CLX_EN_DMA_RESERVED)
    boolean available;
#endif

} osal_mdc_dma_node_t;

typedef struct {
#if defined(CLX_EN_DMA_RESERVED)
    void *ptr_rsrv_virt_addr;
    clx_addr_t rsrv_phy_addr;
    clx_addr_t rsrv_size;
#else
    struct device *ptr_dma_dev; /* for allocate/free system memory */
#endif

#if defined(CLX_LINUX_KERNEL_MODE)
    osal_mdc_list_t *ptr_dma_list;
#else
#ifndef __KERNEL__
    util_lib_list_t *ptr_dma_list;
#else
    void *ptr_dma_list;
#endif
#endif

    clx_semaphore_id_t sema;

} osal_mdc_dma_info_t;

clx_error_no_t
osal_mdc_ioctl(const uint32 unit, const clx_ioctl_type_t type, void *ptr_data);

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
osal_mdc_pci_reg_read(const uint32 unit, const uint32 offset, uint32 *ptr_data, const uint32 len);

clx_error_no_t
osal_mdc_pci_reg_write(const uint32 unit,
                       const uint32 offset,
                       const uint32 *ptr_data,
                       const uint32 len);

clx_error_no_t
osal_mdc_device_init(drv_dev_t *ptr_dev_list, uint32 *ptr_dev_num);

clx_error_no_t
osal_mdc_device_deinit(void);

clx_error_no_t
osal_mdc_dma_mem_init(void);

clx_error_no_t
osal_mdc_dma_mem_deinit(void);

void *
osal_mdc_dma_mem_mmap(const clx_addr_t dma_phy_addr, const uint32 size);

clx_error_no_t
osal_mdc_dma_mem_munmap(void *ptr_virt_addr);

void *
osal_mdc_dma_mem_alloc(const uint32 size);

clx_error_no_t
osal_mdc_dma_mem_free(void *ptr_virt_addr);

clx_error_no_t
osal_mdc_virt_to_phy_convert(void *ptr_virt_addr, clx_addr_t *ptr_phy_addr);

clx_error_no_t
osal_mdc_phy_to_virt_convert(const clx_addr_t phy_addr, void **pptr_virt_addr);

clx_error_no_t
osal_mdc_register_isr(const uint32 unit, drv_dev_isr_func_t handler, void *ptr_cookie);

clx_error_no_t
osal_mdc_isr_connect(const uint32 unit, drv_dev_isr_func_t handler, void *ptr_cookie);

clx_error_no_t
osal_mdc_isr_disconnect(const uint32 unit);

clx_error_no_t
osal_mdc_synchronize_irq(const uint32 unit);

clx_error_no_t
osal_mdc_cache_flush(void *ptr_virt_addr, const uint32 size);

clx_error_no_t
osal_mdc_cache_invalidate(void *ptr_virt_addr, const uint32 size);

/* IO */
int
osal_io_copy_to_user(void *ptr_usr_buf, void *ptr_knl_buf, unsigned int size);

int
osal_io_copy_from_user(void *ptr_knl_buf, void *ptr_usr_buf, unsigned int size);

#endif /* OSAL_MDC_H */
