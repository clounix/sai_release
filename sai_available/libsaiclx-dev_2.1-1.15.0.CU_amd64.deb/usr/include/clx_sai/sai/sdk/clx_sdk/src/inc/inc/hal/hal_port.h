/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_PORT_H
#define HAL_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <hal/hal_mac.h>
#include <util/lib/util_lib_avl.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PORT_HW_VLAN_TAG_MODE_1Q      (HAL_VLAN_TAG_MODE_1Q_1AD)
#define HAL_PORT_HW_VLAN_TAG_MODE_1AD     (HAL_VLAN_TAG_MODE_1Q_1AD_0)
#define HAL_PORT_HW_VLAN_TAG_MODE_EXTVLAN (HAL_VLAN_TAG_MODE_24B)

#define HAL_PORT_EXCPT_IDS_TAG_ERR_OFFSET (8)

#define HAL_PORT_PHY_PORT_MASK (0x7F)
#define HAL_PORT_VLAN_MASK     (0xFFF)
#define HAL_PORT_MERGE_VID_1ST (1)

#define HAL_PORT_NATIVE_INTF_OFFSET (8192)

#define HAL_PORT_DB_DUMP_FLAGS_LINK (1U << 0)

/* defined for ps table */
#define HAL_PORT_VLAN_RNG_INVALID_PORT (0x7F)
#define HAL_PORT_PS_RNG_ENTRY_NUM      (128)

#define HAL_PORT_SPEED_IDX_1G   (0)
#define HAL_PORT_SPEED_IDX_10G  (1)
#define HAL_PORT_SPEED_IDX_25G  (2)
#define HAL_PORT_SPEED_IDX_40G  (3)
#define HAL_PORT_SPEED_IDX_50G  (4)
#define HAL_PORT_SPEED_IDX_100G (5)
#define HAL_PORT_SPEED_IDX_200G (6)
#define HAL_PORT_SPEED_IDX_400G (7)
#define HAL_PORT_SPEED_IDX_800G (8)
#define HAL_PORT_SPEED_IDX_LAST (9)

#define HAL_PORT_LANE_CNT_IDX_1    (0)
#define HAL_PORT_LANE_CNT_IDX_2    (1)
#define HAL_PORT_LANE_CNT_IDX_4    (2)
#define HAL_PORT_LANE_CNT_IDX_8    (3)
#define HAL_PORT_LANE_CNT_IDX_LAST (4)

#define HAL_PORT_FEC_NONE      (1U << CLX_PORT_FEC_DISABLE)
#define HAL_PORT_FEC_BASER     (1U << CLX_PORT_FEC_ENABLE)
#define HAL_PORT_FEC_RS528     (1U << CLX_PORT_FEC_RS528)
#define HAL_PORT_FEC_RS544     (1U << CLX_PORT_FEC_RS544)
#define HAL_PORT_FEC_RS272     (1U << CLX_PORT_FEC_RS272)
#define HAL_PORT_FEC_RS544_INT (1U << CLX_PORT_FEC_RS544_INT)
#define HAL_PORT_FEC_RS272_INT (1U << CLX_PORT_FEC_RS272_INT)
#define HAL_PORT_FEC_LAST      (1U << CLX_PORT_FEC_LAST)

#define HAL_PORT_FEC_NONE_BASER (HAL_PORT_FEC_NONE | HAL_PORT_FEC_BASER)

#define HAL_PORT_FEC_NONE_RS528 (HAL_PORT_FEC_NONE | HAL_PORT_FEC_RS528)

#define HAL_PORT_FEC_NONE_BASER_RS528 (HAL_PORT_FEC_NONE | HAL_PORT_FEC_BASER | HAL_PORT_FEC_RS528)

#define HAL_PORT_FEC_RS544_RS272 (HAL_PORT_FEC_RS544 | HAL_PORT_FEC_RS272)

#define HAL_PORT_FEC_RS544_RS272_RSINT \
    (HAL_PORT_FEC_RS544 | HAL_PORT_FEC_RS272 | HAL_PORT_FEC_RS544_INT | HAL_PORT_FEC_RS272_INT)

#define HAL_PORT_FEC_RS528_RS544_RS272 \
    (HAL_PORT_FEC_RS528 | HAL_PORT_FEC_RS544 | HAL_PORT_FEC_RS272)

#define HAL_PORT_FEC_NONE_RS528_RS544_RS272 \
    (HAL_PORT_FEC_NONE | HAL_PORT_FEC_RS528 | HAL_PORT_FEC_RS544 | HAL_PORT_FEC_RS272)

#define HAL_PORT_FEC_NONE_BASER_RS528_RS544_RS272                                       \
    (HAL_PORT_FEC_NONE | HAL_PORT_FEC_BASER | HAL_PORT_FEC_RS528 | HAL_PORT_FEC_RS544 | \
     HAL_PORT_FEC_RS272)

#define HAL_PORT_WBDB_ID_LAST_PREV (4)
#define HAL_PORT_NUM_PREV          (160)
#define HAL_PORT_BITMAP_SIZE_PREV  CLX_BITMAP_SIZE(HAL_PORT_NUM_PREV)

#define HAL_PORT_DFLT_UL_EXP_VLAN_TPID_1ST_SET (0)
#define HAL_PORT_DFLT_UL_ALW_VLAN_TAG_SET      (1)
#define HAL_PORT_DFLT_1ST_TPID                 (0x8100)
#define HAL_PORT_DFLT_2ST_TPID                 (0x0)

#define HAL_PORT_DFLT_L3_MTU_CK_SUPP_SET (0)
#define HAL_PORT_DFLT_L2_MTU_SIZE        (1536)

#define HAL_PORT_SST_INVALID (0x1F)

#define HAL_PORT_EXCPT_IDS_TAG_ERR_OFFSET (8)

#define HAL_PORT_PHY_PORT_MASK         (0x7F)
#define HAL_PORT_MERGE_VID_1ST         (1)
#define HAL_PORT_VLAN_RNG_INVALID_PORT (0x7F)

#define HAL_PORT_ABILITY_ADD_1G(__ptr_ability__)                         \
    do {                                                                 \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_1000BASE_X;   \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |  \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                            \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_GMII; \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |     \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                              \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_GMII; \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;      \
    } while (0)

#define HAL_PORT_ABILITY_ADD_10G(__ptr_ability__)                                              \
    do {                                                                                       \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_10GBASE_KR;                         \
        (__ptr_ability__)->eee |= CLX_PORT_ABILITY_EEE_10GBASE_KR;                             \
        (__ptr_ability__)->fec |= CLX_PORT_ABILITY_FEC_ABILITY | CLX_PORT_ABILITY_FEC_REQUEST; \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |                        \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                                  \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_XGMII;                      \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |                           \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                                    \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;                            \
    } while (0)

#define HAL_PORT_ABILITY_ADD_40G(__ptr_ability__)                                              \
    do {                                                                                       \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_40GBASE_KR4 |                       \
            CLX_PORT_ABILITY_SPEED_40GBASE_CR4;                                                \
        (__ptr_ability__)->eee |= CLX_PORT_ABILITY_EEE_40GBASE_KR4 |                           \
            CLX_PORT_ABILITY_EEE_40GBASE_CR4;                                                  \
        (__ptr_ability__)->fec |= CLX_PORT_ABILITY_FEC_ABILITY | CLX_PORT_ABILITY_FEC_REQUEST; \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |                        \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                                  \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_XLGMII;                     \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |                           \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                                    \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;                            \
    } while (0)

#define HAL_PORT_ABILITY_ADD_25G(__ptr_ability__)                            \
    do {                                                                     \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR_S | \
            CLX_PORT_ABILITY_SPEED_25GBASE_KR_CR;                            \
        (__ptr_ability__)->eee |= CLX_PORT_ABILITY_EEE_25GBASE_R;            \
        (__ptr_ability__)->fec |= CLX_PORT_ABILITY_FEC_RS_REQUEST |          \
            CLX_PORT_ABILITY_FEC_BASE_R_REQUEST;                             \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |      \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_25GMII;   \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |         \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                  \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;          \
    } while (0)

#define HAL_PORT_ABILITY_ADD_50G_CONSORTIUM(__ptr_ability__)                       \
    do {                                                                           \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_50GBASE_KR2_CONSORTIUM; \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_50GBASE_CR2_CONSORTIUM; \
        (__ptr_ability__)->fec |= CLX_PORT_ABILITY_FEC_RS_REQUEST |                \
            CLX_PORT_ABILITY_FEC_BASE_R_REQUEST;                                   \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |            \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                      \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_50GMII;         \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |               \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                        \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;                \
    } while (0)

#define HAL_PORT_ABILITY_ADD_100G(__ptr_ability__)                        \
    do {                                                                  \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_100GBASE_KR4 | \
            CLX_PORT_ABILITY_SPEED_100GBASE_CR4;                          \
        (__ptr_ability__)->eee |= CLX_PORT_ABILITY_EEE_100GBASE_KR4 |     \
            CLX_PORT_ABILITY_EEE_100GBASE_CR4;                            \
        (__ptr_ability__)->fec |= CLX_PORT_ABILITY_FEC_RS_REQUEST;        \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |   \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                             \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_CGMII; \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |      \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                               \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;       \
    } while (0)

#define HAL_PORT_ABILITY_ADD_50G_R1(__ptr_ability__)                       \
    do {                                                                   \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_50GBASE_KR_CR;  \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |    \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                              \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_50GMII; \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |       \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;        \
    } while (0)

#define HAL_PORT_ABILITY_ADD_100G_R1(__ptr_ability__)                      \
    do {                                                                   \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_100GBASE_KR_CR; \
        (__ptr_ability__)->fec |= CLX_PORT_ABILITY_FEC_RS_INT_REQUEST;     \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |    \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                              \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_CGMII;  \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |       \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;        \
    } while (0)

#define HAL_PORT_ABILITY_ADD_100G_R2(__ptr_ability__)                        \
    do {                                                                     \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_100GBASE_KR2_CR2; \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |      \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_CGMII;    \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |         \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                  \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;          \
    } while (0)

#define HAL_PORT_ABILITY_ADD_200G_R2(__ptr_ability__)                        \
    do {                                                                     \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_200GBASE_KR2_CR2; \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |      \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_200GMII;  \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |         \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                  \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;          \
    } while (0)

#define HAL_PORT_ABILITY_ADD_200G_R4(__ptr_ability__)                        \
    do {                                                                     \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_200GBASE_KR4_CR4; \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |      \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_200GMII;  \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |         \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                  \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;          \
    } while (0)

#define HAL_PORT_ABILITY_ADD_400G_R4(__ptr_ability__)                        \
    do {                                                                     \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_400GBASE_KR4_CR4; \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |      \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_400GMII;  \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |         \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                  \
    } while (0)

#define HAL_PORT_ABILITY_ADD_400G_R8(__ptr_ability__)                           \
    do {                                                                        \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_400GBASE_CONSORTIUM; \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |         \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                   \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_400GMII;     \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |            \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                     \
        (__ptr_ability__)->flags |= CLX_PORT_ABILITY_FLAGS_AUTONEG;             \
    } while (0)

#define HAL_PORT_ABILITY_ADD_800G_R8(__ptr_ability__)                        \
    do {                                                                     \
        (__ptr_ability__)->speed |= CLX_PORT_ABILITY_SPEED_800GBASE_KR8_CR8; \
        (__ptr_ability__)->pause |= CLX_PORT_ABILITY_PAUSE_ASYM_PAUSE |      \
            CLX_PORT_ABILITY_PAUSE_SYM_PAUSE;                                \
        (__ptr_ability__)->interface |= CLX_PORT_ABILITY_INTERFACE_800GMII;  \
        (__ptr_ability__)->medium |= CLX_PORT_ABILITY_MEDIUM_FIBER |         \
            CLX_PORT_ABILITY_MEDIUM_COPPER;                                  \
    } while (0)

#define HAL_PORT_ABILITY_INIT(__ptr_ability__) \
    do {                                       \
        (__ptr_ability__)->speed = 0;          \
        (__ptr_ability__)->eee = 0;            \
        (__ptr_ability__)->fec = 0;            \
        (__ptr_ability__)->pause = 0;          \
        (__ptr_ability__)->medium = 0;         \
        (__ptr_ability__)->interface = 0;      \
        (__ptr_ability__)->flags = 0;          \
    } while (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_PORT_PROPERTY_TS_MAC_RPL_EGR = 0,
    HAL_PORT_PROPERTY_TS_MAC_RPL_DA,
    HAL_PORT_PROPERTY_TS_MAC_RPL_EN,
    HAL_PORT_PROPERTY_IGR_TS_EOF_INS_EN,
    HAL_PORT_PROPERTY_EGR_TS_EOF_INS_EN,
} HAL_PORT_PP_PROPERTY_T;

/* Port speed and lane count */
typedef enum {
    HAL_PORT_SPEED_LANE_1G_R1 = 0,
    HAL_PORT_SPEED_LANE_10G_R1,
    HAL_PORT_SPEED_LANE_40G_R2,
    HAL_PORT_SPEED_LANE_40G_R4,
    HAL_PORT_SPEED_LANE_25G_R1,
    HAL_PORT_SPEED_LANE_50G_R2,
    HAL_PORT_SPEED_LANE_100G_R4,
    HAL_PORT_SPEED_LANE_50G_R1,
    HAL_PORT_SPEED_LANE_100G_R2,
    HAL_PORT_SPEED_LANE_200G_R4,
    HAL_PORT_SPEED_LANE_400G_R8,
    HAL_PORT_SPEED_LANE_100G_R1,
    HAL_PORT_SPEED_LANE_200G_R2,
    HAL_PORT_SPEED_LANE_400G_R4,
    HAL_PORT_SPEED_LANE_800G_R8,
    HAL_PORT_SPEED_LANE_200G_R8,
    HAL_PORT_SPEED_LANE_LAST
} HAL_PORT_SPEED_LANT_T;

typedef struct {
    uint32 mode;
    uint32 vlan_1st_tpid;
    uint32 vlan_2nd_tpid;
} HAL_PORT_HW_VLAN_TAG_T;

typedef struct HAL_PORT_INTF_CONFIG_S {
    uint32 acc_frm_tag_typ;
    uint32 precedence;
    uint32 vlan_tag_mode;
    uint16 vlan_tpid_1st;
    uint16 vlan_tpid_2nd;
    uint16 egr_vlan_tpid_1st;
    uint16 egr_vlan_tpid_2nd;
    uint32 dflt_1st_vid;
    uint32 dflt_2nd_vid;
    /* sampling */
    hal_sflow_dst_type_t igr_sflow_dst_type;
    uint32 igr_sampling_rate;
    uint32 igr_sample_to_mir_session_id;
    hal_sflow_dst_type_t egr_sflow_dst_type;
    uint32 egr_sampling_rate;
    uint32 egr_sample_to_mir_session_id;
    boolean egr_sample_high_latency;
    /* meter */
    uint32 igr_mtr_idx;
    uint32 egr_mtr_idx;
    /* cntr */
    uint32 igr_cnt_idx;
    uint32 egr_cnt_idx;
    uint32 igr_dist_cnt_idx;
    uint32 egr_dist_cnt_idx;
    /* qos */
    uint32 pcp_dei_to_phb_prof_idx;
    uint32 phb_to_pcp_dei_prof_idx;
    uint32 dscp_to_phb_prof_idx;
    uint32 phb_to_dscp_prof_idx;
    uint32 exp_to_phb_prof_idx;
    uint32 phb_to_exp_prof_idx;

    uint32 igr_flw_lbl;
    uint32 egr_flw_lbl;
    uint32 sa_rsn;
    uint32 igr_mir_idx;
    uint32 egr_mir_idx;
} HAL_PORT_INTF_CONFIG_T;

/* IEEE 802.3 Clause 37 Autonegotiation Ability */
typedef enum {
    HAL_PORT_C37_AN_ABILITY_FD = (1 << 5),
    HAL_PORT_C37_AN_ABILITY_HD = (1 << 6),
    HAL_PORT_C37_AN_ABILITY_PAUSE = (1 << 7),
    HAL_PORT_C37_AN_ABILITY_ASM_DIR = (1 << 8),
    HAL_PORT_C37_AN_ABILITY_RF1 = (1 << 12),
    HAL_PORT_C37_AN_ABILITY_RF2 = (1 << 13),
} HAL_PORT_C37_AN_ABILITY_T;

/* Port vlan-range DB */
typedef struct HAL_PORT_PS_RNG_S {
    /* invalid entry: port = HAL_INVALID_ID */
    uint32 port;
    uint32 vid_min;
    uint32 vid_max;
} HAL_PORT_PS_RNG_T;

typedef enum {
    HAL_PORT_WBDB_ID_SST = 0,
    HAL_PORT_WBDB_ID_PBM,
    HAL_PORT_WBDB_ID_TXS,
    HAL_PORT_WBDB_ID_RXS,
    HAL_PORT_WBDB_ID_PS_RNG,
    HAL_PORT_WBDB_ID_LANE_CNT,
    HAL_PORT_WBDB_ID_LFC_TX,
    HAL_PORT_WBDB_ID_PFC_TX,
    HAL_PORT_WBDB_ID_LAST
} HAL_PORT_WBDB_ID_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS */

/**
 * @brief Set MxLink per physical port.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    port      - Physical port id.
 * @param [in]    enable    - 1: enable MxLink 0: disable MxLink.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NOT_SUPPORT      - Not support MxLink.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_port_mxlink_set(const uint32 unit, const uint32 port, const uint32 enable);

/**
 * @brief Get MxLink per physical port.
 *
 * @param [in]    unit          - Device unit number.
 * @param [in]    port          - Physical port id.
 * @param [in]    ptr_enable    - 1: MxLink is enalbed 0: MxLink is disabled.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_NOT_SUPPORT      - Not support MxLink.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */

clx_error_no_t
hal_port_mxlink_get(const uint32 unit, const uint32 port, uint32 *ptr_enable);

/**
 * @brief This API is used to get port from UNIT_PORT interface object.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     clx_port    - The UNIT_PORT interface object.
 * @param [out]    ptr_port    - The pointer of Port ID.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_port_gport_to_port_trans(const uint32 unit, const clx_port_t clx_port, uint32 *ptr_port);

/**
 * @brief Get port type. It is used to lookup corresponding database to get its key.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Interface object.
 * @param [out]    ptr_type    - Type of clx_gport_type_t.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_port_port_type_get(const uint32 unit, const clx_port_t port, clx_gport_type_t *ptr_type);

/**
 * @brief Update port bitmap.
 *
 * @param [in]     unit           - Device unit number.
 * @param [out]    port_bitmap    - New port bitmap.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_port_port_bitmap_update(const uint32 unit, clx_port_bitmap_t port_bitmap);

/**
 * @brief Get port bitmap to be inited.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_bitmap    - Port bitmap needs to be inited.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_port_init_port_bitmap_get(const uint32 unit, clx_port_bitmap_t *ptr_bitmap);

/**
 * @brief This API is used to create a UNIT_PORT interface object.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Port ID.
 * @param [out]    ptr_intf    - The pointer of the UNIT_PORT interface object.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_port_gport_create(const uint32 unit, const uint32 port, clx_port_t *ptr_intf);

/**
 * @brief This API is used to destroy a UNIT_PORT interface object.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    intf    - The pointer of the UNIT_PORT interface object.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_port_gport_destroy(const uint32 unit, clx_port_t intf);

/**
 * @brief This API is used to get a UNIT_PORT interface object.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Port ID.
 * @param [out]    ptr_port    - The pointer of the UNIT_PORT interface object.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_port_port_to_gport_trans(const uint32 unit, const uint32 port, clx_port_t *ptr_port);

/**
 * @brief This API is used to get Plane Port for a UNIT_PORT interface object or Normal port.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     port          - CLX Port.
 * @param [out]    plane         - The plane ID.
 * @param [out]    plane_port    - The plane port ID.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_port_clx_plane_port_get(const uint32 unit,
                            const clx_port_t port,
                            uint32 *plane,
                            uint32 *plane_port);
#endif /* #ifndef HAL_PORT_H */
