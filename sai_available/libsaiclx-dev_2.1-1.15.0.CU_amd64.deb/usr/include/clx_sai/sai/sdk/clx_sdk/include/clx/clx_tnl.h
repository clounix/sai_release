/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_tnl.h
 * PURPOSE:
 *      It provides tunnel module api.
 * NOTES:
 *
 */

#ifndef CLX_TNL_H
#define CLX_TNL_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_l3.h>
#include <clx/clx_qos.h>
#include <clx/clx_types.h>

#include <clx/clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_TNL_FLAGS_WITH_ID (0x1U << 0) /* Use user input tnl_port to set parameter */
#define CLX_TNL_EVPN_FLAGS_WITH_ID \
    (0x1U << 0) /* Use user input eg_group to create ethernet segment group */

#define CLX_TNL_FLEX_TNL_HDR_NUM (6)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef enum clx_tnl_psr_type_e {
    CLX_TNL_PSR_TYPE_ALL = 0,
    CLX_TNL_PSR_TYPE_GRE,
    CLX_TNL_PSR_TYPE_VXLAN,
    CLX_TNL_PSR_TYPE_IPINIP,
    CLX_TNL_PSR_TYPE_GTP,
    CLX_TNL_PSR_TYPE_LAST,
} clx_tnl_psr_type_t;

/* Multicast Tunnel PIM mode
 * PIM-BIDIR https://www.rfc-editor.org/rfc/rfc7761.html
 * PIM-SM    https://www.rfc-editor.org/rfc/rfc5015.html
 */
typedef enum clx_tnl_pim_mode_e {
    CLX_TNL_PIM_MODE_SM = 0, /* PIM-SM mode */
    CLX_TNL_PIM_MODE_BIDIR,  /* PIM-BIDIR mode */
    CLX_TNL_PIM_MODE_LAST
} clx_tnl_pim_mode_t;

/* Tunnel MAC Entry */
typedef struct clx_tnl_mac_info_s {
    uint32 flags;                /* Refer to CLX_TNL_MAC_FLAGS_XXX */
    uint32 port;                 /* Key: Physical port or LAG port ID */
    clx_vlan_t cvid;             /* Key: C-VLAN ID */
    clx_mac_t mac;               /* Key: Tunnel MAC address */
    clx_mac_t mac_msk;           /* Mask for the tunnel router MAC */
    uint16 l3_mtu;               /* L3 mtu size */
    uint16 stpo_id;              /* STP check index. cl8600 only */
    uint16 underlay_vrf;         /* Vrf id of the underlay network. cl8600 only */
    clx_tnl_pim_mode_t rpf_mode; /* PIM rpf check mode. cl8600 only */
    uint16 rpf_intf_or_bmp;      /* PIM rpf check interface id or RP group bitmap.
                                  * if rpf_mode is CLX_TNL_PIM_MODE_SM, the rpf check will fail when the
                                  * TDS_HSH_MXGO.rpf_bd is not equal rpf_intf_id_or_bmp. if
                                  * rpf_mode is CLX_TNL_PIM_MODE_BIDIR, the rpf check will fail when
                                  * the lower 3 bits of TDS_HSH_MGO.rpf_bd which is RP
                                  * group is not set in rpf_intf_id_or_bmp
                                  * cl8600 only */
} clx_tnl_mac_info_t;
#define CLX_TNL_MAC_FLAGS_PORT_VALID                                                 \
    (0x1U << 0)                                  /* Enable port comparison,          \
                                                  * set to 1 to compare port_lag_id; \
                                                  * set to 0 to mask port_lag_id.    \
                                                  */
#define CLX_TNL_MAC_FLAGS_CVID_VALID (0x1U << 1) /* Indicate if cvid is valid */
#define CLX_TNL_MAC_FLAGS_MPLS_EN    (0x1U << 2) /* Enable MPLS */
#define CLX_TNL_MAC_FLAGS_MPLS_MAC_CHK_EXCPT \
    (0x1U << 3) /* Raise exception if MPLS packets rmac check fail. cl8600 only */
#define CLX_TNL_MAC_FLAGS_GIPO_MISS_DROP \
    (0x1U << 4) /* Drop if outer multicast IP address lookup miss. cl8600 only */
#define CLX_TNL_MAC_FLAGS_RPF_CHK_EN (0x1U << 5) /* Enable PIM rpf check. cl8600 only */
#define CLX_TNL_MAC_FLAGS_MAC_SRAM_CHK                                          \
    (0x1U << 6) /* Select to use tcam or sram table for rmac check. cl8600 only \
                 * set to 1 use sram table check mac address.                   \
                 * set to 0 use tcam table check mac address.                   \
                 */
#define CLX_TNL_MAC_FLAGS_SRV6_ONLY                                                      \
    (0x1U << 7) /* Enable SRv6 packet only. cl8600 only                                  \
                 * Set to 1 to disable IPv6 Tunnel decapsulation and MPLS decapsulation. \
                 * MUST set if locator length less then 4 bytes.                         \
                 */

/* Tunnel Encapsulation Information. */
typedef struct clx_tnl_encap_info_s {
    uint32 flags;             /* Refer to CLX_TNL_ENCAP_FLAGS_XXX. */
    clx_qos_prof_t egr_qos;   /* Egress qos */
    uint8 dscp;               /* If the outer header QOS is not from the inner
                               * header, assign the outer header DSCP value.
                               */
    uint8 ttl;                /* If the outer header TTL is not from the inner
                               * header, assign the outer header TTL value.
                               */
    uint32 mir_session_bmp;   /* Mirror session ID bitmap */
    uint32 grp_lbl;           /* Group label */
    uint32 meter_id;          /* Meter ID */
    uint32 cnt_id;            /* Service counter ID */
    uint32 dist_cnt_id;       /* Distribution counter ID */
    uint16 l2_mtu;            /* L2 mtu size. cl8600 only */
    clx_sample_t sample;      /* Sample */
    clx_vlan_tpid_t egr_tpid; /* Inner header's TPID setting. */
} clx_tnl_encap_info_t;
#define CLX_TNL_ENCAP_FLAGS_DST_IP_FROM_IPV6                   \
    (0x1U << 0)  /* Per tunnel encap and only for auto tunnel, \
                  * set to 1 if destination IPv4 address       \
                  * derived from inner destination IPv6        \
                  * address. cl8500 only                       \
                  */
#define CLX_TNL_ENCAP_FLAGS_TTL_UNIFORM                    \
    (0x1U << 1)  /* Per tunnel encap.                      \
                  * set to 1 if outer TTL value from inner \
                  * header TTL.                            \
                  */
#define CLX_TNL_ENCAP_FLAGS_FLOWLABEL_COPY_INNER               \
    (0x1U << 2)  /* Per tunnel encap and only for IPv6 tunnel. \
                  * set to 1 if outer header flowlabel         \
                  * value from inner header flowlabel.         \
                  */
#define CLX_TNL_ENCAP_FLAGS_DF_BIT_EN                          \
    (0x1U << 3)  /* Per tunnel encap and only for IPv4 tunnel. \
                  * set to 1 if set DF bit  in outer IPv4      \
                  * header.                                    \
                  */
#define CLX_TNL_ENCAP_FLAGS_QOS_UNIFORM                    \
    (0x1U << 4)  /* Per tunnel encap.                      \
                  * Set to 1 if outer QoS value from inner \
                  * header QoS.                            \
                  */
#define CLX_TNL_ENCAP_FLAGS_ECN_STANDARD               \
    (0x1U << 5)  /* Per tunnel encap.                  \
                  * Set to 1 if outer header ECN value \
                  * from inner header ECN.             \
                  */
#define CLX_TNL_ENCAP_FLAGS_KEEP_INNER_TAG      \
    (0x1U << 6)  /* Per tunnel encap.           \
                  * set to 1 if keep inner tag. \
                  * cl8600 only                 \
                  */
#define CLX_TNL_ENCAP_FLAGS_METER_ID                 \
    (0x1U << 7)  /* Per tunnel encap.                \
                  * set to 1 if meter_id is applied. \
                  */
#define CLX_TNL_ENCAP_FLAGS_CNT_ID                 \
    (0x1U << 8)  /* Per tunnel encap.              \
                  * set to 1 if cnt_id is applied. \
                  */
#define CLX_TNL_ENCAP_FLAGS_DIST_CNT_ID                 \
    (0x1U << 9)  /* Per tunnel encap.                   \
                  * set to 1 if dist_cnt_id is applied. \
                  */
#define CLX_TNL_ENCAP_FLAGS_GBP_EN \
    (0x1U << 10) /* set to 1 to encapsulate gbp tag to Vxlan header. cl8600 only */

/* Tunnel decapsulation, MRPF mode */
typedef enum clx_tnl_mc_mode_e {
    CLX_TNL_MC_MODE_NONE = 0,
    CLX_TNL_MC_MODE_MGO_ONLY,  /* only set MGO table */
    CLX_TNL_MC_MODE_MSGO_ONLY, /* only set MSGO table, need to create MGO with sg_only=1 */
    CLX_TNL_MC_MODE_LAST
} clx_tnl_mc_mode_t;

/* Tunnel decapsulation Information */
typedef struct clx_tnl_decap_info_s {
    uint32 flags;              /* Refer to CLX_L3T_TERM_FLAGS_XXX. */
    uint32 intf_id;            /* Tunnel interface ID */
    uint8 dflt_pcp;            /* The default PCP will be used if the native packet
                                * is untagged, or the native VLAN tag is distrusted.
                                */
    uint8 dflt_dei;            /* The default DEI will be used if the native packet
                                * is untagged or the native VLAN tag is distrusted.
                                */
    clx_qos_prof_t igr_qos;    /* ingress qos, including dscp-to-phb and dot1p-to-phb */
    uint32 mir_session_bmp;    /* Mirror session ID bitmap */
    uint32 grp_lbl;            /* Group label */
    uint32 meter_id;           /* Meter ID */
    uint32 cnt_id;             /* Service counter ID */
    uint32 dist_cnt_id;        /* Distribution counter ID */
    uint32 es_grp;             /* use to esi filter
                                * cl8600 only
                                */
    uint16 rpf_bd;             /* use to check mrpf
                                * cl8600 only
                                */
    clx_tnl_mc_mode_t mc_mode; /* use to set mrpf mode
                                * cl8600 only
                                */
    clx_sa_miss_rsn_t sa_rsn;  /* CLX_SA_MISS_RSN_0/1 */
    clx_sample_t sample;
    uint16 l2_mtu;             /* L2 mtu size */
    clx_vlan_tpid_t igr_tpid[CLX_PORT_INTF_TPID_MAX_NUM]; /* Inner header's TPID setting */
} clx_tnl_decap_info_t;
#define CLX_TNL_DECAP_FLAGS_6TO4_IP_CHECK                      \
    (0x1U << 0)  /* Per tunnel decap.                          \
                  * set to 1 if check 6to4 tunnel inner header \
                  * IP consistent with outer header IP         \
                  */
#define CLX_TNL_DECAP_FLAGS_ISATAP_IP_CHECK                      \
    (0x1U << 1)  /* Per tunnel decap.                            \
                  * set to 1 if check isatap tunnel inner header \
                  * IP consistent with outer header IP           \
                  */
#define CLX_TNL_DECAP_FLAGS_USE_INNER_PHB                      \
    (0x1U << 2)  /* Per tunnel term.                           \
                  * set to 1 if user inner header QoS(DSCP/PCP \
                  * /DEI) as traffic class and color source    \
                  */
#define CLX_TNL_DECAP_FLAGS_KEEP_INNER_QOS                                         \
    (0x1U << 3)  /* Per tunnel term.                                               \
                  * set to 1 if outer copy qos value into inner                    \
                  * need set qos_dont_modify to 1 first, when this flag is working \
                  */
#define CLX_TNL_DECAP_FLAGS_QOS_UNIFORM                                            \
    (0x1U << 4)  /* Per tunnel term.                                               \
                  * set to 1 if outer copy qos value into inner                    \
                  * need set qos_dont_modify to 1 first, when this flag is working \
                  * cl8600 only                                                    \
                  */
#define CLX_TNL_DECAP_FLAGS_TTL_UNIFORM                       \
    (0x1U << 5)  /* Per tunnel term.                          \
                  * set to 1 if copy outer TTL  to inner TTL. \
                  */
#define CLX_TNL_DECAP_FLAGS_ALLOW_INNER_TAG                  \
    (0x1U << 6)  /* Per tunnel term and only for vxlan.      \
                  * For nvgre, this flag must be 0.          \
                  * set to 1 if forward inner tagged packet. \
                  */
#define CLX_TNL_DECAP_FLAGS_METER_ID                 \
    (0x1U << 7)  /* Per tunnel term.                 \
                  * set to 1 if meter_id is applied. \
                  */
#define CLX_TNL_DECAP_FLAGS_CNT_ID                 \
    (0x1U << 8)  /* Per tunnel term.               \
                  * set to 1 if cnt_id is applied. \
                  */
#define CLX_TNL_DECAP_FLAGS_DIST_CNT_ID                 \
    (0x1U << 9)  /* Per tunnel term.                    \
                  * set to 1 if dist_cnt_id is applied. \
                  */
#define CLX_TNL_DECAP_FLAGS_ECN_STANDARD     \
    (0x1U << 10) /* Per tunnel term entry,   \
                  * set to 1 if disable ECN. \
                  */
#define CLX_TNL_DECAP_FLAGS_MAC_LEARN_DISABLE                     \
    (0x1U << 11) /* Per tunnel term and only for vxlan and nvgre. \
                  * set to 1 to disable MAC address learning.     \
                  */
#define CLX_TNL_DECAP_FLAGS_MCAST_RPF_FAIL_TO_CPU                          \
    (0x1U << 12) /* Per tunnel term and only for multicast tunnel          \
                  * set to 1 if multicast packets rpf fail and copy to CPU \
                  * cl8600 only                                            \
                  */
#define CLX_TNL_DECAP_FLAGS_TEP_BIND                              \
    (0x1U << 13) /* Per tunnel term.                              \
                  * set to 1 if check src_tep and dst_tep binding \
                  * cl8600 only                                   \
                  */
#define CLX_TNL_DECAP_FLAGS_GBP_EN \
    (0x1U << 14) /* set to 1 to get gbp tag from Vxlan header. cl8600 only */

/* NVO3 Route Information*/
typedef struct clx_tnl_nvo3_route_info_s {
    clx_nhp_t nhp; /* Nexthop information */
} clx_tnl_nvo3_route_info_t;

/* Flex Tunnel Information */
typedef struct clx_tnl_flex_tnl_udp_prof_s {
    uint32 rsv[CLX_TNL_FLEX_TNL_HDR_NUM - 1]; /* decrease size of destination port and source port
                                               */
    uint16 dst_port;
    uint16 src_port;
} clx_tnl_flex_tnl_udp_prof_t;

typedef struct clx_tnl_flex_tnl_udf_prof_s {
    union {
        uint32 user_defined[CLX_TNL_FLEX_TNL_HDR_NUM];
        clx_tnl_flex_tnl_udp_prof_t udp_hdr;
    } hdr;
    uint8 ip_proto;
    uint8 len; /* Flexible encap header length in bytes.
                  The maximum encap len is 24 and only even number of len is allowed.
                  example: UDP = 8
                */
} clx_tnl_flex_tnl_udf_prof_t;

typedef enum clx_tnl_flex_tnl_hdr_type_e {
    CLX_TNL_FLEX_TNL_HDR_TYPE_PIM,         /* Tunnel type PIM, use one entry */
    CLX_TNL_FLEX_TNL_HDR_TYPE_L2TP,        /* Tunnel type L2TP, use one entry */
    CLX_TNL_FLEX_TNL_HDR_TYPE_L2TP_WO_LEN, /* Tunnel type L2TP without len filed, use one entry */
    CLX_TNL_FLEX_TNL_HDR_TYPE_GTP,         /* Tunnel type GTP, use two entries */
    CLX_TNL_FLEX_TNL_HDR_TYPE_UDF,         /* User defined tunnel type */
    CLX_TNL_FLEX_TNL_HDR_TYPE_TEREDO,      /* Tunnel type TEREDO, use one entry in cl8600 */
    CLX_TNL_FLEX_TNL_HDR_TYPE_TEREDO_SIMP, /* Tunnel type TEREDO SIMP, use one entry in cl8600
                                            */
    CLX_TNL_FLEX_TNL_HDR_TYPE_LAST
} clx_tnl_flex_tnl_hdr_type_t;

typedef struct clx_tnl_flex_tnl_info_s {
    uint16 flags; /* Refer to CLX_TNL_FLEX_TNL_FLAGS_XXX. */
    clx_tnl_flex_tnl_hdr_type_t flex_tnl_hdr_type;
} clx_tnl_flex_tnl_info_t;
#define CLX_TNL_FLEX_TNL_FLAGS_UDP_IPV4_CHKSUM0_EN (0x1U << 0) /* Enable udp ipv4 checksum */
#define CLX_TNL_FLEX_TNL_FLAGS_UDP_IPV6_CHKSUM0_EN (0x1U << 1) /* Enable udp ipv6 checksum */

/* Physical port information for tunnel use */
typedef uint32 clx_es_df_bitmap_t[1];
typedef struct clx_tnl_port_info_s {
    uint32 flags;
    uint32 dflt_pcp;           /* Default pcp of tunnel header vlan tag */
    uint32 dflt_dei;           /* Default dei of tunnel header vlan tag */
    uint32 dflt_vid;           /* Default vid of tunnel header vlan tag */
    uint32 igr_l2_mtu;         /* L2 mtu size */
    uint32 esi;                /* EVPN esi label */
    clx_es_df_bitmap_t df_bmp; /* EVPN designated forwarder bitmap.
                                * bit0(1) set to 1 means this link is DF of
                                * bridge domain 0(1), 32(33), 64(65)...
                                */
    clx_vlan_tpid_t igr_tpid[CLX_PORT_INTF_TPID_MAX_NUM]; /* Ingress tpid */
    clx_vlan_tpid_t egr_tpid;                             /* Egress tpid */
    uint64 attr_bmp;                                      /* Mark which fields to set */
} clx_tnl_port_info_t;
#define CLX_TNL_PORT_INFO_FLAGS_TRUST_1P   (1U << 0) /* Trust 802.1p of tunnel header vlan tag */
#define CLX_TNL_PORT_INFO_FLAGS_TRUST_VLAN (1U << 1) /* Trust vlan id of tunnel header vlan tag */
#define CLX_TNL_PORT_INFO_FLAGS_RMAC_MERGE                                                  \
    (1U << 2)                                        /* Merge port to same tunnel rmac.     \
                                                      * Set to 1 if the tunnel is allowed   \
                                                      * to be terminated on multiple ports. \
                                                      */
#define CLX_TNL_PORT_INFO_FLAGS_NOT_ALLOW_CTAG \
    (1U << 3) /* Decapsulation of c-tag-only packets is not allowed */
#define CLX_TNL_PORT_INFO_FLAGS_TNL_SKIP_CHECK (1U << 4)   /* Skip outer l2/l3 address check. */
#define CLX_TNL_PORT_INFO_ATTR_DFLT_PCP        (1ULL << 0) /* Set dflt_pcp */
#define CLX_TNL_PORT_INFO_ATTR_DFLT_DEI        (1ULL << 1) /* Set dflt_dei */
#define CLX_TNL_PORT_INFO_ATTR_DFLT_VID        (1ULL << 2) /* Set dflt_vid */
#define CLX_TNL_PORT_INFO_ATTR_TRUST_1P        (1ULL << 3) /* Set CLX_TNL_PORT_INFO_FLAGS_TRUST_1P */
#define CLX_TNL_PORT_INFO_ATTR_TRUST_VLAN      (1ULL << 4) /* Set CLX_TNL_PORT_INFO_FLAGS_TRUST_VLAN */
#define CLX_TNL_PORT_INFO_ATTR_RMAC_MERGE      (1ULL << 5)  /* Set rmac merge mode */
#define CLX_TNL_PORT_INFO_ATTR_IGR_MTU         (1ULL << 6)  /* Set l2_mtu_size */
#define CLX_TNL_PORT_INFO_ATTR_ESI             (1ULL << 7)  /* Set esi */
#define CLX_TNL_PORT_INFO_ATTR_DF              (1ULL << 8)  /* Set df_bitmap */
#define CLX_TNL_PORT_INFO_ATTR_IGR_TPID        (1ULL << 9)  /* Set igr_tpid */
#define CLX_TNL_PORT_INFO_ATTR_EGR_TPID        (1ULL << 10) /* Set egr_tpid */
#define CLX_TNL_PORT_INFO_ATTR_NOT_ALLOW_CTAG \
    (1ULL << 11) /* Set CLX_TNL_PORT_INFO_FLAGS_NOT_ALLOW_CTAG */
#define CLX_TNL_PORT_INFO_ATTR_TNL_SKIP_CHECK \
    (1ULL << 12) /* Set CLX_TNL_PORT_INFO_FLAGS_TNL_SKIP_CHECK */
#define CLX_TNL_PORT_INFO_ATTR_ALL (0xFFFFFFFFFFFFFFFF) /* Set all fields */

typedef struct clx_tnl_seg_key_s {
    uint32 segment;        /* Segment id mapping to overlay network */
    uint32 egress_segment; /* Segment id used for encapsulation.
                            * If the mapping relation between segment and overlay is
                            * unique, this parameter does not need configuration */
    uint32 flags;          /* Refer to CLX_TNL_OVERLAY_MAPPING_FLAGS_XXX */
} clx_tnl_seg_key_t;

/* Assign segment id for egress encapsulation */
#define CLX_TNL_OVERLAY_MAPPING_FLAGS_ASSIGN_EGRESS_SEGMENT (1U << 0)

typedef enum {
    CLX_TNL_IPV6_EXT_TYPE_0 = 0,
    CLX_TNL_IPV6_EXT_TYPE_1,
    CLX_TNL_IPV6_EXT_TYPE_2,
    CLX_TNL_IPV6_EXT_TYPE_3,
    CLX_TNL_IPV6_EXT_TYPE_LAST,
} clx_tnl_ipv6_ext_type_t;

typedef clx_error_no_t (*clx_tnl_mac_trav_t)(const uint32 unit,
                                             const uint32 index,
                                             const clx_tnl_mac_info_t *ptr_mac_info,
                                             void *ptr_cookie);

typedef clx_error_no_t (*clx_tnl_encap_trav_func_t)(const uint32 unit,
                                                    const clx_tnl_info_t *ptr_tnl_info,
                                                    const clx_tnl_encap_info_t *ptr_encap_info,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*clx_tnl_decap_trav_func_t)(const uint32 unit,
                                                    const clx_tnl_info_t *ptr_tnl_info,
                                                    const clx_tnl_decap_info_t *ptr_decap_info,
                                                    void *ptr_cookie);

typedef clx_error_no_t (*clx_tnl_nvo3_route_trav_func_t)(
    const uint32 unit,
    const clx_tnl_info_t *ptr_tnl_info,
    const clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info,
    void *ptr_cookie);

typedef clx_error_no_t (*clx_tnl_port_trav_func_t)(const uint32 unit,
                                                   const clx_tnl_info_t *ptr_tnl_info,
                                                   const clx_port_t port,
                                                   void *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Add a tunnel MAC entry.
 *
 * This API is used to add a tunnel MAC entry. User needs to specify the index of
 * My Tunnel MAC table and the data of entry, including the port LAG ID, S-VLAN ID,
 * C-VLAN ID, tunnel MAC address and the mask of them.
 * My Tunnel MAC table is used to judge whether the incoming packet needs to be
 * sent via the tunnel decapsulation packet flow.
 * When packet arrives, if the tunnel is enabled, the ingress port ID,
 * outer destination MAC address, and outer VLAN ID are used to lookup the MyTunnelMAC table.
 * If the search result is hit, and outer source IP address and outer destination IP address
 * are both hit in the tunnel term table, the packet will go through the tunnel decapsulation packet
 * flow. User can set the mask bit to 0 in order to multiplex one entry by multiple port IDs, VLAN
 * IDs and MAC addresses.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    index           - The entry index.
 * @param [in]    ptr_mac_info    - The tunnel mac infomation.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_mac_add(const uint32 unit, const uint32 index, const clx_tnl_mac_info_t *ptr_mac_info);

/**
 * @brief Delete a tunnel MAC entry.
 *
 * This API is used to del a tunnel MAC entry.
 * Support_chip: CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    index    - The entry index.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No entry is found with input index.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 */
clx_error_no_t
clx_tnl_mac_del(const uint32 unit, const uint32 index);

/**
 * @brief Get a tunnel MAC infomation.
 *
 * This API is used to get a tunnel MAC infomation.
 .
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     index           - The entry index.
 * @param [out]    ptr_mac_info    - The tunnel mac infomation.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input index.
 */
clx_error_no_t
clx_tnl_mac_get(const uint32 unit, const uint32 index, clx_tnl_mac_info_t *ptr_mac_info);

/**
 * @brief Traverse all configured tunnel mac entries.
 *
 * This API is used to traverse all configured tunnel mac entries.
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_mac_trav(const uint32 unit, const clx_tnl_mac_trav_t cb, void *ptr_cookie);

/**
 * @brief Add a tunnel encapsulation for IP tunnel. If the tunnel encapsulation existed,
 *        the tunnel encapsulation attributes will be updated.
 *
 * This API is used to add a tunnel encapsulation entry for IP tunnel. If the tunnel encapsulation
 * existed, the tunnel encapsulation attributes will be updated. Source IP, destination IP, underlay
 * vrf, tunnel type tunnel type and tunnel interface ID must be specified in ptr_tnl_info. For
 * automatic tunnel, DIP is not required. For detailed description of tunnel encap information,
 * refer to clx_tnl_encap_info_t. If the incoming packet needs to go through the tunnel
 * encapsulation process, user can add the outer IP header to the original packet by this API. The
 * outer IP header information, such as QOS and TTL, can be obtained from the inner IP header or by
 * reassigning a new value. If the outer SIP and outer DIP are the same, VxLAN tunnel, NVGRE tunnel
 * and other L3 GRE tunnel must share the same tunnel encapsulation configuration with IP in IP
 * tunnel and automatic tunnel (6to4 and ISATAP).
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ptr_tnl_info      - Tunnel header information.
 * @param [in]    ptr_encap_info    - The tunnel encapsulation information to be added.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_encap_add(const uint32 unit,
                  const clx_tnl_info_t *ptr_tnl_info,
                  const clx_tnl_encap_info_t *ptr_encap_info);

/**
 * @brief Delete a tunnel encapsulation for IP tunnel.
 *
 * This API is used to delete a tunnel encapsulation entry for IP tunnel.
 * Source IP, Destination IP, underlay vrfand tunnel type must be specified in ptr_tnl_info.
 * But for automatic tunnel, SIP is not required.
 * For detailed description of tunnel encap information, refer to clx_tnl_encap_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel header information.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 */
clx_error_no_t
clx_tnl_encap_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

/**
 * @brief Get a tunnel encapsulation for IP tunnel.
 *
 * This API is used to get a tunnel encapsulation entry for IP tunnel.
 * Source IP, Destination IP, underlay vrfand tunnel type must be specified in ptr_tnl_info.
 * But for automatic tunnel, SIP is not required.
 * Detail description for tunnel encap information refers to clx_tnl_encap_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_tnl_info      - Tunnel header information.
 * @param [out]    ptr_encap_info    - The tunnel encap information to be obtained.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel header
 *                                            information.
 */
clx_error_no_t
clx_tnl_encap_get(const uint32 unit,
                  const clx_tnl_info_t *ptr_tnl_info,
                  clx_tnl_encap_info_t *ptr_encap_info);

/**
 * @brief Traverse all configured tunnel encap entries.
 *
 * This API is used to traverse all tunnel encap entries.
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_encap_trav(const uint32 unit, const clx_tnl_encap_trav_func_t cb, void *ptr_cookie);

/**
 * @brief Add a tunnel decapsulation entry for IP tunnel. If the tunnel decapsulation existed,
 *        the tunnel decapsulation attributes will be updated.
 *
 * This API is used to add a tunnel decapsulation entry. For automatic tunnel, SIP is not required;
 * Source IP, Destination IP, underlay vrf, tunnel type and tunnel interface ID must be specified in
 * ptr_tnl_info.  For detailed information of the tunnel decapsulation, refer to
 * clx_tnl_decap_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit              - Device unit number.
 * @param [in]    ptr_tnl_info      - Tunnel header information.
 * @param [in]    ptr_decap_info    - The tunnel decapsulation information to be added.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_decap_add(const uint32 unit,
                  const clx_tnl_info_t *ptr_tnl_info,
                  const clx_tnl_decap_info_t *ptr_decap_info);

/**
 * @brief Delete a tunnel decapsulation entry for IP tunnel.
 *
 * This API is used to delete a tunnel decapsulation entry.
 * Source IP, destination IP, underlay vrf and tunnel type must be specified in ptr_tnl_info.
 * But for automatic tunnel, SIP is not required.
 * For detailed information of the decapsulation, refer to clx_tnl_decap_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel header information.
 * @return        CLX_E_NO_MEMORY          - No available memory.
 */
clx_error_no_t
clx_tnl_decap_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

/**
 * @brief Get a specified tunnel decapsulation entry for IP tunnel.
 *
 * This API is used to get a specified tunnel decapsulation entry.
 * Source IP, destination IP, underlay vrf and tunnel type must be specified in ptr_tnl_info.
 * But for automatic tunnel, SIP is not required.
 * For detailed information of the tunnel decapsulation, refer to clx_tnl_decap_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     ptr_tnl_info      - Tunnel header information.
 * @param [out]    ptr_decap_info    - The tunnel decapsulation information to be obtained.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel header
 *                                            information.
 */
clx_error_no_t
clx_tnl_decap_get(const uint32 unit,
                  const clx_tnl_info_t *ptr_tnl_info,
                  clx_tnl_decap_info_t *ptr_decap_info);

/**
 * @brief Traverse all configured tunnel decapsulation entries.
 *
 * This API is used to traverse all configured tunnel decapsulation entries.
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_decap_trav(const uint32 unit, const clx_tnl_decap_trav_func_t cb, void *ptr_cookie);

/**
 * @brief Add a NVO3 route. If NHP type is ECMP, add a NVO3 ECMP route.
 *
 * This API is used to add a NVO3 route. If NHP type is ECMP, add a NVO3 ECMP route.
 * When user needs to set an IP packet forward from tunnel, it can be used
 * to set the IP packet which matches one route entry forwarded from a tunnel.
 * For detailed information of NVO3 route, refer to clx_tnl_nvo3_route_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit                   - Device unit number.
 * @param [in]    ptr_tnl_info           - Tunnel header information.
 * @param [in]    ptr_nvo3_route_info    - The NVO3 route information to be added.
 *                                         For ECMP route, the NVO3 ECMP group ID needs to be
 *                                         specified.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_nvo3_route_add(const uint32 unit,
                       const clx_tnl_info_t *ptr_tnl_info,
                       const clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);

/**
 * @brief Delete NVO3 route of IP tunnel.
 *
 * This API is used to delete a NVO3 route.
 * Destination IP, source IP, underlay vrf and tunnel type must be specified in ptr_tnl_info.
 * For detailed information of NVO3 route, refer to clx_tnl_nvo3_route_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_nvo3_route_del(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info);

/**
 * @brief Get a NVO3 route of IP tunnel.
 *
 * This API is used to get a NVO3 route.
 * Destination IP, source IP, underlay vrf and tunnel type must be specified in ptr_tnl_info.
 * For detailed information of NVO3 route, refer to clx_tnl_nvo3_route_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]     unit                   - Device unit number.
 * @param [in]     ptr_tnl_info           - Tunnel header information.
 * @param [out]    ptr_nvo3_route_info    - The NVO3 route information to be obtained.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel header
 *                                            information.
 */
clx_error_no_t
clx_tnl_nvo3_route_get(const uint32 unit,
                       const clx_tnl_info_t *ptr_tnl_info,
                       clx_tnl_nvo3_route_info_t *ptr_nvo3_route_info);
/**
 * @brief Traverse all configured nvo3_route entries.
 *
 * This API is used to traverse all configured nvo3_route entries.
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_nvo3_route_trav(const uint32 unit,
                        const clx_tnl_nvo3_route_trav_func_t cb,
                        void *ptr_cookie);

/**
 * @brief Create tunnel port.
 *
 * This API is used to create tunnel port.
 * Source IP, destination IP, underlay vrf and tunnel type must be specified in ptr_tnl_info.
 * But for automatic tunnel, SIP is not required.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     flag            - Refers to CLX_TNL_FLAGS_XXX.
 * @param [in]     ptr_tnl_info    - Tunnel header infomation.
 * @param [out]    ptr_port        - Tunnel port.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel header
 *                                            information.
 */
clx_error_no_t
clx_tnl_port_create(const uint32 unit,
                    const uint32 flag,
                    const clx_tnl_info_t *ptr_tnl_info,
                    clx_port_t *ptr_port);

/**
 * @brief Destroy tunnel port.
 *
 * This API is used to destroy tunnel port.
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Tunnel port.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel port information.
 */
clx_error_no_t
clx_tnl_port_destroy(const uint32 unit, const clx_port_t port);

/**
 * @brief Get tunnel port from tunnel header.
 *
 * This API is used to get tunnel port from tunnel header.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_tnl_info    - Tunnel header information.
 * @param [out]    ptr_tnl_port    - Tunnel port.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel header
 *                                            information.
 */
clx_error_no_t
clx_tnl_port_get(const uint32 unit, const clx_tnl_info_t *ptr_tnl_info, clx_port_t *ptr_tnl_port);

/**
 * @brief Get tunnel header from tunnel port.
 *
 * This API is used to get tunnel header from tunnel port.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     tnl_port        - Tunnel port.
 * @param [out]    ptr_tnl_info    - Tunnel header information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input tunnel port information.
 */
clx_error_no_t
clx_tnl_info_get(const uint32 unit, const clx_port_t tnl_port, clx_tnl_info_t *ptr_tnl_info);

/**
 * @brief Traverse all configured tunnel port entries.
 *
 * This API is used to traverse all configured tunnel port entries.
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     cb            - Callback function provided by user for traversed node operation.
 * @param [in]     ptr_cookie    - Input parameter of callback function.
 * @param [out]    ptr_cookie    - Output parameter of callback function.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_port_trav(const uint32 unit, const clx_tnl_port_trav_func_t cb, void *ptr_cookie);

/**
 * @brief Add flexible tunnel pattern.
 *
 * This API is used to add flexible tunnel pattern.
 * For detailed information of flexible tunnel pattern, refer to clx_tnl_flex_tnl_info_t.
 * Support_chip: CLX86.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    index                - Index of flexible tunnel pattern.
 * @param [in]    ptr_flex_tnl_info    - Flexible tunnel information.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_flex_tnl_add(const uint32 unit,
                     const uint32 index,
                     const clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

/**
 * @brief Delete flexible tunnel pattern.
 *
 * This API is used to del flexible tunnel pattern.
 * Support_chip: CLX86.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    index    - Index of flexible tunnel pattern.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_flex_tnl_del(const uint32 unit, const uint32 index);

/**
 * @brief Get flexible tunnel pattern by index.
 *
 * This API is used to get flexible tunnel pattern by index.
 * Support_chip: CLX86.
 *
 * @param [in]     unit                 - Device unit number.
 * @param [in]     index                - Index of flexible tunnel pattern.
 * @param [out]    ptr_flex_tnl_info    - Flexible tunnel information.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - No entry is found with input index.
 */
clx_error_no_t
clx_tnl_flex_tnl_get(const uint32 unit,
                     const uint32 index,
                     clx_tnl_flex_tnl_info_t *ptr_flex_tnl_info);

/**
 * @brief Set flexible tunnel UDF profile.
 *
 * This API is used to set flexible tunnel UDF profile.
 * Flex tunnel used profile parameter when type is CLX_TNL_FLEX_TNL_HDR_TYPE_UDF.
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    index       - Index of flexible tunnel pattern.
 * @param [in]    ptr_prof    - UDF profile information to be set.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_flex_tnl_udf_set(const uint32 unit,
                         const uint32 index,
                         clx_tnl_flex_tnl_udf_prof_t *ptr_prof);

/**
 * @brief Get flexible tunnel UDF profile by index.
 *
 * This API is used to get flexible tunnel UDF profile by index.
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     index       - Index of flexible tunnel pattern.
 * @param [out]    ptr_prof    - UDF profile information to be obtained.
 * @return         CLX_E_OK    - Operation success.
 */
clx_error_no_t
clx_tnl_flex_tnl_udf_get(const uint32 unit,
                         const uint32 index,
                         clx_tnl_flex_tnl_udf_prof_t *ptr_prof);

/**
 * @brief Set physical port property.
 *
 * This API is used to set physical port property.
 * Support_chip: CLX86.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    port             - Port object.
 * @param [in]    ptr_port_info    - Physical port property to be set.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_phy_port_set(const uint32 unit,
                     const clx_port_t port,
                     const clx_tnl_port_info_t *ptr_port_info);

/**
 * @brief Get Physical Port property.
 *
 * This API is used to get physical port property.
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Port object.
 * @param [out]    ptr_port_info    - Physical port property to be obtained.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_tnl_phy_port_get(const uint32 unit, const clx_port_t port, clx_tnl_port_info_t *ptr_port_info);

/**
 * @brief Create an ethernet segment group.
 *
 * This API is used to add or set an ethernet segment group, which is used to filter looped
 * multi-copy packets in NVO encapsulation(VxLAN/NVGRE/GENEVE) EVPN. EVPN needs some mechanisms for
 * split-horizon filtering to support all-active multihoming. MPLS encapsulation(including MPLS over
 * GRE) uses MPLS label to achieve this goal while network virtualization overlay
 * encapsulation(VxLAN/NVGRE/GENEVE) use local bias to implement it. Every NVE tracks the IP
 * address(es) associated with the other NVE(s) with which it has shared multihomed ESs. When the
 * NVE receives a multi-copy frame from the overlay network, it examines the source IP address in
 * the tunnel header (which corresponds to the ingress NVE) and filters out the frame on all local
 * interfaces connected to ESs that are shared with the ingress NVE. This is local bias mentioned
 * above.
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     flags         - Refers to CLX_TNL_EVPN_FLAGS_XX.
 * @param [out]    ptr_es_grp    - The pointer of ethernet segment group index.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_ENTRY_IN_USE     - Entry is in use.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_es_grp_create(const uint32 unit, const uint32 flags, uint32 *ptr_es_grp);

/**
 * @brief Destroy an ethernet segment group.
 *
 * This API is used to destroy an ethernet segment group.
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    es_grp    - Ethernet segment group index.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_es_grp_destroy(const uint32 unit, const uint32 es_grp);

/**
 * @brief Add ethernet segment group port member.
 *
 * This API is used to add ethernet segment group port member.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    es_grp          - Ethernet segment group index.
 * @param [in]    ptr_port_mbr    - The pointer of esgroup member port array.
 * @param [in]    port_num        - Add esgroup member count.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_es_grp_mbr_add(const uint32 unit,
                       const uint32 es_grp,
                       const clx_port_t *ptr_port_mbr,
                       const uint32 port_num);

/**
 * @brief Delete ethernet segment group port member.
 *
 * This API is used to delete ethernet segment group port member.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    es_grp          - Ethernet segment group index.
 * @param [in]    ptr_port_mbr    - The pointer of esgroup member port array.
 * @param [in]    port_num        - Delete esgroup member count.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_es_grp_mbr_del(const uint32 unit,
                       const uint32 es_grp,
                       const clx_port_t *ptr_port_mbr,
                       const uint32 port_num);

/**
 * @brief Get ethernet segment group port member.
 *
 * This API is used to get ethernet segment group port member.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     es_grp          - Ethernet segment group index.
 * @param [out]    ptr_port_mbr    - The pointer of esgroup member port array.
 * @param [out]    ptr_port_num    - The pointer of esgroup member count.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_es_grp_mbr_get(const uint32 unit,
                       const uint32 es_grp,
                       clx_port_t *ptr_port_mbr,
                       uint32 *ptr_port_num);

/**
 * @brief Add or set a tunnel to a specified segment and related service.
 *
 * This API is used to add or set a tunnel to a specified segment and related service.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header information.
 * @param [in]    ptr_segment     - The pointer of segment information.
 * @param [in]    bdid            - Bridge domain ID.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_ENTRY_EXISTS     - Entry exists.
 * @return        CLX_E_TABLE_FULL       - Hardware table is full, entry can not be added.
 * @return        CLX_E_NOT_SUPPORT      - Not Supported.
 * @return        CLX_E_OTHERS           - Other errors.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 */
clx_error_no_t
clx_tnl_seg_srv_add(const uint32 unit,
                    const clx_tnl_info_t *ptr_tnl_info,
                    const clx_tnl_seg_key_t *ptr_segment,
                    const uint32 bdid);

/**
 * @brief Delete a specified segment segment of a tunnel.
 *
 * This API is used to used to delete a specified segment segment of a tunnel.
 * Support_chip: CLX86.
 *
 * @param [in]    unit            - Device unit number.
 * @param [in]    ptr_tnl_info    - Tunnel header information.
 * @param [in]    ptr_segment     - The pointer of segment information.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 * @return        CLX_E_NOT_SUPPORT        - Not Supported.
 */
clx_error_no_t
clx_tnl_seg_srv_del(const uint32 unit,
                    const clx_tnl_info_t *ptr_tnl_info,
                    const clx_tnl_seg_key_t *ptr_segment);

/**
 * @brief Get the service of a (segment, tunnel) pair.
 *
 * This API is used to get the service of a (segment, tunnel) pair.
 * Support_chip: CLX86.
 *
 * @param [in]     unit            - Device unit number.
 * @param [in]     ptr_tnl_info    - Tunnel header information.
 * @param [in]     ptr_segment     - The pointer of segment information.
 * @param [out]    ptr_bdid        - The pointer of bridge domain ID.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 * @return         CLX_E_NOT_SUPPORT        - Not Supported.
 */
clx_error_no_t
clx_tnl_seg_srv_get(const uint32 unit,
                    const clx_tnl_info_t *ptr_tnl_info,
                    const clx_tnl_seg_key_t *ptr_segment,
                    uint32 *ptr_bdid);

#endif
