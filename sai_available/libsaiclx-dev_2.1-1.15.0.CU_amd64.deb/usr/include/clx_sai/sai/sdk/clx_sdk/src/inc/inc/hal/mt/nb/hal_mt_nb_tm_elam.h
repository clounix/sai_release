/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_nb_tm_elam.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_MT_NB_TM_ELAM_H
#define HAL_MT_NB_TM_ELAM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_init.h>
#include <clx/clx_port.h>
#include <clx/clx_swc.h>
#include <clx/clx_tm.h>

typedef enum hal_mt_nb_tm_elam_bac_bus_1_field_id_e {
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_MOD_OQ_BUF_FULL_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_MOD_OQ_PD_FULL_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_MOD_MAPPED_SQ_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SAI_OQ_INDEX_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SAI_SQ_INDEX_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SAI_COLOR_WRED_DROP_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SAI_COLOR_ECN_MARK_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SAI_RECV_COLOR_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SAI_SRC_TAIL_DROP_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SA_REP_DROP_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SAI_VLD_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_POOL_PFC_XOFF_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_BAC2IPL_PFC_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_OQ_RESULT_ECN_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_OQ_RESULT_DROP_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SQG_SMART_DROP_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SQ_RESULT_DEC_PFC_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SQ_RESULT_DEC_VLD_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SQ_RESULT_PD_PFC_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SQ_RESULT_PD_DROP_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SQ_RESULT_PD_VLD_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SCRUBBER_PFC_WDATA_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_SCRUBBER_PFC_WREN_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_RESULT_DEC_SQ_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_RESULT_PD_SQ_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_GENERAL_IRQ_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_DEBUG_INFO_FILED_ID,
    HAL_MT_NB_TM_ELAM_BAC_BUS_1_LAST_FIELD_ID
} hal_mt_nb_tm_elam_field_id_t;

extern packing_info_t
    hal_mt_nb_tm_elam_bac_bus_1_fld_info[HAL_MT_NB_TM_ELAM_BAC_BUS_1_LAST_FIELD_ID];

extern table_info_t hal_mt_nb_tm_elam_bac_bus_1_tbl_info;

clx_error_no_t
hal_mt_nb_tm_elam_init(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_elam_cap_data_get(const uint32 unit,
                               const uint32 count,
                               uint32 *ptr_real_count,
                               hal_tm_elam_capture_data_t *ptr_trigger_data_list);

clx_error_no_t
hal_mt_nb_tm_elam_trigger_cfg_set(const uint32 unit, const hal_tm_elam_trigger_cfg_t *ptr_cfg);

clx_error_no_t
hal_mt_nb_tm_elam_trigger_cfg_get(const uint32 unit, hal_tm_elam_trigger_cfg_t *ptr_cfg);

clx_error_no_t
hal_mt_nb_tm_elam_trigger_key_set(const uint32 unit,
                                  const hal_tm_elam_trigger_key_t *ptr_trigger_key);

clx_error_no_t
hal_mt_nb_tm_elam_trigger_key_get(const uint32 unit, hal_tm_elam_trigger_key_t *ptr_trigger_key);

clx_error_no_t
hal_mt_nb_tm_elam_start(const uint32 unit);

clx_error_no_t
hal_mt_nb_tm_elam_clear(const uint32 unit);

#endif /* #ifndef HAL_MT_NB_TM_ELAM_H */
