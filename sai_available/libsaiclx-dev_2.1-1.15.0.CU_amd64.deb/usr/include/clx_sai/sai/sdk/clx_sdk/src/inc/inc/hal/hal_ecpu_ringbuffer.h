/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_ecpu_ringbuffer.h
 * PURPOSE:
 *  1. Provide ring buffer macros and data structures.
 */

#ifndef HAL_ECPU_RING_BUFFER_H
#define HAL_ECPU_RING_BUFFER_H

/* INCLUDE FILE DECLARATIONS
 */
#include <stdbool.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_ECPU_RING_BUFFER_DB_RESET(pdb) \
    {                                      \
        (pdb)->data_offset = 0;            \
        (pdb)->size = 0;                   \
        (pdb)->sop = 0;                    \
        (pdb)->eop = 0;                    \
    }

#define HAL_ECPU_RING_BUFFER_SIZE_GET(pelk_cb) ((pelk_cb)->txbuf.ring.size)
#define HAL_ECPU_RING_SIZE_GET(pring)          ((pring)->ring.ring_size)
#define HAL_ECPU_RING_INFO_GET(pring)          (&(pring)->ring)

#define HAL_ECPU_RING_WR_RD_IDX_GET(unit, pring, write_idx, read_idx)          \
    do {                                                                       \
        clx_error_no_t ret = CLX_E_OK;                                         \
        uint32 index[2] = {0};                                                 \
        ret = drv_reg_read(unit, pring->ring.write_idx, index, sizeof(index)); \
        if (ret != CLX_E_OK) {                                                 \
            return CLX_E_OTHERS;                                               \
        }                                                                      \
        write_idx = index[0];                                                  \
        read_idx = index[1];                                                   \
    } while (false)

#define HAL_ECPU_RING_RD_IDX_GET(unit, pinfo, pindex)                                           \
    do {                                                                                        \
        if (drv_reg_read(unit, pinfo->read_idx, pindex, sizeof(pinfo->read_idx)) != CLX_E_OK) { \
            return CLX_E_OTHERS;                                                                \
        }                                                                                       \
    } while (false)

#define HAL_ECPU_RING_WR_IDX_GET(unit, pinfo, pindex)                                             \
    do {                                                                                          \
        if (drv_reg_read(unit, pinfo->write_idx, pindex, sizeof(pinfo->write_idx)) != CLX_E_OK) { \
            return CLX_E_OTHERS;                                                                  \
        }                                                                                         \
    } while (false)

typedef struct hal_ecpu_ring_buffer_descriptor_s {
    uint16 size; /*length of data in the buffer*/
    uint8 sop;   /*start of data*/
    uint8 eop;   /*end of data*/
    uint32 data_offset;
    uint32 buf_addr;
} hal_ecpu_ring_buffer_descriptor_t;

typedef struct hal_ecpu_ring_buffer_s {
    struct hal_ecpu_ring_buffer_s *frags;
    const uint8 *pdata;
    uint32 offset;
    uint16 len; /*data length*/
} hal_ecpu_ring_buffer_t;

typedef struct hal_ecpu_ring_buffer_info_s {
    uint32 ring_base;
    uint32 write_idx;
    uint32 read_idx;
    uint32 ring_size; /*The number of buffers*/
    uint32 size;      /*The length of each buffer*/
    uint32 buf_base;
    hal_ecpu_ring_buffer_descriptor_t db[0];
} hal_ecpu_ring_buffer_info_t;

typedef struct hal_ecpu_ring_buffer_control_s {
    clx_semaphore_id_t sem_sync;
    hal_ecpu_ring_buffer_info_t ring;
    uint32 base; /*Ecpu memory address on chain or in soc*/
} hal_ecpu_ring_buffer_control_t;

/**
 * @brief This API is used to init received buffer.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    pbuf    - The received buffer.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_ring_buf_rx_init(const uint32 unit, hal_ecpu_ring_buffer_control_t *pbuf);

/**
 * @brief This API is used to init send buffer.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    pbuf    - The send buffer.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Operate failed.
 */
clx_error_no_t
hal_ring_buf_tx_init(const uint32 unit, hal_ecpu_ring_buffer_control_t *pbuf);

/**
 * @brief This API is used to get the number of free buffers.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    pring    - Ring buffer control block.
 * @return        uint32    - The number of free buffers.
 */
uint32
hal_ring_buf_free_buf_num_get(const uint32 unit, hal_ecpu_ring_buffer_control_t *pring);

/**
 * @brief This API is used to read data from ring buffer.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    pring     - Ring buffer control block.
 * @param [in]    ppdata    - Pointer to the data read from the ring buffer.
 * @return        CLX_E_OK                 - Successfully read ring buffer.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Ring buffer is empty.
 * @return        CLX_E_NO_MEMORY          - Failed to osal_alloc memory.
 * @return        CLX_E_OTHERS             - Failed to read ring buffer.
 */
clx_error_no_t
hal_ring_buf_read(const uint32 unit, hal_ecpu_ring_buffer_control_t *pring, void **ppdata);

/**
 * @brief This API is used to write data to the ring buffer.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    pring    - Ring buffer control block.
 * @param [in]    pbuf     - Pointer for the written data.
 * @return        CLX_E_OK        - Successfully read ring buffer.
 * @return        CLX_E_OTHERS    - Failed to read ring buffer.
 */
clx_error_no_t
hal_ring_buf_write(const uint32 unit,
                   hal_ecpu_ring_buffer_control_t *pring,
                   hal_ecpu_ring_buffer_t *pbuf);

/**
 * @brief This API is used to get ring buffer read index.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     pinfo     - Pointer to ring info descriptor.
 * @param [out]    pindex    - Pointer to read index.
 * @return         CLX_E_OK        - Successfully read ring buffer.
 * @return         CLX_E_OTHERS    - Failed to read ring buffer.
 */
clx_error_no_t
hal_ring_buf_read_idx_get(const uint32 unit, hal_ecpu_ring_buffer_info_t *pinfo, uint32 *pindex);

/**
 * @brief This API is used to get ring buffer write index.
 *
 * @param [in]     unit      - Device unit number.
 * @param [in]     pinfo     - Pointer to ring info descriptor.
 * @param [out]    pindex    - Pointer to write index.
 * @return         CLX_E_OK        - Successfully read ring buffer.
 * @return         CLX_E_OTHERS    - Failed to read ring buffer.
 */
clx_error_no_t
hal_ring_buf_write_idx_get(const uint32 unit, hal_ecpu_ring_buffer_info_t *pinfo, uint32 *pindex);

#endif
