/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_pkj.h
 * PURPOSE:
 *      It provides packet journal function for mountain family.
 *
 * NOTES:
 *
 */

#ifndef HAL_MT_PKJ_H
#define HAL_MT_PKJ_H

/* INCLUDE FILE DECLARATIONS
 */
#include <hal/hal_pkj.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum hal_mt_pkj_trigger_e {
    HAL_MT_PKJ_TRIGGER_IGR_OUTER = 0,
    HAL_MT_PKJ_TRIGGER_IGR_INNER,
    HAL_MT_PKJ_TRIGGER_EGR,
    HAL_MT_PKJ_TRIGGER_LAST,
} hal_mt_pkj_trigger_t;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
clx_error_no_t
hal_mt_pkj_cmm_init(const uint32 unit);

clx_error_no_t
hal_mt_pkj_cmm_deinit(const uint32 unit);

clx_error_no_t
hal_mt_pkj_cmm_property_set(const uint32 unit,
                            const hal_pkj_property_t property,
                            const uint32 value);

clx_error_no_t
hal_mt_pkj_cmm_property_get(const uint32 unit,
                            const hal_pkj_property_t property,
                            uint32 *ptr_value);

clx_error_no_t
hal_mt_pkj_cmm_trigger_key_set(const uint32 unit,
                               const uint32 flags,
                               const hal_pkj_trig_key_t *ptr_trig_key);

clx_error_no_t
hal_mt_pkj_cmm_trigger_key_get(const uint32 unit, hal_pkj_trig_key_t *ptr_trig_key);

clx_error_no_t
hal_mt_pkj_cmm_trigger_enable(uint32 unit);

clx_error_no_t
hal_mt_pkj_hit_plane_get(const uint32 unit, const hal_mt_pkj_trigger_t type, uint32 *ptr_plane_bmp);

clx_error_no_t
hal_mt_pkj_handler_apply(const uint32 unit,
                         const uint32 inst,
                         const uint32 sub_inst,
                         const hal_pkj_tbl_cb_info_t *ptr_tbl_info,
                         const hal_pkj_buf_meta_t *ptr_meta);

clx_error_no_t
hal_mt_pkj_decode_cb_id_find(const uint32 unit,
                             const uint32 base_cb_id,
                             hal_pkj_tbl_cb_decode_info_t *ptr_cb,
                             const uint32 *ptr_buf,
                             uint32 *ptr_cb_id);

clx_error_no_t
hal_mt_pkj_util_tbl_field_print(const uint32 unit,
                                const uint32 inst,
                                const uint32 sub_inst,
                                const uint32 tbl_id,
                                const uint32 entry_idx,
                                const uint32 flags);

void
hal_mt_pkj_port_list_print(const clx_port_bitmap_t pbm);
/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif /* End of HAL_MT_PKJ_H */