/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  osal.h
 * PURPOSE:
 *  osal.h provide an OS abstration layer's API for different OS. The APIs
 *  include task/thread, semaphore, time, memory, string and C library.
 * NOTES:
 *
 */

#ifndef OSAL_H
#define OSAL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <osal/osal_lib.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

#ifdef CLX_LOCK_DEBUG

#define OSAL_LOCK_DEBUG (1)

#endif

/* DATA TYPE DECLARATIONS
 */

typedef struct osal_tm_s {
    uint32 year;  /* year,   20XX */
    uint32 month; /* month,  1~12 */
    uint32 day;   /* day,    1~31 */
    uint32 hour;  /* hour,   0~23 */
    uint32 min;   /* minute, 0~59 */
    uint32 sec;   /* second, 0~59 */
} osal_tm_t;

/* Thread */
#define OSAL_THREAD_NAME_LEN         (15)
#define OSAL_THREAD_DFT_NAME         ("Unknown")
#define OSAL_THREAD_HIGHEST_PRIORITY (99)

extern const char *_osal_task_list[];

typedef enum {
    OSAL_TASK_ID_ALL = -1,
    OSAL_TASK_ID_NON_TASK,
    OSAL_TASK_ID_SDK_DIAG = OSAL_TASK_ID_NON_TASK,
    OSAL_TASK_ID_ERROR,
    OSAL_TASK_ID_FIFO_TASK,
    OSAL_TASK_ID_POLLING_TASK,
    OSAL_TASK_ID_TRAVERSE_TASK,
    OSAL_TASK_ID_TCAM_ECC_TASK,
    OSAL_TASK_ID_TX_FREE,
    OSAL_TASK_ID_TX_ISR,
    OSAL_TASK_ID_TX_PERF,
    OSAL_TASK_ID_RX_FREE,
    OSAL_TASK_ID_RX_ISR,
    OSAL_TASK_ID_RECOV,
    OSAL_TASK_ID_IFMON_THREAD,
    OSAL_TASK_ID_INTR_THREAD,
    OSAL_TASK_ID_NB_STAT_THREAD,
    OSAL_TASK_ID_NB_RSFEC_THREAD,
    OSAL_TASK_ID_ISR_TASK,
    OSAL_TASK_ID_PTP_MASTER_THREAD,
    OSAL_TASK_ID_PTP_SLAVE_THREAD,
    OSAL_TASK_ID_PTP_TRANSPARENT_THREAD,
    OSAL_TASK_ID_PKT_ADD_THREAD,
    OSAL_TASK_ID_PKT_DEL_THREAD,
    OSAL_TASK_ID_PORT_ANLT_THREAD,
    OSAL_TASK_ID_ANLT_FSM_MON_THREAD,
    OSAL_TASK_ID_TM_PFCWD,
    OSAL_TASK_ID_PFCWD_TASK,
    OSAL_TASK_ID_HISTO_TASK,
    OSAL_TASK_ID_OTHER,
    OSAL_TASK_ID_LAST
} osal_task_id_t;

typedef struct osal_thread_cb_s {
    struct osal_thread_cb_s *ptr_next_thread;   /* next thread */
    clx_thread_id_t thread_id;                  /* thread id, task struct pointer */
    char thread_name[OSAL_THREAD_NAME_LEN + 1]; /* thread name */
    uint32 priority;                            /* priority, 0~99 */
    uint32 stack_size;                          /* stack size */
    boolean is_stop;                            /* thread status */
    uint32 thread_sn;                           /* thread serial number */
} osal_thread_cb_t;

typedef struct osal_timespec_s {
    uint32 sec;  /* second */
    uint32 nsec; /* Nanoseconds.  */
} osal_timespec_t;

typedef void (*osal_thread_function_t)(void *);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief OS abstration API to initialize osal module.
 *
 */
clx_error_no_t
osal_init(void);

/**
 * @brief Deinitialize the OSAL module.
 *
 */
clx_error_no_t
osal_deinit(void);

/**
 * @brief OS abstration API to allocate memory.
 *
 * @param [in]    size    - Size of memory to be allocate.
 * @return        Point to memory.
 */
void *
osal_alloc(const uint32 size);

/**
 * @brief OS abstration API to free allocated memory.
 *
 * @param [in]    ptr_mem    - Point of the memory to be freed.
 */
void
osal_free(const void *ptr_mem);

/**
 * @brief OS abstration API to init the running thread's attribute.
 *
 */
void
osal_thread_init(void);

/**
 * @brief OS abstration API to create thread.
 *
 * The proper way to invoke osal_thread_create is
 * 1. Caller define a clx_thread_id_t thread_id,
 * 2. Invoke with thread_id's address, i.e. osal_thread_create(&thread_id).
 *
 * @param [in]     ptr_thread_name    - Point to the string for name of thread.
 * @param [in]     stack_size         - Size of stack.
 * @param [in]     priority           - Thread priority (Highest : 99, Lowest : 1).
 * @param [in]     function           - Function point of thread.
 * @param [in]     ptr_arg            - Point to agrument for callback function.
 * @param [out]    ptr_thread_id      - Pointer to thread ID.
 * @return         CLX_E_OK        - Successfully create the thread.
 * @return         CLX_E_OTHERS    - Fail to create the thread.
 */
clx_error_no_t
osal_thread_create(const char *ptr_thread_name,
                   const uint32 stack_size,
                   const uint32 priority,
                   osal_thread_function_t function,
                   void *ptr_arg,
                   clx_thread_id_t *ptr_thread_id);

/**
 * @brief OS abstration API to stop thread.
 *
 * Similar with osal_thread_create, when invoke osal_thread_stop(),
 * the caller should pass the thread_id's address.
 *
 * @param [in]    ptr_thread_id    - Thread ID.
 * @return        CLX_E_OK    - Successfully destroy the thread.
 */
clx_error_no_t
osal_thread_stop(clx_thread_id_t *ptr_thread_id);

/**
 * @brief OS abstration API to destroy thread.
 *
 * Similar with osal_thread_create, when invoke osal_thread_destroy(),
 * the caller should pass the thread_id's address.
 *
 * @param [in]    ptr_thread_id    - Thread ID.
 * @return        CLX_E_OK    - Successfully destroy the thread.
 */
clx_error_no_t
osal_thread_destroy(clx_thread_id_t *ptr_thread_id);

/**
 * @brief OS abstration API to check if the thread is in run state.
 *
 * @return        CLX_E_OTHERS    - The thread is not in run state.
 * @return        CLX_E_OK        - The thread is in run state.
 */
clx_error_no_t
osal_thread_is_run(void);

/**
 * @brief OS abstration API to release the OS resource.
 *
 */
void
osal_thread_exit(void);

/**
 * @brief OS abstration API to suspend the current thread for microseconds.
 *
 * @param [in]    usecond    - Microseconds to suspend.
 * @return        CLX_E_OK        - Successfully suspend the thread.
 * @return        CLX_E_OTHERS    - Fail to suspend.
 */
clx_error_no_t
osal_thread_sleep(const uint64 usecond);

/**
 * @brief OS abstration API to delay the current thread for microseconds.
 *
 * @param [in]    usecond    - Microseconds to delay.
 * @return        CLX_E_OK    - Successfully delay the thread.
 */
clx_error_no_t
osal_delay_us(const uint32 usecond);

/**
 * @brief OS abstration API to create semaphore.
 *
 * The proper way to invoke osal_semaphore_create is
 * 1. Caller define a clx_semaphore_id_t id,
 * 2. Invoke with id's address, i.e. osal_semaphore_create(&id).
 *
 * @param [in]     ptr_sema_name       - Pointer to the string of semaphore name.
 * @param [in]     sema_count          - The init value of semaphore CLX_SEMAPHORE_BINARY: this
 *                                       means the semaphore is as mutex for protecting critical
 *                                       section CLX_SEMAPHORE_SYNC: this means the semaphore is as
 *                                       signal for syncing.
 * @param [out]    ptr_semaphore_id    - Pointer to semaphore ID.
 * @return         CLX_E_OK        - Successfully create the semaphore.
 * @return         CLX_E_OTHERS    - Fail to create the semaphore.
 */
clx_error_no_t
osal_semaphore_create(const char *ptr_sema_name,
                      const uint32 sema_count,
                      clx_semaphore_id_t *ptr_semaphore_id);

/**
 * @brief OS abstration API to destroy semaphore.
 *
 * Similar with osal_semaphore_create, when invoke osal_semaphore_destroy(),
 * the caller should pass the semaphore_id's address.
 *
 * @param [in]    ptr_semaphore_id    - Pointer to semaphore ID.
 * @return        CLX_E_OK        - Successfully destroy the semaphore.
 * @return        CLX_E_OTHERS    - Fail to destroy the semaphore.
 */
clx_error_no_t
osal_semaphore_destroy(clx_semaphore_id_t *ptr_semaphore_id);

/**
 * @brief OS abstration API to take semaphore.
 *
 * @param [in]    ptr_semaphore_id    - Pointer to semaphore ID.
 * @param [in]    time_out            - Time out before waiting semaphore in usec.
 *                                      Wait forever. (0xFFFFFFFF).
 * @return        CLX_E_OK         - Successfully take the semaphore.
 * @return        CLX_E_TIMEOUT    - Timeout.
 * @return        CLX_E_OTHERS     - Other errors.
 */
clx_error_no_t
osal_semaphore_take(clx_semaphore_id_t *ptr_semaphore_id, uint32 time_out);

/**
 * @brief OS abstration API to give semaphore.
 *
 * @param [in]    ptr_semaphore_id    - Pointer to semaphore ID.
 * @return        CLX_E_OK    - Successfully give the semaphore.
 */
clx_error_no_t
osal_semaphore_give(clx_semaphore_id_t *ptr_semaphore_id);

/**
 * @brief OS abstration API to create IsrLock.
 *
 * IsrLock can protect shared resources between interrupt context switch
 * and thread context switch.
 * IsrLock support single-core CPU and multi-core CPU.
 * In user space, IsrLock is the same as binary semaphore.
 * In kernel space, take IsrLock will monopolize CPU until thread or interrupt give IsrLock.
 *
 * @param [in]     ptr_isrlock_name    - Pointer to the string of IsrLock name.
 * @param [out]    ptr_isrlock_id      - Pointer to IsrLock ID.
 * @return         CLX_E_OK        - Successfully create IsrLock.
 * @return         CLX_E_OTHERS    - Fail to create IsrLock.
 */
clx_error_no_t
osal_isr_lock_create(const char *ptr_isrlock_name, clx_isrlock_id_t *ptr_isrlock_id);

/**
 * @brief OS abstration API to destroy IsrLock.
 *
 * @param [in]    ptr_isrlock_id    - Pointer to IsrLock ID.
 * @return        CLX_E_OK        - Successfully destroy the IsrLock.
 * @return        CLX_E_OTHERS    - Fail to destroy the IsrLock.
 */
clx_error_no_t
osal_isr_lock_destroy(clx_isrlock_id_t *ptr_isrlock_id);

/**
 * @brief OS abstration API to take srLock.
 *
 * In user space, taking srLock is the same as taking binary semaphore.
 * In kernel space, taking srLock must disable all CPU interrupt, in some OS, may be need to disable
 * preempt. In multi-core CPU, it must have a flag to indicate that shared resource is used by this
 * interrupt or thread.
 *
 * @param [in]     ptr_isrlock_id    - Pointer to srLock ID.
 * @param [out]    ptr_irq_flags     - CPU interrupt enable/disable status.
 * @return         CLX_E_OK    - Successfully take the srLock.
 */
clx_error_no_t
osal_isr_lock_take(clx_isrlock_id_t *ptr_isrlock_id, clx_irq_flags_t *ptr_irq_flags);

/**
 * @brief OS abstration API to give IsrLock.
 *
 * In user space, giving IsrLock is the same as giving binary semaphore.
 * In kernel space, giving IsrLock must enable CPU interrupt that disabled in osal_isr_lock_take,
 * if osal_isr_lock_take disable preempt, it must enable preempt.
 * In multi-core CPU, it must reset a flag to indicate that shared resource is released now.
 *
 * @param [in]    ptr_isrlock_id    - Pointer to IsrLock ID.
 * @param [in]    ptr_irq_flags     - CPU interrupt enable/disable status.
 * @return        CLX_E_OK    - Successfully give the IsrLock.
 */
clx_error_no_t
osal_isr_lock_give(clx_isrlock_id_t *ptr_isrlock_id, clx_irq_flags_t *ptr_irq_flags);

/**
 * @brief OS abstration API to get current monotonic time(uptime).
 *
 * @param [out]    ptr_timespec    - Time in osal_timespec_t (sec, nsec).
 * @return         CLX_E_OK               - Successfully get time.
 * @return         CLX_E_BAD_PARAMETER    - Ptr_timespec is NULL.
 * @return         CLX_E_OTHERS           - Fail to get time.
 */
clx_error_no_t
osal_monotonic_time_get(osal_timespec_t *ptr_timespec);

/**
 * @brief OS abstration API to get current time since Unix Epoch.
 *
 * @param [out]    ptr_time    - Time in micro-seconds.
 * @return         CLX_E_OK        - Successfully get time.
 * @return         CLX_E_OTHERS    - Fail to get time.
 */
clx_error_no_t
osal_time_get(clx_time_t *ptr_time);

/**
 * @brief OS abstration API to get current time since Unix Epoch.
 *
 * @param [out]    ptr_tm    - Time in osal_tm_t.
 * @return         CLX_E_OK        - Successfully get time.
 * @return         CLX_E_OTHERS    - Fail to get time.
 */
clx_error_no_t
osal_calendar_time_get(osal_tm_t *ptr_tm);

/**
 * @brief OS abstration API to get current thread serial number.
 *
 * @param [out]    thread_sn    - Pointer of thread serial number.
 * @return         CLX_E_OK        - Successfully get thread name.
 * @return         CLX_E_OTHERS    - Fail to get thread name.
 */
clx_error_no_t
osal_thread_sn_get(uint32 *thread_sn);

/**
 * @brief OS abstration API to create mutex lock.
 *
 * The proper way to invoke osal_lock_create is
 * 1. Caller define a clx_lock_id_t id,
 * 2. Invoke with id's address, i.e. osal_lock_create(&id).
 * This function is only allowed in user mode.
 *
 * @param [in]     ptr_lock_name    - Pointer to the string of lock name.
 * @param [in]     lock_mode        - The mode of lock, support: CLX_LOCK_NORMAL CLX_LOCK_RECURSIVE.
 * @param [out]    ptr_lock_id      - Pointer to lock ID.
 * @return         CLX_E_OK        - Successfully create the lock.
 * @return         CLX_E_OTHERS    - Fail to create the lock.
 */
clx_error_no_t
osal_lock_create(const char *ptr_lock_name, clx_lock_t lock_mode, clx_lock_id_t *ptr_lock_id);

/**
 * @brief OS abstration API to destroy mutex lock.
 *
 * Similar with osal_lock_create, when invoke osal_lock_destroy(),
 * the caller should pass the lock_id's address.
 * This function is only allowed in user mode.
 *
 * @param [in]    ptr_lock_id    - Pointer to lock ID.
 * @return        CLX_E_OK        - Successfully destroy the lock.
 * @return        CLX_E_OTHERS    - Fail to destroy the lock.
 */
clx_error_no_t
osal_lock_destroy(clx_lock_id_t *ptr_lock_id);

/**
 * @brief OS abstration API to acquire mutex lock.
 *
 * This function is only allowed in user mode.
 *
 * @param [in]    ptr_lock_id    - Pointer to lock ID.
 * @return        CLX_E_OK        - Successfully acquire the lock.
 * @return        CLX_E_OTHERS    - Failed acquire the lock.
 */
clx_error_no_t
osal_lock_acquire(clx_lock_id_t *ptr_lock_id);

/**
 * @brief OS abstration API to release mutex lock.
 *
 * This function is only allowed in user mode.
 *
 * @param [in]    ptr_lock_id    - Pointer to lock ID.
 * @return        CLX_E_OK        - Successfully release the lock.
 * @return        CLX_E_OTHERS    - Failed release the lock.
 */
clx_error_no_t
osal_lock_release(clx_lock_id_t *ptr_lock_id);

#endif /* OSAL_H */
