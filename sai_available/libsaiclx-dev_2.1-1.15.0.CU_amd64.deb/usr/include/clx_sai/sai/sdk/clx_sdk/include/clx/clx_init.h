/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   clx_init.h
 * PURPOSE:
 *      Custom configuration on CLX SDK.
 * NOTES:
 */
#ifndef CLX_INIT_H
#define CLX_INIT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_module.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_INIT_DBG_SUBMODULE_ALL (0) /* All debug submodule */
#define CLX_INIT_DBG_SUBMODULE_CMN (1) /* The first debug submodule is general a common module */

#define CLX_INIT_DBG_FLAG_ERR  (1U << 0)
#define CLX_INIT_DBG_FLAG_WARN (1U << 1)
#define CLX_INIT_DBG_FLAG_INFO (1U << 2)
#define CLX_INIT_DBG_FLAG_OFF  (1U << 3)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef void (*clx_init_write_func_t)(const void *ptr_buf, uint32 len);

typedef clx_error_no_t (*clx_init_open_nonvolatile_func_t)(void);

typedef clx_error_no_t (*clx_init_close_nonvolatile_func_t)(void);

typedef int32 (*clx_init_write_nonvolatile_func_t)(const void *ptr_buf, uint32 num_bytes);

typedef int32 (*clx_init_read_nonvolatile_func_t)(void *ptr_buf, uint32 num_bytes);

typedef struct clx_init_param_s {
    clx_init_write_func_t dsh_write_func;            /* Write function for diag shell */
    clx_init_write_func_t debug_write_func;          /* Write function for debug message */
    clx_init_open_nonvolatile_func_t open_nv_func;   /* Open non-volatile function file */
    clx_init_close_nonvolatile_func_t close_nv_func; /* Close non-volatile function file */
    clx_init_write_nonvolatile_func_t write_nv_func; /* Write non-volatile function into file */
    clx_init_read_nonvolatile_func_t read_nv_func;   /* Read non-volatile function from file */
} clx_init_param_t;

typedef enum clx_init_mode_e {
    CLX_INIT_MODE_WARM_INIT = 0, /* reload config in init stage */
    CLX_INIT_MODE_WARM_DEINIT,   /* save config in deinit stage */
    CLX_INIT_MODE_LAST
} clx_init_mode_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief This API is used to initialize the common modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    ptr_init_param    - The sdk_demo callback functions.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_cmn_module_init(clx_init_param_t *ptr_init_param);

/**
 * @brief This API is used to deinitialize the common modules.
 *
 * Support_chip: CLX86.
 *
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_cmn_module_deinit(void);

/**
 * @brief This API is used to initialize the low level modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_low_level_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize the low level modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_low_level_deinit(const uint32 unit);

/**
 * @brief This API is used to initialize the task resources of the modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_task_rsrc_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize the task resources of the modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_task_rsrc_deinit(const uint32 unit);

/**
 * @brief This API is used to initialize the modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_module_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize the modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_module_deinit(const uint32 unit);

/**
 * @brief This API is used to initialize the tasks of the modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_task_init(const uint32 unit);

/**
 * @brief This API is used to deinitialize the tasks of the modules.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_task_deinit(const uint32 unit);

/**
 * @brief This API is used to get the unit numbers.
 *
 * Support_chip: CLX86.
 *
 * @param [out]    ptr_num    - The unit numbers.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_unit_num_get(uint32 *ptr_num);

/**
 * @brief This API is used to deinitialize the CLX SDK.
 *
 * Support_chip: CLX86.
 *
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_deinit(void);

/**
 * @brief This API is used to set init Mode.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    mode      - Warm init, or deinit mode.
 * @param [in]    enable    - TRUE, FALSE.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_init_mode_set(const uint32 unit, const clx_init_mode_t mode, const boolean enable);

/**
 * @brief This API is used to get init Mode.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     mode          - Warm init, or deinit mode.
 * @param [out]    ptr_enable    - TRUE, FALSE.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_init_mode_get(const uint32 unit, const clx_init_mode_t mode, boolean *ptr_enable);

/**
 * @brief This API is used to set debug flag on each module. Once module's debug flag has been set,
 *        the corresponding debug messages will be dumpped by debug_write_func.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    task_id      - Task id.
 * @param [in]    module_id    - Selected module item.
 * @param [in]    submodule    - Refence to CLX_INIT_DBG_SUBMODULE_XXX.
 * @param [in]    dbg_flag     - Refence to CLX_INIT_DBG_FLAG_XXX.
 * @return        CLX_E_OK        - Operation success.
 * @return        CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_module_debug_flag_set(const uint32 task_id,
                               const uint32 module_id,
                               const uint32 submodule,
                               const uint32 dbg_flag);

/**
 * @brief This API is used to get debug flag setting from each module.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     task_id         - Task id.
 * @param [in]     module_id       - Selected module item.
 * @param [in]     submodule       - Refence to CLX_INIT_DBG_SUBMODULE_XXX.
 * @param [out]    ptr_dbg_flag    - Refence to CLX_INIT_DBG_FLAG_XXX.
 * @return         CLX_E_OK        - Operation success.
 * @return         CLX_E_OTHERS    - Other errors.
 */
clx_error_no_t
clx_init_module_debug_flag_get(const uint32 task_id,
                               const clx_module_t module_id,
                               const uint32 submodule,
                               uint32 *ptr_dbg_flag);

#endif /* CLX_INIT_H */
