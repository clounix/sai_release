/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  drv.h
 * PURPOSE:
 *  1. Provide whole DRV resource initialization API.
 *  2. Provide configuration access APIs.
 *  3. Provide ISR registration and deregistration APIs.
 *  4. Provide memory access.
 *  5. Provide DMA management APIs.
 *  6. Provide address translation APIs.
 * NOTES:
 */

#ifndef DRV_H
#define DRV_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_cfg.h>
#include <drv/drv_dma.h>
#include <drv/drv_io.h>
#include <util/util_log.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define DRV_RUN_CHIP_MODE        (0x0)
#define DRV_RUN_FPGA_MODE        (0x1)
#define DRV_RUN_PXP_MODE         (0x2)
#define DRV_RUN_PCIE_BYPASS_MODE (0x3)

#define DRV_DEV_ID_MASK          (0xFFFFFF)
#define DRV_DEV_MODE_MASK        (0xF)
#define DRV_DEV_MODE_OFFSET      (28)
#define DRV_DEV_ID_GET(__id__)   (__id__ & DRV_DEV_ID_MASK)
#define DRV_DEV_MODE_GET(__id__) ((__id__ >> DRV_DEV_MODE_OFFSET) & DRV_DEV_MODE_MASK)

#define DRV_DEV_CLX_VENDOR_ID (0x1F83)
#define DRV_DEV_ID_CL8600     (0x8600)   /* chip family */
#define DRV_DEV_ID_CL860080   (0x860101) /* 8.0T, 4 slices */
#define DRV_DEV_ID_CL860128   (0x860100) /* 12.8T, 4 slices */
#define DRV_DEV_ID_CL860128P  (0x860300) /* 12.8T, 8 slices */
#define DRV_DEV_ID_CL860160   (0x860001) /* 16T, 7 slices*/
#define DRV_DEV_ID_CL860160E  (0x860002) /* 16T, 8 slices*/
#define DRV_DEV_ID_CL860080P  (0x860301) /* 8.0T, 4 slices */
#ifdef CLX_MOCK
#define DRV_DEV_ID_CL8652 (0x8653)       /* 12.8T, 4 slices*/
#else
#define DRV_DEV_ID_CL8652 (0x8652)       /* 12.8T, 4 slices*/
#endif

#ifdef NB_EMU_DEV
#define DRV_DEV_ID_CL860256 (0x860000) /* 25.6T, 8 slices*/
#elif defined CLX_MOCK
#define DRV_DEV_ID_CL860256 (0x8681)   /* 25.6T, 8 slices*/
#else
#define DRV_DEV_ID_CL860256 (0x860000) /* 25.6T, 8 slices*/
#endif

#define DRV_DEV_ID_CL8400   (0x8400)
#define DRV_DEV_ID_CL840020 (0x840000) /* 1 slices */

#define DRV_DEV_REVISION_ID_E1 (0x01)
#define DRV_DEV_REVISION_ID_E2 (0x02)
#define DRV_DEV_INVALID_ID     (0xFFFFFFFF)

#define DRV_DEV_PN_CLX860256  "CLX860256"
#define DRV_DEV_PN_CLX860128  "CLX860128"
#define DRV_DEV_PN_CLX860128P "CLX860128P"
#define DRV_DEV_PN_CLX860080  "CLX860080"
#define DRV_DEV_PN_CLX860160  "CLX860160"
#define DRV_DEV_PN_CLX860160E "CLX860160E"
#define DRV_DEV_PN_CLX860080P "CLX860080P"

/* DATA TYPE DECLARATIONS
 */
typedef enum drv_hw_if_e {
    DRV_DEV_TYPE_PCI,
    DRV_DEV_TYPE_I2C,
    DRV_DEV_TYPE_SPI,
    DRV_DEV_TYPE_LAST

} drv_hw_if_t;

typedef clx_error_no_t (*drv_dev_read_func_t)(const uint32 unit,
                                              const uint32 addr_offset,
                                              uint32 *ptr_data,
                                              const uint32 len);

typedef clx_error_no_t (*drv_dev_write_func_t)(const uint32 unit,
                                               const uint32 addr_offset,
                                               const uint32 *ptr_data,
                                               const uint32 len);

typedef clx_error_no_t (*drv_dev_isr_func_t)(void *ptr_data);

typedef struct drv_dev_msi_data_s {
    uint32 unit;
    uint32 msi;
    uint32 valid;
} drv_dev_msi_data_t;

/* To read or write the HW-intf registers. */
typedef struct drv_dev_access_s {
    drv_dev_read_func_t read_callback;
    drv_dev_write_func_t write_callback;

} drv_dev_access_t;

typedef struct drv_dev_id_s {
    uint32 vendor;
    uint32 device;
    uint32 revision;
    uint32 uid[3];
    uint32 config_model;
    uint32 package_type;
    uint32 slice_info;
} drv_dev_id_t;

typedef struct drv_dev_s {
    drv_hw_if_t if_type;
    drv_dev_id_t id;
    drv_dev_access_t access;
} drv_dev_t;

typedef struct drv_ctb_s {
    drv_dev_t dev[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
    uint32 dev_num;
    drv_dma_t *dma_drv[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
    drv_io_t *io_drv[CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM];
} drv_ctb_t;

typedef enum drv_dev_family_e { DRV_DEV_FAMILY_NB, DRV_DEV_FAMILY_LAST } drv_dev_family_t;

/* MACRO FUNCTION DECLARATIONS
 */
#define DRV_DEV_IS_NB_FAMILY(unit)                           \
    ((drv_cb.dev[unit].id.device == DRV_DEV_ID_CL8652) ||    \
     (drv_cb.dev[unit].id.device == DRV_DEV_ID_CL860256) ||  \
     (drv_cb.dev[unit].id.device == DRV_DEV_ID_CL860128P) || \
     (drv_cb.dev[unit].id.device == DRV_DEV_ID_CL860080) ||  \
     (drv_cb.dev[unit].id.device == DRV_DEV_ID_CL860080P) || \
     (drv_cb.dev[unit].id.device == DRV_DEV_ID_CL860160) ||  \
     (drv_cb.dev[unit].id.device == DRV_DEV_ID_CL860160E) || \
     (drv_cb.dev[unit].id.device == DRV_DEV_ID_CL860128))

#define DRV_DEV_FAMILY_GET(unit) (DRV_DEV_IS_NB_FAMILY(unit) ? DRV_DEV_FAMILY_NB : 0)

#define DRV_PTR_CHK(__ptr__)                                                                 \
    do {                                                                                     \
        if (NULL == (__ptr__)) {                                                             \
            UTIL_LOG_PRINT(UTIL_LOG_DRV, UTIL_LOG_ERR, #__ptr__ " is null pointer, rc=%d\n", \
                           CLX_E_BAD_PARAMETER);                                             \
            return CLX_E_BAD_PARAMETER;                                                      \
        }                                                                                    \
    } while (0)

#define DRV_UNIT_CHK(__unit__)                                                                   \
    do {                                                                                         \
        if (CLX_CFG_MAXIMUM_CHIPS_PER_SYSTEM <= (__unit__)) {                                    \
            UTIL_LOG_PRINT(UTIL_LOG_DRV, UTIL_LOG_ERR, "unit(%u) is invalid, rc=%d\n", __unit__, \
                           CLX_E_BAD_PARAMETER);                                                 \
            return CLX_E_BAD_PARAMETER;                                                          \
        }                                                                                        \
    } while (0)

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief To get current SDK running mode.
 *
 * @param [in]     unit        - The device unit.
 * @param [out]    ptr_mode    - Current running mode.
 * @return         CLX_E_OK    - Successfully get the running mode.
 */
clx_error_no_t
drv_run_mode_get(const uint32 unit, uint32 *ptr_mode);

/**
 * @brief To initialize the DMA memory and interface-related kernel source such as PCIe/I2C/SPI.
 *
 * @return        CLX_E_OK        - Successfully initialize DRV module.
 * @return        CLX_E_OTHERS    - Failed to initialize DRV module.
 */
clx_error_no_t
drv_deinit(void);

/**
 * @brief To initialize the DMA memory and interface-related kernel source such as PCIe/I2C/SPI.
 *
 * @return        CLX_E_OK        - Successfully initialize DRV module.
 * @return        CLX_E_OTHERS    - Failed to initialize DRV module.
 */
clx_error_no_t
drv_init(void);

/**
 * @brief To get the number of chips connected to host CPU.
 *
 * @param [out]    ptr_num    - Pointer for the chip number.
 * @return         CLX_E_OK    - Successfully get the number of chips.
 */
clx_error_no_t
drv_number_of_chip_get(uint32 *ptr_num);

/**
 * @brief To enable the system intterupt and specify the ISR handler.
 *
 * @param [in]    unit          - The device unit.
 * @param [in]    handler       - The ISR hanlder.
 * @param [in]    ptr_cookie    - Pointer for the data as an argument of the handler.
 * @return        CLX_E_OK        - Successfully connect the ISR handler to the system.
 * @return        CLX_E_OTHERS    - Failed to connect the ISR handler to the system.
 */
clx_error_no_t
drv_isr_connect(const uint32 unit, drv_dev_isr_func_t handler, void *ptr_cookie);

/**
 * @brief To disable the system intterupt notification.
 *
 * @param [in]    unit    - The device unit.
 * @return        CLX_E_OK        - Successfully disconnect the ISR handler to the system.
 * @return        CLX_E_OTHERS    - Failed to disconnect the ISR handler to the system.
 */
clx_error_no_t
drv_isr_disconnect(const uint32 unit);

/**
 * @brief To get the vendor/device/revision ID of the specified chip unit.
 *
 * @param [in]     unit             - The device unit.
 * @param [out]    ptr_device_id    - Pointer for the device ID.
 * @return         CLX_E_OK        - Successfully get the IDs.
 * @return         CLX_E_OTHERS    - Failed to get the IDs.
 */
clx_error_no_t
drv_dev_id_get(const uint32 unit, drv_dev_id_t *ptr_device_id);

/**
 * @brief To read data from the register of the specified chip unit.
 *
 * @param [in]     unit           - The device unit.
 * @param [in]     addr_offset    - The address of register.
 * @param [in]     len            - Data size read.
 * @param [out]    ptr_data       - Pointer for the register data.
 * @return         CLX_E_OK        - Successfully read the data.
 * @return         CLX_E_OTHERS    - Failed to read the data.
 */
clx_error_no_t
drv_reg_read(const uint32 unit, const uint32 addr_offset, uint32 *ptr_data, const uint32 len);

/**
 * @brief To write data to the register of the specified chip unit.
 *
 * @param [in]    unit           - The device unit.
 * @param [in]    addr_offset    - The address of register.
 * @param [in]    ptr_data       - Pointer for the written data.
 * @param [in]    len            - Data size read.
 * @return        CLX_E_OK        - Successfully write the data.
 * @return        CLX_E_OTHERS    - Failed to write the data.
 */
clx_error_no_t
drv_reg_write(const uint32 unit, const uint32 addr_offset, const uint32 *ptr_data, const uint32 len);

/**
 * @brief To get the physical address of the corresponding virtual address input.
 *
 * @param [in]     ptr_virt_addr    - Pointer to the virtual address.
 * @param [out]    ptr_phy_addr     - Pointer to the physical address.
 * @return         CLX_E_OK        - Successfully convert the address.
 * @return         CLX_E_OTHERS    - Failed to convert the address. The memory might be not
 *                                   allocated by DRV.
 */
clx_error_no_t
drv_virt_to_phy_convert(void *ptr_virt_addr, clx_addr_t *ptr_phy_addr);

/**
 * @brief To get the virtual address of the corresponding physical address input.
 *
 * @param [in]     phy_addr          - Pointer for the physical address.
 * @param [out]    pptr_virt_addr    - Pointer for the virtual address pointer.
 * @return         CLX_E_OK        - Successfully convert the address.
 * @return         CLX_E_OTHERS    - Failed to convert the address. The memory might be not
 *                                   allocated by DRV.
 */
clx_error_no_t
drv_phy_to_virt_convert(const clx_addr_t phy_addr, void **pptr_virt_addr);

/**
 * @brief To update the data from CPU cache to the physical memory.
 *
 * @param [in]    ptr_virt_addr    - Pointer for the data.
 * @param [in]    size             - Target data size to be updated.
 * @return        CLX_E_OK        - Successfully update the data from CPU cache to the physical
 *                                  memory.
 * @return        CLX_E_OTHERS    - Failed to pdate the data from CPU cache to the physical memory.
 */
clx_error_no_t
drv_cache_flush(void *ptr_virt_addr, const uint32 size);

/**
 * @brief To update the data from physical memory to the CPU cache.
 *
 * @param [in]    ptr_virt_addr    - Pointer for the data.
 * @param [in]    size             - Target data size to be updated.
 * @return        CLX_E_OK        - Successfully update the data from physical memory to the CPU
 *                                  cache.
 * @return        CLX_E_OTHERS    - Failed to pdate the data from physical memory to the CPU cache.
 */
clx_error_no_t
drv_cache_invalidate(void *ptr_virt_addr, const uint32 size);

/**
 * @brief To restore the previously saved pci configuration space data.
 *
 * @param [in]    unit    - The device unit.
 * @return        CLX_E_OK        - Successfully restore the pci configuration space data.
 * @return        CLX_E_OTHERS    - Failed to restore the pci configuration space data.
 */
clx_error_no_t
drv_pci_cfg_restore(const uint32 unit);

// typedef enum { DRV_IO, DRV_DMA, DRV_LAST } DRV_LOG_TYPE_E;

void
drv_log_msg(util_log_drv_t drv, const char *format, ...);
void
drv_show_error_logs(util_log_drv_t drv);
void
drv_clear_error_logs(util_log_drv_t drv);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
extern drv_ctb_t drv_cb;

#endif /* #ifndef DRV_H */
