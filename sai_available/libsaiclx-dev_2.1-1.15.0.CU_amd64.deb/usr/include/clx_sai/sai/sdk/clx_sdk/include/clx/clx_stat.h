/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  clx_stat.h
 * PURPOSE:
 *      Define the declartion for Statistics module in CLX SDK.
 * NOTES:
 *
 */

#ifndef CLX_STAT_H
#define CLX_STAT_H

#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_init.h>
#include <clx/clx_l3.h>
#include <clx/clx_tm.h>
#include <clx/clx_pkt.h>

#define CLX_STAT_CFG_TX_DROP_FILTER         (1U << 0)
#define CLX_STAT_CFG_TM_DROP_FILTER         (1U << 1)
#define CLX_STAT_INVALID_CNT_ID             (0xFFFFFFFF)
#define CLX_STAT_SRV_CNT_ENTRY_NUM          (6)
#define CLX_STAT_SRV_CNT_FLAGS_FORWARD      (1U << 0) /* Count Forward */
#define CLX_STAT_SRV_CNT_FLAGS_DROP         (1U << 1) /* Count Drop */
#define CLX_STAT_SRV_CNT_FLAGS_BYTE         (1U << 2) /* Count Byte */
#define CLX_STAT_SRV_CNT_FLAGS_COLOR_RED    (1U << 3) /* Count Red */
#define CLX_STAT_SRV_CNT_FLAGS_COLOR_YELLOW (1U << 4) /* Count Yellow */
#define CLX_STAT_SRV_CNT_FLAGS_COLOR_GREEN  (1U << 5) /* Count Green */
#define CLX_STAT_SRV_CNT_FLAGS_COLOR_ALL              /* Count All colors */    \
    (CLX_STAT_SRV_CNT_FLAGS_COLOR_GREEN | CLX_STAT_SRV_CNT_FLAGS_COLOR_YELLOW | \
     CLX_STAT_SRV_CNT_FLAGS_COLOR_RED)

#define CLX_STAT_EN_HPC_CNT /* Macro definition for High Precision Collection */
#ifdef CLX_STAT_EN_HPC_CNT
#define CLX_STAT_HPC_TOTAL_PORT (256)
#endif /* End of CLX_STAT_EN_HPC_CNT */

typedef enum clx_pkt_hw_rsn_e {
    CLX_PKT_HW_RSN_ECC_ERR = 1,
    CLX_PKT_HW_RSN_ERR_FRM,
    CLX_PKT_HW_RSN_CRC_ERR,
    CLX_PKT_HW_RSN_MAX_LEN_VLT,
    CLX_PKT_HW_RSN_JABBER_FRM,
    CLX_PKT_HW_RSN_LEN_ERR,
    CLX_PKT_HW_RSN_CONST_SOP,
    CLX_PKT_HW_RSN_OVER_MTU,
    CLX_PKT_HW_RSN_EOP_TIME_OUT,
    CLX_PKT_HW_RSN_BUF_OVF,
    CLX_PKT_HW_RSN_FRG_DROP,
    CLX_PKT_HW_RSN_TRUN_ERR,
    CLX_PKT_HW_RSN_RECVD_ERR,
    CLX_PKT_HW_RSN_MGO = 16,
    CLX_PKT_HW_RSN_MSGO,
    CLX_PKT_HW_RSN_UNDERLAY_L3MC_SPT_RDY_SET_1,
    CLX_PKT_HW_RSN_TUNNEL_MAC_SA,
    CLX_PKT_HW_RSN_MTU2,
    CLX_PKT_HW_RSN_MTU3,
    CLX_PKT_HW_RSN_TNL_TTL0,
    CLX_PKT_HW_RSN_TNL_TTL1,
    CLX_PKT_HW_RSN_TNL_BAD_IP_0,
    CLX_PKT_HW_RSN_TNL_BAD_IP_1,
    CLX_PKT_HW_RSN_TNL_NVO3_UKN_PLD,
    CLX_PKT_HW_RSN_BDO_SPT,
    CLX_PKT_HW_RSN_MPLS_RMAC_MISS,
    CLX_PKT_HW_RSN_MPLS_DIS,
    CLX_PKT_HW_RSN_IP_ETH_DIS,
    CLX_PKT_HW_RSN_IP_IP_DIS,
    CLX_PKT_HW_RSN_GRE_ETH_DIS = 32,
    CLX_PKT_HW_RSN_GRE_IP_DIS,
    CLX_PKT_HW_RSN_GRE_ERSPAN_DIS,
    CLX_PKT_HW_RSN_VXLAN_ETH_DIS,
    CLX_PKT_HW_RSN_GPE_ETH_DIS,
    CLX_PKT_HW_RSN_GPE_IP_DIS,
    CLX_PKT_HW_RSN_GENEVE_ETH_DIS,
    CLX_PKT_HW_RSN_GENEVE_IP_DIS,
    CLX_PKT_HW_RSN_FLEX_ETH_DIS,
    CLX_PKT_HW_RSN_FLEX_IP_DIS,
    CLX_PKT_HW_RSN_GIPO_MISS_0,
    CLX_PKT_HW_RSN_GIPO_MISS_1,
    CLX_PKT_HW_RSN_MPLS_LSP_MISS,
    CLX_PKT_HW_RSN_TEP_BIND,
    CLX_PKT_HW_RSN_TEP_RPF_0,
    CLX_PKT_HW_RSN_TEP_RPF_1,
    CLX_PKT_HW_RSN_ERSPAN_MISS = 48,
    CLX_PKT_HW_RSN_GRE_VER,
    CLX_PKT_HW_RSN_GRE_FLG0,
    CLX_PKT_HW_RSN_GRE_FLG1,
    CLX_PKT_HW_RSN_GRE_FLG2,
    CLX_PKT_HW_RSN_GRE_FLG3,
    CLX_PKT_HW_RSN_BAS_ZR,
    CLX_PKT_HW_RSN_BAS_FLG0,
    CLX_PKT_HW_RSN_BAS_FLG1,
    CLX_PKT_HW_RSN_GPE_ZR,
    CLX_PKT_HW_RSN_GPE_FLG0,
    CLX_PKT_HW_RSN_GPE_FLG1,
    CLX_PKT_HW_RSN_GENEVE_VER,
    CLX_PKT_HW_RSN_GENEVE_O,
    CLX_PKT_HW_RSN_GENEVE_C,
    CLX_PKT_HW_RSN_FLEX_EXCPT_0,
    CLX_PKT_HW_RSN_FLEX_EXCPT_1 = 64,
    CLX_PKT_HW_RSN_FLEX_EXCPT_2,
    CLX_PKT_HW_RSN_FLEX_EXCPT_3,
    CLX_PKT_HW_RSN_FLEX_EXCPT_4,
    CLX_PKT_HW_RSN_FLEX_EXCPT_5,
    CLX_PKT_HW_RSN_FLEX_EXCPT_6,
    CLX_PKT_HW_RSN_MPLS_LSP_LBL_GT4,
    CLX_PKT_HW_RSN_MPLS_LSP_RSVD,
    CLX_PKT_HW_RSN_MPLS_LSP_RSVD1,
    CLX_PKT_HW_RSN_MPLS_ELI_BOS,
    CLX_PKT_HW_RSN_MPLS_2ND_ELI,
    CLX_PKT_HW_RSN_MPLS_NULL_TOP,
    CLX_PKT_HW_RSN_MPLS_EXPOSE_TTL0,
    CLX_PKT_HW_RSN_MPLS_EXPOSE_TTL1,
    CLX_PKT_HW_RSN_MPLS_NULL_IP,
    CLX_PKT_HW_RSN_MPLS_EL_IP,
    CLX_PKT_HW_RSN_MPLS_LSP_IP = 80,
    CLX_PKT_HW_RSN_UNDERLAY_L3MC_PIM_REGISTER,
    CLX_PKT_HW_RSN_PSR_PKT_INC_EXCPT_0,
    CLX_PKT_HW_RSN_SRV6_SL_BIG,
    CLX_PKT_HW_RSN_HSH_SRV6_FUNC_MISS,
    CLX_PKT_HW_RSN_SRV6_SRC_TEP_MISS,
    CLX_PKT_HW_RSN_SRV6_DIS,
    CLX_PKT_HW_RSN_SRV6_TTL1,
    CLX_PKT_HW_RSN_SRV6_ERR_HDR,
    CLX_PKT_HW_RSN_SRV6_FUNC_REDIR,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_23,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_24,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_25,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_26,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_27,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_28,
    CLX_PKT_HW_RSN_SRV6_SL0_SI0_COC1 = 96,
    CLX_PKT_HW_RSN_SRV6_USP_SL0,
    CLX_PKT_HW_RSN_SRV6_SL0,
    CLX_PKT_HW_RSN_SRV6_DECAP_SL_NON_ZERO,
    CLX_PKT_HW_RSN_SRV6_WRONG_FLAVOR,
    CLX_PKT_HW_RSN_SRV6_NXTUSID0,
    CLX_PKT_HW_RSN_SRV6_NXTCSID0,
    CLX_PKT_HW_RSN_SRV6_DECAP_USID_NON_ZERO,
    CLX_PKT_HW_RSN_SRV6_DECAP_INNER_UNK,
    CLX_PKT_HW_RSN_SRV6_USP_SL0_TWO_SRH,
    CLX_PKT_HW_RSN_SRV6_USP_NO_SRH,
    CLX_PKT_HW_RSN_SRV6_RCV_SRC_RED,
    CLX_PKT_HW_RSN_SRV6_B6_INSERT_LAST_HOP,
    CLX_PKT_HW_RSN_SRV6_RSVD_END_BEH_CODE,
    CLX_PKT_HW_RSN_PSR_PKT_INC_EXCPT_1,
    CLX_PKT_HW_RSN_TNL_AUTO_IP,
    CLX_PKT_HW_RSN_TNL_ISATAP_IP = 112,
    CLX_PKT_HW_RSN_PRIO_TAG,
    CLX_PKT_HW_RSN_1QMODE_W_STAG_PKT,
    CLX_PKT_HW_RSN_PSR_PKT_BAD_IP,
    CLX_PKT_HW_RSN_LCL_DROP_PKT_UNTAGGED,
    CLX_PKT_HW_RSN_LCL_DROP_PKT_TAGGED,
    CLX_PKT_HW_RSN_LCL_DROP_PKT_TAGGED_EXCPT_DEFAULT,
    CLX_PKT_HW_RSN_MPLS_DECAP_BOS,
    CLX_PKT_HW_RSN_MPLS_PW_CW,
    CLX_PKT_HW_RSN_MPLS_PW_ACH,
    CLX_PKT_HW_RSN_MPLS_PW_UNK,
    CLX_PKT_HW_RSN_MPLS_L3VPN_IP,
    CLX_PKT_HW_RSN_BDI_HSH_MISS,
    CLX_PKT_HW_RSN_IGMP_SNOOPING,
    CLX_PKT_HW_RSN_MLD_SNOOPING,
    CLX_PKT_HW_RSN_TNL_ECN_1,
    CLX_PKT_HW_RSN_TNL_ECN_2 = 128,
    CLX_PKT_HW_RSN_TNL_ECN_3,
    CLX_PKT_HW_RSN_BDI_SPT_EXCPT_0,
    CLX_PKT_HW_RSN_DOS_CHK,
    CLX_PKT_HW_RSN_IPV4_MAC_DA_MC_MAPPING_MISMATCH,
    CLX_PKT_HW_RSN_IPV6_MAC_DA_MC_MAPPING_MISMATCH,
    CLX_PKT_HW_RSN_IP_MC_LCL,
    CLX_PKT_HW_RSN_L3VPN_BUT_NO_L3_SERVICE,
    CLX_PKT_HW_RSN_L3PORT_GET_IP_UC_PKT_BUT_RMAC_FAIL,
    CLX_PKT_HW_RSN_L3PORT_GET_IP_UC_PKT_BUT_IP_UC_NOT_EN,
    CLX_PKT_HW_RSN_L3PORT_GET_IP_MC_PKT_BUT_IP_MC_NOT_EN,
    CLX_PKT_HW_RSN_L3PORT_GET_NON_IP_PKT,
    CLX_PKT_HW_RSN_UNEXPECTED_LKUP_TYPE,
    CLX_PKT_HW_RSN_SRV6_L2_FWD_IS_L3_IF,
    CLX_PKT_HW_RSN_L2MTU_EXCPT_0,
    CLX_PKT_HW_RSN_L3MTU_EXCPT_0,
    CLX_PKT_HW_RSN_IPV4_SRC_GUARD = 144,
    CLX_PKT_HW_RSN_IPV6_SRC_GUARD,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_29,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_30,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_31,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_32,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_33,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_34,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_35,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_36,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_37,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_38,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_39,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_40,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_41,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_42,
    CLX_PKT_HW_RSN_C2C_TCAM_START = 160,
    CLX_PKT_HW_RSN_C2C_TCAM_0 = CLX_PKT_HW_RSN_C2C_TCAM_START,
    CLX_PKT_HW_RSN_C2C_TCAM_1,
    CLX_PKT_HW_RSN_C2C_TCAM_2,
    CLX_PKT_HW_RSN_C2C_TCAM_3,
    CLX_PKT_HW_RSN_C2C_TCAM_4,
    CLX_PKT_HW_RSN_C2C_TCAM_5,
    CLX_PKT_HW_RSN_C2C_TCAM_6,
    CLX_PKT_HW_RSN_C2C_TCAM_7,
    CLX_PKT_HW_RSN_C2C_TCAM_8,
    CLX_PKT_HW_RSN_C2C_TCAM_9,
    CLX_PKT_HW_RSN_C2C_TCAM_10,
    CLX_PKT_HW_RSN_C2C_TCAM_11,
    CLX_PKT_HW_RSN_C2C_TCAM_12,
    CLX_PKT_HW_RSN_C2C_TCAM_13,
    CLX_PKT_HW_RSN_C2C_TCAM_14,
    CLX_PKT_HW_RSN_C2C_TCAM_15,
    CLX_PKT_HW_RSN_C2C_TCAM_16 = 176,
    CLX_PKT_HW_RSN_C2C_TCAM_17,
    CLX_PKT_HW_RSN_C2C_TCAM_18,
    CLX_PKT_HW_RSN_C2C_TCAM_19,
    CLX_PKT_HW_RSN_C2C_TCAM_20,
    CLX_PKT_HW_RSN_C2C_TCAM_21,
    CLX_PKT_HW_RSN_C2C_TCAM_22,
    CLX_PKT_HW_RSN_C2C_TCAM_23,
    CLX_PKT_HW_RSN_C2C_TCAM_24,
    CLX_PKT_HW_RSN_C2C_TCAM_25,
    CLX_PKT_HW_RSN_C2C_TCAM_26,
    CLX_PKT_HW_RSN_C2C_TCAM_27,
    CLX_PKT_HW_RSN_C2C_TCAM_28,
    CLX_PKT_HW_RSN_C2C_TCAM_29,
    CLX_PKT_HW_RSN_C2C_TCAM_30,
    CLX_PKT_HW_RSN_C2C_TCAM_31,
    CLX_PKT_HW_RSN_C2C_TCAM_32 = 192,
    CLX_PKT_HW_RSN_C2C_TCAM_33,
    CLX_PKT_HW_RSN_C2C_TCAM_34,
    CLX_PKT_HW_RSN_C2C_TCAM_35,
    CLX_PKT_HW_RSN_C2C_TCAM_36,
    CLX_PKT_HW_RSN_C2C_TCAM_37,
    CLX_PKT_HW_RSN_C2C_TCAM_38,
    CLX_PKT_HW_RSN_C2C_TCAM_39,
    CLX_PKT_HW_RSN_C2C_TCAM_40,
    CLX_PKT_HW_RSN_C2C_TCAM_41,
    CLX_PKT_HW_RSN_C2C_TCAM_42,
    CLX_PKT_HW_RSN_C2C_TCAM_43,
    CLX_PKT_HW_RSN_C2C_TCAM_44,
    CLX_PKT_HW_RSN_C2C_TCAM_45,
    CLX_PKT_HW_RSN_C2C_TCAM_46,
    CLX_PKT_HW_RSN_C2C_TCAM_47,
    CLX_PKT_HW_RSN_C2C_TCAM_48 = 208,
    CLX_PKT_HW_RSN_C2C_TCAM_49,
    CLX_PKT_HW_RSN_C2C_TCAM_50,
    CLX_PKT_HW_RSN_C2C_TCAM_51,
    CLX_PKT_HW_RSN_C2C_TCAM_52,
    CLX_PKT_HW_RSN_C2C_TCAM_53,
    CLX_PKT_HW_RSN_C2C_TCAM_54,
    CLX_PKT_HW_RSN_C2C_TCAM_55,
    CLX_PKT_HW_RSN_C2C_TCAM_56,
    CLX_PKT_HW_RSN_C2C_TCAM_57,
    CLX_PKT_HW_RSN_C2C_TCAM_58,
    CLX_PKT_HW_RSN_C2C_TCAM_59,
    CLX_PKT_HW_RSN_C2C_TCAM_60,
    CLX_PKT_HW_RSN_C2C_TCAM_61,
    CLX_PKT_HW_RSN_C2C_TCAM_62,
    CLX_PKT_HW_RSN_C2C_TCAM_63,
    CLX_PKT_HW_RSN_C2C_TCAM_64 = 224,
    CLX_PKT_HW_RSN_C2C_TCAM_65,
    CLX_PKT_HW_RSN_C2C_TCAM_66,
    CLX_PKT_HW_RSN_C2C_TCAM_67,
    CLX_PKT_HW_RSN_C2C_TCAM_68,
    CLX_PKT_HW_RSN_C2C_TCAM_69,
    CLX_PKT_HW_RSN_C2C_TCAM_70,
    CLX_PKT_HW_RSN_C2C_TCAM_71,
    CLX_PKT_HW_RSN_C2C_TCAM_72,
    CLX_PKT_HW_RSN_C2C_TCAM_73,
    CLX_PKT_HW_RSN_C2C_TCAM_74,
    CLX_PKT_HW_RSN_C2C_TCAM_75,
    CLX_PKT_HW_RSN_C2C_TCAM_76,
    CLX_PKT_HW_RSN_C2C_TCAM_77,
    CLX_PKT_HW_RSN_C2C_TCAM_78,
    CLX_PKT_HW_RSN_C2C_TCAM_79,
    CLX_PKT_HW_RSN_C2C_TCAM_80 = 240,
    CLX_PKT_HW_RSN_C2C_TCAM_81,
    CLX_PKT_HW_RSN_C2C_TCAM_82,
    CLX_PKT_HW_RSN_C2C_TCAM_83,
    CLX_PKT_HW_RSN_C2C_TCAM_84,
    CLX_PKT_HW_RSN_C2C_TCAM_85,
    CLX_PKT_HW_RSN_C2C_TCAM_86,
    CLX_PKT_HW_RSN_C2C_TCAM_87,
    CLX_PKT_HW_RSN_C2C_TCAM_88,
    CLX_PKT_HW_RSN_C2C_TCAM_89,
    CLX_PKT_HW_RSN_C2C_TCAM_90,
    CLX_PKT_HW_RSN_C2C_TCAM_91,
    CLX_PKT_HW_RSN_C2C_TCAM_92,
    CLX_PKT_HW_RSN_C2C_TCAM_93,
    CLX_PKT_HW_RSN_C2C_TCAM_94,
    CLX_PKT_HW_RSN_C2C_TCAM_95,
    CLX_PKT_HW_RSN_C2C_TCAM_96 = 256,
    CLX_PKT_HW_RSN_C2C_TCAM_97,
    CLX_PKT_HW_RSN_C2C_TCAM_98,
    CLX_PKT_HW_RSN_C2C_TCAM_99,
    CLX_PKT_HW_RSN_C2C_TCAM_100,
    CLX_PKT_HW_RSN_C2C_TCAM_101,
    CLX_PKT_HW_RSN_C2C_TCAM_102,
    CLX_PKT_HW_RSN_C2C_TCAM_103,
    CLX_PKT_HW_RSN_C2C_TCAM_104,
    CLX_PKT_HW_RSN_C2C_TCAM_105,
    CLX_PKT_HW_RSN_C2C_TCAM_106,
    CLX_PKT_HW_RSN_C2C_TCAM_107,
    CLX_PKT_HW_RSN_C2C_TCAM_108,
    CLX_PKT_HW_RSN_C2C_TCAM_109,
    CLX_PKT_HW_RSN_C2C_TCAM_110,
    CLX_PKT_HW_RSN_C2C_TCAM_111,
    CLX_PKT_HW_RSN_C2C_TCAM_112 = 272,
    CLX_PKT_HW_RSN_C2C_TCAM_113,
    CLX_PKT_HW_RSN_C2C_TCAM_114,
    CLX_PKT_HW_RSN_C2C_TCAM_115,
    CLX_PKT_HW_RSN_C2C_TCAM_116,
    CLX_PKT_HW_RSN_C2C_TCAM_117,
    CLX_PKT_HW_RSN_C2C_TCAM_118,
    CLX_PKT_HW_RSN_C2C_TCAM_119,
    CLX_PKT_HW_RSN_C2C_TCAM_120,
    CLX_PKT_HW_RSN_C2C_TCAM_121,
    CLX_PKT_HW_RSN_C2C_TCAM_122,
    CLX_PKT_HW_RSN_C2C_TCAM_123,
    CLX_PKT_HW_RSN_C2C_TCAM_124,
    CLX_PKT_HW_RSN_C2C_TCAM_125,
    CLX_PKT_HW_RSN_C2C_TCAM_126,
    CLX_PKT_HW_RSN_C2C_TCAM_127,
    CLX_PKT_HW_RSN_L3MC_SPT_RDY_SET_1 = 288,
    CLX_PKT_HW_RSN_L3MC_PIM_REGISTER,
    CLX_PKT_HW_RSN_L3MC_C2C,
    CLX_PKT_HW_RSN_GLEAN_ADJ,
    CLX_PKT_HW_RSN_L2UC_DA_MISS,
    CLX_PKT_HW_RSN_L2MC_DA_MISS,
    CLX_PKT_HW_RSN_L3UC_IPV4_DIP_MISS,
    CLX_PKT_HW_RSN_L3UC_IPV4_RPF_FAIL_DROP,
    CLX_PKT_HW_RSN_L3UC_IPV4_RPF_FAIL_REDIR,
    CLX_PKT_HW_RSN_L3UC_IPV4_ICMP_REDIR,
    CLX_PKT_HW_RSN_L3MC_IPV4_DIP_MISS,
    CLX_PKT_HW_RSN_L3MC_IPV4_RPF_FAIL_DROP,
    CLX_PKT_HW_RSN_L3MC_IPV4_RPF_FAIL_REDIR,
    CLX_PKT_HW_RSN_L3MC_IPV4_RPF_FAIL_CANT_FALL_BACK_L2,
    CLX_PKT_HW_RSN_L3UC_IPV6_DIP_MISS,
    CLX_PKT_HW_RSN_L3UC_IPV6_RPF_FAIL_DROP,
    CLX_PKT_HW_RSN_L3UC_IPV6_RPF_FAIL_REDIR = 304,
    CLX_PKT_HW_RSN_L3UC_IPV6_ICMP_REDIR,
    CLX_PKT_HW_RSN_L3MC_IPV6_DIP_MISS,
    CLX_PKT_HW_RSN_L3MC_IPV6_RPF_FAIL_DROP,
    CLX_PKT_HW_RSN_L3MC_IPV6_RPF_FAIL_REDIR,
    CLX_PKT_HW_RSN_L3MC_IPV6_RPF_FAIL_CANT_FALL_BACK_L2,
    CLX_PKT_HW_RSN_L3UC_NO_FWD_PTR,
    CLX_PKT_HW_RSN_L3UC_NO_AFIB_RSLT_PTR,
    CLX_PKT_HW_RSN_L25MPLS_TRANSIT_LBL_MISS,
    CLX_PKT_HW_RSN_ECMPGRP_ZERO_NUM_PATH_EXCPT_0,
    CLX_PKT_HW_RSN_ECMPMBR_INVALID_EXCPT_0,
    CLX_PKT_HW_RSN_L2_SA_MOVE,
    CLX_PKT_HW_RSN_L2_SA_MISS_0,
    CLX_PKT_HW_RSN_L2_SA_MISS_1,
    CLX_PKT_HW_RSN_L2_SA_FWD_MAC_BD_MISMATCH,
    CLX_PKT_HW_RSN_L2ECMP_MISS,
    CLX_PKT_HW_RSN_POLICE_RED_EXCPT_0 = 320,
    CLX_PKT_HW_RSN_ACTION_SUP_LOG_0,
    CLX_PKT_HW_RSN_ACTION_SUP_DENY_0,
    CLX_PKT_HW_RSN_FINAL_RED_EXCPT_0,
    CLX_PKT_HW_RSN_STORM_RED_EXCPT_0,
    CLX_PKT_HW_RSN_INT_SOURCE_RCV_INT_ENCAP,
    CLX_PKT_HW_RSN_ECMPGRP_ZERO_NUM_PATH_EXCPT_1,
    CLX_PKT_HW_RSN_ECMPMBR_INVALID_EXCPT_1,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_0,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_1,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_2,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_3,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_4,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_5,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_6,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_7 = 336,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_8,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_9,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_10,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_11,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_12,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_13,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_14,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_15,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_16,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_17,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_18,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_19,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_20,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_21,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_22,
    CLX_PKT_HW_RSN_SFLOW_SAMPLER_EXCPT_0 = 352,
    CLX_PKT_HW_RSN_UC_SOURCE_PRUNING,
    CLX_PKT_HW_RSN_UC_UL2UL_PRUNING,
    CLX_PKT_HW_RSN_TNL_IDX_IN_LAT_MODE,
    CLX_PKT_HW_RSN_IP_TTL0,
    CLX_PKT_HW_RSN_IP_TTL1,
    CLX_PKT_HW_RSN_IPV4_OPTION_EXIST_FWD,
    CLX_PKT_HW_RSN_IPV6_NHDR_SW_FWD,
    CLX_PKT_HW_RSN_TNL_ECMPGRP_ZERO_NUM_PATH,
    CLX_PKT_HW_RSN_TNL_ECMPMBR_INVALID,
    CLX_PKT_HW_RSN_TELM_OVER_UNSUPPORTED_TYPE,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_43,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_44,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_45,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_46,
    CLX_PKT_HW_RSN_RX_COPYTOCPU_RSN_47,
    CLX_PKT_HW_RSN_EVPN_ESI_FLITER = 384,
    CLX_PKT_HW_RSN_EVPN_DF_FLITER,
    CLX_PKT_HW_RSN_VLAN_HSH_MISS,
    CLX_PKT_HW_RSN_L2MTU_EXCPT_1,
    CLX_PKT_HW_RSN_L3MTU_EXCPT_1,
    CLX_PKT_HW_RSN_BDI_SPT_EXCPT_1,
    CLX_PKT_HW_RSN_PVLAN_PORT_TYPE,
    CLX_PKT_HW_RSN_PVLAN,
    CLX_PKT_HW_RSN_INT_OVER_UNSUPPORTED_TYPE,
    CLX_PKT_HW_RSN_MC_SOURCE_PRUNING,
    CLX_PKT_HW_RSN_MC_UL2UL_PRUNING,
    CLX_PKT_HW_RSN_MC_L3VPN_PRUNING,
    CLX_PKT_HW_RSN_IOAM_OVER_UNSUPPORTED_TYPE,
    CLX_PKT_HW_RSN_INT_REPORT_REC,
    CLX_PKT_HW_RSN_INT_MTU_EXCEED,
    CLX_PKT_HW_RSN_INT_META_INCOMP,
    CLX_PKT_HW_RSN_TELM_NONEXIST_DECAP = 400,
    CLX_PKT_HW_RSN_IFA_HOP_LIMIT_0,
    CLX_PKT_HW_RSN_POST_SMALL_PKT_EXCPT_0,
    CLX_PKT_HW_RSN_INC_OVERFLOW_EXCPT_0,
    CLX_PKT_HW_RSN_POLICE_RED_EXCPT_1 = 449,
    CLX_PKT_HW_RSN_ACTION_SUP_LOG_1,
    CLX_PKT_HW_RSN_ACTION_SUP_DENY_1,
    CLX_PKT_HW_RSN_FINAL_RED_EXCPT_1,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_0,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_1,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_2,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_3,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_4,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_5,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_6,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_7,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_8,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_9,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_10,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_11 = 464,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_12,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_13,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_14,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_15,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_16,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_17,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_18,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_19,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_20,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_21,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_22,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_23,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_24,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_25,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_26,
    CLX_PKT_HW_RSN_SFLOW_SAMPLER_EXCPT_1 = 480,
    CLX_PKT_HW_RSN_INT_OVER_VXLAN_BASE,
    CLX_PKT_HW_RSN_INT_OVER_UNSUPPORTED_TNL,
    CLX_PKT_HW_RSN_IOAM_OVER_UNSUPPORTED_TNL,
    CLX_PKT_HW_RSN_L3MTU_EXCPT_2,
    CLX_PKT_HW_RSN_MPLS_PHP_BOS_ETH,
    CLX_PKT_HW_RSN_POST_SMALL_PKT_EXCPT_1,
    CLX_PKT_HW_RSN_HDC_VAL,
    CLX_PKT_HW_RSN_INC_OVERFLOW_EXCPT_1,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_27,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_28,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_29,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_30,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_31,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_32,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_33,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_34,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_35,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_36,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_37,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_38,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_39,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_40,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_41,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_42,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_43,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_44,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_45,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_46,
    CLX_PKT_HW_RSN_RX_TRAP_RSN_47,
    CLX_PKT_HW_RSN_MOD = 511,
    CLX_PKT_HW_RSN_LAST = 512,
} clx_pkt_hw_reason_t;

typedef enum clx_stat_srv_cnt_mode_e {
    CLX_STAT_SRV_CNT_MODE_SINGLE = 0, /* Service counter single mode */
    CLX_STAT_SRV_CNT_MODE_DOUBLE,     /* Service counter double mode */
    CLX_STAT_SRV_CNT_MODE_TRIPLE,     /* Service counter triple mode */
    CLX_STAT_SRV_CNT_MODE_SIXFOLD,    /* Service counter sixfold mode */
    CLX_STAT_SRV_CNT_MODE_LAST
} clx_stat_srv_cnt_mode_t;

typedef enum clx_stat_rate_type_e {
    CLX_STAT_RATE_RX_BYTE_L1, /* Byte per second */
    CLX_STAT_RATE_RX_BYTE,    /* Byte per second */
    CLX_STAT_RATE_RX_PKT,     /* Packet per second */
    CLX_STAT_RATE_TX_BYTE_L1, /* Byte per second */
    CLX_STAT_RATE_TX_BYTE,    /* Byte per second */
    CLX_STAT_RATE_TX_PKT,     /* Packet per second */
    CLX_STAT_RATE_IF_OUT_DISCARDS,
    CLX_STAT_RATE_TM_START,
    CLX_STAT_RATE_TX_DROP_EGR_BUF = CLX_STAT_RATE_TM_START,
    CLX_STAT_RATE_TYPE_LAST
} clx_stat_rate_type_t;

typedef enum clx_stat_port_cnt_type_e {
    /* RFC2863 */
    CLX_STAT_PORT_IF_IN_OCTETS = 0,         /* ifInOctets */
    CLX_STAT_PORT_IF_IN_UCAST_PKTS,         /* ifInUcastPkts */
    CLX_STAT_PORT_IF_IN_NUCAST_PKTS,        /* ifInNUcastPkts */
    CLX_STAT_PORT_IF_IN_DISCARDS,           /* ifInDiscards */
    CLX_STAT_PORT_IF_IN_ERRORS,             /* ifInErrors */
    CLX_STAT_PORT_IF_IN_UNKNOWN_PROTOS,     /* ifInUnknownProtos, not support on CL8600 */
    CLX_STAT_PORT_IF_OUT_OCTETS,            /* ifOutOctets */
    CLX_STAT_PORT_IF_OUT_UCAST_PKTS,        /* ifOutUcastPkts */
    CLX_STAT_PORT_IF_OUT_NUCAST_PKTS,       /* ifOutNUcastPkts */
    CLX_STAT_PORT_IF_OUT_DISCARDS,          /* ifOutDiscards */
    CLX_STAT_PORT_IF_OUT_ERRORS,            /* ifOutErrors */
    CLX_STAT_PORT_IF_IN_MULTICAST_PKTS,     /* ifInMulticastPkts */
    CLX_STAT_PORT_IF_IN_BROADCAST_PKTS,     /* ifInBroadcastPkts */
    CLX_STAT_PORT_IF_OUT_MULTICAST_PKTS,    /* ifOutMulticastPkts */
    CLX_STAT_PORT_IF_OUT_BROADCAST_PKTS,    /* ifOutBroadcastPkts */
    CLX_STAT_PORT_IF_HC_IN_OCTETS,          /* ifHCInOctets */
    CLX_STAT_PORT_IF_HC_IN_UCAST_PKTS,      /* ifHCInUcastPkts */
    CLX_STAT_PORT_IF_HC_IN_MULTICAST_PKTS,  /* ifHCInMulticastPkts */
    CLX_STAT_PORT_IF_HC_IN_BROADCAST_PKTS,  /* ifHCInBroadcastPkts */
    CLX_STAT_PORT_IF_HC_OUT_OCTETS,         /* ifHCOutOctets */
    CLX_STAT_PORT_IF_HC_OUT_UCAST_PKTS,     /* ifHCOutUcastPkts */
    CLX_STAT_PORT_IF_HC_OUT_MULTICAST_PKTS, /* ifHCOutMulticastPkts */
    CLX_STAT_PORT_IF_HC_OUT_BROADCAST_PKTS, /* ifHCOutBroadcastPkts */
                                            /* end */

                                            /* RFC2819 */
    CLX_STAT_PORT_ETHER_STATS_DROP_EVENTS,      /* etherStatsDropEvents, not support on CL8600
                                                 */
    CLX_STAT_PORT_ETHER_STATS_OCTETS,           /* etherStatsOctets */
    CLX_STAT_PORT_ETHER_STATS_PKTS,             /* etherStatsPkts */
    CLX_STAT_PORT_ETHER_STATS_BROADCAST_PKTS,   /* etherStatsBroadcastPkts */
    CLX_STAT_PORT_ETHER_STATS_MULTICAST_PKTS,   /* etherStatsMulticastPkts */
    CLX_STAT_PORT_ETHER_STATS_CRC_ALIGN_ERRORS, /* etherStatsCRCAlignErrors, not support on
                                                            CL8600 */
    CLX_STAT_PORT_ETHER_STATS_UNDERSIZE_PKTS,   /* etherStatsUndersizePkts */
    CLX_STAT_PORT_ETHER_STATS_OVERSIZE_PKTS,    /* etherStatsOversizePkts */
    CLX_STAT_PORT_ETHER_STATS_FRAGMENTS,        /* etherStatsFragments */
    CLX_STAT_PORT_ETHER_STATS_JABBERS,          /* etherStatsJabbers */
    CLX_STAT_PORT_ETHER_STATS_COLLISIONS,       /* etherStatsCollisions, not support on CL8600 */
    CLX_STAT_PORT_ETHER_STATS_PKTS_64_OCTETS,   /* etherStatsPkts64Octets */
    CLX_STAT_PORT_ETHER_STATS_PKTS_65_TO_127_OCTETS,    /* etherStatsPkts65to127Octets */
    CLX_STAT_PORT_ETHER_STATS_PKTS_128_TO_255_OCTETS,   /* etherStatsPkts128to255Octets */
    CLX_STAT_PORT_ETHER_STATS_PKTS_256_TO_511_OCTETS,   /* etherStatsPkts256to511Octets */
    CLX_STAT_PORT_ETHER_STATS_PKTS_512_TO_1023_OCTETS,  /* etherStatsPkts512to1023Octets */
    CLX_STAT_PORT_ETHER_STATS_PKTS_1024_TO_1518_OCTETS, /* etherStatsPkts1024to1518Octets
                                                         */
                                                        /* end */

                                                        /* RFC3635 */
    CLX_STAT_PORT_DOT3_STATS_ALIGNMENT_ERRORS,          /* dot3StatsAlignmentErrors, not support on
                                                                    CL8600 */
    CLX_STAT_PORT_DOT3_STATS_FCS_ERRORS,                /* dot3StatsFCSErrors */
    CLX_STAT_PORT_DOT3_STATS_SINGLE_COLLISION_FRAMES,   /* dot3StatsSingleCollisionFrames,
                                                                    not support on CL8600 */
    CLX_STAT_PORT_DOT3_STATS_MULTIPLE_COLLISION_FRAMES, /* dot3StatsMultipleCollisionFrames,
                                                                    not support on CL8600 */
    CLX_STAT_PORT_DOT3_STATS_SQE_TEST_ERRORS,           /* dot3StatsSQETestErrors, not support on
                                                                    CL8600 */
    CLX_STAT_PORT_DOT3_STATS_DEFERRED_TRANSMISSIONS,    /* dot3StatsDeferredTransmissions, not
                                                                    support on CL8600 */
    CLX_STAT_PORT_DOT3_STATS_LATE_COLLISIONS,           /* dot3StatsLateCollisions, not support on
                                                                    CL8600 */
    CLX_STAT_PORT_DOT3_STATS_EXCESSIVE_COLLISIONS,      /* dot3StatsExcessiveCollisions, not
                                                                    support on CL8600 */
    CLX_STAT_PORT_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS, /* dot3StatsInternalMacTransmitErrors
                                                            */
    CLX_STAT_PORT_DOT3_STATS_CARRIER_SENSE_ERRORS,         /* dot3StatsCarrierSenseErrors, not
                                                                       support on CL8600 */
    CLX_STAT_PORT_DOT3_STATS_FRAME_TOO_LONGS,              /* dot3StatsFrameTooLongs */
    CLX_STAT_PORT_DOT3_STATS_INTERNAL_MAC_RECEIVE_ERRORS,  /* dot3StatsInternalMacReceiveErrors
                                                            */
    CLX_STAT_PORT_DOT3_STATS_SYMBOL_ERRORS,       /* dot3StatsSymbolErrors, not support on CL8600
                                                   */
    CLX_STAT_PORT_DOT3_HC_STATS_ALIGNMENT_ERRORS, /* dot3HCStatsAlignmentErrors, not
                                                              support on CL8600 */
    CLX_STAT_PORT_DOT3_HC_STATS_FCS_ERRORS,       /* dot3HCStatsFCSErrors */
    CLX_STAT_PORT_DOT3_HC_STATS_INTERNAL_MAC_TRANSMIT_ERRORS, /* dot3HCStatsInternalMacTransmitErrors
                                                               */
    CLX_STAT_PORT_DOT3_HC_STATS_FRAME_TOO_LONGS,              /* dot3HCStatsFrameTooLongs */
    CLX_STAT_PORT_DOT3_HC_STATS_INTERNAL_MAC_RECEIVE_ERRORS,  /* dot3HCStatsInternalMacReceiveErrors
                                                               */
    CLX_STAT_PORT_DOT3_HC_STATS_SYMBOL_ERRORS,        /* dot3HCStatsSymbolErrors, not support on
                                                                  CL8600 */
    CLX_STAT_PORT_DOT3_CONTROL_IN_UNKNOWN_OPCODES,    /* dot3ControlInUnknownOpcodes, not
                                                                  support on CL8600 */
    CLX_STAT_PORT_DOT3_HC_CONTROL_IN_UNKNOWN_OPCODES, /* dot3HCControlInUnknownOpcodes, not
                                                                  support on CL8600 */

    CLX_STAT_PORT_DOT3_IN_PAUSE_FRAMES,               /* dot3InPauseFrames */
    CLX_STAT_PORT_DOT3_OUT_PAUSE_FRAMES,              /* dot3OutPauseFrames */
    CLX_STAT_PORT_DOT3_HC_IN_PAUSE_FRAMES,            /* dot3HCInPauseFrames */
    CLX_STAT_PORT_DOT3_HC_OUT_PAUSE_FRAMES,           /* dot3HCOutPauseFrames */
                                                      /* end */

                                                      /* RFC3273, not support on CL8600 */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_DROP_EVENTS,             /* mediaIndependentDropEvents */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_DROPPED_FRAMES,          /* mediaIndependentDroppedFrames */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_PKTS,                 /* mediaIndependentInPkts */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_OVERFLOW_PKTS,        /* mediaIndependentInOverflowPkts */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_PKTS,   /* mediaIndependentInHighCapacityPkts
                                                              */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_PKTS,                /* mediaIndependentOutPkts */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_OVERFLOW_PKTS,       /* mediaIndependentOutOverflowPkts
                                                              */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_PKTS,  /* mediaIndependentOutHighCapacityPkts
                                                              */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_OCTETS,               /* mediaIndependentInOctets */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_OVERFLOW_OCTETS,      /* mediaIndependentInOverflowOctets
                                                              */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_HIGH_CAPACITY_OCTETS, /* mediaIndependentInHighCapacityOctets
                                                              */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_OCTETS,              /* mediaIndependentOutOctets */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_OVERFLOW_OCTETS,     /* mediaIndependentOutOverflowOctets
                                                              */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_HIGH_CAPACITY_OCTETS, /* mediaIndependentOutHighCapacityOctets
                                                               */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_NUCAST_PKTS,           /* mediaIndependentInNUCastPkts */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_NUCAST_OVERFLOW_PKTS, /* mediaIndependentInNUCastOverflowPkts
                                                              */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_NUCAST_HIGH_CAPACITY_PKTS, /* mediaIndependentInNUCastHighCapacityPkts
                                                                   */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_NUCAST_PKTS,          /* mediaIndependentOutNUCastPkts */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_NUCAST_OVERFLOW_PKTS, /* mediaIndependentOutNUCastOverflowPkts
                                                               */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_NUCAST_HIGH_CAPACITY_PKTS, /* mediaIndependentOutNUCastHighCapacityPkts
                                                                    */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_IN_ERRORS,                     /* mediaIndependentInErrors */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_OUT_ERRORS,                    /* mediaIndependentOutErrors */
    CLX_STAT_PORT_MEDIA_INDEPENDENT_DUPLEX_CHANGES,          /* mediaIndependentDuplexChanges */

    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS,   /* etherStatsHighCapacityOverflowPkts
                                                              */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_PKTS,            /* etherStatsHighCapacityPkts */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_OCTETS, /* etherStatsHighCapacityOverflowOctets
                                                              */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OCTETS,          /* etherStatsHighCapacityOctets */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_64_OCTETS, /* etherStatsHighCapacityOverflowPkts64Octets
                                                                      */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_PKTS_64_OCTETS, /* etherStatsHighCapacityPkts64Octets
                                                             */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_65_TO_127_OCTETS, /* etherStatsHighCapacityOverflowPkts65to127Octets
                                                                             */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_PKTS_65_TO_127_OCTETS, /* etherStatsHighCapacityPkts65to127Octets
                                                                    */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_128_TO_255_OCTETS, /* etherStatsHighCapacityOverflowPkts128to255Octets
                                                                              */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_PKTS_128_TO_255_OCTETS, /* etherStatsHighCapacityPkts128to255Octets
                                                                     */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_256_TO_511_OCTETS, /* etherStatsHighCapacityOverflowPkts256to511Octets
                                                                              */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_PKTS_256_TO_511_OCTETS, /* etherStatsHighCapacityPkts256to511Octets
                                                                     */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_512_TO_1023_OCTETS, /* etherStatsHighCapacityOverflowPkts512to1023Octets
                                                                               */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_PKTS_512_TO_1023_OCTETS, /* etherStatsHighCapacityPkts512to1023Octets
                                                                      */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_OVERFLOW_PKTS_1024_TO_1518_OCTETS, /* etherStatsHighCapacityOverflowPkts1024to1518Octets
                                                                                */
    CLX_STAT_PORT_ETHER_STATS_HIGH_CAPACITY_PKTS_1024_TO_1518_OCTETS, /* etherStatsHighCapacityPkts1024to1518Octets
                                                                       */
                                                                      /* end */

    /* RFC4836, not support on CL8600 */
    CLX_STAT_PORT_RP_MAU_MEDIA_AVAILABLE_STATE_EXITS, /* rpMauMediaAvailableStateExits */
    CLX_STAT_PORT_RP_MAU_FALSE_CARRIERS,              /* rpMauFalseCarriers */

    CLX_STAT_PORT_IF_MAU_MEDIA_AVAILABLE_STATE_EXITS, /* ifMauMediaAvailableStateExits */
    CLX_STAT_PORT_IF_MAU_FALSE_CARRIERS,              /* ifMauFalseCarriers */
    CLX_STAT_PORT_IF_MAU_HC_FALSE_CARRIERS,           /* ifMauHCFalseCarriers */
                                                      /* end */

    /* IEEE P802.1Q(TM) Priority-based Flow Control MIB */
    CLX_STAT_PORT_IEEE_8021_PFC_REQUESTS,               /* ieee8021PfcRequests */
    CLX_STAT_PORT_IEEE_8021_PFC_INDICATIONS,            /* ieee8021PfcIndications */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E0_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE0InPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E0_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE0OutPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E1_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE1InPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E1_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE1OutPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E2_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE2InPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E2_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE2OutPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E3_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE3InPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E3_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE3OutPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E4_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE4InPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E4_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE4OutPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E5_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE5InPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E5_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE5OutPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E6_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE6InPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E6_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE6OutPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E7_IN_PAUSE_FRAMES,  /* ieee8021PfcHcE7InPauseFrames */
    CLX_STAT_PORT_IEEE_8021_PFC_HC_E7_OUT_PAUSE_FRAMES, /* ieee8021PfcHcE7OutPauseFrames */
                                                        /* end */

    CLX_STAT_PORT_RX_FRAMES_RECEIVED_OK,                /* The total count of
                                                         * CLX_STAT_PORT_IF_IN_UCAST_PKTS,
                                                         *                    CLX_STAT_PORT_IF_IN_MULTICAST_PKTS,
                                                         *                    CLX_STAT_PORT_IF_IN_BROADCAST_PKTS.
                                                         */
    CLX_STAT_PORT_RX_PAUSE_MAC_CTRL_FRAMES_RECEIVED,    /* The total count of
                                                         * CLX_STAT_PORT_IEEE_8021_PFC_INDICATIONS,
                                                         *                    CLX_STAT_PORT_DOT3_IN_PAUSE_FRAMES
                                                         */
    CLX_STAT_PORT_RX_MAC_CONTROL_FRAMES_RECEIVED,       /* The same as
                                                                    CLX_STAT_PORT_IF_IN_UNKNOWN_PROTOS,
                                                                    not support on CL8600. */
    CLX_STAT_PORT_RX_IN_RANGE_LENGTH_ERROES,    /* Rx length error, not support on CL8600. */
    CLX_STAT_PORT_RX_PKTS_1519_TO_2560_OCTETS,  /* Count if pkt length is in the range
                                                            between 1519 and 2560. Dawn only. */
    CLX_STAT_PORT_RX_PKTS_2561_TO_MAX_OCTETS,   /* Count if pkt length is larger then 2561.
                                                            Dawn only. */
    CLX_STAT_PORT_RX_PKTS_1519_TO_2047_OCTETS,  /* Count if pkt length is in the range
                                                            between 1519 and 2047. */
    CLX_STAT_PORT_RX_PKTS_2048_TO_4095_OCTETS,  /* Count if pkt length is in the range
                                                            between 2048 and 4095. Not support on
                                                            dawn. */
    CLX_STAT_PORT_RX_PKTS_4096_TO_9216_OCTETS,  /* Count if pkt length is in the range
                                                            between 4096 and 9216. Not support on
                                                            CL8600. */
    CLX_STAT_PORT_RX_PKTS_9217_TO_16383_OCTETS, /* Count if pkt length is in the range
                                                            between 9217 and 16383. Not support on
                                                            CL8600. */
    CLX_STAT_PORT_RX_PKTS_4096_TO_8191_OCTETS,  /* Count if pkt length is in the range
                                                            between 4096 and 8191. CL8600 only. */
    CLX_STAT_PORT_RX_PKTS_8192_TO_9215_OCTETS,  /* Count if pkt length is in the range
                                                            between 8192 and 9215. CL8600 only. */
    CLX_STAT_PORT_RX_PKTS_9216_TO_MAX_OCTETS,   /* Count if pkt length is larger then 9216.
                                                            CL8600 only. */
    CLX_STAT_PORT_TX_FRAMES_TRANSMITTED_OK,     /* The total count of
                                                 * CLX_STAT_PORT_IF_OUT_UCAST_PKTS,
                                                 *                     CLX_STAT_PORT_IF_OUT_MULTICAST_PKTS,
                                                 *                     CLX_STAT_PORT_IF_OUT_BROADCAST_PKTS
                                                 *
                                                 */
    CLX_STAT_PORT_TX_PAUSE_MAC_CTRL_FRAMES_TRANSMITTED, /* The total count of
                                                         * CLX_STAT_PORT_IEEE_8021_PFC_REQUESTS,
                                                         *                     CLX_STAT_PORT_DOT3_OUT_PAUSE_FRAMES
                                                         */
    CLX_STAT_PORT_TX_PKTS_CRC_ERR,                      /* The same as
                                                                    CLX_STAT_PORT_DOT3_STATS_INTERNAL_MAC_TRANSMIT_ERRORS
                                                                  */
    CLX_STAT_PORT_TX_PKTS_64_OCTETS,                    /* Count if pkt length is less then 64.*/
    CLX_STAT_PORT_TX_PKTS_65_TO_127_OCTETS,     /* Count if pkt length is in the range between
                                                            65 and 127. */
    CLX_STAT_PORT_TX_PKTS_128_TO_255_OCTETS,    /* Count if pkt length is in the range between
                                                            128 and 255. */
    CLX_STAT_PORT_TX_PKTS_256_TO_511_OCTETS,    /* Count if pkt length is in the range between
                                                            256 and 511. */
    CLX_STAT_PORT_TX_PKTS_512_TO_1023_OCTETS,   /* Count if pkt length is in the range
                                                            between 512 and 1023. */
    CLX_STAT_PORT_TX_PKTS_1024_TO_1518_OCTETS,  /* Count if pkt length is in the range
                                                            between 1024 and 1518. */
    CLX_STAT_PORT_TX_PKTS_1519_TO_2560_OCTETS,  /* Count if pkt length is in the range
                                                            between 1519 and 2560. Dawn only */
    CLX_STAT_PORT_TX_PKTS_2561_TO_MAX_OCTETS,   /* Count if pkt length is larger then 2561.
                                                            Dawn only */
    CLX_STAT_PORT_TX_PKTS_1519_TO_2047_OCTETS,  /* Count if pkt length is in the range
                                                            between 1519 and 2047. */
    CLX_STAT_PORT_TX_PKTS_2048_TO_4095_OCTETS,  /* Count if pkt length is in the range
                                                            between 2048 and 4095. */
    CLX_STAT_PORT_TX_PKTS_4096_TO_9216_OCTETS,  /* Count if pkt length is in the range
                                                            between 4096 and 9216. Not support on
                                                            CL8600. */
    CLX_STAT_PORT_TX_PKTS_9217_TO_16383_OCTETS, /* Count if pkt length is in the range
                                                            between 9217 and 16383. Not support on
                                                            CL8600. */
    CLX_STAT_PORT_TX_PKTS_4096_TO_8191_OCTETS,  /* Count if pkt length is in the range
                                                            between 4096 and 8191. CL8600 only */
    CLX_STAT_PORT_TX_PKTS_8192_TO_9215_OCTETS,  /* Count if pkt length is in the range
                                                            between 8192 and 9215. CL8600 only */
    CLX_STAT_PORT_TX_PKTS_GT_9216_OCTETS,       /* Count if pkt length is greater than 9216.
                                                            CL8600 only */
    CLX_STAT_PORT_DROP_CNT_RECEIVE,             /* Dawn only */
    CLX_STAT_PORT_DROP_CNT_TRANSMIT,            /* Dawn only */

                                                /* Drop counter, not support on CL8600.*/
    CLX_STAT_PORT_TX_OVERSIZE_PKTS,             /* Tx oversize pkt */
    CLX_STAT_PORT_L3_DISCARDS,                  /* The same as CLX_STAT_PORT_INGRESS_L3_DISCARDS */
    CLX_STAT_PORT_INGRESS_L3_DISCARDS,          /* Ingress l3 discard packet */
    CLX_STAT_PORT_EGRESS_L3_DISCARDS,           /* Egress l3 discard packet */
    CLX_STAT_PORT_L3_BLACKHOLE_DISCARDS,        /* L3 blackhole discard packet */
    CLX_STAT_PORT_INGRESS_PARITY_DISCARDS,      /* Ingress parity discard packet */
    CLX_STAT_PORT_EGRESS_NON_QUEUE_DISCARDS,    /* Egress non-queue discard packet */
    CLX_STAT_PORT_EGRESS_INVALID_VLAN_DISCARDS, /* Egress invalid vlan discard packet */
    CLX_STAT_PORT_INGRESS_L2_MTU_DISCARDS,      /* Ingress L2 MTU discard packet */
    CLX_STAT_PORT_BUFFER_DISCARDS,              /* Buffer discard pkts */
    CLX_STAT_PORT_INGRESS_NON_QUEUE_DISCARDS,   /* Ingress non-queue discard packet */
                                                /* end */

                                                /* CL8600 only */
    CLX_STAT_PORT_IN_DROP_NON_IP_PKTS,    /* The total number of drop non-IP packets received
                                           */
    CLX_STAT_PORT_IN_DROP_NON_IP_OCTETS,  /* The total number of drop non-IP octets received
                                           */
    CLX_STAT_PORT_IN_DROP_IPV4_PKTS,      /* The total number of drop IPv4 packets received */
    CLX_STAT_PORT_IN_DROP_IPV4_OCTETS,    /* The total number of drop IPv4 octets  received */
    CLX_STAT_PORT_IN_DROP_IPV6_PKTS,      /* The total number of drop IPv6 packets received */
    CLX_STAT_PORT_IN_DROP_IPV6_OCTETS,    /* The total number of drop IPv6 octets received */
    CLX_STAT_PORT_IN_PKTS,                /* The total number of good packets received */
    CLX_STAT_PORT_IN_OCTETS,              /* The total number of good octets received */
    CLX_STAT_PORT_IN_IPV4_PKTS,           /* The total number of good IPv4 packets received */
    CLX_STAT_PORT_IN_IPV4_OCTETS,         /* The total number of good IPv4 octets received */
    CLX_STAT_PORT_IN_IPV6_PKTS,           /* The total number of good IPv6 packets received */
    CLX_STAT_PORT_IN_IPV6_OCTETS,         /* The total number of good IPv6 octets received */
    CLX_STAT_PORT_OUT_DROP_NON_IP_PKTS,   /* The total number of drop non-IP packets
                                                      transmitted */
    CLX_STAT_PORT_OUT_DROP_NON_IP_OCTETS, /* The total number of drop non-IP octets
                                                      transmitted */
    CLX_STAT_PORT_OUT_DROP_IPV4_PKTS,     /* The total number of drop IPv4 packets transmitted
                                           */
    CLX_STAT_PORT_OUT_DROP_IPV4_OCTETS,   /* The total number of drop IPv4 octets transmitted
                                           */
    CLX_STAT_PORT_OUT_DROP_IPV6_PKTS,     /* The total number of drop IPv6 packets transmitted
                                           */
    CLX_STAT_PORT_OUT_DROP_IPV6_OCTETS,   /* The total number of drop IPv6 octets transmitted
                                           */
    CLX_STAT_PORT_OUT_PKTS,               /* The total number of good packets transmitted */
    CLX_STAT_PORT_OUT_OCTETS,             /* The total number of good octets transmitted */
    CLX_STAT_PORT_OUT_IPV4_PKTS,          /* The total number of good IPv4 packets transmitted
                                           */
    CLX_STAT_PORT_OUT_IPV4_OCTETS,        /* The total number of good IPv4 octets transmitted
                                           */
    CLX_STAT_PORT_OUT_IPV6_PKTS,          /* The total number of good IPv6 packets transmitted
                                           */
    CLX_STAT_PORT_OUT_IPV6_OCTETS,        /* The total number of good IPv6 octets transmitted
                                           */
    CLX_STAT_PORT_TIMESTAMP,              /* The timestamp of the last update */
                                          /* end */
    CLX_STAT_PORT_LAST
} clx_stat_port_t;

typedef enum clx_stat_tm_e {
    CLX_STAT_TM_QUEUE_CNT = 0,
    CLX_STAT_TM_QUEUE_RX_BUF_FULL_DROP,
    CLX_STAT_TM_QUEUE_TX_BUF_FULL_DROP,
    CLX_STAT_TM_QUEUE_TX_ECN_BUF_FULL,
    CLX_STAT_TM_PORT_RX,
    CLX_STAT_TM_PORT_RX_DROP,
    CLX_STAT_TM_PORT_TX,
    CLX_STAT_TM_PORT_TX_DROP,
    CLX_STAT_TM_PORT_ECN_TRANSMIT,
    CLX_STAT_TM_LAST
} clx_stat_tm_t;

typedef struct clx_stat_tm_cnt_s {
    uint64 pkt_cnt;  /* The packet counter */
    uint64 byte_cnt; /* The packet byte counter */
    uint64 timestamp; /* The timestamp of the last update, unit: ms */
} clx_stat_tm_cnt_t;

typedef struct clx_stat_dist_cnt_s {
    uint64 le64_cnt;
    uint64 pkt_65_to_127_cnt;
    uint64 pkt_128_to_255_cnt;
    uint64 pkt_256_to_511_cnt;
    uint64 pkt_512_to_1023_cnt;
    uint64 pkt_1024_to_1518_cnt;
    uint64 pkt_1519_to_2560_cnt;
    uint64 pkt_2561_to_9216_cnt;
    uint64 pkt_1519_to_2047_cnt;
    uint64 pkt_2048_to_9216_cnt;
    uint64 bc_cnt;
    uint64 mc_cnt;
    uint64 pkt_cnt;
    uint64 byte_cnt;
} clx_stat_dist_cnt_t;

typedef struct clx_stat_srv_cnt_cfg_s {
    clx_stat_srv_cnt_mode_t mode;
    uint32 flags[CLX_STAT_SRV_CNT_ENTRY_NUM]; /* Counter configuration */
} clx_stat_srv_cnt_cfg_t;

typedef struct clx_stat_srv_cnt_s {
    uint64 cnt[CLX_STAT_SRV_CNT_ENTRY_NUM]; /* The counter. Counting is based on the configuration
                                             */
    uint64 timestamp; /* The timestamp of the last update, unit: ms */
} clx_stat_srv_cnt_t;

#ifdef CLX_STAT_EN_HPC_CNT
typedef enum {
    CLX_STAT_HPC_CNT_TYPE_RX_PKT = 0,
    CLX_STAT_HPC_CNT_TYPE_RX_OCTECTS,
    CLX_STAT_HPC_CNT_TYPE_TX_PKT,
    CLX_STAT_HPC_CNT_TYPE_TX_OCTECTS,
    CLX_STAT_HPC_CNT_TYPE_LAST
} clx_stat_hpc_cnt_type_t;

typedef struct clx_stat_hpc_cfg_s {
    uint32 polling_intvl; /* Set the polling interval of stat HPC in millisecond(ms) */
    uint64 fifo_size;     /* Allocate the total size of FIFO storage */
} clx_stat_hpc_cfg_t;

typedef struct clx_stat_hpc_cnt_s {
    uint64 time_stamp;
    uint64 cnt[CLX_STAT_HPC_TOTAL_PORT * CLX_STAT_HPC_CNT_TYPE_LAST];
    uint64 ipl_utilization[CLX_STAT_HPC_TOTAL_PORT];
    uint64 epl_utilization[CLX_STAT_HPC_TOTAL_PORT];
} clx_stat_hpc_cnt_t;

#define CLX_STAT_HPC_CNT_OFFSET(__port__, __type__) \
    ((__port__) * CLX_STAT_HPC_CNT_TYPE_LAST + (__type__))
#endif /* End of CLX_STAT_EN_HPC_CNT */

/**
 * @brief This API is used to get port counter by physical port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Physical port.
 * @param [in]     type       - Counter type.
 * @param [out]    ptr_cnt    - Counter.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_port_cnt_get(const uint32 unit,
                      const uint32 port,
                      const clx_stat_port_t type,
                      uint64 *ptr_cnt);

/**
 * @brief This API is used to retrieve specific list counters by physical port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port.
 * @param [in]     ptr_type    - Multiple lists of counter.
 * @param [in]     total       - The total count of the retrieved specific list counters.
 * @param [out]    ptr_cnt     - Counter list.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_port_cnts_get(const uint32 unit,
                       const uint32 port,
                       const clx_stat_port_t *ptr_type,
                       const uint32 total,
                       uint64 *ptr_cnt);

/**
 * @brief This API is used to clear port counter by physical port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Physical port.
 * @param [in]    type    - Counter type.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_port_cnt_clear(const uint32 unit, const uint32 port, const clx_stat_port_t type);

/**
 * @brief This API is used to clear specific list counters by physical port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    port        - Physical port.
 * @param [in]    ptr_type    - Multiple lists of counter.
 * @param [in]    total       - The total count of the retrieved specific list counters.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_port_cnts_clear(const uint32 unit,
                         const uint32 port,
                         const clx_stat_port_t *ptr_type,
                         const uint32 total);

/**
 * @brief This API is used to get port traffic rate by physical port.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     port        - Physical port.
 * @param [in]     type        - Counter type.
 * @param [out]    ptr_rate    - Rate.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_port_rate_get(const uint32 unit,
                       const uint32 port,
                       const clx_stat_rate_type_t type,
                       uint64 *ptr_rate);

/**
 * @brief This API is used to get TM counter by TM queue.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     handler    - The handler of TM queue.
 * @param [out]    ptr_cnt    - Queue counter.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_queue_cnt_get(const uint32 unit,
                       const clx_tm_handler_t handler,
                       clx_stat_tm_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear TM counter by TM queue.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    handler    - The handler of TM queue.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - Allocate memory failed.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_stat_queue_cnt_clear(const uint32 unit, const clx_tm_handler_t handler);

/**
 * @brief This API is used to get counter by port, queue, and TM counter type.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Port ID.
 * @param [in]     handler    - The handler of TM queue.
 * @param [in]     type       - Counter type.
 * @param [out]    ptr_cnt    - Counter value.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_stat_tm_cnt_get(const uint32 unit,
                    const uint32 port,
                    const clx_tm_handler_t handler,
                    const clx_stat_tm_t type,
                    clx_stat_tm_cnt_t *ptr_cnt);

/**
 * @brief This API is used to clear counter by port, queue, and TM counter type.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port ID.
 * @param [in]    handler    - The handler of TM queue.
 * @param [in]    type       - Counter type.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_stat_tm_cnt_clear(const uint32 unit,
                      const uint32 port,
                      const clx_tm_handler_t handler,
                      const clx_stat_tm_t type);

/**
 * @brief This API is used to create a distribution counter for ingress interface (L2,
 *        L3, tunnel), egress interface (L2, L3, tunnel), domain (VLAN,
 *        FD, VRF) and flow (ingress ACL and egress ACL).
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [out]    ptr_cnt_id    - Counter logic ID.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - There is no counter to serve the cnt_type.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_stat_dist_cnt_create(const uint32 unit, uint32 *ptr_cnt_id);

/**
 * @brief This API is used to create a counter for interface (ingress, egress) or domain (forward
 *        domain, VRF), or flow (ingress ACL or egress ACL).
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit          - Device unit number.
 * @param [in]     ptr_cfg       - The type of counter.
 * @param [out]    ptr_cnt_id    - Counter ID.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return         CLX_E_TABLE_FULL       - There is no counter available.
 * @return         CLX_E_OTHERS           - Other errors.
 */
clx_error_no_t
clx_stat_srv_cnt_create(const uint32 unit,
                        const clx_stat_srv_cnt_cfg_t *ptr_cfg,
                        uint32 *ptr_cnt_id);

/**
 * @brief This API is used to destroy a distribution counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter logic ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_stat_dist_cnt_destroy(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to destroy a counter create via clx_stat_srv_cnt_create.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
clx_stat_srv_cnt_destroy(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to get a distribution counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     cnt_id     - Counter ID.
 * @param [out]    ptr_cnt    - Counter.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return         CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_stat_dist_cnt_get(const uint32 unit, const uint32 cnt_id, clx_stat_dist_cnt_t *ptr_cnt);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * The number of counters value return is determined by the type of counter under study.
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     cnt_id     - Counter ID.
 * @param [out]    ptr_cnt    - The return counter values.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
clx_stat_srv_cnt_get(const uint32 unit, const uint32 cnt_id, clx_stat_srv_cnt_t *ptr_cnt);

/**
 * @brief This API is used to get config of the counter under study.
 *
 * The number of counters value return is determined by the type of counter under study.
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     cnt_id     - Counter ID.
 * @param [out]    ptr_cfg    - The return counter values.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return         CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
clx_stat_srv_cnt_cfg_get(const uint32 unit, const uint32 cnt_id, clx_stat_srv_cnt_cfg_t *ptr_cfg);

/**
 * @brief This API is used to clear a distribution counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 * @return        CLX_E_OTHERS             - Other errors.
 */
clx_error_no_t
clx_stat_dist_cnt_clear(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit      - Device unit number.
 * @param [in]    cnt_id    - Counter ID.
 * @return        CLX_E_OK                 - Operation success.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The counter has not been created.
 */
clx_error_no_t
clx_stat_srv_cnt_clear(const uint32 unit, const uint32 cnt_id);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     rx_rsn_code    - RX reason code.
 * @param [out]    ptr_cnt        - The return counter values.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_reason_cnt_get(const uint32 unit, const clx_pkt_rx_reason_t rx_rsn_code, uint64 *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit           - Device unit number.
 * @param [in]    rx_rsn_code    - RX reason code.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_reason_cnt_clear(const uint32 unit, const clx_pkt_rx_reason_t rx_rsn_code);

/**
 * @brief This API is used to get value of the counter under study.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit        - Device unit number.
 * @param [in]     rsn_code    - RX reason code.
 * @param [out]    ptr_cnt     - The return counter values.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_hw_reason_cnt_get(const uint32 unit, const clx_pkt_hw_reason_t rsn_code, uint64 *ptr_cnt);

/**
 * @brief This API is used to clear value of the counter under study.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit        - Device unit number.
 * @param [in]    rsn_code    - RX reason code.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_hw_reason_cnt_clear(const uint32 unit, const clx_pkt_hw_reason_t rsn_code);

/**
 * @brief This API is used to trigger manually counter update to get latest counter value.
 *
 * The API takes time to collect latest counter please use it wisely.
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_SUPPORT      - This API is not support in this chip.
 */
clx_error_no_t
clx_stat_cnt_refresh(const uint32 unit);

#ifdef CLX_STAT_EN_HPC_CNT
/**
 * @brief This API is used to create HPC counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    cfg     - Cfg with polling time and FIFO size.
 * @return        CLX_E_OK                - Operation success.
 * @return        CLX_E_ALREADY_INITED    - Already initialized.
 * @return        CLX_E_BAD_PARAMETER     - Bad parameter.
 * @return        CLX_E_NO_MEMORY         - No memory.
 * @return        CLX_E_OTHER             - Other error.
 */
clx_error_no_t
clx_stat_hpc_create(const uint32 unit, const clx_stat_hpc_cfg_t cfg);

/**
 * @brief This API is used to destroy HPC counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NOT_INITED       - Not initialized.
 */
clx_error_no_t
clx_stat_hpc_destroy(const uint32 unit);

/**
 * @brief This API is used to dequeue HPC counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [out]    ptr_cnt    - The return counter values.
 * @return         CLX_E_OK                 - Operation success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry not found.
 * @return         CLX_E_NOT_INITED         - Not initialized.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
clx_error_no_t
clx_stat_hpc_dequeue(const uint32 unit, clx_stat_hpc_cnt_t *ptr_cnt);
#endif /* End of CLX_STAT_EN_HPC_CNT */

/**
 * @brief This API is used to get watermark counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit       - Device unit number.
 * @param [in]     port       - Port number.
 * @param [in]     handler    - Tm queue handler.
 * @param [out]    ptr_cnt    - The return counter values.
 * @return         CLX_E_OK               - Operation success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_hrm_watermark_get(const uint32 unit,
                           const uint32 port,
                           const clx_tm_handler_t handler,
                           uint32 *ptr_cnt);

/**
 * @brief This API is used to clear the watermark counter.
 *
 * Support_chip: CLX86.
 *
 * @param [in]    unit       - Device unit number.
 * @param [in]    port       - Port number.
 * @param [in]    handler    - Tm queue handler.
 * @return        CLX_E_OK               - Success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_hrm_watermark_clear(const uint32 unit, const uint32 port, const clx_tm_handler_t handler);

/**
 * @brief This API is used to get the watermark counter occupancy.
 *
 * Support_chip: CLX86.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     port             - Port number.
 * @param [in]     handler          - Tm queue handler.
 * @param [out]    ptr_occupancy    - Watermark counter occupancy.
 * @return         CLX_E_OK               - Success.
 * @return         CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
clx_stat_hrm_occupancy_get(const uint32 unit,
                           const uint32 port,
                           const clx_tm_handler_t handler,
                           uint32 *ptr_occupancy);
#endif /* End of CLX_STAT_H */
