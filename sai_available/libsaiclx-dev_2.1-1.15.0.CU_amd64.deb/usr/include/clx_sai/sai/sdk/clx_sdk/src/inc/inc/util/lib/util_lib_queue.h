/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  util_lib_queue.h
 * PURPOSE:
 *  this file is used to provide queue operations to other users.
 * NOTES:
 *  it contains operations as below:
 *      1. create a queue
 *      2. destroy a queue
 *      3. push one element to tail of a queue
 *      4. pop 1~N elements from head of a queue
 *      5. get usage(length) of a queue.
 *
 */
#ifndef UTIL_LIB_QUEUE_H
#define UTIL_LIB_QUEUE_H
/* INCLUDE FILE DECLARATIONS
 */

#include <util/lib/util_lib.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* the queue operation position */
typedef enum util_lib_queue_pos_e {
    UTIL_LIB_QUEUE_POS_HEAD = 0, /* operation position at head */
    UTIL_LIB_QUEUE_POS_TAIL,     /* operation position at tail */
    UTIL_LIB_QUEUE_POS_LAST,
} util_lib_queue_pos_t;

/* MACRO FUNCTION DECLARATIONS
 */
/* DATA TYPE DECLARATIONS
 */

/* the queue entry structure */
typedef struct util_lib_queue_entry_s {
    void *ptr_data; /* the user data saved in the entrys */
} util_lib_queue_entry_t;

/* FUNCTION TYPE NAME: util_lib_queue_destroy_func_t
 * PURPOSE:
 *      it is used to release user data saved in queue entry when destoy the
 *      queue.
 * INPUT:
 *      ptr_user_data  -- the queue element data will be released.
 * OUTPUT:
 *      None.
 * RETURN:
 *      None.
 * NOTES:
 *
 */
typedef void (*util_lib_queue_destroy_func_t)(void *ptr_user_data);

/* the queue head structure */
typedef struct util_lib_queue_s {
    int32 head_index;                   /* index of the queue head entry can be read  */
    int32 tail_index;                   /* index of the queue tail entry can be write */
    uint32 wr_cnt;                      /* enqueue total count                        */
    uint32 rd_cnt;                      /* dequeue total count                        */
    uint32 capacity;                    /* the queue size                             */
    util_lib_queue_entry_t *ptr_entrys; /* the queue entry buffer                  */
} util_lib_queue_t;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief it is used to create a new queue.
 *
 * @param [in]     capacity    - the queue capacity, it should be 1~N.
 * @param [in]     ptr_name    - the queue name, max length is UTIL_LIB_NAME_LEN_MAX(include '\0')
 * @param [out]    pptr_q      - the new queue head
 * @return         CLX_E_OK               - create success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_NO_MEMORY        - alloc queue head failed.
 */
clx_error_no_t
util_lib_queue_create(const uint32 capacity, const char *ptr_name, util_lib_queue_t **pptr_q);

/**
 * @brief it is used to destroy a queue and release queue head and resource,
 *        if destroy callback is not null, release entry data.
 *
 * @param [in]     ptr_q               - the queue will be destroyed.
 * @param [in]     destroy_callback    - destroy function, used to release entry data.
 * @return         CLX_E_OK               - destroy success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 */
clx_error_no_t
util_lib_queue_destroy(util_lib_queue_t *ptr_q,
                       const util_lib_queue_destroy_func_t destroy_callback);

/**
 * @brief enqueue only one queue entry to tail.
 *
 * @param [in]     ptr_q       - the queue will be pushed.
 * @param [in]     ptr_data    - the user data will be pushed.
 * @return         CLX_E_OK               - push success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_TABLE_FULL       - the queue is full.
 */
clx_error_no_t
util_lib_queue_enqueue(util_lib_queue_t *ptr_q, void *ptr_data);

/**
 * @brief dequeue queue entrys from head.
 *
 * the output datas is from head to tail.
 * eg:
 * tail| a, b, c|head
 * pop 2 elements from head, the output datas are:
 * [0]=c, [1]=b
 *
 * @param [in]     ptr_q         - the queue will be dequeued.
 * @param [in]     count         - the dequeue entry number.
 * @param [out]    pptr_datas    - the dequeued entry data pointers will be fill in this buffer.
 * @return         CLX_E_OK               - dequeue success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_OTHERS           - the entrys in the queue is not enough for popping.
 */
clx_error_no_t
util_lib_queue_dequeues(util_lib_queue_t *ptr_q, const uint32 count, void **pptr_datas);

/**
 * @brief dequeue only one queue entry from head or tail.
 *
 * @param [in]     ptr_q        - the queue will be dequeued.
 * @param [out]    pptr_data    - the popped entry data pointer.
 * @return         CLX_E_OK               - dequeue success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 * @return         CLX_E_OTHERS           - the queue is empty
 */
clx_error_no_t
util_lib_queue_dequeue(util_lib_queue_t *ptr_q, void **pptr_data);

/**
 * @brief it used to get the number of entry in the queue.
 *
 * @param [in]     ptr_q        - the queue will be get the number of entry.
 * @param [out]    ptr_count    - the count of queue entry.
 * @return         CLX_E_OK               - get count success.
 * @return         CLX_E_BAD_PARAMETER    - parameter pointer is null.
 */
clx_error_no_t
util_lib_queue_count_get(util_lib_queue_t *ptr_q, uint32 *ptr_count);

#endif /* End of UTIL_LIB_QUEUE_H */
