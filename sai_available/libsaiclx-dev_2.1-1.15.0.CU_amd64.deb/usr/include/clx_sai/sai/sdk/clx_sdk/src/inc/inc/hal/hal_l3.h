/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_l3.h
 * PURPOSE:
 *      It provides hal l3 module API.
 * NOTES:
 *
 *
 */
#ifndef HAL_L3_H
#define HAL_L3_H

/*****************************************************************************
 * INCLUDE FILE DECLARATIONS
 *****************************************************************************
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_swc.h>
#include <clx/clx_l3.h>
#include <util/util.h>
#include <util/lib/util_lib_avl.h>
#include <util/lib/util_lib_list.h>
#include <util/lib/util_lib_bit.h>
#include <util/lib/util_lib_bmp.h>
#include <hal/hal_tbl.h>
#include <hal/hal_io.h>
#include <hal/hal_vlan.h>

/*****************************************************************************
 * NAMING CONSTANT DECLARATIONS
 *****************************************************************************
 */
#define HAL_L3_ECMP_SW_MODE_SYNC (1)
#define HAL_L3_RPF_NUM           (16384)
#define HAL_L3_TAPPING_DISABLE   (0)

#define HAL_L3_ERRO(TYPE, ...) UTIL_LOG_PRINT(UTIL_LOG_L3_##TYPE, UTIL_LOG_ERR, ##__VA_ARGS__)
#define HAL_L3_WARN(TYPE, ...) UTIL_LOG_PRINT(UTIL_LOG_L3_##TYPE, UTIL_LOG_WARN, ##__VA_ARGS__)
#define HAL_L3_INFO(TYPE, ...) UTIL_LOG_PRINT(UTIL_LOG_L3_##TYPE, UTIL_LOG_INFO, ##__VA_ARGS__)

/* MTU */
#define HAL_L3_MTU_SIZE (16383)

/* VRF */
#define HAL_L3_VRF_ADMIN_STATE_ENABLE  (1)
#define HAL_L3_VRF_ADMIN_STATE_DISABLE (0)

/* ADJ */
#define HAL_L3_FRR_INVALID_GRP_ID (0xFFFFFFFF)
#define HAL_L3_RESERVE_ADJ_ID     (0)

#define HAL_L3_ID_DETACH(id, type, idx)                                                    \
    do {                                                                                   \
        (idx) = ((id) & 0xFFFFFF);                                                         \
        (type) = (((id) >> 24) & 0xFF);                                                    \
        if (type >= (uint32)CLX_NHP_TYPE_LAST) {                                           \
            osal_printf("%s, %d: id %u type %u invalid\n", __func__, __LINE__, idx, type); \
        }                                                                                  \
    } while (0)

#define HAL_L3_ID_GET_TYPE(id) (((id) >> 24) & 0xFF)
#define HAL_L3_ID_IS_TNL(id)   (HAL_L3_ID_GET_TYPE(id) == (uint32)CLX_L3_ADJ_TYPE_TNL)
#define HAL_L3_ID_CHECK_TNL(id)         \
    do {                                \
        if (!HAL_L3_ID_IS_TNL(id)) {    \
            return CLX_E_BAD_PARAMETER; \
        }                               \
    } while (0)

/* Route */
#define HAL_L3_ROUTE_ROOT_WORD_NUM (4)  /* Word32 num */
#define HAL_L3_ROUTE_ROOT_BYTE_NUM (16) /* Byte num */
#define HAL_L3_ROUTE_TRIE_BIT_MAX  (31) /* trie bit num */

#define HAL_L3_ROUTE_INSERT_TCAM (0)    /* tcam hw      */
#define HAL_L3_ROUTE_INSERT_HASH (1)    /* hash hw      */

#define HAL_L3_ROUTE_INSERT_MODE (0)    /* alloc iev for insert      */
#define HAL_L3_ROUTE_DELETE_MODE (1)    /* alloc iev fot delete      */

/* ECMP */
#define HAL_L3_ECMP_PATH_DFLT_TOT (0) /* default act_tot or orig_tot   */

/* MCAST */
#define HAL_L3_MCAST_PER_GROUP_PER_PORT_MAX_EGR_INTF_NUM (8192)

#if defined(CLX_EN_COMPILER_SUPPORT_LONG_LONG)
#define UI64_RSHIFT(dst, shift) ((dst) >>= (shift))
#define UI64_LSHIFT(dst, shift) ((dst) <<= (shift))
#else
#define UI64_RSHIFT(dst, shift)                             \
    do {                                                    \
        if (64 == (shift)) {                                \
            UI64_LOW(dst) = 0;                              \
            UI64_HI(dst) = 0;                               \
        } else if ((shift) >= 32) {                         \
            UI64_LOW(dst) = UI64_HI(dst) >> ((shift) - 32); \
            UI64_HI(dst) = 0;                               \
        } else if ((shift) > 0) {                           \
            uint32 temp = 0;                                \
            UI64_LOW(dst) >>= (shift);                      \
            temp = UI64_HI(dst) & ((1U << (shift)) - 1);    \
            UI64_LOW(dst) |= temp << (32 - (shift));        \
            UI64_HI(dst) >>= (shift);                       \
        }                                                   \
    } while (0)

#define UI64_LSHIFT(dst, shift)                             \
    do {                                                    \
        if (64 == (shift)) {                                \
            UI64_HI(dst) = 0;                               \
            UI64_LOW(dst) = 0;                              \
        } else if ((shift) >= 32) {                         \
            UI64_HI(dst) = UI64_LOW(dst) << ((shift) - 32); \
            UI64_LOW(dst) = 0;                              \
        } else if ((shift) > 0) {                           \
            uint32 temp = 0;                                \
            UI64_HI(dst) <<= (shift);                       \
            temp = UI64_LOW(dst) & (~(32 - (shift)));       \
            UI64_HI(dst) |= temp >> (32 - (shift));         \
            UI64_LOW(dst) <<= (shift);                      \
        }                                                   \
    } while (0)

#endif

/*****************************************************************************
 * MACRO FUNCTION DECLARATIONS
 *****************************************************************************
 */
/* Checker */
#define HAL_L3_IP_IS_MULTICAST(ptr_ip)                                               \
    ((TRUE == (ptr_ip)->ipv4) ? CLX_IPV4_IS_MULTICAST((ptr_ip)->ip_addr.ipv4_addr) : \
                                CLX_IPV6_IS_MULTICAST((ptr_ip)->ip_addr.ipv6_addr))

#define HAL_L3_IP_IS_ZERO(ptr_ip)                  \
    ((TRUE == (ptr_ip)->ipv4) ?                    \
         (0x0 == (ptr_ip)->ip_addr.ipv4_addr) :    \
         (0x0 == (ptr_ip)->ip_addr.ipv6_addr[0] && \
          0 == osal_memcmp((ptr_ip)->ip_addr.ipv6_addr, (ptr_ip)->ip_addr.ipv6_addr + 1, 15)))

#define HAL_L3_IP_MASK_IS_ZERO(ptr_ip)             \
    ((TRUE == (ptr_ip)->ipv4) ?                    \
         (0x0 == (ptr_ip)->ip_mask.ipv4_addr) :    \
         (0x0 == (ptr_ip)->ip_mask.ipv6_addr[0] && \
          0 == osal_memcmp((ptr_ip)->ip_mask.ipv6_addr, (ptr_ip)->ip_mask.ipv6_addr + 1, 15)))

#define HAL_L3_IP_MASK_IS_FULLMSK(ptr_ip)               \
    ((TRUE == (ptr_ip)->ipv4) ?                         \
         (0xFFFFFFFFU == (ptr_ip)->ip_mask.ipv4_addr) : \
         (0xFF == (ptr_ip)->ip_mask.ipv6_addr[0] &&     \
          0 == osal_memcmp((ptr_ip)->ip_mask.ipv6_addr, (ptr_ip)->ip_mask.ipv6_addr + 1, 15)))

#define HAL_L3_CHK_IP_VER_MATCH(ip1, ip2)         \
    do {                                          \
        if ((ip1).ipv4 != (ip2).ipv4) {           \
            HAL_CHECK_ERROR(CLX_E_BAD_PARAMETER); \
        }                                         \
    } while (0)

#define HAL_L3_CHK_FLW_LBL(__unit__, __tbl_id__, __field_id__, __flw_lbl__)                        \
    do {                                                                                           \
        if (!HAL_IS_UI32_FLD_RANGE_VALID(__unit__, __tbl_id__, __field_id__, __flw_lbl__)) {       \
            UTIL_LOG_PRINT(UTIL_LOG_L3, UTIL_LOG_WARN, "u=%u, invalid group_label=%d\n", __unit__, \
                           __flw_lbl__);                                                           \
            return CLX_E_BAD_PARAMETER;                                                            \
        }                                                                                          \
    } while (0)

/* utility */
#define HAL_L3_PLANE_BMP_FOREACH(__unit__, __plane__)                           \
    for ((__plane__) = 0; (__plane__) < HAL_PLANE_NUM(__unit__); (__plane__)++) \
        if (UTIL_LIB_BMP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane__)))

#define HAL_L3_ERROR_RETRUN(module, rc, fmt, args...)                                            \
    {                                                                                            \
        if (CLX_E_OK != rc) {                                                                    \
            UTIL_LOG_PRINT(module, UTIL_LOG_ERR, "[error:%s-%d]:" fmt, clx_error_string_get(rc), \
                           rc, ##args);                                                          \
            return rc;                                                                           \
        }                                                                                        \
    }

#define HAL_L3_ERROR_NO_RETRUN(module, rc, fmt, args...)                                         \
    {                                                                                            \
        if (CLX_E_OK != rc) {                                                                    \
            UTIL_LOG_PRINT(module, UTIL_LOG_ERR, "[error:%s-%d]:" fmt, clx_error_string_get(rc), \
                           rc, ##args);                                                          \
        }                                                                                        \
    }

#define HAL_L3_WARN_NO_RETRUN(module, rc, fmt, args...)                                          \
    {                                                                                            \
        if (CLX_E_OK != rc) {                                                                    \
            UTIL_LOG_PRINT(module, UTIL_LOG_WARN, "[warn:%s-%d]:" fmt, clx_error_string_get(rc), \
                           rc, ##args);                                                          \
        }                                                                                        \
    }

#define HAL_L3_ERROR_GOTO_LABEL(module, rc, label, fmt, args...)                                 \
    {                                                                                            \
        if (CLX_E_OK != rc) {                                                                    \
            UTIL_LOG_PRINT(module, UTIL_LOG_ERR, "[error:%s-%d]:" fmt, clx_error_string_get(rc), \
                           rc, ##args);                                                          \
            goto label;                                                                          \
        }                                                                                        \
    }

#define HAL_L3_MC_PORT_VALID(port_type)                                           \
    ((CLX_GPORT_TYPE_LAG == (port_type) || CLX_GPORT_TYPE_LOCAL == (port_type) || \
      CLX_GPORT_TYPE_UNIT_PORT == (port_type)) ?                                  \
         TRUE :                                                                   \
         FALSE)
/*****************************************************************************
 * DATA TYPE DECLARATIONS
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- Common */
/* Dump SWDB */
typedef enum {
    HAL_L3_DB_DUMP_FLAGS_INTF = 0,
    HAL_L3_DB_DUMP_FLAGS_HOST,
    HAL_L3_DB_DUMP_FLAGS_ROUTE,
    HAL_L3_DB_DUMP_FLAGS_ADJ,
    HAL_L3_DB_DUMP_FLAGS_ECMP,
    HAL_L3_DB_DUMP_FLAGS_MCAST,
    HAL_L3_DB_DUMP_FLAGS_VRF,
    HAL_L3_DB_DUMP_FLAGS_RMAC,
    HAL_L3_DB_DUMP_FLAGS_LAST,
} hal_l3_db_dump_flags_t;
/* ----------------------------------------------------------------------------------- INTF */
typedef struct hal_l3_intf_rsrc_s {
    /* resources waited to be free */
    uint32 ids_mtu_idx;    /* l3_mtu_idx       : IDS_RSLT_L3_MTU        */
    uint32 ids_prof_idx;   /* cnt_mtr_prof_idx : ICIA_RSLT_CNT|CLR_PROF */
    uint32 iev_mtu_idx;    /* l3_mtu_idx       : IEV_RSLT_L3_MTU        */
    uint32 igr_sflw_idx;   /* sflw_idx */
    uint32 igr_hw_mtr_idx; /* mtr_idx */
    uint32 igr_hw_cnt_idx;
    uint32 igr_hw_dist_cnt_idx;
    uint32 emi_sa_idx;     /* l2_sa_idx        : EMI_RSLT_MAC_SA        */
    uint32 emi_mtu_idx;    /* l3_mtu_idx       : EMI_RSLT_L3_MTU        */
    uint32 emi_prof_idx;   /* cnt_mtr_prof_idx : ECIA_RSLT_CNT|CLR_PROF */
    uint32 egr_sflw_idx;   /* sflw_idx */
    uint32 egr_hw_mtr_idx; /* mtr_idx */
    uint32 egr_hw_cnt_idx;
    uint32 egr_hw_dist_cnt_idx;

    /* when these fields are changed, traverse ADJ to find (ecmp|frr, intf) */
    uint32 urpf_mode;
    uint32 icmpv4_redir;
    uint32 icmpv6_redir;

} hal_l3_intf_rsrc_t;

typedef struct hal_l3_intf_mtu_cfg_s {
    boolean mtu_vld; /* Valid */
    uint32 mtu;      /* L3 MTU size */
    uint32 use_num;  /* Reference count of MTU */

} hal_l3_intf_mtu_cfg_t;

typedef struct hal_l3_intf_cb_s {
    uint32 iev_l2uc_drop_idx; /* Hit my_rte_mac but HW can't route */
    uint32 *ptr_intf2fdid;    /* Array of l3 interface */
    uint32 *ptr_intf2vrf;     /* Array of vrf */
    uint32 *ptr_fdid2intf;    /* Array of bdid */
    clx_semaphore_id_t sema;

} hal_l3_intf_cb_t;

/* ----------------------------------------------------------------------------------- VRF */
typedef struct hal_l3_vrf_cb_s {
    uint32 *ptr_ipv4_state_bmp; /* VRF admin state. 0: diable, 1: enable */
    uint32 *ptr_ipv6_state_bmp; /* VRF admin state. 0: diable, 1: enable */
    clx_semaphore_id_t sema;
} hal_l3_vrf_cb_t;

/* ----------------------------------------------------------------------------------- ADJ */
typedef struct hal_l3_adj_cb_s {
    util_lib_avl_head_t *ptr_avl; /* util_lib_avl_insert(hal_l3_adj_node_t) when addAdj()
                                   * util_lib_avl_delete(hal_l3_adj_node_t) when delAdj()
                                   * util_lib_list_insert_to_tail(uint32) when addGrpList() of ECMP
                                   * and FRR util_lib_list_node_delete_by_data(uint32) when
                                   * delGrpList() of ECMP and FRR
                                   */
    uint32 *ptr_urpf_use_num;
    clx_semaphore_id_t sema;

} hal_l3_adj_cb_t;

typedef struct hal_l3_adj_node_s {
    /* AVL key */
    uint32 adj_id; /* hw adj index           */

    /* AVL data */
    uint32 iev_idx;                 /* hw iev index           */
    uint32 frr_idx;                 /* hw frr addr, only valid for nb */
    uint32 mpls_en;                 /* sw mpls en, only valid for nb */
    util_lib_list_t *ptr_ecmp_list; /* hw ecmp group-id list  */
    util_lib_list_t *ptr_frr_list;  /* hw frr group-id list of this backup adj */
    uint32 use_num;                 /* reference count of host, route, ecmp, and frr */
    clx_port_t port;                /* interface object        */
    uint32 hw_mac[2];               /* hw dst mac              */
    uint32 intf_id;                 /* intf                    */
    uint32 is_drop;                 /* blackhole               */

} hal_l3_adj_node_t;

typedef struct hal_l3_adj_info_s {
    uint32 adj_id;    /* hw adj index,fpu_idx for mt                  */
    uint32 iev_idx;   /* hw iev index                                 */
    uint32 intf_id;   /* hw intf index                                */
    uint32 ueid_mgid; /* hw ueid_mgid                                 */
    uint32 drop;      /* black hole                                   */
    uint32 frr_id;    /* frr group id, means frr hw addr nb           */
    uint32 use_num;   /* reference count of host, route, ecmp, and frr */
    clx_port_t port;  /* interface object                              */

    uint32 hw_mac[2]; /* hw dst mac, only valid for nb                 */
    uint32 mpls_en;   /* sw mpls_en, only valid for nb                 */

} hal_l3_adj_info_t;

typedef struct hal_l3_adj_trav_cookie_s {
    uint32 unit;

    /* [Out] for traverseAdj() API, store the TRAV_DATA in list */
    util_lib_list_t *ptr_list;

    /* [In] for travGrpUpdateUrpf(), add or del ECMP/FRR uRPF when change intf urpf_mode */
    uint32 bdid;
    uint32 is_add;

} hal_l3_adj_trav_cookie_t;

typedef struct hal_l3_adj_trav_data_s {
    uint32 adj_id;
    clx_l3_adj_t adj_info;

} hal_l3_adj_trav_data_t;

/* ----------------------------------------------------------------------------------- ECMP */
typedef struct hal_l3_ecmp_s {
    uint32 grp_id;                    /* hw ecmp group index    */
    clx_l3_ecmp_algo_mode_t grp_mode; /* hw ecmp group mode     */
    clx_nhp_type_t grp_type;          /* hw ecmp group type     */
    uint32 iev_idx;                   /* hw iev index           */
    uint32 decr_ttl;                  /* flag for decr ttl      */
    uint32 urpf_en;                   /* flag for strict urpf   */
    uint32 path_cnt;
    uint32 weight_cnt;
    uint32 weight_vld;  /* only update weight_cnt when this field is 1 */
    uint32 use_num;     /* reference count of host, route */
    uint32 real_size;   /* real hash buckets for fine grain ECMP */
    uint32 use_default; /* insert default path */
    uint32 order_mode;  /* order ecmp */
} hal_l3_ecmp_t;

typedef enum hal_l3_trans_ecmp_type_e {
    HAL_L3_TRANS_ECMP_L2_TO_L3 = 0, /* trans l3 hal to clx info */
    HAL_L3_TRANS_ECMP_L3_TO_L2 = 1, /* trans l3 clx to hal info */
    HAL_L3_TRANS_ECMP_TYPE_LAST
} hal_l3_trans_ecmp_type_t;
/* ----------------------------------------------------------------------------------- HOST */
/* ----------------------------------------------------------------------------------- ROUTE */
typedef struct hal_l3_route_trav_sw_cookie_s {
    uint32 unit;

    /* now only counter flag */
    uint32 counter_only;
    uint32 root_count;
    uint32 detail_en;

} hal_l3_route_trav_sw_cookie_t;
/* ----------------------------------------------------------------------------------- MCAST */
/* Mcast Egress Interface */
typedef struct hal_l3_mcast_mel_sub_entry_s {
    /* ETM_RSLT_MEL_INFO */
    uint32 src_supp_ck_vid;
    uint32 src_supp_tag;
    HAL_VLAN_VID_CTL_T vid_info;

    /* EMI_RSLT_MC_SC */
    uint32 nvo3_adj_idx;
    uint32 nvo3_encap_idx;
    uint32 seg_vmid;

} hal_l3_mcast_mel_sub_entry_t;

/* DF Interface */
typedef struct hal_l3_mcast_rpa_node_s {
    /* AVL key */
    clx_ip_addr_t rp_addr;

    /* AVL data */
    uint32 rp_id;
    uint32 use_num;

} hal_l3_mcast_rpa_node_t;

typedef struct hal_l3_mcast_rpa_trav_cookie_s {
    uint32 unit;

    /* [In] for getDfIntf() API, get all RPAs from intf ID */
    uint32 intf_id;
    uint32 cnt;
    uint32 real_cnt;

    /* [In] for getGroup() API, get RPA from RP-ID */
    uint32 rp_id;

    /* [Out] RPA */
    clx_ip_addr_t *ptr_rp_addr;

} hal_l3_mcast_rpa_trav_cookie_t;

typedef struct hal_l3_mcast_egr_intf_s {
    clx_l3_mcast_egr_intf_type_t intf_type; /* type of mcast egr interface */
    uint32 intf_id;                         /* egr l3if id */
    clx_port_t port_id;                     /* the egress port id */
    union {
        clx_l3_mcast_egr_intf_tnl_t tnl;    /* egr setting for intf of nvo3 */
        clx_l3_mcast_egr_intf_mpls_t mpls;  /* egr setting for intf of mpls */
    };
} hal_l3_mcast_egr_intf_t;

/* ----------------------------------------------------------------------------------- Function */
typedef clx_error_no_t (*HAL_L3_ECMP_CALLBACK_FUNC_T)(const uint32 unit,
                                                      const uint32 adj_id,
                                                      const uint32 ecmp_grp_id,
                                                      const void *ptr_cookie);

typedef clx_error_no_t (*hal_l3_frr_cb_func_t)(const uint32 unit,
                                               const uint32 adj_id,
                                               const uint32 frr_grp_id,
                                               const void *ptr_cookie);
typedef struct hal_l3_frr_s {
    clx_l3_frr_type_t type;
    uint32 pri_nhp_id;
    uint32 bak_nhp_id;
    uint32 state;
} hal_l3_frr_t;

/*****************************************************************************
 * LOCAL SUBPROGRAM BODIES
 *****************************************************************************
 */
/* ----------------------------------------------------------------------------------- MAIN */
/* Utility */
clx_error_no_t
hal_l3_bmp_dump(const uint32 *ptr_bmp, const uint32 bmp_cnt);

uint32
hal_l3_hit_value_get(const uint32 val, const uint32 offset, const uint32 length);

void
hal_l3_hit_value_set(const uint32 offset, const uint32 length, const uint32 value, uint32 *ptr_val);

void
hal_l3_hit_value_clr(const uint32 offset, const uint32 length, uint32 *ptr_val);

/* DMA */
clx_error_no_t
hal_l3_tbl_dma_move(const uint32 unit,
                    const uint32 tbl_id,
                    const boolean delete_offset,
                    const uint32 offset,
                    const uint32 base_old,
                    const uint32 num_old,
                    const uint32 base_new);

clx_error_no_t
hal_l3_tbl_dma_clear(const uint32 unit,
                     const uint32 tbl_id,
                     const uint32 clear_base,
                     const uint32 clear_num);

/* Properties */

/* Exceptions */

/* Chip Dispatcher */

/* Init and Deinit */

/* Dump SWDB */

/* ----------------------------------------------------------------------------------- INTF */

/* ----------------------------------------------------------------------------------- VRF */

/* ----------------------------------------------------------------------------------- ADJ */

clx_error_no_t
hal_l3_adj_grp_list_add(/* for addEcmpPath, addNvo3EcmpPath, addFrrPath, setFrrPath */
                        const uint32 grp_id,
                        util_lib_list_t *ptr_list);

clx_error_no_t
hal_l3_adj_grp_list_del(/* for delEcmp, delNvo3Ecmp, delEcmpPath, delNvo3EcmpPath, delFrrPath,
                         setFrrPath */
                        const uint32 grp_id,
                        util_lib_list_t *ptr_list);

/* traverse ECMP, nvo3-ECMP or FRR group-list by adj-id */
clx_error_no_t
hal_l3_adj_grp_list(/* for setAdj, setNvo3Adj */
                    const uint32 unit,
                    util_lib_list_t *ptr_list,
                    const uint32 adj_id,
                    void *ptr_cookie,
                    hal_l3_frr_cb_func_t callback);

/* ----------------------------------------------------------------------------------- ECMP */
clx_error_no_t
hal_l3_ecmp_path_hsh_calc(const uint32 unit,
                          const clx_swc_hsh_pkt_type_t hash_type,
                          const clx_swc_flow_hsh_key_t *ptr_hash_key,
                          const uint32 ecmp_grp_id,
                          clx_l3_ecmp_path_hsh_rslt_t *ptr_rslt);

/* ----------------------------------------------------------------------------------- HOST */

/* ----------------------------------------------------------------------------------- ROUTE */

/* ----------------------------------------------------------------------------------- MCAST */

#endif /* End of HAL_L3_H */
