/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:   hal_mt_mac.h
 * PURPOSE:
 *      It provide MAC APIs.
 * NOTES:
 */

#ifndef HAL_MT_MAC_H
#define HAL_MT_MAC_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx/clx_error.h>
#include <clx/clx_types.h>
#include <clx/clx_port.h>
#include <hal/hal_mac.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_MT_MAC_IPG_BIAS_DFLT    (4)
#define HAL_MT_MAC_IPG_BIAS_DISABLE (0)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_MT_MAC_TX_PAUSE_STATE_XOFF = 0x1,
    HAL_MT_MAC_TX_PAUSE_STATE_XON,
    HAL_MT_MAC_TX_PAUSE_STATE_LAST
} HAL_MT_MAC_TX_PAUSE_STATE_T;

typedef enum {
    HAL_MT_MAC_TX_CTRL_STATE_IDLE = 0,
    HAL_MT_MAC_TX_CTRL_STATE_PKT,
    HAL_MT_MAC_TX_CTRL_STATE_PAUSE,
    HAL_MT_MAC_TX_CTRL_STATE_FAULT = 5,
    HAL_MT_MAC_TX_CTRL_STATE_LPI = 6,
    HAL_MT_MAC_TX_CTRL_STATE_LAST
} HAL_MT_MAC_TX_CTRL_STATE_T;

typedef enum {
    HAL_MT_MAC_STATUS_TX_FIFO_EMPTY = 0,
    HAL_MT_MAC_STATUS_RX_LOC_FAULT,
    HAL_MT_MAC_STATUS_RX_REM_FAULT,
    HAL_MT_MAC_STATUS_RX_LFC_STS,
    HAL_MT_MAC_STATUS_RX_PFC_STS,
    HAL_MT_MAC_STATUS_TX_PAUSE_STATE,
    HAL_MT_MAC_STATUS_TX_PFC_STATE,
    HAL_MT_MAC_STATUS_TX_CTRL_STATE,
    HAL_MT_MAC_STATUS_TXCLKPRESENTALL,
    HAL_MT_MAC_STATUS_RXCLKPRESENTALL,
    HAL_MT_MAC_STATUS_RXSIGOKALL,
    HAL_MT_MAC_STATUS_BLOCKLOCKALL,
    HAL_MT_MAC_STATUS_DRVOCKALL,
    HAL_MT_MAC_STATUS_ALIGNED,
    HAL_MT_MAC_STATUS_NOHIBER,
    HAL_MT_MAC_STATUS_NOLOCALFAULT,
    HAL_MT_MAC_STATUS_NOREMOTEFAULT,
    HAL_MT_MAC_STATUS_LINKUP,
    HAL_MT_MAC_STATUS_HISER,
    HAL_MT_MAC_STATUS_FECDEGSER,
    HAL_MT_MAC_STATUS_RXAMSF,
    HAL_MT_MAC_STATUS_SUPERJABBER,
    HAL_MT_MAC_STATUS_LAST
} HAL_MT_MAC_STATUS_T;

typedef enum {
    HAL_MT_MAC_SYNCE_MODE_0 = 0,
    HAL_MT_MAC_SYNCE_MODE_1,
    HAL_MT_MAC_SYNCE_MODE_LAST

} HAL_MT_MAC_SYNCE_MODE_T;

typedef enum {
    HAL_MT_MAC_PORT_CTRL_TX_CG_EN = 0,
    HAL_MT_MAC_PORT_CTRL_RX_CG_EN,
    HAL_MT_MAC_PORT_CTRL_PKTGEN_CG_EN,
    HAL_MT_MAC_PORT_CTRL_PTP_CG_EN,
    HAL_MT_MAC_PORT_CTRL_TX_RST_B,
    HAL_MT_MAC_PORT_CTRL_RX_RST_B,
    HAL_MT_MAC_PORT_CTRL_PKTGEN_RST_B,
    HAL_MT_MAC_PORT_CTRL_PTP_RST_B,
    HAL_MT_MAC_PORT_CTRL_LAST
} HAL_MT_MAC_PORT_CTRL_T;

typedef enum {
    HAL_MT_MAC_CHANNEL_CTRL_TXFIFO_CG_EN = 0,
    HAL_MT_MAC_CHANNEL_CTRL_RX_CG_EN,
    HAL_MT_MAC_CHANNEL_CTRL_TXFIFO_RST_B,
    HAL_MT_MAC_CHANNEL_CTRL_RX_RST_B,
    HAL_MT_MAC_CHANNEL_CTRL_LAST
} HAL_MT_MAC_CHANNEL_CTRL_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief Initialize MAC function of all ports.
 *
 * @param [in]    unit    - Chip id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_init(const uint32 unit);

/**
 * @brief Deinitialize MAC function of all ports.
 *
 * @param [in]    unit    - Chip id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_deinit(const uint32 unit);

/**
 * @brief To set default MTU for a specific port.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_dft_mtu_set(const uint32 unit, const uint32 port);

/**
 * @brief Initialize MAC function of one port.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_port_init(const uint32 unit, const uint32 port);

/**
 * @brief Deinitialize MAC function of one port.
 *
 * @param [in]    unit    - Chip id.
 * @param [in]    port    - Port id.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_port_deinit(const uint32 unit, const uint32 port);

/**
 * @brief To set port link flow control.
 *
 * @param [in]    unit         - Chip id.
 * @param [in]    port         - Port id.
 * @param [in]    flow_ctrl    - Flow control type.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_flow_ctrl_set(const uint32 unit, const uint32 port, const clx_port_fc_dir_t flow_ctrl);

/**
 * @brief To get port link flow control.
 *
 * @param [in]     unit             - Chip id.
 * @param [in]     port             - Port id.
 * @param [out]    ptr_flow_ctrl    - Flow control type.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_flow_ctrl_get(const uint32 unit, const uint32 port, clx_port_fc_dir_t *ptr_flow_ctrl);

/**
 * @brief To set the PFC configuration for a specific port.
 *
 * @param [in]    unit         - Chip id.
 * @param [in]    port         - Port id.
 * @param [in]    flow_ctrl    - Flow control type.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_pri_flow_ctrl_set(const uint32 unit,
                             const uint32 port,
                             const clx_port_fc_dir_t flow_ctrl);

/**
 * @brief To get the PFC configuration for a specific port.
 *
 * @param [in]     unit             - Chip id.
 * @param [in]     port             - Port id.
 * @param [in]     pri              - Priority number 0~7.
 * @param [out]    ptr_flow_ctrl    - Flow control type.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_pri_flow_ctrl_get(const uint32 unit,
                             const uint32 port,
                             const uint8 pri,
                             clx_port_fc_dir_t *ptr_flow_ctrl);

/**
 * @brief Get port ability.
 *
 * @param [in]     unit           - Chip id.
 * @param [in]     port           - Port id.
 * @param [out]    ptr_ability    - Port ability.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_ability_get(const uint32 unit, const uint32 port, clx_port_ability_t *ptr_ability);

/**
 * @brief Update mac egress TS latency.
 *
 * @param [in]    unit       - Chip id.
 * @param [in]    port       - Port id.
 * @param [in]    latency    - Latency of egress.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_ts_tx_latency_update(const uint32 unit, const uint32 port, const uint32 latency);

/**
 * @brief Update mac Igress TS latency.
 *
 * @param [in]    unit       - Chip id.
 * @param [in]    port       - Port id.
 * @param [in]    latency    - Latency of egress.
 * @return        CLX_E_OK        - Operate success.
 * @return        CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_ts_rx_latency_update(const uint32 unit, const uint32 port, const uint32 latency);

/**
 * @brief To get mac status.
 *
 * @param [in]     unit          - Chip id.
 * @param [in]     port          - Port id.
 * @param [in]     status        - Status type.
 * @param [out]    ptr_param0    - Pfc/Fc status.
 * @param [out]    ptr_param1    - Reserved.
 * @return         CLX_E_OK        - Operate success.
 * @return         CLX_E_OTHERS    - Error occurs.
 */
clx_error_no_t
hal_mt_mac_status_get(const uint32 unit,
                      const uint32 port,
                      const HAL_MT_MAC_STATUS_T status,
                      uint32 *ptr_param0,
                      uint32 *ptr_param1);

/**
 * @brief To get status string.
 *
 * @param [in]    status    - Status type.
 * @return        Status string.
 */
const char *
hal_mt_mac_status_str_get(const HAL_MT_MAC_STATUS_T status);

/**
 * @brief To check if mac status is right.
 *
 * @param [in]    unit         - Chip id.
 * @param [in]    port         - Port id.
 * @param [in]    sts_type     - Status type.
 * @param [in]    sts_value    - Status value.
 * @return        CLX_E_OK         - Operate success.
 * @return        CLX_E_OTHERS     - Error occurs.
 * @return        CLX_E_TIMEOUT    - Operate timeout.
 */
clx_error_no_t
hal_mt_mac_status_check(const uint32 unit,
                        const uint32 port,
                        const HAL_MT_MAC_STATUS_T sts_type,
                        const uint32 sts_value);

#endif /* End of HAL_MT_MAC_H */
