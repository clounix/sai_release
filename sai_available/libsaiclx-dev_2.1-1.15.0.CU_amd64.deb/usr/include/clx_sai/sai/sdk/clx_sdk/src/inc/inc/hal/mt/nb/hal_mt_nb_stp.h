/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_nb_stp.h
 * PURPOSE:
 *  Define STP module HAL function.
 *
 * NOTES:
 *
 */
#ifndef HAL_MT_NB_STP_H
#define HAL_MT_NB_STP_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_stp.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_STP_ATTACH_OBJ_TYPE_VLANID = 0,
    HAL_STP_ATTACH_OBJ_TYPE_BDID,
    HAL_STP_ATTACH_OBJ_TYPE_LAST
} HAL_STP_ATTACH_OBJ_TYPE_T;

typedef struct {
    HAL_STP_ATTACH_OBJ_TYPE_T type;
    uint32 vlanid;
    uint32 bdid;
} HAL_STP_ATTACH_OBJ_T;

typedef enum {
    HAL_STP_DIRECTION_INGRESS = 0,
    HAL_STP_DIRECTION_EGRESS = 1,
    HAL_STP_DIRECTION_LAST
} HAL_STP_DIRECTION;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/******************************************************************************/
/* hal multiplexing api                                                       */
/******************************************************************************/

/**
 * @brief Initialize the STP module. In the initialization process, it will create the STG 0,
 *        and set the port state to be "forward" or "discard" for all ports in STG 0 according to
 *        user's choose.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_NO_MEMORY        - No available memory.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stp_init(const uint32 unit);

/**
 * @brief Deinitialize the STP module.
 *
 * @param [in]    unit    - Device unit number.
 * @return        CLX_E_OK               - Operation success.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 * @return        CLX_E_OTHERS           - Operation failed.
 */
clx_error_no_t
hal_mt_nb_stp_deinit(const uint32 unit);

/**
 * @brief Apply default stp related properties for the new created port: (1) Set port state to
 *        forward on default stp group.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Operate fail.
 */
clx_error_no_t
hal_mt_nb_stp_portdefault_set(const uint32 unit, const uint32 port);

/**
 * @brief Reset default stp related properties for the deleted port: (1) Set port state to discard
 *        on default stp.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    port    - Port number.
 * @return        CLX_E_OK       - Operate success.
 * @return        CLX_E_OTHER    - Operate fail.
 */
clx_error_no_t
hal_mt_nb_stp_portdefault_reset(const uint32 unit, const uint32 port);

/**
 * @brief Create a new STG.
 *
 * This API is used to create a new STG. The stgid can be specified
 * by user or automatically assigned by the software.
 * STG 0 has been created in STP module initialization process, and
 * it should not be created again.
 * support_chip all.
 *
 * @param [in]    unit    - Device unit number.
 * @param [in]    flag    - Flag to specify the operation @param [in, out] ptr_stgid - Pointer to
 *                          stgid.
 * @return        CLX_E_OK               - Operate success.
 * @return        CLX_E_ENTRY_EXISTS     - Entry already exists.
 * @return        CLX_E_BAD_PARAMETER    - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stp_create(const uint32 unit, const uint32 flag, uint32 *ptr_stgid);

/**
 * @brief Destroy a STG with user specified STG ID.
 *
 * If the STG ID is bound to some Bridge Domains, user should
 * bind them to other existing STG(s) before destroying this STG.
 * clx_bd_cfg_set is used to bind a STG to a Bridge Domain.
 * STG 0 is always active and should not be deleted.
 * support_chip all.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    stgid    - STG ID which will be deleted.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry does not exist.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stp_destroy(const uint32 unit, const uint32 stgid);

/**
 * @brief Set the STP state of a specified port.
 *
 * Support_chip: all.
 *
 * @param [in]    unit         - Device unit number.
 * @param [in]    stgid        - STG ID.
 * @param [in]    port         - Port ID.
 * @param [in]    stp_state    - Stp state.
 * @return        CLX_E_OK                 - Operate success.
 * @return        CLX_E_ENTRY_NOT_FOUND    - Entry does not exist.
 * @return        CLX_E_BAD_PARAMETER      - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stp_portstate_set(const uint32 unit,
                            const uint32 stgid,
                            const uint32 port,
                            const clx_stp_state_t stp_state);

/**
 * @brief Get the STP state for a specified port.
 *
 * Support_chip: all.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     stgid            - STG ID.
 * @param [in]     port             - Port ID.
 * @param [out]    ptr_stp_state    - Pointer to stp state.
 * @return         CLX_E_OK                 - Operate success.
 * @return         CLX_E_ENTRY_NOT_FOUND    - Entry does not exist.
 * @return         CLX_E_BAD_PARAMETER      - Bad parameter.
 */
clx_error_no_t
hal_mt_nb_stp_portstate_get(const uint32 unit,
                            const uint32 stgid,
                            const uint32 port,
                            clx_stp_state_t *ptr_stp_state);

/**
 * @brief Check whether a specified STG is created.
 *
 * Support_chip: all.
 *
 * @param [in]    unit     - Device unit number.
 * @param [in]    stgid    - STG ID.
 * @return        CLX_E_OK                 - The STG has been created.
 * @return        CLX_E_ENTRY_NOT_FOUND    - The STG has not been created.
 */
clx_error_no_t
hal_mt_nb_stp_is_valid(const uint32 unit, const uint32 stgid);

clx_error_no_t
hal_mt_nb_stp_stpid_set(const uint32 unit,
                        const uint32 stp_id,
                        const HAL_STP_ATTACH_OBJ_T *stp_obj);

clx_error_no_t
hal_mt_nb_stp_stpid_get(const uint32 unit, uint32 *stp_id, HAL_STP_ATTACH_OBJ_T *stp_obj);

clx_error_no_t
hal_mt_nb_stp_vlanfilter_set(const uint32 unit,
                             const HAL_STP_DIRECTION dir,
                             const uint32 vlanid,
                             const uint32 *port_bmp);
#endif
