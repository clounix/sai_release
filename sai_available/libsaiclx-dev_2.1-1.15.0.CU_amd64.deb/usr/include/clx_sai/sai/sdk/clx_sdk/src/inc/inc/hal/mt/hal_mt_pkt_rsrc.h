/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  This software and the information contained therein are protected by
 *  copyright and other intellectual property laws and terms herein is
 *  confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Clounix (Shanghai) Technology Limited. (C) 2020-2023
 *
 *  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
 *  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
 *  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 *  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 *  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 *  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
 *  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
 *  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
 *  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
 *  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
 *  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
 *  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
 *  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
 *
 *  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
 *  WITH THE LAWS OF THE PEOPLE'S REPUBLIC OF CHINA, EXCLUDING ITS CONFLICT OF
 *  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
 *  RELATED THERETO SHALL BE SETTLED BY LAWSUIT IN SHANGHAI,CHINA UNDER.
 *
 *******************************************************************************/

/* FILE NAME:  hal_mt_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_MT_PKT_RSRC_H
#define HAL_MT_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx/clx_types.h>
#include <clx/clx_error.h>
#include <clx/clx_pkt.h>

#include <hal/hal_pkt_rsrc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* Keep these values applied to different modules. */
typedef enum hal_mt_pkt_pp_rsn_e {
    /* PL */
    HAL_MT_PKT_PP_RSN_ECC_ERR = 1,
    HAL_MT_PKT_PP_RSN_IPL_ERR_FRM,
    HAL_MT_PKT_PP_RSN_IPL_CRC_ERR,
    HAL_MT_PKT_PP_RSN_IPL_MAX_LEN_VLT,
    HAL_MT_PKT_PP_RSN_IPL_JABBER_FRM,
    HAL_MT_PKT_PP_RSN_IPL_LEN_ERR,
    HAL_MT_PKT_PP_RSN_IPL_CONST_SOP,
    HAL_MT_PKT_PP_RSN_IPL_OVER_MTU,
    HAL_MT_PKT_PP_RSN_IPL_EOP_TIME_OUT,
    HAL_MT_PKT_PP_RSN_IPL_BUF_OVF,
    HAL_MT_PKT_PP_RSN_LBM_FRG_DROP,
    HAL_MT_PKT_PP_RSN_LBM_TRUN_ERR,
    HAL_MT_PKT_PP_RSN_LBM_RECVD_ERR,
    /* TDS, 16 */
    HAL_MT_PKT_PP_RSN_TDS_RSN_OFFSET = 16,
    HAL_MT_PKT_PP_RSN_TDS_MGO = 16,
    HAL_MT_PKT_PP_RSN_TDS_MSGO,
    HAL_MT_PKT_PP_RSN_TDS_UNDERLAY_L3MC_SPT_RDY_SET_1,
    HAL_MT_PKT_PP_RSN_TDS_TUNNEL_MAC_SA,
    HAL_MT_PKT_PP_RSN_TDS_MTU2,
    HAL_MT_PKT_PP_RSN_TDS_MTU3,
    HAL_MT_PKT_PP_RSN_TDS_TNL_TTL0,
    HAL_MT_PKT_PP_RSN_TDS_TNL_TTL1,
    HAL_MT_PKT_PP_RSN_TDS_TNL_BAD_IP_0,
    HAL_MT_PKT_PP_RSN_TDS_TNL_BAD_IP_1,
    HAL_MT_PKT_PP_RSN_TDS_TNL_NVO3_UKN_PLD,
    HAL_MT_PKT_PP_RSN_TDS_BDO_SPT,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_RMAC_MISS,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_DIS,
    HAL_MT_PKT_PP_RSN_TDS_IP_ETH_DIS,
    HAL_MT_PKT_PP_RSN_TDS_IP_IP_DIS,
    /* 32 */
    HAL_MT_PKT_PP_RSN_TDS_GRE_ETH_DIS,
    HAL_MT_PKT_PP_RSN_TDS_GRE_IP_DIS,
    HAL_MT_PKT_PP_RSN_TDS_GRE_ERSPAN_DIS,
    HAL_MT_PKT_PP_RSN_TDS_VXLAN_ETH_DIS,
    HAL_MT_PKT_PP_RSN_TDS_GPE_ETH_DIS,
    HAL_MT_PKT_PP_RSN_TDS_GPE_IP_DIS,
    HAL_MT_PKT_PP_RSN_TDS_GENEVE_ETH_DIS,
    HAL_MT_PKT_PP_RSN_TDS_GENEVE_IP_DIS,
    HAL_MT_PKT_PP_RSN_TDS_FLEX_ETH_DIS,
    HAL_MT_PKT_PP_RSN_TDS_FLEX_IP_DIS,
    HAL_MT_PKT_PP_RSN_TDS_GIPO_MISS_0,
    HAL_MT_PKT_PP_RSN_TDS_GIPO_MISS_1,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_LSP_MISS,
    HAL_MT_PKT_PP_RSN_TDS_TEP_BIND,
    HAL_MT_PKT_PP_RSN_TDS_TEP_RPF_0,
    HAL_MT_PKT_PP_RSN_TDS_TEP_RPF_1,
    /* 48 */
    HAL_MT_PKT_PP_RSN_TDS_ERSPAN_MISS,
    HAL_MT_PKT_PP_RSN_TDS_GRE_VER,
    HAL_MT_PKT_PP_RSN_TDS_GRE_FLG0,
    HAL_MT_PKT_PP_RSN_TDS_GRE_FLG1,
    HAL_MT_PKT_PP_RSN_TDS_GRE_FLG2,
    HAL_MT_PKT_PP_RSN_TDS_GRE_FLG3,
    HAL_MT_PKT_PP_RSN_TDS_BAS_ZR,
    HAL_MT_PKT_PP_RSN_TDS_BAS_FLG0,
    HAL_MT_PKT_PP_RSN_TDS_BAS_FLG1,
    HAL_MT_PKT_PP_RSN_TDS_GPE_ZR,
    HAL_MT_PKT_PP_RSN_TDS_GPE_FLG0,
    HAL_MT_PKT_PP_RSN_TDS_GPE_FLG1,
    HAL_MT_PKT_PP_RSN_TDS_GENEVE_VER,
    HAL_MT_PKT_PP_RSN_TDS_GENEVE_O,
    HAL_MT_PKT_PP_RSN_TDS_GENEVE_C,
    HAL_MT_PKT_PP_RSN_TDS_FLEX_EXCPT_0,
    /* 64 */
    HAL_MT_PKT_PP_RSN_TDS_FLEX_EXCPT_1,
    HAL_MT_PKT_PP_RSN_TDS_FLEX_EXCPT_2,
    HAL_MT_PKT_PP_RSN_TDS_FLEX_EXCPT_3,
    HAL_MT_PKT_PP_RSN_TDS_FLEX_EXCPT_4,
    HAL_MT_PKT_PP_RSN_TDS_FLEX_EXCPT_5,
    HAL_MT_PKT_PP_RSN_TDS_FLEX_EXCPT_6,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_LSP_LBL_GT4,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_LSP_RSVD, // rsvd0
    HAL_MT_PKT_PP_RSN_TDS_MPLS_LSP_RSVD1,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_ELI_BOS,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_2ND_ELI,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_NULL_TOP,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_EXPOSE_TTL0,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_EXPOSE_TTL1,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_NULL_IP,
    HAL_MT_PKT_PP_RSN_TDS_MPLS_EL_IP,
    /* 80 */
    HAL_MT_PKT_PP_RSN_TDS_MPLS_LSP_IP,
    HAL_MT_PKT_PP_RSN_TDS_UNDERLAY_L3MC_PIM_REGISTER,
    HAL_MT_PKT_PP_RSN_TDS_PSR_PKT_INC,
    HAL_MT_PKT_PP_RSN_TDS_SRV6_SL_BIG,
    HAL_MT_PKT_PP_RSN_TDS_HSH_SRV6_FUNC_MISS,
    HAL_MT_PKT_PP_RSN_TDS_SRV6_SRC_TEP_MISS,
    HAL_MT_PKT_PP_RSN_TDS_SRV6_DIS,
    HAL_MT_PKT_PP_RSN_TDS_SRV6_TTL1,
    HAL_MT_PKT_PP_RSN_TDS_SRV6_ERR_HDR,
    HAL_MT_PKT_PP_RSN_TDS_SRV6_FUNC_REDIR,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_23,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_24,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_25,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_26,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_27,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_28,
    /* DIS, 96 */
    HAL_MT_PKT_PP_RSN_DIS_RSN_OFFSET = 96,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_SL0_SI0_COC1 = 96,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_USP_SL0,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_SL0,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_DECAP_SL_NON_ZERO,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_WRONG_FLAVOR,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_NXTUSID0,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_NXTCSID0,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_DECAP_USID_NON_ZERO,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_DECAP_INNER_UNK,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_USP_SL0_TWO_SRH,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_USP_NO_SRH,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_RCV_SRC_RED,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_B6_INSERT_LAST_HOP,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_RSVD_END_BEH_CODE,
    HAL_MT_PKT_PP_RSN_DIS_PSR_PKT_INC,
    HAL_MT_PKT_PP_RSN_DIS_TNL_AUTO_IP,
    /* 112 */
    HAL_MT_PKT_PP_RSN_DIS_TNL_ISATAP_IP,
    HAL_MT_PKT_PP_RSN_DIS_PRIO_TAG,
    HAL_MT_PKT_PP_RSN_DIS_1QMODE_W_STAG_PKT,
    HAL_MT_PKT_PP_RSN_DIS_PSR_PKT_BAD_IP,
    HAL_MT_PKT_PP_RSN_DIS_LCL_DROP_PKT_UNTAGGED,
    HAL_MT_PKT_PP_RSN_DIS_LCL_DROP_PKT_TAGGED,
    HAL_MT_PKT_PP_RSN_DIS_LCL_DROP_PKT_TAGGED_EXCPT_DEFAULT,
    HAL_MT_PKT_PP_RSN_DIS_MPLS_DECAP_BOS,
    HAL_MT_PKT_PP_RSN_DIS_MPLS_PW_CW,
    HAL_MT_PKT_PP_RSN_DIS_MPLS_PW_ACH,
    HAL_MT_PKT_PP_RSN_DIS_MPLS_PW_UNK,
    HAL_MT_PKT_PP_RSN_DIS_MPLS_L3VPN_IP,
    HAL_MT_PKT_PP_RSN_DIS_BDI_HSH_MISS,
    HAL_MT_PKT_PP_RSN_DIS_IGMP_SNOOPING,
    HAL_MT_PKT_PP_RSN_DIS_MLD_SNOOPING,
    HAL_MT_PKT_PP_RSN_DIS_TNL_ECN_1,
    /* 128 */
    HAL_MT_PKT_PP_RSN_DIS_TNL_ECN_2,
    HAL_MT_PKT_PP_RSN_DIS_TNL_ECN_3,
    HAL_MT_PKT_PP_RSN_DIS_BDI_SPT,
    HAL_MT_PKT_PP_RSN_DIS_DOS_CHK,
    HAL_MT_PKT_PP_RSN_DIS_IPV4_MAC_DA_MC_MAPPING_MISMATCH,
    HAL_MT_PKT_PP_RSN_DIS_IPV6_MAC_DA_MC_MAPPING_MISMATCH,
    HAL_MT_PKT_PP_RSN_DIS_IP_MC_LCL,
    HAL_MT_PKT_PP_RSN_DIS_L3VPN_BUT_NO_L3_SERVICE,
    HAL_MT_PKT_PP_RSN_DIS_L3PORT_GET_IP_UC_PKT_BUT_RMAC_FAIL,
    HAL_MT_PKT_PP_RSN_DIS_L3PORT_GET_IP_UC_PKT_BUT_IP_UC_NOT_EN,
    HAL_MT_PKT_PP_RSN_DIS_L3PORT_GET_IP_MC_PKT_BUT_IP_MC_NOT_EN,
    HAL_MT_PKT_PP_RSN_DIS_L3PORT_GET_NON_IP_PKT,
    HAL_MT_PKT_PP_RSN_DIS_UNEXPECTED_LKUP_TYPE,
    HAL_MT_PKT_PP_RSN_DIS_SRV6_L2_FWD_IS_L3_IF,
    HAL_MT_PKT_PP_RSN_DIS_L2MTU,
    HAL_MT_PKT_PP_RSN_DIS_L3MTU,
    /* 144 */
    HAL_MT_PKT_PP_RSN_DIS_IPV4_SRC_GUARD,
    HAL_MT_PKT_PP_RSN_DIS_IPV6_SRC_GUARD,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_29,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_30,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_31,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_32,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_33,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_34,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_35,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_36,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_37,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_38,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_39,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_40,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_41,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_42,
    /* 160 */
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_START = 160, // C2C, range from 160 to 287
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_0 = HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_START,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_1,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_2,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_3,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_4,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_5,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_6,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_7,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_8,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_9,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_10,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_11,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_12,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_13,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_14,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_15,
    /* 176 */
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_16,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_17,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_18,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_19,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_20,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_21,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_22,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_23,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_24,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_25,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_26,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_27,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_28,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_29,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_30,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_31,
    /* 192 */
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_32,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_33,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_34,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_35,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_36,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_37,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_38,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_39,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_40,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_41,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_42,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_43,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_44,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_45,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_46,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_47,
    /* 208 */
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_48,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_49,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_50,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_51,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_52,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_53,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_54,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_55,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_56,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_57,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_58,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_59,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_60,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_61,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_62,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_63,
    /* 224 */
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_64,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_65,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_66,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_67,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_68,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_69,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_70,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_71,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_72,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_73,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_74,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_75,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_76,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_77,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_78,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_79,
    /* 240 */
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_80,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_81,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_82,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_83,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_84,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_85,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_86,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_87,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_88,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_89,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_90,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_91,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_92,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_93,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_94,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_95,
    /* 256 */
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_96,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_97,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_98,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_99,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_100,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_101,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_102,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_103,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_104,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_105,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_106,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_107,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_108,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_109,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_110,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_111,
    /* 272 */
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_112,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_113,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_114,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_115,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_116,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_117,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_118,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_119,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_120,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_121,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_122,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_123,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_124,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_125,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_126,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_127,
    HAL_MT_PKT_PP_RSN_DIS_C2C_TCAM_END = 287,
    /* FPU, 288 */
    HAL_MT_PKT_PP_RSN_FPU_RSN_OFFSET = 288,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_SPT_RDY_SET_1 = 288,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_PIM_REGISTER,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_C2C,
    HAL_MT_PKT_PP_RSN_FPU_GLEAN_ADJ,
    HAL_MT_PKT_PP_RSN_FPU_L2UC_DA_MISS,
    HAL_MT_PKT_PP_RSN_FPU_L2MC_DA_MISS,
    HAL_MT_PKT_PP_RSN_FPU_L3UC_IPV4_DIP_MISS,
    HAL_MT_PKT_PP_RSN_FPU_L3UC_IPV4_RPF_FAIL_DROP,
    HAL_MT_PKT_PP_RSN_FPU_L3UC_IPV4_RPF_FAIL_REDIR,
    HAL_MT_PKT_PP_RSN_FPU_L3UC_IPV4_ICMP_REDIR,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_IPV4_DIP_MISS,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_IPV4_RPF_FAIL_DROP,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_IPV4_RPF_FAIL_REDIR,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_IPV4_RPF_FAIL_CANT_FALL_BACK_L2,
    HAL_MT_PKT_PP_RSN_FPU_L3UC_IPV6_DIP_MISS,
    HAL_MT_PKT_PP_RSN_FPU_L3UC_IPV6_RPF_FAIL_DROP,
    /* 304 */
    HAL_MT_PKT_PP_RSN_FPU_L3UC_IPV6_RPF_FAIL_REDIR,
    HAL_MT_PKT_PP_RSN_FPU_L3UC_IPV6_ICMP_REDIR,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_IPV6_DIP_MISS,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_IPV6_RPF_FAIL_DROP,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_IPV6_RPF_FAIL_REDIR,
    HAL_MT_PKT_PP_RSN_FPU_L3MC_IPV6_RPF_FAIL_CANT_FALL_BACK_L2,
    HAL_MT_PKT_PP_RSN_FPU_L3UC_NO_FWD_PTR,       // L3.fwd_ptr need to point a non-zero key L2,
                                                 // otherwise trigger this
    HAL_MT_PKT_PP_RSN_FPU_L3UC_NO_AFIB_RSLT_PTR, // L3.afib_rslt_ptr need to point a afib tile,
                                                 // otherwise trigger this
    HAL_MT_PKT_PP_RSN_FPU_L25MPLS_TRANSIT_LBL_MISS,
    HAL_MT_PKT_PP_RSN_FPU_ECMPGRP_ZERO_NUM_PATH, // number of ecmp path is 0
    HAL_MT_PKT_PP_RSN_FPU_ECMPMBR_INVALID,       // point to a ecmp mbr with invalid config
    HAL_MT_PKT_PP_RSN_FPU_L2_SA_MOVE,
    HAL_MT_PKT_PP_RSN_FPU_L2_SA_MISS_0,
    HAL_MT_PKT_PP_RSN_FPU_L2_SA_MISS_1,
    HAL_MT_PKT_PP_RSN_FPU_L2_SA_FWD_MAC_BD_MISMATCH,
    HAL_MT_PKT_PP_RSN_FPU_L2ECMP_MISS,
    /* ICIA, 320 */
    HAL_MT_PKT_PP_RSN_ICIA_RSN_OFFSET = 320,
    HAL_MT_PKT_PP_RSN_ICIA_POLICE_RED_EXCPT = 321,
    HAL_MT_PKT_PP_RSN_ICIA_ACTION_SUP_LOG,
    HAL_MT_PKT_PP_RSN_ICIA_ACTION_SUP_DENY,
    HAL_MT_PKT_PP_RSN_ICIA_FINAL_RED_EXCPT,
    HAL_MT_PKT_PP_RSN_ICIA_STORM_RED_EXCPT,
    HAL_MT_PKT_PP_RSN_ICIA_INT_SOURCE_RCV_INT_ENCAP,
    HAL_MT_PKT_PP_RSN_ICIA_ECMPGRP_ZERO_NUM_PATH, // number of ecmp path is 0
    HAL_MT_PKT_PP_RSN_ICIA_ECMPMBR_INVALID,       // point to a ecmp mbr with invalid config
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_0,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_1,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_2,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_3,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_4,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_5,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_6,
    /* 336 */
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_7,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_8,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_9,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_10,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_11,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_12,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_13,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_14,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_15,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_16,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_17,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_18,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_19,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_20,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_21,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_22,
    /* FWR, 352 */
    HAL_MT_PKT_PP_RSN_FWR_RSN_OFFSET = 352,
    // Default COPY
    HAL_MT_PKT_PP_RSN_FWR_SFLOW_SAMPLER = 352,
    HAL_MT_PKT_PP_RSN_FWR_UC_SOURCE_PRUNING,
    HAL_MT_PKT_PP_RSN_FWR_UC_UL2UL_PRUNING,
    HAL_MT_PKT_PP_RSN_FWR_TNL_IDX_IN_LAT_MODE,
    HAL_MT_PKT_PP_RSN_FWR_IP_TTL0,                    // for TTL dropping check
    HAL_MT_PKT_PP_RSN_FWR_IP_TTL1,                    // for TTL dropping check
    HAL_MT_PKT_PP_RSN_FWR_IPV4_OPTION_EXIST_FWD,      // if option exist forward to SW
    HAL_MT_PKT_PP_RSN_FWR_IPV6_NHDR_SW_FWD,           // if option exist forward to SW
    HAL_MT_PKT_PP_RSN_FWR_TNL_ECMPGRP_ZERO_NUM_PATH,  // number of ecmp path is 0
    HAL_MT_PKT_PP_RSN_FWR_TNL_ECMPMBR_INVALID,        // point to a ecmp mbr with invalid config
    HAL_MT_PKT_PP_RSN_FWR_TELM_OVER_UNSUPPORTED_TYPE, // tnl is expected
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_43,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_44,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_45,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_46,
    HAL_MT_PKT_PP_RSN_ICIA_RX_COPYTOCPU_RSN_47,
    /* RWI, 384 */
    HAL_MT_PKT_PP_RSN_RWI_RSN_OFFSET = 384,
    // Default EXCPT
    HAL_MT_PKT_PP_RSN_RWI_EVPN_ESI_FLITER = 384,
    HAL_MT_PKT_PP_RSN_RWI_EVPN_DF_FLITER,
    HAL_MT_PKT_PP_RSN_RWI_VLAN_HSH_MISS,
    HAL_MT_PKT_PP_RSN_RWI_L2MTU,
    HAL_MT_PKT_PP_RSN_RWI_L3MTU,
    HAL_MT_PKT_PP_RSN_RWI_BDI_SPT,
    HAL_MT_PKT_PP_RSN_RWI_PVLAN_PORT_TYPE,
    HAL_MT_PKT_PP_RSN_RWI_PVLAN,
    HAL_MT_PKT_PP_RSN_RWI_INT_OVER_UNSUPPORTED_TYPE,
    HAL_MT_PKT_PP_RSN_RWI_MC_SOURCE_PRUNING,
    HAL_MT_PKT_PP_RSN_RWI_MC_UL2UL_PRUNING,
    HAL_MT_PKT_PP_RSN_RWI_MC_L3VPN_PRUNING,
    HAL_MT_PKT_PP_RSN_RWI_IOAM_OVER_UNSUPPORTED_TYPE,
    HAL_MT_PKT_PP_RSN_RWI_INT_REPORT_REC,
    HAL_MT_PKT_PP_RSN_RWI_INT_MTU_EXCEED,
    HAL_MT_PKT_PP_RSN_RWI_INT_META_INCOMP,
    /* 400 */
    HAL_MT_PKT_PP_RSN_RWI_TELM_NONEXIST_DECAP,
    HAL_MT_PKT_PP_RSN_RWI_IFA_HOP_LIMIT_0,
    HAL_MT_PKT_PP_RSN_RWI_POST_SMALL_PKT,
    HAL_MT_PKT_PP_RSN_RWI_INC_OVERFLOW, /* 404-415 12 */
    /* RWX, 416 */
    HAL_MT_PKT_PP_RSN_RWX_RSN_OFFSET = 416, /* 416-448 33 */
    /* ECIA, 448 */
    HAL_MT_PKT_PP_RSN_ECIA_RSN_OFFSET = 448,
    HAL_MT_PKT_PP_RSN_ECIA_POLICE_RED_EXCPT,
    HAL_MT_PKT_PP_RSN_ECIA_ACTION_SUP_LOG,
    HAL_MT_PKT_PP_RSN_ECIA_ACTION_SUP_DENY,
    HAL_MT_PKT_PP_RSN_ECIA_FINAL_RED_EXCPT,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_0,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_1,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_2,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_3,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_4,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_5,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_6,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_7,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_8,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_9,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_10,
    /* 464 */
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_11,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_12,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_13,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_14,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_15,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_16,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_17,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_18,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_19,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_20,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_21,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_22,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_23,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_24,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_25,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_26,
    /* RWO, 480 */
    HAL_MT_PKT_PP_RSN_RWO_RSN_OFFSET = 480,
    // Default COPY
    HAL_MT_PKT_PP_RSN_RWO_SFLOW_SAMPLER = 480,
    HAL_MT_PKT_PP_RSN_RWO_INT_OVER_VXLAN_BASE,
    HAL_MT_PKT_PP_RSN_RWO_INT_OVER_UNSUPPORTED_TNL,
    HAL_MT_PKT_PP_RSN_RWO_IOAM_OVER_UNSUPPORTED_TNL,
    HAL_MT_PKT_PP_RSN_RWO_L3MTU,
    HAL_MT_PKT_PP_RSN_RWO_MPLS_PHP_BOS_ETH,
    HAL_MT_PKT_PP_RSN_RWO_POST_SMALL_PKT,
    HAL_MT_PKT_PP_RSN_RWO_HDC_VAL,
    HAL_MT_PKT_PP_RSN_RWO_INC_OVERFLOW,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_27,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_28,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_29,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_30,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_31,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_32,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_33,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_34,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_35,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_36,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_37,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_38,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_39,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_40,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_41,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_42,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_43,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_44,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_45,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_46,
    HAL_MT_PKT_PP_RSN_ECIA_RX_TRAP_RSN_47,
    HAL_MT_PKT_PP_RSN_ECIA_RX_UDF_RSN,
    HAL_MT_PKT_PP_RSN_MOD = 511,
    HAL_MT_PKT_PP_RSN_LAST = 512,
} hal_mt_pkt_pp_rsn_t;

#define HAL_MT_PKT_RSN_BMP_SIZE (CLX_BITMAP_SIZE(HAL_MT_PKT_PP_RSN_LAST))
typedef uint32 hal_mt_pkt_pp_rsn_bmp_t[HAL_MT_PKT_RSN_BMP_SIZE];

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_MT_PKT_FOREACH_RSN_BIT(pp_reason_bitmap, pp_reason)          \
    for (pp_reason = 0; pp_reason < HAL_MT_PKT_PP_RSN_LAST; pp_reason++) \
        if (CLX_PKT_RSN_BMP_CHK(pp_reason_bitmap, pp_reason))

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/**
 * @brief To translate the reason from user-view to chip-view.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     drop_reason           - The drop reason code.
 * @param [out]    ptr_pp_reason_cnt     - The drop reason map pp reason cnt.
 * @param [out]    ptr_pp_reason_list    - The drop reason map pp reason list.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - Input pp reason is invalid.
 */
clx_error_no_t
hal_mt_pkt_rsrc_pp_to_drop_rsn_trans(const uint32 unit,
                                     const clx_pkt_drop_reason_t drop_reason,
                                     uint32 *ptr_pp_reason_cnt,
                                     uint32 *ptr_pp_reason_list);

/**
 * @brief To translate the reason from user-view to chip-view.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     rx_reason_code      - The user-view reason.
 * @param [out]    pp_reason_bitmap    - Pointer to the chip-view reason.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - User-view reason does not match chip-view reason.
 */
clx_error_no_t
hal_mt_pkt_rsrc_usr_to_pp_rsn_get(const uint32 unit,
                                  const clx_pkt_rx_reason_t rx_reason_code,
                                  hal_mt_pkt_pp_rsn_bmp_t pp_reason_bitmap);

/**
 * @brief To translate the reason from chip-view to user-view.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     pp_reason_bitmap      - The chip-view reason.
 * @param [out]    ptr_rx_reason_code    - Pointer to the user-view reason.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - Chip-view reason does not match User-view reason.
 */
clx_error_no_t
hal_mt_pkt_rsrc_pp_to_user_rsn_get(const uint32 unit,
                                   const hal_mt_pkt_pp_rsn_bmp_t pp_reason_bitmap,
                                   clx_pkt_rx_reason_t *ptr_rx_reason_code);

/**
 * @brief To translate the reason bitmap from chip-view to user-view.
 *
 * @param [in]     unit                - Device unit number.
 * @param [in]     pp_reason_bitmap    - The chip-view reason.
 * @param [out]    rx_reason_bitmap    - Pointer to the user-view reason.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - Chip-view reason does not match User-view reason.
 */
clx_error_no_t
hal_mt_pkt_rsrc_pp_to_user_rsn_bmp_get(const uint32 unit,
                                       const hal_mt_pkt_pp_rsn_bmp_t pp_reason_bitmap,
                                       clx_pkt_rx_rsn_bmp_t rx_reason_bitmap);

/**
 * @brief To get the default drop reason code of the PP reason.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     pp_reason      - The PP reason code.
 * @param [out]    drop_reason    - Pointer to the drop reason.
 * @return         CLX_E_OK               - Success to get the drop reason.
 * @return         CLX_E_BAD_PARAMETER    - There is no default drop reason of PP reason.
 */
clx_error_no_t
hal_mt_pkt_rsrc_drop_code_by_pp_get(const uint32 unit,
                                    const hal_mt_pkt_pp_rsn_t pp_reason,
                                    clx_pkt_drop_reason_t *drop_reason);

/**
 * @brief To get the default drop reason code of the reason.
 *
 * @param [in]     unit           - Device unit number.
 * @param [in]     reason         - Reason code.
 * @param [out]    drop_reason    - Pointer to the drop reason.
 * @return         CLX_E_OK               - Success to get the drop reason.
 * @return         CLX_E_BAD_PARAMETER    - There is no default drop reason of PP reason.
 */
clx_error_no_t
hal_mt_pkt_rsrc_drop_code_by_rsn_get(const uint32 unit,
                                     const clx_pkt_rx_reason_t reason,
                                     clx_pkt_drop_reason_t *drop_reason);

/**
 * @brief To translate chip-view PP reasons to string.
 *
 * @param [in]     unit             - Device unit number.
 * @param [in]     pp_reason        - The PP reason code.
 * @param [in]     str_len          - String length.
 * @param [out]    str_pp_reason    - The PP reason code string.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER      - PP reason out of range.
 * @return         CLX_E_ENTRY_NOT_FOUND    - PP reason dose not match.
 */
clx_error_no_t
hal_mt_pkt_rsrc_pp_rsn_get(const uint32 unit,
                           const hal_mt_pkt_pp_rsn_t pp_reason,
                           const uint32 str_len,
                           char *str_pp_reason);

/**
 * @brief To translate PP reason string to PP reason code.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     str_pp_reason     - The PP reason string.
 * @param [out]    pp_reason_code    - The PP reason code.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_ENTRY_NOT_FOUND    - RX reason string dose not match.
 */
clx_error_no_t
hal_mt_pkt_rsrc_pp_rsn_code_get(const uint32 unit,
                                const char *str_pp_reason,
                                uint32 *pp_reason_code);

/**
 * @brief To translate RX reason code to string.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     rx_reason_code    - The RX reason code.
 * @param [in]     str_len           - String length.
 * @param [out]    str_rx_reason     - The RX reason string.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_ENTRY_NOT_FOUND    - RX reason code dose not match.
 */
clx_error_no_t
hal_mt_pkt_rsrc_rsn_get(const uint32 unit,
                        const clx_pkt_rx_reason_t rx_reason_code,
                        const uint32 str_len,
                        char *str_rx_reason);

/**
 * @brief To translate RX reason string to Rx reason code.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     str_rx_reason     - The RX reason string.
 * @param [out]    rx_reason_code    - The RX reason code.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_ENTRY_NOT_FOUND    - RX reason string dose not match.
 */
clx_error_no_t
hal_mt_pkt_rsrc_rsn_code_get(const uint32 unit,
                             const char *str_rx_reason,
                             clx_pkt_rx_reason_t *rx_reason_code);

/**
 * @brief To translate drop reason code to string.
 *
 * @param [in]     unit               - Device unit number.
 * @param [in]     drop_reason        - Drop reason code.
 * @param [in]     str_len            - String length.
 * @param [out]    str_drop_reason    - The drop reason string.
 * @return         CLX_E_OK                 - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER      - PP reason out of range.
 * @return         CLX_E_ENTRY_NOT_FOUND    - PP reason dose not match.
 */
clx_error_no_t
hal_mt_pkt_rsrc_drop_rsn_get(const uint32 unit,
                             const clx_pkt_drop_reason_t drop_reason,
                             const uint32 str_len,
                             char *str_drop_reason);

/**
 * @brief To configure the mapping from user-view reason to the RX CPU queue.
 *
 * @param [in]    unit             - Device unit number.
 * @param [in]    queue            - The specified queue.
 * @param [in]    reason_bitmap    - The reason bitmap.
 * @return        CLX_E_OK        - Successfully configure the mapping.
 * @return        CLX_E_OTHERS    - Configure the mapping failed.
 */
clx_error_no_t
hal_mt_pkt_rsrc_queue_rsn_mapping_set(const uint32 unit,
                                      const uint32 queue,
                                      const clx_pkt_rx_rsn_bmp_t reason_bitmap);

/**
 * @brief To get the mapping from user-view reason to the CPU queue.
 *
 * @param [in]    unit                 - Device unit number.
 * @param [in]    queue                - The specified queue.
 * @param [in]    ptr_reason_bitmap    - Pointer of the reason bitmap.
 * @return        CLX_E_OK        - Successfully get the mapping.
 * @return        CLX_E_OTHERS    - Get the mapping failed.
 */
clx_error_no_t
hal_mt_pkt_rsrc_queue_rsn_mapping_get(const uint32 unit,
                                      const uint32 queue,
                                      clx_pkt_rx_rsn_bmp_t *ptr_reason_bitmap);

/**
 * @brief To translate the reason one to one from user-view to chip-view.
 *
 * @param [in]     unit              - Device unit number.
 * @param [in]     rx_reason_code    - The user-view reason.
 * @param [out]    pp_reason_code    - Pointer to the chip-view reason.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - User-view reason does not match chip-view reason.
 */
clx_error_no_t
hal_mt_pkt_rsrc_user_rsn_to_hw_rsn_trans(const uint32 unit,
                                         const clx_pkt_rx_reason_t rx_reason_code,
                                         hal_mt_pkt_pp_rsn_t *pp_reason_code);

/**
 * @brief To translate the reason one to one from chip-view to user-view.
 *
 * @param [in]     unit                  - Device unit number.
 * @param [in]     pp_reason_code        - The chip-view reason.
 * @param [out]    ptr_rx_reason_code    - Pointer to the user-view reason.
 * @return         CLX_E_OK               - Success to translate the reason.
 * @return         CLX_E_BAD_PARAMETER    - Chip-view reason does not match User-view reason.
 */
clx_error_no_t
hal_mt_pkt_rsrc_hw_rsn_to_user_rsn_trans(const uint32 unit,
                                         const hal_mt_pkt_pp_rsn_t pp_reason_code,
                                         clx_pkt_rx_reason_t *ptr_rx_reason_code);

#endif
