/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_sec.h
 * PURPOSE:
 *      Define the declaration for Security module.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_SEC_H
#define HAL_SEC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_cfg.h>
#include <clx_types.h>
#include <clx_error.h>
#include <clx_sec.h>
#include <clx_port.h>
#include <osal/osal.h>
#include <dcc/dcc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* Dos check size maximum */
#define HAL_SEC_DOS_MAX_ICMPV4_SIZE             (0xFFFF)
#define HAL_SEC_DOS_MAX_ICMPV6_SIZE             (0xFFFF)
#define HAL_SEC_DOS_MAX_L4_PROT                 (0xFF)
#define HAL_SEC_DOS_MIN_UDP_SIZE                (0xF)
#define HAL_SEC_DOS_MIN_UDP_FRG_OFF             (0xF)
#define HAL_SEC_DOS_MIN_TCP_SIZE                (0x1F)
#define HAL_SEC_DOS_MIN_TCP_FRG_OFF             (0x1F)
#define HAL_SEC_DOS_MIN_SCTP_SIZE               (0xF)
#define HAL_SEC_DOS_MIN_SCTP_FRG_OFF            (0xF)
#define HAL_SEC_DOS_MIN_IPV6_FRAG_SIZE          (0x1F)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

#define HAL_SEC_DOS_EXCEPTION_CHECK        (32 *3 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W0_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W0_SDK_DOS_CHK_0_FIELD_ID].offset)
#define HAL_SEC_DOS_EXCEPTION_TRAP         (32 *3 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W0_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W0_SDK_DOS_CHK_1_FIELD_ID].offset)
#define HAL_SEC_DOS_EXCEPTION_SUPP         (32 *3 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W0_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W0_SDK_DOS_CHK_2_FIELD_ID].offset)

#define HAL_LIGHTNING_SEC_DOS_EXCEPTION_TRAP     (32 *1 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W2_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W2_ETH_IP_HDR_FIELD_ID].offset)
#define HAL_LIGHTNING_SEC_DOS_EXCEPTION_SUPP     (32 *3 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W0_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W0_L3_MTU_FIELD_ID].offset)


/* meter rate granularity, unit: kbps */
#define HAL_SEC_SCMETER_RATE_GRANULARITY(unit)    \
            (HAL_IS_DEVICE_DAWN_FAMILY(unit)? (64) : (8))

/* meter bucket granularity, unit: byte */
#define HAL_SEC_SCMETER_BUCKET_SIZE_GRANULARITY(unit)  \
                (HAL_IS_DEVICE_DAWN_FAMILY(unit)? (64) : (8))
/* storm meter rate max */
#define HAL_SEC_SCMETER_RATE_MAX                        (1600000000UL)     /* 1.6G Kbps = 1.6Tbps */
/* storm meter bucket size max */
#define HAL_SEC_SCMETER_BUCKET_SIZE_MAX                 (64000000)      /* 64M bytes */
/* storm meter bucket size default */
#define HAL_SEC_SCMETER_BUCKET_SIZE_DEFAULT             (9216+20+64)    /* static value: */

/* storm meter packet length in pps mode */
#define HAL_SEC_MTR_PKT_LEN                             (128)

/* rate = (((packet) * HAL_SEC_MTR_PKT_LEN * 8) / 1000) */
#define HAL_SEC_MTR_PKT_TO_RATE(packet, rate)                                                      \
    do                                                                                             \
    {                                                                                              \
        UI64_T __pkt1__;                                                                           \
        UI64_T __rate1__;                                                                          \
        osal_memset(&__pkt1__, 0, sizeof(UI64_T));                                                 \
        osal_memset(&__rate1__, 0, sizeof(UI64_T));                                                \
        UI64_ADD_UI32(__pkt1__, packet);                                                           \
        UI64_MULT_UI32(__pkt1__, (HAL_SEC_MTR_PKT_LEN * 8));                                       \
        cmlib_bit64_divUi32(__pkt1__, 1000, &__rate1__);                                           \
        rate = UI64_LOW(__rate1__);                                                                \
    } while (0)

/* packet =  (((rate) * 1000) / (HAL_SEC_MTR_PKT_LEN * 8)) */
#define HAL_SEC_MTR_RATE_TO_PKT(rate, packet)                                                      \
    do                                                                                             \
    {                                                                                              \
        UI64_T __pkt2__;                                                                           \
        UI64_T __rate2__;                                                                          \
        osal_memset(&__pkt2__, 0, sizeof(UI64_T));                                                 \
        osal_memset(&__rate2__, 0, sizeof(UI64_T));                                                \
        UI64_ADD_UI32(__rate2__, rate);                                                            \
        UI64_MULT_UI32(__rate2__, (1000));                                                         \
        cmlib_bit64_divUi32(__rate2__, (HAL_SEC_MTR_PKT_LEN * 8), &__pkt2__);                      \
        packet = UI64_LOW(__pkt2__);                                                               \
    } while (0)

#define HAL_SEC_MTR_ROUND_RATE_TO_PKT(rate, packet)                                                \
    do                                                                                             \
    {                                                                                              \
        UI32_T __pkt__ = 0;                                                                        \
        UI32_T __rate__ = 0;                                                                       \
        HAL_SEC_MTR_RATE_TO_PKT(rate, __pkt__);                                                    \
        HAL_SEC_MTR_PKT_TO_RATE(__pkt__, __rate__);                                                \
        packet = __rate__ != rate ? __pkt__ + 1 : __pkt__ ;                                        \
    } while (0)

#define HAL_SEC_IFP_IPSG_BLOCK_NUM                      (3)     /* ip source guard block num */
#define HAL_SEC_IFP_IPSG_HASH_DEPTH                     (4)     /* ip source guard hash depth */
#define HAL_SEC_IFP_IPSG_BUCKET_NUM                     (512)   /* ip source guard bucket num */
#define HAL_SEC_IFP_IPSG_ENTRY_KEY_LENGTH               (3)     /* ip source entry key length */
#define HAL_SEC_IFP_IPSG_128_ENTRY_KEY_LENGTH           (9)     /* ip source 128 entry key length */

#define HAL_SEC_DOS_LOCK(unit)      hal_sec_sema((unit), HAL_SEC_ACT_LOCK,   HAL_SEC_ST_DOS)
#define HAL_SEC_SC_LOCK(unit)       hal_sec_sema((unit), HAL_SEC_ACT_LOCK,   HAL_SEC_ST_SC)
#define HAL_SEC_SG_LOCK(unit)       hal_sec_sema((unit), HAL_SEC_ACT_LOCK,   HAL_SEC_ST_SG)
#define HAL_SEC_TI_LOCK(unit)       hal_sec_sema((unit), HAL_SEC_ACT_LOCK,   HAL_SEC_ST_TI)
#define HAL_SEC_DOS_UNLOCK(unit)    hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_DOS)
#define HAL_SEC_SC_UNLOCK(unit)     hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_SC)
#define HAL_SEC_SG_UNLOCK(unit)     hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_SG)
#define HAL_SEC_TI_UNLOCK(unit)     hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_TI)

/* security action */
typedef enum
{
    HAL_SEC_ACT_INIT,       /* init */
    HAL_SEC_ACT_DEINIT,     /* deinit */
    HAL_SEC_ACT_LOCK,       /* lock */
    HAL_SEC_ACT_UNLOCK,     /* unlock */
    HAL_SEC_ACT_LAST,
} HAL_SEC_ACTION_T;

/* Security SDK API Semaphore Type */
typedef enum
{
    HAL_SEC_ST_DOS,         /* semaphore type dos */
    HAL_SEC_ST_SC,          /* semaphore type storm control */
    HAL_SEC_ST_SG,          /* semaphore type source guard */
    HAL_SEC_ST_TI,          /* semaphore type traffic isolation */
    HAL_SEC_ST_LAST
} HAL_SEC_SEMAPHORE_TYPE_T;

/* storm control counter pool entry */
typedef struct HAL_SEC_SCCOUNTER_ENTRY_S
{
    UI64_T  cnt[3];     /* cnt[0]: fwd byte;
                         * cnt[1]: fwd packet;
                         * cnt[2]: drop packet
                         */
} HAL_SEC_SCCOUNTER_ENTRY_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_sec_init
 * PURPOSE:
 *      Initialize security module.
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_init(
    const UI32_T             unit);

/* FUNCTION NAME: hal_sec_deinit
 * PURPOSE:
 *      Deinitialize security module.
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_deinit(
    const UI32_T             unit);

/* FUNCTION NAME:   hal_sec_sema
 * PURPOSE:
 *      Operate security controlled semaphore
 * INPUT:
 *      unit   --  Device unit number
 *      action --  Device resource action
 *      type   --  Device resource type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_sec_sema(
    const UI32_T                        unit,
    const HAL_SEC_ACTION_T          action,
    const HAL_SEC_SEMAPHORE_TYPE_T  type);

/* FUNCTION NAME:   hal_sec_setDosPortConfig
 * PURPOSE:
 *      set port DoS configuration. (add profile or record reference counter)
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  physical port ID.
 *      ptr_entry       --  DoS per port configuration.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sec_setDosPortConfig (
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry );

/* FUNCTION NAME:   hal_sec_getDosPortConfig
 * PURPOSE:
 *      get port DoS configuration. (get the port DoS profile id, and get dos profile entry)
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  physical port ID.
 * OUTPUT:
 *      ptr_entry       --  DoS per port configuration.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sec_getDosPortConfig (
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SEC_DOS_PORT_CONFIG_T       *ptr_entry );

CLX_ERROR_NO_T
hal_sec_getDosPortProfileInfo(
    const UI32_T                    unit,
    const UI32_T                    port,
    UI32_T                          *ptr_profile_id,
    UI32_T                          *ptr_ref_cnt);

/* FUNCTION NAME:   hal_sec_setDosConfig
 * PURPOSE:
 *      set global DoS configuration. (update all profile)
 * INPUT:
 *      unit            --  Device unit number.
 *      ptr_entry       --  DoS global configuration.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sec_setDosConfig (
    const UI32_T                    unit,
    const CLX_SEC_DOS_CONFIG_T      *ptr_entry);

/* FUNCTION NAME:   hal_sec_getDoSPortConfig
 * PURPOSE:
 *      get global DoS configuration. (get profile 0)
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      ptr_entry       --  DoS global configuration.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sec_getDosConfig (
    const UI32_T                    unit,
    CLX_SEC_DOS_CONFIG_T            *ptr_entry );

/* FUNCTION NAME: hal_sec_setStormCtrlProperty
 * PURPOSE:
 *      Set storm control properties on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 *      ptr_entry   --  The storm control properties for the physical port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_setStormCtrlProperty (
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_STORM_CTRL_T      *ptr_entry);

/* FUNCTION NAME: hal_sec_getStormCtrlProperty
 * PURPOSE:
 *      Get storm control properties on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 * OUTPUT:
 *      ptr_entry   --  The storm control properties for the physical port.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlProperty (
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SEC_STORM_CTRL_T            *ptr_entry);

/* FUNCTION NAME: hal_sec_getStormCtrlCnt
 * PURPOSE:
 *      Get storm control counter on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 *      type        --  The storm control counter type.
 * OUTPUT:
 *      ptr_cnt     --  The storm control counter.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlCnt(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_STORM_CTRL_TYPE_T type,
    CLX_SEC_STORM_CTRL_CNT_T        *ptr_cnt);

/* FUNCTION NAME: hal_sec_setStormCtrlCtrlPktEn
 * PURPOSE:
 *      Set storm control enable for control packets.
 * INPUT:
 *      unit        --  Device unit number.
 *      enable      --  Enable/Disable storm control for control packets.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_setStormCtrlCtrlPktEn (
    const UI32_T                    unit,
    const UI32_T                    enable);

/* FUNCTION NAME: hal_sec_getStormCtrlCtrlPktEn
 * PURPOSE:
 *      Set storm control enable for control packets.
 * INPUT:
 *      unit        --  Device unit number.
 * OUTPUT:
 *      ptr_enable  --  Enable/Disable storm control for control packets.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlCtrlPktEn (
    const UI32_T                    unit,
    UI32_T                          *ptr_enable);

/* FUNCTION NAME: hal_sec_setStormCtrlMeterLayer
 * PURPOSE:
 *      Set storm control meter layer mode(L1/L2).
 * INPUT:
 *      unit            --  Device unit number.
 *      layer_mode      --  storm control meter layer mode.
 *                          1 - layer 1; 0 - layer 2
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_setStormCtrlMeterLayer(
    const UI32_T                    unit,
    const UI32_T                    layer_mode);

/* FUNCTION NAME: hal_sec_setStormCtrlMeterLayer
 * PURPOSE:
 *      Set storm control meter layer mode(global).
 * INPUT:
 *      unit            --  Device unit number.
 *      ptr_layer_mode  --  storm control meter layer mode
 *                          1 - layer 1; 0 - layer 2
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlMeterLayer(
    const UI32_T                    unit,
    UI32_T                          *ptr_layer_mode);

/* FUNCTION NAME: hal_sec_setSourceGuardProperty
 * PURPOSE:
 *      Set source guard properties on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 *      ptr_entry   --  The source guard properties for the physical port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_setSourceGuardProperty(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    const CLX_SEC_SG_PROPERTY_T     *ptr_entry);

/* FUNCTION NAME: hal_sec_getSourceGuardProperty
 * PURPOSE:
 *      Get source guard properties on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 * OUTPUT:
 *      ptr_entry   --  The source guard properties for the physical port.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getSourceGuardProperty(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_SEC_SG_PROPERTY_T           *ptr_entry);

/* FUNCTION NAME: hal_sec_addSourceGuardEntry
 * PURPOSE:
 *      Add a source guard entry.
 * INPUT:
 *      unit        --  Device unit number.
 *      ptr_entry   --  Source guard entry.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_addSourceGuardEntry(
    const UI32_T                    unit,
    const CLX_SEC_SG_ENTRY_T        *ptr_entry);

/* FUNCTION NAME: hal_sec_delSourceGuardEntry
 * PURPOSE:
 *      Delete a source guard entry.
 * INPUT:
 *      unit        --  Device unit number.
 *      ptr_entry   --  Source guard entry.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_delSourceGuardEntry(
    const UI32_T                    unit,
    const CLX_SEC_SG_ENTRY_T        *ptr_entry);

/* FUNCTION NAME: hal_sec_getSourceGuardEntry
 * PURPOSE:
 *      Get a source guard entry.
 * INPUT:
 *      unit        --  Device unit number.
 * OUTPUT:
 *      ptr_entry   --  Source guard entry.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getSourceGuardEntry(
    const UI32_T                    unit,
    CLX_SEC_SG_ENTRY_T              *ptr_entry);

/* FUNCTION NAME: hal_sec_setEgressPort
 * PURPOSE:
 *      Set the egress portlist for an ingress port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Ingress port ID.
 *      port_bitmap --  Egress port bitmap.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      For a given ingress port, the packet is allowed to the egress port
 *      only if corresponding bit of the port is set in the port bitmap.
 */
CLX_ERROR_NO_T
hal_sec_setEgressPort(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_BITMAP_T         port_bitmap);

/* FUNCTION NAME: hal_sec_getEgressPort
 * PURPOSE:
 *      Get the egress portlist for an ingress port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Ingress port ID.
 * OUTPUT:
 *      port_bitmap --  Egress port bitmap.
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      For a given ingress port, the packet is allowed to the egress port
 *      only if corresponding bit of the port is set in the port bitmap.
 */
CLX_ERROR_NO_T
hal_sec_getEgressPort(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_BITMAP_T               port_bitmap);

/* FUNCTION NAME:   hal_sec_resetPortDefault
 * PURPOSE:
 *      Reset source port suppression.
 * INPUT:
 *      unit -- Device unit number
 *      port -- Ingress port ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Port beyond range.
 * NOTES:
 *      None
 */

CLX_ERROR_NO_T
hal_sec_resetPortDefault(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_sec_setPortDefault
 * PURPOSE:
 *      Set source port suppression.
 * INPUT:
 *      unit -- Device unit number
 *      port -- Ingress port ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Port beyond range.
 * NOTES:
 *      None
 */

CLX_ERROR_NO_T
hal_sec_setPortDefault(
    const UI32_T    unit,
    const UI32_T    port);

#endif /* End of HAL_SEC_H */


