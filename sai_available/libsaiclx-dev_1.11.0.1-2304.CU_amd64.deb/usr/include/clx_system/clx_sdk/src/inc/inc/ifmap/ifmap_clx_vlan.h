/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   ifmap_clx_vlan.h
 * PURPOSE:
 *      It provides user port to cl port translation for VLAN API.
 * NOTES:
 */

#ifndef IFMAP_CLX_VLAN_H
#define IFMAP_CLX_VLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* FUNCTION NAME:   ifmap_clx_vlan_setPort
 * PURPOSE:
 *      Add member and untag port list of existing vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_user_vlan_entry   -- VLAN entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *      VLAN entry includes member port list and untag port list.
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_setPort(
    const UI32_T              unit,
    const CLX_VLAN_ENTRY_T    *ptr_user_vlan_entry);

/* FUNCTION NAME:   ifmap_clx_vlan_getPort
 * PURPOSE:
 *      Get a vlan entry with specified 802.1Q vlan.
 * INPUT:
 *      unit                  -- Device unit number
 * OUTPUT:
 *      ptr_user_vlan_entry   -- VLAN entry
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_getPort(
    const UI32_T        unit,
    CLX_VLAN_ENTRY_T    *ptr_user_vlan_entry);

/* FUNCTION NAME:   ifmap_clx_vlan_traverseEntry
 * PURPOSE:
 *      Traverse vlan tagged/untagged member port for active vlan.
 * INPUT:
 *      unit        -- Device unit number
 *      callback    -- The callback function to be called for each traversed vlan entry
 *      ptr_cookie  -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_traverseEntry(
    const UI32_T                            unit,
    const CLX_VLAN_ENTRY_TRAVERSE_FUNC_T    callback,
    void                                    *ptr_cookie);

/* FUNCTION NAME:   ifmap_clx_vlan_setTypeEntry
 * PURPOSE:
 *      Set a type-based vlan entry.
 * INPUT:
 *      unit                -- Device unit number
 *      index               -- Index of the entry
 *      ptr_user_entry      -- Protocol-related and common L2 fields
 *      ptr_action          -- Assigned actions of vlan info
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_setTypeEntry(
    const UI32_T                      unit,
    const UI32_T                      index,
    const CLX_VLAN_CLASSIFY_TYPE_T    *ptr_user_entry,
    const CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   ifmap_clx_vlan_getTypeEntry
 * PURPOSE:
 *      Get a type-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      index                 -- Index of the entry
 * OUTPUT:
 *      ptr_user_entry        -- Protocol-related and common L2 fields
 *      ptr_action            -- Assigned actions of vlan info
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *      Type-based entry includes protocol type.
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_getTypeEntry(
    const UI32_T                unit,
    const UI32_T                index,
    CLX_VLAN_CLASSIFY_TYPE_T    *ptr_user_entry,
    CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   ifmap_clx_vlan_setAddrEntry
 * PURPOSE:
 *      Set a address-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      index                 -- Index of the entry
 *      ptr_user_entry        -- L2/L3 address-related and common L2 fields
 *      ptr_action            -- Assigned actions of vlan info
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *      Address-based entry includes mac and ip address.
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_setAddrEntry(
    const UI32_T                      unit,
    const UI32_T                      index,
    const CLX_VLAN_CLASSIFY_ADDR_T    *ptr_user_entry,
    const CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   ifmap_clx_vlan_getAddrEntry
 * PURPOSE:
 *      Get a address-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      index                 -- Index of the entry
 * OUTPUT:
 *      ptr_user_entry        -- L2/L3 address-related and common L2 fields
 *      ptr_action            -- Assigned actions of vlan info
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *      Address-based entry includes mac and ip address.
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_getAddrEntry(
    const UI32_T                unit,
    const UI32_T                index,
    CLX_VLAN_CLASSIFY_ADDR_T    *ptr_user_entry,
    CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   ifmap_clx_vlan_addPvlanEntry
 * PURPOSE:
 *      Add a pvlan entry for the primary vlan.
 * INPUT:
 *      unit                  -- Device unit number
 *      primary_vlan          -- 802.1Q VLAN id
 *      ptr_user_pvlan_entry  -- Pvlan entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_addPvlanEntry(
    const UI32_T                    unit,
    const CLX_VLAN_T                primary_vlan,
    const CLX_VLAN_PVLAN_ENTRY_T    *ptr_user_pvlan_entry);

/* FUNCTION NAME:   ifmap_clx_vlan_getPvlanEntry
 * PURPOSE:
 *      Get a pvlan entry for the primary vlan.
 * INPUT:
 *      unit                  -- Device unit number
 *      primary_vlan          -- 802.1Q VLAN id
 * OUTPUT:
 *      ptr_user_pvlan_entry  -- Pvlan entry
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_vlan_getPvlanEntry(
    const UI32_T              unit,
    const CLX_VLAN_T          primary_vlan,
    CLX_VLAN_PVLAN_ENTRY_T    *ptr_user_pvlan_entry);

#endif /* End of #ifndef IFMAP_CLX_VLAN_H */
