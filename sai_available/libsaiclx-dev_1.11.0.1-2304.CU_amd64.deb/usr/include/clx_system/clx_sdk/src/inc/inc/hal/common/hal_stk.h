/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_stk.h
 * PURPOSE:
 *      It provides hal stacking module API.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_STK_H
#define HAL_STK_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stk.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_STK_LCL_DI_TO_DI(__unit__, __chip__, __lcl_di__) \
        ((__chip__) * HAL_PORT_DI_NUM(__unit__) + (__lcl_di__))

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_STK_CHIP_MODE_PORT_CHIP = 0,
    HAL_STK_CHIP_MODE_CHASSIS_FAB,
    HAL_STK_CHIP_MODE_CHASSIS_CUSTOMIZE,
    HAL_STK_CHIP_MODE_LAST
} HAL_STK_CHIP_MODE_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
/* FUNCTION NAME:   [HAL] hal_stk_init
 * PURPOSE:
 *      Config stacking related register/table.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_init(
    const UI32_T    unit);

/* FUNCTION NAME:   [HAL] hal_stk_deinit
 * PURPOSE:
 *      Config stacking related register/table.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_deinit(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_stk_setMyChipId
 * PURPOSE:
 *      Set chip id.
 * INPUT:
 *      unit                -- Device unit number
 *      chip                -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_setMyChipId(
    const UI32_T    unit,
    const UI32_T    chip);

/* FUNCTION NAME:   hal_stk_getMyChipId
 * PURPOSE:
 *      Get chip id.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_chip            -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_getMyChipId(
    const UI32_T    unit,
    UI32_T          *ptr_chip);

/* FUNCTION NAME:   hal_stk_setNeighborChipId
 * PURPOSE:
 *      Set neighbor chip id. Each device has two neighbors in a ring topology.
 * INPUT:
 *      unit                -- Device unit number
 *      path                -- Path id
 *      chip                -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_setNeighborChipId(
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    chip);

/* FUNCTION NAME:   hal_stk_getNeighborChipId
 * PURPOSE:
 *      Get neighbor chip id. Each device has two neighbors in a ring topology.
 * INPUT:
 *      unit                -- Device unit number
 *      path                -- Path id
 *      ptr_chip            -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_getNeighborChipId(
    const UI32_T    unit,
    const UI32_T    path,
    UI32_T          *ptr_chip);

/* FUNCTION NAME:   hal_stk_setCufOffChipId
 * PURPOSE:
 *      Set cut off chip id. It is used to avoid packet looping in a ring topology.
 * INPUT:
 *      unit                -- Device unit number
 *      path                -- Path id
 *      chip                -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_setCutOffChipId(
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    chip);

/* FUNCTION NAME:   hal_stk_getCutOffChipId
 * PURPOSE:
 *      Get neighbor chip id. It is used to avoid packet looping in a ring topology.
 * INPUT:
 *      unit                -- Device unit number
 *      path                -- Path id
 *      ptr_chip            -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_getCutOffChipId(
    const UI32_T    unit,
    const UI32_T    path,
    UI32_T          *ptr_chip);

/* FUNCTION NAME:   hal_stk_addStackingPort
 * PURPOSE:
 *      Add stacking port to a stacking group path.
 * INPUT:
 *      unit                -- Device unit number
 *      path                -- Path id
 *      port                -- Port id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_addStackingPort(
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    port);

/* FUNCTION NAME:   hal_stk_delStackingPort
 * PURPOSE:
 *      Delete stacking port from a stacking group path.
 * INPUT:
 *      unit                -- Device unit number
 *      path                -- Path id
 *      chip_id             -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_delStackingPort(
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    port);

/* FUNCTION NAME:   hal_stk_getStackingPort
 * PURPOSE:
 *      Get stacking port list from a stacking group path.
 * INPUT:
 *      unit                -- Device unit number
 *      path                -- Path id
 *      ptr_port_list       -- Port list
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */

CLX_ERROR_NO_T
hal_stk_getStackingPort(
    const UI32_T         unit,
    const UI32_T         path,
    CLX_PORT_BITMAP_T    *ptr_port_list);

/* FUNCTION NAME:   hal_stk_setPathToRemoteChip
 * PURPOSE:
 *      Set a path to the remote chip
 * INPUT:
 *      unit                -- Device unit number
 *      path                -- Path id
 *      chip                -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_setPathToRemoteChip(
    const UI32_T    unit,
    const UI32_T    path,
    const UI32_T    chip);

/* FUNCTION NAME:   hal_stk_addStackingPortToCpu
 * PURPOSE:
 *      Add stacking port to a stacking group path for packet to CPU.
 * INPUT:
 *      unit                -- Device unit number
 *      cpu_path            -- Path id
 *      port                -- Port id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_addStackingPortToCpu(
    const UI32_T    unit,
    const UI32_T    cpu_path,
    const UI32_T    port);

/* FUNCTION NAME:   hal_stk_delStackingPortToCpu
 * PURPOSE:
 *      Delete stacking port from a stacking group path for packet to CPU.
 * INPUT:
 *      unit                -- Device unit number
 *      cpu_path            -- Path id
 *      chip_id             -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_delStackingPortToCpu(
    const UI32_T    unit,
    const UI32_T    cpu_path,
    const UI32_T    port);

/* FUNCTION NAME:   hal_stk_getStackingPortToCpu
 * PURPOSE:
 *      Get stacking port list from a stacking group path for packet to CPU.
 * INPUT:
 *      unit                -- Device unit number
 *      cpu_path            -- Path id
 *      ptr_port_list       -- Port list
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */

CLX_ERROR_NO_T
hal_stk_getStackingPortToCpu(
    const UI32_T         unit,
    const UI32_T         cpu_path,
    CLX_PORT_BITMAP_T    *ptr_port_list);

/* FUNCTION NAME:   hal_stk_setCpuPathToRemoteChip
 * PURPOSE:
 *      Set a cpu path to the remote chip
 * INPUT:
 *      unit                -- Device unit number
 *      cpu_path            -- Path id
 *      chip                -- Device chip id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_setCpuPathToRemoteChip(
    const UI32_T    unit,
    const UI32_T    cpu_path,
    const UI32_T    chip);

/* FUNCTION NAME:   hal_stk_setReasonMapping
 * PURPOSE:
 *      Set the reason bitmap to trap packets to the remote chip
 * INPUT:
 *      unit                -- Device unit number
 *      chip                -- Device chip id
 *      reason_bitmap       -- The reason bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_setReasonMapping(
    const UI32_T                        unit,
    const UI32_T                        chip,
    const CLX_PKT_RX_REASON_BITMAP_T    reason_bitmap);

/* FUNCTION NAME:   hal_stk_getReasonMapping
 * PURPOSE:
 *      Get the reason bitmap which traps packets to the target remote chip
 * INPUT:
 *      unit                -- Device unit number
 *      chip                -- Device chip id
 *      ptr_reason_bitmap   -- Pointer to the reason bitmap obtained
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_getReasonMapping(
    const UI32_T                  unit,
    const UI32_T                  chip,
    CLX_PKT_RX_REASON_BITMAP_T    *ptr_reason_bitmap);


/* EXPORTED HAL PROGRAMS
 */

/* FUNCTION NAME:   hal_stk_getFabPortBmp
 * PURPOSE:
 *      Get fabric port bitmap in hw plane port view.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_pp_pbmp         -- mgid port bitmap   (optional)
 *      cl_pbmp             -- CLX_PORT_BITMAP_T  (optional)
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. For pp_pbmp size, please reference HAL_ITM_PBM_WORDS.
 */
CLX_ERROR_NO_T
hal_stk_getFabPortBmp(
    const UI32_T         unit,
    UI32_T               *ptr_pp_pbmp,
    CLX_PORT_BITMAP_T    cl_pbmp);

/* FUNCTION NAME:   hal_stk_checkFabPort
 * PURPOSE:
 *      Check given port is used as fabric port or not.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port
 * OUTPUT:
 *      *ptr_is_fab         -- 1 : used as FAB port
 *                             0 : used as front port
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_checkFabPort(
    const UI32_T    unit,
    const UI32_T    port,
    BOOL_T          *ptr_is_fab);

/* FUNCTION NAME:   hal_stk_setStackingPortQueueMapping
 * PURPOSE:
 *      Set the egress stacking port queue for a specific remote cpu queue
 *      when Tx packet to remote cpu.
 * INPUT:
 *      unit                -- Device unit number
 *      rmt_cpu_queue       -- Remote CPU queue
 *      stacking_queue      -- Egress stacking port queue
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_setStackingPortQueueMapping(
    const UI32_T    unit,
    const UI32_T    rmt_cpu_queue,
    const UI32_T    stacking_queue);

/* FUNCTION NAME:   hal_stk_getStackingPortQueueMapping
 * PURPOSE:
 *      Get the egress stacking port queuefor a specific remote cpu queue
 *      when Tx packet to remote cpu.
 * INPUT:
 *      unit                -- Device unit number
 *      rmt_cpu_queue       -- Remote CPU queue
 * OUTPUT:
 *      ptr_stacking_queue  -- Egress stacking port queue
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_getStackingPortQueueMapping(
    const UI32_T    unit,
    const UI32_T    rmt_cpu_queue,
    UI32_T          *ptr_stacking_queue);

/* FUNCTION NAME:   hal_stk_setDilEntry
 * PURPOSE:
 *      Get the DIL entry.
 * INPUT:
 *      unit                -- Device unit number
 *      di                  -- Destination index
 *      ptr_dil_entry       -- DIL entry
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_setDilEntry(
    const UI32_T            unit,
    const UI32_T            di,
    const CLX_STK_DIL_T     *ptr_dil_entry);

/* FUNCTION NAME:   hal_stk_getDilEntry
 * PURPOSE:
 *      Get the DIL entry.
 * INPUT:
 *      unit                -- Device unit number
 *      di                  -- Destination index
 * OUTPUT:
 *      ptr_dil_entry       -- DIL entry
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stk_getDilEntry(
    const UI32_T    unit,
    const UI32_T    di,
    CLX_STK_DIL_T   *ptr_dil_entry);

/* FUNCTION NAME:   hal_stk_getPathNum
 * PURPOSE:
 *      Get path number.
 * INPUT:
 *      unit                -- Device unit number
 * RETURN:
 *      UI32_T              -- path number
 * NOTES:
 *
 */
UI32_T
hal_stk_getPathNum(
    const UI32_T    unit);

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */
#endif
