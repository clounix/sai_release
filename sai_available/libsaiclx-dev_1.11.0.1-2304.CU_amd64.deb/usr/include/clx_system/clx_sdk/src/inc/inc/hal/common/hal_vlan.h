/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_vlan.h
 * PURPOSE:
 *  Define the declartion for VLAN module for CL8360, CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_VLAN_H
#define HAL_VLAN_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_swc.h>
#include <clx_vlan.h>
#include <hal/common/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* for setServiceRslt HAL API */
#define HAL_VLAN_SRV_RSLT_FLAGS_IGR_IS_NEW        (1U << 0)
#define HAL_VLAN_SRV_RSLT_FLAGS_EGR_IS_NEW        (1U << 1)
#define HAL_VLAN_SRV_RSLT_FLAGS_EGR_ALW_PRIO_TAG  (1U << 2)
#define HAL_VLAN_SRV_RSLT_FLAGS_LRN_COPY2         (1U << 3)
#define HAL_VLAN_SRV_RSLT_FLAGS_ALW_QINQ_TRANS_C  (1U << 4)

/* for getHwVidCtl */
#define HAL_VLAN_VID_CTL_FLAGS_KEEP_FRM_VID       (1U << 0)
#define HAL_VLAN_VID_CTL_FLAGS_NO_L2              (1U << 1)

/********** IDS_RSLT_SRV_FDID **********/
#define HAL_VLAN_FDID_ENTRY_NUM             (16384)
#define HAL_VLAN_FDID_ENTRY_MIN             (1)
#define HAL_VLAN_FDID_ENTRY_MAX             (16382) /* 16K - 2 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct HAL_VLAN_VID_CTL_S
{
    HAL_VID_CTL_TYP_ENUM_T    vid_ctl;
    UI16_T                    vid_1st;
    UI16_T                    vid_2nd;
} HAL_VLAN_VID_CTL_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */

/* FUNCTION NAME:   hal_vlan_init
 * PURPOSE:
 *     Init vlan module.
 * INPUT:
 *      unit --  Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    --  Operate success.
 *      CLX_E_OTHER --  Init fail.
 * NOTES:
  */
CLX_ERROR_NO_T
hal_vlan_init(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_vlan_deinit
 * PURPOSE:
 *     Init vlan module.
 * INPUT:
 *      unit --  Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operate success.
 *      CLX_E_OTHER --  Init fail.
 * NOTES:
  */
CLX_ERROR_NO_T
hal_vlan_deinit(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_vlan_setPortDefault
 * PURPOSE:
 *      Apply default vlan related properties for the new created port:
 *      (1) Join default vlan as untagged member port
 *      (2) Join default vlan flooding member
 * INPUT:
 *      unit -- Device unit number
 *      port -- Port number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Operate success.
 *      CLX_E_OTHER -- Operate fail.
 * NOTES:
 *      (1) CLX/Hw design support modify member port of an un-active VLAN.
 */
CLX_ERROR_NO_T
hal_vlan_setPortDefault(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_vlan_resetPortDefault
 * PURPOSE:
 *      Reset default vlan related properties for the deleted port:
 *      (1) Remove from default vlan member port
 *      (2) Remove from default vlan flooding member
 * INPUT:
 *      unit -- Device unit number
 *      port -- Port number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Operate success.
 *      CLX_E_OTHER -- Operate fail.
 * NOTES:
 *      (1) CLX/Hw design support modify member port of an un-active VLAN.
 */
CLX_ERROR_NO_T
hal_vlan_resetPortDefault(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_vlan_dumpDb
 * PURPOSE:
 *      Dump db for debug.
 * INPUT:
 *      unit                -- Device unit number
 *      flags               -- Reference HAL_VLAN_DB_DUMP_FLAGS_XXX
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_OTHERS        -- Operate failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_dumpDb(
    const UI32_T    unit,
    const UI32_T    flags);

/* FUNCTION NAME:   hal_vlan_dumpReg
 * PURPOSE:
 *      Dump table/register for debug.
 * INPUT:
 *      unit                -- Device unit number
 *      flags               -- Reference HAL_VLAN_REG_DUMP_FLAGS_XXX
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_OTHERS        -- Operate failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_dumpReg(
    const UI32_T    unit,
    const UI32_T    flags);

/* FUNCTION NAME:   hal_vlan_createVlan
 * PURPOSE:
 *     Create vlan entries.
 * INPUT:
 *      unit --  Device unit number.
 *      vlan --  802.1Q VLAN associated with the entry.
 *               The 802.1Q VLAN id range is 1-4094.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      This function will create vlan entry and set fields of vlan entry include portlist, untag portlist to default
 *      value.
 */
CLX_ERROR_NO_T
hal_vlan_createVlan(
    const UI32_T    unit,
    const UI32_T    vid);

/* FUNCTION NAME:   hal_vlan_delVlan
 * PURPOSE:
 *     Delete vlan entries.
 * INPUT:
 *      unit --  Device unit number.
 *      vlan --  802.1Q VLAN associated with the entry.
 *               The 802.1Q VLAN id range is 1-4094.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      This function will delete a vlan entry.
 */
CLX_ERROR_NO_T
hal_vlan_delVlan(
    const UI32_T    unit,
    const UI32_T    vid);

/* FUNCTION NAME:   hal_vlan_createBridgeDomain
 * PURPOSE:
 *      Create a bridge domain.
 * INPUT:
 *      unit -- Device unit number
 *      bdid -- The Bridge domain id started from 1.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             -- Operate success.
 *      CLX_E_BAD_PARAMETER  -- Bad parameter.
 * NOTES:
 *      Will enable fdid only.
 */
CLX_ERROR_NO_T
hal_vlan_createBridgeDomain(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid);

/* FUNCTION NAME:   hal_vlan_destroyBridgeDomain
 * PURPOSE:
 *      Destory a forwarding domain entry.
 * INPUT:
 *      unit -- Device unit number
 *      bdid -- L2 bridge domain id started from 1.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK             -- Operate success.
 *      CLX_E_BAD_PARAMETER  -- Bad parameter.
 * NOTES:
 *      Will disable fdid only.
 */
CLX_ERROR_NO_T
hal_vlan_destroyBridgeDomain(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid);

/* FUNCTION NAME:   hal_vlan_setProperty
 * PURPOSE:
 *      Set properties of the bridge domain.
 * INPUT:
 *      unit                -- Device unit number
 *      vlan                -- Vlan or BD ID
 *      property            -- Property type
 *      param0              -- First parameter
 *      param1              -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Operate failed.
 * NOTES:
 *      User should create this bridge domain before setting property.
 */
CLX_ERROR_NO_T
hal_vlan_setProperty(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid,
    const CLX_VLAN_PROPERTY_T    property,
    const UI32_T                 param0,
    const UI32_T                 param1);

/* FUNCTION NAME:   hal_vlan_getProperty
 * PURPOSE:
 *      Get properties of the bridge domain.
 * INPUT:
 *      unit                -- Device unit number
 *      bdid                -- Bridge domain id
 *      property            -- Property type
 * OUTPUT:
 *      *ptr_param0         -- Ptr of first parameter
 *      *ptr_param1         -- Ptr of second parameter
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Operate failed.
 * NOTES:
 *      User should create this bridge domain before getting property.
 */
CLX_ERROR_NO_T
hal_vlan_getProperty(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid,
    const CLX_VLAN_PROPERTY_T    property,
    UI32_T                       *ptr_param0,
    UI32_T                       *ptr_param1);

/* FUNCTION NAME:   hal_vlan_setService
 * PURPOSE:
 *      Set vlan-based service l2:
 * INPUT:
 *      unit    -- Device unit number.
 *      vid     -- VLAN id.
 *      ptr_srv -- Service control.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_BAD_PARAM  -- Bad parameter
 *      CLX_E_OTHERS     -- Operate failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_setService(
    const UI32_T                unit,
    const CLX_VLAN_T            vid,
    const CLX_PORT_SEG_SRV_T    *ptr_srv);

/* FUNCTION NAME:   hal_vlan_getService
 * PURPOSE:
 *      Get vlan-based service l2.
 * INPUT:
 *      unit    -- Device unit number.
 *      vid     -- VLAN id.
 * OUTPUT:
 *      ptr_srv -- Service control.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_BAD_PARAM  -- Bad parameter
 *      CLX_E_OTHERS     -- Operate failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getService(
    const UI32_T          unit,
    const CLX_VLAN_T      vid,
    CLX_PORT_SEG_SRV_T    *ptr_srv);

/* FUNCTION NAME:   hal_vlan_setPort
 * PURPOSE:
 *      Add member and untag port list of existing vlan entry.
 * INPUT:
 *      unit --  Device unit number.
 *      port_bitmap -- Port bitmap indicate what port join VLAN member.
 *      ut_port_bitmap -- Untagged port bitmap indicated what port not tagging VLAN.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  No such entry.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_setPort(
    const UI32_T              unit,
    const CLX_VLAN_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   hal_vlan_getPort
 * PURPOSE:
 *      Get a vlan entry with specified 802.1Q vlan.
 * INPUT:
 *      unit --  Device unit number.
 *      vlan --  802.1Q VLAN associated with the entry.
 *               The 802.1Q VLAN id range is 1-4094.
 * OUTPUT:
 *      ptr_vlan_entry  --  The VLAN entry gotted.
 * RETURN:
 *      CLX_E_OK              --  Operation is success.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  No such entry in VLAN table.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getPort(
    const UI32_T        unit,
    CLX_VLAN_ENTRY_T    *ptr_vlan_entry);

/* FUNCTION NAME:   hal_vlan_traverseEntry
 * PURPOSE:
 *      Traverse vlan tagged/untagged member port for active vlan.
 * INPUT:
 *      unit        -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_traverseEntry(
    const UI32_T                            unit,
    const CLX_VLAN_ENTRY_TRAVERSE_FUNC_T    callback,
    void                                    *ptr_cookie);

/* FUNCTION NAME:   hal_vlan_addMacVlan
 * PURPOSE:
 *      Add a mac-based vlan entry.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_entry           -- MAC VLAN entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No more memory
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_addMacVlan(
    const UI32_T                       unit,
    const CLX_VLAN_MAC_VLAN_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   hal_vlan_delMacVlan
 * PURPOSE:
 *      Delete a mac-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_entry             -- MAC VLAN entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_delMacVlan(
    const UI32_T                       unit,
    const CLX_VLAN_MAC_VLAN_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   hal_vlan_getMacVlan
 * PURPOSE:
 *      Get a mac-based vlan entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_entry             -- Field "port" and "mac"
 * OUTPUT:
 *      ptr_entry             -- Field "vlan", "pcp" and "dei"
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- No such entry
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getMacVlan(
    const UI32_T                 unit,
    CLX_VLAN_MAC_VLAN_ENTRY_T    *ptr_entry);

/* FUNCTION NAME:   hal_vlan_setTypeEntry
 * PURPOSE:
 *      Set a type vlan assignment entry.
 * INPUT:
 *      unit        --  Device unit number.
 *      index       --  The index number of the entry.
 *      ptr_entry   --  Consist of port, frame vlan and protocol-related key.
 *      ptr_action  --  Assigned actions of vlan tag.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                --  Operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   --  No such entry in VLAN table.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_setTypeEntry(
    const UI32_T                      unit,
    const UI32_T                      index,
    const CLX_VLAN_CLASSIFY_TYPE_T    *ptr_entry,
    const CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   hal_vlan_getTypeEntry
 * PURPOSE:
 *      Get a type-based vlan assignment entry.
 * INPUT:
 *      unit       --  Device unit number.
 *      index      --  The index number of the entry.
 * OUTPUT:
 *      ptr_entry  --  Consist of port, frame vlan and protocol-related key.
 *      ptr_action --  Assigned actions of vlan tag.
 * RETURN:
 *      CLX_E_OK              --  Operation is success.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  No such entry in VLAN table.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getTypeEntry(
    const UI32_T                unit,
    const UI32_T                index,
    CLX_VLAN_CLASSIFY_TYPE_T    *ptr_entry,
    CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   hal_vlan_setAddrEntry
 * PURPOSE:
 *      Set a Address-based vlan assignment entry.
 * INPUT:
 *      unit       --  Device unit number.
 *      index      --  The index number of the entry.
 *      ptr_entry  --  Consist of port, frame vlan and mac/subnet-related key.
 *      ptr_action --  Assigned actions of vlan tag.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              --  Operation is success.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  No such entry in VLAN table.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_setAddrEntry(
    const UI32_T                      unit,
    const UI32_T                      index,
    const CLX_VLAN_CLASSIFY_ADDR_T    *ptr_entry,
    const CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   hal_vlan_getAddrEntry
 * PURPOSE:
 *      Get a Address-based vlan assignment entry.
 * INPUT:
 *      unit        --  Device unit number.
 *      index       --  The index number of the entry.
 * OUTPUT:
 *      ptr_entry   --  Consist of port, frame vlan and mac/subnet-related key.
 *      ptr_action  --  Assigned actions of vlan tag.
 * RETURN:
 *      CLX_E_OK                --  Operation is success.
 *      CLX_E_BAD_PARAMETER     --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND   --  No such entry in VLAN table.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getAddrEntry(
    const UI32_T                unit,
    const UI32_T                index,
    CLX_VLAN_CLASSIFY_ADDR_T    *ptr_entry,
    CLX_VLAN_TAG_ACTION_T       *ptr_action);

/* FUNCTION NAME:   hal_vlan_addPvlanEntry
 * PURPOSE:
 *     add  pvlan entry for a primary vlan.
 * INPUT:
 *      unit --  Device unit number.
 *      vlan --  802.1Q VLAN associated with the entry.
 *               The 802.1Q VLAN id range is 1-4094.
 *      ptr_pvlan_entry -- The pvlan entry will be set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              --  Operate success.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  No such entry.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_addPvlanEntry(
    const UI32_T                    unit,
    const UI32_T                    primary_vlan,
    const CLX_VLAN_PVLAN_ENTRY_T    *ptr_pvlan_entry);

/* FUNCTION NAME:   hal_vlan_delPvlanEntry
 * PURPOSE:
 *      Delete a pvlan entry for a primary vlan.
 * INPUT:
 *      unit --  Device unit number.
 *      vlan --  802.1Q VLAN associated with the entry.
 *               The 802.1Q VLAN id range is 1-4094.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              --  Operate success.
 *      CLX_E_BAD_PARAMETER   --  Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND --  No such entry.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_delPvlanEntry(
    const UI32_T    unit,
    const UI32_T    primary_vlan);

/* FUNCTION NAME:   hal_vlan_getPvlanEntry
 * PURPOSE:
 *      Get a pvlan entry for a primary vlan.
 * INPUT:
 *      unit                   -- Device unit number.
 *      primary_vlan           -- 802.1Q VLAN associated with the entry.
 *                                The 802.1Q VLAN id range is 1-4094.
 * OUTPUT:
 *      ptr_pvlan_entry        -- The pvlan entry will be got.
 * RETURN:
 *      CLX_E_OK               -- Operate success.
 *      CLX_E_BAD_PARAMETER    -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND  -- No such entry.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getPvlanEntry(
    const UI32_T              unit,
    const UI32_T              primary_vlan,
    CLX_VLAN_PVLAN_ENTRY_T    *ptr_pvlan_entry);

/************************************/
/* EXPOSED HAL PROGRAMS             */
/************************************/
/* FUNCTION NAME:   hal_vlan_initServiceRslt
 * PURPOSE:
 *      [HAL] Configure ingress/egress service hw table with default value
 * INPUT:
 *      unit      -- Device unit number
 *      srv_idx   -- Index of service table
 *      dir       -- Configure igr/egr/both service table
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     -- Operate success.
 *      CLX_E_OTHERS -- Operate failed.
 * NOTES:
 *      1. Should allocate srv idx by each module.
 */
CLX_ERROR_NO_T
hal_vlan_initServiceRslt(
    const UI32_T       unit,
    const UI32_T       srv_idx,
    const CLX_DIR_T    dir);

/* FUNCTION NAME:   hal_vlan_setServiceRslt
 * PURPOSE:
 *      [HAL] Configure ingress/egress service hw table
 * INPUT:
 *      unit      -- Device unit number
 *      srv_idx   -- Index of service table
 *      dir       -- Configure igr/egr/both service table
 *      ptr_srv   -- Service control
 *      sst       -- Per service suppression tag value (0-31)
 *      flags     -- [0] igr_is_new: 1 means first config this igr srv idx, will skip igr resource check
 *                -- [1] egr_is_new: 1 means first config this egr srv idx, will skip egr resource check
 *                -- [2] alw_prio_tag = 1 - Allow egress frame content priority tag
 *                                      0 - pop priority tag
 *                -- please reference HAL_VLAN_SRV_RSLT_FLAGS_* in hal_vlan.h
 *      set_vid_ctl_as_is   -- Set IEV_RSLT_U_L2.vid_ctl = as_is
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     -- Operate success.
 *      CLX_E_OTHERS -- Operate failed.
 * NOTES:
 *      1. Should allocate srv idx by each module.
 *      2. Should create bridge domain first.
 */
CLX_ERROR_NO_T
hal_vlan_setServiceRslt(
    const UI32_T                unit,
    const UI32_T                srv_idx,
    const CLX_DIR_T             dir,
    const CLX_PORT_SEG_SRV_T    *ptr_srv,
    const UI32_T                sst,
    const UI32_T                flags,
    const UI32_T                set_vid_ctl_as_is);

/* FUNCTION NAME:   hal_vlan_getServiceRslt
 * PURPOSE:
 *      [HAL] Get configured ingress/egress service hw table
 * INPUT:
 *      unit         -- Device unit number
 *      srv_idx      -- Index of service table
 *      dir          -- Get igr/egr/both service table
 * OUTPUT:
 *      ptr_srv      -- Service control
 * RETURN:
 *      CLX_E_OK     -- Operate success.
 *      CLX_E_OTHERS -- Operate failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getServiceRslt(
    const UI32_T          unit,
    const UI32_T          srv_idx,
    const CLX_DIR_T       dir,
    CLX_PORT_SEG_SRV_T    *ptr_srv);

/* FUNCTION NAME:   hal_vlan_freeServiceRsltProf
 * PURPOSE:
 *      [HAL] Free all profile idx in service entry allocated by setServiceRslt.
 * INPUT:
 *      unit         -- Device unit number
 *      srv_idx      -- Index of service table
 *      dir          -- Configure igr/egr/both service table
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     -- Operate success.
 *      CLX_E_OTHERS -- Operate failed.
 * NOTES:
 *      Will NOT free service entry since srv_idx in controlled by each module.
 */
CLX_ERROR_NO_T
hal_vlan_freeServiceRsltProf(
    const UI32_T       unit,
    const UI32_T       srv_idx,
    const CLX_DIR_T    dir);

/* FUNCTION NAME:   hal_vlan_transIntfToHwPrecedence
 * PURPOSE:
 *      [HAL] Translate interface view precedence to hw view precedence value.
 * INPUT:
 *      unit              -- Device unit number
 *      precedence        -- User interface view precedence
 * OUTPUT:
 *      ptr_hw_precedence -- Hw interface view precedence
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_OTHERS      -- Operate failed
 * NOTES:
 */
CLX_ERROR_NO_T
hal_vlan_transIntfToHwPrecedence(
    const UI32_T                   unit,
    const CLX_VLAN_PRECEDENCE_T    precedence,
    UI32_T                         *ptr_hw_precedence);

/* FUNCTION NAME:   hal_vlan_transHwToIntfPrecedence
 * PURPOSE:
 *      [HAL] Translate hw view precedence to interface view precedence value.
 * INPUT:
 *      unit              -- Device unit number
 *      hw_precedence     -- Hw interface view precedence
 * OUTPUT:
 *      ptr_precedence    -- User interface view precedence
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_OTHERS      -- Operate failed
 * NOTES:
 */
CLX_ERROR_NO_T
hal_vlan_transHwToIntfPrecedence(
    const UI32_T             unit,
    const UI32_T             hw_precedence,
    CLX_VLAN_PRECEDENCE_T    *ptr_precedence);

/* FUNCTION NAME:   hal_vlan_setVlanFilter
 * PURPOSE:
 *      Set igr/egr vlan filtering enable/disable.
 * INPUT:
 *      unit     -- Device unit number
 *      port     -- Physical port id
 *      dir      -- Config igr or egr setting
 *      enable   -- Enable/Disable vlan filtering
 * OUTPUT:
 *      none
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_setVlanFilter(
    const UI32_T       unit,
    const UI32_T       port,
    const CLX_DIR_T    dir,
    const UI32_T       enable);

/* FUNCTION NAME:   hal_vlan_getVlanFilter
 * PURPOSE:
 *      Get igr/egr vlan filtering enable/disable.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Physical port id
 *      dir         -- Config igr or egr setting
 * OUTPUT:
 *      *ptr_enable -- Enable/Disable vlan filtering
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getVlanFilter(
    const UI32_T       unit,
    const UI32_T       port,
    const CLX_DIR_T    dir,
    UI32_T             *ptr_enable);

/* FUNCTION NAME:   hal_vlan_checkPortUseVlanKeep
 * PURPOSE:
 *      Check given port is used as following scenario which allow learning keep:
 *      1. PVLAN trunk port
 *      2. QinQ NNI port
 *      3. Remote port (cannot check, treated as not-allow)
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Port (native/unit/lag port)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Check pass
 *      CLX_E_BAD_PARAMETER -- Check fail
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_checkPortUseVlanKeep(
    const UI32_T        unit,
    const CLX_PORT_T    port);

/* FUNCTION NAME:   hal_vlan_transToHwVidCtl
 * PURPOSE:
 *      Get hw-view vid_ctl/1st/2nd from user-view vlan action for end-point port
 * INPUT:
 *      unit         -- Device unit number
 *      vlan_act     -- User-view vlan action
 *      *ptr_tag_act -- Vlan tag info (optional; only SET would use)
 *      flags        -- Refer HAL_VLAN_VID_CTL_FLAGS_*
 * OUTPUT:
 *      vid_ctl      -- Hw-view vid_ctl/1st/2nd
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_transToHwVidCtl(
    const UI32_T                   unit,
    const CLX_VLAN_ACTION_T        vlan_act,
    const CLX_VLAN_TAG_ACTION_T    *ptr_tag_act,
    const UI32_T                   flags,
    HAL_VLAN_VID_CTL_T             *ptr_vid_ctl);

/* FUNCTION NAME:   hal_vlan_transToSwVlanAct
 * PURPOSE:
 *      Get user-view vlan action from hw-view vid_ctl for end-point port
 * INPUT:
 *      unit        -- Device unit number
 *      ptr_vid_ctl -- Hw-view vid_ctl/1st/2nd
 *      flags       -- Refer HAL_VLAN_VID_CTL_FLAGS_*
 * OUTPUT:
 *      vlan_act    -- User-view vlan action
 *      ptr_tag_act -- Vlan tag info
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_transToSwVlanAct(
    const UI32_T                unit,
    const HAL_VLAN_VID_CTL_T    *ptr_vid_ctl,
    const UI32_T                flags,
    CLX_VLAN_ACTION_T           *ptr_vlan_act,
    CLX_VLAN_TAG_ACTION_T       *ptr_tag_act);

/* FUNCTION NAME:   hal_vlan_getCapacity
 * PURPOSE:
 *      Get capacity of vlan-related hw resource type
 * INPUT:
 *      unit        -- Device unit number
 *      type        -- Vlan-related hw resource type
 *      param       -- Optional parameter
 * OUTPUT:
 *      ptr_size    -- Capacity size
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getCapacity(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_size);

/* FUNCTION NAME:   hal_vlan_getUsage
 * PURPOSE:
 *      Get used of vlan-related hw resource type
 * INPUT:
 *      unit        -- Device unit number
 *      type        -- Vlan-related hw resource type
 *      param       -- Optional parameter
 * OUTPUT:
 *      ptr_cnt     -- Count of usage
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vlan_getUsage(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_cnt);

/* FUNCTION NAME:   hal_vlan_setKeepDei
 * PURPOSE:
 *      Set keep dei setting
 * INPUT:
 *      unit   -- Device unit number
 *      enable -- Keep dei is enable or not
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *      1. CL8360 not support (not register in cmn drv vector)
 */
CLX_ERROR_NO_T
hal_vlan_setKeepDei(
    const UI32_T    unit,
    const UI32_T    enable);

/* FUNCTION NAME:   hal_vlan_getKeepDei
 * PURPOSE:
 *      Get keep dei setting
 * INPUT:
 *      unit       -- Device unit number
 * OUTPUT:
 *      ptr_enable -- Keep dei is enable or not
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *      1. CL8360 not support (not register in cmn drv vector)
 */
CLX_ERROR_NO_T
hal_vlan_getKeepDei(
    const UI32_T    unit,
    UI32_T          *ptr_enable);



/* FUNCTION NAME:   hal_vlan_bindL3Intf
 * PURPOSE:
 *      Bind fdid to the L3 intf
 * INPUT:
 *      unit       -- Device unit number
 *      bdid       -- Bridge domain ID
 *      bind       -- Bind L3 intf to the BD or not
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK          -- Operate success
 *      CLX_E_NOT_SUPPORT -- Not supported feature
 * NOTES:
 *      1. NB not support (no need to bind bd to L3 intf)
 */
CLX_ERROR_NO_T
hal_vlan_bindL3Intf(
    const UI32_T                 unit,
    const CLX_BRIDGE_DOMAIN_T    bdid,
    const BOOL_T                 bind
);

/* FUNCTION NAME:   hal_vlan_printCreatedBdId
 * PURPOSE:
 *      Print created bridge domain ID
 * INPUT:
 *      unit       -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 * NOTES:
 */
void
hal_vlan_printCreatedBdId(
    const UI32_T                 unit);

#endif /* End of HAL_VLAN_H */
