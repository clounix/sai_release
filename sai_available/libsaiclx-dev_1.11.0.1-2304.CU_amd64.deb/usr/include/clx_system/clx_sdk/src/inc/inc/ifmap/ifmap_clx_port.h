/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   ifmap_clx_port.h
 * PURPOSE:
 *      It provides user port to CLX port translation API.
 * NOTES:
 */

#ifndef IFMAP_CLX_PORT_H
#define IFMAP_CLX_PORT_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <hal/common/hal_phy.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   ifmap_clx_port_setSpeed
 * PURPOSE:
 *      To set the speed for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      speed               -- The speed of the physical port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setSpeed(
    const UI32_T              unit,
    const UI32_T              port,
    const CLX_PORT_SPEED_T    speed);


/* FUNCTION NAME:   ifmap_clx_port_getSpeed
 * PURPOSE:
 *      To get the speed for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_speed           -- The speed of the physical port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getSpeed(
    const UI32_T        unit,
    const UI32_T        port,
    CLX_PORT_SPEED_T    *ptr_speed);

/* FUNCTION NAME:   ifmap_clx_port_setFlowCtrl
 * PURPOSE:
 *      To set the flow control configuration for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      fc                  -- The flow control configuration of the physical port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setFlowCtrl(
    const UI32_T           unit,
    const UI32_T           port,
    const CLX_PORT_FC_T    fc);

/* FUNCTION NAME:   ifmap_clx_port_getFlowCtrl
 * PURPOSE:
 *      To get the flow control configuration for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_fc              -- The flow control configuration of the physical port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getFlowCtrl(
    const UI32_T     unit,
    const UI32_T     port,
    CLX_PORT_FC_T    *ptr_fc);

/* FUNCTION NAME:   ifmap_clx_port_setPriFlowCtrl
 * PURPOSE:
 *      To set the PFC configuration for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      pri                 -- The priority number 0~7
 *      pfc                 -- The PFC configuration of the physical port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setPriFlowCtrl(
    const UI32_T           unit,
    const UI32_T           port,
    const UI8_T            pri,
    const CLX_PORT_FC_T    pfc);

/* FUNCTION NAME:   ifmap_clx_port_getPriFlowCtrl
 * PURPOSE:
 *      To get the PFC configuration for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      pri                 -- The priority number 0~7
 * OUTPUT:
 *      ptr_pfc             -- The PFC configuration of the physical port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getPriFlowCtrl(
    const UI32_T     unit,
    const UI32_T     port,
    const UI8_T      pri,
    CLX_PORT_FC_T    *ptr_pfc);

/* FUNCTION NAME:   ifmap_clx_port_setEeeMode
 * PURPOSE:
 *      To set the EEE mode for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      mode                -- The EEE mode of the physical port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setEeeMode(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_EEE_MODE_T    mode);

/* FUNCTION NAME:   ifmap_clx_port_getEeeMode
 * PURPOSE:
 *      To get the EEE mode for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_mode            -- The EEE mode of the physical port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getEeeMode(
    const UI32_T           unit,
    const UI32_T           port,
    CLX_PORT_EEE_MODE_T    *ptr_mode);

/* FUNCTION NAME:   ifmap_clx_port_setLocalAdvAbility
 * PURPOSE:
 *      To set the auto-negotiation advertisement for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      ptr_ability         -- Auto-negotiation ability setting per port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setLocalAdvAbility(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   ifmap_clx_port_getLocalAdvAbility
 * PURPOSE:
 *      To get the auto-negotiation advertisement for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ability         -- Auto-negotiation ability setting per port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getLocalAdvAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   ifmap_clx_port_getRemoteAdvAbility
 * PURPOSE:
 *      This API is used to get the auto-negotiation remote advertisement for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ability         -- Auto-negotiation ability setting per port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getRemoteAdvAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   ifmap_clx_port_getAbility
 * PURPOSE:
 *      This API is used to get the auto-negotiation ability for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ability         -- Auto-negotiation ability setting per port
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getAbility(
    const UI32_T          unit,
    const UI32_T          port,
    CLX_PORT_ABILITY_T    *ptr_ability);

/* FUNCTION NAME:   ifmap_clx_port_setLoopback
 * PURPOSE:
 *      This API is used to set the loopback for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      loopback            -- Loopback type:
 *                          CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                          CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                          CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setLoopback(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_LOOPBACK_T    loopback);

/* FUNCTION NAME:   ifmap_clx_port_getLoopback
 * PURPOSE:
 *      This API is used to get the loopback for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_loopback        -- Loopback type:
 *                          CLX_PORT_LOOPBACK_DISABLE: disable loopback.
 *                          CLX_PORT_LOOPBACK_PHY: local PHY loopback.
 *                          CLX_PORT_LOOPBACK_MAC: local MAC loopback.
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getLoopback(
    const UI32_T           unit,
    const UI32_T           port,
    CLX_PORT_LOOPBACK_T    *ptr_loopback);

/* FUNCTION NAME:   ifmap_clx_port_probe
 * PURPOSE:
 *      This API is used to probe a user port
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_probe(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   ifmap_clx_port_initPort
 * PURPOSE:
 *      This API is used to initialize a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_initPort(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   ifmap_clx_port_deinitPort
 * PURPOSE:
 *      This API is used to deinitialize a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_deinitPort(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   ifmap_clx_port_setMacAddr
 * PURPOSE:
 *      This API is used to set the MAC address for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      mac                 -- The MAC address
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setMacAddr(
    const UI32_T       unit,
    const UI32_T       port,
    const CLX_MAC_T    mac);

/* FUNCTION NAME:   ifmap_clx_port_getMacAddr
 * PURPOSE:
 *      This API is used to get the MAC address for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_mac             -- The MAC address
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getMacAddr(
    const UI32_T    unit,
    const UI32_T    port,
    CLX_MAC_T       *ptr_mac);

/* FUNCTION NAME:   ifmap_clx_port_getLink
 * PURPOSE:
 *      This API is used to get the physical link status for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_link            -- Link status (Reference to CLX_PORT_LINK_XXX)
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getLink(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_link);

/* FUNCTION NAME:   ifmap_clx_port_getFault
 * PURPOSE:
 *      To get the physical fault status for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_fault           -- Fault status (Reference to CLX_PORT_FAULT_XXX)
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getFault(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_fault);

/* FUNCTION NAME:   ifmap_clx_port_setMediumType
 * PURPOSE:
 *      This API is used to set the medium type for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      medium              -- Medium type
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setMediumType(
    const UI32_T                  unit,
    const UI32_T                  port,
    const CLX_PORT_MEDIUM_TYPE_T  medium);

/* FUNCTION NAME:   ifmap_clx_port_getMediumType
 * PURPOSE:
 *      This API is used to get the medium type for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_medium          -- Medium type
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getMediumType(
    const UI32_T              unit,
    const UI32_T              port,
    CLX_PORT_MEDIUM_TYPE_T    *ptr_medium);

/* FUNCTION NAME:   ifmap_clx_port_setPhyProperty
 * PURPOSE:
 *      This API is used to set the PHY property for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      location            -- PHY location
 *      property            -- PHY property type
 *      value_cnt           -- PHY property value count
 *      ptr_value           -- PHY property value array
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setPhyProperty(
    const UI32_T                     unit,
    const UI32_T                     port,
    const CLX_PORT_PHY_LOCATION_T    location,
    const CLX_PORT_PHY_PROPERTY_T    property,
    const UI32_T                     value_cnt,
    const UI32_T                     *ptr_value);

/* FUNCTION NAME:   ifmap_clx_port_getPhyProperty
 * PURPOSE:
 *      This API is used to get the property for a user port.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      location            -- PHY location
 *      property            -- PHY property type
 *      value_cnt           -- PHY property value count
 * OUTPUT:
 *      ptr_value           -- PHY property value array
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getPhyProperty(
    const UI32_T                     unit,
    const UI32_T                     port,
    const CLX_PORT_PHY_LOCATION_T    location,
    const CLX_PORT_PHY_PROPERTY_T    property,
    const UI32_T                     value_cnt,
    UI32_T                           *ptr_value);

/* FUNCTION NAME:   ifmap_clx_port_addSegServiceGroup
 * PURPOSE:
 *      This API is used to add a merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      merged_vid_min      -- Minimum value of merged vlan id
 *      merged_vid_max      -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
ifmap_clx_port_addSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   ifmap_clx_port_delSegServiceGroup
 * PURPOSE:
 *      This API is used to del a merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      merged_vid_min      -- Minimum value of merged vlan id
 *      merged_vid_max      -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
ifmap_clx_port_delSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   ifmap_clx_port_getSegServiceGroup
 * PURPOSE:
 *      This API is used to get a merged vlan group entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      port                  -- Physical port ID
 *      merged_vid_min        -- Minimum value of merged vlan id
 *      merged_vid_max        -- Maximum value of merged vlan id
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK              -- Entry exist
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      1. Would merged vlan id in range {merged_vid_min, merged_vid_max}
 *         to merged_vid_min when loop-up port-seg service table.
 */
CLX_ERROR_NO_T
ifmap_clx_port_getSegServiceGroup(
    const UI32_T        unit,
    const UI32_T        port,
    const CLX_VLAN_T    merged_vid_min,
    const CLX_VLAN_T    merged_vid_max);

/* FUNCTION NAME:   ifmap_clx_port_traverseSegServiceGroup
 * PURPOSE:
 *      This API is used to traverse merged vlan group entry.
 * INPUT:
 *      unit                -- Device unit number
 *      callback            -- The callback function of type CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_traverseSegServiceGroup(
    const UI32_T                                    unit,
    const CLX_PORT_SEG_SRV_GROUP_TRAVERSE_FUNC_T    callback,
    void                                            *ptr_cookie);

/* FUNCTION NAME:   ifmap_clx_port_addSegService
 * PURPOSE:
 *      This API is used to add a port seg service
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 *      ptr_seg_srv         -- segment service
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Not allow setting port with CLX_PORT_TYPE_LAG,
 *         CLX_PORT_TYPE_MPLS* or CLX_PORT_TYPE_CPU_PORT.
 *      2. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *         Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *         Setting port-based only, seg0 = seg1 = invalid value.
 */
CLX_ERROR_NO_T
ifmap_clx_port_addSegService(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const UI32_T                seg0,
    const UI32_T                seg1,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   ifmap_clx_port_delSegService
 * PURPOSE:
 *      This API is used to del a port seg service
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Not allow setting port with CLX_PORT_TYPE_LAG,
 *         CLX_PORT_TYPE_MPLS* or CLX_PORT_TYPE_CPU_PORT.
 *      2. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *         Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *         Setting port-based only, seg0 = seg1 = invalid value.
 */
CLX_ERROR_NO_T
ifmap_clx_port_delSegService(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    const UI32_T        seg0,
    const UI32_T        seg1);

/* FUNCTION NAME:   ifmap_clx_port_getSegService
 * PURPOSE:
 *      This API is used to get a port seg service
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 *      seg0                -- segment parameter 0
 *      seg1                -- segment parameter 1
 * OUTPUT:
 *      ptr_seg_srv         -- segment service
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      1. Not allow setting port with CLX_PORT_TYPE_LAG,
 *         CLX_PORT_TYPE_MPLS* or CLX_PORT_TYPE_CPU_PORT.
 *      2. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *         Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 *         Setting port-based only, seg0 = seg1 = invalid value.
 */
CLX_ERROR_NO_T
ifmap_clx_port_getSegService(
    const UI32_T          unit,
    const CLX_PORT_T      port,
    const UI32_T          seg0,
    const UI32_T          seg1,
    CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   ifmap_clx_port_setProperty
 * PURPOSE:
 *      Set Port property.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      property            -- Property type
 *      param0              -- First parameter
 *      param1              -- Second parameter
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setProperty(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_PROPERTY_T    property,
    const UI32_T                 param0,
    const UI32_T                 param1);

/* FUNCTION NAME:   ifmap_clx_port_getProperty
 * PURPOSE:
 *      Get switch control property.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      property            -- Property type
 * OUTPUT:
 *      *ptr_param0         -- Ptr of first parameter
 *      *ptr_param1         -- Ptr of second parameter
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getProperty(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_PROPERTY_T    property,
    UI32_T                       *ptr_param0,
    UI32_T                       *ptr_param1);

/* FUNCTION NAME:   ifmap_clx_port_setLaneMap
 * PURPOSE:
 *      This API is used to set the mapping between unit/port and eth-macro/lane
 *      number.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 *      eth_macro           -- physical ETH macro ID
 *      lane                -- Physical lane ID
 *      max_speed           -- The maximum speed of the physical port
 *      flags               -- Attributes of the physical port and refer to CLX_PORT_FLAGS_XXX
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      This API is suggested to be used during SDK initialization.
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_setLaneMap(
    const UI32_T              unit,
    const UI32_T              port,
    const UI32_T              eth_macro,
    const UI32_T              lane,
    const CLX_PORT_SPEED_T    max_speed,
    const UI32_T              flags);

/* FUNCTION NAME:   ifmap_clx_port_getLaneMap
 * PURPOSE:
 *      This API is used to get the mapping between unit/port and eth-macro/lane
 *      number.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_eth_macro       -- physical ETH macro ID
 *      ptr_lane            -- Physical lane ID
 *      ptr_max_speed       -- The maximum speed of the physical port
 *      ptr_flags           -- Attributes of the physical port and refer to CLX_PORT_FLAGS_XXX
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
ifmap_clx_port_getLaneMap(
    const UI32_T        unit,
    const UI32_T        port,
    UI32_T              *ptr_eth_macro,
    UI32_T              *ptr_lane,
    CLX_PORT_SPEED_T    *ptr_max_speed,
    UI32_T              *ptr_flags);

/* FUNCTION NAME:   ifmap_clx_port_createPort
 * PURPOSE:
 *      This API is used to create a UNIT_PORT object
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_port            -- The pointer of the UNIT_PORT object
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_port_createPort(
    const UI32_T    unit,
    const UI32_T    port,
    CLX_PORT_T      *ptr_port);

/* FUNCTION NAME:   ifmap_clx_port_destroyPort(
 * PURPOSE:
 *      This API is used to destroy a UNIT_PORT object
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- UNIT_PORT object
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_port_destroyPort(
    const UI32_T    unit,
    CLX_PORT_T      port);

/* FUNCTION NAME:   ifmap_clx_port_getPort
 * PURPOSE:
 *      This API is used to get UNIT_PORT object port from port.
 * INPUT:
 *      unit -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_port            -- The pointer of the UNIT_PORT
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_port_getPort(
    const UI32_T    unit,
    const UI32_T    port,
    CLX_PORT_T      *ptr_port);

/* FUNCTION NAME:   ifmap_clx_port_setIntfProperty
 * PURPOSE:
 *      This API is used to set the properties for a specified interface object
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_port_setIntfProperty(
    const UI32_T                      unit,
    const CLX_PORT_T                  port,
    const CLX_PORT_INTF_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   ifmap_clx_port_getIntfProperty
 * PURPOSE:
 *      This API is used to get the properties for a specified interface object
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 * OUTPUT:
 *      ptr_property        -- The pointer of the interface properties
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_port_getIntfProperty(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    CLX_PORT_INTF_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   ifmap_clx_port_getTsTxEntry
 * PURPOSE:
 *      Get port tx time stamp entry information.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ts_entry        -- Time stamp entry information
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_port_getTsTxEntry(
    const UI32_T           unit,
    const UI32_T           port,
    CLX_PORT_TS_ENTRY_T    *ptr_ts_entry);

/* FUNCTION NAME:   ifmap_clx_port_getTsRxEntry
 * PURPOSE:
 *      Get port rx time stamp entry information.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Physical port ID
 * OUTPUT:
 *      ptr_ts_entry        -- Time stamp entry information
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_port_getTsRxEntry(
    const UI32_T           unit,
    const UI32_T           port,
    CLX_PORT_TS_ENTRY_T    *ptr_ts_entry);

/* FUNCTION NAME:   ifmap_clx_port_getPortType
 * PURPOSE:
 *      Get port type.
 *      It is used to lookup corresponding database to get its key.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Interface object
 * OUTPUT:
 *      ptr_type            -- type of CLX_PORT_TYPE_T
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_OTHERS        -- Error occurs
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
ifmap_clx_port_getPortType(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    CLX_PORT_TYPE_T     *ptr_type);


/* FUNCTION NAME:   ifmap_clx_port_getStatus
 * PURPOSE:
 *      Get the status per physical port.
 * INPUT:
 *      unit       -- Device unit number
 *      port       -- Physical port id
 * OUTPUT:
 *      ptr_status -- Port status
 *                    speed  - reference to CLX_PORT_SPEED_T
 *                    link   - reference to CLX_PORT_LINK_XXX
 *                    fault  - reference to CLX_PORT_FAULT_XXX
 *                    rx_fc  - reference to CLX_PORT_FC_STATUS_XXX
 *                    rx_pfc - reference to CLX_PORT_FC_STATUS_XXX
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      There is 8 bits for 8 RX priority flow control status in rx_pfc.
 *      RX flow control status for priority x (x = 0~7) =
 *      rx_pfc & (CLX_PORT_FC_STATUS_ON << x)
 */
CLX_ERROR_NO_T
ifmap_clx_port_getStatus(
    const UI32_T         unit,
    const UI32_T         port,
    CLX_PORT_STATUS_T    *ptr_status);

CLX_ERROR_NO_T
ifmap_clx_port_setTxCoef(
    const UI32_T                     unit,
    const UI32_T                     port,
    const UI32_T                     lane_idx,
    const CLX_PORT_PHY_LOCATION_T    location,
    CLX_PORT_TX_COEF_T               *ptr_tx_coef);

CLX_ERROR_NO_T
ifmap_clx_port_getTxCoef(
    const UI32_T                     unit,
    const UI32_T                     port,
    const UI32_T                     lane_idx,
    const CLX_PORT_PHY_LOCATION_T    location,
    CLX_PORT_TX_COEF_T               *ptr_tx_coef);

CLX_ERROR_NO_T
ifmap_clx_port_getAutoNegEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_AUTO_NEG_TYPE_T        *an_en);

CLX_ERROR_NO_T
ifmap_clx_port_setAutoNegEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_AUTO_NEG_TYPE_T  enable);

CLX_ERROR_NO_T
ifmap_clx_port_getLinkTrainingEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_LINK_TRAINING_T        *enable);

CLX_ERROR_NO_T
ifmap_clx_port_setLinkTrainingEn(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    enable);

CLX_ERROR_NO_T
ifmap_clx_port_getLinkTrainingResult(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_PORT_LINK_TRAINING_RESULT_T     *status);

CLX_ERROR_NO_T
ifmap_clx_port_setAdvIntfType(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        intf_type);
#endif /* End of #ifndef IFMAP_CLX_PORT_H */

