/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_phy.h
 * PURPOSE:
 *      It provide HAL PHY module API.
 * NOTES:
 *
 */

#ifndef HAL_PHY_H
#define HAL_PHY_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PHY_BITS_PER_BYTE           (8)
#define HAL_PHY_BYTES_PER_WORD          (2)
#define HAL_PHY_BITS_PER_WORD           (HAL_PHY_BITS_PER_BYTE * HAL_PHY_BYTES_PER_WORD)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_PHY_FOREACH_ABILITY(__field_value__, __field_start__, __field_end__, __ability__) \
    for ((__ability__) = (__field_start__); \
         (__ability__) < (__field_end__); \
         (__ability__) <<= 1) \
        if (((__ability__) & (__field_value__)) > 0)

/* DATA TYPE DECLARACTIONS
 */
typedef enum
{
    HAL_PHY_MDIO_DEVICE_TYPE_PMA_PMD    = 1,
    HAL_PHY_MDIO_DEVICE_TYPE_WIS        = 2,
    HAL_PHY_MDIO_DEVICE_TYPE_PCS        = 3,
    HAL_PHY_MDIO_DEVICE_TYPE_PHY_XS     = 4,
    HAL_PHY_MDIO_DEVICE_TYPE_DTE_XS     = 5,
    HAL_PHY_MDIO_DEVICE_TYPE_TC         = 6,
    HAL_PHY_MDIO_DEVICE_TYPE_AN         = 7,
    HAL_PHY_MDIO_DEVICE_TYPE_VENDOR_1   = 30,
    HAL_PHY_MDIO_DEVICE_TYPE_VENDOR_2   = 31,
    HAL_PHY_MDIO_DEVICE_TYPE_LAST       = (0x1UL << 5) /* 5-bit vlaue for device type */
} HAL_PHY_MDIO_DEVICE_TYPE_T;

typedef enum
{
    HAL_PHY_ADMIN_STATE_TYPE_DISABLE = 0x0,
    HAL_PHY_ADMIN_STATE_TYPE_ENABLE,
    HAL_PHY_ADMIN_STATE_TYPE_LAST
} HAL_PHY_ADMIN_STATE_TYPE_T;

typedef enum
{
    HAL_PHY_LINK_STATE_TYPE_DOWN = 0x0,
    HAL_PHY_LINK_STATE_TYPE_UP,
    HAL_PHY_LINK_STATE_TYPE_LAST
} HAL_PHY_LINK_STATE_TYPE_T;

typedef enum
{
    HAL_PHY_SPEED_TYPE_1000M = 0x0,
    HAL_PHY_SPEED_TYPE_2500M,
    HAL_PHY_SPEED_TYPE_5G,
    HAL_PHY_SPEED_TYPE_10G,
    HAL_PHY_SPEED_TYPE_25G,
    HAL_PHY_SPEED_TYPE_26G,
    HAL_PHY_SPEED_TYPE_40G,
    HAL_PHY_SPEED_TYPE_50G,
    HAL_PHY_SPEED_TYPE_100G,
    HAL_PHY_SPEED_TYPE_200G,
    HAL_PHY_SPEED_TYPE_400G,
    HAL_PHY_SPEED_TYPE_LAST
} HAL_PHY_SPEED_TYPE_T;

typedef enum
{
    HAL_PHY_EEE_TYPE_DISABLE = 0x0,
    HAL_PHY_EEE_TYPE_ENABLE,
    HAL_PHY_EEE_TYPE_LAST
} HAL_PHY_EEE_TYPE_T;

typedef enum
{
    HAL_PHY_EEE_MODE_TYPE_DEEP_SLEEP = 0x0,
    HAL_PHY_EEE_MODE_TYPE_FAST_WAKE,
    HAL_PHY_EEE_MODE_TYPE_LAST
} HAL_PHY_EEE_MODE_TYPE_T;

typedef enum
{
    HAL_PHY_FEC_TYPE_DISABLE = 0x0,
    HAL_PHY_FEC_TYPE_ENABLE,
    /* 3 RSFECs: RS528/RS544/RS272 */
    HAL_PHY_FEC_TYPE_RS528,
    HAL_PHY_FEC_TYPE_RS544,
    HAL_PHY_FEC_TYPE_RS272,
    HAL_PHY_FEC_TYPE_LAST
} HAL_PHY_FEC_TYPE_T;

typedef enum
{
    HAL_PHY_FEC_CNT_TYPE_CERR = 0x0,
    HAL_PHY_FEC_CNT_TYPE_UCERR,
    HAL_PHY_FEC_CNT_TYPE_LANE_SERR,
    HAL_PHY_FEC_CNT_TYPE_LAST
} HAL_PHY_FEC_CNT_TYPE_T;

typedef struct HAL_PHY_FEC_CNT_S
{
    BOOL_T                          cnt_valid;
    UI32_T                          cnt_value;
} HAL_PHY_FEC_CNT_T;


typedef enum
{
    HAL_PHY_LOOPBACK_TYPE_DISABLE = 0x0,
    HAL_PHY_LOOPBACK_TYPE_LOCAL,
    HAL_PHY_LOOPBACK_TYPE_LAST
} HAL_PHY_LOOPBACK_TYPE_T;

typedef enum
{
    HAL_PHY_INTF_LOCATION_TYPE_INTERNAL = 0x0,
    HAL_PHY_INTF_LOCATION_TYPE_EXTERNAL_SYSTEM_SIDE,
    HAL_PHY_INTF_LOCATION_TYPE_EXTERNAL_LINE_SIDE,
    HAL_PHY_INTF_LOCATION_TYPE_LAST
} HAL_PHY_INTF_LOCATION_TYPE_T;

typedef enum
{
    HAL_PHY_PMA_INTF_TYPE_NONE = 0x0,
    HAL_PHY_PMA_INTF_TYPE_SGMII,
    HAL_PHY_PMA_INTF_TYPE_XFI,
    HAL_PHY_PMA_INTF_TYPE_SFI,
    HAL_PHY_PMA_INTF_TYPE_KR,
    HAL_PHY_PMA_INTF_TYPE_KR4,
    HAL_PHY_PMA_INTF_TYPE_CR4,
    HAL_PHY_PMA_INTF_TYPE_XLAUI,
    HAL_PHY_PMA_INTF_TYPE_XLPPI,
    HAL_PHY_PMA_INTF_TYPE_CAUI,
    HAL_PHY_PMA_INTF_TYPE_CPPI,
    HAL_PHY_PMA_INTF_TYPE_LAST
} HAL_PHY_PMA_INTF_TYPE_T;

typedef enum
{
    HAL_PHY_PMD_INTF_TYPE_SGMII = 0x0,
    HAL_PHY_PMD_INTF_TYPE_1000BASE_X,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_ER,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_LR,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_SR,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_KR,
    HAL_PHY_PMD_INTF_TYPE_10GBASE_CR,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_KR4,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_CR4,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_SR4,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_LR4,
    HAL_PHY_PMD_INTF_TYPE_40GBASE_ER4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_CR10,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_SR10,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_KR4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_CR4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_SR4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_LR4,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_ER4,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_KR4,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_CR4,
    HAL_PHY_PMD_INTF_TYPE_200GBASE_SR4,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_DR4,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_LR8,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_CR8,
    HAL_PHY_PMD_INTF_TYPE_400GBASE_SR16,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_KR,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_CR,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_SR,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_LR,
    HAL_PHY_PMD_INTF_TYPE_25GBASE_ER,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_KR,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_CR,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_SR,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_CR2,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_SR2,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_KR2,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_CR2,
    HAL_PHY_PMD_INTF_TYPE_100GBASE_SR2,
    HAL_PHY_PMD_INTF_TYPE_50GBASE_MXLINK,     /* PHY internal use */
    HAL_PHY_PMD_INTF_TYPE_100GBASE_MXLINK,    /* PHY internal use */
    HAL_PHY_PMD_INTF_TYPE_200GBASE_MXLINK,    /* PHY internal use */
    HAL_PHY_PMD_INTF_TYPE_400GBASE_MXLINK,    /* PHY internal use */
    HAL_PHY_PMD_INTF_TYPE_LAST
} HAL_PHY_PMD_INTF_TYPE_T;

typedef enum
{
    HAL_PHY_ADVER_INTF_TYPE_NONE                = 0,
    HAL_PHY_ADVER_INTF_TYPE_1000BASE_KX         = 1 << 0,
    HAL_PHY_ADVER_INTF_INTF_TYPE_2P5GBASE_KX    = 1 << 1,
    HAL_PHY_ADVER_INTF_TYPE_5GBASE_KR           = 1 << 2,
    HAL_PHY_ADVER_INTF_TYPE_10GBASE_KX4         = 1 << 3,
    HAL_PHY_ADVER_INTF_TYPE_10GBASE_KR          = 1 << 4,
    HAL_PHY_ADVER_INTF_TYPE_25GBASE_KR          = 1 << 5,
    HAL_PHY_ADVER_INTF_TYPE_25GBASE_CR          = 1 << 6,
    HAL_PHY_ADVER_INTF_TYPE_40GBASE_KR4         = 1 << 7,
    HAL_PHY_ADVER_INTF_TYPE_40GBASE_CR4         = 1 << 8,
    HAL_PHY_ADVER_INTF_TYPE_50GBASE_KR          = 1 << 9,
    HAL_PHY_ADVER_INTF_TYPE_50GBASE_CR          = 1 << 10,
    HAL_PHY_ADVER_INTF_TYPE_100GBASE_CR10       = 1 << 11,
    HAL_PHY_ADVER_INTF_TYPE_100GBASE_KP4        = 1 << 12,
    HAL_PHY_ADVER_INTF_TYPE_100GBASE_KR4        = 1 << 13,
    HAL_PHY_ADVER_INTF_TYPE_100GBASE_CR4        = 1 << 14,
    HAL_PHY_ADVER_INTF_TYPE_100GBASE_KR2        = 1 << 15,
    HAL_PHY_ADVER_INTF_TYPE_100GBASE_CR2        = 1 << 16,
    HAL_PHY_ADVER_INTF_TYPE_200GBASE_KR4        = 1 << 17,
    HAL_PHY_ADVER_INTF_TYPE_200GBASE_CR4        = 1 << 18,
    HAL_PHY_ADVER_INTF_TYPE_LAST
} HAL_PHY_ADVER_INTF_TYPE_T;

typedef enum
{
    HAL_PHY_AN_TARGET_TYPE_SELF = 0x0,
    HAL_PHY_AN_TARGET_TYPE_PEER,
    HAL_PHY_AN_TARGET_TYPE_LAST
} HAL_PHY_AN_TARGET_TYPE_T;

typedef enum
{
    HAL_PHY_ANLT_TYPE_DISABLE = 0x0,
    HAL_PHY_ANLT_TYPE_ENABLE,
    HAL_PHY_ANLT_TYPE_ENABLE_LT,              /* Link-training only without Auto negotiation */
    HAL_PHY_ANLT_TYPE_LAST
} HAL_PHY_ANLT_TYPE_T;

typedef enum
{
    HAL_PHY_AN_RE_AN_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_RE_AN_TYPE_RESTART,
    HAL_PHY_AN_RE_AN_TYPE_LAST
} HAL_PHY_AN_RE_AN_TYPE_T;

typedef enum
{
    HAL_PHY_AN_SPEED_TYPE_DISABLE             = 0x0,
    HAL_PHY_AN_SPEED_TYPE_1000BASE_KX         = (0x1UL << 0),
    HAL_PHY_AN_SPEED_TYPE_10GBASE_KX4         = (0x1UL << 1),
    HAL_PHY_AN_SPEED_TYPE_10GBASE_KR          = (0x1UL << 2),
    HAL_PHY_AN_SPEED_TYPE_40GBASE_KR4         = (0x1UL << 3),
    HAL_PHY_AN_SPEED_TYPE_40GBASE_CR4         = (0x1UL << 4),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_CR10       = (0x1UL << 5),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KP4        = (0x1UL << 6),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KR4        = (0x1UL << 7),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_CR4        = (0x1UL << 8),
    HAL_PHY_AN_SPEED_TYPE_25GBASE_KR_CR_S     = (0x1UL << 9),
    HAL_PHY_AN_SPEED_TYPE_25GBASE_KR_CR       = (0x1UL << 10),
    HAL_PHY_AN_SPEED_TYPE_2G5BASE_KX          = (0x1UL << 11),
    HAL_PHY_AN_SPEED_TYPE_5GBASE_KR           = (0x1UL << 12),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_KR_CR       = (0x1UL << 13),
    HAL_PHY_AN_SPEED_TYPE_100GBASE_KR2_CR2    = (0x1UL << 14),
    HAL_PHY_AN_SPEED_TYPE_200GBASE_KR4_CR4    = (0x1UL << 15),
    HAL_PHY_AN_SPEED_TYPE_50GBASE_KR2_CR2     = (0x1UL << 16),
    HAL_PHY_AN_SPEED_TYPE_400GBASE_CONSORTIUM = (0x1UL << 17),
    HAL_PHY_AN_SPEED_TYPE_LAST
} HAL_PHY_AN_SPEED_TYPE_T;

typedef enum
{
    HAL_PHY_AN_EEE_TYPE_DISABLE         = 0x0,
    HAL_PHY_AN_EEE_TYPE_1000BASE_KX     = (0x1UL << 0),
    HAL_PHY_AN_EEE_TYPE_10GBASE_KX4     = (0x1UL << 1),
    HAL_PHY_AN_EEE_TYPE_10GBASE_KR      = (0x1UL << 2),
    HAL_PHY_AN_EEE_TYPE_40GBASE_KR4     = (0x1UL << 3),
    HAL_PHY_AN_EEE_TYPE_40GBASE_CR4     = (0x1UL << 4),
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR10   = (0x1UL << 5),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KP4    = (0x1UL << 6),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KR4    = (0x1UL << 7),
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR4    = (0x1UL << 8),
    HAL_PHY_AN_EEE_TYPE_25GBASE_R       = (0x1UL << 9),  /* NOTE: defined in EEE capability p8023_d3p2 */
    /*defined in section 78 of 8023cd_d3p4*/           /* not confirmed: waiting for SerDes confirmation */
    HAL_PHY_AN_EEE_TYPE_40GBASE_ER4     = (0x1UL << 10),
    HAL_PHY_AN_EEE_TYPE_50GBASE_KR      = (0x1UL << 11),
    HAL_PHY_AN_EEE_TYPE_50GBASE_CR      = (0x1UL << 12),
    HAL_PHY_AN_EEE_TYPE_50GBASE_SR      = (0x1UL << 13),
    HAL_PHY_AN_EEE_TYPE_50GBASE_FR      = (0x1UL << 14),
    HAL_PHY_AN_EEE_TYPE_50GBASE_LR      = (0x1UL << 15),
    HAL_PHY_AN_EEE_TYPE_100GBASE_KR2    = (0x1UL << 16),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_CR10   = (0x1UL << 17),*/
    HAL_PHY_AN_EEE_TYPE_100GBASE_CR2    = (0x1UL << 17),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_SR10   = (0x1UL << 18),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_100GBASE_SR4    = (0x1UL << 18),
    HAL_PHY_AN_EEE_TYPE_100GBASE_SR2    = (0x1UL << 19),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_DR     = (0x1UL << 21),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_100GBASE_LR4    = (0x1UL << 20),
    HAL_PHY_AN_EEE_TYPE_100GBASE_ER4    = (0x1UL << 21),
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_KR4    = (0x1UL << 25),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_CR4    = (0x1UL << 26),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_SR4    = (0x1UL << 27),*/
    /*HAL_PHY_AN_EEE_TYPE_100GBASE_DR4    = (0x1UL << 24),*/ /* Not support */
    /*defined in section 78 of 802d3bs_d3p5*/              /* not comfirmed: wiaitng for SerDes confirmation */
    /*HAL_PHY_AN_EEE_TYPE_200GBASE_DR4    = (0x1UL << 25),*/ /* Not support */
    HAL_PHY_AN_EEE_TYPE_200GBASE_FR4    = (0x1UL << 22),
    HAL_PHY_AN_EEE_TYPE_200GBASE_LR4    = (0x1UL << 23),
    /*HAL_PHY_AN_EEE_TYPE_400GBASE_LR16   = (0x1UL << 28),*/ /*Not support*/
    /*HAL_PHY_AN_EEE_TYPE_400GBASE_DR4    = (0x1UL << 29),*/ /*Not support*/
    HAL_PHY_AN_EEE_TYPE_400GBASE_FR8    = (0x1UL << 24),
    HAL_PHY_AN_EEE_TYPE_400GBASE_LR8    = (0x1UL << 25),
    HAL_PHY_AN_EEE_TYPE_LAST
} HAL_PHY_AN_EEE_TYPE_T;

typedef enum
{
    HAL_PHY_AN_FEC_TYPE_DISABLE             = 0x0,
    HAL_PHY_AN_FEC_TYPE_ABILITY             = (0x1UL << 0),
    HAL_PHY_AN_FEC_TYPE_REQUEST             = (0x1UL << 1),
    HAL_PHY_AN_FEC_TYPE_25G_RS_REQUEST      = (0x1UL << 2),
    HAL_PHY_AN_FEC_TYPE_25G_BASER_REQUEST   = (0x1UL << 3),
    HAL_PHY_AN_FEC_TYPE_LAST
} HAL_PHY_AN_FEC_TYPE_T;

typedef enum
{
    HAL_PHY_AN_FC_TYPE_CL37_NO_PAUSE    = 0x0,
    HAL_PHY_AN_FC_TYPE_CL73_NO_PAUSE    = 0x0,
    HAL_PHY_AN_FC_TYPE_CL37_PAUSE       = (0x1UL << 0),
    HAL_PHY_AN_FC_TYPE_CL37_ASM_DIR     = (0x1UL << 1),
    HAL_PHY_AN_FC_TYPE_CL73_ASYM_PAUSE  = (0x1UL << 2),
    HAL_PHY_AN_FC_TYPE_CL73_SYM_PAUSE   = (0x1UL << 3),
    HAL_PHY_AN_FC_TYPE_LAST             = (0x1UL << 4)
} HAL_PHY_AN_FC_TYPE_T;

typedef enum
{
    HAL_PHY_AN_DUPLEX_TYPE_DISABLE  = 0x0,
    HAL_PHY_AN_DUPLEX_TYPE_FULL     = (0x1UL << 0),
    HAL_PHY_AN_DUPLEX_TYPE_HALF     = (0x1UL << 1),
    HAL_PHY_AN_DUPLEX_TYPE_LAST     = (0x1UL << 2)
} HAL_PHY_AN_DUPLEX_TYPE_T;

typedef enum
{
    HAL_PHY_AN_RF_TYPE_DISABLE  = 0x0,
    HAL_PHY_AN_RF_TYPE_1        = (0x1UL << 0),
    HAL_PHY_AN_RF_TYPE_2        = (0x1UL << 1),
    HAL_PHY_AN_RF_TYPE_LAST     = (0x1UL << 2)
} HAL_PHY_AN_RF_TYPE_T;

typedef enum
{
    HAL_PHY_EYE_SCAN_TYPE_DIAGRAM   = 0x0,
    HAL_PHY_EYE_SCAN_TYPE_BER,
    HAL_PHY_EYE_SCAN_TYPE_LAST
} HAL_PHY_EYE_SCAN_TYPE_T;

typedef enum
{
    HAL_PHY_PRBS_PATTERN_TYPE_DISABLE   = 0x0,
    HAL_PHY_PRBS_PATTERN_TYPE_9,
    HAL_PHY_PRBS_PATTERN_TYPE_13,
    HAL_PHY_PRBS_PATTERN_TYPE_31,
    HAL_PHY_PRBS_PATTERN_TYPE_SQUARE,
    HAL_PHY_PRBS_PATTERN_TYPE_LAST
} HAL_PHY_PRBS_PATTERN_TYPE_T;

typedef enum
{
    HAL_PHY_PRBS_CHECKER_TYPE_DISABLE   = 0x0,
    HAL_PHY_PRBS_CHECKER_TYPE_ENABLE,
    HAL_PHY_PRBS_CHECKER_TYPE_LAST
} HAL_PHY_PRBS_CHECKER_TYPE_T;

typedef enum
{
    /** PRBS Disable */
    HAL_PHY_PRBS_CONFIG_DISABLE = 0,
    /** Enable both PRBS Transmitter and Receiver */
    HAL_PHY_PRBS_CONFIG_ENABLE_TX_RX,
    /** Enable PRBS Receiver */
    HAL_PHY_PRBS_CONFIG_ENABLE_RX,
    /** Enable PRBS Transmitter */
    HAL_PHY_PRBS_CONFIG_ENABLE_TX,
    HAL_PHY_PRBS_LAST
} HAL_PHY_PRBS_CONFIG_T;

typedef enum
{
    HAL_PHY_AN_TYPE_DISABLE = 0x0,
    HAL_PHY_AN_TYPE_ENABLE,
    HAL_PHY_AN_TYPE_LAST
} HAL_PHY_AN_TYPE_T;

typedef enum
{
    HAL_PHY_LINK_TRAINING_TYPE_DISABLE  = 0x0,
    HAL_PHY_LINK_TRAINING_TYPE_ENABLE,
    HAL_PHY_LINK_TRAINING_TYPE_LAST
} HAL_PHY_LINK_TRAINING_TYPE_T;

typedef enum
{
    HAL_PHY_PRBS_BER_TYPE_DISABLE   = 0x0,
    HAL_PHY_PRBS_BER_TYPE_BER4,
    HAL_PHY_PRBS_BER_TYPE_BER5,
    HAL_PHY_PRBS_BER_TYPE_BER6,
    HAL_PHY_PRBS_BER_TYPE_LAST
} HAL_PHY_PRBS_BER_TYPE_T;


typedef struct HAL_PHY_PRBS_CHECKER_S
{
    HAL_PHY_PRBS_CHECKER_TYPE_T     checker_mode;
    HAL_PHY_PRBS_BER_TYPE_T         ber_mode;
} HAL_PHY_PRBS_CHECKER_T;

typedef enum
{
    HAL_PHY_PRBS_CHKSTS_TYPE_UNLOCK = 0x0,
    HAL_PHY_PRBS_CHKSTS_TYPE_PASS   = 0x1,
    HAL_PHY_PRBS_CHKSTS_TYPE_FAIL   = 0x3,
    HAL_PHY_PRBS_CHKSTS_TYPE_LAST
} HAL_PHY_PRBS_CHKSTS_TYPE_T;


typedef struct HAL_PHY_PRBS_ERRCNT_S
{
    HAL_PHY_PRBS_CHKSTS_TYPE_T      cmpsts;
    UI32_T                          errcnt;
} HAL_PHY_PRBS_ERRCNT_T;


typedef enum
{
    HAL_PHY_SERDES_DUMP_TYPE_MEM   = 0x0,
    HAL_PHY_SERDES_DUMP_TYPE_REG,
    HAL_PHY_SERDES_DUMP_TYPE_COEF,
    HAL_PHY_SERDES_DUMP_TYPE_MSGQ,
    HAL_PHY_SERDES_DUMP_TYPE_LAST
} HAL_PHY_SERDES_DUMP_TYPE_T;

typedef enum
{
    HAL_PHY_LED_MODE_TYPE_NORMAL    = 0x0,
    HAL_PHY_LED_MODE_TYPE_FORCE,
    HAL_PHY_LED_MODE_TYPE_BIT_ON,
    HAL_PHY_LED_MODE_TYPE_BIT_OFF,
    HAL_PHY_LED_MODE_TYPE_LAST
} HAL_PHY_LED_MODE_TYPE_T;

typedef enum
{
    HAL_PHY_LED_STS_TYPE_NORMAL_ON    = 0x0,
    HAL_PHY_LED_STS_TYPE_NORMAL_OFF,
    HAL_PHY_LED_STS_TYPE_FORCE_ON,
    HAL_PHY_LED_STS_TYPE_FORCE_OFF,
    HAL_PHY_LED_STS_TYPE_LAST
} HAL_PHY_LED_STS_TYPE_T;

typedef enum
{
    HAL_PHY_PROPERTY_TYPE_LANE_SWAP_TX = 0x0,
    HAL_PHY_PROPERTY_TYPE_LANE_SWAP_RX,
    HAL_PHY_PROPERTY_TYPE_POLARITY_REV_TX,
    HAL_PHY_PROPERTY_TYPE_POLARITY_REV_RX,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C0,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C1,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_C2,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_CN1,
    HAL_PHY_PROPERTY_TYPE_TX_COEFFICIENT_CN2,
    HAL_PHY_PROPERTY_TYPE_LAST
} HAL_PHY_PROPERTY_TYPE_T;

typedef struct HAL_PHY_TX_COEF_S
{
#define HAL_PHY_TX_COEF_FLAGS_C0  (1UL << 0)  /* C0 must the last set coefficient */
#define HAL_PHY_TX_COEF_FLAGS_C1  (1UL << 1)
#define HAL_PHY_TX_COEF_FLAGS_CN1 (1UL << 2)
#define HAL_PHY_TX_COEF_FLAGS_C2  (1UL << 3)
#define HAL_PHY_TX_COEF_FLAGS_CN2 (1UL << 4)
    UI32_T    flags;
    UI32_T    cn2;
    UI32_T    cn1;
    UI32_T    c0;
    UI32_T    c1;
    UI32_T    c2;
} HAL_PHY_TX_COEF_T;

#if defined (CLX_EN_BIG_ENDIAN)
typedef union
{
    UI32_T  value;
    struct
    {
        UI32_T  psel    :  1;
        UI32_T  rsv     : 15;
        UI32_T  addr    : 16;
    } field;
} HAL_PHY_PHY_ADDR_T;
#else
typedef union
{
    UI32_T  value;
    struct
    {
        UI32_T  addr    : 16;
        UI32_T  rsv     : 15;
        UI32_T  psel    :  1;
    } field;
} HAL_PHY_PHY_ADDR_T;
#endif

typedef struct
{
    CLX_ERROR_NO_T
    (*init)(
        const UI32_T    unit,
        const UI32_T    port_id);
    CLX_ERROR_NO_T
    (*deinit)(
        const UI32_T    unit,
        const UI32_T    port_id);

    CLX_ERROR_NO_T
    (*setAdminState)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_ADMIN_STATE_TYPE_T    admin_state);
    CLX_ERROR_NO_T
    (*getAdminState)(
        const UI32_T                unit,
        const UI32_T                port_id,
        HAL_PHY_ADMIN_STATE_TYPE_T  *ptr_admin_state);

    CLX_ERROR_NO_T
    (*getLinkState) (
        const UI32_T                unit,
        const UI32_T                port_id,
        HAL_PHY_LINK_STATE_TYPE_T   *ptr_link_state);

    CLX_ERROR_NO_T
    (*setSpeed)(
        const UI32_T                unit,
        const UI32_T                port_id,
        const HAL_PHY_SPEED_TYPE_T  speed);
    CLX_ERROR_NO_T
    (*getSpeed)(
        const UI32_T            unit,
        const UI32_T            port_id,
        HAL_PHY_SPEED_TYPE_T    *ptr_speed);

    CLX_ERROR_NO_T
    (*setEee)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_EEE_TYPE_T        eee);
    CLX_ERROR_NO_T
    (*getEee)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        HAL_PHY_EEE_TYPE_T              *ptr_eee);

    CLX_ERROR_NO_T
    (*setEeeMode)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_EEE_MODE_TYPE_T   eee_mode);
    CLX_ERROR_NO_T
    (*getEeeMode)(
        const UI32_T            unit,
        const UI32_T            port_id,
        HAL_PHY_EEE_MODE_TYPE_T *ptr_eee_mode);

    CLX_ERROR_NO_T
    (*setFec)(
        const UI32_T                unit,
        const UI32_T                port_id,
        const HAL_PHY_FEC_TYPE_T    fec);
    CLX_ERROR_NO_T
    (*getFec)(
        const UI32_T        unit,
        const UI32_T        port_id,
        HAL_PHY_FEC_TYPE_T  *ptr_fec);

    CLX_ERROR_NO_T
    (*setLoopback)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
        const HAL_PHY_LOOPBACK_TYPE_T       loopback);
    CLX_ERROR_NO_T
    (*getLoopback)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
        HAL_PHY_LOOPBACK_TYPE_T             *ptr_loopback);

    CLX_ERROR_NO_T
    (*setPmaIntf)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
        const HAL_PHY_PMA_INTF_TYPE_T       pma_intf);
    CLX_ERROR_NO_T
    (*getPmaIntf)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
        HAL_PHY_PMA_INTF_TYPE_T             *ptr_pma_intf);

    CLX_ERROR_NO_T
    (*setPmdIntf)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_PMD_INTF_TYPE_T   pmd_intf);
    CLX_ERROR_NO_T
    (*getPmdIntf)(
        const UI32_T            unit,
        const UI32_T            port_id,
        HAL_PHY_PMD_INTF_TYPE_T *ptr_pmd_intf);

    CLX_ERROR_NO_T
    (*setAdverIntf)(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const UI32_T                    adver_intf);

    CLX_ERROR_NO_T
    (*setAn)(
        const UI32_T              unit,
        const UI32_T              port_id,
        const HAL_PHY_ANLT_TYPE_T an);
    CLX_ERROR_NO_T
    (*getAn)(
        const UI32_T          unit,
        const UI32_T          port_id,
        HAL_PHY_ANLT_TYPE_T   *ptr_an);

    CLX_ERROR_NO_T
    (*setAnReAn)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_AN_RE_AN_TYPE_T   an_re_an);
    CLX_ERROR_NO_T
    (*getAnReAn)(
        const UI32_T            unit,
        const UI32_T            port_id,
        HAL_PHY_AN_RE_AN_TYPE_T *ptr_an_re_an);

    CLX_ERROR_NO_T
    (*setAnSpeed)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_AN_SPEED_TYPE_T   an_speed);
    CLX_ERROR_NO_T
    (*getAnSpeed)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_AN_TARGET_TYPE_T  an_target,
        HAL_PHY_AN_SPEED_TYPE_T         *ptr_an_speed);

    CLX_ERROR_NO_T
    (*setAnEee)(
        const UI32_T                unit,
        const UI32_T                port_id,
        const HAL_PHY_AN_EEE_TYPE_T an_eee);
    CLX_ERROR_NO_T
    (*getAnEee)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_AN_TARGET_TYPE_T      an_target,
        HAL_PHY_AN_EEE_TYPE_T               *ptr_an_eee);

    CLX_ERROR_NO_T
    (*setAnFec)(
        const UI32_T                unit,
        const UI32_T                port_id,
        const HAL_PHY_AN_FEC_TYPE_T an_fec);
    CLX_ERROR_NO_T
    (*getAnFec)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_AN_TARGET_TYPE_T  an_target,
        HAL_PHY_AN_FEC_TYPE_T           *ptr_an_fec);

    CLX_ERROR_NO_T
    (*setAnFc)(
        const UI32_T                unit,
        const UI32_T                port_id,
        const HAL_PHY_AN_FC_TYPE_T  an_fc);
    CLX_ERROR_NO_T
    (*getAnFc)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_AN_TARGET_TYPE_T  an_target,
        HAL_PHY_AN_FC_TYPE_T            *ptr_an_fc);

    CLX_ERROR_NO_T
    (*setAnDuplex)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_AN_DUPLEX_TYPE_T  an_duplex);
    CLX_ERROR_NO_T
    (*getAnDuplex)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_AN_TARGET_TYPE_T  an_target,
        HAL_PHY_AN_DUPLEX_TYPE_T        *ptr_an_duplex);

    CLX_ERROR_NO_T
    (*setAnRf)(
        const UI32_T                unit,
        const UI32_T                port_id,
        const HAL_PHY_AN_RF_TYPE_T  an_rf);
    CLX_ERROR_NO_T
    (*getAnRf)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const HAL_PHY_AN_TARGET_TYPE_T  an_target,
        HAL_PHY_AN_RF_TYPE_T            *ptr_an_rf);

    CLX_ERROR_NO_T
    (*setPhyCfg)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        lane_cnt,
        const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
        const HAL_PHY_PROPERTY_TYPE_T       property_type,
        const UI32_T                        *ptr_property);
    CLX_ERROR_NO_T
    (*getPhyCfg)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        lane_cnt,
        const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
        const HAL_PHY_PROPERTY_TYPE_T       property_type,
        UI32_T                              *ptr_property);
    CLX_ERROR_NO_T
    (*setC45Cfg)(
        const UI32_T                        unit,
        const UI32_T                        eth_macro,
        const UI32_T                        lane,
        const UI32_T                        dev_type,
        const UI32_T                        reg_addr,
        const UI32_T                        reg);
    CLX_ERROR_NO_T
    (*getC45Cfg)(
        const UI32_T                        unit,
        const UI32_T                        eth_macro,
        const UI32_T                        lane,
        const UI32_T                        dev_type,
        const UI32_T                        reg_addr,
        UI32_T                              *ptr_reg);
    CLX_ERROR_NO_T
    (*getTemperature)(
        const UI32_T    unit,
        const UI32_T    port_id,
        I32_T           *ptr_temp);

    CLX_ERROR_NO_T
    (*dumpEyeScan)(
        const UI32_T                    unit,
        const UI32_T                    port_id,
        const UI32_T                    lane_cnt,
        const HAL_PHY_EYE_SCAN_TYPE_T   property);

    CLX_ERROR_NO_T
    (*setPrbsPattern)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_PRBS_PATTERN_TYPE_T   prbs_pattern);

    CLX_ERROR_NO_T
    (*getPrbsPattern)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        HAL_PHY_PRBS_PATTERN_TYPE_T         *ptr_prbs_pattern);

    CLX_ERROR_NO_T
    (*setPrbsChecker)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_PRBS_CHECKER_TYPE_T   prbs_checker,
        const UI32_T                        ber_mode);

    CLX_ERROR_NO_T
    (*getPrbsChecker)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        HAL_PHY_PRBS_CHECKER_TYPE_T         *ptr_prbs_checker);

    CLX_ERROR_NO_T
    (*setPrbsGenerator)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        HAL_PHY_PRBS_CONFIG_T          prbs_gen);

    CLX_ERROR_NO_T
    (*getPrbsErrorCnt)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        lane_bmp,
        HAL_PHY_PRBS_BER_TYPE_T             *ptr_ber_mode,
        HAL_PHY_PRBS_ERRCNT_T               *ptr_error_cnt);

    CLX_ERROR_NO_T
    (*setLedBit)(
        const UI32_T                    unit,
        const UI32_T                    led_id,
        const UI32_T                    bit_id,
        const UI32_T                    *ptr_led_mode);

    CLX_ERROR_NO_T
    (*getLedBit)(
        const UI32_T                    unit,
        const UI32_T                    led_id,
        const UI32_T                    bit_id,
        UI32_T                          *ptr_led_mode);

    CLX_ERROR_NO_T
    (*setMdioRate) (
        const UI32_T    unit,
        const UI32_T    chn_id,
        const UI32_T    rate_khz);

    void
    (*setPhyAddr)(
        void);
    CLX_ERROR_NO_T
    (*getPhyAddr)(
        const UI32_T        unit,
        const UI32_T        port_id,
        UI32_T              *ptr_up_id,
        HAL_PHY_PHY_ADDR_T  *ptr_phy_addr);

    CLX_ERROR_NO_T
    (*dumpSerDesInfo)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        lane_bmp,
        const HAL_PHY_SERDES_DUMP_TYPE_T    dump_type,
        const UI32_T                        more);

    CLX_ERROR_NO_T
    (*setTxCoef)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        lane_id,
        const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
        HAL_PHY_TX_COEF_T                   *ptr_tx_coef);

    CLX_ERROR_NO_T
    (*getTxCoef)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        lane_id,
        const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
        HAL_PHY_TX_COEF_T                   *ptr_tx_coef);

    CLX_ERROR_NO_T
    (*setMxLink)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        enable);

    CLX_ERROR_NO_T
    (*getMxLink)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        UI32_T                              *ptr_enable);

    CLX_ERROR_NO_T
    (*getFecCnt)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        land_id,
        const HAL_PHY_FEC_CNT_TYPE_T        cnt_type,
        HAL_PHY_FEC_CNT_T                   *ptr_cnt);

    CLX_ERROR_NO_T
    (*setLinkTrainingEn)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const HAL_PHY_LINK_TRAINING_TYPE_T  type);

    CLX_ERROR_NO_T
    (*getLinkTrainingEn)(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        HAL_PHY_LINK_TRAINING_TYPE_T        *type);

    CLX_ERROR_NO_T
    (*getAnEn)(
    const UI32_T                            unit,
    const UI32_T                            port_id,
    HAL_PHY_AN_TYPE_T                       *ptr_an_en);

    CLX_ERROR_NO_T
    (*setAnEn)(
    const UI32_T                            unit,
    const UI32_T                            port_id,
    HAL_PHY_AN_TYPE_T                       an_en);
} HAL_PHY_DRIVER_T;

#if defined (CLX_EN_BIG_ENDIAN)
typedef union
{
    UI32_T  value;
    struct
    {
        UI32_T  oui         : 22;
        UI32_T  model       :  6;
        UI32_T  revision    :  4;
    } field;
} HAL_PHY_DEVICE_ID_T;
#else
typedef union
{
    UI32_T  value;
    struct
    {
        UI32_T  revision    :  4;
        UI32_T  model       :  6;
        UI32_T  oui         : 22;
    } field;
} HAL_PHY_DEVICE_ID_T;
#endif

typedef struct
{
    C8_T                *ptr_name;
    HAL_PHY_DRIVER_T    *ptr_driver;
    HAL_PHY_DEVICE_ID_T device_id;
    UI32_T              device_id_mask;
    UI32_T              up_num;
} HAL_PHY_DEVICE_CB_T;

typedef enum
{
    HAL_PHY_PHY_TYPE_INTERNAL = 0x0,
    HAL_PHY_PHY_TYPE_EXTERNAL,
    HAL_PHY_PHY_TYPE_LAST
} HAL_PHY_PHY_TYPE_T;

typedef struct
{
    C8_T                *device_name[HAL_PHY_PHY_TYPE_LAST];
    HAL_PHY_DRIVER_T    *driver[HAL_PHY_PHY_TYPE_LAST];
    BOOL_T              known_device[HAL_PHY_PHY_TYPE_LAST];
} HAL_PHY_DRIVER_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* FUNCTION NAME:   hal_phy_init
 * PURPOSE:
 *      Init the PHY drive per unit
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_init(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_phy_deinit
 * PURPOSE:
 *      Deinit PHY driver per unit
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_deinit(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_phy_probePort
 * PURPOSE:
 *      Probe the port and init itself
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_probePort(
    const UI32_T    unit,
    const UI32_T    port_id);

/* FUNCTION NAME:   hal_phy_removePort
 * PURPOSE:
 *      Remove the port and deinit itself
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_removePort(
    const UI32_T    unit,
    const UI32_T    port_id);

/* FUNCTION NAME:   hal_phy_setAdminState
 * PURPOSE:
 *      Set admin state to enable or disable
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      admin_state     -- Port admin state
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        --  Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAdminState(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_ADMIN_STATE_TYPE_T    admin_state);

/* FUNCTION NAME:   hal_phy_getAdminState
 * PURPOSE:
 *      Get admin state
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_admin_state -- Port admin state
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAdminState(
    const UI32_T                unit,
    const UI32_T                port_id,
    HAL_PHY_ADMIN_STATE_TYPE_T  *ptr_admin_state);

/* FUNCTION NAME:   hal_phy_getLinkState
 * PURPOSE:
 *      Get link state
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_link_state  -- Port link state
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getLinkState(
    const UI32_T                unit,
    const UI32_T                port_id,
    HAL_PHY_LINK_STATE_TYPE_T   *ptr_link_state);

/* FUNCTION NAME:   hal_phy_setSpeed
 * PURPOSE:
 *      Set speed
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      speed           -- Port speed
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setSpeed(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_SPEED_TYPE_T  speed);

/* FUNCTION NAME:   hal_phy_getSpeed
 * PURPOSE:
 *      Get speed
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_speed       -- Port speed
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getSpeed(
    const UI32_T            unit,
    const UI32_T            port_id,
    HAL_PHY_SPEED_TYPE_T    *ptr_speed);

/* FUNCTION NAME:   hal_phy_setEee
 * PURPOSE:
 *      Set EEE(Energy-Efficient Ethernet) ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      eee             -- EEE ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setEee(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_EEE_TYPE_T    eee);

/* FUNCTION NAME:   hal_phy_getEee
 * PURPOSE:
 *      Get EEE(Energy-Efficient Ethernet) ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_eee         -- EEE ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getEee(
    const UI32_T        unit,
    const UI32_T        port_id,
    HAL_PHY_EEE_TYPE_T  *ptr_eee);

/* FUNCTION NAME:   hal_phy_setEeeMode
 * PURPOSE:
 *      Set EEE(Energy-Efficient Ethernet) mode as deep-sleep or fast-wakeup
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      eee_mode        -- EEE mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setEeeMode(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_EEE_MODE_TYPE_T   eee_mode);

/* FUNCTION NAME:   hal_phy_getEeeMode
 * PURPOSE:
 *      Get EEE(Energy-Efficient Ethernet) mode
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_eee_mode    -- EEE mode
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getEeeMode(
    const UI32_T            unit,
    const UI32_T            port_id,
    HAL_PHY_EEE_MODE_TYPE_T *ptr_eee_mode);

/* FUNCTION NAME:   hal_phy_setFec
 * PURPOSE:
 *      Set FEC(Forward Error Correction) ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      fec             -- FEC ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setFec(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_FEC_TYPE_T    fec);

/* FUNCTION NAME:   hal_phy_getFec
 * PURPOSE:
 *      Get FEC(Forward Error Correction) ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_fec         -- FEC ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getFec(
    const UI32_T        unit,
    const UI32_T        port_id,
    HAL_PHY_FEC_TYPE_T  *ptr_fec);

/* FUNCTION NAME:   hal_phy_setLoopback
 * PURPOSE:
 *      Set local loopback ability to enable or disable it
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      intf_location   -- Where the loopback interface locates
 *      loopback        -- Loopback ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setLoopback(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
    const HAL_PHY_LOOPBACK_TYPE_T       loopback);

/* FUNCTION NAME:   hal_phy_getLoopback
 * PURPOSE:
 *      Get local loopback ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      intf_location   -- Where the loopback interface locates
 * OUTPUT:
 *      ptr_loopback    -- Loopback ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getLoopback(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
    HAL_PHY_LOOPBACK_TYPE_T             *ptr_loopback);

/* FUNCTION NAME:   hal_phy_setPmaIntf
 * PURPOSE:
 *      Set the type of PMA interface
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      intf_location   -- Where the interface locates
 *      pma_intf        -- Type of PMA interface
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setPmaIntf(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
    const HAL_PHY_PMA_INTF_TYPE_T       pma_intf);

/* FUNCTION NAME:   hal_phy_getPmaIntf
 * PURPOSE:
 *      Get the type of PMA interface
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      intf_location   -- Where the interface locates
 * OUTPUT:
 *      ptr_pma_intf    -- Type of PMA interface
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getPmaIntf(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
    HAL_PHY_PMA_INTF_TYPE_T             *ptr_pma_intf);

/* FUNCTION NAME:   hal_phy_setPmdIntf
 * PURPOSE:
 *      Set the type of PMD interface
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      pmd_intf        -- Type of PMD interface
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setPmdIntf(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_PMD_INTF_TYPE_T   pmd_intf);

/* FUNCTION NAME:   hal_phy_getPmdIntf
 * PURPOSE:
 *      Get the type of PMD interface
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_pmd_intf    -- Type of PMD interface
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getPmdIntf(
    const UI32_T            unit,
    const UI32_T            port_id,
    HAL_PHY_PMD_INTF_TYPE_T *ptr_pmd_intf);

/* FUNCTION NAME:   hal_phy_setAn
 * PURPOSE:
 *      Set AN(Auto-Negotiation) ability to enable or disable
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an              -- AN ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAnLt(
    const UI32_T              unit,
    const UI32_T              port_id,
    const HAL_PHY_ANLT_TYPE_T anlt);

/* FUNCTION NAME:   hal_phy_getAn
 * PURPOSE:
 *      Get AN(Auto-Negotiation) ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_an          -- AN ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAnLt(
    const UI32_T          unit,
    const UI32_T          port_id,
    HAL_PHY_ANLT_TYPE_T   *ptr_anlt);

/* FUNCTION NAME:   hal_phy_setReAn
 * PURPOSE:
 *      Set Re-AN(Auto-Negotiation) ability to restart or disable
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_re_an        -- Re-AN ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAnReAn(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_RE_AN_TYPE_T   an_re_an);

/* FUNCTION NAME:   hal_phy_getReAn
 * PURPOSE:
 *      Get Re-AN(Auto-Negotiation) ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_an_re_an    -- Re-AN ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAnReAn(
    const UI32_T            unit,
    const UI32_T            port_id,
    HAL_PHY_AN_RE_AN_TYPE_T *ptr_an_re_an);

/* FUNCTION NAME:   hal_phy_setAnSpeed
 * PURPOSE:
 *      Set AN speed ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_speed        -- AN speed ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAnSpeed(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_SPEED_TYPE_T   an_speed);

/* FUNCTION NAME:   hal_phy_getAnSpeed
 * PURPOSE:
 *      Get AN speed ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_target       -- The target of AN ability such as local or remote peer
 * OUTPUT:
 *      ptr_an_speed    -- AN speed ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAnSpeed(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_TARGET_TYPE_T  an_target,
    HAL_PHY_AN_SPEED_TYPE_T         *ptr_an_speed);

/* FUNCTION NAME:   hal_phy_setAnEee
 * PURPOSE:
 *      Set AN EEE ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_eee          -- AN EEE ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAnEee(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_AN_EEE_TYPE_T an_eee);

/* FUNCTION NAME:   hal_phy_getAnEee
 * PURPOSE:
 *      Get AN EEE ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_target       -- The target of AN ability such as local or remote peer
 * OUTPUT:
 *      ptr_an_eee      -- AN EEE ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAnEee(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_TARGET_TYPE_T  an_target,
    HAL_PHY_AN_EEE_TYPE_T           *ptr_an_eee);

/* FUNCTION NAME:   hal_phy_setAnFec
 * PURPOSE:
 *      Set AN FEC ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_fec          -- AN FEC ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAnFec(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_AN_FEC_TYPE_T an_fec);

/* FUNCTION NAME:   hal_phy_getAnFec
 * PURPOSE:
 *      Get AN FEC ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_target       -- The target of AN ability such as local or remote peer
 * OUTPUT:
 *      ptr_an_fec      -- AN FEC ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAnFec(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_TARGET_TYPE_T  an_target,
    HAL_PHY_AN_FEC_TYPE_T           *ptr_an_fec);

/* FUNCTION NAME:   hal_phy_setAnFc
 * PURPOSE:
 *      Set AN flow control ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_fc           -- AN flow control ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAnFc(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_AN_FC_TYPE_T  an_fc);

/* FUNCTION NAME:   hal_phy_getAnFc
 * PURPOSE:
 *      Get AN flow control ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_target       -- The target of AN ability such as local or remote peer
 * OUTPUT:
 *      ptr_an_fc       -- AN flow control ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAnFc(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_TARGET_TYPE_T  an_target,
    HAL_PHY_AN_FC_TYPE_T            *ptr_an_fc);

/* FUNCTION NAME:   hal_phy_setAnDuplex
 * PURPOSE:
 *      Set AN Duplex ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_duplex       -- AN duplex ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAnDuplex(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_DUPLEX_TYPE_T  an_duplex);

/* FUNCTION NAME:   hal_phy_getAnDuplex
 * PURPOSE:
 *      Get AN duplex ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_target       -- The target of AN ability such as local or remote peer
 * OUTPUT:
 *      ptr_an_duplex   -- AN duplex ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAnDuplex(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_TARGET_TYPE_T  an_target,
    HAL_PHY_AN_DUPLEX_TYPE_T        *ptr_an_duplex);

/* FUNCTION NAME:   hal_phy_setAnRf
 * PURPOSE:
 *      Set AN remote-fault ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_rf           -- AN remote fault ability
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setAnRf(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_AN_RF_TYPE_T  an_rf);

/* FUNCTION NAME:   hal_phy_getAnRf
 * PURPOSE:
 *      Get AN remote-fault ability
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      an_target       -- The target of AN ability such as local or remote peer
 * OUTPUT:
 *      ptr_an_rf       -- AN remote-fault ability
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getAnRf(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const HAL_PHY_AN_TARGET_TYPE_T  an_target,
    HAL_PHY_AN_RF_TYPE_T            *ptr_an_rf);

/* FUNCTION NAME:   hal_phy_setPhyCfg
 * PURPOSE:
 *      Set phy config such as lane-swap, polarity-reversion and tx-coefficient
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      lane_cnt        -- Count of lanes inside the port
 *      intf_location   -- Where the interface locates
 *      property_type   -- Type of config
 *      ptr_property    -- The config array with lane_cnt elements
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setPhyCfg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_cnt,
    const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
    const HAL_PHY_PROPERTY_TYPE_T       property_type,
    const UI32_T                        *ptr_property);

/* FUNCTION NAME:   hal_phy_getPhyCfg
 * PURPOSE:
 *      Get phy config such as lane-swap, polarity-reversion and tx-coefficient
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      lane_cnt        -- Count of lanes inside the port
 *      intf_location   -- Where the interface locates
 *      property_type   -- Type of config
 * OUTPUT:
 *      ptr_property    -- The config array with lane_cnt elements
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getPhyCfg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_cnt,
    const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
    const HAL_PHY_PROPERTY_TYPE_T       property_type,
    UI32_T                              *ptr_property);

/* FUNCTION NAME:   hal_phy_setTxCoef
 * PURPOSE:
 *      Set all tx coefficients (CN2, CN1, C0, C1, C2) for a specific lane
 *      Note 1: different switch family supports different coefficient number
 *      Note 2: when summation of coefficient is overflow, C0 got reduction
 *      Note 3: partial coefficients configuration is allowed (flags within struct config is necessary)
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      lane_id         -- Lane offset inside the port
 *      intf_location   -- Where the interface locates
 *      ptr_tx_coef     -- The tx coefficients applied to the specific lane
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setTxCoef(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_id,
    const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
    HAL_PHY_TX_COEF_T                   *ptr_tx_coef);

/* FUNCTION NAME:   hal_phy_getTxCoef
 * PURPOSE:
 *      Get all tx coefficients (CN2, CN1, C0, C1, C2) for a spceific lane
 *      Note 1: different switch family supports different coefficient number
 *      Note 2: flags within the struct indicates the coefficients supported in this switch family
  * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      lane_id         -- Lane offset inside the port
 *      intf_location   -- Where the interface locates
 * OUTPUT:
 *      ptr_tx_coef     -- The tx coefficients applied to the specific lane
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getTxCoef(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_id,
    const HAL_PHY_INTF_LOCATION_TYPE_T  intf_location,
    HAL_PHY_TX_COEF_T                   *ptr_tx_coef);



/* FUNCTION NAME:   hal_phy_setC45Cfg
 * PURPOSE:
 *      Allow users to set C45 config with only eth-macro/lane information.
 * INPUT:
 *      unit            -- Device unit number
 *      eth-macro       -- Ethc-xx shown in schematic
 *      lane            -- lane of the eth-macro
 *      dev_type        -- Type of PHY device
 *      reg_addr        -- Register address
 *      ptr_reg         -- Pointer to the data for set into the register specified
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setC45Cfg(
    const UI32_T                        unit,
    const UI32_T                        eth_macro,
    const UI32_T                        lane,
    const UI32_T                        dev_type,
    const UI32_T                        reg_addr,
    const UI32_T                        reg);

/* FUNCTION NAME:   hal_phy_getC45Cfg
 * PURPOSE:
 *      Allow users to set C45 config with only eth-macro/lane information.
 * INPUT:
 *      unit            -- Device unit number
 *      eth-macro       -- Ethc-xx shown in schematic.
 *      lane            -- lane of the eth-macro.
 *      dev_type        -- Type of PHY device
 *      reg_addr        -- Register address
 * OUTPUT:
 *      ptr_reg         -- Pointer to buffer the data read from register specified
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getC45Cfg(
    const UI32_T                        unit,
    const UI32_T                        eth_macro,
    const UI32_T                        lane,
    const UI32_T                        dev_type,
    const UI32_T                        reg_addr,
    UI32_T                              *ptr_reg);

/* FUNCTION NAME:   hal_phy_getTemperature
 * PURPOSE:
 *      Get temperature of external PHY
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_temp        -- Temperature of enternal PHY
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getTemperature(
    const UI32_T    unit,
    const UI32_T    port_id,
    I32_T           *ptr_temp);

/* FUNCTION NAME:   hal_phy_dumpEyeScan
 * PURPOSE:
 *      Dump eye scan result
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      lane_cnt        -- Lane count within the port
 *      property        -- Optional perperty setting
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_dumpEyeScan(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const UI32_T                    lane_cnt,
    const HAL_PHY_EYE_SCAN_TYPE_T   property);

/* FUNCTION NAME:   hal_phy_setPrbsPattern
 * PURPOSE:
 *      Set the PRBS test pattern
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      prbs_pattern    -- Test pattern on PRBS
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setPrbsPattern(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_PRBS_PATTERN_TYPE_T   prbs_pattern);

/* FUNCTION NAME:   hal_phy_getPrbsPattern
 * PURPOSE:
 *      Get the PRBS test pattern
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 * OUTPUT:
 *      ptr_prbs_pattern -- Test pattern on PRBS
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getPrbsPattern(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    HAL_PHY_PRBS_PATTERN_TYPE_T         *ptr_prbs_pattern);

/* FUNCTION NAME:   hal_phy_setPrbsChecker
 * PURPOSE:
 *      Enable/disable the PRBS test checker
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 *      prbs_checker     -- Enable/Disable checker
 *      ber_mode         -- Enable/Disable ber mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setPrbsChecker(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_PRBS_CHECKER_TYPE_T   prbs_checker,
    const UI32_T                        ber_mode);

/* FUNCTION NAME:   hal_phy_getPrbsChecker
 * PURPOSE:
 *      Get the PRBS test checker status (enable/disable)
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 * OUTPUT:
 *      ptr_prbs_checker -- Test checker status (enable/disable)
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getPrbsChecker(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    HAL_PHY_PRBS_CHECKER_TYPE_T         *ptr_prbs_checker);

/* FUNCTION NAME:   hal_phy_getPrbsErrorCnt
 * PURPOSE:
 *      Get the PRBS checker error count
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 *      lane_bmp         -- specify the lanes to report prbs error cnt
 * OUTPUT:
 *      ptr_ber_mode     -- for PAM4/NRZ PRBS, ber_mode is enable/disable
 *      ptr_error_cnt    -- Error bit counter (including lock sts + error counter)
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getPrbsErrorCnt(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    HAL_PHY_PRBS_BER_TYPE_T             *ptr_ber_mode,
    HAL_PHY_PRBS_ERRCNT_T               *ptr_error_cnt);

/* FUNCTION NAME:   hal_phy_dumpSerDesInfo
 * PURPOSE:
 *      Dump serdes internal information
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 *      lane_bmp         -- Focus the lane list within the port (started from 0)
 *      dump_type        -- HAL_PHY_SERDES_DUMP_TYPE_MEM/HAL_PHY_SERDES_DUMP_TYPE_REG/HAL_PHY_SERDES_DUMP_TYPE_COEF
 *      more             -- more flag to dump more detail
 * OUTPUT:
 *      serdes sdk module osal_printf directly.
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_dumpSerDesInfo(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const HAL_PHY_SERDES_DUMP_TYPE_T    dump_type,
    const UI32_T                        more);

/* FUNCTION NAME:   hal_phy_setLedBit
 * PURPOSE:
 *      Set the bit within the shift register for LED
 * INPUT:
 *      unit            -- Device unit number
 *      led_id          -- LED module ID
 *      led_mode        -- LED mode to set
 *      bit_id          -- The bit to set
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setLedBit(
    const UI32_T                    unit,
    const UI32_T                    led_id,
    const UI32_T                    bit_id,
    const UI32_T                    *ptr_led_mode);

/* FUNCTION NAME:   hal_phy_getLedBit
 * PURPOSE:
 *      get the bit within the shift register for LED
 * INPUT:
 *      unit            -- Device unit number
 *      led_id          -- LED module ID
 *      bit_id          -- The bit to set
 * OUTPUT:
 *      led_mode        -- LED status [on/off (normal/force)]
  * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getLedBit(
    const UI32_T                    unit,
    const UI32_T                    led_id,
    const UI32_T                    bit_id,
    UI32_T                          *ptr_led_mode);


/* FUNCTION NAME:   hal_phy_setMdioReg
 * PURPOSE:
 *      Set MDIO(Management Data Input/Output) register of PHY
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      phy_type        -- Type of PHY such as internal or external
 *      dev_type        -- Type of PHY device
 *      reg_addr        -- Register address
 *      reg             -- Register data
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setMdioReg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_PHY_TYPE_T            phy_type,
    const HAL_PHY_MDIO_DEVICE_TYPE_T    dev_type,
    const UI32_T                        reg_addr,
    const UI32_T                        reg);

/* FUNCTION NAME:   hal_phy_getMdioReg
 * PURPOSE:
 *      Get MDIO(Management Data Input/Output) register of PHY
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      phy_type        -- Type of PHY such as internal or external
 *      dev_type        -- Type of PHY device
 *      reg_addr        -- Register address
 * OUTPUT:
 *      ptr_reg         -- Register data
 * RETURN:
 *      CLX_E_OK        -- Operate success.
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getMdioReg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_PHY_TYPE_T            phy_type,
    const HAL_PHY_MDIO_DEVICE_TYPE_T    dev_type,
    const UI32_T                        reg_addr,
    UI32_T                              *ptr_reg);

/* FUNCTION NAME:   hal_phy_setMdioRate
 * PURPOSE:
 *      Set MDIO(Management Data Input/Output) clock rate in KHZ on specified channel
 * INPUT:
 *      unit            -- Device unit number
 *      chn_id          -- MDIO channel ID
 *      rate_khz        -- MDIO clock rate
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success.
 *
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setMdioRate(
    const UI32_T    unit,
    const UI32_T    chn_id,
    const UI32_T    rate_khz);

/* FUNCTION NAME:   hal_phy_getDieLaneMap
 * PURPOSE:
 *      Convert unit/port to die and lane addr.
                           examples of lane addr conversion
 *                         CL8360: for some port mapped to
 *                                 macro 0 lane 0 = 1 (macro 0 reserved for cpi macro) * 4 (4 lanes per macro) +0 = 4;
 *                                 macro 1 lane 3 = 2 (cpi macro + macro 0) * 4 (4 lanes per macro) + 3 = 11;
 *                         CL8570: for some port mapped to
 *                                 macro 0 lane 0 = 0 * 8 (8 lanes per macro) + 0 = 0;
 *                                 macro 1 lane 3 = 1 * 8 (8 lanes per macro) + 3 = 11;
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_up_id       -- pointer to the uP id (=die id)
 *                         ex. CL8360 range = 0~1
                               CL8570 range = 0~4 (4 index to T-die)
 *      ptr_lane_addr   -- global lane addr in a die/bin
 * RETURN:
 *      CLX_E_OK             -- Operate success.
 *      CLX_E_BAD_PARAMETER  -- Invalid input
 *      CLX_E_NOT_SUPPORT    -- not support nullphy addr translation
 * NOTES:
 */

CLX_ERROR_NO_T
hal_phy_getDieLaneMap(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    UI32_T                              *ptr_up_id,
    UI32_T                              *ptr_lane_addr);

/* FUNCTION NAME:   hal_phy_setMxLink
 * PURPOSE:
 *      set port to support MxLink feature
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      enable          -- 1: enable mxlink 0: disable mxlink
 * RETURN:
 *      CLX_E_OK             -- Operate success.
 *      CLX_E_BAD_PARAMETER  -- Invalid input.
 *      CLX_E_NOT_SUPPORT    -- Hardware does not support.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_setMxLink(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        enable);

/* FUNCTION NAME:   hal_phy_getMxLink
 * PURPOSE:
 *      get MxLink enable/disable
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 * OUTPUT:
 *      ptr_enable      -- show mxlink enable/disable
 * RETURN:
 *      CLX_E_OK             -- Operate success.
 *      CLX_E_BAD_PARAMETER  -- Invalid input.
 *      CLX_E_NOT_SUPPORT    -- Hardware does not support.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getMxLink(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        UI32_T                              *ptr_enable);

/* FUNCTION NAME:   hal_phy_getFecCnt
 * PURPOSE:
 *      get fec counter value based on counter type
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      lane_id         -- Device lane number
 *      cnt_type        -- CERR/UCERR/lane SERR
 * OUTPUT:
 *      ptr_cnt         -- fec counter value
 * RETURN:
 *      CLX_E_OK             -- Operate success.
 *      CLX_E_BAD_PARAMETER  -- Invalid input.
 *      CLX_E_NOT_SUPPORT    -- Hardware does not support.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_phy_getFecCnt(
        const UI32_T                        unit,
        const UI32_T                        port_id,
        const UI32_T                        lane_id,
        const HAL_PHY_FEC_CNT_TYPE_T        cnt_type,
        HAL_PHY_FEC_CNT_T                   *ptr_cnt);

CLX_ERROR_NO_T
hal_phy_setLinkTrainingEn(
    const UI32_T                            unit,
    const UI32_T                            port_id,
    const HAL_PHY_LINK_TRAINING_TYPE_T      type);

CLX_ERROR_NO_T
hal_phy_getLinkTrainingEn(
    const UI32_T                            unit,
    const UI32_T                            port_id,
    HAL_PHY_LINK_TRAINING_TYPE_T            *type);

CLX_ERROR_NO_T
hal_phy_getAnEn(
    const UI32_T                            unit,
    const UI32_T                            port_id,
    HAL_PHY_AN_TYPE_T                       *ptr_an_en);

CLX_ERROR_NO_T
hal_phy_setAnEn(
    const UI32_T                            unit,
    const UI32_T                            port_id,
    HAL_PHY_AN_TYPE_T                       an_en);

CLX_ERROR_NO_T
hal_phy_setPrbsGenerator(
    const UI32_T                            unit,
    const UI32_T                            port_id,
    HAL_PHY_PRBS_CONFIG_T                   prbs_gen);

CLX_ERROR_NO_T
hal_phy_setAdverIntf(
    const UI32_T                            unit,
    const UI32_T                            port_id,
    const UI32_T                            adver_type);

#endif  /* End of HAL_PHY_H */
