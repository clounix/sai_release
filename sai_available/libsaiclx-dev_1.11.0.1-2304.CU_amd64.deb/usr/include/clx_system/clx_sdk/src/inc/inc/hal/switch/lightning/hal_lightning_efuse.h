/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_efuse.h
 * PURPOSE:
 *  Provide HAL efuse APIs for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_LIGHTNING_EFUSE_H
#define HAL_LIGHTNING_EFUSE_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <hal/switch/lightning/hal_lightning_mbist.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_LIGHTNING_EFUSE_MACRO_WORDS                     (128)
#define HAL_LIGHTNING_EFUSE_TDIE_GROUP_1_WORDS              (HAL_LIGHTNING_EFUSE_MACRO_WORDS * 1)
#define HAL_LIGHTNING_EFUSE_TDIE_GROUP_2_WORDS              (HAL_LIGHTNING_EFUSE_MACRO_WORDS * 3)
#define HAL_LIGHTNING_EFUSE_PDIE_GROUP_1_WORDS              (HAL_LIGHTNING_EFUSE_MACRO_WORDS * 1)
#define HAL_LIGHTNING_EFUSE_PDIE_GROUP_2_WORDS              (HAL_LIGHTNING_EFUSE_MACRO_WORDS * 2)

#define HAL_LIGHTNING_EFUSE_GET_MACRO(__addr__)             ((__addr__) / HAL_LIGHTNING_EFUSE_MACRO_WORDS)
#define HAL_LIGHTNING_EFUSE_GET_PER_MACRO_ADDR(__addr__)    ((__addr__) % HAL_LIGHTNING_EFUSE_MACRO_WORDS)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_lightning_efuse_load(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T       die,
    const HAL_EFUSE_GROUP_T    group);

CLX_ERROR_NO_T
hal_lightning_efuse_read(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T       die,
    const HAL_EFUSE_GROUP_T    group,
    const UI32_T                   addr,
    UI32_T                         *ptr_val);

CLX_ERROR_NO_T
hal_lightning_efuse_dmaRead(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T       die,
    const HAL_EFUSE_GROUP_T    group,
    const UI32_T                   addr,
    const UI32_T                   words,
    UI32_T                         *ptr_buf);  /* if ptr_buf is NULL, put data to EFS_MIR only */

CLX_ERROR_NO_T
hal_lightning_efuse_readMir(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T       die,
    const HAL_EFUSE_GROUP_T    group,
    const UI32_T                   mir_idx,
    UI32_T                         *ptr_val);

CLX_ERROR_NO_T
hal_lightning_efuse_write(
    const UI32_T                   unit,
    const HAL_CHIP_DIE_T       die,
    const HAL_EFUSE_GROUP_T    group,
    const UI32_T                   addr,
    const UI32_T                   bit_offset,
    const UI32_T                   bit_len,
    const UI32_T                   value);

#endif /* End of HAL_LIGHTNING_EFUSE_H */

