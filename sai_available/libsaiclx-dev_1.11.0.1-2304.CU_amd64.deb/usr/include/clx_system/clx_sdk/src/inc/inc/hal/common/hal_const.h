/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_const.h
 * PURPOSE:
 *  It provides constant definition for use.
 *
 * NOTES:
 */

#ifndef HAL_CONST_H
#define HAL_CONST_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <hal/common/hal_swc.h>
#include <hal/common/hal_stat.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_VLAN_ENTRY_NUM              (4096)
#define HAL_TRILL_NICKNAME_MIN          (0x0001)   /* 0x0000 is unknown */
#define HAL_TRILL_NICKNAME_MAX          (0xFFBF)   /* 0xFFC0~0xFFFF is reserved */
#define HAL_VM_P2P_ECID_MIN             (0x1)      /* min ecid for point-to-point e-channel      */
#define HAL_VM_P2P_ECID_MAX             (0xFFFFF)  /* max ecid for point-to-point e-channel      */
#define HAL_VM_P2MP_ECID_MIN            (0x100000) /* min ecid for point-to-multipoint e-channel */
#define HAL_VM_P2MP_ECID_MAX            (0x3FFFFE) /* max ecid for point-to-multipoint e-channel */
#define HAL_VM_VIF_MIN                  (0x0)      /* min svif */
#define HAL_VM_VIF_MAX                  (0xFFF)    /* max svif */
#define HAL_VM_VIF_LIST_MIN             (0x4000)   /* min dvif */
#define HAL_VM_VIF_LIST_MAX             (0x7FFF)   /* max dvif */
#define HAL_VM_SCID_MIN                 (0x1)      /* min scid */
#define HAL_VM_SCID_MAX                 (0xFFF)    /* max scid */
#define HAL_QOS_PCP_NUM                 (8)        /* 3 bit PCP in VLAN tag */
#define HAL_QOS_DEI_NUM                 (2)        /* 1 bit DEI in VLAN tag */
#define HAL_QOS_DSCP_NUM                (64)       /* 6 bit DSCP in IP header */
#define HAL_QOS_EXP_NUM                 (8)        /* 3 bit EXP in MPLS Lable */
#define HAL_QOS_COLOR_NUM               (3)        /* 3 bit colors(Green/Yellow/Red) */

/* MACRO FUNCTION DECLARATIONS
 */
#define PTR_HAL_CONST_INFO(__unit__, __module__) \
        (_ext_chip_control_block[(__unit__)].ptr_driver_info->ptr_const_info->ptr_##__module__##_const)

/* DATA TYPE DECLARATIONS
 */

typedef struct HAL_CONST_VLAN_INFO_S
{
    UI32_T    vid_ctl_add;
} HAL_CONST_VLAN_INFO_T;

typedef struct HAL_CONST_PKT_INFO_S
{
    UI32_T    ipp_excpt_num;
    UI32_T    ipp_l3_excpt_num;
    UI32_T    ipp_copy2cpu_num;
    UI32_T    ipp_rsn_num;
    UI32_T    epp_excpt_num;
    UI32_T    epp_copy2cpu_num;
    UI32_T    pcie_que_num;
    UI32_T    cpi_que_num;
} HAL_CONST_PKT_INFO_T;

typedef struct HAL_CONST_SWC_INFO_S
{
    UI32_T    emi[HAL_SWC_CAP_EMI_LAST];
    UI32_T    tcam_bank_num;
    UI32_T    tcam_bank_entry;
    UI32_T    master_die_id;
} HAL_CONST_SWC_INFO_T;

typedef struct HAL_CONST_STAT_INFO_S
{
    UI32_T    pp[HAL_STAT_CAP_PP_LAST];
    UI32_T    mac[HAL_STAT_CAP_MAC_LAST];
    UI32_T    tm[HAL_STAT_CAP_TM_LAST];
} HAL_CONST_STAT_INFO_T;

typedef struct HAL_CONST_ACL_INFO_S
{
    UI32_T    udf_int_key_vld_bmp_flw;
    UI32_T    udf_int_key_vld_bmp_igr;
    UI32_T    udf_int_key_vld_bmp_egr;
    UI32_T    udf_0_pkg_tlv_base_id;
    UI32_T    action_flags_igr;
    UI32_T    action_flags_egr;
    UI32_T    igr_acl_group_label_lsb_vld_bits;
    UI32_T    rewr_page_num;
} HAL_CONST_ACL_INFO_T;

typedef struct HAL_CONST_TM_INFO_S
{
    UI32_T    cpu_queue_num;
    UI32_T    port_pfc_max_num; //Max num of pfc priority support on port
    UI32_T    cell_size;
} HAL_CONST_TM_INFO_T;

typedef struct HAL_CONST_SEC_INFO_S
{
    UI32_T max_icmpv4_size;                                     /* maximum icmpv4 size */
    UI32_T max_icmpv6_size;                                     /* maximum icmpv6 size */
    UI32_T max_l4_prot;                                         /* maximum l4 protocol */
    UI32_T min_udp_size;                                        /* minimum udp size */
    UI32_T min_udp_frg_off;                                     /* minimum udp fragment offset */
    UI32_T min_tcp_size;                                        /* minimum tcp size */
    UI32_T min_tcp_frg_off;                                     /* minimum tcp fragment offset */
    UI32_T min_sctp_size;                                       /* minimum sctp size */
    UI32_T min_sctp_frg_off;                                    /* minimum sctp fragment offset */
    UI32_T min_ipv6_frag_size;                                  /* minimum ipv6 fragment size */
    UI32_T max_sc_meter_rate;                                   /* maximum storm control meter rate, unit: kbps */
}HAL_CONST_SEC_INFO_T;

typedef struct HAL_CONST_INFO_S
{
    /* vlan */
    HAL_CONST_VLAN_INFO_T    *const ptr_vlan_const;
    /* pkt */
    HAL_CONST_PKT_INFO_T     *const ptr_pkt_const;
    /* swc */
    HAL_CONST_SWC_INFO_T     *const ptr_swc_const;
    /* stat */
    HAL_CONST_STAT_INFO_T    *const ptr_stat_const;
    /* acl */
    HAL_CONST_ACL_INFO_T     *const ptr_acl_const;
    /* tm */
    HAL_CONST_TM_INFO_T      *const ptr_tm_const;
    /* security */
    HAL_CONST_SEC_INFO_T     *const ptr_sec_const;
} HAL_CONST_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* GLOBAL VARIABLE EXTERN DECLARATIONS
 */

#endif  /* #ifndef HAL_CONST_H */
