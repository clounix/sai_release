/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_pkt_rsrc.h
 * PURPOSE:
 *      It provides hal pkt module API.
 * NOTES:
 *
 */

#ifndef HAL_PKT_RSRC_H
#define HAL_PKT_RSRC_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_pkt.h>


/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_PKT_PP_REASON_STR_LEN       (64)

/* Keep these values applied to different modules. */
#define HAL_PKT_IPP_EXCPT_NUM           (256)
#define HAL_PKT_EPP_EXCPT_NUM           (64)
#define HAL_PKT_IPP_L3_EXCPT_NUM        (6)
#define HAL_PKT_IPP_RSN_NUM             (16)
#define HAL_PKT_IPP_COPY2CPU_NUM        (16)
#define HAL_PKT_EPP_COPY2CPU_NUM        (8)

/* IEV_CFG_EXCPT_EN_W1_SDK_REDIRECT_TO_CPU_L2UC_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L2UC      (192 + 23)

/* IEV_CFG_EXCPT_EN_W1_SDK_REDIRECT_TO_CPU_L3UC_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_REDIRECT_TO_CPU_L3UC      (192 + 24)

/* IEV_CFG_EXCPT_EN_W1_SDK_L3UC_DA_MISS_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_L3UC_DA_MISS              (192 + 30)

/* IEV_CFG_EXCPT_EN_W1_SDK_L3MC_PIM_REGISTER_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_L3MC_PIM_REGISTER         (192 + 31)

/* IEV_CFG_EXCPT_EN_W0_SDK_FLEX_DECAP_0_REASON_0_FIELD_ID */
#define HAL_PKT_IPP_EXCPT_IEV_SDK_FLEX_DECAP_0_REASON_0     (224 + 8)

/* HW define offset
 * Module write IEV.cp_to_cpu_idx=1-3
 * Module write IEV_CFG_CP_TO_CPU_BIT_POS[offset + cp_to_cpu_idx - 1]
 */
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L2UC_DA   (0)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L2MC_DA   (3)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L2SA      (6)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_MPLS      (9)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_TRILL     (12)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_FCOE      (15)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L3UC_DA   (18)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L3UC_SA   (21)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_L3MC      (24)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_FLW_UC    (27)
#define HAL_PKT_IEV_CP_TO_CPU_BIT_POS_FLW_MC    (30)

/* capacities are the same between CL8360 and CL8570 */
#define HAL_PKT_IPP_EXCPT_BITMAP_SIZE    (CLX_BITMAP_SIZE(HAL_PKT_IPP_EXCPT_NUM))
#define HAL_PKT_IPP_L3_EXCPT_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_PKT_IPP_L3_EXCPT_NUM))
#define HAL_PKT_EPP_EXCPT_BITMAP_SIZE    (CLX_BITMAP_SIZE(HAL_PKT_EPP_EXCPT_NUM))
#define HAL_PKT_IPP_RSN_BITMAP_SIZE      (CLX_BITMAP_SIZE(HAL_PKT_IPP_RSN_NUM))
#define HAL_PKT_IPP_COPY2CPU_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_PKT_IPP_COPY2CPU_NUM))
#define HAL_PKT_EPP_COPY2CPU_BITMAP_SIZE (CLX_BITMAP_SIZE(HAL_PKT_EPP_COPY2CPU_NUM))

typedef UI32_T HAL_PKT_IPP_EXCPT_BITMAP_T[HAL_PKT_IPP_EXCPT_BITMAP_SIZE];
typedef UI32_T HAL_PKT_IPP_L3_EXCPT_BITMAP_T[HAL_PKT_IPP_L3_EXCPT_BITMAP_SIZE];
typedef UI32_T HAL_PKT_EPP_EXCPT_BITMAP_T[HAL_PKT_EPP_EXCPT_BITMAP_SIZE];
typedef UI32_T HAL_PKT_IPP_RSN_BITMAP_T[HAL_PKT_IPP_RSN_BITMAP_SIZE];
typedef UI32_T HAL_PKT_IPP_COPY2CPU_BITMAP_T[HAL_PKT_IPP_COPY2CPU_BITMAP_SIZE];
typedef UI32_T HAL_PKT_EPP_COPY2CPU_BITMAP_T[HAL_PKT_EPP_COPY2CPU_BITMAP_SIZE];

typedef struct
{
    /* excpt */
    HAL_PKT_IPP_EXCPT_BITMAP_T        ipp_excpt_bitmap;
    HAL_PKT_IPP_L3_EXCPT_BITMAP_T     ipp_l3_excpt_bitmap;
    HAL_PKT_EPP_EXCPT_BITMAP_T        epp_excpt_bitmap;

    /* cp */
    HAL_PKT_IPP_RSN_BITMAP_T          ipp_rsn_bitmap;
    HAL_PKT_IPP_COPY2CPU_BITMAP_T     ipp_copy2cpu_bitmap;
    HAL_PKT_EPP_COPY2CPU_BITMAP_T     epp_copy2cpu_bitmap;

} HAL_PKT_RX_REASON_BITMAP_T;

/* Control-to-CPU Decap Types */
typedef enum
{
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_NONE = 0,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_TRILL,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_MPLS,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_GRE,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_VXLAN_GPE,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_VXLAN_BAS,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_RAW,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_FLEX,
    HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_LAST
} HAL_PKT_CTRL_TO_CPU_DECAP_TYPE_T;

/* Control-to-CPU Action Types */
typedef enum
{
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_NONE = 0,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_CPU_QUE,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_REDIR,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_REDIR_IF_FWD,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_CP2CPU_IF_FWD,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_SUPP_CPU,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_DROP_ALL,
    HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_INVALID
} HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T;

/* Control-to-CPU Types */
typedef enum
{
    HAL_PKT_GET_REASON_BY_KET_QUEUE = 0,
    HAL_PKT_GET_REASON_BY_KET_LCL_CHIP_IDX,
    HAL_PKT_GET_REASON_BY_KET_RCL_CHIP_IDX,
    HAL_PKT_GET_REASON_BY_KET_LAST
} HAL_PKT_GET_REASON_BY_KET_T;

/* INTERNAL SUBPROGRAM SPECIFICATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_pkt_mapIppExcptToUser
 * PURPOSE:
 *      To map the reason from hw ipp exception bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapIppExcptToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
    CLX_PKT_RX_REASON_BITMAP_T              user_bitmap);

/* FUNCTION NAME: hal_pkt_mapIppExcptCodeToUser
 * PURPOSE:
 *      To map the reason from hw ipp exception value to user reason bitmap.
 * INPUT:
 *      code   -- The hw reason code
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapIppExcptCodeToUser(
    const UI32_T                            unit,
    UI32_T                                  code,
    CLX_PKT_RX_REASON_BITMAP_T              user_bitmap);

/* FUNCTION NAME: hal_pkt_mapIppL3ExcptToUser
 * PURPOSE:
 *      To map the reason from hw ipp l3 exception bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapIppL3ExcptToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_pkt_mapIppCopyToCpuToUser
 * PURPOSE:
 *      To map the reason from hw ipp copy2cpu bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapIppCopyToCpuToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_pkt_mapIppRsnToUser
 * PURPOSE:
 *      To map the reason from hw ipp rsn bitmap to user reason bitmap.
 * INPUT:
 *      hw_bitmap       -- The hw reason bitmap
 * OUTPUT:
 *      ptr_user_bitmap -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapIppRsnToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_pkt_mapIppRsnCodeToUser
 * PURPOSE:
 *      To map the reason from hw ipp rsn code to user reason bitmap.
 * INPUT:
 *      code            -- The hw reason code
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapIppRsnCodeToUser(
    const UI32_T                            unit,
          UI32_T                            code,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_pkt_mapEppExcptToUser
 * PURPOSE:
 *      To map the reason from hw epp exception bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapEppExcptToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_pkt_mapEppExcptCodeToUser
 * PURPOSE:
 *      To map the reason from hw epp exception code to user reason bitmap.
 * INPUT:
 *      code   -- The hw reason code
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapEppExcptCodeToUser(
    const UI32_T                            unit,
          UI32_T                            code,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_pkt_mapEppCopyToCpuToUser
 * PURPOSE:
 *      To map the reason from hw epp copy2cpu bitmap to user reason bitmap.
 * INPUT:
 *      ptr_hw_bitmap   -- The hw reason bitmap
 * OUTPUT:
 *      user_bitmap     -- Pointer to the user reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapEppCopyToCpuToUser(
    const UI32_T                            unit,
    const HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap,
          CLX_PKT_RX_REASON_BITMAP_T        user_bitmap);

/* FUNCTION NAME: hal_pkt_mapUserToIppExcpt
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw ipp exception bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToIppExcpt(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_pkt_mapUserToIppL3Excpt
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw ipp l3 excpt bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToIppL3Excpt(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_pkt_mapUserToIppCopy2cpu
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw ipp copy2cpu bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToIppCopyToCpu(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_pkt_mapUserToIppRsn
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw ipp rsn bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToIppRsn(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_pkt_mapUserToEppExcpt
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw epp exception bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToEppExcpt(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_pkt_mapUserToEppCopy2cpu
 * PURPOSE:
 *      To map the reason from user reason bitmap to hw epp copy2cpu bitmap.
 * INPUT:
 *      user_bitmap     -- The user reason bitmap
 * OUTPUT:
 *      ptr_hw_bitmap   -- Pointer to the hw reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to map the reason
 *      CLX_E_OTHERS    -- Fail to map the reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_mapUserToEppCopyToCpu(
    const UI32_T                            unit,
    const CLX_PKT_RX_REASON_BITMAP_T        user_bitmap,
          HAL_PKT_RX_REASON_BITMAP_T        *ptr_hw_bitmap);

/* FUNCTION NAME: hal_pkt_transUserToHwReason
 * PURPOSE:
 *      To translate the reason from user-view to chip-view.
 * INPUT:
 *      user_reason     -- The user-view reason
 * OUTPUT:
 *      ptr_hw_reason   -- Pointer to the chip-view reason
 * RETURN:
 *      CLX_E_OK        -- Success to translate the reason.
 *      CLX_E_OTHERS    -- Undefined user-view reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_transUserToHwReason(
    const UI32_T                                unit,
    const CLX_PKT_RX_REASON_T                   user_reason,
    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T     hw_action,
          UI32_T                                *ptr_hw_reason);

/* FUNCTION NAME: hal_pkt_transHwToUserReason
 * PURPOSE:
 *      To translate the reason from chip-view to user-view.
 * INPUT:
 *      hw_reason       -- The chip-view reason
 * OUTPUT:
 *      ptr_user_reason -- Pointer to the user-view reason
 * RETURN:
 *      CLX_E_OK        -- Success to translate the reason.
 *      CLX_E_OTHERS    -- Undefined chip-view reason
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_transHwToUserReason(
    const UI32_T                            unit,
    const UI32_T                            hw_reason,
    const HAL_PKT_CTRL_TO_CPU_ACTION_TYPE_T hw_action,
          CLX_PKT_RX_REASON_T               *ptr_user_reason);

/* FUNCTION NAME: hal_pkt_setCtrlToCpuEntry
 * PURPOSE:
 *      To set a specify ctrl2cpu entry.
 * INPUT:
 *      unit            -- The unit ID
 *      index           -- The entry index in HW table which user want to set
 *      ptr_entry       -- The value of the entry user want to set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Success to set the ctrl2cpu entry.
 *      CLX_E_OTHERS    -- Fail to set the ctrl2cpu entry.
 * NOTES:
 *      Must get the entry first, and then modify the fields want to set.
 */
CLX_ERROR_NO_T
hal_pkt_setCtrlToCpuEntry(
    const UI32_T                      unit,
    const UI32_T                      index,
    const CLX_PKT_CTRL_TO_CPU_ENTRY_T *ptr_entry);

/* FUNCTION NAME: hal_pkt_getCtrlToCpuEntry
 * PURPOSE:
 *      To set action of a ctrl2cpu entry
 * INPUT:
 *      unit            -- The unit ID
 *      index           -- The entry index in HW table which user want to get
 * OUTPUT:
 *      ptr_entry       -- The value of the target entry
 * RETURN:
 *      CLX_E_OK        -- Success to get the entry.
 *      CLX_E_OTHERS    -- Fail to get the entry.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_getCtrlToCpuEntry(
    const UI32_T                      unit,
    const UI32_T                      index,
          CLX_PKT_CTRL_TO_CPU_ENTRY_T *ptr_entry);

/* FUNCTION NAME: hal_pkt_delCtrlToCpuEntryAll
 * PURPOSE:
 *      To delete all ctrl-to-CPU entries configured.
 * INPUT:
 *      unit            -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operation is successful.
 *      CLX_E_OTHERS    -- Fail
 *
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_delCtrlToCpuEntryAll(
    const UI32_T                        unit);

/* FUNCTION NAME: hal_pkt_setRxQueueMapping
 * PURPOSE:
 *      To set a reason-to-queue mapping to the specified entry.
 * INPUT:
 *      unit            -- The unit ID
 *      queue           -- The specified queue
 *      reason_bitmap   -- The reason bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Success to set the mapping.
 *      CLX_E_OTHERS    -- Fail to set the mapping.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_setRxQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        queue,
    const CLX_PKT_RX_REASON_BITMAP_T    reason_bitmap);

/* FUNCTION NAME: hal_pkt_getRxQueueMapping
 * PURPOSE:
 *      To get a reason-to-queue mapping from the specified entry.
 * INPUT:
 *      unit            -- The unit ID
 *      queue           -- The specified queue
 * OUTPUT:
 *      ptr_reason_bitmap -- Pointer to the reason bitmap
 * RETURN:
 *      CLX_E_OK        -- Success to get the mapping.
 *      CLX_E_OTHERS    -- Fail to get the mapping.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_getRxQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        queue,
          CLX_PKT_RX_REASON_BITMAP_T    *ptr_reason_bitmap);

/* FUNCTION NAME:   hal_pkt_setRxChipMapping
 * PURPOSE:
 *      Set the reason bitmap to trap packets to the remote chip
 * INPUT:
 *      unit                -- Device unit number
 *      chip                -- Device chip id
 *      reason_bitmap       -- The reason bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_pkt_setRxChipMapping(
    const UI32_T                        unit,
    const UI32_T                        chip,
    const CLX_PKT_RX_REASON_BITMAP_T    reason_bitmap);

/* FUNCTION NAME:   hal_pkt_getRxChipMapping
 * PURPOSE:
 *      Get the reason bitmap which traps packets to the target remote chip
 * INPUT:
 *      unit                -- Device unit number
 *      chip                -- Device chip id
 *      ptr_reason_bitmap   -- Pointer to the reason bitmap obtained
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_pkt_getRxChipMapping(
    const UI32_T                        unit,
    const UI32_T                        chip,
          CLX_PKT_RX_REASON_BITMAP_T    *ptr_reason_bitmap);

/* FUNCTION NAME: hal_pkt_deinitRsrcMgr
 * PURPOSE:
 *      To de-initialize the SW resource.
 * INPUT:
 *      unit            -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Success to perform de-initializtion.
 *      CLX_E_OTHERS    -- Fail to perform de-initializtion.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_deinitPktRsrc(
    const UI32_T    unit);

/* FUNCTION NAME: hal_initRsrcMgr
 * PURPOSE:
 *      To initialize the SW resource.
 * INPUT:
 *      unit            -- The unit ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Success to perform initializtion.
 *      CLX_E_OTHERS    -- Fail to perform initializtion.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_initPktRsrc(
    const UI32_T    unit);

/* FUNCTION NAME: hal_pkt_setRxMapping
 * PURPOSE:
 *      To set the CPU reason code to RX port and queue mapping.
 * INPUT:
 *      unit            -- The unit ID
 *      port            -- The port ID indicating CPU or CPI
 *      queue           -- The specified queue
 *      reason_bitmap   -- The reason bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operation is successful.
 *      CLX_E_OTHERS    -- Fail
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_pkt_setRxMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        queue,
    const CLX_PKT_RX_REASON_BITMAP_T    reason_bitmap);

/* FUNCTION NAME: hal_pkt_getRxMapping
 * PURPOSE:
 *      To get the CPU reason code to RX port and queue mapping.
 * INPUT:
 *      unit          -- The unit ID
 *      port          -- The port ID indicating CPU or CPI
 *      queue         -- The specified queue
 * OUTPUT:
 *      ptr_reason-bitmap -- Pointer of the reason bitmap
 * RETURN:
 *      CLX_E_OK      -- Successfully get the mapping.
 *      CLX_E_OTHERS  -- Get the mapping failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_pkt_getRxMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        queue,
          CLX_PKT_RX_REASON_BITMAP_T    *ptr_reason_bitmap);

CLX_ERROR_NO_T
hal_pkt_setStackingPortQueueMapping(
     const UI32_T                       unit,
     const UI32_T                       rmt_cpu_queue,
     const UI32_T                       stacking_queue);

CLX_ERROR_NO_T
hal_pkt_getStackingPortQueueMapping(
     const UI32_T                       unit,
     const UI32_T                       rmt_cpu_queue,
     UI32_T                             *ptr_stacking_queue);

#endif  /* End of HAL_VLAN_H */
