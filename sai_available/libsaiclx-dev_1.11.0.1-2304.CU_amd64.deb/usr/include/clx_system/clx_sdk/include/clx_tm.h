/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_tm.h
 * PURPOSE:
 *      It provides tm module API.
 *
 * NOTES:
 *
 */


#ifndef CLX_TM_H
#define CLX_TM_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */
/*port level node handler*/
#define CLX_TM_HANDLER_PORT     (0xFFFFFFFF)
#define CLX_TM_HANDLER_NONE     (CLX_INVALID_ID)


/*value 0 means no configure for bandwidth*/
#define CLX_TM_BANDWIDTH_NONE   (0)

#define CLX_PFCWD_MAX_DETECTION_TIME      (5000)        /* ms */
#define CLX_PFCWD_MAX_RECOVERY_TIME       (60000)       /* ms */
#define CLX_PFCWD_DEFAULT_DETECTION_TIME  (100)        /* ms */
#define CLX_PFCWD_DEFAULT_RECOVERY_TIME   (1000)       /* ms */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef UI32_T CLX_TM_HANDLER_T;

typedef enum
{
    CLX_TM_BUF_TYPE_IGR_PORT = 0,                       /* The buffer type is ingress port */
    CLX_TM_BUF_TYPE_IGR_QUEUE,                          /* The buffer type is ingress queue */
    CLX_TM_BUF_TYPE_EGR_PORT,                           /* The buffer type is egress port */
    CLX_TM_BUF_TYPE_EGR_QUEUE,                          /* The buffer type is egress queue */
    CLX_TM_BUF_TYPE_IGR_SYSTEM,                         /* The buffer type is ingress system */
    CLX_TM_BUF_TYPE_EGR_SYSTEM,                         /* The buffer type is egress system */
    CLX_TM_BUF_TYPE_IGR_DP_MIN,                         /* The buffer type is data plane minimum */
    CLX_TM_BUF_TYPE_IGR_DP_HRM,                         /* The buffer type is data plane headroom */
    CLX_TM_BUF_TYPE_LAST
} CLX_TM_BUF_TYPE_T;

typedef enum
{
    CLX_TM_HANDLER_TYPE_NONE = 0,                       /* The handler type is None */
    CLX_TM_HANDLER_TYPE_UNICAST_QUEUE,                  /* The handler type is Unicast queue */
    CLX_TM_HANDLER_TYPE_MULTICAST_QUEUE,                /* The handler type is Mulitcast queue */
    CLX_TM_HANDLER_TYPE_SCHEDULE_NODE,                  /* The handler type is Schedule node */
    CLX_TM_HANDLER_TYPE_LAST
}CLX_TM_HANDLER_TYPE_T;

typedef enum
{
    CLX_TM_SCH_MODE_SP = 0,                             /* The schedule mode is Strict Priority */
    CLX_TM_SCH_MODE_DWRR,                               /* The schedule mode is Weighted Round Robin */
    CLX_TM_SCH_MODE_LAST
}CLX_TM_SCH_MODE_T;

typedef enum
{
    CLX_TM_BANDWIDTH_MODE_BYTE = 0,                     /* The bandwidth is byte unit */
    CLX_TM_BANDWIDTH_MODE_PACKET,                       /* The bandwidth is packet unit */
    CLX_TM_BANDWIDTH_MODE_LAST
}CLX_TM_BANDWIDTH_MODE_T;

typedef enum
{
    CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_SEPARATE = 0,   /* DWRR minbw separate mode */
    CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_SHARE,          /* DWRR minbw share mode */
    CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_LAST
}CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_T;

/* TM Global control type */
typedef enum
{
    CLX_TM_PROPERTY_BANDWIDTH_SHAPER_LAYER,             /* Set how to calculate packet length for TM schedule block.
                                                         * In function clx_tm_setProperty, param0
                                                         * value 0 is for layer 2 shaper (without SFG and IFG).
                                                         * Param0 value 1 is for layer 1 shaper
                                                         * (include SFG and IFG). */

    CLX_TM_PROPERTY_SCHEDULE_DWRR_MINBW_COMBINE_MODE,   /* Set the relationship between minimum bandwidth and dwrr
                                                         * weight.
                                                         * In function clx_tm_setProperty, param0 is
                                                         * CLX_TM_SCHEDULE_DWRR_MINBW_COMBINE_MODE_T.
                                                         * Share mode means minimum bandwidth will be calculated into
                                                         * dwrr weight. Separate mode means minimum bandwidth will not
                                                         * be calculated into dwrr weight which means first service
                                                         * minimum bandwidth and then the free bandwidth will be shared
                                                         * by dwrr weight.*/

    CLX_TM_PROPERTY_SYSTEM_ECN,                         /* Set the global ECN remarking enabled less then
                                                         * global free threshold. (granularity : 2 cells) */
    CLX_TM_PROPERTY_SNAPSHOT_THRESHOLD_EGR_GLOBAL,      /* Use egress global threshold to trigger snapshot.
                                                         * Param0 will be buffer threshold to trigger snapshot and 0 is
                                                         * to disable.*/
    CLX_TM_PROPERTY_CPI_QUEUE_TRUNCATE_SIZE,            /* Set truncate packet size of one queue of CPI port.
                                                         * Param0 will be CPI port 0/1, param1 is handler of queue and
                                                         * value is truncate packet size.*/
    CLX_TM_PROPERTY_LAST
}CLX_TM_PROPERTY_T;

/* TM congestion control mode */
typedef enum
{
    CLX_TM_CNG_TAILDROP = 0,                /* tail drop, available for all queue type. */
    CLX_TM_CNG_WRED,                        /* enable WRED on TCP and non-TCP traffic, but not remark ECN cap packet
                                             * (pass & no remark), only available for UC queue. */
    CLX_TM_CNG_WRED_TCP,                    /* enable WRED on TCP traffic only, but not remark ECN cap packet
                                             * (pass & no remark), only available for UC queue. */

    CLX_TM_CNG_WRED_ECN,                    /* enable WRED on TCP and non-TCP traffic, and remark ECN cap packet
                                             * (pass & remark), only available for UC queue. */
    CLX_TM_CNG_WRED_TCP_ECN,                /* enable WRED on TCP traffic only, and remark ECN cap packet(pass & remark).
                                             * only available for UC queue. */

    CLX_TM_CNG_DCTCP,                       /* enable DCTCP, only available for UC queue. */
    CLX_TM_CNG_LAST
}CLX_TM_CNG_T;


typedef enum
{
    CLX_TM_TRAFFIC_TYPE_TCP = 0,                        /* TM traffic type: TCP traffic. */
    CLX_TM_TRAFFIC_TYPE_NON_TCP,                        /* TM traffic type: non-TCP traffic. */
    CLX_TM_TRAFFIC_TYPE_LAST
}CLX_TM_TRAFFIC_TYPE_T;

typedef enum
{
    CLX_TM_SNAPSHOT_TYPE_PERIODIC                   = (1U << 0),    /* The snapshot type perdiodic. */
    CLX_TM_SNAPSHOT_TYPE_THRESHOLD_EGR_GLOBAL       = (1U << 1),    /* The snapshot type global egress threshold. */
    CLX_TM_SNAPSHOT_TYPE_THRESHOLD_EGR_GLOBAL_HYS   = (1U << 2),    /* The snapshot type global egress hysteresis. */
    CLX_TM_SNAPSHOT_TYPE_FIRST_DROP                 = (1U << 3),    /* The snapshot type first drop. */
    CLX_TM_SNAPSHOT_TYPE_FIRST_FC                   = (1U << 4),    /* The snapshot type first fc. */
} CLX_TM_SNAPSHOT_BITMAP_TYPE_T;


//PFCWD

/* PFCWD State */
typedef enum
{
    CLX_TM_PFCWD_STATE_DISABLED,                        /* The PFC WatchDog state -- disabled */
    CLX_TM_PFCWD_STATE_CONFIG_NOT_RDY,                  /* The PFC WatchDog state -- enable but config not ready (pfc map not configure)*/
    CLX_TM_PFCWD_STATE_OPERATIONAL,                     /* The PFC WatchDog state -- operational */
    CLX_TM_PFCWD_STATE_STORMED,                         /* The PFC WatchDog state -- stormed */
    CLX_TM_PFCWD_STATE_LAST
} CLX_TM_PFCWD_STATE_T;

typedef enum
{
    CLX_TM_PFCWD_EVENT_DETECTED = 0,                    /* The PFC WatchDog PFC storm detected event */
    CLX_TM_PFCWD_EVENT_RECOVERED,                       /* The PFC WatchDog recovered event */
    CLX_TM_PFCWD_EVENT_LAST
}CLX_TM_PFCWD_EVENT_T;

typedef enum
{
    CLX_TM_PFCWD_ACTION_DROP = 0,                       /* The PFC WatchDog DROP action */
    CLX_TM_PFCWD_ACTION_FORWARD,                        /* The PFC WatchDog forward packets action */
    CLX_TM_PFCWD_ACTION_DONTCARE,                       /* The PFC WatchDog don't care action and just notify uplayer */
    CLX_TM_PFCWD_ACTION_LAST
} CLX_TM_PFCWD_ACTION_T;


typedef struct CLX_TM_BUF_OCCUPANCY_S
{
    UI32_T queue_depth;                                 /* The buffer occupancy queue depth */
    UI32_T headroom_depth;                              /* The buffer occupancy headroom depth */

} CLX_TM_BUF_OCCUPANCY_T;

typedef struct CLX_TM_BUF_WATERMARK_S
{
    UI32_T queue;                                       /* The buffer queue watermark */
    UI32_T headroom;                                    /* The buffer headroom watermark */

} CLX_TM_BUF_WATERMARK_T;


typedef struct CLX_TM_BUF_THRESHOLD_S
{

#define CLX_TM_BUF_THRESHOLD_FLAGS_HYSTERESIS_EN   (1<<0) /* the threshold for cancelling the flow control */
                                                          /* or drop state. unit: cell */
#define CLX_TM_BUF_THRESHOLD_FLAGS_MAX_STATIC_EN   (1<<1) /* To enable/disable the static maximum threshold */
                                                          /* on a port or queue. */
    UI32_T flags;
    UI32_T min;                                           /* the guarantee threshold. unit: cell */
    UI32_T headroom;                                      /* the FC/PFC headroom threshold. unit: cell */
    UI32_T hysteresis;                                    /* the threshold for cancelling the flow control */
                                                          /* or drop state while max_static_en is Enable. unit: cell */
                                                          /* while Dynamic is Enable hysteresis will be xon threshold */
                                                          /* for lossless. For PFC threshold, only support on Dawn */
    UI32_T xon;                                           /* The threshold for cancelling the flow control. Only support on lightning. */
    UI32_T max;                                           /* while max_static_en is Enable for a port, the max value */
                                                          /* is a static threshold, otherwise max_static is disable. */
                                                          /* unit: cell. */
                                                          /* while max_static_en is Enable for a queue, the max value */
                                                          /* is a static threshold, otherwise Dynamic is Enable. */
                                                          /* value = dynamic alpha * 256.*/
} CLX_TM_BUF_THRESHOLD_T;

typedef struct CLX_TM_SCH_TOPOLOGY_ENTRY_S
{
    CLX_TM_HANDLER_T handler;               /* Handler of children */
    CLX_TM_HANDLER_T parent_handler;        /* Handler of parent */
    UI32_T schedule_sequence;               /* It is used to indicate scheduling sequence if connecting to the same
                                             * parent handler. big->small
                                             */
}CLX_TM_SCH_TOPOLOGY_ENTRY_T;

typedef struct CLX_TM_BANDWIDTH_S
{
    UI32_T min_bandwidth;                   /* Minimum rate */
    UI32_T min_burst_size;                  /* Burst size for minimum bucket */
    UI32_T max_bandwidth;                   /* Maximum rate */
    UI32_T max_burst_size;                  /* Burst size for maximum bucket */
    CLX_TM_BANDWIDTH_MODE_T bandwidth_mode; /* It indicates that bandwidth is byte-based or packet-based. */
}CLX_TM_BANDWIDTH_T;

/* WRED */
typedef struct CLX_TM_WRED_ENTRY_S
{
    UI32_T min_threshold;                   /* The minimum threshold for the WRED profile entry */
    UI32_T max_threshold;                   /* The maximum threshold for the WRED profile entry */
    UI32_T max_drop_rate;                   /* The maximum drop rate for the WRED profile entry */
}CLX_TM_WRED_ENTRY_T;

typedef struct CLX_TM_WRED_QUEUE_CFG_S
{
    UI32_T profile_id;                      /* The WRED profile ID is bound by the queue. */
    UI32_T weight;                          /* The weight of current queue depth is used for calculating
                                             * the average queue depth, and the range is 0 ~ 100%.
                                             * The input parameter is enlarged 10000 times, and
                                             * the range is 0 ~ 10000. <CL>
                                             * If the input parameter does not match the exact HW setting,
                                             * SDK will choose a larger value of HW setting to replace the input parameter.
                                             */
}CLX_TM_WRED_QUEUE_CFG_T;

/* DCTCP */
typedef struct CLX_TM_DCTCP_PROFILE_S
{
    UI32_T offset_green;                    /* Green color offset */
    UI32_T offset_yellow;                   /* Yellow color offset */
    UI32_T offset_red;                      /* Red color offset.
                                             * While percentage mode is enabled, the offset value
                                             * will be dynamic and represent the percentage of qmax.
                                             * The percentage of qmax is the offset divide 256
                                             * and the valid offset range is between 0 to 256.
                                             * E.g. the offset is 128, the percentage of qmax
                                             * will be 128/256=50%.
                                             * If percentage mode is disabled, the offset value is
                                             * a static offset of qmax.
                                             */
}CLX_TM_DCTCP_PROFILE_T;

/* Network Visibility*/
/* TM ingress port buffer snapshot structure */
typedef struct CLX_TM_IGR_PORT_BUF_SNAPSHOT_S
{
    UI32_T port_id;              /* port id */
    UI32_T pcp_group0;           /* pcp group 0 */
    UI32_T pcp_group1;           /* pcp group 1 */
    UI32_T pcp_group2;           /* pcp group 2 */
    UI32_T pcp_group3;           /* pcp group 3 */
    UI32_T pcp_group4;           /* pcp group 4 */
    UI32_T pcp_group5;           /* pcp group 5 */
    UI32_T pcp_group6;           /* pcp group 6 */
    UI32_T pcp_group7;           /* pcp group 7 */
} CLX_TM_IGR_PORT_BUF_SNAPSHOT_T;

/* TM ingress pool buffer snapshot structure */
typedef struct CLX_TM_IGR_BUF_SNAPSHOT_S
{
    UI32_T global_lossless;                         /* global lossless */
    UI32_T global_headroom;                         /* global headroom */
    UI32_T port_cnt;                                /* port count */
    CLX_TM_IGR_PORT_BUF_SNAPSHOT_T *ptr_port_buf;   /* port buffer snapshot */
}CLX_TM_IGR_BUF_SNAPSHOT_T;

/* TM egress port buffer snapshot structure */
typedef struct CLX_TM_EGR_PORT_BUF_SNAPSHOT_S
{
    UI32_T port_id;                /* port id */
    UI32_T uc_group0;              /* unicast group 0 */
    UI32_T uc_group1;              /* unicast group 1 */
    UI32_T uc_group2;              /* unicast group 2 */
    UI32_T uc_group3;              /* unicast group 3 */
    UI32_T uc_group4;              /* unicast group 4 */
    UI32_T uc_group5;              /* unicast group 5 */
    UI32_T uc_group6;              /* unicast group 6 */
    UI32_T uc_group7;              /* unicast group 7 */
    UI32_T mc_group0;              /* multicast group 0 */
    UI32_T mc_group1;              /* multicast group 1 */
    UI32_T mc_group2;              /* multicast group 2 */
    UI32_T mc_group3;              /* multicast group 3 */
    UI32_T mc_group4;              /* multicast group 4 */
    UI32_T mc_group5;              /* multicast group 5 */
    UI32_T mc_group6;              /* multicast group 6 */
    UI32_T mc_group7;              /* multicast group 7 */
}CLX_TM_EGR_PORT_BUF_SNAPSHOT_T;

/* TM egress CPU queue buffer snapshot structure */
typedef struct CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_S
{
    UI32_T id;                                  /* egress queue buffer id */
    UI32_T depth;                               /* egress queue buffer depth */
}CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_T;

/* TM egress pool buffer snapshot structure */
typedef struct CLX_TM_EGR_BUF_SNAPSHOT_S
{
    UI32_T global_share;                                    /* egress global share buffer */
    UI32_T cpu_queue_cnt;                                   /* egress CPU queue count */
    CLX_TM_EGR_CPU_QUEUE_BUF_SNAPSHOT_T *ptr_cpu_queue_buf; /* egress CPU queue buffer snapshot structure */
    UI32_T port_cnt;                                        /* egress port count */
    CLX_TM_EGR_PORT_BUF_SNAPSHOT_T *ptr_port_buf;           /* egress port buffer snapshot structure */
} CLX_TM_EGR_BUF_SNAPSHOT_T;

typedef struct CLX_TM_POOL_BUF_SNAPSHOT_S
{
    UI32_T pool_id;                                         /* buffer pool id */
    CLX_TM_IGR_BUF_SNAPSHOT_T igr_buf;                      /* ingress buffer snapshot structure */
    CLX_TM_EGR_BUF_SNAPSHOT_T egr_buf;                      /* egress buffer snapshot structure */
}CLX_TM_POOL_BUF_SNAPSHOT_T;

typedef struct CLX_TM_PFCWD_ENTRY_S
{
    BOOL_T                  enable;             /* enable PFCWD */
    UI32_T                  detection_time;     /* detection time in ms */
    UI32_T                  recovery_time;      /* recovery time in ms */
    CLX_TM_PFCWD_ACTION_T   action;             /* Take what action when detect PFC storm */
}CLX_TM_PFCWD_ENTRY_T;


//Callback Function Prototype
typedef void (*CLX_TM_SNAPSHOT_FUNC_T)(
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_BITMAP_TYPE_T type,
    const UI32_T                        pool_cnt,
    const CLX_TM_POOL_BUF_SNAPSHOT_T    *ptr_pool_snapshot,
    void                                *ptr_cookie);



typedef void (*CLX_TM_PFCWD_HANDLE_FUNC_T)(
  const UI32_T                  unit,
  const UI32_T                  port,
  const CLX_TM_HANDLER_T        handler,      /*Queue*/
  const CLX_TM_PFCWD_EVENT_T    event_type,
  void                          *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_tm_createHandler
 * PURPOSE:
 *    Create a schedule handler for the specified egress port. <CL> A schedule handler
 *    can be a unicast queue or a multicast queue or a node which is
 *    composed of many queues.
 *
 * INPUT:
 *    unit                -- Device unit number
 *    port                -- Egress port ID
 *    handler_type        -- It indicate the type of the handler to be created by user.
 *    queue_id            -- The queue_id is meaningful if handler_type is
 *                            CLX_TM_HANDLER_TYPE_UNICAST_QUEUE or
 *                            CLX_TM_HANDLER_TYPE_MULTICAST_QUEUE.
 * OUTPUT:
 *    ptr_handler         -- The ID of the handler created by SDK
 * RETURN:
 *    CLX_E_OK            -- Operate success.
 *    CLX_E_TABLE_FULL    -- No more handler can be created.
 *    CLX_E_NOT_INITED    -- SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER -- Bad parameter.
 *
 * NOTES:
 *    This API should be called first if user chooses to use user-defined schedule
 *    policy. After calling this API, user should use the key pair
 *    {handler_type, handler_id} to uniquely identify a schedule handler.
 */
CLX_ERROR_NO_T
clx_tm_createHandler(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_TYPE_T         handler_type,
    const UI32_T                        queue_id,
    CLX_TM_HANDLER_T                    *ptr_handler) ;

/* FUNCTION NAME:   clx_tm_deleteHandler
 * PURPOSE:
 *    Delete a schedule handler for specified egress port. <CL> A schedule handler
 *    can be a unicast queue or a multicast queue or a queue group which is
 *    composed of many queues.
 *
 * INPUT:
 *    unit                    -- Device unit number
 *    port                    -- Egress port ID
 *    handler                 -- It indicates the ID of the handler.
 * OUTPUT:
 *    None.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_ENTRY_NOT_FOUND   -- The handler is not exist.
 *    CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
clx_tm_deleteHandler(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler);

/* FUNCTION NAME:   clx_tm_setScheduleTopology
 * PURPOSE:
 *      Configure schedule topology of an egress port.
 *
 * INPUT:
 *      unit               -- Device unit number
 *      port               -- Egress Physical port ID
 *      ptr_topology_entry -- Array with multiple topology entries
 *      entry_count        -- Entry count of the array ptr_topology_entry
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK           -- Success.
 *      CLX_E_OTHERS       -- Failed.
 *
 * NOTES:
 *      When topology is changed successfully, all schedule properties such as
 *      algorithm, DWRR weight, and min/maximum bandwidth will be rewritten to
 *      hardware.
 */
CLX_ERROR_NO_T
clx_tm_setScheduleTopology(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_SCH_TOPOLOGY_ENTRY_T   *ptr_topology_entry,
    const UI32_T                        entry_count);

/* FUNCTION NAME:   clx_tm_getScheduleTopology
 * PURPOSE:
 *      Get the schedule topology of an egress port.
 * INPUT:
 *      unit                   -- Device unit number
 *      port                   -- Egress Physical port ID
 *      entry_count            -- Entry count of the array ptr_topology_entry
 * OUTPUT:
 *      ptr_topology_entry     -- Array with multiple topology entries
 *                                returned by SDK
 *      ptr_actual_entry_count -- Entry count returned by SDK
 * RETURN:
 *      CLX_E_OK               -- Success.
 *      CLX_E_OTHERS           -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_getScheduleTopology(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_TM_SCH_TOPOLOGY_ENTRY_T         *ptr_topology_entry,
    UI32_T                              entry_count,
    UI32_T                              *ptr_actual_entry_count);

/* FUNCTION NAME:   clx_tm_setScheduleMode
 * PURPOSE:
 *      Configure SP/DWRR weight for a handler.
 * INPUT:
 *      unit         -- Device unit number
 *      port         -- Egress physical port ID to be written
 *      handler      -- The handler on which the bandwidth is written
 *      mode         -- Schedule algorithm (can be SP or DWRR)
 *      weight       -- Weight of DWRR <CL>
 *                      It is valid only when mode parameter is DWRR.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_setScheduleMode(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_SCH_MODE_T             mode,
    const UI32_T                        weight);

/* FUNCTION NAME:   clx_tm_getScheduleMode
 * PURPOSE:
 *      Get SP/DWRR weight of a handler.
 * INPUT:
 *      unit         -- Device unit number
 *      port         -- Egress physical port ID to be obtained
 *      handler      -- The handler to be obtained
 * OUTPUT:
 *      ptr_mode     -- Schedule algorithm (can be SP or DWRR)
 *      ptr_weight   -- Weight of DWRR <CL>
 *                      It is valid only when mode parameter is DWRR.
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_getScheduleMode(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_SCH_MODE_T                   *ptr_mode,
    UI32_T                              *ptr_weight);

/* FUNCTION NAME:   clx_tm_setBandwidth
 * PURPOSE:
 *      Configure min/maximum bandwidth for a handler.
 * INPUT:
 *      unit            -- Device unit number
 *      port            -- Egress physical port ID to be written
 *      handler         -- The handler on which the bandwidth is written
 *      ptr_bandwidth   -- Bandwidth information
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK        -- Success.
 *      CLX_E_OTHERS    -- Failed.
 *
 * NOTES:
 *      If the maximum bandwidth is 0, SDK will use this default bandwidth to
 *      configure hardware. If the burst size is 0, SDK will configure hardware as 0.
 *      If the burst size is between 1~(1*granularity), SDK will configure hardware as
 *      (1*granularity).
 */
CLX_ERROR_NO_T
clx_tm_setBandwidth(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BANDWIDTH_T            *ptr_bandwidth);

/* FUNCTION NAME:   clx_tm_getBandwidth
 * PURPOSE:
 *      Get min/maximum bandwidth of a handler.
 * INPUT:
 *      unit           -- Device unit number
 *      port           -- Egress physical port ID to be written
 *      handler        -- The bandwidth of the handler to be obtained
 * OUTPUT:
 *      ptr_bandwidth  -- The bandwidth of the handler
 * RETURN:
 *      CLX_E_OK       -- Success.
 *      CLX_E_OTHERS   -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_getBandwidth(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_BANDWIDTH_T                  *ptr_bandwidth);

/* FUNCTION NAME:   clx_tm_setTcQueueMapping
 * PURPOSE:
 *      Configure "TC to queue" mapping.
 * INPUT:
 *      unit         -- Device unit number
 *      port         -- Egress physical port ID to be written
 *      tc           -- Traffic class to be mapped
 *      type         -- The type of the handler must be unicast queue or
 *                      multicast queue or legacy queue.
 *      handler      -- The handler of the queue is mapped out.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      If parameter type is "unicast queue", parameter handler must be a unicast
 *      queue handler. If parameter type is "multicast queue", parameter handler
 *      must be a multicast queue handler. If parameter type is "none", parameter
 *      handler must be a legacy queue handler.
 */
CLX_ERROR_NO_T
clx_tm_setTcQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        tc,
    const CLX_TM_HANDLER_TYPE_T         type,
    const CLX_TM_HANDLER_T              handler);

/* FUNCTION NAME:   clx_tm_getTcQueueMapping
 * PURPOSE:
 *      Get "TC to queue" mapping.
 * INPUT:
 *      unit         -- Device unit number
 *      port         -- Egress physical port ID to be written
 *      tc           -- Traffic class to be mapped
 *      type         -- The type of the handler must be unicast queue or
 *                      multicast queue or legacy queue.
 * OUTPUT:
 *      ptr_handler  -- The handler of the queue is mapped out.
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      If parameter type is "unicast queue", parameter ptr_handler will be a
 *      unicast queue handler. If parameter type is "multicast queue", parameter
 *      ptr_handler will be a multicast queue handler. If parameter type is
 *      "none", parameter ptr_handler will be a legacy queue handler.
 */
CLX_ERROR_NO_T
clx_tm_getTcQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        tc,
    const CLX_TM_HANDLER_TYPE_T         type,
    CLX_TM_HANDLER_T                    *ptr_handler);

/* FUNCTION NAME: clx_tm_setIgrBufPcpRemap
 * PURPOSE:
 *      The function is used to set original pcp remapped to Ingress buffer PCP.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      org_pcp                 -- Original PCP
 *      igrbuf_pcp              -- Ingress buffer PCP
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_setIgrBufPcpRemap(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        org_pcp,
    const UI32_T                        igrbuf_pcp);

/* FUNCTION NAME: clx_tm_getIgrBufPcpRemap
 * PURPOSE:
 *      The function is used to get the original pcp remapped to ingress buffer
 *      PCP.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      org_pcp                 -- Original PCP
 * OUTPUT:
 *      ptr_igrbuf_pcp          -- Ingress buffer PCP
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_getIgrBufPcpRemap(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        org_pcp,
    UI32_T                              *ptr_igrbuf_pcp);

/* FUNCTION NAME: clx_tm_setEgrBufPfcPcpRemapQueue
 * PURPOSE:
 *      The function is used to set the pcp which is received from PFC pause
 *      frame remapped to egress queue.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      pfc_pcp                 -- The pcp which is received from PFC pause frame
 *      handler                 -- Egress queue handler
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_setEgrBufPfcPcpRemapQueue(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        pfc_pcp,
    const CLX_TM_HANDLER_T              handler);

/* FUNCTION NAME: clx_tm_getEgrBufPfcPcpRemapQueue
 * PURPOSE:
 *      The function is used to get the pcp which is received from PFC pause
 *      frame remapped to egress queue.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      pfc_pcp                 -- The pcp which is received from PFC pause frame
 * OUTPUT:
 *      ptr_handler             -- Egress queue handler
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_getEgrBufPfcPcpRemapQueue(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        pfc_pcp,
    CLX_TM_HANDLER_T                    *ptr_handler);

/* FUNCTION NAME: clx_tm_setProperty
 * PURPOSE:
 *      The function is used to configure some special properties for TM module.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- (Optional) If the property is Port or Queue
 *                                 setting, the port ID needs to be specified.
 *      handler                 -- (Optional) If the property is Queue setting,
 *                                 the queue handler needs to be specified.
 *      property                -- The property type of TM module which supports
 *                                 special properties of TM.
 *      param0                  -- The default parameter, refer to property for its
 *                                 definition.
 *      param1                  -- (Optional) The optional parameter which is
 *                                 available when the property needs the second
 *                                 arguments.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_setProperty(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_PROPERTY_T             property,
    const UI32_T                        param0,
    const UI32_T                        param1);

/* FUNCTION NAME: clx_tm_getProperty
 * PURPOSE:
 *      The function is used to get the special property for TM module.
 * INPUT:
 *      unit                   -- Device unit number.
 *      port                   -- (Optional) If the property is Port or Queue
 *                                setting, the port ID needs to be specified.
 *      handler                -- (Optional) If the property is Queue setting,
 *                                the queue handler needs to be specified.
 *      property               -- The property type of TM module which supports
 *                                special properties of TM.
 * OUTPUT:
 *      ptr_param0             -- The default parameter, refer to property for its
 *                                definition.
 *      ptr_param1             -- (Optional) The optional parameter which is
 *                                available when the property needs second
 *                                arguments.
 * RETURN:
 *      CLX_E_OK               -- Operate success.
 *      CLX_E_BAD_PARAMETER    -- Bad parameter.
 *      CLX_E_NOT_INITED       -- SDK module has not been initialized.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_getProperty(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_PROPERTY_T             property,
    UI32_T                              *ptr_param0,
    UI32_T                              *ptr_param1);

/* FUNCTION NAME: clx_tm_setCngCtrl
 * PURPOSE:
 *      The function is used to set queue TM congestion control mode
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      handler                 -- Egress queue handler
 *      mode                    -- TM congestion control mode
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_setCngCtrl(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_CNG_T                  mode);

/* FUNCTION NAME: clx_tm_getCngCtrl
 * PURPOSE:
 *      The function is used to get queue TM congestion control mode
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      handler                 -- Egress queue handler
 * OUTPUT:
 *      ptr_mode                -- TM congestion control mode
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_getCngCtrl(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_CNG_T                        *ptr_mode);

/* FUNCTION NAME: clx_tm_createWredProfile
 * PURPOSE:
 *      The function is used to create WRED profile.
 * INPUT:
 *      unit                    -- Device unit number
 *      profile_id              -- WRED profile ID
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_EXISTS      -- The profile has been created.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_createWredProfile(
    const UI32_T                        unit,
    const UI32_T                        profile_id);

/* FUNCTION NAME: clx_tm_delWredProfile
 * PURPOSE:
 *      The function is used to delete WRED profile.
 * INPUT:
 *      unit                    -- Device unit number
 *      profile_id              -- WRED profile ID
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_tm_delWredProfile(
    const UI32_T                        unit,
    const UI32_T                        profile_id);

/* FUNCTION NAME: clx_tm_setWredProfile
 * PURPOSE:
 *      The function is used to set WRED profile.
 * INPUT:
 *      unit                    -- Device unit number
 *      profile_id              -- WRED profile ID
 *      type                    -- Traffic type
 *      color                   -- Traffic color
 *      ptr_entry               -- WRED profile entry
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      Since each WRED profile has six WRED entries (TCP_R, TCP_Y, TCP_G,
 *      non-TCP_R, non-TCP_Y, and non_TCP_G), the API needs to be called six times
 *      for one profile.
 */
CLX_ERROR_NO_T
clx_tm_setWredProfile(
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    const CLX_TM_TRAFFIC_TYPE_T         type,
    const CLX_COLOR_T                   color,
    const CLX_TM_WRED_ENTRY_T           *ptr_entry);

/* FUNCTION NAME: clx_tm_getWredProfile
 * PURPOSE:
 *      The function is used to get WRED profile.
 * INPUT:
 *      unit                    -- Device unit number
 *      profile_id              -- WRED profile ID
 *      type                    -- Traffic type
 *      color                   -- Traffic color
 * OUTPUT:
 *      ptr_entry               -- WRED profile entry
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      Since each WRED profile has six WRED entries (TCP_R, TCP_Y, TCP_G,
 *      non-TCP_R, non-TCP_Y, and non_TCP_G), the API needs to be called six times
 *      for one profile.
 */
CLX_ERROR_NO_T
clx_tm_getWredProfile(
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    const CLX_TM_TRAFFIC_TYPE_T         type,
    const CLX_COLOR_T                   color,
    CLX_TM_WRED_ENTRY_T                 *ptr_entry);

/* FUNCTION NAME: clx_tm_setWredQueueConfig
 * PURPOSE:
 *      The function is used to set per queue WRED configuration.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      handler                 -- Egress queue handler
 *      ptr_entry               -- WRED configuration of egress queue
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      The WRED configuration only supports unicast queue.
 */
CLX_ERROR_NO_T
clx_tm_setWredQueueConfig(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_WRED_QUEUE_CFG_T       *ptr_entry);

/* FUNCTION NAME: clx_tm_getWredQueueConfig
 * PURPOSE:
 *      The function is used to get per queue WRED configuration.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      handler                 -- Egress queue handler
 * OUTPUT:
 *      ptr_entry               -- WRED configuration of egress queue
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      The WRED configuration only supports unicast queue.
 */
CLX_ERROR_NO_T
clx_tm_getWredQueueConfig(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_WRED_QUEUE_CFG_T             *ptr_entry);

/* FUNCTION NAME: clx_tm_createDctcpProfile
 * PURPOSE:
 *      The function is used to create DCTCP profile.
 * INPUT:
 *      unit                    -- Device unit number
 *      profile_id              -- DCTCP profile ID
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_EXISTS      -- The profile has been created.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
clx_tm_createDctcpProfile(
    const UI32_T                        unit,
    const UI32_T                        profile_id);

/* FUNCTION NAME: clx_tm_delDctcpProfile
 * PURPOSE:
 *      The function is used to delete DCTCP profile.
 * INPUT:
 *      unit                    -- Device unit number
 *      profile_id              -- DCTCP profile ID
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
clx_tm_delDctcpProfile(
    const UI32_T                        unit,
    const UI32_T                        profile_id);

/* FUNCTION NAME: clx_tm_setDctcpProfile
 * PURPOSE:
 *      The function is used to set DCTCP profile.
 * INPUT:
 *      unit                    -- Device unit number
 *      profile_id              -- DCTCP profile ID
 *      ptr_entry               -- DCTCP profile entry
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
clx_tm_setDctcpProfile(
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    const CLX_TM_DCTCP_PROFILE_T        *ptr_entry);

/* FUNCTION NAME: clx_tm_getDctcpProfile
 * PURPOSE:
 *      The function is used to get DCTCP profile.
 * INPUT:
 *      unit                    -- Device unit number
 *      profile_id              -- DCTCP profile ID
 * OUTPUT:
 *      ptr_entry               -- DCTCP profile entry
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
clx_tm_getDctcpProfile(
    const UI32_T                        unit,
    const UI32_T                        profile_id,
    CLX_TM_DCTCP_PROFILE_T              *ptr_entry);

/* FUNCTION NAME: clx_tm_setDctcpQueueConfig
 * PURPOSE:
 *      The function is used to set per queue DCTCP configuration.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      handler                 -- Egress queue handler
 *      profile_id              -- The DCTCP profile ID is bound by the queue.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      The DCTCP configuration only supports unicast queue.
 */
CLX_ERROR_NO_T
clx_tm_setDctcpQueueConfig(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        profile_id);

/* FUNCTION NAME: clx_tm_getDctcpQueueConfig
 * PURPOSE:
 *      The function is used to get per queue DCTCP configuration.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      handler                 -- Egress queue handler
 * OUTPUT:
 *      ptr_profile_id          -- The DCTCP profile ID is bound by the queue.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 *      CLX_E_NOT_INITED        -- SDK module has not been initialized.
 *      CLX_E_ENTRY_NOT_FOUND   -- The profile is not exist.
 * NOTES:
 *      The DCTCP configuration only supports unicast queue.
 */
CLX_ERROR_NO_T
clx_tm_getDctcpQueueConfig(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_profile_id);

/* FUNCTION NAME: clx_tm_setPfcMapping
 * PURPOSE:
 *      The function is used to set the mapping of the PCP and the queue group.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      pcp_bitmap       -- The bit map of port control protocol.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_setPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

/* FUNCTION NAME: clx_tm_getPfcMapping
 * PURPOSE:
 *      The function is used to get the mapping of the PCP and the queue group.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_pcp_bitmap   -- The bit map of port control protocol.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

/* FUNCTION NAME: clx_tm_setPcpPfcMapping
 * PURPOSE:
 *      The function is used to set the specified port/queue with lossless
 *      attribute and the pcp for pfc mapping.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- Physical port ID.
 *      handler                 -- Egress queue handler.
 *      pcp_bitmap              -- The bit map of port control protocal.
 * OUTPUT:
 *      None.

 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_setPcpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

/* FUNCTION NAME: clx_tm_getPcpPfcMapping
 * PURPOSE:
 *      The function is used to get the specified port/queue with lossless
 *      attribute and the pcp for pfc mapping.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- Physical port ID.
 *      handler                 -- Egress queue handler.
 * OUTPUT:
 *      ptr_pcp_bitmap          -- The bit map of port control protocal.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_OTHER             -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getPcpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

/* FUNCTION NAME: clx_tm_setDscpPfcMapping
 * PURPOSE:
 *      The function is used to set the specified port/queue with lossless
 *      attribute and the dscp for pfc mapping.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- Physical port ID.
 *      handler                 -- Egress queue handler.
 *      dscp_count              -- The dscp list count.
 *      ptr_dscp_list           -- The porint of dscp list.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_setDscpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        dscp_count,
    UI32_T                              *ptr_dscp_list);

/* FUNCTION NAME: clx_tm_getDscpPfcMapping
 * PURPOSE:
 *      The function is used to get the specified port/queue with lossless
 *      attribute and the dscp for pfc mapping.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- Physical port ID.
 *      handler                 -- Egress queue handler.
 * OUTPUT:
 *      ptr_dscp_count          -- The dscp list count.
 *      ptr_dscp_list           -- The porint of dscp list.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_OTHER             -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getDscpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_dscp_count,
    UI32_T                              *ptr_dscp_list);

/* FUNCTION NAME: clx_tm_setQueuePfcPriMapping
 * PURPOSE:
 *      The function is used to set the pfc priority vector when the specified
 *      lossless port/queue reach pfc threshold.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- Physical port ID.
 *      handler                 -- Egress queue handler.
 *      bitmap                  -- The priority bitmap.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_OTHER             -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_setQueuePfcPriMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        bitmap);

/* FUNCTION NAME: clx_tm_getQueuePfcPriMapping
 * PURPOSE:
 *      The function is used to get the pfc priority vector for the specified
 *      lossless port/queue.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- Physical port ID.
 *      handler                 -- Egress queue handler.
 * OUTPUT:
 *      ptr_bitmap              -- The priority bitmap.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_OTHER             -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getQueuePfcPriMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_bitmap);

/* FUNCTION NAME: clx_tm_setPfcPriQueueMapping
 * PURPOSE:
 *      The function is used to set the stopped lossless queue when the port
 *      receive pause frame with the specified pfc priority vector.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- Physical port ID.
 *      bitmap                  -- The priority bitmap.
 *      handler                 -- Egress queue handler.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_OTHER             -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_setPfcPriQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    const CLX_TM_HANDLER_T              handler);

/* FUNCTION NAME: clx_tm_getPfcPriQueueMapping
 * PURPOSE:
 *      The function is used to get the stopped lossless queue for the
 *      specified pfc priority vector.
 * INPUT:
 *      unit                    -- Device unit number.
 *      port                    -- Physical port ID.
 *      bitmap                  -- The priority bitmap.
 * OUTPUT:
 *      ptr_handler             -- Egress queue handler.
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_OTHER             -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getPfcPriQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    UI32_T                              *ptr_handler);

/* FUNCTION NAME: clx_tm_setBufThreshold
 * PURPOSE:
 *      The function is used to set the buffer threshold.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Tm queue handler.
 *      type             -- To set the threshold of port/queue in ingress/egress type.
 *      ptr_entry        -- the entry which the user want to set.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_setBufThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    const CLX_TM_BUF_THRESHOLD_T        *ptr_entry);

/* FUNCTION NAME: clx_tm_getBufThreshold
 * PURPOSE:
 *      The function is used to get the buffer threshold.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Tm queue handler.
 *      type             -- To get the threshold of port/queue in ingress/egress type.
 * OUTPUT:
 *      ptr_entry        -- the entry which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 *      CLX_E_OP_INVALID -- Operate invalid due to
 *                          1. When FC is not enabled
 *                             or handler is not equal to 7 when FC is enabled by clx_port_setFlowCtrl().
 *                          2. Handler is not set by clx_tm_setPfcMapping() mapping.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getBufThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_THRESHOLD_T              *ptr_entry);

/* FUNCTION NAME: clx_tm_getBufOccupancy
 * PURPOSE:
 *      The function is used to get the buffer usage.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Tm queue handler.
 *      type             -- To get the usage of port/queue in ingress/egress type.
 * OUTPUT:
 *      ptr_entry        -- the usage which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 *      CLX_E_OP_INVALID -- Operate invalid due to
 *                          1. When FC is not enabled
 *                             or handler is not equal to 7 when FC is enabled by clx_port_setFlowCtrl().
 *                          2. Handler is not set by clx_tm_setPfcMapping() mapping.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getBufOccupancy(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_OCCUPANCY_T              *ptr_entry);

/* FUNCTION NAME: clx_tm_getBufWatermark
 * PURPOSE:
 *      The function is used to get the buffer Watermark.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Tm queue handler.
 *      type             -- To get the usage of port/queue in ingress/egress type.
 * OUTPUT:
 *      ptr_entry        -- the Watermark which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 *      CLX_E_OP_INVALID -- Operate invalid due to
 *                          1. When FC is not enabled
 *                             or handler is not equal to 7 when FC is enabled by clx_port_setFlowCtrl().
 *                          2. Handler is not set by clx_tm_setPfcMapping() mapping.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getBufWatermark(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_WATERMARK_T              *ptr_entry);

/* FUNCTION NAME: clx_tm_clearBufWatermark
 * PURPOSE:
 *      The function is used to clear the buffer Watermark.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Tm queue handler.
 *      type             -- To get the usage of port/queue in ingress/egress type.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 *      CLX_E_OP_INVALID -- Operate invalid due to
 *                          1. When FC is not enabled
 *                             or handler is not equal to 7 when FC is enabled by clx_port_setFlowCtrl().
 *                          2. Handler is not set by clx_tm_setPfcMapping() mapping.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_clearBufWatermark(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type);

/* FUNCTION NAME: clx_tm_getBufWatermarkList
 * PURPOSE:
 *      The function is used to get the buffer Watermark from list.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      ptr_handler_list -- Tm queue handler list.
 *      type             -- To get the usage of port/queue in ingress/egress type.
 *      list_cnt         -- List count.
 * OUTPUT:
 *      ptr_entry_list   -- the Watermark list which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 *      CLX_E_OP_INVALID -- Operate invalid due to
 *                          1. When FC is not enabled
 *                             or handler is not equal to 7 when FC is enabled by clx_port_setFlowCtrl().
 *                          2. Handler is not set by clx_tm_setPfcMapping() mapping.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_getBufWatermarkList(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T     type,
    const UI32_T                list_cnt,
    CLX_TM_BUF_WATERMARK_T      *ptr_entry_list);

/* FUNCTION NAME: clx_tm_clearBufWatermarkList
 * PURPOSE:
 *      The function is used to clear the buffer Watermark from list.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      ptr_handler_list -- Tm queue handler list.
 *      type             -- To get the usage of port/queue in ingress/egress type.
 *      list_cnt         -- List count.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 *      CLX_E_OP_INVALID -- Operate invalid due to
 *                       -- 1. When FC is not enabled
 *                       --    or handler is not equal to 7 when FC is enabled by clx_port_setFlowCtrl().
 *                       -- 2. Handler is not set by clx_tm_setPfcMapping() mapping.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_tm_clearBufWatermarkList(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T     type,
    const UI32_T                list_cnt);

/* FUNCTION NAME:   clx_tm_registerBufSnapshotCallback
 * PURPOSE:
 *      This API is used to register a callback function to handle snapshot.
 * INPUT:
 *      unit                --  Device unit number
 *      notify_function     --  Callback function
 *      ptr_cookie          --  Cookie data of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OP_INVALID    --  Operate invalid due to
 *                              1. When FC is not enabled
 *                                 or handler is not equal to 7 when FC is enabled by clx_port_setFlowCtrl().
 *                              2. Handler is not set by clx_tm_setPfcMapping() mapping.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_tm_registerBufSnapshotCallback(
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_FUNC_T        notify_function,
    void                                *ptr_cookie);


/* FUNCTION NAME:   clx_tm_deregisterBufSnapshotCallback
 * PURPOSE:
 *      This API is used to deregister a callback function from callback functions.
 * INPUT:
 *      unit                --  Device unit number
 *      notify_function     --  Callback function
 *      ptr_cookie          --  Cookie data of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_tm_deregisterBufSnapshotCallback(
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_FUNC_T        notify_function,
    void                                *ptr_cookie);

/* FUNCTION NAME: clx_tm_getPauseStatus
 * PURPOSE:
 *      The function is used to get per port/queue pause status.
 * INPUT:
 *      unit                    -- Device unit number
 *      port                    -- Physical port ID
 *      handler                 -- Egress queue handler
 * OUTPUT:
 *      ptr_status              -- The pause status of port or queue
 * RETURN:
 *      CLX_E_OK                -- Operate success.
 *      CLX_E_BAD_PARAMETER     -- Bad parameter.
 * NOTES:
 *      If user wants to get FC status, use CLX_TM_HANDLER_PORT as
 *      handler input. If user wants to get PFC status, specify which
 *      queue(handler) you want. *ptr_status will return 1 if port/queue is in
 *      pause state. *ptr_status will return 0 if port/queue is not in pause state.
 */
CLX_ERROR_NO_T
clx_tm_getPauseStatus(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_status);



/* FUNCTION NAME:   clx_tm_registerPfcWdCallback
 * PURPOSE:
 *      This API is used to register a callback function that will be called
 *      whenever the PFCWD event occur.
 * INPUT:
 *      unit               --  Device unit number
 *      notify_function    --  The callback function of type CLX_TM_PFCWD_HANDLE_FUNC_T
 *      ptr_cookie         --  The cookie data as input parameter of callback function
 *
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T clx_tm_registerPfcWdCallback(
      const UI32_T                         unit,
      const CLX_TM_PFCWD_HANDLE_FUNC_T     notify_function,
      void                                 *ptr_cookie);


/* FUNCTION NAME:   clx_tm_deregisterPfcWdCallback
 * PURPOSE:
 *      This API is used to deregister a callback function which register for PFCWD event before.
 * INPUT:
 *      unit               --  Device unit number
 *      notify_function    --  The callback function of type CLX_TM_PFCWD_HANDLE_FUNC_T
 *      ptr_cookie         --  The cookie data as input parameter of callback function
 *
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T clx_tm_deregisterPfcWdCallback(
      const UI32_T                         unit,
      const CLX_TM_PFCWD_HANDLE_FUNC_T     notify_function,
      void                                 *ptr_cookie);


/* FUNCTION NAME:   clx_tm_setPfcWd
 * PURPOSE:
 *      This API is used to configure PFCWD on queue.
 * INPUT:
 *      unit        --  Device unit number
 *      port        --  physical port ID
 *      handler     --  queue handler.
 *      ptr_entry   --  PFCWD Configuration
 *
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T clx_tm_setPfcWd(
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_ENTRY_T                *ptr_entry);


/* FUNCTION NAME:   clx_tm_getPfcWd
 * PURPOSE:
 *      This API is used to get current configuration of PFCWD.
 * INPUT:
 *      unit        --  Device unit number
 *      port        --  physical port ID
 *      handler     --  Egress queue handler.
 *
 * OUTPUT:
 *      ptr_entry   --  PFCWD Configuration
 *
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T clx_tm_getPfcWd(
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_ENTRY_T                *ptr_entry);

/* FUNCTION NAME:   clx_tm_getPfcWdState
 * PURPOSE:
 *      This API is used to get current state of PFCWD.
 * INPUT:
 *      unit        --  Device unit number
 *      port        --  physical port ID
 *      handler     --  queue handler.
 *
 * OUTPUT:
 *      ptr_state       --  PFCWD Current State
 *
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T clx_tm_getPfcWdState(
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_STATE_T                *ptr_state);

#endif  /* End of CLX_TM_H */

