/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_l3.h
* PURPOSE:
*      It provide L3 module API.
* NOTES:
*
*/
#ifndef CLX_L3_H
#define CLX_L3_H

/* INCLUDE FILE DECLARATIONS
*/
#include <clx_error.h>
#include <clx_types.h>
#include <clx_vlan.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
*/

/* MACRO FUNCTION DECLARATIONS
*/

/* DATA TYPE DECLARATIONS
*/
#define CLX_L3_MCAST_FLAGS_WITH_ID     (1U << 1)    /* Use the specified multicast ID while creating */
#define CLX_L3_SRV_TYPE_FD             (0x10000)    /* Specific forwarding domain */
#define CLX_L3_SRV_TYPE_L3_INTF        (0x20000)    /* Specific L3 interface */

/* L3 URPF Check Mode, per Interface Configurable */
typedef enum
{
    CLX_L3_URPF_CHECK_MODE_DISABLED = 0, /* No URPF check */
    CLX_L3_URPF_CHECK_MODE_STRICT,       /* Strict mode: Ingress interface of packet must
                                          * equal to out interface of search result when
                                          * search source IP in FIB table, check pass, else
                                          * check fail.
                                          */
    CLX_L3_URPF_CHECK_MODE_LOOSE,        /* Loose mode: If find match route when search
                                          * source IP in FIB table, check pass, else check fail.
                                          */
    CLX_L3_URPF_CHECK_MODE_LOOSE_IGNORE_DEFAULT, /* If find match non-default route when
                                                  * search source IP in FIB table, check pass,
                                                  * else check fail.
                                                  */
    CLX_L3_URPF_CHECK_MODE_LAST
} CLX_L3_URPF_CHECK_MODE_T;

/* L3 Multicast RPF Check Fail Action */
typedef enum
{
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_DROP = 0,    /* Drop when multicast RPF check failure */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_SEND2CPU,    /* Send to CPU when multicast RPF check failure */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_L2MC_LOOKUP, /* Fall back to L2 result when multicast RPF check failure */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_NONE,        /* NO multicast RPF check */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_LAST
} CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T;

/* Actions for IP Multicast Lookup Miss, per Interface Configurable */
typedef enum
{
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_DROP = 0,    /* Drop when multicast look up miss */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_SEND2CPU,    /* Send to CPU when multicast look up miss */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_L2MC_LOOKUP, /* Fall back to L2 result when multicast look up miss */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_FORWARD,     /* Forward when multicast look up miss */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_LAST
} CLX_L3_MCAST_LOOKUP_MISS_ACTION_T;

/* IP Multicast Egress Interface Type */
typedef enum
{
    CLX_L3_MCAST_EGR_INTF_TYPE_L3 = 0,  /* For L3 */
    CLX_L3_MCAST_EGR_INTF_TYPE_VM_1BR,  /* For 802.1BR */
    CLX_L3_MCAST_EGR_INTF_TYPE_VM_NIV,  /* For NIV */
    CLX_L3_MCAST_EGR_INTF_TYPE_VM_VEPA, /* For 802.1Qbg VEPA */
    CLX_L3_MCAST_EGR_INTF_TYPE_NV,      /* For Network Virtualization */
    CLX_L3_MCAST_EGR_INTF_TYPE_TRILL,   /* For TRILL */
    CLX_L3_MCAST_EGR_INTF_TYPE_MPLS,    /* For MPLS */
    CLX_L3_MCAST_EGR_INTF_TYPE_LAST
} CLX_L3_MCAST_EGR_INTF_TYPE_T;

/* Output type */
typedef enum
{
    CLX_L3_OUTPUT_TYPE_ADJ = 0,  /* Specify output type is L3 adjacency */
    CLX_L3_OUTPUT_TYPE_ECMP,     /* Specify output type is ECMP */
    CLX_L3_OUTPUT_TYPE_NVO3_ADJ, /* Specify output type is NVO3 */
    CLX_L3_OUTPUT_TYPE_MPLS_LSP, /* Specify output type is MPLS Label Switch Path */
    CLX_L3_OUTPUT_TYPE_MPLS_PW,  /* Specify output type is MPLS Pseudowire */
    CLX_L3_OUTPUT_TYPE_LAST
} CLX_L3_OUTPUT_TYPE_T;

/* IP Network Address */
typedef struct CLX_L3_IP_NETWORK_ADDR_S
{
    CLX_IP_T    ip_addr;                        /* IP address. For default route, set all to zero.*/
    CLX_IP_T    ip_mask;                        /* IP address mask. For default route, set all to zero.*/
    BOOL_T      ipv4;                           /* This IP network address is IPV4 address or not.*/
} CLX_L3_IP_NETWORK_ADDR_T;

/* L3 Interface Information */
typedef struct CLX_L3_INTF_INFO_S
{
    UI32_T                            intf_id;   /* L3 interface ID */
    CLX_MAC_T                         mac;       /* L3 interface MAC address; it will be used as Source MAC
                                                  * when IP packet is egressed from this interface.
                                                  */
    CLX_L3_URPF_CHECK_MODE_T          urpf_mode; /* For detailed information, refer to the enum definition. */
    UI32_T                            vrf_id;    /* Virtual Routing Forwarding ID of L3 interface. */

#define CLX_L3_INTF_FLAGS_IPV4_UC      (1U << 0) /* IPV4 unicast enable in this L3 interface.     */
#define CLX_L3_INTF_FLAGS_IPV6_UC      (1U << 1) /* IPV6 unicast enable in this L3 interface.     */
#define CLX_L3_INTF_FLAGS_IPV4_MC      (1U << 2) /* IPV4 multicast enable in this L3 interface.   */
#define CLX_L3_INTF_FLAGS_IPV6_MC      (1U << 3) /* IPV6 multicast enable in this L3 interface.   */
#define CLX_L3_INTF_FLAGS_NO_MOD_SA    (1U << 4) /* Not modify Source MAC address when packet forwarding from this interface.*/
#define CLX_L3_INTF_FLAGS_NO_MOD_DA    (1U << 5) /* Not modify destination MAC address when packet forwarding from this interface.*/
#define CLX_L3_INTF_FLAGS_NO_MOD_VLAN  (1U << 6) /* Not modify VLAN ID when packet forwarding from this interface.*/
#define CLX_L3_INTF_FLAGS_ICMPV4_REDIR_EN              (1U << 7)  /* ICMPV4 Redirect check enable */
#define CLX_L3_INTF_FLAGS_ICMPV6_REDIR_EN              (1U << 8)  /* ICMPV6 Redirect check enable */
#define CLX_L3_INTF_FLAGS_IPV4_OPTION_HEADER_SW_FWD_EN (1U << 9)  /* IPV4 Packet with option header would trap to CPU to do SW forward */
#define CLX_L3_INTF_FLAGS_IPV6_OPTION_HEADER_SW_FWD_EN (1U << 10) /* IPV6 Packet with option header would trap to CPU to do SW forward */
#define CLX_L3_INTF_FLAGS_WITH_ID                      (1U << 11) /* Use user input intf_id.      */
#define CLX_L3_INTF_FLAGS_IGR_METER_VALID              (1U << 12) /* igr_meter_id is valid        */
#define CLX_L3_INTF_FLAGS_EGR_METER_VALID              (1U << 13) /* egr_meter_id is valid        */
#define CLX_L3_INTF_FLAGS_IGR_CNT_VALID                (1U << 14) /* igr_cnt_id is valid          */
#define CLX_L3_INTF_FLAGS_EGR_CNT_VALID                (1U << 15) /* egr_cnt_id is valid          */
#define CLX_L3_INTF_FLAGS_IGR_DIST_CNT_VALID           (1U << 16) /* igr_dist_cnt_id is valid     */
#define CLX_L3_INTF_FLAGS_EGR_DIST_CNT_VALID           (1U << 17) /* egr_dist_cnt_id is valid     */

    UI32_T                            flags;            /* Refer to CLX_L3_INTF_FLAGS_XX.    */
    UI16_T                            igr_mtu_size;     /* MTU size used by ingress process  */
    UI16_T                            egr_mtu_size;     /* MTU size used by egress process   */
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_T ipv4_lookup_miss_action;  /* L3 multicast look up miss action for IPV4 packet*/
    CLX_L3_MCAST_LOOKUP_MISS_ACTION_T ipv6_lookup_miss_action;  /* L3 multicast look up miss action for IPV6 packet*/
    CLX_FWD_ACTION_T                  igr_mtu_fail_action;  /* Ingress MTU check fail action */
    CLX_FWD_ACTION_T                  egr_mtu_fail_action;  /* Egress MTU check fail action  */
    CLX_FWD_ACTION_T                  urpf_fail_action; /* URPF check fail action */
    UI32_T                            igr_meter_id;     /* Ingress meter ID       */
    UI32_T                            egr_meter_id;     /* Egress meter ID        */
    UI32_T                            igr_cnt_id;       /* Ingress counter ID     */
    UI32_T                            egr_cnt_id;       /* Egress counter ID      */
    UI32_T                            igr_dist_cnt_id;  /* Ingress distribution counter ID */
    UI32_T                            egr_dist_cnt_id;  /* Egress distribution counter ID */
    UI32_T                            igr_group_label;  /* group label for ICIA   */
    UI32_T                            egr_group_label;  /* group label for ECIA   */
} CLX_L3_INTF_INFO_T;

/* IP Host Information */
typedef struct CLX_L3_HOST_INFO_S
{
    CLX_IP_ADDR_T               ip_host_addr;   /* Key: IP address of host entry  */
    UI32_T                      vrf_id;         /* Key: virtual routing forwarding domain ID */
    CLX_L3_OUTPUT_TYPE_T        output_type;    /* Output type not support CLX_L3_OUTPUT_TYPE_NVO3_ADJ */
    UI32_T                      output_id;      /* Adjacency id, ECMP group id, MPLS tunnel or MPLS port */
    UI32_T                      tc;             /* Traffic class remark value     */

#define CLX_L3_HOST_FLAGS_DROP              (1U << 0)    /* Black hole. The output_id field will be invalid. */
#define CLX_L3_HOST_FLAGS_KEEP_TTL          (1U << 1)    /* Not modify TTL        */
#define CLX_L3_HOST_FLAGS_SIP_TC_REMARK     (1U << 2)    /* SIP TC remark         */
#define CLX_L3_HOST_FLAGS_DIP_TC_REMARK     (1U << 3)    /* DIP TC remark         */
#define CLX_L3_HOST_FLAGS_TC_STICKY         (1U << 4)    /* Sticky TC will not be changed by ICIA */
#define CLX_L3_HOST_FLAGS_DST_HIT           (1U << 5)    /* Indicates entry was hit on DIP address */
#define CLX_L3_HOST_FLAGS_SRC_HIT           (1U << 6)    /* Indicates entry was hit on SIP address */
#define CLX_L3_HOST_FLAGS_MPLS_LABEL_EN     (1U << 7)    /* Enable MPLS label     */

    UI32_T                      flags;          /* Refer to CLX_L3_HOST_FLAGS_XX  */
    UI32_T                      group_label;    /* group label for CIA            */
    UI32_T                      mpls_label;     /* MPLS label                     */
} CLX_L3_HOST_INFO_T;

/* Subnet Broadcast Information */
typedef struct CLX_L3_SUBNET_BCAST_INFO_S
{
    CLX_IP_ADDR_T               ip_subnet_addr; /* Key: IP address of Subnet  */
    UI32_T                      vrf_id;         /* Key: virtual routing forwarding domain ID */
    UI32_T                      mcast_id;       /* Mcast ID                   */
    UI32_T                      group_label;    /* group label for CIA        */

#define CLX_L3_SUBNET_BCAST_FLAGS_KEEP_TTL  (1U << 1)    /* Not modify TTL    */

    UI32_T                      flags;          /* Refer to CLX_L3_SUBNET_BCAST_FLAGS_XX */
} CLX_L3_SUBNET_BCAST_INFO_T;

/* IP Route Information */
typedef struct CLX_L3_ROUTE_INFO_S
{
    CLX_L3_IP_NETWORK_ADDR_T    ip_network_addr; /* Key: IP network address       */
    UI32_T                      vrf_id;          /* Key: Virtual routing forwarding domain ID */
    CLX_L3_OUTPUT_TYPE_T        output_type;     /* Output type not support CLX_L3_OUTPUT_TYPE_NVO3_ADJ */
    UI32_T                      output_id;       /* Adjacency id, ECMP group id, MPLS tunnel or MPLS port */
    UI32_T                      tc;              /* Traffic class remark value    */

#define CLX_L3_ROUTE_FLAGS_DROP             (1U << 0)    /* Black hole. The output_id field will be invalid. */
#define CLX_L3_ROUTE_FLAGS_KEEP_TTL         (1U << 1)    /* Not modify TTL        */
#define CLX_L3_ROUTE_FLAGS_SIP_TC_REMARK    (1U << 2)    /* SIP TC remark         */
#define CLX_L3_ROUTE_FLAGS_DIP_TC_REMARK    (1U << 3)    /* DIP TC remark         */
#define CLX_L3_ROUTE_FLAGS_TC_STICKY        (1U << 4)    /* Sticky TC will not be changed by ICIA */
#define CLX_L3_ROUTE_FLAGS_DST_HIT          (1U << 5)    /* Indicates entry was hit on DIP address */
#define CLX_L3_ROUTE_FLAGS_SRC_HIT          (1U << 6)    /* Indicates entry was hit on SIP address */
#define CLX_L3_ROUTE_FLAGS_MPLS_LABEL_EN    (1U << 7)    /* Enable MPLS label     */
#define CLX_L3_ROUTE_FLAGS_GLOBAL_ROUTE     (1U << 8)    /* Configure global route (vrf_id is wildcard) */

    UI32_T                      flags;          /* Refer to CLX_L3_ROUTE_FLAGS_XX */
    UI32_T                      group_label;    /* group label for CIA            */
    UI32_T                      mpls_label;     /* MPLS label                     */
} CLX_L3_ROUTE_INFO_T;

/* ECMP mode type */
typedef enum
{
    CLX_L3_ECMP_MODE_TYPE_HW = 0,   /* Chip uses hardware hash threshold based path
                                     * selection. The incoming packets with different
                                     * packet hash values will be sent to different
                                     * egresses.The default hash mode is HW.
                                     */
    CLX_L3_ECMP_MODE_TYPE_SW,       /* Chip uses software hash threshold based
                                     * path selection. User can specify different
                                     * egresses with different packet hash values of the
                                     * incoming packets (API:clx_l3_setEcmpGrpHashPath).
                                     */
    CLX_L3_ECMP_MODE_TYPE_LAST
} CLX_L3_ECMP_MODE_TYPE_T;

/* ECMP Group SW mode Information */
typedef struct CLX_L3_ECMP_GRP_SW_MODE_INFO_S
{
    UI32_T    sw_hash_val_cnt;      /* 1. Hash entry count in software hash mode.
                                     * 2. User must set this count > 0.
                                     * 3. When delete ECMP path, the corresponding sw_hash_val_cnt
                                     *    in the ECMP group will be subtracted.
                                     * 4. When user update a larger value (API: clx_l3_setEcmpGrp),
                                     *    just add an ECMP path (API: clx_l3_addEcmpGrpPath)
                                     *    and assign hash_values (API: clx_l3_setEcmpGrpHashPath),
                                     *    or user can reconfigure the whole hash_list.
                                     * 5. When user update a smaller value (API: clx_l3_setEcmpGrp),
                                     *    user MUST reconfigure the whole hash_list.
                                     */
} CLX_L3_ECMP_GRP_SW_MODE_INFO_T;

/* ECMP Dynamic Load Balance Configuration */
typedef struct CLX_L3_ECMP_DLB_CFG_S
{
#define CLX_L3_ECMP_DLB_FLAGS_DLB   (1U << 0) /* Whether the Dynamic Load Balance is enabled in
                                               * this ECMP group. For detailed description of
                                               * dynamic load balance, refer to the Dynamic Load
                                               * Balance API Guide.
                                               */
#define CLX_L3_ECMP_DLB_FLAGS_ET    (1U << 1) /* Elephant trap enable */
    UI32_T    flags;                /* Refer to CLX_L3_ECMP_DLB_FLAGS_XX. */
    UI32_T    et_id;                /* Specify elephant trap ID for this ECMP group. */
} CLX_L3_ECMP_DLB_CFG_T;

/* ECMP Hash Configuration */
typedef struct CLX_L3_ECMP_HASH_CFG_S
{
   CLX_L3_ECMP_MODE_TYPE_T  hash_mode;  /* If hash_mode is set to 0 (hardware mode), chip
                                         * uses hardware hash threshold based path
                                         * selection. The incoming packets with different
                                         * packet hash values will be sent to different
                                         * egresses. If hash_mode is set to 1 (software
                                         * mode), chip uses software hash threshold based
                                         * path selection. User can specify different
                                         * egresses with different packet hash values of the
                                         * incoming packets (API: clx_l3_setEcmpGrpHashPath).
                                         * The default hash mode is 0.
                                         */
   CLX_L3_ECMP_GRP_SW_MODE_INFO_T  sw_mode_info; /* Will be ignored when hash_mode is hw. */
} CLX_L3_ECMP_HASH_CFG_T;

/* ECMP Group Configuration */
typedef struct CLX_L3_ECMP_GRP_INFO_S
{
    CLX_L3_OUTPUT_TYPE_T    type;       /* Group type not support CLX_L3_OUTPUT_TYPE_ECMP. */
    UI32_T                  path_cnt;   /* The total ecmp path number currently. This number
                                         * is valid only when user uses clx_l3_getEcmpGrp to
                                         * get ECMP group information.
                                         */
    UI32_T                  weight_cnt; /* The total ecmp group weight currently. This
                                         * number is valid only when user uses clx_l3_getEcmpGrp
                                         * to get ECMP group information.
                                         */
    CLX_L3_ECMP_HASH_CFG_T  hash_cfg;   /* Refer to CLX_L3_ECMP_HASH_CFG_T. */
    CLX_L3_ECMP_DLB_CFG_T   dlb_cfg;    /* Refer to CLX_L3_ECMP_DLB_CFG_T.  */

#define CLX_L3_ECMP_GRP_FLAGS_KEEP_TTL       (1U << 0) /* No modify TTL. */
#define CLX_L3_ECMP_GRP_FLAGS_URPF_STRICT_EN (1U << 1) /* Enable URPF strict mode. */
#define CLX_L3_ECMP_GRP_FLAGS_WECMP_EN       (1U << 2) /* Enable weighted ECMP. */

    UI32_T                  flags;      /* Refer to CLX_L3_ECMP_GRP_FLAGS_XX. */
} CLX_L3_ECMP_GRP_INFO_T;

/* ECMP Path for Hash Value and Next Hop Configuration */
typedef struct CLX_L3_ECMP_PATH_INFO_S
{
    CLX_L3_OUTPUT_TYPE_T    type;               /* Path type not support CLX_L3_OUTPUT_TYPE_ECMP. */
    UI32_T                  output_path_id;     /* L3 adjacency ID, NVO3 adjacency ID or MPLS port. */
    UI32_T                  monitor_id;         /* Rebalance monitor ID which is used by DLB. If it
                                                 * is not set, fill in 0.
                                                 */
    UI32_T                  frr_state_id;       /* L3 only. State id for fast-reroute. */
    UI32_T                  mpls_label;         /* MPLS label */
    UI32_T                  weight;             /* The weight of weighted ECMP path. */

#define CLX_L3_ECMP_PATH_FLAGS_MPLS_LABEL_VALID (1U << 0) /* mpls_label is valid */

    UI32_T                  flags;              /* Refer to CLX_L3_ECMP_PATH_FLAGS_XX. */
} CLX_L3_ECMP_PATH_INFO_T;

/* My Router MAC Information */
typedef struct CLX_L3_ROUTER_MAC_INFO_S
{
    CLX_MAC_T               mac;                /* My MAC address       */
    CLX_MAC_T               mac_mask;           /* Mask of my MAC       */
    UI32_T                  intf_id;            /* Interface ID         */
    UI32_T                  intf_id_mask;       /* Mask of interface ID */
} CLX_L3_ROUTER_MAC_INFO_T;

/* VRF Information */
typedef struct CLX_L3_VRF_INFO_S
{
    CLX_FWD_ACTION_T                  option_header_action;   /* IPV4 packet with option header forward action */
    CLX_FWD_ACTION_T                  lkp_miss_action;        /* Unicast packet lookup miss action */
    CLX_FWD_ACTION_T                  ttl0_action;            /* Packet with ttl =0 forward action */
    CLX_FWD_ACTION_T                  ttl1_action;            /* Packet with ttl =1 forward action */
    UI32_T                            meter_id;               /* Meter ID                   */
    UI32_T                            cnt_id;                 /* Counter ID                 */
    UI32_T                            dist_cnt_id;            /* Distribution counter ID    */
    CLX_METER_COLOR_RESOLVE_TYPE_T    color_resolve_type;     /* Meter color resolve type   */
    UI32_T                            group_label;            /* Group label for CIA        */
    UI32_T                            ipv4_state;             /* ipv4 admin state control   */
    UI32_T                            ipv6_state;             /* ipv6 admin state control   */

#define CLX_L3_VRF_FLAGS_FALL_BACK_EN    (1U << 0)            /* TRUE: Enable fall-back to global route */
#define CLX_L3_VRF_FLAGS_SIP_FAVOR       (1U << 1)            /* TRUE: Source IP hit traffic class has higher
                                                               * precedence than destination IP.<CL>FALSE: Source
                                                               * IP hit traffic class has lower precedence than
                                                               * destination IP.
                                                               */
#define CLX_L3_VRF_FLAGS_METER_VALID     (1U << 2)            /* meter_id is valid          */
#define CLX_L3_VRF_FLAGS_CNT_VALID       (1U << 3)            /* cnt_id is valid            */
#define CLX_L3_VRF_FLAGS_DIST_CNT_VALID  (1U << 4)            /* dist_cnt_id is valid       */
#define CLX_L3_VRF_FLAGS_IPV4_ADMIN_VALID   (1U << 5)         /* ipv4 admin state valid     */
#define CLX_L3_VRF_FLAGS_IPV6_ADMIN_VALID   (1U << 6)         /* ipv6 admin state valid     */

    UI32_T                           flags;                   /* Refer to CLX_L3_VRF_FLAGS_XX */
} CLX_L3_VRF_INFO_T;

/* IP Multicast Group Information */
typedef struct CLX_L3_MCAST_GROUP_INFO_S
{
    UI32_T              vrf_id;                 /* Key: Virtual Routing Forwarding ID*/
    CLX_IP_ADDR_T       src_ip;                 /* Key: Source IP address of L3 multicast group,
                                                 * which needs to be set for (S, G) group. For (, G)
                                                 * group, src_ip.ip_addr must be set to 0, and the
                                                 * IP version must be the same with group IP.
                                                 */
    CLX_IP_ADDR_T       grp_ip;                 /* Key: Multicast group IP address */
    UI32_T              mcast_id;               /* multicast forwarding ID */

#define CLX_L3_MCAST_FLAGS_PIM_BIDIR     (1U << 0) /* Per G entry
                                                    * If set to 1, PIM-BIDIR support,
                                                    * else support PIM-SM
                                                    */
#define CLX_L3_MCAST_FLAGS_DROP          (1U << 1) /* Per (*,G) or (S,G)
                                                    * If set to 1, the packet match this
                                                    * group entry will be dropped.
                                                    */
#define CLX_L3_MCAST_FLAGS_NO_MODIFY_TTL (1U << 2) /* Per (*,G) or (S,G)
                                                    * If set to 1, not modify TTL,
                                                    * else modify TTL.
                                                    */
#define CLX_L3_MCAST_FLAGS_SPT_READY     (1U << 3) /* Per (S,G) group config
                                                    * If set to 1, forward packet from S to G.
                                                    * If user uses PIM-SM protocol, before the
                                                    * Short-Path tree is ready, this flag should set to 0,
                                                    * multicast packet will send to CPU and encapsulated
                                                    * as unicast packet, then, routing to RP. RP will
                                                    * unpack this tunnel packet back to multicast packet
                                                    * and send to host join this group. After Short-Path
                                                    * tree is ready, hardware table entry for multicast
                                                    * packet forwarding is OK, this bit should to set to 1,
                                                    * the multicast packet will not be send to CPU again.
                                                    */
#define CLX_L3_MCAST_FLAGS_HIT           (1U << 4) /* Indicates Multicast group was hit */
#define CLX_L3_MCAST_FLAGS_TO_CPU        (1U << 5) /* Copy to CPU */

    UI32_T              flags;                  /* Refer to CLX_L3_MCAST_FLAGS_XXX */
    CLX_IP_ADDR_T       rp_addr;                /* Rendezvous Point address used in BIDIR-PIM
                                                 * protocol. User can use clx_l3_addMcastDfIntf to
                                                 * add the RP address to the DF state for one
                                                 * interface.
                                                 */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T    mrpf_check_fail_action;    /* If multicast reverse path
                                                                        * forwarding check is
                                                                        * failed, multicast packet
                                                                        * will do action by the
                                                                        * setting of this field.
                                                                        */
    UI32_T              rpf_intf_id;            /* Interface ID used by RPF check.
                                                 * If CLX_L3_MCAST_FLAGS_PIM_BIDIR flag is set to 1,
                                                 * the RPF check will fail when the ingress interface
                                                 * is not included in the DF interface of this group.
                                                 * If CLX_L3_MCAST_FLAGS_PIM_BIDIR flag is set to 0,
                                                 * the RPF check will fail when the ingress interface
                                                 * is not equal to rpf_intf_id.
                                                 */
    UI32_T              group_label;            /* Group label for CIA */
} CLX_L3_MCAST_GROUP_INFO_T;

/* IP Multicast Egress Interface Setting For NV */
typedef struct CLX_L3_MCAST_EGR_INTF_NV_S
{
    CLX_TUNNEL_KEY_T        tunnel_key;             /* MC Tunnel */
    CLX_PORT_T              port;                   /* UC Tunnel */
    UI32_T                  nvo3_adj_id;            /* For tunnel encapsulation */
} CLX_L3_MCAST_EGR_INTF_NV_T;

/* IP Multicast Egress Interface Setting For TRILL */
typedef struct CLX_L3_MCAST_EGR_INTF_TRILL_S
{
    CLX_TRILL_NICKNAME_T    egr_nickname;           /* Egress nickname */
    UI32_T                  nvo3_adj_id;            /* For tunnel encapsulation */
} CLX_L3_MCAST_EGR_INTF_TRILL_T;

/* IP Multicast Egress Interface Setting For MPLS */
typedef struct CLX_L3_MCAST_EGR_INTF_MPLS_S
{
    UI32_T                  mpls_label;             /* MPLS label */
    CLX_PORT_T              port;                   /* Tunnel port */
    UI32_T                  nvo3_adj_id;            /* For tunnel encapsulation */

#define CLX_L3_MCAST_EGR_MPLS_FLAGS_LABEL   (1U << 0) /* MPLS label valid flag */
#define CLX_L3_MCAST_EGR_MPLS_FLAGS_TUNNEL  (1U << 1) /* Tunnel port valid flag */

    UI32_T                  flags;                  /* Refer to CLX_L3_MCAST_EGR_MPLS_FLAGS_XX. */
} CLX_L3_MCAST_EGR_INTF_MPLS_T;

/* IP Multicast Egress Interface Setting */
typedef struct CLX_L3_MCAST_EGR_INTF_S
{
    CLX_L3_MCAST_EGR_INTF_TYPE_T        intf_type;   /* Multicast egress interface type */
    UI32_T                              intf_id;     /* L3 egress interface ID */
    CLX_VLAN_ACTION_T                   vlan_action; /* VLAN action */
    CLX_VLAN_T                          svid;        /* Service VLAN ID */
    CLX_VLAN_T                          cvid;        /* Customer VLAN ID */
    CLX_MAC_T                           dmac;        /* Destination MAC */
    union
    {
        UI32_T                          vm_id;       /* VM ID */
        CLX_L3_MCAST_EGR_INTF_NV_T      nv;          /* Setting For NV */
        CLX_L3_MCAST_EGR_INTF_TRILL_T   trill;       /* Setting For TRILL */
        CLX_L3_MCAST_EGR_INTF_MPLS_T    mpls;        /* Setting For MPLS */
    };

#define CLX_L3_MCAST_EGR_FLAGS_SVID_VALID   (1U << 0) /* Indicate if svid is applied to packet */
#define CLX_L3_MCAST_EGR_FLAGS_CVID_VALID   (1U << 1) /* Indicate if cvid is applied to packet */
#define CLX_L3_MCAST_EGR_FLAGS_KEEP_DMAC    (1U << 2) /* No modify Destination MAC */
#define CLX_L3_MCAST_EGR_FLAGS_KEEP_SMAC    (1U << 3) /* No modify Source MAC */
#define CLX_L3_MCAST_EGR_FLAGS_KEEP_TTL     (1U << 4) /* No modify TTL */

    UI32_T                              flags;      /* Refer to CLX_L3_MCAST_EGR_FLAGS_XX. */
} CLX_L3_MCAST_EGR_INTF_T;

/* BFD Global Configure Information */
typedef struct CLX_L3_BFD_INFO_S
{
    UI32_T    s_hop_port;                   /* BFD single hop UDP destination port  */
    UI32_T    m_hop_port;                   /* BFD multi hop UDP destination port   */
    UI32_T    echo_port;                    /* BFD echo UDP destination port        */

#define CLX_L3_BFD_FLAGS_ICMPV4_REDIR_EN     (1U << 0)  /* ICMPv4 redirect enabled flag */
#define CLX_L3_BFD_FLAGS_ICMPV6_REDIR_EN     (1U << 1)  /* ICMPv6 redirect enabled flag */
#define CLX_L3_BFD_FLAGS_CHECK_EN            (1U << 2)  /* BFD globally enabled flag */
#define CLX_L3_BFD_FLAGS_BYPASS_SOURCE_CHECK (1U << 3)  /* BFD echo bypass source check. If this flag is
                                                         * false, BFD echo packet may be dropped due to
                                                         * source check in IP safe guard, URPF, or
                                                         * icmp-redirect process.
                                                         */

    UI32_T    flags;                        /* Refer to CLX_L3_BFD_FLAGS_XX. */
} CLX_L3_BFD_INFO_T;

/* Adjacency type */
typedef enum CLX_L3_ADJ_TYPE_E
{
    CLX_L3_ADJ_TYPE_L3 = 0,   /* l3 adjacency */
    CLX_L3_ADJ_TYPE_NVO3,     /* nvo3 adjacency */
    CLX_L3_ADJ_TYPE_LAST
} CLX_L3_ADJ_TYPE_T;

/* Adjacency Information */
typedef struct CLX_L3_ADJ_INFO_S
{
    CLX_L3_ADJ_TYPE_T           adj_type;           /* Adjacency type */
    CLX_MAC_T                   dst_mac;            /* Destination MAC */
    UI32_T                      intf_id;            /* Egress interface ID. L3 only */
    CLX_MAC_T                   src_mac;            /* nvo3 only */
    CLX_VLAN_T                  svid;               /* Service VLAN ID */
    CLX_VLAN_T                  cvid;               /* Customer VLAN ID */

#define CLX_L3_ADJ_FLAGS_SVID_VALID     (1U << 0)    /* Indicate if svid is applied to packet */
#define CLX_L3_ADJ_FLAGS_CVID_VALID     (1U << 1)    /* Indicate if cvid is applied to packet */
#define CLX_L3_ADJ_FLAGS_DST_MAC_VALID  (1U << 2)    /* Indicate if dst_mac is applied to packet */
#define CLX_L3_ADJ_FLAGS_KEEP_SA        (1U << 3)    /* Keep source MAC address when packet forwarding from this adjacency. */
#define CLX_L3_ADJ_FLAGS_KEEP_VLAN      (1U << 4)    /* Keep VLAN when packet forwarding from this adjacency.
                                                      * For nvo3 adjacency it indicates the inner vlan modification.
                                                      */
#define CLX_L3_ADJ_FLAGS_FRR_EN         (1U << 5)    /* L3 only. Enable the fast-reroute on this adjacency. */
#define CLX_L3_ADJ_FLAGS_WITH_ID        (1U << 6)    /* L3: Set adjacency with the input *ptr_adj_id.
                                                      * nvo3: Add or Set adjacency with the input *ptr_adj_id.
                                                      */
#define CLX_L3_ADJ_FLAGS_KEEP_TTL       (1U << 7)    /* No modify TTL. */
#define CLX_L3_ADJ_FLAGS_URPF_STRICT_EN (1U << 8)    /* Enable URPF strict mode on this adjacency. */
#define CLX_L3_ADJ_FLAGS_DROP           (1U << 9)    /* Black hole. The port field will be invalid.
                                                      * Only support L3 unicast Host or Route.
                                                      * Not support FRR, ECMP and nvo3.
                                                      */
#define CLX_L3_ADJ_FLAGS_SEG_ID_VALID   (1U << 10)   /* indicate if seg_id is applied to packet when configuring adjacency,
                                                      * not applied to clx_l3_getAdj */

    UI32_T                      flags;              /* Refer to CLX_L3_ADJ_FLAGS_XX. */
    CLX_PORT_T                  port;               /* Destination Interface Object id. */
    UI16_T                      s_tpid;             /* nvo3 only */
    UI16_T                      c_tpid;             /* nvo3 only */
    UI16_T                      mtu_size;           /* nvo3 only */
    UI32_T                      frr_backup_path;    /* L3 only. Backup adjacency for fast-reroute. */
    UI32_T                      frr_state_id;       /* L3 only. State id for fast-reroute. */
    UI32_T                      seg_id;             /* Segment id */
} CLX_L3_ADJ_INFO_T;

/* L3 Packet with Option Header Action Configuration */
typedef struct CLX_L3_OPTION_HEADER_INFO_S
{
    CLX_FWD_ACTION_T            ipv4_action;    /* Action of IPV4 Packet with option header */
    CLX_FWD_ACTION_T            ipv6_action;    /* Action of IPV6 Packet with option header */
} CLX_L3_OPTION_HEADER_INFO_T;

/* IP Multicast PIM-register Setting */
typedef struct CLX_L3_PIM_REG_INFO_S
{
    UI32_T                      vrf_id;      /* key: Virtual Routing Forwarding ID */
    CLX_L3_IP_NETWORK_ADDR_T    src_ip;      /* key: IP subnet */
    UI32_T                      rpf_intf_id; /* Interface ID used for RPF check. */
    UI32_T                      mcast_id;    /* multicast forwarding ID */
    CLX_L3_MCAST_RPF_CHECK_FAIL_ACTION_T    mrpf_check_fail_action;    /* If multicast rpf check failed,
                                                                        * packet will do action by the
                                                                        * setting of this field.
                                                                        */

#define CLX_L3_PIM_REG_INFO_FLAGS_TO_CPU  (1U << 0)  /* If enable this bit, mcast_id will be ignore */

    UI32_T                      flags;       /* Refer to CLX_L3_PIM_REG_INFO_FLAGS_XX. */
} CLX_L3_PIM_REG_INFO_T;

/* -------------------------------------------------------------- Traverse Callbacks */
typedef CLX_ERROR_NO_T
(*CLX_L3_ADJ_TRAVERSE_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        adj_id,
    const CLX_L3_ADJ_INFO_T             *ptr_adj_info,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3_INTF_TRAVERSE_FUNC_T)(
    const UI32_T                        unit,
    const CLX_BRIDGE_DOMAIN_T           bdid,
    const CLX_L3_INTF_INFO_T            *ptr_intf_info,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T)(
    const UI32_T                        unit,
    const UI32_T                        ecmp_grp_id,
    const CLX_L3_ECMP_GRP_INFO_T        *ptr_ecmp_grp_info,
    const CLX_L3_ECMP_PATH_INFO_T       *ptr_ecmp_path_info,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3_HOST_TRAVERSE_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_HOST_INFO_T            *ptr_host_info,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3_ROUTE_TRAVERSE_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_ROUTE_INFO_T           *ptr_route_info,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3_MCAST_GROUP_INFO_T     *ptr_group_info,
    void                                *ptr_cookie);

/* FUNCTION NAME:     clx_l3_addIntf
 * PURPOSE:
 *      This API is used to add the interface based on Bridge Domain ID.<CL>
 *      User should specify the Bridge Domain ID and the interface configuration.
 * INPUT:
 *        unit              -- Device unit number
 *        bdid              -- Bridge Domain ID
 *        ptr_l3_intf       -- The Interface information
 * OUTPUT:
 *        ptr_l3_intf->intf_id
 * RETURN:
 *        CLX_E_OK               --  Operate success.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter.
 *        CLX_E_TABLE_FULL       --  Hardware table is full, entry can't be added.
 *        CLX_E_NO_MEMORY        --  No available memory
 * NOTES:
 *  While create L3 interface for router-only L2 interface, user do not need to specify a BDID.
 *  While create L3 interface for both bridging and routing L2 interface, user needs to create bridge
 *  domain by this BDID firstly, otherwise, interface cannot work correctly.
 *  User only needs to fill in VRF ID and MAC if a VLAN based interface is created.
 *  If this L3 Interface is existed, this API may change the configure of Interface.
 */
CLX_ERROR_NO_T
clx_l3_addIntf(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    CLX_L3_INTF_INFO_T              *ptr_l3_intf);

/* FUNCTION NAME:     clx_l3_delIntf
 * PURPOSE:
 *      This API is used to delete the interface based on Bridge Domain ID.
 * INPUT:
 *        unit            --  Device unit number
 *        srv_id          --  Service ID, specific bridge domain ID or L3 interface ID
 *                            The service type can be specified by CLX_L3_SRV_TYPE_XX, otherwise,
 *                            srv_id is regarded as the bridge domain ID
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK               --  Operate success.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter.
 *        CLX_E_NO_MEMORY        --  No available memory
 *        CLX_E_ENTRY_NOT_FOUND  --  The specified interface has not been created
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_l3_delIntf(
    const UI32_T                    unit,
    const UI32_T                    srv_id);

/* FUNCTION NAME:     clx_l3_getIntf
 * PURPOSE:
 *      This API is used to get interface information according to specified Bridge Domain ID.
 * INPUT:
 *        unit            --  Device unit number
 *        srv_id          --  Service ID, specific bridge domain ID or L3 interface ID
 *                            The service type can be specified by CLX_L3_SRV_TYPE_XX, otherwise,
 *                            srv_id is regarded as the bridge domain ID
 * OUTPUT:
 *        ptr_l3_intf     --  Interface property, including MAC, VRF ID, MTU, URPF check mode and etc
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_NO_MEMORY         --  No available memory
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified interface has not been created
 * NOTES:
 *   This API is used get the interface property according to the specified service ID.
 *   While specify the service ID is BDID, the L3 interface binded with the BDID will be retrieved.
 *   User must create interface first. If the IP network address bound to this interface cannot be
 *   obtained, user needs to use clx_l3_getHost and clx_l3_getRoute to get the host and route entry
 *   added.
 */
CLX_ERROR_NO_T
clx_l3_getIntf(
    const UI32_T                    unit,
    const UI32_T                    srv_id,
    CLX_L3_INTF_INFO_T              *ptr_l3_intf);

/* FUNCTION NAME:     clx_l3_traverseIntf
 * PURPOSE:
 *        This API is used to get all Interfaces.
 * INPUT:
 *        unit                 -- Device unit number
 *        callback             -- Callback function provided by user, user can do self
 *                                action to every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3_traverseIntf(
    const UI32_T                        unit,
    const CLX_L3_INTF_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);

/* FUNCTION NAME:     clx_l3_addMyRouterMac
 * PURPOSE:
 *       This API is used to add my router MAC address and interface to my router MAC table.<CL>
 *       User should specify the entry index, interface ID and my MAC address.
 * INPUT:
 *        unit             --  Device unit number
 *        index            --  Hardware access index
 *        ptr_router_mac_info  --  myRouterMAC information including MAC/MAC mask and ifidx/ifidx mask
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK               --  Operate success.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter.
 *        CLX_E_TABLE_FULL       --  Hardware table is full, entry can't be added.
 *        CLX_E_NO_MEMORY        --  No available memory
 * NOTES:
 *    User needs to specify the index of MyRouterMAC
 *    table and the data of entry, including the interface ID, MAC address, and the mask of them.<CL>
 *    MyRouterMAC table is used to judge the incoming packet whether need to send to L3 unicast packet
 *    flow. Unicast IP routing can be enabled on per port or per forwarding domain basis. <CL>
 *    When packet arrives, ingress L3 interface will be derived. If IPv4/IPv6 routing is enabled,
 *    the ingress L3 interface together with the Layer 2 destination MAC address are used to lookup
 *    the MyRouterMAC table, if the ingress interface ID and destination MAC address of incoming packet
 *    can't match, packet will not go to L3 unicast packet flow.<CL>
 *    User can set mask bit to 0 in order to multiplex one entry by multiple interface ID and MAC address.
 */
CLX_ERROR_NO_T
clx_l3_addMyRouterMac(
    const UI32_T                    unit,
    const UI32_T                    index,
    const CLX_L3_ROUTER_MAC_INFO_T  *ptr_router_mac_info);

/* FUNCTION NAME:     clx_l3_delMyRouterMac
 * PURPOSE:
 *       This API is used to delete my router MAC address and interface to my router MAC table.<CL>
 *       User should specify the entry index.
 * INPUT:
 *        unit             --  Device unit number
 *        index            --  Hardware access index
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_NO_MEMORY         --  No available memory
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified interface has not been created
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3_delMyRouterMac(
    const UI32_T                    unit,
    const UI32_T                    index);

/* FUNCTION NAME:     clx_l3_getMyRouterMac
 * PURPOSE:
 *        Get my router MAC information in my router MAC table.
 * INPUT:
 *        unit             --  Device unit number
 *        index            --  Hardware access index
 * OUTPUT:
 *        ptr_router_mac_info  --  myRouterMAC information, MAC/MAC mask and ifidx/ifidx mask
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified interface has not been created
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3_getMyRouterMac(
    const UI32_T                    unit,
    const UI32_T                    index,
    CLX_L3_ROUTER_MAC_INFO_T        *ptr_router_mac_info);

/* FUNCTION NAME:   clx_l3_addAdj
 * PURPOSE:
 *        This API is used to add/set an adjacency.
 * INPUT:
 *        unit           --  Device unit number
 *        *ptr_adj_info  --  Adjacency information
 * OUTPUT:
 *        *ptr_adj_id    --  Adjacency ID
 * RETURN:
 *        CLX_E_OK            --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *    This API is used to add/set an adjacency for a host, route or ecmp group.
 *    If the ptr_adj_info->flags & CLX_L3_ADJ_FLAGS_WITH_ID is 0, means add a new adjacency,
 *    and the *ptr_adj_id will be the returned value. Otherwise, set an existing adjacency,
 *    and the *ptr_adj_id will be the inputted value.
 *    If this adjacency is used by host, route, or ecmp group, the packet will be
 *    affected when the adjacency is set.
 */
CLX_ERROR_NO_T
clx_l3_addAdj(
    const UI32_T                unit,
    const CLX_L3_ADJ_INFO_T     *ptr_adj_info,
    UI32_T                      *ptr_adj_id);

/* FUNCTION NAME:   clx_l3_delAdj
 * PURPOSE:
 *        This API is used to delete an adjacency.
 * INPUT:
 *        unit       -- Device unit number
 *        type       -- Adjacency type.
 *        adj_id     -- Adjacency ID
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK            --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_l3_delAdj(
    const UI32_T                unit,
    const CLX_L3_ADJ_TYPE_T     type,
    const UI32_T                adj_id);

/* FUNCTION NAME:   clx_l3_getAdj
 * PURPOSE:
 *        This API is used to get the Adjacency information
 * INPUT:
 *        unit       -- Device unit number
 *        adj_id     -- Adjacency ID
 * OUTPUT:
 *        *ptr_adj_info   -- Adjacency information
 * RETURN:
 *        CLX_E_OK            --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None.
 */
CLX_ERROR_NO_T
clx_l3_getAdj(
    const UI32_T                unit,
    const UI32_T                adj_id,
    CLX_L3_ADJ_INFO_T           *ptr_adj_info);

/* FUNCTION NAME:     clx_l3_traverseAdj
 * PURPOSE:
 *        This API is used to get all Adjacencies.
 * INPUT:
 *        unit                 -- Device unit number
 *        type                 -- Adjacency type.
 *        callback             -- Callback function provided by user, user can do self
 *                                action to every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3_traverseAdj(
    const UI32_T                        unit,
    const CLX_L3_ADJ_TYPE_T             type,
    const CLX_L3_ADJ_TRAVERSE_FUNC_T    callback,
    void                                *ptr_cookie);

/* FUNCTION NAME:     clx_l3_addHost
 * PURPOSE:
 *        This API is used to add an l3 host entry.
 * INPUT:
 *        unit            --  Device unit number
 *        ptr_host_info   --  L3 host information, including IP address, VRF ID, Destination MAC, the output path ID,
 *                            egress interface and etc.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK             --  Operate success.
 *        CLX_E_BAD_PARAMETER  --  Bad parameter.
 *        CLX_E_TABLE_FULL     --  Hardware table is full, entry can't be added.
 *        CLX_E_NO_MEMORY      --  No available memory
 * NOTES:
 *  The detailed information of L3 host entry refers to structure of CLX_L3_HOST_INFO_T.<CL>
 *  Key of entry is IP address and VRF ID.<CL>
 *  For packets which are attached to the Host lookup L3 host to find adjacency and egress
 *  interface information, the lookup process uses the whole destination IP address in the
 *  packet and the VRF ID assigned to packet's ingress interface. If a matched entry is found,
 *  the egress interface will be used for delivery.<CL>
 *  If the host entry exists, this API will change the attribute of entry. The key of entry cannot be changed.<CL>
 *  NV and VM modules can also call this API to add the host entry.
 */
CLX_ERROR_NO_T
clx_l3_addHost(
    const UI32_T                    unit,
    const CLX_L3_HOST_INFO_T        *ptr_host_info);

/* FUNCTION NAME:     clx_l3_delHost
 * PURPOSE:
 *        This API is used to delete an l3 host entry.
 * INPUT:
 *        unit            --  Device unit number
 *        ptr_host_info   --  L3 host information, including IP address, VRF ID, Destination MAC, the output path ID,
 *                            egress interface and etc.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified host entry has not been created
 * NOTES:
 *    User only needs to fill the IP address and VRF ID into ptr_host_info. <CL>
 *    NV and VM modules can also call this API to delete the host entry.
 */
CLX_ERROR_NO_T
clx_l3_delHost(
    const UI32_T                   unit,
    const CLX_L3_HOST_INFO_T       *ptr_host_info);

/* FUNCTION NAME:     clx_l3_getHost
 * PURPOSE:
 *        This API is used to get an L3 host entry.
 * INPUT:
 *        unit           -- Device unit number
 *        ptr_host_info  -- Only need L3 host's key: IP address and VRF ID.
 * OUTPUT:
 *        ptr_host_info  -- L3 host information, including IP address, VRF ID, Destination MAC, the output path ID,
 *                          egress interface and etc.
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified host entry has not been created
 * NOTES:
 *    User only needs to fill IP address and VRF ID into ptr_host_info.<CL>
 *    NV and VM modules can also call this API to get the host entry.
 */
CLX_ERROR_NO_T
clx_l3_getHost(
    const UI32_T                   unit,
    CLX_L3_HOST_INFO_T             *ptr_host_info);

/* FUNCTION NAME:     clx_l3_traverseHost
 * PURPOSE:
 *        This API is used to get all host entries.
 * INPUT:
 *        unit                 -- Device unit number
 *        callback             -- Callback function user provided by user, user can do self
 *                                action for every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *    NV and VM modules can also call this API to traverse all host entries.
 *
 */
CLX_ERROR_NO_T
clx_l3_traverseHost(
    const UI32_T                        unit,
    const CLX_L3_HOST_TRAVERSE_FUNC_T   callback,
    void                                *ptr_cookie);

/* FUNCTION NAME:     clx_l3_addSubnetBcast
 * PURPOSE:
 *        This API is used to add an L3 Subnet Broadcast entry.
 * INPUT:
 *        unit                -- Device unit number
 *        ptr_subnet_info     -- Subnet Broadcast information, including subnet address, VRF ID,
 *                               mcast ID and etc.<CL>
 *                               Key is the subnet address and VRF ID.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK               --  Operate success.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter.
 *        CLX_E_TABLE_FULL       --  Hardware table is full, the entry can not be added.
 *        CLX_E_NO_MEMORY        --  No available memory
 * NOTES:
 *     IP subnet address and VRF ID need to be filled into ptr_subnet_info.
 */
CLX_ERROR_NO_T
clx_l3_addSubnetBcast(
    const UI32_T                        unit,
    const CLX_L3_SUBNET_BCAST_INFO_T    *ptr_subnet_info);

/* FUNCTION NAME:     clx_l3_delSubnetBcast
 * PURPOSE:
 *        This API is used to delete an L3 Route entry.
 * INPUT:
 *        unit                -- Device unit number
 *        ptr_subnet_info     -- Subnet Broadcast information, IP subnet address and VRF ID must be input.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_NO_MEMORY         --  No available memory
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified route entry has not been created
 * NOTES:
 *  The detailed information of route refers to structure of CLX_L3_SUBNET_BCAST_INFO_T.<CL>
 *  If the route entry exists, some attributes of this entry will be changed.<CL>
 *  The key of entry cannot be changed.
 */
CLX_ERROR_NO_T
clx_l3_delSubnetBcast(
    const UI32_T                        unit,
    const CLX_L3_SUBNET_BCAST_INFO_T    *ptr_subnet_info);

/* FUNCTION NAME:     clx_l3_getSubnetBcast
 * PURPOSE:
 *      This API is used to get an L3 Subnet Broadcast entry.
 * INPUT:
 *        unit                -- Device unit number
 *        ptr_subnet_info     -- Subnet Broadcast information, only including key: IP subnet address, VRF ID
 * OUTPUT:
 *        ptr_subnet_info     -- Subnet Broadcast information, including IP subnet address, VRF ID,
 *                               the output path ID and so on.
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified route entry has not been created
 * NOTES:
 *  User only needs to fill in IP subnet address and VRF ID.
 */
CLX_ERROR_NO_T
clx_l3_getSubnetBcast(
    const UI32_T                        unit,
    CLX_L3_SUBNET_BCAST_INFO_T          *ptr_subnet_info);

/* FUNCTION NAME:     clx_l3_addRoute
 * PURPOSE:
 *        This API is used to add an L3 Route entry.
 * INPUT:
 *        unit                -- Device unit number
 *        ptr_route_info      -- Route information, including network address, VRF ID,
 *                               the output path ID and etc. <CL>
 *                               Key is the network address and VRF ID.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK               --  Operate success.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter.
 *        CLX_E_TABLE_FULL       --  Hardware table is full, the entry can not be added.
 *        CLX_E_NO_MEMORY        --  No available memory
 * NOTES:
 *  The detailed information of route refers to structure of CLX_L3_ROUTE_INFO_T.<CL>
 *  If the route entry exists, some attributes of this entry will be changed.<CL>
 *  The key of entry cannot be changed.
 */
CLX_ERROR_NO_T
clx_l3_addRoute(
    const UI32_T                    unit,
    const CLX_L3_ROUTE_INFO_T       *ptr_route_info);

/* FUNCTION NAME:     clx_l3_delRoute
 * PURPOSE:
 *        This API is used to delete an L3 Route entry.
 * INPUT:
 *        unit                -- Device unit number
 *        ptr_route_info      -- Route information, IP network address and VRF ID must be input.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_NO_MEMORY         --  No available memory
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified route entry has not been created
 * NOTES:
 *        IP network address and VRF ID need to be filled into ptr_route_info.
 */
CLX_ERROR_NO_T
clx_l3_delRoute(
    const UI32_T                    unit,
    const CLX_L3_ROUTE_INFO_T       *ptr_route_info);

/* FUNCTION NAME:     clx_l3_delRouteAll
 * PURPOSE:
 *        This API is used to delete all L3 Route entries.
 * INPUT:
 *        unit                      -- Device unit number
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                  --  Operate success.
 *        CLX_E_BAD_PARAMETER       --  Bad parameter.
 *        CLX_E_NO_MEMORY           --  No available memory.
 * NOTES:
 *       This function can be called before changing URPF check configuration or FIB long prefix capacity.
 */
CLX_ERROR_NO_T
clx_l3_delRouteAll(
    const UI32_T                    unit);

/* FUNCTION NAME:     clx_l3_getRoute
 * PURPOSE:
 *      This API is used to get an L3 Route entry.
 * INPUT:
 *        unit                -- Device unit number
 *        ptr_route_info      -- The route information, only including key: IP network address, VRF ID
 * OUTPUT:
 *        ptr_route_info      -- The route information, including IP network address, VRF ID,
 *                               the output path ID and so on. <CL>
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified route entry has not been created
 * NOTES:
 *        User only needs to fill in IP network address and VRF ID.
 */
CLX_ERROR_NO_T
clx_l3_getRoute(
    const UI32_T                    unit,
    CLX_L3_ROUTE_INFO_T             *ptr_route_info);

/* FUNCTION NAME:     clx_l3_traverseRoute
 * PURPOSE:
 *         This API is used to get all Route entries.
 * INPUT:
 *        unit                 -- Device unit number
 *        callback             -- Callback function provided by user, user can do self
 *                                action to every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3_traverseRoute(
    const UI32_T                        unit,
    const CLX_L3_ROUTE_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

/* FUNCTION NAME:     clx_l3_createEcmpGrp
 * PURPOSE:
 *      This API is used to create an ECMP route Group.<CL>
 *      User should specify the configuration of the ECMP route group.
 *      The group ID will be output.
 * INPUT:
 *        unit                        -- Device unit number
 *        ptr_ecmp_grp_info           -- ECMP group information including
 *                                       hash mode, SW hash value count,
 *                                       and DLB flag
 * OUTPUT:
 *        ptr_ecmp_grp_id             -- ECMP group ID allocated
 * RETURN:
 *        CLX_E_OK               --  Operate success.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter.
 *        CLX_E_TABLE_FULL       --  Hardware table is full, entry can't be added.
 *        CLX_E_NO_MEMORY        --  No available memory
 * NOTES:
 *  Equal-cost multi-path (ECMP) is a routing technique for routing packets along
 *  multiple paths of equal cost. The forwarding engine identifies paths by adjacency.
 *  When forwarding a packet, the router must decide which adjacency to use. For
 *  detailed information of ECMP group, refer to CLX_L3_ECMP_GRP_INFO_T.<CL>
 *  User can set the property of ECMP route group when creating the ECMP group or use
 *  API clx_l3_setEcmpGrp to modify property of ECMP group at a later time.<CL>
 *  In order to add the ECMP route, user can follow the steps below:<CL>
 *    1) Create ECMP route group with API: clx_l3_createEcmpGrp. Group index will be
 *       allocated and returned to user.<CL>
 *    2) Set the property of ECMP route group with API: clx_l3_setEcmpGrp.<CL>
 *    3) Add one or multiple ECMP paths to this ECMP group with API:  clx_l3_addEcmpGrpPath.<CL>
 *    4) Add one ECMP route using this ECMP group with API: clx_l3_addRoute.
 */
CLX_ERROR_NO_T
clx_l3_createEcmpGrp(
    const UI32_T                    unit,
    const CLX_L3_ECMP_GRP_INFO_T    *ptr_ecmp_grp_info,
    UI32_T                          *ptr_ecmp_grp_id);

/* FUNCTION NAME:     clx_l3_setEcmpGrp
 * PURPOSE:
 *      This API is used to set the property of the ECMP route Group.<CL>
 *      User should specify the configuration of the ECMP route group changed. The group
 *      ID must be input.
 * INPUT:
 *        unit                        -- Device unit number
 *        ecmp_grp_id                 -- Specify group ID to be set
 *        ptr_ecmp_grp_info           -- ECMP group information, including
 *                                       hash mode, SW hash value count,
 *                                       DLB flag and IPV4 flag
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK             --  Operate success.
 *        CLX_E_BAD_PARAMETER  --  Bad parameter.
 *        CLX_E_NO_MEMORY      --  No available memory
 * NOTES:
 *     Allow to change normal HW mode to SW mode, and vice versa.<CL>
 *     Not allow the followings:<CL>
 *        - normal HW mode <-> weighted HW/SW mode<CL>
 *        - normal SW mode <-> weighted HW/SW mode<CL>
 *        - weighted HW mode <-> weighted SW mode<CL>
 *     For detailed information of ECMP group, refer to CLX_L3_ECMP_GRP_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3_setEcmpGrp(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_GRP_INFO_T    *ptr_ecmp_grp_info);

/* FUNCTION NAME:     clx_l3_delEcmpGrp
 * PURPOSE:
 *      This API is used to delete an ECMP route group.<CL>
 *      User should specify the group ID of the ECMP route group.
 * INPUT:
 *        unit                    -- Device unit number
 *        type                    -- ECMP group type.
 *        ecmp_grp_id             -- Specify group ID to be deleted
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_NO_MEMORY         --  No available memory
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified ECMP group entry has not been created
 * NOTES:
 *
 *   This API is used to delete an ECMP group entry. All ECMP paths and ECMP hash paths will be deleted.<CL>
 *   If an ECMP route uses this deleted ECMP group, this route will be invalid.<CL>
 *   User needs to delete this route and add this route again with the new adjacency information.
 */
CLX_ERROR_NO_T
clx_l3_delEcmpGrp(
    const UI32_T                    unit,
    const CLX_L3_OUTPUT_TYPE_T      type,
    const UI32_T                    ecmp_grp_id);

/* FUNCTION NAME:     clx_l3_getEcmpGrp
 * PURPOSE:
 *      This API is used to get ECMP route group information.<CL>
 *      User should specify the group ID of the ECMP route group.
 * INPUT:
 *        unit                        -- Device unit number
 *        ecmp_grp_id                 -- Specify group ID to be obtained
 * OUTPUT:
 *        ptr_ecmp_grp_info           -- ECMP group information, including
 *                                       hash mode, SW hash value count,
 *                                       DLB flag and IPV4 flag.
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified host entry has not been created
 * NOTES:
 *   For detailed information of the ECMP group, refer to CLX_L3_ECMP_GRP_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3_getEcmpGrp(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    CLX_L3_ECMP_GRP_INFO_T          *ptr_ecmp_grp_info);

/* FUNCTION NAME:     clx_l3_traverseEcmpGrp
 * PURPOSE:
 *        This API is used to get all ECMP groups.
 * INPUT:
 *        unit                 -- Device unit number
 *        type                 -- ECMP group type.
 *        callback             -- Callback function provided by user, user can do self
 *                                action to every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3_traverseEcmpGrp(
    const UI32_T                            unit,
    const CLX_L3_OUTPUT_TYPE_T              type,
    const CLX_L3_ECMP_GRP_TRAVERSE_FUNC_T   callback,
    void                                    *ptr_cookie);

/* FUNCTION NAME:     clx_l3_syncEcmpGrp
 * PURPOSE:
 *        This API is used to sync two ecmp group member.
 * INPUT:
 *        unit                 -- Device unit number
 *        ori_grp_id           -- original ECMP group.
 *        new_grp_id           -- current ECMP group.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *        Now only support hw mode ecmp without weight and L3 type.
 *
 */
CLX_ERROR_NO_T
clx_l3_syncEcmpGrp(
    const UI32_T                            unit,
    const UI32_T                            ori_grp_id,
    const UI32_T                            new_grp_id);

/* FUNCTION NAME:     clx_l3_addEcmpGrpPath
 * PURPOSE:
 *      This API is used to add an ECMP path to an ECMP route group.<CL>
 *      User should specify the group ID of the ECMP route group and the ECMP path information.
 * INPUT:
 *        unit                     -- Device unit number
 *        ecmp_grp_id              -- Specify ECMP group ID
 *        ptr_ecmp_path_info       -- It includes output path ID, VRF ID, destination MAC, etc.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK             --  Operate success.
 *        CLX_E_BAD_PARAMETER  --  Bad parameter.
 *        CLX_E_TABLE_FULL     --  Hardware table is full, entry can not be added.
 *        CLX_E_NO_MEMORY      --  No available memory
 * NOTES:
 *   For detailed information of the ECMP path, refer to CLX_L3_ECMP_PATH_INFO_T.<CL>
 *   User can add multiple ECMP paths to one ECMP group.<CL>
 */
CLX_ERROR_NO_T
clx_l3_addEcmpGrpPath(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info);

/* FUNCTION NAME:     clx_l3_delEcmpGrpPath
 * PURPOSE:
 *      This API is used to delete an ECMP path to an ECMP route group.<CL>
 *      User should specify the group ID of the ECMP route group and the ECMP path information.
 *      User should not delete all paths from a group if the group is used by others.
 * INPUT:
 *        unit                -- Device unit number
 *        ecmp_grp_id         -- Specify group ID
 *        ptr_ecmp_path_info  -- ECMP path to be deleted,
 *                               including output path ID, VRF ID, destination MAC, etc.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_NO_MEMORY         --  No available memory
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified ECMP group entry or ECMP path has not been created
 * NOTES:
 *    For detailed information of the ECMP path, refer to CLX_L3_ECMP_PATH_INFO_T.
 *
 */
CLX_ERROR_NO_T
clx_l3_delEcmpGrpPath(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const CLX_L3_ECMP_PATH_INFO_T   *ptr_ecmp_path_info);

/* FUNCTION NAME:     clx_l3_getEcmpGrpPathByIdx
 * PURPOSE:
 *      This API is used to get an ECMP path from an ECMP route group according to index.<CL>
 *      User should specify the group ID of the ECMP route group and the ECMP path
 *      index. The ECMP path information will be output.
 * INPUT:
 *        unit                    -- Device unit number
 *        ecmp_grp_id             -- Specify group ID
 *        path_idx                -- ECMP path index
 * OUTPUT:
 *        ptr_ecmp_path_info      -- ECMP path information for path index,
 *                                   including output path IP, VRF ID, destination MAC, etc.
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified ECMP group entry or
 *                                    ECMP path entry has not been created
 * NOTES:
 *
 *    Detail information of the ECMP path refers to CLX_L3_ECMP_PATH_INFO_T.<CL>
 *    User can get the total path number by API: clx_l3_getEcmpGrp; the path_cnt in structure
 *    CLX_L3_ECMP_GRP_INFO_T is the total path number. Path index starts from 0 to path number-1.<CL>
 *    The ECMP path is sorted by the order by which user adds the ECMP path. The new ECMP path is
 *    always the last in the order. If user deletes an ECMP path, the ECMP path belonging to the same
 *    ECMP group will be re-sorted.
 */
CLX_ERROR_NO_T
clx_l3_getEcmpGrpPathByIdx(
    const UI32_T                    unit,
    const UI32_T                    ecmp_grp_id,
    const UI32_T                    path_idx,
    CLX_L3_ECMP_PATH_INFO_T         *ptr_ecmp_path_info);

/* FUNCTION NAME:     clx_l3_setEcmpGrpHashPath
 * PURPOSE:
 *      This API is used to set the hash value for an ECMP path.<CL>
 *      User should specify the ECMP route group ID, the hash value and the ECMP path information.
 * INPUT:
 *        unit                     --  Device unit number
 *        ecmp_grp_id              --  Specify ECMP group ID
 *        ptr_hash_val_list        --  hash value (list) needed for configuration, share same ECMP path
 *        hash_val_cnt             --  hash value count needed for configuration
 *        ptr_ecmp_path_info       --  ECMP path information, including output path ID, VRF ID, destination MAC, etc.
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified ECMP group or ECMP path entry has not been created
 * NOTES:
 *   For detailed information of the ECMP path, refer to CLX_L3_ECMP_PATH_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3_setEcmpGrpHashPath(
    const UI32_T                     unit,
    const UI32_T                     ecmp_grp_id,
    const UI32_T                     *ptr_hash_val_list,
    const UI32_T                     hash_val_cnt,
    const CLX_L3_ECMP_PATH_INFO_T    *ptr_ecmp_path_info);

/* FUNCTION NAME:     clx_l3_getEcmpGrpHashPath
 * PURPOSE:
 *      This API is used to get the hash value of an ECMP path.<CL>
 *      User should specify the ECMP route group ID and the ECMP path information.<CL>
 *      The hash value list will be output.
 * INPUT:
 *        unit                  -- Device unit number
 *        ecmp_grp_id           -- ECMP group ID
 *        hash_val_cnt          -- Count of specified hash value
 *        ptr_ecmp_path_info    -- ECMP path information, including output path ID, VRF ID, destination MAC, etc.
 * OUTPUT:
 *       ptr_hash_val_list         -- Hash value array: the array unit number is the value of
 *                                    ptr_actual_hash_val_cnt.
 *       ptr_actual_hash_val_cnt   -- Actual ECMP hash value count
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified ECMP group or ECMP path entry has not been created
 * NOTES:
 *  For detailed information of the ECMP path, refer to CLX_L3_ECMP_PATH_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3_getEcmpGrpHashPath(
    const UI32_T                     unit,
    const UI32_T                     ecmp_grp_id,
    const UI32_T                     hash_val_cnt,
    const CLX_L3_ECMP_PATH_INFO_T    *ptr_ecmp_path_info,
    UI32_T                           *ptr_hash_val_list,
    UI32_T                           *ptr_actual_hash_val_cnt);

/* FUNCTION NAME:     clx_l3_setPktHandlingByVrf
 * PURPOSE:
 *        This API is used to set the packet handling action on a Virtual Routing Forwarding.<CL>
 *        User should specify the VRF ID and the packet handling action.
 * INPUT:
 *        unit               -- Device unit number
 *        vrf_id             -- Virtual Routing Forwarding ID
 *        ptr_pkt_handling   -- Packet handling configuration
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified VRF has not been created
 * NOTES:
 *     For detailed packet handling configuration, refer to CLX_L3_VRF_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3_setPktHandlingByVrf(
    const UI32_T                     unit,
    const UI32_T                     vrf_id,
    const CLX_L3_VRF_INFO_T          *ptr_pkt_handling);

/* FUNCTION NAME:     clx_l3_getPktHandlingByVrf
 * PURPOSE:
 *        This API is used to get the packet handling action on a Virtual Routing Forwarding.<CL>
 *        User should specify the VRF ID. The packet handling action will be output.
 * INPUT:
 *        unit          -- Device unit number
 *        vrf_id        -- Virtual Routing Forwarding ID
 * OUTPUT:
 *        ptr_pkt_handling  -- Packet handling configuration
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified VRF has not been created.
 * NOTES:
 *     For detailed packet handling configuration, refer to CLX_L3_VRF_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3_getPktHandlingByVrf(
    const UI32_T                    unit,
    const UI32_T                    vrf_id,
    CLX_L3_VRF_INFO_T               *ptr_pkt_handling);

/* FUNCTION NAME:   clx_l3_addMcastId
 * PURPOSE:
 *   This API is used to allocate a multicast forwarding ID.
 * INPUT:
 *   unit              --  Device unit number
 *   flags             --  The L3 multicast flags, refer to CLX_L3_MCAST_FLAGS_XXX
 * OUTPUT:
 *   ptr_mcast_id      --  The allocated multicast forwarding ID
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 *   CLX_E_TABLE_FULL    --  No more memory for the entry.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_l3_addMcastId(
    const UI32_T        unit,
    const UI32_T        flags,
    UI32_T              *ptr_mcast_id);

/* FUNCTION NAME:   clx_l3_delMcastId
 * PURPOSE:
 *   This API is used to release a multicast forwarding ID.
 * INPUT:
 *   unit          --  Device unit number
 *   mcast_id      --  The multicast forwarding ID
 * OUTPUT:
 *   None.
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_l3_delMcastId(
    const UI32_T        unit,
    const UI32_T        mcast_id);

/* FUNCTION NAME:   clx_l3_getMcastId
 * PURPOSE:
 *   This API is used to get the rough info on a multicast forwarding ID.
 * INPUT:
 *   unit              --  Device unit number
 *   mcast_id          --  The multicast forwarding ID
 * OUTPUT:
 *   ptr_flags         --  The L3 multicast flags, refer to CLX_L3_MCAST_FLAGS_XXX
 *   port_bitmap       --  The egress port bitmap. If a bit is set to 1, the
 *                         corresponding port is the member port.
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 *   CLX_E_ENTRY_NOT_FOUND --  The multicast forwarding ID is not used.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_l3_getMcastId(
    const UI32_T        unit,
    const UI32_T        mcast_id,
    UI32_T              *ptr_flags,
    CLX_PORT_BITMAP_T   port_bitmap);

/* FUNCTION NAME:   clx_l3_addMcastGroup
 * PURPOSE:
 *   This API is used to add an IP multicast group.
 * INPUT:
 *   unit              --  Device unit number
 *   ptr_group_info    --  The multicast group information
 * OUTPUT:
 *   None
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 *   CLX_E_TABLE_FULL    --  No more memory for the entry.
 * NOTES:
 *   The VRF ID, multicast group IP address must be set for adding (*.G) group, the source IP address
 * also needs to be set for adding (S,G) group. If the multicast group exists, update the group property.<CL>
 * For other group property, refer to the description of CLX_L3_MCAST_GROUP_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3_addMcastGroup(
    const UI32_T                        unit,
    const CLX_L3_MCAST_GROUP_INFO_T     *ptr_group_info);

/* FUNCTION NAME:   clx_l3_delMcastGroup
 * PURPOSE:
 *    This API is used to delete an IP multicast group.
 * INPUT:
 *    unit                    --  Device unit number
 *    ptr_group_info   --  The multicast group information
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK --  Operate success.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND -- No entry is found.
 * NOTES:
 *    Only need to fill VRF ID and multicast group IP address in  ptr_group_info
 *    for deleting (*,G) group. <CL>
 *    The source IP address is also needed for deleting (S,G) group.
 */
CLX_ERROR_NO_T
clx_l3_delMcastGroup(
    const UI32_T                        unit,
    const CLX_L3_MCAST_GROUP_INFO_T     *ptr_group_info);

/* FUNCTION NAME:   clx_l3_getMcastGroup
 * PURPOSE:
 *   This API is used to get an IP multicast group information.
 * INPUT:
 *   unit            --  Device unit number
 *   ptr_group_info  --  The multicast group information. Only need to
 *                       fill VRF ID and multicast group IP address for
 *                       (*,G) group. The source IP address also need for (S,G) group.
 * OUTPUT:
 *   ptr_group_info   -- Other multicast data information
 * RETURN:
 *   CLX_E_OK              --  Operate success.
 *   CLX_E_BAD_PARAMETER   --  Bad parameter.
 *   CLX_E_ENTRY_NOT_FOUND --  No entry is found.
 * NOTES:
 *   For detailed group information, refer to description of CLX_L3_MCAST_GROUP_INFO_T.
 *
 */
CLX_ERROR_NO_T
clx_l3_getMcastGroup(
    const UI32_T                        unit,
    CLX_L3_MCAST_GROUP_INFO_T           *ptr_group_info);

/* FUNCTION NAME:   clx_l3_addMcastEgrIntfByPort
 * PURPOSE:
 *   This API is used to add the egress interface of an IP multicast group in an egress port.
 * INPUT:
 *   unit             --  Device unit number
 *   mcast_id         --  The multicast forwarding ID
 *   port_id          --  The egress port ID
 *   egr_intf_cnt     --  The egress interface count
 *   ptr_egr_intf     --  The egress interface information
 * OUTPUT:
 *   None
 * RETURN:
 *   CLX_E_OK --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 *   CLX_E_TABLE_FULL -- No more memory for the entry.
 * NOTES:
 *   If the egress port is the CPU port, the egress interface count must be 0.
 */
CLX_ERROR_NO_T
clx_l3_addMcastEgrIntfByPort(
    const UI32_T                     unit,
    const UI32_T                     mcast_id,
    const UI32_T                     port_id,
    const UI32_T                     egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T    *ptr_egr_intf);

/* FUNCTION NAME:   clx_l3_delMcastEgrIntfByPort
 * PURPOSE:
 *   This API is used to delete the egress interface of an IP multicast group in an egress port.
 * INPUT:
 *   unit            --  Device unit number
 *   mcast_id        --  The multicast forwarding ID
 *   port_id         --  The egress port ID
 *   egr_intf_cnt    --  The egress interface count
 *   ptr_egr_intf    --  The egress interface information
 * OUTPUT:
 *   None
 * RETURN:
 *   CLX_E_OK               --  Operate success.
 *   CLX_E_BAD_PARAMETER    --  Bad parameter.
 *   CLX_E_ENTRY_NOT_FOUND  --  No entry is found.
 * NOTES:
 *   If the egress port is the CPU port, the egress interface count must be 0.
 */
CLX_ERROR_NO_T
clx_l3_delMcastEgrIntfByPort(
    const UI32_T                     unit,
    const UI32_T                     mcast_id,
    const UI32_T                     port_id,
    const UI32_T                     egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T    *ptr_egr_intf);

/* FUNCTION NAME:   clx_l3_setMcastEgrIntfByPort
 * PURPOSE:
 *   This API is used to replace the whole egress interface list  on a port for a multicast forwarding ID.
 * INPUT:
 *   unit            --  Device unit number
 *   mcast_id        --  The multicast forwarding ID
 *   port_id         --  The egress port ID
 *   egr_intf_cnt    --  The egress interface count
 *   ptr_egr_intf    --  The egress interface information
 * OUTPUT:
 *   None
 * RETURN:
 *   CLX_E_OK               --  Operate success.
 *   CLX_E_BAD_PARAMETER    --  Bad parameter.
 *   CLX_E_ENTRY_NOT_FOUND  --  No entry is found.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_l3_setMcastEgrIntfByPort(
    const UI32_T                     unit,
    const UI32_T                     mcast_id,
    const UI32_T                     port_id,
    const UI32_T                     egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T    *ptr_egr_intf);

/* FUNCTION NAME:   clx_l3_getMcastEgrIntfCntByPort
 * PURPOSE:
 *   This API is used to get the egress interface number of an IP multicast group in an egress port.
 * INPUT:
 *   unit                --  Device unit number
 *   mcast_id            --  The multicast forwarding ID
 *   port_id             --  The egress port ID
 * OUTPUT:
 *   ptr_egr_intf_cnt    -- The egress interface count of the egress port
 * RETURN:
 *   CLX_E_OK                       --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *  This API is used to get egress interface number of an egress port of IP
 *  multicast group. One L3 multicast group can have multiple egress ports,
 *  and one egress port can be sent out from multiple egress interfaces.
 *  Therefore, user needs to use this API to get the interface number per port,
 *  and then use the API "clx_l3_getMcastEgrIntfCntByPort"  to get all egress
 *  interfaces listed in this port.<CL>
 */
CLX_ERROR_NO_T
clx_l3_getMcastEgrIntfCntByPort(
    const UI32_T                      unit,
    const UI32_T                      mcast_id,
    const UI32_T                      port_id,
    UI32_T                            *ptr_egr_intf_cnt);

/* FUNCTION NAME:   clx_l3_getMcastEgrIntfByPort
 * PURPOSE:
 *   This API is used to get all egress interfaces of an IP multicast group in an egress port.
 * INPUT:
 *   unit           --  Device unit number
 *   mcast_id       --  The multicast forwarding ID
 *   port_id        --  The egress port ID
 *   egr_intf_cnt   --  The egress interface count of the egress port
 * OUTPUT:
 *   ptr_egr_intf            -- The egress interface information
 *   ptr_actual_egr_intf_cnt -- The actual egress interface count
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_l3_getMcastEgrIntfByPort(
    const UI32_T                      unit,
    const UI32_T                      mcast_id,
    const UI32_T                      port_id,
    const UI32_T                      egr_intf_cnt,
    CLX_L3_MCAST_EGR_INTF_T           *ptr_egr_intf,
    UI32_T                            *ptr_actual_egr_intf_cnt);

/* FUNCTION NAME:   clx_l3_addMcastDfIntf
 * PURPOSE:
 *   This API is used to add a specific interface as the DF interface for a multicast group.
 * INPUT:
 *   unit         -- Device unit number
 *   intf_id      -- The logical interface ID
 *   ptr_rp_addr  -- The RP IP address
 * OUTPUT:
 *   None
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *  This API is used to add a specific interface as the DF interface
 *  for a multicast group. This API is only used before a multicast group
 *  is set to BIDIR-PIM mode. Otherwise, it will return fail when set/add the multicast group.
 *  The ptr_rp_addr is set in one multicast group.
 */
CLX_ERROR_NO_T
clx_l3_addMcastDfIntf(
    const UI32_T                unit,
    const UI32_T                intf_id,
    const CLX_IP_ADDR_T         *ptr_rp_addr);

/* FUNCTION NAME:   clx_l3_delMcastDfIntf
 * PURPOSE:
 *   This API is used to delete a specific interface as the DF interface for a multicast group.
 * INPUT:
 *   unit        -- Device unit number
 *   intf_id     -- The logical interface ID
 *   ptr_rp_addr -- The RP IP address
 * OUTPUT:
 *   None
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *  This API is only used  for PIM-BIDIR mode.
 */
CLX_ERROR_NO_T
clx_l3_delMcastDfIntf(
    const UI32_T                unit,
    const UI32_T                intf_id,
    const CLX_IP_ADDR_T         *ptr_rp_addr);

/* FUNCTION NAME:   clx_l3_getMcastDfIntf
 * PURPOSE:
 *   This API is used to get the RP IP address list if the specified interface is a DF interface.
 * INPUT:
 *   unit        --  Device unit number
 *   intf_id     -- The logical interface ID
 *   rp_addr_cnt -- The RP IP address count t0 be obtained by user
 * OUTPUT:
 *   ptr_actual_rp_addr_cnt -- The actual RP IP address count
 *   ptr_rp_addr            -- The RP IP address
 * RETURN:
 *   CLX_E_OK            --  Operate success.
 *   CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *   This API is only used  for PIM-BIDIR mode.
 */
CLX_ERROR_NO_T
clx_l3_getMcastDfIntf(
    const UI32_T                unit,
    const UI32_T                intf_id,
    const UI32_T                rp_addr_cnt,
    UI32_T                      *ptr_actual_rp_addr_cnt,
    CLX_IP_ADDR_T               *ptr_rp_addr);

/* FUNCTION NAME:     clx_l3_traverseMcastGroup
 * PURPOSE:
 *        This API is used to get all group entries.
 * INPUT:
 *        unit                 -- Device unit number
 *        callback             -- Callback function user provided by user, user can do self
 *                                action for every node data in this callback function.
 *        ptr_cookie           -- User cookie data as input parameter of callback function
 * OUTPUT:
 *        ptr_cookie           -- User cookie data as output parameter of callback function
 * RETURN:
 *        CLX_E_OK --  Operate success.
 *        CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
clx_l3_traverseMcastGroup(
    const UI32_T                                unit,
    const CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T    callback,
    void                                        *ptr_cookie);

/* FUNCTION NAME: clx_l3_setBfdInfo
 * PURPOSE:
 *      This API is used to set the configuration of Bidirectional Forwarding Detection.
 * INPUT:
 *      unit          -- Device unit number
 *      ptr_bfd_info  -- Refer to CLX_L3_BFD_INFO_T
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  operate success.
 *      CLX_E_BAD_PARAMETER --  bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_l3_setBfdInfo(
    const UI32_T                unit,
    const CLX_L3_BFD_INFO_T     *ptr_bfd_info);

/* FUNCTION NAME: clx_l3_getBfdInfo
 * PURPOSE:
 *      This API is used to get the configuration of Bidirectional Forwarding Detection.
 * INPUT:
 *      unit  -- Device unit number
 * OUTPUT:
 *      ptr_bfd_info  -- Refer to CLX_L3_BFD_INFO_T
 * RETURN:
 *      CLX_E_OK --  operate success.
 *      CLX_E_BAD_PARAMETER --  bad parameter.
 * NOTES:
 *  User can enable/disable BFD, or set the UDP port of BFD control packet
 *  and echo packet. User also can use this API to set whether bypass
 *  source check for BFD echo packet.
 */
CLX_ERROR_NO_T
clx_l3_getBfdInfo(
    const UI32_T                unit,
    CLX_L3_BFD_INFO_T           *ptr_bfd_info);

/* FUNCTION NAME: clx_l3_setBfdCheckFailAction
 * PURPOSE:
 *      This API is used to set "BFD control packet check fail" action per port.
 * INPUT:
 *      unit  -- Device unit number
 *      port_id  -- Port ID
 *      action  -- Refer to CLX_FWD_ACTION_T
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  operate success.
 *      CLX_E_BAD_PARAMETER --  bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_l3_setBfdCheckFailAction(
    const UI32_T                unit,
    const UI32_T                port_id,
    const CLX_FWD_ACTION_T      action);

/* FUNCTION NAME: clx_l3_getBfdCheckFailAction
 * PURPOSE:
 *      This API is used to get "BFD control packet check fail" action per port.
 * INPUT:
 *      unit  -- Device unit number
 *      port_id  -- Port ID
 * OUTPUT:
 *      ptr_action  -- Refer to CLX_FWD_ACTION_T
 * RETURN:
 *      CLX_E_OK --  operate success.
 *      CLX_E_BAD_PARAMETER --  bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_l3_getBfdCheckFailAction(
    const UI32_T                unit,
    const UI32_T                port_id,
    CLX_FWD_ACTION_T            *ptr_action);

/* FUNCTION NAME: clx_l3_setOptionHeaderAction
 * PURPOSE:
 *      This API is used to set the action for the packet with option header.
 * INPUT:
 *      unit  -- Device unit number.
 *      action  -- Refer to CLX_FWD_ACTION_T.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK --  operate success.
 *      CLX_E_BAD_PARAMETER --  bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_l3_setOptionHeaderAction(
    const UI32_T                        unit,
    const CLX_L3_OPTION_HEADER_INFO_T   action);

/* FUNCTION NAME: clx_l3_getOptionHeaderAction
 * PURPOSE:
 *      This API is used to get the action for the packet with option header.
 * INPUT:
 *      unit  -- Device unit number.
 * OUTPUT:
 *      ptr_action  -- Refer to CLX_FWD_ACTION_T.
 * RETURN:
 *      CLX_E_OK --  operate success.
 *      CLX_E_BAD_PARAMETER --  bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
clx_l3_getOptionHeaderAction(
    const UI32_T                        unit,
    CLX_L3_OPTION_HEADER_INFO_T         *ptr_action);

/* FUNCTION NAME:   clx_l3_createFrrStateId
 * PURPOSE:
 *       This API is used to create a state_id for Fast Re-Route. This ID
 *       can be used in CLX_L3_ECMP_PATH_INFO_T or CLX_L3_ADJ_INFO_T.
 * INPUT:
 *       unit           -- Device unit number
 *       type           -- Egress type. Only support ADJ & NVO3_ADJ
 * OUTPUT:
 *       ptr_state_id   -- State ID
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *       None
 *
 */
CLX_ERROR_NO_T
clx_l3_createFrrStateId(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    UI32_T                              *ptr_state_id);

/* FUNCTION NAME:   clx_l3_destroyFrrStateId
 * PURPOSE:
 *       This API is used to destroy a state ID.
 * INPUT:
 *       unit           -- Device unit number
 *       type           -- Egress type. Only support ADJ & NVO3_ADJ
 *       state_id       -- State ID for Fast Re-Route
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *       None
 *
 */
CLX_ERROR_NO_T
clx_l3_destroyFrrStateId(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id);

/* FUNCTION NAME:   clx_l3_setFrrState
 * PURPOSE:
 *       This API is used to set the linkup status for a specific state ID.
 *       The status of the state_id can imply the status of a specific port or
 *       path.
 * INPUT:
 *       unit           -- Device unit number
 *       type           -- Egress type
 *       state_id       -- State ID for Fast Re-Route
 *       link_up        -- The linkup status for this state_id
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *       None
 *
 */
CLX_ERROR_NO_T
clx_l3_setFrrState(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id,
    const BOOL_T                        link_up);

/* FUNCTION NAME:   clx_l3_getFrrState
 * PURPOSE:
 *       This API is used to get the linkup status for a specific state ID.
 * INPUT:
 *       unit           -- Device unit number
 *       type           -- Egress type
 *       state_id       -- State ID for the Fast Re-Route
 * OUTPUT:
 *       ptr_link_up    -- The setting status for the state_id
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *       None
 *
 */
CLX_ERROR_NO_T
clx_l3_getFrrState(
    const UI32_T                        unit,
    const CLX_L3_OUTPUT_TYPE_T          type,
    const UI32_T                        state_id,
    BOOL_T                              *ptr_link_up);

/* FUNCTION NAME:   clx_l3_addSrcForPimReg
 * PURPOSE:
 *       This API is used to add a IP subnet for PIM register.
 * INPUT:
 *       unit           -- Device unit number
 *       *ptr_info      -- The information for pim register
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *       PIM register packet could forward to a specific multicast-id or to CPU.
 *       Multicast-id and CPU cannot be set to the same IP subnet.
 */
CLX_ERROR_NO_T
clx_l3_addSrcForPimReg(
    const UI32_T                    unit,
    const CLX_L3_PIM_REG_INFO_T     *ptr_info);

/* FUNCTION NAME:   clx_l3_delSrcForPimReg
 * PURPOSE:
 *       This API is used to delete a IP subnet for PIM register.
 * INPUT:
 *       unit           -- Device unit number
 *       *ptr_info      -- The information for pim register, only need the keys: vrf_id and src_ip.
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
clx_l3_delSrcForPimReg(
    const UI32_T                    unit,
    const CLX_L3_PIM_REG_INFO_T     *ptr_info);

/* FUNCTION NAME:   clx_l3_getSrcForPimReg
 * PURPOSE:
 *       This API is used to get PIM register information by a specific VRF and IP subnet.
 * INPUT:
 *       unit           -- Device unit number
 *       *ptr_info      -- The information for pim register, only need the keys: vrf_id and src_ip.
 * OUTPUT:
 *       *ptr_info      -- The information for pim register
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
clx_l3_getSrcForPimReg(
    const UI32_T                    unit,
    CLX_L3_PIM_REG_INFO_T           *ptr_info);

/* FUNCTION NAME:   clx_l3_addVrrp
 * PURPOSE:
 *       This API is used to add a VRRP entry.
 * INPUT:
 *       unit           -- Device unit number
 *       vrid           -- Virtual router identifier (VRID)
 *       bdid           -- Bridge Domain ID
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK            --  Operate success.
 *       CLX_E_BAD_PARAMETER --  Bad parameter.
 *       CLX_E_TABLE_FULL    --  Table full.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
clx_l3_addVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

/* FUNCTION NAME:   clx_l3_delVrrp
 * PURPOSE:
 *       This API is used to delete a VRRP entry.
 * INPUT:
 *       unit           -- Device unit number
 *       vrid           -- Virtual router identifier (VRID)
 *       bdid           -- Bridge Domain ID
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
clx_l3_delVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

/* FUNCTION NAME:   clx_l3_getVrrp
 * PURPOSE:
 *       This API is used to check VRRP entry exist or not.
 * INPUT:
 *       unit           -- Device unit number
 *       vrid           -- Virtual router identifier (VRID)
 *       bdid           -- Bridge Domain ID
 * OUTPUT:
 *       None
 * RETURN:
 *       CLX_E_OK               --  Operate success.
 *       CLX_E_BAD_PARAMETER    --  Bad parameter.
 *       CLX_E_ENTRY_NOT_FOUND  --  Entry not found.
 * NOTES:
 *       None
 */
CLX_ERROR_NO_T
clx_l3_getVrrp(
    const UI32_T                unit,
    const UI32_T                vrid,
    const CLX_BRIDGE_DOMAIN_T   bdid);

/* FUNCTION NAME:   clx_l3_addFdlEcmpGroup
 * PURPOSE:
 *      This API is used to enable FDL for the ECMP group.
 * INPUT:
 *      unit            -- Device unit number
 *      ecmp_grp_id     -- ECMP group ID
 *      ptr_fdl_info    -- property of FDL
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3_addFdlEcmpGroup(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    const CLX_FDL_INFO_T        *ptr_fdl_info);

/* FUNCTION NAME:   clx_l3_delFdlEcmpGroup
 * PURPOSE:
 *      This API is used to disable FDL for the ECMP group.
 * INPUT:
 *      unit            -- Device unit number
 *      ecmp_grp_id     -- ECMP group ID
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3_delFdlEcmpGroup(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id);

/* FUNCTION NAME:   clx_l3_getFdlEcmpGroup
 * PURPOSE:
 *      This API is used to get the property of FDL for the ECMP group.
 * INPUT:
 *      unit            -- Device unit number
 *      ecmp_grp_id     -- ECMP group ID
 * OUTPUT:
 *      ptr_fdl_info    -- property of FDL
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3_getFdlEcmpGroup(
    const UI32_T                unit,
    const UI32_T                ecmp_grp_id,
    CLX_FDL_INFO_T              *ptr_fdl_info);

/* FUNCTION NAME:     clx_l3_addBulkRoute
 * PURPOSE:
 *        This API is used to add bulk L3 Route entries.
 * INPUT:
 *        unit                -- Device unit number
 *        mode                -- Bulk Mode
 *        route_cnt           -- Route number
 *        ptr_route_info_list -- Route information array, including network address, VRF ID,
 *                               the output path ID and etc. <CL>
 *                               Key is the network address and VRF ID.
 * OUTPUT:
 *        ptr_rc_list         -- Pointer of a return code array
 * RETURN:
 *        CLX_E_OK               --  Operate success.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter.
 *        CLX_E_TABLE_FULL       --  Hardware table is full, the entry can not be added.
 *        CLX_E_NO_MEMORY        --  No available memory
 * NOTES:
 *  The detailed information of route refers to structure of CLX_L3_ROUTE_INFO_T.<CL>
 *  If the route entry exists, some attributes of this entry will be changed.<CL>
 *  The key of entry cannot be changed.
 */
CLX_ERROR_NO_T
clx_l3_addBulkRoute(
    const UI32_T                    unit,
    const CLX_BULK_OP_MODE_T        mode,
    const UI32_T                    route_cnt,
    const CLX_L3_ROUTE_INFO_T       *ptr_route_info_list,
    CLX_ERROR_NO_T                  *ptr_rc_list);

/* FUNCTION NAME:     clx_l3_delBulkRoute
 * PURPOSE:
 *        This API is used to delete bulk L3 Route entries.
 * INPUT:
 *        unit                -- Device unit number
 *        mode                -- Bulk Mode
 *        route_cnt           -- Route number
 *        ptr_route_info_list -- Route information array, IP network address and VRF ID must be input.
 * OUTPUT:
 *        ptr_rc_list         -- Pointer of a return code array
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_NO_MEMORY         --  No available memory
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified route entry has not been created
 * NOTES:
 *        IP network address and VRF ID need to be filled into ptr_route_info.
 */
CLX_ERROR_NO_T
clx_l3_delBulkRoute(
    const UI32_T                    unit,
    const CLX_BULK_OP_MODE_T        mode,
    const UI32_T                    route_cnt,
    const CLX_L3_ROUTE_INFO_T       *ptr_route_info_list,
    CLX_ERROR_NO_T                  *ptr_rc_list);

/* FUNCTION NAME:     clx_l3_getBulkRoute
 * PURPOSE:
 *      This API is used to get bulk L3 Route entries.
 * INPUT:
 *        unit                -- Device unit number
 *        mode                -- Bulk Mode
 *        route_cnt           -- Route number
 *        ptr_route_info_list -- Route information array, only including key: IP network address, VRF ID
 * OUTPUT:
 *        ptr_route_info_list -- Route information array, including IP network address, VRF ID,
 *                               the output path ID and so on.
 *        ptr_rc_list         -- Pointer of a return code array
 * RETURN:
 *        CLX_E_OK                --  Operate success.
 *        CLX_E_BAD_PARAMETER     --  Bad parameter.
 *        CLX_E_ENTRY_NOT_FOUND   --  The specified route entry has not been created
 * NOTES:
 *        User only needs to fill in IP network address and VRF ID.
 */
CLX_ERROR_NO_T
clx_l3_getBulkRoute(
    const UI32_T                    unit,
    const CLX_BULK_OP_MODE_T        mode,
    const UI32_T                    route_cnt,
    CLX_L3_ROUTE_INFO_T             *ptr_route_info_list,
    CLX_ERROR_NO_T                  *ptr_rc_list);

#endif
