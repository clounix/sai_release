/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_trill.h
 * PURPOSE:
 *      It provides TRILL module API.
 *
 * NOTES:
 *
 */


#ifndef CLX_TRILL_H
#define CLX_TRILL_H


/* INCLUDE FILE DECLARTIONS
 */
#include <clx_port.h>
#include <clx_types.h>
#include <clx_error.h>
#include <clx_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_TRILL_PORT_WITH_ID       (1U << 0)
#define CLX_TRILL_VIRTUAL_RB_WITH_ID (1U << 0)

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct CLX_TRILL_PKT_HANDLING_S
{
    CLX_FWD_ACTION_T    multi_dst_bit_error;
    CLX_FWD_ACTION_T    option_len_error;
    CLX_FWD_ACTION_T    ver_field_error;
    CLX_FWD_ACTION_T    decap_ttl0_action;
    CLX_FWD_ACTION_T    decap_ttl1_action;
    CLX_FWD_ACTION_T    transit_ttl0_action;
    CLX_FWD_ACTION_T    transit_ttl1_action;
    CLX_FWD_ACTION_T    uc_adj_chk_fail_action;
    CLX_FWD_ACTION_T    mc_adj_chk_fail_action;
    CLX_FWD_ACTION_T    rpf_chk_fail_action;
} CLX_TRILL_PKT_HANDLING_T;

typedef struct CLX_TRILL_INIT_INFO_S
{
    CLX_TRILL_NICKNAME_T    egr_nickname; /* key */
    BOOL_T                  multi_dst;    /* key */

#define CLX_TRILL_INIT_FLAGS_FGL_EN                       (1U << 0) /* Enable: FGL, disable: VL */
#define CLX_TRILL_INIT_FLAGS_QOS_FROM_INNER               (1U << 1) /* both outer_qos, vl/fgl qos from inner */
#define CLX_TRILL_INIT_FLAGS_METER_VALID                  (1U << 2)
#define CLX_TRILL_INIT_FLAGS_CNT_VALID                    (1U << 3)
#define CLX_TRILL_INIT_FLAGS_DIST_CNT_VALID               (1U << 4)
#define CLX_TRILL_INIT_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID (1U << 5)
#define CLX_TRILL_INIT_FLAGS_PHB_TO_DSCP_PROFILE_VALID    (1U << 6)
#define CLX_TRILL_INIT_FLAGS_SAMPLE_TO_MIR                (1U << 7) /* Sample packets to mirror session */
#define CLX_TRILL_INIT_FLAGS_SAMPLE_HIGH_LATENCY          (1U << 8) /* Sample high latency packets */
#define CLX_TRILL_INIT_FLAGS_DTEL                         (1U << 9)
    UI32_T    flags;

    /* outer header */
    UI8_T     outer_pcp;
    UI8_T     outer_dei;
    /* trill header */
    UI8_T     pcp; /* pcp for vl/fgl high part if qos not from inner */
    UI8_T     dei; /* dei for vl/fgl high part if qos not from inner */
    UI32_T    ttl; /* hop count on TRILL header */

    /* intf properties */
    UI32_T    phb_to_pcp_dei_profile_id;
    UI32_T    phb_to_dscp_profile_id;
    UI32_T    mir_session_bitmap;         /* Mirror session ID bitmap */
    UI32_T    group_label;                /* acl group label */
    UI32_T    meter_id;
    UI32_T    cnt_id;                     /* Service counter ID */
    UI32_T    dist_cnt_id;                /* Distribution counter ID */
    UI32_T    sampling_rate;              /* Sampling rate */
    UI32_T    sample_to_mir_session_id;   /* Sample to mirror session ID */
    UI32_T    dtel_profile_id;
} CLX_TRILL_INIT_INFO_T;

typedef enum
{
    CLX_TRILL_TUNNEL_NORMAL = 0,
    CLX_TRILL_TUNNEL_TREE,
    CLX_TRILL_TUNNEL_LAST
} CLX_TRILL_TUNNEL_TYPE_T;

typedef struct CLX_TRILL_TERM_INFO_S
{
    CLX_TRILL_NICKNAME_T     igr_nickname; /* key */
    CLX_TRILL_NICKNAME_T     egr_nickname; /* key: only mc */
    BOOL_T                   multi_dst;    /* key */

    /* intf properties */
#define CLX_TRILL_TERM_FLAGS_USE_INNER_PHB                (1U << 0) /* 1: use vl/fgl, 0: use outer vlan */
#define CLX_TRILL_TERM_FLAGS_ECN_DISABLE                  (1U << 1) /* 1: disable ECN */
#define CLX_TRILL_TERM_FLAGS_METER_VALID                  (1U << 2)
#define CLX_TRILL_TERM_FLAGS_CNT_VALID                    (1U << 3)
#define CLX_TRILL_TERM_FLAGS_DIST_CNT_VALID               (1U << 4)
#define CLX_TRILL_TERM_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID (1U << 5)
#define CLX_TRILL_TERM_FLAGS_DSCP_TO_PHB_PROFILE_VALID    (1U << 6)
#define CLX_TRILL_TERM_FLAGS_SAMPLE_TO_MIR                (1U << 7) /* Sample packets to mirror session */
#define CLX_TRILL_TERM_FLAGS_DTEL                         (1U << 8)
    UI32_T        flags;

    CLX_PORT_T    learned_port;
    UI32_T        pcp_dei_to_phb_profile_id;
    UI32_T        dscp_to_phb_profile_id;
    UI32_T        mir_session_bitmap;   /* Mirror session ID bitmap */
    UI32_T        group_label; /* acl group label */
    UI32_T        meter_id;
    UI32_T        cnt_id;      /* Service counter ID */
    UI32_T        dist_cnt_id; /* Distribution counter ID */
    UI32_T        sampling_rate;              /* Sampling rate */
    UI32_T        sample_to_mir_session_id;   /* Sample to mirror session ID */
    UI32_T        dtel_profile_id;
    UI16_T        l2_mtu_size;
} CLX_TRILL_TERM_INFO_T;

typedef enum
{
    CLX_TRILL_FWD_INIT = 0,
    CLX_TRILL_FWD_TRANSIT,
    CLX_TRILL_FWD_LAST
} CLX_TRILL_FWD_T;

/*************************UC ROUTING RELATED*************************/
typedef struct CLX_TRILL_ROUTE_INFO_S
{
    CLX_TRILL_NICKNAME_T    egr_nickname; /* key */
    CLX_TRILL_FWD_T         fwd_type;     /* key */
    CLX_L3_OUTPUT_TYPE_T    output_type;  /* only ADJ/ECMP/NVO3_ADJ */
    UI32_T                  output_id;

#define CLX_TRILL_ROUTE_FLAGS_DROP     (1U << 0)
    UI32_T                  flags;
} CLX_TRILL_ROUTE_INFO_T;

/*************************MC TREE RELATED*************************/
typedef enum
{
    CLX_TRILL_PRUNE_NORMAL = 0,
    CLX_TRILL_PRUNE_VLAN,
    CLX_TRILL_PRUNE_VLAN_MAC,
    CLX_TRILL_PRUNE_VLAN_IP,
    CLX_TRILL_PRUNE_LAST
} CLX_TRILL_PRUNE_T;

typedef struct CLX_TRILL_TREE_S
{
    CLX_TRILL_NICKNAME_T    egr_nickname; /* key: tree root */
    CLX_TRILL_FWD_T         fwd_type;     /* key */
    CLX_TRILL_PRUNE_T       prune_type;   /* key */
    UI32_T                  mcast_id;
#define CLX_TRILL_TREE_FLAGS_DROP     (1U << 0)
    UI32_T                  flags;

    /* optional key info, based on prune_type */
    UI32_T                  vl_fgl_high;
    UI32_T                  fgl_low;      /* set all 1 when vl */
    union
    {
        CLX_MAC_T           mac;          /* inner dst mac addr */
        CLX_IP_ADDR_T       ip_addr;      /* inner dst ip addr  */
    };
} CLX_TRILL_TREE_INFO_T;

typedef struct CLX_TRILL_ADJ_CHECK_S
{
    UI32_T                  port;         /* ingress phy port */
    CLX_MAC_T               src_mac;      /* outer src MAC */
    BOOL_T                  multi_dst;    /* 0: UC, 1: MC */
    CLX_TRILL_NICKNAME_T    egr_nickname; /* only used for MC */
} CLX_TRILL_ADJ_CHECK_T;

typedef struct CLX_TRILL_RPF_CHECK_S
{
    UI32_T                  port;         /* ingress phy port */
    CLX_TRILL_NICKNAME_T    igr_nickname; /* IRB nickname */
    CLX_TRILL_NICKNAME_T    egr_nickname; /* tree nickname */
} CLX_TRILL_RPF_CHECK_T;

/*************************Port Property*************************/
typedef struct CLX_TRILL_PORT_PROPERTY_S
{
#define CLX_TRILL_PORT_PROPERTY_FLAGS_RBV_EN   (1U << 0)
    UI32_T    flags;

    UI32_T    rbv_id; /* virtual RB ID */
} CLX_TRILL_PORT_PROPERTY_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_trill_setMyNickname
 * PURPOSE:
 *      Assign the nickname for the device.
 * INPUT:
 *      unit                -- Device unit number
 *      nickname            -- Nickname of the device
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_NO_MEMORY     -- No available memory
 *      CLX_E_OTHERS        -- Operate failed
 * NOTES:
 *      1. User should assign the device nickname before calling other trill APIs.
 *      2. If user doesn't assign the nickname, the default nickname is 0x0000 (unknown).
 *      3. The given nickname should not in the reserved ranged as RFC6325 defined.
 */
CLX_ERROR_NO_T
clx_trill_setMyNickname(
    const UI32_T                  unit,
    const CLX_TRILL_NICKNAME_T    nickname);

/* FUNCTION NAME:   clx_trill_getMyNickname
 * PURPOSE:
 *      Get the nickname of the device
 * INPUT:
 *      unit                  -- Device unit number
 * OUTPUT:
 *      ptr_nickname          -- Nickname of the device
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_ENTRY_NOT_FOUND -- User doesn't set the nickname
 *      CLX_E_OTHERS          -- Operate failed
 * NOTES:
 *      If user doesn't assign the nickname, the default nickname is 0x0000 (unknown).
 */
CLX_ERROR_NO_T
clx_trill_getMyNickname(
    const UI32_T            unit,
    CLX_TRILL_NICKNAME_T    *ptr_nickname);

/* FUNCTION NAME:   clx_trill_setPktHandling
 * PURPOSE:
 *      Set the forward action for TRILL-related exception.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_action          -- Forward action for the exception
 *
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Operate failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_setPktHandling(
    const UI32_T                      unit,
    const CLX_TRILL_PKT_HANDLING_T    *ptr_action);

/* FUNCTION NAME:   clx_trill_getPktHandling
 * PURPOSE:
 *      Get the forward action for TRILL-related exception.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_action          -- Forward action when some exception occurs
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Operate failed
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getPktHandling(
    const UI32_T                unit,
    CLX_TRILL_PKT_HANDLING_T    *ptr_action);

/* FUNCTION NAME:   clx_trill_createPort
 * PURPOSE:
 *      Create a Trill-type tunnel port for unicast Trill tunnel.
 * INPUT:
 *      unit                -- Device unit number
 *      egr_nickname        -- Nickname of the remote RB
 *      flags               -- Option
 * OUTPUT:
 *      ptr_tnl_port        -- Trill-type tunnel port
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_ENTRY_EXISTS  -- Tunnel port has already been created
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_createPort(
    const UI32_T                  unit,
    const CLX_TRILL_NICKNAME_T    egr_nickname,
    const UI32_T                  flags,
    CLX_PORT_T                    *ptr_tnl_port);

/* FUNCTION NAME:   clx_trill_destroyPort
 * PURPOSE:
 *      Destroy a Trill-type tunnel port.
 * INPUT:
 *      unit                  -- Device unit number
 *      tnl_port              -- Trill-type tunnel port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Tunnel port is not created
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_destroyPort(
    const UI32_T        unit,
    const CLX_PORT_T    tnl_port);

/* FUNCTION NAME:   clx_trill_addInit
 * PURPOSE:
 *      Add a trill-type tunnel initiation entry and also set the initiation properties.
 *      If the tunnel initiation existed, the tunnel initiation properties will be updated.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_info            -- Keys and properties for tunnel initiation
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No available entry
 *      CLX_E_NO_MEMORY     -- No available memory
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_addInit(
    const UI32_T                   unit,
    const CLX_TRILL_INIT_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_delInit
 * PURPOSE:
 *      Delete a trill-type tunnel initiation entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_info              -- Keys for tunnel initiation
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_delInit(
    const UI32_T                   unit,
    const CLX_TRILL_INIT_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_getInit
 * PURPOSE:
 *      Get a tunnel initiation properties for trill-type tunnel.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_info              -- Keys for tunnel initiation
 * OUTPUT:
 *      ptr_info              -- Properties for tunnel initiation
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getInit(
    const UI32_T             unit,
    CLX_TRILL_INIT_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_addTerm
 * PURPOSE:
 *      Add a trill-type tunnel termination entry and also set the termination properties.
 *      If the tunnel termination existed, the tunnel termination properties will be updated.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_info            -- Keys and properties for tunnel termination
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No available entry
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_addTerm(
    const UI32_T                   unit,
    const CLX_TRILL_TERM_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_delTerm
 * PURPOSE:
 *      Delete a trill-type tunnel termination entry.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_info            -- Keys for tunnel termination
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              --  Operate success
 *      CLX_E_BAD_PARAMETER   --  Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND --  Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_delTerm(
    const UI32_T                   unit,
    const CLX_TRILL_TERM_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_getTerm
 * PURPOSE:
 *      Get a tunnel termination properties for trill-type tunnel.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_info              -- Keys for tunnel termination
 * OUTPUT:
 *      ptr_info              -- Properties for tunnel termination
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getTerm(
    const UI32_T             unit,
    CLX_TRILL_TERM_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_addSegService
 * PURPOSE:
 *      Add a service based on multicast trill-type tunnel and segment, either vl or fgl.
 *      If the service existed, the properties will be updated.
 * INPUT:
 *      unit                -- Device unit number
 *      igr_nickname        -- Ingress RB nickname
 *      egr_nickname        -- Tree root nickname
 *      vl_fgl_high         -- Vl or fgl high-part value
 *      fgl_low             -- Fgl low-part value (for vl, must fill all one)
 *      ptr_srv             -- Service Properties
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No available entry
 *      CLX_E_NO_MEMORY     -- No available memory
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_addSegService(
    const UI32_T                  unit,
    const CLX_TRILL_NICKNAME_T    igr_nickname,
    const CLX_TRILL_NICKNAME_T    egr_nickname,
    const UI32_T                  vl_fgl_high,
    const UI32_T                  fgl_low,
    const CLX_PORT_SEG_SRV_T      *ptr_srv);

/* FUNCTION NAME:   clx_trill_delSegService
 * PURPOSE:
 *      Delete a service based on multicast trill-type tunnel and segment, either vl or fgl.
 * INPUT:
 *      unit                  -- Device unit number
 *      igr_nickname          -- Ingress RB nickname
 *      egr_nickname          -- Tree root nickname
 *      vl_fgl_high           -- Vl or fgl high-part value
 *      fgl_low               -- Fgl low-part value (for vl, must fill all one)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_delSegService(
    const UI32_T                  unit,
    const CLX_TRILL_NICKNAME_T    igr_nickname,
    const CLX_TRILL_NICKNAME_T    egr_nickname,
    const UI32_T                  vl_fgl_high,
    const UI32_T                  fgl_low);

/* FUNCTION NAME:   clx_trill_getSegService
 * PURPOSE:
 *      Get a service based on multicast trill-type tunnel and segment, either vl or fgl.
 * INPUT:
 *      unit                  -- Device unit number
 *      igr_nickname          -- Ingress RB nickname
 *      egr_nickname          -- Tree root nickname
 *      vl_fgl_high           -- Vl or fgl high-part value
 *      fgl_low               -- Fgl low-part value (for vl, must fill all one)
 * OUTPUT:
 *      ptr_srv               -- Service Properties
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getSegService(
    const UI32_T                  unit,
    const CLX_TRILL_NICKNAME_T    igr_nickname,
    const CLX_TRILL_NICKNAME_T    egr_nickname,
    const UI32_T                  vl_fgl_high,
    const UI32_T                  fgl_low,
    CLX_PORT_SEG_SRV_T            *ptr_srv);

/* FUNCTION NAME:   clx_trill_addRoute
 * PURPOSE:
 *      Add a unicast routing information for Trill tunnel init or transit.
 *      If the routing information is existed, the related attributes will be updated.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_info            -- Address and properties of Trill init/transit route
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No available entry
 *      CLX_E_NO_MEMORY     -- No available memory
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_addRoute(
    const UI32_T                    unit,
    const CLX_TRILL_ROUTE_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_delRoute
 * PURPOSE:
 *      Delete a unicast routing entry with the specific egress nickname and forward type.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_info              -- Address of Trill init/transit route
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operation success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_NO_MEMORY       -- No available memory
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_delRoute(
    const UI32_T                    unit,
    const CLX_TRILL_ROUTE_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_getRoute
 * PURPOSE:
 *      Get a routing information with the specific egress nickname and forward type.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_info              -- Address of Trill init/transit route
 * OUTPUT:
 *      ptr_info              -- Properties of Trill init/transit route
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_NO_MEMORY       -- No available memory
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getRoute(
    const UI32_T              unit,
    CLX_TRILL_ROUTE_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_addTree
 * PURPOSE:
 *      Add the mcast forwarding information according to the specified condition.
 *      If the forwarding information existed, the attributes will be updated.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_info            -- The mcast forwarding information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No available entry
 *      CLX_E_NO_MEMORY     -- No available memory
 * NOTES:
 *      1. Should add normal tree before add prune tree.
 *         And, init type and transit type tree will be treated as different tree.
 *         That means, if want to add transit mac-prune tree,
 *         must add transit normal tree instead of init normal tree.
 *      2. For init type:
 *         a. VLAN prune tree: be active by configuring this tree by APIs
 *            which using CLX_PORT_SEG_SRV_T with bum_mcast_id.
 *         b. IP prune tree: be active when enable ipmc in bridge domain.
 */
CLX_ERROR_NO_T
clx_trill_addTree(
    const UI32_T                   unit,
    const CLX_TRILL_TREE_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_delTree
 * PURPOSE:
 *      Delete the mcast forwarding information according to the specified condition and egr_nickname.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_info              -- The mcast forwarding information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_NO_MEMORY       -- No available memory
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_delTree(
    const UI32_T                   unit,
    const CLX_TRILL_TREE_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_getTree
 * PURPOSE:
 *      Get the mcast forwarding information according to the specified condition and egr_nickname.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_info              -- The mcast forwarding information
 * OUTPUT:
 *      ptr_info              -- The mcast forwarding information
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_NO_MEMORY       -- No available memory
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getTree(
    const UI32_T             unit,
    CLX_TRILL_TREE_INFO_T    *ptr_info);

/* FUNCTION NAME:   clx_trill_addAdjCheckEntry
 * PURPOSE:
 *      Add a Trill adjacency check entry.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_entry           -- Adjacency check information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No available entry
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_addAdjCheckEntry(
    const UI32_T                   unit,
    const CLX_TRILL_ADJ_CHECK_T    *ptr_entry);

/* FUNCTION NAME:   clx_trill_delAdjCheckEntry
 * PURPOSE:
 *      Delete a Trill adjacency check entry
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_entry             -- Adjacency check information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_delAdjCheckEntry(
    const UI32_T                   unit,
    const CLX_TRILL_ADJ_CHECK_T    *ptr_entry);

/* FUNCTION NAME:   clx_trill_getAdjCheckEntry
 * PURPOSE:
 *      Check the Trill adjacency check entry exist or not.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_entry             -- Adjacency check information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Entry exists
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getAdjCheckEntry(
    const UI32_T                   unit,
    const CLX_TRILL_ADJ_CHECK_T    *ptr_entry);

/* FUNCTION NAME:   clx_trill_addRpfCheckEntry
 * PURPOSE:
 *      Add a Trill RPF check entry.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_entry           -- Rpf check information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No available entry
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_addRpfCheckEntry(
    const UI32_T                   unit,
    const CLX_TRILL_RPF_CHECK_T    *ptr_entry);

/* FUNCTION NAME:   clx_trill_delRpfCheckEntry
 * PURPOSE:
 *      Delete a Trill RPF check entry.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_entry             -- Rpf check information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry is not added
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_delRpfCheckEntry(
    const UI32_T                   unit,
    const CLX_TRILL_RPF_CHECK_T    *ptr_entry);

/* FUNCTION NAME:   clx_trill_getRpfCheckEntry
 * PURPOSE:
 *      Check the Trill RPF check entry exist or not.
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_entry             -- Rpf check information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Entry exists
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getRpfCheckEntry(
    const UI32_T                   unit,
    const CLX_TRILL_RPF_CHECK_T    *ptr_entry);

/* FUNCTION NAME:   clx_trill_addVirtualRb
 * PURPOSE:
 *      Add virtual rb with virtual nickname.
 * INPUT:
 *      unit                -- Device unit number
 *      nickname            -- Virtual nickname
 *      flags               -- Optional flags
 *                             Please reference CLX_TRILL_VIRTUAL_RB_*
 * OUTPUT:
 *      ptr_rbv_id          -- Virtual rb id
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_TABLE_FULL    -- No available entry
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_addVirtualRb(
    const UI32_T                  unit,
    const CLX_TRILL_NICKNAME_T    nickname,
    const UI32_T                  flags,
    UI32_T                        *ptr_rbv_id);

/* FUNCTION NAME:   clx_trill_delVirtualRb
 * PURPOSE:
 *      Delete a virtual rb.
 * INPUT:
 *      unit                  -- Device unit number
 *      rbv_id                -- Virtual rb id
 * OUTPUT:
 *      none
 * RETURN:
 *      CLX_E_OK              -- Entry exists
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_delVirtualRb(
    const UI32_T    unit,
    const UI32_T    rbv_id);

/* FUNCTION NAME:   clx_trill_getVirtualRb
 * PURPOSE:
 *      Get virtual nickname with virtual rb id.
 * INPUT:
 *      unit                  -- Device unit number
 *      rbv_id                -- Virtual rb id
 * OUTPUT:
 *      ptr_nickname              -- Virtual nickname
 * RETURN:
 *      CLX_E_OK              -- Entry exists
 *      CLX_E_BAD_PARAMETER   -- Bad parameter
 *      CLX_E_ENTRY_NOT_FOUND -- Entry does not exist
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getVirtualRb(
    const UI32_T            unit,
    const UI32_T            rbv_id,
    CLX_TRILL_NICKNAME_T    *ptr_nickname);

/* FUNCTION NAME:   clx_trill_setPortProperty
 * PURPOSE:
 *      Set TRILL related port properties.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Port
 *      ptr_property        -- Port properties
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Operation fail
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_setPortProperty(
    const UI32_T                       unit,
    const CLX_PORT_T                   port,
    const CLX_TRILL_PORT_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   clx_trill_getPortProperty
 * PURPOSE:
 *      Get TRILL related port properties.
 * INPUT:
 *      unit                -- Device unit number
 *      port                -- Port
 * OUTPUT:
 *      ptr_property        -- Port properties
 * RETURN:
 *      CLX_E_OK            -- Operation success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Operation fail
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_trill_getPortProperty(
    const UI32_T                 unit,
    const CLX_PORT_T             port,
    CLX_TRILL_PORT_PROPERTY_T    *ptr_property);

#endif /* End of CLX_TRILL_H */
