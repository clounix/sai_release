/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_acl.h
 * PURPOSE:
 *      It provides ACL module API.
 * NOTES:
 */

#ifndef CLX_ACL_H
#define CLX_ACL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>
#include <clx_pkt.h>
#include <clx_fcoe.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define CLX_ACL_PKG_NUM                (46)  /* Maximum ACL PKG key byte number for ACL */
#define CLX_ACL_FLOW_PKG_NUM           (31)  /* Maximum ACL PKG key byte number for Flow */
#define CLX_ACL_FLOW_1_PKG_NUM         (16)  /* Maximum ACL PKG key byte number for Flow_1 */
#define CLX_ACL_LOU_NUM                (16)  /* Maximum LOU number for each udf profile */
#define CLX_ACL_REWRITE_NUM            (9)   /* Maximum FCM rewrite profile number */
#define CLX_ACL_REWRITE_DATA_NUM       (16)  /* Maximum FCM rewrite byte number without mask */
#define CLX_ACL_REWRITE_MASK_NUM       (8)   /* Maximum FCM rewrite byte number with mask */

/* MACRO FUNCTION DECLARATIONS */

/* DATA TYPE DECLARATIONS
 */

typedef enum
{
    CLX_ACL_GROUP_INGRESS = 0, /* ingress stage */
    CLX_ACL_GROUP_EGRESS,      /* egress stage */
    CLX_ACL_GROUP_LAST
} CLX_ACL_GROUP_T;

typedef enum
{
    CLX_ACL_L2_FRAME_ETHERNET = 0,   /* Ethernet frame */
    CLX_ACL_L2_FRAME_RFC1042,        /* RFC1042 */
    CLX_ACL_L2_FRAME_SNAP_OTHER,     /* DSAP=0xAA, SSAP=0xAA, Control=0x3, Org Code not zero */
    CLX_ACL_L2_FRAME_LLC_OTHER,      /* L2 has LLC header but not SNAP */
    CLX_ACL_L2_FRAME_LAST
} CLX_ACL_L2_FRAME_T;

typedef enum
{
    CLX_ACL_VM_TAG_NONE = 0,    /* No VM tag */
    CLX_ACL_VM_TAG_ETAG,        /* Etag */
    CLX_ACL_VM_TAG_VNTAG,       /* VNTAG */
    CLX_ACL_VM_TAG_VEPA,        /* VEPA */
    CLX_ACL_VM_TAG_LAST
} CLX_ACL_VM_TAG_T;

typedef enum
{
    CLX_ACL_TNL_IPV4 = 0,       /* IPv4 tunnel type */
    CLX_ACL_TNL_IPV4_GRE,       /* IPv4 GRE tunnel type */
    CLX_ACL_TNL_IPV4_VXLAN,     /* IPv4 Vxlan tunnel type */
    CLX_ACL_TNL_IPV6,           /* IPv6 tunnel type */
    CLX_ACL_TNL_IPV6_GRE,       /* IPv6 GRE tunnel type */
    CLX_ACL_TNL_IPV6_VXLAN,     /* IPv6 Vxlan tunnel type */
    CLX_ACL_TNL_LAST
} CLX_ACL_TNL_T;

typedef enum
{
    CLX_ACL_FCOE_HDR_NOT_EXISTED = 0,   /* header not exist */
    CLX_ACL_FCOE_HDR_STD,               /* std header */
    CLX_ACL_FCOE_HDR_VFT,               /* vft header */
    CLX_ACL_FCOE_HDR_IFR,               /* ifr header */
    CLX_ACL_FCOE_HDR_ENCAP,             /* encap header */
    CLX_ACL_FCOE_HDR_UNKNOWN,           /* unknown header */
    CLX_ACL_FCOE_HDR_LAST
} CLX_ACL_FCOE_HDR_T;

typedef enum
{
    CLX_ACL_FRG_NONE = 0,   /* None fragment packet */
    CLX_ACL_FRG_FIRST,      /* First fragment packet, fragment offset field is zero */
    CLX_ACL_FRG_MIDDLE,     /* Middle fragment packet, fragment offset and more fragments flag fields are not zero */
    CLX_ACL_FRG_END,        /* Final fragment packet, more fragments flag is 0 in the flags field */
    CLX_ACL_FRG_LAST
} CLX_ACL_FRG_T;

typedef enum
{
    CLX_ACL_TTL_ZERO = 0,   /* TTL is 0 */
    CLX_ACL_TTL_ONE,        /* TTL is 1 */
    CLX_ACL_TTL_GT_ONE,     /* TTL is grater than 1 */
    CLX_ACL_TTL_LAST
} CLX_ACL_TTL_T;

typedef enum
{
    CLX_ACL_ARP_FRAME_ARP_REQUEST = 0,  /* ARP frame type is ARP request */
    CLX_ACL_ARP_FRAME_ARP_RESPONSE,     /* ARP frame type is ARP response */
    CLX_ACL_ARP_FRAME_LAST,
} CLX_ACL_ARP_FRAME_T;

typedef enum
{
    CLX_ACL_MAC_FRAME_PKT_NO_VLAN = 0,  /* no vlan tag packet */
    CLX_ACL_MAC_FRAME_PKT_SINGLE_VLAN,  /* match svid in 1ad; match cvid in 1q
                                         * treat cvid as 1st vid if s_tpid is the same as c_tpid */
    CLX_ACL_MAC_FRAME_PKT_DOUBLE_VLAN,  /* double vlan tag packet */
    CLX_ACL_MAC_FRAME_PKT_VLAN_LAST,
} CLX_ACL_PKT_VLAN_TYPE_T;

typedef enum
{
    CLX_ACL_GROUP_FORMAT_TC_COLOR             = (1U << 0),      /* for BASE_L2 KEY/BASE L3 KEY,
                                                                 * if use tc_color as key, can not use pcp/dei/dscp/ecn as key */
    CLX_ACL_GROUP_FORMAT_UDF_KEY_SINGLE       = (1U << 1),      /* single udf key */
    CLX_ACL_GROUP_FORMAT_UDF_KEY_DOUBLE       = (1U << 2),      /* double udf key, not supported on CL8360 */
    CLX_ACL_GROUP_FORMAT_L2_BIDIR             = (1U << 3),      /* l2 sa/da bi-direction */
    CLX_ACL_GROUP_FORMAT_L3_BIDIR             = (1U << 4),      /* l3 sa/da bi-direction */
    CLX_ACL_GROUP_FORMAT_L4_BIDIR             = (1U << 5),      /* l4 dp/sp bi-direction */
    CLX_ACL_GROUP_FORMAT_BASE_KEY_L2          = (1U << 6),      /* l2 base key */
    CLX_ACL_GROUP_FORMAT_BASE_KEY_L3          = (1U << 7),      /* l3 base key */
} CLX_ACL_GROUP_FORMAT_T;

typedef struct CLX_ACL_GROUP_PROFILE_S
{
    UI32_T    mac_pkt_format_bitmap;     /* CLX_ACL_GROUP_FORMAT_T, acl search only */
    UI32_T    arp_pkt_format_bitmap;     /* CLX_ACL_GROUP_FORMAT_T, acl search only */
    UI32_T    ipv4_pkt_format_bitmap;    /* CLX_ACL_GROUP_FORMAT_T, acl search only */
    UI32_T    ipv6_pkt_format_bitmap;    /* CLX_ACL_GROUP_FORMAT_T, acl search only */
    UI32_T    fcoe_pkt_format_bitmap;    /* CLX_ACL_GROUP_FORMAT_T, acl search only */

#define CLX_ACL_GROUP_PROFILE_FLAGS_PORT_BITMAP    (1U << 0)    /* acl search only.
                                                                * for pure BASE_L2/L3_KEY, if use port bitmap as key,
                                                                * can not use intf_group_label, l2/l3_da/sa_group_label,
                                                                * ingress_acl_group_label, arp.tpa as key
                                                                */
#define CLX_ACL_GROUP_PROFILE_FLAGS_FLOW           (1U << 1)    /* flow only */
    UI32_T    flags;                     /* CLX_ACL_GROUP_PROFILE_XXX flags */
} CLX_ACL_GROUP_PROFILE_T;

typedef struct CLX_ACL_PKT_FORMAT_S
{
    UI16_T                ethertype;                /* ethertype key */
    UI16_T                ethertype_mask;           /* ethertype key mask */
    UI8_T                 protocol;                 /* ip protocol */
    UI8_T                 protocol_mask;            /* ip protocol mask */
    UI16_T                src_port;                 /* l4 source port */
    UI16_T                src_port_mask;            /* l4 source port mask */
    UI16_T                dst_port;                 /* l4 destination port */
    UI16_T                dst_port_mask;            /* l4 destination port mask */
    CLX_ACL_L2_FRAME_T    l2_frame_type;            /* l2 frame type */
    CLX_ACL_VM_TAG_T      vm_tag_type;              /* vm tag type, ingress only */
    CLX_ACL_TNL_T         tnl_type;                 /* tunnel type and decap pass = 1, ingress only */

#define CLX_ACL_PKT_FORMAT_FLAGS_L2_FRAME_TYPE_VALID     (1U << 0)      /* l2 frame type flag */
#define CLX_ACL_PKT_FORMAT_FLAGS_VM_TAG_TYPE_VALID       (1U << 1)      /* vm tag type flag, ingress only */
#define CLX_ACL_PKT_FORMAT_FLAGS_TNL_TYPE_VALID          (1U << 2)      /* tunnel type flag, ingress only */
#define CLX_ACL_PKT_FORMAT_FLAGS_STAG_VALID              (1U << 3)      /* service vlan tag valid flag */
#define CLX_ACL_PKT_FORMAT_FLAGS_CTAG_VALID              (1U << 4)      /* custom vlan tag valid flag */
#define CLX_ACL_PKT_FORMAT_FLAGS_VLAN_TAG_MODE_1Q        (1U << 5)      /* indicates ctag_valid is in 1'st or 2'nd vlan */
    UI32_T    flags;            /* CLX_ACL_PKT_FORMAT_XXX flags*/
    UI32_T    flags_mask;       /* CLX_ACL_PKT_FORMAT_XXX flags*/
} CLX_ACL_PKT_FORMAT_T;

typedef enum
{
    CLX_ACL_PKG_BASE_NONE = 0,
    CLX_ACL_PKG_BASE_START_TNL_HDR,     /* tunnel header start, ingress only */
    CLX_ACL_PKG_BASE_START_L2_HDR,      /* l2 header start */
    CLX_ACL_PKG_BASE_START_L3_HDR,      /* l3 header start */
    CLX_ACL_PKG_BASE_START_L4_HDR,      /* l4 header start */
    CLX_ACL_PKG_BASE_END_TNL_HDR,       /* tunnel header end, not supported on CL8360, ingress only */
    CLX_ACL_PKG_BASE_END_L2_HDR,        /* l2 header end, not supported on CL8360 */
    CLX_ACL_PKG_BASE_END_L3_HDR,        /* l3 header end, not supported on CL8360 */
    CLX_ACL_PKG_BASE_END_L4_HDR,        /* l4 header end, not supported on CL8360 */
    CLX_ACL_PKG_BASE_LAST
} CLX_ACL_PKG_BASE_T;

typedef struct CLX_ACL_PKG_CFG_S
{
    CLX_ACL_PKG_BASE_T    type;         /* pkg type */
    UI32_T                offset;       /* byte offset */
    UI32_T                mask;         /* pkg data mask, acl search only */
    UI32_T                flags;        /* no used */
} CLX_ACL_PKG_CFG_T;

typedef enum
{
    CLX_ACL_UDF_INTERNAL_KEY_L2_SA_GROUP_LABEL   = (1U << 0),  /* l2 sa group label, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_L2_DA_GROUP_LABEL   = (1U << 1),  /* l2 da group label, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_L3_SA_GROUP_LABEL   = (1U << 2),  /* l3 sa group label, need to enable CLX_CFG_TYPE_TCAM_L3_SIP_ENABLE
                                                                * for Tcam search and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_L3_DA_GROUP_LABEL   = (1U << 3),  /* l3 da group label, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_INTF_GROUP_LABEL    = (1U << 4),  /* interface group label, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_SERVICE_GROUP_LABEL = (1U << 5),  /* l2 service group label, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_LOU                 = (1U << 6),  /* lou key.*/
    CLX_ACL_UDF_INTERNAL_KEY_PORT_BITMAP         = (1U << 7),  /* port bitmap key, not supported on CL8360 and acl search only */
    CLX_ACL_UDF_INTERNAL_KEY_BDID                = (1U << 8),  /* bridge domain id, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_VRF                 = (1U << 9),  /* virtual routing and forwarding id, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_L3_INTF_ID          = (1U << 10), /* l3 interface id, ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_STAG_VID            = (1U << 11), /* service vlan id, not supported on CL8360 and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_CTAG_VID            = (1U << 12), /* custom vlan id, not supported on CL8360 and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_STAG_PCP_DEI        = (1U << 13), /* service vlan pcp/dei, not supported on CL8360 and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_CTAG_PCP_DEI        = (1U << 14), /* custom vlan pcp/dei, not supported on CL8360 and ingress only */
    CLX_ACL_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q    = (1U << 15), /* vlan tag mode 802.1q, not supported on CL8360, ingress only,
                                                                  indicates ctag_vid/pcp_dei is in 1'st or 2'nd vlan */
    CLX_ACL_UDF_INTERNAL_KEY_L3_ROUTE            = (1U << 16), /* is l3 routing, ingress only */
} CLX_ACL_UDF_INTERNAL_KEY_T;

typedef struct CLX_ACL_UDF_KEY_PROFILE_S
{
    CLX_ACL_PKG_CFG_T    pkg_cfg[CLX_ACL_PKG_NUM];               /* pkg key config */
    UI32_T               pkg_cnt;                                /* CL8360 : max 41, non CL8360 : max 46 */
    UI32_T               internal_key_bitmap;                    /* CLX_ACL_UDF_INTERNAL_KEY_T */

    CLX_ACL_PKG_CFG_T    flow_pkg_cfg[CLX_ACL_FLOW_PKG_NUM];     /* ingress only */
    UI32_T               flow_pkg_cnt;                           /* ingress only */
    UI32_T               flow_internal_key_bitmap;               /* ingress only */
    UI32_T               flow_profile_id;                        /* Not supported on CL8360, ingress only.
                                                                    If flow 1 search is invalid, value of flow_profile_id
                                                                    must be (udf_key_profile_id & 0x3c/3d/3e/3f) */
    CLX_ACL_PKG_CFG_T    flow_1_pkg_cfg[CLX_ACL_FLOW_1_PKG_NUM]; /* Not supported on CL8360, ingress only */
    UI32_T               flow_1_pkg_cnt;                         /* Not supported on CL8360, ingress only */
    UI32_T               flow_1_internal_key_bitmap;             /* Not supported on CL8360, ingress only */
    UI32_T               flow_1_profile_id;                      /* Not supported on CL8360, ingress only */

#define CLX_ACL_UDF_KEY_PROFILE_FLAGS_FLOW_PROFILE_ID_VALID      (1U << 0)  /* flow profile flag */
#define CLX_ACL_UDF_KEY_PROFILE_FLAGS_FLOW_1_PROFILE_ID_VALID    (1U << 1)  /* flow 1 profile flag */
    UI32_T               flags;     /*CLX_ACL_UDF_KEY_PROFILE_FLAGS_XXX flags*/
} CLX_ACL_UDF_KEY_PROFILE_T;

typedef enum
{
    CLX_ACL_LOU_NONE = 0,       /* No lou*/
    CLX_ACL_LOU_SVID,           /* service vlan range */
    CLX_ACL_LOU_CVID,           /* custom vlan range */
    CLX_ACL_LOU_IP_TTL,         /* ip ttl range */
    CLX_ACL_LOU_SRC_PORT,       /* l4 source port range */
    CLX_ACL_LOU_DST_PORT,       /* l4 destination port range */
    CLX_ACL_LOU_PKG,            /* pkg key range */
    CLX_ACL_LOU_IP_TOTAL_LEN,   /* IP packet total length range */
    CLX_ACL_LOU_LAST
} CLX_ACL_LOU_T;

typedef struct CLX_ACL_LOU_CFG_S
{
    CLX_ACL_LOU_T         type;             /* lou type */
    CLX_ACL_PKG_BASE_T    pkg_base_type;    /* pkg base type if select CLX_ACL_LOU_PKG */
    UI32_T                pkg_offset;       /* pkg byte offset */
    UI16_T                val_mask;         /* value mask */
    UI16_T                val_max;          /* range value maximum */
    UI16_T                val_min;          /* range value mininum */
    UI8_T                 lou_or_bmap;      /* each bit set to 1 indicates the corresponding
                                             * lou participates in the logical "OR" operation of
                                             * bit map profile, lou_or_bmap is zero means logical "AND"
                                             * within 16 lou of udf key profile */

#define CLX_ACL_LOU_CFG_FLAGS_INVERSE             (1U << 0)     /* range inverse */
#define CLX_ACL_LOU_CFG_FLAGS_VLAN_TAG_MODE_1Q    (1U << 1)     /* indicates lou_cvid is in 1'st or 2'nd vlan */
#define CLX_ACL_LOU_CFG_FLAGS_ACL_VALID           (1U << 2)     /* acl search only*/
#define CLX_ACL_LOU_CFG_FLAGS_FLOW_VALID          (1U << 3)     /* ingress only */
#define CLX_ACL_LOU_CFG_FLAGS_FLOW_1_VALID        (1U << 4)     /* Not supported on CL8360, ingress only */
    UI32_T    flags;    /* CLX_ACL_LOU_CFG_XXX flags*/
} CLX_ACL_LOU_CFG_T;

typedef enum
{
    CLX_ACL_CLASSIFY_KEY_MAC = 0,   /* mac frame classify key */
    CLX_ACL_CLASSIFY_KEY_ARP,       /* arp frame classify key */
    CLX_ACL_CLASSIFY_KEY_IPV4,      /* ipv4 frame classify key */
    CLX_ACL_CLASSIFY_KEY_IPV6,      /* ipv6 frame classify key */
    CLX_ACL_CLASSIFY_KEY_FCOE,      /* fcoe frame classify key */
    CLX_ACL_CLASSIFY_KEY_UDF,       /* udf frame classify key */
    CLX_ACL_CLASSIFY_KEY_LAST
} CLX_ACL_CLASSIFY_KEY_T;

typedef struct CLX_ACL_MAC_KEY_S
{
    CLX_MAC_T                  dmac;            /* destination mac */
    CLX_MAC_T                  dmac_mask;       /* destination mac mask */
    CLX_MAC_T                  smac;            /* source mac */
    CLX_MAC_T                  smac_mask;       /* source mac mask */
    UI16_T                     ether_type;      /* ether type */
    UI16_T                     ether_type_mask; /* ether type mask */
    CLX_ACL_PKT_VLAN_TYPE_T    pkt_vlan_type;   /* packet vlan tag type */

#define CLX_ACL_MAC_KEY_FLAGS_PKT_VLAN_TYPE_VALID (1U << 0)     /* packet vlan tag type flag */
#define CLX_ACL_MAC_KEY_FLAGS_VLAN_TAG_MODE_1Q    (1U << 1)     /* indicates ctag_valid is in 1'st or 2'nd vlan */
    UI32_T    flags;    /* CLX_ACL_MAC_KEY_FLAGS_XXX flags */
} CLX_ACL_MAC_KEY_T;

typedef struct CLX_ACL_ARP_KEY_S
{
    CLX_MAC_T              sender_mac;      /* sender mac */
    CLX_MAC_T              sender_mac_mask; /* sender mac mask */
    CLX_IPV4_T             sender_ip;       /* sender ip address */
    CLX_IPV4_T             sender_ip_mask;  /* sender ip address mask */
    CLX_MAC_T              target_mac;      /* target mac */
    CLX_MAC_T              target_mac_mask; /* target mac mask*/
    CLX_IPV4_T             target_ip;       /* target ip address */
    CLX_IPV4_T             target_ip_mask;  /* target ip address mask */
    CLX_ACL_ARP_FRAME_T    arp_frame_type;  /* arp frame type */

#define CLX_ACL_ARP_FRAME_TYPE_VALID    (1U << 0)   /* arp frame valid flag */
    UI32_T    flags;    /* CLX_ACL_ARP_XXX flags */
} CLX_ACL_ARP_KEY_T;

typedef struct CLX_ACL_IPV4_KEY_S
{
    CLX_IPV4_T       dip;               /* destination ip address */
    CLX_IPV4_T       dip_mask;          /* destination ip address mask */
    CLX_IPV4_T       sip;               /* source ip address */
    CLX_IPV4_T       sip_mask;          /* source ip address mask*/
    UI8_T            protocol;          /* ip protocol */
    UI8_T            protocol_mask;     /* ip protocol mask */
    UI16_T           dst_port;          /* l4 destination port */
    UI16_T           dst_port_mask;     /* l4 destination port mask */
    UI16_T           src_port;          /* l4 source port */
    UI16_T           src_port_mask;     /* l4 source port mask */
    UI16_T           tcp_flag;          /* tcp flag */
    UI16_T           tcp_flag_mask;     /* tcp flag mask, must be all one or all zero */
    UI8_T            icmp_type;         /* icmp type value */
    UI8_T            icmp_type_mask;    /* icmp type mask */
    UI8_T            icmp_code;         /* icmp code value */
    UI8_T            icmp_code_mask;    /* icmp code value mask */
    UI8_T            igmp_type;         /* igmp type value */
    UI8_T            igmp_type_mask;    /* igmp type value mask */
    CLX_ACL_FRG_T    frg_type;          /* ip fragment type */
    CLX_ACL_TTL_T    ttl_type;          /* ttl type */

#define CLX_ACL_IPV4_KEY_FLAGS_FRG_TYPE_VALID    (1U << 0)  /* ip fragment type valid flag */
#define CLX_ACL_IPV4_KEY_FLAGS_TTL_TYPE_VALID    (1U << 1)  /* ttl type valid flag */
#define CLX_ACL_IPV4_KEY_FLAGS_AUTH_HDR_EXIST    (1U << 2)  /* Authentication header exist flag */
#define CLX_ACL_IPV4_KEY_FLAGS_OPT_HDR_EXIST     (1U << 3)  /* option header exist flag */
    UI32_T    flags;        /* CLX_ACL_IPV4_KEY_XXX flags */
    UI32_T    flags_mask;   /* CLX_ACL_IPV4_KEY_XXX flags mask */
} CLX_ACL_IPV4_KEY_T;

typedef struct CLX_ACL_IPV6_KEY_S
{
    CLX_IPV6_T       dip;                             /* destination ip address */
    CLX_IPV6_T       dip_mask;                        /* destination ip address mask */
    CLX_IPV6_T       sip;                             /* source ip address */
    CLX_IPV6_T       sip_mask;                        /* source ip address mask */
    UI8_T            protocol;                        /* ip protocol */
    UI8_T            protocol_mask;                   /* ip protocol mask */
    UI32_T           flow_label;                      /* flow label */
    UI32_T           flow_label_mask;                 /* flow label mask */
    UI8_T            first_ext_hdr_protocol;          /* first extension header protocol */
    UI8_T            first_ext_hdr_protocol_mask;     /* first extension header protocol mask, must be all one or all zero */
    UI8_T            second_ext_hdr_protocol;         /* second extension header protocol */
    UI8_T            second_ext_hdr_protocol_mask;    /* second extension header protocol, must be all one or all zero */
    UI16_T           dst_port;                        /* l4 destination port */
    UI16_T           dst_port_mask;                   /* l4 destination port mask */
    UI16_T           src_port;                        /* l4 source port */
    UI16_T           src_port_mask;                   /* l4 source port mask */
    UI16_T           tcp_flag;                        /* tcp flag */
    UI16_T           tcp_flag_mask;                   /* tcp flag mask, must be all one or all zero */
    UI8_T            icmp_type;                       /* icmp type value */
    UI8_T            icmp_type_mask;                  /* icmp type value mask */
    UI8_T            icmp_code;                       /* icmp code value */
    UI8_T            icmp_code_mask;                  /* icmp code value mask */
    UI8_T            igmp_type;                       /* igmp type value */
    UI8_T            igmp_type_mask;                  /* igmp type value mask */
    CLX_ACL_FRG_T    frg_type;                        /* ip fragment type */
    CLX_ACL_TTL_T    ttl_type;                        /* ttl type */

#define CLX_ACL_IPV6_KEY_FLAGS_FRG_TYPE_VALID       (1U << 0) /* ip fragment type valid flag */
#define CLX_ACL_IPV6_KEY_FLAGS_TTL_TYPE_VALID       (1U << 1) /* ttl type valid flag */
#define CLX_ACL_IPV6_KEY_FLAGS_AUTH_HDR_EXIST       (1U << 2) /* Authentication header exist flag */
    UI32_T    flags;        /* CLX_ACL_IPV6_KEY_XXX flags */
    UI32_T    flags_mask;   /* CLX_ACL_IPV6_KEY_XXX flags mask */
} CLX_ACL_IPV6_KEY_T;

typedef struct CLX_ACL_FCOE_KEY_S
{
    UI8_T                 sof;                  /* sof */
    UI8_T                 sof_mask;             /* sof mask*/
    UI8_T                 r_ctl;                /* r control */
    UI8_T                 r_ctl_mask;           /* r control mask */
    UI8_T                 type;                 /* type */
    UI8_T                 type_mask;            /* type mask */
    CLX_FCOE_FCID_T       dst_fcid;             /* destination fcid */
    CLX_FCOE_FCID_T       dst_fcid_mask;        /* destination fcid mask */
    CLX_FCOE_FCID_T       src_fcid;             /* source fcid */
    CLX_FCOE_FCID_T       src_fcid_mask;        /* source fcid mask */
    UI8_T                 cs_ctl;               /* cs control */
    UI8_T                 cs_ctl_mask;          /* cs control mask */
    UI8_T                 df_ctl;               /* df control */
    UI8_T                 df_ctl_mask;          /* df control mask */
    UI16_T                ox_id;                /* originator exchange id */
    UI16_T                ox_id_mask;           /* originator exchange id mask */
    UI16_T                rx_id;                /* responder exchange id*/
    UI16_T                rx_id_mask;           /* responder exchange id mask */
    UI8_T                 vft_type;             /* vft type */
    UI8_T                 vft_type_mask;        /* vft type mask */
    UI32_T    flags;    /* no used */
} CLX_ACL_FCOE_KEY_T;

typedef struct CLX_ACL_QOS_KEY_S
{
    UI8_T          pcp;             /* service vlan pcp for 1ad mode, custom vlan pcp for 1q mode */
    UI8_T          pcp_mask;        /* service vlan pcp mask for 1ad mode, custom pcp mask for 1q mode  */
    UI8_T          dei;             /* service vlan dei for 1ad mode, custom dei for 1q mode */
    UI8_T          dei_mask;        /* service vlan dei mask for 1ad mode, custom dei mask for 1q mode  */
    UI8_T          dscp;            /* dscp for l3 packet */
    UI8_T          dscp_mask;       /* dscp mask for l3 packet */
    UI8_T          ecn;             /* ecn for l3 packet */
    UI8_T          ecn_mask;        /* ecn mask for l3 packet */
    UI8_T          tc;              /* tc */
    UI8_T          tc_mask;         /* tc mask */
    CLX_COLOR_T    color;           /* color type */

#define CLX_ACL_QOS_KEY_FLAGS_STAG_PCP_DEI        (1U << 0)    /* service vlan pcp/dei for 1ad mode flag */
#define CLX_ACL_QOS_KEY_FLAGS_CTAG_PCP_DEI        (1U << 1)    /* custom vlan pcp/dei for 1q mode flag */
#define CLX_ACL_QOS_KEY_FLAGS_DSCP_ECN            (1U << 2)    /* dscp/ecn flag */
#define CLX_ACL_QOS_KEY_FLAGS_TC_COLOR            (1U << 3)    /* enable both tc and color flag */
#define CLX_ACL_QOS_KEY_FLAGS_COLOR_VALID         (1U << 4)    /* color valid flag */
#define CLX_ACL_QOS_KEY_FLAGS_VLAN_TAG_MODE_1Q    (1U << 5)    /* indicates ctag_pcp_dei is in 1'st or 2'nd vlan */
    UI32_T    flags;        /* CLX_ACL_QOS_KEY_FLAGS_XXX */
} CLX_ACL_QOS_KEY_T;

typedef struct CLX_ACL_PP_INFO_KEY_S
{
    UI32_T                 intf_group_label;                /* 12 bits, local interface group label*/
    UI32_T                 intf_group_label_mask;           /* 12 bits, local interface group label mask */
    UI32_T                 service_group_label;             /* 12 bits, service interface group label */
    UI32_T                 service_group_label_mask;        /* 12 bits, service interface group label mask */
    UI32_T                 l3_intf_group_label;             /* 14 bits, l3 interface group label */
    UI32_T                 l3_intf_group_label_mask;        /* 14 bits, l3 interface group label mask */
    UI32_T                 ingress_acl_group_label;         /* 10 bits, ingress acl search group label, egress match only */
    UI32_T                 ingress_acl_group_label_mask;    /* 10 bits, ingress acl search group label mask, egress match only */
    UI32_T                 l2_da_group_label;               /* 12 bits, l2 destination address group label */
    UI32_T                 l2_da_group_label_mask;          /* 12 bits, l2 destination address group label mask*/
    UI32_T                 l2_sa_group_label;               /* 12 bits, l2 source address group label */
    UI32_T                 l2_sa_group_label_mask;          /* l2 bits, l2 source address group label mask*/
    UI32_T                 l3_da_group_label;               /* 12 bits, l3 destination address group label */
    UI32_T                 l3_da_group_label_mask;          /* 12 bits, l3 destination address group label mask */
    UI32_T                 l3_sa_group_label;               /* 12 bits, l3 source address group label */
    UI32_T                 l3_sa_group_label_mask;          /* 12 bits, l3 source address group label mask */
    UI32_T                 bdid;                     /* Ingress : match ingress fdid
                                                        Egress  : match egress bdid, must match flags_l3_route=0 simultaneously */
    UI32_T                 bdid_mask;
    UI32_T                 l3_intf_id;               /* Ingress : match ingress l3_intf_id
                                                        Egress  : match egress l3_intf_id, must match flags_l3_route=1 simultaneously */
    UI32_T                 l3_intf_id_mask;          /* 14 bits, l3 interface index mask */
    CLX_ACL_L2_FRAME_T     l2_frame_type;            /* l2 frame type */

    UI32_T                 svid;                     /* Not supported on CL8360, ingress only */
    UI32_T                 svid_mask;                /* Not supported on CL8360, ingress only */
    UI32_T                 cvid;                     /* Not supported on CL8360, ingress only */
    UI32_T                 cvid_mask;                /* Not supported on CL8360, ingress only.
                                                        Can not match service/l3_intf_group_label/bdid/l3_intf_id
                                                        if matching svid/cvid.
                                                        Need to enable CLX_PORT_PROPERTY_ACL_MATCH_PACKET_VLAN
                                                        if want to match svid/cvid. */

#define CLX_ACL_PP_INFO_KEY_FLAGS_L2_FRAME_TYPE_VALID        (1U << 0)    /* l2 frame type valid flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_L3_ROUTE                   (1U << 1)    /* is l3 route flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_STAG_VALID                 (1U << 2)    /* service vlan tag valid flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_CTAG_VALID                 (1U << 3)    /* custom vlan tag valid flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_TNL_TERM                   (1U << 4)    /* is tunnel decap pass flag */
#define CLX_ACL_PP_INFO_KEY_FLAGS_VLAN_TAG_MODE_1Q           (1U << 5)    /* indicates cvid/ctag_valid is in 1'st or 2'nd vlan */
    UI32_T    flags;        /* CLX_ACL_PP_INFO_KEY_FLAG_XXX */
    UI32_T    flags_mask;   /* CLX_ACL_PP_INFO_KEY_FLAG_XXX */
} CLX_ACL_PP_INFO_KEY_T;

typedef struct CLX_ACL_PKG_KEY_S
{
    UI32_T    l2_sa_group_label;        /* 12 bits, l2 source address group label */
    UI32_T    l2_sa_group_label_mask;   /* 12 bits, l2 source address group label mask */
    UI32_T    l2_da_group_label;        /* 12 bits, l2 destination address group label */
    UI32_T    l2_da_group_label_mask;   /* 12 bits, l2 destination address group label mask */
    UI32_T    l3_sa_group_label;        /* 12 bits, l3 source address group label */
    UI32_T    l3_sa_group_label_mask;   /* 12 bits, l3 source address group label mask */
    UI32_T    l3_da_group_label;        /* 12 bits, l3 destination address group label */
    UI32_T    l3_da_group_label_mask;   /* 12 bits, l3 destination address group label mask */
    UI32_T    intf_group_label;         /* 12 bits, local interface group label*/
    UI32_T    intf_group_label_mask;    /* 12 bits, local interface group label mask */
    UI32_T    service_group_label;      /* 12 bits, service interface group label */
    UI32_T    service_group_label_mask; /* 12 bits, service interface group label mask */
    UI32_T    vrf;                      /* 13 bits, virtual routing forwarding index */
    UI32_T    vrf_mask;                 /* 13 bits, virtual routing forwarding index mask */
    UI32_T    bdid;                     /* 14 bits, bridge domain index */
    UI32_T    bdid_mask;                /* 14 bits, bridge domain index mask */
    UI32_T    l3_intf_id;               /* 14 bits, l3 interface index group label */
    UI32_T    l3_intf_id_mask;          /* 14 bits, l3 interface index group label */

    UI16_T    svid;         /* service vlan id, not supported on CL8360 */
    UI16_T    svid_mask;    /* service vlan id mask, not supported on CL8360 */
    UI8_T     spcp;         /* service vlan pcp, not supported on CL8360 */
    UI8_T     spcp_mask;    /* service vlan pcp mask, not supported on CL8360 */
    UI8_T     sdei;         /* service vlan dei, not supported on CL8360 */
    UI8_T     sdei_mask;    /* service vlan dei mask, not supported on CL8360 */
    UI16_T    cvid;         /* custom vlan id, not supported on CL8360 */
    UI16_T    cvid_mask;    /* custom vlan id mask, not supported on CL8360 */
    UI8_T     cpcp;         /* custom vlan pcp, not supported on CL8360 */
    UI8_T     cpcp_mask;    /* custom vlan pcp mask, not supported on CL8360 */
    UI8_T     cdei;         /* custom vlan dei, not supported on CL8360 */
    UI8_T     cdei_mask;    /* custom vlan dei mask, not supported on CL8360 */

    UI32_T    pkg_cnt;      /* pkg key byte count */
    UI32_T    data[CLX_ACL_PKG_NUM];    /* pkg key data */
    UI32_T    mask[CLX_ACL_PKG_NUM];    /* pkg key data mask */

#define CLX_ACL_PKG_KEY_FLAGS_VLAN_TAG_MODE_1Q    (1U << 0)     /* indicates cvid/cpcp/cdei is in 1'st or 2'nd vlan */
#define CLX_ACL_PKG_KEY_FLAGS_L3_ROUTE            (1U << 1)     /* is l3 route */
    UI32_T    flags;        /* CLX_ACL_PKG_KEY_FLAGS_XXX */
    UI32_T    flags_mask;   /* CLX_ACL_PKG_KEY_FLAGS_XXX */
} CLX_ACL_PKG_KEY_T;

typedef struct CLX_ACL_LOU_KEY_S
{
    UI32_T    lou_cnt;                  /*lou count */
    UI32_T    lou_id[CLX_ACL_LOU_NUM];  /* lou index */
} CLX_ACL_LOU_KEY_T;

typedef enum
{
    CLX_ACL_UDF_KEY_AUTO = 0,   /* udf key auto */
    CLX_ACL_UDF_KEY_UDF_0,      /* udf key 0, flow and acl search */
    CLX_ACL_UDF_KEY_UDF_1,      /* Not supported on CL8360, flow only */
    CLX_ACL_UDF_KEY_LAST
} CLX_ACL_UDF_KEY_T;

typedef struct CLX_ACL_CLASSIFY_S
{
    CLX_ACL_CLASSIFY_KEY_T    classify_key_type;    /* CLX_ACL_CLASSIFY_KEY_MAC  : mac/qos/pp_info/pkg/lou_key
                                                       CLX_ACL_CLASSIFY_KEY_ARP  : mac/arp/qos/pp_info/pkg/lou_key
                                                       CLX_ACL_CLASSIFY_KEY_IPV4 : mac/ipv4/qos/pp_info/pkg/lou_key
                                                       CLX_ACL_CLASSIFY_KEY_IPV6 : mac/ipv6/qos/pp_info/pkg/lou_key
                                                       CLX_ACL_CLASSIFY_KEY_FCOE : mac/fcoe/qos/pp_info/pkg/lou_key
                                                       CLX_ACL_CLASSIFY_KEY_UDF  : pkg/lou_key */
    CLX_PORT_BITMAP_T         port_bitmap;              /* ingress/egress port bitmap for ingress/egress stage */
    CLX_ACL_MAC_KEY_T         mac_key;                  /* mac key */
    CLX_ACL_ARP_KEY_T         arp_key;                  /* arp key */
    CLX_ACL_IPV4_KEY_T        ipv4_key;                 /* ipv4 key */
    CLX_ACL_IPV6_KEY_T        ipv6_key;                 /* ipv6 key */
    CLX_ACL_FCOE_KEY_T        fcoe_key;                 /* fcoe key */
    CLX_ACL_QOS_KEY_T         qos_key;                  /* qos key */
    CLX_ACL_PP_INFO_KEY_T     pp_info_key;              /* pp info key */
    CLX_ACL_PKG_KEY_T         pkg_key;                  /* pkg key */
    CLX_ACL_LOU_KEY_T         lou_key;                  /* lou key */
    UI32_T                    udf_key_profile_id;       /* udf key profile id */
    UI32_T                    udf_key_profile_id_mask;  /* udf key prfile id mask */
    CLX_ACL_UDF_KEY_T         udf_key_type;             /* udf key type */

#define CLX_ACL_CLASSIFY_FLAGS_MAC_KEY           (1U << 0)  /* mac key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_ARP_KEY           (1U << 1)  /* arp key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_IPV4_KEY          (1U << 2)  /* ipv4 key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_IPV6_KEY          (1U << 3)  /* ipv6 key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_FCOE_KEY          (1U << 4)  /* fcoe key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_QOS_KEY           (1U << 5)  /* qos key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_PP_INFO_KEY       (1U << 6)  /* pp info key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_PKG_KEY           (1U << 7)  /* pkg key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_LOU_KEY           (1U << 8)  /* lou key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_UDF_VALID         (1U << 9)  /* udf key flag, depends on classify_key_type */
#define CLX_ACL_CLASSIFY_FLAGS_PORT_BITMAP_VALID (1U << 10) /* port bitmap key flag, depends on classify_key_type */
     UI32_T    flags;   /* CLX_ACL_CLASSIFY_FLAGS_XXX */
} CLX_ACL_CLASSIFY_T;

typedef struct CLX_ACL_QOS_ACTION_S
{
    UI8_T          pcp;     /* remark pcp */
    UI8_T          dei;     /* remark dei */
    UI8_T          dscp;    /* remark dscp */
    UI8_T          ecn;     /* remark ecn */
    UI8_T          tc;      /* remark tc */
    CLX_COLOR_T    color;   /* remark color */

#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_PCP      (1U << 0)  /* remark pcp flag */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_DEI      (1U << 1)  /* remark dei flag */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_DSCP     (1U << 2)  /* remark dscp flag */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_ECN      (1U << 3)  /* remark ecn flag */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_TC       (1U << 4)  /* remark tc flag */
#define CLX_ACL_QOS_ACTION_FLAGS_REMARK_COLOR    (1U << 5)  /* remark color flag */
#define CLX_ACL_QOS_ACTION_FLAGS_DROP            (1U << 6)  /* per qos color decision drop forward flag */
#define CLX_ACL_QOS_ACTION_FLAGS_TO_CPU_DROP     (1U << 7)  /* per qos color decision drop cpu flag */
    UI32_T    flags;    /* CLX_ACL_QOS_ACTION_FLAGS_XXX */
} CLX_ACL_QOS_ACTION_T;

typedef enum
{
    CLX_ACL_REDIRECT_L2_UC,        /* redirect to l2 unicast */
    CLX_ACL_REDIRECT_L3_UC,        /* redirect to l3 unicast */
    CLX_ACL_REDIRECT_L3_ECMP,      /* redirect to l3 ecmp group */
    CLX_ACL_REDIRECT_L2_MC,        /* redirect to l2 multicast group */
    CLX_ACL_REDIRECT_L3_MC,        /* redirect to l3 multicast group */
    CLX_ACL_REDIRECT_CPU,          /* redirect to cpu port */
    CLX_ACL_REDIRECT_L2_MGLAG,     /* redirect to lag multicast group */
    CLX_ACL_REDIRECT_LAST
} CLX_ACL_REDIRECT_T;

typedef struct CLX_ACL_REDIRECT_ACTION_S
{
    CLX_ACL_REDIRECT_T            redirect_type;
    CLX_PORT_T                    port;                           /* used for L2_UC */
    CLX_BRIDGE_DOMAIN_T           bdid;                           /* used for L2_UC(nv) */
    UI32_T                        adj_id;                         /* used for L3_UC */
    UI32_T                        ecmp_group_id;                  /* used for L3_ECMP */
    UI32_T                        mcast_id;                       /* used for L2/L3_MC */
    CLX_PKT_RX_REASON_BITMAP_T    cpu_reason_bitmap;              /* used for CPU */

#define CLX_ACL_REDIRECT_ACTION_FLAGS_BYPASS_PRUNE    (1U << 0)    /* used for L2_UC */
   UI32_T                         flags;        /* CLX_ACL_REDIRECT_ACTION_FLAGS_XXX */
} CLX_ACL_REDIRECT_ACTION_T;

typedef enum
{
    CLX_ACL_REWRITE_DEL = 1,        /* del packet info */
    CLX_ACL_REWRITE_ADD,            /* add packet info */
    CLX_ACL_REWRITE_SET,            /* replace packet info */
    CLX_ACL_REWRITE_SET_WITH_MASK,  /* replace packet info with mask */
    CLX_ACL_REWRITE_SET_INCR,       /* increase packet info */
    CLX_ACL_REWRITE_LAST
}CLX_ACL_REWRITE_ACTION_T;

typedef struct CLX_ACL_REWRITE_CFG_S
{
    CLX_ACL_REWRITE_ACTION_T    type;           /* rewrite action type */
    CLX_ACL_PKG_BASE_T          pkg_base_type;  /* rewrite base type */
    UI32_T                      byte_offset;    /* value should be multiple of two bytes */
    UI32_T                      byte_cnt;       /* value should be multiple of two bytes */
    UI8_T                       data[CLX_ACL_REWRITE_DATA_NUM];     /* rewrite data */
    UI8_T                       mask[CLX_ACL_REWRITE_MASK_NUM];     /* rewrite data mask */
}CLX_ACL_REWRITE_CFG_T;

typedef struct CLX_ACL_PKT_REWRITE_S
{
    CLX_ACL_REWRITE_CFG_T    rewrite_cfg[CLX_ACL_REWRITE_NUM];  /* rewrite config array */
    UI32_T                   rewrite_cnt;   /* rewrite config count */
}CLX_ACL_PKT_REWRITE_T;

typedef struct CLX_ACL_ACTION_S
{
    UI32_T                        priority;                   /* value : 0-15, can only set to 0 if
                                                                 CLX_ACL_ACTION_FLAGS_QOS_ACTION_INVALID and
                                                                 CLX_ACL_ACTION_FLAGS_FWD_ACTION_INVALID is set */
    UI32_T                        mir_session_bitmap;         /* Mirror session ID bitmap */
    UI32_T                        sampling_rate;              /* Sampling rate */
    UI32_T                        sample_to_mir_session_id;   /* Sample packets to mirror session, not supported on CL8360 */
    UI32_T                        meter_id;                   /* meter index */
    UI32_T                        counter_id;                 /* counter index */
    UI32_T                        dist_counter_id;            /* distribution counter index */
    UI32_T                        ingress_acl_group_label;    /* write ingress acl group label */
    UI32_T                        da_group_label;             /* flow only */
    CLX_ACL_QOS_ACTION_T          qos_action_color_blind;     /* color blind qos action */
    CLX_ACL_QOS_ACTION_T          qos_action_color_green;     /* color green qos action */
    CLX_ACL_QOS_ACTION_T          qos_action_color_yellow;    /* color yellow qos action */
    CLX_ACL_QOS_ACTION_T          qos_action_color_red;       /* color red qos action */
    CLX_PKT_RX_REASON_BITMAP_T    cpu_reason_bitmap;          /* can only set one bit of the bitmap */
    CLX_ACL_REDIRECT_ACTION_T     redirect_action;            /* redirect action */
    CLX_ACL_PKT_REWRITE_T         pkt_rewrite;                /* packet rewrite action */
    UI32_T                        dtel_profile_id;            /* data plane telemetry action, Not supported on CL8360 */

#define CLX_ACL_ACTION_FLAGS_METER_VALID                         (1U << 0)      /* meter valid flag */
#define CLX_ACL_ACTION_FLAGS_COUNTER_VALID                       (1U << 1)      /* counter vadlid flag */
#define CLX_ACL_ACTION_FLAGS_DIST_COUNTER_VALID                  (1U << 2)      /* distribution counter valid flag */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_BLIND              (1U << 3)      /* color blind qos action valid flag */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_GREEN              (1U << 4)      /* color green qos action valid flag */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_YELLOW             (1U << 5)      /* color yellow qos action valid flag */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_RED                (1U << 6)      /* color red qos action valid flag */
#define CLX_ACL_ACTION_FLAGS_CANCEL_LEARN                        (1U << 7)      /* ingress only */
#define CLX_ACL_ACTION_FLAGS_BYPASS_RPF_CHECK_FAIL               (1U << 8)      /* ingress only */
#define CLX_ACL_ACTION_FLAGS_COPY_TO_CPU                         (1U << 9)      /* copy to cpu action valid flag */
#define CLX_ACL_ACTION_FLAGS_REDIRECT                            (1U << 10)     /* redirect action, ingress only */
#define CLX_ACL_ACTION_FLAGS_DROP                                (1U << 11)     /* drop normal port/redirect to cpu packet */
#define CLX_ACL_ACTION_FLAGS_TO_CPU_DROP                         (1U << 12)     /* drop copy/exception to cpu packet */
#define CLX_ACL_ACTION_FLAGS_PKT_REWRITE                         (1U << 13)     /* packet rewrite action valid flag, ingress only */
#define CLX_ACL_ACTION_FLAGS_L3_DA_GROUP_LABEL                   (1U << 14)     /* write l3 da label valid flag, flow only */
#define CLX_ACL_ACTION_FLAGS_ALLOW_STEERING                      (1U << 15)     /* allow steering, ingress only */
#define CLX_ACL_ACTION_FLAGS_BYPASS_TTL_CHECK_FAIL               (1U << 16)     /* bypass ttl check fail, ingress only */
#define CLX_ACL_ACTION_FLAGS_SAMPLE_TO_MIR                       (1U << 17)     /* Sample packets to mirror session, not supported on CL8360 */
#define CLX_ACL_ACTION_FLAGS_SAMPLE_HIGH_LATENCY                 (1U << 18)     /* Sample high latency packets, not supported on CL8360, egress only */
#define CLX_ACL_ACTION_FLAGS_KEEP_TTL                            (1U << 19)     /* Not supported on CL8360, ingress only.
                                                                                   If this flag is set, not supprot redirect action */
#define CLX_ACL_ACTION_FLAGS_TS_REPLACE_MAC                      (1U << 20)     /* timestamp replace mac, Not supported on CL8360, egress only */
#define CLX_ACL_ACTION_FLAGS_DTEL_VALID                          (1U << 21)     /* data plane telemetry valid flag, Not supported on CL8360 */
#define CLX_ACL_ACTION_FLAGS_QOS_ACTION_INVALID                  (1U << 22)     /* qos action invalid flag */
#define CLX_ACL_ACTION_FLAGS_FWD_ACTION_INVALID                  (1U << 23)     /* forward action invalid flag */
    UI32_T    flags;
} CLX_ACL_ACTION_T;

typedef struct CLX_ACL_GROUP_INFO_S
{
    CLX_ACL_GROUP_T            type;            /* acl group stage type */
    UI32_T                     group_id;        /* acl group index */
    UI32_T                     priority;        /* group priority */
    CLX_ACL_GROUP_PROFILE_T    group_profile;   /* group profile */
} CLX_ACL_GROUP_INFO_T;

typedef CLX_ERROR_NO_T
(*CLX_ACL_GROUP_TRAVERSE_FUNC_T)(
    const UI32_T                  unit,
    const CLX_ACL_GROUP_INFO_T    *ptr_group_info,
    void                          *ptr_cookie);

typedef struct CLX_ACL_ENTRY_INFO_S
{
    CLX_ACL_GROUP_T       type;             /* group stage type */
    UI32_T                group_id;         /* group index */
    UI32_T                entry_id;         /* entry index */
    UI32_T                priority;         /* flow entry : ignore this field */
    BOOL_T                entry_valid;      /* flow entry : ignore this field */
    CLX_ACL_CLASSIFY_T    classify;         /* entry classify */
    CLX_ACL_ACTION_T      action;           /* entry action */
} CLX_ACL_ENTRY_INFO_T;

typedef CLX_ERROR_NO_T
(*CLX_ACL_ENTRY_TRAVERSE_FUNC_T)(
    const UI32_T                  unit,
    const CLX_ACL_ENTRY_INFO_T    *ptr_entry_info,
    void                          *ptr_cookie);

typedef struct CLX_ACL_UDF_INFO_S
{
    CLX_ACL_GROUP_T              type;
    UI32_T                       udf_key_profile_id;
    CLX_ACL_PKT_FORMAT_T         pkt_format;
    CLX_ACL_UDF_KEY_PROFILE_T    profile;
} CLX_ACL_UDF_INFO_T;

typedef CLX_ERROR_NO_T
(*CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T)(
    const UI32_T                unit,
    const CLX_ACL_UDF_INFO_T    *ptr_udf_info,
    void                        *ptr_cookie);

typedef struct CLX_ACL_LOU_INFO_S
{
    CLX_ACL_GROUP_T      type;      /* group stage */
    UI32_T               id;        /* udf key profile index */
    UI32_T               lou_id;    /* lou index, 0-16 */
    CLX_ACL_LOU_CFG_T    lou_cfg;   /* lou config */
} CLX_ACL_LOU_INFO_T;

typedef CLX_ERROR_NO_T
(*CLX_ACL_LOU_TRAVERSE_FUNC_T)(
    const UI32_T                unit,
    const CLX_ACL_LOU_INFO_T    *ptr_lou_info,
    void                        *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: clx_acl_addGroup
 * PURPOSE:
 *      The API is used to add a UCP group.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      priority            -- UCP group priority
 *      ptr_group_profile   -- UCP group profile
 * OUTPUT:
 *      ptr_group_id        -- UCP group id
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_addGroup(
    const UI32_T                     unit,
    const CLX_ACL_GROUP_T            type,
    const UI32_T                     priority,
    const CLX_ACL_GROUP_PROFILE_T    *ptr_group_profile,
    UI32_T                           *ptr_group_id);

/* FUNCTION NAME: clx_acl_delGroup
 * PURPOSE:
 *      The API is used to delete a UCP group.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- The UCP group id to be deleted
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_delGroup(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id);

/* FUNCTION NAME: clx_acl_getGroup
 * PURPOSE:
 *      The API is used to get the configuration information of UCP group.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- The UCP group id to be deleted
 * OUTPUT:
 *      ptr_priority        -- UCP group priority to be returned
 *      ptr_group_profile   -- UCP group profile to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_getGroup(
    const UI32_T               unit,
    const CLX_ACL_GROUP_T      type,
    const UI32_T               group_id,
    UI32_T                     *ptr_priority,
    CLX_ACL_GROUP_PROFILE_T    *ptr_group_profile);

/* FUNCTION NAME:   clx_acl_addUdfKeyProfile
 * PURPOSE:
 *      The API is used to add a udf key profile.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      udf_key_profile_id  -- The udf key profile id to be added
 *      ptr_pkt_format      -- The packet format
 *      ptr_profile         -- The programming key format
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS        --  Other error.
 * NOTES:
 *      ACL udf key (non flow key) generation rule :
 *      - udf-key-0 length : 168(CL8360) / 208(non CL8360) bits
 *      - udf-key-1 length : 208 bits
 *      - internal key : Always generate at udf-key-0.
 *        -- l2/l3_da/sa_group_label : 12 bits
 *        -- intf_group_label : 10 bits
 *        -- service_group_label : 12 bits
 *        -- lou : 16 bits
 *        -- port_bitmap : 34 bits
 *        -- stag/ctag_vid : 13 bits
 *        -- stag/ctag_pcp_dei : 5 bits
 *        -- bdid : 14 bits
 *        -- l3_intf_id : 14 bits
 *      - pkg key : Generate at udf-key-0 first. If length of udf-key-0 is not enough, generate at udf-key-1.
 *        -- each pkg : 9 bits
 */
CLX_ERROR_NO_T
clx_acl_addUdfKeyProfile(
    const UI32_T                       unit,
    const CLX_ACL_GROUP_T              type,
    const UI32_T                       udf_key_profile_id,
    const CLX_ACL_PKT_FORMAT_T         *ptr_pkt_format,
    const CLX_ACL_UDF_KEY_PROFILE_T    *ptr_profile);

/* FUNCTION NAME:   clx_acl_delUdfKeyProfile
 * PURPOSE:
 *      The API is used to delete a udf key profile.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      udf_key_profile_id  -- udf key profile id to be deleted
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS        --  Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_delUdfKeyProfile(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             udf_key_profile_id);

/* FUNCTION NAME:   clx_acl_getUdfKeyProfile
 * PURPOSE:
 *      The API is used to get the configuration information of udf key profile.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      udf_key_profile_id  -- The udf key profile id to be get
 * OUTPUT:
 *      ptr_pkt_format      -- The packet format information to be returned
 *      ptr_profile         -- The programming key format information to be returned
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS        --  Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_getUdfKeyProfile(
    const UI32_T                 unit,
    const CLX_ACL_GROUP_T        type,
    const UI32_T                 udf_key_profile_id,
    CLX_ACL_PKT_FORMAT_T         *ptr_pkt_format,
    CLX_ACL_UDF_KEY_PROFILE_T    *ptr_profile);

/* FUNCTION NAME: clx_acl_addLou
 * PURPOSE:
 *      The API is used to add/set the LOU configuration information.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      id                  -- Udf key profile id.
 *      lou_id              -- The LOU id to be added/set
 *      ptr_lou             -- The LOU configuration information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_addLou(
    const UI32_T               unit,
    const CLX_ACL_GROUP_T      type,
    const UI32_T               id,
    const UI32_T               lou_id,
    const CLX_ACL_LOU_CFG_T    *ptr_lou);

/* FUNCTION NAME: clx_acl_delLou
 * PURPOSE:
 *      The API is used to delete the LOU configuration information.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      id                  -- Udf key profile id.
 *      lou_id              -- The LOU id to be deleted
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_delLou(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             id,
    const UI32_T             lou_id);

/* FUNCTION NAME: clx_acl_getLou
 * PURPOSE:
 *      The API is used to get the LOU configuration information.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      id                  -- Udf key profile id.
 *      lou_id              -- The LOU id to be get
 * OUTPUT:
 *      ptr_lou             -- The LOU configuration information to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_getLou(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             id,
    const UI32_T             lou_id,
    CLX_ACL_LOU_CFG_T        *ptr_lou);

/* FUNCTION NAME: clx_acl_allocEntryId
 * PURPOSE:
 *      The API is used to allocate a logic id for UCP entry.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Allocate a entry id from UCP group
 *      entry_priority      -- entry priority
 * OUTPUT:
 *      ptr_entry_id        -- The entry id to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_allocEntryId(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id,
    const UI32_T             entry_priority,
    UI32_T                   *ptr_entry_id);

/* FUNCTION NAME: clx_acl_freeEntryId
 * PURPOSE:
 *      The API is used to free the logic id for UCP entry.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- entry id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_freeEntryId(
    const UI32_T    unit,
    const UI32_T    entry_id);

/* FUNCTION NAME: clx_acl_getEntryIdInfo
 * PURPOSE:
 *      The API is used to get logic id information for UCP entry.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- Entry id
 * OUTPUT:
 *      ptr_type            -- the UCP group type of the entry id to be returned
 *      ptr_group_id        -- the group id of the entry id to be returned
 *      ptr_entry_priority  -- the entry priority of the entry id to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_getEntryIdInfo(
    const UI32_T       unit,
    const UI32_T       entry_id,
    CLX_ACL_GROUP_T    *ptr_type,
    UI32_T             *ptr_group_id,
    UI32_T             *ptr_entry_priority);

/* FUNCTION NAME: clx_acl_addEntry
 * PURPOSE:
 *      The API is used to add/set an UCP entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- entry id
 *      entry_valid         -- The status of the entry: TRUE for valid and FALSE for invalid
 *      ptr_classify        -- The classified information of the entry
 *      ptr_action          -- The action to be taken of the entry when the classified information is matched
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *      If both ptr_classify and ptr_action are NULL, the API will only modify valid bit of entry.
 */
CLX_ERROR_NO_T
clx_acl_addEntry(
    const UI32_T                unit,
    const UI32_T                entry_id,
    const BOOL_T                entry_valid,
    const CLX_ACL_CLASSIFY_T    *ptr_classify,
    const CLX_ACL_ACTION_T      *ptr_action);

/* FUNCTION NAME:   clx_acl_delEntry
 * PURPOSE:
 *      The API is used to delete an UCP entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- entry id

 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS        --  Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_delEntry(
    const UI32_T    unit,
    const UI32_T    entry_id);

/* FUNCTION NAME: clx_acl_getEntry
 * PURPOSE:
 *      The API is used to get an UCP entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- entry id
 * OUTPUT:
 *      entry_valid         -- The status of the entry to be returned
 *      ptr_classify        -- The classified information of the entry to be returned
 *      ptr_action          -- The action to be taken of the entry to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_acl_getEntry(
    const UI32_T          unit,
    const UI32_T          entry_id,
    BOOL_T                *ptr_entry_valid,
    CLX_ACL_CLASSIFY_T    *ptr_classify,
    CLX_ACL_ACTION_T      *ptr_action);

/* FUNCTION NAME: clx_acl_addFlowEntry
 * PURPOSE:
 *      The API is used to add an exact match entry to HW.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Group id
 *      ptr_classify        -- The classified information of the entry
 *      ptr_action          -- The action to be taken of the entry when the classified information is matched
 * OUTPUT:
 *      ptr_entry_id        -- The returned entry id from HW
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 */
CLX_ERROR_NO_T
clx_acl_addFlowEntry(
    const UI32_T                unit,
    const CLX_ACL_GROUP_T       type,
    const UI32_T                group_id,
    const CLX_ACL_CLASSIFY_T    *ptr_classify,
    const CLX_ACL_ACTION_T      *ptr_action,
    UI32_T                      *ptr_entry_id);

/* FUNCTION NAME: clx_acl_delFlowEntry
 * PURPOSE:
 *      The API is used to delete an exact match entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Group id
 *      entry_id            -- Entry id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 */
CLX_ERROR_NO_T
clx_acl_delFlowEntry(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id,
    const UI32_T             entry_id);

/* FUNCTION NAME: clx_acl_getFlowEntry
 * PURPOSE:
 *      The API is used to get an exact match entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Group id
 *      entry_id            -- Entry id
 * OUTPUT:
 *      ptr_classify        -- The classified information of the entry
 *      ptr_action          -- The action to be taken of the entry
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 */
CLX_ERROR_NO_T
clx_acl_getFlowEntry(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id,
    const UI32_T             entry_id,
    CLX_ACL_CLASSIFY_T       *ptr_classify,
    CLX_ACL_ACTION_T         *ptr_action);

/* FUNCTION NAME: clx_acl_traverseGroup
 * PURPOSE:
 *      The API is used to traverse UCP groups.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      callback            -- The callback function of type CLX_ACL_GROUP_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_acl_traverseGroup(
    const UI32_T                           unit,
    const CLX_ACL_GROUP_T                  type,
    const CLX_ACL_GROUP_TRAVERSE_FUNC_T    callback,
    void                                   *ptr_cookie);

/* FUNCTION NAME: clx_acl_traverseEntry
 * PURPOSE:
 *      The API is used to traverse UCP entries.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Group id
 *      callback            -- The callback function of type CLX_ACL_ENTRY_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_acl_traverseEntry(
    const UI32_T                           unit,
    const CLX_ACL_GROUP_T                  type,
    const UI32_T                           group_id,
    const CLX_ACL_ENTRY_TRAVERSE_FUNC_T    callback,
    void                                   *ptr_cookie);

/* FUNCTION NAME: clx_acl_traverseUdfKeyProfile
 * PURPOSE:
 *      The API is used to traverse udf key profile.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      callback            -- The callback function of type CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_acl_traverseUdfKeyProfile(
    const UI32_T                                     unit,
    const CLX_ACL_GROUP_T                            type,
    const CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T    callback,
    void                                             *ptr_cookie);

/* FUNCTION NAME: clx_acl_traverseLou
 * PURPOSE:
 *      The API is used to traverse lou.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      id                  -- Udf key profile id.
 *      callback            -- The callback function of type CLX_ACL_LOU_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_acl_traverseLou(
    const UI32_T                         unit,
    const CLX_ACL_GROUP_T                type,
    const UI32_T                         id,
    const CLX_ACL_LOU_TRAVERSE_FUNC_T    callback,
    void                                 *ptr_cookie);

#endif  /* End of CLX_ACL_H */

