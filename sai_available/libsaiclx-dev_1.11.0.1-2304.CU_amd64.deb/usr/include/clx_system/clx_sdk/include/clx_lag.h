/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_lag.h
 * PURPOSE:
 *      It provides LAG module API.
 * NOTES:
 *
 */

#ifndef CLX_LAG_H
#define CLX_LAG_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    CLX_LAG_HW_TYPE = 0,
    CLX_LAG_SW_TYPE,
    CLX_LAG_RR_TYPE,
    CLX_LAG_LAST_TYPE,
} CLX_LAG_TYPE_T;

typedef struct CLX_LAG_ATTRIB_S
{
    CLX_LAG_TYPE_T  lag_type;
} CLX_LAG_ATTRIB_T;

typedef struct CLX_LAG_TRAVERSE_INFO_S
{
    UI32_T        lag_id;   /* Link aggregation group ID */
    CLX_PORT_T    lag_port; /* LAG port*/
} CLX_LAG_TRAVERSE_INFO_T;

typedef CLX_ERROR_NO_T
(*CLX_LAG_TRAVERSE_FUNC_T)(
    const UI32_T                     unit,
    const CLX_LAG_TRAVERSE_INFO_T    *ptr_info,
    void                             *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_lag_createPort
 * PURPOSE:
 *      This API is used to create LAG port.
 * INPUT:
 *      unit -- Device unit number
 *      lag_id -- IEEE802.1AX link aggregation ID
 * OUTPUT:
 *      ptr_lag_port -- The pointer of the LAG port
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS -- Entry exists.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_createPort(
    const UI32_T    unit,
    const UI32_T    lag_id,
    CLX_PORT_T      *ptr_lag_port);

/* FUNCTION NAME:   clx_lag_destroyPort
 * PURPOSE:
 *      This API is used to destroy LAG port.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- Entry not found.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_destroyPort(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port);

/* FUNCTION NAME:   clx_lag_setMember
 * PURPOSE:
 *      This API is used to set LAG member.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 *      member_cnt -- Member port count
 *      ptr_member -- Member port list
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_setMember(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    const UI32_T        member_cnt,
    const CLX_PORT_T    *ptr_member);

/* FUNCTION NAME:   clx_lag_getMember
 * PURPOSE:
 *      This API is used to get LAG member.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 *      member_cnt -- Get member port count
 * OUTPUT:
 *      ptr_member -- Member port list
 *      ptr_actual_member_cnt -- Actual member port count
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getMember(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    const UI32_T        member_cnt,
    CLX_PORT_T          *ptr_member,
    UI32_T              *ptr_actual_member_cnt);

/* FUNCTION NAME:   clx_lag_getMemberCnt
 * PURPOSE:
 *      This API is used to get LAG member count.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 * OUTPUT:
 *      ptr_member_cnt -- Member port count
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getMemberCnt(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    UI32_T              *ptr_member_cnt);

/* FUNCTION NAME: clx_lag_traversePort
 * PURPOSE:
 *      The API is used to traverse LAG.
 * INPUT:
 *      unit                -- Device unit number
 *      callback            -- The callback function of type CLX_LAG_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_lag_traversePort(
    const UI32_T                     unit,
    const CLX_LAG_TRAVERSE_FUNC_T    callback,
    void                             *ptr_cookie);

/* FUNCTION NAME:   clx_lag_getRange
 * PURPOSE:
 *      This API is used to get LAG range.
 * INPUT:
 *      unit -- Device unit number
 * OUTPUT:
 *      ptr_range -- LAG range information
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getRange(
    const UI32_T        unit,
    CLX_RANGE_INFO_T    *ptr_range);

/* FUNCTION NAME:   clx_lag_getPort
 * PURPOSE:
 *      This API is used to get LAG port from LAG ID.
 * INPUT:
 *      unit -- Device unit number
 *      lag_id -- IEEE802.1AX link aggregation ID
 * OUTPUT:
 *      ptr_lag_port -- The pointer of the LAG port
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getPort(
    const UI32_T    unit,
    const UI32_T    lag_id,
    CLX_PORT_T      *ptr_lag_port);

/* FUNCTION NAME:   clx_lag_getKey
 * PURPOSE:
 *      This API is used to get LAG ID from LAG port.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 * OUTPUT:
 *      ptr_lag_id -- The pointer of the LAG Id
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getKey(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    UI32_T              *ptr_lag_id);

/* FUNCTION NAME:   clx_lag_addFdlGroup
 * PURPOSE:
 *      This API is used to enable FDL for the LAG port.
 * INPUT:
 *      unit            -- Device unit number
 *      lag_port        -- LAG port
 *      ptr_fdl_info    -- property of FDL
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_addFdlGroup(
    const UI32_T                unit,
    const CLX_PORT_T            lag_port,
    const CLX_FDL_INFO_T        *ptr_fdl_info);

/* FUNCTION NAME:   clx_lag_getFdlGroup
 * PURPOSE:
 *      This API is used to get the property of FDL for the LAG port.
 * INPUT:
 *      unit            -- Device unit number
 *      lag_port        -- LAG port
 * OUTPUT:
 *      ptr_fdl_info    -- property of FDL
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getFdlGroup(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    CLX_FDL_INFO_T      *ptr_fdl_info);


/* FUNCTION NAME:   clx_lag_delFdlGroup
 * PURPOSE:
 *      This API is used to disable FDL for the LAG port.
 * INPUT:
 *      unit            -- Device unit number
 *      lag_port        -- LAG port
 * OUTPUT:
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_delFdlGroup(
    const UI32_T                 unit,
    const CLX_PORT_T             lag_port);

/* FUNCTION NAME:   clx_lag_setAttr
 * PURPOSE:
 *      This API is used to set the lag attributes.
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 *      ptr_attr -- Pointer of the lag attribute
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_setAttr(
    const UI32_T              unit,
    const CLX_PORT_T          lag_port,
    const CLX_LAG_ATTRIB_T    *ptr_attr);  

/* FUNCTION NAME:   clx_lag_getAttr
 * PURPOSE:
 *      This API is used to get the lag attributes..
 * INPUT:
 *      unit -- Device unit number
 *      lag_port -- LAG port
 * OUTPUT:
 *      ptr_attr -- Pointer of the lag attribute
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getAttr(
    const UI32_T        unit,
    const CLX_PORT_T    lag_port,
    CLX_LAG_ATTRIB_T    *ptr_attr);

/* FUNCTION NAME:   clx_lag_createMglag
 * PURPOSE:
 *      This API is used to create mglag.
 * INPUT:
 *      unit -- Device unit number
 *      flag -- Attributes  refer to mglag
 * OUTPUT:
 *      ptr_mglag_id -- The pointer of the mglag id
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS -- Entry exists.
 * NOTES:
 *      None
 */	
CLX_ERROR_NO_T
clx_lag_createMglag(
    const UI32_T    unit,
    const UI32_T    flags,
    UI32_T          *ptr_mglag_id);

/* FUNCTION NAME:   clx_lag_destroyMglag
 * PURPOSE:
 *      This API is used to destroy mglag.
 * INPUT:
 *      unit -- Device unit number
 *      lag_mgid -- mglag id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- Entry not found.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_destroyMglag(
    const UI32_T    unit,
    const UI32_T    mglag_id);

/* FUNCTION NAME:   clx_lag_setMglagMbr
 * PURPOSE:
 *      This API is used to set mglag member.
 * INPUT:
 *      unit -- Device unit number
 *      mglag_id -- mglag id
 *      member_cnt -- Member port count
 *      ptr_member -- Member port list
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_setMglagMbr(
    const UI32_T        unit,
    const UI32_T        mglag_id,
    const UI32_T        member_cnt,
    const UI32_T        *ptr_member);

/* FUNCTION NAME:   clx_lag_getMglagMbr
 * PURPOSE:
 *      This API is used to get mglag member.
 * INPUT:
 *      unit -- Device unit number
 *      mglag_id -- mglag id
 *      member_cnt -- Get member port count
 * OUTPUT:
 *      ptr_member -- Member port list
 *      ptr_actual_member_cnt -- Actual member port count
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getMglagMbr(
    const UI32_T        unit,
    const UI32_T        mglag_id,
    const UI32_T        member_cnt,
    UI32_T              *ptr_member,
    UI32_T              *ptr_actual_member_cnt);

/* FUNCTION NAME:   clx_lag_getMglagMbrCnt
 * PURPOSE:
 *      This API is used to get mglag member count.
 * INPUT:
 *      unit -- Device unit number
 *      mglag_id -- mglag id
 * OUTPUT:
 *      ptr_member_cnt -- Member port count
 * RETURN:
 *      CLX_E_OK -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_lag_getMglagMbrCnt(
    const UI32_T        unit,
    const UI32_T        mglag_id,
    UI32_T              *ptr_member_cnt);
#endif  /* End of CLX_LAG_H */
