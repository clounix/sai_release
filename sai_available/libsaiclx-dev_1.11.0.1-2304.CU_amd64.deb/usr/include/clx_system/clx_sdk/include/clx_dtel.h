/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_dtel.h
 * PURPOSE:
 *      It provides DTEL module API.
 *
 * NOTES:
 *
 */


#ifndef CLX_DTEL_H
#define CLX_DTEL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* DPP/IFA Header Format */
typedef struct CLX_DTEL_DPP_HDR_S
{

    UI32_T          probe_mark_1; /* Probe Marker, identify DPP probe as UDP probe or IPv6 extension header porbe */
    UI32_T          probe_mark_2; /* Probe Marker, identify DPP probe as UDP probe or IPv6 extension header porbe */
    UI32_T          probe_mask;   /* Mask for Probe Marker */
    UI32_T          hop_lim;      /* Hop Limit */
    UI32_T          max_len;      /* Telemetry Metadata Maximum Length */
    UI32_T          cur_len;      /* Current Length */
    UI32_T          send_id;      /* Sender's Handle */
    UI32_T          seq_num;      /* Sequence Number */

} CLX_DTEL_DPP_HDR_T;

/* DPP Loopback path information */
typedef struct CLX_DTEL_DPP_S
{
    CLX_IPV4_T          ipv4_addr;       /* IPv4 address */
    CLX_IPV6_T          ipv6_addr;       /* IPv6 address */
    BOOL_T              check_threshold; /* Check hop threshold */
    UI32_T              udp_dp;          /* UDP destination port */
    UI32_T              v6_nhdr;         /* Next-header value of IPv6 ext-Header for DPP encap */
    UI32_T              opq_id;          /* Opaque schema ID */
    UI32_T              dev_id;          /* Device ID */
    CLX_DTEL_DPP_HDR_T  dpp_hdr;         /* DPP Header */
} CLX_DTEL_DPP_T;

/* refers to https://tools.ietf.org/html/draft-ietf-ippm-ioam-data-00 */

/* IOAM-Trace-Type: A 16-bit identifier which specifies which data types are used in this node data list */
typedef enum
{
    CLX_DTEL_IOAM_TRACE_TYPE_HOP_LIM_NODE_ID       = (1UL << 15), /* Bit 0 = Hop limit and node ID */
    CLX_DTEL_IOAM_TRACE_TYPE_IF_ID                 = (1UL << 14), /* Bit 1 = Ingress interface ID and Egress interface ID in short format */
    CLX_DTEL_IOAM_TRACE_TYPE_TS_SEC                = (1UL << 13), /* Bit 2 = Timestamp seconds */
    CLX_DTEL_IOAM_TRACE_TYPE_TS_NSEC               = (1UL << 12), /* Bit 3 = Timestamp nanoseconds */
    CLX_DTEL_IOAM_TRACE_TYPE_TRANS_DELAY           = (1UL << 11), /* Bit 4 = Transit delay */
    CLX_DTEL_IOAM_TRACE_TYPE_APP_DATA              = (1UL << 10), /* Bit 5 = App data */
    CLX_DTEL_IOAM_TRACE_TYPE_QUEUE_DEPTH           = (1UL << 9),  /* Bit 6 = Queue depth */
    CLX_DTEL_IOAM_TRACE_TYPE_OPACK_INFO            = (1UL << 8),  /* Bit 7 = Variable length Opaque State Snapshot field */
    CLX_DTEL_IOAM_TRACE_TYPE_HOP_LIM_NODE_ID_WIDE  = (1UL << 7),  /* Bit 8 = Hop limit and node ID wide */
    CLX_DTEL_IOAM_TRACE_TYPE_IF_ID_WIDE            = (1UL << 6),  /* Bit 9 = Ingress interface ID and Egress interface ID in wide format */
    CLX_DTEL_IOAM_TRACE_TYPE_APP_DATA_WIDE         = (1UL << 5),  /* Bit 10 = App data wide */
    CLX_DTEL_IOAM_TRACE_TYPE_CHKSM                 = (1UL << 4),  /* Bit 11 = Checksum Complement */
} CLX_DTEL_IOAM_TRACE_TYPE_T;

/* Dtel types */
typedef enum
{
    CLX_DTEL_TYPE_NONE,
    CLX_DTEL_TYPE_IOAM,            /* IOAM Initiator */
    CLX_DTEL_TYPE_IOAM_TRANSIT,    /* IOAM Transit */
    CLX_DTEL_TYPE_DPP,             /* DPP Transit */
    CLX_DTEL_TYPE_IFA_LIVE_MODE,   /* IFA Live Mode Initiator */
    CLX_DTEL_TYPE_IFA_SAMPLE_MODE, /* IFA Sample Mode Initiator */
    CLX_DTEL_TYPE_IFA_TRANSIT,     /* IFA Transit */
    CLX_DTEL_TYPE_IFA_TERM,        /* IFA Terminator */
    CLX_DTEL_TYPE_LAST,
} CLX_DTEL_TYPE_T;

/* Dtel Profile Configuration */
typedef struct CLX_DTEL_CFG_S
{
    CLX_DTEL_DPP_HDR_T  ifa_hdr;         /* IFA Header */
    CLX_DTEL_TYPE_T     type;            /* Dtel type */

/*
   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  |        IOAM-Trace-Type        |NodeLen|  Flags  | Max Length  |
  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
    UI32_T              ioam_opt_header; /* Only for IOAM, refer to CLX_DTEL_IOAM_TRACE_TYPE_T */
    UI32_T              ioam_node_len;   /* Node Data Length field in IOAM Incremental Trace Header */
    UI32_T              ioam_flags;      /* Bit 0 (most significant bit) = Overflow, Bit 1 = Loopback */
    UI32_T              ioam_node_id;    /* Current node ID */
    UI32_T              ioam_max_len;    /* Max Length field in IOAM Incremental Trace Header */
    UI32_T              opq_id;          /* Opaque schema ID from current node */
    UI32_T              dev_id;          /* Device ID from current node */
    UI32_T              udp_dp;          /* DPP destination port from sampled UDP */
    UI32_T              ifa_tid;         /* TID field in IFA Metadata */
    UI32_T              ifa_user_defined_0; /* User define field after TID in IFA Metadata */
    UI32_T              ifa_user_defined_1; /* User define field after TTL in IFA Metadata */
    UI32_T              sampling_rate;      /* sFlow sample rate for IOAM/IFA Initiator */
} CLX_DTEL_CFG_T;

/* dtel profile */
/* FUNCTION NAME:   clx_dtel_setProfile
 * PURPOSE:
 *    Set DTEL profile information with IOAM option header and sampling rate.
 *
 * INPUT:
 *    unit                --  Device unit number.
 *    profile_id          --  Profile id.
 *    ptr_cfg             --  DTEL profile config
 * OUTPUT:
 *      None.
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_TABLE_FULL    --  No more handler can be created.
 *    CLX_E_NOT_INITED    --  SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_dtel_setProfile(
    const UI32_T                unit,
    const UI32_T                profile_id,
    const CLX_DTEL_CFG_T        *ptr_cfg);

/* FUNCTION NAME:   clx_dtel_getProfile
 * PURPOSE:
 *    Get DTEL profile information with IOAM option header and sampling rate.
 *
 * INPUT:
 *    unit                --  Device unit number.
 *    profile_id          --  Profile id.
 * OUTPUT:
 *    ptr_cfg             --  DTEL profile config
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_TABLE_FULL    --  No more handler can be created.
 *    CLX_E_NOT_INITED    --  SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_dtel_getProfile(
    const UI32_T                unit,
    const UI32_T                profile_id,
    CLX_DTEL_CFG_T              *ptr_cfg);

/* dpp loopback */
/* FUNCTION NAME:   clx_dtel_setDppLoopback
 * PURPOSE:
 *    Set loopback path information for DPP usage
 *
 * INPUT:
 *    unit                --  Device unit number.
 *    ptr_dpp             --  Loopback path information.
 * OUTPUT:
 *    None.
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_TABLE_FULL    --  No more handler can be created.
 *    CLX_E_NOT_INITED    --  SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_dtel_setDppLoopback(
    const UI32_T                unit,
    const CLX_DTEL_DPP_T        *ptr_dpp);

/* FUNCTION NAME:   clx_dtel_getDppLoopback
 * PURPOSE:
 *    Get loopback path information for DPP usage
 *
 * INPUT:
 *    unit                --  Device unit number.
 * OUTPUT:
 *    ptr_dpp             --  Loopback path information.
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_TABLE_FULL    --  No more handler can be created.
 *    CLX_E_NOT_INITED    --  SDK module has not been initialized.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
clx_dtel_getDppLoopback(
    const UI32_T                unit,
    CLX_DTEL_DPP_T              *ptr_dpp);

#endif  /* End of CLX_DTEL_H */
