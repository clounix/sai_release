#if !defined (__CLXS_OBJECT_H__)
#define __CLXS_OBJECT_H__

/* GLOBAL VARIABLE DECLARATIONS
 */
extern sai_vendor_attribute_entry_t* vendor_attributes[];
extern uint32_t    vendor_attributes_count[];

/*object type capability for stat**/
typedef struct 
{
    const sai_stat_capability_t       *info;
    uint32_t                           count;
} CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T;
    
/* MACRO FUNCTION DECLARATIONS
 */
#define OBJECT_VENDOR_ATTRIBUTE_REGISTER(object_type, attributes)  \
    do { \
        if ((object_type) < SAI_OBJECT_TYPE_MAX)          \
        {\
            vendor_attributes[(object_type)] = (sai_vendor_attribute_entry_t*)(&attributes);             \
            vendor_attributes_count[(object_type)] = sizeof(attributes)/sizeof(sai_vendor_attribute_entry_t);       \
        }\
        else        \
            CLXS_LOG_ERR(__MODULE__, "error object type %d", object_type);       \
    } while(0)

/* API DECLARATIONS
 */


#endif /* __CLXS_OBJECT_H__ */
