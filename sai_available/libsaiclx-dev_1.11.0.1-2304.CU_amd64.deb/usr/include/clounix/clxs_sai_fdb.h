#if !defined (__CLXS_FDB_H__)
#define __CLXS_FDB_H__

#define MAX_MAC_STR_LEN                 20

extern const sai_fdb_api_t              fdb_api;

/* API DECLARATIONS
 */
sai_status_t
clxs_fdb_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_fdb_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_fdb_registerCallback(
    _In_ const uint32_t unit,
    _In_ void *ptr_func);

sai_status_t
clxs_fdb_addNotifyL2Addr(
    _In_ const uint32_t                    unit,
    _In_ const CLX_L2_ADDR_NOTIFY_REASON_T reason,
    _In_ const CLX_L2_ADDR_T               *ptr_l2_addr);

#endif /* __CLXS_FDB_H__ */
