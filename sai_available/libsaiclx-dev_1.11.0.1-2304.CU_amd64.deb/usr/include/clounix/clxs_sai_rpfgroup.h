#if !defined (__CLXS_RPFGROUP_H__)
#define __CLXS_RPFGROUP_H__

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_rpf_group_api_t        rpfgroup_api;

/* API DECLARATIONS
 */
sai_status_t clxs_rpfgrp_getGrpInfo(
    _In_  sai_object_id_t   obj_id,
    _Out_ uint32_t          *ptr_unit,
    _Out_ CLX_IP_ADDR_T     *ptr_ip,
    _Out_ uint32_t          *ptr_cnt,
    _Out_ uint32_t          *ptr_grp_id);

sai_status_t clxs_rpfgrp_getObjByIp(
    _In_   CLX_IP_ADDR_T    *ptr_ip,
    _In_   uint32_t         unit,
    _Out_  sai_object_id_t  *ptr_obj_id);

sai_status_t clxs_rpfgrp_init(
    const uint32_t    unit);

sai_status_t clxs_rpfgrp_deinit(
    const uint32_t    unit);

sai_status_t clxs_get_rpf_object_count(
    _In_ const uint32_t unit,
    _In_ uint32_t  type,
    _Out_ uint32_t *count);

#endif /* __CLXS_RPFGROUP_H__ */
