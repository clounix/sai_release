#if !defined (__CLXS_MCASTFDB_H__)
#define __CLXS_MCASTFDB_H__

#define CLXS_MAX_MCAST_FDB_NUM           (16384) /* default config */

extern const sai_mcast_fdb_api_t        mcastfdb_api;

sai_status_t
clxs_mcastfdb_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_mcastfdb_deinit(
    _In_ const uint32_t unit);

sai_status_t clxs_get_mcast_fdb_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif
