#if !defined (__CLXS_STP_H__)
#define __CLXS_STP_H__

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_stp_api_t              stp_api;

/* API DECLARATIONS
 */
sai_status_t
clxs_stp_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_stp_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_stp_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_stpid);

sai_status_t
clxs_stp_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_stp_getPortInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_stpid,
    _Out_ uint32_t                  *ptr_bd_port_id);

sai_status_t
clxs_stp_getPortObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             bd_port_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_stp_updateStpVlan(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             vid,
    _In_ const bool                 is_add);

sai_status_t
clxs_stp_updateStpBdid(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             stpid,
    _In_ const uint32_t             bd_port_id,
    _In_ const uint32_t             bdid);

sai_status_t
clxs_get_stp_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_stp_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif /* __CLXS_STP_H__ */
