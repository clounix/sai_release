#if !defined (__CLXS_TUNNEL_H__)
#define __CLXS_TUNNEL_H__

#if SAI_API_VERSION >= SAI_VERSION(1,7,3)
#define CLXS_MAX_TUNNEL_TYPES_NUM SAI_TUNNEL_TYPE_MPLS + 1
#endif

/* MACRO FUNCTION DECLARATIONS
 */
#define CLXS_TUNNEL_QOSMAP_PROF_INDEX_BASE        (CLXS_MAX_PORT_NUM)

#define CLXS_TUNNEL_FOREACH(__unit__, __tunnel__)                              \
    for (__tunnel__ = 0; __tunnel__ < CLXS_MAX_TUNNEL_NUM(__unit__); __tunnel__++)    \

extern const sai_tunnel_api_t           tunnel_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T tunnel_stats_capability_info;
/* API DECLARATIONS
 */
sai_status_t
clxs_tunnel_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_tunnel_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_tunnel_getInfo(
    _In_ const sai_api_t init_caller,
    _In_ const sai_object_id_t tunnel_id,
    _In_ const sai_ip_address_t *ptr_dip,
    _Out_ uint32_t *ptr_unit,
    _Out_ CLX_TUNNEL_KEY_T *ptr_key,
    _Out_ CLX_PORT_T *ptr_port);

sai_status_t
clxs_tunnel_get_tunnel_port_vni(
    _In_ sai_object_id_t tunnel_id,
    _In_ uint32_t vrf_id,
    _In_ sai_ip_address_t ipaddr,
    _Out_ CLX_PORT_T *port,
    _Out_ uint32_t *vni);

sai_status_t
clxs_tunnel_add_nexthop_tunnel(
    UI32_T unit, UI32_T clxs_next_hop_id,
    sai_object_id_t  sai_tunnel_id,
    sai_ip_address_t endpoint_ip, UI32_T tunnel_vni,
    UI32_T vni_configured);

sai_status_t
clxs_tunnel_remove_nexthop_tunnel(
    UI32_T unit, UI32_T clxs_next_hop_id,
    sai_object_id_t sai_tunnel_id,
    sai_ip_address_t endpoint_ip, UI32_T tunnel_vni,
    UI32_T vni_configured);

sai_status_t
clxs_tunnel_update_nexthop_tunnel_vni(
    UI32_T unit, sai_object_id_t sai_tunnel_id,
    UI32_T clxs_next_hop_id, UI32_T tunnel_vni);

sai_status_t
clxs_get_tunnel_portList(
    _In_ const sai_object_id_t tunnel_id,
    _Out_ uint32_t *unit,
    _Out_ CLX_PORT_T port_list[CLX_PORT_NUM],
    _Out_ uint32_t *pcount);

bool clxs_tunnel_is_vxlan(
    _In_ sai_object_id_t tunnel_id);

sai_status_t
clxs_tunnel_port_get_ref_bridge_port(
    _In_ const UI32_T unit,
    _In_ const CLX_PORT_T tunnel_port,
    _Out_ sai_object_id_t* bridge_port_id,
    _Out_ sai_ip_address_t* dst_ip);

sai_status_t
clxs_tunnel_set_ref_bridge_port(
    _In_ const sai_object_id_t tunnel_id,
    _In_ const sai_object_id_t bridge_port_id);

sai_status_t
clxs_tunnel_host_update(
    UI32_T unit,
    CLX_L3_HOST_INFO_T* host_info);

sai_status_t
clxs_tunnel_adj_update(
    UI32_T unit,
    UI32_T l3_adj_id);

sai_status_t
clxs_tunnel_route_update(
    UI32_T unit,
    CLX_L3_ROUTE_INFO_T* route_info);

sai_status_t
clxs_tunnel_ecmp_grp_update(
    UI32_T unit,
    UI32_T ecmp_grp_id,
    BOOL_T add,
    UI32_T adj_id);

sai_status_t
clxs_set_tunnel_portlrn(
    _In_ const uint32_t   unit,
    _In_ const sai_object_id_t tunnel_id,
    _In_ const CLXS_SRV_LRN_MODE_T  mode);

sai_status_t
clxs_get_tunnel_map_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_term_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_tunnel_map_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#if SAI_API_VERSION >= SAI_VERSION(1,7,3)
sai_status_t _clxs_tunnel_get_switch_tunnel_attr(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t switch_tunnel_type,
    _In_  sai_switch_tunnel_attr_t id,
    _Out_ sai_attribute_value_t *ptr_val);
sai_status_t
 _clxs_tunnel_set_switch_tunnel_attr(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t switch_tunnel_type,
    _In_  sai_switch_tunnel_attr_t id,
    _In_  const sai_attribute_value_t *ptr_val);

sai_status_t _clxs_tunnel_create_switch_tunnel(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t tunnel_type,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);

sai_status_t _clxs_tunnel_remove_switch_tunnel(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t tunnel_type);

sai_status_t clxs_tunnel_get_switch_tunnel(
    _In_ UI32_T unit,
    _In_ sai_tunnel_type_t tunnel_type,
    _Out_ sai_object_id_t *ptr_switch_tunnel_id);

sai_status_t clxs_tunnel_set_switch_tunnel(
    _In_ UI32_T unit,
    _In_ sai_object_id_t switch_tunnel_id);
#endif

sai_status_t clxs_create_tunnel(
    _Out_ sai_object_id_t *ptr_tunnel_id,
    _In_ sai_object_id_t switch_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);
sai_status_t clxs_remove_tunnel(
    _In_ sai_object_id_t tunnel_id);
sai_status_t
clxs_set_tunnel_attribute(
    _In_ sai_object_id_t tunnel_id,
    _In_ const sai_attribute_t *ptr_attr);
sai_status_t
clxs_get_tunnel_attribute(
    _In_ sai_object_id_t tunnel_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *ptr_attr_list);

#endif /* __CLXS_TUNNEL_H__ */
