#if !defined (__CLXS_SWITCH_FEATURE_H__)
#define __CLXS_SWITCH_FEATURE_H__

typedef enum
{
    CLXS_FEATURE_ACL_SONIC_BIND,
    CLXS_FEATURE_ADJ_DROP_BY_DELETING_FDB,
    CLXS_FEATURE_BRIDGEPORT_ING_FILTER,
    CLXS_FEATURE_BUM_SONIC_IMPL,
    CLXS_FEATURE_ECC_ERR_LOG,
    CLXS_FEATURE_MAC_MOVE_NOTIFY,
    CLXS_FEATURE_PORT_IP_COUNT_USING_ACL,
    CLXS_FEATURE_PORT_LINK_DELAY,
    CLXS_FEATURE_SHOW_ECMP_PATH,
    CLXS_FEATURE_SWITCH_MONITOR,
    CLXS_FEATURE_RIF_RESOURCE_MODE,
    CLXS_FEATURE_TUNNEL_NOV3_RIF_NUM,
    CLXS_FEATURE_TUNNEL_NOV3_RTE_MAC_NUM,
    CLXS_FEATURE_LAST
}CLXS_FEATURE_TYPE_T;

uint32_t clxs_switch_get_feature(
    _In_ const uint32_t unit,
    _In_ CLXS_FEATURE_TYPE_T feature_type);

CLX_ERROR_NO_T
clxs_switch_getFeatureType(
    _In_ const char *ptr_feature_name,
    _Out_ UI32_T    *ptr_feature_type);

CLX_ERROR_NO_T clxs_switch_feature_dump_cmd(
    _In_ const C8_T                *tokens[]);


#endif /* __CLXS_SWITCH_FEATURE_H__ */