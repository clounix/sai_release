#if !defined (__CLXS_IPSEC_H__)
#define __CLXS_IPSEC_H__

#if SAI_API_VERSION >= SAI_VERSION(1,9,0)
extern const sai_ipsec_api_t   ipsec_api;

/* API DECLARATIONS
 */

#endif
#endif /* __CLXS_IPSEC_H__ */