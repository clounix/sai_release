#if !defined (__CLXS_SAMPLEPACKET_H__)
#define __CLXS_SAMPLEPACKET_H__

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_samplepacket_api_t     samplepacket_api;

/* API DECLARATIONS
 */
sai_status_t clxs_samplepacket_init(
    _In_ uint32_t unit);

sai_status_t clxs_samplepacket_deinit(
    _In_ uint32_t unit);

sai_status_t clxs_samplepacket_getRate(
    _In_ sai_object_id_t samplepacket_id,
    _Out_ uint32_t *ptr_samplepacket_rate);

sai_status_t clxs_samplepacket_getType(
    _In_ sai_object_id_t samplepacket_id,
    _Out_ sai_samplepacket_type_t *ptr_samplepacket_type);

sai_status_t clxs_samplepacket_applySetting(
    _In_ sai_object_id_t obj_id,
    _In_ bool igr,
    _In_ sai_object_id_t cur_samplepacket_id,
    _In_ sai_object_id_t new_samplepacket_id);

sai_status_t clxs_get_samplepacket_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif /* __CLXS_SAMPLEPACKET_H__ */
