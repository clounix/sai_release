#if !defined (__CLXS_HOSTIF_H__)
#define __CLXS_HOSTIF_H__

#define CLXS_HOSTIF_MAX_NUM_OF_HIF  (512)
#define CLXS_HOSTIF_MAX_NUM_OF_HIF_TABLE                     (4096)  /* hostif_table_entry */
#define CLXS_HOSTIF_MAX_TRAP_GROUPS (48)
#define CLXS_HOSTIF_REGULAR_TRAP_SUPPORTED_NUM               (32)    /* hostif_trap */
#define CLXS_HOSTIF_UDF_TRAP_SUPPORTED_NUM       (4)
#if 0
#define CLXS_SAI_HOSTIF_MAX_NUM_OF_HIF  (512)
#define CLXS_SAI_HOSTIF_MAX_NUM_OF_HIF_TABLE                     (4096)  /* hostif_table_entry */
#define CLXS_SAI_HOSTIF_MAX_TRAP_GROUPS (48)
#define CLXS_SAI_HOSTIF_REGULAR_TRAP_SUPPORTED_NUM               (32)    /* hostif_trap */
#define CLXS_HOSTIF_UDF_TRAP_SUPPORTED_NUM       (4)
#endif
extern const sai_hostif_api_t           hostif_api;

sai_status_t
clxs_hostif_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_hostif_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_hostif_getDefaultTrapGroupOid(
    _In_ const uint32_t         unit,
    _Out_ sai_object_id_t       *ptr_trap_group_oid);


sai_status_t clxs_get_hostif_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_trap_group_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_trap_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_hostif_table_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

void clxs_hostif_arp_nd_action_modify(
    _In_ uint32_t unit,
    _In_ bool modify_en,
    _In_ bool is_arp);

sai_status_t
clxs_hostif_setNetIfSampleRate(
    _In_ const sai_object_id_t      obj_id,
    _In_ const bool                 is_ingress,
    _In_ const uint32_t             sample_rate);

#endif
