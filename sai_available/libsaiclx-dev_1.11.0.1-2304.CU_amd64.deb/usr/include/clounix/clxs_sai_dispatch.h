#if !defined (__CLXS_DISPATCH_H__)
#define __CLXS_DISPATCH_H__

#define END_FUNCTIONALITY_ATTRIBS_ID    0xFFFFFFFF

typedef enum _clxs_api_t
{
    CLXS_API_START      = SAI_API_MAX,
    CLXS_API_LIB         = CLXS_API_START,
    CLXS_API_DIAG,
    CLXS_SAI_API_TAM_INT,
    CLXS_API_MONITOR,
    CLXS_API_ECC,
    CLXS_API_OID,
    CLXS_API_OSAL,
    CLXS_API_LOG,
    CLXS_API_WARMBOOT,
    CLXS_API_DISPATCH,
    CLXS_API_MAX
}clxs_api_t;

/*
 *  SAI operation type
 *  Values must start with 0 base and be without gaps
 */
typedef enum sai_operation_t {
    SAI_OPERATION_CREATE,
    SAI_OPERATION_REMOVE,
    SAI_OPERATION_SET,
    SAI_OPERATION_GET,
    SAI_OPERATION_MAX
} sai_operation_t;

/*
 *  Attribute value types
 */
typedef enum _sai_attribute_value_type_t {
    SAI_ATTR_VAL_TYPE_UNDETERMINED,
    SAI_ATTR_VAL_TYPE_BOOL,
    SAI_ATTR_VAL_TYPE_CHARDATA,
    SAI_ATTR_VAL_TYPE_U8,
    SAI_ATTR_VAL_TYPE_S8,
    SAI_ATTR_VAL_TYPE_U16,
    SAI_ATTR_VAL_TYPE_S16,
    SAI_ATTR_VAL_TYPE_U32,
    SAI_ATTR_VAL_TYPE_S32,
    SAI_ATTR_VAL_TYPE_U64,
    SAI_ATTR_VAL_TYPE_S64,
    SAI_ATTR_VAL_TYPE_MAC,
    SAI_ATTR_VAL_TYPE_IPV4,
    SAI_ATTR_VAL_TYPE_IPV6,
    SAI_ATTR_VAL_TYPE_IPADDR,
    SAI_ATTR_VAL_TYPE_OID,
    SAI_ATTR_VAL_TYPE_OBJLIST,
    SAI_ATTR_VAL_TYPE_U8LIST,
    SAI_ATTR_VAL_TYPE_S8LIST,
    SAI_ATTR_VAL_TYPE_U16LIST,
    SAI_ATTR_VAL_TYPE_S16LIST,
    SAI_ATTR_VAL_TYPE_U32LIST,
    SAI_ATTR_VAL_TYPE_S32LIST,
    SAI_ATTR_VAL_TYPE_U32RANGE,
    SAI_ATTR_VAL_TYPE_S32RANGE,
    SAI_ATTR_VAL_TYPE_MAPLIST,
    SAI_ATTR_VAL_TYPE_VLANLIST,
    SAI_ATTR_VAL_TYPE_QOSMAP,
    SAI_ATTR_VAL_TYPE_TUNNELMAP,
    SAI_ATTR_VAL_TYPE_ACLFIELD_BOOLDATA,
    SAI_ATTR_VAL_TYPE_ACLFIELD_U8,
    SAI_ATTR_VAL_TYPE_ACLFIELD_S8,
    SAI_ATTR_VAL_TYPE_ACLFIELD_U16,
    SAI_ATTR_VAL_TYPE_ACLFIELD_S16,
    SAI_ATTR_VAL_TYPE_ACLFIELD_U32,
    SAI_ATTR_VAL_TYPE_ACLFIELD_S32,
    SAI_ATTR_VAL_TYPE_ACLFIELD_MAC,
    SAI_ATTR_VAL_TYPE_ACLFIELD_IPV4,
    SAI_ATTR_VAL_TYPE_ACLFIELD_IPV6,
    SAI_ATTR_VAL_TYPE_ACLFIELD_OID,
    SAI_ATTR_VAL_TYPE_ACLFIELD_OBJLIST,
    SAI_ATTR_VAL_TYPE_ACLFIELD_U8LIST,
    SAI_ATTR_VAL_TYPE_ACLACTION_U8,
    SAI_ATTR_VAL_TYPE_ACLACTION_S8,
    SAI_ATTR_VAL_TYPE_ACLACTION_U16,
    SAI_ATTR_VAL_TYPE_ACLACTION_S16,
    SAI_ATTR_VAL_TYPE_ACLACTION_U32,
    SAI_ATTR_VAL_TYPE_ACLACTION_S32,
    SAI_ATTR_VAL_TYPE_ACLACTION_MAC,
    SAI_ATTR_VAL_TYPE_ACLACTION_IPV4,
    SAI_ATTR_VAL_TYPE_ACLACTION_IPV6,
    SAI_ATTR_VAL_TYPE_ACLACTION_OID,
    SAI_ATTR_VAL_TYPE_ACLACTION_OBJLIST,
    SAI_ATTR_VAL_TYPE_ACLACTION_NONE,
    SAI_ATTR_VAL_TYPE_ACLCAPABILITY,
    SAI_ATTR_VALUE_TYPE_ACL_RESOURCE_LIST,
    SAI_ATTR_VALUE_TYPE_TLV_LIST,
    SAI_ATTR_VALUE_TYPE_SEGMENT_LIST,
    SAI_ATTR_VALUE_TYPE_IP_ADDRESS_LIST,
    SAI_ATTR_VALUE_TYPE_PORT_EYE_VALUES_LIST,
    SAI_ATTR_VALUE_TYPE_TIMESPEC,
    SAI_ATTR_VALUE_TYPE_OUTSEG,
    SAI_ATTR_VALUE_TYPE_OUTSEG_TTL,
    SAI_ATTR_VALUE_TYPE_OUTSEG_EXP,
    SAI_ATTR_VALUE_TYPE_SYSTEM_PORT_CONFIG_LIST,
    SAI_ATTR_VALUE_TYPE_PORT_ERR_STATUS_LIST,
    SAI_ATTR_VALUE_TYPE_PORT_LANE_LATCH_STATUS_LIST,
    SAI_ATTR_VALUE_TYPE_LATCH_STATUS,
    SAI_ATTR_VALUE_TYPE_FABRIC_PORT_REACHABILITY
} sai_attribute_value_type_t;

/*
 *  SAI module bulk function
 *  
 */
typedef enum _sai_module_bulk_function_t {
    SAI_NEIGHBOR_BULK_CREATE,
    SAI_NEIGHBOR_BULK_REMOVE,
    SAI_NEIGHBOR_BULK_SET,
    SAI_NEIGHBOR_BULK_GET,
    SAI_NHGROUP_MEMBER_BULK_SET,
    SAI_NHGROUP_MEMBER_BULK_GET,
    SAI_PORT_BULK_CREATE,
    SAI_PORT_BULK_REMOVE,
    SAI_PORT_BULK_SET,
    SAI_PORT_BULK_GET,
    SAI_TUNNEL_BULK_CREATE,
    SAI_TUNNEL_BULK_REMOVE,
    SAI_TUNNEL_BULK_SET,
    SAI_TUNNEL_BULK_GET,
    SAI_MODULE_BULK_END
} sai_module_bulk_function_t;

typedef struct _sai_attribute_entry_t {
    sai_attr_id_t              id;
    bool                       mandatory_on_create;
    bool                       valid_for_create;
    bool                       valid_for_set;
    bool                       valid_for_get;
    const char                *attrib_name;
    sai_attribute_value_type_t type;
} sai_attribute_entry_t;

typedef sai_status_t (*sai_attribute_set_fn)(
    _In_ const sai_object_key_t *key,
    _In_ const sai_attribute_value_t *value,
         void *arg);

typedef union {
    int dummy;
} vendor_cache_t;

typedef sai_status_t (*sai_attribute_get_fn)(
    _In_ const sai_object_key_t *key,
    _Inout_ sai_attribute_value_t *value,
    _In_ uint32_t attr_index, _Inout_ vendor_cache_t *cache, void *arg);

typedef struct _sai_vendor_attribute_entry_t {
    sai_attr_id_t        id;
    bool                 is_implemented[SAI_OPERATION_MAX];
    bool                 is_supported[SAI_OPERATION_MAX];
    sai_attribute_get_fn getter;
    void                *getter_arg;
    sai_attribute_set_fn setter;
    void                *setter_arg;
} sai_vendor_attribute_entry_t;

extern const sai_status_t               ext_clx_status_to_sai_map[CLX_E_LAST];
extern const char*                      ext_sai_type_to_str_map[SAI_OBJECT_TYPE_MAX];
extern const C8_T *clxs_switch_module_str_list[CLXS_API_MAX];

 #define SAI_TYPE_STR(__type__)     \
    ({int t = (__type__); t< SAI_OBJECT_TYPE_MAX ? ext_sai_type_to_str_map[t] : "Unknown object type";})
#define CLXS_STATUS_TO_SAI(__rc__)  \
    ({CLX_ERROR_NO_T tmp = (__rc__); ((tmp < CLX_E_LAST) ? ext_clx_status_to_sai_map[tmp] : CLX_E_LAST);})

#define MODULE_NAME(module)  clxs_switch_module_str_list[module]

/* API DECLARATIONS
 */
sai_status_t
_find_functionality_attrib_index(
    const sai_attr_id_t             id,
    const sai_attribute_entry_t     *ptr_functionality_attr,
    uint32_t                        *ptr_index);

sai_status_t
clxs_check_attribs_metadata(
    _In_ uint32_t                            attr_count,
    _In_ const sai_attribute_t               *attr_list,
    _In_ const sai_attribute_entry_t         *functionality_attr,
    _In_ const sai_vendor_attribute_entry_t  *functionality_vendor_attr,
    _In_ sai_operation_t                     oper);

sai_status_t
clxs_find_attrib_in_list(
    _In_ uint32_t                       attr_count,
    _In_ const sai_attribute_t          *attr_list,
    _In_ sai_attr_id_t                  attrib_id,
    _Out_ const sai_attribute_value_t   **attr_value,
    _Out_ uint32_t                      *index);

sai_status_t
clxs_sai_set_attribute(
    _In_ const sai_object_key_t              *key,
    _In_ const char                          *key_str,
    _In_ const sai_attribute_entry_t         *functionality_attr,
    _In_ const sai_vendor_attribute_entry_t  *functionality_vendor_attr,
    _In_ const sai_attribute_t               *attr);

sai_status_t
clxs_sai_get_attributes(
    _In_ const sai_object_key_t              *key,
    _In_ const char                          *key_str,
    _In_ const sai_attribute_entry_t         *functionality_attr,
    _In_ const sai_vendor_attribute_entry_t  *functionality_vendor_attr,
    _In_ uint32_t                            attr_count,
    _Inout_ sai_attribute_t                  *attr_list);

sai_status_t
clxs_check_bulk_attrs_validate(
    _In_ uint32_t                 object_count,
    _In_ const uint32_t          *attr_count,
    _In_ const sai_attribute_t  **attr_list_for_create, sai_attribute_t **attr_list_for_get,
    _In_ const sai_attribute_t   *attr_list_for_set,
    _In_ sai_bulk_op_error_mode_t mode,
    _In_ sai_status_t            *object_statuses,
    _In_ sai_common_api_t         api,
    _Out_ bool                   *stop_on_error);

sai_status_t
clxs_sai_value_to_str(
    _In_ sai_attribute_value_t      value,
    _In_ sai_attribute_value_type_t type,
    _In_ uint32_t                   max_length,
    _Out_ char                      *value_str);

sai_status_t
clxs_sai_attr_list_to_str(
    _In_ uint32_t                     attr_count,
    _In_ const sai_attribute_t        *attr_list,
    _In_ const sai_attribute_entry_t  *functionality_attr,
    _In_ uint32_t                     max_length,
    _Out_ char                        *list_str);

sai_status_t
clxs_sai_attr_value_to_str(
    _In_ const sai_attr_id_t            id,
    _In_ const sai_attribute_value_t    *ptr_value,
    _In_ const sai_attribute_entry_t    *pfunctionality_attr,
    _In_ uint32_t                       max_length,
    _Out_ char                          *ptr_list_str);


sai_status_t clxs_sai_bulk_operation
(
    sai_module_bulk_function_t  module_operation,
    uint32_t                    object_count,
    sai_bulk_op_error_mode_t    mode,
    sai_status_t *              object_statuses,
    ...
);

#endif /* __CLXS_BRIDGE_H__ */
