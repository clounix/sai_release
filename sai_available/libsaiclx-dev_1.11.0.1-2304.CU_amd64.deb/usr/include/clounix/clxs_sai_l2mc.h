#if !defined (__CLXS_L2MC_H__)
#define __CLXS_L2MC_H__

extern const sai_l2mc_api_t             l2mc_api;

/* API DECLARATIONS
 */
sai_status_t
clxs_l2mc_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_l2mc_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_get_l2mc_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif /* __CLXS_L2MC_H__ */
