#if !defined (__CLXS_L2MCGROUP_H__)
#define __CLXS_L2MCGROUP_H__

extern const sai_l2mc_group_api_t       l2mcgroup_api;

sai_status_t
clxs_l2mcgrp_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_l2mcgrp_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_l2mcgrp_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_mcast_id);

sai_status_t
clxs_l2mcgrp_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             mcast_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_l2mcgrp_addMcastBdPortId(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             mcast_id,
    _In_ const uint32_t             bdid,
    _In_ const uint32_t             bd_port_id,
    _In_ const uint32_t             flags);


sai_status_t
clxs_l2mcgrp_delMcastBdPortId(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             mcast_id,
    _In_ const uint32_t             vid,
    _In_ const uint32_t             bd_port_id,
    _In_ const uint32_t             flags);

sai_status_t
clxs_l2mcgrp_addMcastMbrPort(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  mcast_id,
    _In_ const CLXS_BRIDGE_PORT_INFO_T    *ptr_port_info,
    _In_ const CLX_BRIDGE_DOMAIN_T       bdid,
    _In_ const uint32_t                  flags);

sai_status_t
clxs_l2mcgrp_delMcastMbrPort(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  mcast_id,
    _In_ const CLXS_BRIDGE_PORT_INFO_T    *ptr_port_info,
    _In_ const CLX_BRIDGE_DOMAIN_T       bdid,
    _In_ const uint32_t          flags);
#endif
