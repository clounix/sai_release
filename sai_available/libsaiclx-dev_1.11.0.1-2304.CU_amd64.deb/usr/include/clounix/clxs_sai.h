#if !defined (__CLXS_SAI_H__)
#define __CLXS_SAI_H__

#include <clxs_sai_version.h>
#ifndef CLXS_SAI_HEAD_VERSION
#define CLXS_SAI_HEAD_VERSION                 "1.7.1"
#endif

#ifndef SAI_VERSION
#define SAI_VERSION(major, minor, revision) (10000 * (major) + 100 * (minor) + (revision))
#endif

#ifndef SAI_API_VERSION
/* SAI_MAJOR, SAI_MINOR, SAI_REVISION is defined in clxs_sai_version.h when SAI VERSION < 1.8.0 */
#define SAI_API_VERSION SAI_VERSION(SAI_MAJOR, SAI_MINOR, SAI_REVISION)
#endif

#include <sai.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>
#include <stdarg.h>
#include <assert.h>
#include <inttypes.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <clxs_sdk.h>
#include <shal/shal.h>
#include <clxs_sai_dispatch.h>
#include <clxs_sai_lib.h>
#include <clxs_sai_osal.h>
#include <clxs_sai_log.h>
#include <clxs_sai_warmboot.h>
#include <clxs_sai_switch_feature.h>
#include <clxs_sai_oid.h>
#include <clxs_sai_object.h>
#include <clxs_sai_port.h>
#include <clxs_sai_switch.h>
#include <clxs_sai_bridge.h>
#include <clxs_sai_vlan.h>
#include <clxs_sai_fdb.h>
#include <clxs_sai_lag.h>
#include <clxs_sai_l2mc.h>
#include <clxs_sai_nexthop.h>
#include <clxs_sai_nexthopgroup.h>
#include <clxs_sai_policer.h>
#include <clxs_sai_qosmap.h>
#include <clxs_sai_queue.h>
#include <clxs_sai_route.h>
#include <clxs_sai_routerinterface.h>
#include <clxs_sai_rpfgroup.h>
#include <clxs_sai_samplepacket.h>
#include <clxs_sai_scheduler.h>
#include <clxs_sai_schedulergroup.h>
#include <clxs_sai_stp.h>
#include <clxs_sai_tunnel.h>
#include <clxs_sai_udf.h>
#include <clxs_sai_wred.h>
#include <clxs_sai_virtualrouter.h>
#include <clxs_sai_switch_capacity.h>
#include <clxs_sai_acl.h>
#include <clxs_pkt_rx.h>
#include <clxs_sai_buffer.h>
#include <clxs_sai_counter.h>
#include <clxs_sai_debugcounter.h>
#include <clxs_sai_hash.h>
#include <clxs_sai_hostif.h>
#include <clxs_sai_ipmc.h>
#include <clxs_sai_ipmcgroup.h>
#include <clxs_sai_isolationgroup.h>
#include <clxs_sai_l2mcgroup.h>
#include <clxs_sai_mcastfdb.h>
#include <clxs_sai_mirror.h>
#include <clxs_sai_neighbor.h>
#include <clxs_sai_mpls.h>
#include <clxs_sai_segmentroute.h>
#include <clxs_sai_dtel.h>
#include <clxs_sai_bfd.h>
#include <clxs_sai_nat.h>
#include <clxs_sai_macsec.h>
#include <clxs_sai_systemport.h>
#include <clxs_sai_monitor.h>
#if SAI_API_VERSION >= SAI_VERSION(1,9,0)
#include <clxs_sai_ipsec.h>
#include <clxs_sai_mymac.h>
#include <clxs_sai_srv6.h>
#endif
#if SAI_API_VERSION >= SAI_VERSION(1,11,0)
#include <clxs_sai_genericprogrammable.h>
#endif
#include <clxs_sai_tam_int.h>
#include <clxs_sai_tam.h>
#include <clxs_ecc.h>
#include <clxs_diag.h>

#include <parser/dsh_parser.h>
#include <parser/dsh_util.h>

extern sai_service_method_table_t       g_services;

#endif /* __CLXS_SAI_H__ */
