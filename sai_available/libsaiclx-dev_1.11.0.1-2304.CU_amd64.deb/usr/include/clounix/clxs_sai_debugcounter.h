#if !defined (__CLXS_DEBUGCOUNTER_H__)
#define __CLXS_DEBUGCOUNTER_H__

#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)

extern const sai_debug_counter_api_t debug_counter_api;

sai_status_t
clxs_debug_counter_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_debug_counter_deinit(
    _In_ const uint32_t         unit);
#endif
#endif
