#if !defined (__CLXS_PORT_ECMP_MEMBER_TRACER_H__)
#define __CLXS_PORT_ECMP_MEMBER_TRACER_H__

#if SAI_API_VERSION >= SAI_VERSION(1,7,0)
#ifdef CLX_SHOW_ECMP_PATH_EN

/*  ecmp path data init */
#define CLXS_ECMP_PATH_L4_SRC_PORT_DEFAULT  (1)
#define CLXS_ECMP_PATH_L4_DST_PORT_DEFAULT  (0x3f)
#define CLXS_ECMP_PATH_IP_PROTOCOL_DEFAULT  (0x11)
#define CLXS_ECMP_PATH_SRC_IPv4_DEFAULT     (0x0b010001) /* '11.1.0.1 */
#define CLXS_ECMP_PATH_DST_IPv4_DEFAULT     (0x64010101) /* '100.1.1.1 */
#define CLXS_ECMP_PATH_INVALID_NET_IF_PROFILE_ID (0xffffffff)
#define CLXS_ECMP_PATH_ATTR_COUNT           (6)

/* ECMP PATH pkt format TCP/UDP over IPv4 */
#define ECMP_PATH_PKT_TX_WAIT_TIMEOUT      (2 * 1000)  /* 2ms */
#define ECMP_PATH_PKT_INVALID_IGR_PHY_PORT (0xffffffff)
#define ECMP_PATH_PKT_INVALID_EGR_PHY_PORT (0xffffffff)
#define ECMP_PATH_PKT_SEND_LEN          (80)
#define ECMP_PATH_PKT_OFFSET_DST_MAC    (0)
#define ECMP_PATH_PKT_OFFSET_SRC_MAC    (6)
#define ECMP_PATH_PKT_OFFSET_L3_START   (14)
#define ECMP_PATH_PKT_OFFSET_PROTOCOL   (23)
#define ECMP_PATH_PKT_OFFSET_HDR_CHKSM  (24)
#define ECMP_PATH_PKT_OFFSET_SRC_IP     (26)
#define ECMP_PATH_PKT_OFFSET_DST_IP     (30)
#define ECMP_PATH_PKT_OFFSET_SRC_PORT  (34)
#define ECMP_PATH_PKT_OFFSET_DST_PORT  (36)
#define ECMP_PATH_PKT_OFFSET_UDP_LEN   (38)
#define ECMP_PATH_PKT_OFFSET_MSG_TYPE  (42)
#define ECMP_PATH_PKT_OFFSET_MSG_LEN   (44)
#define ECMP_PATH_PKT_IP4_L3_HD_LEN    (20)
#define ECMP_PATH_PKT_IP6_L3_HD_LEN    (40)
#define ECMP_PATH_PKT_IP6_OFFSET_SRC_IP    (22)
#define ECMP_PATH_PKT_IP6_OFFSET_DST_IP    (38)
#define ECMP_PATH_PKT_IP6_OFFSET_PROTOCOL  (20)
#define ECMP_PATH_PKT_IP6_OFFSET_SRC_PORT  (54)
#define ECMP_PATH_PKT_IP6_OFFSET_DST_PORT  (56)

#define CLXS_ECMP_PATH_CHECK_RC(__rc__) do  \
    {                                       \
        CLX_ERROR_NO_T  __rc = (__rc__);    \
        if (CLX_E_OK != __rc)               \
        {                                   \
            return CLXS_STATUS_TO_SAI(__rc);\
        }                                   \
    } while(0)

/* ecmp hash acl info structure */
#define CLXS_ECMP_HASH_ACL_INVALID_ENTRY_ID   0xffffffff
#define CLXS_ECMP_HASH_ACL_INVALID_TABLE_ID   0xffffffff
#define SAI_SWITCH_INGRESS_ACL_INFO_INIT(info) \
    info.ingEntryId            = CLXS_ECMP_HASH_ACL_INVALID_ENTRY_ID;\
    info.ingCounterId          = CLXS_ECMP_HASH_ACL_INVALID_ENTRY_ID;\
    info.ingGroupId            = CLXS_ECMP_HASH_ACL_INVALID_TABLE_ID;

#define SAI_SWITCH_EGRESS_ACL_INFO_INIT(info)   \
    uint32_t port;                              \
    for (port = 0; port < CLX_PORT_NUM; port++) \
    {                                           \
        info.egrAclInfo[port].egrIP4EntryId   = CLXS_ECMP_HASH_ACL_INVALID_ENTRY_ID;\
        info.egrAclInfo[port].egrIP4CounterId = CLXS_ECMP_HASH_ACL_INVALID_ENTRY_ID;\
        info.egrAclInfo[port].egrIP6EntryId   = CLXS_ECMP_HASH_ACL_INVALID_ENTRY_ID;\
        info.egrAclInfo[port].egrIP6CounterId = CLXS_ECMP_HASH_ACL_INVALID_ENTRY_ID;\
    }

#define CLXS_ECMP_HASH_INGRESS_ACL_GROUP_LABEL      0x6f
#define CLXS_ECMP_HASH_INGRESS_ACL_GROUP_LABEL_MASK 0xffffffff

#define CLXS_ACL_INGRESS_GROUP_PRIO_ECMP_PATH       (7)
#define CLXS_ACL_EGRESS_GROUP_PRIO_ECMP_PATH       (1)

typedef enum
{
    CLXS_ATTR_ECMP_PATH_OUT_PORT_GET,
    CLXS_ATTR_ECMP_PATH_MAX
}_CLXS_GET_ATTR_PREFER_PROCESS_E;

typedef sai_status_t
(*clxs_get_switch_attribute_prefer_callback_fn)(
    _In_ const uint32_t         unit,
    _In_       uint32_t         port,
    _In_       uint32_t         attr_count,
    _Inout_    sai_attribute_t *attr_list,
    _Out_      bool            *bTerminal);

typedef struct CLXS_SWITCH_ECMP_PATH_ING_ACL_INFO_S
{
    uint32_t ingEntryId;          /* Ingress acl entry id    */
    uint32_t ingCounterId;        /* Ingress acl counter id  */
    uint32_t ingGroupId;          /* Ingress acl table id  */
}CLXS_SWITCH_ECMP_PATH_ING_ACL_INFO_T;

typedef struct CLXS_SWITCH_ECMP_PATH_EGR_ACL_INFO_S
{
    uint32_t egrIP4EntryId;       /* Egress acl entry id     */
    uint32_t egrIP4CounterId;     /* Egress acl counter id   */
    uint32_t egrIP6EntryId;       /* Egress acl entry id     */
    uint32_t egrIP6CounterId;     /* Egress acl counter id   */
}CLXS_SWITCH_ECMP_PATH_EGR_ACL_INFO_T;

typedef struct CLXS_SWITCH_ECMP_PATH_ACL_INFO_S
{
    CLXS_SWITCH_ECMP_PATH_ING_ACL_INFO_T    ingAclInfo;
    CLXS_SWITCH_ECMP_PATH_EGR_ACL_INFO_T    egrAclInfo[CLX_PORT_NUM];
}CLXS_SWITCH_ECMP_PATH_ACL_INFO_T;

typedef struct CLXS_SW_ECMP_PATH_PKT_INFO_S
{
    CLX_MAC_T  src_mac_addr;      /* ipv4/ipv6 Switch src mac addr */
    CLX_MAC_T  dst_mac_addr;      /* ipv4/ipv6 Switch dst mac addr */
    CLX_IP_T   srcIP;             /* ipv4/ipv6 Switch ecmp_path srcIP */
    CLX_IP_T   dstIP;             /* ipv4/ipv6 Switch ecmp_path dstIP */
    uint8_t    protocol;          /* ipv4/ipv6 Protocol type */
    uint16_t   srcPort;           /* ipv4/ipv6 Switch ecmp_path l4 src port */
    uint16_t   dstPort;           /* ipv4/ipv6 Switch ecmp_path l4 dst port */
    uint32_t   igr_phy_port;      /* ipv4/ipv6 Switch ecmp_path ingress physical port */
    uint32_t   egr_phy_port;      /* ipv4/ipv6 Switch ecmp_path egress physical port */
    bool       bIPv6;             /* check if run show egress-port ipv4/ipv6 ecmp cli */
}CLXS_SW_ECMP_PATH_PKT_INFO_T;

typedef struct CLXS_SW_ECMP_PATH_RES_S
{
    UI32_T             netif_prof_id;             /*  ecmp path netif profile prof_id */
    CLXS_SWITCH_ECMP_PATH_ACL_INFO_T aclinfo; /* Ingress and Egress acl entry info */
}CLXS_SW_ECMP_PATH_RES_T;

extern clxs_get_switch_attribute_prefer_callback_fn _clxs_getAttrPreCallbackList[CLXS_ATTR_ECMP_PATH_MAX];

/* =========ecmp path info structure, include pkt info and res info========= */
typedef struct CLXS_SW_ECMP_PATH_S
{
    CLXS_SW_ECMP_PATH_PKT_INFO_T pktInfo;
    CLXS_SW_ECMP_PATH_RES_T      res;
}CLXS_SW_ECMP_PATH_T;

extern CLXS_SW_ECMP_PATH_T _clxs_sw_ecmp_path_cb[CLXS_MAX_CHIP_NUM];
/* ECMP PATH pkt format TCP/UDP over IPv6/IPv4 */
#define CLXS_SW_ECMP_PATH_PKT_INFO(unit)           (_clxs_sw_ecmp_path_cb[unit].pktInfo)
#define CLXS_SW_ECMP_PATH_NETIF_PROF_ID(unit)      (_clxs_sw_ecmp_path_cb[unit].res.netif_prof_id)
#define CLXS_SW_ECMP_PATH_ACL_RES(unit)            (_clxs_sw_ecmp_path_cb[unit].res.aclinfo)
#define CLXS_SW_ECMP_PATH_ING_ACL_RES(unit)        (_clxs_sw_ecmp_path_cb[unit].res.aclinfo.ingAclInfo)
#define CLXS_SW_ECMP_PATH_EGR_ACL_RES(unit, port)  (_clxs_sw_ecmp_path_cb[unit].res.aclinfo.egrAclInfo[port])

extern bool
clxs_ecmp_path_rx_callback(
    _In_ const UI32_T            unit,
    _In_ const CLX_PKT_RX_PKT_T *ptr_pkt);

sai_status_t
clxs_ecmp_path_get_info(
    _In_ uint32_t unit,
    _In_ long  attr_id,
    _Inout_ sai_attribute_value_t  *ptr_value);

void clxs_switch_ecmp_path_egr_acl_delete(
    _In_ const uint32_t unit);

CLX_ERROR_NO_T clxs_switch_ecmp_path_egr_acl_create(
    _In_  const uint32_t unit);


#endif /*CLX_SHOW_ECMP_PATH_EN*/
#endif /*SAI_API_VERSION*/

#endif /*__CLXS_PORT_ECMP_MEMBER_TRACER_H__*/