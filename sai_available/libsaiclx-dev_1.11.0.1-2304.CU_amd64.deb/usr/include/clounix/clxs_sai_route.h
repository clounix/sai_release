#if !defined (__CLXS_ROUTE_H__)
#define __CLXS_ROUTE_H__

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_route_api_t            route_api;

/* API DECLARATIONS
 */
sai_status_t clxs_route_init(
    const uint32_t    unit);

sai_status_t clxs_route_deinit(
    const uint32_t    unit);

bool is_route_directed(CLX_L3_ROUTE_INFO_T * ptr_route_info);

bool clxs_route_check_interface(UI32_T unit, UI32_T vrf_id, sai_ip_prefix_t* prefix, UI32_T intf_id);

sai_status_t clxs_route_match_get(
    _In_ const UI32_T    unit,
    _In_ const UI32_T    vrf_id,
    _In_ sai_ip_address_t   ip_addr,
    _Out_  CLX_L3_ROUTE_INFO_T* route_info);

sai_status_t clxs_route_get_used_route_num(
    _In_ sai_object_id_t switch_id,
    _Out_ uint32_t *count);

CLX_ERROR_NO_T clxs_route_dbg_show_route_oper(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clxs_route_dbg_clear_route_oper(
    _In_ const C8_T                *tokens[]);

sai_status_t
clxs_route_get_available_route_num(
    _In_ sai_object_id_t   switch_id,
    _In_ BOOL_T            is_ipv6,
    _Out_ uint32_t         *count);

#endif /* __CLXS_ROUTE_H__ */
