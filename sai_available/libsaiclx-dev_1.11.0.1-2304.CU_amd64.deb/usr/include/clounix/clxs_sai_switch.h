#if !defined (__CLXS_SWITCH_H__)
#define __CLXS_SWITCH_H__

/* GLOBAL VARIABLE DECLARATIONS
 */

#define SAI_COLD_BOOT               0
#define SAI_WARM_BOOT               1
#define SAI_FAST_BOOT               2

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    _CLXS_SWITCH_MAC = 0,
    _CLXS_DEFAULT_VXLAN_ROUTER_MAC
}SWITCH_MAC_TYPE;

typedef enum
{
    CLX_CFG_TYPE_EXTEND_DIAG_LOG_SEVERITY = CLX_CFG_TYPE_LAST + 1,
    CLX_CFG_TYPE_PORT_BREAKOUT_LANE_NUM_MAX,
    CLX_CFG_TYPE_EXTEND_SDK_LOG_SEVERITY,

    CLX_CFG_TYPE_EXTEND_LAST
}CLX_CFG_TYPE_EXTEND_T;

typedef sai_status_t (*SAI_MODULE_BACKUP_FUNC)(
    _In_ const uint32_t unit,
    _Out_ uint32_t* module_length,
    _Out_ void** module_data);

extern BOOL_T                           clxs_schedule_legacy;
extern const sai_switch_api_t           switch_api;
extern SAI_MODULE_BACKUP_FUNC           sai_module_backer[CLXS_API_MAX];
extern CLX_SEMAPHORE_ID_T               clxs_tm_mutex[CLXS_MAX_CHIP_NUM];
extern CLX_SEMAPHORE_ID_T               clxs_db_mutex[CLXS_MAX_CHIP_NUM];
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T switch_stats_capability_info;

#define SAI_REGISTER_WARM_BACKER(func)   do { sai_module_backer[__MODULE__] = func; } while (0)
#define SAI_IS_WARM_BOOT(unit)  (get_fake_warm_reboot() || clxs_switch_getBootType(unit) == SAI_WARM_BOOT)
#define SAI_IS_FAST_BOOT(unit)  (clxs_switch_getBootType(unit) == SAI_FAST_BOOT)
#define SAI_IS_WARM_DEINIT(unit)  clxs_switch_getDeinitType(unit)

#define CLXS_TM_LOCK(unit)          sai_osal_mutex_lock(clxs_tm_mutex[unit])
#define CLXS_TM_UNLOCK(unit)        sai_osal_mutex_unlock(clxs_tm_mutex[unit])
#define CLXS_DB_LOCK(unit)          sai_osal_mutex_lock(clxs_db_mutex[unit])
#define CLXS_DB_UNLOCK(unit)        sai_osal_mutex_unlock(clxs_db_mutex[unit])

/* API DECLARATIONS
 */
#if defined(CLXS_USE_CMODEL)
extern UI32_T      _ext_aml_forced_dev_id;
extern void dcc_lamp_setSrvPort(UI32_T  srv_port);
int clxs_switch_init_netif(
    _In_ const uint32_t              unit);
#endif

sai_status_t
clxs_switch_getUnitId(
    _In_ sai_object_id_t        switch_id,
    _Out_ uint32_t              *ptr_unit_id);

sai_status_t
clxs_switch_getFdbMissAction(
    _In_ const uint32_t             unit,
    _In_ const CLXS_SRV_BUM_TYPE_T   type,
    _Out_ sai_packet_action_t       *ptr_action);

sai_status_t
clxs_switch_getCfgValue(
    _In_ const UI32_T unit,
    _In_ const CLX_CFG_TYPE_T in_cfg_type,
    _Inout_ CLX_CFG_VALUE_T * ptr_in_value);

bool
clxs_switch_get_restart_warm_only(
    uint32_t unit);

const char *
clxs_switch_get_module_name(
    uint32_t index);

sai_status_t
clxs_switch_getSrcMac(
    _In_ const uint32_t              unit,
    _In_ const uint32_t              type,
    _Out_ sai_mac_t                 *mac);

sai_status_t
clxs_switch_getDefaultVxlanRouterMac(
    _In_ const uint32_t              unit,
    _Out_ sai_mac_t                 *mac);

sai_status_t
clxs_switch_init_chip_spec_info(
    _In_ uint32_t unit );

uint32_t
clxs_switch_getUnitInited(
    uint32_t unit);

sai_status_t
clxs_get_switch_count(
    _Out_ uint32_t *count);

void
clxs_switch_printf(
    const void      *ptr_buf,
    UI32_T          len);

const char *
clxs_switch_get_profile(
    _In_ const UI32_T   unit,
    _In_ char   *profile_name);

sai_status_t
clxs_switch_initModule(
    _In_ uint32_t       unit);

CLX_ERROR_NO_T
_clxs_switch_getCfgValue(
    const UI32_T            unit,
    const UI32_T            in_cfg_type,
    CLX_CFG_VALUE_T         *ptr_in_value);

sai_status_t
clxs_sai_restore_module_data(
    uint32_t unit,
    char*filename,
    uint32_t *length);

extern sai_status_t clxs_sai_get_module_warm_data(
    _In_ sai_api_t module,
    _In_ uint32_t unit,
    _Out_ uint32_t* length,
    _Out_ void** data);

uint32_t clxs_switch_getBootType(
    uint32_t unit);

bool clxs_switch_getDeinitType(
    uint32_t unit);

void set_fake_warm_reboot(
    bool warm);

int get_fake_warm_reboot(void);

sai_status_t
clxs_switch_getEcmpRhEnable(
    _In_ const uint32_t     unit,
    _In_ bool               *rh_enable);

#endif /* __CLXS_SWITCH_H__ */
