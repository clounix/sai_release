#if !defined (__CLXS_VLAN_H__)
#define __CLXS_VLAN_H__

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_vlan_api_t             vlan_api;

#define CLXS_VLAN_BC_LABEL  0x1
#define CLXS_VLAN_UMC_LABEL 0x2
#define CLXS_VLAN_UUC_LABEL 0x3
/* API DECLARATIONS
 */
sai_status_t
clxs_vlan_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_vlan_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_vlan_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint16_t                  *ptr_vid);

sai_status_t
clxs_vlan_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint16_t             vid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_vlan_setFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLXS_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act);

sai_status_t
clxs_vlan_create_VlanMbr(
    _Out_ sai_object_id_t    *vlan_member_id,
    _In_ const sai_object_id_t   switch_id,
    _In_ uint16_t   vid,
    _In_ const sai_object_id_t   bd_port_oid,
    _In_ sai_vlan_tagging_mode_t tag_mode);

sai_status_t
clxs_vlan_updateLagMbr(
    _In_ const uint32_t                  unit,
    _In_ const uint32_t                  bd_port_id,
    _In_ const CLXS_BRIDGE_PORT_INFO_T    *ptr_port_info,
    _In_ const bool                      is_add);

sai_status_t
clxs_vlan_update_flood_all_mgid(
    _In_ const uint32_t unit,
    _In_ const uint32_t vid,
    _In_ const uint32_t flags,
    _Out_ uint32_t *mcast_id
    );

sai_status_t clxs_vlan_valid_check(
    _In_ const uint32_t unit,
    _In_ const uint16_t vid);

sai_status_t clxs_vlan_set_dtel_profile (
    _In_ const uint32_t unit,
    _In_ const uint16_t vid,
    _In_ const uint32_t profile);

sai_status_t clxs_get_vlan_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_vlan_member_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);
#if 0
bool clxs_vlan_isIpProxySet(
    _In_ bool isND);
#endif
#endif /* __CLXS_VLAN_H__ */
