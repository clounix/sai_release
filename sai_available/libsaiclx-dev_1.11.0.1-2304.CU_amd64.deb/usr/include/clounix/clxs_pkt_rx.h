#if !defined (__CLXS_PKT_RX_H__)
#define __CLXS_PKT_RX_H__

#define CLXS_PKT_MAC_LEN_BYTE                     (6)
#define CLXS_PKT_VXLAN_LEN_WORD                   (2)
#define CLXS_PKT_IPV4_LEN_WORD                    (5)
#define CLXS_PKT_IPV6_LEN_WORD                    (10)
#define CLXS_PKT_ETH_P_8021Q     0x8100 /* 802.1q Service VLAN */
#define CLXS_PKT_ETH_P_8021AD    0x88A8 /* 802.1ad Service VLAN */
#define CLXS_PKT_ETHERTYPE_IPV4  0x0800
#define CLXS_PKT_ETHERTYPE_IPV6  0x86dd
#define SAI_PACKET_ACTION_MAX           8


extern const CLX_FWD_ACTION_T           ext_sai_action_to_clx_map[SAI_PACKET_ACTION_MAX];
extern const sai_packet_action_t        ext_clx_action_to_sai_map[CLX_FWD_ACTION_LAST];
extern const CLX_FWD_ACTION_T           swc_sai_action_to_clx_map[SAI_PACKET_ACTION_MAX];

#define SAI_FWD_ACTION_TO_CLXS(__action__)     ext_sai_action_to_clx_map[__action__]
#define CLXS_FWD_ACTION_TO_SAI(__action__)     ext_clx_action_to_sai_map[__action__]
#define CLXS_PKT_PORT_INDEX_TO_PHYPORT(__port__)        ((__port__ & 0x000000ff))

/* CLXS_PKT ETH/ETH_VLAN/VXLAN_EVPN_IPV4/VXLAN_EVPN_VLAN_IPV4/VXLAN_EVPN_QINQ/VXLAN_EVPN_IPV6/VXLAN_EVPN_VLAN_IPV6/VXLAN_EVPN_QINQ_IPV6 PKT struct START */
typedef struct
{
    uint8_t  dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
} CLXS_PKT_ETH_T;

typedef struct
{
    uint8_t  dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
} CLXS_PKT_ETH_VLAN_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
    uint32_t outer_ipv4[CLXS_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_IPV4_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv4[CLXS_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_VLAN_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t outer_vlan_type;
    uint16_t outer_vlan_tag;
    uint16_t inner_vlan_type;
    uint16_t inner_vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv4[CLXS_PKT_IPV4_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_QINQ_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t ethertype;
    uint32_t outer_ipv6[CLXS_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_IPV6_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t vlan_type;
    uint16_t vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv6[CLXS_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_VLAN_IPV6_T;

typedef struct
{
    uint8_t  outer_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  outer_smac[CLXS_PKT_MAC_LEN_BYTE];
    uint16_t outer_vlan_type;
    uint16_t outer_vlan_tag;
    uint16_t inner_vlan_type;
    uint16_t inner_vlan_tag;
    uint16_t ethertype;
    uint32_t outer_ipv6[CLXS_PKT_IPV6_LEN_WORD];
    uint16_t outer_udp_sport;
    uint16_t outer_udp_dport;
    uint16_t outer_udp_length;
    uint16_t outer_udp_checksum;
    uint32_t vxlan[CLXS_PKT_VXLAN_LEN_WORD];
    uint8_t  inner_dmac[CLXS_PKT_MAC_LEN_BYTE];
    uint8_t  inner_smac[CLXS_PKT_MAC_LEN_BYTE];
} CLXS_PKT_QINQ_IPV6_T;
/* CLXS_PKT ETH/ETH_VLAN/VXLAN_EVPN_IPV4/VXLAN_EVPN_VLAN_IPV4/VXLAN_EVPN_QINQ/VXLAN_EVPN_IPV6/VXLAN_EVPN_VLAN_IPV6/VXLAN_EVPN_QINQ_IPV6 PKT struct END */



sai_status_t
clxs_pkt_rx_registerCallback(
    _In_ const uint32_t         unit,
    _In_ void                   *ptr_func);

sai_status_t
clxs_pkt_rx_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_pkt_rx_deinit(
    _In_ const uint32_t         unit);
#endif
