#if !defined (__CLXS_ACL_H__)
#define __CLXS_ACL_H__

extern const sai_acl_api_t              acl_api;

#define CLXS_ACL_USER_META_FDB_DST_MIN                  (0)
#define CLXS_ACL_USER_META_FDB_DST_MAX                  (0xfff)
#define CLXS_ACL_USER_META_ROUTE_DST_MIN                (0)
#define CLXS_ACL_USER_META_ROUTE_DST_MAX                (0x7ff)
#define CLXS_ACL_USER_META_NEIGHBOR_DST_MIN             (0)
#define CLXS_ACL_USER_META_NEIGHBOR_DST_MAX             (0x7ff)
#define CLXS_ACL_USER_META_ROUTE_NEIGHBOR_DST_OFFSET    (1)
#define CLXS_ACL_USER_META_PORT_MIN                     (0)
#define CLXS_ACL_USER_META_PORT_MAX                     (3)
#define CLXS_ACL_USER_META_PORT_OFFSET                  (8)
#define CLXS_ACL_USER_META_ACL_MIN                      (0)
#define CLXS_ACL_USER_META_ACL_MAX                      (0x3f)
#define CLXS_ACL_INTERNAL_META_ACL_MIN               (0x40)
#define CLXS_ACL_INTERNAL_META_ACL_MAX               (0x7f)
#define CLXS_ACL_META_MAX                    (0x7f)
#define CLXS_ACL_META_MASK                    (CLXS_ACL_META_MAX)
#define CLXS_INTERNAL_META_ACL_BITMAP_SIZE       \
            (CLX_BITMAP_SIZE(CLXS_ACL_INTERNAL_META_ACL_MAX-CLXS_ACL_INTERNAL_META_ACL_MIN))

#define CLXS_ACL_GROUP_NUM_IGR                          (256)
#define CLXS_ACL_GROUP_NUM_EGR                          (256)
#define CLXS_ACL_RANGE_NUM                                  (CLX_ACL_LOU_NUM)
/*should be bigger than (CLXS_ACL_TABLE_NUM_IGR +  CLXS_ACL_TABLE_NUM_EGR)*/
#define CLXS_ACL_GROUP_MEMBER_NUM         (16)
#define CLXS_ECN_MARKED_INGRESS_ACL_GROUP_LABEL      0x6e
#define CLXS_ECN_MARKED_INGRESS_ACL_GROUP_LABEL_MASK 0xffffffff

#ifndef CLX_ACL_SONIC_BIND
#define CLXS_ACL_SRV_GRP_LBL_MAX		0x3FF
#define CLXS_ACL_SRV_GRP_LBL_INDEX_MIN               (0x1)
#define CLXS_ACL_SRV_GRP_LBL_INDEX_MAX               (0x3FF)
#endif

#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MIN             (200)
#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX             (600)
#else
#define CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX             (700)
#endif

#define CLXS_ACL_GROUP_MEMBER_PRIO_MIN                  (CLXS_ACL_ACTION_PRIO_USR_DEFINE_MIN)
#define CLXS_ACL_GROUP_MEMBER_PRIO_MAX                  (CLXS_ACL_ACTION_PRIO_USR_DEFINE_MAX)
#define CLXS_ACL_ENTRY_PRIO_MIN                         (0)
#define CLXS_ACL_ENTRY_PRIO_MAX                         (0xffffff)

/*the smaller prio value means higher priority */
/*other priority reserved to acl application */
#define CLXS_ACL_GROUP_PRIO_POLICER     (7)
#if defined(CLX_PORT_IP_COUNT_USING_ACL) || defined(CLX_SHOW_ECMP_PATH_EN)
#define CLXS_ACL_GROUP_PRIO_USER_ALLOC_MIN               (2)
#else
#define CLXS_ACL_GROUP_PRIO_USER_ALLOC_MIN               (1)
#endif
#define CLXS_ACL_GROUP_PRIO_USER_ALLOC_MAX               (5)
#define CLXS_ACL_GROUP_PRIO_ICC         (0)
#define CLXS_ACL_GROUP_PRIO_COUNTER     (6)
#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_ACL_GROUP_PRIO_PORT_IP_COUNT     (1)
#endif

#define CLXS_ACL_ACTION_PRIO_POLICER    (15)
#define CLXS_ACL_ACTION_PRIO_USER_ALLOC_MIN              (2)
#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_EGR_ACL_ACTION_PRIO_USER_ALLOC_MAX              (6)
#else
#define CLXS_EGR_ACL_ACTION_PRIO_USER_ALLOC_MAX              (7)
#endif
#define CLXS_IGR_ACL_ACTION_PRIO_USER_ALLOC_MAX              (14)
#define CLXS_ACL_ACTION_PRIO_ICC        (1)

#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_EGR_ACL_ACTION_PRIO_COUNTER	(7)
#define CLXS_ING_ACL_ACTION_PRIO_COUNTER	(15)
#endif

#define CLXS_ACL_GROUP_PRIO_ECN_MARKED_COUNT     (1)

#if SAI_API_VERSION >= SAI_VERSION(1, 4, 0)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_IPV6_AETH_DEFAULT	    (59)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_AETH_DEFAULT            (60)
#endif

#define CLXS_ACL_UDF_PROFILE_ID_FOR_TCP_FLAG_DEFAULT        (61)
#define CLXS_ACL_UDF_PROFILE_ID_FOR_INT_DEFAULT         (62)
#define CLXS_ACL_UDF_PROFILE_ID_DEFAULT                     (63)
#define CLXS_ACL_UDF_PROFILE_NUM                            (64)

#if SAI_API_VERSION >= SAI_VERSION(1, 4, 0)
#define CLXS_ACL_UDF_AETH_OFFSET                        (20)
#define CLXS_ACL_UDF_BTH_OFFSET                         (8)
#define CLXS_ACL_IP_PROTO_UDP                           (0x11)
#endif
#define CLXS_ACL_UDF_TCP_FLAG_OFFSET                    (13)
#define CLXS_ACL_IP_PROTO_TCP                           (0x6)
#define CLXS_ACL_UDF_TCP_PROFILE_PKT_CNT                (14)
#define CLXS_ACL_UDF_PROFILE_PKT_CNT_FOR_INT            (16)

#define CLXS_ACL_INVALID_GROUP_ID                       (0xffffffff)
#define CLXS_ACL_INVALID_ENTRY_ID                       (0xffffffff)

#define CLXS_ACL_UDF_DEFAULT_ID_OFFSET                  (CLXS_ACL_UDF_TCP_FLAG_OFFSET)
#define CLXS_ROUTE_IP2ME_GROUP_LABEL (1 << 11)

#define CLXS_ACL_UDF_PROF_BMP_FOREACH(__udf_prof_bmp__, __prof_idx__)                                              \
    for ((__prof_idx__) = 0; (__prof_idx__) < CLXS_ACL_UDF_PROFILE_NUM; (__prof_idx__)++)                           \
    if (CMLIB_BITMAP_BIT_CHK((__udf_prof_bmp__), (__prof_idx__)))

typedef struct CLXS_ACL_UDF_CB_S
{
    uint32_t    udf_prof_bmp[2];    /* total 64 udf_profile */
} CLXS_ACL_UDF_CB_T;

typedef enum
{
    CLXS_ACL_USER_META_PORT,
    CLXS_ACL_USER_META_FDB_DST,
    CLXS_ACL_USER_META_ROUTE_DST,
    CLXS_ACL_USER_META_NEIGHBOR_DST,
    CLXS_ACL_USER_META_ACL,
    CLXS_ACL_USER_META_ACL_LAST
} CLXS_ACL_USER_META_T;

typedef struct CLXS_ACL_BIND_TAM_INT_S
{
    sai_object_id_t acl_table_oid;
    bool            bind;
    bool            enable;
    uint32_t        dtel_profile_id;
    bool            need_internal_entry;
    uint32_t        presence_pb1;
    uint32_t        presence_pb2;
}CLXS_ACL_BIND_TAM_INT_T;

sai_status_t
clxs_acl_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_acl_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_acl_getSwitchAttr(
    _In_ const sai_object_key_t *ptr_key,
    _Inout_ sai_attribute_value_t *ptr_value,
    void *ptr_arg);

sai_status_t
clxs_get_acl_entry_enum_values_capability(
    _In_ uint32_t unit,
    _In_ sai_attr_id_t attr_id,
    _Inout_ sai_s32_list_t *enum_values_capability);

sai_status_t
clxs_acl_setGrpLblBindInfo(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const sai_object_id_t acl_object_id,
    _In_ const sai_object_id_t bind_point_onject_id,
    _Inout_ uint32_t *ptr_group_label);

sai_status_t
clxs_acl_setGrpLblUserMeta(
    _In_ const CLXS_ACL_USER_META_T user_meta_type,
    _In_ const uint32_t user_meta,
    _Inout_ uint32_t *ptr_group_label);

sai_status_t
clxs_acl_getUserMeta(
    _In_ const CLXS_ACL_USER_META_T user_meta_type,
    _In_ const uint32_t group_label,
    _Out_ uint32_t *ptr_user_meta);

sai_status_t
clxs_acl_addUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const uint32_t prof_id,
    _In_ const CLX_ACL_PKT_FORMAT_T *ptr_pkt_format,
    _In_ const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

sai_status_t
clxs_acl_delUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const uint32_t prof_id);

sai_status_t
clxs_acl_updateUdfKeyProfile(
    _In_ const uint32_t unit,
    _In_ const CLX_ACL_UDF_KEY_PROFILE_T *ptr_profile);

sai_status_t
clxs_acl_updateEntrySamplingRate(
    _In_ const sai_object_id_t entry_object_id,
    _In_ const uint32_t sampling_rate);

sai_status_t
clxs_acl_getBindPortList(
    _In_ uint32_t   unit,
    _In_ uint32_t   entry_id,
    _Out_ sai_object_list_t *ptr_igr_portlist,
    _Out_ sai_object_list_t *ptr_egr_portlist);

sai_status_t clxs_acl_bindTableToTamInt(
    _In_ CLXS_ACL_BIND_TAM_INT_T    *ptr_bind_info);

sai_status_t clxs_get_acl_entry_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_acl_range_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_acl_getBindPointAclbyBindPointobj(
    _In_ const uint32_t unit,
    _In_ const sai_acl_stage_t stage,
    _In_ const sai_object_id_t  bind_obj,
    _Out_ sai_object_id_t *ptr_aclobj);

sai_status_t clxs_acl_getUdfInfo(
    _In_ uint32_t unit,
    _Out_ CLXS_ACL_UDF_CB_T** ptr_udfInfo
);
#endif
