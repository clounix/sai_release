#if !defined (__CLXS_WRED_H__)
#define __CLXS_WRED_H__

extern const sai_wred_api_t             wred_api;

/* API DECLARATIONS
 */
sai_status_t clxs_wred_applySetting(
    _In_ sai_object_id_t obj_id,
    _In_ sai_object_id_t wred_id);

sai_status_t clxs_wred_init(
    _In_ uint32_t unit);

sai_status_t clxs_wred_deinit(
    _In_ uint32_t unit);

sai_status_t clxs_get_wred_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif /* __CLXS_WRED_H__ */
