#if !defined (__CLXS_NEIGHBOR_H__)
#define __CLXS_NEIGHBOR_H__

extern const sai_neighbor_api_t         neighbor_api;

sai_status_t clxs_neighbor_init(
    _In_ const uint32_t           unit);

sai_status_t clxs_neighbor_deinit(
    _In_ const uint32_t           unit);

sai_status_t clxs_neighbor_getInfo(
    _In_ const sai_neighbor_entry_t     *ptr_neighbor,
    _Out_ CLX_L3_HOST_INFO_T            *ptr_host_info,
    _Out_ uint32_t                      *ptr_adj_id,
    _Out_ CLX_L3_ADJ_INFO_T             *ptr_adj_info);
#if 0
sai_status_t clxs_neighbor_route_add_update(
    UI32_T unit,
    CLX_L3_ROUTE_INFO_T* route_info,
    UI32_T intf_id);

sai_status_t clxs_neighbor_route_delete_update(
    UI32_T unit,
    CLX_L3_ROUTE_INFO_T* route_info,
    UI32_T intf_id);
#endif
sai_status_t clxs_bc_neigh_update_vlan_member(
    _In_ BOOL_T add,
    _In_  uint32_t unit,
    _In_ CLX_VLAN_T vlan,
    _In_ CLX_PORT_BITMAP_T port_bitmap);

sai_status_t
clxs_create_neighbor_entry(
    _In_ const sai_neighbor_entry_t *neighbor_entry,
    _In_ uint32_t                   attr_count,
    _In_ const sai_attribute_t      *attr_list);

sai_status_t
clxs_remove_neighbor_entry(
    _In_ const sai_neighbor_entry_t *neighbor_entry);

sai_status_t
clxs_set_neighbor_entry_attribute(
    _In_ const sai_neighbor_entry_t *neighbor_entry,
    _In_ const sai_attribute_t      *attr);

sai_status_t
clxs_get_neighbor_entry_attribute(
    _In_ const sai_neighbor_entry_t *neighbor_entry,
    _In_ uint32_t               attr_count,
    _Inout_ sai_attribute_t     *attr_list);

#endif
