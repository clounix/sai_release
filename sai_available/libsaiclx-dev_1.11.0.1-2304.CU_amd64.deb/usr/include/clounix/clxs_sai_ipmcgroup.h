#if !defined (__CLXS_IPMCGROUP_H__)
#define __CLXS_IPMCGROUP_H__

extern const sai_ipmc_group_api_t       ipmcgroup_api;

sai_status_t
clxs_ipmcgrp_getInfo(
    _In_ const sai_object_id_t    oid,
    _Out_ uint32_t                *ptr_unit,
    _Out_ uint32_t                *ptr_mcast_id);

sai_status_t clxs_ipmc_group_init(
    const uint32_t    unit);

sai_status_t clxs_ipmc_group_deinit(
    const uint32_t    unit);

sai_status_t clxs_get_l2mc_group_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_l2mc_group_member_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_ipmc_group_member_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif
