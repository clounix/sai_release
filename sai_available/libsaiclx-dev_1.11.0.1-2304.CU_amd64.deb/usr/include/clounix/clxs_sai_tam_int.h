#if !defined (__CLXS_TAM_INT_H__)
#define __CLXS_TAM_INT_H__

#define CLXS_TAM_INT_PROFILE_ENTRY_NUM    (8)
typedef enum
{
    CLXS_TAM_INT_DEVICE_ROLE_NONE = 0,
    CLXS_TAM_INT_DEVICE_ROLE_INITIATOR,
    CLXS_TAM_INT_DEVICE_ROLE_TRANSIT,
    CLXS_TAM_INT_DEVICE_ROLE_TRANSIT_PORT_BASE,
    CLXS_TAM_INT_DEVICE_ROLE_TERMINATOR
} CLXS_TAM_INT_DEVICE_ROLE_T;

typedef enum
{
    CLXS_TAM_INT_MODE_NONE = 0,
    CLXS_TAM_INT_MODE_PORT, /* for device role: transit/terminator*/
    CLXS_TAM_INT_MODE_FLOW, /* for device role: initiator/transit */
    CLXS_TAM_INT_MODE_TUNNEL, /* for device role: initiator/terminator*/
    CLXS_TAM_INT_MODE_LAST
} CLXS_TAM_INT_MODE_T;

typedef struct CLXS_TAM_INT_IOAM_S
{
    uint32_t    trace_type;
    uint32_t    opq_id;
    uint8_t     node_len;
} CLXS_TAM_INT_IOAM_T;

typedef struct CLXS_TAM_INT_IFA1_S
{
    uint32_t    presence_pb1;
    uint32_t    presence_pb2;
    bool        in_line;
    uint16_t    trace_vector;
    uint16_t    action_vector;
    uint32_t    send_id;
    uint32_t    seq_num;
    uint8_t     tid;
} CLXS_TAM_INT_IFA1_T;

typedef struct CLXS_TAM_INT_BIND_DATA_S
{
    sai_object_id_t oid;
} CLXS_TAM_INT_BIND_DATA_T;

typedef struct CLXS_TAM_INT_DEVICE_S
{
    CLXS_TAM_INT_DEVICE_ROLE_T  role;
    CLXS_TAM_INT_MODE_T         mode;
    uint32_t                    acl_ref;
    union
    {
        CMLIB_LIST_T *port_list;
        CMLIB_LIST_T *mir_list;
    } u;
    uint32_t                    list_len; /* for warm-reboot */
} CLXS_TAM_INT_DEVICE_T;

typedef struct CLXS_TAM_INT_INFO_S
{
    bool                        valid;
    uint32_t                    profile; /* sdk: The profile ID 0 ~ 7 are for DTEL profile, and profile 0 reserve to port tasnsit only. */
    sai_tam_int_type_t          int_type;
    sai_tam_int_presence_type_t presence_type;
    uint32_t                    device_id;
    union
    {
        CLXS_TAM_INT_IOAM_T ioam;
        CLXS_TAM_INT_IFA1_T ifa1;
    } u;
    uint8_t                     presence_dscp_value;
    uint8_t                     presence_l3_protocol;
    bool                        metadata_fragment_enable;
    bool                        report_all_packets;
    uint16_t                    flow_liveness_period;
    uint8_t                     latency_sensitivity;
    uint8_t                     max_hop_count;
    uint8_t                     max_length;
    uint8_t                     name_space_id;
    bool                        name_sapce_id_global;
    sai_object_id_t             acl_group;
    sai_object_id_t             ingress_samplepacket_enable;
    uint32_t                    sampling_rate;
    sai_object_list_t           collector;
    sai_object_id_t             math_func;
    sai_object_id_t             report_id;
    CLXS_TAM_INT_DEVICE_T       device;
} CLXS_TAM_INT_INFO_T;

sai_status_t clxs_tam_int_init(
    _In_ const uint32_t unit);

sai_status_t clxs_tam_int_deinit(
    _In_ const uint32_t unit);

sai_status_t clxs_create_tam_int(
    _Out_ sai_object_id_t       *tam_int_id,
    _In_ sai_object_id_t        switch_id,
    _In_ uint32_t               attr_count,
    _In_ const sai_attribute_t  *attr_list);

sai_status_t clxs_remove_tam_int(
    _In_ sai_object_id_t    tam_int_id);

sai_status_t clxs_get_tam_int_attribute(
    _In_ sai_object_id_t    tam_int_id,
    _In_ uint32_t           attr_count,
    _Inout_ sai_attribute_t *attr_list);

sai_status_t clxs_set_tam_int_attribute(
    _In_ sai_object_id_t        tam_int_id,
    _In_ const sai_attribute_t  *attr);

char * clxs_tam_int_typeToStr(
    _In_ sai_tam_int_type_t type);

char * clxs_tam_int_deviceRoleToStr(
    _In_ CLXS_TAM_INT_DEVICE_ROLE_T type);

char * clxs_tam_int_presenceTypeToStr(
    _In_ sai_tam_int_presence_type_t    type);

sai_status_t clxs_tam_int_updatePort(
    _In_ const sai_object_id_t  tam_int_oid,
    _In_ const uint32_t         port,
    _In_ const bool             bind);

sai_status_t clxs_tam_int_setMirrorSessionId(
    _In_ const sai_object_id_t tam_int_oid,
    _In_ const uint32_t mir_session_id,
    _In_ const bool bind);

sai_status_t clxs_tam_int_getTamIntBindInfo(
    _In_ const sai_object_id_t tam_int_oid,
    _Out_ CLXS_ACL_BIND_TAM_INT_T *ptr_bind_info);

sai_status_t clxs_tam_int_getTamIntBindInfoByAclTable(
    _In_ const sai_object_id_t      acl_table_oid,
    _Out_ CLXS_ACL_BIND_TAM_INT_T   *ptr_bind_info);

sai_status_t clxs_tam_int_updateSampleRate(
    _In_ const sai_object_id_t tam_int_oid,
    _In_ uint32_t sample_rate);

#endif //__CLXS_TAM_INT_H__