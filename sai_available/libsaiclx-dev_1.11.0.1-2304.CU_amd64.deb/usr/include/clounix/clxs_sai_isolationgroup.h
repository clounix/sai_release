#if !defined (__CLXS_ISOLATIONGROUP_H__)
#define __CLXS_ISOLATIONGROUP_H__

#if SAI_API_VERSION >= SAI_VERSION(1, 4, 0)

extern const sai_isolation_group_api_t   isolationgroup_api;

sai_status_t
clxs_isolationgroup_init(
    _In_ const uint32_t    unit);

sai_status_t
clxs_isolationgroup_deinit(
    _In_ const uint32_t    unit);

sai_status_t
clxs_isolation_group_setBindObj(
    _In_ sai_object_id_t    bind_port_oid,
    _In_ sai_object_id_t    isolation_grp_oid,
    _In_ bool   is_add);

sai_status_t
clxs_isolation_group_updateLagMbr(
    _In_ sai_object_id_t    lag_oid,
    _In_ sai_object_id_t    lag_member_oid,
    _In_ bool   is_add);
#endif
#endif