#if !defined (__CLXS_NAT_H__)
#define __CLXS_NAT_H__
#if SAI_API_VERSION >= SAI_VERSION(1,5,0)

extern const sai_nat_api_t   nat_api;

/* API DECLARATIONS
 */

#endif /* SAI_API_VERSION */
#endif /* __CLXS_NAT_H__ */
