#if !defined (__CLXS_QOSMAP_H__)
#define __CLXS_QOSMAP_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define CLXS_QOSMAP_MAX_TC_COUNT             (16)
#define CLXS_QOSMAP_MAX_LOSSLESS_QUEUE_NUM   (2)
#define CLXS_QOSMAP_MAX_PFC_COUNT            (8)

/* GLOBAL VARIABLE DECLARATIONS
 */
extern const sai_qos_map_api_t          qosmap_api;

/* API DECLARATIONS
 */
sai_status_t clxs_qosmap_getPfcControl(
    sai_object_id_t         port_object_id,
    const sai_port_attr_t   attr_id,
    sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setPfcControl(
    sai_object_id_t         port_object_id,
    const sai_port_attr_t       attr_id,
    const sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_getPfcControlMode(
    sai_object_id_t         port_object_id,
    sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setPfcControlMode(
    sai_object_id_t         port_object_id,
    const sai_attribute_value_t   *ptr_value);

sai_status_t  _clxs_qosmap_updata_port_dscp(
    uint32_t        unit,
    uint32_t        port,
    uint32_t        profile_hw,
    uint32_t        property_flag);

sai_status_t clxs_qosmap_getProfileFromPort(
    sai_object_id_t         port_object_id,
    uint32_t                type,
    sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setProfileToPort(
    sai_object_id_t         port_object_id,
    uint32_t                type,
    sai_object_id_t         profile_object_id);

sai_status_t clxs_qosmap_getProfileFromTunnel(
    _In_ uint32_t        unit,
    _In_ uint32_t        sai_id,
    _In_ sai_qos_map_type_t      type,
    _Out_ sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setProfileToTunnel(
    _In_ uint32_t        unit,
    _In_ uint32_t        sai_id,
    _In_ sai_qos_map_type_t        type,
    _In_ sai_object_id_t        profile_object_id,
    _In_ uint32_t current_hw_profile,
    _Out_ uint32_t *new_hw_profile);

sai_status_t clxs_qosmap_getProfileFromSwitch(
    sai_object_id_t         switch_id,
    uint32_t                type,
    sai_attribute_value_t   *ptr_value);

sai_status_t clxs_qosmap_setProfileToSwitch(
    sai_object_id_t         switch_id,
    uint32_t                type,
    sai_object_id_t         profile_object_id);

sai_status_t clxs_qosmap_getPfcRxEnable(
    _In_ uint32_t        unit,
    _In_ uint32_t        port,
    _In_ uint32_t        pg_id,
    _Out_ BOOL_T         *rx_enable);

sai_status_t clxs_qosmap_init(
    uint32_t unit);

sai_status_t clxs_qosmap_deinit(
    uint32_t unit);

sai_status_t clxs_get_qos_map_count(_In_ const uint32_t unit, _Out_ uint32_t *count);
#endif /* __CLXS_QOSMAP_H__ */
