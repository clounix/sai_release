#if !defined (__CLXS_ROUTERINTERFACE_H__)
#define __CLXS_ROUTERINTERFACE_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define INVALID_INTF_ID 0xffffffff
#define CLXS_RIF_NVO3_RTE_INTF(__unit__)                (CLXS_MIN_NVO3_INTF_ID(__unit__))
#define CLXS_RIF_NVO3_RTE_MASK(__unit__)                (CLXS_NUM_RIF(__unit__) - CLXS_NUM_NVO3_INTF_ID(__unit__))

#define CLXS_RIF_RTE_MASK(__unit__)                     (((CLXS_NUM_RIF(__unit__)+1023)/1024)*1024 - 1)

#define CLXS_MIN_NVO3_INTF_ID(__unit__)             (CLXS_NUM_RIF(__unit__) - CLXS_NUM_NVO3_INTF_ID(__unit__))
#define CLXS_MIN_NVO3_RTE_MAC(__unit__)             (CLXS_NUM_RTE(__unit__) - CLXS_NUM_NVO3_RTE_MAC(__unit__))

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    CLXS_RIF_IDX_TYPE_RTE_MAC = 0,
    CLXS_RIF_IDX_TYPE_TNL_MAC,
    CLXS_RIF_IDX_TYPE_NVO3_MAC,
} CLXS_RIF_IDX_TYPE_T;

extern const sai_router_interface_api_t routerinterface_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T router_interface_stats_capability_info;

/* API DECLARATIONS
 */
sai_status_t clxs_rif_init(
    _In_ const uint32_t    unit);

sai_status_t clxs_rif_deinit(
    _In_ const uint32_t    unit);

sai_status_t clxs_rif_getsubvid(
    _In_  const sai_object_id_t         rif_id,
    _Out_ uint32_t                      *ptr_subvid);

sai_status_t clxs_rif_getInfo(
    _In_  const sai_object_id_t         rif_id,
    _Out_ uint32_t                      *ptr_unit,
    _Out_ CLX_BRIDGE_DOMAIN_T           *ptr_bdid,
    _Out_ CLX_L3_INTF_INFO_T            *ptr_intf_info,
    _Out_ sai_router_interface_type_t   *ptr_type,
    _Out_ CLX_PORT_T                    *ptr_port);

sai_status_t clxs_rif_updateLagMember(
    _In_ const sai_object_id_t          lag_oid,
    _In_ const sai_object_id_t          member_port_oid,
    _In_ const bool                     is_add);

sai_status_t clxs_rif_get_bdid(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  intf_id,
    _Out_ CLX_BRIDGE_DOMAIN_T* bdid);

sai_status_t clxs_rif_get_type(
    _In_ const uint32_t  unit,
    _In_ const uint32_t  intf_id,
    _Out_ sai_int32_t* type);

sai_status_t
clxs_rif_allocRouterMacIdx(
    const uint32_t              unit,
    const CLXS_RIF_IDX_TYPE_T    type,
    uint32_t                    *ptr_idx);

void
clxs_rif_freeRouterMacIdx(
    const uint32_t              unit,
    const CLXS_RIF_IDX_TYPE_T    type,
    const uint32_t              idx);

sai_status_t clxs_rif_getRouterMacIdx(
    _In_ const uint32_t              unit,
    _In_ const CLXS_RIF_IDX_TYPE_T    type,
    _In_ const uint32_t                 l3_intf_id,
    _In_ const CLX_MAC_T  mac,
    _Out_  uint32_t*              ptr_idx);

sai_status_t clxs_rif_update_router_mac(
    _In_ const uint32_t unit,
    _In_ const sai_mac_t old_mac,
    _In_ const sai_mac_t new_mac);

sai_status_t
clxs_rif_alloc_nvo3_intf(
    const uint32_t  unit,
    uint32_t        *ptr_intf_id);

void
clxs_rif_free_nvo3_intf(
    const uint32_t  unit,
    uint32_t        intf_id);

bool
clxs_rif_intf_is_nvo3(
    const uint32_t  unit,
    const uint32_t  intf_id);

sai_status_t
clxs_rif_update_router_macByVrf(
    _In_ const uint32_t unit,
    _In_ const uint32_t vrf,
    _In_ const sai_mac_t* new_mac);

#endif /* __CLXS_ROUTERINTERFACE_H__ */
