#if !defined (__CLXS_MPLS_H__)
#define __CLXS_MPLS_H__

extern const sai_mpls_api_t             mpls_api;

/* API DECLARATIONS
 */


#endif /* __CLXS_MPLS_H__ */
