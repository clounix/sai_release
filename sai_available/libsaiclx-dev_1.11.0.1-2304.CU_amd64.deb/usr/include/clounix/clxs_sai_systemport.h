#if !defined (__CLXS_SYSTEM_PORT_H__)
#define __CLXS_SYSTEM_PORT_H__

#if SAI_API_VERSION >= SAI_VERSION(1,6,0)
extern const sai_system_port_api_t   system_port_api;

/* API DECLARATIONS
 */

#endif
#endif /* __CLXS_SYSTEM_PORT_H__ */
