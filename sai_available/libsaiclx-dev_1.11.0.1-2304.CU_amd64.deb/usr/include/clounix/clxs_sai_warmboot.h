#if !defined (__CLXS_WARMBOOT_H__)
#define __CLXS_WARMBOOT_H__

/* DATA TYPE DECLARATIONS
 */

/* API DECLARATIONS
 */
bool
clxs_wb_dataAllZero(
    const char *ptr_data,
    const uint32_t data_size);

sai_status_t
clxs_wb_saveArrayWithIdx(
    const uint32_t  length,
    const uint32_t  count,
    const void  *ptr_array,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clxs_wb_restoreArrayWithIdx(
    const uint32_t       length,
    const uint32_t       count,
    void    *ptr_array,
    const HAL_IO_OBJ_META_T *ptr_obj_meta);

sai_status_t
clxs_wb_restoreList(
    const UI32_T             length,
    const CMLIB_LIST_T       *ptr_list,
    const HAL_IO_OBJ_META_T  *ptr_obj_meta);

sai_status_t
clxs_wb_saveList(
    const UI32_T       length,
    const CMLIB_LIST_T *ptr_list,
    HAL_IO_OBJ_META_T  *ptr_obj_meta);

void
clxs_wb_destoryWbObjList(
    uint32_t    wbdb_obj_list_cnt,
    HAL_IO_OBJ_META_T   *wbdb_obj_list);

sai_status_t
clxs_wb_saveAvlTree(
    const uint32_t           length,
    const CMLIB_AVL_HEAD_T *ptr_avl,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clxs_wb_saveGeneralData(
    const uint32_t  length,
    const char  *ptr_data,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clxs_wb_nonvolatileToDb(
    _In_ uint32_t   *module_length,
    _In_ void   **module_data,
    _In_ uint32_t   module_ver,
    _Out_ HAL_IO_WB_DB_T  **pptr_db);

sai_status_t
clxs_wb_dbToNonvolatile(
    _In_ HAL_IO_WB_DB_T  *ptr_db,
    _In_ uint32_t   module_ver,
    _Out_ uint32_t  *module_length,
    _Out_ void  **module_data);

sai_status_t
clxs_wb_getWbObj(
    const HAL_IO_WB_DB_T *ptr_db,
    UI32_T               obj_id,
    HAL_IO_OBJ_META_T    *ptr_obj);

CLX_ERROR_NO_T
clxs_io_saveAvlTree(
    const CMLIB_AVL_HEAD_T *ptr_avl,
    CMLIB_AVL_TRAV_FUNC_T trav_func,
    HAL_IO_OBJ_META_T      *ptr_obj_meta);

CLX_ERROR_NO_T
clxs_io_restoreAvlTree(
    CMLIB_AVL_HEAD_T  *ptr_avl,
    CMLIB_AVL_TRAV_FUNC_T trav_func,
    HAL_IO_OBJ_META_T *ptr_obj_meta);

sai_status_t
clxs_wb_restoreHashTable(
    const UI32_T             length,
    const CMLIB_HASH_TBL_T   *ptr_hash_tbl,
    HAL_IO_OBJ_META_T        *ptr_obj_meta);

sai_status_t
clxs_wb_saveHashTable(
    const uint32_t           length,
    const CMLIB_HASH_TBL_T   *ptr_hash_tbl,
    HAL_IO_OBJ_META_T        *ptr_obj_meta);

#endif /* __CLXS_WARMBOOT_H__ */
