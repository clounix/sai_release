#if !defined (__CLXS_BRIDGE_H__)
#define __CLXS_BRIDGE_H__

#define CLXS_BRIDGE_FLAGS_CREATE_WITH_ID (1 << 0)
#define CLXS_BRIDGE_FLAGS_IS_1Q_BRIDGE   (1 << 1)

#define CLXS_BRIDGE_PORT_BMP_SIZE(__unit__)    (CLX_BITMAP_SIZE(CLXS_MAX_BRIDGE_PORT_NUM(__unit__)))
#define CLXS_BRIDGE_FDID_1Q_NUM      (4095)
#define CLXS_BRIDGE_FDID_1D_NUM(__unit__)      (CLXS_BRIDGE_FDID_NUM(__unit__) - CLXS_BRIDGE_FDID_1Q_NUM)

typedef struct CLXS_BRIDGE_PORT_INFO_S
{
    sai_bridge_port_type_t    type;
    sai_object_id_t           oid;  /* PORT/LAG/RIF/TNL object */
    uint16_t                  vid;  /* only SUB_PORT use */
} CLXS_BRIDGE_PORT_INFO_T;

extern const sai_bridge_api_t           bridge_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T bridge_stats_capability_info ;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T bridge_port_stats_capability_info; 

/* API DECLARATIONS
 */
sai_status_t
clxs_bridge_init(
    _In_ const uint32_t             unit);

sai_status_t
clxs_bridge_deinit(
    _In_ const uint32_t             unit);

sai_status_t
clxs_bridge_createBridgeDomain(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             flags,      /* reference CLXS_BRIDGE_FLAGS_XXX */
    _Inout_ CLX_BRIDGE_DOMAIN_T     *ptr_bdid);

sai_status_t
clxs_bridge_removeBridgeDomain(
    _In_ const uint32_t             unit,
    _In_ const CLX_BRIDGE_DOMAIN_T  bdid);

sai_status_t
clxs_bridge_getBridgeDomainType_loose(
    _In_ const uint32_t        unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_bridge_type_t         *ptr_type);

sai_status_t
clxs_bridge_getBridgeDomainType(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_bridge_type_t         *ptr_type);

sai_status_t
clxs_bridge_getInfo(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_bdid);

sai_status_t
clxs_bridge_getObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bdid,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_bridge_getBdPortIdByObject(
    _In_ const sai_object_id_t      oid,
    _Out_ uint32_t                  *ptr_unit,
    _Out_ uint32_t                  *ptr_bd_port_id);

sai_status_t
clxs_bridge_getBdPortIdByInfo(
    _In_ const uint32_t                 unit,
    _In_ const CLXS_BRIDGE_PORT_INFO_T   *ptr_info,
    _Out_ uint32_t                      *ptr_bd_port_id);

sai_status_t
clxs_bridge_getPortInfo(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ CLXS_BRIDGE_PORT_INFO_T    *ptr_info);

sai_status_t
clxs_bridge_getPortObject(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ sai_object_id_t           *ptr_oid);

sai_status_t
clxs_bridge_getBdPortBdid(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             bd_port_id,
    _Out_ uint32_t                  *ptr_bdid);

sai_status_t
clxs_bridge_setFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLXS_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act);
#if 0
sai_status_t
clxs_bridge_setPortMode(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             port, /* native port id */
    _In_ const sai_bridge_port_type_t mode);

sai_status_t
clxs_bridge_getPortMode(
    _In_ const uint32_t             unit,
    _In_ const uint32_t             port, /* native port id */
    _Out_ sai_bridge_port_type_t      *ptr_mode);
#endif
sai_status_t
clxs_bridge_fillServiceFloodAct(
    _In_ const uint32_t             unit,
    _In_ const CLXS_SRV_BUM_TYPE_T   type,
    _In_ const sai_packet_action_t  act,
    _In_ const uint32_t             mcast_id,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clxs_bridge_fillServiceLrn(
    _In_ const uint32_t             unit,
    _In_ const bool                 bd_lrn_en,
    _In_ const CLXS_SRV_LRN_MODE_T   mode,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clxs_bridge_fillTnlService(
    _In_ const uint32_t             unit,
    _In_ const sai_object_id_t      tnl_oid,
    _In_ const uint32_t             bdid,
    _Inout_ CLX_PORT_SEG_SRV_T      *ptr_srv);

sai_status_t
clxs_bridge_createDfltBdPort(
    _Out_  sai_object_id_t *bd_port_oid,
    _In_ const sai_object_id_t          switch_id,
    _In_ const CLXS_BRIDGE_PORT_INFO_T   *ptr_port_info);

sai_status_t
clxs_bridge_updateLagMbr(
    _In_ const uint32_t                 unit,
    _In_ const uint32_t                 bd_port_id,
    _In_ const CLXS_BRIDGE_PORT_INFO_T   *ptr_port_info,
    _In_ const bool                     is_add);

sai_status_t
clxs_get_1q_fdid_count(
    _In_ uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_bridge_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_bridge_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif /* __CLXS_BRIDGE_H__ */
