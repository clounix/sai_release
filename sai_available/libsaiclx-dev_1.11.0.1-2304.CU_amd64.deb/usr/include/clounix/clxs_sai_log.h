#if !defined (__CLXS_LOG_H__)
#define __CLXS_LOG_H__

#define CLXS_LOG_PRINT(module, severity, fmt, arg ...)                       \
    do {                                                                    \
        clxs_log_print(module, severity,                                   \
                        "%s:%d " fmt,  __FUNCTION__,__LINE__, ## arg);                 \
    } while (0)
#define CLXS_LOG_PRINT_WITHOUT_CODE_INFO(module, severity, fmt, arg ...)                \
    do {                                                                    \
        clxs_log_print(module, severity, fmt, ## arg);                 \
    } while (0)

#define CLXS_LOG_TYPE_SAI      0
#define CLXS_LOG_TYPE_DIAG   1
#define CLXS_LOG_DBG(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_DEBUG,   fmt, ## arg)
#define CLXS_LOG_INF(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_INFO,    fmt, ## arg)
#define CLXS_LOG_WRN(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_WARN,    fmt, ## arg)
#define CLXS_LOG_ERR(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_ERROR,   fmt, ## arg)
#define CLXS_LOG_NTC(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_NOTICE,  fmt, ## arg)
#define CLXS_LOG_CTL(module, fmt, arg ...)     CLXS_LOG_PRINT(module, SAI_LOG_LEVEL_CRITICAL,fmt, ## arg)

#define CLXS_ATTRIBS_LOG(_module,_clxs_range_attr_arr,_dbg_level) \
{\
    if (clxs_log_isModuleLogLevelOn((_module), (_dbg_level)))\
    {\
        char _list_str[MAX_LIST_VALUE_STR_LEN] = {0};\
        clxs_sai_attr_list_to_str(attr_count, attr_list, _clxs_range_attr_arr, MAX_LIST_VALUE_STR_LEN, _list_str);\
        CLXS_LOG_PRINT(_module, _dbg_level,"%s", _list_str);\
    }\
}

#define CLXS_ATTR_VALUE_LOG(module, _id, _attr_value, _clxs_range_attr_arr, _dbg_level) \
{\
    char _value_str[MAX_VALUE_STR_LEN] = {0};\
    clxs_sai_attr_value_to_str(_id, _attr_value, _clxs_range_attr_arr, MAX_VALUE_STR_LEN, _value_str);\
    CLXS_LOG_PRINT(module, _dbg_level, "%s", _value_str);\
}

#define CHECK_RET_FAIL_LOG(ret, level, fmt, arg ...)  do {\
    if ((ret)!= SAI_STATUS_SUCCESS) \
    {\
        CLXS_LOG_##level(__MODULE__, fmt" "#ret"=%d", ##arg, (ret));\
    }\
}while (0)

#define CHECK_RET_ERR_LOG(fmt, arg ...)  CHECK_RET_FAIL_LOG(ret, ERR, fmt, ##arg)

#define CLXS_COUNTER_ID_LOG(module, _num_of_cnt, _cnt_ids, _dbg_level)\
{\
    uint32_t _cnt_id_idx = 0;\
    for (_cnt_id_idx=0;_cnt_id_idx<_num_of_cnt;_cnt_id_idx++)\
    {\
        CLXS_LOG_PRINT(module, _dbg_level, "counter id[%u]=%u",_cnt_id_idx,_cnt_ids[_cnt_id_idx]);\
    }\
}

#define CLXS_COUNTER_ID_AND_VALUE_LOG(module, _num_of_cnt, _cnt_ids, _cnt_value, _dbg_level)\
{\
    uint32_t _cnt_idx = 0;\
    for (_cnt_idx=0;_cnt_idx<_num_of_cnt;_cnt_idx++)\
    {\
        CLXS_LOG_PRINT(module, _dbg_level, "counter id[%u]=%d,value=%#" PRIx64 ,_cnt_idx,_cnt_ids[_cnt_idx],_cnt_value[_cnt_idx]);\
    }\
}

/* API DECLARATIONS
 */
void
clxs_log_print(
    const clxs_api_t        module,
    const sai_log_level_t       severity,
    const C8_T                  *ptr_fmt,
    ...)
__attribute__ ((__format__ (__printf__, 3, 4)));

BOOL_T
clxs_log_isModuleLogLevelOn(
    const clxs_api_t        module,
    const sai_log_level_t       severity);

CLX_ERROR_NO_T
clxs_log_setModuleLogLevel(
    const clxs_api_t        module,
    const uint32_t              type,
    const sai_log_level_t       severity);

CLX_ERROR_NO_T
clxs_log_getModuleLogLevel(
    const clxs_api_t        module,
    const uint32_t              type,
    sai_log_level_t             *severity);

sai_status_t
clxs_bulk_statuses_log(
    _In_ const char         *object_type_str,
    _In_ const sai_status_t *object_statuses,
    _In_ uint32_t            object_count,
    _In_ sai_common_api_t    api);

void
clxs_log_setDiagCfg(_In_ const uint32_t  unit);

void clxs_sai_printVersion();

void clxs_log_init(void);

#endif /* __CLXS_LOG_H__ */
