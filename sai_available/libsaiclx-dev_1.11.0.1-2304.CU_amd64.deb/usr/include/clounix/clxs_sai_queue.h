#if !defined (__CLXS_QUEUE_H__)
#define __CLXS_QUEUE_H__

/* MACRO FUNCTION DECLARATIONS
 */


/* DATA TYPE DECLARATIONS
 */
typedef struct CLXS_QUEUE_DB_S
{
    bool                        is_used;
    sai_object_id_t             object_id;
    sai_object_id_t             parent_id;
    sai_object_id_t             scheduler_id;
    sai_object_id_t             wred_id;
    sai_object_id_t             buffer_id;
    CLX_TM_SCH_TOPOLOGY_ENTRY_T topology_entry;
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
    sai_object_list_t            tamlist;
#endif
} CLXS_QUEUE_DB_T;

extern const sai_queue_api_t            queue_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T queue_stats_capability_info;

/* API DECLARATIONS
 */
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
 /*micro-burst begin*/

#define CLXS_TAM_CONFIG_ADD               (1)
#define CLXS_TAM_CONFIG_DEL                (0)

 #endif

sai_status_t
clxs_queue_registerCallback(
    _In_ const uint32_t unit,
    _In_ void           *func);

sai_status_t clxs_queue_getQueueDb(
    uint32_t            unit,
    uint32_t            port,
    sai_queue_type_t    type,
    uint32_t            queue_id,
    CLXS_QUEUE_DB_T      *ptr_queue_db);

sai_status_t clxs_queue_setQueueDb(
    uint32_t            unit,
    uint32_t            port,
    sai_queue_type_t    type,
    uint32_t            queue_id,
    CLXS_QUEUE_DB_T      *ptr_queue_db);

sai_status_t clxs_queue_getNum(
    sai_object_id_t     port_object_id,
    uint32_t             *ptr_num);

sai_status_t clxs_queue_getList(
    sai_object_id_t     port_object_id,
    sai_object_id_t     *ptr_list);

sai_status_t clxs_queue_init(
    uint32_t unit);

sai_status_t clxs_queue_deinit(
    uint32_t unit);

sai_status_t clxs_port_wred_apply(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ sai_object_id_t wred_id);

#endif /* __CLXS_QUEUE_H__ */
