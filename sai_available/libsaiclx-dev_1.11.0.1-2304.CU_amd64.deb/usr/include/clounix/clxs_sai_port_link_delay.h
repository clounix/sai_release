#if !defined (__CLXS_PORT_LINK_DELAY_H__)
#define __CLXS_PORT_LINK_DELAY_H__

#ifdef CLX_PORT_LINK_DELAY

typedef struct  CLXS_PORT_LINK_DELAY_S
{
    uint32_t                upDelay;
    uint32_t                downDelay;
    uint64_t                upTime;
    uint64_t                downTime;
    sai_port_oper_status_t  linkStatus;
#ifdef CLX_PORT_LINK_DELAY_CLXEXT
    uint32_t                upCnt;
    uint32_t                downCnt;
#endif
} CLXS_PORT_LINK_DELAY_T;

typedef struct  CLXS_LINK_DELAY_S
{
    CLX_PORT_BITMAP_T       port_bmp;
    CLXS_PORT_LINK_DELAY_T  *port_link_delay_ptr;
    uint32_t                interval_us;
    CLX_THREAD_ID_T         thread_id;
    CLX_SEMAPHORE_ID_T      data_protect;
    CLX_SEMAPHORE_ID_T      thread_sync;
} CLXS_LINK_DELAY_T;

extern CLXS_LINK_DELAY_T _clxs_link_delay[CLXS_MAX_CHIP_NUM];

#define CLXS_PORT_LINK_DELAY_LOCK(unit) \
    sai_osal_mutex_lock(_clxs_link_delay[unit].data_protect);

#define CLXS_PORT_LINK_DELAY_UNLOCK(unit) \
    sai_osal_mutex_unlock(_clxs_link_delay[unit].data_protect);

#define CLXS_PORT_LINK_DELAY_PTR(__unit__, __port__)        ((CLXS_PORT_LINK_DELAY_T *)(_clxs_link_delay[__unit__].port_link_delay_ptr + __port__ ))

sai_status_t clxs_port_linkdelay_state_update(
        _In_ const uint32_t unit,
        _In_ const uint32_t port,
        _In_ const uint32_t link,
        _Out_   bool *ptr_linkdelay_en);

sai_status_t _clxs_port_setLinkUpDelayTime(
    _In_ const sai_object_key_t      *ptr_key,
    _In_ const sai_attribute_value_t *ptr_value,
    void                             *ptr_arg);

sai_status_t _clxs_port_setLinkDownDelayTime(
    _In_ const sai_object_key_t      *ptr_key,
    _In_ const sai_attribute_value_t *ptr_value,
    void                             *ptr_arg);

uint32_t clxs_port_linkdelay_get_upDelayTime(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

uint32_t clxs_port_linkdelay_get_downDelayTime(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

#ifdef CLX_PORT_LINK_DELAY_CLXEXT
uint32_t clxs_port_linkdelay_get_downCnt(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);

uint32_t clxs_port_linkdelay_get_upCnt(
    _In_ uint32_t                unit,
    _In_ uint32_t                port);
#endif

sai_status_t clxs_port_link_delay_initRsrc(
    _In_ const uint32_t unit);

sai_status_t clxs_port_link_delay_deinitRsrc(
    _In_ const uint32_t unit);

sai_status_t clxs_port_link_delay_initThread(
    _In_ const uint32_t     unit);

sai_status_t clxs_port_link_delay_destroyThread(
    _In_ const uint32_t     unit);

CLX_ERROR_NO_T _clxs_port_link_delay_diag_dump_cmd(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T _clxs_port_link_delay_diag_get_cmd(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T _clxs_port_link_delay_diag_set_cmd(
    _In_ const C8_T                *tokens[]);
#endif


#endif /* __CLXS_PORT_LINK_DELAY_H__ */