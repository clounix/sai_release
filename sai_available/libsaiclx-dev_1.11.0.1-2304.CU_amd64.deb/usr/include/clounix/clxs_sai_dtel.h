#if !defined (__CLXS_DTEL_H__)
#define __CLXS_DTEL_H__

extern const sai_dtel_api_t               dtel_api;
/* API DECLARATIONS
 */


#endif /* __CLXS_DTEL_H__ */
