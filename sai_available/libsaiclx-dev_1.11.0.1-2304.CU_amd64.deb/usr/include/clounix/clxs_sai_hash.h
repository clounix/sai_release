#if !defined (__CLXS_HASH_H__)
#define __CLXS_HASH_H__

extern const sai_hash_api_t             hash_api;

sai_status_t
clxs_hash_init(
    _In_ uint32_t               unit);

sai_status_t
clxs_hash_deinit(
    _In_ uint32_t               unit);

sai_status_t
clxs_hash_id_get(
    _In_  sai_object_id_t       switch_id,
    _In_  sai_switch_attr_t     attr,
    _Out_ sai_object_id_t       *ptr_hash_id);

sai_status_t
clxs_hash_id_set(
    _In_ sai_object_id_t        switch_id,
    _In_  sai_switch_attr_t     attr,
    _In_ sai_object_id_t        hash_id);

CLX_ERROR_NO_T clxs_hash_diag_show_hash_key(
    _In_ const C8_T                *tokens[]);

sai_status_t clxs_get_hash_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif
