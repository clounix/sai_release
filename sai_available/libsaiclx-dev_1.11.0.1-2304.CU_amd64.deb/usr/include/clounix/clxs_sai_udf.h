#if !defined (__CLXS_UDF_H__)
#define __CLXS_UDF_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define CLXS_UDF_GROUP_MAX_NUM       (1)

/* MACRO FUNCTION DECLARATIONS
 */
#define CLXS_UDF_ENTRY_MAX_NUM(__unit__)       (CLXS_UDF_GROUP_MAX_NUM * CLXS_UDF_GROUP_CAPACITY(__unit__))

/* DATA TYPE DECLARATIONS
 */
typedef struct _CLXS_UDF_MATCH_L2_T
{
    uint16_t data;
    bool     is_valid;
} CLXS_UDF_MATCH_L2_T;

typedef struct _CLXS_UDF_MATCH_L3_T
{
    uint8_t  data;
    bool     is_valid;
} CLXS_UDF_MATCH_L3_T;

typedef struct _CLXS_UDF_MATCH_DB_T
{
    uint32_t refs;
    CLXS_UDF_MATCH_L2_T l2_type;
    CLXS_UDF_MATCH_L3_T l3_type;
    uint8_t priority;
    sai_object_id_t sai_object;
} CLXS_UDF_MATCH_DB_T;

typedef struct _CLXS_UDF_GROUP_DB_T
{
    uint32_t type;
    uint32_t length;
    uint32_t refs;
    uint32_t count;
    sai_object_id_t sai_object;
    uint32_t udf_indexes[0];
} CLXS_UDF_GROUP_DB_T;

extern const sai_udf_api_t              udf_api;

/* API DECLARATIONS
 */
sai_status_t clxs_udf_get_match_list_from_group(
    _In_ sai_object_id_t    udf_group_id,
    _Out_ uint32_t          *ptr_count,
    _Out_ CLXS_UDF_MATCH_DB_T *ptr_match_list);

sai_status_t clxs_udf_get_entry_list(
    _In_ sai_object_id_t    udf_group_id,
    _In_ sai_object_id_t    udf_match_id,
    _Out_ uint32_t          *ptr_count,
    _Out_ uint32_t          *ptr_list);

sai_status_t clxs_udf_init(_In_ uint32_t unit);

sai_status_t clxs_udf_deinit(_In_ uint32_t unit);

sai_status_t clxs_udf_get_group_obj(
    _In_ uint32_t         unit,
    _In_ uint32_t         udf_group_id,
    _Out_ sai_object_id_t *ptr_udf_group_id);

sai_status_t clxs_udf_get_match_id(
    _In_ sai_object_id_t    udf_match_obj,
    _Out_ uint32_t          *ptr_match_id);

sai_status_t clxs_udf_get_db_size(
    _In_ uint32_t           unit,
    _In_ sai_object_type_t  udf_type,
    _Out_ uint32_t         *size);

sai_status_t clxs_udf_get_db_count(
    _In_ uint32_t unit, _In_ sai_object_type_t udf_type,
    _Out_ uint32_t *count);

#endif /* __CLXS_UDF_H__ */
