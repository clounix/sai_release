#if !defined (__CLXS_OSAL_H__)
#define __CLXS_OSAL_H__

typedef enum {
    MUTEX_TYPE_NORMAL=0,
    MUTEX_TYPE_RECURSIVE,
     /*now i only need this type, want more? define it here*/
    MUTEX_TYPE_MAX
 }mutex_type_t;

CLX_SEMAPHORE_ID_T sai_osal_create_mutex(_In_ int type);
CLX_ERROR_NO_T sai_osal_destroy_mutex(CLX_SEMAPHORE_ID_T  ptr_semaphore_id);
int sai_osal_mutex_lock(_In_ CLX_SEMAPHORE_ID_T sema);
int sai_osal_mutex_unlock(_In_ CLX_SEMAPHORE_ID_T sema);

/* API DECLARATIONS
 */
sai_status_t sai_osal_getSysTime(
    uint64_t          *ptr_time_usec);
sai_status_t sai_osal_getCalendarTime(
    uint64_t          cur_time_second,
    OSAL_TM_T         *ptr_tm);
sai_status_t sai_osal_getMonotonicTime(
    uint64_t          *ptr_time_usec);

I32_T
sai_osal_snprintf(
    C8_T            *ptr_str,
    const I32_T    length,
    const C8_T      *ptr_fmt,
    ...);

#endif /* __CLXS_OSAL_H__ */
