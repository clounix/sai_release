#if !defined (__CLXS_SRV6_H__)
#define __CLXS_SRV6_H__

extern const sai_srv6_api_t               srv6_api;
/* API DECLARATIONS
 */


#endif /* __CLXS_SRV6_H__ */
