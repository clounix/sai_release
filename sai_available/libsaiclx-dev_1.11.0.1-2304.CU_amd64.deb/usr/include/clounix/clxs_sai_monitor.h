#ifndef CLX_MONITOR_H
#define CLX_MONITOR_H

#define SAI_RX_ERR_CNT_THRESHOLD            1000000
#define SAI_RX_ERR_CNT_ACCUMULATED_CYCLE    5
#define SAI_RX_DMA_BUF_LOW_THRESHOLD_PERCENT    0.02

#ifdef CLX_SWITCH_MONITOR
typedef struct  CLXS_SWITCH_MONITOR_S
{
    uint32_t                interval_us;
    CLX_THREAD_ID_T         thread_id;
    CLX_SEMAPHORE_ID_T      sema;
} CLXS_SWITCH_MONITOR_T;
#endif

typedef struct {
    UI32_T cnt_single;
    UI32_T cnt_double;
} DEMO_SWC_CMD_TRAV_COOKIE_T;

#ifdef CLX_ECC_ERR_LOG
typedef struct SAI_ECC_ERR_CNT_S
{
    uint32_t*    history_single_table_err_cnt;
    uint32_t*    history_double_table_err_cnt;
    uint32_t*    history_single_hub_mem_err_cnt;
    uint32_t*    history_double_hub_mem_err_cnt;
    uint32_t     single_err_total_cnt;
    uint32_t     double_err_total_cnt;
    uint32_t     correct_total_cnt;
} SAI_ECC_ERR_CNT_T;
#endif

#ifdef CLX_SWITCH_MONITOR
sai_status_t clxs_port_fault_log(
	    _In_ const uint32_t     unit,
	    _In_ const uint32_t     port);

sai_status_t clxs_switch_monitor_init(
    _In_ const uint32_t unit);

sai_status_t clxs_switch_monitor_deinit(
    _In_ const uint32_t unit);
#endif

#ifdef CLX_ECC_ERR_LOG
sai_status_t clxs_monitor_initEccLog(
    uint32_t unit);

sai_status_t clxs_monitor_deinitEccLog(
    uint32_t unit);
#endif

#endif  /* End of CLX_MONITOR_H */