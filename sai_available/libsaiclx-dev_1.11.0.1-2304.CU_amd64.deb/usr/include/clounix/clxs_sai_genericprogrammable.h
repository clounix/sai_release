#if !defined (__CLXS_GENERIC_PROGRAMMABLE_H__)
#define __CLXS_GENERIC_PROGRAMMABLE_H__

#if SAI_API_VERSION >= SAI_VERSION(1,11,0)
extern const sai_generic_programmable_api_t   generic_programmable_api;

/* API DECLARATIONS
 */

#endif
#endif /* __CLXS_GENERIC_PROGRAMMABLE_H__ */