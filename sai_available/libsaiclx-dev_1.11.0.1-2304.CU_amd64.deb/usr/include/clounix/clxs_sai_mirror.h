#if !defined (__CLXS_MIRROR_H__)
#define __CLXS_MIRROR_H__

extern const sai_mirror_api_t           mirror_api;

sai_status_t clxs_mirror_syncSes(
    _In_ uint32_t               unit,
    _In_ sai_object_id_t        mir_obj_idx,
    _In_ CLX_MIR_DIRECTION_T    dir,
    _Out_ uint32_t              *ptr_mir_session);

sai_status_t clxs_mirror_getMirType(
    _In_ uint32_t           unit,
    _In_ sai_object_id_t    mir_obj_idx,
    _Out_ CLX_MIR_TYPE_T    *mir_type);

sai_status_t clxs_mirror_setNvgreCtrl(
    uint32_t        unit,
    sai_object_id_t mir_obj_idx);

/* Get session id from mirror idx*/
sai_status_t clxs_mirror_getSesId(
    _In_ uint32_t               unit,
    _In_ CLX_MIR_DIRECTION_T    dir,
    _In_ uint32_t               mir_idx,
    _Out_ sai_object_id_t       *ptr_mir_ses_obj_id);

sai_status_t clxs_mirror_init(
    uint32_t unit);

sai_status_t clxs_mirror_deinit(
    uint32_t unit);

sai_status_t clxs_mirror_getSysTc(
    uint32_t    unit,
    uint8_t     *ptr_sys_tc);

sai_status_t clxs_mirror_setSysTc(
    uint32_t    unit,
    uint8_t     new_sys_tc);

sai_status_t clxs_mirror_applyTcToAllSession(
    uint32_t    unit,
    uint8_t     new_tc);

sai_status_t clxs_mirror_getSdkSesId(
    _In_ sai_object_id_t    session_oid,
    _Inout_ uint32_t        *sdk_ses_id);

sai_status_t clxs_mirror_getSessionCount(
    _In_ const uint32_t unit,
    _Out_ uint32_t      *count);

#endif