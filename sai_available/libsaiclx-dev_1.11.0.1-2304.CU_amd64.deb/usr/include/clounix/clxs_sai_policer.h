#if !defined (__CLXS_POLICER_H__)
#define __CLXS_POLICER_H__

extern const sai_policer_api_t          policer_api;

/* API DECLARATIONS
 */
sai_status_t
clxs_policer_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_policer_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_policer_getUnitId(
    _In_ const sai_object_id_t  policer_id,
    _Out_ uint32_t              *ptr_unit);

sai_status_t
clxs_policer_addColorAct(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         port,
    _In_ const CLX_ACL_GROUP_T  type,
    _In_ const sai_object_id_t  policer_id);

sai_status_t
clxs_policer_delColorAct(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         port,
    _In_ const CLX_ACL_GROUP_T  type,
    _In_ const sai_object_id_t  policer_id);

#define CLXS_POLICER_GN_PKT_ACT_DROP             (0x1 << CLX_COLOR_GREEN)
#define CLXS_POLICER_YL_PKT_ACT_DROP             (0x1 << CLX_COLOR_YELLOW)
#define CLXS_POLICER_RD_PKT_ACT_DROP             (0x1 << CLX_COLOR_RED)

#define CLXS_POLICER_INVALID_METER_ID            (0xFFFFFFFF)

/* Consistent with the order of sec_cmd_showStormControlPortInfo */
typedef enum
{
    CLXS_STORM_CTRL_TYPE_BROADCAST = 0,
    CLXS_STORM_CTRL_TYPE_FLOOD,
    CLXS_STORM_CTRL_TYPE_MULTICAST,
    CLXS_STORM_CTRL_TYPE_RESERVE,
    CLXS_STORM_CTRL_TYPE_LAST
} CLX_STORM_CTRL_TYPE_T;

typedef enum
{
    CLXS_POLICER_PORT_ACTION_ADD,
    CLXS_POLICER_PORT_ACTION_DELETE,
    CLXS_POLICER_PORT_ACTION_MODIFY,
    CLXS_POLICER_PORT_ACTION_LAST
} CLXS_POLICER_PORT_ACTION_T;

sai_status_t
clxs_policer_setPortStormControl(
    _In_ const sai_object_id_t          port_id,
    _In_ sai_port_attr_t                type,
    _In_ const sai_object_id_t          cur_policer_id,
    _In_ const sai_object_id_t          new_policer_id);

sai_status_t
clxs_policer_getMeterCfg(
    _In_ const sai_object_id_t      policer_id,
    _Out_ uint32_t      *ptr_meter_id,
    _Out_ CLX_METER_CFG_T   *ptr_meter_cfg);

#endif /* __CLXS_POLICER_H__ */
