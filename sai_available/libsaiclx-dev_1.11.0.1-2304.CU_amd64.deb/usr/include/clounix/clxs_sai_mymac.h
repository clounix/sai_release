#if !defined (__CLXS_MYMAC_H__)
#define __CLXS_MYMAC_H__

extern const sai_my_mac_api_t               mymac_api;
/* API DECLARATIONS
 */


#endif /* __CLXS_MYMAC_H__ */
