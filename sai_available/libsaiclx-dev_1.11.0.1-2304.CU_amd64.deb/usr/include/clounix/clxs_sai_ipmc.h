#if !defined (__CLXS_IPMC_H__)
#define __CLXS_IPMC_H__

extern const sai_ipmc_api_t             ipmc_api;
sai_status_t
clxs_ipmc_init(
    _In_ const uint32_t unit);
#endif
