#if !defined (__CLXS_ECC_H__)
#define __CLXS_ECC_H__

#ifdef CLX_EN_LIGHTNING
extern char *ecc_table_name_of_lightning[];
extern uint32_t ecc_table_count_of_lightning;
#endif
#endif /* __CLXS_ECC_H__ */
