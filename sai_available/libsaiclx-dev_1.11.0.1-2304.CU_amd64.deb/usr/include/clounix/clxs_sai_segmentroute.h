#if !defined (__CLXS_SEGMENTROUTE_H__)
#define __CLXS_SEGMENTROUTE_H__

#if SAI_API_VERSION < SAI_VERSION(1,9,0)
extern const sai_segmentroute_api_t     segmentroute_api;
#endif
/* API DECLARATIONS
 */


#endif /* __CLXS_SEGMENTROUTE_H__ */
