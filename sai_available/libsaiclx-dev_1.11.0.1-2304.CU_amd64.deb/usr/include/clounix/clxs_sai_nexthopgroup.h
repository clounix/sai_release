#if !defined (__CLXS_NEXTHOPGROUP_H__)
#define __CLXS_NEXTHOPGROUP_H__

extern const sai_next_hop_group_api_t   nexthopgroup_api;

/* API DECLARATIONS
 */
sai_status_t
clxs_nexthopgroup_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthopgroup_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthopgroup_getObj(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         ecmp_grp_id,
    _Out_ sai_object_id_t       *ptr_next_hop_group_id);

sai_status_t
clxs_nexthopgroup_getInfo(
    _In_ const sai_object_id_t  next_hop_group_id,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_ecmp_grp_id);

sai_status_t
clxs_set_next_hop_group_member_attribute(
    _In_ sai_object_id_t        next_hop_group_member_id,
    _In_ const sai_attribute_t  *attr);

sai_status_t
clxs_get_next_hop_group_member_attribute(
    _In_ sai_object_id_t        next_hop_group_member_id,
    _In_ uint32_t               attr_count,
    _Inout_ sai_attribute_t     *attr_list);

sai_status_t
clxs_nexthopgroup_syncRhGroup(
    _In_ const uint32_t         unit,
    _In_ sai_object_id_t        pre_group_oid,
    _In_ sai_object_id_t        cur_group_oid);

sai_status_t
clxs_nexthopgroup_getMemberNum(
    _In_ sai_object_id_t        switch_id,
    _Inout_ uint32_t            *count);

#ifdef CLX_NEXTHOPGROUP_FAST_FAILOVER
void
clxs_nexthopgroup_member_fail_handler (
    _In_ sai_object_id_t port_id);
#endif

#endif /* __CLXS_NEXTHOPGROUP_H__ */
