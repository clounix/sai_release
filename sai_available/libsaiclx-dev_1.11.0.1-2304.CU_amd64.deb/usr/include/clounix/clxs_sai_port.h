#if !defined (__CLXS_PORT_H__)
#define __CLXS_PORT_H__

#define CLXS_PORT_MAX_PFC_COUNT            (8)

#define CLXS_PORT_FOREACH(__unit__, __port__)                              \
    if ( __unit__ < CLXS_MAX_CHIP_NUM&&NULL != _clxs_port_cb[__unit__].port_db_ptr)                 \
    for (__port__ = 0; __port__ < CLX_PORT_NUM; __port__++)    \
    if (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port)

#define CLXS_FRONT_PORT_FOREACH(__unit__, __port__)                              \
    if ( __unit__ < CLXS_MAX_CHIP_NUM&&NULL != _clxs_port_cb[__unit__].port_db_ptr)                 \
    for (__port__ = 0; __port__ < CLX_PORT_NUM; __port__++)    \
    if ((CLXS_CPU_PORT(unit) != __port__) && (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port))

#define CLXS_PORT_DB_PTR(__unit__, __port__)        ((CLXS_PORT_UNIT_PORT_PRPRTY_T *)(_clxs_port_cb[__unit__].port_db_ptr + __port__ ))
#define CLXS_PORT_MAP_PTR(__unit__, __port__)       ((CLXS_PORT_MAP_T *)(_clxs_port_cb[__unit__].port_map + __port__))

#define CLXS_IS_ETH_PORT_VALID(__unit__, __port__)  ((__port__ < CLXS_MAX_PORT_NUM) && ((NULL == _clxs_port_cb[__unit__].port_db_ptr) ? false : (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port)))
#define CLXS_IS_PORT_VALID(__unit__, __port__)      ((__port__ < CLXS_MAX_PORT_NUM) && ((NULL == _clxs_port_cb[__unit__].port_db_ptr) ? false : (0 != CLXS_PORT_DB_PTR(__unit__, __port__)->clx_port)))

#define CHECK_PORT_ERR_RETURN(unit, port)  do {\
    CHECK_UNIT_ERR_RETURN(unit);    \
    if (!CLXS_IS_PORT_VALID(unit, port))\
    {\
        CLXS_LOG_ERR(__MODULE__, "Invalid unit %d, port %d", unit, port);\
        return SAI_STATUS_INVALID_PARAMETER;\
    }\
}while (0)

#ifdef CLX_PORT_IP_COUNT_USING_ACL
#define CLXS_PORT_IP_COUNT_PTR(__unit__, __port__)  ((CLXS_PORT_IP_COUNTER_DB_T *)(_clxs_port_cb[__unit__].port_ip_count_info + __port__))
#endif

typedef enum
{
    CLXS_PORT_BREAKOUT_CAPABILITY_NONE       = 0,
    CLXS_PORT_BREAKOUT_CAPABILITY_TWO        = 1,
    CLXS_PORT_BREAKOUT_CAPABILITY_FOUR       = 2,
    CLXS_PORT_BREAKOUT_CAPABILITY_TWO_FOUR   = 3     /*TODO: clarify this purpose*/
} clxs_port_breakout_capability_t;

typedef enum
{
    CLXS_PORT_POLICER_TYPE_REGULAR_INDEX     = 0,
    CLXS_PORT_POLICER_TYPE_FLOOD_INDEX       = 1,
    CLXS_PORT_POLICER_TYPE_BROADCAST_INDEX   = 2,
    CLXS_PORT_POLICER_TYPE_MULTICAST_INDEX   = 3,
    CLXS_PORT_POLICER_TYPE_MAX               = 4
} clxs_port_policer_type;

typedef struct CLXS_PORT_UNIT_PORT_PRPRTY_S
{
    uint8_t                         valid;
    CLX_PORT_T                      clx_port;
    CLX_PORT_SPEED_T                max_speed;
    CLX_PORT_MEDIUM_TYPE_T          medium_type;
    uint32_t                        lane_grp;  /*First lane number in the list*/
    uint8_t                         lane_num;
    uint8_t                         default_tc;
    uint16_t                        pvid;
    bool                            is_present;
    uint32_t                        admin_state;
    /*  SAI Port can have up to CLXS_PORT_POLICER_TYPE_MAX SDK port storm
     *  policers in use internally.  For each storm item we keep type of
     *  traffic it'll handle and SAI policer id which contains the policer
     *  attributes (cbs, pir, etc.) if SAI_NULL_OBJECT_ID == policer_id then
     *  given storm item is not in use currently.
     */
    sai_object_id_t                 ingress_policers[CLXS_PORT_POLICER_TYPE_MAX];
    sai_object_id_t                 ingress_samplepacket_obj;
    sai_object_id_t                 egress_samplepacket_obj;
    sai_object_id_t                 ingress_sample_mirror_session_obj;
    sai_object_id_t                 egress_sample_mirror_session_obj;
    sai_object_id_t                 wred_id;
    sai_object_id_t                 isolation_group_id;
    sai_object_id_t                 ing_acl_object;
    sai_object_id_t                 egr_acl_object;
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 1)
    sai_object_id_t                 port_serdes_id;
#endif
#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
    sai_object_list_t            tamlist;
#endif
#define CLXS_PORT_UNIT_PORT_FLAG_PARENT    (1 << 0)
    uint32_t                        flags;
    bool                            an_lt;
    uint32_t                        speed;
    int32_t                         fec;
    int32_t                         interface_type;

}CLXS_PORT_UNIT_PORT_PRPRTY_T;

#ifdef CLX_PORT_IP_COUNT_USING_ACL
/*iptype for ip count*/
typedef enum
{
    CLXS_PORT_IPCOUNT_IPTYPE_IPV4,
    CLXS_PORT_IPCOUNT_IPTYPE_IPV6,
    CLXS_PORT_IPCOUNT_IPTYPE_MAX
} CLXS_PORT_IPCOUNT_IPTYPE_T;

/*ip count db info*/
typedef struct CLXS_PORT_IP_COUNTER_DB_S
{
    bool        valid;
    uint32_t    unit;
    UI32_T      port;
    CLX_PORT_T  clx_port;
    UI32_T      acl_for_ip_counter_ing[CLXS_PORT_IPCOUNT_IPTYPE_MAX];   /*ingress 2 acl, 0-ipv4, 1-ipv6*/
    UI32_T      acl_for_ip_counter_egr[CLXS_PORT_IPCOUNT_IPTYPE_MAX];   /*egress 2 acl, 0-ipv4, 1-ipv6*/

    UI32_T      ing_counter_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];	 /*ingress 2 2xcounters, 0-ipv4,1-ipv6*/
    UI32_T      egr_counter_id[CLXS_PORT_IPCOUNT_IPTYPE_MAX];	 /*egress 2 2xcounters, 0-ipv4,1-ipv6*/
}CLXS_PORT_IP_COUNTER_DB_T;
#endif

typedef struct CLXS_PORT_MAP_S
{
    bool                        valid;
    uint32_t                    unit;
    uint32_t                    port;
    CLX_PORT_T                  clx_port;
    uint32_t                    dst_idx;
    sai_object_id_t             obj;
    char                        hostif_name[SAI_HOSTIF_NAME_SIZE];
}CLXS_PORT_MAP_T;

typedef struct  CLXS_PORT_LINK_S
{
    sai_pointer_t               callback_func;
    CLX_SEMAPHORE_ID_T          mutex;
    CLX_SEMAPHORE_ID_T          sema;
    CLX_THREAD_ID_T             thread_id;
    CMLIB_LIST_T                *event_list;
}CLXS_PORT_LINK_T;

typedef struct  CLXS_PORT_CB_S
{
    CLXS_PORT_UNIT_PORT_PRPRTY_T *port_db_ptr;
    CLXS_PORT_LINK_T            port_link;
    CLX_SEMAPHORE_ID_T          sema;
    uint32_t                    port_count;
    CLXS_PORT_MAP_T             *port_map;
#ifdef CLX_PORT_IP_COUNT_USING_ACL
    CLXS_PORT_IP_COUNTER_DB_T   *port_ip_count_info;
#endif
} CLXS_PORT_CB_T;

extern CLXS_PORT_CB_T _clxs_port_cb[];

typedef struct  CLXS_PORT_STAT_PFC_CB_S
{
    uint64_t                    rx_duration[CLXS_MAX_PORT_NUM][CLXS_PORT_MAX_PFC_COUNT];
    uint32_t                    interval_us;
    UI32_T                      thread_pri;
    CLX_THREAD_ID_T             thread_id;
    CLX_SEMAPHORE_ID_T          sema;
} CLXS_PORT_STAT_PFC_CB_T;

extern CLXS_PORT_STAT_PFC_CB_T *_clxs_port_stat_pfc_cb[];

typedef enum
{
    CLXS_PORT_IPTYPE_IPV4,
    CLXS_PORT_IPTYPE_IPV6,
    CLXS_PORT_IPTYPE_MAX
} CLXS_PORT_IPTYPE_T;
typedef struct CLXS_PORT_ECN_MARKED_COUNTER_DB_S
{
    bool        enabled;
    uint32_t    unit;
    UI32_T      port;
    CLX_PORT_T  clx_port;
    UI32_T      ecn_marked_entry_id[CLXS_PORT_IPTYPE_MAX];   /*ingress 2 acl mactch ecn = 0x2, 0-ipv4, 1-ipv6*/
    UI32_T      ecn_marked_counter_id[CLXS_PORT_IPTYPE_MAX];	 /*egress 2 2xcounters, 0-ipv4,1-ipv6*/
}CLXS_PORT_ECN_MARKED_COUNTER_DB_T;

typedef struct CLXS_PORT_ECN_MARKED_CB_S
{
    uint32_t        enable_count_num;
    uint32_t        egr_group_id;
    uint32_t        igr_group_id;
    uint32_t        ecn_marked_1_entry_id[CLXS_PORT_IPTYPE_MAX];   /*ingress 2 acl mactch ecn = 0x1, 0-ipv4, 1-ipv6*/
    uint32_t        ecn_marked_2_entry_id[CLXS_PORT_IPTYPE_MAX];   /*ingress 2 acl mactch ecn = 0x2, 0-ipv4, 1-ipv6*/
    CLXS_PORT_ECN_MARKED_COUNTER_DB_T   *port_ecn_marked_count_info;
}CLXS_PORT_ECN_MARKED_CB_T;

typedef struct CLXS_PORT_LAG_COMMON_ATTRS_S
{
    uint16_t        pvid;
}CLXS_PORT_LAG_COMMON_ATTRS_T;

extern const sai_port_api_t             port_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T port_stats_capability_info;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T port_pool_stats_capability_info;

typedef struct CLXS_PORT_SPEED_TABLE_S{
    CLX_PORT_SPEED_T    sdk_speed;
    uint32_t            sai_speed;
} CLXS_PORT_SPEED_TABLE_T;

typedef struct CLXS_PORT_INTERFACE_MEDIUM_TYPE_TABLE_S{
    int32_t                 interface_type;
    CLX_PORT_SPEED_T        sdk_speed;
    CLX_PORT_MEDIUM_TYPE_T  medium_type;
} CLXS_PORT_INTERFACE_MEDIUM_TYPE_TABLE_T;

sai_status_t
clxs_port_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_port_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_port_to_object(
    uint32_t            unit,
    uint32_t            port,
    sai_object_id_t     *ptr_object_id);

sai_status_t
clxs_port_registerCallback(
    _In_ const uint32_t         unit,
    _In_ void                   *func);


sai_status_t clxs_port_getPortNumber(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clxs_port_getMaxPortNumber(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clxs_port_getPortList(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clxs_port_getCpuPort(
    _In_ const uint32_t unit,
    _Inout_ sai_attribute_value_t  *ptr_value);

sai_status_t clxs_port_getTpid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const sai_switch_attr_t attr,
    _Out_ uint16_t * ptr_tpid);

sai_status_t clxs_port_setTpid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const sai_switch_attr_t attr,
    _In_ const uint16_t ptr_tpid);

sai_status_t
clxs_port_setBindEgrTable(
    sai_object_id_t     port_object,
    uint32_t        intf_group_label,
    bool        is_add);

sai_status_t
clxs_port_updatePortMapForName(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ const char *port_name);

sai_status_t
clxs_port_updateLagMbr(
    _In_ const sai_object_id_t              port_oid,
    _In_ const CLXS_PORT_LAG_COMMON_ATTRS_T *attrs,
    _In_ const bool                         is_add);

#if 0
CLX_ERROR_NO_T clxs_port_dpbRemovePort(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clxs_port_dpbCreatePort(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clxs_port_dpbSetPort(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clxs_port_dpbGetPort(
    _In_ const C8_T                *tokens[]);

CLX_ERROR_NO_T clxs_port_dpbShowPort(
    _In_ const C8_T                *tokens[]);
#ifdef CLX_PORT_IP_COUNT_USING_ACL
CLX_ERROR_NO_T clxs_port_dbgShowIpCountInfo(
    _In_ const C8_T                *tokens[]);
#endif
#endif

sai_status_t
clxs_port_getMirrorSessionOid(
    _In_ const uint32_t unit,
    _In_ const uint32_t port,
    _In_ bool igr,
    _Out_ sai_object_id_t *ptr_mirrorsession_oid);

sai_status_t
clxs_get_port_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_port_get_plane_id(
    UI32_T unit,
    UI32_T port,
    UI32_T *bin,
    UI32_T *plane_id);

sai_status_t
clxs_port_get_portlist(
    UI32_T unit, UI32_T bin,
    UI32_T plane_id,
    UI32_T *plist,
    UI32_T *count);


sai_status_t clxs_port_pool_getWredProfileID(
        uint32_t unit,uint32_t port,
        _Out_ sai_object_id_t* wredId);

void
_clxs_port_state_change_notify(
        _In_ uint32_t unit,
        _In_ uint32_t count,
        _In_ const sai_port_oper_status_notification_t *data);

CLX_ERROR_NO_T clxs_port_link_event_init(
    _In_ const uint32_t     unit);

sai_status_t clxs_port_traverse_set_stormctl_property(
    _In_ const uint32_t unit,
    _In_ const sai_object_id_t  policer_id,
    _In_ uint32_t      old_clx_cir,
    _In_ uint32_t      new_clx_cir);

sai_status_t clxs_port_getClxPort(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _Out_ CLX_PORT_T *ptr_clx_port);

sai_status_t clxs_port_getPortId(
    _In_ uint32_t unit,
    _In_ CLX_PORT_T clx_port,
    _Out_ uint32_t *ptr_port);

sai_status_t clxs_create_port(
    _Out_ sai_object_id_t *port_id,
    _In_ sai_object_id_t switch_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list);

sai_status_t clxs_remove_port(
    _In_ sai_object_id_t port_id);

sai_status_t clxs_set_port_attribute(
    _In_ sai_object_id_t port_id,
    _In_ const sai_attribute_t *attr);

sai_status_t clxs_get_port_attribute(
    _In_ sai_object_id_t port_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list);
#endif /* __CLXS_PORT_H__ */