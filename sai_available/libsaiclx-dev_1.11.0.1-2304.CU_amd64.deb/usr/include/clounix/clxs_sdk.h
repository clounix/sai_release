#if !defined (__CLXS_SDK_H__)
#define __CLXS_SDK_H__
#include <saitypes.h>
#ifdef CLX_SDK
#include <clx_types.h>
#include <clx_module.h>
#include <clx_vm.h>
#include <clx_init.h>
#include <clx_error.h>
#include <clx_lag.h>
#include <clx_ifmon.h>
#include <clx_acl.h>
#include <clx_swc.h>
#include <clx_l3t.h>
#include <clx_netif.h>
#include <clx_pkt.h>
#include <clx_fcoe.h>
#include <clx_l3.h>
#include <clx_stk.h>
#include <clx_nv.h>
#include <clx_sec.h>
#include <clx_mpls.h>
#include <clx_port.h>
#include <clx_l2.h>
#include <clx_stp.h>
#include <clx_ver.h>
#include <clx_mir.h>
#include <clx_cfg.h>
#include <clx_meter.h>
#include <clx_trill.h>
#include <clx_vlan.h>
#include <clx_tm.h>
#include <clx_stat.h>
#include <clx_qos.h>
#include <clx_dtel.h>
#include <clx_ifmap.h>
#include <cdb/cdb.h>
#include <hal/common/hal_io.h>
#include <hal/common/hal.h>
#include <hal/common/hal_obj.h>
#include <hal/switch/lightning/hal_lightning_ecc.h>
#include <cmlib/cmlib_list.h>
#include <cmlib/cmlib_avl.h>
#include <cmlib/cmlib_bitmap.h>
#include <cmlib/cmlib_hash.h>
#include <cmlib/cmlib_crc.h>
#include <osal/osal_types.h>
#include <osal/osal.h>
#include <osal/osal_lib.h>
#include <osal/osal_dma.h>
#endif

#define CLXS_MAX_CHIP_NUM                (16)
#define CLXS_MAX_PORT_NUM                (CLX_PORT_NUM)
#define CLXS_MAX_VLAN_NUM                (4096)
#define CLXS_MAX_FDB_NUM                 (65536) /* default config */

/* The value come from osal_dma.h (#define OSAL_DMA_MEM_SIZE  (4*1024*1024)) */
#define CLXS_DMA_MEM_SIZE                  (4*1024*1024)

#define CLXS_MAX_TAM_OBJECT_COUNT 256
#define CLXS_MAX_SNAPSHOT_COUNT 256
#define CLXS_MAX_TAM_STAT_OBJECT_COUNT 1024
#define CLXS_MAX_TAM_THRESHOLD_OBJECT_COUNT 1024
#define CLXS_MAX_TAM_SNAPSHOT_OBJECT_COUNT 1024
#define CLXS_MAX_TAM_TRANSPORTER_OBJECT_COUNT 32
#define CLXS_MAX_TAM_MICROBURST_OBJECT_COUNT 1024
#define CLXS_MAX_TAM_HISTOGRAM_OBJECT_COUNT 1024

#define CLXS_DFLT_VLAN               (1)
#define CLXS_DFLT_STP                (0)
#define CLXS_DFLT_1Q_BRIDGE_ID       (1)
#define CLXS_VLAN_BMP_SIZE           (CLX_BITMAP_SIZE(CLXS_MAX_VLAN_NUM))


#define CLXS_IS_UNIT_VALID(__unit__)                ((__unit__ >= CLXS_MAX_CHIP_NUM) ? false : clxs_switch_getUnitInited(__unit__))

#define CLXS_ECN_MARKED_INGRESS_ACL_GROUP_LABEL      0x6e
#define CLXS_ECN_MARKED_INGRESS_ACL_GROUP_LABEL_MASK 0xffffffff
#define CLXS_PORT_ECN_MARKED_COUNT_PTR(__unit__, __port__)  ((CLXS_PORT_ECN_MARKED_COUNTER_DB_T *)(_clxs_port_ecn_marked_cb[unit].port_ecn_marked_count_info + __port__))

#define CLXS_CHECK_PTR(__ptr__, __msg__) \
    do                         \
    {                                                              \
        if (NULL == __ptr__)                                       \
        {                                                          \
            CLXS_LOG_ERR(__MODULE__, "%s", __msg__);                \
            return SAI_STATUS_INVALID_PARAMETER;                   \
        }                                                          \
    } while (0)

#define CLXS_UNIT_FOREACH(__unit__)                              \
    for (__unit__ = 0; __unit__ < CLXS_MAX_CHIP_NUM; __unit__++)    \
        if (clxs_switch_getUnitInited(__unit__))


struct avl_cookie
{
    UI32_T length;
    void* data;
};

struct avl_cookie_box
{
    UI32_T count;
    struct avl_cookie* cookies;
};

static inline UI32_T
cmlib_bitmap_findFirstOne(
    UI32_T ui32_map)
{
    UI32_T shift_count;
    static const C8_T lookup_table[] =
    {
        4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 /*0 is invalid*/
    };

    for (shift_count = 0; shift_count < 32; shift_count += 8)
    {
        if ((ui32_map & 0xff) != 0)
        {
            break;
        }
        ui32_map >>= 8;
    }
    if (ui32_map & 0x0f)
        return lookup_table[ui32_map & 0x0f] + shift_count;
    return lookup_table[(ui32_map>>4) & 0x0f] + shift_count + 4;
}

#define CMLIB_BITMAP_NEXT(bitmap, word, from, bit) \
({\
    unsigned int i = ((from) + 1)/32;  \
    unsigned int offset = ((from)+1) %32;  \
    if (offset && (i < word) && bitmap[i] >=(unsigned int)(1<< offset))  \
        bit = i*32 + cmlib_bitmap_findFirstOne(bitmap[i] & ~((1<<offset)-1)); \
    else  \
    { \
        if (offset) i++; \
        for(; i<(word); i++) \
        { \
            if (bitmap[i]) \
            {    \
                bit = i* 32 + cmlib_bitmap_findFirstOne(bitmap[i]); \
                break; \
            } \
        }  \
        if (i == (word))bit = (word)*32;\
    } \
})

#define CMLIB_BITMAP_FIRST(bitmap, word, bit) \
({\
    unsigned int i; \
    for(i = 0; i < (word); i++) \
    { \
        if (bitmap[i]) \
        { \
            bit = i*32 + cmlib_bitmap_findFirstOne(bitmap[i]); \
            break; \
        } \
    } \
    if (i == (word))bit = (word)*32; \
})

#define CMLIB_BITMAP_FOREACH(bitmap, bit, word)  \
for (CMLIB_BITMAP_FIRST(bitmap, word, bit); bit < (word)*32; CMLIB_BITMAP_NEXT(bitmap, word, bit, bit))


#define CMLIB_LIST_FOREACH(ptr_list, ptr_data, ptr_node) \
    for ( cmlib_list_locateHead(ptr_list, &ptr_node); \
          ptr_node && CLX_E_OK == cmlib_list_getNodeData(ptr_list, ptr_node, (void**)&ptr_data); \
          cmlib_list_next(ptr_list, ptr_node, &ptr_node))
#define CMLIB_LIST_FOREACH_SAFE(ptr_list, ptr_data, ptr_node, ptr_next_node) \
    for ( cmlib_list_locateHead(ptr_list, &ptr_node); \
          ptr_node && (CLX_E_OK == cmlib_list_getNodeData(ptr_list, ptr_node, (void**)&ptr_data)); \
          (ptr_next_node = NULL,cmlib_list_next(ptr_list, ptr_node, &ptr_next_node),ptr_node = ptr_next_node))


typedef enum
{
    CLXS_SRV_LRN_MODE_EXCPT,     /* sa_miss: except, lrn: dis */
    CLXS_SRV_LRN_MODE_FWD,       /* sa_miss: fwd,    lrn: dis */
    CLXS_SRV_LRN_MODE_LRN,       /* sa_miss: fwd,    lrn: en  */
    CLXS_SRV_LRN_MODE_LAST
} CLXS_SRV_LRN_MODE_T;

typedef enum
{
    CLXS_SRV_BUM_TYPE_BROADCAST = 0,
    CLXS_SRV_BUM_TYPE_UNKNOWN_MULTICAST,
    CLXS_SRV_BUM_TYPE_UNKNOWN_UNICAST,
    CLXS_SRV_BUM_TYPE_LAST
} CLXS_SRV_BUM_TYPE_T;

#endif /* __CLXS_SDK_H__ */
