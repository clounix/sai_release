#if !defined (__CLXS_NEXTHOP_H__)
#define __CLXS_NEXTHOP_H__

/* NAMING CONSTANT DECLARATIONS
 */
#define INVALID_L3_ADJ_ID 0xffffffff

#define CREATE_NEXTHOP  (1 << 0)
#define REMOVE_NEXTHOP  (1 << 1)
#define ADD_MACADDR     (1 << 2)
#define DEL_MACADDR     (1 << 3)
#define SET_ADJACTION   (1 << 4)

/*although these cmds can not exist at same time, maybe we can use enum to describe it
   but i keep the possibility something can do together*/
#define SET_TUNNEL_VNI     (1 << 0)
#define UNSET_TUNNEL_VNI     (1 << 1)
#define SET_TUNNEL_MAC      (1 << 2)
#define UPDATE_VRF_VNI      (1 << 3)
#define ADD_ROUTE      (1 << 4)
#define DELETE_ROUTE      (1 << 5)

extern const sai_next_hop_api_t         nexthop_api;

/* API DECLARATIONS
 */
sai_status_t
clxs_nexthop_init(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthop_deinit(
    _In_ const uint32_t         unit);

sai_status_t
clxs_nexthop_getObj(
    _In_ const uint32_t         unit,
    _In_ const uint32_t         adj_id,
    _Out_ sai_object_id_t       *ptr_next_hop_id);

sai_status_t
clxs_nexthop_getInfo(
    _In_ const sai_object_id_t  next_hop_id,
    _In_ const uint32_t  vrf_id,
    _In_ const uint32_t  flags,
    _Out_ uint32_t              *ptr_unit,
    _Out_ uint32_t              *ptr_adj_id);

sai_status_t clxs_nexthop_updateL2Addr(
    _In_ const uint32_t              unit,
    _In_ const CLX_L2_ADDR_T         *ptr_l2_addr,
    _In_ const uint32_t              reason);


void clxs_nexthop_tunnel_map_encap_update(uint32_t unit, uint32_t vrf_id, uint32_t vni);
void clxs_nexthop_switch_vxlan_mac_update(uint32_t unit);

sai_status_t
clxs_nexthop_set_ip_adj(
    _In_  uint32_t              unit,
    _In_ sai_object_id_t        rif_id,
    _In_ sai_ip_address_t       ip_address,
    _In_ uint32_t               flags,
    _In_ void                   *mac_addr,
    _Out_ uint32_t              *out_adj_id);

sai_status_t clxs_nexthop_update_by_adj_id(
    _In_  uint32_t              unit,
    _In_  uint32_t              vrf_id,
    _In_  uint32_t              adj_id);

sai_status_t
clxs_nexthop_get_adj_id(
    _In_ uint32_t               unit,
    _In_ sai_object_id_t        rif_id,
    _In_ sai_ip_address_t       ip_address,
    _Out_ uint32_t              *out_adj_id);


#endif /* __CLXS_NEXTHOP_H__ */
