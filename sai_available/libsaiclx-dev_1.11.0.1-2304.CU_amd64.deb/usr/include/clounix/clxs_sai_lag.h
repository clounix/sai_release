#if !defined (__CLXS_LAG_H__)
#define __CLXS_LAG_H__

extern const sai_lag_api_t              lag_api;

/* API DECLARATIONS
 */
sai_status_t
clxs_lag_init(
    _In_ const uint32_t unit);

sai_status_t
clxs_lag_deinit(
    _In_ const uint32_t unit);

sai_status_t
clxs_lag_getInfo(
    _In_ const sai_object_id_t oid,
    _Out_ uint32_t             *ptr_unit,
    _Out_ CLX_PORT_T           *ptr_lag_port);

sai_status_t
clxs_lag_getObject(
    _In_ const uint32_t   unit,
    _In_ const CLX_PORT_T lag_port,
    _Out_ sai_object_id_t *ptr_oid);

sai_status_t
clxs_lag_setBindEgrTable(
    sai_object_id_t    lag_object,
    uint32_t        intf_group_label,
    bool        is_add);

sai_status_t
clxs_get_lag_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t
clxs_get_lag_member_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#ifdef CLX_LAG_MEMBER_AUTO_UPDATE
void
clxs_lag_member_fail_handler (
    _In_ sai_object_id_t            port_id,
    _In_ sai_port_oper_status_t     port_state);
#endif
#endif /* __CLXS_LAG_H__ */
