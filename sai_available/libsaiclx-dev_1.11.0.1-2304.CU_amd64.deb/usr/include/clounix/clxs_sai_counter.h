#if !defined (__CLXS_COUNTER_H__)
#define __CLXS_COUNTER_H__

#if SAI_API_VERSION >= SAI_VERSION(1, 5, 0)
#define CLXS_COUNTER_GRPLABEL_DST_MIN             (0)
#define CLXS_COUNTER_GRPLABEL_DST_MAX             (0x7ff)

#define CLXS_COUNTER_MAPPED_DST_MASK             (0x7ff)
#define CLXS_COUNTER_MAPPED_NUM           (2047)
#define CLXS_COUNTER_MAPPED_SIZE           (CLX_BITMAP_SIZE(CLXS_COUNTER_MAPPED_NUM))
#define CLXS_META_MAPPED_SIZE               (10)

#define CLXS_COUNTER_TYPE_DIST       1
#define CLXS_COUNTER_TYPE_SRV        2

extern const sai_counter_api_t counter_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T counter_stats_capability_info;

sai_status_t
clxs_get_CounterInfo(
    _In_ sai_object_id_t counter_id,
    _Out_ uint32_t *cnt_id,
    _Out_ uint32_t *cnt_type);

#define CLXS_COUNTER_L3_OPTFLAGS_REMOVE       (0)
#define CLXS_COUNTER_L3_OPTFLAGS_CREATE        (1)
#define CLXS_COUNTER_GRPLABEL_CREATE        (1)
#define CLXS_COUNTER_GRPLABEL_REMOVE        (0)

#define CLXS_L3_GRPLABEL_FLAGS_META             (1 << 0)
#define CLXS_L3_GRPLABEL_FLAGS_COUNTER         (1 << 1)

sai_status_t
clxs_counter_init(
    _In_ const uint32_t      unit);

sai_status_t
clxs_counter_deinit(
    _In_ const uint32_t      unit);

sai_status_t
clxs_counter_operate(
    _In_ uint32_t unit,
    _In_ uint32_t optflags,
    _In_ sai_object_id_t counter_id,
    _In_ sai_ip_addr_family_t addr_family,
    _Out_ uint32_t *ptr_group_label);

#endif
#endif
