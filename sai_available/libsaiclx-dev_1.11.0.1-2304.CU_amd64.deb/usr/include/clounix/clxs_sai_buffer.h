#if !defined (__CLXS_BUFFER_H__)
#define __CLXS_BUFFER_H__

#define CLXS_BUF_ING_POOL_NUM        (10)
#define CLXS_BUF_EGR_POOL_NUM        (10)
#define CLXS_BUF_MAX_PROFILE_NUM   (128)

typedef enum _CLXS_BUFFER_PORT_TYPE_T
{
    PORT_BUFF_TYPE_INGRESS,
    PORT_BUFF_TYPE_EGRESS,
    PORT_BUFF_TYPE_PG,
    PORT_BUFF_TYPE_QUEUE
} CLXS_BUFFER_PORT_TYPE_T;

typedef struct _CLXS_BUFFER_CAPACITY_T
{
    uint32_t num_ingress_pools;
    uint32_t num_egress_pools;
    uint32_t num_total_pools;
    uint32_t num_port_queue_buff;
    uint32_t num_port_pg_buff;
    uint32_t unit_size;
    uint32_t max_buffer_profiles;
} CLXS_BUFFER_CAPACITY_T;

typedef struct _CLXS_BUFFER_POOL_ATTR_T
{
    uint32_t                    clxs_pool_id;
    /*size in bytes*/
    uint64_t                    pool_size;
    uint64_t                    pool_xoff_size;
    sai_buffer_pool_type_t      pool_type;
    sai_buffer_pool_threshold_mode_t pool_mode;
    sai_object_id_t             wred_profile_id;
} CLXS_BUFFER_POOL_ATTR_T;

extern  CLXS_BUFFER_CAPACITY_T buffer_limits[CLXS_MAX_CHIP_NUM];
extern const sai_buffer_api_t           buffer_api;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T ing_pg_stats_capability_info;
extern CLXS_OBJ_TYPE_STATS_CAPABILITY_INFO_T buffer_pool_stats_capability_info;

sai_status_t clxs_buffer_set_profile_to_obj(
    _In_ CLXS_BUFFER_PORT_TYPE_T port_buff_type,
    _In_ sai_object_id_t object_id,
    _In_ sai_object_id_t profile);

sai_status_t
clxs_buffer_get_port_profile_list(
    _In_ CLXS_BUFFER_PORT_TYPE_T port_buff_type,
    _In_ sai_object_id_t    object_id,
    _Inout_ sai_attribute_value_t       *ptr_value);

sai_status_t clxs_buffer_get_port_pool_list(
    _In_ sai_object_id_t    object_id,
    _Inout_ sai_attribute_value_t       *ptr_value);

sai_status_t clxs_buffer_init(uint32_t unit);

sai_status_t clxs_buffer_add_port(
    _In_ uint32_t unit,
    _In_ uint32_t port);

sai_status_t clxs_buffer_deinit(uint32_t unit);

sai_status_t clxs_buffer_getPriorityGroupCount(
    _In_ sai_object_id_t port_object_id,
    _Out_ uint32_t *ptr_count);

sai_status_t clxs_buffer_getPriorityGroupList(
    _In_ sai_object_id_t port_object_id,
    _Out_ sai_object_id_t *ptr_list);

sai_status_t
clxs_buffer_updatePortPgBuffer(
    _In_ uint32_t    unit,
    _In_ uint32_t    port,
    _In_ uint32_t    pg_idx,
    _In_ uint32_t    pfc_enable);

CLX_ERROR_NO_T clxs_buffer_getHandler(
    _In_ uint32_t unit,
    _In_ uint32_t port,
    _In_ uint32_t type,
    _In_ uint32_t queue_id,
    _Out_ CLX_TM_HANDLER_T *ptr_handler);

uint32_t clxs_buffer_clxs_cells_to_bytes( uint32_t unit,uint32_t cells);

sai_status_t clxs_buffer_get_pool_data_ext(
    _In_ sai_object_id_t             sai_pool,
    _Out_ CLXS_BUFFER_POOL_ATTR_T *ptr_sai_pool_attr);
#if SAI_API_VERSION >= SAI_VERSION(1,5,0)
sai_status_t
clxs_buffer_get_pg_data(
    _In_ uint32_t unit,
    _In_ sai_object_id_t sai_pg,
    _Out_ uint32_t       *ptr_port,
    _Out_ uint32_t       *ptr_port_pg_index);

sai_status_t
clxs_buffer_pg_getUnitId(
    _In_ sai_object_id_t       object_id,
    _Out_ uint32_t *ptr_unit);
#endif

sai_status_t clxs_get_buffer_pool_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

sai_status_t clxs_get_buffer_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif
