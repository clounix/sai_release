#if !defined (__CLXS_SCHEDULER_H__)
#define __CLXS_SCHEDULER_H__

#define CLXS_MAX_SCHEDULER_PROFILE_NUM(__unit__)   ((CLXS_MAX_PORT_NUM) * ( CLXS_QUEUE_UC_NUM(__unit__) +CLXS_QUEUE_MC_NUM(__unit__) ))  /* all ports with 8 uc and 8 mc*/

extern const sai_scheduler_api_t        scheduler_api;

/* API DECLARATIONS
 */
sai_status_t clxs_scheduler_setToPort(
    sai_object_id_t     object_id,
    sai_object_id_t     scheduler_id);

sai_status_t clxs_scheduler_getFromPort(
    sai_object_id_t     object_id,
    sai_object_id_t     *ptr_scheduler_id);

sai_status_t clxs_scheduler_applyToQueueGroup(
    sai_object_id_t     scheduler_id,
    uint32_t            port,
    CLX_TM_HANDLER_T    handler);

sai_status_t clxs_scheduler_init(
    uint32_t unit);

sai_status_t clxs_scheduler_deinit(
    uint32_t unit);

sai_status_t clxs_get_scheduler_profile_count(
    _In_ const uint32_t unit,
    _Out_ uint32_t *count);

#endif /* __CLXS_SCHEDULER_H__ */
