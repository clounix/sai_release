#if !defined (__CLXS_BFD_H__)
#define __CLXS_BFD_H__

extern const sai_bfd_api_t               bfd_api;

/* API DECLARATIONS
 */


#endif /* __CLXS_BFD_H__ */
