#if !defined (__CLXS_MACSEC_H__)
#define __CLXS_MACSEC_H__

#if SAI_API_VERSION >= SAI_VERSION(1,6,0)
extern const sai_macsec_api_t   macsec_api;

/* API DECLARATIONS
 */

#endif
#endif /* __CLXS_MACSEC_H__ */
