/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_sec.h
 * PURPOSE:
 *      Define the declartion for Security module.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_SEC_H
#define HAL_SEC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_cfg.h>
#include <clx_types.h>
#include <clx_error.h>
#include <clx_sec.h>
#include <clx_port.h>
#include <osal/osal.h>
#include <dcc/dcc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

#define HAL_SEC_DOS_EXCEPTION_CHECK        (32 *3 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W0_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W0_SDK_DOS_CHK_0_FIELD_ID].offset)
#define HAL_SEC_DOS_EXCEPTION_TRAP         (32 *3 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W0_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W0_SDK_DOS_CHK_1_FIELD_ID].offset)
#define HAL_SEC_DOS_EXCEPTION_SUPP         (32 *3 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W0_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W0_SDK_DOS_CHK_2_FIELD_ID].offset)

#define HAL_LIGHTNING_SEC_DOS_EXCEPTION_TRAP     (32 *1 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W2_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W2_ETH_IP_HDR_FIELD_ID].offset)
#define HAL_LIGHTNING_SEC_DOS_EXCEPTION_SUPP     (32 *3 + CDB_TABLE(unit, REG_IDS_CFG_EXCPT_EN_W0_ID)->ptr_table_entry[IDS_CFG_EXCPT_EN_W0_L3_MTU_FIELD_ID].offset)


    /* meter rate granularity, unit: kbps */
#define HAL_SEC_SCMETER_RATE_GRANULARITY(unit)    \
            (HAL_IS_DEVICE_DAWN_FAMILY(unit)? (64) : (8))

    /* meter bucket granularity, unit: byte */
#define HAL_SEC_SCMETER_BUCKET_SIZE_GRANULARITY(unit)  \
                (HAL_IS_DEVICE_DAWN_FAMILY(unit)? (64) : (8))

#define HAL_SEC_SCMETER_RATE_MAX                        (480000000)     /* 480M Kbps = 480Gbps */
#define HAL_SEC_SCMETER_BUCKET_SIZE_MAX                 (64000000)      /* 64M bytes */
#define HAL_SEC_SCMETER_BUCKET_SIZE_DEFAULT             (9216+20+64)    /* static value: */

#define HAL_SEC_MTR_PKT_LEN                             (128)

#define HAL_SEC_IFP_IPSG_BLOCK_NUM                      (3)
#define HAL_SEC_IFP_IPSG_HASH_DEPTH                     (4)
#define HAL_SEC_IFP_IPSG_BUCKET_NUM                     (512)
#define HAL_SEC_IFP_IPSG_ENTRY_KEY_LENGTH               (3)
#define HAL_SEC_IFP_IPSG_128_ENTRY_KEY_LENGTH           (9)

#define HAL_SEC_DOS_LOCK(unit)      hal_sec_sema((unit), HAL_SEC_ACT_LOCK,   HAL_SEC_ST_DOS)
#define HAL_SEC_SC_LOCK(unit)       hal_sec_sema((unit), HAL_SEC_ACT_LOCK,   HAL_SEC_ST_SC)
#define HAL_SEC_SG_LOCK(unit)       hal_sec_sema((unit), HAL_SEC_ACT_LOCK,   HAL_SEC_ST_SG)
#define HAL_SEC_TI_LOCK(unit)       hal_sec_sema((unit), HAL_SEC_ACT_LOCK,   HAL_SEC_ST_TI)
#define HAL_SEC_DOS_UNLOCK(unit)    hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_DOS)
#define HAL_SEC_SC_UNLOCK(unit)     hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_SC)
#define HAL_SEC_SG_UNLOCK(unit)     hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_SG)
#define HAL_SEC_TI_UNLOCK(unit)     hal_sec_sema((unit), HAL_SEC_ACT_UNLOCK, HAL_SEC_ST_TI)

typedef enum
{
    HAL_SEC_ACT_INIT,
    HAL_SEC_ACT_DEINIT,
    HAL_SEC_ACT_LOCK,
    HAL_SEC_ACT_UNLOCK,
    HAL_SEC_ACT_LAST,
} HAL_SEC_ACTION_T;

/* Security SDK API Semaphore Type */
typedef enum
{
    HAL_SEC_ST_DOS,
    HAL_SEC_ST_SC,
    HAL_SEC_ST_SG,
    HAL_SEC_ST_TI,
    HAL_SEC_ST_LAST
} HAL_SEC_SEMAPHORE_TYPE_T;

/* storm control counter pool entry */
typedef struct HAL_SEC_SCCOUNTER_ENTRY_S
{
    UI64_T  cnt[3];     /* cnt[0]: fwd byte;
                         * cnt[1]: fwd packet;
                         * cnt[2]: drop packet
                         */
} HAL_SEC_SCCOUNTER_ENTRY_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_sec_init
 * PURPOSE:
 *      Initialize security module.
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_init(
    const UI32_T             unit);

/* FUNCTION NAME: hal_sec_deinit
 * PURPOSE:
 *      Deinitialize security module.
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_deinit(
    const UI32_T             unit);

/* FUNCTION NAME:   hal_sec_sema
 * PURPOSE:
 *      Operate security controlled semaphore
 * INPUT:
 *      unit   --  Device unit number
 *      action --  Device resource action
 *      type   --  Device resource type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_sec_sema(
    const UI32_T                        unit,
    const HAL_SEC_ACTION_T          action,
    const HAL_SEC_SEMAPHORE_TYPE_T  type);

/* FUNCTION NAME:   hal_sec_setDosPortConfig
 * PURPOSE:
 *      set port DoS configuration. (add profile or record reference counter)
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  physical port ID.
 *      ptr_entry       --  DoS per port configuration.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sec_setDosPortConfig (
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_DOS_PORT_CONFIG_T *ptr_entry );

/* FUNCTION NAME:   hal_sec_getDosPortConfig
 * PURPOSE:
 *      get port DoS configuration. (get the port DoS profile id, and get dos profile entry)
 * INPUT:
 *      unit            --  Device unit number.
 *      port            --  physical port ID.
 * OUTPUT:
 *      ptr_entry       --  DoS per port configuration.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sec_getDosPortConfig (
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SEC_DOS_PORT_CONFIG_T       *ptr_entry );

CLX_ERROR_NO_T
hal_sec_getDosPortProfileInfo(
    const UI32_T                    unit,
    const UI32_T                    port,
    UI32_T                          *ptr_profile_id,
    UI32_T                          *ptr_ref_cnt);

/* FUNCTION NAME:   hal_sec_setDosConfig
 * PURPOSE:
 *      set global DoS configuration. (update all profile)
 * INPUT:
 *      unit            --  Device unit number.
 *      ptr_entry       --  DoS global configuration.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sec_setDosConfig (
    const UI32_T                    unit,
    const CLX_SEC_DOS_CONFIG_T      *ptr_entry);

/* FUNCTION NAME:   hal_sec_getDoSPortConfig
 * PURPOSE:
 *      get global DoS configuration. (get profile 0)
 * INPUT:
 *      unit            --  Device unit number.
 * OUTPUT:
 *      ptr_entry       --  DoS global configuration.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sec_getDosConfig (
    const UI32_T                    unit,
    CLX_SEC_DOS_CONFIG_T            *ptr_entry );

/* FUNCTION NAME: hal_sec_setStormCtrlProperty
 * PURPOSE:
 *      Set storm control properties on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 *      ptr_entry   --  The storm control properties for the physical port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_setStormCtrlProperty (
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_STORM_CTRL_T      *ptr_entry);

/* FUNCTION NAME: hal_sec_getStormCtrlProperty
 * PURPOSE:
 *      Get storm control properties on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 * OUTPUT:
 *      ptr_entry   --  The storm control properties for the physical port.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlProperty (
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_SEC_STORM_CTRL_T            *ptr_entry);

/* FUNCTION NAME: hal_sec_getStormCtrlCnt
 * PURPOSE:
 *      Get storm control counter on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 *      type        --  The storm control counter type.
 * OUTPUT:
 *      ptr_cnt     --  The storm control counter.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlCnt(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_SEC_STORM_CTRL_TYPE_T type,
    CLX_SEC_STORM_CTRL_CNT_T        *ptr_cnt);

/* FUNCTION NAME: hal_sec_setStormCtrlCtrlPktEn
 * PURPOSE:
 *      Set storm control enable for control packets.
 * INPUT:
 *      unit        --  Device unit number.
 *      enable      --  Enable/Disable storm control for control packets.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_setStormCtrlCtrlPktEn (
    const UI32_T                    unit,
    const UI32_T                    enable);

/* FUNCTION NAME: hal_sec_getStormCtrlCtrlPktEn
 * PURPOSE:
 *      Set storm control enable for control packets.
 * INPUT:
 *      unit        --  Device unit number.
 * OUTPUT:
 *      ptr_enable  --  Enable/Disable storm control for control packets.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlCtrlPktEn (
    const UI32_T                    unit,
    UI32_T                          *ptr_enable);

/* FUNCTION NAME: hal_sec_setStormCtrlMeterLayer
 * PURPOSE:
 *      Set storm control meter layer mode(L1/L2).
 * INPUT:
 *      unit            --  Device unit number.
 *      layer_mode      --  storm control meter layer mode.
 *                          1 - layer 1; 0 - layer 2
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_setStormCtrlMeterLayer(
    const UI32_T                    unit,
    const UI32_T                    layer_mode);

/* FUNCTION NAME: hal_sec_setStormCtrlMeterLayer
 * PURPOSE:
 *      Set storm control meter layer mode(global).
 * INPUT:
 *      unit            --  Device unit number.
 *      ptr_layer_mode  --  storm control meter layer mode
 *                          1 - layer 1; 0 - layer 2
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getStormCtrlMeterLayer(
    const UI32_T                    unit,
    UI32_T                          *ptr_layer_mode);

/* FUNCTION NAME: hal_sec_setSourceGuardProperty
 * PURPOSE:
 *      Set source guard properties on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 *      ptr_entry   --  The source guard properties for the physical port.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_setSourceGuardProperty(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    const CLX_SEC_SG_PROPERTY_T     *ptr_entry);

/* FUNCTION NAME: hal_sec_getSourceGuardProperty
 * PURPOSE:
 *      Get source guard properties on a physical port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Physical port ID.
 * OUTPUT:
 *      ptr_entry   --  The source guard properties for the physical port.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getSourceGuardProperty(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    CLX_SEC_SG_PROPERTY_T           *ptr_entry);

/* FUNCTION NAME: hal_sec_addSourceGuardEntry
 * PURPOSE:
 *      Add a source guard entry.
 * INPUT:
 *      unit        --  Device unit number.
 *      ptr_entry   --  Source guard entry.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_addSourceGuardEntry(
    const UI32_T                    unit,
    const CLX_SEC_SG_ENTRY_T        *ptr_entry);

/* FUNCTION NAME: hal_sec_delSourceGuardEntry
 * PURPOSE:
 *      Delete a source guard entry.
 * INPUT:
 *      unit        --  Device unit number.
 *      ptr_entry   --  Source guard entry.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_delSourceGuardEntry(
    const UI32_T                    unit,
    const CLX_SEC_SG_ENTRY_T        *ptr_entry);

/* FUNCTION NAME: hal_sec_getSourceGuardEntry
 * PURPOSE:
 *      Get a source guard entry.
 * INPUT:
 *      unit        --  Device unit number.
 * OUTPUT:
 *      ptr_entry   --  Source guard entry.
 * RETURN:
 *      CLX_E_OK  --  Operation success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_sec_getSourceGuardEntry(
    const UI32_T                    unit,
    CLX_SEC_SG_ENTRY_T              *ptr_entry);

/* FUNCTION NAME: hal_sec_setEgressPort
 * PURPOSE:
 *      Set the egress portlist for an ingress port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Ingress port ID.
 *      port_bitmap --  Egress port bitmap.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      For a given ingress port, the packet is allowed to the egress port
 *      only if corresponding bit of the port is set in the port bitmap.
 */
CLX_ERROR_NO_T
hal_sec_setEgressPort(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_PORT_BITMAP_T         port_bitmap);

/* FUNCTION NAME: hal_sec_getEgressPort
 * PURPOSE:
 *      Get the egress portlist for an ingress port.
 * INPUT:
 *      unit        --  Device unit number.
 *      port        --  Ingress port ID.
 * OUTPUT:
 *      port_bitmap --  Egress port bitmap.
 * RETURN:
 *      CLX_E_OK  --  Operate success.
 *      CLX_E_OTHERS  --  Operation fail.
 * NOTES:
 *      For a given ingress port, the packet is allowed to the egress port
 *      only if corresponding bit of the port is set in the port bitmap.
 */
CLX_ERROR_NO_T
hal_sec_getEgressPort(
    const UI32_T                    unit,
    const UI32_T                    port,
    CLX_PORT_BITMAP_T               port_bitmap);

/* FUNCTION NAME:   hal_sec_resetPortDefault
 * PURPOSE:
 *      Reset source port suppession.
 * INPUT:
 *      unit -- Device unit number
 *      port -- Ingress port ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Port beyond range.
 * NOTES:
 *      None
 */

CLX_ERROR_NO_T
hal_sec_resetPortDefault(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_sec_setPortDefault
 * PURPOSE:
 *      Set source port suppession.
 * INPUT:
 *      unit -- Device unit number
 *      port -- Ingress port ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Port beyond range.
 * NOTES:
 *      None
 */

CLX_ERROR_NO_T
hal_sec_setPortDefault(
    const UI32_T    unit,
    const UI32_T    port);

#endif /* End of HAL_SEC_H */


