#define CLNX_SAI_COMMIT_ID "2a0667163ba4f29150bcf27487b98bcb5bd40b8c"
#define CLNX_SAI_GIT_BRANCH "v1.7_ks_yangjie-bj_inc-dirty"
#define CLNX_SAI_BUILD_TIME "Wed Mar 30 10:20:25 UTC 2022"
#define CLNX_SDK_COMMIT_ID "f77170b36c5575e921451b454c518ce7193dc21e(clx_system_1.1.0_candidate3)"
#define CLNX_SAI_BUILD_BY "yangjie-bj@hszswls001"
#define SAI_VERSION_CODE 67329
#define CLNX_SAI_HEAD_VERSION "1.7.1"
#define SAI_VER(a,b,c) (((a)<<16)+((b)<<8)+(c))
