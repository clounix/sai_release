/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_sfc.h
 * PURPOSE:
 *      It provide sfc module api.
 * NOTES:
 *
 */

#ifndef CLX_SFC_H
#define CLX_SFC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>

#include <clx_l3.h>
/* NAMING CONSTANT DECLARATIONS
 */


/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef struct CLX_SFC_ENCAP_KEY_S
{
    UI32_T      spi;            /* Service path identifier */
    UI32_T      si;             /* Service index */
    UI32_T      length;         /* Length */
    UI32_T      metadata_type;  /* Metadata type */
    UI32_T      context_hdr[4]; /* Context header */
    CLX_PORT_T  underlay_port;  /* Tunnel */
    UI32_T      adj_id;         /* Nvo3_adj (SFCoETH) */
}   CLX_SFC_ENCAP_KEY_T;

typedef struct CLX_SFC_FORWARDER_S
{
    UI32_T  spi;                        /* Service path identifier */
    UI32_T  si;                         /* Service index */
    CLX_L3_OUTPUT_TYPE_T output_type;   /* Refer to CLX_L3_OUTPUT_TYPE_T */
    UI32_T  output_id;                  /* Only support ADJ & ECMP type */

#define CLX_SFC_FORWARDER_FLAGS_RM_SFC  (0x1U << 0) /* Remove SFC header */
        UI32_T             flags;
}   CLX_SFC_FORWARDER_T;


/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: clx_sfc_createPort
 * PURPOSE:
 *      Create SFC port
 * INPUT:
 *      unit      --  Device unit number
 *      ptr_key   --  SFC header content
 * OUTPUT:
 *      ptr_port  --  Pointer to the generated SFC port
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_sfc_createPort(
    const UI32_T unit,
    const CLX_SFC_ENCAP_KEY_T *ptr_key,
    CLX_PORT_T *ptr_port);

/* FUNCTION NAME: clx_sfc_destroyPort
 * PURPOSE:
 *      Destroy SFC port
 * INPUT:
 *      unit  --  Device unit number
 *      port  --  SFC port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_sfc_destroyPort(
    const UI32_T unit,
    const CLX_PORT_T port);

/* FUNCTION NAME: clx_sfc_getPort
 * PURPOSE:
 *      Get SFC port from SFC header content
 * INPUT:
 *      unit     --  Device unit number
 *      ptr_key  --  SFC header content
 * OUTPUT:
 *      ptr_port --  SFC port
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_sfc_getPort(
    const UI32_T unit,
    const CLX_SFC_ENCAP_KEY_T *ptr_key,
    CLX_PORT_T *ptr_port);

/* FUNCTION NAME: clx_sfc_getKey
 * PURPOSE:
 *      Get SFC header content from SFC port
 * INPUT:
 *      unit     --  Device unit number
 *      port     --  SFC port
 * OUTPUT:
 *      ptr_key  --  SFC header content
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_sfc_getKey(
    const UI32_T unit,
    const CLX_PORT_T port,
    CLX_SFC_ENCAP_KEY_T *ptr_key);

/* FUNCTION NAME: clx_sfc_addForwarder
 * PURPOSE:
 *      Add service function forwarder (SFF)
 * INPUT:
 *      unit           --  Device unit number
 *      ptr_forwarder  --  SFC forwarder
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_sfc_addForwarder(
    const UI32_T unit,
    const CLX_SFC_FORWARDER_T *ptr_forwarder);

/* FUNCTION NAME: clx_sfc_delForwarder
 * PURPOSE:
 *      Delete service function forwarder (SFF)
 * INPUT:
 *      unit           --  Device unit number
 *      ptr_forwarder  --  SFC forwarder
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_sfc_delForwarder(
    const UI32_T unit,
    const CLX_SFC_FORWARDER_T *ptr_forwarder);

/* FUNCTION NAME: clx_sfc_getForwarder
 * PURPOSE:
 *      Get service function forwarder (SFF) content
 * INPUT:
 *      unit           --  Device unit number
 *      ptr_forwarder  --  SFC forwarder
 * OUTPUT:
 *      ptr_forwarder  --  SFC forwarder
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_sfc_getForwarder(
    const UI32_T unit,
    CLX_SFC_FORWARDER_T *ptr_forwarder);

#endif