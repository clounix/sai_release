/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_acl.h
 * PURPOSE:
 *    Provide HAL driver API functions for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_LIGHTNING_ACL_H
#define HAL_LIGHTNING_ACL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_acl.h>
#include <hal/common/hal_acl.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_LIGHTNING_ACL_UDF_INT_KEY_VLD_BMP_FLW             (CLX_ACL_UDF_INTERNAL_KEY_L2_SA_GROUP_LABEL         |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_L2_DA_GROUP_LABEL         |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_L3_SA_GROUP_LABEL         |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_L3_DA_GROUP_LABEL         |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_INTF_GROUP_LABEL          |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_SERVICE_GROUP_LABEL       |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_LOU                       |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_BDID                      |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_L3_INTF_ID                |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_STAG_VID                  |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_CTAG_VID                  |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_STAG_PCP_DEI              |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_CTAG_PCP_DEI              |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_VLAN_TAG_MODE_1Q          |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_L3_ROUTE)
#define HAL_LIGHTNING_ACL_UDF_INT_KEY_VLD_BMP_IGR             (HAL_LIGHTNING_ACL_UDF_INT_KEY_VLD_BMP_FLW                |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_PORT_BITMAP)
#define HAL_LIGHTNING_ACL_UDF_INT_KEY_VLD_BMP_EGR             (CLX_ACL_UDF_INTERNAL_KEY_LOU                       |   \
                                                         CLX_ACL_UDF_INTERNAL_KEY_PORT_BITMAP)
#define HAL_LIGHTNING_ACL_UDF_0_PKG_TLV_BASE_ID               (0)
#define HAL_LIGHTNING_ACL_ACTION_FLAGS_IGR                    (CLX_ACL_ACTION_FLAGS_METER_VALID                   |   \
                                                         CLX_ACL_ACTION_FLAGS_COUNTER_VALID                 |   \
                                                         CLX_ACL_ACTION_FLAGS_DIST_COUNTER_VALID            |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_BLIND        |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_GREEN        |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_YELLOW       |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_RED          |   \
                                                         CLX_ACL_ACTION_FLAGS_CANCEL_LEARN                  |   \
                                                         CLX_ACL_ACTION_FLAGS_BYPASS_RPF_CHECK_FAIL         |   \
                                                         CLX_ACL_ACTION_FLAGS_BYPASS_TTL_CHECK_FAIL         |   \
                                                         CLX_ACL_ACTION_FLAGS_COPY_TO_CPU                   |   \
                                                         CLX_ACL_ACTION_FLAGS_REDIRECT                      |   \
                                                         CLX_ACL_ACTION_FLAGS_DROP                          |   \
                                                         CLX_ACL_ACTION_FLAGS_TO_CPU_DROP                   |   \
                                                         CLX_ACL_ACTION_FLAGS_PKT_REWRITE                   |   \
                                                         CLX_ACL_ACTION_FLAGS_L3_DA_GROUP_LABEL             |   \
                                                         CLX_ACL_ACTION_FLAGS_SAMPLE_TO_MIR                 |   \
                                                         CLX_ACL_ACTION_FLAGS_KEEP_TTL                      |   \
                                                         CLX_ACL_ACTION_FLAGS_DTEL_VALID                    |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_INVALID            |   \
                                                         CLX_ACL_ACTION_FLAGS_FWD_ACTION_INVALID)
#define HAL_LIGHTNING_ACL_ACTION_FLAGS_EGR                    (CLX_ACL_ACTION_FLAGS_METER_VALID                   |   \
                                                         CLX_ACL_ACTION_FLAGS_COUNTER_VALID                 |   \
                                                         CLX_ACL_ACTION_FLAGS_DIST_COUNTER_VALID            |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_BLIND        |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_GREEN        |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_YELLOW       |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_COLOR_RED          |   \
                                                         CLX_ACL_ACTION_FLAGS_COPY_TO_CPU                   |   \
                                                         CLX_ACL_ACTION_FLAGS_DROP                          |   \
                                                         CLX_ACL_ACTION_FLAGS_TO_CPU_DROP                   |   \
                                                         CLX_ACL_ACTION_FLAGS_SAMPLE_TO_MIR                 |   \
                                                         CLX_ACL_ACTION_FLAGS_SAMPLE_HIGH_LATENCY           |   \
                                                         CLX_ACL_ACTION_FLAGS_TS_REPLACE_MAC                |   \
                                                         CLX_ACL_ACTION_FLAGS_DTEL_VALID                    |   \
                                                         CLX_ACL_ACTION_FLAGS_QOS_ACTION_INVALID            |   \
                                                         CLX_ACL_ACTION_FLAGS_FWD_ACTION_INVALID)
#define HAL_LIGHTNING_ACL_IGR_ACL_GROUP_LABEL_LSB_VLD_BITS    (7) /* reserve msb 3 bits for dtel */
#define HAL_LIGHTNING_ACL_REWR_PAGE_NUM                       (32)


/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_lightning_acl_setActiveUcp(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             ucp_bmp);

CLX_ERROR_NO_T
hal_lightning_acl_setUcpCfg(
    const UI32_T                    unit,
    const UI32_T                    tbl_id,
    const UI32_T                    ucp_id,
    const HAL_UCP_FRM_TYP_ENUM_T    frame_type,
    const UI32_T                    *ptr_buf);

CLX_ERROR_NO_T
hal_lightning_acl_setUcpPbmEn(
    const UI32_T    unit,
    const UI32_T    tbl_id,
    const UI32_T    ucp_id,
    const UI32_T    *ptr_buf);

CLX_ERROR_NO_T
hal_lightning_acl_addHwEntry(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             entry_1x_id,
    const UI32_T             norm_width,
    UI32_T                   (*ptr_entry_2d_buf)[CDB_ICIA_COM_TCAM_4X_WORDS]);

CLX_ERROR_NO_T
hal_lightning_acl_setHwEntryVld(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             hw_entry_id,
    const UI32_T             norm_width,
    const BOOL_T             entry_valid);

CLX_ERROR_NO_T
hal_lightning_acl_readHwEntry(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             entry_1x_id,
    const UI32_T             norm_width,
    UI32_T                   (*ptr_entry_2d_buf)[CDB_ICIA_COM_TCAM_4X_WORDS]);

CLX_ERROR_NO_T
hal_lightning_acl_delHwEntry(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             entry_1x_id,
    const UI32_T             norm_width);

CLX_ERROR_NO_T
hal_lightning_acl_clearContHwEntry(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             start_1x_entry,
    const UI32_T             last_1x_entry);

CLX_ERROR_NO_T
hal_lightning_acl_moveHwEntry(
    const UI32_T               unit,
    const CLX_ACL_GROUP_T      type,
    const I32_T                src_1x_entry_id,
    const I32_T                dst_1x_entry_id,
    const UI32_T               tot_1x_move_entry_num,
    const DCC_DMA_D2D_DIR_T    d2d_dir,
    const UI32_T               shift_cnt,
    const UI32_T               cont_move);

#endif /* End of HAL_LIGHTNING_ACL_H */

