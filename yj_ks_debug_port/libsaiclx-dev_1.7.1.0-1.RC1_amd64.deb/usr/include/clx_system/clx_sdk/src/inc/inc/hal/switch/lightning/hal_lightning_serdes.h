/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_serdes.h
 * PURPOSE:
 *      It provide HAL_LIGHTNING_SERDES module API.
 * NOTES:
 *
 */

#ifndef HAL_LIGHTNING_SERDES_H
#define HAL_LIGHTNING_SERDES_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

typedef struct
{
    C8_T    *ptr_field_name;
    UI32_T table_id;
    UI32_T filed_id;
    UI32_T lane_offset;
} TECH_DUMP_REG_PHY_ENTRY_T;

typedef struct
{
    C8_T                     *ptr_phy_name;
    UI32_T                   table_total_fields;
    TECH_DUMP_REG_PHY_ENTRY_T *ptr_phy_entry;
} TECH_DUMP_REG_PHY_T;

typedef struct
{
    C8_T    *ptr_field_name;
    UI32_T base_addr;
    UI32_T macro_offset;
    UI32_T lane_offset;
    UI32_T length;
} TECH_DUMP_MEM_PHY_ENTRY_T;

typedef struct
{
    C8_T                     *ptr_phy_name;
    UI32_T                   table_total_fields;
    TECH_DUMP_MEM_PHY_ENTRY_T *ptr_phy_entry;
} TECH_DUMP_MEM_PHY_T;

typedef struct
{
    C8_T                     *ptr_phy_name;
    UI32_T                   table_total_fields;
    TECH_DUMP_REG_PHY_ENTRY_T *ptr_phy_entry;
} TECH_DUMP_COEF_PHY_T;

typedef struct msgq_desc
{
    UI32_T                   write_idx; /* byte size */
    UI32_T                   read_idx;  /* byte size */
    UI32_T                   buf_base;
    UI32_T                   buf_size;
    UI32_T                   size_mask;
} MSGQ_DESC_T;

typedef struct ser_element
{
    C8_T                     *ser_String;
    UI32_T                   ser_err_count;
} SER_ELE_LIST_T;

typedef struct msgq_event
{
    C8_T                     *ptr_event_str;
    UI32_T                   event_id;
} MSGQ_EVENT_LIST_T;

typedef union
{
    struct
    {
        UI32_T                   event_id : 16;
        UI32_T                   lane_id  : 8;
        UI32_T                   resv     : 8;
    }bits;
    UI32_T raw;
} MSGQ_EVENT_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEthxMem(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEthlMem(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEthxReg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEthlReg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEthxCoef(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEthlCoef(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEthxMsgq(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEthlMsgq(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const UI32_T                        more);

CLX_ERROR_NO_T
hal_lightning_serdes_dumpEyeBER(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_cnt);

CLX_ERROR_NO_T
hal_lightning_serdes_drawEyeScan(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_cnt);

#endif   /* End of HAL_LIGHTNING_SERDES_H */