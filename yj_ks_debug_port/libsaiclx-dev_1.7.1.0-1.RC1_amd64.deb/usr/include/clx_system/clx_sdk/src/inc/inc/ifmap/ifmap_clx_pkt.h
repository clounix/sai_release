/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  ifmap_clx_pkt.h
 * PURPOSE:
 *      It provide user port to CLX port translation PKT API.
 * NOTES:
 *
 */
#ifndef IFMAP_CLX_PKT_H
#define IFMAP_CLX_PKT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_pkt.h>
#include <clx_netif.h>


CLX_ERROR_NO_T
ifmap_clx_pkt_setRxConfig(
    const UI32_T                unit,
    const CLX_PKT_RX_CFG_T      *ptr_rx_cfg);

CLX_ERROR_NO_T
ifmap_clx_pkt_getRxConfig(
    const UI32_T                unit,
          CLX_PKT_RX_CFG_T      *ptr_rx_cfg);

CLX_ERROR_NO_T
ifmap_clx_pkt_sendPacket(
    const UI32_T                unit,
    const UI32_T                channel,
    const CLX_PKT_TX_PKT_T      *ptr_pkt);

CLX_ERROR_NO_T
ifmap_clx_pkt_setRxMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        queue,
    const CLX_PKT_RX_REASON_BITMAP_T    reason_bitmap);

CLX_ERROR_NO_T
ifmap_clx_pkt_getRxMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        queue,
          CLX_PKT_RX_REASON_BITMAP_T    *ptr_reason_bitmap);

CLX_ERROR_NO_T
ifmap_clx_pkt_createIntf(
    const UI32_T                unit,
    CLX_NETIF_INTF_T            *ptr_net_intf,
    UI32_T                      *ptr_intf_id);

CLX_ERROR_NO_T
ifmap_clx_pkt_createProfile(
    const UI32_T                unit,
    CLX_NETIF_PROFILE_T         *ptr_net_profile,
    UI32_T                      *ptr_profile_id);

#endif
