/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_stat.h
 * PURPOSE:
 *    It provides HAL driver API functions for stat module.
 *
 * NOTES:
 *
 *
 */
#ifndef HAL_DAWN_STAT_H
#define HAL_DAWN_STAT_H
/* INCLUDE FILE DECLARATIONS
 */
#include <clx_stat.h>
#include <clx_tm.h>
#include <dcc/dcc_dma.h>
#include <hal/common/hal_cmn.h>
#include <hal/common/hal_cmn_drv.h>
#include <hal/common/hal_stat.h>
#include <hal/common/hal_sec.h>
#include <hal/switch/dawn/hal_dawn_cmn.h>


#define HAL_DAWN_STAT_USE_CLD_DMA

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_DAWN_STAT_SRV_CNT_IDX_OFFSET         (10)
#define HAL_DAWN_STAT_SRV_CNT_NUM_PER_BANK       ((1U << HAL_DAWN_STAT_SRV_CNT_IDX_OFFSET) * 6)
#define HAL_DAWN_STAT_SRV_CNT_BANK_NUM           (16)
#define HAL_DAWN_STAT_DST_CNT_NUM_PER_BANK       (256)
#define HAL_DAWN_STAT_DST_CNT_BANK_NUM           (4)
#define HAL_DAWN_STAT_MAC_NUM_PER_DIE            (32)
#define HAL_DAWN_STAT_LANE_NUM_PER_MAC           (4)
#define HAL_DAWN_STAT_ETHC_LANE_NUM              (256)
#define HAL_DAWN_STAT_ETHX_LANE_NUM              (4)
#define HAL_DAWN_STAT_TM_QUEUECNT_NUM_PER_PLANE  (600)
#define HAL_DAWN_STAT_TM_CPU_QUEUE_NUM           (48)
#define HAL_DAWN_STAT_TM_CPI_QUEUE_NUM           (8)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_DAWN_STAT_DBG_SHOW_INDENT(__space_num__) do  \
{                                                       \
    UI32_T (__temp__) = (__space_num__);                \
    while (0 != (__temp__))                             \
    {                                                   \
        osal_printf(" ");                               \
        (__temp__) -= 1;                                \
    }                                                   \
} while(0)

/* DATA TYPE DECLARATIONS
 */
typedef enum {
    HAL_DAWN_STAT_MIB_REG_RX_MCAST_PKT = 0,
    HAL_DAWN_STAT_MIB_REG_RX_BCAST_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_NUCAST_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_SYMBOL_ERR_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_RS_ERR_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_STOMP_CRC_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_CRC_ERR_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_UNK_OPC_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_UNDERSIZE_GOOD_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_UNDERSIZE_BAD_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_UNDERSIZE_OCTET,
    HAL_DAWN_STAT_MIB_REG_RX_PFC0_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_PFC1_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_PFC2_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_PFC3_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_PFC4_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_PFC5_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_PFC6_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_PFC7_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_DROP_PKT,
    HAL_DAWN_STAT_MIB_REG_RX_LENG_ERR_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_MCAST_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_BCAST_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_NUCAST_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_ERR_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_UNDERSIZE_GOOD_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_UNDERSIZE_BAD_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_UNDERSIZE_OCTET,
    HAL_DAWN_STAT_MIB_REG_TX_PFC0_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_PFC1_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_PFC2_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_PFC3_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_PFC4_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_PFC5_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_PFC6_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_PFC7_PKT,
    HAL_DAWN_STAT_MIB_REG_TX_DROP_PKT,
    HAL_DAWN_STAT_MIB_REG_TYPE_LAST
} HAL_DAWN_STAT_MIB_REG_TYPE_T;

typedef enum {
    HAL_DAWN_STAT_MIB_SRAM_RX_PAUSE_MC_PKT = 0,
    HAL_DAWN_STAT_MIB_SRAM_RX_PAUSE_MC_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_PAUSE_UC_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_PAUSE_UC_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_PFC_MC_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_PFC_MC_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_64_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_64_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_65_127_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_65_127_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_128_255_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_128_255_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_256_511_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_256_511_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_512_1023_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_512_1023_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_1024_1518_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_1024_1518_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_1519_2560_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_1519_2560_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_2561_MAX_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_LENG_2561_MAX_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_OS_GOOD_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_OS_GOOD_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_RX_OS_BAD_PKT,
    HAL_DAWN_STAT_MIB_SRAM_RX_OS_BAD_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_PAUSE_MC_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_PAUSE_MC_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_PFC_MC_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_PFC_MC_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_64_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_64_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_65_127_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_65_127_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_128_255_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_128_255_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_256_511_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_256_511_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_512_1023_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_512_1023_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_1024_1518_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_1024_1518_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_1519_2560_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_1519_2560_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_2561_MAX_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_LENG_2561_MAX_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_OS_GOOD_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_OS_GOOD_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TX_OS_BAD_PKT,
    HAL_DAWN_STAT_MIB_SRAM_TX_OS_BAD_OCTET,
    HAL_DAWN_STAT_MIB_SRAM_TYPE_LAST
} HAL_DAWN_STAT_MIB_SRAM_TYPE_T;

typedef enum {
    HAL_DAWN_STAT_TM_ENB_BUF_FULL_TRUNC = 0,
    HAL_DAWN_STAT_TM_ENB_BUF_FULL_ENQED,
    HAL_DAWN_STAT_TM_ENB_CT_PKT_CNT,
    HAL_DAWN_STAT_TM_ENB_SF_PKT_CNT,
    HAL_DAWN_STAT_TM_ENB_STR_PKT_CNT,
    HAL_DAWN_STAT_TM_ENB_LEN_INVALID_PKT_CNT,
    HAL_DAWN_STAT_TM_ENB_TOTAL_PKT_CNT,
    HAL_DAWN_STAT_TM_ENB_TYPE_LAST
} HAL_DAWN_STAT_TM_ENB_TYPE_T;

typedef enum {
    HAL_DAWN_STAT_TM_XNB_SOP_EVENT_FROM_ITM = 0,
    HAL_DAWN_STAT_TM_XNB_EOP_EVENT_FROM_ITM,
    HAL_DAWN_STAT_TM_XNB_SOP_EVENT_FROM_INFO,
    HAL_DAWN_STAT_TM_XNB_EOP_EVENT_FROM_INFO,
    HAL_DAWN_STAT_TM_XNB_SOP_EVENT_TO_INFO,
    HAL_DAWN_STAT_TM_XNB_EOP_EVENT_TO_INFO,
    HAL_DAWN_STAT_TM_XNB_SOP_EVENT_TO_ENB_0,
    HAL_DAWN_STAT_TM_XNB_EOP_EVENT_TO_ENB_0,
    HAL_DAWN_STAT_TM_XNB_SOP_EVENT_TO_ENB_1,
    HAL_DAWN_STAT_TM_XNB_EOP_EVENT_TO_ENB_1,
    HAL_DAWN_STAT_TM_XNB_EVENT_TYPE_LAST
} HAL_DAWN_STAT_TM_XBN_EVENT_TYPE_T;

typedef enum {
    HAL_DAWN_STAT_TM_ADM_RX_PKT_OUT = 0,
    HAL_DAWN_STAT_TM_ADM_RX_PKT_IN,
    HAL_DAWN_STAT_TM_ADM_TYPE_LAST
} HAL_DAWN_STAT_TM_ADM_TYPE_T;

typedef enum {
    HAL_DAWN_STAT_TM_EA_P_DROP_CNT_Q0 = 0,
    HAL_DAWN_STAT_TM_EA_P_DROP_CNT_Q1,
    HAL_DAWN_STAT_TM_EA_P_DROP_CNT_Q2,
    HAL_DAWN_STAT_TM_EA_P_DROP_CNT_Q3,
    HAL_DAWN_STAT_TM_EA_P_DROP_CNT_Q4,
    HAL_DAWN_STAT_TM_EA_P_DROP_CNT_Q5,
    HAL_DAWN_STAT_TM_EA_P_DROP_CNT_Q6,
    HAL_DAWN_STAT_TM_EA_P_DROP_CNT_Q7,
    HAL_DAWN_STAT_TM_EA_P_TYPE_LAST
} HAL_DAWN_STAT_TM_EA_P_TYPE_T;

typedef enum {
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_Q0 = 0,
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_Q1,
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_Q2,
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_Q3,
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_Q4,
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_Q5,
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_Q6,
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_Q7,
    HAL_DAWN_STAT_TM_EA_G_DROP_CNT_STR,
    HAL_DAWN_STAT_TM_EA_G_TYPE_LAST
} HAL_DAWN_STAT_TM_EA_G_TYPE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_dawn_stat_init
 * PURPOSE:
 *      Init stat module control blocks.
 * INPUT:
 *      unit                -- device unit number
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK            -- init success.
 *      CLX_E_NO_MEMORY     -- allocate control block failed
 *      CLX_E_OTHERS        -- init fail
 *      CLX_E_BAD_PARAMETER -- parameter invalid
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_init(
    const UI32_T            unit);

/* FUNCTION NAME: hal_dawn_stat_deinit
 * PURPOSE:
 *      Deinit stat module control blocks and free resource.
 * INPUT:
 *      unit                -- device unit number
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK            -- deinit success
 *      CLX_E_OTHERS        -- deInit fail
 *      CLX_E_BAD_PARAMETER -- parameter invalid
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_deinit(
    const UI32_T            unit);

/* FUNCTION NAME:   hal_dawn_stat_getTmCnt
 * PURPOSE:
 *      This API is used to get counter by port, queue, and TM counter type.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Port ID
 *    handler              --  The handler of TM queue
 *    type                 --  The TM counter type
 *
 * OUTPUT:
 *    ptr_cnt              --  Counter value
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_OTHERS         --  Operation failed
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getTmCnt(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_TM_HANDLER_T       handler,
    const CLX_STAT_TM_CNT_TYPE_T type,
    CLX_STAT_TM_CNT_T            *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_clearTmCnt
 * PURPOSE:
 *      This API is used to clear counter by port, queue, and TM counter type.
 * INPUT:
 *    unit                 --  Device unit number
 *    port                 --  Port ID
 *    handler              --  The handler of TM queue
 *    type                 --  The TM counter type
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK             --  Success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.
 *    CLX_E_OTHERS         --  Operation failed
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearTmCnt(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_TM_HANDLER_T       handler,
    const CLX_STAT_TM_CNT_TYPE_T type);

/* FUNCTION NAME:   hal_dawn_stat_getDistCnt
 * PURPOSE:
 *      This API is used to get a distribution counter.
 * INPUT:
 *    unit                  --  Device unit number
 *    cnt_id                --  Counter ID
 *
 * OUTPUT:
 *    ptr_cnt               --  Counter
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND --  The counter has not been created.
 *    CLX_E_OTHERS          --  Operation failed.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getDistCnt(
    const UI32_T        unit,
    const UI32_T        cnt_id,
    CLX_STAT_DIST_CNT_T *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_clearDistCnt
 * PURPOSE:
 *      This API is used to clear a distribution counter.
 * INPUT:
 *    unit                  --  Device unit number
 *    cnt_id                --  Counter ID
 * OUTPUT:
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND --  The counter has not been created.
 *    CLX_E_OTHERS          --  Operation failed
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearDistCnt(
    const UI32_T unit,
    const UI32_T cnt_id);

/* FUNCTION NAME:   hal_dawn_stat_getCntHWIdx
 * PURPOSE:
 *      This API is used to get PP counter HW index using SW index
 * INPUT:
 *    unit                  --  Device unit number
 *    sw_cnt_id             --  SW counter id
 *    cnt_type              --  counter type
 *    pp_obj_type           --  PP binding object type
 *
 * OUTPUT:
 *    ptr_hw_cnt_idx        --  HW counter idx
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 *    CLX_E_TABLE_FULL      --  No available HW resource
 *    CLX_E_ENTRY_NOT_FOUND --  The SW counter has not been created.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getCntHWIdx(
    const UI32_T                     unit,
    const UI32_T                     sw_cnt_id,
    const HAL_STAT_HW_TYPE_T         cnt_type,
    const HAL_STAT_PP_OBJ_TYPE_T     pp_obj_type,
    UI32_T                           *ptr_hw_cnt_idx);

/* FUNCTION NAME:   hal_dawn_stat_getCntSWId
 * PURPOSE:
 *      This API is used to get PP counter SW ID using HW index
 * INPUT:
 *    unit                  --  Device unit number
 *    hw_cnt_idx            --  HW counter idx in HW table
 *    cnt_type              --  counter type
 *
 * OUTPUT:
 *    ptr_sw_cnt_id         --  HW counter id
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getCntSWId(
    const UI32_T                     unit,
    const UI32_T                     hw_cnt_idx,
    const HAL_STAT_HW_TYPE_T         cnt_type,
    UI32_T                           *ptr_sw_cnt_id);

/* FUNCTION NAME:   hal_dawn_stat_getMibSram
 * PURPOSE:
 *      This API is used to get port MIB raw counter
 * INPUT:
 *    unit                  --  Device unit number
 *    port                  --  Physical port
 *    hw_type               --  The type of HW, ETHC or ETHX
 *    cnt_type              --  The type of counter
 *
 * OUTPUT:
 *    ptr_cnt               --  Pointer to counter
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getMibSram(
    const UI32_T                        unit,
    const UI32_T                        port,
    const HAL_STAT_HW_TYPE_T            hw_type,
    const HAL_DAWN_STAT_MIB_SRAM_TYPE_T  cnt_type,
    UI64_T                              *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_clearMibSram
 * PURPOSE:
 *      This API is used to clear port MIB raw counter
 * INPUT:
 *    unit                  --  Device unit number
 *    port                  --  Physical port
 *    hw_type               --  The type of HW, ETHC or ETHX
 *    cnt_type              --  The type of counter
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearMibSram(
    const UI32_T                        unit,
    const UI32_T                        port,
    const HAL_STAT_HW_TYPE_T            hw_type,
    const HAL_DAWN_STAT_MIB_SRAM_TYPE_T  cnt_type);


/* FUNCTION NAME:   hal_dawn_stat_getMibReg
 * PURPOSE:
 *      This API is used to get port MIB raw counter
 * INPUT:
 *    unit                  --  Device unit number
 *    port                  --  Physical port
 *    hw_type               --  The type of HW, ETHC or ETHX
 *    cnt_type              --  The type of counter
 *
 * OUTPUT:
 *    ptr_cnt               --  Pointer to counter
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getMibReg(
    const UI32_T                        unit,
    const UI32_T                        port,
    const HAL_STAT_HW_TYPE_T            hw_type,
    const HAL_DAWN_STAT_MIB_REG_TYPE_T   cnt_type,
    UI64_T                              *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_clearMibReg
 * PURPOSE:
 *      This API is used to clear port MIB raw counter
 * INPUT:
 *    unit                  --  Device unit number
 *    port                  --  Physical port
 *    hw_type               --  The type of HW, ETHC or ETHX
 *    cnt_type              --  The type of counter
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearMibReg(
    const UI32_T                        unit,
    const UI32_T                        port,
    const HAL_STAT_HW_TYPE_T            hw_type,
    const HAL_DAWN_STAT_MIB_REG_TYPE_T   cnt_type);

/* FUNCTION NAME:   hal_dawn_stat_getMibRaw
 * PURPOSE:
 *      This API is used to get port MIB raw counter
 * INPUT:
 *    unit                  --  Device unit number
 *    port                  --  Physical port
 *    hw_type               --  The type of HW, ETHC or ETHX
 *    cnt_type              --  The type of counter
 *
 * OUTPUT:
 *    ptr_cnt               --  Pointer to counter
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getMibRaw(
    const UI32_T                        unit,
    const UI32_T                        port,
    const HAL_STAT_HW_TYPE_T            hw_type,
    const HAL_DAWN_STAT_MIB_SRAM_TYPE_T  cnt_type,
    UI64_T                              *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_clearMibRaw
 * PURPOSE:
 *      This API is used to clear port MIB raw counter
 * INPUT:
 *    unit                  --  Device unit number
 *    port                  --  Physical port
 *    hw_type               --  The type of HW, ETHC or ETHX
 *    cnt_type              --  The type of counter
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearMibRaw(
    const UI32_T                        unit,
    const UI32_T                        port,
    const HAL_STAT_HW_TYPE_T            hw_type,
    const HAL_DAWN_STAT_MIB_SRAM_TYPE_T  cnt_type);

/* FUNCTION NAME:   hal_dawn_stat_getTmRaw
 * PURPOSE:
 *      This API is used to get TM raw counter
 * INPUT:
 *    unit                  --  Device unit number
 *    inst_idx              --  Instance index
 *    sub_idx               --  Sub-instance index
 *    type                  --  TM counter type
 *    entry_idx             --  Entry index
 *    field_id              --  Counter index of the corresponding field
 *
 * OUTPUT:
 *    ptr_cnt               --  Pointer to counter
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getTmRaw(
    const UI32_T                    unit,
    const UI32_T                    inst_idx,
    const UI32_T                    sub_idx,
    const HAL_STAT_HW_TYPE_T        type,
    const UI32_T                    entry_idx,
    const UI32_T                    field_id,
    UI64_T                          *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_clearTmRaw
 * PURPOSE:
 *      This API is used to clear port MIB raw counter
 * INPUT:
 *    unit                  --  Device unit number
 *    inst_idx              --  Instance index
 *    sub_idx               --  Sub-instance index
 *    type                  --  TM counter type
 *    entry_idx             --  Entry index
 *    field_id              --  Counter index of the corresponding field
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearTmRaw(
    const UI32_T                    unit,
    const UI32_T                    inst_idx,
    const UI32_T                    sub_idx,
    const HAL_STAT_HW_TYPE_T        type,
    const UI32_T                    entry_idx,
    const UI32_T                    field_id);

/* FUNCTION NAME:   hal_dawn_stat_getUpdateCnt
 * PURPOSE:
 *      This API is used to get how many times the counter has been updated
 * INPUT:
 *    unit                  --  Device unit number
 *
 * OUTPUT:
 *    ptr_cnt               --  Update count
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getUpdateCnt(
    const UI32_T                    unit,
    UI64_T                          *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_getExcptCnt
 * PURPOSE:
 *      This API is used to get PP exception counter by exception code
 * INPUT:
 *    unit                  --  Device unit number
 *    excpt_id              --  The exception code
 *
 * OUTPUT:
 *    ptr_cnt               --  Pointer to counter value
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getExcptCnt(
    const UI32_T                unit,
    const HAL_DAWN_CMN_EXCPT_T   excpt_id,
    UI64_T                      *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_clearExcptCnt
 * PURPOSE:
 *      This API is used to clear PP exception counter by exception code
 * INPUT:
 *    unit                  --  Device unit number
 *    excpt_id              --  The exception code
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearExcptCnt(
    const UI32_T                unit,
    const HAL_DAWN_CMN_EXCPT_T   excpt_id);

/* FUNCTION NAME:   hal_dawn_stat_getStormCnt
 * PURPOSE:
 *      This API is used to get PP storm control counter by index
 * INPUT:
 *    unit                  --  Device unit number
 *    plane                 --  Plane number
 *    cnt_idx               --  The strom control counter index
 *
 * OUTPUT:
 *    ptr_cnt               --  Pointer to corresponding counter entry (3 values)
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_getStormCnt(
    const UI32_T                  unit,
    const UI32_T                  plane,
    const UI32_T                  cnt_idx,
    HAL_SEC_SCCOUNTER_ENTRY_T     *ptr_cnt);

/* FUNCTION NAME:   hal_dawn_stat_clearStormCnt
 * PURPOSE:
 *      This API is used to clear PP storm control counter by index
 * INPUT:
 *    unit                  --  Device unit number
 *    plane                 --  Plane number
 *    cnt_idx               --  The strom control counter index
 *
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearStormCnt(
    const UI32_T                unit,
    const UI32_T                plane,
    const UI32_T                cnt_idx);

/* FUNCTION NAME:   hal_dawn_stat_showDbgCnt
 * PURPOSE:
 *      This API is used to show debug counter
 * INPUT:
 *    unit                  --  Device unit number
 *    port                  --  CLX port number
 *    stage_bmp             --  The bitmap of stage:
 *                              bit0: mac; bit1: ipm; bit2: ios: bit3: ipp; bit4: xbn; bit5: tm;
 *                              bit6: epp; bit7: epm; bit8: lbm
 * OUTPUT:
 *    None
 *
 * RETURN:
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_showDbgCnt(
    const UI32_T                unit,
    const UI32_T                port,
    const UI32_T                stage_bmp,
    const UI32_T                filter0);

/* FUNCTION NAME:   hal_dawn_stat_clearDbgCnt
 * PURPOSE:
 *      This API is used to clear all debug counter
 * INPUT:
 *    unit                  --  Device unit number
 * OUTPUT:
 *    None
 *
 * RETURN:
 *    CLX_E_OK              --  Success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_stat_clearDbgCnt(
    const UI32_T                unit);

CLX_ERROR_NO_T
hal_dawn_stat_getAiqWatermark(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_TM_HANDLER_T  handler,
    CLX_TM_BUF_WATERMARK_T  *ptr_cnt);

CLX_ERROR_NO_T
hal_dawn_stat_clearAiqWatermark(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_TM_HANDLER_T  handler);

CLX_ERROR_NO_T
hal_dawn_stat_clearAoqWatermark(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_TM_HANDLER_T  handler);

CLX_ERROR_NO_T
hal_dawn_stat_getAoqWatermark(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_TM_HANDLER_T  handler,
    CLX_TM_BUF_WATERMARK_T  *ptr_cnt);



#endif /* End of HAL_DAWN_STAT_H */
