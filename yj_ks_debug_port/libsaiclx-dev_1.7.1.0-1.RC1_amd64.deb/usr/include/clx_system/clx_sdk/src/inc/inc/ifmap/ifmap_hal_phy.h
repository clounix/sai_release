/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   ifmap_hal_phy.h
 * PURPOSE:
 *      It provides user port set/show phy configuration.
 * NOTES:
 */

#ifndef IFMAP_HAL_PHY_H
#define IFMAP_HAL_PHY_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <hal/common/hal_phy.h>

/* FUNCTION NAME:   ifmap_hal_phy_mii_getPhyAddr
 * PURPOSE:
 *      Get PHY address of MDIO(Management Data Input/Output)
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      phy_type        -- Type of PHY such as internal or external
 * OUTPUT:
 *      ptr_up_id       -- Device uP number
 *      ptr_phy_addr    -- PHY address of MDIO
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_mii_getPhyAddr(
    const UI32_T                unit,
    const UI32_T                port_id,
    const HAL_PHY_PHY_TYPE_T    phy_type,
    UI32_T                      *ptr_up_id,
    HAL_PHY_PHY_ADDR_T          *ptr_phy_addr);

/* FUNCTION NAME:   ifmap_hal_phy_getPrbsErrorCnt
 * PURPOSE:
 *      Get the PRBS checker error count
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 *      lane_bmp         -- specify the lanes to report prbs error cnt
 * OUTPUT:
 *      ptr_ber_mode     -- for PAM4/NRZ PRBS, ber_mode is enable/disable
 *      ptr_error_cnt    -- Error bit counter (including lock sts + error counter)
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_getPrbsErrorCnt(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    HAL_PHY_PRBS_BER_TYPE_T             *ptr_ber_mode,
    HAL_PHY_PRBS_ERRCNT_T               *ptr_error_cnt);

/* FUNCTION NAME:   ifmap_hal_phy_getFecCnt
 * PURPOSE:
 *      get fec counter value based on counter type
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      lane_id         -- Device lane number
 *      cnt_type        -- CERR/UCERR/lane SERR
 * OUTPUT:
 *      ptr_cnt         -- fec counter value
 * RETURN:
 *      CLX_E_OK             -- Operate success.
 *      CLX_E_BAD_PARAMETER  -- Invalid input.
 *      CLX_E_NOT_SUPPORT    -- Hardware does not support.
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_getFecCnt(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_id,
    const HAL_PHY_FEC_CNT_TYPE_T        cnt_type,
    HAL_PHY_FEC_CNT_T                   *ptr_cnt);

/* FUNCTION NAME:   ifmap_hal_phy_dumpSerDesInfo
 * PURPOSE:
 *      Dump serdes internal information
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 *      lane_bmp         -- Focus the lane list within the port (started from 0)
 *      dump_type        -- HAL_PHY_SERDES_DUMP_TYPE_MEM/HAL_PHY_SERDES_DUMP_TYPE_REG/HAL_PHY_SERDES_DUMP_TYPE_COEF
 *      more             -- more flag to dump more detail
 * OUTPUT:
 *      serdes sdk module osal_printf directly.
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_dumpSerDesInfo(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const UI32_T                        lane_bmp,
    const HAL_PHY_SERDES_DUMP_TYPE_T    dump_type,
    const UI32_T                        more);

/* FUNCTION NAME:   ifmap_hal_phy_setPrbsPattern
 * PURPOSE:
 *      Set the PRBS test pattern
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      prbs_pattern    -- Test pattern on PRBS
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_setPrbsPattern(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_PRBS_PATTERN_TYPE_T   prbs_pattern);


/* FUNCTION NAME:   ifmap_hal_phy_getPrbsPattern
 * PURPOSE:
 *      Get the PRBS test pattern
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 * OUTPUT:
 *      ptr_prbs_pattern -- Test pattern on PRBS
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_getPrbsPattern(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    HAL_PHY_PRBS_PATTERN_TYPE_T         *ptr_prbs_pattern);

/* FUNCTION NAME:   ifmap_hal_phy_setPrbsChecker
 * PURPOSE:
 *      Enable/disable the PRBS test checker
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 *      prbs_checker     -- Enable/Disable checker
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_setPrbsChecker(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_PRBS_CHECKER_TYPE_T   prbs_checker);

/* FUNCTION NAME:   ifmap_hal_phy_getPrbsChecker
 * PURPOSE:
 *      Get the PRBS test checker status (enable/disable)
 * INPUT:
 *      unit             -- Device unit number
 *      port_id          -- Device port number
 * OUTPUT:
 *      ptr_prbs_checker -- Test checker status (enable/disable)
 * RETURN:
 *      CLX_E_OK         -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_getPrbsChecker(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    HAL_PHY_PRBS_CHECKER_TYPE_T         *ptr_prbs_checker);


/* FUNCTION NAME:   ifmap_hal_phy_dumpEyeScan
 * PURPOSE:
 *      Dump eye scan result
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      lane_cnt        -- Lane count within the port
 *      property        -- Optional perperty setting
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_dumpEyeScan(
    const UI32_T                    unit,
    const UI32_T                    port_id,
    const UI32_T                    lane_cnt,
    const HAL_PHY_EYE_SCAN_TYPE_T   property);

/* FUNCTION NAME:   ifmap_hal_phy_setMdioReg
 * PURPOSE:
 *      Set MDIO(Management Data Input/Output) register of PHY
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      phy_type        -- Type of PHY such as internal or external
 *      dev_type        -- Type of PHY device
 *      reg_addr        -- Register address
 *      reg             -- Register data
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Operate success
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_setMdioReg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_PHY_TYPE_T            phy_type,
    const HAL_PHY_MDIO_DEVICE_TYPE_T    dev_type,
    const UI32_T                        reg_addr,
    const UI32_T                        reg);

/* FUNCTION NAME:   ifmap_hal_phy_getMdioReg
 * PURPOSE:
 *      Get MDIO(Management Data Input/Output) register of PHY
 * INPUT:
 *      unit            -- Device unit number
 *      port_id         -- Device port number
 *      phy_type        -- Type of PHY such as internal or external
 *      dev_type        -- Type of PHY device
 *      reg_addr        -- Register address
 * OUTPUT:
 *      ptr_reg         -- Register data
 * RETURN:
 *      CLX_E_OK        -- Operate success.
 *
 * NOTES:
 */
CLX_ERROR_NO_T
ifmap_hal_phy_getMdioReg(
    const UI32_T                        unit,
    const UI32_T                        port_id,
    const HAL_PHY_PHY_TYPE_T            phy_type,
    const HAL_PHY_MDIO_DEVICE_TYPE_T    dev_type,
    const UI32_T                        reg_addr,
    UI32_T                              *ptr_reg);


#endif